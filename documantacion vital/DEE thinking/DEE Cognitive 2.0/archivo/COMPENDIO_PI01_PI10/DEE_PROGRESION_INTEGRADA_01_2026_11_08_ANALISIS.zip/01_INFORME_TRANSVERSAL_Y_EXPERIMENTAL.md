# DEE — Progresión integrada PI01

Proyecto INVESTIGACION DEE. Autor del proyecto: Ivan Erick Tlaltecatl Morales. Inspección y ejecución:7–8 de noviembre de2026, America/Mexico_City. Universev27 y Thinking4.5.0 permanecen como base congelada. Este informe separa resultados científicos, migración operativa y comprobaciones documentales. El cierre incorpora los comprobantes de adopción, publicación documental y limpieza efectivamente producidos; la verificación del contenedor exacto se registra fuera del ZIP.

## Resultado científico y novedad

Una continuación completa del principal utilizó su memoria adquirida y su comparador existente bajo una selección física que cambió por consecuencias. En18 oportunidades reservadas obtuvo16 recursos reales de64bytes; la rama sin valencia negativa obtuvo12 y la de actuación anulada0. Las tres recorrieron el mismo calendario hastaT734101. En la misma vida principal se realizaron después doce usos de funciones anteriores, con12/12 primeras respuestas concordantes y929/929 entradas Native aplicadas. Una nueva carga en otro proceso conservó la historia y permitió otra oportunidad de la tarea: recurso17, T735843.

El avance no es descubrir por primera vez aprendizaje por consecuencias. CORE09, AA33 y Ciclo02 ya tenían resultados locales de esa clase. Es reutilizar un mecanismo legal compatible en la genealogía operativa actual, vincularlo a dos accesos que ya coexistían, comprobar utilidad bajo cambios reservados y conservar funciones anteriores. Se conserva la asistencia de un codec fijo que convierte la ruta física en una llamada MA/FI. No se demostró iniciativa libre, planificación autogenerada, recuperación autónoma general ni un algoritmo aritmético aprendido.

## Fuentes y frontera previa

Se reutilizó el expediente histórico de7noviembre sin repetir su inventario de260278rutas. La comparación inicial de selectores, registro de vida, snapshot y par completo corroboró **ECI02_OPERATIVA_PRINCIPAL_01, N67,T727225**, Manual DCS11-MM-001 de contenido1.26. No se eligió el mayor tick de vidas desconectadas. El futuro T727493 y MINUS T720592 son otras trayectorias.

La lectura técnica de los dos manuales oficiales Thinking fue completa en OOXML: MAR capítulos1–58 y anexosA–M,72tablas; LBM capítulos1–74 y anexosA–L,80tablas, encabezados y pies. Se leyeron como texto, no se ejecutaron sus cápsulas. Sus hashes locales coinciden con los históricos citados, lo que no equivale a comparar con bytes actuales de Biblioteca. No contienen medios ni ecuaciones OMML en el cuerpo inspeccionado. Los detalles y rangos exactos están en las coberturas MAR/LBM.

El Compendio se leyó completo, incluidos sus cuadros y actualizaciones. Las lecturas de CPC y campañas hasta Ciclo02 cubrieron58 contenidos únicos completos entre72 contenidos seleccionados; otras filas técnicas se marcaron parciales o de metadatos. CORE/Ingeniería/Procesos/Pensamiento/basal/OBP aportaron148 textos nuevos completos, una extensión completa y65 lecturas previas completas reutilizadas;3JSON estructurados siguen parciales. Las campañas MI/CF/ENTE/MA/MU/APD se revisaron mediante13 informes completos,12 decisiones y código/primarios dirigidos. Estos recuentos son por bloque: no deben sumarse como contenidos globalmente únicos, pues existen fuentes comunes. Los índices dan hashes, miembros ZIP y estado de lectura. No se leyó ciegamente toda la microtelemetría ni cada binario incrustado.

Se recuperaron sin reinventarlos: la distinción entre memoria y expresión; revisión selectiva de asociaciones; composición y reutilización de productos; acceso material remoto y temprano; comunicación con actualización del receptor; selección local por consecuencias; acciones útiles con referencia adquirida; persistencia completa y procedimientos de continuación. Las matrices históricas conservan vida, dominio, asistencia y evidencia. Su disponibilidad en la biblioteca no convierte esos aprendizajes en recuerdos del principal.

La genealogía actual procede de MA02 y sus continuaciones MU/FI, APD, DEE20 y ECI. No es la biografía física de E1_SOCIAL/CPC9/U0, aunque emplee mecanismos relacionados. El panel heredado ECI02 de12/12 y929/929 contaba solicitudes y componentes Native, respectivamente; no conceptos ni organismos. La adopción posterior de accesos explícitos y el fracaso anterior del proveedorR04 son hechos distintos. PI01 no borra aquel fallo, no restaura un JSON recuperado como si fuera un original íntegro y no incorpora luma negativa de MINUS copiando recuerdos.

## Organización y asistencia

La candidata **ECI02_PI01_MAIN** se originó en un importado completo y verificable del padre T727225, no en una recetaT0. Comparte un Runtime N67 que conserva los soportes MA, las asociaciones léxicas y el árbol preparado FI128. Se añadió externamente una traza binaria periférica por cinco interfaces legales en torno a(0,5,20). Su política inicialA y las oportunidades de cambio son arquitectura preparada; su historia posterior se adquiere mediante entradas y evoluciónv27.

La clasificación es **organización compuesta híbrida con acoplamiento externo explícito**. La frontera cognitiva funcional no se identifica con todo el universo por compartir Runtime. El snapshot conserva el mundo completo para no perder influencias fuera de los puertos nominales. Las rutas retornantes pueden extender el soporte más allá de las coordenadas de lectura.

La traza emite en una oportunidad genérica una de dos firmas activas SEM1: dirección(0,0,1)→ruta0 y(−1,1,1)→ruta1. El lector y el instanteq se fijaron antes de las reservas. Ruta0 llama exclusivamente al acceso adquirido MA/alfa; ruta1 llama exclusivamente al comparador FI128 con lector tempranoq+4. No se consultan ambos para elegir el resultado favorable. El calendario y la llamada de método son asistencia P0 del anfitrión, no una conexión material nativa cerrada ni un plan aprendido. El contenido leído se obtiene de las observaciones físicas, no del catálogo.

El entorno posee un cierre privado de polaridad±1. Esa condición no entra al selector ni a los lectores. La emisión final−1/0/+1 se aplica como comando. Si coincide con el cierre actual, el entorno copia realmente64bytes del reservorio al conjunto adquirido y comprueba su lectura/hash. El contador pertenece al entorno simulado: no es energía, metabolismo ni una medida de inteligencia.

Después de actuar, un retorno genérico de fracaso aporta valencia5 sobre el eco de la ruta realmente formada; un normalizador3 mantiene la interacción preparada. La firma de la próxima política la producev27. Python no escribe el bit de política, no elige la ruta óptima y no devuelve la respuesta correcta. Las oportunidades siguen iniciadas por el operador. Los diarios, semillas, nombres de caso y reglas privadas no son memoria accesible al lector DEE.

## Desarrollo y fallos conservados

R01 interpretó prematuramente un recibo SCHEDULED como si ya fuese terminal; se conservó el futuro con su entrada pendiente. R02 avanzó la misma solicitud hasta su frontera efectiva, sin duplicarla ni reiniciar la vida. La primera ubicación(47,49,53) produjo la primera firma, pero no conservó la traza requerida. El diagnóstico posterior desde copia completa mostró el portador24/Z+ hasta(47,49,44),T727486; el destino(47,49,45) tenía RAW2^62, semantic4,state0 y bloqueó la propuesta siguiente. No fue una suma aditiva ni prueba de agotamiento global. El normalizador llegó solo después. No se limpió el soporte para rescatar ese futuro.

El cruce estático con `lexico_compartido_apd04.py` sitúa(47,49,45) exactamente en un terminador previsto para la forma «quita»: origenJ=(47,47,47), dirección(0,1,0),k2,z2,signo negativo. Eso identifica una función de diseño compatible con el soporte observado; no demuestra su linaje completo ni que su ablación actual dañaría esa palabra, pues no se hizo tal corte. Por eso se relocalizó la nueva preparación, sin borrar aquel contexto como si fuese basura.

Una calibración R03 en(41,43,47) consiguióA→B mediante contacto de valencia, pero el análisis geométrico encontró un cruce nominal con FI. Esa rama se conservó como desarrollo. El tercer montaje espacial R04 se fijó por un cribado geométrico exacto, antes de medir su utilidad: primer origen lexicográfico con cinco rayos RAW0 y margen mínimo4 respecto del marco FI. Había8322 candidatos; no se probaron funcionalmente miles de geometrías hasta seleccionar un éxito. Esta separación no garantiza independencia de todo el contexto ni estabilidad ilimitada.

Los cinco episodios de desarrollo R04 dieron rutas0,1,1,1,0 y respuestasMA−,FI+,FI−,FI+,MA−, con3/5 recursos. Se usaron para fijar el diseño, no se cuentan como reserva independiente. Se conservan fuentes exactas de cada revisión ejecutada, errores, registros y estados adversos. R01/R02 revisan la semántica de admisión; las tres ubicaciones anteriores son las tres variantes físicas investigadas, no cuatro campañas nuevas.

## Reserva, controles y causalidad

`PROTOCOLO_RESERVA_R04.json` congeló18 pares numéricos nuevos, cargas de contexto11/17/23/29/101/103 y separaciones0/1/2 períodosN67. El cierre ambiental fue negativo en oportunidades0–5, positivo6–11 y negativo12–17. Se fijaron criterio mínimo15/18 recursos, ventaja mínima3 frente a omisión, ausencia de recursos con actuación anulada y conservación/reapertura. No se cambió el decodificador ni el criterio después de observar las respuestas.

| Vida/condición | Oportunidades | Rutas y respuestas válidas | Recursos ejecutados | Entradas Native únicas aplicadas |
|---|---:|---:|---:|---:|
|MAIN, retorno real|18|18/18|16/18|1347/1347|
|CONTROL_OMIT, sin valencia negativa|18|18/18|12/18|162/162|
|CONTROL_NULLED, acción anulada tras formarse|18|18/18|0/18|1701/1701|
|Desarrollo R04, no reserva|5|5/5|3/5|554/554|
|MAIN después de reabrir, no añadir al denominador reservado|1|1/1|1/1|9/9|

No hubo rechazos ni silencios en esas oportunidades puntuables. Las solicitudes de preparación, las operaciones administrativas y las calibraciones se conservan separadamente. Los rechazos antiguos del SQLite no son rechazos nuevos. Un mismo ID repetido en un alias de recibo no se cuenta otra vez; ramas con prefijo común tampoco son réplicas biológicas independientes.

El primer cambio reservado ocurrió después del fracaso6. Enq729572, MAIN seleccionó ruta0 con carga320. El encuentro del retorno enT729840 formó carga328,dirección(0,1,0), y la oportunidad7 enq729974 seleccionó ruta1,carga345. Sin valencia, el control conservó ruta0 ante la oportunidad común. La diferencia del retorno precede a que se ejecute FI: las entradas adicionales de FI no pueden explicar retrospectivamente esa primera decisión distinta.

En la oportunidad12, FI formó una respuesta negativa útil y mantuvo ruta1; por tanto no se trata simplemente de que ruta1 signifique siempre positivo. La utilidad se define por el comando material, no por una única ruta universalmente correcta. Después del fracaso13, q732252/ruta1,carga647, el retornoT732520 produjo carga655,dirección(1,0,0); q732587 volvió a ruta0,carga678, y el recurso se obtuvo. La anatomía prepara cómo puede cambiar una política binaria; la consecuencia efectivamente vivida determina su estado y uso posterior. Éste es el alcance local que respalda P2, sin regulaciónR2 general ni aprendizaje de una política arbitraria.

La actuación anulada dejó que se formasen decisiones y respuestas, pero impidió liberar archivos. El entorno no resolvió igual la tarea cuando se rompió el actuador. La omisión mantuvo el normalizador y la edad/calendario, pero retiró la valencia: no se afirma dosis total idéntica. Además, FI requiere más entradas que MA. Esa diferencia de coste aparece después de elegir el acceso y se registra, en vez de ocultarla como si todos los ensayos consumieran los mismos recursos.

El contraste usa tres ramas del mismo prefijo, no varios organismos independientes ni un estudio estadístico de poblaciones. Las variaciones reservadas acreditan transferencia dentro de ese codec, fase y dominio; no a todos los N, todos los tiempos ni otra geometría. No se investigaron en PI01 negociación, nuevo vocabulario, recuperación iniciada sin oportunidad externa ni control competente de Pendulum.

## Conservación y continuación de la misma historia

Después de los18 casos, MAIN utilizó consecutivamente luma+,nara−,clasifica−,suma+,alfa−,comparaciones14>3,2<11 y6=6 con cero material; suma6+7→13 y diferencia13−5→8; alfa− y luma+ otra vez. El13 real formado fue transportado a la petición siguiente; no se sustituyó por el esperado. El orden de esas dos operaciones lo pidió el investigador. La representación y el árbol aritmético son preparados, no un algoritmo descubierto por la vida.

El panel transcurrió deT734101 aT735466:12 primeras respuestas concordantes,929/929 entradas aplicadas y ninguna enseñanza. Se distingue este corte de conservación del corte finalT735843. Al cerrar y abrir otro proceso, la oportunidad18 usó MA−, produjo otro recurso y mantuvo sus17 archivos adquiridos. No se reseteó el entorno ni la memoria para empezar esa oportunidad. No se volvió a consultar todo el panel tras ese último paso; su alcance temporal queda explícito.

La exportación completa final contiene3214 miembros,147901306bytes y1009interfaces; conserva snapshot, agenda, recibos, metadata de progreso,SQLite,outbox y artefactos, incluido el banco de recursos. No hay entradas Native pendientes. El SQLite de la exportación fuente conservaba exclusivamente el exportar en processing, con recibo nativo/outbox exactos para conciliación. La carga del producto lo concilió sin purgarlo ni repetirlo. La migración oficial reserializó metadata administrativa y cambió SHA del contenedor sin alterar N/T/RAW/clocks ni el prefijo causal. `CONTROL/REAPERTURA_PRODUCTO_PI01.json` documenta esa equivalencia, 1009interfaces y112829recibos antes/después. Un hash físico no sustituye el conjunto operativo.

## Interpretación transversal y siguiente frontera

Los resultados apoyan mecanismos especializados que pueden compartir historia y participar en funciones integradas acotadas. No obligan a escoger entre especialización e integración. Una organización más amplia que nuestros lectores sigue siendo hipótesis: la huella no leída no es por sí sola capacidad oculta y el fallo de un lector no es incapacidad universal. La dependencia de encuentros, direcciones, fase y soportes distribuidos es física DEE; no acredita automáticamente equivalencia con un cerebro ni fenómenos cuánticos.

La principal ganancia utilizable es selección local de acceso revisada por consecuencias, conservando conocimientos heredados y efectos reales bajo un aparato explícito. La frontera pendiente está localizada: iniciativa y conexiones nativas de acceso en vez de llamadas del codec; contingencias más diversas sin un bit binario preparado; costes y retención a horizontes mayores; comunicación nueva incorporada en esta genealogía. No se ejecutan aquí esas extensiones. Las funciones sociales históricas permanecen en sus vidas/procedimientos, sin sumarlas ficticiamente al desempeño de MAIN.

## Presupuesto, preservación y alcance del expediente

El presupuesto inicial se fijó una vez:6horas, un escritor Native, un hilo,512MiB por trabajador y15GB locales. El controlNULLED quedó cerrado a00:32:14−06. La comprobación de procesos obligatoria fue denegada por sandbox y requirió permiso del sistema; la espera se extendió hasta después de08:14−06, superando el corte horario previsto05:08. No se reinició el reloj ni se oculta el incumplimiento del tiempo total. Tras resolverlo se ejecutó sólo la verificación de continuidad pendiente377ticks, exportación/migración0ticks y cierre documental; no otra búsqueda de diseños ni ampliación de la reserva.

Los originales, el futuro adverso, las ramas y los snapshots grandes permanecen locales. El expediente transportable no es respaldo completo del ente. Los manuales Thinking, los motores, el inventario antiguo y todos los estados densos no se duplican en el ZIP; sus localizadores/hashes permiten traer lo indispensable. Las coberturas distinguen lectura nueva, previa reutilizada, parcial, metadatos, recálculo documental y ejecución Native nueva.

La limpieza autorizada de la auditoría antigua se documenta después de ejecutarla y comprobarla. El ZIP histórico íntegro se preserva fuera de su temporal con sus comprobantes y código únicos; no se anida en esta entrega ni se confunde con respaldo operativo. El cierre efectivo, la edición vigente, las rutas finales y la limpieza se detallan a continuación y en la continuidad exportada.

## Cierre efectivo: único principal y producto incorporado

`CONTROL/ADOPCION_PRODUCTO_PI01.json` y el diario de promociones registran **COMMITTED** para **ECI02_PI01_MAIN, N67, T735843, perfil fisica_directa**. Es sucesor físico de ECI02_OPERATIVA_PRINCIPAL_01,T727225. El snapshot T735843 utilizado como padre de importación es un contenedor de transporte, no otro pasado biográfico. ACTIVO, PROYECTO, selección personal y configuración de candidata de la aplicación apuntan al mismo principal. La configuración gráfica se inspeccionó estáticamente; no se abrió la GUI para atribuirle una prueba no realizada.

Se incorporaron cuatro archivos al producto, conservando los bytes anteriores de los dos hooks modificados y los parches: `sistema/capacidades/progresion_integrada_01.py`, `sistema/capacidades/pi01_traza_legal_base.py`, `sistema/app/mundo_genesis_apd05.py` y `sistema/app/cola_local.py`. El nuevo contrato R04 y tres contratos afectados, catálogo y continuidad contienen el dominio y asistencia correspondientes. No se cambió v27 ni el WHL4.5.0. El control de publicación volvió a comparar los hashes del WHL, PYD, los dos manuales Thinking y el snapshot protegido del padre; no es una declaración de inmutabilidad de cada archivo de todo el proyecto.

Desde la raíz real `DEE thinking/DEE Cognitive 2.0`, los localizadores del conjunto adoptado son:

- `sistema/estado/checkpoints/ECI02_PI01_MAIN.T735843.085696415346.deetsnap.gz`,1619636bytes,SHA-256`4c585112f33b126a0ee6114e19ef203f0bab658f76545636a6e70f573d628a50`.
- `sistema/estado/vidas/ECI02_PI01_MAIN/VIDA.json`: identidad, snapshot y procedencia.
- `sistema/estado/servicios_persistentes/ECI02_PI01_MAIN`:SQLite, outbox y resultados; `servicios_locales/ECI02_PI01_MAIN`:artefactos y banco de recursos. Deben conservarse conjuntamente con el registro y snapshot.
- `sistema/estado/pares_iniciales/ECI02_PI01_MAIN`:copia emparejada completa preservada, manifiesto de origen3214miembros/147901306bytes. No debe importarse encima de una continuación que haya avanzado.

`ABRIR_DEE_COGNITIVE.bat` sigue siendo el lanzador. La interfaz material PI01 se utiliza con el gestor existente, no con otra plataforma. Para un uso futuro, desde esa raíz, primero se inicia el propietario existente pausado (comprobar que no hay otro propietario vivo):

```text
motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-iniciar --vida ECI02_PI01_MAIN --backend mente_unificada --eci01 --pausado --intervalo 60 --guardar-cada 3600 --max-segundos 7200
```

Los modos de petición son `eci01-pi01-estado` y `eci01-pi01-paso` mediante `mente-unificada-pedir`. La continuidad y el contrato incluidos contienen los ejemplos completos, los campos de la oportunidad y la conciliación. Una oportunidad PI01 sí es material y avanza historia; no debe ejecutarse como consulta de auditoría ni repetirse con otro ID cuando el resultado del primero sea incierto. Usar IDs únicos, reanudar para aplicar la cola y después pausar/guardar/cerrar. No utilizar `--nueva` ni una preparación desdeT0 para abrir esta vida.

La mejora adoptada es útil dentro de la tarea y conserva los doce usos comprobados hastaT735466, con un uso adicional de la tarea después de reabrir hastaT735843. No se afirma un panel nuevo completo en este último corte ni se atribuyen las historias de OMIT, NULLED, MINUS o CPC9 a MAIN. Los cuatro puntos materiales de ganancia son: estado de ruta modificado por consecuencia; selección distinta de acceso en la siguiente oportunidad; respuesta que procede del soporte MA/FI; liberación efectiva del recurso. La llamada entre método y ruta, el calendario y la interpretación siguen asistidos.

## Cierre documental y límites de verificación

Se publicó el mismo Manual rector **DCS11-MM-001, edición interna1.27**, conservando el nombre compatible `DEE_Cognitive_2_0_Manual_Maestro_DCS11_MM_001_Edicion_1_21.docx`. Sus221461bytes tienen SHA-256`dec1fa7f96ddb5d0db541653152d9f4ba0cf741a85260973d1538bdde3651178`. La edición1.26literal quedó en `respaldo_inicial`. Se actualizaron portada/control, cabecera/pie, índice, reanudación y capítulo43/apéndiceF sin reemplazar el historial científico. El Compendio acumulativo se actualizó también, conservando su original102868bytes; su versión publicada94283bytes tiene SHA-256`90a5c68f6c13c6348d388119c1125ddbbc52db3483d8155cc301ef73274a6ee9`.

Ambos DOCX completos se renderizaron con Word16, sobre copias cortas de bytes idénticos, en modo lectura: Manual112páginas y Compendio54. El primer intento quedó bloqueado por sandbox/automatización y una ruta larga; se resolvió con copias cortas, sin sustituir el contenido por un resumen. La revisión combinó contactos del documento, comparación del cuerpo histórico y lectura a escala de páginas afectadas. Se corrigió una fila huérfana de la tabla inicial. Los informes QA declaran qué se observó; no equivalen a una nueva lectura científica línea por línea de cada página histórica.

Un cierre de metadatos encontró `current_operation` como texto donde el helper esperaba un objeto. La publicación ya verificada de los DOCX no se repitió: se reanudaron sólo las escrituras pendientes, conservando el tipo textual y la historia anterior. `CONTROL/CIERRE_METADATOS_PUBLICACION_PI01.json` registra esa corrección. No modificó estado físico ni añadió ticks. El posterior corte de conexión y las esperas de permisos forman parte del tiempo real de cierre; no se ocultan como una campaña terminada dentro de seis horas.

## Limpieza autorizada realizada

Se eliminó exactamente `DEE thinking/archivo/AUDITORIA_CONTINUIDAD_2026_11_07_215656`, tras preservar y verificar fuera el ZIP histórico de8179154bytes,SHA-256`eabc0d201a07755e06fa2c06097cddd38dc4238557c23113b3478002db01c52f`, ahora en `DEE thinking/archivo/DEE_ESTADO_ACTUAL_Y_CONTINUIDAD_2026_11_07.zip`. Sus143miembros se abrieron y142hashes del manifiesto se comprobaron antes del borrado. Se preservaron además34archivos únicos de código/comprobantes,152457bytes, en `control/auditoria_anterior_preservada`.

Se retiraron504archivos y164directorios(incluida la raíz),**1109275409bytes lógicos**. No se midió espacio físico libre recuperado. Se comprobaron0reparse/uniones, identidad exacta, acceso a los504archivos y dependencias. La prueba incluye correspondencias de rutas antiguas a ZIP/miembro o localizador preservado, sin reescribir procedencias históricas. No se tocaron snapshots, SQLite, vidas, estados operativos ni el directorio de la campaña nueva. El recálculo portátil funciona con los primarios exportados después de esa eliminación; la verificación final desde el ZIP repite únicamente ese cálculo documental, no el motor.

## Organización documental observada, sin reorganización nueva

La raíz real es `documantacion vital`(escritura conservada). Sus familias dirigidas son `cores`, `ingenieria`, `procesos`, `pensamiento`, `mente basal`, `FISICA DEE UNI 1`, `FISICA DEE Y PROCESAMIENTO NATIVO` y `entrelazamiento cuantico explicacion y kernel completo`; conservan fundamentos, constructores, protocolos, controles y resultados. `documentos necesarios para cada chat` contiene material documental de consulta. La carpeta de adaptación Mac existe, pero su contenido quedó excluido de este trabajo.

Dentro de `DEE thinking` se observaron cinco directorios: `4.5`(los dos manuales oficiales/base), `DEE Cognitive 2.0`(producto operativo, Manual y estados), `CPC - Experimentos y mecanismos`(Compendio y mecanismos recuperados), `archivo`(historia, revisión transversal y esta campaña) y `casos practicos`(antecedentes con excepción histórica de movimiento conservada). No se movió ni limpió ninguno por estética. El mapa de rutas de la entrega da ubicaciones decisivas; no es un nuevo censo masivo de toda la documentación.

## Qué permite y qué no permite el ZIP

Incluye el Manual completo vigente, Compendio actualizado, informe, matrices de cobertura/antes-después, genealogía/localizadores, revisiones exactas y parches, protocolo congelado,100capturas primarias(60de tarea,12de conservación y28de desarrollo/diagnóstico), controles adversos y92archivos de recursos. El verificador recalcula sobre esos datos con Python estándar; no importa DEE ni depende de las rutas originales para leer su núcleo. El manifiesto final cubre todos los miembros de contenido sin autorreferencia y la verificación externa identifica el ZIP exacto.

No es una distribución ejecutable ni respaldo operativo completo: los snapshots, SQLite y artefactos completos, ambos manuales Thinking, motor y telemetría profunda permanecen locales. Se identifica qué traer para cada necesidad. Las copias de render en la ruta corta y la extracción de verificación final son temporales regenerables después de conservar los originales y comprobar esta entrega; no se eliminan automáticamente. La evidencia nueva, el par emparejado y los34archivos únicos preservados no son temporales eliminables.
