#!/usr/bin/env python3
"""Recálculo portátil PI01 sobre evidencia exportada, únicamente Python stdlib.

Uso: python RECALCULAR_PI01.py --root <extraccion> [--out-dir <directorio>]
Lee EVIDENCIA/INDICE.json; no importa DEE ni abre SQLite/estados originales.
Los decodificadores sólo reciben observaciones RAW. El evaluador ambiental se
aplica después de decodificar la respuesta, nunca para elegirla o completarla.
"""
from pathlib import Path, PurePosixPath
import argparse, collections, csv, datetime, hashlib, json, re, sys

ACTION={0:(0,0,1),1:(-1,1,1)}
ORIGIN=(0,5,20); E=(15,15,15); N=67
MA_ORIGIN=(33,33,33)
MA_TOKENS=((1,0,0),(0,1,0),(1,1,0),(-1,1,0),(1,-1,0),(-1,-1,0))
MA_GATES={tuple((MA_ORIGIN[i]+4*v[i]+(sg if i==2 else 0))%N for i in range(3)) for v in MA_TOKENS for sg in(-1,1)}
# Fixed APD04 common36 anatomy, not selected by word or expected sign.
LEXICAL_ORIGINS_AND_DIRECTIONS=(
 ((33,33,33),((1,0,0),(0,1,0),(1,1,0),(-1,1,0),(1,-1,0),(-1,-1,0),(-1,0,0),(0,-1,0))),
 ((47,47,47),((-1,0,0),(0,-1,0),(1,0,0),(0,1,0))),
 ((47,17,47),((1,0,0),(0,1,0))),
 ((47,7,47),((-1,0,0),(0,-1,0),(1,0,0),(1,1,0))))
LEXICAL_GATES={tuple((origin[i]+4*v[i]+(sg if i==2 else 0))%N for i in range(3))
               for origin,vs in LEXICAL_ORIGINS_AND_DIRECTIONS for v in vs for sg in(-1,1)}

def exact_int(v):
    if type(v)is int:return v
    if isinstance(v,str)and re.fullmatch(r'-?[0-9]+',v):return int(v)
    raise ValueError('Integer field is not exact: '+repr(v))

def raw_fields(raw):
    value=exact_int(raw)
    if not 0<=value<2**64:raise ValueError('RAW outside uint64')
    def nibble(shift):
        x=(value>>shift)&15
        return x-16 if x>=8 else x
    return {'raw':value,'state':value&0xffffffff,'s_reg':(value>>32)&0xffff,
            'direction':(nibble(48),nibble(52),nibble(56)),'semantic':(value>>60)&15}

def decode_route(raw):
    f=raw_fields(raw)
    if f['state']<=0 or f['semantic']!=1:return None
    return next((k for k,d in ACTION.items()if f['direction']==d),None)

def decode_pure_z(raw):
    f=raw_fields(raw);x,y,z=f['direction']
    return z if f['state']>0 and f['semantic']==1 and x==0 and y==0 and z in(-1,1)else None

def decode_fi(raw):
    f=raw_fields(raw);x,y,z=f['direction']
    return x if f['state']>0 and f['semantic']==1 and x in(-1,0,1)and y==1 and z in(0,-1)else None

def safe_file(base,relative):
    if not isinstance(relative,str)or '\\'in relative:raise ValueError('Use safe slash-separated evidence path')
    q=PurePosixPath(relative)
    if q.is_absolute()or '..'in q.parts or ':'in relative:raise ValueError('Unsafe evidence path')
    p=base.joinpath(*q.parts)
    if not p.resolve(strict=True).is_relative_to(base.resolve(strict=True)):raise ValueError('Evidence escaped root')
    cur=p
    while cur!=base:
        if cur.is_symlink()or getattr(cur.lstat(),'st_file_attributes',0)&1024:raise ValueError('Evidence reparse/link disallowed')
        cur=cur.parent
    if not p.is_file():raise ValueError('Evidence is not a file')
    return p

def sha_file(path):
    h=hashlib.sha256()
    with path.open('rb')as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def observation_errors(o):
    f=raw_fields(o['raw']);errors=[]
    for k in('state','s_reg','semantic'):
        if exact_int(o[k])!=f[k]:errors.append(k+' disagrees with RAW')
    if tuple(o['direction'])!=f['direction']:errors.append('direction disagrees with RAW')
    c=exact_int(o['clock'])
    if not 0<=c<2**64:errors.append('clock outside uint64')
    return errors

def unique_at(frames,tick):
    matches=[f['center']for f in frames if exact_int(f['tick'])==tick]
    if len(matches)!=1:raise ValueError('Frozen time has '+str(len(matches))+' center observations')
    return matches[0]

def unwrap(outer):
    result=outer.get('result')
    if isinstance(result,str):result=json.loads(result)
    if not isinstance(result,dict):raise ValueError('Queue capture has no structured result')
    body=result.get('result',result)
    rows=body.get('rows',[])
    if len(rows)!=1:raise ValueError('Expected one material opportunity per capture')
    return result,rows[0]

def ma_unit(native):
    row=native['rows'][0]
    return row['result']['rows'][0]if row.get('kind')=='explicit_operator_memory_access'else row

def deduplicate_receipts(refs):
    unique={};aliases=0
    for scope,r in refs:
        identifier=exact_int(r['id'])
        if identifier in unique:
            if unique[identifier]['receipt']!=r:raise ValueError('Conflicting receipts for one Native ID')
            aliases+=1;unique[identifier]['aliases'].append(scope)
        else:unique[identifier]={'receipt':r,'aliases':[scope]}
    statuses=collections.Counter(r['receipt']['status']for r in unique.values())
    return unique,{'requested_unique':len(unique),'applied':statuses.get('applied',0),
       'rejected':sum(v for k,v in statuses.items()if k.startswith('rejected')),
       'pending_or_other':sum(v for k,v in statuses.items()if k!='applied'and not k.startswith('rejected')),
       'statuses':dict(statuses),'alias_copies_not_counted':aliases}

def request_receipts(items,prefix):
    refs=[]
    for i,r in enumerate(items):
        receipt=r['receipt']
        if exact_int(r['id'])!=exact_int(receipt['id']):raise ValueError('Request/receipt Native ID mismatch')
        refs.append((prefix+'/'+str(i),receipt))
    return refs

def canonical_receipts(row,access_kind):
    """Only this episode's canonical material sections, never final/history."""
    refs=[('sensor',row['native_decision']['sensor_receipt'])]
    access=row['selected_access']['native_result']
    if access_kind=='MA_alfa':items=ma_unit(access)['requests']
    elif access_kind=='FI128_early_q4':items=access['all_material_receipts']
    else:items=[]
    refs.extend(request_receipts(items,'access'))
    returned=row['native_return'];refs.append(('normalizer',returned['normalizer']))
    if returned.get('negative_valence')is not None:refs.append(('negative_valence',returned['negative_valence']))
    return deduplicate_receipts(refs)

def analyze_retention(meta,outer,panel_evaluator=None):
    result,row=unwrap(outer);problems=[];checks={};payload=outer['payload']
    if isinstance(payload,str):payload=json.loads(payload)
    literals=payload['situaciones']
    if len(literals)!=1:raise ValueError('Retention capture must have one actual request')
    literal=literals[0];mode=literal['modo'];reader_info={};formed=None
    def check(label,condition):
        checks[label]=bool(condition)
        if not condition:problems.append(label)
    check('retention_no_external_return',payload['retorno']=='omit')
    if mode in('apd04-palabra','memoria'):
        unit=row if mode=='apd04-palabra'else row['result']['rows'][0]
        reader=unit['reader'];panel=reader['panel'];expected_sites=LEXICAL_GATES if mode=='apd04-palabra'else MA_GATES
        check('fixed_common_gate_set',len(panel)==len(expected_sites)and{tuple(o['site'])for o in panel}==expected_sites)
        read=exact_int(unit['read_tick']);check('first_read_input_plus4',read==exact_int(unit['input_tick'])+4)
        candidates=[]
        for o in panel:
            problems.extend('panel/'+x for x in observation_errors(o))
            check('all_gates_at_first_fixed_time',all(exact_int(x['tick'])==read for x in panel))
            z=decode_pure_z(o['raw'])
            if z is not None:candidates.append({'site':o['site'],'sign':z,'raw':o['raw']})
        formed=candidates[0]['sign']if len(candidates)==1 else None
        check('recorded_common_reader_matches_RAW',reader['formed_native_command']==formed and reader['ambiguous']==(len(candidates)>1))
        if mode=='apd04-palabra':check('no_lexical_teacher_or_expected_supplied',unit['teacher_correct_function_or_expected_sign_supplied']is False)
        requests=unit['requests'];reader_info={'kind':'common36 pureZ'if mode=='apd04-palabra'else'MA12 pureZ','read_tick':read,'candidates':candidates}
    elif mode=='eci01-balance':
        o=row['early_observation'];q=exact_int(row['query_tick']);read=q+4
        problems.extend('FI/'+x for x in observation_errors(o))
        check('first_FI_read_fixed_E_q4',tuple(o['site'])==E and exact_int(o['tick'])==read and exact_int(row['early_tick'])==read)
        formed=decode_fi(o['raw']);check('recorded_FI_reader_matches_RAW',row['early_physical_choice']==formed)
        check('no_FI_R04_return',row['new_R04_return_delivered']is False)
        requests=row['all_material_receipts'];reader_info={'kind':'FI first E/q4','read_tick':read,'observation':o}
    elif mode=='eci01-aritmetica-directa':
        operation=literal['operacion']
        if operation not in('suma','diferencia'):raise ValueError('Undeclared numeric representation')
        trial=row['native_operation']['native_trial'];read=exact_int(trial['datum_tick'])-2
        check('existing_FI128_numeric_trial',trial['kind']=='native_joint_raw_perception'and exact_int(trial['level'])==128)
        fs=[f for f in trial['frames']if exact_int(f['tick'])==read]
        if len(fs)!=1:raise ValueError('Numeric first gate observation absent or ambiguous')
        o=fs[0]['fields']['C'];problems.extend('numeric/'+x for x in observation_errors(o));f=raw_fields(o['raw'])
        valid=tuple(o['site'])==(12,17,18)and exact_int(o['tick'])==read and f['state']>0 and f['semantic']==1 and f['direction']==(1,-1,-1)
        bias=0 if operation=='suma'else 32
        formed=f['s_reg']-bias if valid else None
        nr=row['numeric_reader'];inner=row['native_operation']['numeric_reader']
        check('numeric_observation_is_exact_first_gate',nr['observation']==o and inner==nr and exact_int(nr['tick'])==read)
        check('recorded_numeric_decoder_matches_RAW',nr['numeric_result']==formed and row['numeric_result']==formed and nr['fixed_site_direction_valid']==valid and nr['abstention']==(not valid)and exact_int(nr['representation_bias'])==bias)
        check('numeric_no_teacher_provider_or_fallback',all(row[x]is False for x in('R04_route_consulted','provider_called','quality_evaluation_or_return','teacher_delivered','fallback_to_failed_request')))
        requests=trial['requests'];reader_info={'kind':'native numeric fixedC first datum_tick−2','read_tick':read,'representation_bias':bias,'observation':o}
    else:raise ValueError('Unrecognized retention literal')
    receipts,denominators=deduplicate_receipts(request_receipts(requests,'retention_access'))
    check('no_teacher_channels_in_panel',[r for r in requests if any(word in str(r.get('channel',r.get('port',''))).lower()for word in('teacher','teach','revision'))]==[])
    check('material_receipts_at_recorded_boundaries',all(x['receipt']['status']!='applied'or exact_int(x['receipt']['effective_tick'])==exact_int(x['receipt']['requested_tick'])for x in receipts.values()))
    # Expected panel values are evaluated only now, after the frozen RAW reader.
    match=re.fullmatch(r'PI01_RET_([0-9]{2})_(.+)',meta['id']);position=int(match[1])if match else meta.get('panel_index')
    label=match[2]if match else meta.get('label');expected=None;concordant=None
    if panel_evaluator is not None:
        check('panel_life_matches_frozen_protocol',meta['life']==panel_evaluator['life'])
        if position is None or not 0<=position<len(panel_evaluator['sequence']):raise ValueError('Panel sequence index not identifiable')
        fixture=panel_evaluator['sequence'][position];check('panel_label_matches_frozen_order',fixture['label']==label)
        if fixture['literal']is not None:check('panel_actual_literal_matches_frozen_request',fixture['literal']==literal)
        else:check('dynamic_chain_literal_is_difference',mode=='eci01-aritmetica-directa'and literal['operacion']=='diferencia'and exact_int(literal['derecha'])==5)
        expected=fixture['auditor_only_expected'];concordant=formed is not None and formed==expected
    reference=None
    if mode=='eci01-balance':reference=(literal['izquierda']>literal['derecha'])-(literal['izquierda']<literal['derecha'])
    elif mode=='eci01-aritmetica-directa':reference=literal['izquierda']+literal['derecha']if literal['operacion']=='suma'else literal['izquierda']-literal['derecha']
    return {'id':meta['id'],'life':meta['life'],'role':meta.get('role'),'kind':meta['kind'],'queue_status':outer['status'],
      'panel_index':position,'label':label,'before_tick':result['before_tick'],'after_tick':result['after_tick'],
      'actual_literal':literal,'reader':reader_info,'physical_response':formed,'formed_valid':formed is not None,
      'auditor_only_expected_after_decoding':expected,'concordant':concordant,'numeric_reference_after_decoding':reference,
      'reference_concordant':None if reference is None else formed==reference,'native_denominators':denominators,'native_ids':sorted(receipts),
      'checks':checks,'inconsistencies':problems,'scope':'Consecutive assisted first reads on the recorded life; no teaching, Native reproduction, independent acquisitions or general-language assertion inferred.'}

def analyze_episode(meta,outer,resources,evaluator=None):
    result,row=unwrap(outer);problems=[];checks={}
    def check(label,condition):
        checks[label]=bool(condition)
        if not condition:problems.append(label)
    for key in('before','after'):check(key+'_N67',exact_int(row[key]['N'])==N)
    decision=row['native_decision'];q=exact_int(decision['query_tick'])
    check('frozen_route_time_is_q',exact_int(decision['frozen_read_tick'])==q)
    o=unique_at(decision['frames'],q);problems.extend('route/'+x for x in observation_errors(o))
    check('route_center_is_fixed',tuple(o['site'])==ORIGIN and exact_int(o['tick'])==q)
    route=decode_route(o['raw'])
    check('recorded_route_matches_RAW',decision['route']==route and(type(decision['route'])is int or decision['route']is None))
    access=row['selected_access'];kind=access['access'];formed=None;reader_info={}
    check('unselected_access_not_called',access.get('unselected_access_called')is False)
    if route==0:
        check('route0_uses_only_MA',kind=='MA_alfa')
        unit=ma_unit(access['native_result']);panel=unit['reader']['panel'];cs=[]
        check('MA_twelve_fixed_gates',len(panel)==12 and{tuple(x['site'])for x in panel}==MA_GATES)
        read=exact_int(unit['read_tick']);check('MA_frozen_read_delay4',read==exact_int(unit['input_tick'])+4)
        for entry in panel:
            problems.extend('MA/'+x for x in observation_errors(entry))
            check('MA_all_panel_ticks_fixed',all(exact_int(z['tick'])==read for z in panel))
            value=decode_pure_z(entry['raw'])
            if value is not None:cs.append({'site':entry['site'],'sign':value,'raw':entry['raw']})
        formed=cs[0]['sign']if len(cs)==1 else None
        check('MA_recorded_reader_matches_RAW',unit['reader']['formed_native_command']==formed)
        check('MA_ambiguity_record_matches',unit['reader']['ambiguous']==(len(cs)>1))
        reader_info={'kind':'MA fixed12 unique SEM1 pureZ','read_tick':read,'candidates':cs}
    elif route==1:
        check('route1_uses_only_FI',kind=='FI128_early_q4')
        native=access['native_result'];early=native['early_observation'];fq=exact_int(native['query_tick'])
        problems.extend('FI/'+x for x in observation_errors(early))
        check('FI_fixed_E_q4',tuple(early['site'])==E and exact_int(early['tick'])==fq+4 and exact_int(native['early_tick'])==fq+4)
        formed=decode_fi(early['raw']);check('FI_recorded_reader_matches_RAW',native['early_physical_choice']==formed)
        reader_info={'kind':'FI fixedE SEM1 direction[x,1,z]','query_tick':fq,'read_tick':fq+4,'observation':early}
    else:
        check('invalid_route_has_no_access_or_fallback',kind is None and access['native_result']is None and access['physical_response']is None)
    check('access_response_matches_recomputed',access['physical_response']==formed)
    effect=row['external_effect'];arm=effect['actuator_control']
    payload=outer.get('payload',{})
    if isinstance(payload,str):payload=json.loads(payload)
    actuator=payload.get('actuador','closed')
    command=formed if actuator=='closed'and arm!='nulled'else None
    check('command_matches_fixed_actuator',effect['applied_command']==command and effect['formed_native_response']==formed)
    # The lock is an auditor-only value, used only AFTER the RAW decoder above.
    lock=exact_int(effect['private_lock_used_only_after_action'])
    protocol_match=None
    if evaluator is not None:
        lives=[evaluator['life_main'],*evaluator.get('controls',[])]
        if meta['life']in lives:
            ep=exact_int(row['episode']);cases=evaluator['episodes']
            continuation=ep>=len(cases)and'continu' in str(meta.get('role','')).lower()
            check('within_frozen18_or_declared_continuation',0<=ep<len(cases)or continuation)
            if 0<=ep<len(cases)or continuation:
                case=cases[ep%len(cases)];public=row['public_observation']
                check('public_fixture_matches_frozen_protocol',all(exact_int(public[k])==exact_int(case[k])for k in('left','right','context_load','gap_periods')))
                check('private_lock_matches_frozen_protocol',lock==exact_int(case['private_lock']))
                expected_arm={evaluator['life_main']:'real',evaluator['controls'][0]:'omit',evaluator['controls'][1]:'nulled'}[meta['life']]
                check('life_arm_matches_frozen_protocol',arm==expected_arm)
                protocol_match={'frozen_episode_index':case['index'],'stage':'post_reserve_continuation'if continuation else'reserve',
                                'public_and_lock_checked_after_RAW_decoding':True}
    accepted=command is not None and command==lock
    check('environment_acceptance_after_action',type(effect['accepted'])is bool and effect['accepted']==accepted)
    rb=exact_int(effect['resources_before']);ra=exact_int(effect['resources_after'])
    check('resource_counter_delta',ra-rb==int(accepted))
    actual=effect['actual_resource'];resource_witness=None
    if accepted:
        check('accepted_has_resource_record',isinstance(actual,dict))
        if isinstance(actual,dict):
            item=resources.get((meta['life'],actual['file']))
            check('resource_is_in_export_index',item is not None)
            check('resource_record_is64bytes',exact_int(actual['bytes'])==64 and exact_int(actual['episode'])==exact_int(row['episode']))
            if item is not None:
                resource_witness=item
                check('resource_record_equals_export_bytes',item['bytes']==64 and actual['sha256']==item['computed_sha256'])
                ep=exact_int(row['episode']);expected_payload=hashlib.sha256(('PI01 reservoir '+str(ep)).encode('ascii')).digest()*2
                check('resource_is_actual_reservoir_payload',hashlib.sha256(expected_payload).hexdigest()==item['computed_sha256'])
    else:check('not_accepted_has_no_resource_record',actual is None)
    ret=row['native_return'];at=exact_int(ret['fixed_tick'])
    check('feedback_deadline_fixed4N',at==q+4*N)
    check('post_feedback_horizon40',exact_int(ret['end_tick'])==at+40 and exact_int(row['after']['tick'])==at+40)
    check('negative_condition_from_actual_consequence',ret['negative_condition']==(not accepted))
    check('echo_is_actual_route_only',ret['selected_actual_route_echo']==route and ret['target_route_sent']is False)
    normal=ret['normalizer'];negative=ret['negative_valence']
    check('normalizer_fixed_channel_and_time',normal['channels']==['PI01.R03.normalizer']and exact_int(normal['requested_tick'])==at-1)
    need_negative=not accepted and route is not None and arm!='omit'
    check('valence_presence_matches_arm_and_outcome',(negative is not None)==need_negative)
    check('omit_flag_matches_negative_consequence',ret['omitted']==((not accepted)and arm=='omit'))
    if negative is not None:check('valence_echo_channel_and_time',negative['channels']==['PI01.R03.penalty'+str(route)]and exact_int(negative['requested_tick'])==at-1)
    receipts,denominators=canonical_receipts(row,kind)
    check('all_native_receipt_times_well_formed',all(r['receipt']['status']!='applied'or exact_int(r['receipt']['effective_tick'])==exact_int(r['receipt']['requested_tick'])for r in receipts.values()))
    policy_o=unique_at(ret['frames'],at);problems.extend('return/'+x for x in observation_errors(policy_o))
    pf=raw_fields(policy_o['raw']);policy=next((i for i,d in {0:(1,0,0),1:(0,1,0)}.items()if pf['direction']==d),None)if pf['state']>0 and pf['semantic']==1 else None
    # Correctness reference for FI is evaluated only after extraction, not a decoder input.
    public=row['public_observation'];ref=(public['left']>public['right'])-(public['left']<public['right'])if kind=='FI128_early_q4'else None
    return {'id':meta['id'],'life':meta['life'],'role':meta.get('role'),'kind':meta['kind'],'queue_status':outer['status'],
      'episode':exact_int(row['episode']),'before_tick':exact_int(row['before']['tick']),'after_tick':exact_int(row['after']['tick']),
      'query_tick':q,'route_raw':o['raw'],'route':route,'access':kind,'reader':reader_info,'physical_response':formed,
      'fi_reference_after_decoding':ref,'fi_matches_reference':None if ref is None else formed==ref,
      'arm':arm,'applied_command':command,'lock_auditor_only':lock,'frozen_protocol_match':protocol_match,'accepted':accepted,'resource_delta':ra-rb,'resources_before':rb,'resources_after':ra,
      'resource_witness':resource_witness,'post_return_policy':policy,'native_denominators':denominators,
      'native_ids':sorted(receipts),'checks':checks,'inconsistencies':problems,
      'limits':['Normalizer/valence receipts do not contain s_reg; their3/5 payloads are code/encounter-backed, not independently decoded from these receipts.',
                'Opportunity schedule, MA/FI call and actuator codec are prepared host assistance.',
                'This is passive recalculation; shared-prefix branches and repeated queries are not independent new acquisitions.']}

def run(root,outdir):
    root=root.resolve(strict=True);base=root/'EVIDENCIA';index_file=base/'INDICE.json'
    index=json.loads(index_file.read_text(encoding='utf-8-sig'))
    resources={};file_checks=[];errors=[];evaluator=None;panel_evaluator=None
    if index.get('evaluator'):
        item=index['evaluator'];f=safe_file(base,item['file']);h=sha_file(f)
        if h!=item['sha256']:errors.append('Frozen evaluator export identity mismatch: '+item['file'])
        evaluator=json.loads(f.read_text(encoding='utf-8-sig'))
        file_checks.append({'file':item['file'],'bytes':f.stat().st_size,'sha256':h,'kind':'frozen_evaluator_auditor_only'})
    if index.get('panel_evaluator'):
        item=index['panel_evaluator'];f=safe_file(base,item['file']);h=sha_file(f)
        if h!=item['sha256']:errors.append('Panel evaluator export identity mismatch: '+item['file'])
        panel_evaluator=json.loads(f.read_text(encoding='utf-8-sig'))
        file_checks.append({'file':item['file'],'bytes':f.stat().st_size,'sha256':h,'kind':'panel_evaluator_auditor_only'})
    for item in index.get('resource_files',[]):
        f=safe_file(base,item['evidence_file']);h=sha_file(f);size=f.stat().st_size
        if h!=item['sha256']or size!=exact_int(item['bytes']):errors.append('Resource export identity mismatch: '+item['evidence_file'])
        key=(item['life'],item['relative_file'])
        if key in resources:errors.append('Duplicate resource identity: '+str(key))
        resources[key]={**item,'computed_sha256':h,'bytes':size}
        file_checks.append({'file':item['evidence_file'],'sha256':h,'bytes':size,'kind':'resource'})
    episodes=[];retention=[];non_game=[];seen=set()
    for meta in index.get('primarios',[]):
        path=safe_file(base,meta['file']);h=sha_file(path)
        if h!=meta['sha256']:errors.append('Primary export identity mismatch: '+meta['file']);continue
        file_checks.append({'file':meta['file'],'sha256':h,'bytes':path.stat().st_size,'kind':meta.get('kind')})
        key=(meta['life'],meta['id'])
        if key in seen:errors.append('Duplicate primary identity; not counted twice: '+str(key));continue
        seen.add(key)
        if meta.get('kind')not in('game_episode','retention_panel'):non_game.append({'id':meta['id'],'life':meta['life'],'kind':meta.get('kind'),'hash_verified':True});continue
        outer=json.loads(path.read_text(encoding='utf-8-sig'))
        if outer.get('id')!=meta['id']:errors.append('Capture/index ID mismatch: '+meta['file'])
        try:
            if meta['kind']=='game_episode':episodes.append(analyze_episode(meta,outer,resources,evaluator))
            else:retention.append(analyze_retention(meta,outer,panel_evaluator))
        except (KeyError,ValueError,TypeError,IndexError)as e:
            (episodes if meta['kind']=='game_episode'else retention).append({'id':meta['id'],'life':meta['life'],'role':meta.get('role'),'kind':meta['kind'],'queue_status':outer.get('status'),
                             'episode':None,'inconsistencies':['Missing/incomplete evidence: '+str(e)],'not_dropped':True})
    for item in index.get('outboxes',[]):
        relative=item.get('file',item.get('evidence_file'));f=safe_file(base,relative);h=sha_file(f)
        if h!=item['sha256']:errors.append('Outbox identity mismatch: '+relative)
        file_checks.append({'file':relative,'bytes':f.stat().st_size,'sha256':h,'kind':'outbox_identity_only'})
    groups=[]
    for key in sorted({(x['life'],str(x.get('role')),str(x.get('arm')))for x in episodes}):
        xs=[x for x in episodes if (x['life'],str(x.get('role')),str(x.get('arm')))==key];ids=set();dup=[]
        for x in xs:
            for i in x.get('native_ids',[]):
                if i in ids:dup.append(i)
                ids.add(i)
        if dup:errors.append('Native IDs reused across indexed episodes of '+key[0]+': '+str(dup))
        usable=sorted((x for x in xs if x.get('episode')is not None),key=lambda x:x['episode'])
        continuity=[]
        for a,b in zip(usable,usable[1:]):
            if b['episode']==a['episode']+1:continuity.append({'from':a['id'],'to':b['id'],'resource_counter_continuous':a['resources_after']==b['resources_before'],'native_time_nondecreasing':a['after_tick']<=b['before_tick']})
        groups.append({'life':key[0],'role':key[1],'arm':key[2],'indexed_opportunities':len(xs),'completed_captures':sum(x.get('queue_status')=='completed'for x in xs),
          'valid_routes':sum(x.get('route')is not None for x in xs),'formed_responses':sum(x.get('physical_response')is not None for x in xs),
          'accepted_resources':sum(x.get('accepted')is True for x in xs),'native_unique_ids_across_these_episodes':len(ids),
          'requested_native_sum':sum(x.get('native_denominators',{}).get('requested_unique',0)for x in xs),
          'applied_native_sum':sum(x.get('native_denominators',{}).get('applied',0)for x in xs),
          'rejected_native_sum':sum(x.get('native_denominators',{}).get('rejected',0)for x in xs),
          'incomplete_or_inconsistent_rows':sum(bool(x['inconsistencies'])for x in xs),'adjacent_continuity':continuity,
          'independence':'Same-life opportunities are dependent; branches may share a complete prefix. No independent-acquisition count inferred.'})
    retention_summary=[]
    for life in sorted({x['life']for x in retention}):
        xs=sorted((x for x in retention if x['life']==life),key=lambda x:x.get('panel_index',999));ids=[]
        for x in xs:ids.extend(x.get('native_ids',[]))
        if len(ids)!=len(set(ids)):errors.append('Native aliases reused across retention captures: '+life)
        sequential=[]
        for a,b in zip(xs,xs[1:]):sequential.append({'from':a['id'],'to':b['id'],'time_nondecreasing':a.get('after_tick',-1)<=b.get('before_tick',-1)})
        chain=None
        first=next((x for x in xs if x.get('label')=='number13'),None);second=next((x for x in xs if x.get('label')=='number8'),None)
        if first and second:
            chain={'first_id':first['id'],'second_id':second['id'],'first_actual_RAW_result':first['physical_response'],
                   'second_actual_left_operand':second['actual_literal']['izquierda'],
                   'actual_first_result_is_second_input':first['physical_response']is not None and second['actual_literal']['izquierda']==first['physical_response'],
                   'operator_ordered_not_self_planned':True}
            if not chain['actual_first_result_is_second_input']:errors.append('Retention chain does not use actual preceding Native result: '+life)
        retention_summary.append({'life':life,'material_requests_in_export':len(xs),'formed_valid':sum(x.get('formed_valid')is True for x in xs),
          'concordant_with_frozen_auditor':sum(x.get('concordant')is True for x in xs),'auditor_denominator':None if panel_evaluator is None else len(panel_evaluator['sequence']),
          'native_unique_ids':len(set(ids)),'native_applied':sum(x.get('native_denominators',{}).get('applied',0)for x in xs),
          'native_rejected':sum(x.get('native_denominators',{}).get('rejected',0)for x in xs),
          'incomplete_or_inconsistent_rows':sum(bool(x['inconsistencies'])for x in xs),'consecutive_times':sequential,'arithmetic_chain':chain,
          'scope':'Twelve first responses are uses of one life, not twelve concepts or independent individuals. Game utility and save/reopen are separate evidence.'})
    frozen_evidence=None
    if evaluator is not None:
        per_life=[];amounts={}
        for life in[evaluator['life_main'],*evaluator.get('controls',[])]:
            xs=[x for x in episodes if x['life']==life and x.get('frozen_protocol_match',{})and x['frozen_protocol_match']['stage']=='reserve']
            seen_eps={x['episode']for x in xs};actual=sum(x['accepted']for x in xs);amounts[life]=(len(seen_eps),actual)
            per_life.append({'life':life,'reserved_denominator':len(evaluator['episodes']),'observed_indices':sorted(seen_eps),
              'not_present_in_export':[x['index']for x in evaluator['episodes']if x['index']not in seen_eps],
              'accepted_resources':actual,'scope':'Missing/unexecuted opportunities are listed; they are not invented successes or Native rejections.'})
        main=evaluator['life_main'];omit,nulled=evaluator['controls'];den=len(evaluator['episodes'])
        frozen_evidence={'per_life':per_life,'minimum_main_resources_predeclared':evaluator['criteria_before_reserve']['minimum_main_actual_resources'],
          'main_at_least15_of18':amounts[main][1]>=15 if amounts[main][0]==den else None,
          'main_minus_omit_resources':amounts[main][1]-amounts[omit][1]if amounts[main][0]==amounts[omit][0]==den else None,
          'nulled_zero_resources':amounts[nulled][1]==0 if amounts[nulled][0]==den else None,
          'retention_and_reopen':'Not certified by game totals; their separate primary records and scientific assessment are required.',
          'no_promotion_or_intelligence_verdict':True}
    report={'schema':'PI01.portable.passive-recalculation.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'index_sha256':sha_file(index_file),'engine_imports':0,'new_ticks':0,'no_global_pass_verdict':True,
      'file_identity_errors':errors,'verified_files':file_checks,'non_game_primaries_not_assimilated':non_game,'episodes':episodes,'groups':groups,
      'frozen_evaluator_evidence':frozen_evidence,'retention_panel_rows':retention,'retention_panel_summary':retention_summary,
      'scope':'Exported records and resource bytes only; not Native reproduction, a backup, current-world observation or proof of general autonomy.'}
    outdir.mkdir(parents=True,exist_ok=True)
    (outdir/'RECALCULO_PI01.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    fields=['id','life','role','queue_status','episode','before_tick','after_tick','query_tick','route','access','physical_response','fi_reference_after_decoding','fi_matches_reference','arm','applied_command','accepted','resource_delta','resources_before','resources_after','post_return_policy','native_requested','native_applied','native_rejected','inconsistencies']
    with (outdir/'RECALCULO_PI01.csv').open('w',encoding='utf-8-sig',newline='')as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
        for x in episodes:
            row={k:x.get(k)for k in fields};den=x.get('native_denominators',{})
            row.update(native_requested=den.get('requested_unique'),native_applied=den.get('applied'),native_rejected=den.get('rejected'),inconsistencies='; '.join(x['inconsistencies']))
            w.writerow({k:'NULL'if v is None else v for k,v in row.items()})
    panel_fields=['id','life','role','queue_status','panel_index','label','before_tick','after_tick','physical_response','formed_valid','auditor_only_expected_after_decoding','concordant','numeric_reference_after_decoding','reference_concordant','native_requested','native_applied','native_rejected','inconsistencies']
    with (outdir/'RECALCULO_RETENCION_PI01.csv').open('w',encoding='utf-8-sig',newline='')as f:
        w=csv.DictWriter(f,fieldnames=panel_fields);w.writeheader()
        for x in retention:
            row={k:x.get(k)for k in panel_fields};den=x.get('native_denominators',{})
            row.update(native_requested=den.get('requested_unique'),native_applied=den.get('applied'),native_rejected=den.get('rejected'),inconsistencies='; '.join(x['inconsistencies']))
            w.writerow({k:'NULL'if v is None else v for k,v in row.items()})
    print(json.dumps({'groups':groups,'retention':retention_summary,'file_identity_errors':errors,'outputs':['RECALCULO_PI01.json','RECALCULO_PI01.csv','RECALCULO_RETENCION_PI01.csv']},ensure_ascii=False,indent=2))
    return report

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',type=Path,required=True);p.add_argument('--out-dir',type=Path);p.add_argument('--strict',action='store_true')
    args=p.parse_args();report=run(args.root,args.out_dir or args.root/'RECALCULO')
    if args.strict and(report['file_identity_errors']or any(x['inconsistencies']for x in report['episodes']+report['retention_panel_rows'])):return 2
    return 0
if __name__=='__main__':sys.exit(main())
