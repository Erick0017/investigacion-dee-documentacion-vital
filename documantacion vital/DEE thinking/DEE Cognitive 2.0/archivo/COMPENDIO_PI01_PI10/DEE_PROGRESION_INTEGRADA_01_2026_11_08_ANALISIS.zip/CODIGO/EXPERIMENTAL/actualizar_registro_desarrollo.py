"""Actualiza el registro existente sin alterar sus cortes científicos previos."""
from pathlib import Path
import datetime as dt,hashlib,json,os
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;C=R/'DEE Cognitive 2.0';S=C/'sistema'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
 tmp=p.with_name(p.name+'.PI01.pending');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)
now=dt.datetime.now(dt.timezone.utc).isoformat();project=read(C/'PROYECTO.json');rec=read(S/'estado/vidas'/project['selected_life']/'VIDA.json')
path=S/'contratos/SERVICIO_PERSISTENTE_MU01.json';x=read(path)
if 'historical_operational_option_before_PI01'not in x:
 before=sha(path);x['historical_operational_option_before_PI01']=x['current_operational_option'];x['current_operational_option']={'life_id':rec['life_id'],'tick':rec['physical']['tick'],'snapshot':rec['snapshot'],'snapshot_sha256':rec['snapshot_sha256'],'global_ACTIVO_promoted':True,'complete_pair_required':True,'selection_scope':'Saved current principal. No assertion of instantaneous running state.','source_current_selection':'../estado/ACTIVO.json','updated_by':'PI01.N0.reference_correction'}
 candidate=P/'control/contratos_corregidos/SERVICIO_PERSISTENTE_MU01.json';write(candidate,x)
 old=read(P/'respaldo_inicial/sistema/contratos/SERVICIO_PERSISTENTE_MU01.json')
 for key,value in old.items():
  if key!='current_operational_option':assert x[key]==value
 write(path,x);p=P/'control/CORRECCION_REFERENCIAS_N0.json';rows=read(p);rows.append({'file':str(path),'before_sha256':before,'after_sha256':sha(path),'physical_ticks':0,'old_pointer_preserved_key':'historical_operational_option_before_PI01'});write(p,rows)
current=P/'REGISTRO_CAMPANA.json';campaign=read(current);campaign['phase']='LEGAL_COMPONENT_DEVELOPMENT_AND_INTEGRATION';campaign['updated_utc']=now;campaign['experimental_lives']={}
for p in(P/'estados').glob('*/sistema/estado/vidas/*/VIDA.json'):
 r=read(p);campaign['experimental_lives'][r['life_id']]={'record':str(p),'N':r['physical']['N'],'T':r['physical']['tick'],'snapshot_sha256':r['snapshot_sha256'],'parent':r.get('parent'),'role':'Diagnostic/development, not adopted'}
campaign['source_review']=[{'block':p.name,'coverage_files':[str(q.relative_to(P))for q in p.rglob('COBERTURA*.json')]}for p in(P/'lecturas').iterdir()if p.is_dir()]
campaign['protected_principal_at_update']={'id':rec['life_id'],'N':rec['physical']['N'],'T':rec['physical']['tick'],'snapshot_sha256':rec['snapshot_sha256']};write(current,campaign)
rp=R/'archivo/analisis_transversal_cognitivo/REVISION_TRANSVERSAL.json';revision=read(rp)
if 'operation_before_PI01'not in revision:revision['operation_before_PI01']=revision.get('current_operation')
revision['current_operation']='PROGRESION_INTEGRADA_01: transversal review and controlled native integration, in progress; original principal protected.'
revision['progression_integrated_PI01']={'status':'IN_PROGRESS','campaign_record':str(current),'initial_principal':campaign['source_life'],'initial_tick':campaign['record']['physical']['tick'],'source_reading':campaign['source_review'],'new_native_experiment_ledger':str(P/'ENSAYOS.jsonl'),'technical_corrections':str(P/'control/CORRECCION_REFERENCIAS_N0.json'),'no_operational_promotion_yet':True,'historical_ECI02_adverse_cut_preserved':True,'interpretation':'CORE09/C2/AA/APD mechanisms are antecedents, not new discoveries or memories imported into the principal.'};revision['updated_utc']=now;write(rp,revision)
print(json.dumps({'registry_updated':str(rp),'protected_main':rec['life_id'],'T':rec['physical']['tick'],'experimental_lives':len(campaign['experimental_lives']),'source_review_blocks':len(campaign['source_review'])},ensure_ascii=False))
