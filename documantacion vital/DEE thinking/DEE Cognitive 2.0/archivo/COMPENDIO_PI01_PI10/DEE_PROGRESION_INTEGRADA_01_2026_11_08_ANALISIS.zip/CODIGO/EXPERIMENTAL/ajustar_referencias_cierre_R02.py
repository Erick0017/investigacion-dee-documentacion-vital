"""Resolve remaining pre-seal documentary status fields. No DEE imports or ticks."""
from pathlib import Path
import datetime,hashlib,json,os
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;C=R/'DEE Cognitive 2.0'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def write(p,x):
    t=p.with_suffix(p.suffix+'.pi01_r02_tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
manual=read(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')['manual']
path=C/'CONTINUIDAD_DEE_COGNITIVE_2_0.json';cont=read(path)
if cont.get('manual',{}).get('edition')!='1.27':
    cont['manual_before_PI01_publication_historical']=cont['manual']
cont['manual']={'edition':'1.27','path_relative_to_product':Path(manual['path']).name,'sha256':manual['sha256'],'document_publication':str(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')}
cont['updated_utc']=now;write(path,cont)
regpath=P.parent/'REVISION_TRANSVERSAL.json';reg=read(regpath);block=reg['progression_integrated_PI01']
if 'stage_results'in block:
    block['stage_results_as_recorded_during_execution_historical']=block.pop('stage_results')
block['final_scored_results']={'source':'Exported primary RAW/receipt/resource recalculation, not a repeated Native run','reserve_main':{'opportunities':18,'resources':16,'requested':1347,'applied':1347},'reserve_omit':{'opportunities':18,'resources':12,'requested':162,'applied':162},'reserve_nulled':{'opportunities':18,'resources':0,'requested':1701,'applied':1701},'retention':{'uses':12,'concordant':12,'requested':929,'applied':929,'through_tick':735466},'main_after_reopening':{'opportunities':1,'resources':1,'total_resources':17,'through_tick':735843}}
block['package']={'status':'CONTENT_CLOSED_EXACT_CONTAINER_WITNESS_EXTERNAL','limit_bytes':15000000,'not_an_operational_backup':True,'verification_path':str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json'),'note':'A final ZIP cannot contain its own hash. Its exact bytes and extraction/recalculation result are recorded externally after sealing.'}
write(regpath,reg)
path=P/'CONTINUIDAD_PI01.json';cont=read(path)
cont['usable_functions']=block
cont['updated_utc']=now
cont['analysis_package']={'content_status':'CLOSED','limit_bytes':15000000,'full_current_manual_included':True,'operational_backup':False,'final_exact_container_verification':str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json')}
cont['analysis_zip_status']='CONTENT_CLOSED; exact archive integrity/bytes/hash recorded externally after sealing'
write(path,cont)
result={'schema':'PI01.closure.reference.correction.R02','utc':now,'new_native_ticks':0,'changes':['Current operational continuity manual descriptor1.26 preserved under an explicit historical key; manual now1.27, matching manual_current and the published bytes.','Intermediate stage-results array preserved with an explicit during-execution historical name; final denominators given separately.','Pre-seal package status replaced by closed content plus external exact-container witness.'],'scientific_results_changed':False,'physical_state_changed':False,'manual_DOCX_changed':False,'requires_new_zip_candidate':True}
write(P/'control/AJUSTE_REFERENCIAS_CIERRE_R02.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2))
