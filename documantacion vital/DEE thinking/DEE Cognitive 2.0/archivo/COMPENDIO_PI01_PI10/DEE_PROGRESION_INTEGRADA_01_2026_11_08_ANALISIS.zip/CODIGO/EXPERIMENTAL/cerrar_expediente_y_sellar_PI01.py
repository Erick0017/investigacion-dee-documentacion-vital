"""Assemble and verify the exact analysis ZIP. Pure documentation: never import DEE."""
from pathlib import Path,PurePosixPath
import csv,datetime,hashlib,io,json,os,runpy,shutil,subprocess,sys,zipfile
P=Path(__file__).resolve().parent.parent; R=P.parent.parent.parent
C=R/'DEE Cognitive 2.0'; S=C/'sistema'; E=P/'entrega/EXPEDIENTE'
Z=P/'entrega/DEE_PROGRESION_INTEGRADA_01_2026_11_08_ANALISIS.zip'
X=P/'entrega/VERIFICACION_EXTRAIDA_FINAL_02'
OUT=P/'control/recalculo_desde_zip_final_R02'
PROOF=P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json'
MANIFEST='CONTROL/MANIFIESTO_SHA256.json'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1048576),b''): h.update(block)
    return h.hexdigest()
def desc(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def cp(p,rel):
    q=E/rel; q.parent.mkdir(parents=True,exist_ok=True); shutil.copyfile(p,q)
    if sha(p)!=sha(q): raise ValueError('Copied bytes differ:'+str(p))
def safe(name):
    rel=PurePosixPath(name)
    if not name or rel.is_absolute() or any(x in ('','..','.') for x in rel.parts) or '\\' in name or ':' in name:
        raise ValueError('Unsafe ZIP name:'+name)
    return rel
def guarded_sources():
    active=read(S/'estado/ACTIVO.json'); record=S/'estado/vidas/ECI02_PI01_MAIN/VIDA.json'; life=read(record)
    if active['life_id']!='ECI02_PI01_MAIN' or life['physical']['tick']!=735843: raise ValueError('Principal has advanced; do not rewind')
    check=[(record,'b70385593dda8feeb3f501d8be3a21f0ef6256e9c8f8d8dde6ab19c8611b6982'),(S/life['snapshot'],'4c585112f33b126a0ee6114e19ef203f0bab658f76545636a6e70f573d628a50'),(S/'estado/servicios_persistentes/ECI02_PI01_MAIN/cola.sqlite3','da5f1e75d7c83dc4d9d8ede34afba0466336941c8fecaeed611399a824e8d515'),(S/'estado/checkpoints/ECI02_OPERATIVA_PRINCIPAL_01.T727225.8965823a85b7.deetsnap.gz','46e275be49a1e8df9b823e3c533156d91fa66a79477872a125efabfa350470d4')]
    pub=read(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')
    check.extend((Path(v['path']),v['sha256'])for k,v in pub.items()if k in ('manual','compendium'))
    check.extend((Path(v['path']),v['sha256'])for v in pub['engine_and_source_preservation'])
    hist=R/'archivo/DEE_ESTADO_ACTUAL_Y_CONTINUIDAD_2026_11_07.zip'
    check.append((hist,'eabc0d201a07755e06fa2c06097cddd38dc4238557c23113b3478002db01c52f'))
    if (R/'archivo/AUDITORIA_CONTINUIDAD_2026_11_07_215656').exists(): raise ValueError('Authorized removed folder unexpectedly exists')
    result=[]
    for path,expected in check:
        entry=desc(path)
        if entry['sha256']!=expected: raise ValueError('Decisive source changed:'+str(path))
        result.append(entry)
    return result

if Z.exists() or X.exists() or PROOF.exists(): raise ValueError('Final candidate or proof exists; inspect it, never overwrite silently')
initial=guarded_sources(); pub=read(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')
# Refresh current operation descriptors only; historical source hashes stay historical.
mapfile=P/'MAPA_RUTAS_DECISIVAS.json'; routes=read(mapfile)
for entry in routes.get('operation',[]):
    src=Path(entry['path'])
    if src.is_file() and entry.get('sha256')!=sha(src):
        prior={k:entry[k]for k in ('bytes','sha256')if k in entry}
        entry.setdefault('prior_descriptor_historical',prior)
        entry.update(bytes=src.stat().st_size,sha256=sha(src),descriptor_refreshed_utc=now())
routes['updated_utc']=now(); write(mapfile,routes)
runpy.run_path(str(P/'codigo/preparar_expediente_PI01.py'))['assemble'](True)
for name in ['CIERRE_METADATOS_PUBLICACION_PI01.json','AJUSTE_REFERENCIAS_CIERRE_R02.json','QA_CIERRE_FINAL_INDEPENDIENTE.json','QA_DOCUMENTAL_CIERRE.json','QA_PAQUETE_CIERRE.json','QA_VISUAL_MANUAL_FINAL.json','QA_VISUAL_MANUAL_RAIZ.json','QA_VISUAL_COMPENDIO.json','BLOQUEO_RENDER_DOCUMENTAL.json','PROCESOS_CIERRE_PI01.json']:
    cp(P/'control'/name,'CONTROL/'+name)
for name in ['ACTUALIZACION_DOCUMENTAL_CORREGIDA.json','RENDERIZADO_FINAL_WORD.json','RENDER_CIERRE_FIJO.ps1']:
    cp(P/'documentos'/name,'CONTROL/DOCUMENTOS/'+name)
for key in ('manual','compendium'):
    cp(Path(pub[key]['rendered_pdf']['path']),'02_MANUAL/'+Path(pub[key]['rendered_pdf']['path']).name)
pair=read(P/'control/PAR_FINAL_PI01.json')['pair']
omitted=[]
for path,role,reason in [
    (R/'4.5/DEE_thinking_4_5_0_Maestro_Arquitectura_Reconstruccion.docx','Official Thinking architecture manual','Full technical text reviewed; source coverage/synthesis exported. Large official original stays local.'),
    (R/'4.5/DEE_thinking_4_5_0_Libro_Blanco_y_Manual_Tecnico.docx','Official Thinking technical manual','Full technical text reviewed; source coverage/synthesis exported. Large official original stays local.'),
    (S/'estado/checkpoints/ECI02_PI01_MAIN.T735843.085696415346.deetsnap.gz','Current complete Native snapshot','Omitted from analysis export; by itself it is not the full Cognitive operational set.'),
    (S/'estado/servicios_persistentes/ECI02_PI01_MAIN/cola.sqlite3','Current queue SQLite','Local operational state. Do not copy it live with incompatible auxiliary files.'),
    (Path(pair['directory'])/'EXPORTACION_SERVICIO.json','Full paired source manifest','Literal manifest exported in03_MAPAS; its3214data members remain in the paired local directory.'),
    (P.parent/'REVISION_TRANSVERSAL.json','Existing cumulative technical register','Only affected blocks exported; full register remains local, no duplicate historical inventory.'),
    (R/'archivo/DEE_ESTADO_ACTUAL_Y_CONTINUIDAD_2026_11_07.zip','Preserved historical audit','Historical143member archive intentionally not nested; prior integrity proof included.'),
    (S/'runtime/dee_thinking-4.5.0-cp313-cp313-win_amd64.whl','Official frozen engine wheel','No engine duplication; install/run only from existing product.'),
    (C/'motor/python313/site-packages/dee_thinking/_native.cp313-win_amd64.pyd','Installed compiled Native engine','Frozen binary omitted; hash preservation recorded.'),
]:
    omitted.append(desc(path)|{'role':role,'reason':reason})
omissions={'schema':'PI01.analysis.omissions.v1','cut_utc':now(),'files':omitted,
 'complete_source_pair':pair,
 'required_current_operational_set':{'product_root':str(C),'life_id':'ECI02_PI01_MAIN','tick':735843,'directories_relative_to_product':['sistema/estado/vidas/ECI02_PI01_MAIN','sistema/estado/servicios_persistentes/ECI02_PI01_MAIN','sistema/estado/servicios_locales/ECI02_PI01_MAIN','sistema/estado/pares_iniciales/ECI02_PI01_MAIN'],'snapshot':'sistema/estado/checkpoints/ECI02_PI01_MAIN.T735843.085696415346.deetsnap.gz','minimum_to_bring':'Use the complete paired export plus official compatible engine and Cognitive code/contracts, or preserve all current operational directories jointly. Do not reconstruct from RAW/clocks or import a seed over a newer life.'},
 'deep_records_not_exported':[{'path':str(P/'estados'),'role':'Complete experimental histories and adverse Native checkpoints','hash_policy':'Individual decisive snapshots/pair manifests are identified in the included maps; no new mass inventory or blanket tree hash.'},{'path':str(P/'ensayos'),'role':'Full deep logs and native outputs','coverage':'All100selected decisive primary captures including negative setup and all54reserved opportunities exported. Not every repeated deep trace is included.'},{'path':str(P/'lecturas'),'role':'Full extracted technical reading corpus','coverage':'Coverage maps, syntheses, selected decisive sources/code exported. Not every repeated extracted paragraph copied.'},{'path':str(P/'control/auditoria_anterior_preservada'),'role':'34unique prior audit files,152457bytes','locator':'Full preservation file hashes and old/new paths are inCONTROL/LIMPIEZA_AUDITORIA_EJECUTADA.json; retained locally.'}],
 'excluded_unread':'Business, email, videos, Mac and unrelated personal data; no credentials included.',
 'temporaries_only_after_verification':{'regenerable':[str(P.parents[5]/'PI01_WORD_QA_20261108'),str(X)],'never_auto_delete':[str(P/'estados'),str(P/'control/auditoria_anterior_preservada'),pair['directory']],'note':'Short render copies/PNG QA and extracted final ZIP are regenerable from preserved bytes. Do not delete unique evidence or paired states.'},
 'scope':'This ZIP is a private analysis dossier with full current Cognitive manual, not a runnable backup or full software distribution.'}
# Fixed short render root is relative to the actual tests workspace, not an inferred ancestor.
omissions['temporaries_only_after_verification']['regenerable'][0]=str(R.parent.parent/'PI01_WORD_QA_20261108')
write(E/'03_MAPAS/INDICE_FUENTES_Y_OMISIONES.json',omissions)
readme='''DEE — PROGRESIÓN INTEGRADA01. Corte8de noviembre de2026, America/Mexico_City.

RESULTADO: se ejecutó y adoptó la continuaciónECI02_PI01_MAIN,N67,T735843,
padre físicoECI02_OPERATIVA_PRINCIPAL_01,T727225. Un único principal seleccionado.
Universev27 y Thinking4.5.0 congelados. No se repitieron experimentos al retomar.

En18oportunidades reservadas: MAIN16recursos, sin retorno negativo12,
acción anulada0. Misma vida:12usos anteriores concordantes,929/929entradas
aplicadas hastaT735466; después reapertura y un recurso adicional hastaT735843.
No es iniciativa general: calendario, codec ruta->acceso y lectura son asistenciaP0.
Hay selección física local modificada por consecuencias, no un plan autogenerado.

Manual rector COMPLETO:02_MANUAL/DEE_Cognitive_2_0_Manual_Maestro_DCS11_MM_001_Edicion_1_21.docx.
Su edición interna es1.27; se retuvo el nombre para compatibilidad del lanzador.
Incluye PDF112páginas y Compendio completo actualizado/PDF54páginas.
Los originales anteriores están preservados localmente.

ORDEN:01_INFORME_TRANSVERSAL_Y_EXPERIMENTAL.md;03_MAPAS/CONTINUIDAD_PI01.json;
03_MAPAS/MATRIZ_ANTES_DESPUES.csv;Manual;EVIDENCIA/INDICE.json;
FUENTES para la cobertura real,con lectura completa/parcial/previamente reutilizada.

RECALCULO DOCUMENTAL(no ejecuta DEE): extraer todo el ZIP y ejecutar con Python3.10+:
python -I -B -X utf8 RECALCULO/RECALCULAR_PI01.py --root . --out-dir ../PI01_RECALCULADO --strict
Genera JSON y CSV, conservaNULLvs0 y comprueba RAW, recibos, respuestas y recursos.
CODIGO contiene revisiones históricas, hooks y scripts locales YA EJECUTADOS:
no ejecutarlos contra el principal como si fueran un instalador.

CONTINUIDAD: el paquete no incluye snapshots/SQLite/motor; NO es respaldo ejecutable.
Los localizadores del conjunto completo están en03_MAPAS. El lanzador local es
DEE thinking/DEE Cognitive2.0/ABRIR_DEE_COGNITIVE.bat(con espacios reales en el mapa).
Los comandos exactos y contratos están en el informe, Manual y las copias deINCORPORACIONES.

Se eliminó sólo el temporal de auditoría autorizado, después de preservar el ZIP
histórico y34archivos únicos.504archivos,1109275409bytes lógicos retirados.
No se midió espacio físico recuperado; estados y evidencia nueva conservados.

LÍMITES:3ramas relacionadas, no réplicas independientes; dosis distintas después
de que el acceso diverge; no panel nuevo trasT735843; no comunicación nueva ni
recuperación autoiniciada demostradas aquí. El límite de6horas de pared fue excedido
por esperas de permisos/cortes; no se reinició el reloj ni se amplió la investigación.

CONTROL/MANIFIESTO_SHA256.json cubre miembros de contenido, sin autorreferencia.
La prueba del ZIP exacto y su SHA-256 quedan fuera encontrol/VERIFICACION_FINAL_EXTERNA_PI01.json.
No se publicó ni se subió a servicios externos. Esta interfaz no ofrece un adjunto
local descargable verificado; una rutaD: no garantiza descarga desde un iPhone.
'''
readme=readme.replace('DEE thinking/DEE Cognitive2.0/','DEE thinking/DEE Cognitive 2.0/')
(E/'00_LEER_PRIMERO.txt').write_text(readme,encoding='utf-8')
coverage='''# Cobertura, omisiones y verificación

El informe yFUENTES declaran lectura completa, parcial, metadatos y reutilización.
MAR:capítulos1–58,anexosA–M,72tablas. LBM:1–74,A–L,80tablas. Lectura técnica OOXML,
sin ejecutar cápsulas; no equivale a nueva revisión visual de sus fuentes históricas.
Manual1.26leído completo en el corte anterior porhash;1.27conserva ese cuerpo y
añadePI01. QA final combina renderWord,contactos,comparación de páginas y revisión
legible de los apartados afectados; no se afirma diseño perfecto de cada página.
Otros bloques:58nuevos contenidos únicos completos/72seleccionadosCPC/Campañas;
148textos completos+1extensión+65lecturas previas reutilizadasCORE/Ingenierías/etc;
13informes y12decisiones de campañas posteriores. No sumar bloques como únicos globales.

Se incluyen100capturas primarias:60tarea(5desarrollo,54reservadas,1continuación),
12conservación y28preparación/diagnóstico/adversos;92archivos de64bytes respaldan
recursos de las cuatro vidasR04. El recálculo usa únicamente rutas relativas del
índice y separa los28primarios no puntuables. No certifica inteligencia ni promoción.

No se excluyeron oportunidades fallidas de las54reservadas; se conservan variantes
R01–R04 y los bloqueos. No se exporta toda la telemetría profunda ni snapshots por tick.
03_MAPAS/INDICE_FUENTES_Y_OMISIONES.json da rutas reales,tamaños,hashes disponibles y
conjunto mínimo para continuar. Los manualesThinking,motor,estados grandes y ZIP
histórico no se anidan. La evidencia exportada después del borrado del temporal
antiguo es suficiente para el recálculo documental, no para reproducir Native.

Se conserva la distinción entre panelT735466 y continuaciónT735843; una comprobación
administrativa0ticks no vuelve a demostrar12usos. El estado vivo no se observa desde
un caché. El propietario quedó cerrado según el recibo de reapertura; en este cierre
sólo se comparan archivos críticos ya identificados, sin ejecutar ni importarDEE.

El sellador crea Deflate estándar,manifiesto de todos los miembros excepto él mismo,
compruebaCRC/hashes,textosJSON/CSV,DOCX yPDF,y extrae en un directorio nuevo. El
recálculo desde esa extracción escribe fuera de ella. El testimonio final externo
registra los resultados reales,bytes exactos y SHA del ZIP; nunca se incluye su hash
en su propio contenedor. Cualquier cambio posterior exige otro candidato y pruebas
afectadas. Las rutas externas de procedencia no son dependencias del recálculo.

La preservación antes/después alcanza snapshot principal,padre,VIDA,SQLite,WHL,PYD,
manualesThinking y documentos publicados, no todos los archivos del proyecto.
El requisito temporal6horas no se cumplió; verINCIDENCIA_HORARIA y el informe. Las
esperas deWord/permisos y el corte de conexión no añaden experiencia del ente.

Sin acceso de subida local descargable en la interfaz, no se inventa enlaceiPhone.
No se utilizaron servicios externos. Los temporales regenerables se señalan en el
índice; no se borran automáticamente ni se confunden con estados únicos/evidencia.
'''
(E/'CONTROL/COBERTURA_OMISIONES_Y_VERIFICACION.md').write_text(coverage,encoding='utf-8')

files=[]; validations={'json':0,'jsonl_lines':0,'csv':0,'docx':0,'utf8_text':0}
for file in sorted(E.rglob('*')):
    if file.is_symlink() or getattr(file.stat(),'st_file_attributes',0)&1024: raise ValueError('Link/reparse in staging')
    if not file.is_file(): continue
    rel=file.relative_to(E).as_posix();safe(rel)
    if rel==MANIFEST: continue
    if file.suffix.lower() in ('.whl','.pyd','.sqlite3','.sqlite','.zip') or '__pycache__'in file.parts:
        raise ValueError('Unexpected engine/database/nestedZIP:'+rel)
    data=file.read_bytes(); suffix=file.suffix.lower()
    if suffix in('.json','.jsonl','.csv','.md','.txt','.py','.ps1','.patch'):
        text=data.decode('utf-8-sig');validations['utf8_text']+=1
        if suffix=='.json': json.loads(text);validations['json']+=1
        elif suffix=='.jsonl':
            for line in text.splitlines():
                if line.strip():json.loads(line);validations['jsonl_lines']+=1
        elif suffix=='.csv': list(csv.reader(io.StringIO(text)));validations['csv']+=1
    if suffix=='.docx':
        with zipfile.ZipFile(file)as doc:
            if doc.testzip()is not None or 'word/document.xml'not in doc.namelist(): raise ValueError('Invalid completeDOCX')
        validations['docx']+=1
    files.append({'path':rel,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
write(E/MANIFEST,{'schema':'PI01.all-content.manifest.v1','created_utc':now(),'algorithm':'SHA-256','excluded_from_self_hash':[MANIFEST],'no_zip_hash_inside':True,'members':files})
with zipfile.ZipFile(Z,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
    for item in files:z.write(E/item['path'],item['path'])
    z.write(E/MANIFEST,MANIFEST)
if Z.stat().st_size>15000000: raise ValueError('Compressed candidate exceeds exact15000000byte limit; preserve and create another candidate')
checks=[]
with zipfile.ZipFile(Z)as z:
    names=z.namelist()
    if len(names)!=len(set(n.casefold()for n in names)):raise ValueError('Duplicate archive names')
    if z.testzip()is not None:raise ValueError('ZIP CRC failed')
    manifest=json.loads(z.read(MANIFEST).decode('utf-8'))
    if set(names)!={MANIFEST,*[x['path']for x in manifest['members']]}:raise ValueError('Manifest coverage mismatch')
    X.mkdir(parents=True,exist_ok=False)
    for item in manifest['members']:
        safe(item['path']);data=z.read(item['path'])
        if len(data)!=item['bytes']or hashlib.sha256(data).hexdigest()!=item['sha256']:raise ValueError('Archive member mismatch')
        target=X/item['path'];target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
    (X/MANIFEST).parent.mkdir(parents=True,exist_ok=True);(X/MANIFEST).write_bytes(z.read(MANIFEST))
    for key in('manual','compendium'):
        name='02_MANUAL/'+Path(pub[key]['path']).name
        if hashlib.sha256(z.read(name)).hexdigest()!=pub[key]['sha256']:raise ValueError('Final archiveDOCX differs from actual published bytes')
        checks.append({'kind':key,'member':name,'published_bytes_match':True,'sha256':pub[key]['sha256']})
# Format checks against the clean extraction, not only staging.
for item in files:
    f=X/item['path'];suffix=f.suffix.lower()
    if sha(f)!=item['sha256']:raise ValueError('Clean extraction hash mismatch')
    if suffix=='.json':read(f)
    elif suffix=='.csv':list(csv.reader(io.StringIO(f.read_text(encoding='utf-8-sig'))))
cmd=[sys.executable,'-I','-B','-X','utf8',str(X/'RECALCULO/RECALCULAR_PI01.py'),'--root',str(X),'--out-dir',str(OUT),'--strict']
completed=subprocess.run(cmd,cwd=str(X),capture_output=True,text=True,encoding='utf-8',timeout=180)
log=P/'control/RECALCULO_DESDE_ZIP_FINAL_R02.log';log.write_text(completed.stdout+'\nSTDERR\n'+completed.stderr,encoding='utf-8')
if completed.returncode: raise ValueError('Final archive documentary recalculation failed:'+str(completed.returncode))
calc=read(OUT/'RECALCULO_PI01.json')
ev=calc['frozen_evaluator_evidence'];amounts=[(x['reserved_denominator'],x['accepted_resources'])for x in ev['per_life']]
if amounts!=[(18,16),(18,12),(18,0)]or calc['file_identity_errors']:raise ValueError('Recalculated evidence differs from report')
panel=calc['retention_panel_summary']
if len(panel)!=1 or panel[0]['material_requests_in_export']!=12 or panel[0]['concordant_with_frozen_auditor']!=12 or panel[0]['native_applied']!=929:raise ValueError('Panel denominators differ')
final=guarded_sources()
if initial!=final: raise ValueError('Decisive sources changed during packaging')
# Ensure verification/recálculo did not write into or alter any archived content.
for item in files:
    if sha(X/item['path'])!=item['sha256']or sha(E/item['path'])!=item['sha256']:raise ValueError('Archive source/extraction changed during checking')
proof={'schema':'PI01.final.exact.zip.verification.v1','verified_utc':now(),'time_zone':'America/Mexico_City','zip':desc(Z),'compressed_limit_bytes':15000000,'within_limit':True,'compression':'ZIP standard Deflate,level9,no password,no volumes','members':len(files)+1,'content_members_hashed':len(files),'uncompressed_content_bytes':sum(x['bytes']for x in files),'manifest_excludes_itself':True,'crc_all_members':True,'all_member_hashes_and_lengths_match':True,'safe_unique_paths':True,'clean_extraction':str(X),'format_checks':validations,'published_documents':checks,'recalculation':{'command':cmd,'cwd':str(X),'exit_code':completed.returncode,'new_native_ticks':0,'engine_imports':0,'log':desc(log),'outputs':[desc(OUT/name)for name in('RECALCULO_PI01.json','RECALCULO_PI01.csv','RECALCULO_RETENCION_PI01.csv')],'reserved_resources':amounts,'retention_uses':12,'retention_concordant':12,'retention_native_applied':929,'inconsistencies':0},'preservation_before_after':final,'removed_historical_folder_absent':True,'historical_zip_not_nested':True,'operational_work_already_done':'Main adoptedT735843, retained panelT735466 and separate-process continuation already recorded; not rerun here.','limitations':['Not a Native reproduction or full runnable backup','Current-life panel not repeated after final377tickcontinuation','Three dependent reserve branches, no population inference','Six-hour wall-time cap exceeded; frozen experiment already complete before closure waits','No local attachment/download service exposed; no external upload or invented download URL'],'sources_changed_during_this_packaging':[]}
priorzip=P/'control/candidatos_preliminares/DEE_PROGRESION_INTEGRADA_01_CANDIDATO_R01.zip'
if priorzip.exists():
    proof['superseded_candidate']={'zip':desc(priorzip),'verification_preserved_at':str(P/'control/candidatos_preliminares/VERIFICACION_CANDIDATO_R01.json'),'reason':'Only residual documentary pending-status references corrected; no scientific record, DOCX or physical Native state changed. Final candidate rechecked from its own new extraction.'}
write(PROOF,proof)
print(json.dumps({'zip':proof['zip'],'members':proof['members'],'integrity_and_recalculation':'verified','external_proof':str(PROOF),'new_native_ticks':0},ensure_ascii=False,indent=2))
