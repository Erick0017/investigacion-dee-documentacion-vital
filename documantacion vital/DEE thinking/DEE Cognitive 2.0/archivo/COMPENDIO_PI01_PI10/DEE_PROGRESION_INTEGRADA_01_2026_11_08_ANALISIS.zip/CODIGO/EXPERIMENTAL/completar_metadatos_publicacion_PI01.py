"""Resume metadata closure after the already witnessed DOCX publication. No DEE imports."""
from pathlib import Path
import datetime,hashlib,json,os,shutil
P=Path(__file__).resolve().parent.parent
R=P.parent.parent.parent; C=R/'DEE Cognitive 2.0'; S=C/'sistema'
def read(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,x):
    t=p.with_suffix(p.suffix+'.pi01_close_tmp')
    t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); os.replace(t,p)
proof=read(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')
for key in ('manual','compendium'):
    if sha(Path(proof[key]['path']))!=proof[key]['sha256']: raise ValueError('Published document changed')
rec=read(S/'estado/vidas/ECI02_PI01_MAIN/VIDA.json')
if read(S/'estado/ACTIVO.json')['life_id']!=rec['life_id'] or rec['physical']['tick']!=735843:
    raise ValueError('Current principal changed; no overwrite')
manual=proof['manual']; now=datetime.datetime.now(datetime.timezone.utc).isoformat()
regpath=P.parent/'REVISION_TRANSVERSAL.json'
reg=read(regpath)
backup=P/'control/REVISION_ANTES_SINCRONIA_PUBLICACION_PI01.json'
if not backup.exists(): shutil.copyfile(regpath,backup)
if reg.get('manual_update',{}).get('sha256')!=manual['sha256']:
    reg.setdefault('manual_update_history',[]).append({'preserved_reported_previous_entry':reg.get('manual_update'), 'superseded_utc':now,'note':'Literal prior1.26 kept; actual PI01 publication1.27 below.'})
reg['manual_update']=manual
reg['manual_update_PI01']=proof
block=reg.setdefault('progression_integrated_PI01',{})
if 'no_operational_promotion_yet' in block:
    block.setdefault('promotion_pending_during_development_historical',block.pop('no_operational_promotion_yet'))
block.update(manual=manual,manual_update=manual,scientific_and_operational_status='CLOSED_COMMITTED',status='CLOSED_COMMITTED',delivery_verification=str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json'))
reg['current_operation']='PI01 COMMITTED: ECI02_PI01_MAIN,N67,T735843. Protected physical parent727225 retained; Manual1.27 published and rendered. Final package verification has its own external witness. No new Native execution in this metadata synchronization.'
reg['current_operation_details']={'life_id':'ECI02_PI01_MAIN','N':67,'tick':735843,'manual':manual}
reg['resume']={'status':'PI01_SCIENTIFIC_AND_OPERATIONAL_CLOSED','principal':'ECI02_PI01_MAIN','N':67,'tick':735843,'manual_internal_edition':'1.27','next':'Continue only the adopted complete local state under its contract. No repeated experiments merely to open it.','continuity':str(P/'CONTINUIDAD_PI01.json'),'delivery_verification':str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json')}
if 'manual_update_pending_PI01' in reg:
    pending=reg.pop('manual_update_pending_PI01')
    reg['manual_update_pending_PI01_resolved']={'historical_pending_descriptor':pending,'resolved_utc':now,'actual_publication':str(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')}
reg['updated_utc']=now; write(regpath,reg)
campaign=read(P/'REGISTRO_CAMPANA.json')
for key in ('manual','manual_current'):
    if key in campaign and campaign[key].get('sha256',campaign[key].get('sha256_at_sync'))!=manual['sha256']:
        campaign.setdefault('historical_manual_before_publication',{})[key]=campaign[key]
    campaign[key]=manual
campaign.update(phase='SCIENTIFIC_OPERATIONAL_AND_DOCUMENTARY_CLOSURE',final_principal=read(P/'CONTINUIDAD_PI01.json')['current_principal'],cleanup={'record':str(P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json'),'sha256':sha(P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json'),'source_record_contains_full_preservation_and_deletion_proof':True},final_delivery_verification=str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json'))
write(P/'REGISTRO_CAMPANA.json',campaign)
mapfile=P/'MAPA_RUTAS_DECISIVAS.json'; route=read(mapfile)
route['manual_before_actual_publication_historical']=route['manual']; route['manual']=manual; write(mapfile,route)
project=read(C/'PROYECTO.json'); project.update(manual_internal_edition='1.27',manual_current_sha256=manual['sha256']); write(C/'PROYECTO.json',project)
contfile=C/'CONTINUIDAD_DEE_COGNITIVE_2_0.json'; cont=read(contfile); cont.update(manual_current=manual,last_documentary_update_PI01=now); write(contfile,cont)
renderfile=P/'control/BLOQUEO_RENDER_DOCUMENTAL.json'; render=read(renderfile)
render.update(final_status='RESOLVED',resolution='Outside sandbox, fixed short-path byte-identical copies; final PDFs produced and visually checked',final_render_proof=str(P/'documentos/RENDERIZADO_FINAL_WORD.json')); write(renderfile,render)
result={'schema':'PI01.metadata.publication.resumption.v1','utc':now,'prior_failure':'Publication copied and verified both completeDOCX and wrote its witness; metadata synchronization stopped because the preexisting current_operation field is a string, not a mapping. No Native calls and no change of physical state.','completed':'Resumed only metadata writes from the existing document witness; kept current_operation a string, preserved prior manual entries as history, and synchronized current references.','manual_sha256':manual['sha256'],'new_native_ticks':0}
write(P/'control/CIERRE_METADATOS_PUBLICACION_PI01.json',result)
print(json.dumps(result,ensure_ascii=False,indent=2))
