"""Frozen first-response retention panel and separate-process continuation."""
from pathlib import Path
import argparse,datetime,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from servicio_ensayo import Owner,P,append
LIFE='ECI02_PI01_MAIN'
PANEL=[('luma',{'modo':'apd04-palabra','texto':'luma'},1),('nara',{'modo':'apd04-palabra','texto':'nara'},-1),('clasifica',{'modo':'apd04-palabra','texto':'clasifica'},-1),('suma',{'modo':'apd04-palabra','texto':'suma'},1),('alfa',{'modo':'memoria','operacion_memoria':'usar','contexto':'alfa'},-1),('FIplus',{'modo':'eci01-balance','izquierda':14,'derecha':3},1),('FIminus',{'modo':'eci01-balance','izquierda':2,'derecha':11},-1),('FIzero',{'modo':'eci01-balance','izquierda':6,'derecha':6},0),('number13',{'modo':'eci01-aritmetica-directa','operacion':'suma','izquierda':6,'derecha':7},13),('number8',None,8),('alfa_after',{'modo':'memoria','operacion_memoria':'usar','contexto':'alfa'},-1),('luma_after',{'modo':'apd04-palabra','texto':'luma'},1)]

def response(result,label):
    row=result['result']['rows'][0]
    if label.startswith('FI'):return row['early_physical_choice']
    if label.startswith('number'):return row['numeric_result']
    if label.startswith('alfa'):row=row['result']['rows'][0]
    return row['reader']['formed_native_command']

def freeze():
    file=P/'control/PANEL_CONSERVACION_R04.json'
    if file.exists():raise RuntimeError('Do not overwrite frozen panel')
    file.write_text(json.dumps({'frozen':datetime.datetime.now().astimezone().isoformat(),'life':LIFE,'sequence':[{'label':lab,'literal':lit,'auditor_only_expected':exp}for lab,lit,exp in PANEL],'chain':'number8 request gets only the actual previous Native numeric result; no expected13 fallback.','promotion_retention_criterion':'12/12 valid concordant first responses. Physical material0 distinguished from None. No teacher or memory repair.','separate_process':'After clean owner stop, reopen same life and execute next PI01 opportunity; no environment reset or seed.'},ensure_ascii=False,indent=2),encoding='utf-8')
    print('FROZEN',file)

def run():
    json.loads((P/'control/PANEL_CONSERVACION_R04.json').read_text(encoding='utf-8'))
    rows=[];previous=None
    with Owner(LIFE,'PI01_RETENTION')as o:
        for i,(label,literal,expected)in enumerate(PANEL):
            if literal is None:
                if type(previous)is not int:append({'kind':'PANEL_STOP','reason':'No formed preceding Native number; no fallback'});break
                literal={'modo':'eci01-aritmetica-directa','operacion':'diferencia','izquierda':previous,'derecha':5}
            result=o.material('PI01_RET_%02d_%s'%(i,label),literal,feedback='omit')
            value=response(result,label)
            if label=='number13':previous=value
            rows.append({'index':i,'label':label,'literal':literal,'expected_auditor_only':expected,'response':value,'concordant':value is not None and value==expected,'before':result['before_tick'],'after':result['after_tick']})
            (P/'ensayos/RESUMEN_CONSERVACION_R04.json').write_text(json.dumps({'life':LIFE,'no_teacher':True,'rows':rows},ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(rows[-1]),flush=True)

def reopen():
    with Owner(LIFE,'PI01_REOPEN')as o:
        # Owner restoration validates resource hashes and complete operational progress.
        r=o.material('PI01_REOPEN_EP18',{'modo':'eci01-pi01-paso'})
        v=r['result']['rows'][0]
        compact={'life':LIFE,'episode':v['episode'],'before_tick':r['before_tick'],'after_tick':r['after_tick'],'route':v['native_decision']['route'],'response':v['selected_access']['physical_response'],'effect':v['external_effect'],'continuation':'same physical life and environment; no reseeding/reset'}
        (P/'ensayos/REAPERTURA_CONTINUACION_R04.json').write_text(json.dumps(compact,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(compact),flush=True)

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('operation',choices=['freeze','panel','reopen']);args=a.parse_args();{'freeze':freeze,'panel':run,'reopen':reopen}[args.operation]()
