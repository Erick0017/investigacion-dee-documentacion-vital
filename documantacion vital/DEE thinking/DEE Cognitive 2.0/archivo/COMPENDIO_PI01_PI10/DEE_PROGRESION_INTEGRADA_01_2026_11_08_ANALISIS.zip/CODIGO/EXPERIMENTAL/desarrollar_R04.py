from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from servicio_ensayo import Owner,P,append
life='ECI02_PI01_DESARROLLO_R04'
with Owner(life,'PI01_DEV_R04')as o:
 o.material('PI01_DEV_R04_PREPARE',{'modo':'eci01-pi01-preparar'})
 o.material('PI01_DEV_R04_ENV',{'modo':'eci01-pi01-ambiente','serie':'desarrollo','brazo':'real'})
 rows=[]
 for e in range(5):
  result=o.material('PI01_DEV_R04_EP%02d'%e,{'modo':'eci01-pi01-paso'},allow_failure=True)
  if 'result'not in result or result.get('operation')!='sesion':
   append({'kind':'DEVELOPMENT_STOP','reason':'preserved failed future','life':life,'episode':e});break
  v=result['result']['rows'][0];rows.append({'episode':e,'before':result['before_tick'],'after':result['after_tick'],'route':v['native_decision']['route'],'access':v['selected_access']['access'],'response':v['selected_access']['physical_response'],'effect':v['external_effect'],'return':v['native_return'],'native_decision':v['native_decision']['frames'][2]['center'],'after_physical':v['after']})
  print(json.dumps({k:rows[-1][k]for k in('episode','before','after','route','access','response','effect')},ensure_ascii=False),flush=True)
  if len(rows)>=2 and all(x['route']is None for x in rows[-2:]):append({'kind':'DEVELOPMENT_STOP','reason':'two consecutive absent route signatures','life':life});break
 (P/'ensayos/RESUMEN_DESARROLLO_R04.json').write_text(json.dumps({'scope':'Development only; not reserved validation or adoption','life':life,'rows':rows},ensure_ascii=False,indent=2),encoding='utf-8')
