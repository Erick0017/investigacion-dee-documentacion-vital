from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent.parent;S=P/'estados/candidato/sistema';back=P/'codigo/revisiones/R03_EJECUTADA'
for rel in ['capacidades/progresion_integrada_01.py','app/mundo_genesis_apd05.py','app/cola_local.py']:
 target=back/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/rel,target)
base=(P/'codigo/progresion_integrada_01_R03.py').read_text(encoding='utf-8')
base=base.replace('def prepare(a):\n','def prepare(a,origin=D):\n D=tuple(origin)\n')
target=P/'codigo/pi01_traza_legal_base_R04.py';target.write_text(base,encoding='utf-8');shutil.copy2(target,S/'capacidades/pi01_traza_legal_base.py')
shutil.copy2(P/'codigo/tarea_acceso_recursos_R04.py',S/'capacidades/progresion_integrada_01.py')
q=S/'app/mundo_genesis_apd05.py';t=q.read_text(encoding='utf-8')
needle='        return result\n\n    def validate'
replacement="""        from capacidades import progresion_integrada_01 as pi
        for name in ('progresion_integrada_01.py','pi01_traza_legal_base.py'):
            path=Path(__file__).resolve().parents[1]/'capacidades'/name
            self.code_sha256[name]=hashlib.sha256(path.read_bytes()).hexdigest()
        pi.resources_valid(self.a,self.work_directory)
        return result

    def validate"""
assert needle in t;t=t.replace(needle,replacement,1)
needle='        return acceso_eci01.extend_operational_dependencies(self.a,super().operational_dependencies())'
replacement="""        result=acceso_eci01.extend_operational_dependencies(self.a,super().operational_dependencies())
        from capacidades import progresion_integrada_01 as pi
        result['PI01']=pi.resources_valid(self.a,self.work_directory)
        return result"""
assert needle in t;t=t.replace(needle,replacement)
needle='        return super().external_uncertainty()or acceso_eci01.external_uncertainty(self.a)'
replacement="""        from capacidades import progresion_integrada_01 as pi
        return super().external_uncertainty()or acceso_eci01.external_uncertainty(self.a)or pi.uncertain(self.a)"""
assert needle in t;t=t.replace(needle,replacement)
q.write_text(t,encoding='utf-8')
files=['capacidades/progresion_integrada_01.py','capacidades/pi01_traza_legal_base.py','app/mundo_genesis_apd05.py','app/cola_local.py']
freeze=P/'codigo/revisiones/R04_CONGELADA'
for rel in files:
 target=freeze/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/rel,target)
m={'version':'PI01.R04','origin':[0,5,20],'base_mechanism':'CORE09 two-state trace, adapted legal API and N67; not new discovery of P2 in isolation','prepared_geometric_criterion':'First lexicographic origin among8322 withRAW0 rays and Chebyshev>=4 from FI128 opened','design_source':'lecturas/CAMPAÑAS_POSTERIORES/COMPATIBILIDAD_PI01/SEPARACION_EXHAUSTIVA_FI_RAW0.json','fixed_feedback_delay_ticks':268,'fixed_reader':'origin at exact decision boundary; no window search','files':[{'file':x,'sha256':hashlib.sha256((S/x).read_bytes()).hexdigest()}for x in files],'code_immutable_before_development':True,'new_native_ticks_by_deploy':0}
(P/'control/DESPLIEGUE_R04.json').write_text(json.dumps(m,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(m,ensure_ascii=False,indent=2))
