from pathlib import Path
import hashlib,json,shutil
P=Path(__file__).resolve().parent.parent;S=P/'estados/candidato/sistema'
shutil.copyfile(P/'codigo/progresion_integrada_01_R01.py',S/'capacidades/progresion_integrada_01.py')
q=S/'app/cola_local.py';t=q.read_text(encoding='utf-8');needle="        for row in rows:\n"
assert t.count(needle)==1
t=t.replace(needle,needle+"            if str(row.get('modo','')).startswith('eci01-pi01-'):\n                from capacidades.progresion_integrada_01 import validate_literal\n                validate_literal(row)\n                continue\n",1);q.write_text(t,encoding='utf-8')
q=S/'app/mundo_genesis_apd05.py';t=q.read_text(encoding='utf-8')
needle='        row=self._eci01_row(payload)\n'
assert t.count(needle)==2
pos=t.index(needle)+len(needle)
t=t[:pos]+"        if row is not None and str(row.get('modo','')).startswith('eci01-pi01-'):\n            from capacidades import progresion_integrada_01 as pi\n            pi.validate(self.a,row)\n            return\n"+t[pos:]
start=t.index('    def execute(self,payload):');pos=t.index(needle,start)+len(needle)
t=t[:pos]+"        if row is not None and str(row.get('modo','')).startswith('eci01-pi01-'):\n            from capacidades import progresion_integrada_01 as pi\n            pi.validate(self.a,row)\n            self.before_mutation('PI01_DECLARED_EXPERIMENTAL_PROTOCOL')\n            value=pi.dispatch(self.a,row,actuator=payload.get('actuador','closed'),directory=self.work_directory)\n            return {'version':pi.VERSION,'rows':[value],'INSTRUMENTO_FENCE':{'denied':self.guard['denied_operations'],'scope':self.guard['scope']}}\n"+t[pos:]
q.write_text(t,encoding='utf-8')
files=['app/cola_local.py','app/mundo_genesis_apd05.py','capacidades/progresion_integrada_01.py']
m={'version':'PI01.R01','files':[{'path':x,'sha256':hashlib.sha256((S/x).read_bytes()).hexdigest()}for x in files],'native_ticks':0}
(P/'control/DESPLIEGUE_R01.json').write_text(json.dumps(m,indent=2),encoding='utf-8');print(json.dumps(m,indent=2))
