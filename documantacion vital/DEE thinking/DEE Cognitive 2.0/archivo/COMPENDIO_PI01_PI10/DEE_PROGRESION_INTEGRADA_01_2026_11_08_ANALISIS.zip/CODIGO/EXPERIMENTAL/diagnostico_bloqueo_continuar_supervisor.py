"""Corrige sólo origen del validador; continúa la misma semilla, no la reenvía."""
from pathlib import Path
import sys,json,hashlib,datetime
P=Path(__file__).resolve().parent.parent;S=P/'estados/diagnostico_bloqueo/sistema'
sys.path.insert(0,str(S))
from app.cola_local import QueueDB
from capacidades.progresion_integrada_01 import validate_literal
sys.path.insert(0,str(P/'codigo'))
from servicio_ensayo import Owner,append
life='ECI02_PI01_TRAZA_BLOQUEO'
reg=json.loads((P/'control/PROTOCOLO_TRAZA_BLOQUEO.json').read_text(encoding='utf-8'))
assert hashlib.sha256((S/'capacidades/progresion_integrada_01.py').read_bytes()).hexdigest()==reg['diagnostic_sha256']
append({'kind':'INSTRUMENT_SUPERVISOR_CORRECTION','role':'Diagnostic only','life':life,'no_ticks_by_edit':True,'reason':'Prior supervisor resolved generic queue validator from candidate; new literal rejected before enqueue. Same prepared future continued, no repeated seed/import.','new_code':str(Path(__file__)),'new_code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()})
with Owner(life,'PI01_DIAGNOSTIC_BLOCKAGE_CONTINUE',system=S)as own:
 result=own.material('PI01_TRAZA_BLOQUEO_INTERVAL',{'modo':'eci01-pi01-traza-bloqueo'})
 print(json.dumps({'diagnostic_completed':True,'life':life,'last_tick':result['after_tick'],'pid':own.proc.pid},ensure_ascii=False),flush=True)
