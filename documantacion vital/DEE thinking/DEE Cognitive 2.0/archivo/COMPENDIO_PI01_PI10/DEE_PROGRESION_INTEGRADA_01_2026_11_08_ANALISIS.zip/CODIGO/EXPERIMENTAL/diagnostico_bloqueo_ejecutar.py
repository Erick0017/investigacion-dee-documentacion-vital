"""Ejecuta sólo la reproducción diagnóstica preregistrada; cierre por Owner."""
from pathlib import Path
import sys,json,hashlib,datetime
P=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(P/'codigo'))
from servicio_ensayo import Owner,append
S=P/'estados/diagnostico_bloqueo/sistema';life='ECI02_PI01_TRAZA_BLOQUEO'
reg=json.loads((P/'control/PROTOCOLO_TRAZA_BLOQUEO.json').read_text(encoding='utf-8'))
assert hashlib.sha256((S/'capacidades/progresion_integrada_01.py').read_bytes()).hexdigest()==reg['diagnostic_sha256']
with Owner(life,'PI01_DIAGNOSTIC_BLOCKAGE',system=S)as own:
 prep=own.material('PI01_TRAZA_BLOQUEO_PREPARE',{'modo':'eci01-pi01-preparar'})
 trace=own.material('PI01_TRAZA_BLOQUEO_INTERVAL',{'modo':'eci01-pi01-traza-bloqueo'})
 print(json.dumps({'diagnostic_completed':True,'life':life,'last_tick':trace['after_tick'],'pid':own.proc.pid},ensure_ascii=False),flush=True)
