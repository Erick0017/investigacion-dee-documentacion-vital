"""Prepara un diagnóstico aislado y su preregistro; no inicia el motor."""
from pathlib import Path
import shutil,os,json,hashlib,datetime
P=Path(__file__).resolve().parent.parent;R=P.parents[2]
S=P/'estados/diagnostico_bloqueo/sistema';BASE=P/'estados/candidato/sistema'
assert not S.exists(),'Do not replace a diagnostic future'
shutil.copytree(BASE,S,ignore=shutil.ignore_patterns('estado','runtime','__pycache__','*.pyc'))
(S/'runtime').mkdir()
for p in(BASE/'runtime').iterdir():
 if p.is_file():
  if p.suffix.lower()in('.whl','.pyd','.dll','.exe'):os.link(p,S/'runtime'/p.name)
  else:shutil.copy2(p,S/'runtime'/p.name)
for n in ['vidas','checkpoints','locks']:(S/'estado'/n).mkdir(parents=True,exist_ok=True)
source=P/'codigo/progresion_integrada_01_R02.py';text=source.read_text(encoding='utf-8')
extra=r'''
# Diagnostic-only passive extension. Original R02 preparation/ports are unchanged.
def trace_blockage(a,directory):
 from pathlib import Path
 m=get(a);seed=int(m['seed_effective_tick']);decision=seed+3*N;feedback=decision+N
 if m['uncertain']or m['in_progress']:raise ValueError('Incomplete diagnostic future')
 m['in_progress']={'kind':'diagnostic_trace','decision':decision,'feedback':feedback};save(a,m)
 sensor=submit_arrival(a,m['prefix']+'sensor',17,decision)
 a.run_until(decision+2)
 first={'tick':int(a.tick),'center':obs(a,D)}
 normal=submit_arrival(a,m['prefix']+'normalizer',3,feedback)
 a.run_until(decision+51)
 folder=Path(directory)/'TRAZA_BLOQUEO';folder.mkdir(exist_ok=True)
 pre=folder/'ANTES_INTERVALO.deetsnap.gz';a.save(pre)
 frames=[];focus=(47,49,45)
 for rel in range(52,69):
  a.run_until(decision+rel)
  roi=[obs(a,tuple((focus[i]+offset[i])%N for i in range(3)))for offset in __import__('itertools').product(range(-3,4),repeat=3)]
  moving=[obs(a,add(D,(0,0,1),rel+k))for k in(-1,0,1)]
  frame={'tick':int(a.tick),'relative_to_decision':rel,'center':obs(a,D),'predicted_ray_neighborhood':moving,'fixed_roi_center':list(focus),'fixed_roi_radius':3,'roi':roi}
  if rel in(59,60,62,63):frame['global_physical']=physical(a.world)
  frames.append(frame)
 post=folder/'DESPUES_INTERVALO.deetsnap.gz';a.save(post)
 m['in_progress']=None;m['diagnostic_trace_completed']=int(a.tick);save(a,m)
 return {'diagnostic_new_execution':True,'not_a_game_or_learning_evaluation':True,'same_R02_ports_and_timing':True,'seed':seed,'decision':decision,'feedback':feedback,'sensor_receipt':rr(a,sensor),'normalizer_receipt':rr(a,normal),'first_decision_plus2':first,'frames':frames,'snapshots':[str(pre),str(post)],'state':state(a),'no_raw_or_clock_edits':True}
_r02_validate_literal=validate_literal
def validate_literal(row):
 if isinstance(row,dict)and row.get('modo')=='eci01-pi01-traza-bloqueo':
  if set(row)!={'modo'}:raise ValueError('No target/extra metadata allowed')
 else:_r02_validate_literal(row)
_r02_dispatch=dispatch
def dispatch(a,row,*,actuator='closed',directory=None):
 validate(a,row)
 if row['modo']=='eci01-pi01-traza-bloqueo':return trace_blockage(a,directory)
 return _r02_dispatch(a,row,actuator=actuator,directory=directory)
'''
target=P/'codigo/progresion_integrada_01_R02_TRAZA.py';target.write_text(text+extra,encoding='utf-8')
shutil.copyfile(target,S/'capacidades/progresion_integrada_01.py')
frozen={'schema':'PI01.diagnostic.blockage.prereg.v1','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'role':'New diagnostic technical reproduction, not audit0ticks','life':'ECI02_PI01_TRAZA_BLOQUEO','parent':'ECI02_OPERATIVA_PRINCIPAL_01','N':67,'parent_tick':727225,'system':str(S),'base_R02_source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'diagnostic_source':str(target),'diagnostic_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'origin':[47,49,53],'seed_load':7,'sensor_load':17,'normalizer_load':3,'decision':'seed_effective_tick+3N','normalizer':'decision+67 exactly','passive_window':'decision+52..+68 inclusive; ROI radius3 at47,49,45 plus trajectoryZ around predicted site','preserved_inputs':'same first R02 seed/sensor/normalizer; no penalty, no game','interventions':[],'stops':'One interval only; no repairs; maximum10minutes; preserve failure and close owner','comparison':'Compare center at feedback+1/+2 and receipts to R02 primary; do not infer lineage by charge alone','source_code_frozen_before_execution':True}
(P/'control/PROTOCOLO_TRAZA_BLOQUEO.json').write_text(json.dumps(frozen,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(frozen,ensure_ascii=False,indent=2))
