"""Existing paired export; zero physical ticks, preserves full transport."""
from pathlib import Path
import datetime,hashlib,json,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from servicio_ensayo import Owner,P,append
dest=P/'control/PAR_FINAL_PI01.json'
if dest.exists():raise RuntimeError('Final pair already recorded; never repeat an uncertain export')
with Owner('ECI02_PI01_MAIN','PI01_CIERRE')as owner:
    row=owner.control('exportar')
    (P/'ensayos/PI01_CIERRE_EXPORT.json').write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
    result=json.loads(row['result'])
    if result['before_tick']!=735843 or result['after_tick']!=735843:raise RuntimeError('Export advanced unexpectedly; preserve record')
    pair=result['paired_export'];path=Path(pair['directory']);manifest=path/'EXPORTACION_SERVICIO.json'
    if hashlib.sha256(manifest.read_bytes()).hexdigest()!=pair['manifest_sha256']:raise RuntimeError('Manifest changed')
    dest.write_text(json.dumps({'source_life':'ECI02_PI01_MAIN','source_tick':735843,'recorded':datetime.datetime.now().astimezone().isoformat(),'pair':pair,'owner_export_request':row['id'],'operation':'Complete existing paired export, no Native acquisition or physical advance'},ensure_ascii=False,indent=2),encoding='utf-8')
    append({'kind':'FINAL_COMPLETE_PAIR','descriptor':str(dest),'pair':pair,'before_tick':735843,'after_tick':735843});print(json.dumps(pair),flush=True)
