from pathlib import Path
import importlib.util,json
P=Path(__file__).resolve().parent.parent;S=P/'estados/candidato/sistema'
spec=importlib.util.spec_from_file_location('passive_pi01',S/'capacidades/observador_causal_retrospectivo_01.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads((S/'estado/vidas/ECI02_PI01_DESARROLLO_R01/VIDA.json').read_text(encoding='utf-8'));s=m.Snapshot(S/r['snapshot'],verify_checksum=False)
policy=json.loads(s.metadata['DEE.Cognitive.System.1.1.PROGRESION_INTEGRADA_01.R01'])
value={'tick':s.tick,'pending':s.pending,'receipt':next(x for x in s.receipts if x['id']==policy['seed_receipt']['id']),'policy':policy,'origin':m.fields(s.raw[m.index([47,49,53],s.N)]),'next':m.fields(s.raw[m.index([48,49,53],s.N)]),'new_ticks':0,'scope':'Passive saved bytes, not fresh world execution'}
(P/'ensayos/SEMANTICA_ADMISION_R01.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(value,ensure_ascii=False,indent=2))
