"""Mapa pasivo de compatibilidad, no selección de respuestas ni avance DEE."""
from pathlib import Path
import importlib.util,json,collections
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;S=R/'DEE Cognitive 2.0/sistema'
spec=importlib.util.spec_from_file_location('passive_route_pi01',S/'capacidades/observador_causal_retrospectivo_01.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rec=json.loads((S/'estado/vidas/ECI02_OPERATIVA_PRINCIPAL_01/VIDA.json').read_text(encoding='utf-8'));snap=m.Snapshot(S/rec['snapshot'],verify_checksum=False);n=snap.N
directions={'A':(1,0,0),'B':(0,1,0),'action0':(0,0,1),'action1':(-1,1,1),'normalizer':(1,0,-1)}
def routes(origin):
 out={}
 for name,v in directions.items():
  obstacles=[]
  for k in range(n):
   p=tuple((origin[i]+k*v[i])%n for i in range(3));index=m.index(p,n);raw=int(snap.raw[index])
   if raw:obstacles.append({'distance_ticks':k,'site':p,'clock':int(snap.clocks[index]),**m.fields(raw)})
  out[name]=obstacles
 return out
old=routes((47,49,53))
# Finite geometric screen declared before functional evaluation; never scores a response.
candidates=[]
for origin in [(41,43,47),(37,41,43),(43,47,51),(49,43,37),(31,47,59),(39,37,47),(53,41,31),(47,39,43)]:
 r=routes(origin);candidates.append({'origin':origin,'nonzero_ray_intersections':sum(map(len,r.values())),'rays':r})
value={'snapshot':str(S/rec['snapshot']),'snapshot_sha256':rec['snapshot_sha256'],'N':n,'T':snap.tick,'old_origin':[47,49,53],'old_rays':old,'finite_geometry_candidates':candidates,'scope':'Static planned rays. Does not prove actual lineage, isolation of future traffic or cause of disappearance. RAW0 is not assumed to mean clock/history absent. No world loaded, no ticks.'}
(P/'ensayos/MAPA_RUTAS_P0.json').write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'old':old,'candidate_counts':[{k:x[k]for k in('origin','nonzero_ray_intersections')}for x in candidates]},ensure_ascii=False,indent=2))
