"""Prepare portable scientific evidence; not a Native runner or distribution."""
from pathlib import Path
import argparse,csv,datetime,difflib,hashlib,json,shutil,zipfile
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;C=R/'DEE Cognitive 2.0';S=C/'sistema';E=P/'entrega/EXPEDIENTE'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
copies=[]
def cp(source,relative):
 source=Path(source);target=E/relative
 if not source.is_file():raise FileNotFoundError(source)
 target.parent.mkdir(parents=True,exist_ok=True)
 if not target.exists()or sha(source)!=sha(target):shutil.copyfile(source,target)
 if sha(source)!=sha(target):raise ValueError('Copy mismatch:'+str(source))
 copies.append({'source':str(source),'export':relative,'bytes':source.stat().st_size,'sha256':sha(source)})

def assemble(with_documents=False):
 if not(E/'EVIDENCIA/INDICE.json').is_file():raise RuntimeError('Portable primary core not ready')
 for file in ['CONTINUIDAD_PI01.json','FICHA_ENTE_Y_ASISTENCIA.json','MAPA_RUTAS_DECISIVAS.json','MATRIZ_ANTES_DESPUES.csv']:
  cp(P/file,'03_MAPAS/'+file)
 cp(P/'INFORME_TRANSVERSAL_Y_EXPERIMENTAL.md','01_INFORME_TRANSVERSAL_Y_EXPERIMENTAL.md')
 for folder in ['MAR','LBM','CORPUS','CPC_Y_CAMPAÑAS','CAMPAÑAS_POSTERIORES']:
  src=P/'lecturas'/folder
  for file in src.iterdir():
   if file.is_file()and(file.name.startswith(('COBERTURA','SINTESIS','MATRIZ','RECALCULO_DOCUMENTAL','C9H02_RECALCULO','NOTAS_TECNICAS','COMPENDIO_FUENTE','ESTRUCTURA_Y_FUENTE','EXTRACTOS_INDICE','ZIP_FUENTES','LOCALIZADORES','MECANISMO_C9','FUENTES_C9','FUNDAMENTOS_ADICIONALES','DECISIVO_C9'))):
    cp(file,'FUENTES/'+folder+'/'+file.name)
 # Literal selected historical controls, never nested historical ZIPs.
 for file in(P/'lecturas/CPC_Y_CAMPAÑAS/extractos').iterdir():
  if file.is_file()and file.name!='1318578b4b0f7e33_C02_GATE_050_RETORNO.json.gz':cp(file,'FUENTES/CPC_Y_CAMPAÑAS/extractos/'+file.name)
 # Exact code revisions, including negative attempts, plus current operational bytes.
 for file in(P/'codigo').rglob('*'):
  if file.is_file()and '__pycache__'not in file.parts and file.suffix.lower()in('.py','.json','.md','.ps1'):
   cp(file,'CODIGO/EXPERIMENTAL/'+file.relative_to(P/'codigo').as_posix())
 four=['capacidades/progresion_integrada_01.py','capacidades/pi01_traza_legal_base.py','app/mundo_genesis_apd05.py','app/cola_local.py']
 for rel in four:cp(S/rel,'CODIGO/OPERATIVO/'+rel)
 for rel in ['app/mundo_genesis_apd05.py','app/cola_local.py']:
  before=P/'control/ADOPCION_PI01_RESPALDO/sistema'/rel
  cp(before,'CODIGO/ANTES_PI01/'+rel)
  diff=''.join(difflib.unified_diff(before.read_text(encoding='utf-8').splitlines(True),(S/rel).read_text(encoding='utf-8').splitlines(True),fromfile='ANTES/'+rel,tofile='ACTUAL/'+rel))
  dest=E/'CODIGO/PARCHES'/Path(rel).name;dest.parent.mkdir(parents=True,exist_ok=True);dest.with_suffix('.patch').write_text(diff,encoding='utf-8')
 for rel in ['capacidades/mente_unificada_01.py','capacidades/mente_acumulativa_r02.py','capacidades/acceso_eci01.py','capacidades/aritmetica_directa_eci02.py','capacidades/aritmetica_apd_01.py','capacidades/lexico_compartido_apd04.py','app/servicio_persistente.py','app/importacion_emparejada.py']:
  cp(S/rel,'CODIGO/DEPENDENCIAS_LEIDAS/'+rel)
 for name in ['PROTOCOLO_RESERVA_R04.json','PANEL_CONSERVACION_R04.json','PAR_FINAL_PI01.json','VALIDACION_ADOPCION_R04.json','PREPARACION_PRODUCTO_PI01.json','REAPERTURA_PRODUCTO_PI01.json','DECISION_PROMOCION_PI01.json','ADOPCION_PRODUCTO_PI01.json','INCIDENCIA_HORARIA.json','CORRECCION_REFERENCIAS_N0.json','DESPLIEGUE_R01.json','DESPLIEGUE_R04.json','VERIFICACION_RECALCULO_PI01.json','VERIFICACION_RECALCULO_PI01_PANEL.json','LIMPIEZA_AUDITORIA_EJECUTADA.json','NUCLEO_PORTATIL_POST_LIMPIEZA.json']:
  cp(P/'control'/name,'CONTROL/'+name)
 for rel in ['PROYECTO.json','CONTINUIDAD_DEE_COGNITIVE_2_0.json','sistema/estado/ACTIVO.json','sistema/estado/genesis/SELECCION_PERSONAL.json','aplicacion/GENESIS/SELECCION_CANDIDATA.json','sistema/estado/vidas/ECI02_PI01_MAIN/VIDA.json','sistema/contratos/PROGRESION_INTEGRADA_01_R04.json','sistema/contratos/ARITMETICA_DIRECTA_ECI02_P0.json','sistema/contratos/ACCESO_TEMPRANO_P0_ECI02.json','sistema/contratos/SERVICIO_PERSISTENTE_MU01.json','sistema/capacidades/CATALOGO_CAPACIDADES.json']:
  cp(C/rel,'INCORPORACIONES/'+rel)
 for file in(S/'estado/vidas/ECI02_PI01_MAIN/PROCEDENCIA_PI01').iterdir():
  if file.is_file():cp(file,'03_MAPAS/PROCEDENCIA_MIGRACION/'+file.name)
 cp(P/'ENSAYOS.jsonl','EVIDENCIA/ENSAYOS_COMPLETOS_CAMPAÑA.jsonl')
 cp(P/'REGISTRO_CAMPANA.json','03_MAPAS/REGISTRO_CAMPANA.json')
 # The existing2MB transversal register is preserved locally; export only its affected block.
 reg=read(P.parent/'REVISION_TRANSVERSAL.json');fragment={k:v for k,v in reg.items()if k in('current_operation','progression_integrated_PI01','resume','manual_update_PI01')}
 (E/'03_MAPAS/REGISTRO_TRANSVERSAL_AFECTADO.json').write_text(json.dumps(fragment,ensure_ascii=False,indent=2),encoding='utf-8')
 cp(P/'control/PAR_FINAL_PI01.json','03_MAPAS/PAR_COMPLETO_LOCALIZADOR.json')
 pair=Path(read(P/'control/PAR_FINAL_PI01.json')['pair']['directory'])
 cp(pair/'EXPORTACION_SERVICIO.json','03_MAPAS/MANIFIESTO_PAR_FUENTE_T735843.json')
 if with_documents:
  doc=read(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json')
  if doc['manual']['internal_edition']!='1.27':raise ValueError('Actual complete updated manual required')
  for name in('manual','compendium'):
   info=doc[name];src=Path(info['path'])
   if sha(src)!=info['sha256']:raise ValueError('Document changed since publication witness')
   cp(src,'02_MANUAL/'+src.name)
  cp(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json','CONTROL/DOCUMENTOS_PUBLICADOS_PI01.json')
 (E/'CODIGO/LEER_CODIGO.txt').write_text('RECALCULO/RECALCULAR_PI01.py es el verificador portátil sin motor ni ticks.\nCODIGO/OPERATIVO contiene los cuatro módulos incorporados. DEPENDENCIAS_LEIDAS son fuentes de contexto: requieren el producto/motor oficial local, omitidos.\nEXPERIMENTAL conserva revisiones exactas y supervisores; NO ejecutar indiscriminadamente ni apuntarlos al principal. El protocolo Native requiere copias completas identificadas y un escritor. Los scripts de promoción tienen guardias y documentan operaciones ya realizadas, no son un instalador automático.\nEl ZIP es un expediente de análisis, no un respaldo ejecutable del ente.\n',encoding='utf-8')
 (E/'CONTROL/COPIAS_Y_PROCEDENCIA.json').write_text(json.dumps(copies,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({'files':sum(p.is_file()for p in E.rglob('*')),'uncompressed_bytes':sum(p.stat().st_size for p in E.rglob('*')if p.is_file()),'documents_included':with_documents}))

if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--with-documents',action='store_true');args=a.parse_args();assemble(args.with_documents)
