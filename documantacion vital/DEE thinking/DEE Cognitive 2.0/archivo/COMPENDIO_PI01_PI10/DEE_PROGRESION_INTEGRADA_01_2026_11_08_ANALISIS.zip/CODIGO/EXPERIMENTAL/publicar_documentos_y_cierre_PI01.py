"""Publish already checked complete documents and closure metadata. Zero DEE imports."""
from pathlib import Path
import datetime,hashlib,json,os,shutil,zipfile
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;C=R/'DEE Cognitive 2.0';S=C/'sistema';D=P/'documentos';REG=P.parent/'REVISION_TRANSVERSAL.json'
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(p,x):
 t=p.with_suffix(p.suffix+'.pi01_close_tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
def desc(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
if(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json').exists():raise ValueError('Publication already witnessed; do not overwrite or downgrade')
for name in['QA_VISUAL_MANUAL_FINAL.json','QA_VISUAL_MANUAL_RAIZ.json','QA_VISUAL_COMPENDIO.json']:
 if not(P/'control'/name).is_file():raise ValueError('Missing visual review:'+name)
adoption=read(P/'control/ADOPCION_PRODUCTO_PI01.json')
if adoption['phase']!='COMMITTED':raise ValueError('No operational adoption')
rec=read(S/'estado/vidas/ECI02_PI01_MAIN/VIDA.json');active=read(S/'estado/ACTIVO.json')
if active['life_id']!=rec['life_id']or rec['physical']['tick']!=735843 or rec['snapshot_sha256']!='4c585112f33b126a0ee6114e19ef203f0bab658f76545636a6e70f573d628a50':raise ValueError('Principal changed: do not rewind')
frozen=[(S/'runtime/dee_thinking-4.5.0-cp313-cp313-win_amd64.whl','09e191d259fd15d321ea11b587f8cc02c12c7adfe81b7b96ca2dbebb1fb12d0c'),(C/'motor/python313/site-packages/dee_thinking/_native.cp313-win_amd64.pyd','17f827341530f66816ec146af085b00a5f7b3d34d645bcd407f1279e8ac6c50d'),(R/'4.5/DEE_thinking_4_5_0_Maestro_Arquitectura_Reconstruccion.docx','8092eedf55c495a9729c4e9ce795fc7bb9135bcbfe60941ab050634b135194ec'),(R/'4.5/DEE_thinking_4_5_0_Libro_Blanco_y_Manual_Tecnico.docx','02f7de4cdbc5dd1a4763e0ff2dc9c59e02d1988a507a091e6335d7eafaec33e4')]
preservation=[]
for p,h in frozen:
 if sha(p)!=h:raise ValueError('Frozen artifact mismatch:'+str(p))
 preservation.append(desc(p)|{'expected_sha256':h,'unchanged_against_start_or_registered_source':True})
parent=read(S/'estado/vidas/ECI02_OPERATIVA_PRINCIPAL_01/VIDA.json');parentfile=S/parent['snapshot']
if sha(parentfile)!='46e275be49a1e8df9b823e3c533156d91fa66a79477872a125efabfa350470d4':raise ValueError('Protected parent changed')
preservation.append(desc(parentfile)|{'role':'Protected parent atT727225','unchanged':True})
source=read(D/'ACTUALIZACION_DOCUMENTAL_CORREGIDA.json');renders=read(D/'RENDERIZADO_FINAL_WORD.json');bykind={x['Kind']:x for x in renders};documents={}
for kind,key,target in [('Manual','manual',C/'DEE_Cognitive_2_0_Manual_Maestro_DCS11_MM_001_Edicion_1_21.docx'),('Compendium','compendium',R/'CPC - Experimentos y mecanismos/COMPENDIO_MAESTRO_DE_MECANISMOS_Y_RESULTADOS_DEE.docx')]:
 item=source[kind];staged=Path(item['output']);oldhash='ad443b3623592730969fc5cbe6857ca2b47480fbf65936d17dea9cf65a6d1029'if kind=='Manual'else'3275e6b9db9d2dba4475a17f26a9fd18d33db63c903f5faa8b7a25b0b48fd6e0'
 if sha(staged)!=item['sha256']or sha(target)!=oldhash:raise ValueError('Document changed; preserve and reconcile')
 if bykind[kind]['InputSha256']!=item['sha256']or not bykind[kind]['ReadOnly']:raise ValueError('PDF does not represent exact staged bytes')
 with zipfile.ZipFile(staged)as z:
  if z.testzip()is not None:raise ValueError('DOCX CRC failed')
 backup=P/'respaldo_inicial'/target.name
 if backup.exists():
  if sha(backup)!=oldhash:raise ValueError('Different prior document backup protected')
 else:shutil.copyfile(target,backup)
 shutil.copyfile(staged,target)
 if sha(target)!=item['sha256']:raise ValueError('Publication copy mismatch')
 documents[key]=desc(target)|{'internal_edition':'1.27'if kind=='Manual'else'PI01 cumulative update,8nov2026','prior_complete_document':desc(backup),'rendered_pdf':desc(Path(bykind[kind]['Output'])),'rendered_pages':bykind[kind]['Pages'],'same_logical_manual_and_filename':kind=='Manual','visual_qa':'Contact overview plus readable affected pages; see QA scope, not a new full historical scientific reading.'}
proof={'schema':'PI01.actual.document.publication.v1','published_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manual':documents['manual'],'compendium':documents['compendium'],'engine_and_source_preservation':preservation,'new_native_ticks':0,'no_life_data_modified_by_document_publication':True,'manual_source_before':'1.26, literal archived copy retained','filename1_21_retained_for_launcher':True,'render_method':'Microsoft Word16.0, read-only short-path copies with exact inputSHA and PDF copySHA; PopplerPNG QA','initial_render_block_resolved':True}
write(P/'control/DOCUMENTOS_PUBLICADOS_PI01.json',proof)
cont=read(P/'CONTINUIDAD_PI01.json');cont['manual']=documents['manual'];cont['manual_target_edition']='1.27';cont['manual_status']='PUBLISHED_AND_RENDERED';cont['analysis_zip_status']='See external final verification after sealing';write(P/'CONTINUIDAD_PI01.json',cont)
reg=read(REG);reg['manual_update_PI01']=proof;reg.setdefault('progression_integrated_PI01',{})['manual_update']=documents['manual'];reg['progression_integrated_PI01']['scientific_and_operational_status']='CLOSED_COMMITTED';reg['progression_integrated_PI01']['delivery_verification']=str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json')
reg.setdefault('current_operation',{})['manual']=documents['manual'];reg['resume']={'status':'PI01_SCIENTIFIC_AND_OPERATIONAL_CLOSED','principal':'ECI02_PI01_MAIN','N':67,'tick':735843,'manual_internal_edition':'1.27','next':'Continue only the adopted complete current state under its contract. No reserved/protected experiments rerun merely to open it.','delivery_verification':str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json')};write(REG,reg)
campaign=read(P/'REGISTRO_CAMPANA.json');campaign.update(phase='SCIENTIFIC_OPERATIONAL_AND_DOCUMENTARY_CLOSURE',final_principal=cont['current_principal'],manual=documents['manual'],cleanup={'record':str(P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json'),'sha256':sha(P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json'),'source_record_contains_full_preservation_and_deletion_proof':True},final_delivery_verification=str(P/'control/VERIFICACION_FINAL_EXTERNA_PI01.json'));write(P/'REGISTRO_CAMPANA.json',campaign)
project=read(C/'PROYECTO.json');project['manual_internal_edition']='1.27';project['manual_current_sha256']=documents['manual']['sha256'];write(C/'PROYECTO.json',project)
maincont=read(C/'CONTINUIDAD_DEE_COGNITIVE_2_0.json');maincont['manual_current']=documents['manual'];maincont['last_documentary_update_PI01']=proof['published_utc'];write(C/'CONTINUIDAD_DEE_COGNITIVE_2_0.json',maincont)
render_limits=read(P/'control/BLOQUEO_RENDER_DOCUMENTAL.json');render_limits.update(final_status='RESOLVED',resolution='Outside sandbox, fixed short-path byte-identical copies; both final PDFs produced and checked',final_render_proof=str(D/'RENDERIZADO_FINAL_WORD.json'));write(P/'control/BLOQUEO_RENDER_DOCUMENTAL.json',render_limits)
print(json.dumps({'manual':documents['manual'],'compendium':documents['compendium'],'new_native_ticks':0},ensure_ascii=False,indent=2))
