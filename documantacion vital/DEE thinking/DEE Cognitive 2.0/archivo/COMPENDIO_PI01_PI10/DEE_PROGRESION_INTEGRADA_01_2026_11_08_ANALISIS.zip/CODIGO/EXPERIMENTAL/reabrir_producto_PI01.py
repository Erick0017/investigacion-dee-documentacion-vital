"""Affected operational check only: zero new Native ticks in migrated product."""
from pathlib import Path
import datetime,json,sqlite3,sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from servicio_ensayo import Owner,P
from PROMOVER_PI01 import snapshot_view,compare_native
S=P.parent.parent.parent/'DEE Cognitive 2.0/sistema';LIFE='ECI02_PI01_MAIN'
target=P/'control/REAPERTURA_PRODUCTO_PI01.json'
if target.exists():raise RuntimeError('Product reopening already witnessed; do not repeat')
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
source=snapshot_view(S/'estado/pares_iniciales'/LIFE/'VIDA.deetsnap.gz')
before=read(S/'estado/vidas'/LIFE/'VIDA.json');initial=snapshot_view(S/before['snapshot'])
with Owner(LIFE,'PI01_PRODUCTO',system=S)as owner:
    result=owner.material('PI01_PRODUCTO_ESTADO_0T',{'modo':'eci01-pi01-estado'})
    if result['before_tick']!=735843 or result['after_tick']!=735843:raise ValueError('Unexpected physical advance; preserve reached future')
    environment=result['result']['rows'][0]['external_environment']
    if environment['episode']!=19 or environment['resources']!=17 or environment['uncertain']or environment['in_progress']:raise ValueError('Environmental continuation not coherent')
after=read(S/'estado/vidas'/LIFE/'VIDA.json');final=snapshot_view(S/after['snapshot']);comparison=compare_native(source,final,allow_service=True)
con=sqlite3.connect((S/'estado/servicios_persistentes'/LIFE/'cola.sqlite3').as_uri()+'?mode=ro',uri=True)
try:
    outstanding=con.execute("SELECT id,status FROM requests WHERE status IN('queued','processing','uncertain')").fetchall()
    export_id=read(P/'control/PAR_FINAL_PI01.json')['owner_export_request'];export_status=con.execute('SELECT status FROM requests WHERE id=?',(export_id,)).fetchone()
finally:con.close()
if outstanding or not export_status or export_status[0]!='completed':raise ValueError('Export reconciliation incomplete; never purge or repeat')
proof={'life_id':LIFE,'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_ticks':0,'physical_unchanged':initial['physical']==final['physical'],'pending_reconciled':not outstanding and export_status[0]=='completed','resources_valid':True,'resource_validation':environment,'source_vs_product':comparison,'initial_record_snapshot_sha256':before['snapshot_sha256'],'current_record_snapshot_sha256':after['snapshot_sha256'],'physical':final['physical'],'native_interfaces':final['interfaces'],'native_pending':final['pending_native'],'native_receipts_before':initial['native_receipts'],'native_receipts_after':final['native_receipts'],'native_causal_prefix_before':initial['causal_prefix_sha256'],'native_causal_prefix_after':final['causal_prefix_sha256'],'export_reconciled_without_native_reexecution':export_id,'no_owner_running_after_close':True,'scope':'Product relocation/queue/resource check only; no repeat of scientific panel or new acquisition.'}
target.write_text(json.dumps(proof,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(proof,ensure_ascii=False,indent=2))
