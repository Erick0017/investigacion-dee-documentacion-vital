"""Analiza únicamente el JSON ya registrado; no importa DEE ni avanza ticks."""
from pathlib import Path
import json,hashlib,datetime
P=Path(__file__).resolve().parent.parent
def load(n):return json.loads((P/n).read_text(encoding='utf-8'))
raw=P/'ensayos/PI01_TRAZA_BLOQUEO_INTERVAL.json';outer=load('ensayos/PI01_TRAZA_BLOQUEO_INTERVAL.json')
v=json.loads(outer['result'])['result']['rows'][0]
old=json.loads(load('ensayos/PI01_DEV_R02_CALIBRATE.json')['result'])['result']['rows'][0]['rows'][1]
at=lambda rows,t:next(r for r in rows if r['tick']==t)
frames=[]
for f in v['frames']:
 guard=next(o for o in f['roi']if o['site']==[47,49,45])
 frames.append({'tick':f['tick'],'relative_to_decision':f['relative_to_decision'],'center':f['center'],
 'moving_ray_neighborhood':f['predicted_ray_neighborhood'],'guard_47_49_45':guard,
 'nonzero_roi_records':[o for o in f['roi']if int(o['raw'])],
 'global_physical_if_recorded':f.get('global_physical')})
comparisons=[]
for t,new in [(v['decision']+2,v['first_decision_plus2']['center'])]+[(f['tick'],f['center'])for f in v['frames']if f['tick']in(v['feedback'],v['feedback']+1)]:
 previous=at(old['frames'],t)['center'];comparisons.append({'tick':t,'all_observation_fields_equal':new==previous,'raw_equal':new['raw']==previous['raw'],'clock_equal':new['clock']==previous['clock'],'previous':previous,'new':new})
assert all(x['all_observation_fields_equal']for x in comparisons)
snapshots=[]
for n in v['snapshots']:
 p=Path(n);assert p.is_file();snapshots.append({'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'scope':'Full native checkpoint; owner SQLite and transport remain with diagnostic clone'})
result={'schema':'PI01.blockage_trace.passive_recount.v1','recount_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'diagnostic_execution_was_new':True,'recount_has_new_ticks':False,'life':'ECI02_PI01_TRAZA_BLOQUEO','N':67,'initial_tick':727225,'last_tick':727496,
 'source':str(raw),'source_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'decision':v['decision'],'feedback':v['feedback'],
 'sensor_receipt':v['sensor_receipt'],'normalizer_receipt':v['normalizer_receipt'],'receptor_comparison_with_original_R02':comparisons,
 'snapshots':snapshots,'frames':frames,
 'demonstrated':'A charge24 directionZ carrier is observed at47,49,44 in T727486; target47,49,45 already has semantic4 RAW2^62,state0. AtT727487 that target keeps exactly its RAW and no charge24 child appears on the predicted ray. The normalizer is admitted and arrives alone atD atT727495; receptor observations match originalR02 at three common times.',
 'mechanism_attribution':'Official kernel_v27.cpp L248 preserves every semantic4 target before routing; hence its zero state does not open this target to the incoming proposal. Source-source collision is not the observed mechanism at this target.',
 'not_demonstrated':['No selective removal control was authorized here; no repair performed.','No claim of global destruction of all information or all inherited Cognitive functions.','No unique genealogy assigned to unrelated carriers by matching charge.','Full-state equality with previous R02 at this horizon was not available; equality is only receptor observations/receipts at shared times.']}
(P/'ensayos/TRAZA_BLOQUEO_RESUMEN.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'N':result['N'],'last_tick':result['last_tick'],'comparison_all_equal':all(x['all_observation_fields_equal']for x in comparisons),'snapshots':snapshots,'first_lost_expected_ray_tick':727487},ensure_ascii=False,indent=2))
