"""Append a scientific stage to the existing register; no DEE imports."""
from pathlib import Path
import datetime,hashlib,json,os
P=Path(__file__).resolve().parent.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def atomic(p,x):
 t=p.with_suffix('.pi01_tmp');t.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');os.replace(t,p)
regpath=P.parent/'REVISION_TRANSVERSAL.json';reg=read(regpath);campaign=read(P/'REGISTRO_CAMPANA.json')
stages=[]
for filename in ['RESUMEN_DESARROLLO_R04.json','RESUMEN_PI01_RES_REAL.json','RESUMEN_PI01_RES_OMIT.json','RESUMEN_PI01_RES_NULLED.json','RESUMEN_CONSERVACION_R04.json','REAPERTURA_CONTINUACION_R04.json']:
 p=P/'ensayos'/filename
 if not p.exists():continue
 v=read(p);rows=v.get('rows',[])
 stages.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'life':v.get('life'),'role':v.get('scope',filename),'opportunities':len(rows),'actual_resources':sum(x.get('accepted',x.get('effect',{}).get('accepted',False))for x in rows),'concordant_retention_responses':sum(x.get('concordant',False)for x in rows),'through_tick':rows[-1].get('after')if rows else v.get('after_tick'),'does_not_represent_promotion':True})
block=reg.setdefault('progression_integrated_PI01',{});block['stage_results']=stages;block['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();block['scientific_stage']='RESERVED_EVALUATION_AND_RETENTION; adoption must be evidenced separately';atomic(regpath,reg)
campaign['stage_results']=stages;campaign['new_ticks_so_far']='See per-life exact records; no combined individual tick or replica count';campaign['updated_utc']=block['updated_utc'];atomic(P/'REGISTRO_CAMPANA.json',campaign)
print(json.dumps(stages,ensure_ascii=False))
