from pathlib import Path
import json
P=Path(__file__).resolve().parent.parent
q=json.loads((P/'ensayos/PI01_DEV_R02_CALIBRATE.json').read_text(encoding='utf-8'));r=json.loads(q['result']);v=r['result']['rows'][0];rows=[]
for g in v['rows']:
 frames=[]
 for x in g.get('frames',[]):
  o=x['center'];frames.append({'tick':x['tick'],'state':o['state'],'s_reg':o['s_reg'],'direction':o['direction'],'semantic':o['semantic'],'raw':o['raw'],'clock':o['clock']})
 rows.append({'kind':g.get('kind','collision'),'episode':g.get('episode'),'decision':g.get('decision'),'feedback':g.get('feedback'),'sensor':g.get('sensor_receipt'),'normalizer':g.get('normalizer_receipt'),'frames':frames,'nonzero_context':[{'tick':x['tick'],'sites':[{k:o[k]for k in('site','state','s_reg','direction','clock')}for o in x['roi']if int(o['raw'])!=0]}for x in g.get('frames',[])]})
out={'scope':'Passive recount of development observation windows, not functional validation.','before_tick':r['before_tick'],'after_tick':r['after_tick'],'rows':rows}
(P/'ensayos/RESUMEN_CALIBRACION_R02.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2))
