from pathlib import Path
import hashlib,json
P=Path(__file__).resolve().parent.parent;src=P/'codigo/progresion_integrada_01_R01.py';t=src.read_text(encoding='utf-8')
t=t.replace("VERSION='PI01.legal_returning_access.R01'","VERSION='PI01.legal_returning_access.R02'")
t=t.replace(' a.run_until(at)\n',' a.run_until(at+1)\n')
needle='def calibrate(a,count):\n'
extra='''def complete_preparation(a):
 m=get(a);identifier=int(m['seed_receipt']['id']);before=physical(a.world);old=exact_receipt(a.world.runtime.receipt(identifier))
 if old['status']!='scheduled':raise ValueError('Only the recorded still-scheduled seed may be completed, never resubmit')
 a.run_until(max(int(a.tick),int(m['seed_requested_tick']))+1)
 new=exact_receipt(a.world.runtime.receipt(identifier));m['seed_receipt']=new;m['seed_effective_tick']=new.get('effective_tick');m['preparation_completed_boundary']=int(a.tick);m['instrument_correction']='R01 checked before input boundary was processed; no seed rejection or reexecution occurred.';save(a,m)
 if new['status']!='applied':raise ValueError('Seed has a terminal non-applied status; preserve future')
 return {'before':before,'after':physical(a.world),'previous_receipt':old,'current_receipt':new,'origin':obs(a,D),'next':obs(a,add(D,A)),'same_material_receipt_no_resubmit':True,'state':state(a)}

'''
assert needle in t;t=t.replace(needle,extra+needle)
t=t.replace("if mode in('eci01-pi01-preparar','eci01-pi01-estado'):","if mode in('eci01-pi01-preparar','eci01-pi01-estado','eci01-pi01-completar-preparacion'):")
t=t.replace(" if row['modo']=='eci01-pi01-estado':return state(a)"," if row['modo']=='eci01-pi01-estado':return state(a)\n if row['modo']=='eci01-pi01-completar-preparacion':return complete_preparation(a)")
target=P/'codigo/progresion_integrada_01_R02.py';target.write_text(t,encoding='utf-8');(P/'estados/candidato/sistema/capacidades/progresion_integrada_01.py').write_text(t,encoding='utf-8')
(P/'control/REVISION_R02.json').write_text(json.dumps({'version':'PI01.R02','change':'Input scheduled at t is applied when boundary t is processed by run_until(t+1); do not mistake scheduled for rejection. Same pending event continues. No reader evaluation/target changed.','source':str(target),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'original_failed_future':'ECI02_PI01_DESARROLLO_R01 T727227','new_native_ticks_by_edit':0},ensure_ascii=False,indent=2),encoding='utf-8')
print('R02 deployed; pending event will not be resubmitted.')
