from pathlib import Path
import json,hashlib,shutil
P=Path(__file__).resolve().parent.parent;S=P/'estados/candidato/sistema'
backup=P/'codigo/revisiones/R02_EJECUTADA';backup.mkdir(parents=True,exist_ok=True)
for rel in ['capacidades/progresion_integrada_01.py','app/cola_local.py','app/mundo_genesis_apd05.py']:
 q=backup/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(S/rel,q)
t=(P/'codigo/progresion_integrada_01_R02.py').read_text(encoding='utf-8')
t=t.replace("VERSION='PI01.legal_returning_access.R02'","VERSION='PI01.legal_returning_access.R03'").replace('N=67;D=(47,49,53)','N=67;D=(41,43,47)')
t=t.replace(" prefix='PI01.R01.'"," prefix='PI01.R03.'")
t=t.replace('def roi(a,radius=3):\n','def roi(a,radius=3):\n D=tuple(get(a)[\'origin\'])\n')
t=t.replace("'center':obs(a,D),'scope'","'center':obs(a,tuple(get(a)['origin'])),'scope'")
t=t.replace(' m=get(a)\n if m[\'uncertain\']'," m=get(a);D=tuple(m['origin'])\n if m['uncertain']")
t=t.replace('roi(a,2)','roi(a,3)')
needle=" prefix='PI01.R03.'"
extra=""" rays=[]
 for v in [A,B,ACTION[0],ACTION[1],NORMALIZER]:
  for k in range(N):
   o=obs(a,add(D,v,k))
   if int(o['raw'])!=0:rays.append(o)
 if rays:raise ValueError('Prepared return path intersects existing causal RAW; no cleanup')
"""
assert needle in t;t=t.replace(needle,extra+needle)
needle="  normal=submit_arrival(a,m['prefix']+'normalizer',3,feedback)"
extra="""  decision_observation=next(x['center']for x in frames if x['tick']==decision)
  direction=tuple(decision_observation['direction']);route=next((k for k,v in ACTION.items()if direction==v),None) if decision_observation['state']>0 and decision_observation['semantic']==1 else None
  negative=None
  if e==1 and route is not None:negative=submit_arrival(a,m['prefix']+'penalty'+str(route),5,feedback)
"""
assert needle in t;t=t.replace(needle,extra+needle)
t=t.replace("'normalizer_receipt':rr(a,normal),'frames':frames}","'normalizer_receipt':rr(a,normal),'calibration_negative_receipt':None if negative is None else rr(a,negative),'fixed_read_route':route,'decision_observation':decision_observation,'frames':frames}")
# One no-tick observer check on the representative assembled world.
needle=" m['calibration']={'completed':True"
extra=""" passive_before=physical(a.world);entries_before=dict(a.world.runtime.snapshot_metadata_entries);tick_before=int(a.tick);roi(a,3)
 passive_unchanged=physical(a.world)==passive_before and dict(a.world.runtime.snapshot_metadata_entries)==entries_before and int(a.tick)==tick_before
 if not passive_unchanged:raise RuntimeError('Observer changed physical state or metadata')
"""
assert needle in t;t=t.replace(needle,extra+needle)
t=t.replace("'rows':[{'kind':'baseline_return','frames':base}]+rows,'state'","'passive_observer_unchanged':passive_unchanged,'rows':[{'kind':'baseline_return','frames':base}]+rows,'state'")
q=P/'codigo/progresion_integrada_01_R03.py';q.write_text(t,encoding='utf-8');(S/'capacidades/progresion_integrada_01.py').write_text(t,encoding='utf-8')
(P/'control/REVISION_R03.json').write_text(json.dumps({'revision':'R03','source':str(q),'sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'origin':[41,43,47],'initial_map':'ensayos/MAPA_RUTAS_P0.json','previous_future_preserved':'ECI02_PI01_DESARROLLO_R01 T727631','new_ticks_by_edit':0},indent=2),encoding='utf-8')
print('R03 deployed to candidate only.')
