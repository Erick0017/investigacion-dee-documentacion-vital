"""Supervisor de dos peticiones de desarrollo por el propietario existente."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;S=P/'estados/candidato/sistema';LIFE='ECI02_PI01_DESARROLLO_R01'
sys.path.insert(0,str(S));from app.cola_local import QueueDB
PY=R/'DEE Cognitive 2.0/motor/python313/python.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def append(x):
 with(P/'ENSAYOS.jsonl').open('a',encoding='utf-8')as f:f.write(json.dumps(x,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
folder=S/'estado/servicios_persistentes'/LIFE;q=QueueDB(folder/'cola.sqlite3')
out=(P/'ensayos/OWNER_DEV_R01.stdout.txt').open('w',encoding='utf-8');err=(P/'ensayos/OWNER_DEV_R01.stderr.txt').open('w',encoding='utf-8')
cmd=[str(PY),'-I','-B','-X','utf8',str(S/'gestionar.py'),'--system-root',str(S),'mente-unificada-iniciar','--vida',LIFE,'--backend','mente_unificada','--eci01','--pausado','--intervalo','3600','--guardar-cada','3600','--max-segundos','1200']
start=time.monotonic();proc=subprocess.Popen(cmd,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW)
def wait(identifier,limit=180):
 stop=time.monotonic()+limit
 while time.monotonic()<stop:
  row=q.get(identifier)
  if row and row['status']in('completed','rejected_invalid','uncertain','failed_preserved'):return row
  if proc.poll()is not None:raise RuntimeError('Owner exited: '+(P/'ensayos/OWNER_DEV_R01.stderr.txt').read_text(encoding='utf-8'))
  time.sleep(.05)
 raise TimeoutError('Request preserved; never retry with a new ID: '+identifier)
def control(op,identifier):
 result=q.put(identifier,{'operacion':op});assert not result['admission'].startswith('rejected'),result
 row=wait(identifier)
 if row['status']!='completed':raise RuntimeError(str(row))
 return row
def material(identifier,literal):
 admission=q.put(identifier,{'operacion':'sesion','situaciones':[literal],'actuador':'closed','retorno':'real'})
 if admission['admission'].startswith('rejected'):raise RuntimeError(str(admission))
 control('reanudar',identifier+'_resume');row=wait(identifier);control('pausar',identifier+'_pause')
 path=P/'ensayos'/(identifier+'.json');path.write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
 append({'id':identifier,'life':LIFE,'role':'DEVELOPMENT_NOT_RESERVED','literal':literal,'status':row['status'],'record':str(path.relative_to(P)),'sha256':sha(path),'host_elapsed_seconds':time.monotonic()-start})
 if row['status']!='completed':raise RuntimeError('Reached future preserved: '+str(row.get('error')))
 result=json.loads(row['result']);value=result['result']['rows'][0]
 print(json.dumps({'id':identifier,'status':row['status'],'before_tick':result['before_tick'],'after_tick':result['after_tick'],'host_elapsed_seconds':time.monotonic()-start},ensure_ascii=False),flush=True)
 return value
try:
 deadline=time.monotonic()+60
 while time.monotonic()<deadline:
  m=q.get_meta('owner')or{}
  if m.get('pid')==proc.pid and m.get('running'):break
  if proc.poll()is not None:raise RuntimeError('Owner open failed')
  time.sleep(.1)
 else:raise TimeoutError('Owner did not publish readiness')
 v=material('PI01_DEV_R01_PREPARE',{'modo':'eci01-pi01-preparar'})
 v=material('PI01_DEV_R01_CALIBRATE',{'modo':'eci01-pi01-calibrar','circuitos':2})
 summary=[]
 for group in v['rows']:
  frames=group.get('frames',[])
  summary.append({'episode':group.get('episode','baseline'),'sensor_receipt':group.get('sensor_receipt'),'normalizer_receipt':group.get('normalizer_receipt'),'frames':[{'tick':x['tick'],'center':x['center']}for x in frames]})
 (P/'ensayos/RESUMEN_CALIBRACION_R01.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(summary,ensure_ascii=False),flush=True)
finally:
 if proc.poll()is None:
  try:control('detener','PI01_DEV_R01_STOP')
  except Exception as e:append({'own_process_close_problem':str(e),'pid':proc.pid})
  try:proc.wait(timeout=30)
  except subprocess.TimeoutExpired:append({'own_process_still_running':proc.pid,'no_forced_termination':True})
 out.close();err.close()
 print(json.dumps({'owner_exit_code':proc.poll(),'pid':proc.pid,'elapsed_seconds':time.monotonic()-start}),flush=True)
