"""Supervisor reutilizable del gestor existente; no decide acciones de DEE."""
from pathlib import Path
import datetime as dt,hashlib,json,os,subprocess,sys,time,uuid
P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;SYSTEM=P/'estados/candidato/sistema';PY=R/'DEE Cognitive 2.0/motor/python313/python.exe'
sys.path.insert(0,str(SYSTEM));from app.cola_local import QueueDB
def append(value):
 with(P/'ENSAYOS.jsonl').open('a',encoding='utf-8')as f:f.write(json.dumps(value,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
class Owner:
 def __init__(self,life,tag,system=SYSTEM):self.life=life;self.tag=tag;self.system=Path(system);self.runid=tag+'_'+uuid.uuid4().hex[:8];self.proc=None
 def __enter__(self):
  self.folder=self.system/'estado/servicios_persistentes'/self.life;self.q=QueueDB(self.folder/'cola.sqlite3')
  self.stdout=(P/'ensayos'/(self.runid+'.stdout.txt')).open('w',encoding='utf-8');self.stderr=(P/'ensayos'/(self.runid+'.stderr.txt')).open('w',encoding='utf-8')
  self.cmd=[str(PY),'-I','-B','-X','utf8',str(self.system/'gestionar.py'),'--system-root',str(self.system),'mente-unificada-iniciar','--vida',self.life,'--backend','mente_unificada','--eci01','--pausado','--intervalo','60','--guardar-cada','3600','--max-segundos','7200']
  self.proc=subprocess.Popen(self.cmd,stdout=self.stdout,stderr=self.stderr,creationflags=subprocess.CREATE_NO_WINDOW);self.start=time.monotonic()
  deadline=time.monotonic()+60
  while time.monotonic()<deadline:
   self.initial=self.q.get_meta('owner')or{}
   if self.initial.get('pid')==self.proc.pid and self.initial.get('running'):
    append({'kind':'OWNER_STARTED','run':self.runid,'life':self.life,'pid':self.proc.pid,'command':self.cmd,'initial_status':self.initial});return self
   if self.proc.poll()is not None:raise RuntimeError('Owner exited; see '+self.runid+'.stdout/stderr')
   time.sleep(.05)
  raise TimeoutError('Owner readiness not published')
 def wait(self,identifier,limit=240):
  end=time.monotonic()+limit
  while time.monotonic()<end:
   x=self.q.get(identifier)
   if x and x['status']in('completed','failed_preserved','uncertain','rejected_invalid'):return x
   if self.proc.poll()is not None:raise RuntimeError('Owner exited with pending request '+identifier)
   time.sleep(.05)
  raise TimeoutError('Uncertain request remains under SAME id; never auto-resubmit: '+identifier)
 def control(self,op):
  identifier=self.runid+'_'+op+'_'+uuid.uuid4().hex[:8];x=self.q.put(identifier,{'operacion':op})
  if x['admission'].startswith('rejected'):raise RuntimeError(str(x))
  row=self.wait(identifier)
  if row['status']!='completed':raise RuntimeError(str(row))
  return row
 def material(self,identifier,literal,*,feedback='real',actuator='closed',allow_failure=False):
  if self.q.get(identifier)is not None:raise RuntimeError('Existing experiment ID; do not repeat: '+identifier)
  payload={'operacion':'sesion','situaciones':[literal],'actuador':actuator,'retorno':feedback};ad=self.q.put(identifier,payload)
  if ad['admission'].startswith('rejected'):raise RuntimeError(str(ad))
  self.control('reanudar');row=self.wait(identifier);self.control('pausar')
  file=P/'ensayos'/(identifier+'.json');file.write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8')
  result=json.loads(row['result'])if row.get('result')else None
  entry={'kind':'MATERIAL_REQUEST','id':identifier,'life':self.life,'run':self.runid,'literal':literal,'return':feedback,'actuator':actuator,'status':row['status'],'before_tick':None if result is None else result['before_tick'],'after_tick':None if result is None else result['after_tick'],'record':str(file.relative_to(P)),'sha256':sha(file),'host_elapsed_seconds':time.monotonic()-self.start}
  append(entry);print(json.dumps(entry,ensure_ascii=False),flush=True)
  if row['status']!='completed'and not allow_failure:raise RuntimeError('Future preserved: '+str(row.get('error')))
  return result if result is not None else row
 def __exit__(self,typ,value,tb):
  if self.proc is not None and self.proc.poll()is None:
   try:self.control('detener');self.proc.wait(timeout=60)
   except Exception as e:append({'kind':'OWN_CLOSE_PROBLEM','run':self.runid,'pid':self.proc.pid,'error':str(e),'process_not_forcibly_stopped':True})
  final=self.q.get_meta('owner');append({'kind':'OWNER_CLOSED','run':self.runid,'life':self.life,'pid':self.proc.pid,'exit_code':self.proc.poll(),'final_status':final,'elapsed_seconds':time.monotonic()-self.start})
  self.stdout.close();self.stderr.close()
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--vida',required=True);p.add_argument('--id',required=True);p.add_argument('--literal',required=True);v=p.parse_args()
 with Owner(v.vida,v.id)as o:o.material(v.id,json.loads(v.literal))
