"""Sincronización documental PI01 tras adopción ya realizada. Cero imports DEE."""
from pathlib import Path
import ast,copy,csv,datetime,hashlib,json,os,shutil

P=Path(__file__).resolve().parent.parent;R=P.parent.parent.parent;C=R/'DEE Cognitive 2.0';S=C/'sistema'
LIFE='ECI02_PI01_MAIN';PARENT='ECI02_OPERATIVA_PRINCIPAL_01';BACK=P/'control/ADOPCION_PI01_RESPALDO'
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+'.sync_pi01.tmp')
 with tmp.open('x',encoding='utf8')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def preserve(p,target):
 p=Path(p);target=Path(target);target.parent.mkdir(parents=True,exist_ok=True)
 if target.exists():return {'path':str(target),'sha256':sha(target),'already_preserved':True}
 with p.open('rb')as a,target.open('xb')as b:shutil.copyfileobj(a,b)
 if sha(p)!=sha(target):raise ValueError('Respaldo no íntegro')
 return {'path':str(target),'sha256':sha(target),'already_preserved':False}
def file_ref(p,role=None,localizer=None):
 p=Path(p);r={'path':str(p.resolve()),'bytes':p.stat().st_size,'sha256':sha(p)}
 if role:r['role']=role
 if localizer:r['localizer']=localizer
 return r

if(P/'CONTINUIDAD_PI01.json').exists():
 raise RuntimeError('Sincronización ya ejecutada. No repetir ni degradar una posterior publicación del Manual; continuar desde los comprobantes existentes.')
stamp=now();adopt=read(P/'control/ADOPCION_PRODUCTO_PI01.json');proof=read(P/'control/REAPERTURA_PRODUCTO_PI01.json')
card_path=S/'estado/vidas'/LIFE/'VIDA.json';card=read(card_path);card_sha=sha(card_path);snap=S/card['snapshot']
active=read(S/'estado/ACTIVO.json');project=read(C/'PROYECTO.json');selection=read(S/'estado/genesis/SELECCION_PERSONAL.json')
if adopt['phase']!='COMMITTED'or active['life_id']!=LIFE or project['selected_life']!=LIFE or selection['life_id']!=LIFE:raise ValueError('Adopción/selecciones aún no concordantes')
if card['physical']['tick']!=735843 or card['snapshot_sha256']!=sha(snap)or active['snapshot_sha256']!=card['snapshot_sha256']:raise ValueError('Checkpoint vigente distinto del adoptado')
if not(proof['new_ticks']==0 and proof['physical_unchanged']and proof['pending_reconciled']and proof['resources_valid']):raise ValueError('Comprobante de reapertura insuficiente')
old=read(S/'estado/vidas'/PARENT/'VIDA.json')
if old['physical']['tick']!=727225 or old['snapshot_sha256']!='46e275be49a1e8df9b823e3c533156d91fa66a79477872a125efabfa350470d4':raise ValueError('El padre protegido cambió')
migration=card['PI01_migration'];panel=read(P/'ensayos/RESUMEN_CONSERVACION_R04.json');validation=read(P/'control/VALIDACION_ADOPCION_R04.json')
if len(panel['rows'])!=12 or sum(x['concordant']for x in panel['rows'])!=12:raise ValueError('Panel no concuerda con fuente')
physical_parent={'life_id':PARENT,'N':67,'tick':727225,'snapshot_sha256':old['snapshot_sha256'],'role':'PARENT_PHYSICAL_HISTORY_PROTECTED_NOT_CURRENT_PRINCIPAL'}
import_parent={**card['parent'],'role':'TRANSPORT_IMPORT_SNAPSHOT_AT735843_NOT_THE_ORIGINAL_PHYSICAL_PARENT'}
current={'life_id':LIFE,'world_id':card['world_id'],'profile':card['profile'],'role':'UNICO_PRINCIPAL_OPERATIVO_ADOPTADO','physical':card['physical'],
 'physical_parent':physical_parent,'transport_import_parent':import_parent,
 'snapshot':{'path_relative_to_product':'sistema/'+card['snapshot'],'bytes':snap.stat().st_size,'sha256':card['snapshot_sha256']},
 'record':{'path_relative_to_product':'sistema/estado/vidas/'+LIFE+'/VIDA.json','sha256':card_sha},
 'proof_sources':[str(P/'control/ADOPCION_PRODUCTO_PI01.json'),str(P/'control/REAPERTURA_PRODUCTO_PI01.json'),str(P/'ensayos/RESUMEN_CONSERVACION_R04.json')],
 'scope':'Localizador actualizado tras promoción real. Panel funcional12/12hastaT735466; luego oportunidad19ycontinuaciónT735843. Migración/reapertura0ticks no son nuevos aprendizajes ni una repetición del panel.'}

# Preserve the exact eight pre-adoption baselines already made by PROMOVER.
tree=ast.parse((P/'codigo/PROMOVER_PI01.py').read_text('utf8'))
baselines=next(ast.literal_eval(x.value)for x in tree.body if isinstance(x,ast.Assign)and any(isinstance(t,ast.Name)and t.id=='BASELINE'for t in x.targets))
baseline_check=[]
for rel,h in baselines.items():
 p=BACK/rel
 if not p.is_file()or sha(p)!=h:raise ValueError('Falta baseline intacto: '+rel)
 baseline_check.append({'relative':rel,'path':str(p),'sha256':h})

contract_files=['ARITMETICA_DIRECTA_ECI02_P0.json','ACCESO_TEMPRANO_P0_ECI02.json','SERVICIO_PERSISTENTE_MU01.json']
contract_changes=[]
for name in contract_files:
 path=S/'contratos'/name;prior=read(path);before=sha(path);backup=preserve(path,BACK/'sistema/contratos'/name)
 data=copy.deepcopy(prior)
 key='current_operational_option'if name=='SERVICIO_PERSISTENTE_MU01.json'else'current_life'
 if data.get(key,{}).get('life_id')!=LIFE:
  data.setdefault('historical_reference_before_PI01_COMMITTED',copy.deepcopy(data.get(key)))
 if key=='current_life':data[key]=copy.deepcopy(current)
 else:data[key]={'life_id':LIFE,'tick':735843,'snapshot':card['snapshot'],'snapshot_sha256':card['snapshot_sha256'],'global_ACTIVO_promoted':True,
  'complete_pair_required':True,'selection_scope':'Current saved principal; cached stop/reopen evidence, not an instantaneous running observation.',
  'source_current_selection':'../estado/ACTIVO.json','updated_by':'PI01.COMMITTED.document_sync','physical_parent':physical_parent,'transport_import_parent':import_parent,
  'worker_directory':'estado/servicios_locales/'+LIFE,'paired_transport_directory':'estado/servicios_persistentes/'+LIFE}
 data['PI01_conservation']={'life_id':LIFE,'current_saved_tick':735843,'panel_from_tick':734101,'panel_through_tick':735466,'panel_source':str(P/'ensayos/RESUMEN_CONSERVACION_R04.json'),
  'recorded_uses':[{'label':x['label'],'response':x['response'],'tick':x['after']}for x in panel['rows']if(name.startswith('ARITMETICA')and x['label'].startswith('number'))or(name.startswith('ACCESO')and x['label'].startswith('FI'))],
  'zero_tick_product_reopening':str(P/'control/REAPERTURA_PRODUCTO_PI01.json'),'not_a_new_validation_of_all_historical_domains':True}
 if name=='SERVICIO_PERSISTENTE_MU01.json':
  data['PI01_conservation']['recorded_uses']=[{'kind':'Complete-pair migration and product owner reopening','new_native_ticks':0,'episode':19,'resources':17,'resource_files':36,'processing_export_reconciled':proof['export_reconciled_without_native_reexecution']}]
  data['optional_extensions_PI01']={'owner':'GenesisNativeWorld via existing --eci01 opt-in','modes':['eci01-pi01-estado','eci01-pi01-paso'],'contract':'PROGRESION_INTEGRADA_01_R04.json',
   'selection_scope':'PI01 acquired route updates concern this life/task; historical service controls and old NoP2/R2 limits retain their original domain.'}
 data['current_source_SHA256_PI01']={rel:sha(C/rel)for rel in('sistema/app/cola_local.py','sistema/app/mundo_genesis_apd05.py')}
 data['reference_updated_by']='PROGRESION_INTEGRADA_01.COMMITTED.document_sync';data['historical_evidence_unchanged']=True;data['software_version']='1.1.0';data['engine_revision_unchanged']='DEE thinking4.5.0 / Universev27'
 write(path,data);contract_changes.append({'path':str(path),'before_sha256':before,'after_sha256':sha(path),'preserved':backup})

# Preserve each legacy capability's original life evidence, adding only a scoped
# conservation witness in the one actually tested descendant.
catalog_path=S/'capacidades/CATALOGO_CAPACIDADES.json';catalog=read(catalog_path)
preserve(catalog_path,BACK/'sistema/capacidades/CATALOGO_CAPACIDADES_APRES_ADOPTION_PRE_SYNC.json')
scope_by_id={
 'ECI02_ARITMETICA_NATIVA_DIRECTA_P0':['number13','number8'],
 'ECI02_ACCESO_TEMPRANO_P0':['FIplus','FIminus','FIzero'],
 'APD04_TALLER_SITUADO':['luma','nara','clasifica','suma','luma_after'],
 'ASISTENTE_PROPOSITO_01':['luma','nara','clasifica','suma'],
 'MENTE_ACUMULATIVA_R02':['alfa','alfa_after'],
 'SERVICIO_PERSISTENTE_MU01':[],
 'FI01_PERCEPCION_CRUDA':['FIplus','FIminus','FIzero'],
 'MENTE_UNIFICADA_01':['alfa','alfa_after','FIplus','FIminus','FIzero']}
for entry in catalog['entries']:
 if entry.get('id')not in scope_by_id:continue
 labels=scope_by_id[entry['id']]
 entry['conservation_PI01']={'life_id':LIFE,'physical_cut':735843,'panel_interval':[734101,735466],
  'checked_subset':[{'label':x['label'],'response':x['response'],'tick':x['after']}for x in panel['rows']if x['label']in labels],
  'source':str(P/'ensayos/RESUMEN_CONSERVACION_R04.json'),'zero_tick_full_transport_reopening':str(P/'control/REAPERTURA_PRODUCTO_PI01.json'),
  'scope':'Only the listed uses, in one continuing descendant. Not all historical functions, tokens, contexts, trials or branches; historical validated_lives remain unchanged.',
  'old_results_not_reassigned':True}
catalog['version']='1.1.0';catalog['PI01_current_principal']={'life_id':LIFE,'N':67,'tick':735843,'snapshot_sha256':card['snapshot_sha256'],'engine_change':False,'updated_utc':stamp}
write(catalog_path,catalog)

coverage=[]
for path in sorted((P/'lecturas').glob('*/COBERTURA*.json')):
 data=read(path);item=file_ref(path,'Scientific reading coverage, not execution')
 item['limits']=data.get('limits',data.get('gaps',[]))
 for key in('principal_reports_fully_read','new_complete_unique_texts','new_partial_unique_texts','unique_contents_read_whole','archives_indexed','read_complete','capsule_all_sources_read','body_nonempty_read','tables','graphics','no_render_or_visual_review'):
  if key in data:item[key]=data[key]
 coverage.append(item)

clean_path=P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json';clean=read(clean_path)
clean_summary={k:clean[k]for k in('exact_target','target_removed','files_removed','logical_bytes_removed_from_tree','disk_free_reclaimed_measured','original_operational_states_touched','Native_ticks','finished_utc')}
clean_summary['historical_zip']=clean['historical_zip'];clean_summary['unique_files_preserved']=len(clean['preserved_unique_files']);clean_summary['evidence']=file_ref(clean_path)
limits=list(validation['limits'])+['The18+18+18controls are deterministic related branches; not independent replications.','The12/12panel endedT735466; it is not a fresh12-question panel after the final0tick migration.','Social communication, autonomous opportunity initiation, self-generated plans and arbitrary vocabulary were not newly tested here.','The six-hour wall limit was exceeded; see control/INCIDENCIA_HORARIA.json. No clock reset; waiting is not cognitive age.']
metrics={k:validation['metrics'][k]for k in('REAL','OMIT','NULLED')}
manual_path=C/project['manual_current'];manual={'path':str(manual_path),'internal_edition_last_confirmed':'1.26','sha256_at_sync':sha(manual_path),
 'target_edition':'1.27','target_publication_status':'PENDIENTE_MAR_EDICION_RENDER_Y_PUBLICACION','scope':'This synchronization does not edit or certify a new Word. Retain1.26until actual publication proof.'}
progression={'status':'COMMITTED','operational_status':'ONE_MAIN_ADOPTED','scientific_stage':'RESERVED_EVALUATION_RETENTION_AND_CONTINUATION_CLOSED',
 'current_principal':current,'physical_parent':physical_parent,'transport_import_parent':import_parent,'adoption':file_ref(P/'control/ADOPCION_PRODUCTO_PI01.json'),
 'decision':file_ref(P/'control/DECISION_PROMOCION_PI01.json'),'product_reopening':file_ref(P/'control/REAPERTURA_PRODUCTO_PI01.json'),
 'metrics':metrics,'retention':{'concordant':12,'solicited':12,'through_tick':735466,'native_inputs_requested':929,'native_inputs_applied':929,'meaning':'12first functional responses;929legal inputevents supporting the panel, not929concepts or independent cognition tests.'},
 'continuation':{'episode':18,'same_life':True,'from_tick':735466,'through_tick':735843,'native_route':0,'access':'MA_alfa','response':-1,'new_actual_resource':1,'total_resources':17},
 'source_coverage':coverage,'coverage_scope':'Readability and completion levels remain per source. No total corpus or visual-review claim; block counts are not summed as unique sources across blocks.',
 'negatives':{'R01_R02':'Development/diagnostic futures preserved; initial state0SEM4 ray interference and admission boundary timing were not hidden.','R03':'Legal developed selector used acquired valence; FI nominal overlap required separately declared R04P0geometry.','reserved_main_errors':[6,13],'reserved_omit_errors':[6,7,8,9,10,11],'nulled_resources':0,
 'historical_ECI02_provider_failure':'Preserved and not repaired or reattributed by PI01.','limits':limits},
 'genealogy':{'physical_parent':physical_parent,'actual_life':LIFE,'source_closed_cut':735843,'import_parent':import_parent,'provenance_card':str(S/'estado/vidas'/LIFE/'PROCEDENCIA_PI01/VIDA_FUENTE.json'),'provenance_history':str(S/'estado/vidas'/LIFE/'PROCEDENCIA_PI01/HISTORIA_FUENTE.jsonl'),'no_branch_memory_merge':True},
 'cleanup':clean_summary,'manual':manual,'package':{'status':'EN_PREPARACION','limit_bytes':15000000,'not_an_operational_backup':True},'updated_utc':stamp,
 'new_ticks_in_this_document_sync':0,'no_operational_promotion_yet':False}

registry_path=P/'REGISTRO_CAMPANA.json';registry=read(registry_path);registry_hash=sha(registry_path)
preserve(registry_path,P/'control/REGISTRO_CAMPANA_PRE_SINCRONIA_COMMITTED.json')
registry['phase']='COMMITTED_DOCUMENTARY_CLOSURE_AND_PACKAGE';registry['updated_utc']=stamp
registry['principal_before_campaign']={'id':PARENT,'N':67,'T':727225,'snapshot_sha256':old['snapshot_sha256'],'preserved_protected':True}
registry['current_principal']={'id':LIFE,'N':67,'T':735843,'snapshot_sha256':card['snapshot_sha256'],'selected_by':['ACTIVO','PROYECTO','SELECCION_PERSONAL'],'role':'UNICO_PRINCIPAL_OPERATIVO'}
registry['physical_parent']=physical_parent;registry['transport_import_parent']=import_parent;registry['closed_stage_results']=metrics;registry['adoption']=progression['adoption']
registry['zero_tick_migration_and_product_reopening']=progression['product_reopening'];registry['retention_panel']=progression['retention'];registry['same_life_continuation']=progression['continuation'];registry['manual_current']=manual
registry['cleanup_executed']=clean_summary;registry['wall_time_incidence']=file_ref(P/'control/INCIDENCIA_HORARIA.json');registry['source_coverage']=coverage
registry['historical_initial_record_kept_under_record']=True;registry['new_ticks_in_this_document_sync']=0
if sha(registry_path)!=registry_hash:raise ValueError('Registro cambió concurrentemente; no sobrescribir')
write(registry_path,registry)

revision_path=P.parent/'REVISION_TRANSVERSAL.json';revision_hash=sha(revision_path);revision=read(revision_path)
preserve(revision_path,P/'control/REVISION_TRANSVERSAL_PRE_PI01_COMMITTED.json')
revision.setdefault('current_operation_before_PI01_COMMITTED',revision.get('current_operation'));revision.setdefault('resume_before_PI01_COMMITTED',copy.deepcopy(revision.get('resume')))
prior=revision.get('progression_integrated_PI01',{});revision.setdefault('progression_PI01_development_before_COMMITTED',copy.deepcopy(prior))
revision['progression_integrated_PI01']={**prior,**progression}
revision['current_operation']='PI01 COMMITTED: ECI02_PI01_MAIN,N67,T735843. Principal físico727225preservado; migración y reapertura0ticks. Cierre documental/ZIP en preparación; Manual1.27pendiente de publicación.'
revision['resume']={'campaign':'PROGRESION_INTEGRADA_01','stage':'COMMITTED_PACKAGE_AND_MANUAL_PENDING','principal':{'life_id':LIFE,'N':67,'tick':735843,'snapshot_sha256':card['snapshot_sha256']},
 'manual_edition':'1.26','manual_target_edition':'1.27','manual_target_status':'PENDIENTE_PUBLICACION','continuity':str(P/'CONTINUIDAD_PI01.json'),
 'next':'Finish verified Word/publication and<=15000000byteanalysis ZIP; no new experiments. To continue the adopted life use its existing full paired local state and the manager; do not reimport the seed over it.'}
revision['manual_update_pending_PI01']=manual;revision['updated_utc']=stamp
if sha(revision_path)!=revision_hash:raise ValueError('REVISION cambió concurrentemente; no sobrescribir cambios MAR/root')
write(revision_path,revision)

commands={'GUI':'ABRIR_DEE_COGNITIVE.bat --sistema','owner':'motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-iniciar --vida ECI02_PI01_MAIN --backend mente_unificada --eci01 --pausado --intervalo 60 --guardar-cada 3600 --max-segundos 7200',
 'resume':'motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-reanudar --vida ECI02_PI01_MAIN',
 'status_literal':[{'modo':'eci01-pi01-estado'}],'next_opportunity_literal':[{'modo':'eci01-pi01-paso'}],
 'request':'motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-pedir --vida ECI02_PI01_MAIN --situaciones <literal JSON list> --id <new unique transport ID> --esperar 240',
 'save':'motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-guardar --vida ECI02_PI01_MAIN',
 'stop':'motor/python313/python.exe -I -B -X utf8 sistema/gestionar.py mente-unificada-detener --vida ECI02_PI01_MAIN',
 'use_conditions':'One writer only; owner opens paused, materialFIFO requires resume. No automatic retry, no reseed, no environment reset. Offering another opportunity advances the existing life and must record its actual outcome. GUI text grammar has no PI01shortcut; use the existing manager JSON.'}
state_files=[S/'estado/ACTIVO.json',card_path,snap,S/'estado/servicios_persistentes'/LIFE/'cola.sqlite3',S/'estado/vidas'/LIFE/'HISTORIA.jsonl',S/'estado/vidas'/LIFE/'PROCEDENCIA_PI01/VIDA_FUENTE.json',S/'estado/vidas'/LIFE/'PROCEDENCIA_PI01/HISTORIA_FUENTE.jsonl',S/'estado/pares_iniciales'/LIFE/'EXPORTACION_SERVICIO.json']
continuity={'schema':'DEE.PI01.continuity.v1','updated_utc':stamp,'status':'COMMITTED','current_principal':current,'physical_parent':physical_parent,'transport_import_parent':import_parent,'complete_state':list(map(file_ref,state_files)),
 'worker_artifacts_directory':str(S/'estado/servicios_locales'/LIFE),'resource_bank_directory':str(S/'estado/servicios_locales'/LIFE/'PI01_RESOURCE_BANK_R04'),
 'environment':proof['resource_validation'],'native_pending_at_last_recorded_product_check':0,'transport_pending_reconciled':True,'owner_at_last_recorded_check':'CLOSED; not an instantaneous observation',
 'last_operation':'Product existing-owner status request plus graceful close,0native ticks; explicit Store.promote COMMITTED at same cut',
 'usable_functions':progression,'commands':commands,'manual':manual,'analysis_package':{'status':'EN_PREPARACION','limit_bytes':15000000,'not_complete_operational_backup':True}}
write(P/'CONTINUIDAD_PI01.json',continuity)

sources=[P/'control/ADOPCION_PRODUCTO_PI01.json',P/'control/DECISION_PROMOCION_PI01.json',P/'control/REAPERTURA_PRODUCTO_PI01.json',P/'control/VALIDACION_ADOPCION_R04.json',P/'control/PAR_FINAL_PI01.json',P/'control/DESPLIEGUE_R04.json',P/'control/PROTOCOLO_RESERVA_R04.json',P/'ensayos/RESUMEN_CONSERVACION_R04.json',P/'ensayos/REAPERTURA_CONTINUACION_R04.json',P/'control/LIMPIEZA_AUDITORIA_EJECUTADA.json',P/'control/INCIDENCIA_HORARIA.json']
sources+=[S/rel for rel in('capacidades/progresion_integrada_01.py','capacidades/pi01_traza_legal_base.py','app/mundo_genesis_apd05.py','app/cola_local.py')]
sources+=[S/'contratos'/name for name in contract_files]
routes={'schema':'DEE.PI01.decisive_routes.v1','updated_utc':stamp,'product_root':str(C),'campaign_root':str(P),'operation':list(map(file_ref,state_files)),
 'science_and_implementation':list(map(file_ref,sources)),'coverage':coverage,'contract_changes':contract_changes,'eight_baselines':baseline_check,
 'historical_audit_relocation':clean_summary,'manual':manual,'excluded':'No new260278-path inventory, engine duplication, videos, Mac or unrelated information. State directories and historical baselines remain local.'}
write(P/'MAPA_RUTAS_DECISIVAS.json',routes)
ficha={'schema':'DEE.PI01.organism_and_assistance.v1','life_id':LIFE,'world_id':card['world_id'],'N':67,'tick':735843,'Runtime':'One inherited official OrganizationalWorld/Runtime in the selected full snapshot; no newT0',
 'classification':'Composed single-world organization with prepared interfaces and external resource environment',
 'criterion':'One shared physical history connects acquired MAcontents/FIsensor and prepared route trace; resource environment is outside Native and returns consequences through legal ports.',
 'physical_parent':physical_parent,'transport_import_parent':import_parent,'components':[{'name':'Two-route native trace','origin':[0,5,20],'purpose':'History-conditioned0/1access; acquired change via consequences','prepared':'Initial carrier, legal interfaces, readers and generic returns'},
 {'name':'Inherited MAcontextual memory','purpose':'Acquired alfa− used when route0 selected; lexical addressing is prepared'},
 {'name':'Inherited FI128 earlyP0access','purpose':'Joint public scalar comparison produces physical+,−,0 through the acquired reference; route1 selects this fixed access'},
 {'name':'Inherited word associations and Native arithmetic','purpose':'Four recorded signs and13then8 used in the same continuing life; no new arithmetic algorithm learned'},
 {'name':'External resource environment','purpose':'Actual64bytefile accepted after the emitted command matches a hidden environment condition;19opportunities,17collectedresources','outside_Runtime':True}],
 'channels':'1009declared interfaces at final recorded cut;5new PI01 ports. Count is neither number of components nor number of concepts.',
 'host_decisions':['Opportunity calendar and fixed curriculum','Fixed trace route0->MAalfa and route1->FIcodec','Fixed readers, signs-to-command conversion and return timing','Environmental rule evaluated after actual physical action','Queue management, serialization, promotion and scientific interpretation'],
 'native_contribution':['Physical direction at frozen site/time selects an access0/1','Acquired memory/encounters determine the formed answer used by fixed transduction','Actual negative consequence changes later route-state behavior through the prepared native mechanism'],
 'acquired_history':'MAIN reserved18then12retention uses then episode18; no copying of controls or MINUS memories. Source record/history preserved through same-ID migration.',
 'initiative':'Operator initiates an opportunity; no claim of learned timing, self-generated plan or universal autonomous recovery.',
 'distinction_P0_P1_P2':'P0anatomy/codec/calendar/readers; P1state-dependent content/use; boundedP2route-state update by consequences compared with OMIT. No generalR2 or general decision algorithm.',
 'boundary':'Native organization is its physically interacting support/context, not the entire external64bytefile bank or audit. The external environment and bridge are declared assistance, not cognitive memory.',
 'preserved_domains':'Only panel uses listed in MATRIZ_ANTES_DESPUES; no assertion that all historical capabilities now inhabit MAIN.',
 'evidence':sources[:9],'limits':limits}
ficha['evidence']=[str(x)for x in ficha['evidence']]
write(P/'FICHA_ENTE_Y_ASISTENCIA.json',ficha)

rows=[]
for row in panel['rows']:
 rows.append({'family':'conservation','function':row['label'],'before':'Previously acquired/functionally available in physical parent; preserved historical evidence, not retaught here','after':str(row['response']),
 'life':LIFE,'from_tick':row['before'],'through_tick':row['after'],'physical_parent_tick':727225,'transport_import_tick':735843,
 'result':'concordant first recorded response','assistance':'Operator request and fixed reader; arithmetic sequence selected by operator','evidence':'ensayos/RESUMEN_CONSERVACION_R04.json#rows['+str(row['index'])+']','limits':'Panel cut is735466, not repeated after final migration'})
rows += [
 {'family':'progression','function':'useful_history_conditioned_access','before':'Mechanism available historically; not acquired in this parent through PI01','after':'REAL16/18resources;OMIT12/18;NULLED0/18','life':LIFE,'from_tick':727225,'through_tick':734101,'physical_parent_tick':727225,'transport_import_tick':735843,'result':'bounded native route acquisition/use integrated with inherited content','assistance':'Prepared opportunities, fixed codec/routes and consequence channels','evidence':'control/VALIDACION_ADOPCION_R04.json#metrics','limits':'Related deterministic branches; MAINerrors6,13; not general policy'},
 {'family':'continuation','function':'same_life_next_opportunity','before':'12retention uses completedT735466','after':'route0MAalfa−;1new resource;17total','life':LIFE,'from_tick':735466,'through_tick':735843,'physical_parent_tick':727225,'transport_import_tick':735843,'result':'separate-process continuation without seed/reset','assistance':'Operator initiates opportunity','evidence':'ensayos/REAPERTURA_CONTINUACION_R04.json','limits':'Single additional opportunity; not a new18casevalidation'},
 {'family':'migration','function':'full_state_product_reopen','before':'Campaign store full pair735843','after':'SameID/productstore;RAWclocks/causalprefix unchanged;pending export reconciled','life':LIFE,'from_tick':735843,'through_tick':735843,'physical_parent_tick':727225,'transport_import_tick':735843,'result':'0native ticks;COMMITTED current selectors','assistance':'Existing import_pair and Store.promote; administrative metadata changesencodedSHA','evidence':'control/REAPERTURA_PRODUCTO_PI01.json;control/ADOPCION_PRODUCTO_PI01.json','limits':'Operational check, not new scientific learning'},
 {'family':'not_tested','function':'social_initiative_general_recovery','before':'Various historical mechanisms in named lives/domains','after':'No new social negotiation/autonomous opportunity initiation/general recovery claim','life':LIFE,'from_tick':727225,'through_tick':735843,'physical_parent_tick':727225,'transport_import_tick':735843,'result':'not tested in this progression','assistance':'Do not merge other biographies into MAIN','evidence':'control/PROTOCOLO_RESERVA_R04.json','limits':'No automatic reassignment of all historical repertoire'}]
with(P/'MATRIZ_ANTES_DESPUES.csv').open('w',encoding='utf-8-sig',newline='')as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
if sha(card_path)!=card_sha or sha(snap)!=card['snapshot_sha256']:raise ValueError('Estado operativo cambió durante sincronía; no declarar corte estable')
print(json.dumps({'status':'DOCUMENT_SYNC_COMPLETE_NO_NATIVE','life_id':LIFE,'N':67,'tick':735843,'snapshot_sha256':card['snapshot_sha256'],'contracts':contract_changes,'outputs':[str(P/x)for x in('CONTINUIDAD_PI01.json','MAPA_RUTAS_DECISIVAS.json','FICHA_ENTE_Y_ASISTENCIA.json','MATRIZ_ANTES_DESPUES.csv')],'manual':manual,'old_record_preserved':True,'eight_baselines_verified':len(baseline_check),'new_ticks':0},ensure_ascii=False,indent=2))
