"""Passive closure checks of recorded results and complete paired export."""
from pathlib import Path,PurePosixPath
import datetime,hashlib,json
P=Path(__file__).resolve().parent.parent
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with p.open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
frozen=read(P/'control/PROTOCOLO_RESERVA_R04.json')
groups={arm:read(P/'ensayos'/('RESUMEN_PI01_RES_'+arm+'.json'))for arm in('REAL','OMIT','NULLED')}
checks={};metrics={}
for arm,g in groups.items():
 rows=g['rows'];checks[arm+'_18_opportunities']=len(rows)==18
 metrics[arm]={'opportunities':len(rows),'valid_route':sum(x['route']in(0,1)for x in rows),'valid_response':sum(type(x['response'])is int and x['response']in(-1,0,1)for x in rows),'resources':sum(x['accepted']for x in rows),'final_tick':rows[-1]['after'],'errors':[x['episode']for x in rows if not x['accepted']]}
checks['same_age_and_calendar']=all(groups['REAL']['rows'][i]['before']==groups[a]['rows'][i]['before']and groups['REAL']['rows'][i]['after']==groups[a]['rows'][i]['after']for a in('OMIT','NULLED')for i in range(18))
checks['main_meets_frozen_15']=metrics['REAL']['resources']>=15
checks['main_gain_at_least3']=metrics['REAL']['resources']-metrics['OMIT']['resources']>=3
checks['null_actuation_no_resources']=metrics['NULLED']['resources']==0
checks['all_game_signatures_valid']=all(x['valid_route']==18 and x['valid_response']==18 for x in metrics.values())
retention=read(P/'ensayos/RESUMEN_CONSERVACION_R04.json');checks['retention12']=len(retention['rows'])==12 and all(x['concordant']for x in retention['rows'])
checks['actual_number_propagated']=retention['rows'][9]['literal']['izquierda']==retention['rows'][8]['response']==13 and retention['rows'][9]['response']==8
continued=read(P/'ensayos/REAPERTURA_CONTINUACION_R04.json');checks['separate_process_next_game']=continued['episode']==18 and continued['before_tick']==735466 and continued['effect']['accepted']and continued['after_tick']==735843
descriptor=read(P/'control/PAR_FINAL_PI01.json');pair=Path(descriptor['pair']['directory']);manifest=pair/'EXPORTACION_SERVICIO.json';m=read(manifest)
checks['pair_manifest']=sha(manifest)==descriptor['pair']['manifest_sha256']
for member in m['members']:
 rel=PurePosixPath(member['file'])
 if rel.is_absolute()or'..'in rel.parts or':'in member['file']:raise ValueError('Unsafe manifest path')
 file=pair.joinpath(*rel.parts)
 if not file.resolve().is_relative_to(pair.resolve())or file.stat().st_size!=member['bytes']or sha(file)!=member['sha256']:raise ValueError('Pair member mismatch:'+member['file'])
checks['pair_all_members_exact']=True;checks['pair_physics_final']=m['physical']['tick']==735843 and m['physical']['N']==67
checks['source_closed_and_certain']=True
closed=[read(P/'control/PAR_FINAL_PI01.json')]
events=[json.loads(line)for line in(P/'ENSAYOS.jsonl').read_text(encoding='utf-8').splitlines()if line]
owners=[e for e in events if e.get('kind')=='OWNER_CLOSED'and e.get('life')=='ECI02_PI01_MAIN']
checks['source_closed_and_certain']=bool(owners)and owners[-1]['exit_code']==0 and not owners[-1]['final_status']['running']and not owners[-1]['final_status']['uncertain_external_result']
checks['no_new_idle_ticks']=all(e['final_status'].get('idle_ticks')==138355 for e in owners)
fixture_resources=[x for x in m['members']if'/PI01_RESOURCE_BANK_R04/'in('/'+x['file'])]
collected=[x for x in fixture_resources if'/collected/'in x['file']]
checks['all17_actual_files_present']=len(collected)==17 and all(x['bytes']==64 for x in collected)
checks['frozen_code_exact']=all(sha(P/'estados/candidato/sistema'/file)==s for file,s in frozen['code_sha256'].items())
record={'schema':'PI01.adoption.evidence_gate.R04','life_id':'ECI02_PI01_MAIN','parent_life':'ECI02_OPERATIVA_PRINCIPAL_01','parent_tick':727225,'N':67,'tick':735843,'approved_for_adoption':all(checks.values()),'decision':'ELIGIBLE_PENDING_ZERO_TICK_PRODUCT_LOAD'if all(checks.values())else'KEEP_OLD_PRINCIPAL','checks':checks,'metrics':metrics,'retention':{'first_responses':12,'concordant':sum(x['concordant']for x in retention['rows']),'no_teacher':True},'pair':descriptor['pair'],'resources_after_continuation':17,'source_physical':m['physical'],'actual_effect':'17 files of64bytes; external resources, not energy or metabolism','limits':['Three related branches from same prefix; not independent replicated organisms','P0 opportunity timing and route-to-access dispatch; no self-initiated goal or universal recovery','P2 local state/route update follows prepared consequence contacts, not learning an unrestricted decision algorithm'],'recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(P/'control/VALIDACION_ADOPCION_R04.json').write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(record,ensure_ascii=False,indent=2))
if not record['approved_for_adoption']:raise SystemExit(2)
