# Cobertura, omisiones y verificación

El informe yFUENTES declaran lectura completa, parcial, metadatos y reutilización.
MAR:capítulos1–58,anexosA–M,72tablas. LBM:1–74,A–L,80tablas. Lectura técnica OOXML,
sin ejecutar cápsulas; no equivale a nueva revisión visual de sus fuentes históricas.
Manual1.26leído completo en el corte anterior porhash;1.27conserva ese cuerpo y
añadePI01. QA final combina renderWord,contactos,comparación de páginas y revisión
legible de los apartados afectados; no se afirma diseño perfecto de cada página.
Otros bloques:58nuevos contenidos únicos completos/72seleccionadosCPC/Campañas;
148textos completos+1extensión+65lecturas previas reutilizadasCORE/Ingenierías/etc;
13informes y12decisiones de campañas posteriores. No sumar bloques como únicos globales.

Se incluyen100capturas primarias:60tarea(5desarrollo,54reservadas,1continuación),
12conservación y28preparación/diagnóstico/adversos;92archivos de64bytes respaldan
recursos de las cuatro vidasR04. El recálculo usa únicamente rutas relativas del
índice y separa los28primarios no puntuables. No certifica inteligencia ni promoción.

No se excluyeron oportunidades fallidas de las54reservadas; se conservan variantes
R01–R04 y los bloqueos. No se exporta toda la telemetría profunda ni snapshots por tick.
03_MAPAS/INDICE_FUENTES_Y_OMISIONES.json da rutas reales,tamaños,hashes disponibles y
conjunto mínimo para continuar. Los manualesThinking,motor,estados grandes y ZIP
histórico no se anidan. La evidencia exportada después del borrado del temporal
antiguo es suficiente para el recálculo documental, no para reproducir Native.

Se conserva la distinción entre panelT735466 y continuaciónT735843; una comprobación
administrativa0ticks no vuelve a demostrar12usos. El estado vivo no se observa desde
un caché. El propietario quedó cerrado según el recibo de reapertura; en este cierre
sólo se comparan archivos críticos ya identificados, sin ejecutar ni importarDEE.

El sellador crea Deflate estándar,manifiesto de todos los miembros excepto él mismo,
compruebaCRC/hashes,textosJSON/CSV,DOCX yPDF,y extrae en un directorio nuevo. El
recálculo desde esa extracción escribe fuera de ella. El testimonio final externo
registra los resultados reales,bytes exactos y SHA del ZIP; nunca se incluye su hash
en su propio contenedor. Cualquier cambio posterior exige otro candidato y pruebas
afectadas. Las rutas externas de procedencia no son dependencias del recálculo.

La preservación antes/después alcanza snapshot principal,padre,VIDA,SQLite,WHL,PYD,
manualesThinking y documentos publicados, no todos los archivos del proyecto.
El requisito temporal6horas no se cumplió; verINCIDENCIA_HORARIA y el informe. Las
esperas deWord/permisos y el corte de conexión no añaden experiencia del ente.

Sin acceso de subida local descargable en la interfaz, no se inventa enlaceiPhone.
No se utilizaron servicios externos. Los temporales regenerables se señalan en el
índice; no se borran automáticamente ni se confunden con estados únicos/evidencia.
