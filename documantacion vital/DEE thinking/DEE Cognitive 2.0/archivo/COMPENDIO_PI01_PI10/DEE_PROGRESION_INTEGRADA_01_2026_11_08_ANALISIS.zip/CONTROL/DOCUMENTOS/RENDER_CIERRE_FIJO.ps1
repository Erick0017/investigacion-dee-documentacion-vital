$ErrorActionPreference='Stop'
# Fixed local copied documents only; no parameters, original files or DEE runtime.
$taskRoot='D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests\documantacion vital\DEE thinking\archivo\analisis_transversal_cognitivo\PROGRESION_INTEGRADA_01\documentos'
$taskConfig=Get-Content -Raw -LiteralPath ($taskRoot+'\ACTUALIZACION_DOCUMENTAL_CORREGIDA.json') | ConvertFrom-Json
$taskShortRoot='D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests\PI01_WORD_QA_20261108'
[void][IO.Directory]::CreateDirectory($taskShortRoot)
$taskWord=$null
$taskDoc=$null
$taskResults=@()
$taskPrevious=@()
if(Test-Path -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD.json')){
 $taskPrevious=@(Get-Content -Raw -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD.json') | ConvertFrom-Json)
 if(-not(Test-Path -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD_R01.json'))){Copy-Item -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD.json') -Destination ($taskRoot+'\RENDERIZADO_FINAL_WORD_R01.json')}
}
try {
 $taskWord=New-Object -ComObject Word.Application
 $taskWord.Visible=$false
 $taskWord.DisplayAlerts=0
 $taskWord.AutomationSecurity=3
 $taskOldLinks=$taskWord.Options.UpdateLinksAtOpen
 $taskOldPrompt=$taskWord.Options.SaveNormalPrompt
 $taskWord.Options.UpdateLinksAtOpen=$false
 $taskWord.Options.SaveNormalPrompt=$false
 foreach($taskKind in @('Manual','Compendium')){
  $taskItem=$taskConfig.$taskKind
  $taskDone=@($taskPrevious | Where-Object {$_.Kind -eq $taskKind -and $_.InputSha256 -eq $taskItem.sha256})
  if($taskDone.Count -eq 1 -and (Test-Path -LiteralPath $taskDone[0].Output) -and (Test-Path -LiteralPath $taskDone[0].ShortPdf)){
   if((Get-FileHash -LiteralPath $taskDone[0].Output -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $taskDone[0].ShortPdf -Algorithm SHA256).Hash){throw 'Previously rendered PDF changed'}
   $taskResults += $taskDone[0]
   continue
  }
  $taskInput=[string]$taskItem.output
  $taskRevision=([string]$taskItem.sha256).Substring(0,8)
  $taskOutput=$taskRoot+'\'+$(if($taskKind -eq 'Manual'){'MANUAL_1_27_ENTREGA_'+$taskRevision+'.pdf'}else{'COMPENDIO_PI01_ENTREGA_'+$taskRevision+'.pdf'})
  if([string]::IsNullOrWhiteSpace($taskInput) -or -not($taskInput.StartsWith($taskRoot+'\staging_ENTREGA\',[StringComparison]::OrdinalIgnoreCase) -or $taskInput.StartsWith($taskRoot+'\staging_ENTREGA_R02\',[StringComparison]::OrdinalIgnoreCase))){throw 'Only the exact PI01 staging document is allowed'}
  if(Test-Path -LiteralPath $taskOutput){throw 'PDF already exists; do not overwrite a verified candidate'}
  $taskHash=(Get-FileHash -LiteralPath $taskInput -Algorithm SHA256).Hash.ToLowerInvariant()
  if($taskHash -ne $taskItem.sha256){throw 'Staged document hash mismatch'}
  $taskShortInput=$taskShortRoot+'\'+$(if($taskKind -eq 'Manual'){'manual_1_27_'+$taskRevision+'.docx'}else{'compendio_pi01_'+$taskRevision+'.docx'})
  $taskShortPdf=$taskShortRoot+'\'+$(if($taskKind -eq 'Manual'){'manual_1_27_'+$taskRevision+'.pdf'}else{'compendio_pi01_'+$taskRevision+'.pdf'})
  if(Test-Path -LiteralPath $taskShortInput){if((Get-FileHash -LiteralPath $taskShortInput -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw 'Different temporary copy protected'}}
  else{Copy-Item -LiteralPath $taskInput -Destination $taskShortInput}
  if((Get-FileHash -LiteralPath $taskShortInput -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw 'Short-path copy mismatch'}
  if(Test-Path -LiteralPath $taskShortPdf){throw 'Temporary PDF exists; preserve and reconcile instead of overwriting'}
  $taskDoc=$taskWord.Documents.Open($taskShortInput,$false,$true,$false)
  $taskActual=[string]$taskDoc.FullName
  if([string]::IsNullOrWhiteSpace($taskActual) -or -not(Test-Path -LiteralPath $taskActual -PathType Leaf)){throw ('Unexpected Word source; requested='+$taskInput+'; actual='+$taskActual)}
  if((Get-FileHash -LiteralPath $taskActual -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw ('Word opened different bytes; requested='+$taskInput+'; actual='+$taskActual)}
  foreach($taskStory in $taskDoc.StoryRanges){
   $taskRange=$taskStory
   while($null -ne $taskRange){[void]$taskRange.Fields.Update();$taskRange=$taskRange.NextStoryRange}
  }
  $taskDoc.Repaginate()
  $taskPages=$taskDoc.ComputeStatistics(2)
  $taskDoc.ExportAsFixedFormat($taskShortPdf,17,$false,0,0,1,$taskPages,0,$true,$true,1,$true,$true,$false)
  $taskDoc.Close(0)
  [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($taskDoc)
  $taskDoc=$null
  if((Get-FileHash -LiteralPath $taskInput -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw 'Read-only source changed'}
  if((Get-FileHash -LiteralPath $taskShortInput -Algorithm SHA256).Hash.ToLowerInvariant() -ne $taskHash){throw 'Temporary read-only source changed'}
  Copy-Item -LiteralPath $taskShortPdf -Destination $taskOutput
  if((Get-FileHash -LiteralPath $taskShortPdf -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $taskOutput -Algorithm SHA256).Hash){throw 'PDF copy mismatch'}
  $taskResults += [pscustomobject]@{Kind=$taskKind;Input=$taskInput;ShortInput=$taskShortInput;WordCanonicalSource=$taskActual;InputSha256=$taskHash;Output=$taskOutput;ShortPdf=$taskShortPdf;Pages=$taskPages;WordVersion=$taskWord.Version;OriginalOpened=$false;ReadOnly=$true;UTC=[DateTime]::UtcNow.ToString('o')}
  $taskResults | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD.json') -Encoding utf8
 }
 $taskResults | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD.json') -Encoding utf8
 $taskResults | ConvertTo-Json -Depth 6
}
catch {
 [pscustomobject]@{Error=$_.Exception.Message;Stack=$_.ScriptStackTrace;HResult=$_.Exception.HResult;UTC=[DateTime]::UtcNow.ToString('o');Completed=$taskResults} | ConvertTo-Json -Depth 7 | Set-Content -LiteralPath ($taskRoot+'\RENDERIZADO_FINAL_WORD_ERROR.json') -Encoding utf8
 throw
}
finally {
 if($null -ne $taskDoc){$taskDoc.Close(0);[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($taskDoc)}
 if($null -ne $taskWord){
  $taskWord.Options.UpdateLinksAtOpen=$taskOldLinks
  $taskWord.Options.SaveNormalPrompt=$taskOldPrompt
  $taskWord.Quit(0)
  [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($taskWord)
 }
}
