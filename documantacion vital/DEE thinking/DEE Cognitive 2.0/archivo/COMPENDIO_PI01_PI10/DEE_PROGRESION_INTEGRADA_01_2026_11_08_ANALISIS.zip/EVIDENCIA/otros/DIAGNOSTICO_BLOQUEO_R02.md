# Primer bloqueo R02: reproducción diagnóstica con observación pasiva

Se ejecutó una reproducción técnica nueva sobre un clon del par operativo completo. No fue parte de la auditoría de cero ticks ni una reparación del principal. El protocolo quedó congelado antes de la ejecución en `control/PROTOCOLO_TRAZA_BLOQUEO.json`.

Vida: **ECI02_PI01_TRAZA_BLOQUEO**, N67. Padre: ECI02_OPERATIVA_PRINCIPAL_01 T727225, importación explícita de snapshot y transporte (3075 miembros, 127575069 bytes verificados). Se reprodujeron sólo semilla7, primer sensor17 y normalizador3 de R02, en D=(47,49,53), con clocks heredados y admisión oficial. No se añadió penalidad, juego, corte, limpieza, interceptor ni corrección de contenido. El clon quedó guardado en **T727496**.

La semilla se aplicó en T727227. La primera decisión fue T727428; el normalizador se programó igual que R02, para aplicación en T727494 y efecto registrado en T727495. Sensor y normalizador terminaron **applied**, con IDs110545 y110546 respectivamente. Se conservaron recibos, dos snapshots completos durante el intervalo y el estado/transporte del clon.

## Lo observado y su explicación

El portador de la decisión tiene carga24 y dirección Z+. Se observa consecutivamente en la línea prevista desde T727480, posición(47,49,38), hasta **T727486, posición(47,49,44)**. El siguiente sitio, **(47,49,45)**, ya contiene **RAW4611686018427387904 = 2^62**, semantic4, dirección cero y state0. En **T727487** conserva ese mismo RAW: no aparece allí el hijo de carga24 ni continúa en la línea prevista. La observación incluyó todos los ticks decisión+52 a +68, ROI fija de radio3 y vecindad de la trayectoria, sin modificar los registros observados.

La regla oficial estática `4.5/DEE_thinking_4_5_0/source/src/kernel_v27.cpp`, línea248, copia el RAW de cualquier target semantic4 antes de ejecutar el routing. Su state0 no lo vuelve receptivo. Por tanto el mecanismo delimitado es **rechazo de una propuesta por soporte persistente preexistente**, no una suma entre dos portadores ni falta de espacio global. El padre ya contenía ese soporte; no se instaló para conseguir este resultado.

Al faltar el portador de acción en el retorno, el normalizador llega solo: en **T727495**, D contiene carga3 y dirección(1,0,−1). En **T727496**, el centro está RAW0. Las observaciones completas del receptor coinciden exactamente con el primario R02 en los tres tiempos compartidos examinados: decisión+2, retorno y retorno+1. Se comprobó igualdad de RAW, clock y demás campos de esas observaciones; no se afirma igualdad del mundo completo con R02 en ese corte porque el registro anterior no ofrecía ese comprobante global para este horizonte.

Este resultado explica la ausencia de la primera política retornante bajo esa ruta y preparación. No demuestra que todas las pérdidas posteriores tengan esa causa ni que se haya borrado toda información adquirida de E1. No se retiró el soporte para un control de necesidad ni se comprobó su función original; esa intervención no pertenecía al diagnóstico autorizado. La atribución de su rechazo se apoya en el preestado, postestado y rama determinista del kernel, sin asignar linaje a otros portadores por una carga coincidente.

## Incidencia instrumental y cierre

El primer supervisor resolvió el validador de cola desde el sistema candidato, que desconocía el nuevo literal diagnóstico. Lo rechazó antes de encolarlo; el propietario PID21512 cerró con exit0 en T727228. Se corrigió sólo la resolución de imports del supervisor, conservando la misma semilla y futuro. No se repitieron importación ni preparación. El segundo propietario, PID20516, ejecutó el único intervalo y cerró con exit0, `running=false`, último guardado T727496. El lease Native se devolvió al coordinador; no se dejaron procesos de este diagnóstico abiertos.

Fuentes exactas: `ensayos/PI01_TRAZA_BLOQUEO_PREPARE.json`, `ensayos/PI01_TRAZA_BLOQUEO_INTERVAL.json`, `ensayos/TRAZA_BLOQUEO_RESUMEN.json`, los logs de Owner y `ENSAYOS.jsonl`. Código congelado: `codigo/progresion_integrada_01_R02_TRAZA.py`; supervisor corregido: `codigo/diagnostico_bloqueo_continuar_supervisor.py`. `codigo/recalcular_traza_bloqueo.py` sólo lee los registros guardados y verifica la comparación, sin DEE.

La reproducción no incorporó una habilidad nueva ni modificó MAIN. Aporta un caso verificable de incompatibilidad entre una ruta añadida y material persistente heredado, que permite diseñar una variante sin limpiar el paisaje ni inventar recuperación.
