# Complemento dirigido de Física para interpretar PI01

Se añadieron lecturas de `FISICA DEE Y PROCESAMIENTO NATIVO/DEE_V4_0_1.docx`, sin repetir los capítulos y apéndices ya acreditados en R01. Localizadores P: índice cero de todos los `w:p` de `word/document.xml`, incluidas tablas. Se leyó texto y OMML, no se renderizó el libro ni se ejecutó código.

Lectura nueva completa por rangos: P1007–1085, P1230–1246, P1437–1476, P4436–4467 y P4586–4588. La ficha JSON adjunta consigna SHA actual y comparación con el registro anterior. Estos rangos completan preguntas puntuales de la progresión; no convierten la cobertura del tratado entero en lectura íntegra.

* P1010–1013 y P1058: semantic4 RAW fijo puede seguir causando efectos; existe un invariante Q4, pero eso no lo convierte en energía. Preparar una fuente persistente tampoco significa que el ente aprendiera a autoabastecerse.
* P1061–1069: recurrencia eventual requiere estado causal finito y contexto autónomo. Un entorno abierto con entradas no incluidas en ese estado no hereda sin más ese teorema. Un RAW fijo no es un punto fijo de RAW+clock; conservar los clocks importa aunque parezcan silenciosos. Esto respalda la adaptación legal de CORE09 sin reiniciarlos.
* P1230–1238: eliminar variables puede producir una memoria efectiva en la descripción reducida. No demuestra memoria corta ni que un lector limitado use toda la información. La comparación de una firma local debe conservar esa restricción de observador.
* P1437–1438: las latencias de Procesos son modulación de acceso por organización; no dilatación física universal. En PI01 los ticks del motor, el calendario de las oportunidades y el tiempo del anfitrión son magnitudes distintas.
* P1445–1455: la pérdida de procedencia se expresa por H(X|F(X)); una proyección observable puede ganar o perder entropía. Una lectura igual no prueba convergencia causal completa, mientras que una convergencia completa bajo protocolo futuro idéntico impide recuperar diferencias históricas desde ese sistema.
* P1460–1476: carga saturada y dirección reducida describen compresión de payload/procedencia, no calor ni energía. El registro de recursos del entorno PI01 puede medir consecuencias útiles de acciones, pero no metabolismo nativo de DEE.
* P4444–4467: la Física distingue recálculo de átomos históricos C6/C7 de una ejecución nueva y conserva denominadores: composición30/30 con270controles; canales86/86; reprogramación12/12. La progresión puede reutilizar esos mecanismos sin reclamar que el principal ya vivió esos ensayos.
* P4586–4588: el orden de autoridad es código, experimento y dominio. La integración editorial posterior de un mecanismo no cambia su fecha científica ni fusiona genealogías.

Procesamiento Nativo ya tiene lectura íntegra previa P0–774/T0–10 acreditada en el registro R01, incluida accesibilidad, historia, factoriales y paisaje. No se volvió a leer por empezar PI01. No se identificó una laguna adicional de ese texto que impida la calibración planteada; los huecos actuales son de acoplamiento/validación en la vida, no de una promesa teórica pendiente de releer.
