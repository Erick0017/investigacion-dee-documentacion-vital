# CORE09: qué puede reutilizar PI01 y qué exige una variante nueva

Lectura estática y recálculo documental: no se importó DEE ni se ejecutaron ticks en esta revisión.

La fuente es `cores/09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip`. Sus miembros decisivos son `RUNNERS/run_c9d02_adaptive_loop_discovery.py`, `RUNNERS/run_c9h02_a6_holdout.py`, `RUNNERS/core09_common.py`, `HOLDOUT_LOCKS/C9H02_ADAPTIVE_POLICY_A6.json` y `RESULTS/C9H02_adaptive_policy_A6.json`.

## Mecanismo y límites

La dirección de un portador móvil conserva una política binaria A/B. Una entrada sensorial colisiona con ese portador y forma una de dos direcciones de acción. La acción recorre el toro y vuelve al lugar de actualización. Un normalizador fijo conserva la política cuando no llega valencia negativa; una contribución de consecuencia, cuya dirección depende exclusivamente de la acción realizada, transforma el retorno en la política contraria. El kernel produce la combinación y la persistencia; el entorno decide si esa acción tuvo una consecuencia negativa según una relación ambiental congelada.

En el marco original:

```
A = (1,0,0); B = (0,1,0)
SENSOR = (-1,0,1); NORMALIZER = (1,0,-1)
ACTION[A] = (0,0,1); ACTION[B] = (-1,1,1)
PENALTY[0] = (-1,1,0); PENALTY[1] = (1,-1,0)
```

La tabla PENALTY es una transducción de valencia y traza de la acción, no una escritura directa de la respuesta correcta. Sin embargo, la anatomía ya ofrece exactamente dos acciones y una regla de cambio a la contraria. No acredita búsqueda de acciones arbitrarias, una política contextual de múltiples condiciones ni regulación general. Las variaciones de `context_sreg` son distractores de carga, no contextos semánticos diferentes que deban elegir políticas distintas.

El ensayo reservado usa 12 mundos principales, 14 oportunidades por mundo, N21/N23/N25, marcos y semillas nuevos. El resultado documental es 144/168 acciones correctas; las 24 incorrectas son las primeras ante adquisición e inversión. Excluidas únicamente esas oportunidades especificadas previamente, 144/144; contextos nuevos, 72/72. Los controles de igual exposición sin consecuencia, política reiniciada, ablación y reflejo fijo quedan en 84/168. Son mundos históricos distintos; sus aprendizajes no pertenecen a ECI02.

## La limpieza del scaffold no es el aprendizaje

`run_world`, líneas 75–76 de la copia exacta `DECISIVO_C9_DISENO.py.txt`, borra el centro C del scaffold regenerativo cuando la acción es incorrecta. Es una intervención externa de daño; no constituye consumo nativo ni una reparación ejecutada por el participante. El centro de política D está separado. La actualización de D sucede por el retorno y las contribuciones físicas, sin necesitar ese borrado de C. Omitir todo el scaffold C puede definir una variante prospectiva enfocada en decisiones, conservando el resultado original como antecedente. No sería una reproducción exacta del conjunto aprendizaje+reparación.

No se debe trasladar el borrado RAW/clock de C a una vida de Cognitive. Tampoco se debe usar el control de reiniciar D como método de mantenimiento de MAIN: es una intervención diagnóstica sobre copias.

## Admisión oficial 4.5 y diferencia con el wrapper histórico

`NativeWorld.inject`, líneas 125–129 de `DECISIVO_C9_COMMON.py.txt`, rechaza cualquier RAW no cero y después escribe ambos buffers RAW y ambos clocks. La función `inject_arrival` del protocolo histórico suministra clocks artificiales. Por tanto no basta envolver ese código y llamarlo operación oficial de Cognitive.

La fuente oficial `DEE thinking/4.5/DEE_thinking_4_5_0/source/src/runtime.cpp`, líneas 294–410, define otra frontera: `experience`/`probe` programan entradas según `ChannelSpec`; conflictos, solicitudes tardías, canales inválidos y sitios ocupados producen recibos de rechazo; al aplicar un evento se escribe RAW y se conserva expresamente la palabra clock existente (línea 404). La carga no transporta un clock. La admisión se decide en el límite temporal real; programado no equivale a aplicado.

Una variante en N67 debe usar canales legales y el propietario/protocolo existente, conservar clocks y rechazos, no abrir una segunda vía de avance. En el sector balístico aislado los clocks son irrelevantes para esos encuentros, pero ese teorema sectorial no elimina la necesidad de comprobar el contexto heredado de E1. El radio causal del tick completo puede llegar a tres, no sólo a Moore-26. Una región con `state=0` no está vacía si RAW conserva otras marcas.

## Acoplar conocimientos existentes

En los documentos y código examinados no se encontró un acoplamiento ya validado que lleve una salida FI/lexical de ECI02 a este selector y permita a DEE elegir por sí mismo qué conocimiento combinar. Compartir Runtime o añadir un componente no establece ese enlace. Un transporte fijo de una salida a otra entrada puede incorporarse como interfaz asistida declarada; si Python interpreta el significado y elige la solución, esa decisión no pertenece a DEE.

Para un enlace nativo candidato se necesitan oportunidades y una transformación física cuyos productos influyan posteriormente en ambos mecanismos, con cortes del producto formado y sham no invasivo. CORE10 proporciona antecedentes de comunicación mediante corredores y controles de fuga del convertidor; no una integración automática con E1.

La incorporación prudente que estos antecedentes habilitan es una variante físicamente legal y acotada del retorno A/B dentro de la genealogía N67, con adquisición/inversión, control sin valencia y corte del retorno. Su posible utilidad compuesta y la conservación de ECI02 requieren los resultados nuevos de PI01; este documento no anticipa su éxito.
