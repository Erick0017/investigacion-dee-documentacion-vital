"""Recalculate exported frozen R04 records and actual file bytes; never run DEE.

Run: python RECALCULAR_CADENA_CORTE.py
All dependencies are adjacent exported files. Absolute historical locators in
the original records are provenance only, never opened by this recalculation.
"""
from pathlib import Path
from collections import Counter
import hashlib,json,zlib
HOME=Path(__file__).resolve().parent
def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((HOME/name).read_text(encoding='utf-8-sig'))
def receipts(tree):
    unique={};occurrences=0
    def walk(x):
        nonlocal occurrences
        if isinstance(x,dict):
            if {'id','status','kind','requested_tick','effective_tick','channels'}<=set(x):
                occurrences+=1
                canonical={k:x[k]for k in('id','status','kind','requested_tick','effective_tick','channels','reason')if k in x}
                identity=str(x['id'])
                if identity in unique:assert unique[identity]==canonical,('Receipt alias disagreement',identity)
                else:unique[identity]=canonical
            for value in x.values():walk(value)
        elif isinstance(x,list):
            for value in x:walk(value)
    walk(tree)
    return unique,{'unique_events':len(unique),'receipt_occurrences':occurrences,'status_counts':dict(Counter(x['status']for x in unique.values())),'alias_occurrences_not_new_events':occurrences-len(unique)}
def main():
    manifest=read('MANIFIESTO.json')
    for n,m in manifest['members'].items():
        data=(HOME/n).read_bytes()
        assert len(data)==m['bytes']and sha(data)==m['sha256']and'%08x'%(zlib.crc32(data)&0xffffffff)==m['crc32'],n
    intact=read('INTACTO_C1_PRIMARIOS.json');cut=read('CORTE_RESULTADO.json')
    row=cut['result']['result']['rows'][0];first=intact['first_native_operation'];first_cut=row['first_native_operation'];second=intact['second_native_operation']
    checks=[]
    def require(label,value):assert value,label;checks.append(label)
    require('source_alias_equal',intact['source_alias']==cut['source_alias']=='PI03_APRENDIDO14_T764407')
    require('cut_transport_completed_and_owner_closed',cut['transport_status']=='completed'and cut['owner_closed']is True)
    for boundary in('before','after'):
        for field in('N','tick','RAW_sha256','clocks_sha256'):
            require('first_'+boundary+'_'+field+'_equal',first[boundary][field]==first_cut[boundary][field])
    require('first_actual_results_equal',first['numeric_result']==row['actual_first_result']==first_cut['numeric_result']==13)
    require('first_horizon_exact198',first['after']['tick']-first['before']['tick']==intact['first_horizon_ticks']==198)
    intact_r,intact_counts=receipts(first);cut_r,cut_counts=receipts(first_cut);second_r,second_counts=receipts(second)
    require('first_input_ids_and_terminal_receipts_equal',intact_r==cut_r)
    require('first_inputs_all_applied',set(x['status']for x in intact_r.values())=={'applied'})
    require('cut_no_second_no_supply_no_resource',row['second_operation_called']is False and row['supply_performed']is False and row['new_resources']==0 and row['payload']is None)
    require('intact_second_uses_actual_first',second['native_operation']['operands']==[first['numeric_result'],5])
    require('intact_second_is_fixed_difference',second['native_operation']['operation']=='diferencia')
    require('intact_final_actual8',second['numeric_result']==intact['actual_final_result']==8)
    require('intact_two_actual_resource_descriptors',len(intact['actual_resource_descriptors'])==2)
    for descriptor in intact['actual_resource_descriptors']:
        compressed=(HOME/'PRODUCTOS_REALES'/descriptor['name']).read_bytes()
        decoded=(HOME/'PRODUCTOS_REALES'/Path(descriptor['name']).with_suffix('.bin')).read_bytes()
        require('resource_'+descriptor['name']+'_compressed',sha(compressed)==descriptor['compressed_sha256']and len(compressed)==descriptor['compressed_bytes'])
        require('resource_'+descriptor['name']+'_actual_product',zlib.decompress(compressed)==decoded and len(decoded)==64 and sha(decoded)==descriptor['decoded_sha256']==intact['actual_payload_sha256'])
        # Exact R04 codec: actual uint16 little-endian followed by62 zeros.
        # The initial draft incorrectly assumed a repeated-byte codec; its
        # negative check and prior source/manifest are preserved separately.
        require('resource_'+descriptor['name']+'_fixed_actual_integer_codec',decoded==second['numeric_result'].to_bytes(2,'little',signed=False)+bytes(62))
    result={'schema':'PI03.assisted_chain_cut.portable_recalculation.v1','checks':checks,'manifest_members_verified':len(manifest['members']),
            'first_intact':intact_counts,'first_cut':cut_counts,'second_intact':second_counts,
            'observed':{'first_result':first['numeric_result'],'intact_final_result':second['numeric_result'],'intact_resources':len(intact['actual_resource_descriptors']),'cut_resources':row['new_resources'],'first_horizon_ticks':198},
            'native_execution':False,'new_native_ticks':0,'after_cut_age_and_exposure_matched':False,
            'conclusion':'Exact same first physical operation and inputs; interrupting the assisted first-to-second data link leaves no second operation/resource. Actual intact chain13->8 supplied two64B resources. This tests an assisted dependency, not Native planning, discovered composition or later policy performance.'}
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return result
if __name__=='__main__':main()
