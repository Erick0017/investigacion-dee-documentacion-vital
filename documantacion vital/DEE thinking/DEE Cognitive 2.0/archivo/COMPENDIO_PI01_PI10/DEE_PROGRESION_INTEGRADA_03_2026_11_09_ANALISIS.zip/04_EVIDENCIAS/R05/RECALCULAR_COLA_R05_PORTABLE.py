"""Pure recalculation from adjacent exported primary JSON; no DEE dependency."""
from pathlib import Path
import json,math
HERE=Path(__file__).resolve().parent
file=HERE/'R05_EVIDENCIA_CAUSAL.json'
if not file.is_file():
    file=HERE.parent/'control/CAUSALIDAD_COLA_R05_PORTABLE/R05_EVIDENCIA_CAUSAL.json'
d=json.loads(file.read_text(encoding='utf-8'));Q=tuple(d['Q']);N=d['N'];cases=d['conditions']
def at(delta):return tuple((Q[k]+delta[k])%N for k in range(3))
def frame(case,label):return next(x for x in cases[case]['frames']if x['label']==label)
def allsites(f):
    out={tuple(o['site']):o for o in f['core_and_encounter_context']}
    out.update({tuple(o['site']):o for o in f['entire_zero_Y_row']});return out
def cell(case,label,delta):return allsites(frame(case,label))[at(delta)]
def active_y(case,label):return[(o['site'][1]-Q[1])%N for o in frame(case,label)['entire_zero_Y_row']if o['state']>0]
def alive(o):return o['state']>0 and o['semantic']!=5
def local_count(case,label):
    rows=allsites(frame(case,label));neighbors=[]
    for x in(-1,0,1):
        for y in(-1,0,1):
            for z in(-1,0,1):
                if(x,y,z)==(0,0,0):continue
                p=at((x,y,z))
                if p not in rows:raise ValueError('Incomplete comparator Moore context')
                if alive(rows[p]):neighbors.append(rows[p])
    # At this recorded comparator no axialX neighbor is alive, ruling out all
    # source-v27 tetrahedral patterns. This is a static local rule calculation,
    # not simulation/evolution of a new world.
    no_x=not alive(rows[at((-1,0,0))])and not alive(rows[at((1,0,0))])
    if not no_x:raise ValueError('Published no-tetra shortcut does not cover this frame')
    n=len(neighbors);return{'n_active':n,'tetrahedral_signature':False,'electroweak_rule_value':math.floor(n*2.5/26+.5)}
checks=[]
def check(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(name)
check('shared_complete_source',len({x['source_manifest_sha256']for x in cases.values()})==1)
check('fixed_window_every_case',all(x['calendar']['query_tick']==771949 and x['calendar']['query_read_tick']==771955 and x['reader_contract_unchanged']for x in cases.values()))
check('noquery_has_no_material_query_or_action',cases['noquery']['actual_task_result']['material_query_inputs']==[] and cases['noquery']['actual_task_result']['task_action']is None)
check('old_carrier_exists_at_origin_without_query_q2',cell('noquery','q+2',(0,0,0))['state']>0 and cell('noquery','q+2',(0,0,0))['direction']==[0,1,0])
check('noquery_old_carrier_at_plus4_q6',4 in active_y('noquery','q+6'))
check('sham_old_Y_and_new_Z_coexist_q2',cell('sham','q+2',(0,0,0))['direction']==[0,1,0]and cell('sham','q+2',(0,0,-1))['direction']==[0,0,1])
check('sham_origin_retains_Y_not_new_Z_q3',cell('sham','q+3',(0,0,0))['direction']==[0,1,0]and cell('sham','q+3',(0,0,-1))['state']==0)
check('sham_old_packet_delayed_to_plus3_q6',3 in active_y('sham','q+6')and cell('sham','q+6',(0,2,0))['state']==0)
check('guard_eliminates_old_Y_before_query',active_y('guard','equal_age_before_fixed_query')==[]and active_y('guard','q-1')==[])
check('guard_admits_fresh_Z_at_origin_q3',cell('guard','q+2',(0,0,0))['state']==0 and cell('guard','q+3',(0,0,0))['direction']==[0,0,1])
check('guard_keeps_zero_at_original_reader_q6',cell('guard','q+6',(0,2,0))['state']>0 and cell('guard','q+6',(0,2,0))['direction']==[0,1,0])
check('guard_stops_postread_tail_q7',active_y('guard','q+7')==[])
check('actual_guard_product_sham_rejection',cases['guard']['actual_task_result']['useful_product']is True and cases['guard']['actual_task_result']['actual_effect']['actual_product_bytes']==64 and cases['sham']['actual_task_result']['useful_product']is False)
rule={'noquery_q2':local_count('noquery','q+2'),'sham_q2':local_count('sham','q+2')}
check('material_density_explains_old_origin_survival',rule['noquery_q2']['n_active']==4 and rule['noquery_q2']['electroweak_rule_value']==0 and rule['sham_q2']['n_active']==6 and rule['sham_q2']['electroweak_rule_value']==1)
for case in('guard','sham'):
    req=cases[case]['actual_task_result']['requests']
    query=[r for r in req if r['channel'].endswith(('.query','.support.plus','.support.minus'))]
    check(case+'_three_queries_admitted_same_boundary',len(query)==3 and all(r['receipt']['status']=='applied'and r['receipt']['effective_tick']==771949 and r['payload']==0 for r in query))
print(json.dumps({'scope':'Portable documentary recalculation ONLY; not Native reproduction or new experiments','checks':checks,'local_rule_from_recorded_Moore_context':rule,
                  'conclusion':'Pre-existing output activity occupies the comparator during the new query. Prepared sink changes that local encounter and restores the unchanged fixed reader and a real product. This is targeted P0 prevention, not autonomous recovery, global memory loss or a decoded change of reader.'},ensure_ascii=False,indent=2))
