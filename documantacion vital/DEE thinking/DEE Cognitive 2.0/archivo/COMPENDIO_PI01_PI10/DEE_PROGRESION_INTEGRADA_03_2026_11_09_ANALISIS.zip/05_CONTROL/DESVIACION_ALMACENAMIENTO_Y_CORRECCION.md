# Corte intermedio de acceso y preservación

La candidata física sigue en ECI02_PI03_MAIN, N67, T768317. El principal seleccionado sigue siendo ECI02_PI02_MAIN, N67, T753346. No se construyó ni ejecutó una decisión de promoción.

El diagnóstico integrado desde768317 conservó los12testigos anteriores y produjo2trabajos H/O, pero el lector R06 fijo q+6 dioNULL después. La operación avanzó771503→771955 antes del error de filesystem. `inflight_silence` faltaba porque la exportación de archivos no conservaba directorios vacíos; ese defecto ocurrió DESPUÉS de leerNULL y no lo explica.

OP2 reconstruye sólo las rutas vacías fijas del dispositivo a partir de su esquema conocido. La prueba directa en una copia recién cargada produjo0material→motor−1 y un producto útil,768317→769099. El control de edad sin las12consultas/H también dioNULL tras3186ticks, por lo que las consultas adicionales no son necesarias para reproducir este fallo. Se conservó la consecuencia negativa real y el propietario cerró sin reintento.

Los registros completos no muestran borrado global: dos referencias siguen activas, guardas intactas y un portador cero está una celda después del lector. Dos portadores históricos cero recorrían la fila central sin terminador. Su interferencia con la consulta es una hipótesis concreta apoyada por posiciones y reglas; todavía requiere contraste Native antes de atribuirle causalidad.

La cota conservadora de6000000000bytes lógicos nuevos se superó: el recuento local21:49 registró6352520945bytes. Se detuvieron nuevas bifurcaciones. No se amplió esa cota; se está archivando sólo los controles nuevos cerrados, con bytes, directorios vacíos, manifiesto y localizadores preservados. El recuento lógico no es una medición de espacio físico libre. Tiempo,120000ticks agregados y512MiB por Job permanecen fijados.

Esta nota registra hechos intermedios. No equivale a la clausura científica ni a una incorporación del estado de la candidata al principal.
