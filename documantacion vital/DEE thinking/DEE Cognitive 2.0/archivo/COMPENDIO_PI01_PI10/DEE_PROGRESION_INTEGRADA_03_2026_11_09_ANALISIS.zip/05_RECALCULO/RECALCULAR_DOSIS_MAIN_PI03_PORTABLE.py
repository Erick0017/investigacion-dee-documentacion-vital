"""Recalcula1290 entradas nuevas con dos snapshots y primarios del expediente.
Sólo stdlib/archivos adyacentes; sin Native, consulta, red ni ruta original.
GzipCRC y SHA global se verifican; no se recalcula aquí el FNV interno Native.
"""
from pathlib import Path,PurePosixPath
import argparse,datetime,gzip,hashlib,json,struct,sys
sys.dont_write_bytecode=True
class Reader:
 def __init__(self,b):self.b=b;self.i=0
 def take(self,n):
  if n<0 or self.i+n>len(self.b):raise ValueError('Snapshot truncado')
  a=self.b[self.i:self.i+n];self.i+=n;return a
 def u8(self):return self.take(1)[0]
 def u32(self):return struct.unpack('<I',self.take(4))[0]
 def u64(self):return struct.unpack('<Q',self.take(8))[0]
 def text(self):
  n=self.u32()
  if n>16*1024**2:raise ValueError('Texto de snapshot fuera de límite')
  return self.take(n).decode('utf8')
 def count(self):
  n=self.u32()
  if n>1000000:raise ValueError('Colección fuera de límite')
  return n

def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def native_body(p):
 r=read(p)
 if 'seq'in r:
  if r['status']!='completed':raise ValueError('Incomplete primary')
  return json.loads(r['result'])if isinstance(r['result'],str)else r['result']
 return r

def receipt_index(path):
 encoded=path.read_bytes();data=gzip.decompress(encoded)if encoded[:2]==b'\x1f\x8b'else encoded;r=Reader(data[:-8])
 if r.take(8)!=b'DEETSNP1'or r.u32()!=2:raise ValueError('Expected inherited full snapshot format')
 N=r.u32();tick=r.u64();r.u8();counters=[r.u64(),r.u64()];phase=r.text();sites=r.u64()
 if sites!=N**3:raise ValueError('Grid size mismatch')
 r.take(16*sites)
 for _ in range(r.count()):r.text();r.take(12+4+12+3)
 pending=r.count()
 for _ in range(pending):
  r.take(8+8+1+8+8)
  for _ in range(r.count()):r.text()
  for _ in range(r.count()):r.take(12+8)
 count=r.count();receipts={}
 for _ in range(count):
  rid=r.u64();kind=r.u8();status=r.u8();requested=r.u64();effective=r.u64()if r.u8()else None
  channels=[r.text()for _ in range(r.count())];reason=r.text()
  if rid in receipts:raise ValueError('Repeated Native ID inside the authoritative snapshot')
  receipts[rid]={'id':rid,'kind_code':kind,'status_code':status,'requested_tick':requested,'effective_tick':effective,'channels':channels,'reason':reason}
 maximum=max(receipts,default=0);candidate=maximum+1
 if candidate not in counters:raise ValueError('Full vector maximum+1 does not match a preserved header counter; next-ID fence not identified')
 return {'path':str(path),'sha256':sha(path),'N':N,'tick':tick,'phase':phase,'pending':pending,'receipt_count':count,
    'max_id':maximum,'next_id_fence':candidate,'header_counters_raw':counters,'receipts':receipts}

def walk(v):
 if isinstance(v,dict):
  x=v.get('receipt')
  if isinstance(x,dict)and type(x.get('id'))is int and'status'in x:yield x
  for child in v.values():yield from walk(child)
 elif isinstance(v,list):
  for child in v:yield from walk(child)

def calculate(cons,root,index):
 before_snapshot=root/index['before_snapshot'];after_snapshot=root/index['after_snapshot']
 before=receipt_index(before_snapshot);after=receipt_index(after_snapshot)
 if before['tick']!=cons['rows'][0]['before_tick']or after['tick']!=cons['final_tick']or before['pending']or after['pending']:
  raise ValueError('Full before/after cuts or agendas do not match the conservation interval')
 authoritative=set(after['receipts'])-set(before['receipts'])
 if any(i<before['next_id_fence']or i>=after['next_id_fence']for i in authoritative):raise ValueError('New vector IDs fall outside the exact preserved fences')
 selected={};embedded={};excluded=set();aliases=0;per=[]
 for row in cons['rows']:
  primary=root/row['primary'];n=native_body(primary)
  if n['before_tick']!=row['before_tick']or n['after_tick']!=row['after_tick']:raise ValueError('Row/primary tick mismatch')
  local={};excluded_here=set()
  for receipt in walk(n):
   rid=receipt['id'];embedded.setdefault(rid,receipt)
   qualifies=row['before_tick']<row['after_tick']and before['next_id_fence']<=rid<after['next_id_fence']and row['before_tick']<=receipt['requested_tick']<=row['after_tick']
   if not qualifies:excluded.add(rid);excluded_here.add(rid);continue
   if rid not in authoritative:raise ValueError('Primary claims an ID absent from the new authoritative Native vector')
   if receipt['requested_tick']!=after['receipts'][rid]['requested_tick']:raise ValueError('Primary and Native vector requested_tick disagree')
   if rid in selected:
    aliases+=1
    if selected[rid]!=receipt:raise ValueError('Conflicting new terminal receipt alias')
   selected[rid]=receipt;local[rid]=receipt
  if row['before_tick']==row['after_tick']and local:raise ValueError('Zero-tick state unexpectedly counted material inputs')
  per.append({'step':row['step'],'before_tick':row['before_tick'],'after_tick':row['after_tick'],'new_ids':sorted(local),'new_unique':len(local),'excluded_embedded_ids_unique':len(excluded_here),'primary_sha256':sha(primary)})
 # The asynchronous H/O bridge records terminal receipts in its own chained
 # journal. A time-advance primary does not duplicate every receipt object.
 # Include that actual journal only for the precise nonzero time window, with
 # the SAME Native ID and requested_tick fences as the direct primaries.
 journal=root/index['journal']
 entries=[json.loads(line)for line in journal.read_text(encoding='utf-8').splitlines()if line.strip()]
 status_row=next(row for row in cons['rows']if row['step']=='legacy_after')
 habitat=native_body(root/status_row['primary'])['result']['rows'][0]['habitat']
 chain=bytes(32);count=0;prefix_checked=False
 for line in journal.read_bytes().splitlines(keepends=True):
  item=json.loads(line)
  if item['index']!=count:raise ValueError('Workbench journal index gap')
  chain=hashlib.sha256(chain+line).digest();count+=1
  if count==habitat['log_count']:
   if chain.hex()!=habitat['log_chain_sha256']:raise ValueError('Workbench journal prefix does not match actual Native habitat status')
   prefix_checked=True
 if not prefix_checked:raise ValueError('Actual journal prefix/status witness absent')
 journal_ids=set()
 for row,stats in zip(cons['rows'],per):
  if row['literal'].get('modo')!='eci01-pi02-tiempo'or row['before_tick']==row['after_tick']:continue
  local=set(stats['new_ids'])
  for event in entries:
   for receipt in walk(event):
    rid=receipt['id']
    if not(before['next_id_fence']<=rid<after['next_id_fence']and row['before_tick']<=receipt['requested_tick']<=row['after_tick']):continue
    if receipt['status']!='applied'and not receipt['status'].startswith('rejected'):continue
    if rid not in authoritative or receipt['requested_tick']!=after['receipts'][rid]['requested_tick']:raise ValueError('Journal receipt differs from authoritative Native vector')
    if rid in selected:
     aliases+=1
     if selected[rid]!=receipt:raise ValueError('Journal/primary terminal receipt conflict')
    selected[rid]=receipt;local.add(rid);journal_ids.add(rid)
  stats['new_ids']=sorted(local);stats['new_unique']=len(local);stats['asynchronous_journal_source']=str(journal)
 if set(selected)!=authoritative:raise ValueError('Primary/journal-window IDs and full snapshot receipt difference disagree: missing='+str(sorted(authoritative-set(selected)))+' extra='+str(sorted(set(selected)-authoritative)))
 statuses=[v['status']for v in selected.values()]
 result={'unique_requested':len(selected),'applied':sum(x=='applied'for x in statuses),'rejected':sum(x.startswith('rejected')for x in statuses),
   'pending_or_other':sum(x!='applied'and not x.startswith('rejected')for x in statuses),'aliases_excluded':aliases,
   'scope':'New Native IDs only: full pre/post vector difference, lower/upper next-ID fences, requested_tick inside each actual nonzero primary window. Zero-tick states contribute0; historical nested receipts are excluded.'}
 return {'schema':'DEE.PI03.conservation_new_native_dose.passive.v2','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'native_receipts':result,'before':{k:v for k,v in before.items()if k!='receipts'},'after':{k:v for k,v in after.items()if k!='receipts'},
    'authoritative_new_receipt_ids':sorted(authoritative),'embedded_receipt_ids_unique_all':len(embedded),
    'excluded_embedded_ids_unique':len(excluded-set(selected)),'excluded_embedded_ids':sorted(excluded-set(selected)),
    'asynchronous_HO_journal':{'path':str(journal),'sha256':sha(journal),'entries':len(entries),'actual_habitat_prefix_chain_checked':True,'new_terminal_ids':sorted(journal_ids),'new_unique':len(journal_ids)},
    'per_primary':per,'Native_vector_difference_matches_filtered_primary_and_journal_ids':True,'new_native_ticks_by_recalculation':0,'DEE_imports':0}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--salida',type=Path);a=ap.parse_args()
 root=Path(__file__).resolve().parents[1]
 manifest=read(root/'05_CONTROL/MANIFIESTO_SHA256.json');records={x['file']:x for x in manifest['content']}
 name='04_EVIDENCIAS/MAIN_OP3/DOSIS_INDICE_PORTABLE.json';index=read(root/name)
 for item in[name,*index['input_members']]:
  rel=PurePosixPath(item)
  if rel.is_absolute()or'..'in rel.parts or ':'in item or '\\'in item:raise ValueError('Unsafe dossier input')
  f=root/rel
  if not f.resolve().is_relative_to(root)or f.is_symlink():raise ValueError('Input outside dossier')
  r=records[item]
  if f.stat().st_size!=r['bytes']or sha(f)!=r['sha256']:raise ValueError('Dossier input hash/size changed')
 result=calculate(read(root/index['conservation']),root,index)
 result['mode']='DOCUMENTARY_RECALCULATION_NOT_NATIVE';result['original_source_paths_opened']=False
 if a.salida:
  if a.salida.exists():raise FileExistsError('New output only')
  a.salida.write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps({k:result[k]for k in('native_receipts','embedded_receipt_ids_unique_all','excluded_embedded_ids_unique','Native_vector_difference_matches_filtered_primary_and_journal_ids','mode','original_source_paths_opened')},ensure_ascii=False))
if __name__=='__main__':main()
