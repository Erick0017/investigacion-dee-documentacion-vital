"""Recalculate the exported PI03 dossier using only adjacent documentary data.

No DEE import, Native replay, life opening, network, or recorded source path is
used. Run after clean extraction:
 python 05_RECALCULO/RECALCULAR_EXPEDIENTE_PI03.py --destino NEW_OUTPUT_FOLDER
The destination must be separate from the extracted dossier and not exist.
"""
from pathlib import Path,PurePosixPath
import argparse,ast,hashlib,json,os,subprocess,sys

GLOBAL_MANIFEST='05_CONTROL/MANIFIESTO_SHA256.json'
LAYOUT={'R02':'04_EVIDENCIAS/R02','R04':'04_EVIDENCIAS/R04',
        'R05':'04_EVIDENCIAS/R05','CORTE':'04_EVIDENCIAS/CORTE'}

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(data):return hashlib.sha256(data).hexdigest()
def reparse(p):
    return p.is_symlink()or bool(getattr(p.lstat(),'st_file_attributes',0)&0x400)
def member(root,name):
    require(type(name)is str and name!=''and '\\'not in name and ':'not in name,'Relative POSIX member required')
    require(not any(x in('','.','..')for x in name.split('/')),'Unsafe member components')
    rel=PurePosixPath(name);require(not rel.is_absolute(),'Absolute member prohibited')
    current=root
    require(not reparse(current),'Root must not be a link/junction')
    for part in rel.parts:
        current=current/part
        require(current.exists()and not reparse(current),'Missing/link/junction member '+name)
    resolved=current.resolve(strict=True)
    require(resolved.is_relative_to(root)and resolved.is_file(),'Member outside root or not a file '+name)
    return resolved
def load(path):return json.loads(path.read_text(encoding='utf-8-sig'))
def verify_records(root,records):
    require(type(records)is list and records,'Manifest content must be a nonempty list')
    seen={}
    for item in records:
        require(type(item)is dict and {'file','bytes','sha256'}<=set(item),'Malformed manifest record')
        name=item['file'];require(name not in seen,'Duplicate manifest file '+str(name))
        require(type(item['bytes'])is int and item['bytes']>=0,'Bad byte count')
        require(type(item['sha256'])is str and len(item['sha256'])==64,'Bad hash')
        file=member(root,name);data=file.read_bytes()
        require(len(data)==item['bytes']and sha(data)==item['sha256'],'Manifest mismatch '+name)
        # The optional historical source field is deliberately never resolved.
        seen[name]=item['sha256']
    return seen
def audit_imports(file):
    tree=ast.parse(file.read_text(encoding='utf-8-sig'),filename=file.name)
    for node in ast.walk(tree):
        if isinstance(node,ast.Import):names=[x.name.split('.')[0]for x in node.names]
        elif isinstance(node,ast.ImportFrom):
            require(node.level==0,'Relative code import forbidden in documentary runner')
            names=[(node.module or '').split('.')[0]]
        else:continue
        require(all(n in sys.stdlib_module_names for n in names),'Non-stdlib import in '+file.name+': '+','.join(names))

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--raiz',type=Path,default=Path(__file__).resolve().parents[1])
    ap.add_argument('--destino',type=Path,required=True)
    args=ap.parse_args();root=args.raiz.resolve(strict=True)
    require(root.is_dir()and not reparse(root),'Dossier root must be a plain directory')
    manifest_file=member(root,GLOBAL_MANIFEST);manifest_bytes=manifest_file.read_bytes();manifest=json.loads(manifest_bytes)
    require('content'in manifest,'Global manifest requires content array; recorded source paths are never used')
    verified=verify_records(root,manifest['content'])
    require(GLOBAL_MANIFEST not in verified,'No self-referential global manifest hash')
    actual=set()
    for folder,dirs,files in os.walk(root,followlinks=False):
        parent=Path(folder)
        for name in dirs:require(not reparse(parent/name),'Linked directory in dossier')
        for name in files:
            f=parent/name;require(not reparse(f),'Linked file in dossier');actual.add(f.relative_to(root).as_posix())
    require(actual==set(verified)|{GLOBAL_MANIFEST},'Unlisted or missing dossier members')
    evidence={k:root/v for k,v in LAYOUT.items()}
    for kind in('R02','R04'):
        m=load(member(root,LAYOUT[kind]+'/MANIFEST.json'))
        verify_records(evidence[kind],m['members'])
    verify_records(evidence['R05'],load(member(root,LAYOUT['R05']+'/MANIFIESTO.json'))['files'])
    m=load(member(root,LAYOUT['CORTE']+'/MANIFIESTO.json'))
    verify_records(evidence['CORTE'],[{'file':n,**v}for n,v in m['members'].items()])
    scripts={
      'R02':member(root,'05_RECALCULO/recalcular_tarea_R02.py'),
      'R04':member(root,'05_RECALCULO/recalcular_cadena_R04.py'),
      'references':member(root,'05_RECALCULO/referencias_tarea_R02.py'),
      'R05':member(root,LAYOUT['R05']+'/RECALCULAR_COLA_R05_PORTABLE.py'),
      'CORTE':member(root,LAYOUT['CORTE']+'/RECALCULAR_CADENA_CORTE.py')}
    for script in scripts.values():audit_imports(script)
    # Source-containing JSON strings, absolute provenance paths, and private
    # evaluator metadata are read as data only. No path from them is opened.
    destination=args.destino.expanduser().resolve(strict=False)
    require(not destination.exists(),'Fresh nonexistent destination required; no overwrite')
    require(not destination.is_relative_to(root)and not root.is_relative_to(destination),'Destination must be separate from dossier tree')
    require(destination.parent.exists()and destination.parent.is_dir(),'Destination parent must exist')
    current=destination.parent
    while True:
        require(not reparse(current),'Destination ancestor must not be link/junction')
        if current.parent==current:break
        current=current.parent
    destination.mkdir()
    jobs=[('R02',[str(scripts['R02']),'--evidence',str(evidence['R02']),'--out',str(destination/'R02'),'--references',str(scripts['references'])]),
          ('R04',[str(scripts['R04']),'--evidence',str(evidence['R04']),'--base-evidence',str(evidence['R02']),'--out',str(destination/'R04')]),
          ('R05',[str(scripts['R05'])]),('CORTE',[str(scripts['CORTE'])])]
    results=[]
    for label,arguments in jobs:
        command=[sys.executable,'-I','-B','-X','utf8']+arguments
        proc=subprocess.run(command,cwd=str(root),capture_output=True,text=True,encoding='utf-8',timeout=120)
        (destination/(label+'_STDOUT.txt')).write_text(proc.stdout,encoding='utf-8')
        (destination/(label+'_STDERR.txt')).write_text(proc.stderr,encoding='utf-8')
        require(proc.returncode==0,'Documentary recalculation failed '+label+'; preserved output in '+str(destination))
        result=json.loads(proc.stdout)
        (destination/(label+'_RESULTADO.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        results.append({'family':label,'returncode':proc.returncode,'mode':'DOCUMENTARY_RECALCULATION_NOT_NATIVE','result':result})
    require(member(root,GLOBAL_MANIFEST).read_bytes()==manifest_bytes,'Global manifest changed while reading')
    require(verify_records(root,manifest['content'])==verified,'Dossier content changed during recalculation')
    report={'schema':'DEE.PI03.combined_portable_recalculation.v1','scope':'Existing exported records and actual bytes only; no Native evolution or experimental reproduction',
            'global_manifest_sha256':sha(manifest_bytes),'content_members_verified_before_and_after':len(verified),
            'source_path_fields_opened':False,'nonstdlib_imports_permitted':False,'native_ticks':0,'DEE_imports':0,
            'outputs':str(destination),'results':results}
    (destination/'RESULTADO_EXPEDIENTE_PI03.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'verified_members':len(verified),'families':[x['family']for x in results],'mode':'DOCUMENTARY_RECALCULATION_NOT_NATIVE','new_native_ticks':0,'output':str(destination)},ensure_ascii=False))
if __name__=='__main__':main()
