"""Portable R04 addon recalculation; requires shared R02 evidence and helper.

No DEE imports, world opening, SQLite, network, or Native evolution. This checks
exported primary observations, exact journal prefixes, codecs and actual bytes.
python recalcular_cadena_R04.py --evidence EVIDENCIA_R04_PORTABLE \
 --base-evidence EVIDENCIA_R02_PORTABLE --out RECALCULO_R04
Keep recalcular_tarea_R02.py beside this file (pure stdlib helper).
"""
from pathlib import Path
import argparse,csv,gzip,hashlib,io,json,runpy,zlib

def sha(b):return hashlib.sha256(b).hexdigest()
def require(c,m):
 if not c:raise ValueError(m)
def jsonbytes(v):return json.dumps(v,ensure_ascii=False,indent=2).encode('utf8')
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--evidence',type=Path,required=True);ap.add_argument('--base-evidence',type=Path,required=True)
 ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
 root=args.evidence.resolve(strict=True);base=args.base_evidence.resolve(strict=True)
 require(not args.out.exists(),'New output required; preserve earlier results')
 h=runpy.run_path(str(Path(__file__).with_name('recalcular_tarea_R02.py')),run_name='shared_pure_R02_helpers')
 load,raw,decoded=h['load'],h['bytesof'],h['decoded']
 for home in(root,base):
  for x in load(home,'MANIFEST.json')['members']:
   b=raw(home,x['file']);require(len(b)==x['bytes']and sha(b)==x['sha256'],'Manifest member mismatch '+x['file'])
 ref=load(root,'base_reference.json');require(sha(raw(base,'MANIFEST.json'))==ref['base_manifest_sha256'],'Wrong R02 base')
 p=load(root,'protocol.json');r01=load(base,'r01_protocol.json');p02=load(base,'protocol.json')
 baseline=h['analyze_arm'](base,'real',p02,r01,h['specs'](p02))
 old=load(base,'arms/real/native_task_metadata.json');old=json.loads(old['metadata_value_exact'])
 meta_proof=load(root,'native_task_metadata.json.gz');txt=meta_proof['metadata_value_exact']
 require(sha(txt.encode())==meta_proof['metadata_value_sha256'],'Metadata string hash differs');m=json.loads(txt)
 require(m['opportunity']==19 and len(m['rows'])==19 and len(m['schedule'])==21,'Final Native counts differ')
 require(m['rows'][:14]==old['rows']and m['schedule'][:14]==old['schedule'],'Original Native history not preserved')
 summary=load(root,'execution_summary.json.gz');require(summary['status']=='COMPLETED'and summary['closed'],'R04 incomplete')
 d=load(root,'device_state.json');old_d=load(base,'arms/real/device_state.json')
 require(d['opportunity']==19 and len(d['capsules'])==21 and len(d['products'])==15 and len(d['rejections'])==4,'Final external counts differ')
 require(d['pending']is None and d['feedback_pending']is None and not d['uncertain']and d.get('supply_pending')is None,'Unresolved device operation')
 require(m['pending']is None and not m['uncertain']and m.get('supply_pending')is None,'Unresolved Native task operation')
 for k in('capsules','products','rejections','blocks'):
  require(d[k][:len(old_d[k])]==old_d[k],'Old device prefix changed '+k)
 def journal(prefix_name,suffix_name,count,chain=None):
  a=decoded(base,'arms/real/'+prefix_name);b=decoded(root,suffix_name);data=a+b;c='00'*32;events=[]
  key='task'if prefix_name.startswith('task')else'device'
  require(len(a)==ref[key+'_prefix_bytes']and sha(a)==ref[key+'_prefix_sha256'],'Wrong shared journal prefix')
  require(data.endswith(b'\n'),'Truncated journal')
  for i,line in enumerate(data.splitlines(keepends=True)):
   e=json.loads(line);require(e['index']==i,'Journal index gap');events.append(e);c=sha(bytes.fromhex(c)+line)
  require(len(events)==count,'Journal count differs')
  if chain:require(c==chain,'Native-bound journal chain differs')
  return events,{'events':len(events),'sha256':sha(data),'chain_sha256':c,'shared_prefix_bytes':len(a),'addon_suffix_bytes':len(b)}
 events,jproof=journal('task_events.jsonl.gz','task_events_suffix.jsonl.gz',m['log_count'],m['log_chain_sha256'])
 dev_events,devproof=journal('device_events.jsonl.gz','device_events_suffix.jsonl.gz',d['events'])
 maps=load(root,'device_file_map.json')['files'];logical={x['logical_path']:x for x in maps}
 require(len(maps)==len(logical),'Duplicate logical file')
 def blob(item):
  require(item['blob_root']in('base','addon'),'Unknown blob root')
  b=raw(base if item['blob_root']=='base'else root,item['blob'])
  require(len(b)==item['bytes']and sha(b)==item['sha256'],'Device file blob differs');return b
 for item in maps:blob(item)
 receipts={};sources=[];source_payload={};opentries=[];current_tick=baseline['last_tick']
 for case,expected in zip(summary['cases'],p['cases']):
  require(case['label']==expected['label']and case.get('owner_closed'),'Case/protocol/closure differs')
  name='PI03_R04_'+case['label']+'_FUENTE_Y_OFERTAS.json.gz'
  outer=load(root,'primaries/'+name);require(outer['status']=='completed','Source primary incomplete')
  v=json.loads(outer['result']);require(v==case['source'],'Source primary/summary differs')
  row=v['result']['rows'][0];s=row['supply']['source'];cfg=expected['supply'];a,b=s['first'],s['second']
  require(row['before']['tick']==current_tick==v['before_tick'],'Source genealogy discontinuity')
  require(a['before']['tick']==current_tick and a['after']==b['before']and b['after']['tick']==v['after_tick'],'Two Native calls do not share sequential physical boundary')
  q=dict(p02);q['native_arithmetic']={'first_operation':'suma','first_operands':[cfg['izquierda'],cfg['derecha']],
     'second_operation':'diferencia','second_right_operand':cfg['restar']}
  payload,source_proof=h['arithmetic_source'](s,q)
  require(s['literal_public_operands']=={k:cfg[k]for k in('izquierda','derecha','restar')},'Public source literals differ')
  require(row['new_native_ticks']==v['after_tick']-v['before_tick']==396,'Unexpected two-operation Native horizon')
  require(row['historical_prefix_preserved']and row['supply']['not_reserved_evaluation'],'Supply resets history or relabels R02 reserve')
  supply=row['supply'];require(supply['quantity']==expected['offers']==cfg['cantidad']and supply['connection']==cfg['conexion']and supply['delay_laps']==cfg['demora_periodos'],'Supply differs from fixed R04 protocol')
  source_proof.update(case=case['label'],before_tick=v['before_tick'],after_tick=v['after_tick'],
   first_numeric_observation_s_reg=a['numeric_reader']['observation']['s_reg'],second_numeric_observation_s_reg=b['numeric_reader']['observation']['s_reg'],
   second_representation_bias=b['numeric_reader']['representation_bias'],attribution='Operator-selected assisted two-operation chain. Actual first result is second input; actual final result is byte payload. Q never chooses the operations or derives a feeder action from numeric content.')
  sources.append(source_proof);h['collect_native_receipts'](s,receipts)
  for i in range(supply['first_resource_index'],supply['first_resource_index']+supply['quantity']):source_payload[i]=payload
  current_tick=v['after_tick']
  require(len(case['opportunities'])==expected['offers'],'Missing R04 opportunity')
  for item in case['opportunities']:
   out=load(root,'primaries/'+Path(item['primary']).name+'.gz');require(out['status']=='completed','Opportunity incomplete')
   value=json.loads(out['result']);require(value==item['result'],'Opportunity primary differs from summary')
   rr=value['result']['rows'][0];opentries.append((case['label'],cfg,rr,value));require(rr['before_tick']==current_tick,'R04 genealogy gap')
   current_tick=rr['after_tick']
 # Two explicitly supplied final offers reuse actual13; neither is scored.
 stock=load(root,'primaries/PI03_R04_FINAL_STOCK_EXPLICIT.json.gz');stock=json.loads(stock['result'])
 require(stock==summary['final_explicit_supply'],'Stock primary/summary differs');sr=stock['result']['rows'][0]
 require(sr['before']==sr['after']and sr['new_native_ticks']==0 and sr['old_opportunity_unchanged']==19 and sr['remaining_offers']==2,'Final supply modified Native/time/consumed counters')
 final_payload=sources[-1]['second_actual'].to_bytes(2,'little')+bytes(62)
 for i in range(sr['supply']['first_resource_index'],len(d['capsules'])):source_payload[i]=final_payload
 require(current_tick==summary['final_tick']==meta_proof['whole_world_view']['physical']['tick']==768317,'Final cut discrepancy')
 original_payload=baseline['source_chain']['second_actual'].to_bytes(2,'little')+bytes(62)
 for i in range(14):source_payload[i]=original_payload
 products={x['index']:x for x in d['products']};rejected={x['index']:x for x in d['rejections']}
 require(set(products).isdisjoint(rejected)and set(products)|set(rejected)==set(range(19)),'Consumed resource coverage differs')
 for i,cap in enumerate(d['capsules']):
  locations=[k for k in logical if k.endswith('/'+cap['name'])];require(len(locations)==1,'Capsule missing/duplicated')
  data=blob(logical[locations[0]]);require(len(data)==cap['compressed_bytes']and sha(data)==cap['compressed_sha256'],'Encoded resource differs')
  payload=zlib.decompress(data);require(payload==source_payload[i]and sha(payload)==cap['decoded_sha256'],'Actual Native payload not conserved')
  if i>=19:require(locations[0].startswith('reservoir/'),'Unused stock not actually available')
  if i in products:
   pr=products[i];data=blob(logical[pr['path']]);require(data==payload and len(data)==pr['bytes']==64 and sha(data)==pr['sha256'],'Useful product bytes differ')
 rows=[]
 for label,cfg,r,value in opentries:
  i=r['opportunity'];mr=m['rows'][i]
  require(i==14+len(rows)and mr=={'opportunity':i,'spec':r['spec'],'reader_choice':r['reader']['choice'],
   'useful_product':r['useful_product'],'effect_sha256':r['actual_effect']['actual_product_sha256'],'after_tick':r['after_tick']},'Native final compact history/new primary differs')
  done=[e for e in events if e.get('kind')=='OPPORTUNITY_COMPLETED'and e['result']['opportunity']==i]
  require(len(done)==1 and done[0]['result']==r,'Journal/new primary differs')
  choice=h['reader_choice'](r['reader'],r01['origin']);motor=r01['zero_motor']if choice==0 else choice
  require(choice is not None and r['emitted_motor']==r['applied_motor']==motor,'Fixed reader/motor differs')
  useful=motor==cfg['conexion'];effect=r['actual_effect'];c=r['calendar'];cons=effect['consequence_tick']
  require(useful==r['useful_product']==(not effect['failed'])and r['returned_failed']==effect['failed'],'Device law/generic return differs')
  require(c['delay_laps']==cfg['demora_periodos']and c['delay_ticks']==67*cfg['demora_periodos'],'Fixed temporal supply differs')
  require(cons==c['outcome_injection_tick']-1 and cons-r['reader']['tick']==c['delay_ticks']-1,'Actual delayed consequence timing differs')
  require(r['after_tick']-r['before_tick']<=p02['max_ticks_per_opportunity'],'Frozen opportunity horizon exceeded')
  outcomes=[x for x in r['requests']if '.outcome.'in x['channel']]
  require(len(r['requests'])==5 and len(outcomes)==1,'Required Native dose differs')
  outcome=outcomes[0];require(outcome['channel']==r01['prefix']+('.outcome.failure'if effect['failed']else'.outcome.nonfailure'),'Return routes by chosen action instead of generic outcome')
  require(all(x['receipt']['status']=='applied'and x['id']==x['receipt']['id']and x['requested_tick']==x['receipt']['effective_tick']for x in r['requests']),'Required admission rejected/pending/mistimed')
  h['collect_native_receipts'](r['requests'],receipts)
  ae=[e for e in dev_events if e.get('kind')=='ACTUATOR_APPLIED'and e.get('opportunity')==i]
  de=[e for e in dev_events if e.get('kind')=='DELAYED_CONSEQUENCE'and e['actual_material_result']['index']==i]
  require(len(ae)==len(de)==1 and ae[0]['actual_motor']==motor and ae[0]['action_tick']==r['reader']['tick']and de[0]['tick']==cons and de[0]['failed']==effect['failed'],'External actual events differ')
  if useful:require(effect['actual_product_sha256']==sha(source_payload[i])and effect['actual_product_bytes']==64 and i in products,'Actual useful output does not carry Native data')
  else:require(effect['actual_product_bytes']==0 and i in rejected,'Failure represented as product')
  rows.append({'stage':'R04_'+label,'life':summary['life'],'opportunity':i,'before_tick':r['before_tick'],'after_tick':r['after_tick'],
   'reader_choice':choice,'material_zero':choice==0,'emitted_motor':motor,'connected_motor_evaluator_only':cfg['conexion'],
   'useful_product':useful,'actual_payload_integer':int.from_bytes(source_payload[i][:2],'little'),'actual_product_bytes':effect['actual_product_bytes'],
   'delay_laps':c['delay_laps'],'action_to_actual_consequence_ticks':cons-r['reader']['tick'],'consequence_to_native_input_ticks':c['outcome_injection_tick']-cons,
   'new_native_ticks':r['after_tick']-r['before_tick'],'bank_before':[x['s_reg']for x in r['bank_before']],
   'bank_after':[x['s_reg']for x in r['bank_after']],'generic_outcome_port':outcome['channel'],'required_inputs_applied':len(r['requests'])})
 combined=baseline['rows']+rows;wsls=-1;wsls_matches=0;reference_products=0
 for i,r in enumerate(combined):
  native=r.get('emitted_motor');connection=r['connected_motor_evaluator_only'];success=wsls==connection
  wsls_matches+=native==wsls;reference_products+=success
  if not success:wsls=-wsls
  if i>=14:r['verified_future_R04_products_after']=sum(v['useful_product']for v in rows[i-13:])
 rs=h['receipts_summary'](receipts)
 report={'schema':'DEE.PI03.portable_variable_chain.recalculated.R04','mode':'Passive recalculation of existing records; zero Native execution',
  'life':summary['life'],'parent_stage_end':baseline['last_tick'],'final_cut':current_tick,'source_chains':sources,
  'R04_offered':5,'R04_completed':len(rows),'R04_formed':len(rows),'R04_NULL':0,'R04_material_zero':sum(r['material_zero']for r in rows),
  'R04_products':sum(r['useful_product']for r in rows),'R04_product_bytes':sum(r['actual_product_bytes']for r in rows),
  'R04_failures':[r['opportunity']for r in rows if not r['useful_product']],
  'cumulative_completed':19,'cumulative_products':len(products),'cumulative_rejections':len(rejected),'total_capsules':len(d['capsules']),'unused_actual_capsules':2,
  'old14_rows_and_device_prefixes_exact':True,'total_source_native_ticks':792,'new_opportunity_ticks':sum(r['new_native_ticks']for r in rows),
  'new_native_receipts_deduplicated':rs,'task_journal':jproof,'device_journal':devproof,
  'cumulative_WSLS_reference':{'algorithm':'Maintain after own success, switch after own failure; start−1; only prior own consequence',
    'matches_native_actions':wsls_matches,'opportunities':19,'analytical_products':reference_products,'Native_or_filesystem_reference_execution':False},
  'snapshot_provenance':{k:meta_proof[k]for k in('source_snapshot','source_snapshot_sha256','whole_world_view')},
  'rows':rows,'limits':['R04 is a five-offer additional stage with new public data and3/4-lap delays, not an independent organism or a relabeled R02 reserve.',
    'Operator chose arithmetic operations, their order, source operands, supplies and fixed device law. Q selected only feeder motor from its physical history, not mathematical operations or number-specific routes.',
    'The two zero readings are active material zero mapped to motor−1; none is NULL.',
    'No Native R04 source-link ablation was executed. The separate pure contract cut test is not Native evidence; R02 actuator-null controls the actuator, not arithmetic transport.',
    'No new12-function panel is demonstrated by these records; later diagnostics must be reported at their own cut.',
    'Byte verification and primary/journal recalculation are not a fresh Native world replay. Physical hashes identify frozen source snapshots; no equality-hash memory inference is made.']}
 args.out.mkdir(parents=True)
 (args.out/'RECALCULO_CADENA_R04.json').write_bytes(jsonbytes(report))
 fields=list(rows[0]);out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=fields);writer.writeheader();writer.writerows(rows)
 (args.out/'TRAYECTORIA_ADICIONAL_R04.csv').write_text(out.getvalue(),encoding='utf8',newline='')
 matrix=[{'momento':'R02_cerrado','T':baseline['last_tick'],'ofertas_preparadas':14,'consumidas':14,'productos':11,'rechazos':3,'stock_disponible':0,'panel_12_en_ese_corte':'No; procede de otro corte'},
  {'momento':'R04_cerrado','T':current_tick,'ofertas_preparadas':21,'consumidas':19,'productos':15,'rechazos':4,'stock_disponible':2,'panel_12_en_ese_corte':'No incluido en estos registros'}]
 out=io.StringIO(newline='');writer=csv.DictWriter(out,fieldnames=list(matrix[0]));writer.writeheader();writer.writerows(matrix)
 (args.out/'MATRIZ_ANTES_DESPUES_R02_R04.csv').write_text(out.getvalue(),encoding='utf8',newline='')
 print(json.dumps({k:report[k]for k in('life','final_cut','R04_products','cumulative_products','unused_actual_capsules','old14_rows_and_device_prefixes_exact','cumulative_WSLS_reference')},ensure_ascii=True))
if __name__=='__main__':main()
