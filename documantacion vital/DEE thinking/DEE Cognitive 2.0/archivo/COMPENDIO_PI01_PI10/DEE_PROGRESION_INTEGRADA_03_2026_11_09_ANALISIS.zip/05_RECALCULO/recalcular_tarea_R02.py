"""Portable R02 analysis from exported records only; no DEE, Native or network.

Usage: python recalcular_tarea_R02.py --evidence EVIDENCIA_R02_PORTABLE --out RECALCULO_R02
Keep referencias_tarea_R02.py beside this script (or pass --references).
The evidence is an analysis export, not a backup of the operational Native life.
"""
from __future__ import annotations
import argparse,csv,gzip,hashlib,io,json,runpy,zlib
from pathlib import Path,PurePosixPath

ARMS=('real','return_nonfailure','actuator_null')
def sha(b):return hashlib.sha256(b).hexdigest()
def require(condition,message):
    if not condition:raise ValueError(message)
def member(root,name):
    rel=PurePosixPath(name)
    require(not rel.is_absolute()and':'not in name and'\\'not in name and not any(p in('.', '..')for p in rel.parts),'Unsafe member')
    p=(root/rel).resolve(strict=True)
    require(p.is_relative_to(root.resolve())and p.is_file()and not p.is_symlink(),'Unsafe member target')
    return p
def bytesof(root,name):return member(root,name).read_bytes()
def decoded(root,name):
    b=bytesof(root,name)
    return gzip.decompress(b)if b[:2]==b'\x1f\x8b'else b
def load(root,name):return json.loads(decoded(root,name))
def write_json(path,value):
    with path.open('x',encoding='utf8')as f:json.dump(value,f,ensure_ascii=False,indent=2)
def exact_observation(o):
    raw,clock=int(o['raw']),int(o['clock'])
    require(0<=raw<2**64 and 0<=clock<2**64,'Observation uint64 range')
    require((raw&0xffffffff)==int(o['state'])and((raw>>32)&65535)==int(o['s_reg'])and((raw>>60)&15)==int(o['semantic']),'Decoded observation/RAW differs')
    return{'site':tuple(o['site']),'raw':str(raw),'clock':str(clock),'state':int(o['state']),
           's_reg':int(o['s_reg']),'semantic':int(o['semantic']),'direction':list(map(int,o['direction']))}
def reader_choice(reader,origin):
    found=[];seen=set()
    for raw in reader['observations']:
        o=exact_observation(raw);seen.add(o['site'])
        for sign in(-1,0,1):
            site=tuple((origin[k]+(2*sign,2,0)[k])%67 for k in range(3))
            if o['site']==site and o['state']>0 and o['semantic']==1 and o['direction']==[sign,1,0]:found.append(sign)
    expected={tuple((origin[k]+(2*sign,2,0)[k])%67 for k in range(3))for sign in(-1,0,1)}
    require(seen==expected,'Frozen reader requires exactly its three fixed sites')
    choice=found[0]if len(found)==1 else None
    require(choice==reader['choice'],'Recorded/decoded choice mismatch')
    return choice
def collect_native_receipts(obj,store):
    if isinstance(obj,dict):
        if 'id'in obj and'status'in obj and'channels'in obj and str(obj['id']).isdigit():
            i=str(obj['id']);store.setdefault(i,[]).append(obj)
        for v in obj.values():collect_native_receipts(v,store)
    elif isinstance(obj,list):
        for v in obj:collect_native_receipts(v,store)
def receipts_summary(store):
    counts={};rows=[]
    for identifier,captures in sorted(store.items(),key=lambda x:int(x[0])):
        statuses={str(r['status'])for r in captures}
        terminal={s for s in statuses if s!='scheduled'}
        require(len(terminal)<=1,'Contradictory terminal Native receipt '+identifier)
        status=next(iter(terminal))if terminal else'scheduled'
        counts[status]=counts.get(status,0)+1
        rows.append({'id':identifier,'terminal_status':status,'captures':len(captures)})
    return{'unique_ids':len(rows),'status_counts':counts,'ids':rows,
           'scope':'Only Native receipts present in exact arithmetic-source records and14task results. Alias captures deduplicated; inherited historical receipts and transport requests are not new events.'}
def specs(protocol):
    out=[]
    for series in('development','reserved'):
        f=protocol['fixtures'][series];local=0
        for b in f['blocks']:
            for _ in range(b['opportunities']):
                out.append({'series':series,'index_within_series':local,'delay_laps':f['delay_laps'][local],
                            'connected_motor':b['connected_motor']});local+=1
        require(local==len(f['delay_laps']),'Fixture count mismatch')
    return out
def journal(root,name,expected_count=None,expected_chain=None):
    b=decoded(root,name);require(b.endswith(b'\n'),'Incomplete JSONL line')
    chain='00'*32;events=[]
    for i,line in enumerate(b.splitlines(keepends=True)):
        e=json.loads(line);require(e['index']==i,'Journal index gap')
        chain=sha(bytes.fromhex(chain)+line);events.append(e)
    if expected_count is not None:require(len(events)==expected_count,'Native metadata/journal count mismatch')
    if expected_chain is not None:require(chain==expected_chain,'Native metadata/journal chain mismatch')
    return events,{'bytes':len(b),'sha256':sha(b),'events':len(events),'computed_chain':chain}
def arithmetic_source(source,protocol):
    require(source['kind']=='assisted_native_arithmetic_data_chain','Unexpected resource source')
    a,b=source['first'],source['second'];c=protocol['native_arithmetic']
    for r in(a,b):
        nr=r['numeric_reader'];obs=exact_observation(nr['observation'])
        require(nr['fixed_site_direction_valid']and not nr['abstention'],'Invalid numeric signature')
        # Published aritmetica_apd_01.numeric_readout subtracts the32 bias for
        # difference; sum has bias0. This is a fixed decoder, not a fitted rule.
        require(obs['s_reg']-nr['representation_bias']==r['numeric_result']==nr['numeric_result'],'Native numeric observation differs')
        require(not r['provider_called']and not r['teacher_delivered']and not r['fallback_to_failed_request'],'Arithmetic used provider/teacher/fallback')
    require(a['literal_operator_request']['operacion']==c['first_operation'],'First operation differs')
    require([a['literal_operator_request']['izquierda'],a['literal_operator_request']['derecha']]==c['first_operands'],'First public operands differ')
    require(b['literal_operator_request']['izquierda']==a['numeric_result'],'Actual first result not transported')
    require(b['literal_operator_request']['derecha']==c['second_right_operand']and b['literal_operator_request']['operacion']==c['second_operation'],'Second operation differs')
    require(source['actual_final_result']==b['numeric_result'],'Actual final source differs')
    payload=source['actual_final_result'].to_bytes(2,'little')+bytes(62)
    require(len(payload)==source['payload_bytes']==64 and sha(payload)==source['payload_sha256'],'Source64B codec mismatch')
    # Reference arithmetic is evaluated AFTER all Native recorded outputs, never fed back.
    expected_first=sum(c['first_operands']);expected_second=expected_first-c['second_right_operand']
    return payload,{'first_actual':a['numeric_result'],'second_actual_left':b['literal_operator_request']['izquierda'],
                    'second_actual':b['numeric_result'],'source_payload_sha256':sha(payload),
                    'matches_arithmetic_reference':a['numeric_result']==expected_first and b['numeric_result']==expected_second,
                    'attribution':'Prepared arithmetic and operator-chosen chain; actual Native9→7 transported unchanged. No discovered plan or learned arithmetic algorithm.'}

def analyze_arm(root,arm,protocol,r01,opportunities):
    home='arms/'+arm+'/'
    summary=load(root,home+'summary.json.gz');require(summary['status']=='COMPLETED'and len(summary['rows'])==14,'Arm not closed14')
    admission=load(root,home+'admission.json.gz');source=admission['result']['rows'][0]['resource_source']
    payload,source_result=arithmetic_source(source,protocol)
    native_meta=load(root,home+'native_task_metadata.json')
    text=native_meta['metadata_value_exact'];require(sha(text.encode())==native_meta['metadata_value_sha256'],'Metadata extract hash mismatch')
    meta=json.loads(text)
    require(meta['protocol_sha256']==sha(bytesof(root,'protocol.json')),'Native task protocol hash differs')
    require(meta['opportunity']==14 and meta['pending']is None and not meta['uncertain'],'Incomplete bound Native progress')
    events,journal_proof=journal(root,home+'task_events.jsonl.gz',meta['log_count'],meta['log_chain_sha256'])
    device=load(root,home+'device_state.json');dev_events,dev_journal=journal(root,home+'device_events.jsonl.gz',device['events'])
    require(device['opportunity']==14 and device['pending']is None and device['feedback_pending']is None and not device['uncertain'],'Device progress incomplete')
    fmap=load(root,home+'device_file_map.json')['files'];logical={r['logical_path']:r for r in fmap}
    require(len(logical)==len(fmap),'Duplicate logical device file identity')
    for item in fmap:
        data=bytesof(root,item['blob'])
        require(len(data)==item['bytes']and sha(data)==item['sha256'],'Exported device blob differs')
    product_map={r['index']:r for r in device['products']};rejected_map={r['index']:r for r in device['rejections']}
    require(set(product_map).isdisjoint(rejected_map)and set(product_map)|set(rejected_map)==set(range(14)),'Missing/duplicate consumed capsule')
    for i,cap in enumerate(device['capsules']):
        locations=[p for p in logical if p.endswith('/'+cap['name'])]
        require(len(locations)==1,'Encoded capsule must occupy exactly one logical location')
        encoded=bytesof(root,logical[locations[0]]['blob'])
        require(len(encoded)==cap['compressed_bytes']and sha(encoded)==cap['compressed_sha256'],'Encoded capsule differs')
        decoded_payload=zlib.decompress(encoded)
        require(decoded_payload==payload and sha(decoded_payload)==cap['decoded_sha256'],'Actual source payload not conserved in capsule')
    all_receipts={};collect_native_receipts(source,all_receipts)
    rows=[];cumulative=0
    for i,spec in enumerate(opportunities):
        outer=load(root,home+'primaries/'+('%02d.json.gz'%i));require(outer['status']=='completed','Material request not completed')
        value=json.loads(outer['result']);r=value['result']['rows'][0]
        require(r['opportunity']==i and r['control']==arm and r['spec']=={k:spec[k]for k in('series','index_within_series','delay_laps')},'Frozen schedule differs')
        completed=[e for e in events if e.get('kind')=='OPPORTUNITY_COMPLETED'and e['result']['opportunity']==i]
        require(len(completed)==1 and completed[0]['result']==r,'Primary/journal result differs')
        choice=reader_choice(r['reader'],r01['origin']);emitted=r01['zero_motor']if choice==0 else choice
        sr=summary['rows'][i]
        require(sr['before_tick']==r['before_tick']and sr['after_tick']==r['after_tick']and sr['choice']==choice,'Summary/primary chronology or choice differs')
        if i:require(r['before_tick']==rows[-1]['after_tick'],'Cumulative life tick discontinuity')
        require(r['emitted_motor']==emitted,'Motor codec differs')
        applied=None if arm=='actuator_null'else emitted;require(r['applied_motor']==applied,'Actuator treatment differs')
        useful=applied==spec['connected_motor'];effect=r['actual_effect'];require(useful==(not effect['failed'])==r['useful_product'],'Actual device effect differs from fixed law')
        returned=False if arm=='return_nonfailure'else effect['failed'];require(r['returned_failed']==returned,'Generic return treatment differs')
        c=r['calendar'];action_tick=r['reader']['tick'];cons=effect['consequence_tick']
        require(c['delay_ticks']==67*spec['delay_laps']and c['collision_tick']-c['seed_tick']==c['delay_ticks'],'Delay law differs')
        require(cons==c['outcome_injection_tick']-1 and action_tick==c['query_read_tick'],'Action/consequence times differ')
        require(cons-action_tick==67*spec['delay_laps']-1,'Actual deferred consequence delay differs')
        require(r['after_tick']-r['before_tick']<=protocol['max_ticks_per_opportunity'],'Opportunity exceeded frozen horizon')
        outcome=[x for x in r['requests']if '.outcome.'in x['channel']]
        require(len(outcome)==1 and outcome[0]['channel']==r01['prefix']+('.outcome.failure'if returned else'.outcome.nonfailure'),'Generic outcome port differs')
        require(outcome[0]['requested_tick']==c['outcome_injection_tick']and outcome[0]['actual_environment_failed']==returned,'Generic return timing/content differs')
        require(all(x['receipt']['status']=='applied'for x in r['requests']),'Rejected/pending required input')
        require(all(x['id']==x['receipt']['id']and x['requested_tick']==x['receipt']['requested_tick']==x['receipt']['effective_tick']for x in r['requests']),'Receipt identity or admission time differs')
        applied_events=[e for e in dev_events if e.get('kind')=='ACTUATOR_APPLIED'and e.get('opportunity')==i]
        require(len(applied_events)==1 and applied_events[0]['actual_motor']==applied and applied_events[0]['action_tick']==action_tick and applied_events[0]['ready_tick']==cons,'Actual actuator journal differs')
        effects=[e for e in dev_events if e.get('kind')=='DELAYED_CONSEQUENCE'and e['actual_material_result']['index']==i]
        require(len(effects)==1 and effects[0]['tick']==cons and effects[0]['failed']==effect['failed'],'Delayed effect journal differs')
        scheduled=[e for e in dev_events if e.get('kind')=='GENERIC_FEEDBACK_SCHEDULED'and e['native_request']['id']==outcome[0]['id']]
        applied_returns=[e for e in dev_events if e.get('kind')=='GENERIC_FEEDBACK_APPLIED'and e['receipt']['id']==outcome[0]['id']]
        require(len(scheduled)==len(applied_returns)==1,'Generic return lacks one scheduled/applied device event')
        collect_native_receipts(r['requests'],all_receipts)
        if useful:
            p=product_map[i];require(p['path']in logical,'Missing decoded product')
            data=bytesof(root,logical[p['path']]['blob'])
            require(data==payload and len(data)==p['bytes']==64 and sha(data)==p['sha256']==effect['actual_product_sha256'],'Actual useful product differs')
            require(effect['actual_product_bytes']==64,'Useful byte count differs')
        else:require(i in rejected_map and effect['actual_product_bytes']==0,'Rejected resource masquerades as product')
        cumulative+=int(useful)
        # Every comparison is after actual outcomes; none feeds E1.
        rows.append({'arm':arm,'life':summary['life'],'opportunity':i,'series':spec['series'],
                     'before_tick':r['before_tick'],'after_tick':r['after_tick'],'delay_laps':spec['delay_laps'],
                     'reader_choice':'NULL'if choice is None else choice,'material_zero':choice==0,
                     'emitted_motor':emitted,'applied_motor':applied,'connected_motor_evaluator_only':spec['connected_motor'],
                     'useful_product':useful,'cumulative_products':cumulative,'available_capsules_after':13-i,
                     'valid_response':choice is not None,'actual_failure':effect['failed'],'returned_failed':returned,
                     'new_native_ticks':r['after_tick']-r['before_tick'],
                     'query_wait_ticks':action_tick-r['before_tick'],'action_to_actual_consequence_ticks':cons-action_tick,
                     'consequence_to_native_input_ticks':c['outcome_injection_tick']-cons,
                     'action_to_bank_contact_ticks':c['contact_tick']-action_tick,
                     'required_native_inputs':len(r['requests']),'requests_all_applied':True,
                     'bank_before':[x['s_reg']for x in r['bank_before']],
                     'bank_after':[x['s_reg']for x in r['bank_after']]})
    for row in rows:row['verified_future_products_after']=cumulative-row['cumulative_products']
    require(cumulative==summary['actual_products']==len(device['products']),'Product summary mismatch')
    require(sum(r['material_zero']for r in rows)==summary['denominators']['material_zero_codec_uses'],'Materialzero denominator differs')
    return{'arm':arm,'life':summary['life'],'first_tick':rows[0]['before_tick'],'last_tick':rows[-1]['after_tick'],
            'offered':14,'completed':14,'formed':sum(r['valid_response']for r in rows),'NULL':sum(not r['valid_response']for r in rows),
            'material_zero':sum(r['material_zero']for r in rows),'products':cumulative,
            'verified_product_bytes':64*cumulative,'failed_actual_effects':14-cumulative,
            'remaining_capsules':len(device['capsules'])-device['opportunity'],
            'products_by_horizon':{str(h):sum(r['useful_product']for r in rows[:h])for h in(3,6,10,14)},
            'source_chain':source_result,'native_receipts':receipts_summary(all_receipts),
            'task_journal':journal_proof,'device_journal':dev_journal,
            'full_snapshot_local_provenance':{k:native_meta[k]for k in('source_snapshot','source_snapshot_sha256','whole_world_view')},
            'rows':rows,'interpretation':'Fourteen opportunities share one Native history with6/8close-reopen. Sibling controls share a prefix; neither opportunities nor clones are independent organisms.'}

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--evidence',type=Path,required=True);ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--references',type=Path,default=Path(__file__).with_name('referencias_tarea_R02.py'))
    args=ap.parse_args();root=args.evidence.resolve(strict=True)
    require(not args.out.exists(),'Fresh output directory required; preserve previous recalculation')
    manifest=load(root,'MANIFEST.json')
    for item in manifest['members']:
        b=bytesof(root,item['file']);require(len(b)==item['bytes']and sha(b)==item['sha256'],'Manifest mismatch '+item['file'])
    protocol=load(root,'protocol.json');r01=load(root,'r01_protocol.json');spec=specs(protocol)
    require(len(spec)==14,'Expected frozen14opportunities')
    frozen=load(root,'references_frozen.json');require(sha(args.references.read_bytes())==frozen['sha256'],'Reference code differs from pre-controls freeze')
    ref=runpy.run_path(str(args.references),run_name='frozen_reference_library')['run'](protocol)
    found=[a for a in ARMS if(root/'arms'/a/'summary.json.gz').is_file()]
    arms=[analyze_arm(root,a,protocol,r01,spec)for a in found]
    real=next((a for a in arms if a['arm']=='real'),None)
    comparisons=[]
    if real:
        for arm in arms:
            if arm['arm']=='real':continue
            comparisons.append({'arms':['real',arm['arm']],'products':[real['products'],arm['products']],
                                'product_difference':real['products']-arm['products'],
                                'same14_opportunities':True,'scope':'Shared-prefix controlled futures, not independent replicates; environment consequences follow actual distinct actions.'})
    result={'schema':'PI03.portable_task_R02_recalculation.v1','mode':'RECORDED_DATA_RECALCULATION_NOT_NATIVE_REPLAY',
            'found_arms':found,'missing_arms':[a for a in ARMS if a not in found],'arms':arms,
            'paired_comparisons':comparisons,'references':ref,
            'code_sha256':sha(Path(__file__).read_bytes()),'manifest_sha256':sha(bytesof(root,'MANIFEST.json')),
            'limits':['Reference scores are analytical under frozen law, not experiments controlling E1.',
                      'Zero is a material reading mapped to preparedmotor−1; NULL is not action.',
                      'Arithmetic9→7 and task sequence are operator-prepared; Native supplies actual outputs and learned relative selection.',
                      'Snapshot hashes are provenance from exact extracts; full physical arrays are not recalculated without omitted local snapshots.',
                      'No spontaneous initiative, learned planner or general agency is established by this finite result.']}
    args.out.mkdir(parents=True)
    write_json(args.out/'RECALCULO_TAREA_R02.json',result)
    flat=[]
    for a in arms:
        for r in a['rows']:
            row=dict(r);row['bank_before']=json.dumps(row['bank_before']);row['bank_after']=json.dumps(row['bank_after']);flat.append(row)
    with(args.out/'TRAYECTORIAS_Y_COSTES_R02.csv').open('x',encoding='utf8',newline='')as f:
        writer=csv.DictWriter(f,fieldnames=list(flat[0])if flat else['arm']);writer.writeheader();writer.writerows(flat)
    summary=[{k:a[k]for k in('arm','life','first_tick','last_tick','offered','completed','formed','NULL','material_zero','products','verified_product_bytes','failed_actual_effects','remaining_capsules')}for a in arms]
    with(args.out/'RESUMEN_CONTROLES_R02.csv').open('x',encoding='utf8',newline='')as f:
        writer=csv.DictWriter(f,fieldnames=list(summary[0])if summary else['arm']);writer.writeheader();writer.writerows(summary)
    print(json.dumps({'output':str(args.out),'arms':summary,'references':[{k:r[k]for k in('policy','products_if_valid_payload_available')}for r in ref['results']]},ensure_ascii=False))
if __name__=='__main__':main()
