"""Frozen analytical references for the published PI03 device law.

No I/O, no DEE import, no actor control and no Native-state/history input.
Policies see only their own opportunity number and preceding actual success.
The separate evaluator applies the frozen conduit law after each policy acts.
This is an analytical environment reference, not a Native experiment or an
execution of reference policies through E1 or the filesystem actuator.
"""
VERSION='PI03.fixed_and_own_consequence_references.R02.v1'
POLICIES=('fixed_minus','fixed_plus','alternating_minus_first','WSLS_minus_first')

def choose(policy,opportunity,previous_action=None,previous_success=None):
    if policy=='fixed_minus':return -1
    if policy=='fixed_plus':return 1
    if policy=='alternating_minus_first':return -1 if opportunity%2==0 else 1
    if policy=='WSLS_minus_first':
        if opportunity==0:return -1
        if previous_action not in(-1,1)or type(previous_success)is not bool:
            raise ValueError('Own preceding action and actual consequence required')
        return previous_action if previous_success else -previous_action
    raise ValueError('Unknown frozen reference policy')

def run(protocol):
    specs=[]
    for name in('development','reserved'):
        fixture=protocol['fixtures'][name];index=0
        for block in fixture['blocks']:
            for _ in range(block['opportunities']):
                specs.append({'series':name,'connected_motor':block['connected_motor'],
                              'delay_laps':fixture['delay_laps'][index]})
                index+=1
        if index!=len(fixture['delay_laps']):raise ValueError('Fixture length differs')
    results=[]
    for policy in POLICIES:
        rows=[];last_action=last_success=None
        for i,spec in enumerate(specs):
            action=choose(policy,i,last_action,last_success)
            # Private conduit evaluated only AFTER choose; policy never receives it.
            success=action==spec['connected_motor']
            rows.append({'opportunity':i,'series':spec['series'],'delay_laps':spec['delay_laps'],
                         'action':action,'success':success,
                         'private_environment_conduit_evaluator_only':spec['connected_motor']})
            last_action,last_success=action,success
        results.append({'policy':policy,'products_if_valid_payload_available':sum(r['success']for r in rows),
                        'opportunities':len(rows),'rows':rows})
    return {'version':VERSION,'scope':'Analytical replay of frozen environment law with own-consequence-only policies. No DEE or actual filesystem actuator is controlled.',
            'information_assumption':'Same offered opportunities, immediate observation only of own delayed outcome before next opportunity, valid same payload reservoir.',
            'results':results}
