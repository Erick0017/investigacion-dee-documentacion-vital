"""Passive scoped resource ledger, no SQLite, DEE import or live-world query.

Counts actual post-import checkpoint advancement per diagnostic life. A live
operation can be ahead of the last published checkpoint; its1500tick bound is
reported separately. File bytes are logical path bytes, not disk free space.
"""
from pathlib import Path
import datetime,json,os
P=Path(__file__).resolve().parent.parent;C=P.parents[2]/'DEE Cognitive 2.0'
systems=[P/'estados/candidato/sistema',P/'estados/observador_minimo/sistema']
systems += sorted(p/'sistema'for p in(P/'estados').glob('repro_*')if p.is_dir())
rows=[]
for system in systems:
    for vida in(system/'estado/vidas').glob('*/VIDA.json'):
        data=json.loads(vida.read_text(encoding='utf-8-sig'));life=vida.parent.name
        imp=system/'estado/servicios_persistentes'/life/'IMPORTACION.json'
        if not imp.is_file():continue
        imported=json.loads(imp.read_text(encoding='utf-8-sig'))
        start=imported['physical']['tick'];end=data['physical']['tick']
        rows.append({'life':life,'system':str(system),'import_tick':start,'last_checkpoint_tick':end,'executed_since_import':end-start,'source_life':imported.get('source_life_id'),'checkpoint_snapshot':data['snapshot'],'scope':'Last coherent VIDA checkpoint only; not instantaneous observation during an in-flight request.'})
archived_ticks=0
for map_name,retirement_name in [('ARCHIVO_CONTROLES_PI03_CERRADOS_R01.json','ARCHIVO_CONTROLES_PI03_RETIRO_R01.json'),('ARCHIVO_R05C_CERRADO_R02.json','ARCHIVO_R05C_RETIRO_R02.json')]:
    archive_map=P/'control'/map_name;archive_retirement=P/'control'/retirement_name
    if not(archive_map.is_file()and archive_retirement.is_file()):continue
    ar=json.loads(archive_map.read_text(encoding='utf-8'));ret=json.loads(archive_retirement.read_text(encoding='utf-8'))
    if ret.get('completed'):
        live_keys={(r['system'],r['life'])for r in rows}
        values=ar.get('archived_lives',[])
        if isinstance(values,dict):values=[values]if 'life'in values else values.values()
        for row in values:
            if(row['system'],row['life'])not in live_keys:
                row=dict(row);row['scope']='Preserved closed-life ledger; full original content in verified archive, not removed from Native tick accounting.'
                rows.append(row);archived_ticks+=row['executed_since_import']
peak=0;logs=[P/'ENSAYOS.jsonl']+list((P/'estados').glob('repro_*/ENSAYOS.jsonl'))
for file in logs:
    if not file.is_file():continue
    for line in file.read_text(encoding='utf-8').splitlines():
        try:r=json.loads(line)
        except json.JSONDecodeError:continue # concurrent tail may be incomplete
        peak=max(peak,r.get('peak_job_committed_bytes',0))
def scoped_bytes(root):
    size=count=0
    for base,dirs,files in os.walk(root,followlinks=False):
        dirs[:]=[x for x in dirs if not(Path(base)/x).is_symlink()]
        for name in files:
            f=Path(base)/name
            if not f.is_symlink():size+=f.stat().st_size;count+=1
    return {'logical_path_bytes':size,'files':count,'hardlinked_paths_can_be_counted_more_than_once':True,'not_measured_free_space_recovered':True}
operational_roots=[C/'sistema/estado'/name/'ECI02_PI03_MAIN'for name in('vidas','servicios_persistentes','servicios_locales')]
operational_files=list((C/'sistema/estado/checkpoints').glob('ECI02_PI03_MAIN.*'))
decision=P/'control/DECISION_FINAL_PI03.json'
if decision.is_file():
    d=json.loads(decision.read_text(encoding='utf-8'))
    operational_files += [C/'sistema'/x['file']for x in d['approved_code_files']]
    operational_files += [C/'sistema'/d['new_contract']['file']]
op_size=sum(scoped_bytes(x)['logical_path_bytes']for x in operational_roots if x.exists())+sum(x.stat().st_size for x in operational_files if x.is_file())
qa=P.parents[4]/'PI03_WORD_QA_20261108'
# Explicit actual workspace short-path Word QA, not the whole workspace.
for ancestor in P.parents:
    candidate=ancestor/'PI03_WORD_QA_20261108'
    if candidate.is_dir():qa=candidate;break
storage={'campaign':scoped_bytes(P),'stable_reproducibility':scoped_bytes(C/'reproducibilidad'),
 'new_operational_PI03':{'logical_path_bytes':op_size,'scope':'Three new product life directories, PI03 checkpoints and conservatively all approved deployed code/contract bytes; old parent/engine excluded.'},
 'short_path_Word_QA':scoped_bytes(qa)if qa.is_dir()else{'logical_path_bytes':0,'scope':'Not created yet'}}
report={'schema':'DEE.PI03.passive_resource_ledger.v2','local_cut':datetime.datetime.now().astimezone().isoformat(),'lives':rows,'checkpoint_native_ticks_executed':sum(r['executed_since_import']for r in rows),'possible_uncommitted_single_operation_upper_bound_ticks':1500,'Native_tick_budget':120000,'peak_owned_job_commit_bytes':peak,'memory_limit_bytes':536870912,'new_tree_storage':storage,'total_scoped_logical_bytes':sum(x['logical_path_bytes']for x in storage.values()),'no_Native_imports':True,'no_physics_query':True}
out=P/'control/RECURSOS_ACTUALES_PI03.json';out.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
reg=P/'REGISTRO_CAMPANA.json';r=json.loads(reg.read_text());r['new_native_ticks_so_far']=report['checkpoint_native_ticks_executed'];r['native_tick_count_scope']='Sum post-import checkpoint advances; one current bounded operation may be ahead, reported separately.';r['resource_ledger']=str(out);r['phase']='EXPERIMENTAL_DELAYED_CREDIT';reg.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:report[k]for k in('local_cut','checkpoint_native_ticks_executed','peak_owned_job_commit_bytes','new_tree_storage')},ensure_ascii=False))
