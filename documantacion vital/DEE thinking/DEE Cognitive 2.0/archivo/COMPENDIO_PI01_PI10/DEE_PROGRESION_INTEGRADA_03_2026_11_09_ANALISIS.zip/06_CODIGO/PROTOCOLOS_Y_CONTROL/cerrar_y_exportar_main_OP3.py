"""Preserve explicit ancestry, then export the real closed Main at zero ticks.

No experimental sequence is repeated; this is the existing paired persistence
contract. Root runs once after OP3 Native phases/code freezing. The complete
export is moved to stable Cognitive storage by a separate verified operation.
"""
from pathlib import Path
import datetime,hashlib,json,sys
P=Path(__file__).resolve().parents[1];C=P.parents[2]/'DEE Cognitive 2.0';S=C/'sistema';CS=P/'estados/candidato/sistema';L='ECI02_PI03_MAIN'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 out=P/'control/EXPORTACION_MAIN_FINAL_OP3.json'
 if out.exists():raise FileExistsError('Exact export is already witnessed; do not repeat')
 stages=[read(P/'control'/('MAIN_INTEGRADA_OP3_'+x+'.json'))for x in('PANEL','CAMBIO','RETENCION')]
 if any(x['status']!='COMPLETED'or not x['criteria_met']or not x['owner_closed_coherently']for x in stages):raise ValueError('All actual empirical phases must be closed and valid')
 file=CS/'estado/vidas'/L/'VIDA.json';card=read(file);parent=read(S/'estado/vidas/ECI02_PI02_MAIN/VIDA.json')
 if card['physical']['tick']!=775355 or card['physical']['tick']!=stages[-1]['final_tick']or parent['physical']['tick']!=753346 or read(S/'estado/ACTIVO.json')['life_id']!='ECI02_PI02_MAIN':raise ValueError('Actual candidate/principal changed; never rewind or overwrite')
 before=P/'control/VIDA_CANDIDATA_ANTES_PROCEDENCIA_PI03.json'
 if before.exists():raise FileExistsError('Administrative ancestry was already written; reconcile rather than repeat')
 before.write_bytes(file.read_bytes())
 card['PI03_provenance']={'schema':'DEE.PI03.physical_main_ancestry.v1','physical_parent_life':'ECI02_PI02_MAIN','physical_parent_tick':753346,
  'physical_parent_snapshot_sha256':parent['snapshot_sha256'],'original_transport_parent':card.get('parent'),
  'immediate_complete_prefix':{'life_id':'ECI02_PI03_CAL_WARM_PREP','tick':753459,'manifest_sha256':'dabfffc105e20c00ea79b1bcb79b2e01d9e4ca946e1f490bc94b4ca1dedb694f'},
  'preparation_chain':[{'life':'ECI02_PI03_CAL_PREP','tick':753349,'legal_birth_inputs':27,'ticks':3},{'life':'ECI02_PI03_CAL_WARM_PREP','tick':753459,'native_maturation_ticks':110},
                       {'life':L,'before_tick':768317,'after_tick':768320,'legal_birth_inputs':1,'scope':'Qualified preventive P0 post-read support, not acquired recovery'}],
  'continuous_experience':['R02 six development/eight reserved opportunities','R04 actual-number variable chains five opportunities','OP3 actual old panel+two O/H works+new use','OP3 changed device effect and subsequent Native route revision','OP3 later useful use after coherent reopening'],
  'no_control_memory_merge':True,'no_T0_recreation':True,'main_ancestor_is_not_immediate_import_container':True,
  'scope':'One full physical descendant. Root adds this administrative explanation only; no RAW, clocks, interfaces, acquired fields or resources are edited.'}
 file.write_text(json.dumps(card,ensure_ascii=False,indent=2),encoding='utf-8')
 sys.path.insert(0,str(P/'codigo'));from servicio_ensayo import Owner
 with Owner(L,'PI03_MAIN_FINAL_EXPORT_OP3',system=CS)as owner:
  initial=owner.initial
  if initial['tick']!=775355:raise ValueError('Opened another cut; no operation is sent')
  exported=owner.control('exportar')
 after=read(file)
 if any(after['physical'][k]!=card['physical'][k]for k in('N','tick','RAW_sha256','clocks_sha256')):raise ValueError('Zero-tick export changed physical state; preserve and diagnose')
 proof={'schema':'DEE.PI03.actual_final_main_export.OP3','at':datetime.datetime.now().astimezone().isoformat(),'life_id':L,'N':67,'final_tick':after['physical']['tick'],
  'closed':True,'before_physical':card['physical'],'reopened_physical':initial['physical'],'closed_physical':after['physical'],'source_card':str(file),'source_card_sha256':sha(file),
  'original_card_preserved':{'path':str(before),'sha256':sha(before)},'paired_export_transport':exported,'new_native_ticks':0,
  'selected':False,'scope':'Complete existing persistence contract after real acquisitions. No experiments repeated, no memory fusion and no promotion.'}
 with out.open('x',encoding='utf-8')as f:json.dump(proof,f,ensure_ascii=False,indent=2)
 print(json.dumps({'proof':str(out),'tick':after['physical']['tick'],'export':json.loads(exported['result'])if isinstance(exported['result'],str)else exported['result']},ensure_ascii=False))
if __name__=='__main__':main()
