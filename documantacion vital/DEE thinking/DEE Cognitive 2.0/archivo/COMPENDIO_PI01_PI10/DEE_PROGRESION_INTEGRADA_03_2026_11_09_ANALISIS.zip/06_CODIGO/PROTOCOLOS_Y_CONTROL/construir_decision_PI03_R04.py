"""Decisión PI03 R03, dosis nuevas verificadas por prefijos/IDs/ventanas, parametrizada, sólo desde primarios cerrados; nunca adopta.

--final-evidence y --conservation son resúmenes Root de hechos ya ejecutados:
life_id/N/final_tick/status=COMPLETED/closed=true y rows canónicas
{step,literal,before_tick,after_tick,primary}. Los primarios pueden ser recibos
SQLite exportados o su resultado Native literal. El panel usa los 12 lectores
congelados de RP/panel_12. La conservación añade old_product_files[2] con
path/bytes/sha256; se verifican los productos reales, no sólo su contador.

Final evidence añade stable_pair_alias, code_capsule_key, approved_code_files,
new_function_step, final_state_step, reopened_proof, closed_proof y process_proof.
Reopened_proof debe conservar life_id y before_physical/reopened_physical
(N,tick,RAW_sha256,clocks_sha256) obtenidos al cerrar y reabrir la misma vida.
La procedencia administrativa la escribe Root ANTES del export final; este
constructor no modifica VIDA, SQLite, selectores, producto o documentos.

Sin --salida sólo imprime. Con --salida exige un archivo NUEVO dentro de PI03.
El borrador construir_decision_PI03.py queda intacto y no se ejecuta.
"""
from pathlib import Path,PurePosixPath
import argparse,ast,datetime,hashlib,json,os,sys
P=Path(__file__).resolve().parent.parent;C=P.parents[2]/'DEE Cognitive 2.0'
S=C/'sistema';CS=P/'estados/candidato/sistema';RP=C/'reproducibilidad'
LIFE='ECI02_PI03_MAIN';PARENT='ECI02_PI02_MAIN';PARENT_T=753346
ROW=['result','rows',0];PHYSICAL=('N','tick','RAW_sha256','clocks_sha256')
sys.dont_write_bytecode=True
sys.path.insert(0,str(RP))
from observador_pasivo import snapshot_view,compare_native
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def bounded(p,root=P):
 p=Path(p);p=p if p.is_absolute()else root/p;p=p.absolute()
 if not p.is_relative_to(root.absolute()):raise ValueError('Outside explicit evidence root: '+str(p))
 for node in (p,*p.parents):
  if node.exists()and(node.is_symlink()or getattr(node.lstat(),'st_file_attributes',0)&1024):raise ValueError('Reparse/link: '+str(node))
  if node==root:break
 return p
def at(x,path):
 for k in path:x=x[k]
 return x
def evidence(p):
 p=bounded(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def primary(row):
 f=bounded(row['primary']);raw=read(f)
 if 'seq'in raw or('payload_sha'in raw and'status'in raw):
  if raw.get('status')!='completed':raise ValueError('Incomplete/failed primary: '+str(f))
  native=json.loads(raw['result'])if isinstance(raw['result'],str)else raw['result']
  payload=json.loads(raw['payload'])if isinstance(raw.get('payload'),str)else raw.get('payload')
  if payload and payload.get('operacion')=='sesion'and payload.get('situaciones')!=[row['literal']]:raise ValueError('Literal differs from actual transport payload')
 else:native=raw
 if not isinstance(native,dict)or native.get('before_tick')!=row['before_tick']or native.get('after_tick')!=row['after_tick']:
  raise ValueError('Canonical ticks differ from actual primary: '+str(f))
 if native.get('committed_snapshot',{}).get('life_id')!=LIFE:raise ValueError('Primary belongs to another physical trajectory')
 if row['after_tick']<row['before_tick']:raise ValueError('Negative evolution interval')
 return native,evidence(f)
def closed_summary(path):
 p=bounded(path);data=read(p)
 if data.get('life_id',data.get('life'))!=LIFE or data.get('N')!=67 or data.get('status')!='COMPLETED'or data.get('closed')is not True:
  raise ValueError('A completed, closed N67 actual MAIN summary is required: '+str(p))
 if type(data.get('final_tick'))is not int or data['final_tick']<=PARENT_T:raise ValueError('Exact later final tick required')
 steps={};previous=-1
 for row in data['rows']:
  if row['step']in steps:raise ValueError('Duplicate canonical step')
  native,ref=primary(row)
  if row['before_tick']<previous:raise ValueError('Summary orders incompatible/reset histories')
  previous=row['after_tick'];steps[row['step']]={'row':row,'native':native,'evidence':ref}
 if previous!=data['final_tick']:raise ValueError('Last material/zero-tick row does not identify summary final cut')
 return data,steps,evidence(p)
def receipt_rows(v):
 if isinstance(v,dict):
  r=v.get('receipt')
  if isinstance(r,dict)and type(r.get('id'))is int and'status'in r:yield r
  for child in v.values():yield from receipt_rows(child)
 elif isinstance(v,list):
  for child in v:yield from receipt_rows(child)
def native_denominators(conservation):
 sys.path.insert(0,str(P/'codigo'))
 from recalcular_dosis_conservacion_OP3_pasivo import calculate
 return calculate(conservation)['native_receipts']
def physical_witness(data,name):
 value=data.get(name)
 if not isinstance(value,dict)or any(k not in value for k in PHYSICAL):raise ValueError('Missing actual reopening physical witness: '+name)
 return {k:value[k]for k in PHYSICAL}
def compact_resources(taskstate,state_native,stable,manifest_sha,pair):
 device=taskstate['device'];progress=taskstate['progress']
 old=state_native['committed_snapshot']['operational_dependencies']['PI02']['R04']
 oldhome=pair/'artefactos_trabajador/PI02_WORKBENCH_R04'
 source=progress['current_resource_source'];supply=progress['resource_supply_history'][-1]
 counters={'prepared_capsules':len(device['capsules']),'consumed':device['opportunity'],
    'products':len(device['products']),'rejections':len(device['rejections']),
    'available':taskstate['remaining_opportunities']}
 if counters['prepared_capsules']-counters['consumed']!=counters['available'] or counters['products']+counters['rejections']!=counters['consumed']:
  raise ValueError('Actual external task counters do not reconcile')
 return {'task':counters,'latest_payload':{'actual_native_integer':source['actual_final_result'],
      'bytes':supply['payload_bytes'],'sha256':supply['payload_sha256']},
   'old_PI02':{'products':old['resources'],'episodes':old['episode'],
      'control_packets_available':sum(f.is_file()for f in(oldhome/'control_stock').iterdir()),'paused':old['enabled']is False},
   'complete_native_and_environment':{'stable_pair_relative_to_product':stable['product_relative'],
      'manifest_sha256':manifest_sha,'native_snapshot':'VIDA.deetsnap.gz',
      'task_artifact_prefix':'artefactos_trabajador/PI03_TAREA_DIFERIDA_R02',
      'old_PI02_artifact_prefix':'artefactos_trabajador/PI02_WORKBENCH_R04',
      'scope':'Complete state, receipt/source history and external device remain in this exact full pair; they are not duplicated or used as a policy table in this operational contract.'}}

def build(a):
 final,fsteps,finalref=closed_summary(a.final_evidence)
 cons,csteps,consref=closed_summary(a.conservation)
 if cons['final_tick']>final['final_tick']:raise ValueError('Conservation is from a later/incompatible future')
 frozen=read(RP/'recetas/panel_12.json');witnesses=[s for b in frozen['variants']['principal']['batches']for s in b if'expected'in s]
 if len(witnesses)!=12:raise ValueError('Frozen published panel changed')
 results=[]
 for s in witnesses:
  item=csteps[s['label']];literal=dict(s['literal'])
  if s.get('actual_integer_binding'):
   binding=s['actual_integer_binding'];previous=csteps[binding['from_step']]
   src=next(x for x in witnesses if x['label']==binding['from_step'])
   value=at(previous['native'],src['read_path'])
   if type(value)is not int:raise ValueError('Actual arithmetic intermediate absent; no expected fallback')
   literal[binding['field']]=value
  if item['row']['literal']!=literal:raise ValueError('Frozen panel literal/actual binding differs: '+s['label'])
  actual=at(item['native'],s['read_path'])
  correct=type(actual)is int and actual==s['expected']
  results.append({'step':s['label'],'actual':actual,'expected':s['expected'],'correct':correct,'NULL':actual is None,'evidence':item['evidence']})
 if not all(r['correct']for r in results):raise ValueError('Material regression in the actual conservation panel')
 products=cons['old_product_files']
 if len(products)!=2 or len({x['path']for x in products})!=2:raise ValueError('Exactly two distinct old protected-work products required')
 oldrefs=[]
 for x in products:
  f=bounded(x['path']);ref=evidence(f)
  if ref['bytes']!=64 or ref['bytes']!=x['bytes']or ref['sha256']!=x['sha256']:raise ValueError('Old actual 64-byte product mismatch')
  oldrefs.append(ref)
 if cons.get('panel_correct')!=12 or cons.get('old_products')!=2:raise ValueError('Reported conservation counts differ from recomputation')
 new=fsteps[final['new_function_step']]
 if new['row']['literal'].get('modo')!='eci01-pi03-tarea-oportunidad'or at(new['native'],ROW+['useful_product'])is not True:
  raise ValueError('Actual final new-task use was not useful; never inherit an earlier successful diagnostic')
 state=fsteps[final['final_state_step']]
 if state['row']['literal']!={'modo':'eci01-pi03-tarea-estado'}:raise ValueError('Actual final task/resource state must be read with its fixed state operator')
 taskstate=at(state['native'],ROW)
 if taskstate.get('admitted')is not True:raise ValueError('Final task state absent')
 reopen_path=bounded(final['reopened_proof']);reopen=read(reopen_path)
 if reopen.get('life_id',reopen.get('life'))!=LIFE:raise ValueError('Reopening witness identifies another life')
 phys_before=physical_witness(reopen,'before_physical');phys_open=physical_witness(reopen,'reopened_physical')
 if phys_before!=phys_open or phys_before['tick']<cons['final_tick']or new['row']['before_tick']<phys_open['tick']:
  raise ValueError('Reopening is not same-state preservation followed by the actual later useful use')
 pair=Path(a.final_pair).absolute();pair=bounded(pair,P)if pair.is_relative_to(P)else bounded(pair,RP)
 m=read(pair/'EXPORTACION_SERVICIO.json');mp_sha=sha(pair/'EXPORTACION_SERVICIO.json')
 card=read(CS/'estado/vidas'/LIFE/'VIDA.json');provenance=card.get('PI03_provenance',{})
 if provenance.get('physical_parent_life')!=PARENT or provenance.get('physical_parent_tick')!=PARENT_T:raise ValueError('Root must preserve/write explicit administrative ancestry before final export')
 if m.get('schema')!='DEE.persistent_service.paired_export.v1'or m.get('queue_journal_required')is not True or m.get('life_id')!=LIFE:
  raise ValueError('Final snapshot alone is insufficient; exact complete paired export required')
 if any(m['physical'][k]!=card['physical'][k]for k in PHYSICAL)or m['physical']['tick']!=final['final_tick']:
  raise ValueError('Current candidate, final evidence and complete export differ')
 current_view=snapshot_view(CS/card['snapshot'])
 if current_view['encoded_sha256']!=card['snapshot_sha256']:raise ValueError('Current source checkpoint integrity differs from its card')
 source_comparison=compare_native(snapshot_view(pair/'VIDA.deetsnap.gz'),current_view,allow_service=True)
 for v in m['members']:
  f=bounded(pair/v['file'],pair)
  if f.stat().st_size!=v['bytes']or sha(f)!=v['sha256']:raise ValueError('Incomplete/changed final pair member')
 cfg=read(RP/'RECURSOS.json');stable=cfg['pairs'][final['stable_pair_alias']]
 if (C/stable['product_relative']).absolute()!=pair or stable['manifest_sha256']!=mp_sha:raise ValueError('Final full pair must already be the one stable resource, not another copy or old cut')
 relocation_ref=final.get('pair_relocation')
 if not pair.is_relative_to(P):
  relocation_path=bounded(relocation_ref);relocation=read(relocation_path)
  if not relocation.get('completed')or Path(relocation['destination']).absolute()!=pair or relocation['manifest_sha256']!=mp_sha:
   raise ValueError('Stable moved export requires its exact completed origin→RP proof')
 else:relocation_path=None
 capsule=cfg['code_capsules'][final['code_capsule_key']];cap=C/capsule['product_relative'];manifest=read(cap/capsule['manifest'])
 if sha(cap/capsule['manifest'])!=capsule['manifest_sha256']:raise ValueError('Pinned final source capsule manifest changed')
 capfiles={v['file']:v for v in manifest['files']}
 for rel,v in capfiles.items():
  if sha(CS/rel)!=v['sha256']or sha(cap/rel)!=v['sha256']:raise ValueError('Final CS code diverged from pinned stable source capsule')
 approved=[]
 for rel in final['approved_code_files']:
  r=PurePosixPath(rel)
  if r.is_absolute()or'..'in r.parts or rel not in capfiles:raise ValueError('Unpinned/unsafe approved code path')
  python=r.suffix=='.py'and(rel=='gestionar.py'or r.parts[0]in('app','capacidades'))
  protocol=rel in('capacidades/PROTOCOLO_PI03_R01.json','capacidades/PROTOCOLO_PI03_TAREA_R02.json')
  if not(python or protocol):raise ValueError('No engine/state/general-file deployment permitted')
  src=CS/rel;ast.parse(src.read_text(encoding='utf-8-sig'))if python else read(src)
  approved.append({'file':rel,'sha256':sha(src),'product_before_sha256':sha(S/rel)if(S/rel).exists()else None})
 needed={'gestionar.py','app/importacion_emparejada.py','app/estructuras_externas_pi03.py','capacidades/pi03_proteccion_cola_OP3.py'}
 if not needed<={x['file']for x in approved}:raise ValueError('Approved deployment omits an indispensable forwarding/import/guard module')
 parent=read(S/'estado/vidas'/PARENT/'VIDA.json')
 if parent['physical']['tick']!=PARENT_T or read(S/'estado/ACTIVO.json')['life_id']!=PARENT:raise ValueError('Protected principal advanced/selection changed; do not adopt an outdated future')
 task=read(P/'control/TAREA_R02_real.json');omit=read(P/'control/TAREA_R02_return_nonfailure.json');null=read(P/'control/TAREA_R02_actuator_null.json')
 chain=read(P/'control/CONTINUACION_CADENA_R04.json');repro=read(P/'control/FISICA_REPRODUCIDA_R02_COGNITIVE.json')
 if any(x['status']!='COMPLETED'for x in(task,omit,null,chain))or task['actual_products']<omit['actual_products']+2 or null['actual_products']!=0 or chain['products_additional']<3 or repro['exact_physical_match']is not True:
  raise ValueError('Previously executed useful-gain/acquisition gates are not supported')
 refs=[finalref,consref,evidence(final['reopened_proof']),evidence(final['closed_proof'])]
 refs += [x['evidence']for x in results]+oldrefs+[new['evidence'],state['evidence']]
 refs += [evidence(P/'control'/n)for n in('TAREA_R02_real.json','TAREA_R02_return_nonfailure.json','TAREA_R02_actuator_null.json','CONTINUACION_CADENA_R04.json','FISICA_REPRODUCIDA_R02_COGNITIVE.json')]
 if relocation_path:refs.append(evidence(relocation_path))
 refs.append(evidence(P/'control/DOSIS_CONSERVACION_OP3_RECALCULADA_R02.json'))
 scope=final['scope'];limits=final['limits'];assistance=final['assistance']
 if not all(isinstance(x,str)and x for x in [scope,*limits,*assistance])or not limits or not assistance:raise ValueError('Explicit scientific scope, preparation and limits required')
 gates={
  'functional_gain':{'satisfied':True,'criterion':'At least two more real useful products than generic nonfailure control; actuator-null zero; at least three new-source products.','result':{'real':task['actual_products'],'nonfailure':omit['actual_products'],'actuator_null':null['actual_products'],'new_chain_products':chain['products_additional']},'evidence':[evidence(P/'control'/n)for n in('TAREA_R02_real.json','TAREA_R02_return_nonfailure.json','TAREA_R02_actuator_null.json','CONTINUACION_CADENA_R04.json','FISICA_REPRODUCIDA_R02_COGNITIVE.json')]},
  'conservation':{'satisfied':True,'criterion':'Same MAIN genealogy materially uses frozen 12 witnesses and produces two old protected-work files.','result':{'correct':12,'requested':12,'old_products':2,'native_receipts':native_denominators(cons)},'evidence':[consref,*oldrefs,evidence(P/'control/DOSIS_CONSERVACION_OP3_RECALCULADA_R02.json')]},
  'source_reopening':{'satisfied':True,'criterion':'Close/reopen the same complete MAIN physical state, then use new function without reset.','result':{'before':phys_before,'reopened':phys_open,'use_after_tick':new['row']['after_tick']},'evidence':[evidence(final['reopened_proof']),new['evidence']]},
  'new_function_at_final_cut':{'satisfied':True,'criterion':'Actual later task result is useful; final resources are preserved, not reset; exact final paired state.','result':{'useful_product':True,'final_tick':final['final_tick'],'task_remaining':taskstate['remaining_opportunities']},'through_tick':final['final_tick'],'evidence':[new['evidence'],state['evidence'],finalref]}}
 contract={'schema':'DEE.PI03.bounded_operational_contract.OP3','life_id':LIFE,'physical_parent':provenance,'scope':scope,'assistance':assistance,'limits':limits,
   'operators':{'state':[{'modo':'eci01-pi03-tarea-estado'}],'next':[{'modo':'eci01-pi03-tarea-oportunidad'}]},
   'reproduction':'sistema/gestionar.py reproducibilidad listar|verificar|recalcular|reproducir; material mode requires explicit fresh diagnostic destination/ID.',
   'final_resources':compact_resources(taskstate,state['native'],stable,mp_sha,pair),
   'continuity':'Complete paired snapshot/clock/interfaces/agenda/SQLite/receipts/outbox/artifacts and both external workbenches; no memory fusion or resource reset.',
   'prepared_guard_is_not_acquired_regulation':True,'clinical_or_consciousness_inference':False}
 d={'schema':'DEE.PI03.reasoned_adoption_decision.v1','approved_for_adoption':True,'life_id':LIFE,'decision_id':'PI03_ADOPCION_OPERATIVA_OP3',
  'desired_cut':{'N':67,'tick':card['physical']['tick'],'snapshot_sha256':card['snapshot_sha256']},
  'pair':{'directory':str(pair),'manifest_sha256':mp_sha,'members':len(m['members']),'bytes':sum(v['bytes']for v in m['members']),'snapshot_sha256':m['snapshot_sha256']},
  'stable_pair_relative_to_product':stable['product_relative'],'approved_code_files':approved,'gates':gates,'scope':scope,
  'gains':final['gains'],'losses':final['losses'],'uncertainties':limits,'assistance':assistance,'evidence':refs,
  'regression_coverage':{'source_cut':cons['rows'][0]['before_tick'],'life_id':LIFE,'through_tick':cons['final_tick'],'summary':gates['conservation']['result'],'scope':'Actual material sequence on the same candidate; final post-reopen cut has its separate later useful-task witness, not another inherited full panel.'},
  'process_proof':str(bounded(final['process_proof'])),'catalog_entry':{'id':'PI03_CREDITO_DIFERIDO_Y_COMPOSICION_ASISTIDA','name':'Selección local con retorno diferido, conservación y protección preparada','level':'Acquired local selection in one prepared Native trajectory; bounded external guard and reproducibility instrument are prepared','scope':scope},
  'new_contract':{'file':'contratos/PROGRESION_INTEGRADA_03_OP3.json','document':contract},'limits':limits,'version':'PI03.OP3.DOSIS_R02.CONTRATO_COMPACTO',
  'builder_has_not_promoted_or_modified_product':True,'builder_has_not_written_VIDA':True,
  'source_to_export_causal_comparison':source_comparison}
 if relocation_path:d['pair_relocation']=evidence(relocation_path)
 return d
def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--final-evidence',required=True,type=Path);ap.add_argument('--final-pair',required=True,type=Path);ap.add_argument('--conservation',required=True,type=Path);ap.add_argument('--salida',type=Path);a=ap.parse_args()
 decision=build(a)
 if a.salida:
  out=bounded(a.salida)
  if out.exists():raise FileExistsError('Existing decision protected; no overwrite')
  with out.open('x',encoding='utf-8')as f:json.dump(decision,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
  print(json.dumps({'decision':str(out),'sha256':sha(out),'tick':decision['desired_cut']['tick'],'still_not_promoted':True},ensure_ascii=False))
 else:print(json.dumps(decision,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
