"""Root-only bounded continuity on the actual candidate; no cloning or promotion.

The panel reuses the frozen OP1 literals/readers unchanged. Revision OP3 only
adds the separately verified legal post-read terminator beforehand. Expected
values remain in the auditor and never enter the world. Each phase has a fresh
process and unique IDs; failures preserve the reached future without retry.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,sys
P=Path(__file__).resolve().parents[1];C=P.parents[2]/'DEE Cognitive 2.0'
S=P/'estados/candidato/sistema';LIFE='ECI02_PI03_MAIN'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def at(v,path):
 for part in path:v=v[part]
 return v
def write(p,v):
 t=p.with_name(p.name+'.writing')
 with t.open('x',encoding='utf-8')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
 t.replace(p)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['panel','cambio','retencion'],required=True);a=ap.parse_args()
 sys.path.insert(0,str(P/'codigo'));from servicio_ensayo import Owner
 out=P/'control'/('MAIN_INTEGRADA_OP3_'+a.phase.upper()+'.json')
 if out.exists():raise FileExistsError('A completed/failed phase is never rerun')
 if(S/'estado/ACTIVO.json').exists():raise ValueError('Candidate must remain unselected until all empirical gates pass')
 card=read(S/'estado/vidas'/LIFE/'VIDA.json')
 if a.phase=='panel'and card['physical']['tick']!=768320:raise ValueError('Require actual legal OP3 guard preparation from768317+3; no rewind')
 if a.phase!='panel':
  previous=read(P/'control'/('MAIN_INTEGRADA_OP3_'+('PANEL'if a.phase=='cambio'else'CAMBIO')+'.json'))
  if previous['status']!='COMPLETED'or not previous['criteria_met']or card['physical']['tick']!=previous['final_tick']:raise ValueError('Prior actual continuous phase is incomplete/changed')
 state={'schema':'DEE.PI03.actual_main_continuation.OP3','phase':a.phase,'life_id':LIFE,'N':67,'source_tick':card['physical']['tick'],'rows':[],
        'status':'RUNNING','started_local':datetime.datetime.now().astimezone().isoformat(),'selected':False,'no_clone_or_reset':True}
 write(out,state);previous_values={};results={}
 try:
  with Owner(LIFE,'PI03_MAIN_OP3_'+a.phase.upper(),system=S)as owner:
   if a.phase=='panel':
    recipe=read(C/'reproducibilidad/recetas/pi03_panel_integrado_OP1.json');steps=recipe['variants']['consecutivo']['batches'][0]
   elif a.phase=='cambio':
    steps=[{'label':'old_stock_next','literal':{'modo':'eci01-pi03-tarea-oportunidad'}},
           {'label':'explicit_changed_effect','literal':{'modo':'eci01-pi03-tarea-suministrar','cantidad':2,'conexion':1,'demora_periodos':2},'require_zero_ticks':True},
           {'label':'changed_effect_first','literal':{'modo':'eci01-pi03-tarea-oportunidad'}},
           {'label':'changed_effect_second','literal':{'modo':'eci01-pi03-tarea-oportunidad'}}]
   else:
    steps=[{'label':'supply_retention','literal':{'modo':'eci01-pi03-tarea-suministrar','cantidad':1,'conexion':1,'demora_periodos':4},'require_zero_ticks':True},
           {'label':'retained_new_use','literal':{'modo':'eci01-pi03-tarea-oportunidad'}},
           {'label':'leave_two_explicit_offers','literal':{'modo':'eci01-pi03-tarea-suministrar','cantidad':2,'conexion':1,'demora_periodos':4},'require_zero_ticks':True},
           {'label':'final_task_state','literal':{'modo':'eci01-pi03-tarea-estado'}}]
   for step in steps:
    literal=json.loads(json.dumps(step['literal']))
    if 'actual_integer_binding'in step:
     b=step['actual_integer_binding'];value=previous_values[b['from_step']]
     if type(value)is not int:raise ValueError('No actual Native integer; never supply expected value')
     literal[b['field']]=value
    ident='PI03_MAIN_OP3_'+a.phase.upper()+'_'+step['label']
    r=owner.material(ident,literal,feedback=step.get('feedback','omit'),actuator=step.get('actuator','closed'))
    value=at(r,step['read_path'])if 'read_path'in step else None;previous_values[step['label']]=value;results[step['label']]=r
    primary=P/'ensayos'/(ident+'.json')
    row={'step':step['label'],'literal':literal,'before_tick':r['before_tick'],'after_tick':r['after_tick'],'primary':str(primary),'primary_sha256':sha(primary),
         'response':value,'decoder_used':'read_path'in step}
    if'expected'in step:row['expected_auditor_only']=step['expected'];row['criterion_met']=type(value)is type(step['expected'])and value==step['expected']
    if literal['modo']=='eci01-pi03-tarea-oportunidad':
     task=r['result']['rows'][0];row['actual_task_result']=task
     if task['reader']['choice']is None:raise ValueError('Fixed q+6 NULL; stop and preserve actual future')
    state['rows'].append(row);state['last_tick']=r['after_tick'];write(out,state)
    if step.get('require_zero_ticks')and r['before_tick']!=r['after_tick']:raise ValueError('External supply unexpectedly advanced Native')
   owner.control('guardar')
  card=read(S/'estado/vidas'/LIFE/'VIDA.json');state['final_tick']=card['physical']['tick'];state['snapshot_sha256']=card['snapshot_sha256']
  state['owner_closed_coherently']=True;state['reopened_same_complete_life']=True
  if a.phase=='panel':
   state['panel_correct']=sum(r.get('criterion_met',False)for r in state['rows']);state['panel_evaluated']=sum('criterion_met'in r for r in state['rows'])
   state['old_products']=at(results['legacy_after'],['result','rows',0,'habitat','resources'])-at(results['legacy_before'],['result','rows',0,'habitat','resources'])
   state['new_products']=int(results['task_next']['result']['rows'][0]['useful_product'])
   state['criteria_met']=state['panel_correct']==12 and state['panel_evaluated']==12 and state['old_products']==2 and state['new_products']==1
  elif a.phase=='cambio':
   v={r['step']:r.get('actual_task_result')for r in state['rows']if'actual_task_result'in r}
   state['new_products']=sum(bool(x['useful_product'])for x in v.values())
   state['criteria_met']=v['old_stock_next']['useful_product']is True and v['changed_effect_first']['useful_product']is False and v['changed_effect_second']['useful_product']is True
  else:
   state['new_products']=int(results['retained_new_use']['result']['rows'][0]['useful_product']);state['final_task_state']=results['final_task_state']['result']['rows'][0]
   state['criteria_met']=state['new_products']==1 and state['final_task_state']['remaining_opportunities']==2
  state['status']='COMPLETED';state['finished_local']=datetime.datetime.now().astimezone().isoformat();write(out,state)
  print(json.dumps({'phase':a.phase,'tick':state['final_tick'],'criteria_met':state['criteria_met'],'summary':str(out)},ensure_ascii=False))
 except BaseException as e:
  state.update(status='STOPPED_FUTURE_PRESERVED',error=repr(e),automatic_retry=False);write(out,state);raise
if __name__=='__main__':main()
