"""OP4: conserva y corrige stdout de la puerta stdlib; dos lecturas reales.

No Native/material, no cambio de cápsulaC ni de los cinco ejecutores RP.
"""
from pathlib import Path
import ast,datetime,hashlib,json,os,shutil,subprocess,sys
P=Path(__file__).resolve().parent.parent;C=P.parents[2]/'DEE Cognitive 2.0';S=C/'sistema';CS=P/'estados/candidato/sistema';RP=C/'reproducibilidad'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save_new(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x',encoding='utf-8')as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
def state_hashes():
 cardpath=S/'estado/vidas/ECI02_PI03_MAIN/VIDA.json';card=read(cardpath)
 files=[S/'estado/ACTIVO.json',cardpath,S/card['snapshot'],C/'PROYECTO.json',
     S/'runtime/dee_thinking-4.5.0-cp313-cp313-win_amd64.whl',C/'motor/python313/site-packages/dee_thinking/_native.cp313-win_amd64.pyd']
 return {'files':[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}for p in files],
         'physical':card['physical'],'snapshot_sha256':card['snapshot_sha256']}
def main():
 before=state_hashes();cfg=read(RP/'RECURSOS.json');cap=cfg['code_capsules']['PI03_DIAGNOSTICO_COLA_R05C']
 cap_manifest=C/cap['product_relative']/cap['manifest'];cap_before=sha(cap_manifest)
 tools=['reproducir.py','importar_diagnostico.py','ejecutar_diagnostico.py','propietario_diagnostico.py','observador_pasivo.py']
 tool_before={n:sha(RP/n)for n in tools}
 base=P/'codigo/revisiones/OP4_FORWARDING_ANTES';base.mkdir(parents=True,exist_ok=False)
 old="""    return subprocess.run(command,cwd=product,shell=False,
          creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)).returncode"""
 new="""    completed=subprocess.run(command,cwd=product,shell=False,
          capture_output=True,text=True,encoding='utf-8',errors='strict',
          creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    # CREATE_NO_WINDOW does not reliably inherit console handles on Windows.
    # Capture pipes explicitly, then forward the exact structured output.
    if completed.stdout:sys.stdout.write(completed.stdout);sys.stdout.flush()
    if completed.stderr:sys.stderr.write(completed.stderr);sys.stderr.flush()
    return completed.returncode"""
 changes=[]
 for label,system in(('producto',S),('fuente_CS',CS)):
  f=system/'gestionar.py';original=f.read_bytes();copy=base/(label+'_gestionar.py');copy.write_bytes(original)
  text=f.read_text(encoding='utf-8-sig')
  if text.count(old)!=1:raise ValueError('Exact forwarding anchor differs: '+str(f))
  revised=text.replace(old,new);ast.parse(revised);f.write_text(revised,encoding='utf-8')
  changes.append({'file':str(f),'before_sha256':hashlib.sha256(original).hexdigest(),'after_sha256':sha(f),'literal_before':str(copy)})
 delta=RP/'codigo_preservado/PI03_OP4_FORWARDING';delta.mkdir(exist_ok=False)
 shutil.copy2(S/'gestionar.py',delta/'gestionar.py')
 descriptor={'schema':'DEE.PI03.localized_instrument_delta.OP4','base_full_capsule_key':'PI03_DIAGNOSTICO_COLA_R05C',
  'base_manifest_sha256':cap_before,'changes':[{'file':'gestionar.py','before_sha256':changes[0]['before_sha256'],
  'after_sha256':changes[0]['after_sha256'],'bytes':(delta/'gestionar.py').stat().st_size}],
  'scope':'Post-commit Windows stdout/stderr forwarding only. No Native physics, policy, reader, state or historical source capsule rewrite.'}
 save_new(delta/'DELTA_COGNITIVE.json',descriptor)
 tests=[];py=C/'motor/python313/python.exe'
 for name,args in(('listar',['listar']),('verificar_R05c',['verificar','pi03_guardia_cola_R05c'])):
  cmd=[str(py),'-I','-B','-X','utf8',str(S/'gestionar.py'),'reproducibilidad',*args]
  result=subprocess.run(cmd,cwd=C,capture_output=True,text=True,encoding='utf-8',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  out=P/'control'/('GESTOR_OP4_'+name+'.stdout.json');err=P/'control'/('GESTOR_OP4_'+name+'.stderr.txt')
  with out.open('x',encoding='utf-8')as f:f.write(result.stdout)
  with err.open('x',encoding='utf-8')as f:f.write(result.stderr)
  if result.returncode or not result.stdout.strip():raise ValueError('Actual manager read mode failed/empty: '+name)
  value=json.loads(result.stdout)
  if name=='listar':
   if value.get('DEE_imports')!=0 or value.get('new_native_ticks')!=0:raise ValueError('List mode changed its passive contract')
  else:
   if len(value)!=1 or value[0]['requirements_available']is not True or value[0]['DEE_imports']!=0 or value[0]['new_native_ticks']!=0:raise ValueError('Read-only requirements check failed')
  tests.append({'name':name,'command':cmd,'exit_code':result.returncode,'stdout':str(out),'stdout_bytes':out.stat().st_size,
       'stdout_sha256':sha(out),'parseable_nonempty_JSON':True,'stderr_bytes':err.stat().st_size})
 after=state_hashes()
 if before!=after or cap_before!=sha(cap_manifest)or tool_before!={n:sha(RP/n)for n in tools}:raise ValueError('State/engine/capsule/execution-tool preservation failed')
 # Execute the early route under runpy with an audit event guard on DEE/app
 # imports. This starts only the same stdlib child listing; no world/owner.
 guard=P/'codigo/inspeccionar_imports_forward_OP4.py'
 guard_text="""import json,runpy,sys
from pathlib import Path
manager=Path(sys.argv[1]);args=sys.argv[2:];seen=[]
def hook(event,values):
 if event=='import':
  name=values[0]
  if name=='dee_thinking'or name.startswith(('dee_thinking.','app.'))or name=='app':
   seen.append(name);raise RuntimeError('Forbidden DEE/app import in manager read route: '+name)
sys.addaudithook(hook);sys.argv=[str(manager),'reproducibilidad',*args]
try:runpy.run_path(str(manager),run_name='__main__')
except SystemExit as exit:
 if exit.code not in(None,0):raise
if seen:raise RuntimeError(str(seen))
print(json.dumps({'manager_DEE_or_app_imports':seen,'material_world_opened':False}),file=sys.stderr)
"""
 with guard.open('x',encoding='utf-8')as f:f.write(guard_text)
 inspected=subprocess.run([str(py),'-I','-B','-X','utf8',str(guard),str(S/'gestionar.py'),'listar'],cwd=C,capture_output=True,text=True,encoding='utf-8',creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 if inspected.returncode:raise ValueError('Actual early route attempted a prohibited import: '+inspected.stderr)
 audit=json.loads(inspected.stderr.strip().splitlines()[-1])
 if audit['manager_DEE_or_app_imports']:raise ValueError('Unexpected manager Native/app import')
 final=state_hashes()
 if before!=final:raise ValueError('Audit wrapper changed state')
 report={'schema':'DEE.PI03.actual_manager_output_correction.OP4','recorded_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'changes':changes,'base_capsule_C_unchanged':True,'five_execution_tools_unchanged':True,'tests':tests,'actual_manager_import_audit':audit,
    'state_and_engine_before':before,'state_and_engine_after':final,'state_hashes_equal':True,'new_native_ticks':0,'no_material_or_owner_start':True,
    'instrument_delta':str(delta/'DELTA_COGNITIVE.json'),'limitations':'Import audit covers the manager early route. Child RP read modes are stdlib and their output reports zero DEE imports/ticks; this is an output/instrument check, not a cognitive test.'}
 save_new(P/'control/GESTOR_OP4_CORREGIDO_Y_LECTURA_VERIFICADA.json',report)
 print(json.dumps({'proof':str(P/'control/GESTOR_OP4_CORREGIDO_Y_LECTURA_VERIFICADA.json'),'changes':changes,
      'nonempty_JSON_tests':[(t['name'],t['stdout_bytes'])for t in tests],'state_hashes_equal':True,'new_native_ticks':0},ensure_ascii=False))
if __name__=='__main__':main()
