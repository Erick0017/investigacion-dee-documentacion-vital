"""Root finite useful task on one continuous full descendant and paired controls.

No scorer chooses actions. Each literal offers the next frozen opportunity;
all Native/physics/device decisions are inside the declared versioned setup.
Closed summaries are cumulative, and no error is retried automatically.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,subprocess,sys
sys.dont_write_bytecode=True
P=Path(__file__).resolve().parent.parent;C=P.parents[2]/'DEE Cognitive 2.0'
S=P/'estados/candidato/sistema';PY=C/'motor/python313/python.exe'
sys.path.insert(0,str(P/'codigo'))
from servicio_ensayo import Owner
parser=argparse.ArgumentParser();parser.add_argument('--control',choices=('real','return_nonfailure','actuator_null'),required=True);parser.add_argument('--hasta',type=int,choices=(6,14),default=14)
a=parser.parse_args()
life={'real':'ECI02_PI03_MAIN','return_nonfailure':'ECI02_PI03_CTL_NO_RETURN','actuator_null':'ECI02_PI03_CTL_ACT_NULL'}[a.control]
summary=P/'control'/('TAREA_R02_'+a.control+'.json')
if summary.exists():raise FileExistsError('Inspect existing task future; never repeat by case name')
prep=json.loads((P/'control/PREFIJO_CALIBRACION_R01W.json').read_text())
subprocess.run([str(PY),'-I','-B','-X','utf8',str(P/'codigo/clonar_corte_experimental_PI03.py'),'--par',prep['paired_export']['directory'],'--vida',life],cwd=P,check=True,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
record={'schema':'DEE.PI03.useful_delayed_task.executed.R02','life':life,'control':a.control,'source_prefix':prep['paired_export'],'started_local':datetime.datetime.now().astimezone().isoformat(),'status':'RUNNING','rows':[],'closed_batches':0,'principal_selected':False,'automatic_retry':False}
def save():summary.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
save()
try:
    # Native state/device/agenda persist through the development/reserve break.
    ranges=[(0,min(6,a.hasta))]+([(6,14)]if a.hasta==14 else[])
    for batch,(begin,end)in enumerate(ranges):
        with Owner(life,'PI03_TASK_'+a.control+'_B'+str(batch),system=S)as owner:
            if batch==0:
                admission=owner.material('PI03_R02_'+a.control+'_ADMITIR',{'modo':'eci01-pi03-tarea-admitir','serie':'continuous','control':a.control},feedback='omit')
                record['admission']=admission;save()
            for i in range(begin,end):
                result=owner.material('PI03_R02_'+a.control+'_OP_'+str(i),{'modo':'eci01-pi03-tarea-oportunidad'},feedback='omit')
                value=result['result']['rows'][0]
                row={'opportunity':i,'transport_id':result['id'],'before_tick':result['before_tick'],'after_tick':result['after_tick'],'series':value['spec']['series'],'delay_laps':value['spec']['delay_laps'],'choice':value['reader']['choice'],'emitted_motor':value['emitted_motor'],'applied_motor':value['applied_motor'],'useful_product':value['useful_product'],'actual_effect':value['actual_effect'],'returned_failed':value['returned_failed'],'primary':'ensayos/PI03_R02_'+a.control+'_OP_'+str(i)+'.json'}
                record['rows'].append(row);record['last_tick']=result['after_tick'];save()
                if value['reader']['choice'] is None or any(r['receipt']['status']!='applied'for r in value['requests']):raise RuntimeError('FirstNULL or required rejected input reached; preserve actual future, no rescue')
            record['closed_batches']+=1
        save()
    record['status']='COMPLETED';record['actual_products']=sum(r['useful_product']for r in record['rows']);record['denominators']={'offered':a.hasta,'completed':len(record['rows']),'formed_Native_responses':sum(r['choice']is not None for r in record['rows']),'material_zero_codec_uses':sum(r['choice']==0 for r in record['rows']),'useful_products':record['actual_products'],'failed_actual_effects':sum(not r['useful_product']for r in record['rows'])};record['finished_local']=datetime.datetime.now().astimezone().isoformat();save()
    print(json.dumps({'life':life,'products':record['actual_products'],'opportunities':a.hasta,'tick':record['last_tick'],'summary':str(summary)}),flush=True)
except BaseException as error:
    record['status']='STOPPED_FUTURE_PRESERVED';record['error']=repr(error);save();raise
