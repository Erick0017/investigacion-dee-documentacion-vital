"""One real continuation, new actual source data and contingency reversal.

R02's fourteen cases are closed and never relabeled. These five additional
offers use the SAME learned Native state across process boundaries. No clone
learning or correct numeric answer is imported into the main candidate.
"""
from pathlib import Path
import datetime,json,sys
P=Path(__file__).resolve().parent.parent;S=P/'estados/candidato/sistema'
sys.path.insert(0,str(P/'codigo'))
from servicio_ensayo import Owner
LIFE='ECI02_PI03_MAIN';out=P/'control/CONTINUACION_CADENA_R04.json'
if out.exists():raise FileExistsError('Inspect the reached continuation, no automatic replay')
config=json.loads((P/'control/PROTOCOLO_VARIACION_CADENA_R04_SELLADO.json').read_text())
record={'schema':'DEE.PI03.variable_chain.executed.R04','life':LIFE,'started_local':datetime.datetime.now().astimezone().isoformat(),'status':'RUNNING','cases':[],'original_R02_history_preserved':True,'new_conditions_held_out_from_R02':True}
def save():out.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
save()
try:
    for case in config['cases']:
        row={'label':case['label'],'source':None,'opportunities':[]};record['cases'].append(row);save()
        with Owner(LIFE,'PI03_R04_'+case['label'],system=S)as owner:
            source=owner.material('PI03_R04_'+case['label']+'_FUENTE_Y_OFERTAS',case['supply'],feedback='omit')
            row['source']=source;save()
            for i in range(case['offers']):
                result=owner.material('PI03_R04_'+case['label']+'_OP_'+str(i),{'modo':'eci01-pi03-tarea-oportunidad'},feedback='omit')
                value=result['result']['rows'][0]
                row['opportunities'].append({'result':result,'primary':'ensayos/PI03_R04_'+case['label']+'_OP_'+str(i)+'.json'});save()
                if value['reader']['choice']is None or any(r['receipt']['status']!='applied'for r in value['requests']):raise RuntimeError('Preserve firstNULL/rejected input; no rescue or alternate decoder')
        row['owner_closed']=True;save()
    # Explicitly leave two real environmental offers available; counters and
    # all consumed resources are preserved, never reset. This is NOT learning.
    with Owner(LIFE,'PI03_R04_FINAL_STOCK',system=S)as owner:
        stock=owner.material('PI03_R04_FINAL_STOCK_EXPLICIT',{'modo':'eci01-pi03-tarea-suministrar','cantidad':2,'conexion':-1,'demora_periodos':4},feedback='omit')
        record['final_explicit_supply']=stock;save()
        export=json.loads(owner.control('exportar')['result'])
    record.update(status='COMPLETED',closed=True,final_tick=stock['after_tick'],paired_export=export['paired_export'],products_additional=sum(item['result']['result']['rows'][0]['useful_product']for case in record['cases']for item in case['opportunities']),finished_local=datetime.datetime.now().astimezone().isoformat());save()
    print(json.dumps({'life':LIFE,'additional_products':record['products_additional'],'five_offers':5,'tick':record['final_tick'],'remaining_offers':2,'summary':str(out)}),flush=True)
except BaseException as error:
    record.update(status='STOPPED_FUTURE_PRESERVED',error=repr(error));save();raise
