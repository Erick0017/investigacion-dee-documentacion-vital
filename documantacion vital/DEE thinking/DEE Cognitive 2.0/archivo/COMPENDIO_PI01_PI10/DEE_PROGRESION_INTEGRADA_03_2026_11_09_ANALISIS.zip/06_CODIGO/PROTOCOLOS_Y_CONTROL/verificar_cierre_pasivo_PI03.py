"""Final bounded file/closed-queue checks; never imports DEE or opens a world."""
from pathlib import Path
import datetime,hashlib,json,sqlite3,zipfile,xml.etree.ElementTree as E
P=Path(__file__).resolve().parents[1];C=P.parents[2]/'DEE Cognitive 2.0';S=C/'sistema';L='ECI02_PI03_MAIN'
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8-sig'))
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def item(p):return{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def main():
 out=P/'control/INTEGRIDAD_CIERRE_PI03.json'
 if out.exists():raise FileExistsError('Final preservation witness already exists; inspect rather than repeat blindly')
 expected=[(S/'runtime/dee_thinking-4.5.0-cp313-cp313-win_amd64.whl','09e191d259fd15d321ea11b587f8cc02c12c7adfe81b7b96ca2dbebb1fb12d0c'),
 (C/'motor/python313/site-packages/dee_thinking/_native.cp313-win_amd64.pyd','17f827341530f66816ec146af085b00a5f7b3d34d645bcd407f1279e8ac6c50d'),
 (C/'DEE_Cognitive_2_0_Manual_Maestro_DCS11_MM_001_Edicion_1_21.docx','86e72b0d35e340effeb83c9fd018ad0ab3bf1fe2e4aa1d6fa12fea2926bd243f'),
 (C.parent/'CPC - Experimentos y mecanismos/COMPENDIO_MAESTRO_DE_MECANISMOS_Y_RESULTADOS_DEE.docx','ed87088d828a60c3cae7a0205a3f30d8924f66dcce2ee7ab0f6085c647226096')]
 critical=[item(p)for p,_ in expected]
 for row,(_,digest)in zip(critical,expected):
  if row['sha256']!=digest:raise ValueError('Critical identity changed:'+row['path'])
 selectors={n:read(C/n)for n in('PROYECTO.json','CONTINUIDAD_DEE_COGNITIVE_2_0.json','sistema/estado/ACTIVO.json','sistema/estado/genesis/SELECCION_PERSONAL.json','aplicacion/GENESIS/SELECCION_CANDIDATA.json')}
 if selectors['PROYECTO.json']['selected_life']!=L or selectors['CONTINUIDAD_DEE_COGNITIVE_2_0.json']['life_id']!=L or selectors['sistema/estado/ACTIVO.json']['life_id']!=L or selectors['sistema/estado/genesis/SELECCION_PERSONAL.json']['life_id']!=L or selectors['aplicacion/GENESIS/SELECCION_CANDIDATA.json']['source_life']!=L:raise ValueError('Selectors disagree')
 lives=[]
 for life,tick,digest in((L,775355,'5581d3785bf7d7194b5bdb545827aab55f0659d8b3f2c00301425d89616cf07b'),('ECI02_PI02_MAIN',753346,'17da00843456f1a76faafcbc42cd72b6395753d439e62edd02883d0f7e8d5c88')):
  f=S/'estado/vidas'/life/'VIDA.json';card=read(f);snapshot=S/card['snapshot']
  if card['physical']['N']!=67 or card['physical']['tick']!=tick or card['snapshot_sha256']!=digest or sha(snapshot)!=digest:raise ValueError('Physical cut advanced/changed; do not overwrite it')
  if(S/'estado/locks'/(card['world_id']+'.lock')).exists()or(f.parent/'FUTURO_INTERRUMPIDO.json').exists():raise ValueError('Affected life is not closed')
  db=S/'estado/servicios_persistentes'/life/'cola.sqlite3'
  for suffix in('-wal','-journal'):
   x=Path(str(db)+suffix)
   if x.exists()and x.stat().st_size:raise ValueError('Nonempty SQLite auxiliary; refuse incoherent immutable read')
  before=sha(db);conn=sqlite3.connect(db.as_uri()+'?mode=ro&immutable=1',uri=True)
  try:
   owner=json.loads(conn.execute("SELECT value FROM meta WHERE key='owner'").fetchone()[0]);pending=conn.execute("SELECT id,status FROM requests WHERE status IN('queued','processing','uncertain')").fetchall()
  finally:conn.close()
  if before!=sha(db)or owner.get('running')or pending:raise ValueError('Closed queue consistency changed')
  lives.append({'life_id':life,'physical':card['physical'],'identity':item(f),'snapshot':item(snapshot),'queue_sha256_before_after':before,'pending':pending,'cached_owner_running':owner['running'],'cache_scope':'Corroborated by the recorded exact-owner close/process proofs and no locks; not an instantaneous material observation.'})
 d=read(P/'control/DECISION_FINAL_PI03.json');code=[]
 for x in d['approved_code_files']:
  path=S/x['file'];actual=sha(path);want='1dad8e7f63303b8584f31a165c9f517141e6c80830b43699adee9e59833fc2f5'if x['file']=='gestionar.py'else x['sha256']
  if actual!=want:raise ValueError('Deployed Cognitive code differs:'+x['file'])
  code.append({'file':x['file'],'sha256':actual,'OP4_console_only_delta':x['file']=='gestionar.py'})
 xml_parts=0
 for row in critical[2:]:
  with zipfile.ZipFile(row['path'])as z:
   if z.testzip()is not None:raise ValueError('Document package CRC failed')
   for name in z.namelist():
    if name.endswith('.xml')or name.endswith('.rels'):E.fromstring(z.read(name));xml_parts+=1
 current=read(C/'CONTINUIDAD_DEE_COGNITIVE_2_0.json')['manual_current']
 result={'schema':'DEE.PI03.final_passive_preservation.v1','recorded_local':datetime.datetime.now().astimezone().isoformat(),'critical':critical,'closed_lives':lives,'selectors':{k:item(C/k)for k in selectors},'deployed_code':code,
 'manual_internal_edition':'1.30','document_XML_parts_parsed':xml_parts,'manual_publication':current,'visual_validation':'PENDING_RENDER_BLOCKED_NOT_CLAIMED','new_Native_ticks':0,'DEE_imports':0,'originals_written':False,
 'scope':'Only listed critical files and two affected operational lives. No claim that every file in the project was reread, unchanged or visually reviewed. SHA matches prior verified full snapshots; no new material capacity panel.'}
 for row in critical:
  if sha(Path(row['path']))!=row['sha256']:raise ValueError('Critical file changed while checking')
 with out.open('x',encoding='utf-8')as f:json.dump(result,f,ensure_ascii=False,indent=2)
 print(json.dumps({'proof':str(out),'principal':L,'N':67,'T':775355,'protected_parent':753346,'critical_files':len(critical),'deployed_files':len(code),'new_Native_ticks':0,'visual_validation':result['visual_validation']},ensure_ascii=False))
if __name__=='__main__':main()
