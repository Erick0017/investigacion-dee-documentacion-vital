# Reproducibilidad de Cognitive

Este apartado conserva recetas y materiales compartidos. No es otro ente principal ni un respaldo universal. El estado aprendido, su adquisición, el recálculo de registros y la recuperación de acceso se identifican por separado.

El principal adoptado es `ECI02_PI03_MAIN`, N67, T775355, descendiente físico de `ECI02_PI02_MAIN` T753346 mediante las preparaciones declaradas. Conserva su estado completo y dos ofertas externas de tarea disponibles: 26 cápsulas preparadas, 24 consumidas, 19 productos y 5 rechazos. El puente PI02 separado tiene 10 productos, 16 episodios y 4 paquetes de control, y queda pausado. Son recursos y resultados del entorno; no conceptos ni energía del ente.

Desde `DEE Cognitive 2.0`, usando el Python oficial ya incluido:

```bat
motor\python313\python.exe -I -B -X utf8 sistema\gestionar.py reproducibilidad listar
motor\python313\python.exe -I -B -X utf8 sistema\gestionar.py reproducibilidad verificar pi03_guardia_cola_R05c
motor\python313\python.exe -I -B -X utf8 sistema\gestionar.py reproducibilidad recalcular --destino D:\destino_nuevo_recalculo --grupos E
motor\python313\python.exe -I -B -X utf8 sistema\gestionar.py reproducibilidad reproducir pi03_uso_final_OP3 --variante una_oportunidad --vida ECI02_PI03_REPRO_USO_NUEVO_01 --destino D:\destino_nuevo_uso
```

Sustituya los destinos por carpetas nuevas cuyo padre ya exista. Las dos primeras órdenes sólo leen archivos y no importan DEE. `recalcular` sólo ejecuta verificadores documentales stdlib sobre el material preservado: no ejecuta el motor. `reproducir` sí presenta experiencias materiales a una copia completa y consume su historia; exige destino explícito y un ID diagnóstico nuevo. Nunca cambia ACTIVO ni promueve controles.

La puerta del gestor se ejecuta como primer comando, sin `--system-root`. El acceso directo por `reproducibilidad/reproducir.py` sigue disponible. La corrección instrumental OP4 captura y reenvía stdout/stderr explícitamente para Windows; se comprobó con JSON no vacío de listar y verificar, sin alterar ACTIVO, estado, motor ni las cinco herramientas materiales. Su único archivo y referencia a la cápsula completa C están en `codigo_preservado/PI03_OP4_FORWARDING/` y `RECURSOS.json/instrument_deltas`.

`pi03_uso_final_OP3` consulta progreso, ofrece una oportunidad y vuelve a consultar el estado en un clon desde T775355. Está preparada y sus requisitos están localizados: **no se ejecutó Native esta receta desde ese corte final**. El uso retenido real de MAIN terminó en T775355; no se atribuye a esa receta futura ni a otro panel completo. El último panel de doce usos terminó en T769703, seguido de dos trabajos O/H hasta T771503 y más trabajos PI03 hasta el corte final.

La receta `pi03_guardia_cola_R05c`, variante `guard`, sí se ejecutó Native desde el prefijo científico T768317: llegó a T772227, produjo cero material en el lector q+6 y un nuevo producto real de 64 bytes. Cinco entradas de tarea y una de guarda se aplicaron, sin rechazos; la comprobación pasiva verificó las seis IDs y coincidencia exacta N/T/RAW/clocks con el caso B. Es reproducción de protección preparada P0, no aprendizaje de esa guarda o regulación general. Sus verificaciones y evidencia pequeña permanecen en `verificaciones/pi03_guardia_cola_R05c/` aunque el árbol diagnóstico cerrado se haya archivado.

`RECURSOS.json` resuelve materiales grandes dentro del producto. `recetas/` fija prefijo, variantes, entradas, lectores, ventanas ya implementadas por los módulos preservados, criterios y asistencia. `codigo_preservado/PI02_R04_OP1` conserva la revisión compartida, separada de modificaciones posteriores del producto. `codigo_preservado/historico_PI02` conserva los originales exactos y su procedencia; esos originales se estudian como texto, porque sus rutas históricas no son portables. Las adaptaciones ejecutables son los scripts de este apartado y tienen revisión propia.

Las recetas fijan un corte; no siguen ACTIVO automáticamente. `panel_12` y `pi02_uso_protegido` documentan el corte inicial PI02 T753346. Si se adopta una continuación con nuevos puentes o recursos, necesita su propia cápsula/receta comprobada; cambiar sólo el prefijo sería insuficiente. Una receta puede declarar `code_capsule_key`, resuelto en `RECURSOS.json/code_capsules`, para compartir una revisión posterior sin sustituir la PI02 histórica. Las nuevas ejecuciones fijan también los hashes de sus cinco scripts de instrumentación antes de abrir Native.

Una coincidencia de resultados con la receta no implica inteligencia general, determinismo binario universal ni adquisición nueva del principal. La comparación al importar comprueba RAW, clocks, interfaces, agenda y recibos sin nuevos ticks, permitiendo sólo el cambio administrativo de identidad. El diario completo se importa con el contrato existente y reconcilia recibos; no se purgan pendientes ni se repiten operaciones ambiguas.

Cada ejecución conserva `CONTEXTO_EJECUCION.json`, `IMPORTACION_DIAGNOSTICA.json`, `RESULTADO_REPRODUCCION.json`, primarios, diario, stdout/stderr y el estado diagnóstico completo. Los controles comparten un prefijo: no son réplicas independientes. El panel es material; cambiar de lector o consultar repetidamente puede alterar lo que se estudia.

Si falla el acceso: primero use `verificar`, sin actuar. Distinga material faltante, recurso agotado, fase/lector, rechazo de admisión, interferencia y contenido no demostrado. La receta `fi_recuperacion` documenta un caso concreto de retirada de interferencia sin restauración ni reenseñanza; no garantiza recuperar cualquier contenido. Cargar un prefijo antiguo sólo conserva su historia anterior, perdiendo las experiencias posteriores de la copia: es restauración externa, no autorreparación del ente.

No vuelva a ejecutar una operación incierta con otro ID. Un bloqueo `EJECUCION_MATERIAL.lock` preservado exige comprobar su PID, propietario y futuro interrumpido antes de retirarlo. El sistema no mata propietarios ni borra bloqueos automáticamente. La rueda se comparte mediante enlace duro de sólo uso previsto; si el destino está en otro volumen, use un destino diagnóstico en el volumen del producto. No se reinstala ni se modifica el motor.

La sección `verification` de cada receta distingue preparada, ejecutada en una copia, adquisición, uso y control. Una receta preparada no se declara comprobada hasta que su evidencia de ejecución y alcance estén registrados.

Después de una ejecución diagnóstica realmente completada y cerrada, el responsable puede registrar su evidencia sin ejecutar DEE:

```bat
motor\python313\python.exe -I -B -X utf8 reproducibilidad\registrar_verificacion.py --resultado D:\destino_nuevo_panel\RESULTADO_REPRODUCCION.json --nota "Reproducción diagnóstica, no promoción"
```

El registro comprueba identidades, importación y primarios; conserva también los resultados locales negativos. `listar` y `verificar` muestran estas comprobaciones separadas de la receta preparada. Registrar una comprobación no cambia el decodificador, el estado aprendido, ACTIVO ni la clasificación cognitiva; tampoco convierte un uso desde un estado aprendido en reproducción de su adquisición.

La preparación de una revisión PI03 posterior usa `preservar_revision_pi03.py --descriptor <JSON>` para verificar fuentes sin actuar. `--aplicar --comprobante <archivo_nuevo>` conserva una cápsula y pares completos explícitos y añade recetas; no ejecuta DEE. La receta inicial `pi03_tarea_R02_adquisicion` conserva su condición histórica de preparación. La revisión `pi03_tarea_R02_adquisicion_reproducible` sí se ejecutó en una copia: 11 productos en 14 oportunidades, 422/422 entradas Native aplicadas y coincidencia final N/T/RAW/clocks con el estado aprendido T764407. Su comprobante está en `verificaciones/pi03_tarea_R02_adquisicion_reproducible/`; los controles fuente 7/14 y 0/14 siguen identificados por separado y no se presentan como ejecuciones nuevas de las otras variantes de esa receta. Si un lector R02 devuelve NULL, se conserva esa oportunidad y se cierra sin enviar la siguiente; el resumen distingue cierre limpio de reproducción completa. Cero material nunca activa esa parada.

Cinco ejecuciones diagnósticas cerradas y siete controles de calibración se preservaron en un archivo local deduplicado con todas sus rutas, archivos y carpetas vacías. Sus verificaciones conservan la procedencia histórica y añaden `archive_locator`; las recetas siguen resolviendo sus prefijos completos en el almacén estable del producto. El archivo no sustituye al principal ni aporta recuerdos de los controles a otra vida.

`mover_par_cerrado_pi03.py` permite verificar y trasladar un único export completo ya cerrado a `materiales/`, en el mismo volumen, sin crear otra copia de sus cientos de megabytes. Exige el hash del manifiesto, corte exacto y una comprobación reciente de ausencia de propietario. Su modo predeterminado sólo verifica; `--aplicar` requiere además un comprobante nuevo y conserva la correspondencia entre origen histórico y ubicación estable. Nunca mueve el estado operativo vivo, importa DEE ni promueve una vida.
