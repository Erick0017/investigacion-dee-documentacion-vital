"""Root-only complete B_REAL18 conservation-clone import under512MiB owned Job.

RevisionR03 preserves the exact published RP importer/context pins, then
materializes only declared empty source directories before any owner.
Default prints a plan. --importar starts the official importer once and waits
for its exit BEFORE any owner may open this new diagnostic world. No time step,
selection, copying of separate memories, state editing or automatic retry.
"""
from pathlib import Path
from datetime import datetime, timezone
import argparse, ctypes, hashlib, importlib.util, json, os, sys, time

P = Path(__file__).resolve().parents[1]
C = P.parents[2]/'DEE Cognitive 2.0'
RP = C/'reproducibilidad'
PY = C/'motor/python313/python.exe'


def read(path): return json.loads(Path(path).read_text('utf-8-sig'))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok, message):
    if not ok: raise ValueError(message)


def main(args):
    prep = read(P/'control/SISTEMA_CONSERVACION_B_PI08_R01_PREPARADO.json')
    item = prep['context']; system = Path(item['system']); destination = Path(item['directory']); life = item['life']
    context = Path(item['context']); require(sha(context) == item['context_sha256'], 'Fixed complete-pair context changed')
    command = [str(PY), '-I', '-B', '-X', 'utf8', str(RP/'importar_diagnostico.py'), '--contexto', str(context)]
    if not args.importar:
        print(json.dumps({'mode': 'PLAN_ONLY_NO_NATIVE', 'command': command, 'memory_limit': 536870912,
                          'life': life, 'new_Native_ticks': 0, 'no_automatic_owner_start': True}, ensure_ascii=False, indent=2))
        return
    require(system.resolve().is_relative_to((P/'estados').resolve()) and not (system/'estado/ACTIVO.json').exists(), 'Explicit unselected PI08 system only')
    for folder in ('vidas', 'servicios_locales', 'servicios_persistentes'):
        require(not (system/'estado'/folder/life).exists(), 'Identity already used; no repeat import')
        require(not (C/'sistema/estado'/folder/life).exists(), 'Identity already exists in product')
    require(not (destination/'IMPORTACION_DIAGNOSTICA.json').exists(), 'Preserve prior import proof')
    marker = P/'PI08_ROOT_NATIVE_WRITER.lock'
    require(not marker.exists() and not (RP/'EJECUCION_MATERIAL.lock').exists(), 'A Native/import writer remains')
    for name in ('estado/locks',):
        path = system/name; require(not path.exists() or not any(path.iterdir()), 'A diagnostic lock remains')
    seal = read(P/'codigo/SELLO_PI08_B_R01.json')
    original = C/'sistema/estado/ACTIVO.json'; active_before = sha(original)
    require(read(original)['life_id'] == 'ECI02_PI03_REPRO_PI04_PI05_PI07_RP_R03_PI08_A01', 'A must be adopted before B')
    source_manifest = read(Path(read(context)['prefix'])/'EXPORTACION_SERVICIO.json')
    require(source_manifest['life_id'] == seal['research_life_ids']['real'] and source_manifest['physical']['tick'] == 875451 and sha(Path(read(context)['prefix'])/'EXPORTACION_SERVICIO.json') == read(context)['prefix_manifest_sha256'], 'Exact closed B_REAL18 source required')
    require(life == seal['conservation_life_id'], 'Only sealed conservation identity; never an extra B action arm')
    cutoff = datetime.fromisoformat(read(P/'REGISTRO_CAMPANA.json')['budget']['new_experimental_uses_cutoff_local']).astimezone(timezone.utc)
    require(datetime.now(timezone.utc) < cutoff, 'Research cutoff reached')
    sys.path.insert(0, str(system))
    from app import process_control as pc  # stdlib Windows Job supervisor only.
    with marker.open('x', encoding='utf8') as out: json.dump({'pid': os.getpid(), 'operation': 'COMPLETE_PAIR_IMPORT_ONLY', 'life': life}, out)
    process = job = None; error = None; resources = {}; directory_transport = None; job_closed_after_verified_import = False; peak = 0; started = time.monotonic()
    stdout = (destination/'importar_diagnostico.R03.stdout.txt').open('x', encoding='utf8')
    stderr = (destination/'importar_diagnostico.R03.stderr.txt').open('x', encoding='utf8')
    try:
        process, job, jobname = pc.spawn_owned(command, cwd=str(P), stdout=stdout, stderr=stderr, memory_limit=536870912)
        while process.poll() is None:
            resources = pc.job_resources(job); peak = max(peak, resources.get('peak_job_committed_bytes', 0))
            if time.monotonic()-started > 240:
                raise TimeoutError('Importer finite host wait exceeded; preserve destination and exact Job, no retry or cleanup')
            time.sleep(.1)
        resources = pc.job_resources(job); peak = max(peak, resources.get('peak_job_committed_bytes', 0))
        require(process.returncode == 0, 'Complete-pair importer failed; preserve logs/future')
        imported = read(destination/'IMPORTACION_DIAGNOSTICA.json')
        require(imported['new_native_ticks'] == 0 and imported['principal_selected'] is False, 'Importer advanced/selected unexpectedly')
        require(sha(original) == active_before, 'Original adopted A selection changed')
        require(imported['comparison']['physical_equal'] is True and imported['comparison']['causal_prefix_equal'] is True, 'Actual full import physical/prefix proof required')
        # Import CLI exited0 and published its coherent full proof. Close only
        # this successful owned import job before a filesystem-only supplement.
        if job is not None:
            pc.close_job(job); job = None; job_closed_after_verified_import = True
        supplement_path = Path(__file__).with_name('directorios_pareados_PI08_R01.py')
        require(sha(supplement_path) == 'd88b99bbc6d1fb72d4e32916815fb48079f8ed2befc5674b836e171838354957', 'Pinned directory transport supplement changed')
        spec = importlib.util.spec_from_file_location('PI08_exact_directory_transport', supplement_path)
        supplement = importlib.util.module_from_spec(spec); spec.loader.exec_module(supplement)
        directory_transport = supplement.materialize(system, life, context, imported, process.pid, apply=True)
    except Exception as exc:
        error = {'type': type(exc).__name__, 'message': str(exc), 'automatic_retry': False}
    closed = process is not None and process.poll() is not None
    output = {'schema': 'DEE.PI08.B.conservation.actual_complete_import.R01', 'role': 'conservation_only', 'life_id': life,
              'status': 'IMPORTED_CLOSED_NO_NATIVE_TICKS' if error is None and closed else 'FAILED_IMPORT_PRESERVED',
              'closed': closed, 'error': error, 'new_Native_ticks': 0, 'importer_Runtime_opened': process is not None,
              'exit_code': None if process is None else process.poll(), 'job_resources': resources,
              'peak_job_committed_bytes': peak, 'memory_limit_bytes': 536870912,
              'context': str(context), 'context_sha256': sha(context), 'command': command,
              'full_import_proof': str(destination/'IMPORTACION_DIAGNOSTICA.json'),
              'directory_transport_supplement': directory_transport, 'successful_import_job_closed_before_supplement': job_closed_after_verified_import,
              'no_owner_started': True, 'principal_unchanged': sha(original) == active_before}
    proof = P/'control'/'IMPORTACION_B_CONSERVACION_PI08_R01.json'
    with proof.open('x', encoding='utf8') as out: json.dump(output, out, ensure_ascii=False, indent=2); out.write('\n')
    if closed:
        stdout.close(); stderr.close()
        if job is not None: pc.close_job(job)
        if error is None: marker.unlink()
    print(json.dumps({'proof': str(proof), 'sha256': sha(proof), 'status': output['status'], 'error': error}, ensure_ascii=False))
    if error: raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--importar', action='store_true')
    main(parser.parse_args())
