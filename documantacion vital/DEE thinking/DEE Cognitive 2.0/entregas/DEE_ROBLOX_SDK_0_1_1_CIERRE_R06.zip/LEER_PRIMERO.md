# SDK DEE–Roblox 0.1.1 y resultados locales

Esta entrega reúne el kit público, el informe y sus pruebas seleccionadas, y el MP4 final. No contiene runtime privado, cerebro Native, estados operativos completos, bases de datos ni credenciales. El expediente sirve para revisar resultados; no es un respaldo ejecutable del ente.

1. Lea `RESULTADOS_R06/INFORME_CIERRE_SDK_R06.md`: alcance, resultados locales K1–K4, capacidades asistidas, incidencias y contraste focal separado. Las pruebas del operador no son evaluación externa; K5 sigue pendiente.
2. El kit previsto para compartir está íntegro en `SDK_PUBLICO/`. Su punto de entrada es `SDK_PUBLICO/LEER_PRIMERO.md`. Usar Native requiere el backend privado autorizado; no hay endpoint remoto ofrecido ni runtime distribuido aquí.
3. El vídeo es `RESULTADOS_R06/DEMOSTRACION/MONTAJE_0_1_1_FINAL_R02/DEE_ROBLOX_SDK_CIERRE_R06.mp4`: 129 segundos, sin audio, lienzo compuesto 1920×1080. Distingue 15 segundos auténticos históricos de R07 de paneles actuales de registros Native. El movimiento no demuestra por sí solo aprendizaje. La comparación histórica conserva sus denominadores y preparación diferente; Llama ejecutó 2/18 oportunidades, las otras16 no se ofrecieron.
4. Los recibos y recálculos están en `RESULTADOS_R06/EXPORT_CHATGPT/` y `RESULTADOS_R06/DEMOSTRACION/`. Los comandos pasivos del informe verifican registros; no avanzan Native.

## Verificación del kit público

Ejecute desde **dentro de `SDK_PUBLICO/`**:

```text
python herramientas/ensamblar_publico_R06.py verify --root .
```

Ese checker exige exactamente los42 miembros públicos. No lo ejecute apuntando a la raíz de esta entrega, que también contiene resultados y vídeo. Verificar integridad no reproduce Roblox ni acredita nuevos resultados científicos.

`MANIFIESTO_ENTREGA.json` registra tamaño y SHA-256 de cada miembro de contenido, incluido el manifiesto público literal. Excluye su propio hash; el SHA del ZIP se registra fuera del ZIP. Los archivos originales seleccionados se transportan sin modificar sus bytes. No se anidan los ZIP anteriores.

El propietario mantiene localmente las vidas y dependencias completas. Los cortes históricos, los diagnósticos y los controles no se convierten en principal por estar incluidos como evidencia. No publique ni distribuya componentes privados sin una autorización separada.
