#!/usr/bin/env python3
"""Recálculo K4 portable sólo sobre el export Core2 cerrado. Cero Native/SQLite/HTTP."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value):
    return hashlib.sha256(canonical(value).encode("utf-8")).hexdigest()


def read(path):
    return json.loads(path.read_text("utf-8-sig"))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--export-root", required=True, type=Path)
    p.add_argument("--comparison-code", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    a = p.parse_args()
    root = a.export_root.resolve(strict=True)
    if a.output.exists():
        raise FileExistsError("New result required; preserve prior reports")
    manifest = read(root / "MANIFIESTO_SHA256.json")
    for item in manifest["members"]:
        path = root / item["path"]
        assert path.resolve().is_relative_to(root) and not path.is_symlink()
        raw = path.read_bytes()
        assert len(raw) == item["bytes"] and hashlib.sha256(raw).hexdigest() == item["sha256"]
    spec = importlib.util.spec_from_file_location("pure_restoration_comparison", a.comparison_code)
    contract = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(contract)
    home = root / "PROTOCOLO_NORMAL_R06"
    cfg, current = read(home / "INSTANCE.json"), read(home / "SDK_PAIR.json")
    archive_paths = sorted(home.glob("SDK_PAIR_*.json"))
    pairs = [(path, read(path)) for path in archive_paths]
    pairs.append((home / "SDK_PAIR.json", current))
    pair_checks = []
    for path, pair in pairs:
        state, proof = pair["snapshot"]["state"], dict(pair["backendProof"])
        proof_hash = proof.pop("proofSha256")
        checks = {"snapshotDigest": digest(pair["snapshot"]) == pair["snapshotSha256"], "backendProofDigest": digest(proof) == proof_hash, "identity": state["sessionId"] == cfg["sessionId"] == pair["sessionId"] and state["lifeId"] == cfg["lifeId"], "tick": state["nativeTick"] == proof["nativeTick"] == pair["native"]["nativeTick"], "cursor": state["sequence"] == pair["localSequence"] == proof["localSequence"], "closed": proof["backendWriterClosed"] is True and proof["bridgeQuiescent"] is True and state["phase"] == "BOUNDARY"}
        pair_checks.append({"file": path.relative_to(root).as_posix(), "fileSha256": hashlib.sha256(path.read_bytes()).hexdigest(), "checkpointId": pair["checkpointId"], "snapshotSha256": pair["snapshotSha256"], "nativeTick": state["nativeTick"], "localSequence": pair["localSequence"], "checks": checks})
        assert all(checks.values())
    rows = [read(path) for path in sorted((home / "http_operations").glob("*.json"))]
    by_id = {row["operationId"]: row for row in rows}
    assert len(rows) == len(by_id)
    acknowledgments = read(home / "ACTION_ACKS.json")
    results = []
    for path in sorted((home / "restoration_proofs").glob("*.json")):
        record = read(path)
        body, value = record["body"], record["value"]
        old_match = [(old_path, pair) for old_path, pair in pairs if pair["snapshotSha256"] == record["checkpointSha256"] and pair["localSequence"] < current["localSequence"]]
        if not old_match:
            continue
        old_path, old = old_match[0]
        old_state, current_state = old["snapshot"]["state"], current["snapshot"]["state"]
        checksum_record = dict(record)
        checksum_record.pop("value")
        expected = contract.expected_view(old["snapshot"])
        actual_comparison = contract.compare(expected, body["proof"]["actual"])
        supplied_expected_comparison = contract.compare(expected, body["proof"]["expected"])
        wanted_ledger = set(expected["actions"]) | {expected["state"]["lastFeedbackOperationId"]}
        recorded_ledger = {item["operationId"]: item for item in record["serverLedgerCheck"]}
        ledger_ok = wanted_ledger == set(recorded_ledger) and all(recorded_ledger[op]["status"] == "COMPLETED" and recorded_ledger[op]["value"] == by_id[op]["value"] for op in wanted_ledger)
        later = [row for row in rows if row.get("kind") in ("decision", "query_sensor", "feedback") and row.get("localSequence", -1) > old["localSequence"]]
        later_ids = [row["operationId"] for row in later]
        later_kinds = {row["kind"] for row in later}
        later_done = bool(later) and {"decision", "feedback"}.issubset(later_kinds) and all(row["status"] == "COMPLETED" and row["admittedUtcEpoch"] > record["recordedUtcEpoch"] and row["nativeContext"]["mode"] == "LIVE_NATIVE" and row["body"]["sessionId"] == cfg["sessionId"] for row in later)
        last_feedback = by_id[current_state["lastFeedbackOperationId"]]
        action_id = last_feedback["body"]["payload"]["actionId"]
        action = by_id[action_id]
        ack = acknowledgments[action_id]["ack"]
        committed = current["snapshot"]["actions"][action_id]
        later_return = last_feedback in later and last_feedback["value"]["accepted"] is True and ack["executionStatus"] == "EXECUTED" and ack["technicalControl"] is False and committed["status"] == "COMMITTED" and committed["ack"] == ack and action["localSequence"] == ack["seq"] == last_feedback["localSequence"]
        checks = {
            "literalManifestMembersVerified": True,
            "recordAndRequestDigests": digest(checksum_record) == value["restorationProofSha256"] and digest(body) == record["requestSha256"],
            "priorPairFileHash": hashlib.sha256(old_path.read_bytes()).hexdigest() == record["pairSha256"] == body["pairSha256"],
            "priorSnapshotHash": old["snapshotSha256"] == record["checkpointSha256"] == body["checkpointSha256"],
            "recordedBeforeAdmission": record["status"] == "RECORDED" and record["nativeAdmissionStarted"] is False,
            "fullRestorationRecalculated": actual_comparison["passed"] and supplied_expected_comparison["passed"],
            "serverAndClientComparisonsAgree": record["serverComparison"]["differenceCount"] == body["proof"]["differenceCount"] == actual_comparison["differenceCount"] == 0 and record["serverCursorMatched"] is True,
            "savedLedgerMatched": ledger_ok,
            "sameLifeSessionAndForwardCursor": current_state["lifeId"] == old_state["lifeId"] == cfg["lifeId"] and current_state["sessionId"] == old_state["sessionId"] == cfg["sessionId"] and current_state["sequence"] > old_state["sequence"] and current_state["completedOpportunities"] > old_state["completedOpportunities"] and current_state["nativeTick"] > old_state["nativeTick"],
            "laterNativeUseCompletedAfterProof": later_done,
            "laterEffectAckAndReturnCommitted": later_return,
            "latestNativeAndAgentClosedAtSameTick": current_state["nativeTick"] == cfg["nativeTick"] and current["backendProof"]["backendWriterClosed"] is True,
        }
        results.append({"restorationOperationId": record["operationId"], "source": path.relative_to(root).as_posix(), "sourceBytes": path.stat().st_size, "sourceFileSha256": hashlib.sha256(path.read_bytes()).hexdigest(), "restorationProofDigestInternal": value["restorationProofSha256"], "priorTick": old_state["nativeTick"], "finalTick": current_state["nativeTick"], "priorSequence": old_state["sequence"], "finalSequence": current_state["sequence"], "priorCompleted": old_state["completedOpportunities"], "finalCompleted": current_state["completedOpportunities"], "differenceCountRecalculated": actual_comparison["differenceCount"], "poseTolerance": actual_comparison["poseTolerance"], "laterNativeOperationIds": later_ids, "checks": checks, "K4": "DOCUMENTED_RESTORATION_AND_POSTERIOR_USE" if all(checks.values()) else "PENDING_UNRESOLVED_K4_CHECKS"})
    report = {"schema": "DEE.SDK.CIERRE_R06.K4PassiveRecalculation.v1", "mode": "DOCUMENTARY_ONLY_NOT_NATIVE_REPRODUCTION", "K4": "DOCUMENTED_RESTORATION_AND_POSTERIOR_USE" if any(item["K4"] == "DOCUMENTED_RESTORATION_AND_POSTERIOR_USE" for item in results) else "PENDING", "pairChecks": pair_checks, "restorationChecks": results, "NativeExecuted": False, "sqliteOpened": False, "httpRequested": False, "originalSourcesOpened": False, "comparisonCodeSha256": hashlib.sha256(a.comparison_code.read_bytes()).hexdigest(), "limits": ["Local diagnostic continuation only; not external validation or indefinite recovery.", "Numeric tolerance is 1e-5 only for poses/transforms under the documented pure contract; counters/identity/ledger remain exact.", "Proof is technical comparison before material observation; no restoration record is counted as a Native operation."]}
    with a.output.open("x", encoding="utf-8") as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(json.dumps({"K4": report["K4"], "restorationProofs": len(results), "NativeExecuted": False}))


if __name__ == "__main__":
    main()
