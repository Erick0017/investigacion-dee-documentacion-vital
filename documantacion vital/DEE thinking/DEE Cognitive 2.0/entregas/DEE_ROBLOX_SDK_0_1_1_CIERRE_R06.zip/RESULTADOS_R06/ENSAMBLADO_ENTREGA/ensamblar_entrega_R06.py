"""Explicit, pinned, offline delivery assembly. Never imports DEE or opens a runtime.

Commands: dry-run --spec ... --report NEW.json
          build --spec ... --zip NEW.zip --extract NEW_DIRECTORY --report NEW.json
          verify --zip ... --extract NEW_DIRECTORY --report NEW.json
Only build requires a Root-reviewed, finalized spec with no pending results.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import zipfile

LIMIT = 15_000_000
MANIFEST = "MANIFIESTO_ENTREGA.json"
SCHEMA = "DEE.SDK.R06.DeliverySpec.v1"
FORBIDDEN_EXT = {".zip", ".7z", ".rar", ".sqlite", ".sqlite3", ".db", ".db3", ".raw", ".pyd", ".dll", ".exe", ".whl", ".pkl", ".pickle"}
FORBIDDEN_PARTS = {"runtime_privado_local", "estado_demo", "dependencias", "__pycache__", ".git", ".env", "id_rsa", "id_ed25519"}
REQUIRED_ROLES = {"final_report", "focal_final", "protection_final", "final_video"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_archive(value: str) -> str:
    if not isinstance(value, str) or not value or "\\" in value or ":" in value or "\x00" in value:
        raise ValueError("UNSAFE_ARCHIVE_PATH")
    p = PurePosixPath(value)
    if p.is_absolute() or any(x in {"", ".", ".."} for x in value.split("/")):
        raise ValueError("UNSAFE_ARCHIVE_PATH")
    if any(x.casefold() in FORBIDDEN_PARTS for x in p.parts) or p.suffix.casefold() in FORBIDDEN_EXT:
        raise ValueError("FORBIDDEN_ARCHIVE_CONTENT")
    return value


def no_reparse(path: Path) -> None:
    current = path.absolute()
    for item in (current, *current.parents):
        info = os.lstat(item)
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("SYMLINK_OR_REPARSE_REJECTED")


def read_regular(path: Path) -> bytes:
    no_reparse(path)
    a = path.stat()
    if not stat.S_ISREG(a.st_mode):
        raise ValueError("REGULAR_FILE_REQUIRED")
    data = path.read_bytes()
    b = path.stat()
    if (a.st_size, a.st_mtime_ns, a.st_ino) != (b.st_size, b.st_mtime_ns, b.st_ino):
        raise ValueError("SOURCE_CHANGED_DURING_READ")
    return data


def checked_pin(item: dict) -> tuple[str, int, str]:
    arc = safe_archive(item["archive"])
    size, sha = item["bytes"], item["sha256"]
    if not isinstance(size, int) or size < 0 or not isinstance(sha, str) or not re.fullmatch("[a-f0-9]{64}", sha):
        raise ValueError("EXACT_BYTES_SHA256_REQUIRED")
    return arc, size, sha


def check_secret_json(value, locator="") -> None:
    # Source code may discuss Token. Only actual JSON credential fields with values are rejected.
    if isinstance(value, dict):
        for key, child in value.items():
            if str(key).casefold() in {"token", "password", "access_token", "refresh_token", "api_key", "client_secret", "authorization"}:
                if child not in (None, "", False, "REDACTED", "OMITTED", "<TOKEN>"):
                    raise ValueError("NONEMPTY_CREDENTIAL_FIELD:" + locator + "/" + str(key))
            check_secret_json(child, locator + "/" + str(key))
    elif isinstance(value, list):
        for n, child in enumerate(value):
            check_secret_json(child, locator + "/" + str(n))


def check_readable(arc: str, data: bytes) -> None:
    ext = PurePosixPath(arc).suffix.casefold()
    if ext == ".json":
        check_secret_json(json.loads(data.decode("utf-8-sig")))
    elif ext == ".jsonl":
        for line in data.decode("utf-8-sig").splitlines():
            if line.strip():
                check_secret_json(json.loads(line))
    elif ext in {".md", ".txt", ".py", ".ps1", ".luau", ".lua", ".csv", ".rbxlx", ".rbxmx"}:
        data.decode("utf-8-sig")


def collect(spec: dict) -> list[tuple[dict, bytes]]:
    if spec.get("schema") != SCHEMA or spec.get("maximum_zip_bytes") != LIMIT:
        raise ValueError("SPEC_SCHEMA_OR_LIMIT")
    roots = [Path(p).absolute() for p in spec["allowed_source_roots"]]
    for root in roots:
        no_reparse(root)
    result, seen = [], set()
    for item in spec["files"]:
        arc, size, sha = checked_pin(item)
        if arc.casefold() in seen or arc.casefold() == MANIFEST.casefold():
            raise ValueError("DUPLICATE_OR_RESERVED_ARCHIVE_PATH")
        seen.add(arc.casefold())
        source = Path(item["source"]).absolute()
        if not any(source.is_relative_to(root) for root in roots):
            raise ValueError("SOURCE_OUTSIDE_ALLOWLIST_ROOTS")
        data = read_regular(source)
        if len(data) != size or digest(data) != sha:
            raise ValueError("SOURCE_BYTES_OR_HASH_CHANGED:" + arc)
        check_readable(arc, data)
        result.append((item, data))
    if not result:
        raise ValueError("EMPTY_DELIVERY")
    # Recheck every source only after the pinned set is fully read, preserving concurrent changes.
    for item, data in result:
        if digest(read_regular(Path(item["source"]))) != digest(data):
            raise ValueError("SOURCE_CHANGED_DURING_COLLECTION:" + item["archive"])
    return result


def public_manifest_check(files: list[tuple[dict, bytes]]) -> int:
    public = {x["archive"]: data for x, data in files if x.get("group") == "PUBLIC_SDK"}
    if not public:
        return 0
    candidates = [name for name in public if name == "MANIFIESTO.json" or name.endswith("/MANIFIESTO.json")]
    if len(candidates) != 1:
        raise ValueError("EXACT_ONE_PUBLIC_MANIFEST_REQUIRED")
    prefix = candidates[0][:-len("MANIFIESTO.json")]
    if not all(name.startswith(prefix) for name in public):
        raise ValueError("PUBLIC_ROOT_LAYOUT_MISMATCH")
    public = {name[len(prefix):]: data for name, data in public.items()}
    obj = json.loads(public["MANIFIESTO.json"].decode("utf-8-sig"))
    names = {m["path"] for m in obj["members"]} | {"MANIFIESTO.json"}
    if names != set(public):
        raise ValueError("PUBLIC_SDK_SET_NOT_EXACT")
    for row in obj["members"]:
        data = public[row["path"]]
        if len(data) != row["bytes"] or digest(data) != row["sha256"]:
            raise ValueError("PUBLIC_SDK_MANIFEST_MISMATCH")
    return len(names)


def new_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    no_reparse(path.parent)
    with path.open("x", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)
        f.write("\n")


def dry_run(spec: dict) -> dict:
    files = collect(spec)
    count = public_manifest_check(files)
    return {"schema": "DEE.SDK.R06.DeliveryDryRun.v1", "mode": "DRY_RUN_NO_FINAL_ZIP_CREATED", "spec_finalized": spec.get("finalized", False), "pending": spec.get("pending", []), "members_without_outer_manifest": len(files), "public_sdk_members": count, "uncompressed_bytes": sum(len(d) for _, d in files), "Native_calls": 0, "sources_preserved": True, "checked": [{"archive": x["archive"], "bytes": len(d), "sha256": digest(d)} for x, d in files]}


def verify(archive: Path, extraction: Path) -> dict:
    raw = read_regular(archive)
    if len(raw) > LIMIT:
        raise ValueError("ZIP_EXCEEDS_15000000_BYTES")
    if extraction.exists():
        raise ValueError("CLEAN_EXTRACTION_DESTINATION_MUST_NOT_EXIST")
    no_reparse(extraction.parent)
    with zipfile.ZipFile(archive) as z:
        infos = z.infolist()
        names = [safe_archive(i.filename) for i in infos]
        if len(names) != len({n.casefold() for n in names}):
            raise ValueError("DUPLICATE_ZIP_MEMBER")
        if any(i.compress_type != zipfile.ZIP_DEFLATED or i.flag_bits & 1 or stat.S_ISLNK(i.external_attr >> 16) for i in infos):
            raise ValueError("ZIP_FORMAT_NOT_STANDARD_UNENCRYPTED_DEFLATE")
        if z.testzip() is not None:
            raise ValueError("ZIP_CRC_FAILURE")
        m = json.loads(z.read(MANIFEST).decode("utf-8"))
        expected = {x["archive"]: x for x in m["members"]}
        if set(names) != set(expected) | {MANIFEST}:
            raise ValueError("OUTER_MANIFEST_NOT_EXACT")
        extraction.mkdir()
        for name in names:
            data = z.read(name)
            if name != MANIFEST:
                row = expected[name]
                if len(data) != row["bytes"] or digest(data) != row["sha256"]:
                    raise ValueError("EXTRACTION_HASH_FAILURE:" + name)
                check_readable(name, data)
            target = extraction.joinpath(*PurePosixPath(name).parts)
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as f:
                f.write(data)
            if digest(read_regular(target)) != digest(data):
                raise ValueError("EXTRACTED_BYTES_FAILURE")
    return {"schema": "DEE.SDK.R06.DeliveryVerification.v1", "zip": archive.name, "bytes": len(raw), "sha256": digest(raw), "members": len(names), "crc_all_members": True, "member_sha256_all": True, "fresh_extraction": True, "all_text_json_readable": True, "Native_calls": 0, "zip_is_operational_backup": False, "private_runtime_included": False}


def build(spec: dict, archive: Path, extraction: Path) -> dict:
    if spec.get("finalized") is not True or spec.get("reviewed_by_root") is not True or spec.get("pending"):
        raise ValueError("FINAL_SEAL_NOT_AUTHORIZED")
    files = collect(spec)
    roles = {x.get("role") for x, _ in files}
    if not REQUIRED_ROLES.issubset(roles):
        raise ValueError("FINAL_RESULTS_ROLES_MISSING")
    public_count = public_manifest_check(files)
    if public_count != spec.get("expected_public_members", public_count):
        raise ValueError("EXPECTED_PUBLIC_MEMBER_COUNT_MISMATCH")
    manifest = {"schema": "DEE.SDK.R06.DeliveryManifest.v1", "self_excluded": True, "Native_calls": 0, "private_runtime_included": False, "operational_backup": False, "public_sdk_members": public_count, "read_first": "LEER_PRIMERO.md", "public_sdk_root": "SDK_PUBLICO", "local_results_root": "RESULTADOS_R06", "members": [{"archive": x["archive"], "bytes": len(d), "sha256": digest(d), "role": x.get("role", "closed_evidence"), "source_reference": x.get("source_reference", x["archive"])} for x, d in files]}
    if archive.exists() or extraction.exists():
        raise ValueError("NEW_DESTINATIONS_REQUIRED")
    archive.parent.mkdir(parents=True, exist_ok=True)
    no_reparse(archive.parent)
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=False) as z:
        for item, data in files:
            z.writestr(item["archive"], data)
        z.writestr(MANIFEST, json.dumps(manifest, ensure_ascii=False, indent=2).encode("utf-8"))
    return verify(archive, extraction)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="mode", required=True)
    for mode in ("dry-run", "build"):
        p = sub.add_parser(mode)
        p.add_argument("--spec", required=True, type=Path)
        p.add_argument("--report", required=True, type=Path)
        if mode == "build":
            p.add_argument("--zip", required=True, type=Path)
            p.add_argument("--extract", required=True, type=Path)
    p = sub.add_parser("verify")
    p.add_argument("--zip", required=True, type=Path)
    p.add_argument("--extract", required=True, type=Path)
    p.add_argument("--report", required=True, type=Path)
    args = parser.parse_args()
    if args.mode == "verify":
        report = verify(args.zip, args.extract)
    else:
        spec = json.loads(read_regular(args.spec).decode("utf-8-sig"))
        report = dry_run(spec) if args.mode == "dry-run" else build(spec, args.zip, args.extract)
    new_json(args.report, report)
    print(json.dumps({k: v for k, v in report.items() if k != "checked"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
