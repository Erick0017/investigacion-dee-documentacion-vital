-- R06 public config; no credential.
return game:GetService("HttpService"):JSONDecode([=[
{
  "Schema": "DEE.SDK.Config.v0.1.1",
  "Version": "0.1.1",
  "Mode": "PREVIEW",
  "ExperienceId": "DEE_SDK_PILOTO",
  "SceneId": "MAPA_EJEMPLO_01",
  "AgentId": "DEMO",
  "ScenarioFingerprint": "87fd8e7a8a481563be518ee5362f09bc6b47b8ec96d36b898dea9cb1d821edc4",
  "MaxOpportunities": 3,
  "MaxActions": 6,
  "Map": {
    "RootName": "DEE_SDK_MAPA_EJEMPLO",
    "Start": [
      20,
      3,
      20
    ],
    "Port0": [
      -12,
      3,
      48
    ],
    "Port1": [
      55,
      3,
      -12
    ],
    "Device": [
      20,
      3,
      -28
    ],
    "FloorCenter": [
      20,
      -0.5,
      20
    ],
    "FloorSize": [
      130,
      1,
      130
    ],
    "Obstacles": [
      {
        "Position": [
          34,
          3,
          4
        ],
        "Size": [
          8,
          6,
          12
        ]
      },
      {
        "Position": [
          0,
          3,
          35
        ],
        "Size": [
          6,
          6,
          8
        ]
      }
    ],
    "Panel": {
      "Signal": 1,
      "Price0": 0,
      "Price1": 0
    },
    "Motor": {
      "WalkSpeed": 16,
      "AgentRadius": 2,
      "AgentHeight": 5,
      "AgentCanJump": false,
      "WaypointSpacing": 4,
      "ArrivalRadius": 2,
      "WaypointTimeout": 8,
      "MaxRecomputes": 2,
      "MaxWallSeconds": 45
    }
  },
  "PreviewPublicState": {
    "permissionStock": 0,
    "inventoryKey": false,
    "inventoryResource": false,
    "numberAPresent": false,
    "codeBPresent": false,
    "numberAVersion": 0,
    "codeBCurrent": false
  },
  "Scope": "Local Studio; PREVIEW construyeaparato,sin backend ni decisiones. Native requiere contrato privado e initialPublicState delservidor.",
  "RunCycles": 1,
  "PrivateConnectionFolder": "DEE_SDK_PrivateConnection_R06",
  "Transport": {
    "OperationPollSeconds": 1800,
    "PollIntervalSeconds": 2,
    "MaxOperationRecords": 128,
    "StartupWaitSeconds": 900
  },
  "MapModule": "MapaEjemplo",
  "AdapterModule": "LiveAdapters_R06",
  "AutoEndStudioTest": false,
  "PersistenceBinding": {
    "schema": "DEE.SDK.PersistenceBinding.R06",
    "release": "0.1.1",
    "wire": "DEE.RBX.Connector.R01",
    "mapModule": "MapaEjemplo",
    "adapterModule": "LiveAdapters_R06",
    "motorModule": "MotorPathfinding_R06",
    "poseTolerance": 0.00001,
    "maxOpportunities": 3,
    "maxActions": 6,
    "geometry": {
      "RootName": "DEE_SDK_MAPA_EJEMPLO",
      "Start": [
        20,
        3,
        20
      ],
      "Port0": [
        -12,
        3,
        48
      ],
      "Port1": [
        55,
        3,
        -12
      ],
      "Device": [
        20,
        3,
        -28
      ],
      "FloorCenter": [
        20,
        -0.5,
        20
      ],
      "FloorSize": [
        130,
        1,
        130
      ],
      "Obstacles": [
        {
          "Position": [
            34,
            3,
            4
          ],
          "Size": [
            8,
            6,
            12
          ]
        },
        {
          "Position": [
            0,
            3,
            35
          ],
          "Size": [
            6,
            6,
            8
          ]
        }
      ],
      "Panel": {
        "Signal": 1,
        "Price0": 0,
        "Price1": 0
      },
      "Motor": {
        "WalkSpeed": 16,
        "AgentRadius": 2,
        "AgentHeight": 5,
        "AgentCanJump": false,
        "WaypointSpacing": 4,
        "ArrivalRadius": 2,
        "WaypointTimeout": 8,
        "MaxRecomputes": 2,
        "MaxWallSeconds": 45
      }
    },
    "declaredScope": "All Agent/receipts + captured World/device/panels/motor + body parts/joints/pose; Native full state sealed privately by runtime"
  }
}
]=])
