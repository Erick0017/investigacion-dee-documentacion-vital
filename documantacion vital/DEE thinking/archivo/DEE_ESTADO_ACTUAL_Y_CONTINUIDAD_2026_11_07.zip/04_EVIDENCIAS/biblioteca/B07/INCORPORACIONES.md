# Incorporaciones ECI01

Se conservan como alternativa experimental ejecutable eci01-balance, eci01-entorno-iniciar/paso/estado y eci01-vigencia-vivir. Funcionan desde el mismo gestor de la copia con --eci01; no se creó otra plataforma. La vida ECI01_ACCESO_P0 termina en T713688 con su historia y par completo.

La integración es P0. El operador elige el modo, inicia oportunidades y aporta el aparato. DEE produce las emisiones. No se aprendió la selección del lector. R05 confirmó el uso léxico del circuito; RAW y clocks de los pares antiguo/temprano coinciden. Un cambio del contador preparado de utilidad no es una nueva política.

DEE20_DEMO_01 sigue protegido en T697764. No se copiaron extensiones ni recuerdos a su estado, ni se cambió su selección. C termina en T730639 con acceso fallido: no supera el panel esencial y no se promociona. La reapertura T714291 es una rama explícita de ALT; sus experiencias no se fusionan.

El atlas, los recálculos y el diagnóstico de deriva quedan como instrumentos del investigador. El Manual Maestro se actualiza a edición interna 1.24, con 1.23 preservada. El ZIP conserva el delta exacto y contratos; no es respaldo operativo completo.
