# Cambios del mismo Manual Maestro

Se publicó la edición documental1.25 en la misma ruta operativa:
DEE Cognitive2.0/DEE_Cognitive_2_0_Manual_Maestro_DCS11_MM_001_Edicion_1_21.docx.
El nombre histórico del archivo se conserva por compatibilidad con el lanzador; portada, control y encabezados identifican1.25.

SHA-256 actual: b0741ff0196f60b16c07e51345d6f66478c8399523e90f49caa5982636978f94.
La edición1.24 anterior se conserva exacta en archivo/analisis_transversal_cognitivo/edicion_anterior/Edicion_1_24.docx, SHA-25695f3291018e69212a9b16a983f3a37da86e2c36c6a25b17617bd98a78b2072ee.

Se actualizaron reanudación, control, cobertura, encabezados y enlace del índice, y se añadió el capítulo41. Se conservó el capítulo40 ECI01 como histórico, con una nota de alcance; no se reescribieron sus resultados. El capítulo41 distingue acceso P0, revisión adquirida P1 asistida, reserva fallida, aritmética directa preparada, diagnóstico C y límites de la lectura R04. Identifica las alternativas725840/720592 y el principal protegido697764.

Word16 actualizó campos, repaginó y exportó un PDF de106páginas. Se inspeccionaron individualmente todas las páginas de la primera versión. La revisión final corrigió dos frases de cobertura y simplificó el encabezado. La comparación de píxeles del cuerpo encontró cambios sólo en páginas3y4, que se inspeccionaron otra vez junto a portada, reanudación, capítulo41 y cierre; las otras104páginas mantuvieron el cuerpo de la versión inspeccionada. Se conservaron PDF yPNG localmente como comprobantes editoriales.

También se actualizó el mismo COMPENDIO_MAESTRO_DE_MECANISMOS_Y_RESULTADOS_DEE.docx, SHA-256f3d3489efab9219b48c43b2c4cffe5fcda887eff92945be9bc6276caac45173f. Se conservaron sus101fichas y los testigos históricos; se añadieron referencias acotadas a M220, M222 y M308 y un apartadoECI02 enlazado al índice. Sus53páginas se revisaron visualmente. El ZIP reproducible R01 anterior permanece idéntico y no contiene estos materiales nuevos.

PUBLICACION_DOCUMENTAL_ECI02.json conserva las rutas, hashes, respaldos y comparación fría del principal. Los estados físicos y las bases de la vida protegida siguieron idénticos. Estas ediciones y recálculos no añadieron ticks.

