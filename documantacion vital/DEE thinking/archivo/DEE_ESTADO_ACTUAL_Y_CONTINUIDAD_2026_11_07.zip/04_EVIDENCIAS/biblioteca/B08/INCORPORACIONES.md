# Incorporaciones y decisiones ECI02

Se mantienen el kernel v27 y el producto thinking 4.5.0. No se cambia el principal protegido DEE20_DEMO_01 T697764. Las alternativas son utilizables sin una promoción global.

## Capacidad del sistema

1. Acceso temprano P0 FI128, incorporado desde ECI01 al gestor y al parser existentes. Contrato: sistema/contratos/ACCESO_TEMPRANO_P0_ECI02.json. Código en sistema/capacidades/acceso_eci01.py, acceso_integrado_eci01.py y uso_acceso_eci01.py, con adaptaciones de cola, propietario y gestor. Uso explícito: acceso balance L R; acceso vivir N. N67, enteros0..20; lector físico temprano y lector posterior conservados. El cero real no es NULL. La iniciativa, el calendario y el codec son preparados. Evidencia: panel y PRUEBA_PUBLICACION_ECI02_R02.json.

2. Aritmética nativa directa por orden explícita. Contrato: sistema/contratos/ARITMETICA_DIRECTA_ECI02_P0.json. Código: sistema/capacidades/aritmetica_directa_eci02.py y enlaces en cola_local.py, mundo_genesis_apd05.py y aplicacion/GENESIS/genesis.py. Uso: acceso numero suma 8 3; acceso numero diferencia RESULTADO 4. Entradas enteras0..32, frontend nativo heredado; ninguna elección R04, calidad o proveedor externos en ese modo. Evidencia: PRUEBA_ARITMETICA_DIRECTA_ECI02_R01.json. El primer resultado11 realmente leído alimentó la siguiente operación, que produjo7. Es función preparada, no aritmética aprendida ni selección autónoma de proveedor.

3. Dos vidas completas seleccionables en el gestor ya existente. ECI02_CONSOLIDADA_OPERATIVA T725840 es una publicación bifurcada desde el final real ALT T724813. ECI02_ACCESO_REVISADO_MINUS T720592 deriva de la revisión negativa T720324. Se conservaron snapshots, SQLite, interfaces, agendas y artefactos; las dos se usaron y continuaron entre procesos. CONTINUIDAD_ECI02.json identifica rutas, hashes y padres.

## Capacidad de una vida y asistencia

La alternativa consolidada conserva los usos fechados de luma+, nara−, clasifica−, suma+, MA alfa− y comparación. El último bloque utilizó cálculo directo, MA, luma y cero. La otra alternativa conserva luma−; su signo adquirido cambia un acceso asistido a MA. No se transfirió esa revisión al cuerpo positivo.

El anfitrión sigue escogiendo el modo explícito o ejecutando una correspondencia preparada de signo a protocolo. No se incorporan como habilidades aprendidas P2/R2, recuperación iniciada por la organización, aritmética general o nuevos significados NSM.

## Decisión sobre promoción

No promover. La reserva esencial original de proveedor falló con19/19 entradas aplicadas, cero proveedores y ningún número. La interfaz directa posterior tiene otro contrato de asistencia y no sustituye ese criterio. El futuro adverso se conserva; no se devuelve a MAIN un futuro favorable de un diagnóstico.

El portador temprano candidato de R04 apareció también en el brazo sin consulta. Se incorpora el contraste como límite del instrumento, no como respuesta de E1. Las ediciones B/sham de C pertenecen a copias diagnósticas y no son reparaciones ni conocimientos de las alternativas.

## Uso local

Desde la raíz DEE Cognitive2.0:
```
ABRIR_DEE_COGNITIVE.bat --sistema --vida ECI02_CONSOLIDADA_OPERATIVA --diagnostico --puerto 8885
ABRIR_DEE_COGNITIVE.bat --sistema --vida ECI02_ACCESO_REVISADO_MINUS --diagnostico --puerto 8886
```
Iniciar, presentar petición, guardar y detener antes de abrir otro propietario. No usar --nueva para esos estados. No abrir ambos comandos sobre una misma vida. Los números35/36 en la consulta de MINUS no implican generalización cuantitativa: MA los ignora.

Los archivos previos se conservaron en respaldo_codigo_principal_antes_P0, respaldo_antes_aritmetica_directa y respaldo_metadatos_incorporacion. El catálogo distingue los dos contratos P0 y la alternativa P1 en la ficha existente APD03. PROYECTO y su selección personal mantienen el principal; el inventario histórico de vidas conserva sus28filas y añade una capa de autoridad actual.

La actualización documental es la edición1.25 del mismo Manual Maestro y referencias limitadas del mismo compendio. El ZIP reproducible R01 del compendio no se modificó y no contiene automáticamente ECI02.

