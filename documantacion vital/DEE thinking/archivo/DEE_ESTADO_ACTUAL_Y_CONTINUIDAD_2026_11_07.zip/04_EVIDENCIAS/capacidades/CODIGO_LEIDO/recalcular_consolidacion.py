"""Pure offline validation of the twelve frozen closure requests. Stdlib only."""
from pathlib import Path
from collections import Counter
import argparse, hashlib, importlib.util, json

HERE = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def parse(value):
    return json.loads(value) if isinstance(value, str) else value


def physical(record):
    return {key: record['physical'][key] for key in ('N', 'tick', 'RAW_sha256', 'clocks_sha256')}


def run(report_path, protocol_path):
    report_path, protocol_path = Path(report_path), Path(protocol_path)
    d, p = read(report_path), read(protocol_path)
    recovered = d['schema'] == 'DEE.ECI02.operational_closure.recovered_proof.R02'
    require(recovered or d['schema'] == 'DEE.ECI02.operational_closure.proof.R02', 'Unexpected proof revision')
    require((d.get('recovery_complete') if recovered else d.get('complete')) is True and not d.get('error'), 'Proof is not complete; preserve its negative/partial result')
    requests = d['recovered_requests'] if recovered else d['requests']
    owners = d['owner_witnesses'] if recovered else d['owners']
    require(d['protocol_sha256'] == sha(protocol_path) and d['controller_sha256'] == p['controller_sha256'], 'Frozen protocol/source mismatch')
    require(d['life'] == p['life'] == 'ECI02_CIERRE_CANDIDATA_01', 'Different child life')
    initial, final = d['initial_record'], d['final_record']
    saved = d['saved_before_reopen_checkpoint_descriptor'] if recovered else d['last_saved_before_reopen']
    require(physical(initial) == {key: p['source_physical'][key] for key in physical(initial)}, 'Initial physical state differs')
    require(initial['parent']['encoded_sha256'] == p['source_snapshot_sha256'], 'Complete source identity differs')
    require(len(requests) == len(p['ordered_requests']) == 12, 'Expected exactly twelve consecutive requests')
    require(len(owners) == 2, 'Expected two real owners')
    helper = HERE / 'codigo/recalculo_base_eci02_R09.py'
    require(sha(helper) == p['recount_base_sha256'], 'R09 fixed reader/receipt code differs')
    spec = importlib.util.spec_from_file_location('_closure_pure_R09', helper)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    rows, all_events, previous, actual_first = [], {}, physical(initial), None
    for index, (item, plan) in enumerate(zip(requests, p['ordered_requests'])):
        require(item['id'] == plan['id'], 'Request order changed')
        terminal = item['terminal']
        require(terminal and terminal['status'] == 'completed' and not terminal.get('error'), 'Non-completed request')
        payload, native = parse(terminal['payload']), parse(terminal['result'])
        literal = item['literal']
        expected_literal = plan.get('row')
        if expected_literal is None:
            expected_literal = {'modo': 'eci01-aritmetica-directa', 'operacion': 'diferencia',
                                'izquierda': actual_first, 'derecha': 2}
        require(literal == expected_literal, 'Payload/binding changed')
        require(payload['situaciones'] == [literal] and payload['retorno'] == 'omit' and payload['actuador'] == 'closed', 'Actor envelope changed')
        require(native['id'] == terminal['id'] == item['transport_id'], 'Transport/result IDs differ')
        require(native['before_tick'] == previous['tick'] == item['before']['tick'], 'Sequential physical chronology differs')
        unit = native['result']['rows'][0]
        admission = base.receipts(unit)
        for event in admission['_events']:
            identifier = event['id']
            if identifier in all_events:
                require(all_events[identifier] == event['status'], 'Conflicting receipt for a reused ID')
            all_events[identifier] = event['status']
        mode = literal['modo']
        if mode == 'eci01-aritmetica-directa':
            number = unit['numeric_reader']
            observation = number['observation']
            fields = base.obs(observation)
            operation = literal['operacion']
            trial = unit['native_operation']['native_trial']
            bias = 0 if operation == 'suma' else 32
            valid = fields['state'] > 0 and fields['semantic'] == 1 and fields['direction'] == [1, -1, -1]
            valid = valid and observation['site'] == [12, 17, 18] and observation['tick'] == trial['datum_tick'] - 2
            observed = fields['s_reg'] - bias if valid else None
            require(number['representation_bias'] == bias and observed == number['numeric_result'] == unit['numeric_result'], 'Fixed numeric RAW decoder mismatch')
            require(unit['native_operation']['operands'] == [literal['izquierda'], literal['derecha']] and unit['native_operation']['operation'] == operation, 'Actual Native operands differ')
            require(unit['native_operation']['numeric_reader'] == number, 'Native numeric observations differ')
            require(unit['literal_operator_request'] == literal and unit['operator_selected_operation'] is True and unit['same_lived_adapter'] is True, 'Operator/adapter attribution differs')
            require(all(unit[k] is False for k in ('R04_route_consulted', 'provider_called', 'quality_evaluation_or_return', 'teacher_delivered', 'fallback_to_failed_request')), 'Unexpected provider/R04/teacher/fallback')
            if item['id'] == 'SUM':
                actual_first = observed
            summary = {'kind': 'explicit_operator_native_arithmetic', 'RAW_numeric': observed,
                       'representation_bias': bias, 'observation': observation,
                       'new_arithmetic_learning_claim': False, 'R04_or_provider_or_teacher': False}
        else:
            summary = base.summarize(unit, literal, None, None)
            observed = summary['P0_q4'] if mode == 'eci01-balance' else summary['choice']
        expected = p['auditor_only'][item['id']]
        correct = observed is not None and observed == expected and admission['complete_admission']
        committed = native['committed_snapshot']
        current = physical(committed)
        require(current['tick'] == native['after_tick'] == item['after']['tick'], 'Committed request end differs')
        for key in ('external_pending_present', 'cascade_pending_present', 'external_uncertain_present'):
            require(committed['operational_dependencies'].get(key) is False, 'Unresolved operational dependency')
        require(native['owner_idle_ticks_after'] == owners[0]['ready']['idle_ticks'], 'Unexpected Native idle')
        rows.append({'index': index + 1, 'id': item['id'], 'literal': literal, 'before': previous, 'after': current,
                     'native_inputs': base.counts(admission), 'summary': summary, 'response': observed,
                     'expected_auditor_only': expected, 'correct_with_full_admission': correct,
                     'nonapplied_events': [event for event in admission['_events'] if event['status'] != 'applied']})
        previous = current
    require(physical(saved) == physical(final) == previous, 'Save/reopen physical state differs')
    require(initial['life_id'] == final['life_id'] == initial['world_id'] == final['world_id'] == d['life'], 'Life/world identity differs')
    require(initial['parent'] == final['parent'], 'Parent changed')
    require(final['operations'][:len(initial['operations'])] == initial['operations'], 'Historical prefix was rewritten')
    if recovered:
        witness = d['reopen_passive_comparison']
        require(witness['physical_equal'] is True and all(witness['full_operational_protocol_fields_equal'].values()), 'Passive full checkpoint comparison differs')
        require(witness['second_owner_ready_physical_matches_saved'] is True, 'Second real owner started from a different physical state')
        require(owners[0]['pid'] != owners[1]['pid'], 'Two distinct real owner PIDs required')
        require(owners[0]['exit_code_from_original_prefix'] == 0, 'Available original first owner exit differs')
        require(d['final_stopped_owner_cache']['running'] is False and d['final_stopped_owner_cache']['uncertain_external_result'] is False, 'Actual final owner is not closed/certain')
        last_stop = parse(d['final_second_stop_exact_row']['result'])
        require(d['final_second_stop_exact_row']['status'] == 'completed' and last_stop['before_tick'] == last_stop['after_tick'] == final['physical']['tick'], 'Actual second STOP is not completed and zero-tick')
        require(last_stop['owner_idle_ticks_after'] == owners[1]['ready']['idle_ticks'] == owners[0]['ready']['idle_ticks'], 'Real owner idle counters changed')
        missing_owner_output = d['missing_original_fields']
    else:
        require(all(d[k] is True for k in ('reopened_exact_checkpoint', 'reopen_zero_ticks', 'same_life_and_world', 'reopen_native_protocol_equal')), 'Reopen witness differs')
        for owner in owners:
            require(owner['exit_code'] == 0 and not owner['stderr'], 'Owner did not close normally')
            status = parse(owner['stdout'])
            require(status['life_id'] == d['life'] and status['running'] is False and status.get('uncertain_external_result') is False, 'Owner status/uncertainty differs')
            require(status['idle_ticks'] == owner['ready']['idle_ticks'], 'Owner introduced idle ticks')
            require(owner['resources']['job_memory_limit'] == 536870912, 'Resource bound differs')
        require(owners[1]['before']['snapshot_sha256'] == saved['snapshot_sha256'], 'Second owner did not restore the exact saved checkpoint')
        require(physical(owners[1]['before']) == physical(owners[1]['after']), 'Second owner advanced Native ticks')
        missing_owner_output = []
    imports = [event for event in d['events'] if event['arguments'][0] == 'mente-unificada-importar']
    require(len(imports) == 1 and imports[0]['exit_code'] == 0, 'Exactly one complete-pair import required')
    require(all(event['exit_code'] == 0 for event in d['events']), 'Manager error occurred')
    require(d['native_ticks_total'] == final['physical']['tick'] - initial['physical']['tick'] <= 3000, 'Panel tick budget/total differs')
    require(actual_first == d['actual_first_result_forwarded'] == requests[9]['literal']['izquierda'], 'Actual first result was not forwarded exactly')
    statuses = Counter(all_events.values())
    return {'schema': 'DEE.ECI02.operational_closure.offline_recount.R02',
            'source': str(report_path), 'source_sha256': sha(report_path),
            'protocol_sha256': sha(protocol_path), 'recounter_sha256': sha(__file__),
            'fixed_R09_reader_sha256': sha(helper), 'new_native_or_SQLite_calls': 0,
            'life': d['life'], 'source_life': d['source_life'], 'before': physical(initial), 'after': physical(final),
            'requests': rows, 'requested': len(rows), 'correct_with_full_admission': sum(r['correct_with_full_admission'] for r in rows),
            'all_twelve_contractual_results_verified': all(r['correct_with_full_admission'] for r in rows),
            'total_native_inputs': {'requested': len(all_events), 'applied': statuses.get('applied', 0), 'statuses': dict(statuses)},
            'actual_first_output_used_as_next_left_operand': True, 'actual_arithmetic_values': [rows[8]['response'], rows[9]['response']],
            'recorded_native_ticks': d['native_ticks_total'], 'owner_PIDs': [o['pid'] for o in owners],
            'same_life_parent_history_and_zero_tick_reopen_verified': True,
            'native_pending_protocol_equality_scope': 'Recorded exact comparison of full local saved snapshots by the controller; compact recount checks this witness and raw/clock identities, not omitted snapshots.',
            'final_snapshot_sha256': final['snapshot_sha256'], 'final_export': d['final_export'] if recovered else d['final_export_manager_response'],
            'recovered_original_serialization': recovered, 'unavailable_original_fields_not_invented': missing_owner_output,
            'original_truncated_sha256': d.get('original_truncated_sha256'),
            'no_promotion_performed': d['no_promotion_performed'],
            'scope': 'Operational bounded inherited/assisted functions, not new learning, autonomous recovery, P2/R2 or repair of the prior failed R04/provider reserve.'}


def main():
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument('--report', type=Path, default=HERE / 'datos/PRUEBA_CONSOLIDACION_RECUPERADA_R02.json')
    parser.add_argument('--protocol', type=Path, default=HERE / 'datos/PROTOCOLO_CONSOLIDACION_R02.json')
    parser.add_argument('--out', type=Path, default=HERE / 'datos/RECALCULO_CONSOLIDACION_R01.json')
    args = parser.parse_args()
    if args.out.exists():
        raise FileExistsError('Preserve existing offline recount')
    result = run(args.report, args.protocol)
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('x', encoding='utf8') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'output': str(args.out), 'sha256': sha(args.out),
                      'correct': result['correct_with_full_admission'], 'requested': result['requested'],
                      'admissions': result['total_native_inputs'], 'after': result['after'], 'new_native_ticks': 0}))


if __name__ == '__main__':
    main()
