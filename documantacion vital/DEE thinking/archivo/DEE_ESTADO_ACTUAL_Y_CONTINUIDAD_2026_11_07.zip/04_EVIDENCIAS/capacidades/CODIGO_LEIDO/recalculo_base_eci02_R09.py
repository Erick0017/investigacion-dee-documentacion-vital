"""ECI02 offline recount. Stdlib only, no Native/DEE imports, SQLite or ticks.
Fixed RAW/readout and receipt logic adapted from ECI01's pure recounters.
Only a closed current request envelope is counted; saved historical metadata is excluded.
"""
from pathlib import Path, PurePosixPath
from collections import Counter
from datetime import datetime, timezone
import argparse,csv,gzip,hashlib,json,os,re
HERE=Path(__file__).resolve().parents[1]
SKIP={"state","final","metadata","buffers","operational","operational_environment_state","committed_snapshot","saved","final_service_status"}
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(",",":"),allow_nan=False)
def read(p):
 b=Path(p).read_bytes();return json.loads(gzip.decompress(b)if b[:2]==b"\x1f\x8b"else b)
def walk(v,ptr=""):
 if isinstance(v,dict):
  yield ptr,v
  for k,x in v.items():
   if k not in SKIP:yield from walk(x,ptr+"/"+str(k).replace("~","~0").replace("/","~1"))
 elif isinstance(v,list):
  for i,x in enumerate(v):yield from walk(x,ptr+"/"+str(i))
def obs(o):
 n=int(o["raw"])
 if not 0<=n<2**64:raise ValueError("Non-uint64 RAW")
 def signed(k):
  x=(n>>k)&15;return x-16 if x&8 else x
 f={"state":n&0xffffffff,"s_reg":(n>>32)&65535,"direction":[signed(k)for k in(48,52,56)],"semantic":(n>>60)&15}
 if any(k in o and o[k]!=x for k,x in f.items()):raise ValueError("RAW/decoded observation mismatch")
 return f
def early(o):
 f=obs(o);x,y,z=f["direction"]
 return x if f["state"]>0 and f["semantic"]==1 and x in(-1,0,1)and y==1 and z in(0,-1)else None
def six(r):
 cs=[]
 for o in r["observations"]:
  f=obs(o);x,y,z=f["direction"]
  if f["state"]>0 and f["semantic"]==1 and x in(-1,0,1)and y==1 and z in(0,-1)and o["site"]==[(15+2*x)%67,17,(15+2*z)%67]:cs.append(x)
 value=cs[0]if len(cs)==1 else None
 if value!=r.get("choice"):raise ValueError("Six-site RAW choice mismatch")
 return value
def pure_z(r):
 cs=[]
 for o in r["panel"]:
  f=obs(o)
  if f["state"]>0 and f["semantic"]==1 and f["direction"]in([0,0,-1],[0,0,1]):cs.append(f["direction"][2])
 value=cs[0]if len(cs)==1 else None
 if value!=r.get("formed_native_command"):raise ValueError("Signed RAW choice mismatch")
 return value
def receipts(v):
 variants={}
 for ptr,x in walk(v):
  r=x.get("receipt")
  if not isinstance(r,dict)or"status"not in r or"id"not in r:continue
  submitted_id=x.get("id",x.get("qid"))
  if submitted_id is not None and str(submitted_id)!=str(r["id"]):raise ValueError("Submission/receipt ID mismatch")
  item={k:r.get(k)for k in("id","kind","requested_tick","effective_tick","channels","status","reason")}
  item.update(id=str(r["id"]),port=x.get("port",x.get("channel")),pointer=ptr)
  own=variants.setdefault(item["id"],[])
  if canon({k:z for k,z in item.items()if k!="pointer"})not in[canon({k:z for k,z in old.items()if k!="pointer"})for old in own]:own.append(item)
 unique=[]
 for rows in variants.values():
  if len({canon({k:r[k]for k in("id","kind","requested_tick","channels")})for r in rows})!=1:raise ValueError("Native ID aliases different inputs")
  terminal=[r for r in rows if r["status"]!="scheduled"]
  if len({canon({k:z for k,z in r.items()if k not in("pointer","port")})for r in terminal})>1:raise ValueError("Incompatible terminal receipts")
  unique.append((terminal or rows)[-1])
 statuses=Counter(r["status"]for r in unique)
 query=[r for r in unique if any(s in (str(r.get("port")or"")+" "+" ".join(r.get("channels")or[])).lower()for s in("query","cue","consulta","token"))]
 return {"requested":len(unique),"admitted":statuses.get("applied",0),"not_applied":len(unique)-statuses.get("applied",0),
         "status_counts":dict(statuses),"complete_admission":bool(unique)and statuses.get("applied",0)==len(unique),
         "query_or_cue_requested":len(query),"query_or_cue_admitted":sum(r["status"]=="applied"for r in query),"_events":unique}
def counts(r):return{k:v for k,v in r.items()if k!="_events"}
def artifact(system,row,artifact_root):
 effect=row.get("committed_effect")or{};a=effect.get("artifact")
 if not isinstance(a,dict):return{"bytes_checked":False,"reason":"No artifact in committed effect"}
 directory=str(row.get("effect_directory","")).replace("\\","/");marker="/estado/servicios_locales/"
 if marker not in directory:return{"bytes_checked":False,"reason":"No declared worker-root locator"}
 rel=directory.split(marker,1)[1].rstrip("/")+"/"+a["relative_path"]
 parts=PurePosixPath(rel).parts
 if PurePosixPath(rel).is_absolute()or".."in parts:raise ValueError("Unsafe artifact locator")
 root=Path(artifact_root)if artifact_root else Path(system)/"estado/servicios_locales";p=root.joinpath(*parts)
 result={"relative_to_worker_root":rel,"expected_sha256":a["sha256"],"expected_bytes":a["bytes"],"bytes_checked":False}
 if not p.is_file():return{**result,"reason":"Actual artifact bytes unavailable at declared root"}
 b=p.read_bytes()
 if sha(b)!=a["sha256"]or len(b)!=a["bytes"]:raise ValueError("Artifact bytes/hash mismatch")
 actual=json.loads(b)
 if actual.get("value")!=effect.get("used_value")or actual.get("operands")!=row.get("raw_operands")or actual.get("operation")!=row.get("selected_operation")or actual.get("procedure")!="native":raise ValueError("Actual artifact does not match native effect")
 return{**result,"bytes_checked":True,"actual_content":actual,"actual_sha256":sha(b)}
def balance(r):
 t=r.get("trial",r);n=t["original_result"]["native_trial"];e=early(t["early_observation"]);old=six(n["reader"])
 if e!=t["early_physical_choice"]or old!=t["old_q6_choice"]or t["early_tick"]!=n["query_tick"]+4:raise ValueError("P0 decoder/horizon mismatch")
 loads=t["original_result"]["public_independent_loads"];expected=(loads[0]>loads[1])-(loads[0]<loads[1]);ad=receipts(n)
 return{"P0_q4":e,"old_q6":old,"loads":loads,"expected_auditor_only":expected,"formed_material_zero":e==0,"NULL_no_answer":e is None,
        "correct_observed":e is not None and e==expected,"correct_with_full_admission":e is not None and e==expected and ad["complete_admission"],"native_inputs":counts(ad)}
def route_r04(reader):
 candidates=[]
 for o in reader["observations"]:
  f=obs(o)
  for sign in(-1,0,1):
   if o["site"]==[25+2*sign,15,53]and f["state"]>0 and f["semantic"]==1 and f["direction"]==[sign,1,0]:candidates.append(sign)
 value=candidates[0]if len(candidates)==1 else None
 if value!=reader.get("choice"):raise ValueError("R04 provider-route RAW decoder mismatch")
 return value
def arithmetic(r,system,artifact_root):
 word_command=pure_z(r["word"]["reader"])
 route=r.get("route");route_choice=route_r04(route["reader"])if route else None
 if word_command!=r.get("native_operator_command")or route_choice!=r.get("native_route_command"):raise ValueError("Archived arithmetic commands differ from physical readouts")
 expected_operation="add"if word_command==1 else"sub"if word_command==-1 else None
 expected_procedure="native"if route_choice==-1 else"external"if route_choice in(0,1)else None
 if r.get("selected_operation")!=expected_operation or r.get("selected_procedure")!=expected_procedure:raise ValueError("Prepared operation/provider transduction differs")
 route_diagnostic={"lexical_command_from_RAW":word_command,"provider_route_from_RAW":route_choice,
   "query_tick":None if route is None else route.get("query_tick"),"read_tick":None if route is None else route["reader"].get("tick"),
   "actuator_observations":[]if route is None else route["reader"]["observations"],"references":[]if route is None else route.get("references",[]),
   "route_inputs":counts(receipts(route))if route else None,
   "failure_stage_observed":"lexical_no_command"if word_command is None else"provider_route_no_emission"if route_choice is None else"external_provider_instead_of_native"if expected_procedure!="native"else None,
   "scope":"Location of observed processing stop, not an attribution of its unobserved physical cause. NULL with applied inputs is not erasure proof."}
 nr=(r.get("native_numeric")or{}).get("numeric_reader");effect=r.get("committed_effect")or{};operation=r.get("selected_operation");value=None
 if nr:
  o=nr["observation"];f=obs(o);trial=r["native_numeric"]["native_trial"];bias=0 if operation=="add"else 32
  valid=f["state"]>0 and f["semantic"]==1 and f["direction"]==[1,-1,-1]and o["site"]==[12,17,18]and int(o["tick"])==int(trial["datum_tick"])-2
  value=f["s_reg"]-bias if valid else None
  if nr.get("representation_bias")!=bias or nr.get("numeric_result")!=value:raise ValueError("Numeric RAW/bias decoder mismatch")
 operands=r.get("raw_operands");expected=None
 if isinstance(operands,list)and len(operands)==2:
  expected=operands[0]+operands[1]if operation=="add"else operands[0]-operands[1]if operation in("sub","subtract")else None
 ad=receipts(r);a=artifact(system,r,artifact_root)
 correct=value is not None and value==expected==effect.get("used_value")==effect.get("reported_value")
 provider=r.get("selected_procedure")=="native"and effect.get("provider_calls")=={"native":1,"external":0}
 return{"selection_diagnostic":route_diagnostic,"selected_operation":operation,"selected_procedure":r.get("selected_procedure"),"raw_operands":operands,"numeric_from_RAW":value,
        "used_value":effect.get("used_value"),"reported_value":effect.get("reported_value"),"expected_auditor_only":expected,
        "provider_calls":effect.get("provider_calls"),"native_only":provider,"correct_observed":correct,"native_inputs":counts(ad),"artifact":a,
        "correct_and_usable_verified":correct and provider and ad["complete_admission"]and a["bytes_checked"]}
def workshop(proc,mode):
 episodes=[]
 for row in proc["rows"]:
  selected=six(row["selection_native_trial"]["reader"]);action={-1:"USE",0:"WAIT",1:"INSPECT"}.get(selected)
  if selected!=row["physical_choice"]or(selected is not None)!=row["formed_unique"]or action!=row["physical_action"]:raise ValueError("APD05 native selection/action mismatch")
  public=row["public_environment_before"];audit=row["auditor_only_after_effect"];effect=row["committed_effect"];op=row.get("native_operation");useful=None
  entry={"episode":row["episode"],"source_id":public["source_id"],"cursor_before":row["cursor_before"],"cursor_after":row["cursor_after"],"public_before":public,
         "auditor_after":audit,"version_choice":selected,"physical_action":action,"lexical_choice":None if row["word"]is None else pure_z(row["word"]["reader"]),
         "effect_archived":effect,"version_inputs":counts(receipts(row["selection_native_trial"]))}
  if row["feedback"].get("native_consequence_delivered")is not False:raise ValueError("APD05 unexpected new consequence")
  if op and op.get("kind")=="APD04_candidate_native_balance":
   t=op["native_trial"];old=six(t["reader"]);eo=op.get("early_E_q4_observation")
   if eo is None:
    frames=[f["fields"]["E"]for f in t.get("frames",[])if f["tick"]==t["query_tick"]+4]
    if len(frames)==1:eo=frames[0]
   e=early(eo)if eo else None;choice=op["physical_choice"]
   if choice!=(e if mode=="eci01-vigencia-vivir"else old):raise ValueError("APD05 did not use frozen specified balance reader")
   before=public["loads"];after=list(before)
   if choice==1 and before[0]>0 and before[1]<20:after=[before[0]-1,before[1]+1]
   elif choice==-1 and before[1]>0 and before[0]<20:after=[before[0]+1,before[1]-1]
   if effect.get("loads_after")is not None and effect["loads_after"]!=after:raise ValueError("APD05 environmental effect mismatch")
   gap=abs(before[0]-before[1]);newgap=abs(after[0]-after[1]);useful=bool(choice is not None and(newgap<gap or(choice==0 and gap==0))and audit["tag"]==audit["goal"])
   entry["balance"]={"old_q6":old,"early_q4":e,"selected":choice,"loads_before":before,"loads_after_recomputed":after,
                     "formed_zero_hold":choice==0,"NULL_no_action":choice is None,"inputs":counts(receipts(op))}
  elif action=="INSPECT":
   newfact=public.get("cached_version")!=public["current_version"]or public.get("cached_value")!=audit["actual_value"]
   useful=bool(newfact and audit["tag"]==audit["goal"])
  elif action in(None,"WAIT"):useful=False
  elif op and effect.get("actual_bin")is not None:
   target=(audit["actual_value"]>audit["criterion"])-(audit["actual_value"]<audit["criterion"])
   correct=effect["actual_bin"]==target and public.get("cached_version")==public["current_version"]
   useful=bool(correct and audit["tag"]==audit["goal"]and effect.get("previous_bin")!=effect["actual_bin"])
  if useful is not None and useful!=bool(effect.get("useful")):raise ValueError("APD05 utility differs from fixed actual-effect recount")
  ad=receipts(row);entry.update(usefulness_recomputed=useful,all_inputs=counts(ad),useful_fully_admitted=useful is True and ad["complete_admission"]);episodes.append(entry)
 return{"episodes":episodes,"requested_opportunities":len(episodes),"formed_version_responses":sum(x["version_choice"]is not None for x in episodes),
        "useful_recomputed":sum(x["usefulness_recomputed"]is True for x in episodes),"useful_fully_admitted":sum(x["useful_fully_admitted"]for x in episodes),
        "formed_zero_holds":sum(x.get("balance",{}).get("formed_zero_hold",False)for x in episodes),
        "NULL_balances":sum(x.get("balance",{}).get("NULL_no_action",False)for x in episodes),
        "scope":"Recompute each actual effect/tag/goal; do not impose either4/4 or2/4 blindly. Material0, silence and usefulness are separate."}
def factorial_unit_summary(unit):
 t=unit.get("native_factorial",unit)
 a=receipts(t)
 if a["requested"]!=t["requested_unique_ids"]:raise ValueError("Factorial unique native-ID count mismatch")
 if a["status_counts"]!=t["request_statuses"]:raise ValueError("Factorial Native status recount mismatch")
 ma=pure_z(t["MA02_common_reader_at_q4"]);fi=six(t["original_FI_MU_reader_at_q6"])
 frame=next(f for f in t["frames"]if f["offset"]==4)
 e=early(frame["capture"]["points"]["E"])
 if e!=t["early_E_q4_reader_auditor_only"]["choice"]:raise ValueError("Factorial early fixed RAW decoder mismatch")
 activities={}
 for name,activity in t["activities"].items():
  activities[name]={"kind":activity["kind"],"material_interval":activity.get("material_interval"),"native_inputs":counts(receipts(activity))}
 ma_armed=any(x["kind"]=="MA02_alfa"for x in activities.values())
 # Preserve actual activity kind spelling without treating an unarmed residual as an answer.
 if not ma_armed:ma_armed=any("MA02"in str(x["kind"])for x in activities.values())
 fi_armed=any(x["kind"]=="FI128_balance"for x in activities.values())
 overlap=t.get("physical_interval_overlap")
 return{"kind":"prepared_material_factorial","condition":t["condition"],"pair":t["pair"],"query_tick":t["query_tick"],"end_tick":t["end_tick"],
  "activities":activities,"native_inputs":counts(a),"MA_q4":ma,"FI_MU_q6":fi,"early_E_q4_auditor_only":e,
  "MA_activity_requested":ma_armed,"FI_activity_requested":fi_armed,
  "MA_response_credit":ma_armed and ma is not None and a["complete_admission"],
  "FI_q6_response_credit":fi_armed and fi is not None and a["complete_admission"],
  "baseline_readings_without_activity_are_not_task_responses":True,
  "physical_interval_overlap":overlap,"has_material_overlap":overlap is not None and overlap[0]<=overlap[1],
  "captures":[{"offset":f["offset"],"tick":f["capture"]["tick"],"N":f["capture"]["N"],
      "RAW_sha256":f["capture"]["RAW_sha256"],"clocks_sha256":f["capture"]["clocks_sha256"],"counts":f["capture"]["counts"]}for f in t["frames"]],
  "scope":"Operator schedules existing MA/FI opportunities in one Runtime. Material overlap and contextual effects do not demonstrate acquired scheduling, independent faculties or general integration."}
def joint_recalculation(campaign,closed):
 import importlib.util
 module_path=Path(campaign)/"instrumento/concurrencia_eci02.py"
 rows=[r for r in closed if r.get("label")in("J_00_FACTORIAL","J_10_FACTORIAL","J_01_FACTORIAL","J_11_FACTORIAL")and r.get("transport_status")=="completed"]
 result={"four_arm_closed_count":len(rows),"factorial_complete":len(rows)==4,"new_Native_calls":0,"no_learning_claim_from_XOR":True}
 if rows:
  if not module_path.is_file():raise ValueError("Exact archived passive factorial module is missing")
  spec=importlib.util.spec_from_file_location("_eci02_passive_factorial",module_path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
  cases={};buffer_checks=[]
  for r in rows:
   wrapper=read(Path(campaign)/r["source"]);native=wrapper["request"]["result"]["result"];t=native.get("native_factorial")
   if t is None:
    units=native.get("rows",[]);t=units[0].get("native_factorial")if len(units)==1 else None
   if t is None:raise ValueError("Closed factorial wrapper lacks exact native factorial")
   for f in t["frames"]:
    capture=f["capture"]
    for key,hashkey in(("raw","RAW_sha256"),("clock","clocks_sha256")):
     payload=capture["buffers"][key];values=m._unpack(payload)
     if len(values)!=capture["N"]**3 or payload["sha256"]!=capture[hashkey]:raise ValueError("Full factorial buffer size/identity mismatch")
    buffer_checks.append({"life":r["life"],"offset":f["offset"],"RAW_and_clocks_verified":True})
   cases[t["condition"]]=t
  result["full_capture_checks"]=buffer_checks;result["passive_module_sha256"]=sha(module_path.read_bytes())
  if len(cases)==4:
   result["conditional_XOR"]=m.recalculate_factorial(cases)
   result["all_requested_inputs_admitted"]=all(receipts(t)["complete_admission"]or not t["activities"]for t in cases.values())
   result["pending_before_equal"]=len({canon(read(Path(campaign)/r["source"]).get("pending_before"))for r in rows})==1
   result["scope"]="Exact matched physical prefixes/calendar and recorded Native admission are required. XOR/set contrasts report context dependence only, never linear superposition, autonomous learning or independence by geometry."
 main=[r for r in closed if r.get("life")=="ECI02_ALT_CONSOLIDADA"and str(r.get("label","")).startswith("J_MAIN_")and r.get("action")=="request"]
 result["MAIN_chronology"]=[{"label":r["label"],"before_tick":r["before"]["tick"],"after_tick":r["after"]["tick"],"native_inputs":r.get("native_inputs"),"procedures":r.get("procedures")}for r in sorted(main,key=lambda r:r["before"]["tick"])]
 result["MAIN_not_reconstructed_from_factorial_branches"]=True
 return result
def r04_diagnostic_summary(unit,literal,protocol):
 from array import array
 import base64,struct
 d=unit["diagnostic"];frozen=protocol["r04_diagnostic"];frames=d["frames"]
 if d["arm_query_present"]is not literal["consulta"]:raise ValueError("R04 diagnostic query ON/OFF differs")
 if d["before"]!=frozen["prefix"]or d["after_word_gate"]!=frozen["after_same_word_query"]:raise ValueError("R04 prefix or lexical gate differs")
 if d["query_tick"]!=frozen["query_tick"]or[f["offset"]for f in frames]!=list(range(-1,13)):raise ValueError("R04 fixed observation calendar differs")
 decoded=[];previous=None;checks=[]
 for frame in frames:
  c=frame["capture"];buffers={}
  for key,hkey in(("raw","RAW_sha256"),("clock","clocks_sha256")):
   payload=c["buffers"][key];b=gzip.decompress(base64.b64decode(payload["data"],validate=True))
   if sha(b)!=payload["sha256"]or sha(b)!=c[hkey]or len(b)!=67**3*8:raise ValueError("R04 complete buffer hash/size differs")
   a=array("Q");a.frombytes(b)
   import sys
   if sys.byteorder!="little":a.byteswap()
   buffers[key]=a
  raw,clocks=buffers["raw"],buffers["clock"]
  for name,delta in(("E",(0,0,0)),("minus",(-2,2,0)),("neutral",(0,2,0)),("plus",(2,2,0))):
   pos=[(x+y)%67 for x,y in zip((25,13,53),delta)];o=frame["explicit_points_including_RAW0"][name];ix=(pos[0]*67+pos[1])*67+pos[2]
   if o["site"]!=pos or int(o["raw"])!=raw[ix]or int(o["clock"])!=clocks[ix]:raise ValueError("R04 fixed points differ from global buffers")
   obs(o)
  expected_roi=[]
  for x in range(-4,5):
   for y in range(-3,8):
    for z in range(-5,4):
     pos=[(25+x)%67,(13+y)%67,(53+z)%67];ix=(pos[0]*67+pos[1])*67+pos[2]
     if raw[ix]:expected_roi.append((pos,int(raw[ix]),int(clocks[ix])))
  actual_roi=[(r["site"],int(r["raw"]),int(r["clock"]))for r in frame["ROI_nonzero_RAW"]]
  if actual_roi!=expected_roi:raise ValueError("R04 fixed ROI omitted or altered nonzero RAW, including inactive records")
  if previous:
   oldraw,oldclock=previous;diff=[[i,str(a),str(b)]for i,(a,b)in enumerate(zip(oldraw,raw))if a!=b]
   ch=hashlib.sha256();count=0
   for i,(a,b)in enumerate(zip(oldclock,clocks)):
    if a!=b:count+=1;ch.update(struct.pack("<QQQ",i,a,b))
   delta=frame["global_difference"]
   if delta["RAW_changed_rows"]!=diff or delta["clock_changed_count"]!=count or delta["clock_change_triples_sha256"]!=ch.hexdigest():raise ValueError("R04 global difference does not match exact consecutive buffers")
  previous=(raw,clocks);decoded.append((frame,raw))
  checks.append({"offset":frame["offset"],"tick":c["tick"],"RAW_sha256":c["RAW_sha256"],"clocks_sha256":c["clocks_sha256"],"global_and_ROI_verified":True,
   "fixed_R04_points":frame["explicit_points_including_RAW0"],"global_RAW_changed_count":None if frame["global_difference"]is None else len(frame["global_difference"]["RAW_changed_rows"])})
 f4=next(f for f in frames if f["offset"]==4);f6=next(f for f in frames if f["offset"]==6)
 broad=early(f4["explicit_points_including_RAW0"]["E"]);old=route_r04(d["route_original_q6"]["reader"])
 if broad!=d["q4_E_direction_class_auditor_only"]:raise ValueError("R04 frozen broad q4 class mismatch")
 q6physical={k:f6["capture"][k]for k in("N","tick","RAW_sha256","clocks_sha256")}
 gate=(q6physical==frozen["original_q6_physical"])
 if literal["consulta"]and not gate:raise ValueError("R04 ON does not reproduce failed-reserve q6 physical state")
 if pure_z(d["same_word_query"]["reader"])!=1:raise ValueError("Common lexical suma command differs")
 if d["provider_calls"]!={"native":0,"external":0}or d["quality_or_return_executed"]or d["teacher_delivered"]or not d["diagnostic_only_not_operational"]:raise ValueError("Diagnostic scope changed")
 adm=receipts(d);end=d["after"]["tick"]
 due=[r for r in adm["_events"]if r.get("requested_tick")is not None and r["requested_tick"]<=end]
 future=[r for r in adm["_events"]if r.get("requested_tick")is not None and r["requested_tick"]>end]
 return{"kind":"R04_prepared_query_observation_diagnostic","query_ON":literal["consulta"],"prefix_gate":True,"lexical_end_gate":True,"original_q6_physical_gate":gate,
  "q4_E_broad_class":broad,"old_fixed_q6":old,"actual_provider_calls":d["provider_calls"],"new_legacy_window_pending":d["pending_window_preserved"],
  "all_inputs":counts(adm),"due_inputs_at_stop":{"requested":len(due),"applied":sum(r["status"]=="applied"for r in due),"statuses":dict(Counter(r["status"]for r in due))},
  "future_inputs_preserved":future,"captures_verified":checks,
  "scope":"Fixed broader observation only. A direction class is not executed, remapped to Native or counted as repair; query dependence is not unique lineage or toroidal origin."}
def r04_diagnostic_contrast(closed):
 rows=[r for r in closed if r.get("label")in("RD_ON_TRAZA","RD_OFF_TRAZA")and r.get("transport_status")=="completed"]
 result={"closed_arms":len(rows),"new_ticks_in_this_recount":0,"not_operational_repair":True}
 for row in rows:
  s=(row.get("procedures")or[{}])[0];result["ON"if row["label"]=="RD_ON_TRAZA"else"OFF"]={"life":row["life"],"source":row["source"],"before":row["before"],"after":row["after"],"summary":s}
 if len(rows)==2:
  on=result["ON"];off=result["OFF"]
  result["initial_RAW_clocks_N_tick_equal"]=on["before"]==off["before"]
  result["broader_q4_classes"]={"ON":on["summary"]["q4_E_broad_class"],"OFF":off["summary"]["q4_E_broad_class"]}
  result["historical_q6_classes"]={"ON":on["summary"]["old_fixed_q6"],"OFF":off["summary"]["old_fixed_q6"]}
  result["scope"]="ON must reproduce original failed reading. OFF removes specific query inputs while preserving generic resources; unequal dose is intentional. Any preserved emission is external observability, not a newly utilized provider or restored MAIN."
 return result
def summarize(unit,literal,system,artifact_root,protocol=None):
 mode=literal.get("modo")
 if mode=="eci02-diagnostico-r04":return r04_diagnostic_summary(unit,literal,protocol)
 if mode=="eci02-factorial-ma-fi":return factorial_unit_summary(unit)
 if mode=="apd04-palabra":return{"kind":"literal_association","choice":pure_z(unit["reader"]),"token":literal["texto"]}
 if mode=="memoria":
  memory=unit
  if unit.get("kind")=="explicit_operator_memory_access":
   rows=(unit.get("result")or{}).get("rows",[])
   if len(rows)!=1 or rows[0].get("kind")!="query":raise ValueError("Expected one exact nested contextual query")
   memory=rows[0]
  return{"kind":"explicit_context_memory","choice":pure_z(memory["reader"]),"context":literal.get("contexto"),"query_pointer":"/result/rows/0"if memory is not unit else"","query_read_tick":memory.get("read_tick")}
 if mode=="eci01-balance":return{"kind":"P0_balance",**balance(unit)}
 if mode in("apd05-vigencia-vivir","eci01-vigencia-vivir"):return{"kind":"APD05_workshop",**workshop(unit,mode)}
 if mode=="apd02-componer":
  stages=[arithmetic(r,system,artifact_root)for r in unit["rows"]];links=[stages[i]["raw_operands"][0]==stages[i-1]["used_value"]for i in range(1,len(stages))]
  return{"kind":"operator_planned_native_composition","stages":stages,"result_archived":unit.get("result"),"actual_previous_output_links":links,
         "all_links_preserved":len(stages)==len(literal["formas"])and all(links),"all_stages_verified":bool(stages)and all(r["correct_and_usable_verified"]for r in stages),
         "final_value":stages[-1]["used_value"]if stages else None}
 if mode=="apd03-lenguaje":
  sign=pure_z(unit["word"]["reader"]);interaction=unit.get("interaction");kind=None if interaction is None else interaction.get("kind");response=None
  if interaction:
   if kind!=("native_current_selection"if sign==1 else"query"if sign==-1 else None):raise ValueError("Learned sign/actual prepared branch mismatch")
   response=six(interaction["reader"])if sign==1 else pure_z(interaction["reader"])
  return{"kind":"P1_acquired_cue_selects_prepared_access","lexical_choice":sign,"interaction_kind":kind,"interaction_choice":response,"no_P2_or_initiative":True}
 if mode=="apd03-docencia":return{"kind":"explicit_external_teaching","teacher_sign":literal["senal"],"revision":literal.get("revision",False),"not_learning_from_counter":True}
 return{"kind":unit.get("kind"),"unimplemented_summary_for_mode":mode}
def expected_for(label,protocol):
 if label.startswith("L_")and"_RET_"in label:
  targets=protocol.get("retention_addendum",{}).get("audit_targets_only",{})
  if label.endswith("_RET_NARA")and"nara"in targets:return{"formed_native_command":targets["nara"],"source":"retention_addendum.audit_targets_only"}
  if label.endswith("_RET_MA")and"alfa"in targets:return{"choice":targets["alfa"],"source":"retention_addendum.audit_targets_only"}
 if label.startswith("ALT_RETENCION_FINAL_"):
  token=label.removeprefix("ALT_RETENCION_FINAL_").lower()
  targets=protocol.get("revision_final_panel",{}).get("expected_auditor_only",{})
  if token in targets:return{"formed_native_command":targets[token],"source":"revision_final_panel.expected_auditor_only"}
 if label.startswith("J_"):
  auditor=protocol.get("auditor_only",{})
  if label.endswith("_MA")and"expected_main_MA"in auditor:return{"choice":auditor["expected_main_MA"]}
  if label.endswith("_FI")and"expected_main_FI"in auditor:return{"P0_q_plus_4_choice":auditor["expected_main_FI"]}
 if label.startswith("L_")and any(label.endswith(x)for x in("USO_COMUN","RESERVA")):
  arm=next((x for x in("PLUS","MINUS","EDAD")if label.startswith("L_"+x+"_")),None)
  prediction=protocol.get("auditor_only",{}).get("predictions",{}).get(arm)
  if prediction is not None:return{"P1_prediction":prediction,"arm":arm,"no_P2_R2":True}
 match=re.match(r"(E02_P\d+)(?:_|$)",label)
 if not match:return None
 p=protocol.get("auditor_only",{});rows=list(p.get("ordered_panel",[]))+[p.get("reserved_new_interaction",{})]+p.get("additional_retention_window",{}).get("rows",[])
 return next((r.get("auditor_only_expected")for r in rows if r.get("id")==match.group(1)),None)
def check_expected(s,e,full):
 if e is None:return None
 kind=s.get("kind")
 if kind in("literal_association","explicit_context_memory"):return s["choice"]is not None and s["choice"]==e.get("formed_native_command",e.get("choice"))and full
 if kind=="P1_acquired_cue_selects_prepared_access":
  pred=e.get("P1_prediction",{});target=pred.get("native_function_choice")
  sign_ok=s.get("lexical_choice")is not None and s["lexical_choice"]==target
  response_ok=("expected_sign"not in pred or(s.get("interaction_choice")is not None and s["interaction_choice"]==pred["expected_sign"]))
  return sign_ok and response_ok and full
 if kind=="P0_balance":return s["P0_q4"]is not None and s["P0_q4"]==e.get("P0_q_plus_4_choice")and full
 if kind=="operator_planned_native_composition":return [r["used_value"]for r in s["stages"]]==e["native_values_in_order"]and s["all_links_preserved"]and s["all_stages_verified"]and full
 return None
def analyze(path,campaign,protocol,artifact_root):
 raw=path.read_bytes();d=json.loads(gzip.decompress(raw))
 if d.get("schema")!="DEE.ECI02.execution.v1"or not d.get("finished_utc"):raise ValueError("Unknown or not closed wrapper")
 row={k:d.get(k)for k in("life","label","action","p0","before","after","native_ticks_advanced","host_seconds","finished_utc","runner_sha256","protocol_sha256","guard_denied")}
 row.update(source=str(path.relative_to(campaign)),source_sha256=sha(raw),pending_after_count=len(d.get("pending_after")or[]))
 request=d.get("request")
 if not isinstance(request,dict):return row
 row.update(transport_id=request.get("id"),transport_status=request.get("status"),transport_error=request.get("error"),payload=request.get("payload"))
 jobs=[j for j in protocol.get("jobs",[])if j.get("label")==d["label"]and j.get("life")==d["life"]]
 row["frozen_job_match"]=len(jobs)==1 and jobs[0].get("payload")==request.get("payload")
 native=(request.get("result")or{}).get("result")or{};ad=receipts(native)
 row.update(native_inputs=counts(ad),_events=ad["_events"],procedures=[])
 if request.get("status")!="completed":return row
 literals=(request.get("payload")or{}).get("situaciones",[]);units=native.get("rows",[])
 if native.get("kind")in("ECI02_independent_material_factorial","ECI02_R04_query_diagnostic"):units=[native]
 if literals and len(literals)!=len(units):raise ValueError("Literal/result count mismatch")
 for literal,unit in zip(literals,units):
  s=summarize(unit,literal,d["system"],artifact_root,protocol);ua=receipts(unit);expected=expected_for(d["label"],protocol)
  s.update(all_inputs=counts(ua),expected_auditor_only=expected,matches_expected_under_full_admission=check_expected(s,expected,ua["complete_admission"]))
  row["procedures"].append(s)
 row["residual_response_not_credited_after_any_rejection"]=not ad["complete_admission"]
 return row
def protocol_catalogue(campaign,main_path):
 found={};candidates={Path(main_path)}
 for root in(Path(campaign)/"datos",Path(campaign)/"codigo",Path(campaign)/"instrumento"):
  if root.exists():candidates.update(p for p in root.rglob("*.json")if"PROTOCOLO"in p.name.upper())
 for p in sorted(candidates):
  d=read(p)
  if isinstance(d,dict)and isinstance(d.get("jobs"),list):found[sha(p.read_bytes())]={"path":str(p.relative_to(campaign)),"document":d}
 return found
def learned_access_contrasts(closed):
 result={}
 for stage in("USO_COMUN","RESERVA"):
  arms={}
  for arm in("PLUS","MINUS","EDAD"):
   rows=[r for r in closed if r.get("label")=="L_"+arm+"_"+stage and r.get("transport_status")=="completed"]
   if rows:
    r=rows[-1];s=(r.get("procedures")or[{}])[0]
    arms[arm]={"life":r["life"],"before":r.get("before"),"after":r.get("after"),"native_inputs":r.get("native_inputs"),
     "lexical_choice":s.get("lexical_choice"),"interaction_kind":s.get("interaction_kind"),"interaction_choice":s.get("interaction_choice"),
     "matches_predeclared":s.get("matches_expected_under_full_admission"),"source":r["source"]}
  result[stage]={"arms_closed":arms,"all_three_arms_closed":len(arms)==3,"P2_R2_demonstrated":False,
   "scope":"Explicit teaching or age control changes inherited cue content. Native cue emission is transduced by a prepared host branch into current comparison or explicit MA access; initiative/context/cadence remain assisted. No fully internal routing or consequence-learned policy is inferred."}
 retention={}
 for arm in("PLUS","MINUS","EDAD"):
  tested=[]
  for suffix,family in(("NARA","lex.nara"),("MA","MA.alfa")):
   rows=[r for r in closed if r.get("label")=="L_"+arm+"_RET_"+suffix and r.get("transport_status")=="completed"]
   if rows:
    r=rows[-1];sm=(r.get("procedures")or[{}])[0]
    tested.append({"family":family,"life":r["life"],"label":r["label"],"after_tick":r["after"]["tick"],
     "response":sm.get("choice"),"native_inputs":r.get("native_inputs"),
     "matches_predeclared_under_full_admission":sm.get("matches_expected_under_full_admission"),"source":r["source"]})
  retention[arm]={"actually_tested":tested,"both_retention_probes_closed":len(tested)==2,
    "scope":"Only actual nara/alfa post-history-and-reserve accesses establish retention at these moments. Other inherited words or capabilities are not credited from the parent."}
 result["post_revision_and_reserve_retention"]=retention
 histories=[r for r in closed if r.get("label")in("L_PLUS_HISTORIA","L_MINUS_HISTORIA","L_EDAD_HISTORIA")]
 if len(histories)==3:
  result["histories"]={"same_before_physical":len({canon({k:r["before"].get(k)for k in("RAW_sha256","clocks_sha256","tick","N")})for r in histories})==1,
   "history_end_ticks":{r["life"]:r["after"]["tick"]for r in histories},"histories_independent_learners":False,
   "teacher_admissions":{r["life"]:r.get("native_inputs")for r in histories}}
 return result
def observation_moment(row):
 label=row.get("label","")
 if label.startswith("ALT_RETENCION_FINAL_")or re.match(r"E02_P1[234](?:_|$)",label):return"RETENCION_FINAL_POST_1341"
 if label.startswith("E02_P11_"):return"RESERVA_NUEVA_POST_CONJUNTO"
 if re.match(r"E02_P(?:0[1-9]|10)(?:_|$)",label):return"PANEL_INICIAL_DESCENDIENTE_ALT"
 if label.startswith(("J_MAIN_01_","J_MAIN_02_")):return"MAIN_SERIAL"
 if label.startswith(("J_MAIN_03_","J_MAIN_04_","J_MAIN_05_","J_MAIN_06_")):return"MAIN_INTERCALADO"
 if label.startswith("J_MAIN_07_"):return"MAIN_SOLAPAMIENTO"
 if label.startswith(("J_MAIN_08_","J_MAIN_09_")):return"MAIN_POST_SOLAPAMIENTO"
 if label.startswith("L_"):
  if"_RET_"in label:return"P1_RETENCION_POST_REVISION_Y_RESERVA"
  if label.endswith("_USO_COMUN"):return"P1_PRIMER_USO_COMUN"
  if label.endswith("_RESERVA"):return"P1_RESERVA_POST_67"
  if label.endswith("_HISTORIA"):return"P1_DOCENCIA_O_EDAD"
  if label.endswith("_DEMORA"):return"P1_DEMORA"
  return"P1_OPERACION_TECNICA"
 if label.startswith("J_"):return"CONTROL_FACTORIAL_Y_POSTLECTURAS"
 if label.startswith("COMPAT_"):return"CONTROL_COMPATIBILIDAD"
 return"OPERACION_TECNICA_O_NO_CLASIFICADA"
def capabilities_by_moment(closed):
 out=[]
 for row in closed:
  if row.get("action")!="request":continue
  for sm in row.get("procedures",[]):
   kind=sm.get("kind");family=kind;response=None;extra={}
   if kind=="literal_association":family="lex."+sm["token"];response=sm.get("choice")
   elif kind=="explicit_context_memory":family="MA."+str(sm.get("context"));response=sm.get("choice")
   elif kind=="P0_balance":
    left,right=sm["loads"];expected=(left>right)-(left<right)
    family="P0."+{1:"positive",-1:"negative",0:"neutral"}[expected];response=sm.get("P0_q4");extra={"old_q6":sm.get("old_q6")}
   elif kind=="operator_planned_native_composition":
    family="aritmetica_nativa_encadenada";response=[x.get("numeric_from_RAW")for x in sm["stages"]]
    extra={"actual_previous_output_links":sm["actual_previous_output_links"],"all_stages_verified":sm["all_stages_verified"]}
   elif kind=="APD05_workshop":
    family="APD05.uso_ambiental_preparado";response={"formed":sm["formed_version_responses"],"opportunities":sm["requested_opportunities"],"useful":sm["useful_recomputed"],"HOLD":sm["formed_zero_holds"]}
   elif kind=="P1_acquired_cue_selects_prepared_access":
    family="P1.senal_a_acceso_preparado";response={"lexical":sm["lexical_choice"],"interaction":sm["interaction_kind"],"response":sm["interaction_choice"]}
   elif kind=="prepared_material_factorial":
    family="MA_FI.solapamiento_preparado";response={"MA_q4":sm["MA_q4"],"FI_q6":sm["FI_MU_q6"],"E_q4":sm["early_E_q4_auditor_only"]}
   out.append({"life":row["life"],"moment":observation_moment(row),"label":row["label"],"before_tick":row["before"]["tick"],"after_tick":row["after"]["tick"],
    "family":family,"observed_response":response,"native_inputs":sm.get("all_inputs",row.get("native_inputs")),
    "matches_predeclared_under_full_admission":sm.get("matches_expected_under_full_admission"),"source":row["source"],"source_sha256":row["source_sha256"],**extra})
 main=[r for r in out if r["life"]=="ECI02_ALT_CONSOLIDADA"]
 moments={}
 for r in main:moments.setdefault(r["moment"],[]).append(r)
 essential={"lex.luma","lex.nara","lex.clasifica","lex.suma","MA.alfa"}
 final={r["family"]:r for r in main if r["moment"]=="RETENCION_FINAL_POST_1341"}
 return{"observations":out,"MAIN_same_continuous_life":"ECI02_ALT_CONSOLIDADA",
  "essential_previous_group":{"families":sorted(essential),"final_tested":sorted(essential&set(final)),
    "final_missing":sorted(essential-set(final)),"final_observed":{f:{"response":final[f]["observed_response"],"matches_under_full_admission":final[f]["matches_predeclared_under_full_admission"],"tick":final[f]["after_tick"]}for f in essential&set(final)}},
  "MAIN_families_by_moment":{m:sorted({r["family"]for r in rows})for m,rows in moments.items()},
  "scope":"Before/after access evidence only at actual sampled moments. A previous success is not filled into an unprobed later moment. Branch controls are never counted as MAIN experiences. No automated promotion."}
def run(campaign,protocol_path,artifact_root=None):
 campaign=Path(campaign).resolve();protocol=read(protocol_path);catalogue=protocol_catalogue(campaign,protocol_path);paths=[]
 planned={}
 for item in catalogue.values():
  for job in item["document"].get("jobs",[]):planned[(job["life"],job["label"])]=job
 for branch in("CONTROL_ANTERIOR","LAB_P0"):
  root=campaign/"estados"/branch/"sistema/estado/eci02_resultados"
  if root.exists():paths.extend(root.rglob("*.json.gz"))
 closed=[];invalid=[];seen=set();events={}
 for p in sorted(paths):
  try:
   header=read(p);chosen=catalogue.get(header.get("protocol_sha256"))
   active_protocol=chosen["document"]if chosen else protocol
   r=analyze(p,campaign,active_protocol,artifact_root)
   r["exact_frozen_protocol_found"]=chosen is not None
   r["frozen_protocol_member"]=None if chosen is None else chosen["path"]
   if r["action"]=="request":
    key=(r["life"],r.get("transport_id"))
    if key in seen:raise ValueError("Duplicate physical request wrapper")
    seen.add(key)
   for ev in r.pop("_events",[]):
    key=(r["life"],ev["id"]);old=events.get(key)
    if old and canon({k:v for k,v in old.items()if k not in("pointer","port")})!=canon({k:v for k,v in ev.items()if k not in("pointer","port")}):raise ValueError("Life/event differs between requests")
    events[key]=ev
   closed.append(r)
  except Exception as exc:invalid.append({"source":str(p.relative_to(campaign)),"error":type(exc).__name__+": "+str(exc)})
 stats=Counter(x["status"]for x in events.values());compat={r["label"]:r for r in closed if r["label"]in("COMPAT_ANTERIOR_USO","COMPAT_OFF_USO","COMPAT_P0_USO")};comparison={}
 if all(k in compat for k in("COMPAT_ANTERIOR_USO","COMPAT_OFF_USO")):
  old,new=compat["COMPAT_ANTERIOR_USO"],compat["COMPAT_OFF_USO"]
  comparison["old_vs_new_off"]={"same_initial_RAW_clocks_tick_N":all(old["before"].get(k)==new["before"].get(k)for k in("RAW_sha256","clocks_sha256","tick","N")),
    "same_final_RAW_clocks_tick_N":all(old["after"].get(k)==new["after"].get(k)for k in("RAW_sha256","clocks_sha256","tick","N")),
    "same_admission":old.get("native_inputs")==new.get("native_inputs"),"same_procedure_summary":old.get("procedures")==new.get("procedures")}
 return{"schema":"DEE.ECI02.offline_panel_recount.R09","computed_utc":datetime.now(timezone.utc).isoformat(),"native_or_sqlite_calls":0,
  "status":"INCREMENTAL_CLOSED_WRAPPERS_ONLY","recounter_source_sha256":sha(Path(__file__).read_bytes()),"revision_note":"R02 unwraps explicit_operator_memory_access/result/rows/0. R03 recognizes the actual frozen operation code sub and counts common.token as a cue. R04 resolves exact frozen protocol by wrapper SHA and supports the predeclared PLUS/MINUS/EDAD P1 contrasts. R05 adds exact four-arm full-buffer/clock verification and reuses the archived passive conditional-XOR module, with MAIN chronology separate from sister controls. R06 reads the prospectively frozen final nara/clasifica/suma targets and reports actual coverage by life/moment without filling unprobed later states. R07 reads the prospective P1 R03 retention addendum and reports only actually tested nara/alfa retention in each branch. R08 decodes lexical/provider commands from their recorded RAW and identifies where a no-provider arithmetic attempt stopped. R09 verifies the frozen R04 ON/OFF global fields, clocks, ROI, successive differences and fixed readers; pending future generic inputs are not mislabeled as rejection. These are offline additions, not new Native results or modified targets.","protocol":{"path":str(protocol_path),"sha256":sha(Path(protocol_path).read_bytes()),"frozen":protocol.get("frozen")},
  "source_count":len(closed),"skipped_or_invalid":invalid,"closed":closed,"compatibility":comparison,"learned_access_contrasts":learned_access_contrasts(closed),"joint_use":joint_recalculation(campaign,closed),"capabilities_by_moment":capabilities_by_moment(closed),"R04_diagnostic":r04_diagnostic_contrast(closed),"protocol_catalogue":[{"sha256":k,"path":v["path"],"schema":v["document"].get("schema")}for k,v in catalogue.items()],
  "counts":{"closed_wrappers":len(closed),"request_wrappers":sum(r["action"]=="request"for r in closed),"completed_requests":sum(r.get("transport_status")=="completed"for r in closed),
    "native_ticks_across_wrappers":sum(r.get("native_ticks_advanced")or 0 for r in closed),"unique_native_events":len(events),"native_status_counts":dict(stats),
    "applied":stats.get("applied",0),"not_applied":len(events)-stats.get("applied",0)},
  "coverage":{"planned_jobs":len(planned),"closed_planned_labels":[r["label"]for r in closed if(r["life"],r["label"])in planned],
    "pending_planned_labels":[j["label"]for j in planned.values()if not any(r["label"]==j["label"]and r["life"]==j["life"]for r in closed)]},
  "limitations":["Only fully closed current wrappers under declared two systems; zero Native,SQLite,queries or history reconstruction.",
    "Fixed RAW decoders are external instruments, not acquired observer selection.",
    "Complete admission required for response credit; residual outputs after rejection remain visible without credit.",
    "Actual artifact bytes/hash/content required for verified file use; missing bytes remain unverified.",
    "No automated promotion or P2/R2/general-autonomy conclusion."]}
def save(v,path):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_name(p.name+".tmp");tmp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf8");os.replace(tmp,p)
def write_csv(result,path):
 rows=[]
 for r in result["closed"]:
  if r["action"]!="request":continue
  ad=r.get("native_inputs",{})
  for s in r.get("procedures",[]):
   rows.append({"life":r["life"],"label":r["label"],"before_tick":(r.get("before")or{}).get("tick"),"after_tick":(r.get("after")or{}).get("tick"),"transport_status":r.get("transport_status"),
    "moment":observation_moment(r),"kind":s.get("kind"),"requested":ad.get("requested"),"admitted":ad.get("admitted"),"not_applied":ad.get("not_applied"),"choice":s.get("choice",s.get("P0_q4")),
    "matches_expected_under_full_admission":s.get("matches_expected_under_full_admission"),"response_detail":canon({k:v for k,v in s.items()if k not in("expected_auditor_only","all_inputs")}),
    "source":r["source"],"source_sha256":r["source_sha256"]})
 if rows:
  with Path(path).open("w",encoding="utf-8-sig",newline="")as f:
   writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
def main():
 ap=argparse.ArgumentParser(__doc__);ap.add_argument("--campaign-root",type=Path,default=HERE);ap.add_argument("--protocol",type=Path);ap.add_argument("--artifact-root",type=Path);ap.add_argument("--output",type=Path);ap.add_argument("--csv",type=Path);a=ap.parse_args()
 protocol=a.protocol or a.campaign_root/"datos/PROTOCOLO_PANEL_ECI02_R01.json";result=run(a.campaign_root,protocol,a.artifact_root)
 output=a.output or a.campaign_root/"datos/RECALCULO_PANEL_ECI02.json";save(result,output)
 write_csv(result,a.csv or a.campaign_root/"datos/CAPACIDADES_POR_VIDA_Y_MOMENTO_ECI02.csv")
 print(json.dumps({"output":str(output),"sha256":sha(output.read_bytes()),"bytes":output.stat().st_size,"counts":result["counts"],"invalid":result["skipped_or_invalid"],"coverage":result["coverage"]},ensure_ascii=False))
if __name__=="__main__":main()
