"""Auditoría documental independiente. Python stdlib; no importa DEE ni abre SQLite.
Ejecutar con python -B -X utf8 RECALCULAR_EVIDENCIA.py [--out resultado.json].
Lee sólo los bytes exportados junto al script. No reproduce la física del motor.
"""
import argparse,collections,hashlib,json,pathlib,gzip
HERE=pathlib.Path(__file__).resolve().parent
SKIP={'state','final','metadata','buffers','operational','operational_environment_state','committed_snapshot','saved','final_service_status'}
def load(rel):
 b=(HERE/rel).read_bytes();return json.loads(gzip.decompress(b) if b[:2]==b'\x1f\x8b' else b)
def sha(b):return hashlib.sha256(b).hexdigest()
def walk(o):
 if isinstance(o,dict):
  yield o
  for k,v in o.items():
   if k not in SKIP:yield from walk(v)
 elif isinstance(o,list):
  for v in o:yield from walk(v)
def fields(o):
 n=int(o['raw']);assert 0<=n<2**64
 d=[(n>>s)&15 for s in (48,52,56)];d=[x-16 if x>=8 else x for x in d]
 r={'state':n&0xffffffff,'s_reg':(n>>32)&65535,'direction':d,'semantic':(n>>60)&15}
 for k,v in r.items():assert k not in o or o[k]==v,(k,o[k],v)
 return r
def purez(reader):
 values=[]
 for o in reader['panel']:
  f=fields(o)
  if f['state']>0 and f['semantic']==1 and f['direction'] in [[0,0,-1],[0,0,1]]:values.append(f['direction'][2])
 v=values[0] if len(values)==1 else None
 assert v==reader['formed_native_command'];return v
def count_receipts(unit):
 groups=collections.defaultdict(list)
 for x in walk(unit):
  r=x.get('receipt')
  if not isinstance(r,dict) or 'id' not in r or 'status' not in r:continue
  ident=str(r['id']);assert str(x.get('id',x.get('qid',r['id'])))==ident
  record={k:r.get(k) for k in ['id','kind','requested_tick','effective_tick','channels','status','reason']}
  if record not in groups[ident]:groups[ident].append(record)
 final={}
 for ident,variants in groups.items():
  assert len({json.dumps({k:r[k] for k in ['id','kind','requested_tick','channels']},sort_keys=True) for r in variants})==1
  terminals=[r for r in variants if r['status']!='scheduled']
  assert len({json.dumps(r,sort_keys=True) for r in terminals})<=1
  final[ident]=(terminals or variants)[-1]
 return final
def decode(unit,literal):
 mode=literal['modo']; detail={}
 if mode=='apd04-palabra':return purez(unit['reader']),{'kind':'association','token':literal['texto']}
 if mode=='memoria':
  u=unit['result']['rows'][0] if unit.get('kind')=='explicit_operator_memory_access' else unit
  return purez(u['reader']),{'kind':'memory','context':literal['contexto']}
 if mode=='eci01-balance':
  t=unit.get('trial',unit);o=t['early_observation'];f=fields(o);x,y,z=f['direction']
  val=x if f['state']>0 and f['semantic']==1 and x in [-1,0,1] and y==1 and z in [0,-1] else None
  assert t['early_tick']==t['original_result']['native_trial']['query_tick']+4
  assert val==t['early_physical_choice']
  return val,{'kind':'P0_balance','old_q6':t['old_q6_choice'],'raw_early':o,'NULL_not_zero':val is None}
 if mode=='eci01-aritmetica-directa':
  n=unit['numeric_reader'];o=n['observation'];f=fields(o);bias=0 if literal['operacion']=='suma' else 32
  assert n['representation_bias']==bias
  valid=f['state']>0 and f['semantic']==1 and f['direction']==[1,-1,-1] and o['site']==[12,17,18] and o['tick']==unit['native_operation']['native_trial']['datum_tick']-2
  value=f['s_reg']-bias if valid else None
  assert value==n['numeric_result']==unit['numeric_result']
  assert unit['native_operation']['operands']==[literal['izquierda'],literal['derecha']]
  assert all(unit[k] is False for k in ['R04_route_consulted','provider_called','quality_evaluation_or_return','teacher_delivered','fallback_to_failed_request'])
  return value,{'kind':'P0_arithmetic','bias':bias,'raw_numeric':o,'operator_selected_operation':unit['operator_selected_operation']}
 raise ValueError('Unsupported frozen mode '+mode)
def contrast_recount():
 history=[]
 for arm in ['PLUS','MINUS','EDAD']:
  for stage in ['HISTORIA','USO_COMUN','RESERVA']:
   wrapper=load('ECI02/PRIMARIOS/L_'+arm+'_'+stage+'.json.gz');q=wrapper['request']['result'];q=json.loads(q) if isinstance(q,str) else q
   root=q['result'];unit=root['rows'][0] if root.get('rows') else root;receipts=count_receipts(unit);entry={'life':wrapper['life'],'arm':arm,'stage':stage,'before_tick':wrapper['before']['tick'],'after_tick':wrapper['after']['tick'],'requested':len(receipts),'statuses':dict(collections.Counter(x['status'] for x in receipts.values()))}
   if stage!='HISTORIA':
    sign=purez(unit['word']['reader']);interaction=unit['interaction'];reader=interaction['reader']
    if sign==-1:
     result=purez(reader);assert interaction['kind']=='query'
    else:
     values=[]
     for o in reader['observations']:
      f=fields(o);x,y,z=f['direction']
      if f['state']>0 and f['semantic']==1 and x in [-1,0,1] and y==1 and z in [0,-1] and o['site']==[(15+2*x)%67,17,(15+2*z)%67]:values.append(x)
     result=values[0] if len(values)==1 else None
     assert result==reader['choice'] and interaction['kind']=='native_current_selection'
    entry.update(lexical_signal=sign,prepared_host_branch=interaction['kind'],following_response=result)
    assert sign==(-1 if arm=='MINUS' else 1) and result==sign
   history.append(entry)
 n=load('ECI02/PRIMARIOS/E02_P11_reserved_native_composition_9_then_5.json.gz');u=n['request']['result']['result']['rows'][0]
 assert len(u['rows'])==1
 stage=u['rows'][0];assert purez(stage['word']['reader'])==1
 assert all(fields(o)['state']==0 and int(o['raw'])==0 for o in stage['route']['reader']['observations'])
 assert stage['native_route_command'] is None and stage['native_numeric'] is None and stage['external_tool'] is None
 assert stage['committed_effect']['provider_calls']=={'external':0,'native':0} and stage['committed_effect']['artifact'] is None
 rs=count_receipts(u)
 assert len(rs)==19 and all(x['status']=='applied' for x in rs.values())
 negative={'life':n['life'],'label':n['label'],'before':n['before'],'after':n['after'],'formed_operator_sign':1,'route_actuator_RAW':[o['raw'] for o in stage['route']['reader']['observations']],'route_command':None,'numeric_response':None,'providers':0,'artifact':None,'requested':len(rs),'applied':19,'second_stage_executed':False,'scope':'Fracaso del acceso R04/proveedor en la reserva, con entradas admitidas. No resultado aritmético incorrecto ni prueba de borrado global.'}
 return {'history_contrasts':history,'negative_reservation':negative,'P1_assistance':'El signo adquirido es nativo; el host selecciona if/else MA.query o MU.current. No selección de acceso completamente interna ni P2/R2.'}
def run():
 proof=load('CIERRE/PRUEBA_CONSOLIDACION_RECUPERADA_R02.json');protocol=load('CIERRE/PROTOCOLO_CONSOLIDACION_R02.json')
 assert proof['protocol_sha256']==sha((HERE/'CIERRE/PROTOCOLO_CONSOLIDACION_R02.json').read_bytes())
 assert proof['life']==protocol['life']=='ECI02_CIERRE_CANDIDATA_01'
 requests=proof['recovered_requests'];assert len(requests)==len(protocol['ordered_requests'])==12
 rows=[];all_events={};previous=proof['initial_record']['physical'];actual_first=None
 for r,plan in zip(requests,protocol['ordered_requests']):
  assert r['id']==plan['id'];terminal=r['terminal'];assert terminal['status']=='completed' and terminal['error'] is None
  native=json.loads(terminal['result']);payload=json.loads(terminal['payload']);literal=r['literal']
  assert payload['situaciones']==[literal] and payload['retorno']=='omit' and payload['actuador']=='closed'
  frozen_literal=plan.get('row',{'modo':'eci01-aritmetica-directa','operacion':'diferencia','izquierda':actual_first,'derecha':2})
  assert literal==frozen_literal
  assert r['before']['tick']==native['before_tick']==previous['tick']
  for k in ['N','RAW_sha256','clocks_sha256']:assert r['before'][k]==previous[k]
  unit=native['result']['rows'][0];receipts=count_receipts(unit);value,details=decode(unit,literal)
  for ident,receipt in receipts.items():
   if ident in all_events:assert all_events[ident]==receipt
   all_events[ident]=receipt
  counts=dict(collections.Counter(x['status'] for x in receipts.values()))
  expected=protocol['auditor_only'][r['id']]
  correct=value is not None and value==expected and len(receipts)>0 and counts=={'applied':len(receipts)}
  if r['id']=='SUM':actual_first=value
  previous=r['after'];assert native['after_tick']==previous['tick']
  rows.append({'id':r['id'],'literal':literal,'tick_before':r['before']['tick'],'tick_after':r['after']['tick'],'response':value,'expected_auditor_only':expected,'correct_with_complete_admission':correct,'unique_input_count':len(receipts),'statuses':counts,'details':details})
 assert proof['final_record']['physical']['RAW_sha256']==previous['RAW_sha256']
 assert proof['initial_record']['parent']==proof['final_record']['parent']
 assert proof['final_record']['operations'][:len(proof['initial_record']['operations'])]==proof['initial_record']['operations']
 exact=[]
 for r in load('CIERRE/PRIMARIOS_OUTBOX_CIERRE_R01.json')['rows']:
  b=(HERE/'OUTBOX'/str(r['label']+'.json')).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
  parsed=json.loads(b)
  if not r['label'].startswith('APP_'):
   original=next(x for x in requests if x['id']==r['label'])
   terminal_native=json.loads(original['terminal']['result'])
   assert parsed['result']==terminal_native['result']
   assert all(parsed[k]==terminal_native[k] for k in ['id','before_tick','after_tick'])
   assert sha(original['terminal']['payload'].encode('utf-8'))==r['exact_payload_sha256']
  exact.append({'label':r['label'],'bytes':len(b),'sha256':sha(b)})
 # Independently decode the exact two normal-application outboxes.
 app=[]
 for name,literal in [('APP_1',{'modo':'eci01-balance','izquierda':7,'derecha':7}),('APP_2',{'modo':'memoria','operacion_memoria':'usar','contexto':'alfa'})]:
  native=load('OUTBOX/'+name+'.json');unit=native['result']['rows'][0];value,details=decode(unit,literal);events=count_receipts(unit)
  app.append({'label':name,'response':value,'unique_inputs':len(events),'statuses':dict(collections.Counter(x['status'] for x in events.values())),'before':native['before_tick'],'after':native['after_tick']})
 result={'schema':'DEE.audit.passive_independent_recount.2026-11-07','new_ticks':0,'DEE_imports':0,'SQLite_opens':0,'scope':'Recuento/decodificación de primarios archivados. No prueba funcionamiento actual.','panel_life':proof['life'],'rows':rows,'panel_material_requests':len(rows),'panel_correct':sum(r['correct_with_complete_admission'] for r in rows),'panel_unique_native_inputs':len(all_events),'panel_statuses':dict(collections.Counter(x['status'] for x in all_events.values())),'arithmetic_chain_uses_actual_first_result':rows[9]['literal']['izquierda']==rows[8]['response']==9,'recorded_tick_span':previous['tick']-proof['initial_record']['physical']['tick'],'exact_outboxes':exact,'normal_app_isolated_future':app,'reopen_witness_original':proof['reopen_passive_comparison'],'unavailable_original_fields':proof['missing_original_fields'],'contrasts':contrast_recount(),'limits':['Los snapshots originales de antes/después del panel y su transporte no se incluyen. Se añadió un snapshot nativo publicado de la principal en la evidencia de estado; no sustituye al par operativo. Las igualdades del panel son testigos originales.','Las doce oportunidades son una trayectoria y no doce individuos.','929 cuenta IDs Native únicos; alias de recibos no se duplican.','Los expected del protocolo pertenecen sólo al auditor; no entran al decodificador RAW.']}
 assert result['panel_correct']==12 and result['panel_unique_native_inputs']==929 and result['panel_statuses']=={'applied':929}
 assert [x['response'] for x in app]==[0,-1] and sum(x['unique_inputs'] for x in app)==183
 return result
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--out',type=pathlib.Path);args=ap.parse_args();r=run();s=json.dumps(r,ensure_ascii=False,indent=2)+'\n'
 if args.out:args.out.write_text(s,encoding='utf-8')
 print(json.dumps({k:r[k] for k in ['new_ticks','panel_life','panel_material_requests','panel_correct','panel_unique_native_inputs','panel_statuses','arithmetic_chain_uses_actual_first_result','normal_app_isolated_future']},ensure_ascii=False))
