"""Read DEETSNP1/v2 bytes only. No DEE import, owner, mutation, restore or tick.
Wire layout: official runtime.cpp613–813; Organizational metadata231–239.
CLI: python -B recalcular_snapshot_sin_dee.py [snapshot.deetsnap.gz]
Defaults to the one principal snapshot included beside this script.
"""
from pathlib import Path
import argparse,struct,gzip,hashlib,json,collections
class Reader:
 def __init__(self,b):self.b=b;self.i=0
 def n(self,n):
  if n<0 or n>len(self.b)-self.i:raise ValueError('Truncated snapshot')
  v=self.b[self.i:self.i+n];self.i+=n;return v
 def u8(self):return self.n(1)[0]
 def u32(self):return struct.unpack('<I',self.n(4))[0]
 def u64(self):return struct.unpack('<Q',self.n(8))[0]
 def s(self):return self.n(self.u32()).decode('utf-8')
def digest(x):return hashlib.sha256(x).hexdigest()
def inspect(p):
 b=p.read_bytes();d=gzip.decompress(b);r=Reader(d)
 if r.n(8)!=b'DEETSNP1' or r.u32()!=2:raise ValueError('Not supported DEETSNP1/v2')
 N=r.u32();tick=r.u64();paused=r.u8();eid=r.u64();sequence=r.u64();phase=r.s();count=r.u64()
 if count!=N**3:raise ValueError('Dimension/array mismatch')
 raw=r.n(count*8);clocks=r.n(count*8);values=list(struct.unpack('<'+str(count)+'Q',raw));channels=r.u32()
 for _ in range(channels):r.s();r.n(31)
 pending=r.u32();events=[]
 for _ in range(pending):
  x={'boundary':r.u64(),'id':r.u64(),'kind':r.u8(),'requested_tick':r.u64(),'sequence':r.u64()};x['channels']=[r.s()for _ in range(r.u32())];nw=r.u32();r.n(nw*20);x['writes_count']=nw;events.append(x)
 receipts=r.u32();statuses=collections.Counter()
 for _ in range(receipts):
  r.u64();r.u8();statuses[r.u8()]+=1;r.u64()
  if r.u8():r.u64()
  for _ in range(r.u32()):r.s()
  r.s()
 backend=r.u8();threads=r.u64();nmeta=r.u32();meta={}
 for _ in range(nmeta):k=r.s();meta[k]=r.s()
 if r.i!=len(d)-8:raise ValueError('Trailing/missing bytes')
 stored=r.u64();fnv=1469598103934665603
 for x in d[:-8]:fnv=((fnv^x)*1099511628211)&0xffffffffffffffff
 if fnv!=stored:raise ValueError('FNV1a64 mismatch')
 jm={}
 for k,v in meta.items():
  if k.startswith('dee_thinking.organizational.'):continue
  try:jm[k]=json.loads(v)
  except ValueError:pass
 service=jm.get('DEE.Cognitive.System.1.1.PERSISTENT_SERVICE.v1',{});slots={k:v for k,v in jm.items()if '.PERSISTENT_SERVICE.v1.queue.'in k};org=int(meta['dee_thinking.organizational.v1.chunks']);orgbytes=bytes.fromhex(''.join(meta['dee_thinking.organizational.v1.'+str(i)]for i in range(org)))
 return {'snapshot_name':p.name,'encoded_bytes':len(b),'encoded_sha256':digest(b),'decoded_bytes':len(d),'decoded_sha256':digest(d),'gzip_crc_verified':True,'fnv1a64_verified':True,'version':2,'N':N,'tick':tick,'native_paused_flag':paused,'next_event_id':eid,'next_sequence':sequence,'protocol_phase':phase,'sites':count,'occupied_state_nonzero':sum((x&0xffffffff)!=0 for x in values),'RAW_nonzero':sum(x!=0 for x in values),'max_s_reg':max((x>>32)&0xffff for x in values),'RAW_sha256':digest(raw),'clocks_sha256':digest(clocks),'channels':channels,'pending_count':pending,'pending':events,'receipts_count':receipts,'receipt_status_enum_counts':dict(statuses),'backend_enum':backend,'threads':threads,'metadata_entries':nmeta,'organizational_chunks':org,'organizational_bytes':len(orgbytes),'organizational_sha256':digest(orgbytes),'native_life_metadata':jm.get('DEE.Cognitive.System.1.1.life.v1'),'service_protocol':service,'queue_slots_count':len(slots),'queue_slots_all_empty':all(x=={'empty':True}for x in slots.values()),'external_balancing':jm.get('DEE.Cognitive.ECI01.external_balancing.P0.R1'),'scope':'Passive byte calculation; not engine execution, functional query, or full operational backup. SQLite/work artifacts are omitted.'}
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('snapshot',nargs='?',type=Path,default=Path(__file__).parent/'ECI02_OPERATIVA_PRINCIPAL_01.T727225.8965823a85b7.deetsnap.gz');v=a.parse_args();print(json.dumps(inspect(v.snapshot),ensure_ascii=False,indent=2))
