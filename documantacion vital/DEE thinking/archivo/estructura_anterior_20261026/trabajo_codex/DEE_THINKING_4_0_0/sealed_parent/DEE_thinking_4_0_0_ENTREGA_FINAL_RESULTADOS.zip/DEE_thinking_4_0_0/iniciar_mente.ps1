param(
    [ValidateSet('continuidad','comparacion','politica','informacion','relaciones','composicion')]
    [string]$Perfil = 'continuidad',
    [string]$Python = 'py',
    [string]$Eventos = '',
    [string]$Sesion = '',
    [string]$Cargar = ''
)
$ErrorActionPreference = 'Stop'
$appPath = Join-Path $PSScriptRoot 'app\conversar.py'
$appArguments = @('-I','-B',$appPath,'--perfil',$Perfil)
if ($Eventos) { $appArguments += @('--eventos',$Eventos) }
if ($Sesion) { $appArguments += @('--sesion',$Sesion) }
if ($Cargar) { $appArguments += @('--cargar',$Cargar) }
if ($Python -eq 'py') { & py -3.13 @appArguments } else { & $Python @appArguments }
exit $LASTEXITCODE
