"""Run from a clean extraction against its noneditable installed WHL."""
import argparse,hashlib,json,sys,tempfile
from pathlib import Path
import dee_thinking as d
def main():
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args()
    assert d.__version__=='4.0.0' and 'site-packages' in d.__file__
    assert d.build_info()['kernel_version']==27
    assert not any(n.startswith(('src.core','src.habitat','src.lenguaje','dee_universe_v27')) for n in sys.modules)
    seed=d.reference_seed_path();params=d.CognitiveParameters();params.seed_path=seed;params.profile='comparison'
    c=d.CognitiveSession.create(params);c.sense();c.predict()
    with tempfile.TemporaryDirectory(prefix='dt4-release-') as td:
        save=str(Path(td)/'pending.deetsnap');c.save_snapshot(save);r=d.CognitiveSession.load_snapshot(save)
        left=c.compare();right=r.compare();assert c.tick==84 and r.tick==84;assert left['status']=='CURRENT_NATIVE_COMPARISON_MEASURED';assert left['comparison_decoder']==right['comparison_decoder'];assert left['comparison_decoder']['presentation']=='discrepancia_direccional';assert c.world.runtime.raw_copy()==r.world.runtime.raw_copy();assert c.world.runtime.clock_copy()==r.world.runtime.clock_copy()
        w=d.create_learnable_cascade(2);receipts=d.experience_composition(w,[(3,9),(3,11)]);w.save_snapshot(str(Path(td)/'learned.deetsnap'));v=d.OrganizationalWorld.load_snapshot(str(Path(td)/'learned.deetsnap'));q=d.query_composition(v,23)
        assert q['decoded']['stage0']==35 and q['decoded']['stage1']==49
    row={'version':d.__version__,'module':d.__file__,'build_info':d.build_info(),'cpc3_function':'physical comparison at84','cpc3_result':left,'new_reserved_question':{'query':23,'response':q},'save_restore_continue':True,'no_hidden_lab_imports':True}
    Path(a.out).write_text(json.dumps(row,ensure_ascii=False,indent=2),encoding='utf-8');print('CLEAN_EXTRACTION_RELEASE_SMOKE_OK')
if __name__=='__main__':main()
