# Fuente editorial

`manuscript.json` conserva los bloques editables del libro (texto, tablas, ejemplos y referencias). `page_map.json` conserva el mapa de paginación del render verificado. El documento Word es la representación final editable y el original3.5 permite recuperar su cobertura anterior.

Los textos heredados S01-S20 conservan sus referencias históricas3.5; los P4 remiten al producto4.0. Las afirmaciones de las conversaciones permanecen diferenciadas de las mediciones. La redacción nueva organiza el uso y la interpretación, sin modificar el kernel ni los artefactos científicos.

No se requiere reconstruir editorialmente el libro para usar el producto o ejecutar los ejemplos.
