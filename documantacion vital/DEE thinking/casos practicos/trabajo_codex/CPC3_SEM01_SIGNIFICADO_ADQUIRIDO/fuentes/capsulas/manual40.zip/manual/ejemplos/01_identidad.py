# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import hashlib
import platform
import sys
from pathlib import Path
import dee_thinking as dt

if dt.__version__ != "4.0.0":
    raise RuntimeError("Este manual corresponde a DEE thinking 4.0.0")
seed = Path(dt.reference_seed_path())
expected = "cd09a4d94f72e00d9a5163c8dfd1d62e1528f1d146e4cb44ae23d261b3da09e6"
if hashlib.sha256(seed.read_bytes()).hexdigest() != expected:
    raise RuntimeError("La semilla no coincide con el corte documentado")
print("Python:", sys.version)
print("Plataforma:", platform.platform())
print("Import:", Path(dt.__file__).resolve())
print("Producto:", dt.__version__, dt.build_info())
print("Nucleo:", dt.kernel_identity())
print("Semilla:", seed)
print("Protocolos:", [d.id for d in dt.integrated_protocol_descriptors()])
