# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

world = dt.Runtime(11)
world.execution_options = dt.TickOptions(dt.Backend.LAZY, 1)
channel = dt.ChannelSpec()
channel.name = "entrada"
channel.injection_site = dt.Coordinate(3, 4, 5)
channel.state = 101
channel.direction = dt.Direction(1, 0, 0)
channel.semantic = 1
channel.allow_experience = True
channel.allow_probe = True
world.register_channel(channel)
request = world.experience("entrada", 0, 17)
assert request.status == dt.EventStatus.SCHEDULED
world.advance(0)
assert world.current_tick == 0
world.advance(1)
receipt = world.receipt(request.id)
assert receipt.status == dt.EventStatus.APPLIED
reading = world.observe(dt.Coordinate(4, 4, 5))
assert reading.record.s_reg == 17
print(world.current_tick, reading.record.s_reg, reading.clock)
# Continuar el mismo Runtime, no crear otro.
second = world.experience("entrada", world.current_tick, 3)
world.advance(1)
print("Segunda entrada:", world.receipt(second.id).status)
