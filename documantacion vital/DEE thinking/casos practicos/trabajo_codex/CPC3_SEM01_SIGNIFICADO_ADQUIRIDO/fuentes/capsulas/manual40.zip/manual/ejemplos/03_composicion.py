# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
from pathlib import Path
import dee_thinking as dt

catalog = dt.OrganizationCatalog()
learn = dt.OrganizationRequest()
learn.catalog_id = "relation_learning.c6h01.v1"
learn.instance_id = "learner"
learn.anchor = dt.Coordinate(10, 18, 14)
read = dt.OrganizationRequest()
read.catalog_id = "relation_query.c6h01.v1"
read.instance_id = "reader"
read.anchor = dt.Coordinate(10, 26, 14)
link = dt.ConnectionRequest()
link.source = dt.Endpoint()
link.source.instance, link.source.port = "learner", "learned_relation"
link.target = dt.Endpoint()
link.target.instance, link.target.port = "reader", "relation_input"
link.purpose = "consulta posterior"
plan = dt.CompositionPlanner(34)
plan.add(catalog.instantiate(learn))
plan.add(catalog.instantiate(read))
plan.connect(link)
if any(p.severity == dt.DiagnosticSeverity.ERROR for p in plan.analyze()):
    raise RuntimeError("La composicion contiene errores de contrato")
world = plan.build()
world.runtime.execution_options = dt.TickOptions(dt.Backend.LAZY, 1)
cue, teacher = dt.PortInputRequest(), dt.PortInputRequest()
cue.instance, cue.port, cue.s_reg = "learner", "cue", 5
teacher.instance, teacher.port, teacher.s_reg = "learner", "teacher", 7
training = world.experience_batch([cue, teacher], 0)
world.runtime.run_until(6)
query = world.probe("reader", "query", 6, 13)
world.runtime.run_until(11)
assert world.runtime.receipt(query.id).status == dt.EventStatus.APPLIED
answer = world.runtime.observe(world.landmarks["reader.response"])
assert answer.record.s_reg == 25
print("Respuesta:", answer.record.s_reg)
out = Path("resultados_manual"); out.mkdir(exist_ok=True)
world.save_snapshot(str(out / "composicion.deetsnap"))
