# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import tempfile
from pathlib import Path
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.DelayPositionConfig()
config.input_delay = 3
result = dt.run_delay_position(config, options)
assert result.measurement == 3
assert tuple(result.active_labels) == (3,)
print("Retardo y posicion:", result.measurement, result.active_labels)
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "h1.deetsnap"
    dt.save_delay_position_checkpoint(config, 5, str(path), options)
    resumed = dt.resume_delay_position_checkpoint(str(path), options)
assert resumed.final_raw == result.final_raw
assert resumed.final_clock == result.final_clock
print("H1 reanudado con el mismo estado final")
