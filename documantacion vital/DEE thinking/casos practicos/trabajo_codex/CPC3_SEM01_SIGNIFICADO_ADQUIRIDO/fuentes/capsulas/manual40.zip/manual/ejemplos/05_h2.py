# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.SeparatedRepertoireConfig()
separated = dt.run_separated_repertoire(config, options)
assert separated.exact_channels == 3
assert separated.all_exact
print("Canales separados:", separated.exact_channels)
config.channels = 7
seven = dt.run_separated_repertoire(config, options)
assert seven.exact_channels == 7
print("Panel ampliado del contrato:", seven.exact_channels)
common = dt.OverlapRepertoireConfig()
overlap = dt.run_overlap_repertoire(common, options)
assert overlap.merge_exact and overlap.composed_response_exact
assert not overlap.individual_identity_preserved
print("Integracion exacta:", overlap.merge_exact)
common.off_fiber = True
control = dt.run_overlap_repertoire(common, options)
assert not control.false_merge
