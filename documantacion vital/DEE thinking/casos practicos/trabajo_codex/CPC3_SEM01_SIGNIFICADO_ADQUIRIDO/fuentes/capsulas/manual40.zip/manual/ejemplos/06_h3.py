# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.RepairConfig()
config.authorize_diagnostic_damage = True
result = dt.run_trained_redundancy_repair(config, options)
assert result.damage_applied
assert result.function_lost_after_damage
assert result.reconstructed_at_arrival and result.fresh_function
print("Funcion recuperada:", result.fresh_function)
config.arm = dt.RepairArm.BACKUP_UNTRAINED
control = dt.run_trained_redundancy_repair(config, options)
assert not control.fresh_function
print("Control sin respaldo entrenado:", control.fresh_function)
