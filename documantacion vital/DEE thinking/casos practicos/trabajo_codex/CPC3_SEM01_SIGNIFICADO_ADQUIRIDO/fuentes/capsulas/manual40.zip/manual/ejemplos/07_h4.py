# DEE thinking 4.0.0 - ejemplo didactico del analizador H4
import dee_thinking as dt

# Lecturas construidas: no son resultados de una nueva corrida DEE.
def reading(load):
    item = dt.AccessibilityReading()
    item.site = dt.Coordinate(1, 2, 3)
    item.raw = dt.pack_record(1, load, 1, 0, 0, 1)
    item.clock = 41
    return item

cases = []
for name, load in (("historia_a", 12), ("historia_b", 17)):
    case = dt.AccessibilityCase()
    case.history_id = name
    case.baseline_tick = case.challenged_tick = 41
    case.baseline = [reading(10)]
    case.challenged = [reading(load)]
    case.history_status = dt.AccessibilityStatus.NOT_DEMONSTRATED
    case.history_reached_natively = False
    case.challenge_applied_to_diagnostic_clone = True
    cases.append(case)
request = dt.AccessibilityRequest()
request.observer_id = "ejemplo_didactico"
request.challenge_id = "desafio_fijo"
request.cases = cases
result = dt.analyze_accessibility(request)
assert result.comparable
assert [list(e.s_reg_deltas) for e in result.effects] == [[2], [7]]
print("Deltas:", [list(e.s_reg_deltas) for e in result.effects])
print("Contraste:", result.history_conditioned_response)
