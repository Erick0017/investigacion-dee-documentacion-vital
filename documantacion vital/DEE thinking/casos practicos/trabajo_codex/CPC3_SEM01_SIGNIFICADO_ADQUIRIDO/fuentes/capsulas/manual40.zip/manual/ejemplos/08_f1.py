# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.ReusableRevisionConfig()
result = dt.run_reusable_revision(config, options)
assert tuple(result.response_loads) == (4149, 4165, 4181)
assert tuple(result.post_revision_loads) == (4160, 4178)
print("Revisiones 11/13:", result.response_loads)
config.id = "REV_13_11"
config.revision1, config.revision2 = 13, 11
reverse = dt.run_reusable_revision(config, options)
assert tuple(reverse.response_loads) == (4149, 4167, 4181)
print("Revisiones 13/11:", reverse.response_loads)
