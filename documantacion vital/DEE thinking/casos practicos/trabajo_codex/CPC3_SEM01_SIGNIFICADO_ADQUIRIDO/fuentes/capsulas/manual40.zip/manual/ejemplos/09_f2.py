# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.EnvironmentalReturnConfig()
result = dt.run_environmental_return(config, options)
assert result.environment_load == 19664
assert result.overflow_total == 1
assert tuple(result.downstream_loads) == (24, 55, 62, 62, 67)
print("Mediacion:", result.downstream_loads)
config.id = "ENV_SUBTHRESHOLD"
config.bias_load = 15514
control = dt.run_environmental_return(config, options)
assert control.overflow_total == 0
assert tuple(control.downstream_loads) == (23, 54, 61, 61, 66)
print("Control subumbral:", control.downstream_loads)
