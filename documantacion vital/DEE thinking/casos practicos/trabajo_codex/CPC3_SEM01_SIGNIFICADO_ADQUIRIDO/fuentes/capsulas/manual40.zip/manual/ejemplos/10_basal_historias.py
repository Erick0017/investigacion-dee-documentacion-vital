# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

histories = ((dt.BasalHistory.AB, 1),
             (dt.BasalHistory.BA, -1),
             (dt.BasalHistory.H0, 0))
for history, expected in histories:
    world = dt.create_relational_world(history)
    before = world.observe()
    assert before.absolute_tick == 32 and before.delta == 0
    world.advance(1)
    after = world.observe()
    assert after.delta == expected
    print(history, after.absolute_tick, after.relative_tick,
          after.a.record.s_reg, after.b.record.s_reg, after.delta)
# Cada vuelta crea un ensayo distinto; no es una sola historia acumulada.
