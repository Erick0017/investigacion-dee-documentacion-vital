# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

world = dt.create_contextual_world()
world.advance(131)
before = world.observe()
assert before.absolute_tick == 163 and before.delta == 1
gate = dt.inspect_write_gate(world.runtime, world.ports.b, True)
assert gate.n_active == 6 and gate.local_clock == 391
assert gate.period == 391 and gate.phase_remainder == 0
assert gate.ordinary_increment_condition
print("Compuerta:", gate.branch, gate.n_active, gate.local_clock)
reference = world.fork()
world.advance(1)
assert world.observe().delta == 0
change = dt.compare_site_transition(reference.runtime, world.runtime,
                                    world.ports.b)
print("Campos modificados:", change.changed_fields)
world.advance(38)
assert world.observe().relative_tick == 170
assert world.observe().delta == 0
print("Relacion retenida:", world.observe().delta)
