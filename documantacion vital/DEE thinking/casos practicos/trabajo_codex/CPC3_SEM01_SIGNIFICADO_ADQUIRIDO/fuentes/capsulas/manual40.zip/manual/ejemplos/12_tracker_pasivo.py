# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import json
from pathlib import Path
import dee_thinking as dt

world = dt.create_relational_world()
reference = world.fork()
site = dt.TrackedSite()
site.id, site.site = "A", world.ports.a
tracker = dt.PassiveTracker([site], 8)
tracker.capture(world.runtime)
for _ in range(3):
    world.advance(1)
    tracker.capture(world.runtime)
    reference.advance(1)
assert world.runtime.raw_copy() == reference.runtime.raw_copy()
assert world.runtime.clock_copy() == reference.runtime.clock_copy()
assert len(tracker.frames) == 4
assert len(tracker.transitions) == 3
rows = [{"tick": int(f.tick), "readings": [
    {"site": [o.coordinate.x, o.coordinate.y, o.coordinate.z],
     "raw_hex": format(int(o.raw), "016x"), "clock": str(o.clock)}
    for o in f.observations]} for f in tracker.frames]
out = Path("resultados_manual"); out.mkdir(exist_ok=True)
(out / "traza_sitios.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print("Alcance:", tracker.transitions[0].scope)
print("Frames guardados:", len(tracker.frames))
