# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

parent = dt.create_contextual_world()
parent.advance(131)
raw_before = parent.runtime.raw_copy()
clock_before = parent.runtime.clock_copy()
edit = dt.ResearchStateEdit()
edit.coordinate = parent.ports.b
edit.clock = 392
edit.label = "phase_plus_one_at_B"
result = dt.compare_diagnostic_fork(parent, [edit], 1, True)
assert result.parent_unchanged
assert result.reference_observation.delta == 0
assert result.diagnostic_observation.delta == 1
assert parent.runtime.raw_copy() == raw_before
assert parent.runtime.clock_copy() == clock_before
print("Referencia / fork:", result.reference_observation.delta,
      result.diagnostic_observation.delta)
print("Diferencias RAW:", result.raw_different_sites)
# La intervencion es diagnostica; no se atribuye a la historia del padre.
