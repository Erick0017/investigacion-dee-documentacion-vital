# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
from pathlib import Path
import dee_thinking as dt

out = Path("resultados_manual"); out.mkdir(exist_ok=True)
world = dt.create_relational_world()
world.advance(1)
path = out / "basal_adquirida.deetsnap"
world.save_snapshot(str(path))
restored = dt.BasalWorld.load_snapshot(str(path))
assert restored.runtime.raw_copy() == world.runtime.raw_copy()
assert restored.runtime.clock_copy() == world.runtime.clock_copy()
world.advance(8)
restored.advance(8)
assert restored.runtime.raw_copy() == world.runtime.raw_copy()
assert restored.runtime.clock_copy() == world.runtime.clock_copy()
print("Restauracion y continuacion:", restored.runtime.current_tick,
      restored.observe().delta)
# La semilla historica no tiene schema basal: usar Runtime para cargarla.
seed_world = dt.Runtime.load_snapshot(dt.reference_seed_path())
print("Semilla Runtime:", seed_world.current_tick)
