# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

world = dt.create_relational_world()
other = world.fork()
world.runtime.execution_options = dt.TickOptions(dt.Backend.DENSE_SEQUENTIAL, 1)
other.runtime.execution_options = dt.TickOptions(dt.Backend.LAZY, 1)
world.advance(8)
other.advance(8)
assert world.runtime.raw_copy() == other.runtime.raw_copy()
assert world.runtime.clock_copy() == other.runtime.clock_copy()
print("Mismo estado fisico a tick", world.runtime.current_tick)
