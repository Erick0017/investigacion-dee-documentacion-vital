# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import dee_thinking as dt

prepared = dt.create_relational_world()
owner = prepared.runtime.fork()
config = dt.BasalConfig.relational_reference(dt.reference_seed_path())
view = dt.BasalWorld.attach(owner, config, prepared.ports, prepared.t0_tick)
view.advance(1)
assert owner.current_tick == 33
assert view.observe().delta == 1
print("La vista usa el Runtime propietario:", owner.current_tick)
# attach no instalo materia ni certifico la organizacion; los puertos
# proceden aqui de una preparacion conocida y compatible.
