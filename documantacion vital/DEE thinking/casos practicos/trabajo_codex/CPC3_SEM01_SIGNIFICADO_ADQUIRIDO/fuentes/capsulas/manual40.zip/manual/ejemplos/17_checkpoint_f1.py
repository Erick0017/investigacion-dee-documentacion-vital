# DEE thinking 4.0.0 - ejemplo del Libro Blanco y Manual Tecnico
import tempfile
from pathlib import Path
import dee_thinking as dt

options = dt.TickOptions(dt.Backend.LAZY, 1)
config = dt.ReusableRevisionConfig()
complete = dt.run_reusable_revision(config, options)
with tempfile.TemporaryDirectory() as tmp:
    path = Path(tmp) / "f1_t40.deetsnap"
    dt.save_reusable_revision_checkpoint(config, 40, str(path), options)
    resumed = dt.resume_reusable_revision_checkpoint(str(path), options)
assert resumed.final_raw == complete.final_raw
assert resumed.final_clock == complete.final_clock
assert tuple(resumed.response_loads) == tuple(complete.response_loads)
print("F1 reanudado:", resumed.response_loads)
