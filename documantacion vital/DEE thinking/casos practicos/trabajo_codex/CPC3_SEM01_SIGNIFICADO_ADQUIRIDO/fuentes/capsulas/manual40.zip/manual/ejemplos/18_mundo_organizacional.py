# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("mobile_pair")
print("Vistas:", w.organization_ids)
print("Interfaces:", [i.name for i in w.interfaces])
for j, teacher in enumerate((7, 11)):
    w.submit(f"l{j}.cue", 5, 0)
    w.submit(f"l{j}.teacher", teacher, 0)
w.run_until(6)
for j in range(2):
    w.probe(f"q{j}.query", 13, 6)
w.run_until(11)
result = [w.observe(f"q{j}", "response").record.s_reg
          for j in range(2)]
assert result == [25, 29]
print("Respuesta:", result)
