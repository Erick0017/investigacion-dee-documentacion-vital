# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("mobile_pair")
for j, teacher in enumerate((7, 11)):
    w.submit(f"l{j}.cue", 5, 0)
    w.submit(f"l{j}.teacher", teacher, 0)
w.run_until(6)
i = d.InterfaceSpec()
i.name = "sensor"
ch = next(x.channel for x in w.interfaces if x.name == "q0.query")
ch.name = "sensor"
i.channel = ch
codec = d.InputCodec()
codec.type = d.CodecType.ENUMERATION
codec.symbols = {"Sensor_Activo": 13}
i.codec = codec
w.declare_interface(i)
receipt = w.probe_symbol("sensor", "Sensor_Activo", 6)
w.run_until(11)
assert w.runtime.receipt(receipt.id).status == d.EventStatus.APPLIED
decoder = d.OutputDecoder()
decoded = w.decode("q0", "response", decoder)
assert decoded.integer == 25
print(decoded.integer, decoded.status)
# Sensor_Activo es un nombre externo de la entrada, no una palabra aprendida.
