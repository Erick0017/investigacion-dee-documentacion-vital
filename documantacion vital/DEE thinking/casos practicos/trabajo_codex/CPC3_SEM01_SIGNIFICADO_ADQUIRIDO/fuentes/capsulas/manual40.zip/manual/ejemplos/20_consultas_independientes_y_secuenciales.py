# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
from pathlib import Path
import dee_thinking as d

w = d.create_organization("mobile_pair")
for j, teacher in enumerate((7, 11)):
    w.submit(f"l{j}.cue", 5, 0)
    w.submit(f"l{j}.teacher", teacher, 0)
w.run_until(6)
for value in (13, 7, 17):
    branch = w.fork()
    for j in range(2):
        branch.probe(f"q{j}.query", value, 6)
    branch.run_until(11)
    print("independiente", value,
          [branch.observe(f"q{j}", "response").record.s_reg
           for j in range(2)])
w.start_mobile_sequence("serie", [13, 7, 17])
w.run_until(13)
out = Path("resultados_manual"); out.mkdir(exist_ok=True)
path = out / "serie.deetsnap"
w.save_snapshot(str(path))
restored = d.OrganizationalWorld.load_snapshot(str(path))
restored.run_until(21)
values = [[o.record.s_reg for o in step.captured]
          for step in restored.protocols[0].steps]
assert values == [[25, 29], [32, 36], [49, 53]]
print("secuencial", values)
