# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

for history, expected in ((d.BasalHistory.AB, 1),
                          (d.BasalHistory.BA, -1),
                          (d.BasalHistory.H0, 0)):
    w = d.create_organization("relational", history=history)
    w.advance(250)
    read = w.view("body").observe()
    assert read.delta == expected
    q = w.fork()
    q.probe("body.common_query", 7, q.runtime.current_tick)
    q.advance(3)
    answer = q.observe("body", "comparator").record.dx
    assert answer == expected
    print(history, read.delta, read.reader_available, answer)
