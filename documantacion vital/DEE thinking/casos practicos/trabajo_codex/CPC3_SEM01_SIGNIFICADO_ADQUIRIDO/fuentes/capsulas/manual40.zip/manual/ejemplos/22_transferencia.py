# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

for teacher, expected in ((7, 25), (11, 29)):
    w = d.create_organization("native_transfer", teacher0=teacher)
    w.probe("query", 0, 6)
    w.probe("receiver_query", 13, 16)
    w.run_until(21)
    value = w.observe("stage0", "receiver_response").record.s_reg
    assert value == expected
    print("transferencia nativa", teacher, value)
