# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

source = d.create_organization("relational")
source.advance(3)
target = d.create_organization("relational", history=d.BasalHistory.H0)
target.advance(3)
spec = d.ReconstructionSpec()
spec.source_sites = [source.view("body").spec.a, source.view("body").spec.b]
spec.destination_sites = [target.view("body").spec.a, target.view("body").spec.b]
spec.copy_raw = True
spec.copy_clocks = False
spec.authorize_assisted_reconstruction = True
rebuilt = target.assisted_reconstruction(source, spec)
assert target.view("body").observe().delta == 0
assert rebuilt.view("body").observe().delta == 1
print("original", target.view("body").observe().delta)
print("copia asistida", rebuilt.view("body").observe().delta)
print(rebuilt.diagnostic_edits[-1].modality)
