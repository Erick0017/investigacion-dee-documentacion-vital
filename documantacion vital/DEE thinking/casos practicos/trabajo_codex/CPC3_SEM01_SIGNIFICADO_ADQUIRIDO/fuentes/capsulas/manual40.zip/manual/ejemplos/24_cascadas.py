# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

for depth, expected in ((2, 39), (4, 73), (8, 165)):
    w = d.create_organization("cascade", depth=depth)
    w.probe("query", 13, 6)
    values = []
    for j in range(depth):
        w.run_until(11 + 5*j)
        values.append(w.observe(f"stage{j}", "response").record.s_reg)
    assert values[-1] == expected
    print(depth, values)
