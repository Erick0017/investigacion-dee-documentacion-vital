# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("mobile_basal")
w.advance(6)
assert w.view("body").observe().delta == 1
assert w.observe("body", "comparator").record.s_reg == 12
q = w.fork()
q.probe("body.common_query", 7, q.runtime.current_tick)
q.advance(3)
assert q.observe("body", "comparator").record.dx == -1
print("memoria", w.view("body").observe().delta)
print("expresion", w.observe("body", "comparator").record.s_reg)
print("sonda", q.observe("body", "comparator").record.dx)
