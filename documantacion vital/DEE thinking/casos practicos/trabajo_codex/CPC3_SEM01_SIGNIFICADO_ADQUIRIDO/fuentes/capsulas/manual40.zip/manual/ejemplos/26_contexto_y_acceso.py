# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("contextual")
w.advance(131)
b = w.view("body").spec.b
g = d.inspect_write_gate(w.runtime, b, True)
assert (g.local_clock, g.n_active, g.period) == (391, 6, 391)
w.advance()
assert w.view("body").observe().delta == 0
print("reescritura", w.view("body").observe().delta)
for mode, expected in ((0, [32, 0]), (1, [0, 32]), (2, [0, 54])):
    w = d.create_organization("phase", mode=mode)
    w.run_until(40)
    values = []
    for delay in (0, 1):
        q = w.fork()
        q.probe("phase.access_query", 13, 40 + delay)
        q.run_until(42 + delay)
        values.append(q.observe("phase", "access_response").record.s_reg)
    assert values == expected
    print("modo", mode, values)
