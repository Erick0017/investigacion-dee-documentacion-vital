# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

full = d.create_organization("contingent")
full.advance(8)
edit = d.ResearchStateEdit()
edit.coordinate = full.view("body").spec.ports["action"]
edit.raw = 0
edit.label = "corte tardio del producto emitido"
cut = full.diagnostic_fork([edit], True)
full.advance(5); cut.advance(5)
values = [w.observe("body", "environment").record.s_reg for w in (full, cut)]
assert values == [48, 30]
print("con accion / corte", values)
for hidden in (23, 25):
    w = d.create_organization("information", hidden=hidden)
    w.advance(16)
    print("canal contextual", hidden, w.observe("body", "downstream").record.s_reg)
