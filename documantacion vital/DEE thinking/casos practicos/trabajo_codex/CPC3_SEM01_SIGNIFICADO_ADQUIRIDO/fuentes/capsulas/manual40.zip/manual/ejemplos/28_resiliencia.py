# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("distributed")
w.submit("integration.A", 8, 0)
w.submit("integration.B", 9, 0)
w.run_until(700)
assert w.observe("integration", "q").record.s_reg == 19664
assert w.view("history").observe().delta == 1
health = w.view("integration").resilience()
assert "q" in health.ordinary_cap_sites
print("canales con cap", health.ordinary_cap_sites)
print("relacion", w.view("history").observe().delta)
q = w.fork()
q.probe("history.common_query", 7, 700)
q.advance(3)
print("sonda posterior", q.view("history").observe().delta)
