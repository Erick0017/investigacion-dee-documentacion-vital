# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("competition")
w.run_until(5)
before = w.runtime.fork()
w.advance()
site = w.view("encounter").spec.ports["meeting"]
report = d.observe_encounter(before, w.runtime, site)
assert report.after.record.s_reg == 36
assert len(report.direct_ballistic_contributors) == 2
print(report.branch, report.after.record.s_reg, report.attribution_scope)
w.probe("joint_query", 13, 6)
w.run_until(10)
assert w.observe("encounter", "response").record.s_reg == 49
w.run_until(14)
w.probe("later_query", 17, 14)
w.run_until(20)
assert w.observe("encounter", "later_response").record.s_reg == 66
print("producto usado", 49, 66)
