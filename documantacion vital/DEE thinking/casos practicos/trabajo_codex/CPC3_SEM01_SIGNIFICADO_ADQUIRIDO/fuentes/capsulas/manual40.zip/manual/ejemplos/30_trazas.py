# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
from pathlib import Path
import dee_thinking as d

w = d.create_organization("competition")
w.run_until(3)
segment = d.MobileSegment()
segment.id = "A_declarado"
segment.birth_site = w.view("encounter").spec.ports["hubA"]
segment.birth_tick = 3
segment.direction = d.Direction(0, 1, 0)
segment.expected_load = 12
segment.expected_semantic = 1
trace = d.TraceSession(); trace.sample_budget = 16
trace.segments = [segment]
w.set_trace(trace)
w.capture_trace(); w.run_until(10)
trace = w.trace()
assert trace.segments[0].correspondence_stopped
out = Path("resultados_manual"); out.mkdir(exist_ok=True)
trace.export_trace(str(out / "segmento.deetrace"))
restored = d.TraceSession.load_trace(str(out / "segmento.deetrace"))
print([(s.tick, s.coverage) for s in restored.samples])
