# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
import dee_thinking as d

w = d.create_organization("mobile_pair")
a = w.submit("l0.cue", 5, 0)
b = w.submit("l0.cue", 7, 0)
w.advance()
assert w.runtime.receipt(a.id).status == d.EventStatus.REJECTED_CONFLICT
assert w.runtime.receipt(b.id).status == d.EventStatus.REJECTED_CONFLICT
late = w.submit("l0.cue", 5, 0)
assert late.status == d.EventStatus.REJECTED_LATE
print("ambas rechazadas por conflicto; siguiente solicitud tardia")
