# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
from pathlib import Path
import dee_thinking as d

place = d.InitialPlacement()
place.site = d.Coordinate(3, 3, 3)
place.raw = d.pack_record(1, 17, 1, 0, 0, 1)
place.clock = 7
recipe = d.OrganizationRecipe.research(11, [place], 0)
spec = d.OrganizationSpec(); spec.id = "transporte"
spec.ports = {"destino": d.Coordinate(4, 3, 3)}
recipe.organizations = [spec]
w = d.OrganizationalWorld.create(recipe)
w.advance()
assert w.observe("transporte", "destino").record.s_reg == 17
out = Path("resultados_manual"); out.mkdir(exist_ok=True)
w.save_snapshot(str(out / "custom.deetsnap"))
c = d.OrganizationalWorld.load_snapshot(str(out / "custom.deetsnap"))
assert c.runtime.raw_copy() == w.runtime.raw_copy()
print(c.observe("transporte", "destino").record.s_reg)
