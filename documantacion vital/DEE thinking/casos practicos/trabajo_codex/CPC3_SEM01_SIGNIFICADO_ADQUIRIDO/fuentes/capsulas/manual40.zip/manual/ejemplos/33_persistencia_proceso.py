# DEE thinking 4.0.0 - Libro Blanco y Manual Tecnico
from pathlib import Path
import subprocess
import sys
import tempfile
import dee_thinking as d

w = d.create_organization("mobile_pair")
for j, teacher in enumerate((7, 11)):
    w.submit(f"l{j}.cue", 5, 0)
    w.submit(f"l{j}.teacher", teacher, 0)
w.run_until(6)
w.start_mobile_sequence("serie", [13, 7, 17]); w.run_until(13)
with tempfile.TemporaryDirectory(prefix="dee-manual-") as folder:
    first = str(Path(folder) / "mid.deetsnap")
    second = str(Path(folder) / "end.deetsnap")
    w.save_snapshot(first)
    code = ("import dee_thinking as d,sys; "
            "w=d.OrganizationalWorld.load_snapshot(sys.argv[1]); "
            "w.run_until(21); w.save_snapshot(sys.argv[2])")
    subprocess.run([sys.executable, "-I", "-c", code, first, second],
                   cwd=folder, check=True)
    restored = d.OrganizationalWorld.load_snapshot(second)
    w.run_until(21)
    assert restored.runtime.raw_copy() == w.runtime.raw_copy()
    assert restored.runtime.clock_copy() == w.runtime.clock_copy()
    assert restored.protocols[0].next_capture == 3
print("continuidad fisica y protocolo restaurados")
