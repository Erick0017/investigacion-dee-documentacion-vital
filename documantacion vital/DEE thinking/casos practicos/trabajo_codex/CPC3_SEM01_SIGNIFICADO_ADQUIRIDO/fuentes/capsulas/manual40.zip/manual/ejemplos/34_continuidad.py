# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("continuidad",initial_open=False,change_tick=80)
s.sense(); p=s.predict()
assert p["emission_tick"]==37 and p["target_tick"]==67
assert p["prediction_set"]==[False]
s.advance(30)
print(p)
print(s.observe())
