# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("comparacion",initial_open=False,change_tick=80)
s.sense(); p=s.predict(); assert p["target_tick"]==83
s.save_snapshot("expectativa.deetsnap")
r=d.load_session("expectativa.deetsnap",profile="comparacion")
out=r.compare()
assert r.tick==84
assert out["comparison_decoder"]["presentation"]=="discrepancia_direccional"
print(out)
