# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
p=d.FinitePolicyParameters();p.roles=d.SourceRole.Q_INFORMATIVE;p.actual_class=1
s=d.FinitePolicySession.create(p)
print(s.sense().as_dict()); print(s.compare().as_dict()); print(s.source().as_dict())
assert s.tick==11
s.save_snapshot("policy_t11.deetsnap")
r=d.FinitePolicySession.load_snapshot("policy_t11.deetsnap")
print(r.sense().as_dict()); assert r.tick==14
