# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
p=d.NativeInformationParameters();p.seed_path=d.reference_seed_path()
p.history=d.BasalHistory.BA;p.context=0;p.actual_class=1
s=d.NativeInformationSession.create(p)
s.run_until(43);s.process_boundary();s.save_snapshot("information_pending.deetsnap")
r=d.NativeInformationSession.load_snapshot("information_pending.deetsnap")
assert r.tick==43
print(r.run_until(56).as_dict());print(r.run_until(64).as_dict())
