# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
for refs,expected in [([7,11],{"q0":25,"q1":29}),([11,7],{"q0":29,"q1":25})]:
 s=d.create_session("relaciones");s.train(refs,cue=5);out=s.query(13)
 assert out["decoded"]==expected
 print(out)
