# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("relaciones");s.train([7,11],cue=5)
r=s.query_sequence([13,7,17])
values=[[o["s_reg"] for o in step["captured"]] for step in r["steps"]]
assert values==[[25,29],[32,36],[49,53]]
print(values)
