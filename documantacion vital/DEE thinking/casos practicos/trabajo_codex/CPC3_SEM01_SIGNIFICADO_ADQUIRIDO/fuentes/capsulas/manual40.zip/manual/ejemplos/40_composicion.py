# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("composicion",depth=2);s.train_all([(3,18),(3,24)])
s.save_snapshot("cascade_t6.deetsnap")
r=d.load_session("cascade_t6.deetsnap",profile="composicion")
out=r.query(23)
assert out["decoded"]=={"stage0":44,"stage1":71}
print(out)
