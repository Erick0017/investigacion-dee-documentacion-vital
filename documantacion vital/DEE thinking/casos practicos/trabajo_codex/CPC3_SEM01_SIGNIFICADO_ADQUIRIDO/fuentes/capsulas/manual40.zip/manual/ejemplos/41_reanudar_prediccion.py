# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("continuidad",initial_open=False);s.sense();p=s.predict()
s.save_snapshot("pregunta_pendiente.deetsnap")
r=d.load_session("pregunta_pendiente.deetsnap",profile="continuidad")
assert r.tick==s.tick==37
for t in (67,100):
 s.run_until(t);r.run_until(t)
 assert s.world.runtime.raw_copy()==r.world.runtime.raw_copy()
 assert s.world.runtime.clock_copy()==r.world.runtime.clock_copy()
print(r.observe())
