# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
s=d.create_session("relaciones");s.train([7,11],cue=5)
before=(s.world.runtime.raw_copy(),s.world.runtime.clock_copy())
s.set_interface_metadata({"nombre_externo":"brisa"})
assert before==(s.world.runtime.raw_copy(),s.world.runtime.clock_copy())
s.save_snapshot("alias.deetsnap")
r=d.load_session("alias.deetsnap",profile="relaciones")
assert r.interface_metadata["nombre_externo"]=="brisa"
assert r.query(13)["decoded"]=={"q0":25,"q1":29}
print(r.interface_metadata)
