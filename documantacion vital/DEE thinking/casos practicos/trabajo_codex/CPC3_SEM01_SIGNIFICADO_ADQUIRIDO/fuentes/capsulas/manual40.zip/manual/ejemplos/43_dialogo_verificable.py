# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
from dee_thinking.dialogue import ConversationSession
s=ConversationSession("composicion",directory="sesion_dialogo")
for text in ["Instancia nueva","Ensena dos relaciones 3,18 y 3,24","A esto lo llamaremos cascada","Guarda la sesion","Carga la sesion","Consulta nueva 23"]:
 frame=s.execute(text)
 print(text,frame)
assert s.session.tick>6
