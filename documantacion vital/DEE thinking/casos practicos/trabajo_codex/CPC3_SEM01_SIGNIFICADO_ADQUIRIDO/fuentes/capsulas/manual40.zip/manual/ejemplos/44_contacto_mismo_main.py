# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import dee_thinking as d
resources=[((17,22,25),12,(1,0,0)),((22,17,25),24,(0,1,0)),((33,25,25),5,(-1,0,0))]
placements=[]
for q,load,direction in resources:
 p=d.InitialPlacement();p.site=d.Coordinate(*q);p.clock=0
 p.raw=d.pack_record(1,load,*direction,1);p.role="reference_resource";placements.append(p)
recipe=d.OrganizationRecipe.research(47,placements,0)
recipe.execution=d.TickOptions(d.Backend.LAZY,1)
interfaces=[]
for j,q in enumerate(((30,33,25),(25,38,25)),1):
 i=d.InterfaceSpec();i.name="world.query"+str(j)
 c=d.ChannelSpec();c.name=i.name;c.injection_site=d.Coordinate(*q)
 c.direction=d.Direction(-1,0,0);c.allow_experience=False;c.allow_probe=True
 i.channel=c;interfaces.append(i)
recipe.interfaces=interfaces;w=d.OrganizationalWorld.create(recipe)
w.run_until(5);assert w.runtime.observe(d.Coordinate(22,22,25)).record.s_reg==36
w.run_until(8);assert w.runtime.observe(d.Coordinate(25,25,25)).record.s_reg==41
w.run_until(11);r1=w.probe("world.query1",13,11);w.run_until(16)
a=w.runtime.observe(d.Coordinate(25,33,25));assert a.record.s_reg==54
r2=w.probe("world.query2",19,16);w.run_until(21)
b=w.runtime.observe(d.Coordinate(20,38,25));assert b.record.s_reg==73
assert w.runtime.receipt(r1.id).status==d.EventStatus.APPLIED
assert w.runtime.receipt(r2.id).status==d.EventStatus.APPLIED
print("MAIN",w.runtime.dimension,w.runtime.current_tick,a.record.s_reg,b.record.s_reg)
