# DEE thinking 4.0.0 - ejemplo editorial del Libro Blanco
# Los asserts verifican referencias; no deciden la dinamica.
import os,json
from pathlib import Path
root=Path(os.environ["DEE_PRODUCT_ROOT"])
p=root/"experiments"/"BLOCK_II"/"RESULTS.json"
data=json.loads(p.read_text(encoding="utf-8-sig"))
print("SOURCE",p)
print("Analisis de resultados guardados; no nueva trayectoria fisica")
print(json.dumps(data,ensure_ascii=False,indent=2))
