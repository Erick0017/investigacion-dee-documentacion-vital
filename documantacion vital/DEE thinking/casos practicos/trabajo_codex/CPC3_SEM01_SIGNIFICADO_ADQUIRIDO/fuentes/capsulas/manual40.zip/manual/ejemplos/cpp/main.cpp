#include <dee_thinking/cognitive.hpp>
#include <iostream>
#include <stdexcept>
int main(int argc,char**argv){
 try {
  if(argc!=2)throw std::invalid_argument("usage: dee_manual40 seed.deetsnap");
  using namespace dee::thinking;
  CognitiveParameters p;p.seed_path=argv[1];p.initial_open=false;
  auto s=CognitiveSession::create(p);auto a=s.sense();auto f=s.predict();
  if(s.tick()!=37 || !f.prediction)throw std::runtime_error("forecast reference failed");
  s.save_snapshot("cpp_session.deetsnap");
  auto r=CognitiveSession::load_snapshot("cpp_session.deetsnap");
  auto later=r.advance(30);
  auto rel=NativeAssociationSession::create();auto acquired=rel.train({7,11});auto q=rel.query_panel(13);
  if(q.decoded.at("q0")!=25 || q.decoded.at("q1")!=29)throw std::runtime_error("association reference failed");
  auto w=create_learnable_cascade(2);auto rs=experience_composition(w,{{3,18},{3,24}});auto c=query_composition(w,23);
  if(c.decoded.at("stage0")!=44 || c.decoded.at("stage1")!=71)throw std::runtime_error("cascade reference failed");
  std::cout<<"continuation="<<r.tick()<<" association=25/29 composition=44/71\n";
  return 0;
 }catch(const std::exception&e){std::cerr<<e.what()<<"\n";return 1;}
}
