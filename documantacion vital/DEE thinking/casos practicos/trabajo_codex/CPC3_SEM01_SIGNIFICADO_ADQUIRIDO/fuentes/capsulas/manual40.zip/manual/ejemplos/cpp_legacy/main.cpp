#include <dee_thinking/organizational.hpp>
#include <filesystem>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>
namespace dt = dee::thinking;
static void check(bool value, const char* message) {
    if (!value) throw std::runtime_error(message);
}
int main(int argc, char** argv) {
    try {
        if (argc < 3) {
            std::cerr << "Uso: dee_manual35 RUTA_SEMILLA DIRECTORIO_SALIDA [completo]\n";
            return 2;
        }
        const std::string seed=argv[1];
        const std::filesystem::path out=argv[2];
        std::filesystem::create_directories(out);
        auto w=dt::OrganizationalWorld::create(dt::OrganizationRecipe::mobile_pair());
        for(int j=0;j<2;++j) {
            const auto id="l"+std::to_string(j);
            w.submit(id+".cue",5,0); w.submit(id+".teacher",j?11:7,0);
        }
        w.run_until(6);
        auto independent=w.fork();
        independent.probe("q0.query",13,6); independent.probe("q1.query",13,6);
        independent.run_until(11);
        check(independent.observe("q0","response").record.s_reg==25,"independent q0");
        check(independent.observe("q1","response").record.s_reg==29,"independent q1");
        w.start_mobile_sequence("serie",{13,7,17}); w.run_until(13);
        w.save_snapshot((out/"serie.deetsnap").string());
        auto resumed=dt::OrganizationalWorld::load_snapshot((out/"serie.deetsnap").string());
        resumed.run_until(21); w.run_until(21);
        check(w.runtime().raw_copy()==resumed.runtime().raw_copy(),"restored RAW");
        check(w.runtime().clock_copy()==resumed.runtime().clock_copy(),"restored clocks");
        const std::vector<std::vector<int>> expected{{25,29},{32,36},{49,53}};
        for(std::size_t k=0;k<expected.size();++k) {
            const auto& step=resumed.protocols().front().steps[k];
            for(std::size_t j=0;j<2;++j) check(step.captured[j].record.s_reg==expected[k][j],"sequence response");
            std::cout<<"secuencia "<<step.captured[0].record.s_reg<<" "<<step.captured[1].record.s_reg<<"\n";
        }
        auto symbol=w.fork();
        dt::InputCodec codec; codec.type=dt::CodecType::Enumeration; codec.symbols={{"Sensor_Activo",13}};
        check(codec.encode_symbol("Sensor_Activo")==13,"codec");
        auto bridge=dt::OrganizationalWorld::create(dt::OrganizationRecipe::mobile_basal(seed));
        dt::TraceSession trace;trace.sample_budget=64;trace.sites={{"lector",*bridge.view("body").spec().comparator}};
        bridge.set_trace(trace); bridge.advance(6);
        check(bridge.view("body").observe().delta==1,"bridge delta");
        check(bridge.observe("body","comparator").record.s_reg==12,"bridge comparator");
        auto probe=bridge.fork();probe.probe("body.common_query",7,probe.runtime().current_tick());probe.advance(3);
        check(probe.observe("body","comparator").record.dx==-1,"bridge probe");
        bridge.trace().export_trace((out/"bridge.deetrace").string());
        std::cout<<"puente 1 12 -1\n";
        auto source=dt::OrganizationalWorld::create(dt::OrganizationRecipe::relational(seed));source.advance(3);
        auto target=dt::OrganizationalWorld::create(dt::OrganizationRecipe::relational(seed,dt::basal::History::H0));target.advance(3);
        dt::ReconstructionSpec rs; rs.source_sites={*source.view("body").spec().a,*source.view("body").spec().b};
        rs.destination_sites={*target.view("body").spec().a,*target.view("body").spec().b};rs.authorize_assisted_reconstruction=true;
        auto rebuilt=target.assisted_reconstruction(source,rs);
        check(target.view("body").observe().delta==0,"original target");
        check(rebuilt.view("body").observe().delta==1,"rebuilt delta");
        std::cout<<"reconstruccion asistida 0 1\n";
        auto transfer=dt::OrganizationalWorld::create(dt::OrganizationRecipe::native_transfer());
        transfer.probe("query",0,6);transfer.probe("receiver_query",13,16);transfer.run_until(21);
        check(transfer.observe("stage0","receiver_response").record.s_reg==25,"native transfer");
        auto cascade=dt::OrganizationalWorld::create(dt::OrganizationRecipe::cascade(4));
        cascade.probe("query",13,6);cascade.run_until(26);
        check(cascade.observe("stage3","response").record.s_reg==73,"cascade");
        std::cout<<"transferencia 25; cascada4 73\n";
        for(int mode=0;mode<3;++mode) {
            auto phase=dt::OrganizationalWorld::create(dt::OrganizationRecipe::phase(mode));phase.run_until(40);
            const int expected_phase[3][2]={{32,0},{0,32},{0,54}};
            for(int delay=0;delay<2;++delay) {
                auto p=phase.fork();p.probe("phase.access_query",13,40+delay);p.run_until(42+delay);
                auto value=p.observe("phase","access_response").record.s_reg;
                check(value==expected_phase[mode][delay],"phase access");
                std::cout<<"fase "<<mode<<" "<<delay<<" "<<value<<"\n";
            }
        }
        auto full=dt::OrganizationalWorld::create(dt::OrganizationRecipe::contingent(seed));full.advance(8);
        dt::ResearchStateEdit cut;cut.coordinate=full.view("body").spec().ports.at("action");cut.raw=0;cut.label="late cut";
        auto missing=full.diagnostic_fork({cut},true);full.advance(5);missing.advance(5);
        check(full.observe("body","environment").record.s_reg==48,"action");
        check(missing.observe("body","environment").record.s_reg==30,"action cut");
        auto joint=dt::OrganizationalWorld::create(dt::OrganizationRecipe::competition());joint.run_until(5);
        auto before=joint.runtime().fork();joint.advance();
        auto encounter=dt::observe_encounter(before,joint.runtime(),joint.view("encounter").spec().ports.at("meeting"));
        check(encounter.after.record.s_reg==36,"encounter");check(encounter.direct_ballistic_contributors.size()==2,"contributors");
        joint.probe("joint_query",13,6);joint.run_until(10);
        check(joint.observe("encounter","response").record.s_reg==49,"joint use");
        joint.run_until(14);joint.probe("later_query",17,14);joint.run_until(20);
        check(joint.observe("encounter","later_response").record.s_reg==66,"later joint");
        std::cout<<"accion 48/30; encuentro 36/49/66\n";
        if(argc>3 && std::string(argv[3])=="completo") {
            auto dist=dt::OrganizationalWorld::create(dt::OrganizationRecipe::distributed());
            dist.submit("integration.A",8,0);dist.submit("integration.B",9,0);dist.run_until(700);
            check(dist.observe("integration","q").record.s_reg==19664,"cap");
            check(dist.view("history").observe().delta==1,"retained delta");
            std::cout<<"distribuido 19664 delta1\n";
        }
        std::cout<<"MANUAL35_CPP_OK\n";return 0;
    } catch(const std::exception& e) {std::cerr<<e.what()<<"\n";return 1;}
}
