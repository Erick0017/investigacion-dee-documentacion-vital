"""Run the documented examples in isolated work folders; never infer cognition."""
from __future__ import annotations
import argparse
import os
import json
from pathlib import Path
import subprocess
import sys
import time

QUICK = {1,2,3,4,10,11,12,13,14,15,16,18,19,20,22,23,25,26,27,29,30,31,32}

def main() -> int:
    p=argparse.ArgumentParser()
    p.add_argument('--group',choices=['inicio','heredados','sesiones','todos'],default='inicio')
    p.add_argument('--select',help='Comma-separated example numbers')
    p.add_argument('--timeout',type=int,default=300)
    p.add_argument('--output',type=Path,default=Path('salida_manual'))
    p.add_argument('--producto',type=Path,help='Raiz extraida del producto 4.0 para ejemplos45/46')
    a=p.parse_args()
    if a.producto: os.environ['DEE_PRODUCT_ROOT']=str(a.producto.resolve())
    if a.timeout<=0: p.error('--timeout must be positive')
    root=Path(__file__).resolve().parents[1]
    wanted={int(x) for x in a.select.split(',')} if a.select else ({'inicio':{1,2,18,34,35,38,40,44},'heredados':set(range(1,34)),'sesiones':set(range(34,45)),'todos':set(range(1,47))}[a.group])
    examples=[s for s in sorted((root/'ejemplos').glob('[0-9][0-9]_*.py')) if int(s.name[:2]) in wanted]
    if len(examples)!=len(wanted): p.error('An example number is unavailable')
    a.output=a.output.resolve();a.output.mkdir(parents=True,exist_ok=True)
    report=[]
    for s in examples:
        folder=a.output/s.stem;folder.mkdir(exist_ok=True)
        started=time.monotonic()
        try:
            r=subprocess.run([sys.executable,'-I','-B',str(s)],cwd=folder,capture_output=True,text=True,timeout=a.timeout)
            status='PASS' if r.returncode==0 else 'FAIL';code=r.returncode;stdout=r.stdout;stderr=r.stderr
        except subprocess.TimeoutExpired as e:
            status='TIMEOUT';code=None
            stdout=e.stdout.decode(errors='replace') if isinstance(e.stdout,bytes) else (e.stdout or '')
            stderr=e.stderr.decode(errors='replace') if isinstance(e.stderr,bytes) else (e.stderr or '')
        (folder/'stdout.txt').write_text(stdout,encoding='utf-8')
        (folder/'stderr.txt').write_text(stderr,encoding='utf-8')
        report.append({'example':s.name,'status':status,'exit_code':code,'seconds':round(time.monotonic()-started,3)})
        (a.output/'RESULTADOS_EJEMPLOS.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
        print(s.name,status,flush=True)
    return 0 if all(x['status']=='PASS' for x in report) else 1
if __name__=='__main__': raise SystemExit(main())
