"""Recover the manual capsule or its full backup, without executing its contents."""
from __future__ import annotations
import argparse, hashlib, io, json, shutil, stat, zipfile
from pathlib import Path, PurePosixPath

MAX_BYTES = 3 * 1024**3
MAX_FILES = 6000

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def extract_checked(z: zipfile.ZipFile, dest: Path, manifest: str) -> dict:
    if dest.exists() and any(dest.iterdir()):
        raise ValueError("Use an empty destination; existing data will not be overwritten")
    infos = z.infolist()
    if len(infos) > MAX_FILES or sum(i.file_size for i in infos) > MAX_BYTES:
        raise ValueError("Archive exceeds the documented extraction budget")
    data = json.loads(z.read(manifest).decode("utf-8"))
    expected = {r["path"]: r for r in data["files"]}
    actual = {i.filename for i in infos if not i.is_dir()}
    if actual != set(expected) | {manifest}:
        raise ValueError("Manifest inventory does not match archive")
    seen = set()
    for info in infos:
        name = info.filename
        rel = PurePosixPath(name)
        if name in seen or "\\" in name or rel.is_absolute() or ".." in rel.parts or ":" in name:
            raise ValueError("Unsafe or duplicate archive path: " + name)
        if stat.S_ISLNK(info.external_attr >> 16):
            raise ValueError("Symbolic links are not extracted")
        seen.add(name)
        if info.is_dir():
            continue
        raw = z.read(name)
        if name != manifest:
            row = expected[name]
            if len(raw) != row["size"] or digest(raw) != row["sha256"]:
                raise ValueError("Integrity error: " + name)
    dest.mkdir(parents=True, exist_ok=True)
    # Write only after all paths and hashes have passed.
    for info in infos:
        if info.is_dir():
            continue
        target = dest.joinpath(*PurePosixPath(info.filename).parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        with z.open(info) as source, target.open("wb") as output:
            shutil.copyfileobj(source, output, 1024 * 1024)
    return {"verified_files":len(expected),"destination":str(dest.resolve()),"manifest":manifest}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument("--backup",type=Path)
    src.add_argument("--docx",type=Path)
    parser.add_argument("--dest",type=Path,required=True)
    args=parser.parse_args()
    if args.backup:
        with zipfile.ZipFile(args.backup) as z:
            result=extract_checked(z,args.dest,"BACKUP_MANIFEST.json")
    else:
        with zipfile.ZipFile(args.docx) as doc:
            capsule=doc.read("dee_payload/manual40.zip")
        with zipfile.ZipFile(io.BytesIO(capsule)) as z:
            result=extract_checked(z,args.dest,"CAPSULE_MANIFEST.json")
    print(json.dumps(result,indent=2))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
