"""Verify a recovered manual backup/capsule without running its software."""
from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path, PurePosixPath

def sha(path: Path) -> str:
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""):
            h.update(b)
    return h.hexdigest()

def main() -> int:
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--root",type=Path,required=True)
    a=p.parse_args();root=a.root.resolve()
    candidates=[root/"BACKUP_MANIFEST.json",root/"CAPSULE_MANIFEST.json"]
    manifest=next((x for x in candidates if x.is_file()),None)
    if manifest is None:raise FileNotFoundError("No manifest at the requested root")
    data=json.loads(manifest.read_text(encoding="utf-8"))
    for row in data["files"]:
        rel=PurePosixPath(row["path"])
        if rel.is_absolute() or ".." in rel.parts or "\\" in row["path"]:
            raise ValueError("Unsafe member path")
        target=root.joinpath(*rel.parts)
        if target.is_symlink() or root not in target.resolve().parents:
            raise ValueError("Member escapes the verification root")
        if not target.is_file() or target.stat().st_size!=row["size"] or sha(target)!=row["sha256"]:
            raise ValueError("Member mismatch: "+row["path"])
    print(json.dumps({"manifest":manifest.name,"verified_files":len(data["files"]),"status":"PASS"},indent=2))
    return 0
if __name__=="__main__":raise SystemExit(main())
