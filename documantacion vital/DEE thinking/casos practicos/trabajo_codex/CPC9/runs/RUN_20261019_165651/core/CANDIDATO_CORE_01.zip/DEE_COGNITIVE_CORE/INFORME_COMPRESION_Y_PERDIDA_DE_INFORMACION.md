# Compresión y pérdida de información

Los ZIP CPC3–CPC7 examinados suman 125,442,378 bytes comprimidos y 25,497,667,043 bytes expandidos. CPC1/2 están dentro de la genealogía CPC3.
Se conservan 7,140 nombres lógicos en 3,268 blobs únicos. Los bytes seleccionados suman 1,264,432,097; tras deduplicar, 1,228,865,226. El almacén gzip ocupa 69,674,157 bytes.

## Conservado

Código y variantes ejecutadas, configuraciones y parámetros, identidad del instrumento, catálogo NSM de origen, telemetría terminal original con controles/errores/reservas, fuentes de las47filas históricas, pruebas actuales y once semillas/checkpoints MBP4 indispensables. Los miembros se recuperan por sus nombres y hashes exactos. No hay ZIP antiguos completos anidados.

## Excluido

Entornos, toolchains, vídeos, gráficos repetidos, logs repetidos, mayor parte de snapshots densos y temporales. En CPC3–CPC7 los snapshots `.deetsnap` no seleccionados representan 24,230,806,827 bytes. Las variantes únicas de código ejecutado sí se conservan por hash.

## Consecuencias

La reproducción ejecuta las trayectorias de los contratos seleccionados y vuelve a generar estados/observaciones. El estado físico y los campos primarios se comparan con referencias inmutables. No se afirma regeneración byte-exacta de todos los contenedores: versiones, rutas, identificadores documentales y nombres de intentos pueden diferir sin cambiar RAW/clocks.

Los snapshots históricos no seleccionados de dominios no reproducidos NO se declaran recuperables. Su trayectoria fina no puede revisarse desde este Core sin el archivo original. Su código y evidencia terminal permanecen. La matriz deja esas capacidades pendientes y no las llama sustituidas operativamente. No se autoriza borrar los originales.

El tamaño del ZIP final, su tamaño expandido real y el hash exacto se informan fuera del ZIP. Los bytes lógicos materializados del almacén no deben confundirse con el tamaño expandido del contenedor.
