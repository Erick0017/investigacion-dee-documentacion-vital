# Matriz de capacidades recuperadas

Las clasificaciones son filas de procedencia, no conceptos ni réplicas. La prueba limpia determina la sustitución operativa. Ninguna fila se integra automáticamente en E1 de CPC9.

| ID | Estado | Dominio y alcance actual |
|---|---|---|
| CP01_C01 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C02 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C03 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C04 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C05 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C06 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C07 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP01_C08 | C | Original source/inputs/positivecontrols/reserves reproduced onofficial4.5, neutralmeasurements and fullphysicalcheckpointdigests exact. CP01C07isderiveddiagnosisusingreproducedC05notanindependentnativepreparation. |
| CP02_B | B | Original predictor implementation on six newly prepared reserved-geometry paired/omitted/unpaired cases with prospectiveforecast and exactrestore; not the original maternalMAINtrajectory. |
| CPC3_MAIN_AND_COMPARISON | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC3_POLICY | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| SEM01 | C | Siete realizaciones originales: historias opuestas, ausencia, desacoplamiento, acción omitida y dos reservas. Estado inicial/final, enseñanza y uso exactos. Los repr del host no son estado físico. |
| CPC4_AB | C | Cuatro realizaciones originales de la red A/B/C/D: filtro, ausencia, mismo aporte fuera de ruta y reserva. No se incorpora toda variante histórica de comunicación. |
| CPC4_REGULATION_ABCD | C | Contraflujo fijo preparado en aparato original N67; utilidad5 frente a4, sham4 y reserva5. No estrategia reguladora aprendida. |
| CPC5_COMPOUND | C | Siete realizaciones originales con reutilización y respaldos adquiridos: desacoplado, historia opuesta, no emparejado, corte/sham y reserva. La carga no mide profundidad conceptual. |
| CPC5_CAPACITY65 | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC5_LONGITUDINAL65 | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC5_ORDER_AND_DIALOGUE | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC6_INTEGRATED | C | Cuatro vidas originales N67 T0–170, historia/comparación/acción/retorno/asociaciones y lector remoto. Rutas preparadas, no política general. |
| CPC6_TWO_FORMS | C | Cuatro protocolos word-bus originales con relación adicional y reexpresión tardía; controles no-repeat, nombre no emparejado e historia invertida. |
| CPC6_RETENTION_CAUSAL | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC6_ARCHITECTURES | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CORE06_RELEARNING | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CORE07_REPROGRAMMING | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| ING01_R04_R14 | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| ING02_RELATIVE | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| ING05_06_CONTEXT | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PROCESOS_OBSERVERS | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PROCESAMIENTO_NATIVO | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| FISICA_META_ROSETTA | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PRODUCT4_CONTRACT | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC7_U0_CONTINUITY | C | Four originalCPC7 finite0→472 contracts reproduced, fullbase338/final472state and receipts match. DoesnotintegrateentirehistoricalfamilyintoCPC9E1. |
| CPC7_SELECTIVE_REVISION_M1_M2 | C | Four originalCPC7 finite0→472 contracts reproduced, fullbase338/final472state and receipts match. DoesnotintegrateentirehistoricalfamilyintoCPC9E1. |
| CPC7_PREPARED_DISCREPANCY_REQUEST | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC7_ABSENCE_APERTURE | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC7_DIRECTIONAL_COMPOSITION_AND_POST_NAME | C | Four originalCPC7 finite0→472 contracts reproduced, fullbase338/final472state and receipts match. DoesnotintegrateentirehistoricalfamilyintoCPC9E1. |
| CPC7_NSM65_SCOPE | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PRODUCT45_PORT_VALIDATION | C | 68 regresiones técnicas de la API oficial. Se distinguen de los casos científicos originales y sus observaciones. |
| CORE15_OBSERVER_SHADOW | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CORE16_OBSERVER_INFORMATION | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CORE17_COMPRESSED_OPERATOR_AND_REPAIR | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| ING05_HISTORY_FACTORIAL | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| ING06_POST_HOST_OPPORTUNITIES | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PROC02_PREEXISTING_INTERFACE | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| PROC03_EXCHANGE_DISCOVERY | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| MBP4_CONTEXTUAL_REWRITE | C | 14 regresiones Basal/MBP4. Semillas/checkpoints históricos indispensables incluidos. Continuaciones y controles locales, no nuevo E1 entrenado. |
| FISICA_UNI1_LATER_REDUCTION | D | Historical source/evidence preserved. The complete historical domain is not newly reproduced by presence in the product or by another apparatus. |
| CPC8_MAIN_ORDER_CONTACT | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_MAIN_QUANTITY_UPDATE | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_CONTACT_SOCIAL | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_MAGNITUDE_SOCIAL | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_K65_PUBLISHED | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_RCA_REGULATION | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_COUNT_SIGN | C | Originalsource/nativeframes/receipts/finalstate reproduced |
| CPC8_QFM_MOVING_FORM | D | Source,configurationandprimaryterminalrecords preservedbycontenthash; currentcleanreproductionnotyetcomplete |
| CPC8_L15_DIAGNOSIS | D | Source,configurationandprimaryterminalrecords preservedbycontenthash; currentcleanreproductionnotyetcomplete |
