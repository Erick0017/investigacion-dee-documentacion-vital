# DEE Cognitive Core CPC01–CPC08

Paquete privado de recuperación sobre DEE thinking 4.5.0 oficial y v27 congelado. Contiene el instrumento, las implementaciones recuperadas, sus configuraciones, fuentes genealógicas y evidencia primaria seleccionada. No contiene ZIP históricos completos ni cambia el producto.

Hay dos alcances distintos:

1. Preservación por identidad de bytes. El índice registra los miembros originales, sus hashes y la implementación recuperada. La matriz distingue lo documentado de lo ejecutado nuevamente.
2. Recuperación operativa comprobada. Únicamente los contratos que superen `PRUEBA_RECUPERACION_DESDE_CERO.json` pueden considerarse sustituidos operativamente por este paquete. Los resultados auxiliares no se suman como conocimientos de un E1.

## Recuperación desde una extracción limpia

Requiere Windows x64 con CPython 3.13 x64 disponible. No requiere los ZIP ni las carpetas CPC anteriores. En una carpeta nueva, extraiga este ZIP y ejecute con ese intérprete:

```text
python -I -B DEE_COGNITIVE_CORE/reproduccion/desde_cero.py --artifact DEE_COGNITIVE_CORE_CPC01_A_CPC08.zip --out RECUPERACION_NUEVA
```

El ejecutor crea un entorno independiente, comprueba que el instrumento no está instalado, instala el único WHL local sin red, materializa sólo los archivos requeridos y ejecuta los contratos. Los archivos de resultados, entornos y estados nuevos se escriben fuera del paquete. El informe externo identifica el ZIP exacto.

Para recuperar únicamente miembros archivados sin ejecutar nada:

```text
python -I -B DEE_COGNITIVE_CORE/scripts/materializar.py --out FUENTES_RECUPERADAS --prefix historico/CPC3/genealogia/CP01_C08/
```

Sin `--prefix` se recuperan todos los miembros indexados, con un coste de disco mayor que el tamaño comprimido. Se verifican todos los blobs del almacén incluso cuando sólo se materializa un subconjunto.

## Qué se ejecuta

El panel incluye los casos originales CP01 C01–C08, predicción prospectiva CP02, SEM01, red A/B/C/D con contraflujo, compuesto con respaldos adquiridos, dos formas y lector renovado CPC6, U0 CPC7, la vida MCTS CPC8, K65, regulación causal RCA y adquisición auxiliar B-only. Incluye controles, historias opuestas, realizaciones reservadas históricas, consultas que también enseñan y restauraciones. Estas repeticiones son reproducciones técnicas de contratos conocidos, no nuevas muestras independientes ni nuevas reservas de descubrimiento.

Las regresiones de API se distinguen de los ensayos científicos. La información detallada está en `documentacion/MATRIZ_CAPACIDADES.json` y en los informes de `verificaciones/`.

## Límites que se conservan

- K65 acredita correspondencias físicas de formas, no 65 significados NSM. En el control no emparejado las consultas posteriores producen adquisiciones: 32/65, 65/65 y 65/65. El control de revisión fuera de ruta conserva 63/64 relaciones no revisadas, no 64/64.
- El aparato N131 K65 no se fusiona documentalmente con U0/MCTS N67.
- Las reglas de comparación, oportunidades de consulta y rutas de regulación están preparadas. La regulación RCA tiene dependencia causal de consecuencias físicas, pero no demuestra una política general que aprenda qué estrategia conviene.
- El resultado ONE B-only depende de unidades materiales y umbral calibrados. No prueba cardinalidad general, un vocabulario conjunto ONE/TWO ni pertenencia al E1 de CPC9.
- Los campos RAW/clocks y sus hashes se conservan sin conversión a floats. Las direcciones de memoria del host y los nombres de archivos de intentos no son estado físico DEE.
- Las entradas del inventario que no pasen la recuperación limpia conservan su código/evidencia, pero no reciben una afirmación de autosuficiencia operativa.

El almacén contiene también variantes históricas de código, incluidas herramientas de mantenimiento y comparadores antiguos. Son genealogía inerte. El ejecutor sólo utiliza una lista explícita de familias. No ejecute limpiadores históricos ni interprete su presencia como parte de CPC9.

No se declara conciencia, inteligencia general, dominio lingüístico humano ni superioridad universal.
