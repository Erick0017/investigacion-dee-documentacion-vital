"""Install and recover from THIS closed artifact, never from historical ZIPs.

Only external dependency: an available CPython3.13 x64 on Windows plus its OS
runtime libraries. All recovery outputs/environment are outside the artifact.
No arbitrary deserialization, downloads, historical launchers or cleanup.
"""
from pathlib import Path,PurePosixPath
from datetime import datetime,timezone
import argparse,hashlib,json,os,subprocess,sys,time,zipfile
ROOT=Path(__file__).resolve().parents[1]
FAMILIES=('cpc1','cpc2','sem01','cpc4','cpc5','cpc6','cpc7','mcts','repertoire','rca','count','product','product_extra')
PREFIXES=('historico/CPC3/genealogia/CP01_C08/','historico/CPC3/genealogia/CP02_B/','historico/CPC3/experimentos/SEM01_SIGNIFICADO_ADQUIRIDO/src/','historico/CPC3/experimentos/SEM01_SIGNIFICADO_ADQUIRIDO/resultados/confirmacion/','historico/CPC4/ampliaciones/02_APRENDIZAJE_CONTINUO_RED_ABCD/src/','historico/CPC4/ampliaciones/02_APRENDIZAJE_CONTINUO_RED_ABCD/resultados/red/fixed_counterflow01/','historico/CPC5/src/','historico/CPC5/configuraciones/compound','historico/CPC5/resultados/compound_reuse','historico/CPC6/src/','historico/CPC6/configuraciones/R03_WORD_BUS_V2','historico/CPC6/resultados/R03_WORD_BUS_V2/','cpc8/src/','cpc8/configuraciones/','cpc8/base_validada/','cpc8/genealogia/CPC7/','cpc8/resultados/transferencia_magnitud/','cpc8/resultados/repertorio65_referencia/','cpc8/resultados/regulacion_acoplada/RCAM_R201_FUNCTION_PLUS/','cpc8/resultados/regulacion_acoplada/RCAM_R202_FUNCTION_MINUS/','cpc8/reproduccion/repetir_count_sign.py','cpc8/resultados/semantica/count_sign_final_fixed/','cpc8/resultados/semantica/count_sign_Bonly_confirm/')
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb')as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def put(p,v):Path(p).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def verify(artifact):
 manifest=json.loads((ROOT/'MANIFIESTO.json').read_text(encoding='utf8'));expected={r['path']for r in manifest['files']}|{'MANIFIESTO.json','HASHES.sha256'}
 actual={p.relative_to(ROOT).as_posix()for p in ROOT.rglob('*')if p.is_file()}
 if actual!=expected:raise ValueError('Extracted inventory differs from manifest')
 for row in manifest['files']:
  p=PurePosixPath(row['path'])
  if p.is_absolute()or'..'in p.parts or':'in str(p):raise ValueError('Unsafe manifest path')
  f=ROOT/p
  if f.stat().st_size!=row['bytes']or sha(f)!=row['sha256']:raise ValueError('Manifest hash mismatch: '+str(p))
 if artifact:
  with zipfile.ZipFile(artifact)as z:
   names=z.namelist()
   if len(names)!=len(set(n.casefold()for n in names))or set(names)!={'DEE_COGNITIVE_CORE/'+n for n in expected}:raise ValueError('Archive inventory mismatch')
   if z.testzip():raise ValueError('CRC failure')
   for name in expected:
    if hashlib.sha256(z.read('DEE_COGNITIVE_CORE/'+name)).hexdigest()!=sha(ROOT/name):raise ValueError('Exact archive/extraction bytes differ: '+name)
 return{'passed':True,'files':len(expected),'manifest_sha256':sha(ROOT/'MANIFIESTO.json')}
def main():
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--artifact',type=Path);p.add_argument('--python',type=Path,default=Path(sys.executable));p.add_argument('--families',default=','.join(FAMILIES));p.add_argument('--total-seconds',type=int,default=2700);a=p.parse_args()
 out=a.out.resolve();artifact=a.artifact.resolve()if a.artifact else None
 if out==ROOT or out.is_relative_to(ROOT)or ROOT.is_relative_to(out):raise ValueError('Use new external recovery output')
 out.mkdir(parents=True,exist_ok=False);start=time.monotonic();path=out/'PRUEBA_RECUPERACION_DESDE_CERO.json'
 report={'schema':'DEE_CORE.clean_recovery.v1','status':'RUNNING','started_utc':datetime.now(timezone.utc).isoformat(),'artifact':str(artifact)if artifact else None,'artifact_sha256':sha(artifact)if artifact else None,'artifact_root':str(ROOT),'external_dependencies':['Available CPython3.13 x64 Windows installation and OS C++runtime, no pipindex'],'historical_archives_opened':False,'commands':[],'family_results':{},'total_limit_seconds':a.total_seconds}
 def save():report['elapsed_seconds']=time.monotonic()-start;put(path,report)
 def run(name,argv,timeout=900):
  remaining=a.total_seconds-(time.monotonic()-start)
  if remaining<=0:raise TimeoutError('Recovery total time limit reached')
  row={'name':name,'argv':list(map(str,argv)),'cwd':str(out),'timeout':min(timeout,remaining),'status':'RUNNING'};report['commands'].append(row);save();t=time.monotonic()
  with(out/(name+'.stdout.log')).open('w',encoding='utf8')as stdout,(out/(name+'.stderr.log')).open('w',encoding='utf8')as stderr:
   process=subprocess.Popen(list(map(str,argv)),cwd=out,stdout=stdout,stderr=stderr,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));row['owned_pid']=process.pid
   try:code=process.wait(timeout=min(timeout,remaining))
   except subprocess.TimeoutExpired:process.kill();process.wait();row.update(status='TIMEOUT',owned_worker_waited=True);save();return False
  row.update(status='PASS'if code==0 else'FAIL',exit_code=code,elapsed_seconds=time.monotonic()-t,owned_worker_waited=True);save();return code==0
 try:
  report['integrity_before']=verify(artifact);save()
  if not run('01_create_environment',[a.python,'-I','-B','-m','venv',out/'environment'],180):raise RuntimeError('Environment creation failed')
  python=out/'environment/Scripts/python.exe';wheel=next((ROOT/'runtime').glob('*.whl'))
  if not run('02_absent_before_install',[python,'-I','-B','-c','import importlib.util,sys,struct; assert sys.version_info[:2]==(3,13) and struct.calcsize("P")==8; assert importlib.util.find_spec("dee_thinking") is None; print(sys.executable)'],60):raise RuntimeError('Fresh interpreter identity failed')
  if not run('03_install_local_official_wheel',[python,'-I','-B','-m','pip','--disable-pip-version-check','install','--no-index','--no-deps','--no-cache-dir',wheel],180):raise RuntimeError('Offline installation failed')
  if not run('03b_example',[python,'-I','-B',ROOT/'ejemplos_funcionales/crear_consultar_continuar.py','--out',out/'example'],180):raise RuntimeError('Fresh small example failed')
  command=[python,'-I','-B',ROOT/'scripts/materializar.py','--out',out/'RECUPERADO']
  for prefix in PREFIXES:command+=['--prefix',prefix]
  if not run('04_materialize_exact_sources',command,300):raise RuntimeError('Materialization/hash validation failed')
  families=a.families.split(',')
  if not set(families)<=set(FAMILIES):raise ValueError('Unknown family requested')
  for family in families:
   target=out/('native_'+family);okay=run('05_'+family,[python,'-I','-B',ROOT/'reproduccion/worker_core.py',family,'--materialized',out/'RECUPERADO','--out',target])
   proof=target/'RECOVERY.json';report['family_results'][family]=json.loads(proof.read_text(encoding='utf8'))if proof.exists()else{'status':'PROCESS_FAILED_WITHOUT_RESULT','command_completed':okay};save()
  report['integrity_after']=verify(artifact);report['no_artifact_changes']=report['integrity_after']==report['integrity_before']
  report['all_requested_families_passed']=all(v['status']=='PASS'for v in report['family_results'].values())
  report['blocked_external_reads']=sum(len(v.get('undeclared_read_attempts',[]))for v in report['family_results'].values())
  report['status']='PASS'if artifact and report['all_requested_families_passed']and report['no_artifact_changes']and report['blocked_external_reads']==0 else'PARTIAL_OR_DEVELOPMENT'
 except BaseException as e:
  import traceback;report.update(status='ERROR',error=repr(e),traceback=traceback.format_exc())
 report['finished_utc']=datetime.now(timezone.utc).isoformat();save()
 lines=['# Recuperación desde cero','',f"Estado: {report['status']}",f"ZIP exacto: {report.get('artifact_sha256')}",'','La instalación y las ejecuciones usan únicamente este paquete y CPython3.13x64. No se abren ZIP históricos. El control de acceso es un audit-hook de archivos Python más revisión de rutas y fuentes; no es una caja de seguridad del sistema operativo.','']
 for family,value in report['family_results'].items():lines.append(f"- {family}: {value['status']} ({value.get('elapsed_seconds',0):.3f}s). {value.get('scope','')}")
 lines+=['','PASS califica recuperación de los contratos ejecutados, no atribución de todas las capacidades a un E1 ni nuevos significados NSM. Las capacidades documentales no ejecutadas permanecen fuera de esta afirmación.']
 (out/'PRUEBA_RECUPERACION_DESDE_CERO.md').write_text('\n'.join(lines)+'\n',encoding='utf8');print(json.dumps({'status':report['status'],'artifact_sha256':report.get('artifact_sha256'),'seconds':report['elapsed_seconds']}))
 if report['status']!='PASS':raise SystemExit(1)
if __name__=='__main__':main()
