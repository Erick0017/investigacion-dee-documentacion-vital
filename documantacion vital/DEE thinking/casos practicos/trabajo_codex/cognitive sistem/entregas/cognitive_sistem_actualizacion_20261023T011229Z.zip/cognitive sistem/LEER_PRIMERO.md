# DEE: copia privada para un colaborador

Universe v27 es la dinámica física nativa; thinking 4.5.0 es el motor e instrumental congelado; Cognitive System 1.1 organiza perfiles, experiencias y vidas persistentes sobre ese motor. Esta carpeta es una distribución, no un sistema cognitivo nuevo. El original sigue siendo la fuente principal.

## Comenzar

1. Extraiga **toda** la carpeta en Windows x64, preferiblemente en una ruta corta y ASCII, por ejemplo `C:\DEE\cognitive sistem`. No ejecute dentro del ZIP.
2. En una computadora sin las bibliotecas Microsoft C++ v14, ejecute primero `motor/VC_redist.x64.exe` y siga su instalador oficial (puede solicitar permisos de administrador). El motor depende de `MSVCP140.dll`; no se supone que ya exista en el otro equipo. No se ejecutó este instalador en el sistema original. Después abra `INICIAR.bat`. Se incluye CPython **3.13.11 x64 portátil**: no necesita instalar Python, pip ni compilador. El primer inicio despliega localmente el único WHL oficial incluido. Para Pendulum se incluye un intérprete separado 3.12.14 y sus dependencias; no controla las decisiones DEE.
3. Elija «Catálogo» y después «Abrir copia». Use una identidad nueva, por ejemplo `COLAB_E1_01`. Se restaura un snapshot **completo** y se registra una continuidad importada; no se reconstruye desde T0 ni se copian recuerdos entre vidas.
4. Los cinco ejercicios están en `ejemplos/`. Toda experiencia o consulta material puede transformar la vida. Pruebe sobre una bifurcación y guarde sus resultados en `trabajo_personal/`.

Comandos desde esta carpeta:

```bat
INICIAR.bat catalogo
INICIAR.bat abrir E1_PROTEGIDO COLAB_E1_01
INICIAR.bat gestor estado --vida COLAB_E1_01
INICIAR.bat gestor bifurcar COLAB_E1_01 COLAB_PRUEBA_01
INICIAR.bat gestor guardar --vida COLAB_PRUEBA_01
INICIAR.bat ejemplo 3
```

`gestor` delega en el **mismo gestionar.py** de Cognitive. `INICIAR.bat gestor --help` muestra sus comandos reales. No hay respuestas en lenguaje libre ni una política inteligente en el lanzador. Silencio, rechazo e indeterminación siguen siendo resultados distintos.

## Tarea principal de cierre: servicio contextual CF01

```bat
INICIAR.bat servicio-cf01 MI_CF01_01 --mediciones=20:28,7:13,9:18
INICIAR.bat gestor guardar --vida MI_CF01_01
INICIAR.bat servicio-cf01 MI_CF01_01 --continuar --mediciones=18:25,6:14
```

El primer comando importa el corte completo `CF01_OPERATIVO` con una identidad personal nueva; el siguiente uso exige `--continuar`, sin recrear ni rebobinar. La calibración externa guardada se conserva: 8 en el final MAIN T67723. `CF01_CALIBRACION7` T63813 y `CF01_PLANTILLA_R9` T44263 son pasados alternativos identificados, no recuerdos fusionados del final. Consulte `ejemplos/SERVICIO_CF01.md`, `sistema/documentacion/GUIA_CF01.md` y los primarios en `investigacion/CF01_CIERRE_FUNCIONAL/`.

El alcance es decisión contextual y consecuencias en un dominio material finito, con anatomía y lectura P0 preparadas. El operador presenta oportunidades; DEE produce las transformaciones y direcciones. Los resultados limitados del servicio no acreditan lenguaje general, lector aprendido, R2 general ni control competente de Pendulum.

## Qué está incluido

- Código operativo completo vigente de Cognitive: app, capacidades, contratos, organizaciones, persistencia y reproducción heredada compacta, no sólo un delta MI01/MI02.
- Un WHL oficial 4.5.0, con el kernel v27 incorporado e intacto; dependencias e intérpretes separados por ABI.
- Estados seleccionados íntegros en `entes/`; catálogo con identidad, padre, perfil, tick, capacidades, asistencia y límites. Una vida no sabe todo lo disponible en la biblioteca.
- Manual Maestro vigente en la raíz y copia idéntica en `documentos/`, manuales técnicos y ciencia esencial; fuentes disponibles para estudiar y modificar **experimentos**, sin recompilar el motor.
- Informes cerrados seleccionados e índices en `investigacion/`, sin los cientos de ZIP históricos ni telemetría profunda. Los diarios del auditor no alimentan al participante.

MI02 ya estaba cerrada al preparar esta distribución. Sus perfiles alternativos se incluyen con sus límites, sin sustituir al E1 protegido. No se afirman 65 significados, lenguaje general, control competente de Pendulum ni R2 general.

## Estado personal y actualizaciones

`entes/` conserva cortes de distribución sin modificarlos. Las copias abiertas, nuevos snapshots, colas, protocolos, puente y resultados viven en `trabajo_personal/`. **Ninguna actualización borra ni sobrescribe esa carpeta.** Una actualización del software no rebobina una vida.

En el equipo de investigación, después de cerrar una campaña, ejecute `ACTUALIZAR.bat`. El origen se busca como hermano `DEE Cognitive System 1.1`, no en una unidad absoluta. El programa sólo incorpora cortes cerrados; si hay cambios operativos posteriores al último cierre, se detiene en vez de enviar trabajo a medias. Consulte `actualizaciones/COMO_ACTUALIZAR.md` para registrar un cierre y seleccionar nuevas vidas.

En la computadora del colaborador, sin ese origen, la carpeta **no se sincroniza sola**. Envíe un ZIP nuevo o una actualización incremental, verifique su hash y aplíquela con `ACTUALIZAR.bat --aplicar archivo.zip`. Los cambios personales en archivos operativos se detectan y no se sobrescriben silenciosamente.

`CREAR_ZIP.bat` vuelve a sellar únicamente el corte ya copiado, sin sincronizar campañas ni ejecutar DEE. El ZIP nunca incluye `entregas/` ni sus propios ZIP. `actualizaciones/COMO_ACTUALIZAR.md` explica los respaldos y la conservación de conflictos.

## Alcance y requisitos

Windows x64 compatible con los binarios incluidos. No se promete compatibilidad con ARM ni Linux. Reserve varios GB de disco y RAM; N131 requiere más que los especialistas N17/N26. Los temporales nativos necesitan una ruta ASCII escribible. Las dependencias y licencias están en `motor/DEPENDENCIAS.json` y sus avisos. El instalador C++ incluido procede del [enlace oficial de Microsoft](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist/); el paquete no lo instala silenciosamente. No se utiliza red durante el arranque normal.

La identidad y situación editorial del Word están en `documentos/MANUAL_VIGENTE.json`; empaquetarlo no añade validación visual. Las rutas antiguas que figuran dentro de informes son procedencia histórica, no dependencias de ejecución. Las instrucciones portátiles de esta carpeta prevalecen para el colaborador.

Material privado para una persona de confianza; no es una autorización de publicación pública.
