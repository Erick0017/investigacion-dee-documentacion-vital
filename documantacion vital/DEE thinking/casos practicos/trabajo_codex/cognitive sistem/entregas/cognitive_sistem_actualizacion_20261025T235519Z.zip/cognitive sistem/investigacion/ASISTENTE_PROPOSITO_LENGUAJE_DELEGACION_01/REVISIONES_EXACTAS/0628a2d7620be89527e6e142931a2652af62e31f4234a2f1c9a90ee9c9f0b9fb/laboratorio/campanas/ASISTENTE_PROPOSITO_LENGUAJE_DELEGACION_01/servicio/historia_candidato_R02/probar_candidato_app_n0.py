"""Zero-native-tick tests of the proposed APD transport/ownership extension.

The APD and memory objects below are explicit instrumentation fixtures, not DEE
participants. No runtime, physical responses, learning or arithmetic are faked.
"""
import argparse,difflib,hashlib,importlib.util,json,sys,types
from pathlib import Path

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def module(name,p):
    s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--sistema',type=Path,required=True);p.add_argument('--salida',type=Path,required=True);a=p.parse_args();here=Path(__file__).resolve().parent;candidate=here/'candidato_app'
    q=module('apd_transport_fixture',candidate/'cola_local.py');svc=module('apd_service_fixture',candidate/'servicio_persistente.py');checks={}
    base={'operacion':'sesion','situaciones':[{'modo':'apd','texto':'sumar','operandos':[3,8]}]}
    checks['literal_APD_accepted']=q.validate_request(base)=='sesion';checks['literal_not_mutated']=base['situaciones'][0]=={'modo':'apd','texto':'sumar','operandos':[3,8]}
    checks['upper_boundary32_accepted']=q.validate_request({'operacion':'sesion','situaciones':[{'modo':'apd','texto':'sumar','operandos':[32,0]}]})=='sesion'
    malformed=[('empty_form',{'modo':'apd','texto':'','operandos':[1,2]}),('target',{'modo':'apd','texto':'sumar','operandos':[1,2],'target':3}),('route',{'modo':'apd','texto':'sumar','operandos':[1,2],'ruta':'externa'}),('teacher_in_use',{'modo':'apd','texto':'sumar','operandos':[1,2],'senal':1}),('bool_operand',{'modo':'apd','texto':'sumar','operandos':[True,2]}),('negative_operand',{'modo':'apd','texto':'sumar','operandos':[-1,2]}),('overbound_operand',{'modo':'apd','texto':'sumar','operandos':[33,2]}),('wrong_count',{'modo':'apd','texto':'sumar','operandos':[1,2,3]}),('oversize_form',{'modo':'apd','texto':'x'*129,'operandos':[1,2]})]
    for name,row in malformed:
        try:q.validate_request({'operacion':'sesion','situaciones':[row]});checks['reject_'+name]=False
        except ValueError:checks['reject_'+name]=True
    checks['legacy_memory_still_admitted']=q.validate_request({'operacion':'sesion','situaciones':[{'modo':'memoria','contexto':'gamma'}]})=='sesion'
    checks['legacy_scalar_still_admitted']=q.validate_request({'operacion':'sesion','situaciones':[{'modo':'dato','valor':13}]})=='sesion'
    calls=[];package=types.ModuleType('capacidades');apd=types.ModuleType('asistente_proposito_01')
    apd.state=lambda adapter:calls.append(adapter)or{'operational':{'prepared':True}}
    package.asistente_proposito_01=apd;sys.modules['capacidades']=package
    class Memory:
        BASE_TOKENS=['gamma']
        def get(self,adapter):return{'enabled_contexts':['gamma']}
    own={'external_pending':None,'cascade_pending':None,'external_uncertain':None}
    capability=types.SimpleNamespace(ma=Memory(),get=lambda adapter:own)
    w=svc.NativeWorld(a.sistema,'INSTRUMENT_ONLY',backend='mente_unificada');w.a=object();w.capability=capability
    w.validate(base);checks['APD_only_passive_preparation_check']=calls==[w.a]
    first=w.operational_dependencies();checks['old_witness_unchanged_when_no_hook']=first['exact_serialized_external_protocol_sha256']==hashlib.sha256(q.canonical(own).encode('utf8')).hexdigest()
    environment={'prices':[2,7],'delay':3,'available':True,'pending':None,'uncertain':None}
    capability.additional_operational_state=lambda adapter:dict(environment)
    second=w.operational_dependencies();third=w.operational_dependencies();checks['external_environment_exactly_repeatable']=second==third
    environment['prices']=[3,7];fourth=w.operational_dependencies();checks['price_change_is_in_operational_witness']=second['exact_serialized_external_protocol_sha256']!=fourth['exact_serialized_external_protocol_sha256']
    capability.external_uncertainty=lambda adapter:False;checks['explicit_false_uncertainty']=w.external_uncertainty()is False
    capability.external_uncertainty=lambda adapter:True;checks['explicit_true_uncertainty']=w.external_uncertainty()is True
    capability.external_uncertainty=lambda adapter:'unknown'
    try:w.external_uncertainty();checks['reject_nonboolean_uncertainty']=False
    except ValueError:checks['reject_nonboolean_uncertainty']=True
    checks['no_DEE_module_imported']=not any(k=='dee_thinking'or k.startswith('dee_thinking.')for k in sys.modules)
    expected={'cola_local.py':'3495702680e1fe827ca1a7319e05fae69358061a21d1372ff35c50c3ea538627','servicio_persistente.py':'544ccef3c060273cdf2986bf8f71dac0854cfd930f0443d3cf6fa696315afd95'}
    patches=[];sources=[]
    for name,baseline in expected.items():
        source=a.sistema/'app'/name;new=candidate/name;checks['source_baseline_'+name]=sha(source)==baseline
        patches.extend(difflib.unified_diff(source.read_text(encoding='utf8').splitlines(True),new.read_text(encoding='utf8').splitlines(True),fromfile='a/sistema/app/'+name,tofile='b/sistema/app/'+name))
        sources.append({'file':'app/'+name,'baseline_sha256':sha(source),'candidate_sha256':sha(new)})
    patch=here/'APLICAR_S_APD01_R02.patch'
    with patch.open('x',encoding='utf8')as f:f.writelines(patches)
    result={'schema':'DEE.APD01.service_patch.instrument_tests.v1','new_native_ticks':0,'new_DEE_participants':0,'checks':checks,'all_true':all(checks.values()),'sources':sources,'patch_sha256':sha(patch),'scope':'Instrumentation fixtures only; no claim of Spanish learning, mathematical competence, native route choice or tool delegation.'}
    a.salida.parent.mkdir(parents=True,exist_ok=True)
    with a.salida.open('x',encoding='utf8')as f:json.dump(result,f,sort_keys=True,ensure_ascii=False,indent=2);f.write('\n')
    print(json.dumps(result,ensure_ascii=False));return 0 if result['all_true']else 1

if __name__=='__main__':raise SystemExit(main())
