"""Bounded operational proof from an exact extracted collaboration archive.

Delegates all inputs/physics/persistence to the existing manager. It never reads
historical scientific targets, chooses a favorable branch or retries an action.
"""
import hashlib,importlib.util,json,subprocess,time
from pathlib import Path
from datetime import datetime


def read(path):return json.loads(path.read_bytes())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def run(root,life,alias,sequence,call,*,resume=None):
    settings=sequence['service_protocol'];python=root/'motor/python313/python.exe';launcher=root/'actualizaciones/arrancar.py';result={'schema':'DEE.collaboration.paired_service_operational_proof.v1','protocol':settings,'parents_are_not_merged':True,'commands_use_only_this_archive':True,'functional_issues':[],'sensor_checks':{}};owner=None;owned_job=None;index=0
    resource_source=root/'sistema/app/process_control.py';spec=importlib.util.spec_from_file_location('exact_archive_owned_process',resource_source);pc=importlib.util.module_from_spec(spec);spec.loader.exec_module(pc);result['owned_job_instrument_from_exact_archive']={'file':str(resource_source),'sha256':sha(resource_source),'hard_memory_bytes':536870912,'scope':'Technical process ownership and resource bounds, not action selection.'}
    folder=root/'trabajo_personal/resultados'/('ENTREGA_'+life)
    if resume is None:folder.mkdir(parents=True,exist_ok=False)
    else:
        if not folder.is_dir():raise ValueError('Explicit continuation requires its existing preserved proof folder')
        result=resume;index=1
    def cmd(label,argv):return json.loads(call(label,['gestor',*argv]))
    def native_result(value):return json.loads(value['request']['result'])['result']
    def check_fence(value,identifier):
        fence=native_result(value).get('INSTRUMENTO_FENCE')
        if not isinstance(fence,dict)or fence.get('denied')or fence.get('no_lab_evidence_or_history_reads_allowed')is not False or fence.get('legacy_combined_flag_deprecated_no_universal_history_guarantee')is not True or fence.get('no_undeclared_external_lab_or_evidence_reads_allowed')is not True or fence.get('operational_history_reads_universally_blocked')is not False:raise ValueError('Missing/denied or misleading operational audit-hook descriptor: '+identifier)
        return fence
    def control(identifier,op):
        # A full paired export copies and hashes the durable outbox, not just a
        # snapshot. Waiting longer for this SAME control never retries physics.
        value=cmd(identifier,['mente-unificada-'+op,'--vida',life,'--id',identifier,'--esperar','180'if op=='exportar'else'40'])
        row=value.get('request')or value
        if row.get('status')!='completed':raise ValueError('Technical control not completed: '+identifier)
        return json.loads(row['result'])if isinstance(row.get('result'),str)else row['result']
    def request(identifier,row,*,wait=True):
        value=cmd(identifier,['mente-unificada-pedir','--vida',life,'--id',identifier,'--situaciones',json.dumps(row,separators=(',',':')),'--retorno','omit','--esperar','40'if wait else'0'])
        if wait and(value.get('request')or value).get('status')!='completed':raise ValueError('New material request not completed; actual state preserved: '+identifier)
        if wait:check_fence(value,identifier)
        return value
    def apd_requests(label,rows):
        # These are fixed literal requests from the pre-sealed release protocol.
        # The auditor is called AFTER the native result and never supplies its
        # arithmetic, target or a preferred procedure to the actor.
        import importlib.util
        path=Path(__file__).with_name('auditar_apd_archivado.py')
        spec=importlib.util.spec_from_file_location('exact_archive_APD_auditor',path);auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
        checked=[]
        for i,row in enumerate(rows):
            identifier='delivery_apd_'+label+'_'+str(i);mode=row['modo']
            if mode=='apd':arguments=['usar','--texto',row['texto'],'--operandos',*[str(v)for v in row['operandos']]]
            elif mode=='apd-conteo':arguments=['contar','--presencias',*[str(v)for v in row['presencias']]]
            elif mode=='apd-componer':arguments=['componer','--formas',*row['formas'],'--datos',*[str(v)for v in row['datos']]]
            else:raise ValueError('This fixed distribution check uses only the approved APD use/count/assisted-composition client, not arbitrary new modes')
            argv=['asistente',life,*arguments,'--id',identifier,'--retorno','omit','--esperar','40']
            value=json.loads(call(identifier,argv));record=value.get('request')or value
            if record.get('status')!='completed':raise ValueError('New literal APD client request did not complete; no automatic retry')
            check_fence(value,identifier);native=native_result(value)['rows'][0]
            audit=auditor.audit(native,root/'trabajo_personal/estado/servicios_locales'/life)
            checked.append({'fixed_literal_request':row,'transport':value,'independent_audit':audit,'new_assistant_launcher_actually_used':True,'actual_literal_client_argv':argv,'launcher_sha256_from_exact_extraction':sha(launcher)})
            if audit['issues']:raise ValueError('APD archived RAW/receipt/artefact interpretation disagrees: '+str(audit['issues']))
            def primitive_rows(value):
                if value.get('kind')=='assisted_operator_order_composition':
                    for child in value['parts']:yield from primitive_rows(child)
                else:yield value
            history=settings.get('auditor_form_signs_from_closed_results',{})
            for stage,part in enumerate(primitive_rows(audit)):
                tag=identifier+'_stage_'+str(stage)
                if part.get('correct_when_responded')is False:result['functional_issues'].append(tag+'_numeric_result_not_the_emitted_operation')
                if part.get('abstention'):result['functional_issues'].append(tag+'_no_numeric_response')
                form=part.get('literal_form')
                if form:
                    known=history.get(form);actual=(part.get('word')or{}).get('command');part['delivery_history_comparison']={'actual':actual,'declared_closed_history':known,'matches':actual==known if known is not None else None,'not_actor_input':True,'scope':'Only actual acquired/used forms documented at the source cut, not nominal scheduled lessons.'}
                    if known is not None and actual!=known:result['functional_issues'].append(tag+'_word_differs_from_its_declared_closed_history')
            if audit.get('kind')=='assisted_operator_order_composition'and audit.get('result')is None:result['functional_issues'].append(identifier+'_composition_has_no_final_result')
        return checked
    def start():
        nonlocal owner,owned_job,index
        if owned_job is not None or(owner is not None and owner.poll()is None):raise ValueError('Previous extracted owner/job remains; never create a second writer')
        index+=1;start_wall=time.time();argv=[str(python),'-I','-B','-X','utf8',str(launcher),'gestor','mente-unificada-iniciar','--vida',life,'--backend','mente_unificada','--pausado','--intervalo','.1','--guardar-cada','60','--max-segundos','600']
        owner,owned_job,job_name=pc.spawn_owned(argv,cwd=root,stdout=(folder/('OWNER_'+str(index)+'.txt')).open('x',encoding='utf8'),stderr=(folder/('OWNER_'+str(index)+'_ERROR.txt')).open('x',encoding='utf8'),memory_limit=536870912)
        result.setdefault('owned_job_start',[]).append({'index':index,'launcher_pid':owner.pid,'job_name':job_name,'hard_memory_bytes':536870912})
        limit=time.monotonic()+45
        while time.monotonic()<limit:
            if owner.poll()is not None:raise RuntimeError('Extracted native owner failed before readiness')
            state=cmd('owner_'+str(index)+'_readiness',['mente-unificada-estado','--vida',life])
            cached=state.get('observation')or state.get('owner')or state
            if cached.get('running')and cached.get('wall_utc')and datetime.fromisoformat(cached['wall_utc']).timestamp()>=start_wall:return cached
            time.sleep(.1)
        raise TimeoutError('Extracted owner readiness')
    def stop(identifier):
        nonlocal owner,owned_job
        value=control(identifier,'detener');owner.wait(timeout=45)
        resources=pc.job_resources(owned_job);exit_start=time.monotonic();exit_samples=[{'elapsed_seconds':0,'resource':resources}]
        while resources.get('job_active_processes',0)and time.monotonic()-exit_start<5:
            time.sleep(.02);resources=pc.job_resources(owned_job);exit_samples.append({'elapsed_seconds':time.monotonic()-exit_start,'resource':resources})
        result.setdefault('owned_job_closed_resources',[]).append({'index':index,'stop_request':identifier,'resource':resources,'exit_accounting_grace':{'maximum_seconds':5,'observations':exit_samples}})
        if resources.get('job_active_processes')!=0:raise RuntimeError('Extracted child process remains after the owner STOP; do not certify clean closure')
        pc.close_job(owned_job);owned_job=None
        if owner.returncode:raise RuntimeError('Extracted owner exited with failure')
        owner=None;return value
    if resume is None:call('open_complete_paired_copy_not_bare_snapshot_fork',['abrir',alias,life])
    card=root/'trabajo_personal/estado/vidas'/life/'VIDA.json';initial=read(card);chosen=next(r for r in read(root/'entes/CATALOGO.json')['cuts']if r['alias']==alias)
    keys=('N','tick','RAW_sha256','clocks_sha256')
    if resume is None:
        if any(initial['physical'][k]!=chosen['physical'][k]for k in keys):raise ValueError('Imported physical cut differs before any input')
        if initial['branch']!='EXPLICIT_IMPORTED_CONTINUITY'or initial['parent']['encoded_sha256']!=chosen['snapshot_sha256']:raise ValueError('A recipe or another biography replaced the imported complete state')
        result['exact_import']={'initial':initial['physical'],'source_snapshot_sha256':chosen['snapshot_sha256'],'source_life':chosen['source_life'],'branch':initial['branch'],'life_id':life,'world_id':initial['world_id'],'no_T0':True,'transport_bundle':chosen.get('persistent_service')}
    else:
        if initial['life_id']!=result['exact_import']['life_id']or initial['world_id']!=result['exact_import']['world_id']:raise ValueError('Explicit continuation identity differs from the preserved first attempt')
        if 'paired_pending_export'not in result or'owner1_stop'not in result:raise ValueError('Explicit continuation must first prove the same export completed and its owner stopped')
    try:
        if resume is None:
            result['owner1']=start();control('delivery_resume1','reanudar')
            result['old_panel_before']=request('delivery_old_before',settings['old_panel'])
            if settings.get('apd_before'):result['apd_before']=apd_requests('before',settings['apd_before'])
            result['new_scalar']=request('delivery_new_scalar',[settings['new_scalar']])
            result['new_raw_frame']=request('delivery_new_raw_frame',[settings['new_raw_frame']])
            for label in('new_scalar','new_raw_frame'):
                row=native_result(result[label])['rows'][0];reader=row.get('reader',{});candidates=[]
                expected_sites={(15+2*x,17,15+2*z)for x in(-1,0,1)for z in(0,-1)}
                if len(reader.get('observations',[]))!=6 or{tuple(o['site'])for o in reader['observations']}!=expected_sites:raise ValueError('New sensor use did not expose exactly the six frozen physical output classes')
                for observation in reader['observations']:
                    raw=int(observation['raw']);direction=[((raw>>k)&15)-16 if((raw>>k)&15)>=8 else((raw>>k)&15)for k in(48,52,56)]
                    x=(observation['site'][0]-15)//2;z=(observation['site'][2]-15)//2
                    if raw&0xffffffff and(raw>>60)&15==1 and direction==[x,1,z]:candidates.append(x)
                independently_decoded=candidates[0]if len(candidates)==1 else None
                if reader.get('choice')!=independently_decoded:raise ValueError('Archived native reader disagrees with independently decoded RAW; instrument result invalid')
                admitted=sum(r['receipt']['status']=='applied'for r in row['requests'])
                result['sensor_checks'][label]={'requests':len(row['requests']),'applied':admitted,'candidates':candidates,'independently_decoded':independently_decoded,'current_physical_response_not_replaced':True}
                if len(candidates)!=1:result['functional_issues'].append(label+'_no_unique_native_output')
                if admitted!=len(row['requests']):result['functional_issues'].append(label+'_some_inputs_rejected')
                if label=='new_raw_frame'and'new_raw_expected_choice'in settings:
                    result['sensor_checks'][label]['frozen_auditor_expected_choice_not_actor_input']=settings['new_raw_expected_choice']
                    if independently_decoded!=settings['new_raw_expected_choice']:result['functional_issues'].append(label+'_does_not_match_frozen_task_relation')
            result['explicit_new_learning']=request('delivery_teaching',[settings['declared_teaching']])
            result['old_panel_after_teaching']=request('delivery_old_after_teach',settings['old_panel'])
            result['chain_begin']=request('delivery_chain_begin',[settings['chain_begin']])
            control('delivery_pause_pending','pausar')
            result['queued_finish']=request('delivery_chain_finish',[{'modo':'cadena-finalizar'}],wait=False)
            result['saved_pending']=control('delivery_pending_save','guardar')
            result['paired_pending_export']=control('delivery_pending_export','exportar')
            result['owner1_stop']=stop('delivery_stop1')
        cut=read(card)
        witness=result['saved_pending']['committed_snapshot'];dependency=witness['operational_dependencies']
        if not dependency['external_pending_present']or not dependency['cascade_pending_present']:raise ValueError('No actual pending artifact at the reserved boundary; do not manufacture a replacement')
        result['owner2']=start();result['reloaded_pending']=control('delivery_reloaded_save','guardar');reloaded=result['reloaded_pending']['committed_snapshot']
        if any(witness['physical'][k]!=reloaded['physical'][k]for k in keys)or witness['operational_dependencies']!=reloaded['operational_dependencies']:raise ValueError('Pending artifact/protocol or native fields changed on reload')
        control('delivery_resume2','reanudar')
        # The already queued FINISH is waited for, not submitted a second time.
        limit=time.monotonic()+40;poll=0
        while time.monotonic()<limit:
            poll+=1;finish=cmd('delivery_wait_already_queued_finish_'+str(poll),['mente-unificada-resultado','--vida',life,'--id','delivery_chain_finish'])
            if(finish.get('request')or{}).get('status')in('completed','uncertain','failed_preserved','rejected_invalid'):break
            time.sleep(.1)
        if(finish.get('request')or{}).get('status')!='completed':raise ValueError('Queued continuation did not complete after reload')
        result['finished_once_after_reload']=finish
        result['old_panel_after_reload']=request('delivery_old_after_reload',settings['old_panel'])
        if settings.get('apd_after_reload'):result['apd_after_reload']=apd_requests('after_reload',settings['apd_after_reload'])
        def memory_panel(value):
            panel=[r['result']['rows'][0]for r in native_result(value)['rows']];expected=[r['contexto']for r in settings['old_panel']];contexts=[r['context_signal']for r in panel]
            if len(contexts)!=len(expected)or len(set(contexts))!=len(contexts)or set(contexts)!=set(expected):raise ValueError('The old-memory panel is incomplete or contains duplicate context addresses')
            return{r['context_signal']:r['reader']['formed_native_command']for r in panel}
        before_panel=memory_panel(result['old_panel_before']);after_teaching=memory_panel(result['old_panel_after_teaching']);after_reload_panel=memory_panel(result['old_panel_after_reload']);target=settings['declared_teaching']['contexto'];sign=settings['declared_teaching']['senal']
        result['memory_delivery_assertions']={'before':before_panel,'after_explicit_teaching':after_teaching,'after_reload':after_reload_panel,'teaching_is_operator_prepared_not_autonomous':True}
        if any(v not in(-1,1)for v in before_panel.values()):result['functional_issues'].append('initial_old_panel_not_fully_accessible')
        if target not in before_panel or before_panel[target]==sign:result['functional_issues'].append('declared_teaching_not_a_verified_new_revision')
        for context,previous in before_panel.items():
            expected=sign if context==target else previous
            if after_teaching.get(context)!=expected or after_reload_panel.get(context)!=expected:result['functional_issues'].append('memory_revision_or_retention_'+context+'_did_not_survive')
        finish_result=native_result(finish)['rows'][0];worker=finish_result['external']['worker_receipt']
        check_fence(finish,'delivery_chain_finish')
        if not worker:raise ValueError('The new two-stage operation has no actual worker receipt; no prepared outcome substitution')
        if not worker.get('transaction_completed'):result['functional_issues'].append('new_two_stage_transaction_did_not_commit')
        actuals=[]
        for stage in(result['chain_begin'],finish):
            receipt=native_result(stage)['rows'][0]['external']['worker_receipt']
            if not receipt:raise ValueError('No real worker receipt for the announced transaction')
            matches=[f for f in(root/'trabajo_personal/estado/servicios_locales'/life).rglob(receipt['output_name'])if f.is_file()and f.stat().st_size==receipt['output_bytes']and sha(f)==receipt['output_sha256']]
            if not matches:raise ValueError('Extracted native action did not leave the exact declared worker bytes')
            actuals.append({'name':receipt['output_name'],'file':str(matches[0]),'bytes':receipt['output_bytes'],'sha256':receipt['output_sha256'],'worker':receipt['worker'],'accepted':receipt['accepted'],'commit':receipt['transaction_completed']})
        result['actual_new_worker_files']=actuals
        control('delivery_final_pause','pausar');result['final_export']=control('delivery_final_export','exportar');result['owner2_stop']=stop('delivery_stop2');after=read(card)
        if after['life_id']!=initial['life_id']or after['world_id']!=initial['world_id']or after['physical']['tick']<=cut['physical']['tick']:raise ValueError('The next process did not continue the same life')
        snap=(root/'sistema'/after['snapshot']).resolve(strict=True)
        if not snap.is_relative_to(root/'trabajo_personal')or sha(snap)!=after['snapshot_sha256']:raise ValueError('Continued complete snapshot is not intact inside this extraction')
        result['continued_state']={'life_id':life,'world_id':after['world_id'],'tick':after['physical']['tick'],'snapshot':str(snap),'snapshot_sha256':after['snapshot_sha256'],'parent':after.get('parent')}
        result['pending_reload_verified']={'physical_fields_identical':True,'external_protocol_exact_SHA_identical':True,'no_new_world_or_T0':True,'same_literal_finish_not_requeued':True}
        if settings.get('auxiliary_after_main_stopped'):
            # Sequential separate participant, never an extra skill of MAIN.
            aux=settings['auxiliary_after_main_stopped'];auxlife=life+'_AUX';auxalias=aux['alias']
            call('open_separate_ready_auxiliary_copy',['abrir',auxalias,auxlife])
            acard=root/'trabajo_personal/estado/vidas'/auxlife/'VIDA.json';abefore=read(acard)
            achosen=next(r for r in read(root/'entes/CATALOGO.json')['cuts']if r['alias']==auxalias)
            if any(abefore['physical'][k]!=achosen['physical'][k]for k in keys):raise ValueError('Separate auxiliary did not import its own exact pre-use state')
            ast=cmd('auxiliary_passive_before',['unificada-acceso-estado','--vida',auxlife])
            if ast.get('operational',{}).get('used')is not False:raise ValueError('Selected auxiliary READY state was already consumed; no rewind or replacement')
            used=cmd('auxiliary_single_destructive_use',['unificada-acceso-usar','--vida',auxlife]);saved=cmd('auxiliary_explicit_save',['guardar','--vida',auxlife]);ast_after=cmd('auxiliary_next_process_state',['unificada-acceso-estado','--vida',auxlife]);afinal=read(acard)
            result['separate_finite_auxiliary']={'alias':auxalias,'life_id':auxlife,'initial':abefore['physical'],'state_before':ast,'one_use':used,'saved':saved,'next_process_state':ast_after,'final':afinal['physical'],'final_snapshot_sha256':afinal['snapshot_sha256'],'not_MAIN_knowledge':True}
            for name,value in(('before',ast),('use',used),('after',ast_after)):
                fence=value.get('INSTRUMENTO_FENCE')
                if not isinstance(fence,dict)or fence.get('denied')or fence.get('no_lab_evidence_or_history_reads_allowed')is not False or fence.get('legacy_combined_flag_deprecated_no_universal_history_guarantee')is not True or fence.get('no_undeclared_external_lab_or_evidence_reads_allowed')is not True or fence.get('operational_history_reads_universally_blocked')is not False:raise ValueError('Separate auxiliary lacks a truthful, clean declared audit-hook descriptor: '+name)
            reader=used['result']['reader'];allowed={(33+4*x,33+4*y,33+z):(x,y,z)for x,y in((1,0),(0,1),(1,1),(-1,1),(1,-1),(-1,-1))for z in(-1,1)};cs=[]
            if len(reader['panel'])!=12 or{tuple(p['observation']['site'])for p in reader['panel']}!=set(allowed):raise ValueError('Auxiliary did not expose exactly the twelve frozen gate sites')
            for p in reader['panel']:
                o=p['observation'];raw=int(o['raw']);v=[((raw>>k)&15)-16 if((raw>>k)&15)>=8 else((raw>>k)&15)for k in(48,52,56)]
                if raw&0xffffffff and(raw>>60)&15==1 and v==list(allowed[tuple(o['site'])]):cs.append(v[2])
            decoded=cs[0]if len(cs)==1 else None
            if reader['formed_native_command']!=decoded:raise ValueError('Auxiliary reader disagrees with independently decoded RAW')
            result['separate_finite_auxiliary']['independent_reader']={'candidate_signs':cs,'command':decoded,'all12_fixed_gates':True}
            if len(cs)!=1:result['functional_issues'].append('separate_auxiliary_no_unique_native_response')
            if afinal['life_id']!=abefore['life_id']or afinal['physical']['tick']<=abefore['physical']['tick']:raise ValueError('Auxiliary save/continuation identity or physical advance failed')
            if not ast_after.get('operational',{}).get('used'):raise ValueError('Separate one-use progress was not preserved in the next process')
        return result
    finally:
        if owner and owner.poll()is None:
            try:stop('delivery_emergency_stop')
            except Exception as error:
                result['owner_failure_preserved_without_forced_rewind']=str(error)
        if owned_job is not None:
            # Only this proof-created process tree may be terminated. A failed
            # graceful close remains a technical negative; no effect is retried.
            remaining=pc.job_resources(owned_job)
            if remaining.get('job_active_processes',0):
                result['forced_exclusive_owned_job_cleanup']={'last_resource':remaining,'last_durable_cut_not_replaced':True,'automatic_action_retry':False};pc.terminate_job(owned_job,125)
                if owner:owner.wait(timeout=45)
            result['finally_owned_job_resources']=pc.job_resources(owned_job);pc.close_job(owned_job);owned_job=None
        name='PRUEBA_SERVICIO.json'if resume is None else'PRUEBA_SERVICIO_R02_CONTINUACION.json'
        (folder/name).write_text(json.dumps(result,sort_keys=True,ensure_ascii=False,indent=2)+'\n',encoding='utf8')


# Same delivery entry point; the older protocol remains byte-preserved above.
_run_previous_paired_protocol = run
def run(root,life,alias,sequence,call,*,resume=None):
    if sequence.get('service_protocol',{}).get('schema')=='APD02.full.operational.R01':
        if resume is not None:raise ValueError('APD02 recovery requires a separately declared same-ID continuation, never an implicit retry')
        path=Path(__file__).with_name('probar_asistente2_distribuido.py');spec=importlib.util.spec_from_file_location('exact_extracted_APD02_proof',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        return module.run(root,life,alias,sequence,call)
    return _run_previous_paired_protocol(root,life,alias,sequence,call,resume=resume)
