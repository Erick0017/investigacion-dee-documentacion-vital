# Deep reduction report — Continuación 1 de 6

## What changed relative to the first scan

The first delivery hashed and structurally catalogued the corpus. This continuation opened the scientific members of every file in `documantacion vital`, recursively descended nested ZIP/WHL containers, parsed complete JSON/JSONL/CSV sources, opened NPZ/NPY payloads, read complete runner/source text and extracted complete DOCX text. Byte-identical sources were reduced once and cross-linked thereafter. Root-level scientific campaign ZIPs outside the vital directory were also reduced, including Formula Bridge, group velocity/phase, V6/V7, metric/minimum-time, multiscale/morphogenesis and replay batteries.

The six cross-campaign synthesis atoms were additionally bound to their exact primary telemetry member and exact producing runner, each with member-level SHA-256.

`EVIDENCE_ATOMS.jsonl` was rebuilt: its records now describe experimental results or mathematical relations with a numerical reduction, not file existence.

## Primary information recovered from telemetry

1. **Native distance:** the Formula Bridge audit contains V7-C reached holdout rows `(d_native,tau,d_naive_x)=(18,18,22)` and `(22,22,26)`. Thus `RMSE(tau,d_native)=0` and `RMSE(tau,d_naive_x)=4` in that small holdout domain.
2. **Group-velocity boundary:** Part C C7 retained `T_peak/T_first/T_centroid`, but all nine media were classified `no_resolved_group_mode`. This narrows the missing dispersion edge instead of supporting a collective `omega(k)`.
3. **History as geometry/latency:** Procesos 01 measures a 329-tick `tau99` displacement between OMIT_P2 and FULL within BA, with local Moore-26 ancestry and toroidal coalescence. Procesos 02 measures contact with a preexisting interface at `tau99-8` in both realizations.
4. **Coarse equality is not causal equality:** terminal branches with similar occupancy retain large RAW differences, while the same 14-site interface geometry supports states 1, 2 and 3 and reinstantiation futures 2/0/2.
5. **Probability:** CORE16/17 primary data support deterministic measure pushforward and exact branch-union prediction, not Born.
6. **R0:** CORE17 primary holdouts establish exact domain-specific closure/compression; this updates earlier universal-sounding “no quotient closes” language without erasing the earlier nulls outside the R0 domain.

## Interpretations refined or superseded

- `P2 amplifies` becomes: P2 changes the latency of BA access to an expansive regime within a non-additive configuration.
- `no endogenous consequence` becomes: a bounded post-host chain reaches a preexisting degree, changes it and changes diagnostic futures.
- `quantum absent` becomes: a reversible-sector unitary representation is a valid formal/sectoral construction, while operational quantum measurement, Born and entanglement remain open.
- `metric missing` becomes: a discrete native path/first-passage geometry is already measured; Lorentzian/Einstein closure remains open.
- Local negative labels remain controls at their apparatus/horizon and are not universal exclusions.

## Formula candidates retained

`FORMULA_CANDIDATES.json` separates exact kernel equations, exact empirical apparatus laws, approximate/formal relations and external analogies. New high-value candidates from deep reduction are the V7-C `tau=d_native` holdout relation, the event-aligned `t_response=tau99-8` relation and the C7 nine-case unresolved-mode boundary.

## Sources still deferred

Deferred entries are enumerated in `SCIENTIFIC_REDUCTION_COVERAGE.json`. They are limited to corrupt/unparseable members, exact byte duplicates, administrative material, binary extensions without a semantic reader, and PDFs where no local text extractor exists. A duplicate is cross-linked to its reduced source and is not counted as independent evidence.

## Scope

No kernel campaign, fresh world, parameter search or new apparatus was executed. All numbers are extracted or derived from existing files. This report does not rewrite the final internal theory; it establishes the evidence base for Continuation 2.
