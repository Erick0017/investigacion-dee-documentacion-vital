# Aristas exactas aún no cerradas

## MQ-01 — Observer cuántico operacional
**QUESTION:** ¿qué mapa preregistrado `M_Q` lleva una organización DEE no trivial a amplitudes/observables y cierra bajo `U_Q`?  
**WHY EXISTING DATA CANNOT ANSWER:** los sectores reversibles y la relación distribuida existen, pero no una lectura Hilbert operacional conjunta.  
**MINIMUM REQUIRED OBSERVABLES:** amplitud/fase, partición A/B, observables locales, conservación de norma, predicción fresh.  
**PARENT DATA:** reversible translation, CORE16/17 phase/ensemble, entanglement documents.  
**MINIMUM EXPERIMENT DESIGN:** seleccionar un sector ya reversible, congelar `M_Q` y partición antes del holdout, probar cierre y Schmidt rank. Runtime esperado: minutos, no sweep.

## QP-02 — Born
Falta una medida/simetría que derive probabilidades por módulo cuadrado y la contraste con el pushforward clásico existente. Requiere ensembles preregistrados sobre un `M_Q` ya cerrado; no puede resolverse sólo renombrando frecuencias.

## DISP-01 — Dispersión
Falta reducir telemetría de modos en un sector homogéneo a `ω(k)` con barras de error/fresh, para decidir transporte lineal, gap, curvatura y masa tensorial efectiva. Primero reanalizar telemetría existente; sólo después un paquete de onda mínimo si faltan series espacio-temporales.

## REL-01 — Métrica móvil
Faltan observers móviles, proper-time-like clock y colapso multiescala de anisotropía. Parent: first passage/causal cone/phase. Diseño mínimo futuro: un solo sector homogéneo con paquetes y frames congelados.

## GR-01 — Respuesta geométrica a fuente
No existe una medición conjunta de `source_eff`, cambio de causal order/metric y trayectoria de prueba con control sin fuente. Las derivaciones EH son condicionales.

## TH-01 — Balance termodinámico
Faltan energía/recurso extensivo, flujo ambiente, temperatura/conjugado y balance. Reanalizar primero `s_reg`, DEMUX y relajación; ninguna variable puede nombrarse por analogía.

## HY-01 — Cierre hidrodinámico
Faltan continuidad, momentum transport, stress y viscosidad sobre el mismo coarse-graining. Los paquetes Navier históricos contienen candidatos pero no un commuting diagram congelado.

## GA-01 — Simetría gauge local
Existe quotient de clock común en aparatos concretos; falta una familia local de transformaciones con compensadores y observables invariantes.

## EXT-01 — Calibración externa común
Faltan unidades/acceso y una predicción externa no usada, compartida por varios sectores sin refit independiente.
