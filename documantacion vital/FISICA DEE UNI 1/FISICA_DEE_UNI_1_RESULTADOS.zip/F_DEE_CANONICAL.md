# F_DEE canónico — kernel v27

## Identidad

La referencia ejecutable es el `.pyd` SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`; el source empaquetado auditado tiene SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`. El mapa público es determinista y sincrónico:

`X_{t+1}=F_DEE(X_t)`, con `X=(raw_a,clock_a)` sobre `Ω_N=Z_N^3`.

`raw_b/clock_b` son buffers de implementación, no grados causales adicionales. Cada `raw` empaqueta `state[32]`, `s_reg[16]`, tres direcciones signed-nibble `[4+4+4]` y `semantic[4]`. `clock` es `uint64` separado.

## Localidad y orden

Cada celda consulta Moore-26 a distancia Chebyshev uno, aplica las ramas en el orden del source y luego recibe deltas DEMUX acumulados. La causalidad microscópica por tick está acotada por self+Moore-26; sobre el toro, `d∞` usa distancia modular. El reducer SYM1 agrega conmutativamente todas las fuentes direccionales que apuntan al destino: una fuente conserva su raw; varias saturan `s_reg` en 19664 y toman el signo de la suma vectorial.

## Vacío y materia

`state=0` no equivale a ausencia de dinámica: puede cristalizar por gradiente, nacer por XNOR o recibir una fuente direccional. La rama material calcula firma tetraédrica, `rho_eff=n_active*T_local/26`, redondea a `rule_value`, actualiza `s_reg` según fase de clock salvo protección, puede emitir un delta de fusión y ancla dirección al gradiente cuando corresponde. Los nombres `electron_seed`, `proton_seed`, `observer`, `horizon` son semánticas internas; no constituyen por sí mismos Rosetta externa.

## Inyectividad

El mapa global contiene ramas many-to-one y no es unitario globalmente. Sí admite subconjuntos cerrados reversibles donde su restricción es una permutación. Esta coexistencia sostiene sectores disipativos/informacionales y sectores reversibles sin contradicción.
