# Cadena materia–historia–información

`raw/clock local → organización → relación → función → reachability`.

Una historia no reside necesariamente en una pieza: se incorpora porque modifica `X_FULL`, y el presente reorganizado cambia futuros. NRD04 mostró soporte RAW sinérgico 8/8 y sensibilidad valor/posición; NRD05/06 mostró transformación específica de historia; Ingeniería 06 acumuló al menos 17 contribuciones individualmente relevantes; Procesos 01/02 mostró transición endógena, latencia histórica, contacto con un grado preexistente y futuros de reinstanciación diferentes.

La materia DEE procesa información porque su dinámica transforma distinciones causales. La reparación/reinstanciación usa organización y rutas; la misma forma puede ser funcionalmente distinta y la misma función puede reinstanciarse en soporte distinto. `HIDDEN != DESTROYED` conecta memoria, coarse-graining y observer sin identificar automáticamente decoherencia cuántica.
