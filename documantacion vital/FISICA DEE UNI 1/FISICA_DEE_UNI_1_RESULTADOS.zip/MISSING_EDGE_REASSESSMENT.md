# Reassessment of the first-scan missing edges

## A) ANSWERED_BY_EXISTING_DATA

- **Native causal geometry at the discrete level.** Existing V7-C telemetry contains reached holdout rows with `tau=d_native` exactly (18/18 and 22/22), while naive x-distance is off by four ticks. Procesos 01 independently establishes self+Moore-26-compatible first divergence, toroidal maximum shell 19 and local ancestry for the BA front. This answers the existence of a native path/causal metric in those domains; it does not answer Lorentzian closure.
- **Preparation-dependent effective probability.** CORE16/17 already provides a complete deterministic pushforward construction, 27,648 microstates, 54 macroclasses, exact 576/576 branch-union predictions and preparation dependence in 7/8 pairs.
- **History-conditioned physical continuation.** Procesos 01/02 measures BA-dependent expansion, event-aligned contact at `tau99-8`, state `1→2→3`, persistence and changed reinstantiation futures. No new experiment is needed to establish that bounded chain.
- **Domain-specific causal compression.** CORE17 R0/R0_FACTOR_52 supplies a fresh exact closure within its stated ordinary-cell/semantic-4 domains.

## B) PARTIALLY_ANSWERED_BY_EXISTING_DATA

- **Dispersion/group velocity.** The C7 campaign measured `T_peak`, `T_first` and `T_centroid` across nine pre-evolved media but classified all nine as `no_resolved_group_mode`. Existing telemetry answers that this apparatus did not resolve a collective mode; it cannot supply `omega(k)` or effective mass.
- **Effective metric.** Causal order, native distance, first passage, anisotropy and state/history-dependent latency exist. Moving-frame closure, interval invariance and a single metric reconstruction remain absent.
- **Thermodynamics.** Many-to-one, ensembles, relaxation, `s_reg`, DEMUX and resource accounts exist. A common energy-like state function, stationary measure and conjugate temperature are not identified.
- **Hydrodynamics.** Historical and CORE15 sources contain density/support, direction responses, fronts and stress/pressure candidates. No source located in this reduction closes local continuity, face flux, momentum/stress and scale-stable constitutive coefficients in one frozen apparatus.
- **Quantum sector.** Closed reversible permutations and their unitary representation are mathematically available; phase and pushforward probability are measured. Operational `M_Q`, Born and a nonfactorizing bipartite DEE state remain uninstantiated.

## C) ACTUALLY_REQUIRES_NEW_MEASUREMENT

- A preregistered operational `M_Q` with bipartite observables and a Born-vs-pushforward discriminator.
- A mode-resolved spatial/time series sufficient for frozen `omega(k)` extraction after the existing C7 null.
- Moving internal observers and proper-time-like readouts for Lorentzian metric closure.
- Joint `source_eff`, metric/causal response and test-organization motion for gravity-like coupling.
- A single thermodynamic apparatus with balance, exchange and conjugate variables.
- A single hydrodynamic apparatus with continuity, momentum flux, stress and transferable viscosity.
- A local compensating-transformation family for a gauge claim.

No design is prescribed here; these are data requirements, not campaign proposals.
