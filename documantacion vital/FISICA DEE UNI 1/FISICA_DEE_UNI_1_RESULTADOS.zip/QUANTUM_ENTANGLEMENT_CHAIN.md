# Cadena cuántica y de entrelazamiento

| Flecha | Estado vigente | Evidencia / condición |
|---|---|---|
| `X → S_Q` | Sectorial | Existen dinámicas reversibles/permutacionales; falta una selección física universal. |
| `S_Q → U_Q` | Derivación exacta | Toda permutación finita induce una matriz unitaria en la base de estados. |
| `U_Q → H_eff` | Formal exacta con rama | `H_eff=(i hbar*/tau*) log U_Q`; la rama forma parte de la especificación. |
| `H_eff → Schrödinger` | Efectiva/condicional | Forma diferencial de una familia escalada; transporte exacto para traslación. |
| `ω(k) → m*` | No instanciada empíricamente | Requiere dispersión medida, gap y curvatura estables; `m*=hbar*ω0/c*²` es condicional. |
| `X_AB → M_Q(X_AB)` | Observer no identificado | Debe cerrar la dinámica y tener lectura operacional. |
| `M_Q → H_A⊗H_B` | Puente no instanciado | La partición debe conservar observables relevantes. |
| `Ψ_AB → Schmidt rank>1` | Criterio formal | No se ha aplicado a un `M_Q` DEE preregistrado no trivial. |
| amplitudes → Born | Medición nueva necesaria | Pushforward clásico existe; falta una medida/simetría que produzca módulos cuadrados. |

Relación microscópica distribuida, contextualidad, fase y hidden-state son prerrequisitos/análogos, no equivalencia automática con entrelazamiento. El resultado Bell previo `CHSH=-2` pertenece al aparato clásico local probado.
