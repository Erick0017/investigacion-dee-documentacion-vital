# Cadena causal, geométrica y relativista

1. `F_DEE` fija localidad self+Moore-26 y orden discreto.
2. First passage define una distancia/tiempo causal dependiente de medio; `d∞` toroidal es el límite mínimo geométrico.
3. Destination fibers, shielding y rutas convierten la retícula en un paisaje dirigido y dependiente de historia.
4. Causal order + volumen/support pueden determinar una clase conformal discreta sólo dentro de un sector/observer declarado.
5. Para una métrica Lorentziana efectiva faltan isotropía multiescala, observers móviles, reglas de reloj propio y cierre de intervalos.
6. Para gravedad faltan `source_eff`, respuesta geométrica y movimiento de prueba en la misma calibración.

Los documentos de Relación Universal aportan el puente formal `R_DEE→causal order→[g_eff]`; la evidencia vigente instancia el primer tramo y partes del segundo, no Einstein como ley del kernel.
