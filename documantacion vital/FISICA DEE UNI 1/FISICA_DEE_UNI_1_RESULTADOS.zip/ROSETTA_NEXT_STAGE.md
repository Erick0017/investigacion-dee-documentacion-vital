# Preparación de la siguiente Rosetta

| Objeto DEE | Observable efectivo | Teoría candidata | Correspondencia conocida | Grados DEE adicionales | Calibración externa | Predicción discriminante |
|---|---|---|---|---|---|---|
| Moore causal order | first passage / cone | geometría causal | límite L∞ exacto | medio, historia, fibers | longitud/tick | anisotropía y dispersión por escala sin refit |
| reversible sector | `U_Q,H_eff` | cuántica | permutación unitaria exacta | `M_Q`, partición, medida | hbar*, tiempo | espectro/estadística no reducible a pushforward clásico |
| many-to-one ensemble | macroclass probability | estadística | pushforward exacto | medida de preparación | protocolo | dependencia de medida predicha antes del ensayo |
| persistent organization | susceptibility/trajectory | mecánica clásica | carriers/collisions | conserved current | masa/longitud/tiempo | relación fuerza-respuesta común entre geometrías |
| history-shaped reachability | effective medium/metric | geometría/gravedad | latencia dependiente de organización | source_eff | scale map | cambio de first passage predicho por organización |
| relaxation/resources | balance variables | termodinámica | irreversibilidad informacional | energy/temperature observers | energy/temp | balance y producción no reducibles a occupancy |
| density/current modes | continuum fields | hidrodinámica | fronts/transport telemetry | stress/viscosity | continuum scale | Navier-like coefficients transfer across flows |
| clock quotient | phase connection | gauge | common-offset invisibility sectorial | local compensators | phase convention | holonomy/invariant response under local transforms |

La Rosetta debe avanzar DEE mechanism → invariant → mathematics → external theory, y reservar una predicción externa o interna no usada para discriminar.
