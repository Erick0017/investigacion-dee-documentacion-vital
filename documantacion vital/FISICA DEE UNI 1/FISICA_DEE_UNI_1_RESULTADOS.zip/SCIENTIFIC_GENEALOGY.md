# Genealogía científica

- **v24–v25.5:** definición del packing, ramas materiales/vacío, corpus morfológico y primeras Rosetta. Muchas etiquetas externas eran hipótesis; los datos siguen siendo válidos en su kernel.
- **v26:** reducer SYM1 elimina dependencia del orden de fuentes y conserva una dinámica conmutativa de llegada.
- **v27:** fija `P_KERNEL=19665`, binario/source canónico y aparato reproducible.
- **CORE01–07:** teoría nativa, causalidad, observers, escalas y atlas experimental.
- **CORE08–14:** observers mínimos, aprendizaje/acoplamiento, Rosetta internas, ecología causal y múltiples relaciones.
- **CORE15:** observer shadows; fase, dirección, historia y clock pueden ocultarse selectivamente.
- **CORE16:** realidad multiescala, ensembles, pushforward y separación entre analogías quantum-like y estructura cuántica específica.
- **CORE17:** R0 exacto y `R0_FACTOR_52`, retorno de información oculta, probabilidad sectorial y reparación con copia aprendida; cierra sus aparatos, no toda posibilidad física.
- **Ingenierías 01–04.5:** memoria relacional, estabilidad/plasticidad, función/competencia, arquitectura causal distribuida y reachability.
- **Ingeniería 05:** historias específicas cambian futuros y transformaciones posteriores; configuración RAW no aditiva.
- **Ingeniería 06:** actualizaciones recurrentes, carga causal, dinámica RAW post-host y equivalence breaking.
- **Procesos 01:** BA accede a un régimen expansivo por propagación local y coalescencia; P2 modula latencia.
- **Procesos 02:** la transición alcanza una interfaz preexistente y produce estados persistentes, una segunda transformación LATE y futuros funcionales distintos.
- **Formalización cuántica posterior:** sectores reversibles admiten representación unitaria/Hamiltoniana; se separa este teorema de la todavía abierta identificación física de `M_Q`, Born y entrelazamiento.

La genealogía conserva resultados negativos con sus dominios; no los universaliza.
