# Cadena termodinámica e hidrodinámica

## Instanciado

- Determinismo microscópico con ramas many-to-one.
- Ensembles y pushforward dependiente de preparación.
- Relajación, basins, pérdida de distinguibilidad y persistencia de historia.
- Variables de soporte, ocupación, `s_reg`, dirección, semántica y clock.
- Propagación, colisiones, fronts y respuestas colectivas en aparatos concretos.

## No reducido todavía

La termodinámica exige una variable de recurso/energía con balance, una temperatura o parámetro conjugado operacional, intercambio sistema-entorno y producción entrópica. La hidrodinámica exige identificar densidad/current conservados, continuidad, momentum transport, stress/pressure y viscosidad dentro de un sector continuo común. Los archivos históricos llamados “termodinámica” o “Navier” preservan telemetría y candidatos, pero la nomenclatura no constituye cierre.

La flecha temporal ya posee una base informacional: microestados distintos pueden converger bajo `F_DEE` o bajo un observer. Esto no convierte `occupancy` en entropía ni `s_reg` en energía.
