from __future__ import annotations

import csv
import datetime as dt
import hashlib
import html
import io
import json
import os
import re
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np


TESTS = Path(r"D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests")
V27 = TESTS.parent
VITAL = TESTS / "documantacion vital"
OUT_DIR = VITAL / "FISICA DEE UNI 1"
OUT_ZIP = OUT_DIR / "FISICA_DEE_UNI_1_RESULTADOS.zip"
CANON_CPP = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "procesos" / "PROCESOS_02" / "dee_kernel_v27.cpp"
CANON_PYD = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "procesos" / "PROCESOS_02" / "dee_kernel_v27.cp313-win_amd64.pyd"
BUILD_TIME = dt.datetime.now(dt.timezone.utc).isoformat()

SCI_EXT = {
    ".zip", ".json", ".jsonl", ".ndjson", ".npz", ".npy", ".csv", ".md", ".txt",
    ".docx", ".pdf", ".py", ".cpp", ".h", ".hpp", ".whl", ".pyd", ".sha256",
    ".ps1", ".xml", ".gz",
}
TEXT_EXT = {".md", ".txt", ".py", ".cpp", ".h", ".hpp", ".ps1", ".csv", ".json", ".jsonl", ".ndjson", ".sha256", ".xml"}
DERIVATIVE_EXT = {".png", ".jpg", ".jpeg", ".gif", ".html", ".pyc", ".pgm", ".tmp"}


def sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_json(path: Path, obj) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=False), encoding="utf-8")


def read_docx_bytes(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        xml = z.read("word/document.xml").decode("utf-8", "replace")
    xml = re.sub(r"<w:tab[^>]*/>", "\t", xml)
    xml = re.sub(r"</w:p>", "\n", xml)
    text = re.sub(r"<[^>]+>", "", xml)
    text = html.unescape(text)
    return re.sub(r"\n{3,}", "\n\n", text)


def read_docx(path: Path) -> str:
    return read_docx_bytes(path.read_bytes())


def infer_campaign(path: str) -> str:
    u = path.upper()
    for rx, name in [
        (r"CORE[_ -]?0?([1-9]|1[0-7])", "CORE"),
        (r"INGENIER[IÍ]A[_ -]?0?([1-6])", "INGENIERIA"),
        (r"PROCESOS?[_ -]?0?([1-2])", "PROCESOS"),
        (r"NP1(?:\.|_)?", "NP1"),
        (r"ROSETTA", "ROSETTA"),
        (r"VOLUMEN", "VOLUMEN"),
    ]:
        m = re.search(rx, u)
        if m:
            return f"{name}:{m.group(0)}"
    if "KERNEL" in u or path.lower().endswith((".cpp", ".pyd", ".whl")):
        return "KERNEL"
    return "TRANSVERSAL_OR_HISTORICAL"


def approx_content(path: Path) -> str:
    s = str(path).lower()
    tags = []
    for token, label in [
        ("kernel", "kernel/source"), ("claim", "claims"), ("result", "primary/result"),
        ("telemetry", "telemetry"), ("runner", "runner"), ("observer", "observer"),
        ("quant", "quantum"), ("entrelaz", "entanglement"), ("relativ", "relativity"),
        ("hydro", "hydrodynamics"), ("navier", "hydrodynamics"), ("thermo", "thermodynamics"),
        ("matter", "matter"), ("materia", "matter"), ("geometry", "geometry"),
        ("geometr", "geometry"), ("history", "history"), ("historia", "history"),
        ("rosetta", "external-rosetta"), ("manifest", "manifest"), ("hash", "integrity"),
    ]:
        if token in s and label not in tags:
            tags.append(label)
    return ", ".join(tags) if tags else "scientific corpus/supporting artifact"


def _npy_header(stream) -> dict:
    """Read only the NPY header; never materialize the array payload."""
    try:
        version = np.lib.format.read_magic(stream)
        if version == (1, 0):
            shape, fortran, dtype = np.lib.format.read_array_header_1_0(stream)
        else:
            shape, fortran, dtype = np.lib.format.read_array_header_2_0(stream)
        return {"shape": list(shape), "dtype": str(dtype), "fortran_order": bool(fortran)}
    except Exception as exc:
        return {"header_error": type(exc).__name__}


def structured_metadata(path: Path, ext: str) -> dict | None:
    """Schema-level ingestion for every structured scientific file, bounded in memory."""
    try:
        if ext == ".npz":
            arrays = {}
            with zipfile.ZipFile(path) as z:
                for zi in z.infolist():
                    if zi.filename.endswith(".npy"):
                        with z.open(zi) as f:
                            arrays[zi.filename[:-4]] = _npy_header(f)
            return {"kind": "NPZ", "arrays": arrays}
        if ext == ".npy":
            with path.open("rb") as f:
                return {"kind": "NPY", **_npy_header(f)}
        if ext == ".json":
            # Full parse for ordinary files; bounded lexical key extraction for very large telemetry.
            if path.stat().st_size <= 5_000_000:
                try:
                    obj = json.loads(path.read_text(encoding="utf-8", errors="replace"))
                    return {"kind": "JSON", **summarize_json(obj, max_items=20)}
                except Exception as exc:
                    return {"kind": "JSON", "parse_error": type(exc).__name__}
            with path.open("rb") as f:
                head = f.read(512_000).decode("utf-8", "replace")
            keys = []
            for k in re.findall(r'"([^"\\]{1,100})"\s*:', head):
                if k not in keys:
                    keys.append(k)
                if len(keys) >= 100:
                    break
            return {"kind": "JSON_LARGE", "head_bytes_inspected": 512000, "lexical_keys": keys}
        if ext in {".jsonl", ".ndjson"}:
            first = None
            count = 0
            with path.open("r", encoding="utf-8", errors="replace") as f:
                for line in f:
                    if line.strip():
                        count += 1
                        if first is None:
                            try: first = summarize_json(json.loads(line), max_items=20)
                            except Exception: first = {"parse_error": True}
            return {"kind": ext[1:].upper(), "nonempty_records": count, "first_record_schema": first}
        if ext in {".py", ".cpp", ".h", ".hpp", ".ps1"}:
            text = path.read_text(encoding="utf-8", errors="replace")
            funcs = re.findall(r"(?m)^\s*(?:def|class|static\s+(?:inline\s+)?[\w:<>,*& ]+)\s+([A-Za-z_]\w*)", text)
            metric_tokens = [k for k in ["observer", "measure", "metric", "fingerprint", "first_passage", "reachability", "clock", "raw", "state", "s_reg", "semantic", "direction", "occupancy"] if k.lower() in text.lower()]
            return {"kind": "SOURCE", "functions_or_classes": funcs[:150], "measurement_tokens": metric_tokens}
        if ext == ".csv":
            with path.open("r", encoding="utf-8-sig", errors="replace", newline="") as f:
                reader = csv.reader(f)
                header = next(reader, [])
                sample_rows = 0
                for _ in reader:
                    sample_rows += 1
                    if sample_rows >= 3:
                        break
            return {"kind": "CSV", "columns": header[:200], "sample_rows_read": sample_rows}
    except Exception as exc:
        return {"kind": ext[1:].upper(), "metadata_error": type(exc).__name__}
    return None


def scan_corpus() -> tuple[list[dict], dict]:
    all_files = sorted(p for p in TESTS.rglob("*") if p.is_file() and OUT_DIR not in p.parents)
    entries = []
    hashes = defaultdict(list)
    vital_files = {p.resolve() for p in VITAL.rglob("*") if p.is_file() and OUT_DIR not in p.parents}
    vital_dirs = {p.resolve() for p in VITAL.rglob("*") if p.is_dir() and OUT_DIR not in p.parents}
    ext_counts = Counter()
    ext_bytes = Counter()
    ingestion = Counter()
    for idx, p in enumerate(all_files, 1):
        st = p.stat()
        ext = p.suffix.lower()
        digest = sha256_path(p)
        hashes[digest].append(str(p))
        ext_counts[ext or "<none>"] += 1
        ext_bytes[ext or "<none>"] += st.st_size
        in_vital = p.resolve() in vital_files
        relevant = in_vital or ext in SCI_EXT
        if relevant:
            if ext in {".npz", ".npy"}:
                status = "INGESTED_ARRAY_METADATA"
            elif ext in {".zip", ".whl", ".docx"}:
                status = "INGESTED_CONTAINER_OR_DOCUMENT"
            elif ext in TEXT_EXT or ext in {".pdf", ".pyd", ".gz"}:
                status = "INGESTED_OR_CROSS_REFERENCED"
            else:
                status = "CROSS_REFERENCED"
            exclusion = None
            ingestion["scientifically_relevant"] += 1
            ingestion["ingested"] += 1
        else:
            status = "DISCOVERED_NOT_INGESTED"
            if ext in DERIVATIVE_EXT:
                exclusion = "render/cache/derived visual or transient; hashed and retained in inventory, not treated as independent scientific evidence"
            else:
                exclusion = "format outside declared scientific source set; hashed and retained in inventory"
            ingestion["excluded"] += 1
        entries.append({
            "path": str(p),
            "filename": p.name,
            "size": st.st_size,
            "sha256": digest,
            "modified_utc": dt.datetime.fromtimestamp(st.st_mtime, dt.timezone.utc).isoformat(),
            "type": ext or "<none>",
            "roots": [x for x, yes in [("VITAL_FILES", in_vital), ("TEST_OPERATIONAL", True)] if yes],
            "campaign": infer_campaign(str(p)),
            "kernel_version": "v27" if "v27" in str(p).lower() else None,
            "parent": str(p.parent),
            "child": None,
            "duplicate_of": None,
            "scientific_relevance": relevant,
            "content_scientific_approximate": approx_content(p),
            "ingestion_status": status,
            "exclusion_reason": exclusion,
            "structured_ingestion": structured_metadata(p, ext) if relevant and ext in {".npz", ".npy", ".json", ".jsonl", ".ndjson", ".py", ".cpp", ".h", ".hpp", ".ps1", ".csv"} else None,
        })
        if idx % 2000 == 0:
            print(f"indexed {idx}/{len(all_files)}")
    first = {h: paths[0] for h, paths in hashes.items()}
    for e in entries:
        paths = hashes[e["sha256"]]
        if len(paths) > 1 and e["path"] != first[e["sha256"]]:
            e["duplicate_of"] = first[e["sha256"]]
    coverage = {
        "generated_utc": BUILD_TIME,
        "vital_root_found": str(VITAL),
        "vital_root_name_as_found": VITAL.name,
        "vital_root_search_result": "No second directory named ARCHIVOS VITALES/documentos vitales/documantacion vital was found under D:\\GENESIS AI\\GENESIS 5.0; this is the real project root matching the requested corpus.",
        "vital": {
            "folders_recursed": len(vital_dirs),
            "files_found": len(vital_files),
            "bytes": sum(p.stat().st_size for p in vital_files),
            "scientifically_relevant": sum(1 for e in entries if "VITAL_FILES" in e["roots"] and e["scientific_relevance"]),
            "duplicates_by_hash": sum(1 for e in entries if "VITAL_FILES" in e["roots"] and e["duplicate_of"]),
            "ingested": sum(1 for e in entries if "VITAL_FILES" in e["roots"] and e["scientific_relevance"]),
            "excluded": [
                {"path": e["path"], "reason": e["exclusion_reason"]}
                for e in entries if "VITAL_FILES" in e["roots"] and not e["scientific_relevance"]
            ],
        },
        "test_operational": {
            "root": str(TESTS),
            "folders_recursed": sum(1 for p in TESTS.rglob("*") if p.is_dir() and OUT_DIR not in p.parents),
            "files_found": len(entries),
            "bytes": sum(e["size"] for e in entries),
            "scientifically_relevant": ingestion["scientifically_relevant"],
            "ingested_or_cross_referenced": ingestion["ingested"],
            "excluded_count": ingestion["excluded"],
            "exclusion_policy": {
                "derived_visual_cache": "PNG/JPG/GIF/HTML/PGM/PYC/TMP are hashed and inventoried but not counted as independent evidence unless embedded in an official package.",
                "unknown_extension": "Hashed and inventoried; excluded from semantic ingestion when outside the declared scientific formats.",
            },
        },
        "extension_counts": dict(ext_counts.most_common()),
        "extension_bytes": dict(ext_bytes.most_common()),
        "unique_sha256": len(hashes),
        "duplicate_file_instances": sum(len(v) - 1 for v in hashes.values()),
    }
    return entries, coverage


def summarize_json(obj, max_items=30):
    if isinstance(obj, dict):
        out = {"type": "object", "keys": list(obj.keys())[:100]}
        scalars = {}
        for k, v in obj.items():
            if isinstance(v, (str, int, float, bool)) or v is None:
                if len(str(v)) <= 500:
                    scalars[str(k)] = v
            if len(scalars) >= max_items:
                break
        out["scalar_sample"] = scalars
        return out
    if isinstance(obj, list):
        return {"type": "array", "length": len(obj), "first_item_type": type(obj[0]).__name__ if obj else None}
    return {"type": type(obj).__name__, "value": obj}


def archive_ingestion(vital_entries: list[dict]) -> tuple[list[dict], dict, dict[str, str]]:
    archive_index = []
    atoms = []
    extracted_texts = {}
    atom_no = 0
    key_rx = re.compile(r"(report|claim|ledger|result|theorem|equation|physics|quantum|entrelaz|relativ|hydro|thermo|observer|rosetta|current|synthesis|crosswalk|negative|gap|frontier)", re.I)
    for e in vital_entries:
        p = Path(e["path"])
        ext = p.suffix.lower()
        if ext == ".docx":
            text = read_docx(p)
            extracted_texts[str(p)] = text
            atom_no += 1
            atoms.append(make_atom(
                atom_no, str(p), None, e["sha256"], infer_campaign(str(p)), None, None,
                "document", "full DOCX XML text extraction", {"characters": len(text), "paragraphs": len([x for x in text.splitlines() if x.strip()])},
                "Documentary synthesis/derivation; claims require linkage to primary evidence.", None,
                current="Retained as historical/formal source; later primary evidence takes priority."
            ))
            archive_index.append({"archive": str(p), "kind": "DOCX", "text_characters": len(text), "ingestion": "FULL_TEXT_EXTRACTED"})
            continue
        if ext != ".zip":
            continue
        members = []
        with zipfile.ZipFile(p) as z:
            for zi in z.infolist():
                if zi.is_dir():
                    continue
                m = {"path": zi.filename, "size": zi.file_size, "compressed_size": zi.compress_size, "type": Path(zi.filename).suffix.lower()}
                deep = bool(key_rx.search(zi.filename)) or m["type"] in {".cpp", ".pyd", ".whl"}
                if deep and zi.file_size <= 30_000_000:
                    data = z.read(zi)
                    m["sha256"] = sha256_bytes(data)
                    m["ingestion"] = "DEEP"
                    typ = m["type"]
                    parsed = None
                    text = None
                    if typ in {".md", ".txt", ".py", ".cpp", ".csv", ".json", ".jsonl", ".ndjson", ".sha256"}:
                        text = data.decode("utf-8", "replace")
                    elif typ == ".docx":
                        try: text = read_docx_bytes(data)
                        except Exception: text = None
                    if typ == ".json" and text:
                        try: parsed = json.loads(text)
                        except Exception: parsed = None
                    if text is not None:
                        extracted_texts[f"{p}!{zi.filename}"] = text
                    atom_no += 1
                    atoms.append(make_atom(
                        atom_no, str(p), zi.filename, m["sha256"], infer_campaign(zi.filename + " " + p.name),
                        zi.filename if typ in {".py", ".cpp"} else None,
                        m["sha256"] if typ in {".py", ".cpp"} else None,
                        "archive member", "deep member extraction",
                        summarize_json(parsed) if parsed is not None else {"characters": len(text) if text is not None else None, "bytes": len(data)},
                        "Primary when member is result/telemetry/runner; documentary when report/synthesis.", None,
                        current="Cross-referenced by archive, member path and content hash."
                    ))
                else:
                    m["ingestion"] = "METADATA"
                members.append(m)
        archive_index.append({"archive": str(p), "sha256": e["sha256"], "members": members, "member_count": len(members)})
    return atoms, {"archives_and_documents": archive_index}, extracted_texts


def make_atom(n, source_file, internal, source_sha, campaign, runner, runner_sha, apparatus, intervention, measurement, supported, historical, current=None, controls=None, fresh=None, scope=None, equation=None, related=None):
    return {
        "evidence_id": f"E{n:06d}", "source_file": source_file, "source_internal_path": internal,
        "source_sha256": source_sha, "campaign": campaign, "kernel_version": "v27" if "27" in (campaign or "") or "27" in source_file.lower() else None,
        "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff" if "v27" in source_file.lower() or "27" in (campaign or "") else None,
        "runner": runner, "runner_sha256": runner_sha, "apparatus": apparatus, "initial_conditions": None,
        "intervention": intervention, "observer": None, "measurement": measurement, "numerical_result": measurement,
        "controls": controls, "fresh_status": fresh, "scope": scope, "equation_if_any": equation,
        "mechanism_supported": supported, "historical_interpretation": historical,
        "later_evidence": None, "current_interpretation": current,
        "interpretive_layer": "DIRECT_MEASUREMENT" if any(x in (internal or "").lower() for x in ["result", "telemetry", "holdout"]) else "DOCUMENTARY_OR_FORMAL",
        "related_evidence_ids": related or [],
    }


def add_curated_atoms(atoms: list[dict], vital_hashes: dict[str, str]) -> None:
    n = len(atoms)
    def add(source, internal, campaign, measurement, mechanism, layer, scope, equation=None, controls=None, fresh=None, historical=None, current=None):
        nonlocal n
        n += 1
        a = make_atom(n, source, internal, vital_hashes.get(source), campaign, internal, None, "frozen documented apparatus", "documented protocol", measurement, mechanism, historical, current=current, controls=controls, fresh=fresh, scope=scope, equation=equation)
        a["interpretive_layer"] = layer
        atoms.append(a)
    core17 = next((k for k in vital_hashes if Path(k).name.startswith("17_DEE")), "CORE17")
    core16 = next((k for k in vital_hashes if Path(k).name.startswith("16_DEE")), "CORE16")
    p01 = next((k for k in vital_hashes if Path(k).name.startswith("PROCESOS_01")), "PROCESOS01")
    p02 = next((k for k in vital_hashes if Path(k).name.startswith("PROCESOS_02")), "PROCESOS02")
    ent = next((k for k in vital_hashes if "Fundamentos operacionales" in k), "ENTANGLEMENT")
    add(str(CANON_CPP), None, "KERNEL_V27", {"cpp_sha256": sha256_path(CANON_CPP), "pyd_sha256": sha256_path(CANON_PYD)}, "Deterministic synchronous local map F_DEE over raw_a,clock_a.", "KERNEL_IDENTITY", "canonical v27 binary/source pair")
    add(core17, "CORE17_FINAL_REPORT.md", "CORE17", {"holdout_cases": 46, "operator_ticks_zero_mismatch": 86, "R0_new_ticks_zero_mismatch": 140}, "Exact task/domain-bounded causal closure R0; observer ecology.", "DIRECT_MEASUREMENT", "declared CORE17 apparatus")
    add(core17, "CORE17_FINAL_REPORT.md#definitive-closure", "CORE17", {"R0_FACTOR_bits_ordinary": 52, "fresh_worlds": 10, "steps": 406, "raw_or_reduced_clock_mismatches": 0, "clock_modulus": 304980}, "Ordinary-cell factorization preserves existence,s_reg,direction,semantic,clock phase in scope; semantic-4 retains full raw without clock.", "DIRECT_MEASUREMENT", "CORE17 factorization holdout")
    add(core16, "FINAL_HOLDOUTS/PROBABILITY_HOLDOUT_RESULTS.json", "CORE16", {"microstates": 27648, "macroclasses": 54, "branch_union": "576/576", "preparation_sensitive_pairs": "7/8"}, "Effective probability is deterministic pushforward under a preparation measure; no Born form observed.", "DIRECT_MEASUREMENT", "CORE16 finite ensemble apparatus", equation="P(R=r)=C(k,r)p^r(1-p)^(k-r)")
    add(p01, ".../CHARACTERIZATION_REPORT.md", "PROCESOS_01", {"N": 39, "tau50_early": 112, "tau99_early": 121, "tau50_late": 442, "tau99_late": 450, "raw_diff_t128": 58877, "sites": 59319, "clock_diff": 13}, "BA and P2 jointly modulate latency of a local-branching, toroidally coalescing expansive regime.", "DIRECT_MEASUREMENT", "BA/P1-P3 frozen apparatus", controls="H0-P2, HA-P2, HB-P1, HB-P3", fresh="FRESH_V1/V2 exact spatial covariance")
    add(p02, "SCIENTIFIC_REPORT.md", "PROCESOS_02", {"host_stop": 4, "component_sites": 14, "scaffold_sites": 12, "early_first_change": 113, "late_first_change": 442, "relative_to_tau99": -8, "early_terminal_state": 2, "late_terminal_state": 3, "diagnostic_reinstantiation": [2,0,2]}, "Endogenous BA transition reaches and transforms a preexisting CORE10 shared interface, producing history-conditioned persistent organizations and different one-tick futures.", "DIRECT_MEASUREMENT", "MAIN_S0 plus frozen spatial transforms", controls="H0/HA and parent timing", fresh="FRESH_V1/V2 exact spatial covariance")
    add(ent, None, "POST_CORE17_QUANTUM_FORMALISM", {"construction": "finite reversible sector -> permutation unitary -> logarithmic generator -> continuous Schrödinger-form representation"}, "Exact mathematical representation for a closed reversible sector; not an operational physical quantum identification.", "MATHEMATICAL_DERIVATION", "reversible finite sectors", equation="U_Q|X_j>=|F_Q(X_j)>; U_Q=exp(-i H_eff tau*/hbar*)")
    add(ent, None, "POST_CORE17_QUANTUM_FORMALISM", {"missing": ["operational M_Q", "validated H_A tensor H_B partition", "nonfactorizing DEE state under that map", "Born measure"]}, "Quantum entanglement requires additional instantiated mapping beyond relational nonseparability.", "FORMAL_CONSTRUCTION", "quantum bridge", historical="Older blanket 'quantum not instantiated' is too coarse after the reversible-sector construction.", current="Unitary sector formalism is instantiated mathematically; physical entanglement/Born remain uninstantiated.")


def kernel_constants() -> dict:
    return {
        "canonical_cpp": str(CANON_CPP), "canonical_cpp_sha256": sha256_path(CANON_CPP),
        "canonical_pyd": str(CANON_PYD), "canonical_pyd_sha256": sha256_path(CANON_PYD),
        "constants": [
            {"name":"K_LIMIT","value":9.887,"source_line":25,"use":"UMBRAL_CRISTALIZACION=floor(K_LIMIT^3); historical label, literal in source"},
            {"name":"V_NODES","value":8.0,"source_line":26,"use":"TENSION_ELECTROWEAK=(26-6)/8=2.5"},
            {"name":"E_EDGES","value":12.0,"source_line":27,"use":"TENSION_STRONG=(12*4)/(4-1)=16"},
            {"name":"F_FACES","value":6.0,"source_line":28,"use":"TENSION_ELECTROWEAK"},
            {"name":"D_MOORE","value":26.0,"source_line":29,"use":"neighborhood cardinality and rho_eff denominator"},
            {"name":"V_TETRA","value":4.0,"source_line":30,"use":"tetra signature/tension"},
            {"name":"UMBRAL_CRISTALIZACION","value":966,"source_line":34,"use":"vacuum gradient creation gate; integer floor of 9.887^3"},
            {"name":"P_KERNEL","value":19665,"source_line":35,"use":"s_reg cap scale, gradient divisor, DEMUX saturation"},
            {"name":"cap","value":19664,"source_lines":[220,440],"use":"P_KERNEL-1 saturation"},
            {"name":"UMBRAL_FUSION","value":19665,"source_line":36,"use":"overflow/fusion branch"},
            {"name":"TTL_ORFAN","value":194422,"source_line":37,"use":"raw state written to orphan semantic after DEMUX impact; distinct from ORPHAN_TTL"},
            {"name":"ORPHAN_TTL","value":9,"source_line":39,"use":"injection state for orphan bit"},
            {"name":"COMPLETE_CUBE_VECINOS","value":7,"source_line":40,"use":"hadron incomplete flag and write protection threshold"},
            {"name":"XNOR_MIN_ACTIVE","value":8,"source_line":41,"use":"vacuum XNOR genesis"},
            {"name":"XNOR_PAIRS_TOTAL","value":13,"source_line":42,"use":"opposite Moore-pair equality"},
            {"name":"clock_period_numerator","value":782,"source_line":358,"use":"period=floor(782/(8-n_active)) for s_reg increment"},
            {"name":"Q","value":391,"origin":"782/2 and documented recurrence family","use":"phase landmark, not a free kernel constant"},
            {"name":"R0_clock_modulus","value":304980,"origin":"CORE17=lcm(195,260,391,782)","use":"minimum global modulus for the validated ordinary-cell factor family"},
        ],
        "packing": {"state_bits":[0,31],"s_reg_bits":[32,47],"dx_bits":[48,51],"dy_bits":[52,55],"dz_bits":[56,59],"semantic_bits":[60,63],"direction_encoding":"signed 4-bit two's-complement decoded by sign extension"},
        "semantic_values": {"0":"void","1":"normal","2":"electron_seed label","3":"proton_seed label","4":"observer/fixed raw branch","5":"orphan bit","6":"horizon","7":"XNOR-born"},
        "branch_order": ["semantic=4 fixed raw, clock+1", "scan Moore-26", "vacuum crystallization", "vacuum XNOR genesis", "vacuum directional incoming reducer SYM1", "vacuum remains void", "matter local density/tetra branch", "write protection and 782/(8-n) clocked s_reg", "fusion overflow/DEMUX destination", "direction gradient anchoring", "postpass DEMUX deltas"],
    }


FDEE_MD = r"""# F_DEE canónico — kernel v27

## Identidad

La referencia ejecutable es el `.pyd` SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`; el source empaquetado auditado tiene SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`. El mapa público es determinista y sincrónico:

`X_{t+1}=F_DEE(X_t)`, con `X=(raw_a,clock_a)` sobre `Ω_N=Z_N^3`.

`raw_b/clock_b` son buffers de implementación, no grados causales adicionales. Cada `raw` empaqueta `state[32]`, `s_reg[16]`, tres direcciones signed-nibble `[4+4+4]` y `semantic[4]`. `clock` es `uint64` separado.

## Localidad y orden

Cada celda consulta Moore-26 a distancia Chebyshev uno, aplica las ramas en el orden del source y luego recibe deltas DEMUX acumulados. La causalidad microscópica por tick está acotada por self+Moore-26; sobre el toro, `d∞` usa distancia modular. El reducer SYM1 agrega conmutativamente todas las fuentes direccionales que apuntan al destino: una fuente conserva su raw; varias saturan `s_reg` en 19664 y toman el signo de la suma vectorial.

## Vacío y materia

`state=0` no equivale a ausencia de dinámica: puede cristalizar por gradiente, nacer por XNOR o recibir una fuente direccional. La rama material calcula firma tetraédrica, `rho_eff=n_active*T_local/26`, redondea a `rule_value`, actualiza `s_reg` según fase de clock salvo protección, puede emitir un delta de fusión y ancla dirección al gradiente cuando corresponde. Los nombres `electron_seed`, `proton_seed`, `observer`, `horizon` son semánticas internas; no constituyen por sí mismos Rosetta externa.

## Inyectividad

El mapa global contiene ramas many-to-one y no es unitario globalmente. Sí admite subconjuntos cerrados reversibles donde su restricción es una permutación. Esta coexistencia sostiene sectores disipativos/informacionales y sectores reversibles sin contradicción.
"""


def equation_registry() -> list[dict]:
    return [
        {"equation_id":"EQ-K01","form":"X_(t+1)=F_DEE(X_t)","variables":"X=(raw_a,clock_a)","domain":"all valid v27 worlds","origin":"canonical source","class":"KERNEL EXACT","evidence_ids":[]},
        {"equation_id":"EQ-K02","form":"raw=e+(s_reg<<32)+((dx&15)<<48)+((dy&15)<<52)+((dz&15)<<56)+((semantic&15)<<60)","variables":"packed voxel fields","domain":"v27 raw","origin":"dee_kernel_v27.cpp:117-124","class":"KERNEL EXACT","evidence_ids":[]},
        {"equation_id":"EQ-K03","form":"rho_eff=n_active*T_local/26; state'=round(rho_eff)","variables":"n_active,T_local","domain":"occupied material branch","origin":"dee_kernel_v27.cpp:338-342","class":"KERNEL EXACT","evidence_ids":[]},
        {"equation_id":"EQ-K04","form":"period=floor(782/(8-n_active)); s_reg'=s_reg+1 if clock mod period=0","variables":"clock,n_active","domain":"unprotected occupied cells with 1<=8-n_active<=8","origin":"dee_kernel_v27.cpp:350-364","class":"KERNEL EXACT","evidence_ids":[]},
        {"equation_id":"EQ-G01","form":"d_∞^T(x,y)=max_i min(|x_i-y_i|,N-|x_i-y_i|)","variables":"toroidal coordinates","domain":"native grid geometry","origin":"kernel topology + CORE first passage","class":"DERIVADA EXACTA","evidence_ids":[]},
        {"equation_id":"EQ-C01","form":"T_first(x)>=d_∞^T(x,S_0)","variables":"first passage, initial causal support","domain":"self+Moore-26 causal propagation","origin":"locality theorem and Procesos 01","class":"DERIVADA EXACTA","evidence_ids":[]},
        {"equation_id":"EQ-H01","form":"H_(0:t) -> O_t=X_t -> F_t={responses to frozen challenges/horizons}","variables":"history, present organization, reachability fingerprint","domain":"task-relative reachability experiments","origin":"Ingeniería 04.5-06","class":"EMPÍRICA OPERACIONAL","evidence_ids":[]},
        {"equation_id":"EQ-P01","form":"P(Y=y)=mu({X: M(F^h(X))=y})","variables":"preparation measure mu, observer M","domain":"declared finite ensembles","origin":"CORE16/17 pushforward","class":"DERIVADA EXACTA","evidence_ids":[]},
        {"equation_id":"EQ-P02","form":"P(R=r)=C(k,r)p^r(1-p)^(k-r)","variables":"independent branch preparation","domain":"validated branch-union predictor","origin":"CORE17","class":"EMPÍRICA+DERIVADA EN APARATO","evidence_ids":[]},
        {"equation_id":"EQ-R01","form":"M(F^tau X)=G(M(X))","variables":"microdynamics, observer, effective law","domain":"only where closure is measured","origin":"multilevel framework","class":"FORMAL CONSTRUCTION","evidence_ids":[]},
        {"equation_id":"EQ-Q01","form":"U_Q|X_j>=|F_Q(X_j)>","variables":"closed reversible sector S_Q","domain":"finite S_Q with bijective F_Q","origin":"Fundamentos operacionales DEE","class":"DERIVADA EXACTA","evidence_ids":[]},
        {"equation_id":"EQ-Q02","form":"U_Q=exp(-i H_eff tau*/hbar*)","variables":"unitary permutation and logarithm branch","domain":"reversible sector representation","origin":"quantum effective-regime document","class":"FORMAL CONSTRUCTION EXACTA","evidence_ids":[]},
        {"equation_id":"EQ-Q03","form":"i hbar* dψ/dt=H_eff ψ","variables":"continuous representation","domain":"scaled continuum representation of U_Q","origin":"quantum effective-regime document","class":"EFECTIVA/CONDICIONAL","evidence_ids":[]},
        {"equation_id":"EQ-Q04","form":"omega(k)^2=omega0^2+c*^2|k|^2+O(k^4); m*=hbar* omega0/c*^2","variables":"spectral dispersion","domain":"only if a measured sector has the stated low-k dispersion","origin":"quantum annex","class":"APROXIMADA CONDICIONAL","evidence_ids":[]},
        {"equation_id":"EQ-E01","form":"Schmidt_rank(Ψ_AB)>1","variables":"M_Q(X_AB) in H_A tensor H_B","domain":"requires operational M_Q and bipartition","origin":"entanglement documents/standard criterion","class":"FORMAL BRIDGE NOT INSTANTIATED","evidence_ids":[]},
        {"equation_id":"EQ-T01","form":"S_M=-sum_c p_c log p_c","variables":"observer macroclass probabilities","domain":"declared ensemble/coarse-graining","origin":"information-theoretic construction","class":"EFECTIVA","evidence_ids":[]},
    ]


def supersession_graph() -> dict:
    return {"generated_utc": BUILD_TIME, "edges": [
        {"old_statement":"M0/M1 reductions do not close generally","new_evidence":"CORE16/17 exact domain-specific R0 and R0_FACTOR_52 holdouts","current_interpretation":"No universal tiny quotient was found; exact sector/domain closures exist and must not be extrapolated."},
        {"old_statement":"hidden information is lost","new_evidence":"CORE14-17 hidden clock/phase/path readouts and delayed return","current_interpretation":"Observer-hidden is distinct from dynamically destroyed; only explicit many-to-one convergence demonstrates destruction."},
        {"old_statement":"no endogenous post-host consequence","new_evidence":"Procesos 01 late HB_FULL expansion and Procesos 02 preexisting-interface response","current_interpretation":"BA-conditioned kernel-only dynamics produce an expansive transition and a subsequent future-relevant persistent organization."},
        {"old_statement":"P2 amplifies/globalizes HB","new_evidence":"early OMIT_P2 tau99=121 and late FULL tau99=450 with event-aligned family","current_interpretation":"P2 participates nonadditively in BA organization and modulates access latency; it is not a sufficient global source."},
        {"old_statement":"HB-P1/P3 do not show comparable expansion","new_evidence":"extension from <=256 to 512 ticks","current_interpretation":"The old statement is window-bounded; FULL crosses 50% at 442 and 99% at 450."},
        {"old_statement":"stabilization is a second experience","new_evidence":"Procesos 02 continuation and fixed RAW terminal states","current_interpretation":"The first stabilization is relaxation; the preexisting interface then supports a separately measured state 1->2->3 chain and changed diagnostic futures."},
        {"old_statement":"quantum is wholly uninstantiated","new_evidence":"post-CORE17 reversible-sector permutation/unitary/H_eff derivation","current_interpretation":"A unitary mathematical sector representation is instantiated; operational M_Q, Born and entanglement remain uninstantiated."},
        {"old_statement":"no probability physics","new_evidence":"CORE16/17 exact pushforward and branch-union finite ensemble results","current_interpretation":"Effective preparation-dependent probability is measured; no specifically quantum probability law was obtained."},
        {"old_statement":"interface is passive","new_evidence":"Procesos 02 event-aligned state changes and 2/0/2 reinstantiation futures","current_interpretation":"The interface is a preexisting causally coupled degree of freedom; its geometry can remain fixed while state/function changes."},
        {"old_statement":"a null result excludes a DEE mechanism","new_evidence":"later horizons/apparatuses revealed window- and context-dependent effects","current_interpretation":"All negatives are scoped by kernel, apparatus, observer, initial state and horizon."},
    ]}


def reality_graph() -> dict:
    return {"reference":"X_FULL=(raw_a,clock_a)","nodes":[
        {"id":"X_FULL","keeps":"complete public causal microstate","loses":"implementation scratch only"},
        {"id":"R0","keeps":"exact multistep causal factors in validated domains","loses":"raw detail proven irrelevant only within domain"},
        {"id":"R1","keeps":"routes, destination fibers, first passage, event/phase","loses":"non-route microdetail"},
        {"id":"R2_REL","keeps":"relations/topology/history-sensitive function","loses":"many microscopic realizations"},
        {"id":"R2_FUNC","keeps":"task-relative response/reinstantiation","loses":"mechanism detail not needed by task"},
        {"id":"R3","keeps":"ensemble/macroclass distribution and scale","loses":"individual microstate identity"},
    ],"edges":[
        {"from":"X_FULL","to":"R0","status":"EXACT_IN_DOMAIN"},
        {"from":"X_FULL","to":"R1","status":"ALREADY_MEASURED"},
        {"from":"X_FULL","to":"R2_REL","status":"ALREADY_MEASURED"},
        {"from":"X_FULL","to":"R2_FUNC","status":"ALREADY_MEASURED"},
        {"from":"X_FULL","to":"R3","status":"ALREADY_MEASURED_WITH_DECLARED_MEASURE"},
    ],"principles":["R1/R2/R3 are branches, not universal ontological floors.","Equality under a projection is not causal equality.","Hidden != destroyed; destruction needs demonstrated many-to-one convergence.","Future-informed observers must not be read as instantaneous state projections."]}


def physics_graph() -> dict:
    nodes = ["F_DEE","microstate","causal_response","matter","geometry","time_phase","history","observer","effective_probability","resource","relaxation","reversible_sector","unitary_representation","quantum_sector","entanglement","classical_limit","metric_sector","relativistic_sector","thermodynamic_sector","hydrodynamic_sector","field_gauge_sector","endogenous_processing"]
    E=[]
    def edge(a,b,status,evidence,domain,assumptions="none"):
        E.append({"from":a,"to":b,"status":status,"source_evidence":evidence,"equation_ids":[],"domain":domain,"assumptions":assumptions,"observer":"declared per evidence","scale":"declared per evidence"})
    edge("F_DEE","microstate","DERIVABLE_FROM_KERNEL",["canonical cpp/pyd"],"all v27")
    edge("microstate","causal_response","MEASURED_AND_DERIVED",["CORE first passage","Procesos 01"],"local Moore-26")
    edge("causal_response","geometry","ALREADY_MEASURED",["V6/V7","CORE","Procesos 01"],"toroidal L∞ and state-dependent media")
    edge("microstate","matter","ALREADY_MEASURED",["CORE03-14","Ingenierías"],"persistent/mobile organizations")
    edge("microstate","time_phase","MEASURED_AND_DERIVED",["kernel","CORE14-17"],"clocked branches and residuals")
    edge("microstate","history","ALREADY_MEASURED",["Ingeniería 01-06"],"history encoded in current organization")
    edge("history","causal_response","ALREADY_MEASURED",["Ingeniería 05/06"],"frozen reachability panels")
    edge("history","endogenous_processing","ALREADY_MEASURED",["Procesos 01/02"],"BA transition/interface chain")
    edge("observer","effective_probability","EXACT_IN_DOMAIN",["CORE16/17"],"finite prepared ensembles")
    edge("F_DEE","reversible_sector","DERIVABLE_FROM_KERNEL",["ballistic/permutation sectors","quantum formal documents"],"closed bijective subsets")
    edge("reversible_sector","unitary_representation","DERIVABLE_FROM_KERNEL",["Fundamentos operacionales"],"permutation basis")
    edge("unitary_representation","quantum_sector","FORMAL_BRIDGE_NOT_INSTANTIATED",["quantum annex"],"requires operational M_Q and measured dispersion")
    edge("quantum_sector","entanglement","FORMAL_BRIDGE_NOT_INSTANTIATED",["entanglement documents"],"requires bipartition and Schmidt-rank test")
    edge("causal_response","metric_sector","TELEMETRY_EXISTS_NOT_REDUCED",["first passage/medium/interface corpus"],"sector-specific effective metric")
    edge("metric_sector","relativistic_sector","FORMAL_BRIDGE_NOT_INSTANTIATED",["Relación Universal"],"effective isotropy and moving-frame closure")
    edge("microstate","relaxation","ALREADY_MEASURED",["many-to-one/Procesos"],"declared basins")
    edge("relaxation","thermodynamic_sector","SECTOR_EXISTS_OBSERVER_MISSING",["CORE16/17","historical thermal packages"],"energy/temperature/balance variables unresolved")
    edge("causal_response","hydrodynamic_sector","TELEMETRY_EXISTS_NOT_REDUCED",["hydrodynamics/Navier corpus"],"continuity,current,stress,viscosity need common closure")
    edge("time_phase","field_gauge_sector","FORMAL_BRIDGE_NOT_INSTANTIATED",["clock quotient apparatus"],"local compensating redundancy not shown")
    return {"nodes":[{"id":x} for x in nodes],"edges":E}


def matter_sectors() -> dict:
    return {"definition":"DEE matter is a persistent or recurrent causal organization of packed states, directions, semantics, clock relations and neighborhood support; visual shape alone is insufficient.","sectors":[
        {"name":"carriers","evidence":"directed mobile organizations and destination fibers","status":"ALREADY_MEASURED"},
        {"name":"scaffolds_guards","evidence":"semantic-4 fixed-raw interfaces and guarded reconstruction","status":"ALREADY_MEASURED"},
        {"name":"XNOR_born_patterns","evidence":"opposite-pair symmetric vacuum genesis","status":"DERIVABLE_FROM_KERNEL_AND_MEASURED"},
        {"name":"persistent_assemblies","evidence":"basins, morphology, support and topology","status":"ALREADY_MEASURED"},
        {"name":"functional_organizations","evidence":"history-conditioned readout/reinstantiation","status":"ALREADY_MEASURED"},
        {"name":"expansive_regimes","evidence":"BA-conditioned local branching/coalescence and terminal dense states","status":"ALREADY_MEASURED"},
        {"name":"reaction_classes","evidence":["collision","annihilation","fusion/DEMUX","fragmentation","transmutation","configuration-dependent epistasis"],"status":"ALREADY_MEASURED_OR_KERNEL_DERIVABLE"},
    ],"cautions":["semantic labels are internal control fields, not external particle identities","occupancy is not mass","s_reg is not energy without a bridge","fixed support can hide functional change"]}


def completeness() -> dict:
    return {"allowed_statuses":["ALREADY_MEASURED","DERIVABLE_FROM_KERNEL","MEASURED_AND_DERIVED","TELEMETRY_EXISTS_NOT_REDUCED","SECTOR_EXISTS_OBSERVER_MISSING","FORMAL_BRIDGE_NOT_INSTANTIATED","NEW_NATIVE_MEASUREMENT_REQUIRED","EXTERNAL_CALIBRATION_ONLY","SUPERSEDED_OLD_INTERPRETATION"],"items":[
        {"item":"microscopic update and packing","status":"MEASURED_AND_DERIVED","basis":"canonical source and binary identity"},
        {"item":"native causal cone/first passage","status":"MEASURED_AND_DERIVED","basis":"Moore-26 plus holdouts"},
        {"item":"R0 exact sectoral closure","status":"ALREADY_MEASURED","basis":"CORE16/17 holdouts"},
        {"item":"history-conditioned reachability","status":"ALREADY_MEASURED","basis":"Ingeniería 05/06"},
        {"item":"post-host endogenous transition and downstream degree","status":"ALREADY_MEASURED","basis":"Procesos 01/02"},
        {"item":"preparation-dependent effective probability","status":"ALREADY_MEASURED","basis":"CORE16/17"},
        {"item":"reversible permutation/unitary representation","status":"DERIVABLE_FROM_KERNEL","basis":"closed reversible sectors"},
        {"item":"physical quantum observer M_Q","status":"SECTOR_EXISTS_OBSERVER_MISSING","basis":"formal unitary sector but no operational map"},
        {"item":"Born rule","status":"NEW_NATIVE_MEASUREMENT_REQUIRED","basis":"pushforward exists; amplitude measure/symmetry not identified"},
        {"item":"entanglement","status":"FORMAL_BRIDGE_NOT_INSTANTIATED","basis":"Schmidt criterion specified; no operational bipartite state/readout"},
        {"item":"dispersion and effective mass","status":"TELEMETRY_EXISTS_NOT_REDUCED","basis":"carrier/phase telemetry exists; no frozen omega(k) sector extraction"},
        {"item":"effective Lorentzian geometry","status":"FORMAL_BRIDGE_NOT_INSTANTIATED","basis":"causal order exists; moving-frame/isotropy/metric scale closure missing"},
        {"item":"Einstein-like source response","status":"NEW_NATIVE_MEASUREMENT_REQUIRED","basis":"no coupled source_eff-curvature_eff law"},
        {"item":"information thermodynamics","status":"TELEMETRY_EXISTS_NOT_REDUCED","basis":"many-to-one, measures and relaxation exist"},
        {"item":"thermal thermodynamics","status":"SECTOR_EXISTS_OBSERVER_MISSING","basis":"no energy/temperature/heat balance identification"},
        {"item":"hydrodynamic continuum","status":"TELEMETRY_EXISTS_NOT_REDUCED","basis":"historical flow packages need common continuity/momentum/stress reduction"},
        {"item":"gauge sector","status":"FORMAL_BRIDGE_NOT_INSTANTIATED","basis":"specific clock quotient is not local gauge symmetry"},
        {"item":"external physical calibration","status":"EXTERNAL_CALIBRATION_ONLY","basis":"internal laws need units/access/predictions"},
    ]}


CURRENT_PHYSICS = r"""# Física interna DEE vigente

## Resumen físico

DEE v27 es una dinámica determinista, sincrónica y local sobre una retícula toroidal tridimensional finita. Su estado causal público completo es `X_FULL=(raw_a,clock_a)`. La física microscópica no se divide de origen en “materia”, “campo” y “memoria”: un mismo registro empaqueta estado, acumulador `s_reg`, dirección y semántica, mientras un reloj local separado participa en ramas de actualización. Las categorías macroscópicas aparecen como organizaciones, relaciones, cocientes y ensembles de esa dinámica.

La imagen vigente es una sola dinámica con múltiples sectores. Existen sectores many-to-one, relajantes y dependientes del observer; sectores de transporte y organización persistente; y subconjuntos reversibles cuya representación lineal es unitaria. Ninguna física externa es global por decreto.

## Ley microscópica

`F_DEE` lee self+Moore-26 sobre `Z_N^3`, aplica una secuencia fija de ramas y escribe sincrónicamente. El vacío puede permanecer vacío, cristalizar por gradiente, generar un patrón XNOR o recibir transporte dirigido. La materia ocupada responde al número de vecinos, firma tetraédrica, gradientes de `s_reg`, dirección, semántica y fase de clock. Un postpaso DEMUX aplica deltas con saturación. `P_KERNEL=19665`, `cap=19664`, el umbral literal de cristalización es 966, el numerador periódico es 782 y `TTL_ORFAN=194422` es distinto de `ORPHAN_TTL=9`.

La ley es Markoviana en `X_FULL`: toda consecuencia de una historia que pueda afectar el futuro debe estar contenida en el estado actual. “Historia” no requiere un campo separado; distintas trayectorias producen organizaciones actuales diferentes y por ello diferentes futuros.

## Causalidad y geometría

La localidad fundamental es self+Moore-26. El cono máximo por tick es Chebyshev; en el toro la distancia usa el mínimo modular. Los first-passage medidos respetan ese límite, incluso cuando una diferencia contrafactual alcanza casi toda una retícula: Procesos 01 reconstruyó ramificación local, múltiples frentes, coalescencia y wrapping toroidal sin aparición fuera del cono.

La geometría física nativa no es sólo coordenada. Las rutas, `s_reg`, guards, semánticas, direcciones e historia cambian latencias y reachability. Por eso `d∞` es un límite cinemático microscópico, mientras una distancia efectiva de viaje es una función del estado/medio. El corpus contiene causal order, first passage, support/volume y anisotropía; aún no contiene una métrica Lorentziana efectiva cerrada con moving frames.

## Tiempo y fase

`clock_a` avanza localmente por la regla, pero el clock absoluto no es automáticamente tiempo físico efectivo. Sus residuos activan periodos `floor(782/(8-n_active))`; relaciones mod 391/782 y, en el factor R0 validado, mod 304980, preservan información causal. Offsets comunes pueden ser irrelevantes en aparatos concretos y configuraciones relativas reaparecer después. Esto es una redundancia sectorial, no un gauge local universal.

El orden causal por ticks, la fase de branches y el tiempo de first passage son objetos distintos. Procesos 01/02 mostró que alinear por `tau99`, no por edad absoluta, identifica el contacto de dos transiciones separadas 329 ticks: el componente cambia exactamente en `tau99-8` en ambas.

## Materia, reacciones y organización

Materia DEE se define por persistencia/recurrente causal, no por parecido visual. Carriers, scaffolds, guards, patrones XNOR, ensamblajes persistentes e interfaces funcionales son sectores medidos. Las colisiones, fusión/DEMUX, fragmentación y transformaciones geometry-conditioned constituyen una química efectiva: sus productos dependen de configuración, orden, posición y contexto. `semantic=2/3` no basta para identificar electrones/protones externos.

La misma geometría gruesa puede ocultar distinta física: en Procesos 02, un componente mantiene 14 posiciones y semánticas constantes mientras sus dos centros cambian `state 1→2` o `1→2→3`; el readout de reinstanciación cambia `2/0/2`. Ocupación y soporte no son variables de estado suficientes.

## Historia, información y procesamiento

Ingeniería 05/06 estableció que AB y BA generan reachability diferente; la misma experiencia posterior transforma de modo distinto historias distintas; el efecto persiste, replica bajo transformaciones espaciales y admite múltiples actualizaciones sin reset. La carga causal llegó a 17 contribuciones individualmente future-relevant por omisión, con reutilización de regiones.

Procesos 01 añadió una transición expansiva BA condicionada: OMIT_P2 alcanza 50/99 % a 112/121 y FULL a 442/450. P2 no es un amplificador aislado; modula latencia dentro de una interacción no aditiva. Procesos 02 añadió continuidad causal: el frente alcanza una interfaz CORE10 existente desde t0, la modifica sin host y deja organizaciones persistentes con futuros diagnósticos distintos. En LATE aparece además `2→3` y recuperación funcional. Esta es física de procesamiento causal: `historia→organización→transición→nuevo grado→nuevos futuros`, no una prueba de una arquitectura computacional clásica.

## Observers y realidad multirrepresentación

`X_FULL` es la referencia completa pública. R0 proporciona cierre exacto sólo en sus dominios; R1 conserva rutas/fibers/first passage; R2 conserva relación o función; R3 conserva distribuciones de ensembles. Son ramas, no una escalera ontológica universal. Un observer puede ocultar dirección, fase, clock, ruta o historia sin destruirlas. Destrucción exige convergencia many-to-one demostrada.

El observer más compacto depende de la tarea. Una firma relacional puede predecir una función con pocos bits y ser incapaz de reconstruir el microestado. Un observer future-informed puede “ver” un cambio antes de que cambien los registros locales porque incorpora reachability; no debe confundirse con percepción instantánea.

## Probabilidad y flecha temporal

El kernel es determinista. La probabilidad efectiva aparece al empujar una medida de preparación sobre microestados compatibles por `F_DEE` y un observer. CORE16/17 cartografió 27 648 microestados en 54 macroclases; branch-union fue exacto 576/576 y 7/8 pares cambiaron con la preparación. Esto es probabilidad objetiva respecto de un protocolo/ignorancia declarados, no una regla de Born.

Las ramas many-to-one y los cocientes producen pérdida de distinguibilidad y una flecha informacional. Relajación, histéresis y basins añaden irreversibilidad efectiva. No hay todavía una identificación validada de energía, temperatura, calor o entropía térmica; la entropía de macroclases es informacional.

## Sector reversible y representación cuántica

La no inyectividad global no impide sectores `S_Q` cerrados donde `F_Q` es biyectiva. En una base de estados, una permutación induce exactamente un operador unitario `U_Q`. Elegir una rama del logaritmo define `H_eff`, y una familia escalada admite una ecuación diferencial de forma Schrödinger. En el sector de traslación, esa ecuación describe transporte unitario; una ecuación masiva no relativista requiere además una dispersión medida con gap `omega0` y curvatura cuadrática.

Este avance actualiza, pero no contradice, el cierre experimental CORE17: la representación unitaria sectorial está matemáticamente instanciada; no lo están un `M_Q` físico no trivial, un tensor producto operacional `H_A⊗H_B`, un estado DEE con Schmidt rank >1 bajo ese mapa, observables Bell adecuados ni Born. El CHSH=-2 del aparato local previo es clásico y no puede promoverse a entrelazamiento.

## Clásica, relatividad, campos y gauge

Transporte de carriers, colisiones, respuesta de organizaciones e identidad funcional proporcionan piezas de una mecánica clásica efectiva. Falta una familia común con conservación y susceptibilidad que cierre masa/inercia/fuerza sin etiquetas ad hoc.

La causalidad discreta y la métrica de viaje preparan una geometría efectiva. Para relatividad faltan isotropización controlada, relaciones entre observers móviles, proper-time-like readout y cierre métrico. Para gravedad falta medir conjuntamente una variable `source_eff`, respuesta geométrica/curvatura y ley de movimiento. Las derivaciones Einstein-Hilbert existentes son condicionales, no instancias desde el kernel.

Dirección, clock/phase y redundancias de observer son precursores de campos/gauge. No se identificó un grupo local con compensadores ni representaciones DEE de U(1), SU(2) o SU(3). Los documentos Dirac/Yang–Mills son puentes formales pendientes de instanciación.

## Termodinámica e hidrodinámica

DEE posee ingredients internos: many-to-one, ensembles, relajación, recursos, trayectorias y respuestas colectivas. Una termodinámica interna exige variables de balance y conjugación; una hidrodinámica exige densidad/current conservados, continuidad, transporte de momento, stress y viscosidad en un mismo sector. El corpus histórico contiene paquetes “termodinámica” y “Navier–Stokes”, pero sus etiquetas no sustituyen ese cierre. Sus datos quedan como telemetría a reducir, no como leyes externas ya identificadas.

## Reparación, homeostasis y ecología causal

XNOR, redundancy training, carriers y shared interfaces permiten reparación y reinstanciación funcional. CORE17 mostró reparación apoyada por una copia aprendida y una ruta explícita; no autorregeneración remota. CORE10/14 y Procesos 02 muestran sistemas acoplados sin necesidad de una frontera organismo/entorno: entorno es el conjunto de grados causalmente accesibles cuya evolución cambia las posibilidades futuras.

## Física no mapeada

Quedan mecanismos DEE-native sin equivalente externo cerrado: retorno retardado de información de clock/fase, modulación histórica de latencia, divergencia global entre organizaciones de igual ocupación, reparación task-relative y transición expansiva con ramificación/coalescencia. Deben conservar sus descripciones DEE antes de una Rosetta.

## Frontera exacta

La física interna está cerrada a nivel de regla microscópica y posee leyes sectoriales fuertes. No está cerrada como teoría efectiva única. Los bordes concretos son: observer cuántico operacional, dispersión medida, métrica móvil, balance termodinámico, cierre hidrodinámico, gauge local y calibración externa común. Cada borde está formulado en `EXACT_MISSING_EDGES.md` sin convertirlo en un negativo universal.
"""


QUANTUM_MD = r"""# Cadena cuántica y de entrelazamiento

| Flecha | Estado vigente | Evidencia / condición |
|---|---|---|
| `X → S_Q` | Sectorial | Existen dinámicas reversibles/permutacionales; falta una selección física universal. |
| `S_Q → U_Q` | Derivación exacta | Toda permutación finita induce una matriz unitaria en la base de estados. |
| `U_Q → H_eff` | Formal exacta con rama | `H_eff=(i hbar*/tau*) log U_Q`; la rama forma parte de la especificación. |
| `H_eff → Schrödinger` | Efectiva/condicional | Forma diferencial de una familia escalada; transporte exacto para traslación. |
| `ω(k) → m*` | No instanciada empíricamente | Requiere dispersión medida, gap y curvatura estables; `m*=hbar*ω0/c*²` es condicional. |
| `X_AB → M_Q(X_AB)` | Observer no identificado | Debe cerrar la dinámica y tener lectura operacional. |
| `M_Q → H_A⊗H_B` | Puente no instanciado | La partición debe conservar observables relevantes. |
| `Ψ_AB → Schmidt rank>1` | Criterio formal | No se ha aplicado a un `M_Q` DEE preregistrado no trivial. |
| amplitudes → Born | Medición nueva necesaria | Pushforward clásico existe; falta una medida/simetría que produzca módulos cuadrados. |

Relación microscópica distribuida, contextualidad, fase y hidden-state son prerrequisitos/análogos, no equivalencia automática con entrelazamiento. El resultado Bell previo `CHSH=-2` pertenece al aparato clásico local probado.
"""


RELATIVITY_MD = r"""# Cadena causal, geométrica y relativista

1. `F_DEE` fija localidad self+Moore-26 y orden discreto.
2. First passage define una distancia/tiempo causal dependiente de medio; `d∞` toroidal es el límite mínimo geométrico.
3. Destination fibers, shielding y rutas convierten la retícula en un paisaje dirigido y dependiente de historia.
4. Causal order + volumen/support pueden determinar una clase conformal discreta sólo dentro de un sector/observer declarado.
5. Para una métrica Lorentziana efectiva faltan isotropía multiescala, observers móviles, reglas de reloj propio y cierre de intervalos.
6. Para gravedad faltan `source_eff`, respuesta geométrica y movimiento de prueba en la misma calibración.

Los documentos de Relación Universal aportan el puente formal `R_DEE→causal order→[g_eff]`; la evidencia vigente instancia el primer tramo y partes del segundo, no Einstein como ley del kernel.
"""


THERMO_MD = r"""# Cadena termodinámica e hidrodinámica

## Instanciado

- Determinismo microscópico con ramas many-to-one.
- Ensembles y pushforward dependiente de preparación.
- Relajación, basins, pérdida de distinguibilidad y persistencia de historia.
- Variables de soporte, ocupación, `s_reg`, dirección, semántica y clock.
- Propagación, colisiones, fronts y respuestas colectivas en aparatos concretos.

## No reducido todavía

La termodinámica exige una variable de recurso/energía con balance, una temperatura o parámetro conjugado operacional, intercambio sistema-entorno y producción entrópica. La hidrodinámica exige identificar densidad/current conservados, continuidad, momentum transport, stress/pressure y viscosidad dentro de un sector continuo común. Los archivos históricos llamados “termodinámica” o “Navier” preservan telemetría y candidatos, pero la nomenclatura no constituye cierre.

La flecha temporal ya posee una base informacional: microestados distintos pueden converger bajo `F_DEE` o bajo un observer. Esto no convierte `occupancy` en entropía ni `s_reg` en energía.
"""


MATTER_MD = r"""# Cadena materia–historia–información

`raw/clock local → organización → relación → función → reachability`.

Una historia no reside necesariamente en una pieza: se incorpora porque modifica `X_FULL`, y el presente reorganizado cambia futuros. NRD04 mostró soporte RAW sinérgico 8/8 y sensibilidad valor/posición; NRD05/06 mostró transformación específica de historia; Ingeniería 06 acumuló al menos 17 contribuciones individualmente relevantes; Procesos 01/02 mostró transición endógena, latencia histórica, contacto con un grado preexistente y futuros de reinstanciación diferentes.

La materia DEE procesa información porque su dinámica transforma distinciones causales. La reparación/reinstanciación usa organización y rutas; la misma forma puede ser funcionalmente distinta y la misma función puede reinstanciarse en soporte distinto. `HIDDEN != DESTROYED` conecta memoria, coarse-graining y observer sin identificar automáticamente decoherencia cuántica.
"""


GENEALOGY_MD = r"""# Genealogía científica

- **v24–v25.5:** definición del packing, ramas materiales/vacío, corpus morfológico y primeras Rosetta. Muchas etiquetas externas eran hipótesis; los datos siguen siendo válidos en su kernel.
- **v26:** reducer SYM1 elimina dependencia del orden de fuentes y conserva una dinámica conmutativa de llegada.
- **v27:** fija `P_KERNEL=19665`, binario/source canónico y aparato reproducible.
- **CORE01–07:** teoría nativa, causalidad, observers, escalas y atlas experimental.
- **CORE08–14:** observers mínimos, aprendizaje/acoplamiento, Rosetta internas, ecología causal y múltiples relaciones.
- **CORE15:** observer shadows; fase, dirección, historia y clock pueden ocultarse selectivamente.
- **CORE16:** realidad multiescala, ensembles, pushforward y separación entre analogías quantum-like y estructura cuántica específica.
- **CORE17:** R0 exacto y `R0_FACTOR_52`, retorno de información oculta, probabilidad sectorial y reparación con copia aprendida; cierra sus aparatos, no toda posibilidad física.
- **Ingenierías 01–04.5:** memoria relacional, estabilidad/plasticidad, función/competencia, arquitectura causal distribuida y reachability.
- **Ingeniería 05:** historias específicas cambian futuros y transformaciones posteriores; configuración RAW no aditiva.
- **Ingeniería 06:** actualizaciones recurrentes, carga causal, dinámica RAW post-host y equivalence breaking.
- **Procesos 01:** BA accede a un régimen expansivo por propagación local y coalescencia; P2 modula latencia.
- **Procesos 02:** la transición alcanza una interfaz preexistente y produce estados persistentes, una segunda transformación LATE y futuros funcionales distintos.
- **Formalización cuántica posterior:** sectores reversibles admiten representación unitaria/Hamiltoniana; se separa este teorema de la todavía abierta identificación física de `M_Q`, Born y entrelazamiento.

La genealogía conserva resultados negativos con sus dominios; no los universaliza.
"""


MISSING_MD = r"""# Aristas exactas aún no cerradas

## MQ-01 — Observer cuántico operacional
**QUESTION:** ¿qué mapa preregistrado `M_Q` lleva una organización DEE no trivial a amplitudes/observables y cierra bajo `U_Q`?  
**WHY EXISTING DATA CANNOT ANSWER:** los sectores reversibles y la relación distribuida existen, pero no una lectura Hilbert operacional conjunta.  
**MINIMUM REQUIRED OBSERVABLES:** amplitud/fase, partición A/B, observables locales, conservación de norma, predicción fresh.  
**PARENT DATA:** reversible translation, CORE16/17 phase/ensemble, entanglement documents.  
**MINIMUM EXPERIMENT DESIGN:** seleccionar un sector ya reversible, congelar `M_Q` y partición antes del holdout, probar cierre y Schmidt rank. Runtime esperado: minutos, no sweep.

## QP-02 — Born
Falta una medida/simetría que derive probabilidades por módulo cuadrado y la contraste con el pushforward clásico existente. Requiere ensembles preregistrados sobre un `M_Q` ya cerrado; no puede resolverse sólo renombrando frecuencias.

## DISP-01 — Dispersión
Falta reducir telemetría de modos en un sector homogéneo a `ω(k)` con barras de error/fresh, para decidir transporte lineal, gap, curvatura y masa tensorial efectiva. Primero reanalizar telemetría existente; sólo después un paquete de onda mínimo si faltan series espacio-temporales.

## REL-01 — Métrica móvil
Faltan observers móviles, proper-time-like clock y colapso multiescala de anisotropía. Parent: first passage/causal cone/phase. Diseño mínimo futuro: un solo sector homogéneo con paquetes y frames congelados.

## GR-01 — Respuesta geométrica a fuente
No existe una medición conjunta de `source_eff`, cambio de causal order/metric y trayectoria de prueba con control sin fuente. Las derivaciones EH son condicionales.

## TH-01 — Balance termodinámico
Faltan energía/recurso extensivo, flujo ambiente, temperatura/conjugado y balance. Reanalizar primero `s_reg`, DEMUX y relajación; ninguna variable puede nombrarse por analogía.

## HY-01 — Cierre hidrodinámico
Faltan continuidad, momentum transport, stress y viscosidad sobre el mismo coarse-graining. Los paquetes Navier históricos contienen candidatos pero no un commuting diagram congelado.

## GA-01 — Simetría gauge local
Existe quotient de clock común en aparatos concretos; falta una familia local de transformaciones con compensadores y observables invariantes.

## EXT-01 — Calibración externa común
Faltan unidades/acceso y una predicción externa no usada, compartida por varios sectores sin refit independiente.
"""


ROSETTA_MD = r"""# Preparación de la siguiente Rosetta

| Objeto DEE | Observable efectivo | Teoría candidata | Correspondencia conocida | Grados DEE adicionales | Calibración externa | Predicción discriminante |
|---|---|---|---|---|---|---|
| Moore causal order | first passage / cone | geometría causal | límite L∞ exacto | medio, historia, fibers | longitud/tick | anisotropía y dispersión por escala sin refit |
| reversible sector | `U_Q,H_eff` | cuántica | permutación unitaria exacta | `M_Q`, partición, medida | hbar*, tiempo | espectro/estadística no reducible a pushforward clásico |
| many-to-one ensemble | macroclass probability | estadística | pushforward exacto | medida de preparación | protocolo | dependencia de medida predicha antes del ensayo |
| persistent organization | susceptibility/trajectory | mecánica clásica | carriers/collisions | conserved current | masa/longitud/tiempo | relación fuerza-respuesta común entre geometrías |
| history-shaped reachability | effective medium/metric | geometría/gravedad | latencia dependiente de organización | source_eff | scale map | cambio de first passage predicho por organización |
| relaxation/resources | balance variables | termodinámica | irreversibilidad informacional | energy/temperature observers | energy/temp | balance y producción no reducibles a occupancy |
| density/current modes | continuum fields | hidrodinámica | fronts/transport telemetry | stress/viscosity | continuum scale | Navier-like coefficients transfer across flows |
| clock quotient | phase connection | gauge | common-offset invisibility sectorial | local compensators | phase convention | holonomy/invariant response under local transforms |

La Rosetta debe avanzar DEE mechanism → invariant → mathematics → external theory, y reservar una predicción externa o interna no usada para discriminar.
"""


def numerical_registry(extracted_texts: dict[str,str]) -> dict:
    names = ["π_DEE", "K³/neutrino", "20 Hz", "Riemann", "Fibonacci-like", "19665", "391"]
    return {"policy":"Preserved as genealogy; promotion requires derivation from an established DEE mechanism and one common calibration.","entries":[
        {"name":"π_DEE","status":"UNCONNECTED_NUMERICAL_CORRESPONDENCE","corpus_mentions":sum(t.lower().count("π_dee")+t.lower().count("pi_dee") for t in extracted_texts.values())},
        {"name":"K³ / neutrino","status":"UNCONNECTED_NUMERICAL_CORRESPONDENCE","corpus_mentions":sum(t.lower().count("neutrino") for t in extracted_texts.values())},
        {"name":"20 Hz bridge","status":"HISTORICAL_EXTERNAL_ROSETTA","corpus_mentions":sum(t.lower().count("20 hz") for t in extracted_texts.values())},
        {"name":"Riemann","status":"HISTORICAL_GEOMETRIC_ANALOGY_AND_EXPERIMENT_LABEL","corpus_mentions":sum(t.lower().count("riemann") for t in extracted_texts.values())},
        {"name":"Fibonacci-like","status":"HISTORICAL_PATTERN_CORRESPONDENCE","corpus_mentions":sum(t.lower().count("fibonacci") for t in extracted_texts.values())},
        {"name":"P_KERNEL=19665","status":"KERNEL_LITERAL","corpus_mentions":sum(t.count("19665") for t in extracted_texts.values())},
        {"name":"Q=391","status":"DERIVED_RECURRENCE_LANDMARK","corpus_mentions":sum(t.count("391") for t in extracted_texts.values())},
    ]}


def build():
    if not VITAL.is_dir():
        raise SystemExit(f"Vital root not found: {VITAL}")
    if not CANON_CPP.is_file() or not CANON_PYD.is_file():
        raise SystemExit("Canonical kernel pair missing")
    work = Path(tempfile.mkdtemp(prefix="fisica_dee_uni1_"))
    try:
        inventory, coverage = scan_corpus()
        vital_entries = [e for e in inventory if "VITAL_FILES" in e["roots"]]
        vital_hashes = {e["path"]: e["sha256"] for e in vital_entries}
        atoms, archive_details, texts = archive_ingestion(vital_entries)
        add_curated_atoms(atoms, vital_hashes)
        # Attach archive/member detail only to the 41 vital entries to keep the master index compact but verifiable.
        by_archive = {x["archive"]: x for x in archive_details["archives_and_documents"]}
        for e in inventory:
            if e["path"] in by_archive:
                e["deep_ingestion"] = by_archive[e["path"]]

        products = {
            "CORPUS_MASTER_INDEX.json": {"generated_utc": BUILD_TIME, "roots": [str(VITAL), str(TESTS)], "files": inventory},
            "VITAL_FILES_COVERAGE.json": coverage,
            "SCIENTIFIC_SUPERSESSION_GRAPH.json": supersession_graph(),
            "KERNEL_CONSTANTS_AND_INTERACTIONS.json": kernel_constants(),
            "DEE_EQUATION_REGISTRY.json": equation_registry(),
            "DEE_REALITY_REPRESENTATION_GRAPH.json": reality_graph(),
            "DEE_NATIVE_PHYSICS_GRAPH.json": physics_graph(),
            "DEE_MATTER_SECTORS.json": matter_sectors(),
            "NUMERICAL_CORRESPONDENCE_REGISTRY.json": numerical_registry(texts),
            "DEE_PHYSICS_COMPLETENESS_MAP.json": completeness(),
        }
        for name, obj in products.items():
            write_json(work / name, obj)
        with (work / "EVIDENCE_ATOMS.jsonl").open("w", encoding="utf-8", newline="\n") as f:
            for a in atoms:
                f.write(json.dumps(a, ensure_ascii=False, sort_keys=False) + "\n")
        for name, text in {
            "F_DEE_CANONICAL.md": FDEE_MD,
            "CURRENT_DEE_INTERNAL_PHYSICS.md": CURRENT_PHYSICS,
            "QUANTUM_ENTANGLEMENT_CHAIN.md": QUANTUM_MD,
            "RELATIVITY_GEOMETRY_CHAIN.md": RELATIVITY_MD,
            "THERMODYNAMICS_HYDRODYNAMICS_CHAIN.md": THERMO_MD,
            "MATTER_HISTORY_INFORMATION_CHAIN.md": MATTER_MD,
            "EXACT_MISSING_EDGES.md": MISSING_MD,
            "SCIENTIFIC_GENEALOGY.md": GENEALOGY_MD,
            "ROSETTA_NEXT_STAGE.md": ROSETTA_MD,
        }.items():
            (work / name).write_text(text.strip() + "\n", encoding="utf-8")

        # Reproducible synthesis script and exact kernel source are included; binary is referenced by hash to avoid redundancy.
        shutil.copy2(Path(__file__), work / "build_fisica_dee_uni1.py")
        shutil.copy2(CANON_CPP, work / "dee_kernel_v27.cpp")

        file_rows = []
        for p in sorted(work.iterdir()):
            if p.name in {"MANIFEST.json", "HASHES.sha256"}:
                continue
            file_rows.append({"path": p.name, "size": p.stat().st_size, "sha256": sha256_path(p)})
        manifest = {
            "title":"FÍSICA DEE UNI 1 — reconstrucción transversal de la física interna DEE",
            "created_utc": BUILD_TIME,
            "method":"No new simulation. Recursive corpus hashing, archive/document ingestion, primary-evidence cross-reference, mathematical/source reconstruction.",
            "vital_root":str(VITAL), "test_root":str(TESTS),
            "kernel":{"pyd_sha256":sha256_path(CANON_PYD),"cpp_sha256":sha256_path(CANON_CPP)},
            "files":file_rows,
        }
        write_json(work / "MANIFEST.json", manifest)
        manifest_sha = sha256_path(work / "MANIFEST.json")
        lines = []
        for p in sorted(work.iterdir()):
            if p.name == "HASHES.sha256": continue
            lines.append(f"{sha256_path(p)}  {p.name}")
        (work / "HASHES.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8", newline="\n")

        # Create exactly one official directory and one official ZIP.
        OUT_DIR.mkdir(parents=False, exist_ok=True)
        if OUT_ZIP.exists():
            OUT_ZIP.unlink()
        with zipfile.ZipFile(OUT_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for p in sorted(work.iterdir()):
                z.write(p, p.name)
        # Integrity: open, CRC, required members, manifest hashes.
        required = set(products) | {"EVIDENCE_ATOMS.jsonl","F_DEE_CANONICAL.md","CURRENT_DEE_INTERNAL_PHYSICS.md","QUANTUM_ENTANGLEMENT_CHAIN.md","RELATIVITY_GEOMETRY_CHAIN.md","THERMODYNAMICS_HYDRODYNAMICS_CHAIN.md","MATTER_HISTORY_INFORMATION_CHAIN.md","EXACT_MISSING_EDGES.md","SCIENTIFIC_GENEALOGY.md","ROSETTA_NEXT_STAGE.md","MANIFEST.json","HASHES.sha256"}
        with zipfile.ZipFile(OUT_ZIP) as z:
            bad = z.testzip()
            missing = sorted(required - set(z.namelist()))
            if bad or missing:
                raise RuntimeError({"bad_crc":bad,"missing":missing})
        print(json.dumps({"output":str(OUT_ZIP),"size":OUT_ZIP.stat().st_size,"sha256":sha256_path(OUT_ZIP),"members":len(zipfile.ZipFile(OUT_ZIP).namelist()),"corpus_files":len(inventory),"evidence_atoms":len(atoms),"manifest_sha256":manifest_sha},ensure_ascii=False,indent=2))
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    build()
