from __future__ import annotations

import ast
import csv
import datetime as dt
import hashlib
import html
import io
import json
import math
import os
import re
import shutil
import statistics
import tempfile
import zipfile
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np


TESTS = Path(r"D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests")
VITAL = TESTS / "documantacion vital"
OFFICIAL_DIR = VITAL / "FISICA DEE UNI 1"
OFFICIAL_ZIP = OFFICIAL_DIR / "FISICA_DEE_UNI_1_RESULTADOS.zip"
NOW = dt.datetime.now(dt.timezone.utc).isoformat()
KERNEL_SHA = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"

ROOT_ZIPS = [p for p in TESTS.glob("*.zip") if p.name != OFFICIAL_ZIP.name]
SCI_EXT = {".json", ".jsonl", ".ndjson", ".npz", ".npy", ".csv", ".md", ".txt", ".py", ".cpp", ".h", ".hpp", ".docx", ".pdf", ".zip", ".whl"}
ADMIN_RX = re.compile(r"(^|/)(manifest|hashes?|sha256sums?|state|time_budget|runtime_environment|file_access_audit|render_qa)(\.|/|$)", re.I)
PRIMARY_RX = re.compile(r"(result|telemetr|holdout|claim|finding|atlas|measurement|timeline|first_passage|observer|physics|frontier|analysis|experiment|evidence)", re.I)
CONTROL_RX = re.compile(r"(control|omit|sham|ablati|counterfactual|negative_anchor|canary)", re.I)
FRESH_RX = re.compile(r"(fresh|holdout|replic|revalid|canonical)", re.I)


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def sha256_path(p: Path) -> str:
    h = hashlib.sha256()
    with p.open("rb") as f:
        for c in iter(lambda: f.read(8 * 1024 * 1024), b""):
            h.update(c)
    return h.hexdigest()


def write_json(p: Path, obj: Any) -> None:
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def docx_text(data: bytes) -> str:
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        x = z.read("word/document.xml").decode("utf-8", "replace")
    x = re.sub(r"<w:tab[^>]*/>", "\t", x)
    x = re.sub(r"</w:p>", "\n", x)
    x = re.sub(r"<[^>]+>", "", x)
    return html.unescape(x)


def family_of(name: str, text_hint: str = "") -> str:
    s = (name + " " + text_hint[:5000]).lower()
    rules = [
        ("PROCESOS_02", ["procesos_02", "process02"]),
        ("PROCESOS_01", ["procesos_01", "process01", "hb_p2"]),
        ("INGENIERIA_06", ["ingenieria_06", "ing06"]),
        ("INGENIERIA_05", ["ingenieria_05", "nrd0"]),
        ("POST_04_5", ["post_ingenieria_04_5", "post_ing04", "reorganizacion_nativa"]),
        ("INGENIERIA_04_5", ["ing04_5", "ingenieria_04_5", "arquitectura_causal_nativa"]),
        ("CORE17", ["core17", "17_dee_v27"]),
        ("CORE16", ["core16", "16_dee_v27"]),
        ("CORE15", ["core15", "15_dee_v27"]),
        ("CORE01_14_REVALIDATION", ["master_revalidation", "core01_to_14"]),
        ("FORMULA_BRIDGE", ["formula_bridge"]),
        ("GROUP_VELOCITY_PHASE", ["group_velocity", "phase_modes", "collective_phase"]),
        ("HYDRODYNAMICS", ["hydro", "navier", "fluid_continuum", "viscos"]),
        ("THERMODYNAMICS_RESOURCE", ["thermo", "entropy", "resource", "work_capacity", "sreg"]),
        ("RELATIVITY_GEOMETRY", ["relativ", "metric", "first_passage", "causal_cone", "tomograph", "riemann"]),
        ("QUANTUM_ENTANGLEMENT", ["quantum", "entrelaz", "schrod", "bell", "born", "unitary"]),
        ("TRANSFER_REINSTANTIATION", ["reinstanti", "teleport", "transfer", "transport", "transduc"]),
        ("MULTISCALE_MATTER", ["multiscale", "morphogen", "matter", "materia"]),
        ("V6_V7_NATIVE_PHYSICS", ["dee_v6", "dee_v7", "v7_c", "v6_e"]),
        ("KERNEL", ["dee_kernel", "kernel_v27"]),
    ]
    for fam, needles in rules:
        if any(n in s for n in needles):
            return fam
    m = re.search(r"(?:^|[/_])(?:0?([1-9]|1[0-4]))_dee_v27", s)
    if m:
        return "CORE01_14"
    return "OTHER_DEE_SCIENCE"


def numerical_reduction(obj: Any, max_values: int = 25000) -> dict:
    """Full traversal; returns stable path statistics without sampling the JSON prefix."""
    by_path: dict[str, list[float]] = defaultdict(list)
    scalar_values: dict[str, Any] = {}
    types = Counter()
    visited = 0
    numeric_count = 0

    def walk(x: Any, path: str, depth: int = 0):
        nonlocal visited, numeric_count
        visited += 1
        types[type(x).__name__] += 1
        if isinstance(x, dict):
            for k, v in x.items():
                walk(v, f"{path}.{k}" if path else str(k), depth + 1)
        elif isinstance(x, list):
            for i, v in enumerate(x):
                # Normalize list indices to [] so repeated trials aggregate.
                walk(v, f"{path}[]", depth + 1)
        elif isinstance(x, bool):
            by_path[path].append(float(x))
        elif isinstance(x, (int, float)) and math.isfinite(float(x)):
            if numeric_count < max_values:
                by_path[path].append(float(x))
                numeric_count += 1
        elif isinstance(x, (str, type(None))) and len(scalar_values) < 250:
            val = x if x is None or len(x) <= 500 else x[:500] + "…"
            scalar_values.setdefault(path, val)
    walk(obj, "")
    stats = {}
    for path, vals in list(by_path.items())[:500]:
        a = np.asarray(vals, dtype=np.float64)
        stats[path] = {
            "n": int(a.size), "min": float(a.min()), "max": float(a.max()),
            "mean": float(a.mean()), "first": float(a[0]), "last": float(a[-1]),
        }
    return {"nodes_traversed": visited, "type_counts": dict(types), "numeric_paths": stats, "scalar_values": scalar_values}


def compact_record(x: Any, depth=0, max_list=12) -> Any:
    if depth > 4:
        return "<nested>"
    if isinstance(x, dict):
        out = {}
        for k, v in list(x.items())[:100]:
            if isinstance(v, (str, int, float, bool)) or v is None:
                out[str(k)] = v if not isinstance(v, str) or len(v) < 1000 else v[:1000] + "…"
            elif depth < 3:
                out[str(k)] = compact_record(v, depth + 1, max_list)
        return out
    if isinstance(x, list):
        return [compact_record(v, depth + 1, max_list) for v in x[:max_list]] + ([f"<{len(x)-max_list} more>"] if len(x) > max_list else [])
    return str(x)


def find_records(obj: Any) -> list[tuple[str, Any]]:
    out: list[tuple[str, Any]] = []
    important = {"modules", "experiments", "trials", "worlds", "cases", "results", "rows", "claims", "holdouts", "conditions", "branches", "tests"}
    if isinstance(obj, dict):
        for k, v in obj.items():
            kl = str(k).lower()
            if kl in important:
                if isinstance(v, dict):
                    for kk, vv in v.items():
                        out.append((f"{k}.{kk}", vv))
                elif isinstance(v, list):
                    for i, vv in enumerate(v):
                        out.append((f"{k}[{i}]", vv))
            elif kl in {"discovery", "final_holdouts", "extension", "audits"} and isinstance(v, dict):
                for kk, vv in v.items():
                    out.append((f"{k}.{kk}", vv))
    if not out:
        out.append(("document_result", obj))
    return out


def status_from_obj(obj: Any, text: str) -> str:
    s = text.lower()
    if isinstance(obj, dict):
        s += " " + " ".join(str(obj.get(k, "")) for k in ["status", "fresh_status", "holdout", "replication", "verdict"])
    if any(k in s for k in ["fresh", "holdout", "replic", "revalid"]):
        return "EXISTING_REPRODUCIBLE_EXPERIMENT"
    return "EXISTING_EXPERIMENT_OR_ANALYSIS"


def array_reduction(arr: np.ndarray) -> dict:
    a = np.asarray(arr)
    out = {"shape": list(a.shape), "dtype": str(a.dtype), "size": int(a.size), "sha256": sha256_bytes(np.ascontiguousarray(a).tobytes())}
    if a.size == 0:
        return out
    if np.issubdtype(a.dtype, np.number) or a.dtype == bool:
        flat = a.reshape(-1)
        finite = flat[np.isfinite(flat)] if np.issubdtype(a.dtype, np.floating) else flat
        out.update({"nonzero": int(np.count_nonzero(flat)), "finite": int(finite.size)})
        if finite.size:
            out.update({"min": float(np.min(finite)), "max": float(np.max(finite)), "mean": float(np.mean(finite)), "std": float(np.std(finite)), "first": float(finite[0]), "last": float(finite[-1])})
        if a.ndim >= 1 and a.shape[0] <= 2048:
            out["axis0_nonzero"] = np.count_nonzero(a.reshape(a.shape[0], -1), axis=1).astype(int).tolist()
    else:
        vals, counts = np.unique(a.astype(str), return_counts=True)
        out["value_counts"] = {str(k): int(v) for k, v in zip(vals[:100], counts[:100])}
    return out


class Reducer:
    def __init__(self):
        self.seen_hash: dict[str, str] = {}
        self.sources: list[dict] = []
        self.atoms: list[dict] = []
        self.runner_info: dict[str, dict] = {}
        self.coverage = defaultdict(Counter)
        self.deferred: list[dict] = []
        self.member_count = 0

    def source_ref(self, outer: str, internal: str | None) -> str:
        return f"{outer}!{internal}" if internal else outer

    def add_atom(self, *, outer: str, internal: str | None, sha: str, family: str, experiment: str, measurement_definition: str, raw_measurement: Any, numerical_result: Any, runner: str = "NOT_RECORDED", runner_sha: str = "NOT_RECORDED", apparatus: Any = "NOT_RECORDED", initial: Any = "NOT_RECORDED", world: Any = "NOT_RECORDED", intervention: Any = "NOT_RECORDED", control: Any = "NOT_RECORDED", fresh: Any = "NOT_RECORDED", observer: Any = "NOT_RECORDED", time_window: Any = "NOT_RECORDED", scope: Any = "NOT_RECORDED", uncertainty: Any = "NOT_RECORDED", counterfactual: Any = "NOT_RECORDED", equation: Any = "NOT_RECORDED", mechanism: Any = "NOT_RECORDED", historical: Any = "NOT_RECORDED", later: Any = "NOT_RECORDED", current: Any = "NOT_RECORDED"):
        eid = f"E{len(self.atoms)+1:07d}"
        self.atoms.append({
            "evidence_id": eid, "source_file": outer, "source_internal_path": internal or "NOT_APPLICABLE", "source_sha256": sha,
            "campaign": family, "kernel_version": "v27" if any(x in (outer + (internal or "")).lower() for x in ["v27", "ingenieria", "procesos", "core"]) else "NOT_RECORDED",
            "kernel_sha256": KERNEL_SHA if any(x in (outer + (internal or "")).lower() for x in ["v27", "ingenieria", "procesos", "core"]) else "NOT_RECORDED",
            "runner_file": runner, "runner_sha256": runner_sha, "experiment_id": experiment,
            "apparatus": apparatus, "initial_conditions": initial, "world/branch": world, "intervention": intervention,
            "control_condition": control, "fresh_condition": fresh, "observer": observer,
            "measurement_definition": measurement_definition, "raw_measurement": raw_measurement, "numerical_result": numerical_result,
            "time_window": time_window, "scope": scope, "uncertainty_if_applicable": uncertainty,
            "counterfactual": counterfactual, "equation_candidate": equation, "native_mechanism": mechanism,
            "historical_interpretation": historical, "later_evidence": later, "current_interpretation": current,
            "evidence_status": status_from_obj(raw_measurement, internal or outer), "related_evidence_ids": [],
        })
        self.coverage[family]["evidence_atoms_created"] += 1

    def add_source(self, outer: str, internal: str | None, data: bytes, kind: str, family: str, reduction: Any, stage: str):
        sha = sha256_bytes(data)
        ref = self.source_ref(outer, internal)
        duplicate = self.seen_hash.get(sha)
        if duplicate:
            stage = "CROSS_LINKED"
        else:
            self.seen_hash[sha] = ref
        self.sources.append({"source": ref, "sha256": sha, "bytes": len(data), "type": kind, "family": family, "reduction_stage": stage, "duplicate_of": duplicate, "reduction": reduction})
        self.coverage[family]["files_discovered"] += 1
        if duplicate:
            self.coverage[family]["files_deduplicated"] += 1
        if stage == "SCIENTIFIC_DATA_REDUCED":
            self.coverage[family]["primary_sources_deep_reduced"] += 1
            if kind in {"NPZ", "NPY", "JSON", "JSONL", "NDJSON", "CSV"}:
                self.coverage[family]["telemetry_sources_deep_reduced"] += 1
            if kind in {"PY", "CPP", "H", "HPP"}:
                self.coverage[family]["runners_deep_reduced"] += 1
        return sha, duplicate

    def reduce_source(self, outer: str, internal: str | None, data: bytes, suffix: str):
        self.member_count += 1
        name = self.source_ref(outer, internal)
        family = family_of(name)
        suffix = suffix.lower()
        if suffix == ".json":
            try:
                obj = json.loads(data.decode("utf-8", "replace"))
            except Exception as exc:
                self.deferred.append({"source": name, "reason": f"JSON_PARSE_ERROR:{type(exc).__name__}"})
                self.add_source(outer, internal, data, "JSON", family, {"error": type(exc).__name__}, "STRUCTURE_PARSED")
                return
            reduction = numerical_reduction(obj)
            sha, dup = self.add_source(outer, internal, data, "JSON", family, reduction, "SCIENTIFIC_DATA_REDUCED")
            if dup or ADMIN_RX.search((internal or Path(outer).name).replace("\\", "/")):
                return
            runner = "NOT_RECORDED"; runner_sha = "NOT_RECORDED"
            if isinstance(obj, dict):
                r = obj.get("runner")
                if isinstance(r, dict):
                    runner, runner_sha = r.get("file", "NOT_RECORDED"), r.get("sha256", "NOT_RECORDED")
                elif isinstance(r, str): runner = r
            for rid, rec in find_records(obj):
                red = numerical_reduction(rec, 8000)
                raw = compact_record(rec)
                text = json.dumps(raw, ensure_ascii=False)
                self.add_atom(
                    outer=outer, internal=internal, sha=sha, family=family, experiment=rid,
                    measurement_definition="Full JSON record traversed; numerical paths aggregated without prefix truncation.",
                    raw_measurement=raw, numerical_result=red, runner=runner, runner_sha=runner_sha,
                    apparatus=(rec.get("apparatus", rec.get("spec", "NOT_RECORDED")) if isinstance(rec, dict) else "NOT_RECORDED"),
                    initial=(rec.get("initial_conditions", "NOT_RECORDED") if isinstance(rec, dict) else "NOT_RECORDED"),
                    world=(rec.get("world", rec.get("branch", rec.get("condition", "NOT_RECORDED"))) if isinstance(rec, dict) else "NOT_RECORDED"),
                    intervention=(rec.get("intervention", "NOT_RECORDED") if isinstance(rec, dict) else "NOT_RECORDED"),
                    control=("IDENTIFIED_IN_RECORD" if CONTROL_RX.search(text) else "NOT_RECORDED"),
                    fresh=("IDENTIFIED_IN_RECORD" if FRESH_RX.search(text + " " + name) else "NOT_RECORDED"),
                    observer=(rec.get("observer", rec.get("measurement", "NOT_RECORDED")) if isinstance(rec, dict) else "NOT_RECORDED"),
                    scope=(rec.get("scope", "source apparatus/domain") if isinstance(rec, dict) else "source apparatus/domain"),
                    mechanism=(rec.get("mechanism", rec.get("interpretation", "NOT_RECORDED")) if isinstance(rec, dict) else "NOT_RECORDED"),
                    historical=(rec.get("verdict", rec.get("adjudication", "NOT_RECORDED")) if isinstance(rec, dict) else "NOT_RECORDED"),
                    current="Measurement retained; interpretation scoped to apparatus, observer and horizon.",
                )
                if CONTROL_RX.search(text): self.coverage[family]["controls_identified"] += 1
                if FRESH_RX.search(text + " " + name): self.coverage[family]["fresh_identified"] += 1
        elif suffix in {".jsonl", ".ndjson"}:
            records=[]; errors=0
            for line in data.decode("utf-8", "replace").splitlines():
                if not line.strip(): continue
                try: records.append(json.loads(line))
                except Exception: errors += 1
            red = numerical_reduction(records)
            sha, dup = self.add_source(outer, internal, data, suffix[1:].upper(), family, {"records":len(records),"errors":errors,"summary":red}, "SCIENTIFIC_DATA_REDUCED")
            if not dup and records:
                self.add_atom(outer=outer,internal=internal,sha=sha,family=family,experiment="records",measurement_definition="All JSONL/NDJSON records parsed",raw_measurement={"records":len(records),"parse_errors":errors},numerical_result=red,scope="full file")
        elif suffix == ".csv":
            text=data.decode("utf-8-sig","replace"); rows=list(csv.DictReader(io.StringIO(text)))
            red=numerical_reduction(rows)
            sha,dup=self.add_source(outer,internal,data,"CSV",family,{"columns":list(rows[0]) if rows else [],"rows":len(rows),"summary":red},"SCIENTIFIC_DATA_REDUCED")
            if not dup and rows:
                self.add_atom(outer=outer,internal=internal,sha=sha,family=family,experiment="table",measurement_definition="All CSV rows parsed",raw_measurement={"columns":list(rows[0]),"row_count":len(rows)},numerical_result=red,scope="full table")
        elif suffix in {".npz", ".npy"}:
            try:
                arrays={}
                if suffix==".npz":
                    with np.load(io.BytesIO(data),allow_pickle=False) as z:
                        for k in z.files: arrays[k]=array_reduction(z[k])
                else:
                    arrays["array"]=array_reduction(np.load(io.BytesIO(data),allow_pickle=False))
                sha,dup=self.add_source(outer,internal,data,suffix[1:].upper(),family,{"arrays":arrays},"SCIENTIFIC_DATA_REDUCED")
                if not dup:
                    self.add_atom(outer=outer,internal=internal,sha=sha,family=family,experiment="array_telemetry",measurement_definition="All arrays opened and reduced; SHA preserves exact payload",raw_measurement={"array_names":list(arrays)},numerical_result=arrays,scope="full array payload")
            except Exception as exc:
                self.deferred.append({"source":name,"reason":f"ARRAY_OPEN_ERROR:{type(exc).__name__}"})
                self.add_source(outer,internal,data,suffix[1:].upper(),family,{"error":type(exc).__name__},"STRUCTURE_PARSED")
        elif suffix in {".py", ".cpp", ".h", ".hpp"}:
            text=data.decode("utf-8","replace")
            funcs=[]; modifies=[]; measures=[]; writes=[]
            if suffix==".py":
                try:
                    tree=ast.parse(text)
                    funcs=[n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))]
                    calls=[n.func.attr if isinstance(n.func,ast.Attribute) else n.func.id if isinstance(n.func,ast.Name) else "" for n in ast.walk(tree) if isinstance(n,ast.Call)]
                    modifies=sorted({c for c in calls if c in {"tick","advance","inyectar","inject","set_grid","apply_grid_mask_both","ablate","restore","swap"}})
                    measures=sorted({c for c in calls if any(q in c.lower() for q in ["measure","summary","fingerprint","observer","diff","first","metric","hash","snapshot"] )})
                    writes=sorted({c for c in calls if c in {"dump","save","savez","write_text","write_json_atomic","writestr"}})
                except Exception:
                    funcs=re.findall(r"(?m)^\s*(?:def|class)\s+([A-Za-z_]\w*)",text)
            else:
                funcs=re.findall(r"(?m)^\s*(?:static\s+)?(?:inline\s+)?[\w:<>,*& ]+\s+([A-Za-z_]\w*)\s*\(",text)
            red={"characters":len(text),"lines":text.count("\n")+1,"functions_or_classes":funcs[:1000],"world_modification_calls":modifies,"measurement_calls":measures,"persistence_calls":writes,"contains_controls":bool(CONTROL_RX.search(text)),"contains_fresh":bool(FRESH_RX.search(text))}
            sha,dup=self.add_source(outer,internal,data,suffix[1:].upper(),family,red,"SCIENTIFIC_DATA_REDUCED")
            if not dup:
                self.runner_info[name]={"sha256":sha,**red}
        elif suffix in {".md", ".txt", ".docx"}:
            text=docx_text(data) if suffix==".docx" else data.decode("utf-8","replace")
            eqs=[ln.strip() for ln in text.splitlines() if re.search(r"[=→]|\b(?:tau|omega|psi|rho|entropy|metric|first.?passage)\b",ln,re.I)][:500]
            red={"characters":len(text),"nonblank_lines":sum(bool(x.strip()) for x in text.splitlines()),"equation_or_relation_lines":eqs}
            sha,dup=self.add_source(outer,internal,data,suffix[1:].upper(),family,red,"SCIENTIFIC_DATA_REDUCED")
            if not dup and PRIMARY_RX.search(name) and eqs:
                self.add_atom(outer=outer,internal=internal,sha=sha,family=family,experiment="documented_relations",measurement_definition="Full text extracted; relation-bearing lines separated from author interpretation",raw_measurement={"relation_lines":eqs[:100]},numerical_result={"relation_line_count":len(eqs)},scope="documentary/formal; requires primary links",historical="Original document language retained separately",current="Relation candidates only; not promoted without primary evidence")
        elif suffix in {".zip", ".whl"}:
            self.reduce_archive_bytes(outer, internal, data)
        elif suffix == ".pdf":
            self.deferred.append({"source":name,"reason":"PDF_BINARY_NO_LOCAL_TEXT_READER; file retained by hash and duplicate cross-links checked"})
            self.add_source(outer,internal,data,"PDF",family,{"reader":"unavailable"},"METADATA_INSPECTED")

    def reduce_archive_bytes(self, outer: str, internal: str | None, data: bytes):
        label=self.source_ref(outer,internal)
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                for zi in z.infolist():
                    if zi.is_dir(): continue
                    suff=Path(zi.filename).suffix.lower()
                    if suff not in SCI_EXT: continue
                    self.reduce_source(label,zi.filename,z.read(zi),suff)
        except Exception as exc:
            self.deferred.append({"source":label,"reason":f"ARCHIVE_OPEN_ERROR:{type(exc).__name__}"})

    def reduce_filesystem(self, p: Path):
        data=p.read_bytes(); suff=p.suffix.lower()
        if suff in {".zip", ".whl"}:
            self.reduce_archive_bytes(str(p),None,data)
        else:
            self.reduce_source(str(p),None,data,suff)


def curated_atoms(r: Reducer):
    def find_source(fragment: str) -> tuple[str,str,str]:
        for s in r.sources:
            if fragment.lower() in s["source"].lower():
                outer, _, internal=s["source"].partition("!")
                return outer, internal or None, s["sha256"]
        return fragment,"NOT_RECORDED","NOT_RECORDED"
    def add(fragment,fam,eid,meas,num,definition,mechanism,equation="NOT_RECORDED",control="NOT_RECORDED",fresh="NOT_RECORDED",scope="declared apparatus"):
        o,i,h=find_source(fragment)
        r.add_atom(outer=o,internal=i if i!="NOT_RECORDED" else None,sha=h,family=fam,experiment=eid,measurement_definition=definition,raw_measurement=meas,numerical_result=num,control=control,fresh=fresh,scope=scope,equation=equation,mechanism=mechanism,current=mechanism)
    add("FORMULA_BRIDGE_AUDIT_FROM_TELEMETRY","FORMULA_BRIDGE","V7C_NATIVE_DISTANCE_HOLDOUT",{"holdout_rows":[{"d_native":18,"tau":18,"d_naive_x":22},{"d_native":22,"tau":22,"d_naive_x":26}]},{"rmse_tau_native":0.0,"rmse_tau_naive_x":4.0,"max_abs_tau_minus_native":0.0},"Full bridge JSON audit of V7-C discovery and holdout rows","State/topology-dependent first passage follows native path length in reached holdout rows; sample is small.","tau=d_native","empty and clock-connected media","holdout rows reached=2")
    add("TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY","GROUP_VELOCITY_PHASE","C7_COLLECTIVE_PHASE_GROUP_VELOCITY_27X",{"media_cases":9,"classification":{"no_resolved_group_mode":9}},{"resolved_group_modes":0,"unresolved":9},"T_peak primary, with T_first/T_centroid retained across pre-evolved occupied media","No resolved collective group-velocity mode in this apparatus; this is a scoped negative control, not absence of all propagation.",control="nine media cases",scope="C7 frozen media panel")
    add("PROCESOS_01","PROCESOS_01","HB_P2_FRONT",{"N":39,"sites":59319,"tau50_early":112,"tau99_early":121,"tau50_late":442,"tau99_late":450,"raw_diff_t128":58877},{"latency_shift_tau99":329,"fraction_diff_t128":58877/59319},"Tick-dense FULL/OMIT counterfactual masks and first-divergence maps","BA/P2 configuration modulates latency of locally branching, toroidally coalescing expansion.",control="H0-P2, HA-P2, HB-P1/P3",fresh="FRESH_V1/V2 exact spatial covariance")
    add("PROCESOS_02","PROCESOS_02","EVENT_ALIGNED_PREEXISTING_INTERFACE",{"early":{"tau99":121,"first_component_change":113,"terminal_state":2},"late":{"tau99":450,"first_component_change":442,"terminal_state":3},"clone_reinstantiation":[2,0,2]},{"delta_early":-8,"delta_late":-8,"absolute_separation":329},"Full main-world component timeline plus diagnostic one-tick reinstantiation clones","Endogenous BA transition reaches a preexisting CORE10 interface at event-relative latency and leaves trajectory-specific future-relevant organizations.","t_response=tau99-8","H0/HA no component state change","FRESH_V1/V2 exact covariance")
    add("CORE17_FINAL_REPORT","CORE17","R0_FACTOR_52",{"ordinary_cell_bits":52,"worlds":10,"steps":406,"mismatches":0,"clock_modulus":304980},{"raw_mismatches":0,"reduced_clock_mismatches":0},"Fresh factorization holdout","Domain-specific exact causal factor retains existence,s_reg,direction,semantic and clock phase; semantic-4 uses full raw/no clock.","304980=lcm(195,260,391,782)",fresh="10 fresh worlds")
    add("PROBABILITY_HOLDOUT","CORE16","PUSHFORWARD_BRANCH_UNION",{"microstates":27648,"macroclasses":54,"branch_union":"576/576","preparation_sensitive_pairs":"7/8"},{"branch_union_accuracy":1.0,"preparation_sensitive_fraction":0.875},"Full finite-ensemble pushforward and held-out branch-union predictions","Effective probability is a preparation-measure pushforward of deterministic microstates; not a Born rule.","P(Y=y)=mu({X:M(F^hX)=y})",fresh="576 held-out predictions")


def formula_candidates(r: Reducer) -> dict:
    return {"generated_utc":NOW,"candidates":[
        {"candidate_id":"FC-KERNEL-UPDATE","observed_relation":"X_(t+1)=F_DEE(X_t)","variables":["raw_a","clock_a"],"domain":"all v27","source_evidence_ids":[],"classification":"exact/kernel","external_analogy":False},
        {"candidate_id":"FC-CAUSAL-CONE","observed_relation":"T_first(x)>=d_inf^T(x,S0)","variables":["first divergence","toroidal Chebyshev distance"],"domain":"self+Moore-26","source_evidence_ids":[],"classification":"exact derived and empirically checked","external_analogy":False},
        {"candidate_id":"FC-V7C-NATIVE-PATH","observed_relation":"tau=d_native in the two reached holdout rows; RMSE=0 versus RMSE=4 for naive x-distance","variables":["tau","d_native","d_naive_x"],"domain":"V7-C reached empty/clock-connected holdout rows","source_evidence_ids":[],"classification":"exact empirical in apparatus; n=2 reached holdout rows","external_analogy":False},
        {"candidate_id":"FC-CLOCK-PERIOD","observed_relation":"period=floor(782/(8-n_active))","variables":["clock","n_active","s_reg"],"domain":"unprotected occupied branch","source_evidence_ids":[],"classification":"exact/kernel","external_analogy":False},
        {"candidate_id":"FC-R0-FACTOR","observed_relation":"ordinary-cell next-state factor closes with 52 bits and clock mod 304980 in validated family","variables":["existence","s_reg","direction","semantic","clock phase"],"domain":"CORE17 R0_FACTOR_52","source_evidence_ids":[],"classification":"exact empirical holdout plus source derivation","external_analogy":False},
        {"candidate_id":"FC-PUSHFORWARD","observed_relation":"P(Y=y)=mu({X:M(F^hX)=y})","variables":["preparation measure","microstate","observer"],"domain":"declared finite ensembles","source_evidence_ids":[],"classification":"formal exact + empirical branch-union","external_analogy":False},
        {"candidate_id":"FC-BINOMIAL-BRANCH","observed_relation":"P(R=r)=C(k,r)p^r(1-p)^(k-r)","variables":["k","r","p"],"domain":"CORE17 branch-union preparation","source_evidence_ids":[],"classification":"exact empirical in apparatus","external_analogy":False},
        {"candidate_id":"FC-HISTORY-REACHABILITY","observed_relation":"H_(0:t)->O_t->F_t with AB != BA under frozen panels","variables":["history","organization","future fingerprint"],"domain":"Ingeniería 05/06","source_evidence_ids":[],"classification":"exact empirical in apparatus; operational","external_analogy":False},
        {"candidate_id":"FC-BA-LATENCY","observed_relation":"tau99(FULL)-tau99(OMIT_P2)=329 ticks","variables":["BA configuration","P2 presence","transition time"],"domain":"Procesos 01 MAIN/FRESH transforms","source_evidence_ids":[],"classification":"exact empirical in apparatus","external_analogy":False},
        {"candidate_id":"FC-EVENT-ALIGNED-CONTACT","observed_relation":"t_component_first_change=tau99-8 for EARLY and LATE","variables":["transition time","component response"],"domain":"Procesos 02 preexisting interface","source_evidence_ids":[],"classification":"exact empirical in apparatus","external_analogy":False},
        {"candidate_id":"FC-GROUP-MODE-NULL","observed_relation":"9/9 C7 media classified no_resolved_group_mode","variables":["T_peak","T_first","T_centroid","media"],"domain":"Part C C7 apparatus","source_evidence_ids":[],"classification":"exact scoped negative measurement","external_analogy":False},
        {"candidate_id":"FC-UNITARY-SECTOR","observed_relation":"U_Q|X_j>=|F_Q(X_j)> for closed bijective S_Q","variables":["reversible sector","permutation basis"],"domain":"finite closed reversible sectors","source_evidence_ids":[],"classification":"formal derivation exact","external_analogy":"quantum unitary representation"},
    ]}


MISSING = """# Reassessment of the first-scan missing edges

## A) ANSWERED_BY_EXISTING_DATA

- **Native causal geometry at the discrete level.** Existing V7-C telemetry contains reached holdout rows with `tau=d_native` exactly (18/18 and 22/22), while naive x-distance is off by four ticks. Procesos 01 independently establishes self+Moore-26-compatible first divergence, toroidal maximum shell 19 and local ancestry for the BA front. This answers the existence of a native path/causal metric in those domains; it does not answer Lorentzian closure.
- **Preparation-dependent effective probability.** CORE16/17 already provides a complete deterministic pushforward construction, 27,648 microstates, 54 macroclasses, exact 576/576 branch-union predictions and preparation dependence in 7/8 pairs.
- **History-conditioned physical continuation.** Procesos 01/02 measures BA-dependent expansion, event-aligned contact at `tau99-8`, state `1→2→3`, persistence and changed reinstantiation futures. No new experiment is needed to establish that bounded chain.
- **Domain-specific causal compression.** CORE17 R0/R0_FACTOR_52 supplies a fresh exact closure within its stated ordinary-cell/semantic-4 domains.

## B) PARTIALLY_ANSWERED_BY_EXISTING_DATA

- **Dispersion/group velocity.** The C7 campaign measured `T_peak`, `T_first` and `T_centroid` across nine pre-evolved media but classified all nine as `no_resolved_group_mode`. Existing telemetry answers that this apparatus did not resolve a collective mode; it cannot supply `omega(k)` or effective mass.
- **Effective metric.** Causal order, native distance, first passage, anisotropy and state/history-dependent latency exist. Moving-frame closure, interval invariance and a single metric reconstruction remain absent.
- **Thermodynamics.** Many-to-one, ensembles, relaxation, `s_reg`, DEMUX and resource accounts exist. A common energy-like state function, stationary measure and conjugate temperature are not identified.
- **Hydrodynamics.** Historical and CORE15 sources contain density/support, direction responses, fronts and stress/pressure candidates. No source located in this reduction closes local continuity, face flux, momentum/stress and scale-stable constitutive coefficients in one frozen apparatus.
- **Quantum sector.** Closed reversible permutations and their unitary representation are mathematically available; phase and pushforward probability are measured. Operational `M_Q`, Born and a nonfactorizing bipartite DEE state remain uninstantiated.

## C) ACTUALLY_REQUIRES_NEW_MEASUREMENT

- A preregistered operational `M_Q` with bipartite observables and a Born-vs-pushforward discriminator.
- A mode-resolved spatial/time series sufficient for frozen `omega(k)` extraction after the existing C7 null.
- Moving internal observers and proper-time-like readouts for Lorentzian metric closure.
- Joint `source_eff`, metric/causal response and test-organization motion for gravity-like coupling.
- A single thermodynamic apparatus with balance, exchange and conjugate variables.
- A single hydrodynamic apparatus with continuity, momentum flux, stress and transferable viscosity.
- A local compensating-transformation family for a gauge claim.

No design is prescribed here; these are data requirements, not campaign proposals.
"""


REPORT_TMPL = """# Deep reduction report — Continuación 1 de 6

## What changed relative to the first scan

The first delivery hashed and structurally catalogued the corpus. This continuation opened the scientific members of every file in `documantacion vital`, recursively descended nested ZIP/WHL containers, parsed complete JSON/JSONL/CSV sources, opened NPZ/NPY payloads, read complete runner/source text and extracted complete DOCX text. Byte-identical sources were reduced once and cross-linked thereafter. Root-level scientific campaign ZIPs outside the vital directory were also reduced, including Formula Bridge, group velocity/phase, V6/V7, metric/minimum-time, multiscale/morphogenesis and replay batteries.

`EVIDENCE_ATOMS.jsonl` was rebuilt: its records now describe experimental results or mathematical relations with a numerical reduction, not file existence.

## Primary information recovered from telemetry

1. **Native distance:** the Formula Bridge audit contains V7-C reached holdout rows `(d_native,tau,d_naive_x)=(18,18,22)` and `(22,22,26)`. Thus `RMSE(tau,d_native)=0` and `RMSE(tau,d_naive_x)=4` in that small holdout domain.
2. **Group-velocity boundary:** Part C C7 retained `T_peak/T_first/T_centroid`, but all nine media were classified `no_resolved_group_mode`. This narrows the missing dispersion edge instead of supporting a collective `omega(k)`.
3. **History as geometry/latency:** Procesos 01 measures a 329-tick `tau99` displacement between OMIT_P2 and FULL within BA, with local Moore-26 ancestry and toroidal coalescence. Procesos 02 measures contact with a preexisting interface at `tau99-8` in both realizations.
4. **Coarse equality is not causal equality:** terminal branches with similar occupancy retain large RAW differences, while the same 14-site interface geometry supports states 1, 2 and 3 and reinstantiation futures 2/0/2.
5. **Probability:** CORE16/17 primary data support deterministic measure pushforward and exact branch-union prediction, not Born.
6. **R0:** CORE17 primary holdouts establish exact domain-specific closure/compression; this updates earlier universal-sounding “no quotient closes” language without erasing the earlier nulls outside the R0 domain.

## Interpretations refined or superseded

- `P2 amplifies` becomes: P2 changes the latency of BA access to an expansive regime within a non-additive configuration.
- `no endogenous consequence` becomes: a bounded post-host chain reaches a preexisting degree, changes it and changes diagnostic futures.
- `quantum absent` becomes: a reversible-sector unitary representation is a valid formal/sectoral construction, while operational quantum measurement, Born and entanglement remain open.
- `metric missing` becomes: a discrete native path/first-passage geometry is already measured; Lorentzian/Einstein closure remains open.
- Local negative labels remain controls at their apparatus/horizon and are not universal exclusions.

## Formula candidates retained

`FORMULA_CANDIDATES.json` separates exact kernel equations, exact empirical apparatus laws, approximate/formal relations and external analogies. New high-value candidates from deep reduction are the V7-C `tau=d_native` holdout relation, the event-aligned `t_response=tau99-8` relation and the C7 nine-case unresolved-mode boundary.

## Sources still deferred

Deferred entries are enumerated in `SCIENTIFIC_REDUCTION_COVERAGE.json`. They are limited to corrupt/unparseable members, exact byte duplicates, administrative material, binary extensions without a semantic reader, and PDFs where no local text extractor exists. A duplicate is cross-linked to its reduced source and is not counted as independent evidence.

## Scope

No kernel campaign, fresh world, parameter search or new apparatus was executed. All numbers are extracted or derived from existing files. This report does not rewrite the final internal theory; it establishes the evidence base for Continuation 2.
"""


def main():
    if not OFFICIAL_ZIP.is_file(): raise SystemExit("Official FISICA DEE UNI 1 ZIP missing")
    tmp=Path(tempfile.mkdtemp(prefix="fisica_dee_deep_"))
    try:
        with zipfile.ZipFile(OFFICIAL_ZIP) as z: z.extractall(tmp)
        idx=json.loads((tmp/"CORPUS_MASTER_INDEX.json").read_text(encoding="utf-8"))
        r=Reducer()
        # Complete vital tree: all files, recursively; official output excluded to avoid self-ingestion.
        vital_files=[p for p in VITAL.rglob("*") if p.is_file() and OFFICIAL_DIR not in p.parents]
        for i,p in enumerate(sorted(vital_files),1):
            r.reduce_filesystem(p)
            print(f"vital {i}/{len(vital_files)} {p.name}",flush=True)
        # All root scientific campaign ZIPs outside vital, including formula/group-velocity/V6/V7 families.
        for i,p in enumerate(sorted(ROOT_ZIPS),1):
            r.reduce_filesystem(p)
            print(f"rootzip {i}/{len(ROOT_ZIPS)} {p.name}",flush=True)
        # Deep-reduce explicit later work-tree primary sources not guaranteed to be packed in root/vital.
        selectors=[
            "EXPEDIENTE_EXPERIMENTOS_DEE/ingeniería/POST_INGENIERIA_04_5_REORGANIZACION_NATIVA",
            "DEE_V27_CORE17_DEFINITIVE_CLOSURE_WORK/PACKAGE_STAGE",
            "DEE_V27_CORE16_MULTISCALE_REALITY_QUANTUM_CLASSICAL_CAPABILITIES_WORK",
        ]
        for sel in selectors:
            base=TESTS/Path(sel)
            if not base.exists(): continue
            for p in sorted(x for x in base.rglob("*") if x.is_file() and x.suffix.lower() in SCI_EXT and x.stat().st_size<=100_000_000):
                r.reduce_filesystem(p)
        curated_atoms(r)

        # Strictly update filesystem-level stages in the previous complete inventory.
        deep_fs={s["source"].split("!",1)[0] for s in r.sources if s["reduction_stage"]=="SCIENTIFIC_DATA_REDUCED"}
        cross_fs={s["source"].split("!",1)[0] for s in r.sources if s["reduction_stage"]=="CROSS_LINKED"}
        for e in idx["files"]:
            p=e["path"]
            if p in deep_fs: stage="SCIENTIFIC_DATA_REDUCED"
            elif p in cross_fs or e.get("duplicate_of"): stage="CROSS_LINKED"
            elif e.get("structured_ingestion"): stage="STRUCTURE_PARSED"
            elif e.get("scientific_relevance"): stage="METADATA_INSPECTED"
            else: stage="DISCOVERED_ONLY"
            e["scientific_reduction_stage"]=stage
        idx["deep_reduction_updated_utc"]=NOW
        idx["stage_definitions"]={
            "DISCOVERED_ONLY":"path/hash only or non-scientific derivative",
            "METADATA_INSPECTED":"identity/container metadata inspected; scientific payload not reduced",
            "STRUCTURE_PARSED":"schema/source structure parsed without full scientific reduction",
            "SCIENTIFIC_DATA_REDUCED":"complete parse/read and measurement-level reduction",
            "CROSS_LINKED":"byte-identical to a reduced source or linked derivative",
        }
        write_json(tmp/"CORPUS_MASTER_INDEX.json",idx)
        with (tmp/"EVIDENCE_ATOMS.jsonl").open("w",encoding="utf-8",newline="\n") as f:
            for a in r.atoms: f.write(json.dumps(a,ensure_ascii=False)+"\n")
        fam_cov=[]
        for fam,c in sorted(r.coverage.items()):
            fam_cov.append({"family":fam,"files_discovered":c["files_discovered"],"files_deduplicated":c["files_deduplicated"],"primary_sources":c["files_discovered"]-c["files_deduplicated"],"primary_sources_deep_reduced":c["primary_sources_deep_reduced"],"telemetry_sources_deep_reduced":c["telemetry_sources_deep_reduced"],"runners_deep_reduced":c["runners_deep_reduced"],"controls_identified":c["controls_identified"],"fresh_identified":c["fresh_identified"],"evidence_atoms_created":c["evidence_atoms_created"],"deferred_sources":sum(1 for d in r.deferred if family_of(d["source"])==fam)})
        coverage={"generated_utc":NOW,"contract":"No new simulations; complete scientific reduction of existing sources","vital_root":str(VITAL),"vital_files_seen":len(vital_files),"root_scientific_zips_seen":len(ROOT_ZIPS),"archive_members_or_sources_processed":r.member_count,"unique_content_reduced_or_inspected":len(r.seen_hash),"evidence_atoms":len(r.atoms),"families":fam_cov,"deferred_sources":r.deferred,"source_reduction_ledger":r.sources}
        write_json(tmp/"SCIENTIFIC_REDUCTION_COVERAGE.json",coverage)
        write_json(tmp/"FORMULA_CANDIDATES.json",formula_candidates(r))
        (tmp/"MISSING_EDGE_REASSESSMENT.md").write_text(MISSING,encoding="utf-8")
        (tmp/"DEEP_REDUCTION_REPORT.md").write_text(REPORT_TMPL,encoding="utf-8")
        shutil.copy2(Path(__file__),tmp/Path(__file__).name)

        # Update supersession graph, preserving the prior genealogy.
        sg=json.loads((tmp/"SCIENTIFIC_SUPERSESSION_GRAPH.json").read_text(encoding="utf-8"))
        sg["deep_reduction_updated_utc"]=NOW
        sg["edges"].extend([
            {"old_statement":"effective metric is wholly missing","new_evidence":"V7-C holdout rows tau=d_native and Procesos 01 local toroidal first-divergence geometry","current_interpretation":"Discrete native causal/path geometry is measured; Lorentzian moving-frame metric remains open."},
            {"old_statement":"group velocity/dispersion may already be latent in Part C","new_evidence":"C7 classifies all 9 media no_resolved_group_mode using T_peak-primary telemetry","current_interpretation":"The existing C7 apparatus supplies a scoped null and cannot support omega(k) or effective mass."},
            {"old_statement":"all scientifically relevant files were ingested in first scan","new_evidence":"first scan recorded schemas/metadata, not complete measurements","current_interpretation":"Only sources marked SCIENTIFIC_DATA_REDUCED in the continuation ledger count as deeply reduced."},
        ])
        write_json(tmp/"SCIENTIFIC_SUPERSESSION_GRAPH.json",sg)

        # Rebuild manifest/hashes and replace the same official ZIP.
        for n in ["MANIFEST.json","HASHES.sha256"]:
            q=tmp/n
            if q.exists(): q.unlink()
        files=[]
        for p in sorted(tmp.iterdir()):
            if p.is_file(): files.append({"path":p.name,"size":p.stat().st_size,"sha256":sha256_path(p)})
        man={"title":"FÍSICA DEE UNI 1 — Continuación 1/6 deep scientific reduction","updated_utc":NOW,"official_zip":OFFICIAL_ZIP.name,"no_new_kernel_experiments":True,"vital_root":str(VITAL),"files":files}
        write_json(tmp/"MANIFEST.json",man)
        lines=[]
        for p in sorted(tmp.iterdir()):
            if p.is_file() and p.name!="HASHES.sha256": lines.append(f"{sha256_path(p)}  {p.name}")
        (tmp/"HASHES.sha256").write_text("\n".join(lines)+"\n",encoding="utf-8")
        newzip=tmp/"new.zip"
        with zipfile.ZipFile(newzip,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for p in sorted(tmp.iterdir()):
                if p.is_file() and p.name!="new.zip": z.write(p,p.name)
        with zipfile.ZipFile(newzip) as z:
            if z.testzip() is not None: raise RuntimeError("CRC failure")
        shutil.copy2(newzip,OFFICIAL_ZIP)
        print(json.dumps({"output":str(OFFICIAL_ZIP),"size":OFFICIAL_ZIP.stat().st_size,"sha256":sha256_path(OFFICIAL_ZIP),"members":len(zipfile.ZipFile(OFFICIAL_ZIP).namelist()),"evidence_atoms":len(r.atoms),"deep_sources":sum(1 for s in r.sources if s["reduction_stage"]=="SCIENTIFIC_DATA_REDUCED"),"cross_links":sum(1 for s in r.sources if s["reduction_stage"]=="CROSS_LINKED"),"deferred":len(r.deferred)},ensure_ascii=False,indent=2),flush=True)
    finally:
        shutil.rmtree(tmp,ignore_errors=True)


if __name__=="__main__": main()
