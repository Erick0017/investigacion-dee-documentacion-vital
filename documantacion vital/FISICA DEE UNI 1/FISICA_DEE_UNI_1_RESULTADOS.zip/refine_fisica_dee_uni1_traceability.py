from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
OFFICIAL = ROOT / "documantacion vital" / "FISICA DEE UNI 1" / "FISICA_DEE_UNI_1_RESULTADOS.zip"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


SOURCES = {
    "V7C_NATIVE_DISTANCE_HOLDOUT": {
        "archive": ROOT / "DEE_V27_FORMULA_BRIDGE_AUDIT_FROM_TELEMETRY_V1_RESULTADOS.zip",
        "data": "REPORT.json",
        "runner": "DEE_V27_FORMULA_BRIDGE_AUDIT_FROM_TELEMETRY_V1.py",
    },
    "C7_COLLECTIVE_PHASE_GROUP_VELOCITY_27X": {
        "archive": ROOT / "DEE_V27_TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY_PART_C_V1.zip",
        "data": "DEE_V27_TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY_PART_C_V1.json",
        "runner": "dee_v27_transversal_native_processing_and_group_velocity_part_c_v1.py",
    },
    "HB_P2_FRONT": {
        "archive": ROOT / "documantacion vital" / "procesos" / "PROCESOS_01_DEE_V27_CONTINUIDAD_ENDOGENA_ATLAS_MULTIOBSERVADOR_RESULTADOS.zip",
        "data": "PROCESOS_01/10_HB_P2_CAUSAL_AMPLIFICATION_CHARACTERIZATION/DENSE_TELEMETRY/HB_P2_DENSE_TIMELINE.json",
        "runner": "PROCESOS_01/10_HB_P2_CAUSAL_AMPLIFICATION_CHARACTERIZATION/RUNNERS/run_hbp2_characterization.py",
    },
    "EVENT_ALIGNED_PREEXISTING_INTERFACE": {
        "archive": ROOT / "documantacion vital" / "procesos" / "PROCESOS_02" / "PROCESOS_02_DEE_V27_CONTINUIDAD_CAUSAL_POST_TRANSICION_RESULTADOS.zip",
        "data": "results.json",
        "runner": "runner_procesos02.py",
    },
    "R0_FACTOR_52": {
        "archive": ROOT / "documantacion vital" / "cores" / "17_DEE_V27_REALITY_UNIFICATION_CROSS_SCALE_PHYSICS_AND_CAPABILITIES_RESULTADOS.zip",
        "data": "EXTENSION/HOLDOUT/C17E05_R0_FACTOR_HOLDOUT.json",
        "runner": "EXTENSION/RUNNERS/run_e05_r0_factor_holdout.py",
    },
    "PUSHFORWARD_BRANCH_UNION": {
        "archive": ROOT / "documantacion vital" / "cores" / "16_DEE_V27_MULTISCALE_REALITY_QUANTUM_CLASSICAL_AND_CAPABILITIES_RESULTADOS.zip",
        "data": "FINAL_HOLDOUTS/PROBABILITY_HOLDOUT_RESULTS.json",
        "runner": "RUNNERS_NEW/run_probability_holdout.py",
    },
}


def main() -> None:
    temp = Path(tempfile.mkdtemp(prefix="fisica_dee_trace_"))
    output = OFFICIAL.with_suffix(".zip.new")
    try:
        with zipfile.ZipFile(OFFICIAL) as archive:
            archive.extractall(temp)

        atoms_path = temp / "EVIDENCE_ATOMS.jsonl"
        atoms = [json.loads(line) for line in atoms_path.read_text(encoding="utf-8").splitlines() if line.strip()]
        atoms = [a for a in atoms if a.get("evidence_id") not in {"KERNEL_EXACT_001", "KERNEL_EXACT_002"}]
        updated = 0
        for atom in atoms:
            spec = SOURCES.get(atom.get("experiment_id"))
            if not spec:
                continue
            archive_path = spec["archive"]
            with zipfile.ZipFile(archive_path) as parent:
                data_bytes = parent.read(spec["data"])
                runner_bytes = parent.read(spec["runner"])
            atom["source_file"] = str(archive_path)
            atom["source_internal_path"] = spec["data"]
            atom["source_sha256"] = sha256_bytes(data_bytes)
            atom["runner_file"] = f"{archive_path}!{spec['runner']}"
            atom["runner_sha256"] = sha256_bytes(runner_bytes)
            updated += 1

        kernel_path = ROOT / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA" / "dee_kernel_v27.cpp"
        kernel_hash = sha256_path(kernel_path)
        kernel_common = {
            "source_file": str(kernel_path), "source_internal_path": "NOT_APPLICABLE", "source_sha256": kernel_hash,
            "campaign": "KERNEL", "kernel_version": "v27",
            "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
            "runner_file": str(kernel_path), "runner_sha256": kernel_hash, "apparatus": "v27 source",
            "initial_conditions": "NOT_APPLICABLE", "world/branch": "kernel update", "intervention": "NOT_APPLICABLE",
            "control_condition": "source identity", "fresh_condition": "NOT_APPLICABLE", "observer": "X_FULL",
            "time_window": "one tick", "scope": "v27 kernel", "uncertainty_if_applicable": "exact source",
            "counterfactual": "NOT_APPLICABLE", "historical_interpretation": "NOT_RECORDED",
            "later_evidence": "NOT_RECORDED", "evidence_status": "KERNEL_IDENTITY",
            "related_evidence_ids": [],
        }
        atoms.append({
            "evidence_id": "KERNEL_EXACT_001", **kernel_common, "experiment_id": "SOURCE_EXACT_LOCAL_UPDATE",
            "measurement_definition": "Complete v27 source: default copy/clock increment and active-raw plus Moore-26 candidate construction.",
            "raw_measurement": {"default_raw": "memcpy(gB,gA)", "default_clock": "clkB[i]=clkA[i]+1", "candidate_support": "raw!=0 plus Moore-26 halo"},
            "numerical_result": {"spatial_dimension": 3, "moore_neighbors": 26, "raw_default_preserved": True, "clock_increment": 1},
            "equation_candidate": "X_(t+1)=F_DEE(X_t)",
            "native_mechanism": "Deterministic full-state update with finite candidate halo.",
            "current_interpretation": "Exact microscopic update support and default clock advance from source.",
        })
        atoms.append({
            "evidence_id": "KERNEL_EXACT_002", **kernel_common, "experiment_id": "SOURCE_EXACT_CLOCK_PERIOD_BRANCH",
            "measurement_definition": "Complete v27 source: unprotected occupied-branch period as integer division by missing anchors.",
            "raw_measurement": {"write_protected": "n_active>=7 and vector symmetry", "missing_anchors": "8-n_active", "period_code": "periodo_ticks=782/anclajes_faltantes"},
            "numerical_result": {"period_numerator": 782, "active_upper_bound_for_branch": 7, "minimum_period": 1},
            "equation_candidate": "period=floor(782/(8-n_active))",
            "native_mechanism": "Clock-gated resource increment outside the write-protected branch.",
            "current_interpretation": "Exact branch-local cadence; not a universal period for every voxel.",
        })
        atoms_path.write_text("\n".join(json.dumps(a, ensure_ascii=False, separators=(",", ":")) for a in atoms) + "\n", encoding="utf-8")

        evidence_by_experiment = {a.get("experiment_id"): a.get("evidence_id") for a in atoms}
        formula_links = {
            "FC-KERNEL-UPDATE": ["KERNEL_EXACT_001"],
            "FC-CAUSAL-CONE": ["KERNEL_EXACT_001", evidence_by_experiment["HB_P2_FRONT"]],
            "FC-V7C-NATIVE-PATH": [evidence_by_experiment["V7C_NATIVE_DISTANCE_HOLDOUT"]],
            "FC-CLOCK-PERIOD": ["KERNEL_EXACT_002"],
            "FC-R0-FACTOR": [evidence_by_experiment["R0_FACTOR_52"]],
            "FC-PUSHFORWARD": [evidence_by_experiment["PUSHFORWARD_BRANCH_UNION"]],
            "FC-BINOMIAL-BRANCH": [evidence_by_experiment["PUSHFORWARD_BRANCH_UNION"]],
            "FC-HISTORY-REACHABILITY": ["E0026117", "E0026118"],
            "FC-BA-LATENCY": [evidence_by_experiment["HB_P2_FRONT"]],
            "FC-EVENT-ALIGNED-CONTACT": [evidence_by_experiment["EVENT_ALIGNED_PREEXISTING_INTERFACE"]],
            "FC-GROUP-MODE-NULL": [evidence_by_experiment["C7_COLLECTIVE_PHASE_GROUP_VELOCITY_27X"]],
            "FC-UNITARY-SECTOR": ["E0011180"],
        }
        formula_path = temp / "FORMULA_CANDIDATES.json"
        formulas = json.loads(formula_path.read_text(encoding="utf-8"))
        for candidate in formulas["candidates"]:
            candidate["source_evidence_ids"] = formula_links[candidate["candidate_id"]]
        formula_path.write_text(json.dumps(formulas, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        coverage_path = temp / "SCIENTIFIC_REDUCTION_COVERAGE.json"
        coverage = json.loads(coverage_path.read_text(encoding="utf-8"))
        coverage["evidence_atoms"] = len(atoms)
        for family in coverage["families"]:
            if family["family"] == "KERNEL":
                family["evidence_atoms_created"] = 2
        coverage_path.write_text(json.dumps(coverage, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        report_path = temp / "DEEP_REDUCTION_REPORT.md"
        report = report_path.read_text(encoding="utf-8")
        marker = "`EVIDENCE_ATOMS.jsonl` was rebuilt:"
        note = "The six cross-campaign synthesis atoms were additionally bound to their exact primary telemetry member and exact producing runner, each with member-level SHA-256.\n\n"
        if note not in report:
            report = report.replace(marker, note + marker)
            report_path.write_text(report, encoding="utf-8")

        shutil.copy2(Path(__file__), temp / Path(__file__).name)
        manifest_path = temp / "MANIFEST.json"
        hashes_path = temp / "HASHES.sha256"
        files_for_manifest = []
        for path in sorted(p for p in temp.iterdir() if p.is_file() and p.name not in {"MANIFEST.json", "HASHES.sha256"}):
            files_for_manifest.append({"path": path.name, "size": path.stat().st_size, "sha256": sha256_path(path)})
        manifest = {
            "title": "FÍSICA DEE UNI 1 — Continuación 1/6 deep scientific reduction",
            "updated_utc": datetime.now(timezone.utc).isoformat(),
            "official_zip": OFFICIAL.name,
            "no_new_kernel_experiments": True,
            "vital_root": str(ROOT / "documantacion vital"),
            "traceability_refinement": {"atoms_rebound_to_primary_data_and_runner": updated, "kernel_exact_atoms_added": 2, "formula_candidates_linked": len(formula_links)},
            "files": files_for_manifest,
        }
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        hashed = sorted(p for p in temp.iterdir() if p.is_file() and p.name != "HASHES.sha256")
        hashes_path.write_text("".join(f"{sha256_path(path)}  {path.name}\n" for path in hashed), encoding="utf-8")

        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for path in sorted(p for p in temp.iterdir() if p.is_file()):
                archive.write(path, path.name)
        output.replace(OFFICIAL)
        print(json.dumps({"official": str(OFFICIAL), "updated_atoms": updated, "size": OFFICIAL.stat().st_size, "sha256": sha256_path(OFFICIAL)}, ensure_ascii=False, indent=2))
    finally:
        shutil.rmtree(temp, ignore_errors=True)
        if output.exists():
            output.unlink()


if __name__ == "__main__":
    main()
