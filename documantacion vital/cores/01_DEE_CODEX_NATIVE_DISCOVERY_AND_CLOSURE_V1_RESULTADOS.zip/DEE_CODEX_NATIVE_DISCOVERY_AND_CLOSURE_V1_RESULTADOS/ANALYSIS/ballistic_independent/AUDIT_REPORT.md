# Independent T8 ballistic-singleton audit

## Outcome

**PASS, with exact domain restrictions.**  The prospectively sealed v27 panel
produced zero mismatches in 16,260 primary cases and 48,876 kernel ticks.  A
complete source argument promotes the sampled checks to an exact vacuum-sector
theorem: a lone normal, directional raw with positive state translates one
Moore step per tick on the torus, normalizing its state to 1 after the first
tick while preserving `s_reg` and direction.

T8 is **not the first observation** of this mechanism.  The recovered v25
`TORUS_MOVING` primary fixture was exactly one such singleton, and the v25.5-C
F-189 directional atlas was a prepared collection of noninteracting
singletons.  T8's novelty is a prospectively frozen, broad v27 generalization
and exact closure across all 26 directions, selected extreme values, clocks,
engines, thread counts, and all unordered two-direction collisions.

## Seal and binary identity

- Preregister:
  `HOLDOUTS/PREREGISTER_T8_BALLISTIC_SINGLETON.md`, SHA-256
  `0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb`.
- Reduction sealed before any T8 binary execution:
  `REDUCTION_BEFORE_RESULTS.md`, SHA-256
  `bab477c1f705fffcad678ccd7a1417c825ec3c9b96255f98cb789834ff10441f`.
- Runner sealed before execution:
  `ballistic_independent_probe.py`, SHA-256
  `5c667de32f91442282d8c20588ae4a78a4773b0d151a9aaa88ce8fd369a41e8c`.
- Accepted wheel SHA-256:
  `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- Imported binary:
  `ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd`,
  SHA-256
  `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Shipped C++ source SHA-256:
  `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.
- Runtime: `D:/Descargas/ANACONDA MINICONDA/python.exe`, CPython 3.13.11,
  AMD64/64-bit, NumPy 2.2.6.

The runner used an isolated direct path to the already extracted wheel.  No
package installation, virtual environment, global-Python change, or second
wheel extraction was performed.

## Executed panel

| Panel | Cases | Ticks | Result |
|---|---:|---:|---|
| Singletons | 624 | 16,848 | exact |
| Two separated movers | 36 | 828 | exact |
| Two-source collisions | 15,600 | 31,200 | exact |
| **Total** | **16,260** | **48,876** | **0 mismatches** |

The singleton panel crossed 26 directions, `N={11,13}`, states
`{1,2,2^32-1}`, `s_reg={0,1,19664,65535}`, three clock fields, and
dense/lazy with one/two threads.  The strength-2 assignment covered every one
of the 12 clock/implementation pairs for each direction and size.  It checked
10,816 Fourier ratios; maximum absolute error was
`7.75031895146933e-15` against a `5e-12` tolerance.

The collision panel exhausted all 325 unordered pairs of distinct Moore
directions, four charge pairs, three clocks, and four engine/thread variants.
The result artifact is `ballistic_probe_results.json`, 57,686,450 bytes,
SHA-256 `fe84156f144d2a060388c7b6eaea314c32077852093c48357e99670e63b212ef`.

## Exact theorem and period

For `N>=5`, one initial raw

`pack(state>0, s, d!=0, SEM_NORMAL)` at `q`

produces, after one tick,

`pack(1, s, d, SEM_NORMAL)` at `q+d mod N`,

and thereafter the same word is at `q+t*d mod N`.  Every clock word increments
locally by one modulo `2^64`; clocks are not transported with the raw.  The
raw orbit has exact period `N`, while the normalized complete raw-plus-clock
state has period `lcm(N,2^64)`.

For the stated Fourier convention, the one-step ratio is exactly
`exp(-2*pi*i*m.d/N)`.  This establishes a one-particle shift eigenphase and
exact lattice advection, not by itself a many-body collective mode, energy
dispersion, physical momentum, light, or matter.

The crystallization branch is globally unreachable in v27.  Its exact
gradient maximum is `15*65535 = 983,025`, below the required
`19665*966 = 18,996,390`.

## Collision law and limits

For exactly two normal state-1 sources aimed at one empty target, tick 1 is

`pack(1, min(s1+s2,19664), sign(d1+d2), SEM_NORMAL)`.

Thirteen of the 325 unordered direction pairs are antipodal and the resulting
zero-direction raw dies on tick 2; the other 312 continue ballistically.  In
the executed panel this yielded 624 dying cases and 14,976 continuing cases.
Half the 15,600 cases exercised charge saturation.  The reducer is
commutative but support-inelastic (`2 -> 1`), can lose charge through
saturation, and does not conserve the integer direction vector.

This is not an arbitrary-density superposition law.  Eight suitably arranged
incoming raws trigger XNOR before DEMUX; the exploratory probe produced
`(state=1,s_reg=1,d=0,semantic=7)`.  A normal occupied target blocked and
annihilated the chosen two-site configuration; an observer target remained
fixed and blocked arrival.  `buscar_fuente_demux` tests direction and geometry,
not state, existence, or semantic: a directional state-0 word can emit a
normal mover, nonobserver semantics normalize to 1, and a semantic-4 observer
persists while broadcasting a normal copy.

## Historical closure

### `TORUS_MOVING`

The original runner
`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/test_v25_lazy_audit.py`
(SHA-256 `764d09223d9407ee05bb899401e22278cf7ff2935e32f5fdbfb3d2f0fa67e202`)
places one state-1, charge-0, normal raw at `(23,12,12)` in `N=24`, pointing
`(+1,0,0)`, and checks ticks 1--12.

Its primary JSON
`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/v25_lazy_audit/DEE_V25_LAZY_AUDIT_20260820_155526.json`
(SHA-256 `d45f8a1881c6e7eafa0e5aa47f55c350632fdc09ebfc7e2c60741886167b62eb`)
records all 12 dense-v24/lazy-v25 comparisons equal with zero Hamming
distance.  An independent no-kernel reconstruction of the singleton at
`((23+t) mod 24,12,12)` reproduced all 12 raw hashes; uniform clocks filled
with `t` reproduced all 12 clock hashes.  Tick 1 is the torus crossing to
`(0,12,12)`.

### F-137

F-137's eight `sparse_directional` trials are random, mixed-direction clouds
of 216, 465, 1,622, and 4,096 initial sites at `N=24,31,47,64`; all five raw
projections empirically had `P=N`.  Collisions are possible and its retained
hashes do not decompose the recurrent tail.  T8 supplies a plausible survivor
mechanism but does not retroactively prove a noninteracting-singleton
decomposition.

### F-189 / v25.5-C

The original runner
`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/dee_v25_5_native_frequency_scale_recurrence_part_c_v1.py`
has SHA-256
`939e0ca75585e6bdc3422ddf238fd9121bbf2668483588a2a400a211afbd3a47`.
The primary ZIP has SHA-256
`c0402e58bc1541f929fc2b4726e926d2dec5131332abfddb62f2f6e1ba17ab5b`;
all embedded manifest hashes were verified, including the 3,350,422-byte JSON
with SHA-256
`7beb816ea781ab9dce18837ee0fd0c673301816914847b260d4eecd91a1edb4d`.

Its 60 directional trials place identical state-1, charge-0 normal raws every
`L_sym` sites along one positive coordinate axis, with every spacing at least
four.  These are noninteracting singleton lanes.  Across 2,226 steps, the
actual raw was exactly `np.roll(previous,1,axis)` every time: all Hamming
distances zero and all translation fractions 1.  Packed/state/direction/
semantic projections had `P=L_sym` in 60/60.  **`sreg_projection` had `P=1`
in 60/60**, because it was identically zero.

Accordingly, `P=L_sym` is a sectoral group-action corollary of exact
translation plus prepared support symmetry.  It is not a universal DEE law.
Nested multi-lane and symmetry-breaking constructions remain separate
empirical results.

## Bottom line

The historical record should say: v25 already observed an exact singleton and
v25.5-C already exercised collision-free singleton lanes; T8 prospectively
freezes and rigorously generalizes the mechanism in v27.  Claims about a
native microscopic raw velocity are now exact in this vacuum sector.  Claims
about global conservation, arbitrary-media particles, collective group modes,
or physical identity remain unsupported.

