# Commands and results log

Working directory throughout:

`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_27/tests`

All writes were confined to
`DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ANALYSIS/ballistic_independent/`.

## Pre-execution seal

The preregister hash was read with `Get-FileHash -Algorithm SHA256` and matched
the root-supplied value
`0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb`.
The reduction and runner were then written, syntax-checked without importing
the kernel, hashed, and recorded in `RUN_SEAL.json`.  The seal states
`binary_executions_seen_before_seal: 0`.

Critical execution command:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\ballistic_independent\ballistic_independent_probe.py'
```

The runner prepended only the already extracted local-wheel directory to its
isolated process search path and asserted wheel/source/binary hashes before
import.  Result: `PASS`, 16,260 primary cases, 48,876 ticks, zero mismatches,
65.829485 seconds.

## Compact result reads

The 57.7 MB JSON was read with CPython 3.13.11 using `json.loads`; only summary
keys were printed.  Reported identity:

- executable `D:\Descargas\ANACONDA MINICONDA\python.exe`;
- NumPy `2.2.6`, architecture `64bit`;
- imported module
  `.../ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd`;
- wheel/source/binary hashes `69297e6f...c939`, `44a80f78...7ab`, and
  `0b17ba32...6ff`.

`Get-FileHash -Algorithm SHA256` over the result returned
`fe84156f144d2a060388c7b6eaea314c32077852093c48357e99670e63b212ef`.

## Historical read-only audit

Read-only `rg`, `Get-Content`, `Get-Item`, `Get-FileHash`, and Python JSON/ZIP
inspection located and verified:

- `VERSION_25/tests/test_v25_lazy_audit.py` and its primary lazy-audit JSON;
- the still-installed exact v25 `.pyd` and shipped C++ source;
- F-137 runner/JSON in the copied Volume-2 forensic bundle;
- F-189 runner and ZIP under `VERSION_25/tests`.

For `TORUS_MOVING`, a no-kernel NumPy reconstruction placed raw word
`1153202979583557633` at `((23+t) mod 24,12,12)` for `t=1..12` and rehashed
each array.  All 12 raw hashes matched the primary JSON.  Uniform clock arrays
filled with `t` matched all 12 clock hashes.

For F-189, every ZIP member was streamed through SHA-256 and compared with its
manifest.  Declared and actual sizes/hashes all matched: JSON 3,350,422 bytes
(`7beb816e...b4d`), summary 15,275 bytes (`e4acc465...fab`), runner 62,727
bytes (`939e0ca7...47`).  The JSON summary count was 60 directional trials and
2,226 exact shift checks, with `sreg_projection P=1` in all 60.

No v27 kernel was re-run during historical reconstruction or final report
assembly.

