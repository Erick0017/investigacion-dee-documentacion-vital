# Package-ready historical corrections: T8 ballistic sector

1. **Replace “T8 first observed persistent motion.”**  v25's literal
   `TORUS_MOVING` fixture was already one state-1, charge-0, normal singleton
   at `(23,12,12)` in `N=24`, direction `(+1,0,0)`.  Its 12 primary raw hashes
   reconstruct exactly as `((23+t) mod 24,12,12)`, including the tick-1 torus
   crossing.  T8 is the prospectively frozen and broad v27 generalization, not
   the first observation.

2. **Qualify native velocity claims.**  v27 now has an exact vacuum-sector law
   `q(t)=q0+t*d` for all 26 nonzero Moore directions, with Chebyshev speed 1
   and Euclidean step lengths `1,sqrt(2),sqrt(3)`.  This is a one-particle
   shift mode, not evidence by itself for an arbitrary-medium particle,
   collective packet, energy dispersion, momentum, light, or matter.

3. **Correct F-189/v25.5-C period wording.**  Its 60 prepared directional
   lanes passed 2,226 exact one-step `np.roll` comparisons.  Packed, state,
   direction, and semantic projections have `P=L_sym` in 60/60, but
   **`sreg_projection` has `P=1` in 60/60** because `s_reg` is identically
   zero.  `P=L_sym` is the group-action corollary of exact translation plus
   prepared periodic support, not a universal DEE law.

4. **Do not reduce F-137 to T8.**  Its eight recurrent directional seeds are
   mixed random clouds (216/465/1,622/4,096 sites), not proven collision-free
   singleton gases.  T8 offers a candidate survivor mechanism; the retained
   hashes do not establish the tail decomposition.

5. **Do not back-port v27 collision semantics.**  Collision-free singleton
   transport already exists in v25, but v25 chooses the first matching DEMUX
   source.  v26-SYM1/v27 use the commutative capped-sum/sign reducer.  T8.6 is
   therefore not retroactive to v25.

6. **Retain global limits.**  The v27 two-source reducer is support-inelastic,
   saturates charge, and can erase antipodal pairs.  XNOR, occupied targets,
   observers, and arbitrary backgrounds preempt or alter free transport.
   Clocks increment in place and are not carried by the raw.

## Primary provenance

| Evidence | Path | SHA-256 | Key count |
|---|---|---|---:|
| v27 T8 result | `ANALYSIS/ballistic_independent/ballistic_probe_results.json` | `fe84156f144d2a060388c7b6eaea314c32077852093c48357e99670e63b212ef` | 16,260 cases / 48,876 ticks |
| v25 `TORUS_MOVING` runner | `D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/test_v25_lazy_audit.py` | `764d09223d9407ee05bb899401e22278cf7ff2935e32f5fdbfb3d2f0fa67e202` | 12 ticks |
| v25 lazy-audit JSON | `D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/v25_lazy_audit/DEE_V25_LAZY_AUDIT_20260820_155526.json` | `d45f8a1881c6e7eafa0e5aa47f55c350632fdc09ebfc7e2c60741886167b62eb` | 12/12 exact |
| F-137 runner | `ANALYSIS/docs_claims/volume2_forensic_bundle/sources/dee_v25_final_volume2_closure_v23_1_part_a.py` | `ec69a9513be49ad2006d4c6a20dd673ad0745b641be0ecf4231c374e3eeb01b2` | 8 directional trials |
| F-137 JSON | `ANALYSIS/docs_claims/volume2_forensic_bundle/sources/DEE_V25_FINAL_VOLUME2_CLOSURE_V23_1_PART_A.json` | `ac4097bc09d38fcc06dc4e4647ae6338d66e7f6e0a877dc0b81ee3756b7c4bad` | 8 raw `P=N` |
| F-189 runner | `D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/dee_v25_5_native_frequency_scale_recurrence_part_c_v1.py` | `939e0ca75585e6bdc3422ddf238fd9121bbf2668483588a2a400a211afbd3a47` | 60 trials |
| F-189 ZIP | `D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/DEE_V25_5_NATIVE_FREQUENCY_SCALE_RECURRENCE_PART_C_V1.zip` | `c0402e58bc1541f929fc2b4726e926d2dec5131332abfddb62f2f6e1ba17ab5b` | 2,226 exact shifts |
| F-189 JSON in ZIP | ZIP member | `7beb816ea781ab9dce18837ee0fd0c673301816914847b260d4eecd91a1edb4d` | `P=L_sym` 60/60 except `sreg P=1` |

