# Ballistic singleton and `TORUS_MOVING`: historical genealogy

## Correction to the corpus-only reading

The copied v27 corpus mentions `TORUS_MOVING` only as a v25 quick-regression
label, so a search confined to that corpus makes the fixture look missing.
Expanding the read-only search to the still-present historical `VERSION_25`
tree recovered both its exact runner and its primary JSON.  The correct finding
is therefore stronger: **`TORUS_MOVING` was exactly a ballistic singleton.**

### Original fixture

Primary runner:

`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/test_v25_lazy_audit.py`

SHA-256: `764d09223d9407ee05bb899401e22278cf7ff2935e32f5fdbfb3d2f0fa67e202`.

The relevant source is unambiguous:

- `181--184`: `inject_moving_boundary` places one raw at
  `(N-1,N//2,N//2)`, with `state=1`, `s_reg=0`, `d=(1,0,0)`, and
  `SEM_NORMAL`;
- `329--334`: `N=24`, zero-initialized clocks/raw background, 12 ticks, every
  tick a checkpoint, case name `TORUS_MOVING`;
- `112--125`, `212--265`: each tick compares v24 dense with v25 lazy, exactly
  across both raw buffers, both clock buffers, overflow and genesis counters.

Thus its initial position was `(23,12,12)`.  The T8 law predicts positions

`(0,12,12), (1,12,12), ..., (11,12,12)`

at ticks 1 through 12; tick 1 is the intended torus-boundary crossing.

### Original primary result and forensic reconstruction

Primary JSON:

`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/v25_lazy_audit/DEE_V25_LAZY_AUDIT_20260820_155526.json`

SHA-256: `d45f8a1881c6e7eafa0e5aa47f55c350632fdc09ebfc7e2c60741886167b62eb`.

It records:

- v24 `DEE Universe Kernel v24.0 (FISICA PURA SIN ALIAS)` against v25
  `DEE Universe Kernel v25.0-LAZY (v24 BIT-EQUIVALENT TARGET)`;
- four threads, 16 cases total, `all_bit_exact=true`;
- `TORUS_MOVING.ok=true`, all 12 checkpoints `same=true`, every Hamming
  difference zero, matching dense/lazy hashes, no overflows/genesis;
- exactly one raw/state-nonzero site at every tick.

The raw value fixed by the runner is `1153202979583557633`.  Independently
constructing a zero `24^3` array with that word at each predicted coordinate
reproduces **all 12 recorded raw SHA-256 hashes**.  Independently constructing
uniform clock arrays filled with tick `t` reproduces **all 12 recorded clock
hashes**.  No kernel was executed for this reconstruction.  The first three
raw hashes are `077abdd3...de34`, `3ec5a74b...c597`, and
`1d512e1e...78b0`; the tick-12 hash is `bda94900...0dee`.

This closes the historical ambiguity left by the secondary v25 technical
document
`ANALYSIS/docs_claims/extracted/036_ed12ac6537b8_composicion_estructural_del_whl_v25.txt`
(SHA-256 `0c640240282f225fb4140f0da78e45337cdfaecfb1fc8903d711ae9c5c86a09d`,
lines `709--726` and `867--879`): that document correctly reported a
backend-equivalence PASS but did not reproduce the fixture coordinates.

## Operator lineage v25 -> v26-SYM1 -> v27

The exact installed historical v25 payload is still readable under
`D:/Descargas/ANACONDA MINICONDA/Lib/site-packages/dee_universe_v25/`:

- binary `dee_kernel_v25.cp313-win_amd64.pyd`, SHA-256
  `a7529600bc2c11c106df087bc831d9a01dab2e878d8e4f9c95de5cb8a5fffe65`;
- source `dee_kernel_v25.cpp`, SHA-256
  `4c310f27dc1e6d79192714833e456033a7f415d10d9f5bc833edaa4e2f8f4bfe`.

That binary hash is the one recorded by the historical v23.1 result and the
v25 technical documentation.  In the v25 source, `buscar_fuente_demux`
(`187--200`) returns the first directional neighbour which points to the empty
destination; the empty branch repacks it as state 1/normal semantic while
copying charge and direction (`274--307`).  Therefore the single-source proof
is already valid in v25.

v26-SYM1 changed only the multiple-source selection: v27 source lines
`187--225` retain the exact sole-source raw but replace v25 first-match with the
commutative capped-sum/sign reducer.  v27 then changes the numerical kernel
threshold/cap to `P_KERNEL=19665`, without touching one-source transport.

Consequences:

- T8.1--T8.5 are a broad, preregistered v27 generalization and formal closure
  of the exact historical singleton mechanism.
- T8.6 is **not retroactive to v25**.  The v25 collision chose the first Moore
  match; the v27 collision combines all sources.  Only collision-free
  trajectories can be carried cleanly across this lineage.

## Relation to F-137 (`sparse_directional`, v23.1-A)

This is adjacent lineage, not the literal `TORUS_MOVING` case.  Here the
primary runner and JSON are available in the forensic bundle:

- runner
  `ANALYSIS/docs_claims/volume2_forensic_bundle/sources/dee_v25_final_volume2_closure_v23_1_part_a.py`,
  SHA-256
  `ec69a9513be49ad2006d4c6a20dd673ad0745b641be0ecf4231c374e3eeb01b2`;
- JSON
  `ANALYSIS/docs_claims/volume2_forensic_bundle/sources/DEE_V25_FINAL_VOLUME2_CLOSURE_V23_1_PART_A.json`,
  SHA-256
  `ac4097bc09d38fcc06dc4e4647ae6338d66e7f6e0a877dc0b81ee3756b7c4bad`;
- exact v25 kernel binary SHA-256 `a7529600...fe65`.

The seed constructor (`runner 1214--1228`) is not a singleton.  For
`sparse_directional` it creates random clouds with state 1, normal semantic,
random `s_reg in [0,16]`, and independently random nonzero Moore directions.
At `density_divisor=64`, the four tested sizes start with respectively 216,
465, 1,622 and 4,096 occupied sites for `N=24,31,47,64`.

`RECURRENCEPROJECTION231X` (`1973--2001`) runs two replicates per size for
1,600 ticks and hashes packed/state/direction/semantic/sreg plus clock modulo
391/782.  The primary JSON records `P=N` for all five raw projections in all
eight directional trials, `P=1` for the eight quiescent controls, and clock
projection periods 391/782.

T8 makes `P=N` mechanistically natural for any surviving isolated singleton,
but it does **not prove** that these random clouds were collision-free or that
their tail was a noninteracting gas.  They contain many directions and can
collide; v25 resolves such collisions by first-match.  The JSON retains hashes
and periods, not tail snapshots/decompositions.  F-137 therefore remains a
strong preparation- and projection-specific empirical recurrence, not a
corollary of T8.  The new theorem supplies a candidate microscopic substrate,
not a retroactive causal decomposition.

## Relation to F-189 (`P=L_sym`, v25.5-C)

As with `TORUS_MOVING`, the primary files were absent from the copied v27
corpus but remain in the historical
`D:/GENESIS AI/GENESIS 5.0/simulador de universo ab-initio/dee_libreria/VERSION_25/tests/`
directory.  Both hashes match the secondary synthesis:

- ZIP `DEE_V25_5_NATIVE_FREQUENCY_SCALE_RECURRENCE_PART_C_V1.zip`, SHA-256
  `c0402e58bc1541f929fc2b4726e926d2dec5131332abfddb62f2f6e1ba17ab5b`;
- runner `dee_v25_5_native_frequency_scale_recurrence_part_c_v1.py`, SHA-256
  `939e0ca75585e6bdc3422ddf238fd9121bbf2668483588a2a400a211afbd3a47`;
- primary JSON inside the ZIP, 3,350,422 bytes, SHA-256
  `7beb816ea781ab9dce18837ee0fd0c673301816914847b260d4eecd91a1edb4d`.
- summary inside the ZIP, 15,275 bytes, SHA-256
  `e4acc4653a0dfc1be2bdc3c8838b6db674e9bd97c9dd182d94f9874bcc475fab`.

Every ZIP manifest entry was independently rehashed and matched its declared
size and SHA-256, including the embedded runner (62,727 bytes, the same
`939e0ca7...47` hash above).

The exact generator (`runner 953--995`) places identical state-1, `s_reg=0`,
normal-semantic raws every `L` sites on one axis, all pointing `+1` along that
axis.  The atlas uses `N={24,30,36,42}`, all three axes, and spacings
`{4,6,8,12,24}`, `{5,6,10,15,30}`, `{6,9,12,18,36}`, and
`{6,7,14,21,42}` respectively (`1135--1166`).  Every spacing is at least four,
so these are exactly noninteracting T8 singletons, not merely a compatible
interpretation.

Moreover, every step explicitly compares the actual full raw array with
`np.roll(previous,1,axis)` (`1093--1106`).  The primary JSON contains 2,226
such directional step comparisons across 60 trials: every Hamming distance is
zero, every `translation_exact_fraction` is 1.0, and occupancy is preserved.
The blind periods equal `L_sym` in 60/60 for packed raw, state, direction and
semantic.  The standalone `s_reg` projection has period 1 in 60/60 because it
is identically zero everywhere; it should not be listed as an `L_sym` field.
The three matched directionless controls extinguish and have packed period 1.

Therefore F-189 is not just strengthened conditionally: its main directional
atlas is an empirical many-singleton instance of the same shift sector, and
its `P=L_sym` law is the immediate group-action corollary of exact translation
plus the prepared support symmetry.  T8 extends that mechanism from three
positive axes/zero charge/periodic lanes to all 26 directions, all `uint16`
charges, arbitrary positive state after normalization, arbitrary clocks, and
v27's dense/lazy/thread implementations.  The nested multi-lane and
symmetry-breaking modules remain additional empirical constructions rather
than consequences of the one-lane theorem alone.

## What historical claims change

1. **Changed:** “`TORUS_MOVING` was only a suggestive label” is false after
   recovering the primary runner/result.  It was one normal directional
   singleton, it crossed the periodic boundary at tick 1, and its 12 stored
   hashes reconstruct exactly the ballistic path.
2. **Changed for v27:** any blanket assertion that no persistent moving raw,
   coordinate `q(t)`, or exact native velocity has been demonstrated must now
   be restricted.  T8 proves `q(t)=q0+t*d`, 26 velocity channels, raw identity
   along the free trajectory, and exact Fourier phase in the vacuum singleton
   sector.
3. **Not changed:** the clock is not carried by the mover, and synchronous
   destroy/recreate of an identical raw does not by itself establish a
   metaphysical “same piece of matter”.  No external units or Rosetta map were
   supplied.
4. **Not changed:** C7's 9/9 `no_resolved_group_mode` result concerns a
   perturbation packet in an occupied pre-evolved medium.  A one-particle shift
   eigenphase is not a resolved many-body collective packet or physical group
   velocity.  T8 only refutes a domain-free “no moving mode anywhere” claim.
5. **Narrowed:** old phrases such as “mobile conservative carriers” now have a
   rigorous example for collision-free raw transport, but not global
   conservation.  Two-source collisions reduce support `2->1`, may saturate
   `s_reg`, can erase opposite directions one tick later, and eight-source
   symmetry can be preempted by XNOR.
6. **Split conclusion:** F-137 remains a random-cloud empirical recurrence for
   which T8 supplies only a candidate tail mechanism.  F-189's primary runner
   and JSON explicitly establish the missing premises—spaced identical
   singletons and zero shift Hamming at every step—so its main `P=L_sym` atlas
   is directly subsumed by the exact shift theorem (while retaining its stated
   experimental domain and hash provenance).
