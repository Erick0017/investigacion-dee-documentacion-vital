# Progress

- [x] Verified the root's sealed T8 preregister and exact SHA-256.
- [x] Wrote and hashed the execution reduction before seeing any T8 binary
  result.
- [x] Wrote, syntax-checked, and hashed the independent runner before kernel
  import.
- [x] Ran exactly one independent v27 panel through the isolated extracted
  wheel; no install, venv, or global-Python mutation.
- [x] Retained all cases, hashes, inputs, outputs, and mismatches in the primary
  JSON.
- [x] Proved the universal singleton branch and exact period statically.
- [x] Exhausted all unordered two-direction collisions for the frozen factors.
- [x] Audited scope breakers: state-0 words, semantics, observers, occupied
  targets, XNOR precedence, and raw-versus-full recurrence.
- [x] Recovered and verified primary `TORUS_MOVING`, F-137, and F-189 sources
  and results without executing a historical kernel.
- [x] Corrected the historical interpretation, including
  `sreg_projection P=1` and sectoral—not universal—`P=L_sym`.
- [x] Produced package-ready narrative, compact corrections, machine-readable
  findings, command log, and checksum manifest.

Final status: **complete; PASS with scoped interpretation; zero discrepancies
against the preregistered primary predictions.**

