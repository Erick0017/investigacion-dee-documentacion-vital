# T8 independent panel — reduction frozen before binary results

Status: **SEALED BEFORE THE FIRST T8 BINARY EXECUTION**  
Seal time: 2026-09-11, America/Mexico_City  
T8 seed: `270819665`

## Upstream seal checked

- Preregister: `HOLDOUTS/PREREGISTER_T8_BALLISTIC_SINGLETON.md`
- Observed SHA-256: `0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb`
- Required SHA-256 communicated by the root: identical.
- Wheel and extracted kernel identities remain the already audited values. This
  panel will assert them before import and will not reinstall or re-extract.

At the time this file was written, no trajectory constructed to test T8 had
been executed against the binary. Static reading of the sealed C++ source was
the discovery step and is not counted as holdout evidence.

## Frozen execution reduction

The literal Cartesian singleton panel would repeat factors which the source
uses in disjoint operations: `state` is overwritten with 1 at the empty
destination, `s_reg` and direction are copied, every clock word is incremented
independently, and dense/lazy/thread variants call the same voxel transition.
The independent panel therefore uses the following strength-2 covering design,
backed by an exhaustive branch proof. No direction, size, state, charge, clock
family, or implementation family is omitted.

### Singleton trajectories (H8.1--H8.4)

- Full `26 directions × N in {11,13} × state in {1,2,4294967295} ×
  s_reg in {0,1,19664,65535}`: 624 trajectories, each through `2*N+3` ticks.
- Position generation is frozen as NumPy `Generator(PCG64(270819665))`, drawing
  each coordinate uniformly from `[0,N)` in lexicographic case order.
- Let `j=4*state_index+sreg_index`. For direction index `k` and size index `n`,
  assign clock family `(j+k+n) mod 3` and implementation family
  `(j+k+2*n) mod 4`. Families are ordered as clocks
  `[zero, heterogeneous, near_wrap]` and implementations
  `[dense/1, dense/2, lazy/1, lazy/2]`.
- Because 3 and 4 are coprime, the 12 `(state,s_reg)` rows cover all 12
  clock/implementation pairs once for every `(direction,N)`, with rotations
  across directions and sizes. Across the full design, each concrete state and
  charge is exercised under every clock and implementation family.
- Every tick is compared with the exact translated raw array and exact
  pointwise clock `clock_0+t (mod 2^64)`. Buffer hashes, position and inputs are
  retained. Fourier ratios for the four preregistered modes are checked on all
  `state=1` trajectories through tick `N+1`, tolerance `5e-12`.

Clock arrays are frozen as:

- zero: every word 0;
- heterogeneous: flattened word `i` is
  `i*6364136223846793005 + case_id*1442695040888963407 (mod 2^64)`;
- near-wrap: flattened word `i` is `2^64-1-((i+case_id) mod 3)`.

This removes only higher-order Cartesian repetitions. Logical coverage is
preserved by the branch proof plus the covering array: every value and every
clock/implementation pair occurs for each direction and size.

### Two separated movers (H8.5)

No implementation/clock reduction: the three frozen direction families
`(1,0,0)`, `(1,1,0)`, `(1,1,1)` are each run under all 12
clock/implementation pairs in `N=17` for 23 ticks. Initial positions are
`(2,3,4)` and `(7,3,4)`, toroidal Chebyshev separation 5; raws have
`state=1, semantic=1` and respective `s_reg=7,65535`.

### Two-source collisions (H8.6)

No reduction: all 325 unordered distinct direction pairs, all four frozen load
pairs, all three clock families and all four implementations are run for two
ticks in `N=11`. The target is `(5,5,5)` and the two sources are exactly
`q-d1`, `q-d2`. This is 15,600 two-tick runs. Tick 1 and tick 2 are both
checked, including support cardinality and every raw word.

## Frozen exploratory scope probes (not adjudicative)

These do not alter H8 PASS/FAIL and are declared now to avoid result-driven
selection:

1. Directional singleton sources with `state=0` or semantic in
   `{0,2,3,4,15}`; determine whether transport tests existence/semantic.
2. A normal occupied target and an observer target in the path of a normal
   singleton; determine whether transport crosses occupied sites.
3. Eight sources arranged as four opposite Moore pairs all pointing to the
   same empty target; test whether XNOR priority shadows the DEMUX reducer.
4. Compare raw recurrence at `N` with the complete `(raw,clock)` state for a
   heterogeneous clock field.

## Adjudication and output policy

- Primary PASS requires zero exact mismatches for H8.1--H8.6 in the reduced
  execution and a complete source proof for the universal promotion.
- A mismatch is retained verbatim and not refit.
- Exploratory probes may restrict interpretation but cannot rescue a primary
  FAIL.
- The runner and all generated material are confined to
  `ANALYSIS/ballistic_independent/`.
