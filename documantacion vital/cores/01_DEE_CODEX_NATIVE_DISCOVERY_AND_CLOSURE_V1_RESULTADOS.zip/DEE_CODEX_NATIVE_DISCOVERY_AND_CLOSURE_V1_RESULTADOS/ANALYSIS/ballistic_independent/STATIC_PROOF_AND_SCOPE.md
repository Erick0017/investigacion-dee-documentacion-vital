# T8 static proof and exact scope

Target source: the C++ file shipped in the accepted v27 wheel, SHA-256
`44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.
Line references below are to
`ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cpp`.

## The one-particle theorem

Let `N>=5`.  At time zero let the raw field be zero except at `q`, where

`r = pack(state, s, dx, dy, dz, SEM_NORMAL)`

with `state>0`, `s in [0,65535]`, and
`d=(dx,dy,dz) in {-1,0,1}^3 \ {0}`.  Let clocks be arbitrary `uint64` words.
Then, after one tick, the sole nonzero raw is

`r* = pack(1, s, dx, dy, dz, SEM_NORMAL)` at `q+d (mod N)`.

For every `t>=1`, the sole nonzero raw is the same `r*` at
`q+t*d (mod N)`.  If the initial state was already 1, the formula also holds
at `t=0`.

### Exhaustive branch argument

1. The source site is not an observer (`247`).  It has no live neighbour, so
   `n_active=0` (`249--277`), no tetrahedral signature, and `rule_value=0`
   (`338--347`).  It becomes raw zero.
2. The intended destination is empty.  Crystallization cannot occur (proof
   below), and one active neighbour cannot pass the eight-active XNOR gate
   (`160--170`, `299--315`).  `buscar_fuente_demux` finds the source because
   it tests `source_coordinate + source_direction == destination` (`187--215`).
   With one source it returns the exact raw (`217--218`), and the empty branch
   repacks it with state 1 and semantic normal while copying `s_reg` and all
   direction nibbles (`317--321`).
3. Any other empty site fails crystallization and XNOR.  The unique source
   points to only one destination, so it has no DEMUX source and remains zero
   (`317--332`).
4. Every branch used sets the local clock to its previous value plus one
   (`305`, `312`, `320`, `326`, `331`, `346`).  Unsigned arithmetic makes
   this exact modulo `2^64`.  None of the three raw decisions reaches a
   clock-dependent condition.
5. These statements reproduce the same hypothesis one tick later, proving the
   trajectory by induction.

The dense implementation evaluates `actualizar_voxel` at every site and then
copies B to A (`451--500`).  The lazy implementation initializes every clock
with `+1`, evaluates every nonzero raw plus its complete Moore halo with the
same function, applies the same post-pass, and performs the same copyback
(`567--667`).  Thread slabs/chunks write distinct output sites from immutable
A; the only atomics are counters/post-pass deltas.  No DEMUX post-pass delta is
created in this theorem.  Therefore engine and thread count cannot change the
result.

### Why crystallization is impossible

For one coordinate sign vector `sigma in {+1,-1}^3`, duality of the L1 norm
gives

`max sum_j |grad_j| = 65535 * max_sigma sum_{u in Moore} max(0,sigma dot u)`.

Direct enumeration of the 26 Moore offsets gives 15 for every sign class, so
the exact global maximum is `15*65535 = 983025`.  The branch requires, because
of integer division,

`grad_mag >= P_KERNEL*UMBRAL_CRISTALIZACION = 19665*966 = 18996390`.

Thus the first empty-site branch at `299--307` is unreachable for every v27
raw field, not merely for T8.

## Period, Fourier phase and reversibility

At least one component of `d` is `+1` or `-1`, hence the additive order of `d`
in `Z_N^3` is exactly `N`.  The singleton raw period is exactly `N`, not just a
divisor of `N`.

For the frozen convention

`rho_hat(m,t) = sum_x rho(x,t) exp(-2*pi*i*m.x/N)`,

the delta support gives exactly

`rho_hat(m,t+1)/rho_hat(m,t) = exp(-2*pi*i*m.d/N)`.

This is an eigenphase of the restricted shift operator.  It is valid to call
it exact lattice advection.  Calling it a many-body *collective mode*, a
physical energy dispersion, momentum, light, or matter requires additional
definitions and evidence not present in T8.

The raw restriction is a permutation and is invertible by shifting `-d`.
Including clocks does not destroy mathematical bijectivity: the inverse also
subtracts one from every clock word.  For an already normalized state-1
singleton, the minimal temporal period of the complete raw-plus-clock state is

`lcm(N, 2^64)`,

whereas its raw projection has period `N`.  Clock values are site-local and are
not transported with the raw; this is an important limit on any object
interpretation.

## Two noncolliding movers

For two distinct normal state-1 raws with the same `d`, exact joint translation
does not fundamentally require separation four.  For two sources, XNOR is
impossible and each occupied source has at most one live neighbour, so its
matter rule returns zero.  The exact necessary branch condition for the simple
translation proof is that neither destination is occupied initially:

`p1+d != p2` and `p2+d != p1 (mod N)`.

Separation at least two is sufficient; separation one can also work when the
relative displacement is not `+d` or `-d`.  The preregistered separation five
is therefore conservative and clean.  For more than two movers, one must also
exclude XNOR configurations and matter-branch survivors; pairwise spacing is
not automatically a many-body superposition theorem.

## Exact isolated two-source collision

Put normal state-1 sources at `q-d1` and `q-d2`, with `d1!=d2`, and leave `q`
empty.  With only two sources, the unreachable crystal branch and the
eight-active XNOR gate cannot preempt the reducer.  Lines `194--225` therefore
give at tick 1:

`pack(1, min(s1+s2,19664), sign(d1+d2), SEM_NORMAL)` at `q`,

with every other raw zero.  The formula is commutative in the two sources.
At tick 2 it follows the singleton theorem if its direction is nonzero; if
`d2=-d1`, its zero-direction raw has no outgoing destination and dies.

Among all 325 unordered pairs of the 26 velocities, 13 are opposite and die at
tick 2; the other 312 continue.  In the executed 12 implementation/clock
variants and four loads, that is 624 dying cases and 14,976 continuing cases.
The tested loads reduce to charges `0`, `3`, `19664`, and `19664`; half of the
15,600 cases exercise saturation.

This collision is support-inelastic (`2 -> 1`) and can lose `s_reg` through
saturation.  Even without saturation, an opposite collision loses the
aggregate raw on the next tick.  `direction` is reduced by componentwise sign,
not conserved as an integer vector.  None of those fields has thereby been
identified as physical particle number, energy, or momentum.

The formula is not a context-free law for arbitrarily many incoming sources.
The empty-site order is crystal, XNOR, then DEMUX (`299--321`).  Eight incoming
sources arranged as four antipodal pairs satisfy XNOR first; the sealed scope
probe observed the target raw `(state=1,s_reg=1,d=0,semantic=7)`, not a SYM1
sum.  An occupied or observer target likewise never enters the empty DEMUX
branch.

## Wider implementation behavior, and why T8 is restricted

`buscar_fuente_demux` checks direction and geometry but not `state`, existence,
or semantic (`204--214`).  Consequently:

- a directional raw with `state=0` can nucleate the normal state-1 mover;
- any nonobserver semantic is normalized to semantic 1 at the destination;
- a semantic-4 observer source is preserved pointwise by `247` and also emits
  a semantic-1 copy, so it is a persistent broadcaster, not a translating
  singleton;
- a normal occupied target blocks the empty transport and can annihilate both
  raws; an observer target remains fixed and blocks the arrival;
- arbitrary occupied backgrounds can trigger XNOR or matter branches and
  invalidate free translation.

The binary scope probes observed each of these selected consequences.  The
clean result is therefore an exact **vacuum raw-transport sector**, not a robust
particle in arbitrary media and not a basin of attraction.
