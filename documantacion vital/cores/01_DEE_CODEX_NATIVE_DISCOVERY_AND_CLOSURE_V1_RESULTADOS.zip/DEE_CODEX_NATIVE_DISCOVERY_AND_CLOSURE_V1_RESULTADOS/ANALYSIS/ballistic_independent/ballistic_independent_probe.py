#!/usr/bin/env python3
"""Independent, preregistered v27 ballistic-singleton holdout.

This runner imports the already extracted local wheel payload directly.  It
does not install a package, create an environment, or modify the extraction.
"""
from __future__ import annotations

import cmath
import hashlib
import importlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
OUTDIR = HERE.parent
WORK = HERE.parents[2]
TESTS = WORK.parent
EXTRACTED = WORK / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKGDIR = EXTRACTED / "dee_universe_v27"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_BIN = PKGDIR / "dee_kernel_v27.cp313-win_amd64.pyd"
KERNEL_SOURCE = PKGDIR / "dee_kernel_v27.cpp"
PREREG = WORK / "HOLDOUTS" / "PREREGISTER_T8_BALLISTIC_SINGLETON.md"
REDUCTION = OUTDIR / "REDUCTION_BEFORE_RESULTS.md"
RUN_SEAL = OUTDIR / "RUN_SEAL.json"
OUTPUT = OUTDIR / "ballistic_probe_results.json"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "source": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
    "preregister": "0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb",
    "reduction": "bab477c1f705fffcad678ccd7a1417c825ec3c9b96255f98cb789834ff10441f",
}

T8_SEED = 270819665
MASK64 = (1 << 64) - 1
STATE_MASK = np.uint64(0xFFFFFFFF)
P_CAP = 19664
DIRECTIONS = [
    (dx, dy, dz)
    for dx in (-1, 0, 1)
    for dy in (-1, 0, 1)
    for dz in (-1, 0, 1)
    if (dx, dy, dz) != (0, 0, 0)
]
SIZES = [11, 13]
STATES = [1, 2, 0xFFFFFFFF]
SREGS = [0, 1, 19664, 65535]
CLOCK_FAMILIES = ["zero", "heterogeneous", "near_wrap"]
IMPLEMENTATIONS = [
    ("dense", 1),
    ("dense", 2),
    ("lazy", 1),
    ("lazy", 2),
]
MODES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 2, 3)]
LOADS = [(0, 0), (1, 2), (19664, 1), (65535, 65535)]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(a)).cast("B")).hexdigest()


def pack(state: int, sreg: int, direction: tuple[int, int, int], semantic: int = 1) -> np.uint64:
    dx, dy, dz = direction
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((dx & 0xF) << 48)
        | ((dy & 0xF) << 52)
        | ((dz & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def unpack(raw: int | np.uint64) -> dict[str, int]:
    v = int(raw)

    def nibble(shift: int) -> int:
        n = (v >> shift) & 0xF
        return n - 16 if n & 8 else n

    return {
        "raw": v,
        "state": v & 0xFFFFFFFF,
        "s_reg": (v >> 32) & 0xFFFF,
        "dx": nibble(48),
        "dy": nibble(52),
        "dz": nibble(56),
        "semantic": (v >> 60) & 0xF,
    }


def clock_array(n: int, family: str, case_id: int) -> np.ndarray:
    total = n**3
    i = np.arange(total, dtype=np.uint64)
    if family == "zero":
        return np.zeros(total, dtype=np.uint64)
    if family == "heterogeneous":
        salt = np.uint64((case_id * 1442695040888963407) & MASK64)
        return np.add(
            np.multiply(i, np.uint64(6364136223846793005), dtype=np.uint64),
            salt,
            dtype=np.uint64,
        )
    if family == "near_wrap":
        residue = np.remainder(
            np.add(i, np.uint64(case_id & MASK64), dtype=np.uint64),
            np.uint64(3),
        )
        return np.subtract(np.uint64(MASK64), residue, dtype=np.uint64)
    raise ValueError(f"unknown clock family {family}")


def add_clock(initial: np.ndarray, tick: int) -> np.ndarray:
    return np.add(initial, np.uint64(tick), dtype=np.uint64)


def support_positions(flat: np.ndarray, n: int) -> list[list[int]]:
    alive = np.bitwise_and(flat, STATE_MASK) != 0
    return [[int(x) for x in row] for row in np.argwhere(alive.reshape(n, n, n))]


def nonzero_positions(flat: np.ndarray, n: int) -> list[list[int]]:
    return [[int(x) for x in row] for row in np.argwhere(flat.reshape(n, n, n) != 0)]


def mismatch_record(kind: str, case: str, tick: int, actual: np.ndarray, expected: np.ndarray) -> dict:
    indices = np.flatnonzero(actual != expected)
    return {
        "kind": kind,
        "case": case,
        "tick": tick,
        "different_words": int(indices.size),
        "differences": [
            {
                "flat_index": int(i),
                "actual": int(actual[i]),
                "expected": int(expected[i]),
            }
            for i in indices
        ],
    }


class Simulation:
    def __init__(
        self,
        kernel,
        n: int,
        raw: np.ndarray,
        clock: np.ndarray,
        engine: str,
        threads: int,
    ) -> None:
        self.n = n
        self.raw_a = np.ascontiguousarray(raw, dtype=np.uint64).reshape(-1).copy()
        self.raw_b = np.zeros_like(self.raw_a)
        self.clock_a = np.ascontiguousarray(clock, dtype=np.uint64).reshape(-1).copy()
        self.clock_b = np.zeros_like(self.clock_a)
        self.fn = kernel.tick_universo_lazy if engine == "lazy" else kernel.tick_universo
        self.threads = threads

    def step(self) -> tuple[dict, bool]:
        info = dict(
            self.fn(
                self.raw_a,
                self.raw_b,
                self.clock_a,
                self.clock_b,
                int(self.n),
                int(self.threads),
            )
        )
        buffers_equal = bool(
            np.array_equal(self.raw_a, self.raw_b)
            and np.array_equal(self.clock_a, self.clock_b)
        )
        clean_info = {
            str(k): int(v) if isinstance(v, (int, np.integer)) else float(v)
            for k, v in info.items()
        }
        return clean_info, buffers_equal


def expected_singleton(n: int, q0: tuple[int, int, int], direction: tuple[int, int, int], sreg: int, tick: int) -> np.ndarray:
    out = np.zeros(n**3, dtype=np.uint64)
    q = tuple((q0[a] + tick * direction[a]) % n for a in range(3))
    out[np.ravel_multi_index(q, (n, n, n))] = pack(1, sreg, direction, 1)
    return out


def rho_hat(flat: np.ndarray, n: int, mode: tuple[int, int, int]) -> complex:
    alive = (np.bitwise_and(flat, STATE_MASK) != 0).reshape(n, n, n)
    coords = np.argwhere(alive)
    return sum(
        cmath.exp(-2j * math.pi * sum(int(mode[a]) * int(q[a]) for a in range(3)) / n)
        for q in coords
    )


def check_arrays(result: dict, case: str, tick: int, sim: Simulation, expected_raw: np.ndarray, expected_clock: np.ndarray, buffers_equal: bool) -> None:
    if not np.array_equal(sim.raw_a, expected_raw):
        result["mismatches"].append(mismatch_record("raw", case, tick, sim.raw_a, expected_raw))
    if not np.array_equal(sim.clock_a, expected_clock):
        result["mismatches"].append(mismatch_record("clock", case, tick, sim.clock_a, expected_clock))
    if not buffers_equal:
        result["mismatches"].append(
            {"kind": "A_B_copyback", "case": case, "tick": tick, "different_words": None}
        )


def singleton_panel(kernel, result: dict) -> None:
    rng = np.random.Generator(np.random.PCG64(T8_SEED))
    records = []
    max_fourier_error = 0.0
    total = len(DIRECTIONS) * len(SIZES) * len(STATES) * len(SREGS)
    counter = 0
    for k, direction in enumerate(DIRECTIONS):
        for n_index, n in enumerate(SIZES):
            for state_index, state in enumerate(STATES):
                for sreg_index, sreg in enumerate(SREGS):
                    j = 4 * state_index + sreg_index
                    clock_name = CLOCK_FAMILIES[(j + k + n_index) % 3]
                    engine, threads = IMPLEMENTATIONS[(j + k + 2 * n_index) % 4]
                    case_id = counter
                    q0 = tuple(int(x) for x in rng.integers(0, n, size=3))
                    raw0 = np.zeros(n**3, dtype=np.uint64)
                    raw0[np.ravel_multi_index(q0, (n, n, n))] = pack(state, sreg, direction, 1)
                    clock0 = clock_array(n, clock_name, case_id)
                    sim = Simulation(kernel, n, raw0, clock0, engine, threads)
                    case = f"singleton-{case_id:04d}"
                    rec = {
                        "case": case,
                        "N": n,
                        "q0": list(q0),
                        "direction": list(direction),
                        "state": state,
                        "s_reg": sreg,
                        "clock_family": clock_name,
                        "engine": engine,
                        "threads": threads,
                        "initial_raw_hash": sha256_array(raw0),
                        "initial_clock_hash": sha256_array(clock0),
                        "ticks": [],
                        "fourier": [],
                    }
                    prior_fourier = {mode: rho_hat(sim.raw_a, n, mode) for mode in MODES} if state == 1 else {}
                    for tick in range(1, 2 * n + 4):
                        info, buffers_equal = sim.step()
                        expected_raw = expected_singleton(n, q0, direction, sreg, tick)
                        expected_clock = add_clock(clock0, tick)
                        check_arrays(result, case, tick, sim, expected_raw, expected_clock, buffers_equal)
                        positions = support_positions(sim.raw_a, n)
                        rec["ticks"].append(
                            {
                                "tick": tick,
                                "raw_hash": sha256_array(sim.raw_a),
                                "clock_hash": sha256_array(sim.clock_a),
                                "support": positions,
                                "buffers_equal": buffers_equal,
                                "kernel_info": info,
                            }
                        )
                        if state == 1 and tick <= n + 1:
                            for mode in MODES:
                                current = rho_hat(sim.raw_a, n, mode)
                                denominator = prior_fourier[mode]
                                if abs(denominator) == 0:
                                    continue
                                actual = current / denominator
                                phase = -2.0 * math.pi * sum(mode[a] * direction[a] for a in range(3)) / n
                                expected = cmath.exp(1j * phase)
                                error = abs(actual - expected)
                                max_fourier_error = max(max_fourier_error, error)
                                rec["fourier"].append(
                                    {
                                        "tick": tick,
                                        "mode": list(mode),
                                        "actual": [actual.real, actual.imag],
                                        "expected": [expected.real, expected.imag],
                                        "abs_error": error,
                                    }
                                )
                                if error > 5e-12:
                                    result["mismatches"].append(
                                        {
                                            "kind": "fourier_ratio",
                                            "case": case,
                                            "tick": tick,
                                            "mode": list(mode),
                                            "actual": [actual.real, actual.imag],
                                            "expected": [expected.real, expected.imag],
                                            "abs_error": error,
                                        }
                                    )
                                prior_fourier[mode] = current
                    if state == 1:
                        at_n = rec["ticks"][n - 1]["raw_hash"]
                        if at_n != rec["initial_raw_hash"]:
                            result["mismatches"].append(
                                {"kind": "raw_cycle_N", "case": case, "tick": n, "different_words": None}
                            )
                    records.append(rec)
                    counter += 1
                    if counter % 52 == 0:
                        print(f"singleton progress {counter}/{total}", flush=True)
    result["singleton"] = {
        "case_count": len(records),
        "max_fourier_abs_error": max_fourier_error,
        "records": records,
    }


def two_mover_panel(kernel, result: dict, case_id_start: int) -> int:
    records = []
    q1 = (2, 3, 4)
    q2 = (7, 3, 4)
    n = 17
    case_id = case_id_start
    for direction in [(1, 0, 0), (1, 1, 0), (1, 1, 1)]:
        for clock_name in CLOCK_FAMILIES:
            for engine, threads in IMPLEMENTATIONS:
                raw0 = np.zeros(n**3, dtype=np.uint64)
                raw0[np.ravel_multi_index(q1, (n, n, n))] = pack(1, 7, direction, 1)
                raw0[np.ravel_multi_index(q2, (n, n, n))] = pack(1, 65535, direction, 1)
                clock0 = clock_array(n, clock_name, case_id)
                sim = Simulation(kernel, n, raw0, clock0, engine, threads)
                case = f"two-mover-{case_id:05d}"
                rec = {
                    "case": case,
                    "N": n,
                    "positions": [list(q1), list(q2)],
                    "direction": list(direction),
                    "s_regs": [7, 65535],
                    "clock_family": clock_name,
                    "engine": engine,
                    "threads": threads,
                    "initial_raw_hash": sha256_array(raw0),
                    "initial_clock_hash": sha256_array(clock0),
                    "ticks": [],
                }
                for tick in range(1, 24):
                    expected_raw = np.zeros(n**3, dtype=np.uint64)
                    for q, sreg in ((q1, 7), (q2, 65535)):
                        qt = tuple((q[a] + tick * direction[a]) % n for a in range(3))
                        expected_raw[np.ravel_multi_index(qt, (n, n, n))] = pack(1, sreg, direction, 1)
                    info, buffers_equal = sim.step()
                    expected_clock = add_clock(clock0, tick)
                    check_arrays(result, case, tick, sim, expected_raw, expected_clock, buffers_equal)
                    rec["ticks"].append(
                        {
                            "tick": tick,
                            "raw_hash": sha256_array(sim.raw_a),
                            "clock_hash": sha256_array(sim.clock_a),
                            "support": support_positions(sim.raw_a, n),
                            "buffers_equal": buffers_equal,
                            "kernel_info": info,
                        }
                    )
                records.append(rec)
                case_id += 1
    result["two_movers"] = {"case_count": len(records), "records": records}
    print(f"two-mover progress {len(records)}/{len(records)}", flush=True)
    return case_id


def collision_expected(n: int, q: tuple[int, int, int], direction: tuple[int, int, int], sreg: int, tick: int) -> np.ndarray:
    out = np.zeros(n**3, dtype=np.uint64)
    if tick == 1:
        out[np.ravel_multi_index(q, (n, n, n))] = pack(1, sreg, direction, 1)
    elif direction != (0, 0, 0):
        q2 = tuple((q[a] + direction[a]) % n for a in range(3))
        out[np.ravel_multi_index(q2, (n, n, n))] = pack(1, sreg, direction, 1)
    return out


def collision_panel(kernel, result: dict, case_id_start: int) -> int:
    records = []
    n = 11
    q = (5, 5, 5)
    unordered_pairs = [
        (DIRECTIONS[i], DIRECTIONS[j])
        for i in range(len(DIRECTIONS))
        for j in range(i + 1, len(DIRECTIONS))
    ]
    case_id = case_id_start
    total = len(unordered_pairs) * len(LOADS) * len(CLOCK_FAMILIES) * len(IMPLEMENTATIONS)
    done = 0
    for pair_index, (d1, d2) in enumerate(unordered_pairs):
        p1 = tuple((q[a] - d1[a]) % n for a in range(3))
        p2 = tuple((q[a] - d2[a]) % n for a in range(3))
        for s1, s2 in LOADS:
            out_sreg = min(s1 + s2, P_CAP)
            out_direction = tuple(1 if d1[a] + d2[a] > 0 else -1 if d1[a] + d2[a] < 0 else 0 for a in range(3))
            for clock_name in CLOCK_FAMILIES:
                for engine, threads in IMPLEMENTATIONS:
                    raw0 = np.zeros(n**3, dtype=np.uint64)
                    raw0[np.ravel_multi_index(p1, (n, n, n))] = pack(1, s1, d1, 1)
                    raw0[np.ravel_multi_index(p2, (n, n, n))] = pack(1, s2, d2, 1)
                    clock0 = clock_array(n, clock_name, case_id)
                    sim = Simulation(kernel, n, raw0, clock0, engine, threads)
                    case = f"collision-{case_id:05d}"
                    rec = {
                        "case": case,
                        "pair_index": pair_index,
                        "N": n,
                        "target": list(q),
                        "directions": [list(d1), list(d2)],
                        "source_positions": [list(p1), list(p2)],
                        "loads": [s1, s2],
                        "expected_output_direction": list(out_direction),
                        "expected_output_s_reg": out_sreg,
                        "clock_family": clock_name,
                        "engine": engine,
                        "threads": threads,
                        "initial_raw_hash": sha256_array(raw0),
                        "initial_clock_hash": sha256_array(clock0),
                        "ticks": [],
                    }
                    for tick in (1, 2):
                        info, buffers_equal = sim.step()
                        expected_raw = collision_expected(n, q, out_direction, out_sreg, tick)
                        expected_clock = add_clock(clock0, tick)
                        check_arrays(result, case, tick, sim, expected_raw, expected_clock, buffers_equal)
                        target_raw = int(sim.raw_a[np.ravel_multi_index(q, (n, n, n))])
                        rec["ticks"].append(
                            {
                                "tick": tick,
                                "raw_hash": sha256_array(sim.raw_a),
                                "clock_hash": sha256_array(sim.clock_a),
                                "support": support_positions(sim.raw_a, n),
                                "target_raw": unpack(target_raw),
                                "buffers_equal": buffers_equal,
                                "kernel_info": info,
                            }
                        )
                    records.append(rec)
                    case_id += 1
                    done += 1
                    if done % 1300 == 0:
                        print(f"collision progress {done}/{total}", flush=True)
    result["collisions"] = {
        "unordered_direction_pairs": len(unordered_pairs),
        "load_pairs": len(LOADS),
        "case_count": len(records),
        "records": records,
    }
    return case_id


def exploratory_panel(kernel, result: dict, case_id_start: int) -> None:
    records = []
    n = 11
    q0 = (4, 4, 4)
    direction = (1, -1, 0)
    q1 = tuple((q0[a] + direction[a]) % n for a in range(3))
    case_id = case_id_start

    for state, semantic in [(0, 1), (1, 0), (1, 2), (1, 3), (1, 4), (1, 15)]:
        raw0 = np.zeros(n**3, dtype=np.uint64)
        raw0[np.ravel_multi_index(q0, (n, n, n))] = pack(state, 11, direction, semantic)
        clock0 = clock_array(n, "heterogeneous", case_id)
        sim = Simulation(kernel, n, raw0, clock0, "lazy", 1)
        info, buffers_equal = sim.step()
        records.append(
            {
                "probe": "source_state_semantic",
                "case_id": case_id,
                "input": {"state": state, "semantic": semantic, "s_reg": 11, "direction": list(direction)},
                "source_after": unpack(sim.raw_a[np.ravel_multi_index(q0, (n, n, n))]),
                "destination_after": unpack(sim.raw_a[np.ravel_multi_index(q1, (n, n, n))]),
                "support_after": support_positions(sim.raw_a, n),
                "nonzero_after": nonzero_positions(sim.raw_a, n),
                "raw_hash": sha256_array(sim.raw_a),
                "clock_hash": sha256_array(sim.clock_a),
                "buffers_equal": buffers_equal,
                "kernel_info": info,
            }
        )
        case_id += 1

    source = (4, 4, 4)
    target = (5, 4, 4)
    for target_semantic in (1, 4):
        raw0 = np.zeros(n**3, dtype=np.uint64)
        raw0[np.ravel_multi_index(source, (n, n, n))] = pack(1, 9, (1, 0, 0), 1)
        raw0[np.ravel_multi_index(target, (n, n, n))] = pack(7, 13, (0, 0, 0), target_semantic)
        clock0 = clock_array(n, "zero", case_id)
        sim = Simulation(kernel, n, raw0, clock0, "dense", 2)
        info, buffers_equal = sim.step()
        records.append(
            {
                "probe": "occupied_target",
                "case_id": case_id,
                "target_semantic": target_semantic,
                "target_after": unpack(sim.raw_a[np.ravel_multi_index(target, (n, n, n))]),
                "support_after": support_positions(sim.raw_a, n),
                "nonzero_after": nonzero_positions(sim.raw_a, n),
                "raw_hash": sha256_array(sim.raw_a),
                "clock_hash": sha256_array(sim.clock_a),
                "buffers_equal": buffers_equal,
                "kernel_info": info,
            }
        )
        case_id += 1

    target = (5, 5, 5)
    xnor_directions = [
        (1, 0, 0), (-1, 0, 0),
        (0, 1, 0), (0, -1, 0),
        (0, 0, 1), (0, 0, -1),
        (1, 1, 0), (-1, -1, 0),
    ]
    raw0 = np.zeros(n**3, dtype=np.uint64)
    for d in xnor_directions:
        p = tuple((target[a] - d[a]) % n for a in range(3))
        raw0[np.ravel_multi_index(p, (n, n, n))] = pack(1, 2, d, 1)
    clock0 = clock_array(n, "near_wrap", case_id)
    sim = Simulation(kernel, n, raw0, clock0, "lazy", 2)
    info, buffers_equal = sim.step()
    records.append(
        {
            "probe": "xnor_preempts_eight_source_demux",
            "case_id": case_id,
            "directions": [list(d) for d in xnor_directions],
            "target_after": unpack(sim.raw_a[np.ravel_multi_index(target, (n, n, n))]),
            "support_after_count": len(support_positions(sim.raw_a, n)),
            "raw_hash": sha256_array(sim.raw_a),
            "clock_hash": sha256_array(sim.clock_a),
            "buffers_equal": buffers_equal,
            "kernel_info": info,
        }
    )
    case_id += 1

    q0 = (3, 4, 5)
    d = (1, 1, -1)
    raw0 = np.zeros(n**3, dtype=np.uint64)
    raw0[np.ravel_multi_index(q0, (n, n, n))] = pack(1, 17, d, 1)
    clock0 = clock_array(n, "heterogeneous", case_id)
    sim = Simulation(kernel, n, raw0, clock0, "dense", 1)
    for _ in range(n):
        sim.step()
    records.append(
        {
            "probe": "raw_vs_full_cycle_N",
            "case_id": case_id,
            "N": n,
            "raw_equal_after_N": bool(np.array_equal(sim.raw_a, raw0)),
            "clock_equal_after_N": bool(np.array_equal(sim.clock_a, clock0)),
            "combined_equal_after_N": bool(np.array_equal(sim.raw_a, raw0) and np.array_equal(sim.clock_a, clock0)),
            "initial_raw_hash": sha256_array(raw0),
            "final_raw_hash": sha256_array(sim.raw_a),
            "initial_clock_hash": sha256_array(clock0),
            "final_clock_hash": sha256_array(sim.clock_a),
        }
    )
    result["exploratory_scope"] = {"case_count": len(records), "records": records}
    print(f"exploratory progress {len(records)}/{len(records)}", flush=True)


def write_output(result: dict) -> None:
    tmp = OUTPUT.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(OUTPUT)


def main() -> int:
    started = time.perf_counter()
    seal = json.loads(RUN_SEAL.read_text(encoding="utf-8"))
    observed = {
        "wheel": sha256_file(WHEEL),
        "kernel": sha256_file(KERNEL_BIN),
        "source": sha256_file(KERNEL_SOURCE),
        "preregister": sha256_file(PREREG),
        "reduction": sha256_file(REDUCTION),
        "runner": sha256_file(HERE),
    }
    for key, expected in EXPECTED.items():
        if observed[key].lower() != expected:
            raise RuntimeError(f"identity failure for {key}: {observed[key]} != {expected}")
    if observed["runner"].lower() != str(seal["runner_sha256"]).lower():
        raise RuntimeError("runner hash differs from pre-run seal")
    if sys.version_info[:2] != (3, 13) or platform.architecture()[0] != "64bit":
        raise RuntimeError(f"wrong runtime: {sys.version}; {platform.architecture()}")

    sys.path.insert(0, str(EXTRACTED))
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    origin = Path(kernel.__file__).resolve()
    if origin != KERNEL_BIN.resolve():
        raise RuntimeError(f"wrong kernel import: {origin}")

    result = {
        "schema": "dee-v27-t8-ballistic-independent-v1",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "identity": observed,
        "seal": seal,
        "runtime": {
            "executable": sys.executable,
            "version": sys.version,
            "architecture": platform.architecture()[0],
            "numpy": np.__version__,
            "kernel_import": str(origin),
        },
        "design": {
            "seed": T8_SEED,
            "directions": [list(d) for d in DIRECTIONS],
            "sizes": SIZES,
            "states": STATES,
            "s_regs": SREGS,
            "clock_families": CLOCK_FAMILIES,
            "implementations": [{"engine": e, "threads": t} for e, t in IMPLEMENTATIONS],
            "modes": [list(m) for m in MODES],
            "loads": [list(x) for x in LOADS],
        },
        "mismatches": [],
    }
    singleton_panel(kernel, result)
    next_id = result["singleton"]["case_count"]
    next_id = two_mover_panel(kernel, result, next_id)
    next_id = collision_panel(kernel, result, next_id)
    exploratory_panel(kernel, result, next_id)
    result["primary_summary"] = {
        "singleton_cases": result["singleton"]["case_count"],
        "two_mover_cases": result["two_movers"]["case_count"],
        "collision_cases": result["collisions"]["case_count"],
        "mismatch_count": len(result["mismatches"]),
        "verdict": "PASS" if not result["mismatches"] else "FAIL",
    }
    result["elapsed_seconds"] = time.perf_counter() - started
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    write_output(result)
    print(json.dumps(result["primary_summary"], sort_keys=True), flush=True)
    print(f"result={OUTPUT}", flush=True)
    print(f"sha256={sha256_file(OUTPUT)}", flush=True)
    print(f"elapsed_seconds={result['elapsed_seconds']:.6f}", flush=True)
    return 0 if not result["mismatches"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
