# Auditoría binaria, API y semántica ejecutable de DEE v27

Fecha de cierre de esta subauditoría: 2026-09-11. Toda ejecución fue local y no destructiva. No se creó entorno, no se instaló ningún paquete y no se modificó el wheel ni Python global.

## Veredicto ejecutivo

La identidad criptográfica principal **sí coincide** con la referencia:

| Objeto | Ruta usada | SHA-256 observado | Resultado |
|---|---|---|---|
| Wheel | `tests/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl` | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` | PASS |
| Package (`__init__.py`) | copia extraída local | `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4` | PASS |
| Kernel `.pyd` | copia extraída local | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` | PASS |
| Fuente C++ incluida | copia extraída local | `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab` | PASS |

El `RECORD` del wheel valida byte por byte todas sus entradas declaradas. El wheel es binario `cp313-cp313-win_amd64`; el encabezado PE del kernel declara `Machine=0x8664 (AMD64)`. La ejecución aislada usó CPython 3.13.11 x64, NumPy 2.2.6, `-I -B`, e importó inequívocamente desde:

`DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ANALYSIS/binary_api/wheel_extracted/dee_universe_v27`

El intérprete histórico, sin el override, resuelve a `D:/Descargas/ANACONDA MINICONDA/Lib/site-packages/dee_universe_v27`; sus cinco archivos de paquete tienen exactamente los mismos hashes que el wheel local. Por tanto no hay discrepancia de identidad entre el wheel local, la instalación histórica y el binario interrogado.

Sí hay discrepancias internas serias de **contrato y metadatos**: `dee_universe_v27.P_KERNEL` expone `19658`, mientras el kernel ejecutable usa `19665` y cap `19664`; tres métodos públicos del wrapper fallan; la telemetría temporal del wrapper siempre reporta cero; y `Requires-Python >=3.11` no describe correctamente el código Python incluido ni el tag real del wheel.

La auditoría semántica altera varias tesis de Claude:

| Candidato | Adjudicación sobre v27 | Resultado esencial |
|---|---|---|
| T1 | **REFUTED** | El raw puede influir a distancia Chebyshev 3 en un solo tick por la selección anidada de destino DEMUX. Cota correcta: `r∞ <= 3t`, no `t`. |
| T2 | **CONDITIONAL as stated; corrected theorem PROVEN** | `clock_i(t)=clock_i(0)+t (mod 2^64)`. Diferencias son invariantes módulo `2^64`; la igualdad entera exige ausencia de wrap. |
| T3 | **CONDITIONAL; sharpened** | `L=1,094,573,220` funciona sin wrap pero no es mínimo. El período universal causal mínimo del raw es `304,980`. No hay simetría global a través de wrap uint64. |
| T4 | **REFUTED** | `Q4=sum_i 1[semantic_i=SEM_OBSERVER]` es un invariante aditivo no trivial de rango 0; existe una familia mucho mayor. |
| T5 | **PROVEN, with corrected witness** | Estado aislado normal 1 y 2, con clocks iguales, produce exactamente la misma imagen completa. La afirmación más fuerte de que los `2^64` raw aislados colapsan es falsa. |
| T6 | **CONDITIONAL / compound** | Traslaciones toroidales son exactas. `O_h` global es falso: los empates DEMUX rompen inversión/rotación/reflexión por orden lexicográfico. |

## Identidad e importación

El contenido del wheel es mínimo y auditable: `__init__.py`, constantes Python, wrapper Python, fuente C++, kernel `.pyd` y metadatos `dist-info`. La evidencia completa, tamaños, hashes y verificación `RECORD` está en `runtime_probe.json`.

Runtime ejecutado:

- `D:\Descargas\ANACONDA MINICONDA\python.exe`
- CPython 3.13.11, AMD64, punteros de 64 bits, `SOABI=cp313-win_amd64`
- NumPy 2.2.6 desde el mismo Miniconda
- `sys.flags.isolated=1`, `no_user_site=1`, `dont_write_bytecode=1`

La importación se hizo insertando la copia extraída exacta en `sys.path[0]` dentro de un proceso `-I`, y se abortaba si `package.__file__` o `kernel.__file__` no quedaban bajo esa raíz o si cualquiera de los cuatro hashes no coincidía. No fue necesario crear un venv.

CPython 3.11.9 no encuentra una instalación del paquete. Además, compilar el texto del wrapper bajo 3.11 falla en la línea 76 por el f-string con comillas reutilizadas (válido por PEP 701 desde 3.12). Por tanto `Requires-Python: >=3.11` es engañoso incluso como contrato de fuente, aunque el tag `cp313` impide instalar este wheel concreto en 3.11.

## Contrato ejecutable real

El módulo binario exporta exactamente:

- `tick_universo(grid_A, grid_B, clock_A, clock_B, N, n_hilos) -> dict`
- `tick_universo_lazy(grid_A, grid_B, clock_A, clock_B, N, n_hilos) -> dict`
- `inyectar_electron(grid, x, y, z, N, valor_inicial, dir_x, dir_y, dir_z) -> int`
- `inyectar_proton(grid, x, y, z, N) -> int`
- `sembrar_ruido(grid, N, densidad, semilla) -> int`
- `censo_semantico(grid, N) -> dict`
- `VERSION = "DEE Universe Kernel v27.0-PKCANON (v26-SYM1 fork; canonical P_KERNEL=19665)"`

Los cuatro buffers deben ser arreglos `uint64` escribibles con al menos `N^3` elementos. El C++ no valida tamaños/forma antes de usar punteros crudos. Ambas funciones de tick escriben B, copian B sobre A y dejan `grid_A==grid_B`, `clock_A==clock_B`. La versión densa requiere de facto `n_hilos>=1`; usa `(N+n_hilos-1)/n_hilos` sin guardia. Lazy aplica `max(1,n_hilos)`. El wrapper siempre llama Lazy.

El empaquetado raw comprobado es:

- estado: bits 0–31, `uint32`;
- `s_reg`: bits 32–47, `uint16`;
- `dir_x/y/z`: bits 48–59, nibbles signed two's complement, rango decodificado `[-8,7]`;
- semantic: bits 60–63.

`censo_semantico` sólo cuenta entradas con estado mayor que cero y retorna `totales`, `vivos`, `orphans`, `xnor`, `observers`, `con_momento`, `suma_s_reg` y el diccionario anidado `por_semantica`.

Dense y Lazy dieron full-state idéntico en el muestreo aleatorio y en todos los testigos construidos de T1–T6.

## Discrepancias del wrapper y metadatos

1. **Constante pública incorrecta.** `dee_constants_v27.py:4` fija `P_KERNEL=19658`; el C++ fija `19665` (`dee_kernel_v27.cpp:35`) y usa cap `P_KERNEL-1=19664` (`:220`, `:440`). Código que derive gates/caps desde el package obtiene otra dinámica nominal.

2. **`sembrar_proton` roto.** El wrapper pasa seis argumentos, incluido `valor_inicial` (`dee_universe_v27.py:54-56`), pero el binding acepta sólo cinco. La llamada pública produce `TypeError` reproducible.

3. **`medir_energia_total` roto.** Solicita `censo()["energia_total"]` (`:89-90`), clave inexistente; produce `KeyError`.

4. **`detectar_estructuras` roto.** Busca claves planas `sem_2`, `sem_3`, `sem_1`, `sem_5`, `voxeles_activos`, `energia_total` (`:92-100`), mientras el binario retorna otra topología; produce `KeyError: voxeles_activos` y los conteos semánticos previos serían ceros silenciosos.

5. **Timing ficticio.** `tick` suma `info.get("elapsed_ms",0.0)`, pero ninguno de los dos bindings retorna `elapsed_ms`; `elapsed_ms_total/promedio` es siempre 0.0.

6. **Proveniencia textual obsoleta.** METADATA resume “Kernel v24”; `__init__` se describe como v25 clonado de v24; el wrapper se etiqueta v16; el docstring binario dice v26/v25 physics. La identidad de comportamiento debe establecerse con versión/hashes, no esos textos.

7. **Compatibilidad Python sobredeclarada.** METADATA dice `>=3.11`, el wheel es sólo `cp313`, y el wrapper ni siquiera parsea en 3.11.

## T1 — cono causal

**REFUTED en el binario exacto.** Claude omitió que la selección DEMUX contiene dos vecindades anidadas. Para un emisor `x` que cruza fusión, el bucle de candidatos lee cada `z=x+d` (`:371`), y para decidir si ese candidato está abierto cuenta los vecinos `q=z+e` (`:382-387`). Después escribe el delta en el destino elegido `y=x+d*` (`:403-406`). Al preguntar por el output de `y`, cualquier emisor `x` a radio 1 puede haber consultado un `q` hasta radio 3 de `y`.

Se construyeron dos preimágenes que difieren sólo en `q=(3,3,3)`. Ese bit cambia el grado del primer candidato DEMUX de 7 a 8 y redirige el overflow del emisor central. Tras un tick, `y=(6,6,6)`, a distancia Chebyshev 3, es VOID en A y `SEM_NORMAL,state=1` en B. El resultado aparece en dense y Lazy con un overflow en cada brazo.

No hay cascada DEMUX dentro del mismo tick: los deltas se acumulan y se aplican una vez después del join. Por tanto la cota estática correcta para dependencia raw es exactamente `r∞(1)<=3`; el testigo satura 3. Por composición, antes de wrap toroidal, `r∞(t)<=3t`. Clock por sí solo entra localmente en el emisor, pero el estado completo hereda la cota máxima raw.

## T2 — clock

Cada salida ejecutada por `actualizar_voxel`, incluida `SEM_OBSERVER`, escribe `clkB[i]=clkA[i]+1`; Lazy prellena la misma operación para las celdas no evaluadas y DEMUX no toca clock. La aritmética C++ es `uint64_t`.

Teorema correcto:

`c_i(t) = c_i(0) + t mod 2^64`.

En consecuencia `c_i-c_j` es invariante en el grupo `Z/(2^64)`. En enteros ordinarios, la afirmación sólo es válida en horizontes sin wrap. El probe incluyó `2^64-1 -> 0` y confirmó exactamente el wrap en dense/Lazy. Esto importa para cualquier pretensión de validez “para todo t”.

## T3 — periodicidad causal del clock

El único uso de clock sobre raw es el gate:

`periodo_ticks = 782 // (8-n_active)` y `tick % periodo_ticks == 0` (`:357-362`).

Claude tomó los ocho valores sintácticos `[782,391,260,195,156,130,111,97]`, cuyo LCM es `1,094,573,220`. Los cuatro últimos primos adicionales provienen de estados con `n_active=0..3`, pero esos estados salen antes por `rule_value==0` (`:344-348`). Nunca consultan el gate. Los únicos períodos causalmente activos son:

| `n_active` | requisito para sobrevivir | período |
|---:|---|---:|
| 4 | firma tetraédrica | 195 |
| 5 | firma tetraédrica | 260 |
| 6 | cualquiera que dé `rule_value>0` | 391 |
| 7 | suma direccional no nula para evitar write-protection | 782 |

Cada uno tiene un testigo binario: clock 0 y clock `p` dan el mismo raw central; clock `p-1` da otro `s_reg`. Por divisibilidad necesaria en esos cuatro contextos, el período universal positivo mínimo es:

`lcm(195,260,391,782) = 304,980`.

El L de Claude es `304,980 * 37 * 97`, válido pero no mínimo. Shifts independientes por sitio en múltiplos de `304,980` dejan toda trayectoria raw igual por inducción mientras no haya wrap uint64. A través de wrap no definen una simetría global, porque `2^64` no es múltiplo de esos períodos.

## T4 — invariantes aditivos de rango 0

**REFUTED.** Dos errores independientes invalidan la supuesta prueba.

Primero, `SEM_OBSERVER` retorna antes de toda regla con `gB[i]=gA[i]` (`:247`), y `aplicar_demux` rehúsa modificarlo (`:433`). Ninguna rama alcanzable crea semantic 4. La única escritura que podría heredarlo es cristalización, pero esa rama es matemáticamente imposible (sección siguiente). Por tanto posiciones y raw de todos los semantic 4 son constantes exactas. Para cualquier función raw-only `f`,

`Q_f(X)=sum_i 1[sem(raw_i)=4] f(raw_i)`

es un invariante aditivo de rango 0. Basta `f=1` para obtener el contador no trivial `Q4`. El binario preservó tres observadores con raws distintos —incluido estado 0— durante cuatro ticks en dense y Lazy.

Segundo, la premisa “todo raw oculto aislado con estado 0 colapsa” es falsa. `buscar_fuente_demux` acepta una dirección no nula sin comprobar `exists`/`is_alive_for_rule` (`:187-225`). Un raw aislado con estado 0 y dirección `(1,0,0)` se copió en un tick al destino vecino como `SEM_NORMAL,state=1` en ambos motores.

Los negativos empíricos previos en bancos restringidos siguen siendo negativos de esas familias, pero no pueden promoverse a inexistencia global de invariantes de rango 0.

## Rama de cristalización: imposibilidad exacta

`UMBRAL_CRISTALIZACION=floor(9.887^3)=966`. La condición usa división entera por `P_KERNEL=19665`, así que requiere `grad_mag >= 18,996,390`.

Para offsets Moore `d` y `s_d in [0,65535]`, el gradiente es `g=-sum_d d s_d`. Usando `||g||_1=max_{sigma in {+-1}^3} sigma·g`, la suma máxima de coeficientes positivos para cualquier octante es 15. Luego:

`grad_mag <= 15*65535 = 983,025 < 18,996,390`.

El cociente entero máximo es 49, no 966. La rama `:300-308` es inalcanzable para todo neighborhood raw válido. Esto también vuelve irrelevante `sem_heredada` y su orden “primer vecino” para la dinámica ejecutable.

`demux_edge_min` (`:173-184`) aparece una sola vez en toda la fuente: su definición. Nunca se llama. No participa en F v27. También se calculan `suma_s_reg_vecinos` y `max_off_*` sin efecto observable en la rama final.

## T5 — no inyectividad

**PROVEN directamente en el binario.** Dos universos con clocks idénticos y un único voxel `SEM_NORMAL,s_reg=0,direction=0`, uno con estado 1 y otro con estado 2, son preimágenes distintas. Ambos voxels tienen `n_active=0`, obtienen `rule_value=0` y todo el estado completo posterior coincide: raw totalmente cero, clocks todos incrementados por uno. Dense y Lazy coinciden.

La conclusión many-to-one sobrevive. No sobrevive la justificación “los `2^64` raws aislados colapsan”: semantic 4 es fijo y estado-0 direccional puede propagarse.

## T6 — simetrías

Las traslaciones toroidales `Z_N^3` son exactas por inspección: índices sólo aparecen mediante offsets relativos y wrap. Un mundo aleatorio empaquetado confirmó full-state equivariancia al shift `(2,-1,3)` tanto dense como Lazy incluso cambiando 3 a 2 hilos. Los acumuladores atómicos son sumas conmutativas y cada voxel base se escribe una vez, por lo que el resultado no depende del particionado válido de hilos.

El grupo cúbico completo `O_h` **no** es simetría global. En fusión, candidatos con el mismo `s_reg` se resuelven por la primera entrada de `MOORE_DXYZ`, orden lexicográfico comenzando en `(-1,-1,-1)`; sólo reemplaza el mejor con desigualdad estricta. Un input exactamente invariante bajo inversión —fuente central `s_reg=19665` y seis soportes de eje— produce un nuevo voxel sólo en `(-1,-1,-1)`, no en `(1,1,1)`. El output tiene dos sitios de mismatch bajo inversión en dense y Lazy.

Así, `O_h` es a lo sumo una equivariancia restringida a configuraciones donde no se activa un empate causal DEMUX (o donde el resultado del empate queda estabilizado por el estado). El 288/288 histórico no demuestra simetría global si no excitó esos empates.

## Alcance probatorio

Las refutaciones T1, T4 y de `O_h`, y la no inyectividad T5, son constructivas sobre el `.pyd` exacto: basta un solo testigo. Las cotas, periodicidad mínima, traslación y familias invariantes combinan inspección de la fuente C++ incluida y sellada con probes binarios discriminantes. No se recompiló el kernel. La concordancia dense/Lazy se verificó en muestras y testigos; la equivalencia universal de ambos caminos se apoya además en que llaman al mismo `actualizar_voxel` y difieren sólo en el conjunto candidato/prellenado.

Archivos primarios:

- `runtime_probe.json`: identidad, RECORD, API y resultados completos.
- `wheel_extracted/`: copia exacta del contenido del wheel usado para inspección/importación.
- `../../RUNNERS_NEW/probe_v27_binary_api.py`: reproducción autocontenida.
- `COMMANDS_AND_RESULTS.md`: comandos y salidas decisivas.

