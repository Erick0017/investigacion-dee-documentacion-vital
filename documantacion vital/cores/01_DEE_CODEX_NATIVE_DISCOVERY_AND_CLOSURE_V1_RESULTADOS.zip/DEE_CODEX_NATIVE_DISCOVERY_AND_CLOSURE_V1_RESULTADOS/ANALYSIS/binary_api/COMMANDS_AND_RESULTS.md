# Comandos y resultados decisivos

Directorio de trabajo para todos los comandos:

`D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests`

## Descubrimiento del wheel y runtime

```powershell
rg --files -g '*.whl' -g '*.pyd' -g '*.dll' -g '*.so'
py -0p
Get-Command python -All
```

Resultado: único wheel local `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl`; `py` sólo registró 3.12, `python` por PATH era 3.11, y se localizó CPython 3.13.11 en `D:\Descargas\ANACONDA MINICONDA\python.exe`.

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -c "import sys,platform,struct,numpy; print(sys.version,sys.executable,platform.machine(),struct.calcsize('P')*8,numpy.__version__,numpy.__file__)"
```

Resultado: CPython 3.13.11, AMD64/64 bits, NumPy 2.2.6.

## Hash y contenido

```powershell
Get-FileHash -Algorithm SHA256 -LiteralPath '.\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl'
tar -tf '.\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl'
```

Resultado: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`; nueve entradas, listadas y verificadas en `runtime_probe.json`.

```powershell
New-Item -ItemType Directory -Force -Path '.\DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\binary_api\wheel_extracted'
tar -xf '.\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl' -C '.\DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\binary_api\wheel_extracted'
```

Resultado: extracción sólo bajo la carpeta nueva. Ningún original modificado.

## Importación aislada y batería binaria

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\RUNNERS_NEW\probe_v27_binary_api.py'
```

Resultado final (exit 0):

```text
status=PASS
wheel=69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939
package=7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4
kernel=0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff
source=44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab
```

Resultados internos principales: T1 testigo a distancia 3 PASS dense/Lazy; T2 incremento y wrap PASS; T3 cuatro testigos de período PASS; T4 observadores y raw direccional PASS; T5 colisión de preimágenes PASS; T6 traslación PASS e inversión FAIL como simetría; dense/Lazy full-state iguales.

## Resolución por defecto del intérprete histórico

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B -c "import importlib.util; s=importlib.util.find_spec('dee_universe_v27'); print(s.origin)"
```

Resultado: `D:\Descargas\ANACONDA MINICONDA\Lib\site-packages\dee_universe_v27\__init__.py`. Los hashes instalados de `__init__.py`, constantes, wrapper, C++ y `.pyd` coinciden uno a uno con la copia del wheel.

## Contrato Python 3.11

```powershell
& 'C:\Users\Erik\AppData\Local\Programs\Python\Python311\python.exe' -I -B -c "from pathlib import Path; p=Path(r'...\wheel_extracted\dee_universe_v27\dee_universe_v27.py'); compile(p.read_text(encoding='utf-8'),str(p),'exec')"
```

Resultado (exit 1): `SyntaxError: f-string: unmatched '('` en línea 76. `find_spec('dee_universe_v27')` bajo 3.11 devolvió `None`.

## Evidencia estática

```powershell
rg -n "P_KERNEL|UMBRAL_CRISTALIZACION|SEM_OBSERVER|rule_value == 0|periodo_ticks|for \(int k_imp|for \(int kk|delta_demux|demux_edge_min" '.\DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_kernel_v27.cpp'
```

Resultado: las líneas pertinentes están citadas en `AUDIT_REPORT.md`; `demux_edge_min` tiene una sola ocurrencia y por tanto no se invoca.

## Hashes del runner y resultado en el último pase

```text
probe_v27_binary_api.py  afa04b5eb331e5710a0ef624296f309dcc8f65cdba96f2d9b2f80bd5d9a33360
runtime_probe.json       b2fc297af7f57f4905a96aadb77310817c90a70e13dfed94dcb29bc7a8925202
```

Estos dos hashes se calcularon a las `2026-09-11T14:37:59-06:00`, antes de añadir únicamente los documentos de cierre; el runner y JSON no cambiaron después de ese cálculo.

