# Progreso de subauditoría binary_api

- `2026-09-11`: localizado el único wheel v27 local y el runtime histórico CPython 3.13.11 x64.
- `2026-09-11`: creado `ANALYSIS/binary_api/wheel_extracted`; wheel extraído allí sin instalación ni modificación de originales.
- `2026-09-11`: hashes wheel/package/kernel/source y todas las entradas RECORD verificados: PASS.
- `2026-09-11`: importación aislada `-I -B` desde la copia exacta, con gate de ruta y hash: PASS.
- `2026-09-11`: API pública del binario y wrapper inventariada; cuatro defectos funcionales/telemetría documentados.
- `2026-09-11`: probes dense/Lazy ejecutados para clock, periodicidades, no inyectividad, invariantes, localidad, traslación e inversión.
- `2026-09-11`: T1 refutado, T2 corregido módulo uint64, T3 minimizado, T4 refutado, T5 probado y T6 descompuesto.
- `2026-09-11`: cristalización demostrada inalcanzable y helper `demux_edge_min` confirmado muerto.
- `2026-09-11`: subauditoría cerrada. No quedan ejecuciones necesarias dentro del alcance binario/API.

