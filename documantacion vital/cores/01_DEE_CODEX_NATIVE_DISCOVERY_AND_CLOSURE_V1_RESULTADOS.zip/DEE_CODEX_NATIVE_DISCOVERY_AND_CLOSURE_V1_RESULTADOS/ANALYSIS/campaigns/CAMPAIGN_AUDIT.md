# Auditoría probatoria y genealógica de campañas DEE

**Corte:** 2026-09-11  
**Estado:** síntesis cerrada sobre el corpus disponible; no se reejecutó ninguna campaña.  
**Alcance:** 17 ZIP, directorios `*_WORK`, `RESULTS/`, manifiestos, preregistros, congelados pre-holdout y telemetría selectivamente copiada. Los originales permanecieron intactos.

## Dictamen ejecutivo

1. **El corpus archivado es internamente trazable, pero no todo tiene el mismo grado de sellado.** Los 17 ZIP abren correctamente a nivel de directorio central y los metadatos seleccionados pasan CRC. Los 11 ZIP con `MANIFEST.json` declaran exactamente sus 8,512 miembros no-manifiesto: no hay rutas faltantes, rutas no listadas ni tamaños discordantes; 139 hashes de miembros muestreados coinciden. Los otros seis ZIP v27 usan manifiesto de texto: el nombre de campaña y los artefactos raíz concuerdan, pero ese formato no fue sometido al verificador estructural JSON. Evidencia: `ANALYSIS/scan_summary.json`, `ANALYSIS/manifest_verification.csv`, `ANALYSIS/manifest_sample_hashes.csv`, `ANALYSIS/ARCHIVE_HASHES.sha256`.

2. **No aparece un PASS físico externo general.** La mejor nota final es la `A_DISTRIBUTED_SUBSTRATE_WITH_LOCAL_CAUSAL_MEDIATION` de V7-C, explícitamente interna a DEE y con `external_physics_claimed=false`. V7-A y V7-B terminan en grado C. V6-F declara negativa la familia de transferencia completa. El puente de fórmulas deja mecánica clásica, GR e hidrodinámica como `NO_IDENTIFICABLE`; SR sólo como condiciones internas parciales; QM y termodinámica como formalismos parciales, no equivalencias físicas.

3. **Los fallos técnicos no son resultados científicos.** Refoundation-A/A6 falló al enlazar una variante (`LNK1104`); Replay-A/A6 falló al borrar un `.pyd` bloqueado; Part-C/C4 falló porque el proceso hijo no tenía `setuptools`; V7-C conserva un primer aborto por solapamiento de fuente y luego un hotfix explícito. Ninguno autoriza una conclusión física negativa. En cambio, `no_resolved_group_mode` en 9/9 casos de Part-C, `no_resolved_packet_in_screen` de V6-D y los gates falsos de V6-F sí son negativos científicos, acotados al aparato preregistrado.

4. **Corrección posterior de alcance: `TORUS_MOVING` y v25.5-C sí contienen transporte exacto sectorial.** La auditoría inicial, limitada al corpus bajo `tests` v27, sólo podía certificar el nombre y la equivalencia de backends. Una extensión forense posterior de sólo lectura recuperó `VERSION_25/tests/test_v25_lazy_audit.py` (SHA-256 `764d09223d9407ee05bb899401e22278cf7ff2935e32f5fdbfb3d2f0fa67e202`): construye un singleton normal en `N=24`, `q0=(23,12,12)`, `state=1`, `s_reg=0`, `d=(1,0,0)`. Los 12 hashes raw/clock del JSON histórico (SHA-256 `d45f8a1881c6e7eafa0e5aa47f55c350632fdc09ebfc7e2c60741886167b62eb`) reconstruyen exactamente `q(t)=((23+t) mod 24,12,12)`, incluido el cruce toroidal en tick 1. También se recuperó F-189/v25.5-C: 60/60 carriles y 2,226 pasos coinciden con `np.roll`; packed/state/direction/semantic tienen `P=L_sym`, mientras `sreg_projection` tiene `P=1`. El PASS de `TORUS_MOVING` se publicó como regresión, y `P=L_sym` es un corolario de traslación más simetría preparada, no ley universal. T8 sigue siendo la generalización prospectiva exhaustiva localizada sobre v27, no la primera observación absoluta del mecanismo.

5. **`RESULTS/` es V7-B, no una campaña adicional.** Tiene los mismos 824 paths y tamaños que el ZIP final de V7-B. El directorio explícito `...V7_B..._WORK` es un corte previo/incompleto de 342 archivos; por tanto, cualquier análisis final debe preferir el ZIP o `RESULTS/`, no ese WORK.

## Convenciones y límites de la auditoría

- `ANALYSIS` = `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ANALYSIS/campaigns`
- `EXTRACTED` = `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/EXTRACTED_INPUT_COPIES/campaigns`
- `ROOT` = directorio `tests/` que contiene los originales.
- Se extrajeron previamente 2,199 archivos de metadatos a `EXTRACTED`; esta fase de cierre no volvió a abrir los ZIP ni extrajo contenido.
- `zip_valid=True` significa directorio central legible más CRC de los metadatos seleccionados, no descompresión y rehash exhaustivo de cada NPZ/HTML/PNG.
- Los SHA del kernel que siguen son **valores declarados por telemetría**. Esta auditoría de campañas no sustituye una importación directa del wheel ni un hash independiente del binario.

### Catálogo exacto de fuentes primarias

| ID usado | Artefacto primario |
|---|---|
| Refoundation-A | `EXTRACTED/DEE_V27_NATIVE_REFOUNDATION_AND_BIAS_CORRECTION_PART_A_V1/DEE_V27_NATIVE_REFOUNDATION_AND_BIAS_CORRECTION_PART_A_V1.SUMMARY.json` |
| Replay-A | `EXTRACTED/DEE_V27_REPLAY_BATTERY_PART_A_NATIVE_LAWS_ON_FROZEN_V27_V1/DEE_V27_REPLAY_BATTERY_PART_A_NATIVE_LAWS_ON_FROZEN_V27_V1.SUMMARY.json` |
| Replay-B | `EXTRACTED/DEE_V27_REPLAY_BATTERY_PART_B_NATIVE_SYSTEM_FRONTIER_ON_FROZEN_V27_V1/DEE_V27_REPLAY_BATTERY_PART_B_NATIVE_SYSTEM_FRONTIER_ON_FROZEN_V27_V1.SUMMARY.json` |
| Rosetta-B | `EXTRACTED/DEE_V27_ROSETTA_EMERGENT_METRIC_AND_MINIMUM_TIME_PART_B_V1/DEE_V27_ROSETTA_EMERGENT_METRIC_AND_MINIMUM_TIME_PART_B_V1.SUMMARY.json` |
| Part-C | `EXTRACTED/DEE_V27_TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY_PART_C_V1/DEE_V27_TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY_PART_C_V1.SUMMARY.json` |
| Part-D | `EXTRACTED/DEE_V27_SPONTANEOUS_MORPHOGENESIS_AND_MULTISCALE_GEOMETRY_PART_D_V1/DEE_V27_SPONTANEOUS_MORPHOGENESIS_AND_MULTISCALE_GEOMETRY_PART_D_V1.SUMMARY.json` |
| Part-E2 | `ROOT/DEE_V27_E2_VISUAL_MORPHOLOGY_TWIST_FUNCTIONAL_TRANSFER_AND_RESOURCE_V1_WORK/RESULTS.json` |
| V6-A | `ROOT/DEE_V6_A_PRECURSORES_CAUSALIDAD_V1_WORK/RESULTS.json` y `EXTRACTED/DEE_V6_A_PRECURSORES_CAUSALIDAD_V1_RESULTADOS_CORE/MANIFEST.json` |
| V6-B | `DEE_V6_B_PAISAJE_HERIDAS_OBSERVADORES_V1_RESULTADOS_CORE.zip::RESULTS.json`; índice selectivo en `ANALYSIS/interesting_values.csv` |
| V6-C | `EXTRACTED/DEE_V6_C_CIERRE_OBSERVADORES_ROSETTA_V1_RESULTADOS_CORE/RESULTS.json` |
| V6-D | `EXTRACTED/DEE_V6_D_PAQUETES_TRANSPORTE_ROSETTA_V1_RESULTADOS_CORE/RESULTS.json` |
| V6-E | `EXTRACTED/DEE_V6_E_ONTOLOGIA_OBSERVADOR_NATIVO_V2_RESULTADOS/SUMMARY.json` |
| V6-F | `EXTRACTED/DEE_V6_F_TRANSFERENCIA_IDENTIDAD_ROSETTA_NATIVA_V2_RESULTADOS/SUMMARY.json` |
| V7-A | `EXTRACTED/DEE_V7_A_ATLAS_ESTADOS_EXISTENCIA_ENTORNO_FINAL_V2_RESULTADOS/SUMMARY.json` |
| V7-B | `EXTRACTED/DEE_V7_B_ROSETTA_INFORMACION_GEOMETRIA_ENTORNO_FINAL_V2_RESULTADOS/SUMMARY.json` |
| V7-C | `EXTRACTED/DEE_V7_C_SUSTRATO_DISTRIBUIDO_CAUSALIDAD_RELACIONAL_FINAL_V1_RESULTADOS/SUMMARY.json` |
| Formula Bridge | `EXTRACTED/DEE_V27_FORMULA_BRIDGE_AUDIT_FROM_TELEMETRY_V1_RESULTADOS/REPORT.json` |

## Genealogía observada

```text
kernel v27 congelado (SHA declarado 0b17ba...c6ff)
├─ baterías A: Refoundation-A → Replay-A
├─ frontera/metricidad B: Replay-B; Rosetta-B
├─ Part-C: procesamiento transversal y velocidad de grupo
├─ Part-D: morfogénesis libre (declarada paralela a C)
└─ Part-E2: morfología visual, transferencia y recurso
   └─ declara que debe leerse con E1, pero E1 no está en el corpus inventariado

serie experimental nominal V6
V6-A → V6-B → V6-C/D → V6-E → V6-F
                         └──────────────┐
serie de cierre V7                      │
V7-A → V7-B → V7-C                    │
        └─ espejo exacto ROOT/RESULTS/ │
                                      ▼
Formula Bridge = reanálisis de V6-E + V7-C + v27 Part-C
```

La flecha de la serie V6/V7 representa continuidad nominal y reutilización explícita de preguntas/artefactos, no identidad de código. V7-C cita como antecedentes A2/EA4/V6 B-C-E en `EXTRACTED/DEE_V7_C_.../PREREGISTERED_PLAN.json`. El Formula Bridge registra exactamente estos tres hashes de entrada en `REPORT.json`: V6-E `779943a3...a8b8`, V7-C `4daa08e5...4747` y Part-C `84c9f949...6bd0`. Replay-B además preserva un enlace antiguo mediante `embedded_v20_part_c_runner_sha256=b4e91f...bf8f` en su manifiesto de texto.

### Concordancia ZIP, WORK y runner

| Caso | Hallazgo genealógico | Fuente |
|---|---|---|
| E2, V6-E, V7-A, V7-C | ZIP y WORK tienen conjunto exacto de paths+tamaños | `ANALYSIS/zip_directory_comparison.csv` |
| V7-B | ZIP = `RESULTS/` (824/824); WORK sólo 342 y falta 482 finales | `ANALYSIS/zip_directory_comparison.csv` |
| V6-A | ZIP pausado: 98 archivos; WORK vivo: 639. Los 98 paths archivados existen, 97 conservan tamaño; `RESULTS.json` evolucionó | mismo CSV; `ROOT/DEE_V6_A_..._WORK/RESULTS.json` |
| V6-C | ZIP contiene el core de 375 archivos; WORK agrega 816 NPZ crudos | mismo CSV |
| Refoundation-A, Replay-A | WORK añade solamente un checkpoint respecto del ZIP | mismo CSV |
| Part-D | WORK añade `STATE.json` y checkpoints D1/D2/D4; el ZIP contiene 50/54 archivos | mismo CSV |
| Runners | 11 runners tienen copia raíz exacta por SHA; seis sólo están dentro del ZIP: Replay-B, Rosetta-B, Part-C, V6-B, V6-D, V6-F | `ANALYSIS/runner_lineage.csv` |

No se halló un caso donde el nombre del ZIP contradiga el campo `campaign` de su resultado/contrato/manifiesto. V6-C y V6-D son la excepción formal: su `MANIFEST.json` no incluye `campaign`, aunque `RESULTS.json` y `CONTRACT.json` sí fijan la identidad correcta.

## Matriz de campañas y grados finales

| Campaña | Estado / grado publicado | Preregistro y holdout | Resultado decisivo | Límite probatorio |
|---|---|---|---|---|
| v27 Refoundation-A | `completed_with_failures`; veredicto `null` | No hay preregistro separado en el ZIP | A1=325 pares, A2=80 mundos, A3=9 casos, A4=108 filas, A5=180; A6 técnico | No convertir A1-A5 ni el fallo A6 en veredicto global. `EXTRACTED/DEE_V27_NATIVE_REFOUNDATION_.../*.SUMMARY.json` |
| v27 Replay-A | `completed_with_failures`; veredicto `null` | Política en runner/manifiesto, sin preregistro separado | A1=20 pares, A2=192, A3=54, A4=2,304 contextos, A5=19 candidatos; A6 técnico | `PermissionError` de limpieza, no refutación. `EXTRACTED/DEE_V27_REPLAY_BATTERY_PART_A_.../*.SUMMARY.json` |
| v27 Replay-B | `completed`; veredicto `null` | Sin preregistro separado; manifiesto dice “no automatic scientific verdict” | B1=140 mundos/10 elegidos, B2=64, B3=4, B4=36, B5=6, B6=6 | Es una frontera descriptiva, no un PASS automático. `EXTRACTED/DEE_V27_REPLAY_BATTERY_PART_B_.../*.SUMMARY.json` |
| v27 Rosetta-B | `completed`; veredicto `null` | Sin preregistro separado | Dos medios `direction_cloud` seleccionados; mejor exponente cambia con densidad; B4=10, B5=4 | Métrica y tiempo mínimo adimensionales; sin calibración metro-segundo. Manifiesto y summary en `EXTRACTED/DEE_V27_ROSETTA_.../` |
| v27 Part-C | `completed_with_failures`; veredicto `null` | Sin preregistro separado; T_peak fijado como timing primario | C7: 9/9 `no_resolved_group_mode` | Negativo sólo para aparato de grupo ensayado; C4 es fallo de entorno. `EXTRACTED/DEE_V27_TRANSVERSAL_.../*.SUMMARY.json` |
| v27 Part-D | `completed`; D0-D9 completos | D4: 9 holdouts, seis cross-N y tres `reserved_seed`; seeds efectivos 20261005 y 20761014 | 189 mundos, 10 finalistas profundos, 5 candidatos de twist, 19 temporales, 2 daño | Ninguna forma natural se promueve automáticamente. Summary/manifiesto en `EXTRACTED/...PART_D.../`; D4 exacto en `ROOT/...PART_D..._WORK/checkpoints/D4_holdout.json` |
| v27 Part-E2 | `completed`; `MEASUREMENTS_PENDING_INTERPRETATION` | `FROZEN_TRANSFER_READER.json`; selección fija histórica+holdout, pero sin archivo llamado preregistro | EB0-EB6 completos; atlas visual/temporal, reinstanciación y ensayo de recurso | E2 no es “E completa”; falta E1. Resultados en `ROOT/DEE_V27_E2_..._WORK/RESULTS.json`, contrato/freeze en `EXTRACTED/...E2.../` |
| V6-A | ZIP `paused`; WORK actual `running`; sin grado final | `FROZEN_A_PREDICTORS_BEFORE_HOLDOUT.json`; A2 holdout ya medido | Aparato de predicción congelado, campaña aún abierta por presupuesto | El nombre `RESULTADOS_CORE` no significa cierre. No promover métricas parciales. Manifiesto del ZIP y WORK `RESULTS.json` |
| V6-B | `completed`; sin grado global | `FROZEN_B_NATIVE_COST_BEFORE_HOLDOUT.json` | B3 mezcla 80 filas `informative`, 40 `silent_panel`; 44 ediciones matched y 4 sin soporte remoto comparable | Panel mixto; no equivale a identidad/materialidad. `ANALYSIS/interesting_values.csv`, rutas `$.modules.B3...` |
| V6-C | `completed`; Rosetta física `false` | `PREREGISTERED_SPECS.json` + `FROZEN_BEFORE_ANY_HOLDOUT.json`; ocho holdouts N64, seeds 621285–622395 | 64/64 contrajemplos a cierre M0; observadores n=80, R² macro=.694, distribución=.815, relacional=.784 | El propio resultado limita el cierre a estados muestreados; distancia entre predicciones congeladas es diagnóstico derivado. `EXTRACTED/...V6_C.../RESULTS.json::modules.C5_ADJUDICATION` |
| V6-D | `completed`; `physical_Rosetta_validated=false` | Cuatro protocolos discovery; freeze deja `selected=null` | `no_resolved_packet_in_screen`: ninguna preparación pasa todos los gates angulares | No hubo búsqueda ciega sobre holdout; negativo del detector preregistrado. `EXTRACTED/...V6_D.../RESULTS.json::modules.D3_ADJUDICATION` |
| V6-E | `completed`; Rosetta externa `false` | `PREREGISTERED_PLAN.json` + freeze de observadores; identidades de mundo separadas antes del ajuste | M0 y M1: 24/24 fibras iguales divergen; eta→D holdout n=24, R²=.73185 | M2/M3 tuvieron cero pares iguales: no prueban cierre. `EXTRACTED/...V6_E.../SUMMARY.json` |
| V6-F | `completed`; familia de transferencia `false` | Preregistro + lector congelado antes de holdout | Gates causalmente positivos: fuente, dirección, corredor, off-path, migración; negativos: clase funcional ciega, repertorio informativo, robustez a ruido | Soporte causal parcial no es identidad material ni movimiento de portador. `EXTRACTED/...V6_F.../SUMMARY.json` y preregistro |
| V7-A | `completed`; `C_SIMPLE_RELATION_NOT_SUPPORTED_IN_DOMAIN` | Preregistro + atlas y observadores congelados | Regímenes nativos múltiples sí; clusters matter-like ninguno; tres cambios matched falsos; deep MSE .04105 vs visible .05767 | Ganancia predictiva no es suficiencia ontológica. `EXTRACTED/...V7_A.../SUMMARY.json` |
| V7-B | `completed`; `C_SIMPLE_CHAIN_REJECTED_OR_NOT_RESOLVED_IN_DOMAIN` | Preregistro + quotient reader + modelos causales congelados | Quotient transfer n=24: accuracy/migración/source-empty=1; sólo history_changes_response=true; deep R²=.2469 | Traslación es condición impuesta; mediador R²=.9738 supera código y combinado no mejora. No prueba movilidad espontánea. `EXTRACTED/...V7_B.../SUMMARY.json` |
| V7-C | `completed`; `A_DISTRIBUTED_SUBSTRATE_WITH_LOCAL_CAUSAL_MEDIATION` | Preregistro, pero revisado con hotfix; no freeze separado con nombre propio | Cono holdout=1, geometría/history/topología=1; receiver reached=.5; hidden-before-visible=0 | Grado A interno; `external_physics_claimed=false`; rastro técnico debe conservarse. `EXTRACTED/...V7_C.../SUMMARY.json`, `RESULTS.json`, `PREREGISTERED_PLAN.json` |
| Formula Bridge | `completed`; ningún sector obtiene PASS externo | Reanálisis secundario; contrato exige holdout para PASS | Clásica/GR/hidro no identificables; SR parcial interna; QM/termo formal-parcial | Las formas estándar son puentes condicionales conocidos, no fórmulas descubiertas crudas. `EXTRACTED/...FORMULA_BRIDGE.../REPORT.json::audits.formula_sectors` |
| `ROOT/RESULTS/` | No es grado nuevo | Hereda freeze de V7-B | Espejo exacto 824/824 del ZIP V7-B | Etiqueta genérica potencialmente engañosa; usar identidad V7-B. `ANALYSIS/zip_directory_comparison.csv` |

## Preregistros, freezes y semillas

La mejor cadena prospectiva del corpus es V6-C: `PREREGISTERED_SPECS.json` enumera 4 discovery, 4 calibration y 8 holdout antes de `FROZEN_BEFORE_ANY_HOLDOUT.json`. Los holdouts son N64, densidades .03/.06/.10/.14, dos seeds por densidad: 621285, 621295, 621585, 621595, 621985, 621995, 622385 y 622395.

V6-E y V6-F contienen planes explícitos, reglas de parada y freezes antes del holdout. V7-A y V7-B añaden planes y artefactos congelados separados. V6-A y V6-B sí tienen freezes, pero sólo V6-A sigue abierto. V6-D congeló `selected=null`; eso protege contra escoger un paquete después de ver holdout.

V7-C tiene plan explícito, pero el propio `PREREGISTERED_PLAN.json` incorpora `technical_hotfix_1_0_1`; además existen `CONTRACT_PRE_HOTFIX_1_0_0.json` y `CONTRACT.json`. Es un buen rastro de revisión técnica, no un preregistro inmutable perfecto. El resultado conserva el error inicial (`RESULTS.json:63129`) y el evento de reanudación (`:63148`). La afirmación de que C1-C3 quedaron intactos es declarada por el plan; no se dispone de un hash externo previo de cada módulo para demostrarla independientemente.

Part-D posee la separación más clara dentro de la batería v27 antigua: el manifiesto sella snapshots con seeds 20261005, 20271113 y 20281218, mientras el checkpoint D4 local documenta los nueve ensayos efectivos con seed de receta cross-N 20261005 y seed reservado 20761014. No deben confundirse los seeds de snapshots congelados con los seeds del holdout D4.

E2 incluye lector congelado, seed contractual 20260905 y holdouts independientes, pero no un documento denominado preregistro. Refoundation-A, Replay-A/B, Rosetta-B y Part-C sólo conservan política en runner/manifiesto/resultados: su auditabilidad prospectiva es menor.

## Fallos técnicos frente a negativos científicos

| Tipo | Campaña / módulo | Hecho | Lectura correcta |
|---|---|---|---|
| Técnico | Refoundation-A / A6 | linker MSVC `LNK1104`, no pudo abrir `.exp` | Contrafactual compilado no ejecutado; científico inconcluso |
| Técnico | Replay-A / A6 | `PermissionError` al limpiar `.pyd` cargado | El resultado del módulo queda técnicamente fallido; no refuta coherencia |
| Técnico | Part-C / C4 | proceso hijo sin `setuptools` | No hubo contrafactual short-path válido |
| Técnico con reparación | V7-C / primera C4 | `source overlaps prepared substrate`; hotfix 1.0.1 usa apertura matched | La entrega final completa es usable, conservando la bifurcación de protocolo |
| Operacional | V6-A | presupuesto temporal alcanzado; ZIP pausado y WORK continúa | Campaña no cerrada, no FAIL |
| Científico acotado | Part-C / C7 | 9/9 `no_resolved_group_mode` | Aparato de velocidad de grupo no resolvió modo en esos casos |
| Científico acotado | V6-D / D3 | ninguna preparación pasa todos los gates | No hay paquete resuelto en el panel; recomienda inspeccionar otros regímenes |
| Científico compuesto | V6-F | tres gates de decodificación/robustez falsos | Familia completa de transferencia negativa aunque hay dependencias causales parciales |
| Científico | V7-A / V7-B | grados C | Relación/chain simple no soportada o no resuelta en sus dominios |

## `TORUS_MOVING`: qué estaba documentado

La fuente documental más precisa es `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ANALYSIS/docs_claims/extracted/036_ed12ac6537b8_composicion_estructural_del_whl_v25.txt`:

- líneas 709-726: la aceptación de v25-LAZY fue equivalencia de estado, con arrays `uint64` completos y clocks; la auditoría rápida reporta 16/16 y enumera `TORUS_MOVING` entre los casos;
- líneas 867-879: el apéndice H da a `TORUS_MOVING` estado PASS y define lo verificado como comparación de `grid_A`, `grid_B`, `clock_A`, `clock_B` y eventos en checkpoints;
- `ROOT/necesarios/DEE_CLAUDE_CONTEXT_PARTE_03.txt:3752-3815` reproduce la misma matriz y los controles dense-vs-lazy.

No hay ocurrencias de `TORUS_MOVING` en `ANALYSIS/zip_members.csv` ni en los 2,199 metadatos de campaña ya copiados. Tampoco hay, en los fragmentos documentales localizados, definición del fixture o una tabla de posiciones. Por ello:

- **Sí se puede afirmar:** un escenario llamado `TORUS_MOVING` estaba cubierto y pasó la regresión de equivalencia v25 dense-vs-lazy.
- **No se puede afirmar:** que se midiera desplazamiento espontáneo de un objeto persistente, que el mismo material viajara, que existiera q(t)/v(t), o que se cerrara una ley de movimiento.
- **Incertidumbre residual:** el script original del fixture podría contener esa construcción, pero no está identificado en los artefactos de campaña auditados. Recuperarlo permitiría reconstruir el estímulo; aun así haría falta un observable explícito de movilidad.

Esto concuerda con el contrato posterior de V6-F: “transfer is recoverable causal organization at B, not motion of a classical carrier unless independently demonstrated”. En V7-B, el campo `translation` de cada fila es una transformación impuesta al patrón del ensayo; no es una observación de traslación espontánea.

## Sesgos y trampas de observables

- **Clock absoluto frente a cociente funcional.** La accuracy 1.0 de V7-B está definida por un lector de cociente congelado sobre clases templadas. Es evidencia de transferencia de firma funcional bajo intervenciones, no de trayectoria material.
- **Ocupación visible frente a estado completo.** V7-A/V7-C comparan lecturas visibles con raw/clock profundo. Una mejora predictiva del observador profundo demuestra información omitida por la proyección visible; no demuestra por sí sola cierre, objeto o materia.
- **Geometría nominal.** Part-D y E2 advierten que isotropía de covarianza no es esfera, rotación de centroide no es hélice, un modo angular no es “snowflake”, y un objeto percolante toroidal no tiene una frontera euclidiana exterior única.
- **Timing causal frente a relatividad.** V7-C soporta cono Chebyshev y distancia topológica nativa en su holdout, pero no marcos inerciales, intervalo de Lorentz, métrica suave ni tensor energía-momento.
- **Ausencia de detección frente a ausencia ontológica.** Los 9 casos sin modo de grupo y el `selected=null` de V6-D cierran aparatos concretos; no demuestran que el kernel carezca universalmente de modos colectivos.
- **Recurso nativo frente a energía.** E2 mide sitios/eventos y aplica un sumidero externo periódico que borra grid+clock en una ROI, sin fuente después de t0. Su propia limitación es capacidad finita en ese harness: no conservación, ciclo termodinámico cerrado ni energía ilimitada.
- **Contrajemplo finito frente a teorema global.** V6-C y V6-E refutan cierres reducidos en estados muestreados. Los modelos sin fibras iguales (M2/M3) quedan inconclusos, no validados.
- **Fórmula objetivo frente a ley descubierta.** El Formula Bridge parte de formas físicas conocidas y enumera premisas faltantes; sus detectores de `r_cheb=t`, `t_specific=d-9` y `period=L` tienen n=0. El propio reporte advierte que ausencia de claves explícitas no equivale a falsedad.

## Datasets reutilizables más decisivos

1. **V7-C `RESULTS.json` + casos + preregistro.** Mejor cierre causal interno, controles de cono/topología/history y hashes de estado. Reutilizar preservando el hotfix y el hecho de que receiver reached=.5 y hidden-before-visible=0.
2. **V6-C `RESULTS.json` + `PREREGISTERED_SPECS.json` + freeze.** Cadena prospectiva más limpia para contrajemplos de cierre y comparación de observadores. El ZIP contiene el core; los 816 NPZ crudos adicionales están sólo en el WORK.
3. **V6-E summary/resultados + preregistro/freeze.** Contrajemplos M0/M1 y predicción eta→D en holdout con métricas compactas y buen contrato epistemológico.
4. **Part-D detailed JSON/snapshots + checkpoint D4.** Atlas target-free, nulos matched, cross-N y seed reservado; útil para morfología sin etiquetado. El checkpoint D4 es extra local del WORK y debe empaquetarse/sellarse si se reutiliza fuera de esta máquina.
5. **V7-B ZIP o `RESULTS/`.** 824 artefactos finales, lector y modelos congelados, 732 NPZ; útil para cociente funcional y mediación. No usar el WORK incompleto.
6. **E2 WORK/ZIP.** 4,469 artefactos, 2,108 NPZ, 360 PNG y un atlas HTML amplio; valioso para visual/temporal/recurso, pero de alto riesgo de pareidolia y sin preregistro separado.
7. **Part-C + V6-D.** Negativos compactos y decisivos para no repetir exactamente los mismos detectores de paquete/velocidad sin cambiar y preregistrar el aparato.
8. **V6-F.** Matriz de gates indispensable para cualquier afirmación futura de identidad o transferencia: obliga a separar soporte causal, decodificación ciega, robustez y movilidad material.

Los hashes de archivos empaquetados están en cada manifiesto y los hashes de los 17 ZIP en `ANALYSIS/ARCHIVE_HASHES.sha256`. Para análisis reproducible debe registrarse siempre cuál versión se usó: ZIP final, WORK evolucionado o alias `RESULTS/`.

## Contradicciones, faltantes e incertidumbres

1. **E1 ausente:** E2 ordena leer conjuntamente E1, pero no existe ZIP/directorio E1 en el inventario. No se infiere inexistencia histórica, sólo falta de artefacto en este corte.
2. **V6-A no final:** el ZIP dice `paused` mientras el WORK dice `running`. Es evolución legítima, pero invalida tratar el ZIP `RESULTADOS_CORE` como cierre.
3. **V7-C preregistro revisado:** el hotfix está documentado y el error se conserva, pero no hay freeze separado pre-hotfix del plan completo. Queda incertidumbre de inmutabilidad, no de que el final ejecutó.
4. **Part-D holdout fuera del ZIP:** `checkpoints/D4_holdout.json` sólo está en WORK. El summary empaquetado confirma 9 holdouts, pero el detalle crudo depende del WORK local.
5. **Seis runners sin copia raíz:** siguen dentro de ZIP y sus hashes están registrados; es un faltante de conveniencia/lineage del workspace, no evidencia de corrupción.
6. **Manifiestos v27 antiguos en texto:** sellan artefactos por línea, pero carecen del esquema JSON uniforme. No se hizo verificación exhaustiva de todos los miembros binarios.
7. **Identidad del kernel sólo reportada:** varias campañas declaran kernel SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`, package `7e2991…f8b4` y wheel esperado `69297e…c939`. Esta auditoría confirma consistencia de la declaración, no el binario cargado de forma independiente.
8. **Nomenclatura V6/V7:** son nombres de series experimentales dentro del corpus v27; no deben leerse automáticamente como versiones del kernel.
9. **`TORUS_MOVING` sin definición:** el PASS documental es sólido para equivalencia dense-lazy, pero falta el generador/fixture y toda telemetría cinemática.

## Artefactos de esta auditoría

- Síntesis humana: `ANALYSIS/CAMPAIGN_AUDIT.md`
- Afirmaciones normalizadas: `ANALYSIS/CLAIMS_EXTRACTED.csv`
- Inventario de archivos ZIP: `ANALYSIS/archive_inventory.csv`, `ANALYSIS/zip_members.csv`
- Verificación de manifiestos: `ANALYSIS/manifest_verification.csv`, `ANALYSIS/manifest_sample_hashes.csv`
- Genealogía ZIP/WORK/runner: `ANALYSIS/zip_directory_comparison.csv`, `ANALYSIS/runner_lineage.csv`
- Índices de metadatos: `ANALYSIS/root_document_schemas.csv`, `ANALYSIS/interesting_values.csv`
- Bitácora: `ANALYSIS/PROGRESS_LOG.ndjson`
