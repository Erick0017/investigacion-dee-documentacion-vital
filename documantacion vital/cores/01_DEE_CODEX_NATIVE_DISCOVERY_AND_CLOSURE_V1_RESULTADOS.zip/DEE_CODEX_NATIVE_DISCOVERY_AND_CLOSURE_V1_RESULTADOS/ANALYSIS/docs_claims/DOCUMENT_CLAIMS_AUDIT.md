# Auditoría documental selectiva de afirmaciones DEE v27

**Corte:** 2026-09-11  
**Raíz local:** `D:\GENESIS AI\GENESIS 5.0\simulador de universo ab-initio\dee_libreria\VERSION_27\tests`  
**Objeto:** distinguir texto histórico, inferencia y evidencia ejecutada/fuente primaria para Claude T1–T7, transferencia v25→v27, constantes, materia, geometría, masa/inercia, termodinámica/hidrodinámica, quantum/Bell, gauge/simetrías y `H_DEE`.

## Dictamen ejecutivo

El dictamen Claude no puede adoptarse como paquete de siete “teoremas exactos”. El resultado forense es:

| Ítem | Adjudicación | Resultado mínimo defendible |
|---|---|---|
| T1, cono `r_Cheb(t)≤t` | **REFUTADO COMO TEOREMA UNIVERSAL** | La rama de overflow DEMUX lee vecino-de-vecino y puede hacer depender un destino de datos a hasta radio Chebyshev 3 en un tick. Los `12/12` de V7-C siguen siendo evidencia de aparato, no prueba global. |
| T2, clock rígido | **PROBADO CON CORRECCIÓN** | `c_i(t)=c_i(0)+t (mod 2^64)`. Las diferencias son invariantes módulo `2^64`; la resta ordinaria y `c-mean` requieren horizonte sin wrap o convención de unwrapping. |
| T3, redundancia local de clock | **CONDICIONAL / CORREGIDO** | El raw consulta `tick % periodo_ticks`; `L=1,094,573,220` es múltiplo común de la lista sintáctica, pero no una simetría full-state ni una simetría exacta de todo `uint64` a través del wrap. Para ramas dinámicamente activas, el m.c.m. mínimo es `304,980`. |
| T4, ausencia de invariantes aditivos rango 0 | **REFUTADO** | `SEM_OBSERVER` queda congelado en raw y DEMUX lo protege; el conteo —y funciones del raw— de observadores es una familia no trivial de invariantes aditivos rango 0 en el dominio full-state. El argumento de la “celda aislada” tampoco cubre raw direccional. |
| T5, no inyectividad | **PROBADO, PERO POR OTRA PRUEBA** | Mundo vacío y mundo con una sola celda `SEM_NORMAL`, `state>0`, `s_reg=dir=0`, con clocks iguales y `N` sin auto-aliasing, producen el mismo mundo vacío tras un tick. No colapsan “los `2^64` raw”: observadores y fuentes direccionales son contraejemplos a esa frase. |
| T6, simetrías | **PARCIAL** | Traslaciones toroidales: exactas. SYM1: reductor conmutativo. `O_h` global: no probado; el destino DEMUX desempata por el primer índice de `MOORE_DXYZ`. La batería ejecutada cubre patrones representativos, no el empate adversarial. |
| T7, CHSH | **TEOREMA CONDICIONAL, NO RESULTADO DEE** | `|S|≤2` requiere resultados binarios, independencia de ajustes, separación/factorización local con el cono real y ausencia de postselección. El corpus no contiene un aparato Bell que instancie y audite esas premisas. |

Dos consecuencias cambian el árbol de conclusiones de Claude:

1. La falsedad de T4 elimina el supuesto “pivote exacto” según el cual energía, termodinámica e hidrodinámica ya fallarían en rango 0. Los bancos históricos negativos siguen siendo negativos acotados, no teoremas globales.
2. La falsedad de T1 como cota universal impide usar automáticamente `r≤t` para validar separación causal en Bell o universalizar el aparato V7-C. La localidad permanece, pero la cota fuente conservadora es de hasta radio 3 por tick.

La integridad documental del Corpus Vols. 1–7 es buena; su contenido sigue siendo predominantemente **secundario/interpretativo**. El wheel v27 y los JSON/manifest/runner de campañas son la autoridad para conducta ejecutada. `H_DEE` es un axioma de trabajo o arquitectura condicional, no evidencia de equivalencia con la naturaleza; el propio Volumen 7 declara esa equivalencia externa no validada.

## Convenciones de evidencia

Los localizadores `A######` son anclas estables del texto DOCX extraído en `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\docs_claims\extracted` o `...\embedded_index\extracted`. `L##` denota línea del TXT original. Para C++ se usan líneas uno-basadas. Para JSON se indica archivo y ruta de claves.

Jerarquía aplicada:

1. **Fuente/ejecución primaria actual:** wheel v27, C++ embebido, runner, preregistro, manifest, resultados y casos.
2. **Primario histórico:** resultados/runners v25 preservados con hash. Prueba lo ejecutado en aquel kernel y aparato; no se transfiere automáticamente.
3. **Documento secundario:** Volúmenes, “Fórmulas”, estructura v27 y registros científicos. Sirven para genealogía, definiciones y localizar primarios, pero no convierten una afirmación en ejecución.
4. **Interpretación/hipótesis:** analogías físicas, puentes Rosetta, nombres ontológicos y `DICTAMEN_CLAUDE_POST_V7.txt`.

El inventario ya existente —no regenerado en esta fase— está en `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK\ANALYSIS\docs_claims\document_inventory_generated.csv`. Registra 51 archivos textuales auditados (43 DOCX, 8 TXT; 47 bajo `necesarios`). Sólo tres TXT tipo manifest se clasificaron como metadata primaria; los DOCX y el dictamen Claude son secundarios o interpretativos.

Inventario selectivo de autoridad:

| Fuente local | Clase forense | Uso permitido |
|---|---|---|
| `necesarios\DEE_CORPUS_INTEGRAL_VOLUMENES_1_A_7_Y_ATLAS_COMPLETO.docx` y Vols. 1–7 embebidos | Contenedor íntegro de documentos secundarios/históricos | Genealogía, alcance, definiciones y referencias a primarios; no prueba autónoma de conducta. |
| `necesarios\FORMULAS Y CORRESPONDENCIAS  DEE.docx` | Ledger secundario acumulativo | Estado histórico de fórmulas, negativos y cautelas; cada positivo empírico exige primario. |
| `necesarios\DEE_UNIVERSE_v27justificacion y estructura del kernel.docx` | Narrativa técnica secundaria | Genealogía v25→v27 y claims Phase0; no reemplaza artefactos decisionales ausentes. |
| `necesarios\composicion estructural del whl v25.docx` | Transcripción/reconstrucción secundaria | Orienta lectura histórica v25; no equivale al wheel v25 ausente. |
| `necesarios\DICTAMEN_CLAUDE_POST_V7.txt` | Interpretación/hipótesis | Objeto auditado, nunca fuente probatoria por sí mismo. |
| `*.MANIFEST.txt` y manifests JSON de las entregas | Metadata primaria | Integridad, membresía y hashes declarados; no adjudican por sí solos el contenido científico. |
| `...\docs_claims\volume2_manifest_verification.csv` | Verificación derivada de esta auditoría | Contraste local esperado/actual de 45 entradas; no es un primario histórico. |
| `dee_universe_v27-27.0.0-...whl` y `...\primary_evidence\wheel_v27\dee_kernel_v27.cpp` | Binario y fuente primaria actual | Semántica exacta de v27 y pruebas por inspección formal. |
| `RESULTS.json`, `SUMMARY.json`, casos, preregistros y runners de campaña | Evidencia ejecutada primaria | Resultados sólo dentro del kernel, apparatus, status y gates registrados. |

## Autoridad e integridad documental

### Corpus Volúmenes 1–7

`necesarios\DEE_CORPUS_INTEGRAL_VOLUMENES_1_A_7_Y_ATLAS_COMPLETO.docx` contiene siete DOCX embebidos. Las copias en `...\docs_claims\embedded_sources\DEE_ORIGINAL_VOLUME_[1-7].docx` coinciden byte-a-byte con el manifest interno y con los originales independientes presentes en `necesarios`; la verificación de fusión interna reporta igualdad textual. Esto prueba **integridad de transmisión**, no veracidad científica de cada frase.

Hashes de Vol. 7 y ejecutable declarados en el propio Volumen 7:

- Volumen 7 embebido: `fd54f7f01a7957614776f5bfa4f4a10b0fca889286eb12d1e085a76332f35451`.
- wheel v27 de referencia: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- `.pyd`: `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- paquete `__init__.py`: `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4`.

Fuentes: `necesarios\DOCUMENTO MAESTRO.docx`, Vol. 7 `A000689–A000714`; wheel local `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl`; copia exacta del C++ en `...\docs_claims\primary_evidence\wheel_v27\dee_kernel_v27.cpp`.

### Bundle histórico v25

El bundle embebido en Vol. 2 contiene 45 entradas de manifest verificadas `PASS` en `...\docs_claims\volume2_manifest_verification.csv`; los JSON y runners preservados son evidencia primaria histórica. El wheel v25 no está incluido: `...\docs_claims\volume2_forensic_bundle\audit\MISSING_WHL.txt` declara `dee_universe_v25-25.0.0-cp313-cp313-win_amd64.whl`, SHA esperado `C7850961262CAC7B9C879EBF76E2A0FE60E544EDBA2212F6D18DA3EFD1FEB4CC`. Por ello `necesarios\composicion estructural del whl v25.docx` es una transcripción documental útil, pero no sustituye una inspección independiente del binario v25 ausente.

### Transferencia v25→v27

La frase Claude “v27 se diferencia [de v25] únicamente por SYM1 y `P_KERNEL=19665`; Phase0 demostró equivalencia full-state en todo lo demás” (`DICTAMEN...`, `L5`) mezcla tres niveles:

- **Historia documental:** `necesarios\DEE_UNIVERSE_v27justificacion y estructura del kernel.docx`, `A000118`, describe v26-SYM1; `A000173–A000219`, el cambio `19658→19665`; `A000221–A000253`, Phase0 y nueve familias con arrays/clocks iguales.
- **Restricción expresa del corpus:** Vol. 7 `A000243` dice que las afirmaciones de distintos kernels no se trasladan automáticamente.
- **Hueco primario local:** al corte no aparecen `DECISION_EDITABLE.json`, `DECISION_INSTALLED_WHEEL.json`, `V27_FINAL_BUILD_AND_DECISION_MANIFEST.json` ni `DEE_V27_DECISION_EVIDENCE.zip`. Phase0 no puede revalidarse aquí como cadena primaria completa.

La conclusión válida es más estrecha: las propiedades actuales discutidas abajo se prueban directamente contra el C++ del wheel v27; no necesitan una transferencia global desde v25. Los resultados v25 sólo conservan validez histórica en su propio kernel/aparato hasta que sean repetidos o se demuestre que no atraviesan las ramas cambiadas.

## Auditoría detallada de Claude T1–T7

### T1 — cono causal

**Afirmación documental:** `DICTAMEN_CLAUDE_POST_V7.txt`, `L28`, dice que `actualizar_voxel` sólo lee Moore radio 1 y que DEMUX sólo escribe a un vecino, por lo que la dependencia total sería radio 1 por tick.

**Fuente actual:** `dee_kernel_v27.cpp`, `L371–L399`, para cada posible destino vecino del emisor recorre a su vez sus 26 vecinos (`L381–L387`) a fin de decidir si está “abierto”; la elección de destino se aplica en `L402–L407` y el delta en `L427–L443`. Para un output en `T`, el emisor puede estar a distancia 1, un candidato a distancia 1 del emisor y el dato de apertura a distancia 1 del candidato: la cota fuente conservadora es `r_Cheb≤3` por tick, no 1. La dependencia no es una lectura muerta: un sitio lejano puede cambiar el conteo de un candidato de 7 a 8, cerrarlo y hacer que el strict-min pase el delta a otro destino; el test P0 debe materializar esta construcción en el binario y determinar si el radio 3 se satura.

**Ejecución existente:** `DEE_V7_C_SUSTRATO_DISTRIBUIDO_CAUSALIDAD_RELACIONAL_FINAL_V1_WORK\SUMMARY.json` informa `causal_cone_respected_all_holdout=true`, `12` holdouts según Vol. 7 `A000862–A000865`. Eso valida el aparato y horizonte ensayados; no activa necesariamente overflow ni prueba la cota universal.

**Adjudicación:** T1 queda refutado **como teorema universal y como prueba**. Sigue abierta la cota exacta alcanzable; una pareja contrafactual que active el empate DEMUX debe mostrar si el radio 3 se satura.

### T2 — clock

**Afirmación documental:** `L30–L34`.

**Fuente actual:** la rama OBSERVER incrementa clock en `dee_kernel_v27.cpp:L247`; las salidas tempranas lo hacen en `L305`, `L312`, `L320`, `L326`, `L331`, `L346`; la salida ordinaria en `L421`; Lazy inicializa todos los outputs con `clkA+1ULL` en `L586–L590`; `aplicar_demux`, `L427–L443`, no toca clock.

Como el tipo es `uint64_t`, el resultado exacto es

`c_i(t) = c_i(0) + t (mod 2^64)`.

Por tanto `c_i-c_j` es invariante módulo `2^64`. `c_i-mean_ROI(c)` sólo es exactamente constante con una representación sin wrap o una convención explícita de unwrapping; no es una identidad global de reales sobre todo el espacio `uint64`.

**Ejecución acotada:** el resultado corregido V7-B en `RESULTS\SUMMARY.json`, claves `clock_quotient_transfer.strict_accuracy=1.0`, `migration_fraction=1.0`, `source_empty_fraction=1.0`, corresponde a `24/24`. Prueba el lector/aparato, no la interpretación ontológica “el clock no es tiempo”.

### T3 — redundancia del clock y cadencias

**Afirmación documental:** `L36` y “Fórmulas” `A000166–A000176`.

**Fuente actual:** `dee_kernel_v27.cpp:L355–L363` contiene la única lectura del clock que afecta raw: `periodo_ticks=782/(8-n_active)` y `tick % periodo_ticks`. La lista sintáctica para `a=1..8` es `{782,391,260,195,156,130,111,97}` y su m.c.m. es efectivamente `1,094,573,220`.

Correcciones:

- La rama de clock se alcanza después de descartar `rule_value==0` (`L338–L347`). Las cadencias dinámicamente relevantes son `782,391,260,195`; su m.c.m. mínimo es `304,980`. El `L` documental sigue siendo un múltiplo común válido, no el generador mínimo.
- La transformación sitio-a-sitio `c→c+kL` preserva la proyección raw si el desplazamiento y horizonte no cruzan wrap. No es simetría del full-state, porque el clock mismo cambia.
- En el espacio `uint64` global falla a través del wrap: `2^64 mod 782=52` (y tampoco es divisible por los demás periodos). Por tanto no existe la acción exacta `ℤ_L^(N^3)` proclamada sobre todo el espacio finito.
- La equivalencia `+391` sigue siendo contextual, como ya limita “Fórmulas” `A000181–A000188`.

**Adjudicación:** redundancia de codificación de la proyección raw, finita y condicionada; no gauge dinámico.

### T4 — invariantes aditivos rango 0

**Afirmación documental:** `L38` promueve los negativos F-114/F-150 a teorema universal.

**Contraevidencia fuente:** `SEM_OBSERVER=4` (`dee_kernel_v27.cpp:L44–L51`) conserva exactamente el raw y sólo incrementa clock (`L247`); DEMUX no modifica observadores (`L431–L433`). La única herencia potencial de semántica de vecino está en cristalización (`L299–L307`), pero el umbral exige `19665×966=18,996,390`, por encima del máximo bruto que puede formar la suma de 26 `uint16` ponderados; el propio documento v27 lo registra en `A000419`. Así, en el dominio full-state,

`Q_obs(X)=Σ_i 1[sem(raw_i)=SEM_OBSERVER]`

es no trivial y conservado. También lo es cualquier suma de pesos constantes por patrón raw OBSERVER.

Además, una celda direccional aislada puede escribir un vecino mediante `buscar_fuente_demux` (`L187–L225`, `L317–L321`), de modo que seguir sólo la celda original no demuestra el balance global de `Q`.

**Contradicción documental interna:** “Fórmulas” conserva explícitamente el alcance acotado: `A001698` (ausencia en un ensemble), `A001728` (el módulo posterior falló antes de medir) y `A001792` (“no autoriza ‘DEE no conserva nada’”).

**Adjudicación:** T4 refutado en el dominio que Claude enuncia. Una versión restringida a estados naturales sin OBSERVER necesita declarar formalmente ese dominio y volver a probarse; no puede heredarse del banco histórico.

### T5 — no inyectividad

**Afirmación documental:** `L40`, derivada incorrectamente de T4 y acompañada por “`2^64` valores de raw aislado colapsan”.

**Prueba corregida de fuente:** para `N` suficientemente grande para evitar aliasing Moore, compare:

- `X0`: grid completamente vacío;
- `X1`: mismo grid salvo una celda `pack_voxel(state=1,s_reg=0,dir=(0,0,0),sem=SEM_NORMAL)`;
- clocks idénticos.

La celda central de `X1` tiene `n_active=0`, obtiene `rule_value=0` y se vacía (`L338–L347`). Cada vecino vacío ve sólo una fuente sin dirección: no satisface XNOR (`L160–L170`) ni `buscar_fuente_demux` (`L199–L218`), y queda vacío (`L299–L332`). Los clocks avanzan igual. Luego `F(X0)=F(X1)`.

**Adjudicación:** no inyectividad probada para v27. La cardinalidad y universalidad de colapso de Claude son falsas: OBSERVER se congela y una fuente direccional puede propagarse.

### T6 — traslaciones y grupo cúbico

**Afirmación documental:** `L42`.

**Fuente actual:** el indexado es relativo y toroidal (`dee_kernel_v27.cpp:L63–L69`, `L134–L139`), por lo que las traslaciones de la retícula son exactas. SYM1 agrega todas las fuentes entrantes con sumas conmutativas (`L187–L225`). Sin embargo, el destino de overflow mantiene el primer candidato con mínimo estricto `s_v<s_min_vecino` (`L371–L399`); empates dependen del orden lexicográfico de `MOORE_DXYZ`, que no es equivariante bajo todo `O_h`.

**Ejecución primaria:** `DEE_V27_NATIVE_REFOUNDATION_AND_BIAS_CORRECTION_PART_A_V1.zip.work\DEE_V27_NATIVE_REFOUNDATION_AND_BIAS_CORRECTION_PART_A_V1.json`, módulo `A1_MULTISOURCE_COMPOSITION_AND_CUBIC_EQUIVARIANCE_27X`, registra `pair_total=325`, `pair_swap_invariant`, `pair_reducer_exact` y `cubic_exact=48/48` por patrón ensayado; el módulo A1 terminó. El resumen de campaña es `completed_with_failures` porque A6 falló técnicamente, por lo que no debe describirse toda la campaña como PASS limpio. Ninguno de esos campos demuestra cobertura del empate de destino overflow.

**Adjudicación:** traslaciones y reductor SYM1 probados; `O_h` global queda refutable por un caso de empate DEMUX y no está demostrado por la batería representativa.

### T7 — Bell/CHSH

**Afirmación documental:** `L44`, reutilizada en `L77–L78` como restricción física.

El teorema estándar `|S|≤2` se obtiene sólo cuando el aparato proporciona outcomes binarios, independencia estadística de ajustes y variable oculta, factorización/localidad respecto del cono causal correcto y una muestra sin selección dependiente de outcome/settings. Determinismo y la palabra “local” no certifican por sí solos esas condiciones operacionales.

No se localizó en el Corpus un preregistro, generador de ajustes, definición de `λ`, outcomes, spacetime/separación, auditoría de independencia ni resultados CHSH. Además, T1 usa la cota causal equivocada.

**Adjudicación:** teorema matemático condicional; `NO_IDENTIFICABLE` como resultado físico DEE. No puede emplearse para afirmar compatibilidad, incompatibilidad o superdeterminismo hasta construir el aparato y medir las premisas.

## Genealogía de constantes y límites de interpretación

| Objeto | Evidencia implementada | Genealogía documental | Dictamen |
|---|---|---|---|
| `α*`, `Δν*` | No son entradas observadas por el kernel C++ como medición. | `DEE_UNIVERSE_v27...docx`, `A000068–A000091`: `α^-1=4π^3+π^2+π-6Δν`, `Δν=3α²/π`; el propio texto la llama ley constitutiva, no teorema inevitable de `Z^3`. | Input/elección constitutiva. Una coincidencia con α no es predicción independiente. |
| `K_LIMIT=9.887`, cristalización `966` | `dee_kernel_v27.cpp:L25`, `L34`, `L299–L307`. | `A000146–A000167`. | Literal actual; la rama de cristalización es inalcanzable bajo los bounds del payload (`A000419`). No es fenómeno ejecutado observado. |
| `P_KERNEL=UMBRAL_FUSION=19665`, cap `19664` | `dee_kernel_v27.cpp:L35–L36`, saturación `L220–L221`, `L439–L443`. | `DEE_UNIVERSE...`, `A000142–A000178`; “Fórmulas” `A002137–A002139`. | Constante/threshold implementado. La derivación desde `Δν*` no es validación externa independiente. |
| `782` | Literal de cadencia en `dee_kernel_v27.cpp:L358`. | `DEE_UNIVERSE...`, `A000146–A000167`; “Fórmulas” `A000166–A000176`. | Parámetro implementado; no frecuencia física. |
| `391` | Surge por división entera `782//2` cuando `8-n_active=2`. | “Fórmulas” `A000181–A000188`, `A000741–A000746`. | Equivalencia de fase contextual, no constante universal ni escala SI. |
| `L=1,094,573,220` | No existe como literal; se deriva del m.c.m. de ocho cocientes. | “Fórmulas” `A000166–A000176`; Claude `L36`. | Múltiplo común correcto de la lista sintáctica; no simetría full-state y no mínimo de ramas dinámicamente activas. |
| `TTL_ORFAN=194422` | Literal y payload escrito sólo cuando DEMUX impacta un ORPHAN: `dee_kernel_v27.cpp:L37`, `L434–L435`. | “Fórmulas” `A002010`, `A002105`. | Propiedad de fuente; el subtest reportó `hit_count=0`. No lifetime universal observado. |
| `20 Hz` | No aparece como escala física ejecutada del kernel. | “Fórmulas” `A002045`, `A002090–A002109`. | Hipótesis Rosetta/externa no promovida; `f∝v/L` interno no valida 20 Hz. |
| “masa informacional” | Conteo de ocupación. | “Fórmulas” `A000043`. | Observable de ocupación; no masa física. |
| Entropía binaria | Shannon sobre occupancy. | “Fórmulas” `A000068`, `A001717–A001718`. | Entropía informacional; no termodinámica física. |

Los nombres `TENSION_ELECTROWEAK=2.5` y `TENSION_STRONG=16` (`dee_kernel_v27.cpp:L32–L33`) son etiquetas de constantes combinatorias. Sin unidades, protocolo de acoplamiento y Rosetta congelada, no evidencian interacción electrodébil o fuerte.

## Mapa de evidencia por dominio

### Materia, movilidad y modos

- **Ejecutado:** `DEE_V7_A_ATLAS_ESTADOS_EXISTENCIA_ENTORNO_FINAL_V2_WORK\SUMMARY.json` está `completed`, encuentra pluralidad de regímenes, pero `matter_like_regime_clusters_verified=[]`. Vol. 7 lo contextualiza en `A000801–A000822`: 2 regímenes, 5/6 holdouts dentro de radios y 0 clusters bajo el gate compuesto.
- **Definición posterior:** Vol. 7 `A000913–A000914` define “materia DEE” como basin/órbita/atractor/candado de fase, no como voxel. Es una definición operacional interna; no reescribe el negativo del gate compuesto ni demuestra materia física externa.
- **Modos:** el primario `...\EXTRACTED_INPUT_COPIES\campaigns\DEE_V27_TRANSVERSAL_NATIVE_PROCESSING_AND_GROUP_VELOCITY_PART_C_V1\...SUMMARY.json` registra `C7_class_counts.no_resolved_group_mode=9`; la campaña global fue `completed_with_failures` por C4, aunque C7 terminó. “Fórmulas” limita correctamente el resultado en `A002173`, `A002371`: no es ausencia universal de modos.
- **Paquetes:** `...\EXTRACTED_INPUT_COPIES\campaigns\DEE_V6_D_PAQUETES_TRANSPORTE_ROSETTA_V1_RESULTADOS_CORE\RESULTS.json`, `modules.D3_ADJUDICATION.status=no_resolved_packet_in_screen`, es un negativo de screen, no teorema global.

No hay aún una clase material móvil con coordenada colectiva `q`, identidad estable y respuesta a fuerza/kick que permita definir cinemática o inercia.

### Geometría y causalidad

V7-C aporta evidencia ejecutada fuerte pero acotada: `SUMMARY.json` está `completed` y reporta `same_inventory_geometry_modulation_fraction=1.0`, `history_modulation_fraction=1.0`, `native_topology_timing_match_fraction=1.0`, `hidden_before_visible_receiver_fraction=0.0`. Vol. 7 `A000859–A000884` da los conteos 2/2, 2/2, 4/4 y ausencia de señal adelantada en 12 holdouts.

Esto sustenta dependencia de primera llegada/accesibilidad respecto de organización, historia y topología nativa del aparato. No identifica tensor métrico, curvatura, gravedad, equivalencia ni ecuaciones de Einstein. El gate de cono debe conservarse como resultado de esos holdouts, no como prueba de T1 global.

### Masa, inercia y energía

Vol. 7 `A000792–A000798` declara que no se ha identificado variable universal equivalente a masa/inercia, energía, temperatura, carga o gravedad, ni un coarse-graining único. Esa declaración es coherente con el expediente: no se localizó un mismo objeto móvil para el cual se midan masa inercial y respuesta geométrica bajo intervenciones emparejadas. Rangos de matrices de respuesta o susceptibilidades contextuales no son por sí solos masa. La prueba correcta requiere una clase `q` congelada, ley fuerza–aceleración y holdouts cruzados.

### Termodinámica e hidrodinámica

La no inyectividad permite definir tamaños de fibra y entropías informacionales; no aporta automáticamente energía, temperatura, equilibrio, ensemble físico, calor o producción entrópica. “Fórmulas” `A000068`, `A001717–A001718` hace esta separación.

Los negativos F-114/F-150 cierran sólo bancos de observables simples: “Fórmulas” `A001698`, `A001728`, `A001792`. Dado que T4 es falso en full-state, no puede concluirse “sin carga rango 0” ni “sin hidrodinámica” globalmente. Tampoco se ha localizado una ecuación de continuidad `Δρ+∇·J=s`, un campo lento, relación constitutiva o límite de escalado. Termodinámica física e hidrodinámica siguen `NO_IDENTIFICABLE`; lo positivo actual es sólo informacional.

### Quantum y Bell

Representar una órbita periódica mediante un operador de Koopman unitario es una construcción matemática genérica. No identifica Hilbert físico, composición tensorial, observables, proyectores, regla de Born ni estadística cuántica. T7 sólo restringiría un aparato Bell después de instanciar y auditar sus premisas; hoy ese aparato no existe en el expediente.

### Gauge y simetrías

El cociente de clock de V7-B es útil para identidad relativa en ese lector. No demuestra simetría gauge porque la transformación no preserva full-state, falla en wrap global y no hay variables de enlace, conexión, curvatura ni carga acoplada. Las traslaciones toroidales sí son exactas. La simetría cúbica está ejecutada en patrones A1 y permanece abierta/refutable en el empate de destino DEMUX.

### `H_DEE`

`DICTAMEN_CLAUDE_POST_V7.txt:L3` adopta `H_DEE` como axioma; ese acto no es evidencia. Vol. 7 `A000793–A000795` declara ausentes equivalentes universales y validación externa; `A001003` resume una ontología interna. Bajo `H_DEE` puede estudiarse coherentemente la arquitectura `F→observables→cocientes→Γ_eff`, pero las flechas hacia física conocida siguen condicionales.

Para convertir `H_DEE` en hipótesis científica discriminable faltan, como mínimo: Rosetta externa congelada antes de resultados; observables operacionalmente suficientes; clases móviles y modos colectivos robustos; cargas/corrientes o campos lentos; respuesta de inercia/geometry sobre la misma clase; y holdouts externos independientes. Al corte, el grado de equivalencia física externa ejecutada es **no identificado**, no cero ontológico ni PASS.

## Contradicciones y riesgos de procedencia

1. **V7-B tiene colisión de rutas.** `DEE_V7_B_ROSETTA_INFORMACION_GEOMETRIA_ENTORNO_FINAL_V2_WORK\RESULTS.json` termina con `status=failed_technical` (`NameError: read_state`), aunque contiene módulos parciales. La ejecución corregida `completed` está en la ruta genérica `RESULTS\RESULTS.json` y su resumen en `RESULTS\SUMMARY.json`, con `campaign=DEE_V7_B_ROSETTA_INFORMACION_GEOMETRIA_ENTORNO_FINAL_V2`. Vol. 7 `A000824` documenta la corrección. Toda cita debe nombrar explícitamente la ruta corregida; citar sólo el directorio nominal puede seleccionar el run fallido.
2. **T4 contradice el registro de alcance.** Claude convierte F-114/F-150 en teorema; “Fórmulas” los limita a ensembles/bancos y advierte que no significan “DEE no conserva nada”. La fuente OBSERVER refuta la promoción.
3. **T1 universaliza un resultado de aparato.** V7-C ejecutó un gate sin pre-señal en 12 holdouts; la fuente contiene una ruta de dependencia más ancha. Ambas afirmaciones coexisten sólo si se mantiene el alcance.
4. **Simetría global vs batería representativa.** A1 tiene resultados exactos por patrón, pero la fuente conserva desempate por orden. Además, la campaña A terminó `completed_with_failures` por A6; el módulo A1 sí es utilizable y debe citarse como tal.
5. **Materia definida vs gate material negativo.** La redefinición por basin/órbita no invalida `matter_like_regime_clusters_verified=[]`; cambia el predicado. Deben mantenerse dos filas separadas en cualquier ledger.
6. **Transferencia histórica vs autoridad actual.** Phase0 se describe, pero sus artefactos decisionales no están en `tests`; el wheel v27 sí contiene el C++ y permite probar el kernel actual sin asumir equivalencia global v25→v27.

## Pruebas de kernel prioritarias para cerrar afirmaciones

| Prioridad | Prueba finita | Claim que decide | Criterio mínimo |
|---|---|---|---|
| P0 | **Testigo de radio DEMUX.** Dos estados iguales dentro de `B_1(T)` —idealmente también `B_2(T)`— y distintos sólo en un sitio lejano, con overflow y empate controlados. | T1 / cono verdadero. | Comparar full raw+clock tras un tick; localizar el menor radio que cambia `T`. Incluir `N` grande y control sin overflow. |
| P0 | **Empate `O_h` DEMUX.** Dos destinos abiertos con igual `s_reg`, aplicar las 48 transformaciones cúbicas. | T6 global. | PASS sólo si `F(RX)=R F(X)` full-state para todas; registrar índice ganador y deltas. |
| P0 | **Dominio de conservación explícito.** Separar full-state, sin OBSERVER, y reachable-from-approved-seeds. | T4 y pivote termo/hidro. | Reconocer primero `Q_obs`; luego resolver el nullspace de `Q=Σq` sólo en el dominio declarado y validar fuera de muestra. |
| P1 | **Wrap de clock.** Clocks cerca de `UINT64_MAX`, shifts `L` y `304980`, varios periodos activos. | T2/T3. | Full raw+clock y residuos antes/después del wrap; distinguir simetría raw de full-state. |
| P1 | **Conservación/corriente rango 1–2.** Buscar conjuntamente densidad `ρ`, corriente `J` y fuente `s`. | Termo/hidro/GR efectiva. | Ecuación de balance local y holdouts; no promover un nullspace sólo entrenado ni confundir observer-sector trivial con carga material. |
| P1 | **Clase móvil preregistrada.** Seleccionar basin/órbita antes de holdout, rastrear `q`, daño, traslación y kicks. | Materia, movilidad, masa/inercia. | Identidad operacional congelada, transporte del soporte/organización y ley respuesta–kick reproducible cross-N/seed. |
| P2 | **Modo colectivo y dispersión.** Reabrir sólo si aparece un modo nativo, sin instalarlo en la preparación. | Relatividad efectiva, masa espectral, hidrodinámica. | `ω(k)` estable, velocidad de grupo y escalado angular/cross-N con nulls; C7/D actuales son negativos acotados. |
| P2 | **Bell operacional.** Sólo después de disponer de fuente, dos estaciones y outcomes. | T7 / quantum. | Auditar `λ⊥(a,b)`, separación con el cono medido, señalización, postselección y CHSH en holdout. |
| P2 | **Rosetta externa congelada.** Una relación adimensional externa seleccionada antes de observar resultados. | `H_DEE`. | Predicción cuantitativa con incertidumbre y holdout externo; ninguna constante genealógicamente alimentada por el target cuenta como predicción. |

## Cierre

El expediente sostiene una dinámica interna determinista, local de alcance finito, no inyectiva, con clock rígido modular, pluralidad de regímenes y efectos causales de organización/topología en aparatos concretos. No sostiene todavía masa/inercia, termodinámica, hidrodinámica, quantum físico, gauge dinámico, gravedad ni equivalencia externa. El paso correcto no es promover documentos a pruebas: es resolver primero los tres claims fuente que alteran el árbol entero —radio DEMUX, empate `O_h` y dominio de conservación— y mantener cada resultado ejecutado dentro de su kernel, aparato y ruta primaria exacta.

## Addendum posterior al corte documental

Las pruebas prioritarias anteriores fueron ejecutadas después de cerrar esta extracción documental. El wheel v27 real resolvió el radio DEMUX en 3, refutó `O_h` global mediante un empate overflow y exhibió invariantes rango 0 sobre semantic 4. T8, preregistrado antes del holdout, formalizó el singleton balístico en las 26 direcciones y su álgebra de colisiones; T9 formalizó semantic 4 como boundary/source pump. La recuperación forense posterior mostró además que `TORUS_MOVING` v25 ya contenía el caso axial y que F-189/v25.5-C ejecutó 2,226 shifts exactos en 60/60 carriles. Por tanto, la frase previa “no hay aún una clase material móvil” queda **superada para una clase operacional interna restringida**, pero masa/inercia y la Rosetta física externa siguen no identificadas. Los negativos Part-C/V6-D conservan su dominio original y no se reetiquetan como PASS.
