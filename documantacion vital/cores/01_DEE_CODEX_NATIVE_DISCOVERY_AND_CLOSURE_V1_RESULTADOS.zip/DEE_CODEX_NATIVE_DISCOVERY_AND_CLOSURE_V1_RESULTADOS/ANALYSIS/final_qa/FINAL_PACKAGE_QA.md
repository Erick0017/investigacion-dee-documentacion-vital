# QA final de `FINAL_PACKAGE`

Fecha del snapshot auditado: 2026-09-11T16:54:09-06:00  
Modo: sólo lectura del paquete; no se ejecutó el kernel ni ningún runner y no se editó `FINAL_PACKAGE`.

## Veredicto

**PASS estructural con correcciones P1 antes del sello/ZIP final.** Los 12 entregables declarados en `MANIFEST.json` existen, no están vacíos y los artefactos tabulares/JSON inspeccionados parsean. `MANIFEST.json` y `HASHES.sha256` también existen y son internamente consistentes. La lista de 78 hashes pasó 78/78 en una comprobación independiente de sólo lectura; el manifiesto declara exactamente los 77 payloads que existen en disco, sin faltantes, extras ni diferencias de tamaño.

El paquete todavía no debe sellarse como ZIP definitivo porque quedan tres erosiones de dominio en la síntesis, una frase de prioridad histórica incorrecta y una validación de seguridad pendiente en `REPRODUCE.ps1`. Además, en el snapshot no existe aún `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip` en la raíz de `tests` ni dentro de la carpeta de trabajo.

No se detectó contradicción en `EXACT_THEOREMS.md`: es byte a byte idéntico al `EXACT_PROOFS.md` corregido, SHA-256 `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.

## Integridad y presencia

### Doce entregables requeridos

| Archivo | Estado | Comprobación |
|---|---|---|
| `FINAL_REPORT.md` | PRESENTE | 18,169 bytes |
| `EXECUTIVE_VERDICT.md` | PRESENTE | 13,035 bytes |
| `NATIVE_DEE_THEORY.md` | PRESENTE | 8,560 bytes |
| `EXACT_THEOREMS.md` | PRESENTE | 16,769 bytes; coincide con la prueba corregida |
| `CLAIM_LEDGER.csv` | PRESENTE | 31,209 bytes; 56 filas |
| `CLAIM_LEDGER.json` | PRESENTE | 54,816 bytes; objeto válido con 56 claims |
| `CLAUDE_AUDIT.md` | PRESENTE | 5,869 bytes |
| `HISTORICAL_CLAIMS_AUDIT.md` | PRESENTE | 9,389 bytes |
| `NEGATIVE_RESULTS.md` | PRESENTE | 5,345 bytes |
| `OPEN_EXTERNAL_GAPS.md` | PRESENTE | 4,355 bytes |
| `EXPERIMENT_INDEX.csv` | PRESENTE | 10,978 bytes; 18 filas |
| `REPRODUCE.ps1` | PRESENTE | 5,052 bytes; parser PowerShell: 0 errores |

### Sello del directorio

- `MANIFEST.json`: presente, schema `dee.codex.native_discovery_and_closure.final_package.v1`, status `COMPLETE`, 77 payloads declarados.
- `HASHES.sha256`: presente, 78 entradas; incluye los 77 payloads más `MANIFEST.json` y, correctamente, no intenta auto-hashearse.
- Rehash independiente: 0 archivos ausentes, 0 mismatches SHA-256.
- Paridad manifiesto/disco excluyendo manifiesto y hash list: 77/77, sin rutas extras ni omitidas; 0 mismatches de tamaño.
- Identidad sellada revalidada: wheel `69297e6f...bc939`, `.pyd` `0b17ba32...c6ff`, C++ `44a80f78...207ab`, preregistros T8 `0ea1b97d...b2fb` y T9 `6e60b8c...2fbe`.
- SHA-256 del snapshot de `MANIFEST.json`: `33b83738dd9958fa2acf69e369389adc4f380e971f4ae0bd7e908cb73e51b5d6`.
- SHA-256 del snapshot de `HASHES.sha256`: `6a770e93d5d686ccb54d0c20e8367e7a315ba80a0535918902c1eb9843424560`.

Esos dos últimos hashes dejarán de ser actuales si se corrigen los documentos o `REPRODUCE.ps1`; en tal caso deben regenerarse manifiesto y lista de hashes antes de construir el ZIP.

## Hallazgos priorizados

### P1-01 — La síntesis pierde restricciones `N>=5` y Moore de E9/E10/E12

`EXACT_THEOREMS.md` delimita correctamente:

- E9 singleton: `N>=5`, `d` Moore no nula;
- E10 gas: `N>=5`, dirección común Moore, separación Chebyshev toroidal por pares `>=3`;
- E12 observer pump: `N>=5`, dirección Moore no nula, únicamente `1<=t<N`.

Las síntesis convierten parte de ello en lenguaje universal:

- `FINAL_REPORT.md:7` presenta el singleton/gas sin `N>=5`; `:69` omite `N>=5` para el gas; `:71` omite `N>=5` para el pump.
- `EXECUTIVE_VERDICT.md:7` presenta el móvil exacto sin `N>=5`; `:9` dice que observer inyecta “si tiene dirección”, lo que incluye falsamente direcciones codificables fuera de Moore y no limita el horizonte.
- `NATIVE_DEE_THEORY.md:79` formula la permutación del gas separado sin `N>=5`; sus descripciones del observer direccional tampoco recuerdan que el teorema del tren es sólo Moore y pre-cierre.

Esto no refuta los resultados, pero sí contradice el dominio publicado si el resumen se lee autónomamente. Corrección mínima: añadir una oración de alcance común en cada resumen —“Los teoremas balístico, gas y pump aquí citados usan `N>=5`; el pump requiere dirección Moore y su fórmula cerrada sólo vale para `1<=t<N`”— y cambiar “si tiene dirección” por “si tiene una dirección Moore no nula, en el aparato aislado”.

### P1-02 — La salida de colisión debe seguir marcada como base pre-DEMUX

E11 corregido afirma que, para blanco raw-cero y XNOR falso, la fórmula de suma-cap/signo es la **salida base antes de `aplicar_demux`**; sólo es la salida final si no llega un delta overflow adicional. Para dos singletons aislados `N>=5` esa condición se satisface.

`FINAL_REPORT.md:70` omite “base pre-DEMUX” y la ausencia de overflow entrante. `NATIVE_DEE_THEORY.md:40` sí dice raw-cero/XNOR falso y su sección posterior menciona deltas, pero la oración aislada también puede interpretarse como producto final universal. Añadir la distinción explícita en ambos sitios. Las frases sobre “colisiones de dos fuentes aisladas” son correctas y no necesitan ampliación ontológica.

### P1-03 — Una frase de `CLAUDE_AUDIT` contradice la genealogía recuperada

La genealogía principal está bien formulada:

- `HISTORICAL_CLAIMS_AUDIT.md:11-16` documenta `TORUS_MOVING` v25 y v25.5-C/F-189 antes de T8;
- `EXACT_THEOREMS.md:E9` dice expresamente que T8 no fue la primera aparición histórica;
- `FINAL_REPORT.md:176-180` usa “generalización” y “antecedente recuperado”;
- `EXECUTIVE_VERDICT.md:7` reconoce ambos antecedentes y delimita T8 a formalización/holdout v27.

Sin embargo, `CLAUDE_AUDIT.md:66` afirma que el modo propagante y la clase móvil “fueron encontradas conjuntamente por T8”. Debe decir que **T8 las formalizó, generalizó y confirmó prospectivamente en v27, después de recuperar antecedentes v25/v25.5-C**. También es preferible retirar “primera” de `EXECUTIVE_VERDICT.md:7` (“primera formalización prospectiva exhaustiva”) salvo que “primera” se acote explícitamente a esta misión; la prioridad histórica global no puede demostrarse sólo con el corpus disponible.

No hay otra prioridad falsa detectada. La formulación cuantitativa de v25.5-C conserva el alcance correcto: 60/60 carriles, 2,226 comparaciones `np.roll`, `P=L` para packed/state/direction/semantic y `P=1` para `s_reg` idénticamente cero; no retrotrae el reducer multifuente v27 a v25.

### P1-04 — `ScratchPath` permite escribir dentro del paquete y copiar una carpeta dentro de sí misma

El camino por defecto de `REPRODUCE.ps1` es seguro y recuperable: crea una carpeta nueva junto a `FINAL_PACKAGE`, nunca borra, no instala, no modifica el wheel y escribe resultados sólo en scratch. Las rutas relativas de los runners empacados son autocontenidas: T8/T9 buscan wheel en `scratch/INPUTS`, `.pyd` en `scratch/ANALYSIS/binary_api/wheel_extracted`, preregistros en `scratch/HOLDOUTS`; D6 usa la copia sellada en `scratch/INPUTS/historical`.

Pero un `-ScratchPath` proporcionado por el usuario puede estar dentro de `$PSScriptRoot`. El script sólo comprueba que todavía no exista. Un valor como `FINAL_PACKAGE/RUNNERS_NEW/nuevo` crea el destino dentro de una carpeta que luego intenta copiar recursivamente hacia ese mismo destino; como mínimo muta el paquete después de verificar sus hashes y puede provocar autorrecursión/error de copia.

Antes de `New-Item`, resolver ambos paths y rechazar si `scratchFull` es igual o descendiente de `packageRoot` (y, por defensa, si uno contiene al otro). No se requiere borrado ni cleanup automático.

### P1-05 — Falta el ZIP solicitado

En el snapshot no se encontró `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip`. Es razonable construirlo después de aplicar esta QA, pero `MANIFEST.status=COMPLETE` no equivale todavía al entregable ZIP exigido por la misión. Tras las correcciones: regenerar `MANIFEST.json`/`HASHES.sha256`, revalidar 100%, crear el ZIP una sola vez y publicar el SHA-256 externo del ZIP.

### P2-01 — El chequeo de runtime no comprueba lo que afirma

`REPRODUCE.ps1:52-55` sólo comprueba `sys.version_info[:2] == (3,13)`, aunque el error afirma haber exigido “CPython 3.13 x64”. Tampoco comprueba que NumPy esté importable antes de crear/copiar scratch. Añadir en el probe previo `struct.calcsize('P')*8 == 64`, `platform.machine()` informativo e `import numpy`; opcionalmente registrar su versión. Así un runtime 32-bit o sin NumPy falla antes, con diagnóstico exacto.

### P2-02 — Fortalecimiento defensivo del verificador de hashes

La lista actual es correcta y pasó completa. Aun así, el parser acepta `../` o una ruta absoluta desde una lista manipulada, porque no confirma que el target resuelto permanezca bajo `packageRoot`. Es una lectura, no una destrucción, pero no es una frontera autocontenida estricta. Canonicalizar y rechazar cualquier target exterior. Para una garantía de completitud, comparar además el conjunto de `MANIFEST.files + MANIFEST.json` contra las rutas de `HASHES.sha256`; hoy esa paridad existe, pero el script sólo verifica lo que la lista enumera.

### P2-03 — El informe adversarial incluido es deliberadamente pre-corrección

`ANALYSIS/proof_review/ADVERSARIAL_REVIEW.md` audita el hash anterior `da840527...` y conserva cinco `ISSUE`; el teorema promovido ya los resolvió. Esto es trazabilidad legítima, no inconsistencia. Para evitar que un lector lo confunda con estado pendiente, puede añadirse fuera del texto sellado una nota de resolución o un pequeño `RESOLUTION.md` que apunte al hash corregido `f7fc8f...`.

## Consistencia E1–E15 por documento

| Documento | Resultado QA | Observación |
|---|---|---|
| `EXACT_THEOREMS.md` | PASS | Copia exacta del documento corregido; conserva ABI, pre-DEMUX, `N`, XNOR, overflow, observer, puntos fijos y alcance de simetría. |
| `FINAL_REPORT.md` | PASS CON P1 | ABI/E1–E8/E13–E15 correctos; restaurar `N>=5` en E9/E10/E12 y “base pre-DEMUX” en E11. |
| `EXECUTIVE_VERDICT.md` | PASS CON P1 | T1–T7 y límites físicos correctos; acotar móvil/pump y retirar o delimitar prioridad “primera”. |
| `NATIVE_DEE_THEORY.md` | PASS CON P1 | Arquitectura, máscaras y reacción pre-DEMUX correctas; acotar gas/pump y explicitar que reducer no siempre es producto final. |
| `CLAUDE_AUDIT.md` | PASS CON P1 | Adjudicaciones T1–T7 consistentes; corregir sólo la atribución histórica “encontradas por T8”. |

No se detectaron regresiones en los puntos delicados restantes: clock modular/no-wrap; radio causal 3 y diámetro; cristalización inalcanzable frente a nacimientos routing; observer como invariante; no-inyectividad no convertida en irreversibilidad universal; puntos fijos no llamados atractores; traslaciones sin pretensión de clasificar todo el grupo; Bell estrictamente condicional; occupancy no causalmente suficiente.

## `REPRODUCE.ps1`: conclusión estática

- Sintaxis: PASS, 0 errores de parser.
- Integridad de la estructura copiada: PASS.
- No destructividad por defecto: PASS; no hay delete/reset/install ni escritura sobre wheel/kernel.
- Autocontención de datos/código: PASS condicionada a CPython 3.13 x64 + NumPy externos, ambos declarados en README.
- Ejecución T8/T9/D6: lógicamente encaminada a outputs scratch correctos; no se ejecutó durante esta QA.
- Seguridad con input `ScratchPath`: FAIL hasta añadir la comprobación de contención P1-04.
- Diagnóstico de runtime: incompleto, P2-01.
- Verificación de frontera/completitud de hashes: funcional para el snapshot, fortalecible según P2-02.

## Secuencia mínima para cierre

1. Corregir P1-01, P1-02 y P1-03 en las síntesis.
2. Endurecer `ScratchPath` en `REPRODUCE.ps1`; idealmente incluir P2-01/P2-02.
3. Regenerar `MANIFEST.json` y `HASHES.sha256`; repetir paridad manifiesto/disco y rehash total.
4. Crear `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip` y calcular su SHA-256 fuera del propio ZIP.
5. No reejecutar el kernel por estas correcciones editoriales/operacionales: no cambiarían ninguna adjudicación científica.

