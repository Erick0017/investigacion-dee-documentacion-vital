# Reauditoría final de `FINAL_PACKAGE`

Fecha del snapshot auditado: 2026-09-11T17:10:02-06:00  
Modo: sólo lectura de `FINAL_PACKAGE`; no se ejecutó el kernel, ningún runner ni `REPRODUCE.ps1`, y no se editó el paquete.

## Veredicto

**PASS.** Los hallazgos P1-01, P1-02, P1-03, P1-04, P2-01, P2-02 y P2-03 de la QA anterior están cerrados en el snapshot actual. No queda ningún issue P1/P2 residual ni contradicción material entre los cinco documentos de síntesis y los dominios corregidos de E1–E15.

El ZIP final no se evaluó ni se contabiliza como defecto: por diseño se construirá después de este PASS.

## Cierre de hallazgos anteriores

| ID | Estado | Evidencia de cierre |
|---|---|---|
| P1-01 | **PASS / CERRADO** | `FINAL_REPORT.md:7,68-71`, `EXECUTIVE_VERDICT.md:7,9` y `NATIVE_DEE_THEORY.md:40,50,79` restauran `N>=5`, direcciones Moore, separación Chebyshev toroidal por pares `>=3` y el horizonte `1<=t<N` del pump. |
| P1-02 | **PASS / CERRADO** | `FINAL_REPORT.md:70` y `NATIVE_DEE_THEORY.md:40` califican el reducer como salida base antes de `aplicar_demux`, exigen blanco raw-cero/XNOR falso, advierten el posible delta overflow posterior y delimitan el caso final a dos singletons aislados `N>=5`. |
| P1-03 | **PASS / CERRADO** | `CLAUDE_AUDIT.md:66`, `EXECUTIVE_VERDICT.md:7`, `FINAL_REPORT.md:179`, `EXACT_THEOREMS.md:98` y X09 del ledger reconocen `TORUS_MOVING` v25 y v25.5-C/F-189. T8 se describe como formalización, generalización y confirmación prospectiva exhaustiva de esta misión sobre v27, no como primera aparición ni prioridad histórica global. |
| P1-04 | **PASS / CERRADO** | `REPRODUCE.ps1:14-20,94-106` canoniza paths y rechaza `ScratchPath` si coincide con el paquete, es descendiente suyo o lo contiene; la validación ocurre antes de crear la carpeta. |
| P2-01 | **PASS / CERRADO** | `REPRODUCE.ps1:83-92` comprueba CPython 3.13, punteros de 64 bits e importabilidad de NumPy antes de crear scratch; informa versión, arquitectura y NumPy. |
| P2-02 | **PASS / CERRADO** | `REPRODUCE.ps1:26-70` rechaza líneas malformadas, duplicados y rutas de hash exteriores; verifica hashes y exige igualdad de conjuntos entre `MANIFEST.files + MANIFEST.json` y `HASHES.sha256`. |
| P2-03 | **PASS / CERRADO** | `ANALYSIS/proof_review/RESOLUTION.md` identifica la revisión adversarial como auditoría histórica del borrador `da840527...`, enumera las correcciones resueltas y remite al teorema promovido con SHA-256 `f7fc8f...c609`. |

## Dominios matemáticos sensibles

**PASS.** La copia promovida `EXACT_THEOREMS.md`, la copia de apoyo `ANALYSIS/native_theory/EXACT_PROOFS.md` y el original corregido de trabajo son byte a byte idénticos, con SHA-256:

`f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.

La relectura de las síntesis confirmó:

- E9: singleton normal, `N>=5`, dirección Moore no nula;
- E10: `N>=5`, dirección Moore común y distancia Chebyshev toroidal por pares `>=3`;
- E11: blanco raw exactamente cero, XNOR falso y fórmula del producto base pre-DEMUX; producto final sólo sin delta overflow adicional;
- E12: observer aislado, `N>=5`, dirección Moore no nula y fórmula exclusivamente para `1<=t<N`;
- E6: supervivencia/nacimiento descritos como regla base pre-DEMUX, sin elevarlos a caracterización final incondicional;
- E14: traslaciones demostradas y `O_h` global refutado, sin afirmar una clasificación completa del grupo global.

No apareció ninguna reclamación residual de prioridad global de T8. Las apariciones de “primera aparición/observación” en el paquete son negaciones explícitas o instrucciones históricas de corrección, no claims positivos.

## `REPRODUCE.ps1`

**PASS estático.** El parser de PowerShell produjo **0 errores** y 1,083 tokens. SHA-256 actual:

`f86f3b79d35e75efdb2f1ba5ab7f0c8ea06ae93a6983f502f36683c21a8001ba`.

El flujo es lógicamente seguro para su uso documentado:

- verifica primero la integridad del paquete;
- la ejecución por defecto termina tras esa verificación, sin crear scratch;
- si se solicitan experimentos, valida runtime antes de cualquier copia;
- exige un scratch nuevo y exterior al paquete;
- copia runners, holdouts, inputs y binario extraído al scratch y dirige allí los outputs;
- usa `-I -B`, no instala paquetes, no modifica el wheel/kernel y no contiene operaciones de borrado;
- comprueba estados, mismatches y conteos congelados de T8, T9 y D6.

La dependencia externa declarada sigue siendo PowerShell más CPython 3.13 x64 con NumPy; el path Python es parametrizable. `platform.machine()` se registra informativamente en vez de imponerse como `AMD64`; una arquitectura incompatible falla de forma segura al importar el `.pyd`. Esto es una observación de portabilidad, no un defecto bloqueante.

## Paridad `MANIFEST` / `HASHES` / disco

**PASS independiente.** Se parseó el manifiesto y se recalcularon todos los SHA-256 sin invocar el script de reproducción:

- archivos físicos totales: **83**;
- payloads físicos, excluidos `MANIFEST.json` y `HASHES.sha256`: **81**;
- payloads declarados por el manifiesto: **81**;
- entradas de `manifest.files`: **81**;
- entradas en `HASHES.sha256`: **82** = 81 payloads + `MANIFEST.json`;
- bytes payload declarados, sumados desde entries y medidos en disco: **18,727,042** en los tres casos;
- líneas hash malformadas: **0**;
- rutas hash duplicadas/exteriores/ausentes: **0/0/0**;
- mismatches SHA-256 de la lista: **0**;
- diferencias manifiesto↔disco: **0**;
- diferencias lista de hashes↔conjunto esperado: **0**;
- mismatches SHA-256 o tamaño en entries del manifiesto: **0/0**;
- entregables requeridos ausentes: **0 de 12**.

Sellos del snapshot:

- `MANIFEST.json`: `c1a883b075cd7725ebc6c097548baa4ce7e083292a0a53578a8605d6aede79d9`;
- `HASHES.sha256`: `705ca823b4d6044c51fe46f1cb547500c7b772eb7da89e707a9f0ca0fe90ccd7`.

## Issues residuales por severidad

- **P0:** ninguno.
- **P1:** ninguno.
- **P2:** ninguno.
- **P3 / informativo:** el runtime probe informa `machine` pero no lo restringe a `AMD64`; la incompatibilidad real queda delegada al import del `.pyd`, que falla antes de ejecutar un runner. No afecta integridad, contención ni reproducibilidad en el runtime documentado.

## Checks ejecutados

1. Relectura dirigida y búsqueda global de formulaciones sobre `N>=5`, Moore, `t<N`, pre-DEMUX/XNOR/overflow y genealogía T8.
2. Comparación criptográfica de las tres copias de los teoremas corregidos.
3. Parseo estático de `REPRODUCE.ps1` y auditoría manual del flujo de paths, scratch, runtime y outputs.
4. Parseo de `MANIFEST.json` y `HASHES.sha256`, rehash 82/82, comparación de conjuntos y reconciliación de bytes contra disco.
5. Comprobación de presencia de los 12 entregables requeridos y lectura de `ANALYSIS/proof_review/RESOLUTION.md`.

No se ejecutó ninguna interrogación adicional del kernel porque esta re-QA era documental, criptográfica y operacional; repetir experimentos no podía cambiar el cierre de estos issues.
