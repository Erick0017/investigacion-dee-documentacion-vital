# Auditoría de los “períodos” de Part-D/D6

## Resultado

D6 no estableció recurrencia ni oscilación. Extrajo máximos de un periodograma FFT sobre series finitas detrendadas y con ventana Hann, y llamó `period` al inverso de la frecuencia discreta. En 19 mundos:

- 60 señales tuvieron picos;
- 300 picos fueron reportados;
- 56/60 señales seleccionaron exactamente, en orden, los bins 1,2,3,4,5;
- los bins 1–5 concentraron 284/300 picos;
- la desviación máxima entre el “período” reportado y un bin FFT entero fue `3.55e-15`;
- no hubo gate de autocorrelación, retorno de estado ni estabilidad de fase.

Los períodos dominantes de discovery (`4112,2056,1370.67,1028,822.4`) son `T,{T/2,...,T/5}` con `T=514×8=4112`. En holdout (`1552,776,517.33,388,310.4`) son la misma secuencia con `T=194×8=1552`. El cambio sigue la longitud de ventana, no una escala dinámica cross-N.

## Control negativo metodológico

Se reaplicó el extractor histórico exacto a tres señales conocidas no periódicas —cuadrática monótona, exponencial monótona y escalón único— con ambas longitudes. Las seis combinaciones devolvieron exactamente los mismos bins 1–5 y los mismos “períodos” `T/j` que dominan D6. El control no pretende modelar DEE; demuestra que el diagnóstico no separa oscilación de tendencia/no estacionariedad finita.

Las comparaciones “Fibonacci-like” eran explícitamente exploratorias. Sus fracciones nulas tienen mediana `0.114` y mínimo `0.016` entre 19 comparaciones, sin corrección de multiplicidad; no sustentan una ley Fibonacci.

## Adjudicación

- **Hecho computacional:** D6 calculó correctamente picos de bins FFT de sus series.
- **Resultado negativo del observable:** esos picos no identifican períodos físicos o nativos sin recurrencia, fase estable y escalamiento de ventana.
- **No descartado:** una serie concreta podría contener oscilación; D6 por sí solo no lo decide.
- **No reinterpretar:** Part-D ya decía que no promovía automáticamente una forma natural. Esta auditoría restringe la lectura posterior; no cambia el resultado preregistrado.

Evidencia reproducible: `d6_period_bin_audit.json`, `d6_peak_bins.csv` y `RUNNERS_NEW/audit_d6_period_bins.py`. Fuente reutilizada SHA-256 `7339604363069f6a9a1522b0841cab0e294f2544a9090f25a647147de0eac1e9`; no se reejecutó la campaña.
