# Revisión matemática adversarial de `EXACT_PROOFS.md`

## Alcance y sello de lo auditado

Revisión sólo de lectura, sin ejecutar probes ni sweeps. Se contrastó la versión de `EXACT_PROOFS.md` con SHA-256
`da840527c87930eee7850960507d7c12501ab794815b45b03f507c28faef45f9` contra:

- fuente C++ sellada `dee_kernel_v27.cpp`, SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`;
- `t8_result.json`, SHA-256 `eb4a74b63afe714b6efedee94e318ace82fadd03763eac0c0e00ab60d37c0e92`;
- `t9_result.json`, SHA-256 `bbc14a60d254d83829680509d1b38185abfa57628b2ef041affb3b6ed801069f`.

Los dos JSON declaran `PASS` y cero mismatches. T8 registra 1,872 trayectorias primarias, 50,544 ticks primarios, 624 comparaciones de variantes, 12 casos de dos cuerpos y 1,300 colisiones. T9 registra 936 casos factoriales, 208 comparaciones de motores, 18 controles y 12,782 ticks. Esos números concuerdan con los resúmenes y los loops de los runners, pero siguen siendo evidencia finita; la universalidad procede de la prueba por ramas, no del conteo experimental.

## Veredicto compacto

| Enunciado | Veredicto | Motivo principal |
|---|---|---|
| E1 | **ISSUE** | La recurrencia del clock es correcta, pero el dominio declarado no excluye alias entre los cuatro buffers ni exige explícitamente `N>=1`; sin ello `F(g,c)` no queda matemáticamente bien definido por la implementación. |
| E2 | **PASS** | Los cuatro períodos causalmente activos y su LCM 304,980 son correctos, con alcance de prefijo sin cruce del corte modular. |
| E3 | **PASS** | La manta raw de radio 3 es correcta y el testigo binario la hace aguda para tamaños suficientemente grandes. |
| E4 | **PASS** | Traslación y equivalencia dense/lazy se siguen de la estructura del scan, bajo el dominio corregido de buffers. |
| E5 | **PASS** | La cota exacta usada, `15*65535`, es válida y deja la rama de cristalización inalcanzable. |
| E6 | **ISSUE** | La condición dada describe la salida base de `actualizar_voxel`, no la supervivencia final después de `aplicar_demux`; un delta entrante puede resucitar un sitio cuya regla base dio cero. |
| E7 | **PASS** | El testigo prueba no-inyectividad; basta fijar, por ejemplo, `N>=3` para que la salida descrita sea exactamente raw cero. |
| E8 | **PASS** | Los observers son fijos, no se crean por `F`, y generan la familia declarada de invariantes de rango cero. |
| E9 | **PASS** | El sector singleton y su dispersión de traslación se deducen exactamente de las ramas y concuerdan con T8. |
| E10 | **ISSUE** | La idea es correcta, pero “geometría que impida…” no define un subespacio matemático. Debe sustituirse por una condición cerrada y verificable, por ejemplo separación Chebyshev por pares al menos 3. |
| E11 | **ISSUE** | El álgebra sólo rige si el blanco raw-cero no satisface XNOR. Sin esa hipótesis, XNOR tiene precedencia y reemplaza el supuesto producto por `(1,1,0,0,0,SEM_NACIDO_XNOR)`. |
| E12 | **ISSUE** | La bomba exacta requiere que `d` sea una de las 26 direcciones Moore y un intervalo preciso `1<=t<N`; “direccional” sin esa restricción incluye direcciones codificables que no emiten. |
| E13 | **PASS** | La familia densa es raw-fija como se afirma; no debe llamarse “atractor” sin probar una cuenca. |
| E14 | **PASS** | Se prueba el subgrupo de traslaciones y se refuta `O_h` global. No se determina el grupo global completo. |
| E15 | **PASS** | `B_3(y)` para raw y `B_1(y)` para clocks son suficientes en un tick; occupancy no es suficiente. |

Resultado: diez enunciados pasan en sustancia y cinco necesitan una corrección de dominio o formulación. Ningún issue refuta E5, E8, E9 ni los resultados finitos T8/T9.

## Precondición global que debe incorporarse

El encabezado exige dtype, contigüidad, escritura y longitud, pero no basta. La implementación escribe en `gB`/`clkB` durante el scan y luego hace `memcpy` hacia `gA`/`clkA` (líneas 451–500; análogo lazy en 567–667). Si dos buffers se solapan, las lecturas sincrónicas pueden ser sobrescritas durante el tick, aparecen carreras con múltiples hilos y un solapamiento parcial viola el contrato de `memcpy`. Debe declararse:

> `N` es entero positivo; los cuatro arrays son buffers `uint64` C-contiguos, escribibles, de longitud al menos `N^3`, y sus regiones de memoria relevantes son disjuntas entre sí. Para dense, `n_hilos>=1`. El producto `N^3` y el indexado caben en los tipos empleados.

Si el objeto matemático se define independientemente de llamadas ABI inválidas, puede decirse que los teoremas conciernen al mapa sincrónico abstracto implementado por una invocación válida con buffers separados. Esta corrección resuelve el issue de E1 y es una precondición de E4 y del resto de los enunciados operacionales.

## Auditoría por enunciado

### E1 — ISSUE

La parte dinámica es exacta: la salida temprana observer escribe `tick+1` (línea 247), todas las demás salidas locales también lo hacen (305, 312, 320, 326, 331, 346 y 421), y lazy prellena cada clock con `+1ULL` (589–591). `aplicar_demux` no recibe clocks. La resta modular de dos clocks es por tanto invariante.

El defecto está sólo en el dominio: con buffers aliasados no se implementa necesariamente ese mapa sincrónico. Añadir la precondición global anterior. También conviene escribir la suma como igualdad en `Z/2^64`, pues en C++ el overflow de `uint64_t` ya realiza exactamente esa operación.

### E2 — PASS

Después de `rule_value==0`, el único uso causal del clock es el gate de líneas 355–363. Los valores supervivientes posibles con `anclajes_faltantes>0` son:

- `n=4`: `782/4=195`, sólo con tetra;
- `n=5`: `782/3=260`, sólo con tetra;
- `n=6`: `782/2=391`;
- `n=7`: `782/1=782`, siempre que no haya write-protection.

Su LCM es 304,980. Los períodos sintácticos para `n<=3` están detrás del retorno por `rule_value==0`; para `n>=8` el gate no se ejecuta. Los testigos registrados para cada gate distinguen residuo cero de no cero, de modo que un período universal debe ser múltiplo de los cuatro. La suficiencia se propaga por inducción mientras ambos levantamientos enteros de clocks permanecen sin wrap.

Corrección editorial: reemplazar “deja toda trayectoria raw idéntica” por “deja idéntico todo prefijo pareado durante el cual ni el clock original ni el desplazado cruza el corte `2^64-1 -> 0`”. No existe una simetría global modular por ese desplazamiento, porque 304,980 no divide `2^64`.

### E3 — PASS

La actualización base en `y` lee como máximo radio 2 cuando evalúa candidatos de overflow. Un delta entrante a `y` sólo puede proceder de un emisor `x` Moore-adyacente; ese emisor consulta el grado de un candidato `z=x+d` leyendo `z+e`, por lo que `z+e-y=d+e-d_*` y la norma Chebyshev es a lo sumo 3 (líneas 371–406). No hay cascada de deltas dentro del tick: todos se aplican después del scan (498 o 664).

El testigo de distancia 3 hace la cota aguda para el `N` ensayado, no para todo `N` pequeño cuyo diámetro toroidal sea menor que 3. Conviene expresar la cota como `min(3t,diametro_infty(Z_N^3))` y la agudeza como existencia para tamaños suficientemente grandes.

### E4 — PASS

Los accesos son offsets relativos sometidos a `wrap`; una traslación no altera el orden lexicográfico de los offsets. Fuera del halo de un raw no cero, dense sólo puede producir raw cero y clock incrementado, que es exactamente el prefill lazy. Cualquier emisor de overflow es raw no cero y su blanco es Moore, luego ambos están en el conjunto de trabajo lazy. Las escrituras no-delta son por índice único y los joins de overflow son `fetch_add`, con reducción final independiente del orden.

Los 980 checks citados sí se reconstruyen: 624 comparaciones T8 de motores, 148 comparaciones T8 del subconjunto de colisiones y 208 comparaciones T9. Son comprobaciones consistentes, no la razón de universalidad. Añadir “para invocaciones válidas con buffers disjuntos” por la precondición global.

### E5 — PASS

Para cualquier vector de signos `sigma`, maximizar `sigma·g` sobre las 26 cargas independientes selecciona los coeficientes positivos de `-sigma·d`. En un octante su suma es `3*1 + 2*3 + 1*6 = 15`; por dualidad de la norma L1,

`||g||_1 <= 15*65535 = 983025`.

La división entera jamás alcanza 966 porque `19665*966=18996390` y aun `983025/19665=49`. La conclusión de inalcanzabilidad es correcta. La frase “toda genesis procede de XNOR” debe precisar “todo incremento del contador de telemetría `genesis_count`”; los nacimientos por routing direccional existen pero deliberadamente no incrementan ese contador (317–321).

### E6 — ISSUE

El cálculo de la regla base es correcto. Sin tetra, `floor(2.5*n/26+0.5)` cambia en `n=6,16,26`; con tetra e `n<7`, los resultados para 4, 5 y 6 son 2, 3 y 4. XNOR se evalúa antes que el reducer direccional.

No obstante, “sobrevive exactamente si” es falso para la salida final `gB` de `F`. Después de que `actualizar_voxel` produzca cero por `rule_value==0`, un emisor vecino con overflow puede sumar un delta al índice. `aplicar_demux` convierte cualquier salida base con estado cero en `(state=1,s_reg=0,d=0,semantic=1)` (líneas 427–444), o reescribe un orphan como `TTL_ORFAN`. Por tanto la equivalencia sólo caracteriza la **supervivencia base antes de deltas entrantes**.

Corrección concreta:

> Para un sitio central no observer y con `state>0`, la salida base de `actualizar_voxel`, antes de `aplicar_demux`, tiene estado no cero exactamente bajo la condición indicada. La salida final también puede ser no cero por un delta overflow entrante.

En el párrafo de vacíos, sustituir “salvo que una fuente direccional sea evaluada después” por “si XNOR es falso, se evalúa después la fuente direccional”; XNOR nunca cede precedencia.

### E7 — PASS

Con un toro ordinario, por ejemplo `N=5`, un singleton normal sin dirección ni `s_reg`, state 1 o state 2, tiene `n=0`, retorna por `rule_value==0`, no emite y no provoca XNOR. Las dos preimágenes distintas producen el mismo raw cero y clocks iguales incrementados. Eso basta para no-inyectividad.

Corrección de dominio menor: fijar explícitamente `N>=3` (o simplemente `N=5`) para justificar la descripción “raw cero”. En toros degenerados los offsets se aliasan y esa descripción particular no se sigue, aunque la existencia de un testigo en `N=5` ya prueba el resultado para la instancia usada.

### E8 — PASS

La copia temprana observer y el skip de DEMUX (247 y 431–434) fijan cada raw semantic 4. XNOR escribe 7, routing escribe 1 y la regla material preserva la semántica central salvo `0->1`. La única ruta de herencia vecinal que podría escribir 4 es la cristalización, excluida por E5. Así, para cualquier `f` con valores en un grupo aditivo bien definido, la suma indicada es invariante.

Precisar que “no se crean” se refiere a iteraciones de `F`; las funciones externas de inyección o la escritura directa de buffers no forman parte del teorema.

### E9 — PASS

Para `N>=5` no hay alias geométrico problemático. El singleton fuente muere por `n=0`; exactamente el blanco `q+d` lo encuentra como única fuente, y las líneas 317–321 normalizan state/semantic preservando `s_reg` y dirección. Ningún otro sitio cumple XNOR ni encuentra la fuente. La inducción y el orden aditivo `N` de cualquier `d` Moore no nulo dan el ciclo raw. El signo de la fase de Fourier coincide con la convención declarada.

T8 aporta un holdout v27 amplio y sin mismatches. Históricamente `TORUS_MOVING` v25 ya contenía el caso particular `state=1,s_reg=0,d=(1,0,0)`; por tanto T8 debe describirse como formalización y generalización/confirmación exhaustiva en v27, no como primera aparición histórica del movimiento.

### E10 — ISSUE

La conclusión es cierta, pero el dominio “cuya geometría impida vecindad, XNOR y colisión” es circular: define el sector por la ausencia de los efectos que se quieren excluir y no da un predicado comprobable.

Una versión exacta suficiente es:

> Fije `N` y una dirección Moore no nula `d`. Considere configuraciones finitas de raws `(state=1,semantic=1,direction=d)` cuyas posiciones tengan distancia Chebyshev toroidal por pares al menos 3. Entonces cada bola Moore contiene a lo sumo un portador; no puede activarse XNOR, no hay supervivencia local ni colisión, y la configuración se traslada rígidamente por `d`. La separación se conserva porque todos reciben la misma traslación.

Ese conjunto sí es cerrado e invariante, y la traslación restringida es una permutación. El Koopman asociado es unitario en `L2` para una medida invariante sobre ese conjunto finito. T8 comprobó sólo 12 recorridos con separación 5; no “confirma” experimentalmente todas las geometrías del teorema.

### E11 — ISSUE

`buscar_fuente_demux` implementa exactamente suma con cap y `sign` para `count>1` (líneas 187–225), pero sólo se llama en la regla del vacío **después** de XNOR (310–321). Así, “si `k>1` fuentes apuntan al mismo vacío, el producto tiene…” no es universal: ocho o más vecinos activos colocados en pares antipodales pueden satisfacer XNOR y la función retorna antes con semantic 7, `s_reg=1` y dirección cero.

Corrección concreta:

> Sea el blanco raw exactamente cero, no observer, y supóngase falso `verificar_genesis_xnor` en su vecindad. Si `k>1` entradas del scan Moore apuntan al blanco, entonces el producto tiene la forma declarada.

Para dos singletons aislados distintos en `N>=3`, las condiciones adicionales se satisfacen automáticamente porque sólo hay dos vecinos activos; en ese dominio, el segundo-tick “muere si `d_out=0`, si no entra en E9” y los 1,300 casos T8 son válidos. No extrapolar ese panel de dos fuentes a colisiones inmersas en un fondo activo.

### E12 — ISSUE

La copia fija del observer es universal, pero la emisión no lo es para toda dirección no cero codificable. Los getters aceptan componentes en `[-8,7]`; `buscar_fuente_demux` sólo inspecciona las 26 celdas Moore del blanco. Por ejemplo una fuente con dirección `(2,0,0)` no está en la vecindad Moore de `q+(2,0,0)` y no emite en el aparato aislado. El prerregistro T9 sí restringe correctamente a “dirección Moore no nula”, pero E12 perdió esa condición.

Corrección concreta:

> Para `N>=11`, un único observer en `q` con `d in {-1,0,1}^3\{0}` produce, para `1<=t<N`, exactamente los descendientes normales `q+k d` con `1<=k<=t` y `k congruente t (mod 2)`; el observer no se cuenta entre ellos.

El intervalo `t<N` reemplaza “antes del cierre toroidal” por una condición auditable. T9 prueba exactamente ese dominio (`N=11,13`, horizonte `N-1`) y no direcciones fuera de Moore. El control `d=0` es correcto.

### E13 — PASS

Con ocupación total, todos los vecinos computados están vivos y `n=26`; `rule_value=3`. La suma direccional es cero, luego hay write-protection y no se incrementa `s_reg`. Aun si `s_reg>=19665`, cada candidato tiene grado 26 y ninguno es abierto, de modo que no se genera delta. Las semánticas enumeradas se preservan y la dirección propia cero evita el anclaje por gradiente. La familia es raw-fija para cualquier clock.

Corrección terminológica: un punto fijo no es automáticamente un atractor. Reemplazar “familia macroscópica de atractores/fibras fijas” por “familia macroscópica de puntos/fibras raw fijos”; una cuenca atractora o estabilidad ante huecos requiere prueba separada.

### E14 — PASS

La equivariancia por `Z_N^3` es exacta. La elección de candidato overflow usa el primer mínimo de la tabla ordenada y sólo reemplaza con `<` estricto (371–399); el testigo de inversión simétrica con salida asimétrica basta para excluir el grupo cúbico completo como simetría global. La regla singleton/reducer, sin overflow, sí conmuta con permutaciones y cambios de signo coordinados de posición/dirección.

Corrección editorial: el título no debe sugerir que se determinó el grupo global completo. Lo probado es “subgrupo exacto de traslaciones y obstrucción a `O_h`”. Podrían existir otras simetrías globales no adjudicadas por este argumento.

### E15 — PASS

La unión de lecturas raw necesarias para deltas entrantes es `B_3(y)` por el razonamiento de E3. El único clock leído por una actualización base es el del sitio actualizado; para un delta que llega a `y`, el clock relevante puede ser el de un emisor `x in B_1(y)`. Por ello las mantas declaradas son suficientes, aunque no se afirma minimalidad.

El contraejemplo de occupancy es correcto al fijar `N>=3` y una dirección Moore no nula: raw cero y raw con `state=0` pero dirección codificada tienen occupancy inicial idéntico, y sólo el segundo crea occupancy en `q+d`. Para predecir el **estado completo**, el clock íntegro sigue siendo necesario; el cociente de fase sólo sustituye clocks cuando el objetivo es la dinámica raw dentro del alcance sin-wrap de E2.

## Correcciones prioritarias antes de promover el documento

1. Añadir la precondición global de `N`, tamaño, contigüidad, escritura y no solapamiento de los cuatro buffers.
2. Renombrar E6 como regla **base pre-DEMUX** y retirar la equivalencia de supervivencia final.
3. Formalizar E10 con un predicado invariante, idealmente separación toroidal por pares `>=3`.
4. Condicionar E11 a blanco raw-cero y XNOR falso; conservar el teorema incondicional sólo para el aparato aislado de dos fuentes.
5. Restaurar en E12 la restricción de dirección Moore y escribir explícitamente `1<=t<N`.
6. Sustituir “atractores” por “puntos fijos” en E13 y evitar que el título de E14 sugiera una clasificación completa del grupo.

Con esas correcciones, el núcleo matemático queda internamente consistente con la fuente sellada y con los dominios efectivamente probados por T8/T9.
