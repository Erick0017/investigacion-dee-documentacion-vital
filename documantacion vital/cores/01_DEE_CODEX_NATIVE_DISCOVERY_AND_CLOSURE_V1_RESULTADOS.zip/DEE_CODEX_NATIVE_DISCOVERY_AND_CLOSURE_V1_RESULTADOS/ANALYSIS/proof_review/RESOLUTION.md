# Resolución de la revisión adversarial

`ADVERSARIAL_REVIEW.md` conserva deliberadamente la auditoría del borrador con SHA-256 `da840527...` y sus cinco `ISSUE`. No describe el estado pendiente del teorema promovido.

Las correcciones se aplicaron antes del paquete final:

- dominio ABI: `N` positivo, tamaños/indexado válidos y cuatro regiones de buffers disjuntas;
- E6: salida base antes de DEMUX, no equivalencia universal de supervivencia final;
- E10: `N>=5`, dirección Moore común y separación Chebyshev toroidal por pares `>=3`;
- E11: blanco raw-cero, XNOR falso y distinción entre salida base y delta overflow posterior;
- E12: `N>=5`, dirección Moore no nula y fórmula sólo para `1<=t<N`;
- E3/E5/E7/E9/E13/E14: caveats de diámetro, contador `genesis_count`, tamaño, linaje, puntos fijos y alcance de grupo.

El documento corregido es `EXACT_THEOREMS.md`, idéntico a `ANALYSIS/native_theory/EXACT_PROOFS.md`, SHA-256 `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.
