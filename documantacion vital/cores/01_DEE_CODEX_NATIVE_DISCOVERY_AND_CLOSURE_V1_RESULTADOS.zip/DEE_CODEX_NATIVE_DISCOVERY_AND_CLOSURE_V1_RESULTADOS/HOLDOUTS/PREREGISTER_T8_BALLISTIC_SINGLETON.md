# T8 — Prerregistro de transporte balístico singleton y colisiones direccionales

Estado: **CONGELADO ANTES DE EJECUTAR EL HOLDOUT BINARIO**  
Fecha de congelación: 2026-09-11T15:44:19-06:00  
Kernel objetivo: wheel local `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl`  
SHA-256 del wheel: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`

## Procedencia y separación discovery/confirmación

La hipótesis se obtuvo post-hoc por inspección estática de la fuente C++ sellada incluida en el wheel, especialmente `buscar_fuente_demux` y las ramas de vacío/materia. Antes de este sello no se ejecutó una trayectoria binaria diseñada para comprobar el transporte singleton. La inspección de fuente pertenece a **discovery**; el panel definido abajo es el **holdout confirmatorio**. No se cambiarán fórmula, casos ni criterios tras observar sus resultados.

## Definiciones congeladas

Sea el espacio un toro cúbico `Z_N^3`. Un raw se decodifica como `(state,s_reg,dx,dy,dz,semantic)`. Definimos un **singleton T8** como un único sitio no vacío `q` con:

- `semantic = SEM_NORMAL = 1`;
- `state > 0`;
- `d=(dx,dy,dz) in {-1,0,1}^3 \ {(0,0,0)}`;
- `s_reg in [0,65535]`;
- todos los demás raw exactamente cero.

La convención de Fourier será

`rho_hat(m,t) = sum_x rho(x,t) exp(-2*pi*i*(m dot x)/N)`,

donde `rho=1[state>0]`.

## Hipótesis primarias

### H8.1 — sector de traslación exacta

Para `state=1`, todo `N>=5`, todo singleton T8 y todo campo inicial de clocks:

`raw_t(x) = raw_0(x-t*d)` para todo `t>=0`, con índices módulo `N`.

Equivalente: hay exactamente un raw no nulo en `q_t=q_0+t*d`, y conserva exactamente `(state=1,s_reg,d,semantic=1)`.

### H8.2 — normalización de estado

Para el mismo aparato con cualquier `state in [1,2^32-1]`, después de un tick el móvil entra en H8.1 con `state=1`; conserva exactamente `s_reg` y `d`, y la semántica de salida es 1.

### H8.3 — ciclo raw y dispersión

Para `state=1`, el raw completo retorna exactamente tras `N` ticks. Para cada modo probado con amplitud no nula:

`rho_hat(m,t+1)/rho_hat(m,t) = exp(-2*pi*i*(m dot d)/N)`.

### H8.4 — independencia de implementación y clock

H8.1–H8.3 deben coincidir bit a bit entre `tick_universo` y `tick_universo_lazy`, entre 1 y 2 hilos, y para clocks uniformes, heterogéneos y próximos al wrap. Los clocks deben satisfacer únicamente `clock_t=clock_0+t mod 2^64`; no se afirma periodicidad del estado completo en `N` ticks.

### H8.5 — dos móviles no interactuantes

Dos singletons con la misma dirección y separación toroidal Chebyshev al menos 4, elegidos de modo que esa separación se mantenga sin ambigüedad de imagen periódica, se trasladan conjuntamente sin cambiar sus raws durante el horizonte congelado.

### H8.6 — álgebra de colisión de dos fuentes

Para dos singletons distintos situados en `q-d1` y `q-d2`, con `d1 != d2`, ambos apuntando al mismo vacío `q`, el primer tick deja un único raw en `q` con:

- `state=1`, `semantic=1`;
- `s_reg=min(s1+s2,19664)`;
- dirección `sign(d1+d2)` componente a componente.

Si la dirección resultante es cero, ese raw desaparece al tick siguiente. Si no es cero, desde el tick siguiente satisface H8.1 con la carga agregada.

## Panel holdout congelado

1. Todas las 26 direcciones, `N in {11,13}`, posiciones obtenidas de la semilla fija `T8_SEED=270819665`, `state in {1,2,4294967295}`, `s_reg in {0,1,19664,65535}` y horizonte `2*N+3`.
2. Clocks: cero; patrón determinista heterogéneo; y patrón con valores en `{2^64-3,2^64-2,2^64-1}`. El raw esperado no depende del patrón.
3. Motores denso/lazy, `n_hilos in {1,2}`; comparación de buffers raw y clock en cada tick.
4. Fourier: en cada dirección se prueban `m in {(1,0,0),(0,1,0),(0,0,1),(1,2,3)}` durante `N+1` ticks, omitiendo únicamente un cociente si el denominador numérico fuese cero.
5. Dos móviles: casos deterministas de eje, diagonal y tridimensional en `N=17`, separación Chebyshev inicial 5, horizonte 23.
6. Colisiones: todos los pares no ordenados de direcciones distintas entre las 26, en `N=11`, con cargas `(0,0)`, `(1,2)`, `(19664,1)` y `(65535,65535)`, dos ticks.

El runner debe registrar la posición, inputs, hashes de buffers y todo mismatch. Se permite reducir duplicados de ejecución sólo si se conserva cobertura lógica idéntica y se documenta la reducción antes de leer resultados.

## Criterio de adjudicación

- **PASS exacto:** cero mismatches en cada hipótesis primaria correspondiente y concordancia con la prueba estática.
- **FAIL:** cualquier mismatch reproducible; se conserva sin refit.
- **ERROR_TÉCNICO:** el binario/importación no coincide con los hashes sellados o el runner no termina; no se interpreta como evidencia científica.

Un PASS confirma que el `.pyd` sellado implementa el sector descrito en el panel. La universalidad matemática para todo `N`, clock y horizonte sólo se promoverá a teorema si además se presenta una prueba exhaustiva por ramas del código fuente. El resultado no autoriza identificar `direction` con momentum, `s_reg` con energía ni el móvil con materia física externa.

## Predicciones secundarias no usadas para aprobar H8

- El sector H8.1 es una permutación/restricción reversible aunque `F_DEE` global sea no inyectiva.
- Sus 26 velocidades constituyen modos colectivos de transporte exactos y su espectro obedece una relación de dispersión de advección sobre el toro.
- Las colisiones son conmutativas en sus fuentes pero generalmente inelásticas respecto al número de soportes; no conservan en general la suma vectorial después de aplicar `sign`.

Estas predicciones sólo se informarán con el alcance probado y no se usarán para reformular retroactivamente las hipótesis primarias.
