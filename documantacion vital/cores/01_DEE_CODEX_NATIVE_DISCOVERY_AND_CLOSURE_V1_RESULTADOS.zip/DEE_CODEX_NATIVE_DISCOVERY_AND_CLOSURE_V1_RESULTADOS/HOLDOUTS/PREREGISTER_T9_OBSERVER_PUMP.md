# T9 — Prerregistro de invariancia y emisión del `SEM_OBSERVER`

Estado: **CONGELADO ANTES DE EJECUTAR EL HOLDOUT BINARIO**  
Fecha: 2026-09-11  
Wheel SHA-256: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`

## Discovery previo

La fuente sellada muestra dos operaciones distintas: `actualizar_voxel` retorna inmediatamente y preserva todo raw cuyo semantic sea 4; `aplicar_demux` también rehúsa modificarlo. A la vez, `buscar_fuente_demux` no excluye semantic 4 ni exige `state>0`: un observer direccional puede actuar como fuente persistente. No se ha ejecutado aún un aparato binario diseñado para esta predicción.

## Predicciones congeladas

En un toro `N>=11`, coloque en `q` un único raw semantic 4 con dirección Moore no nula `d`, `s_reg=s` y cualquier `state` admisible; todo otro raw es cero.

1. El raw en `q` permanece bit a bit invariante para todo tick.
2. Antes del primer cierre toroidal (`1 <= t < N`), los raws normales emitidos ocupan exactamente `q+k*d (mod N)` para `1<=k<=t` y `k mod 2 = t mod 2`.
3. Cada emitido tiene `(state=1,s_reg=s,direction=d,semantic=1)`.
4. El número de emitidos es `ceil(t/2)`.
5. Las mismas salidas raw y clock se obtienen en dense/lazy y 1/2 hilos; clocks avanzan `+1 mod 2^64`.
6. Con dirección cero, el observer permanece fijo y no genera ningún raw adicional en este aparato.

Panel: las 26 direcciones; `N in {11,13}`; `state in {0,1,4294967295}`; `s in {0,19664,65535}`; clocks cero y near-wrap; horizonte `N-1`. El factorial principal se ejecuta lazy/1; todas las direcciones y ambos N se comparan entre los cuatro caminos en `state=0,s=65535,near-wrap`. Se incluyen controles direction=0.

Criterio: cero mismatches = PASS; cualquier mismatch reproducible = FAIL sin refit. La promoción a teorema universal exige también prueba por ramas. Incluso con PASS, `observer` se interpretará operacionalmente como sitio fijado/boundary-source, no como observador físico o medición.
