# Plan de ejecución T8 sellado antes de resultados

Fecha: 2026-09-11T15:44:19-06:00  
Prerregistro: `PREREGISTER_T8_BALLISTIC_SINGLETON.md`  
SHA-256 del prerregistro: `0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb`

## Reducción de duplicados declarada antes de ejecutar

El panel literal completamente factorial cruzaría parámetros que no son leídos por las mismas ramas y repetiría decenas de miles de recorridos densos. Se congela esta reducción, autorizada por el prerregistro, antes de observar resultados:

1. El factorial completo dirección × N × estado × s_reg × patrón de clock se ejecutará con `tick_universo_lazy(...,1)`, conservando todos los niveles, interacciones y horizontes `2N+3` de H8.1–H8.3.
2. La equivalencia denso/lazy y 1/2 hilos se comprobará bit a bit en las 26 direcciones, ambos N y los tres patrones de clock, con un horizonte corto de cuatro ticks, además de recorridos completos representativos de cada N. La fuente muestra que los cuatro caminos llaman a `actualizar_voxel`; este panel discrimina divergencias de scan/particionado sin repetir parámetros que esa lógica no consulta.
3. Fourier se calcula sobre una trayectoria real por dirección y N; variar estado/s_reg/clock no altera `rho` según la hipótesis y ya queda cubierto por el factorial raw.
4. Las 1,300 colisiones (325 pares no ordenados × cuatro pares de cargas) se ejecutarán en lazy/1 hilo. Un subconjunto determinista de al menos 16 colisiones, incluyendo suma cero, saturación y salida diagonal, se repite en los cuatro caminos de ejecución.
5. Los tres casos de dos móviles se repiten en los cuatro caminos durante el horizonte completo.

Esta reducción no cambia fórmulas, tolerancias ni criterios. Todo mismatch se registra y provoca FAIL de la hipótesis correspondiente.
