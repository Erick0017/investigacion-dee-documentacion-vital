# Resultados negativos y su dominio

## Negativos exactos sobre `F_DEE` v27

| Negativo | Alcance demostrado | No implica |
|---|---|---|
| La cristalización por gradiente nunca se alcanza | Todo raw válido: máximo `grad_mag=983,025`, requisito `18,996,390` | Que XNOR/routing no puedan crear soporte |
| El cono raw no es radio 1 | Testigo exacto alcanza radio 3; cota universal ≤3/tick | No localidad o señal instantánea |
| `F` no es inyectiva | Dos preimágenes state 1/2 colisionan en un tick | Irreversibilidad de cada sector; T8 es permutacional |
| `O_h` no es simetría global | Testigo de empate overflow rompe inversión | Ausencia de simetría cúbica en sectores sin tie |
| Occupancy no es causalmente suficiente | `state=0` direccional puede crear soporte; clock puede cambiar `s_reg` | Que occupancy sea inútil como coarse-graining contextual |
| `s_reg` no es masa/momentum en T8 | Velocidad libre y composición direccional son independientes de su magnitud | Imposibilidad de otra masa colectiva en otro sector |
| No hay gauge global de clock con L | Full-state cambia y wrap rompe la acción | Inutilidad del cociente raw sin wrap |

## Negativos científicos históricos, acotados al aparato

| Campaña | Resultado | Dominio correcto |
|---|---|---|
| Part-C/C7 | 9/9 `no_resolved_group_mode` | Los nueve paquetes/preparaciones y detector de group velocity usados |
| V6-D | `no_resolved_packet_in_screen`; `physical_Rosetta_validated=false` | Cuatro protocolos discovery y gates congelados; `selected=null` |
| V6-F | Familia de transferencia completa negativa | Pasan soporte causal/dirección/corredor; fallan decodificación ciega, repertorio y robustez |
| V7-A | `C_SIMPLE_RELATION_NOT_SUPPORTED_IN_DOMAIN`; cero clusters matter-like | Regímenes y gate compuesto ensayados, no toda definición posible de materia |
| V7-B | `C_SIMPLE_CHAIN_REJECTED_OR_NOT_RESOLVED_IN_DOMAIN` | Cadena simple congelada; el lector de cociente sí transfiere 24/24 |
| V6-C | 64/64 contrajemplos a cierre M0 | Estados/observadores muestreados; otros modelos sin fibras iguales quedan inconclusos |
| V6-E | M0/M1: 24/24 fibras iguales divergen; Rosetta externa falsa | Los cierres y observadores congelados; M2/M3 no tuvieron pares para decidir |
| Part-D/D6 | Picos dominados por escala de ventana | El periodograma usado; no prueba ausencia de toda oscilación |
| Part-E2 | `MEASUREMENTS_PENDING_INTERPRETATION` | Atlas/recurso internos; no equivalencia de energía ni capacidad infinita |
| Formula Bridge | Clásica/GR/hidro no identificables; SR parcial; QM/termo formales | Reanálisis de formas objetivo, no teorema de imposibilidad física |

T8 proporciona un contraejemplo a cualquier lectura universal de los dos primeros negativos de modos/paquetes: sí existe un modo de transporte exacto, pero no era el objeto resuelto por esos aparatos. El resultado histórico permanece FAIL para sus gates.

## Búsquedas de conservación

F-114/F-150 y A5 no hallaron una energía/carga útil en sus bancos. A5 generó 19 candidatos dominados por identidades de empaquetado o contabilidad semántica. Esos resultados no cubren todas las funciones de vecindad de raw 64-bit ni invariantes de sector, y T4 queda refutado en full-state por observer.

El veredicto correcto es:

- existe una familia exacta de invariantes rango 0 sobre observer;
- existen invariantes y continuidad en el sector balístico;
- no se ha identificado una carga extensiva energy-like que gobierne la dinámica general no-observer;
- no existe un teorema de ausencia para todas las cargas rango 1–2, relacionales o de coarse-graining.

## Fallos técnicos — no son negativos científicos

- Refoundation-A/A6: linker MSVC `LNK1104`.
- Replay-A/A6: `PermissionError` al limpiar un `.pyd` cargado.
- Part-C/C4: proceso hijo sin `setuptools`.
- Primer C4 de V7-C: solapamiento de fuente; se aplicó hotfix conservado en el rastro.
- V6-A: presupuesto temporal; ZIP `paused`, WORK posterior `running`.
- V7-B nominal WORK: `NameError read_state`; la ejecución corregida final está en `tests/RESULTS`/ZIP.

No se usó ninguno para afirmar ausencia de un mecanismo.

## Afirmaciones externas no validadas

No hay PASS cuantitativo externo para:

- masa/inercia física;
- equivalencia materia–geometría;
- energía, temperatura o termodinámica;
- límite hidrodinámico/Navier–Stokes;
- relatividad de Lorentz o gravedad de Einstein;
- mecánica cuántica/Born/Bell;
- gauge/campos dinámicos;
- 20 Hz u otras conversiones SI;
- alpha/relaciones de masa como predicciones independientes.

“No validado/no identificable” no significa refutado ontológicamente. Significa que faltan objetos operacionales o datos que el kernel solo no suministra.

## Sesgos de observable identificados

- `state>0` omite raws direccionales causales con state 0.
- El clock absoluto mezcla fase rígida con historia; el cociente puede ser más apropiado, con caveat de wrap.
- Mejor predicción desde raw/clock profundo que desde visible indica información omitida, no materia.
- Traslación impuesta de patrones en V7-B no es movilidad espontánea.
- Picos FFT `T/j` no son recurrencia.
- Isotropía de covarianza, modo angular o twist no autorizan nombres geométricos físicos.
- Causalidad de first-passage en un aparato no es una métrica relativista.
