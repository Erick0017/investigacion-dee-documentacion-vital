# Huecos externos y preguntas no identificables

## Pieza central faltante bajo `H_DEE`

La pieza exacta es una **Rosetta operacional congelada** que especifique, antes de mirar resultados físicos:

1. qué distribución/ensemble de estados DEE representa preparaciones reales;
2. qué coarse-graining de `(raw,clock)` es causalmente suficiente;
3. qué funciones producen resultados de medición y probabilidades;
4. qué mapa único asigna voxel/tick/cargas internas a unidades físicas;
5. qué parámetros se calibran una vez y cuáles son predicciones;
6. qué holdouts externos independientes la falsan.

Sin esto, ninguna ejecución interna puede identificar qué mundo es nuestro vacío, qué observador corresponde a un laboratorio o qué número interno equivale a metro, segundo, joule, kilogramo o `hbar`.

## Requisitos concretos por sector

### Espaciotiempo y relatividad

Faltan un régimen de baja energía/longitud grande, transformaciones entre observadores, intervalo efectivo, isotropización cuantificada del tie DEMUX y dispersión que converja a una estructura Lorentziana. La cota causal discreta y first-passage de V7-C no bastan.

### Materia, masa e inercia

T8 da una clase móvil y `q`, pero falta una familia estable e interactuante con intervención force-like definida sin usar la respuesta, aceleración reproducible y parámetro inercial que prediga colisiones/propagación cross-N. Para materia–geometría hacen falta `M_I` y `M_G` medidos independientemente en las mismas clases, seguidos de una relación congelada.

### Gravedad/geometría dinámica

Falta un campo geométrico colectivo que tenga dinámica propia, equivalencia entre su efecto y una conexión/métrica efectiva, fuente energy–momentum y retroacción. El toro y el grafo temporal actual son estructura causal combinatoria, no gravedad.

### Termodinámica e hidrodinámica

Faltan energía o carga lenta no trivial en un dominio físico, corriente y ecuación de balance, ensemble estacionario, temperatura operacional, producción entrópica, separación de escalas y cierre de stress/flujo. T8 ofrece advección y colisiones con fuentes/sumideros; eso es un punto de partida, no Navier–Stokes.

### Quantum y Bell

Faltan espacio de estados físicos y composición, observables, probabilidades/Born y preparaciones. Para Bell se requieren fuente, dos estaciones, settings generados independientemente, outcomes binarios, variable `lambda`, separación según el cono `3t`, auditoría `lambda independent of (a,b)`, no señalización y no postselección. Sin ese aparato CHSH es no identificable.

### Gauge/campos

Faltan variables de enlace/conexión, transformación local que preserve el estado físico completo, curvatura/holonomía y una carga acoplada. La redundancia raw del clock no-wrap no cumple esos requisitos.

### Constantes y unidades

Falta una calibración dimensional que no reutilice alpha, masas o 20 Hz para construir los enteros que luego pretende predecir. Un único ajuste debe predecir varios observables externos con incertidumbre y holdout.

## Abiertos matemáticos internos que no se declaran imposibles

- clasificación completa de invariantes de rango 1–2 o relacionales en dominios no-observer;
- basins y atractores para todos los tamaños/ensembles;
- universalidad y límites de coarse-graining;
- modos interactuantes distintos del sector T8;
- estabilizadores/simetrías emergentes de basins;
- invariantes topológicos persistentes;
- escalamiento de anisotropía overflow bajo medidas estacionarias.

No existe una interrogación finita simple que agote esos espacios de raw 64-bit. Las búsquedas históricas cubren bancos definidos y los teoremas de este paquete cubren sectores exactos. Ninguno de estos abiertos cambia el veredicto externo sin la Rosetta: aun encontrar otro invariante interno no determina su significado físico ni sus unidades.

## Información local ausente pero genealógicamente relevante

- bundle decisional Phase0 citado para equivalencia v25→v27;
- Part-E1, que E2 pide leer conjuntamente;
- cierre final de V6-A;
- freeze completamente externo al hotfix de V7-C;
- algunos runners sólo dentro de ZIP y el detalle D4 sólo en WORK.

Su ausencia limita historia/procedencia. No impide los teoremas actuales porque éstos se probaron directamente sobre el wheel v27.
