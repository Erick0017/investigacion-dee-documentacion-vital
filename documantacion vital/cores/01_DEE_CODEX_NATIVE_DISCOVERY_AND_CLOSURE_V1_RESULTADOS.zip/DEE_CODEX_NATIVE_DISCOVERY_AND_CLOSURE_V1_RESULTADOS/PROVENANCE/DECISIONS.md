# Decision log

## D-0001 — Isolation and evidence order

- Date: 2026-09-11
- Decision: preserve every original and place all generated artifacts beneath this directory.
- Evidence order: direct v27 execution, primary telemetry, exact runner/preregister, manifests and hashes, closure documents, later interpretations, AI opinions.
- First dependency pivot: inventory plus binary/API identity. No new scientific campaign is admissible until the executed kernel is tied to the local wheel and the historical evidence map is known.

## D-0002 — Inventory scale and parallel evidence audit

- Date: 2026-09-11
- Observed corpus: 8,922 original files, 3,418,485,589 bytes (~3.18 GiB), dominated by 5,185 NPZ telemetry files, 1,473 JSON records, 43 DOCX documents and 17 ZIP archives.
- Decision: hash every original file once, then parallelize three orthogonal audits: binary/API identity, archive/telemetry lineage, and document/claim history.
- Reason: these audits share no mutable originals and jointly determine which new kernel interrogations have maximal discriminating power.
- Inventory SHA-256: `00d8334e68ce0877fee93c2805621e87aeb0f14caaa9f84d8c0712e7cc002d94`.
- Immediate verified fact: the local wheel hash is exactly `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.

## D-0003 — Reanudación sin reinicio

- Date: 2026-09-11
- Decision: resume the existing V1 work directory after the credit interruption; do not repeat inventory, wheel extraction, document extraction, archive scanning, hashes, or completed probes.
- Basis: `STATE.json`, `RUN_LOG.ndjson`, timestamps, scripts, extracted inputs, and completed binary-audit artifacts form a coherent and hash-verifiable provenance chain.
- Consequence: the credit interruption is classified as an operational interruption only, never as a scientific result.

## D-0004 — T8 prospective test of the discovered mobile sector

- Date: 2026-09-11
- Discovery basis: source-only branch analysis predicted an exact singleton translation sector, 26 direction classes, an advective Fourier law, and a commutative two-source collision reducer.
- Freeze: `HOLDOUTS/PREREGISTER_T8_BALLISTIC_SINGLETON.md`, SHA-256 `0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb`, sealed before the first targeted binary trajectory.
- Duplicate-control plan: `HOLDOUTS/T8_EXECUTION_PLAN.md`, SHA-256 `12d1145e9079e8c5db37b8ef66578bb30c21701a7d2193435cdb716ba4f5a3ec`, also sealed before results.
- Result: PASS with zero mismatches in 1,872 factorial trajectories (50,544 primary ticks), 624 implementation comparisons, 12 two-particle runs, and 1,300 pair-collision cases.
- Interpretation boundary: `direction` is an exact routing velocity and `s_reg` an exactly transported label in this restricted sector; neither is thereby universal physical momentum or energy.

## D-0005 — T9, semantic como control y no ontología

- Date: 2026-09-11
- Priority reason: the fixed semantic-4 subfield refuted T4 and could alter three central conclusions at once—what observer means, which raws are causal, and whether semantic labels are passive.
- Freeze: `HOLDOUTS/PREREGISTER_T9_OBSERVER_PUMP.md`, SHA-256 `6e60b8cafd19dac9ff04dae7e2b30aed09d944720e99975da71ff0b338602fbe`, before targeted binary execution.
- Result: PASS, 936 factorial cases, 208 cross-engine runs, 18 zero-direction controls, 12,782 ticks, zero mismatches.
- Consequence: semantic 4 is a pinned boundary/source capable of emitting a parity-spaced ballistic train even when its state is zero. It does not implement measurement.

## D-0006 — Dependency graph and stopping priorities

- `binary identity -> all exact/empirical claims`: closed.
- `local rule -> causal geometry, clock quotient, symmetries, invariants`: closed by source proof plus binary witnesses.
- `mobile class -> modes, reversibility, matter, inertia, kinetic/hydro bridge`: unlocked by T8; exact free transport/collisions closed, but no inertial scalar or interacting reversible sector exists in this class.
- `semantic control -> observer sufficiency and observable bias`: closed by T9 and E15.
- `historical telemetry/docs -> transfer and claim genealogy`: reuse-only audits still pending; no reruns unless a lineage ambiguity changes a central verdict.
- `external physics -> Rosetta, dimensions, preparations/probabilities, empirical prediction`: cannot be supplied by the kernel alone; classify after genealogy.
- Decision: do not launch broad blind sweeps. T8/T9 already falsify the historical global absence of mobile modes and occupancy sufficiency; further random morphology sweeps duplicate Part D and cannot create an external Rosetta. Remaining local effort goes to adversarial independent replication, historical scope correction, and package closure.

## D-0007 — Auditoría del observable temporal D6

- Date: 2026-09-11
- Decision: reuse the sealed Part-D JSON rather than rerun 189 worlds; audit the exact FFT extractor and challenge it with short nonperiodic controls.
- Result: 284/300 peaks are bins 1–5, 56/60 signals rank exactly those bins, and six nonperiodic controls reproduce `T/j` for both window lengths.
- Consequence: preserve D6 as a correct periodogram computation but reject promotion of its bins to recurrence, native periods, or a Fibonacci law.

## D-0008 — Corrección de genealogía balística

- Date: 2026-09-11
- Initial scope: the v27 `tests` corpus exposed `TORUS_MOVING` only as a named regression case.
- Extended read-only recovery: the v25 runner and primary JSON reconstruct a singleton crossing the torus in 12/12 ticks; v25.5-C/F-189 records 60/60 prepared lanes and 2,226 exact shifts.
- Decision: T8 is not called the first historical observation. It is the prospectively frozen v27 generalization across 26 directions, states, loads, clocks, engines and collisions. `P=L_sym` is classified as a sectoral group-action corollary; `s_reg` has period 1 in F-189.

## D-0009 — Adversarial proof correction before promotion

- Date: 2026-09-11
- Independent review found five domain/formulation issues without rerunning probes.
- Corrections: disjoint ABI buffers and positive `N`; E6 restricted to base output before DEMUX; E10 uses pairwise toroidal Chebyshev separation at least 3; E11 requires raw-zero/XNOR-false and distinguishes later overflow; E12 requires Moore direction and `1<=t<N`. Terminology and symmetry scope were tightened.
- Promoted proof SHA-256: `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.

## D-0010 — Stopping decision and external boundary

- Date: 2026-09-11
- Closed locally: wheel identity/API, T1–T6, clock phase, causal radius, exact mobile class, Fourier law, restricted gas, pair collisions, observer pump, occupancy sufficiency, D6 bias and historical scope.
- Remaining internal classification problems are unbounded spaces rather than short decisive kernel queries; another random sweep cannot adjudicate the external claim.
- Exact missing piece under `H_DEE`: a frozen, causally sufficient preparation/coarse-graining/observable/unit Rosetta that predicts independent external holdouts in at least two sectors without target leakage.
- Decision: satisfy the stopping rule after reproducibility and final-package QA; do not claim physical equivalence.

## D-0011 — Final QA, reproducibility and seal

- Date: 2026-09-11
- Self-contained reproduction: package integrity, T8, T9 and D6 all PASS from copied package inputs/runners; no sealed result was overwritten.
- Independent re-QA: PASS with no residual P0/P1/P2 issue after correcting theorem domains, collision scope, historical priority language and reproduction-path safeguards.
- Decision: close the scientific investigation and seal one compact external ZIP. The ZIP is a transport envelope, not evidence added after freeze; its SHA-256 is recorded outside the archive to avoid circular self-hashing.
