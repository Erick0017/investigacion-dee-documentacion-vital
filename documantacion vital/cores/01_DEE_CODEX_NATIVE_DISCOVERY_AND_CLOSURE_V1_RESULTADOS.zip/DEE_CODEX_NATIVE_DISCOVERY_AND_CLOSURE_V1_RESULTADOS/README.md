# DEE v27 — paquete de descubrimiento nativo y cierre

Este paquete contiene la evidencia compacta, los teoremas, los holdouts y los runners nuevos de la misión. No incluye ZIP históricos gigantes ni el JSON bruto de 57 MB de la réplica independiente; sus hashes, conteos y resultados estructurados están conservados en `ANALYSIS/ballistic_independent/`.

Orden de lectura recomendado:

1. `EXECUTIVE_VERDICT.md`
2. `FINAL_REPORT.md`
3. `NATIVE_DEE_THEORY.md`
4. `EXACT_THEOREMS.md`
5. `CLAIM_LEDGER.csv` o `CLAIM_LEDGER.json`
6. `HISTORICAL_CLAIMS_AUDIT.md` y `CLAUDE_AUDIT.md`

Integridad:

```powershell
.\REPRODUCE.ps1
```

La llamada anterior sólo verifica `HASHES.sha256`. Para reejecutar T8 y T9 en una carpeta scratch nueva, con CPython 3.13 x64 y NumPy disponibles:

```powershell
.\REPRODUCE.ps1 -PythonPath 'D:\Descargas\ANACONDA MINICONDA\python.exe' -RunExperiments
```

Para añadir el control D6 desde la copia sellada de la telemetría histórica:

```powershell
.\REPRODUCE.ps1 -PythonPath 'D:\Descargas\ANACONDA MINICONDA\python.exe' -RunExperiments -RunD6
```

Los runners usan `-I -B`, cargan exclusivamente el `.pyd` extraído y verifican los hashes del wheel/kernel/preregistro antes de medir. No instalan ni modifican el wheel.

Veredicto en una línea: DEE v27 posee una arquitectura matemática interna específica y un sector balístico exacto, pero no una Rosetta física externa validada.
