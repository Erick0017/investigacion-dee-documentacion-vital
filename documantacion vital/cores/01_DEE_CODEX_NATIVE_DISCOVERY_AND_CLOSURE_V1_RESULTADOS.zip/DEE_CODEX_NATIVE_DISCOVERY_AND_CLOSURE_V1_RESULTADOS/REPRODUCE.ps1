[CmdletBinding()]
param(
    [string]$PythonPath = 'D:\Descargas\ANACONDA MINICONDA\python.exe',
    [switch]$RunExperiments,
    [switch]$RunD6,
    [string]$ScratchPath = ''
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$packageFull = [IO.Path]::GetFullPath($packageRoot).TrimEnd([char[]]@('\', '/'))
$hashList = Join-Path $packageRoot 'HASHES.sha256'

function Test-IsSameOrDescendant {
    param([string]$Candidate, [string]$Base)
    $candidateFull = [IO.Path]::GetFullPath($Candidate).TrimEnd([char[]]@('\', '/'))
    $baseFull = [IO.Path]::GetFullPath($Base).TrimEnd([char[]]@('\', '/'))
    if ($candidateFull.Equals($baseFull, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $candidateFull.StartsWith($baseFull + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)
}

if (-not (Test-Path -LiteralPath $hashList -PathType Leaf)) {
    throw "Missing HASHES.sha256 at $hashList"
}

$hashFailures = [System.Collections.Generic.List[string]]::new()
$listedHashes = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($line in Get-Content -LiteralPath $hashList) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+\*(.+)$') {
        $hashFailures.Add("Malformed checksum line: $line")
        continue
    }
    $expected = $Matches[1].ToLowerInvariant()
    $relativePosix = $Matches[2].Replace('\', '/')
    if (-not $listedHashes.Add($relativePosix)) {
        $hashFailures.Add("Duplicate checksum path: $relativePosix")
        continue
    }
    $relative = $relativePosix.Replace('/', [IO.Path]::DirectorySeparatorChar)
    $target = [IO.Path]::GetFullPath((Join-Path $packageFull $relative))
    if (-not (Test-IsSameOrDescendant -Candidate $target -Base $packageFull)) {
        $hashFailures.Add("Checksum path escapes package: $relativePosix")
        continue
    }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) {
        $hashFailures.Add("Missing: $relativePosix")
        continue
    }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLowerInvariant()
    if ($actual -ne $expected) {
        $hashFailures.Add("Hash mismatch: $relativePosix expected=$expected actual=$actual")
    }
}

$manifestPath = Join-Path $packageRoot 'MANIFEST.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    $hashFailures.Add('Missing MANIFEST.json')
} else {
    $manifest = Get-Content -LiteralPath $manifestPath -Raw | ConvertFrom-Json
    $manifestExpected = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    foreach ($item in $manifest.files) { [void]$manifestExpected.Add([string]$item.path) }
    [void]$manifestExpected.Add('MANIFEST.json')
    foreach ($entry in $manifestExpected) {
        if (-not $listedHashes.Contains($entry)) { $hashFailures.Add("Missing checksum entry: $entry") }
    }
    foreach ($entry in $listedHashes) {
        if (-not $manifestExpected.Contains($entry)) { $hashFailures.Add("Checksum entry not declared by manifest: $entry") }
    }
}

if ($hashFailures.Count -gt 0) {
    throw ("Package integrity failed:`n" + ($hashFailures -join "`n"))
}

Write-Host 'Package integrity: PASS'

if (-not $RunExperiments -and -not $RunD6) {
    Write-Host 'Verification-only run complete. Add -RunExperiments for T8/T9 or -RunD6 for the historical FFT-bin audit.'
    return
}

if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) {
    throw "CPython 3.13 executable not found. Pass -PythonPath explicitly: $PythonPath"
}

$runtimeJson = & $PythonPath -I -B -c "import json,platform,struct,sys; import numpy; ok=(platform.python_implementation()=='CPython' and sys.version_info[:2]==(3,13) and struct.calcsize('P')*8==64); print(json.dumps({'implementation':platform.python_implementation(),'version':'.'.join(map(str,sys.version_info[:3])),'machine':platform.machine(),'pointer_bits':struct.calcsize('P')*8,'numpy':numpy.__version__})); raise SystemExit(0 if ok else 2)"
if ($LASTEXITCODE -ne 0) {
    throw "The packaged wheel requires CPython 3.13 x64 with NumPy; runtime probe was $runtimeJson"
}
$runtime = $runtimeJson | ConvertFrom-Json
Write-Host "Runtime: $($runtime.implementation) $($runtime.version), $($runtime.pointer_bits)-bit $($runtime.machine), NumPy $($runtime.numpy)"

if ([string]::IsNullOrWhiteSpace($ScratchPath)) {
    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
    $ScratchPath = Join-Path (Split-Path -Parent $packageRoot) ("REPRODUCTION_$stamp")
}
$scratchFull = [IO.Path]::GetFullPath($ScratchPath)
if ((Test-IsSameOrDescendant -Candidate $scratchFull -Base $packageFull) -or (Test-IsSameOrDescendant -Candidate $packageFull -Base $scratchFull)) {
    throw "ScratchPath must be outside and must not contain the package directory: $scratchFull"
}
if (Test-Path -LiteralPath $scratchFull) {
    throw "ScratchPath already exists; choose a new empty path: $scratchFull"
}

New-Item -ItemType Directory -Path $scratchFull | Out-Null
Copy-Item -LiteralPath (Join-Path $packageRoot 'RUNNERS_NEW') -Destination $scratchFull -Recurse
Copy-Item -LiteralPath (Join-Path $packageRoot 'HOLDOUTS') -Destination $scratchFull -Recurse
Copy-Item -LiteralPath (Join-Path $packageRoot 'INPUTS') -Destination $scratchFull -Recurse
New-Item -ItemType Directory -Path (Join-Path $scratchFull 'ANALYSIS\binary_api') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $packageRoot 'ANALYSIS\binary_api\wheel_extracted') -Destination (Join-Path $scratchFull 'ANALYSIS\binary_api') -Recurse

if ($RunExperiments) {
    & $PythonPath -I -B (Join-Path $scratchFull 'RUNNERS_NEW\run_t8_ballistic_holdout.py')
    if ($LASTEXITCODE -ne 0) { throw "T8 runner failed with exit code $LASTEXITCODE" }
    $t8 = Get-Content -LiteralPath (Join-Path $scratchFull 'RESULTS\native_ballistic\t8_result.json') -Raw | ConvertFrom-Json
    if ($t8.status -ne 'PASS' -or $t8.mismatch_count -ne 0 -or $t8.sections.primary.trajectories -ne 1872 -or $t8.sections.collisions.collision_cases -ne 1300) {
        throw 'T8 completed but did not reproduce the frozen PASS/counts.'
    }
    Write-Host 'T8 prospective holdout: PASS (1,872 trajectories; 1,300 collisions; zero mismatches)'

    & $PythonPath -I -B (Join-Path $scratchFull 'RUNNERS_NEW\run_t9_observer_pump_holdout.py')
    if ($LASTEXITCODE -ne 0) { throw "T9 runner failed with exit code $LASTEXITCODE" }
    $t9 = Get-Content -LiteralPath (Join-Path $scratchFull 'RESULTS\observer_pump\t9_result.json') -Raw | ConvertFrom-Json
    if ($t9.status -ne 'PASS' -or $t9.mismatch_count -ne 0 -or $t9.factorial_cases -ne 936 -or $t9.ticks_executed -ne 12782) {
        throw 'T9 completed but did not reproduce the frozen PASS/counts.'
    }
    Write-Host 'T9 prospective holdout: PASS (936 cases; 12,782 ticks; zero mismatches)'
}

if ($RunD6) {
    & $PythonPath -I -B (Join-Path $scratchFull 'RUNNERS_NEW\audit_d6_period_bins.py')
    if ($LASTEXITCODE -ne 0) { throw "D6 audit runner failed with exit code $LASTEXITCODE" }
    $d6 = Get-Content -LiteralPath (Join-Path $scratchFull 'ANALYSIS\historical_bias\d6_period_bin_audit.json') -Raw | ConvertFrom-Json
    if ($d6.source_sha256 -ne '7339604363069f6a9a1522b0841cab0e294f2544a9090f25a647147de0eac1e9' -or $d6.reported_peaks -ne 300 -or $d6.signals_whose_ranked_bins_are_exactly_1_to_5 -ne 56) {
        throw 'D6 audit completed but did not reproduce the sealed source/counts.'
    }
    Write-Host 'D6 FFT-bin audit: PASS (sealed input; 300 peaks; 56/60 signals rank bins 1-5)'
}

Write-Host "Reproduction outputs: $scratchFull"
