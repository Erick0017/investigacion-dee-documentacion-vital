#!/usr/bin/env python3
"""Reuse Part-D telemetry to audit whether D6 peaks establish recurrence."""
from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
SOURCE = WORK / "INPUTS" / "historical" / "DEE_V27_SPONTANEOUS_MORPHOGENESIS_AND_MULTISCALE_GEOMETRY_PART_D_V1.json"
OUT = WORK / "ANALYSIS" / "historical_bias"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def periodogram_bins(values, dt, topk=5):
    y = np.asarray(values, dtype=float)
    if len(y) < 16 or float(np.std(y)) < 1e-15:
        return []
    t = np.arange(len(y), dtype=float)
    slope, intercept = np.polyfit(t, y, 1)
    y = y - (intercept + slope * t)
    y = y - np.mean(y)
    p = np.abs(np.fft.rfft(y * np.hanning(len(y)))) ** 2
    freq = np.fft.rfftfreq(len(y), d=float(dt))
    if len(p) <= 1:
        return []
    p[0] = 0
    out = []
    for j in np.argsort(p)[::-1]:
        if freq[j] <= 0:
            continue
        period = 1 / freq[j]
        if period < 2 * dt:
            continue
        if any(abs(period - x["period"]) / max(period, x["period"], 1e-9) < 0.05 for x in out):
            continue
        out.append({"period": float(period), "bin": int(j), "power": float(p[j])})
        if len(out) >= topk:
            break
    return out


def main():
    root = json.loads(SOURCE.read_text(encoding="utf-8"))
    mods = root["modules"]
    d2 = mods["D2_DEEP_FREE_EVOLUTION_AND_SNAPSHOT_FREEZE_27X"]
    d4 = mods["D4_CROSS_N_AND_RESERVED_SEED_HOLDOUT_27X"]
    d6 = mods["D6_TEMPORAL_SPECTRUM_AND_RATIO_ATLAS_27X"]
    temporal = {}
    kind = {}
    for row in d2.get("rows", []):
        temporal[row["world_id"]] = row.get("temporal", [])
        kind[row["world_id"]] = "deep_finalist"
    for row in d4.get("rows", []):
        temporal[row["world_id"]] = row.get("temporal", [])
        kind[row["world_id"]] = "holdout"

    rows = []
    bin_counts = Counter()
    first_five_exact = 0
    signal_count = 0
    reported_count = 0
    max_bin_error = 0.0
    near_constant_with_peaks = 0
    fib_nulls = []
    fields = ("density", "sreg_max", "sreg_sum", "direction_nonzero")
    for drow in d6["rows"]:
        wid = drow["world_id"]
        tr = temporal[wid]
        ticks = np.asarray([x["tick"] for x in tr], dtype=float)
        dt = float(np.median(np.diff(ticks)))
        n = len(tr)
        fft_span = n * dt
        fib = drow.get("fibonacci_like", {})
        if fib.get("available"):
            fib_nulls.append(float(fib["empirical_null_fraction_as_or_better"]))
        for field in fields:
            values = np.asarray([x[field] for x in tr], dtype=float)
            reported = drow["peaks"].get(field, [])
            if not reported:
                continue
            signal_count += 1
            std = float(np.std(values))
            value_range = float(np.ptp(values))
            scale = max(float(np.max(np.abs(values))), 1.0)
            near_constant = value_range / scale < 1e-6
            near_constant_with_peaks += int(near_constant)
            bins_this = []
            for rank, peak in enumerate(reported, 1):
                period = float(peak["period"])
                implied = fft_span / period
                b = int(round(implied))
                err = abs(implied - b)
                max_bin_error = max(max_bin_error, err)
                bin_counts[b] += 1
                bins_this.append(b)
                reported_count += 1
                rows.append({
                    "world_id": wid,
                    "kind": kind.get(wid, drow.get("kind")),
                    "signal": field,
                    "samples": n,
                    "dt": dt,
                    "fft_span": fft_span,
                    "std": std,
                    "range": value_range,
                    "range_over_scale": value_range / scale,
                    "near_constant": near_constant,
                    "rank": rank,
                    "reported_period": period,
                    "implied_fft_bin": implied,
                    "nearest_bin": b,
                    "bin_error": err,
                    "power": float(peak["power"]),
                })
            first_five_exact += int(bins_this == [1, 2, 3, 4, 5])

    # Synthetic negative controls use the exact historical extractor. They are
    # deliberately nonperiodic curves, not additional DEE data.
    controls = []
    for n, dt in sorted({(r["samples"], r["dt"]) for r in rows}):
        x = np.linspace(0, 1, int(n))
        series = {
            "quadratic_monotone": x**2,
            "exponential_monotone": np.exp(-4 * x),
            "single_step": (x >= 0.63).astype(float),
        }
        for name, values in series.items():
            peaks = periodogram_bins(values, dt)
            controls.append({
                "samples": n,
                "dt": dt,
                "control": name,
                "known_periodic": False,
                "top_bins": [p["bin"] for p in peaks],
                "top_periods": [p["period"] for p in peaks],
            })

    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "d6_peak_bins.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    result = {
        "source": str(SOURCE),
        "source_sha256": sha256_file(SOURCE),
        "source_campaign": root.get("campaign"),
        "worlds": len(d6["rows"]),
        "signals_with_reported_peaks": signal_count,
        "reported_peaks": reported_count,
        "max_distance_from_integer_fft_bin": max_bin_error,
        "bin_counts": dict(sorted(bin_counts.items())),
        "signals_whose_ranked_bins_are_exactly_1_to_5": first_five_exact,
        "near_constant_signals_with_reported_peaks": near_constant_with_peaks,
        "fibonacci_null_fraction_min": min(fib_nulls) if fib_nulls else None,
        "fibonacci_null_fraction_median": float(np.median(fib_nulls)) if fib_nulls else None,
        "fibonacci_comparisons": len(fib_nulls),
        "synthetic_nonperiodic_controls": controls,
        "adjudication": "D6 reports dominant DFT-bin scales, predominantly the first five window harmonics. It did not compute an autocorrelation recurrence gate. These peaks and their rational ratios are not evidence of genuine periods; the historical campaign itself did not promote them automatically.",
    }
    (OUT / "d6_period_bin_audit.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
