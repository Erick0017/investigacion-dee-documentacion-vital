#!/usr/bin/env python3
"""Build and validate the compact DEE v27 final-package manifest/checksums."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


REQUIRED = [
    "FINAL_REPORT.md",
    "EXECUTIVE_VERDICT.md",
    "NATIVE_DEE_THEORY.md",
    "EXACT_THEOREMS.md",
    "CLAIM_LEDGER.csv",
    "CLAIM_LEDGER.json",
    "CLAUDE_AUDIT.md",
    "HISTORICAL_CLAIMS_AUDIT.md",
    "NEGATIVE_RESULTS.md",
    "OPEN_EXTERNAL_GAPS.md",
    "EXPERIMENT_INDEX.csv",
    "REPRODUCE.ps1",
]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def role(relative: str) -> str:
    if relative in REQUIRED or relative in {"README.md"}:
        return "primary_deliverable"
    if relative.startswith("INPUTS/"):
        return "sealed_input"
    if relative.startswith("RUNNERS_NEW/"):
        return "reproduction_code"
    if relative.startswith("HOLDOUTS/"):
        return "preregister"
    if relative.startswith("RESULTS/"):
        return "primary_result"
    if relative.startswith("PROVENANCE/"):
        return "provenance"
    if relative.startswith("ANALYSIS/"):
        return "supporting_analysis"
    return "support"


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", required=True)
    args = parser.parse_args()
    root = Path(args.package_root).resolve()

    missing = [name for name in REQUIRED if not (root / name).is_file()]
    if missing:
        raise SystemExit(f"Missing required deliverables: {missing}")

    claims = load_csv(root / "CLAIM_LEDGER.csv")
    experiments = load_csv(root / "EXPERIMENT_INDEX.csv")
    claim_json = json.loads((root / "CLAIM_LEDGER.json").read_text(encoding="utf-8"))
    if len(claims) != 56 or len(experiments) != 18:
        raise SystemExit(f"Unexpected table counts: claims={len(claims)} experiments={len(experiments)}")
    if [row["claim_id"] for row in claims] != [row["claim_id"] for row in claim_json["claims"]]:
        raise SystemExit("CLAIM_LEDGER CSV/JSON parity failure")
    if len({row["claim_id"] for row in claims}) != len(claims):
        raise SystemExit("Duplicate claim_id")
    if len({row["experiment_id"] for row in experiments}) != len(experiments):
        raise SystemExit("Duplicate experiment_id")

    payload = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name in {"MANIFEST.json", "HASHES.sha256"}:
            continue
        relative = path.relative_to(root).as_posix()
        payload.append(
            {
                "path": relative,
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
                "role": role(relative),
            }
        )

    manifest = {
        "schema": "dee.codex.native_discovery_and_closure.final_package.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "package": "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS",
        "status": "COMPLETE",
        "scientific_verdict": "DEE v27 has a specific internal mathematical architecture and exact ballistic sectors; an externally validated physical Rosetta remains unidentified.",
        "kernel_identity": {
            "wheel_sha256": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
            "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
            "cpp_sha256": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
            "abi": "CPython 3.13 x64 / Windows AMD64",
        },
        "method": {
            "originals_modified": False,
            "inventory_files": 8922,
            "inventory_bytes": 3418485589,
            "discovery_then_freeze_then_holdout": True,
            "adversarial_proof_review": True,
            "external_physics_claimed": False,
        },
        "tables": {
            "claim_rows": len(claims),
            "experiment_rows": len(experiments),
            "csv_json_claim_parity": True,
        },
        "primary_results": {
            "T8": "PASS: 1872 trajectories, 50544 primary ticks, 1300 collisions, zero mismatches",
            "T8_independent": "PASS_SCOPED: 16260 cases, 48876 ticks, zero discrepancies",
            "T9": "PASS: 936 factorial cases, 12782 ticks, zero mismatches",
            "D6_audit": "284/300 peaks in FFT bins 1-5; nonperiodic controls reproduce T/j",
        },
        "required_deliverables": REQUIRED,
        "deliberate_omissions": [
            {
                "artifact": "ANALYSIS/ballistic_independent/ballistic_probe_results.json",
                "bytes": 57686450,
                "sha256": "fe84156f144d2a060388c7b6eaea314c32077852093c48357e99670e63b212ef",
                "reason": "Large raw independent panel omitted; compact findings, report, runner and seal are included.",
            },
            {
                "artifact": "historical ZIP corpus",
                "reason": "No redundant multi-gigabyte history; archive hashes, manifest checks and audit reports are included.",
            },
        ],
        "file_count_excluding_manifest_and_hash_list": len(payload),
        "payload_bytes_excluding_manifest_and_hash_list": sum(item["bytes"] for item in payload),
        "files": payload,
    }

    manifest_path = root / "MANIFEST.json"
    manifest_path.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    hash_rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file() or path.name == "HASHES.sha256":
            continue
        hash_rows.append(f"{sha256(path)} *{path.relative_to(root).as_posix()}")
    (root / "HASHES.sha256").write_text("\n".join(hash_rows) + "\n", encoding="utf-8", newline="\n")

    print(
        json.dumps(
            {
                "status": "PASS",
                "files_in_manifest": len(payload),
                "checksum_rows": len(hash_rows),
                "claims": len(claims),
                "experiments": len(experiments),
            }
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
