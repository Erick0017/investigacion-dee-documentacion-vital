#!/usr/bin/env python3
"""Read-only identity/API/semantics probe for the accepted local DEE v27 wheel.

Run with the historical CPython 3.13 interpreter using ``-I -B``.  The wheel is
not installed: its files are imported from an extracted copy below the work
directory, and the resolved paths and hashes are asserted before experiments.
"""
from __future__ import annotations

import base64
import csv
import hashlib
import importlib.util
import inspect
import json
import math
import platform
import struct
import sys
import sysconfig
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
ANALYSIS = WORK / "ANALYSIS" / "binary_api"
EXTRACTED = ANALYSIS / "wheel_extracted"
WHEEL = WORK / "INPUTS" / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
OUTPUT = ANALYSIS / "runtime_probe.json"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "source": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def jdump(obj: object) -> None:
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    tmp = OUTPUT.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True), encoding="utf-8")
    tmp.replace(OUTPUT)


def pack(state=1, sreg=0, direction=(0, 0, 0), semantic=1) -> np.uint64:
    dx, dy, dz = (int(v) for v in direction)
    return np.uint64(
        (int(state) & 0xFFFFFFFF)
        | ((int(sreg) & 0xFFFF) << 32)
        | ((dx & 0xF) << 48)
        | ((dy & 0xF) << 52)
        | ((dz & 0xF) << 56)
        | ((int(semantic) & 0xF) << 60)
    )


def unpack(value) -> dict[str, int]:
    v = int(value)

    def nib(shift: int) -> int:
        x = (v >> shift) & 0xF
        return x - 16 if x & 8 else x

    return {
        "raw": v,
        "state": v & 0xFFFFFFFF,
        "sreg": (v >> 32) & 0xFFFF,
        "dx": nib(48),
        "dy": nib(52),
        "dz": nib(56),
        "semantic": (v >> 60) & 0xF,
    }


MOORE = [
    (dx, dy, dz)
    for dx in (-1, 0, 1)
    for dy in (-1, 0, 1)
    for dz in (-1, 0, 1)
    if (dx, dy, dz) != (0, 0, 0)
]


def tick_direct(kernel, grid, clock, *, lazy=False, threads=1):
    shape = tuple(grid.shape)
    n = shape[0]
    assert shape == (n, n, n)
    # The extension copies B back into A, so copies are mandatory: callers' inputs
    # are experimental preimages and must remain unchanged across paired probes.
    ga = np.ascontiguousarray(grid, dtype=np.uint64).reshape(-1).copy()
    gb = np.zeros_like(ga)
    ca = np.ascontiguousarray(clock, dtype=np.uint64).reshape(-1).copy()
    cb = np.zeros_like(ca)
    fn = kernel.tick_universo_lazy if lazy else kernel.tick_universo
    info = dict(fn(ga, gb, ca, cb, int(n), int(threads)))
    # The binary copies B back into A.  Preserve this API fact in every result.
    buffers_equal = bool(np.array_equal(ga, gb) and np.array_equal(ca, cb))
    return ga.reshape(shape).copy(), ca.reshape(shape).copy(), {
        str(k): int(v) if isinstance(v, (int, np.integer)) else float(v)
        for k, v in info.items()
    }, buffers_equal


def torus_invert(a):
    ids = (-np.arange(a.shape[0])) % a.shape[0]
    return a[np.ix_(ids, ids, ids)]


def shifted(a, shift):
    return np.roll(a, tuple(int(x) for x in shift), axis=(0, 1, 2))


def coords_where(a, b):
    return [[int(v) for v in row] for row in np.argwhere(a != b)]


def validate_record() -> dict:
    record = EXTRACTED / "dee_universe_v27-27.0.0.dist-info" / "RECORD"
    rows = []
    all_ok = True
    with record.open(newline="", encoding="utf-8") as f:
        for name, digest, size in csv.reader(f):
            p = EXTRACTED / Path(name)
            item = {"name": name, "exists": p.is_file(), "declared_size": int(size) if size else None}
            if p.is_file():
                item["actual_size"] = p.stat().st_size
                item["actual_sha256"] = sha256(p)
            if digest:
                algorithm, encoded = digest.split("=", 1)
                padded = encoded + "=" * (-len(encoded) % 4)
                declared_hex = base64.urlsafe_b64decode(padded).hex()
                item["algorithm"] = algorithm
                item["declared_sha256"] = declared_hex
                item["hash_ok"] = algorithm == "sha256" and item.get("actual_sha256") == declared_hex
                item["size_ok"] = item.get("actual_size") == item["declared_size"]
                all_ok &= bool(item["hash_ok"] and item["size_ok"])
            rows.append(item)
    return {"record_path": str(record), "all_declared_entries_ok": all_ok, "entries": rows}


def pe_identity(path: Path) -> dict:
    data = path.read_bytes()
    if data[:2] != b"MZ":
        return {"valid_mz": False}
    peoff = struct.unpack_from("<I", data, 0x3C)[0]
    valid = data[peoff : peoff + 4] == b"PE\0\0"
    machine = struct.unpack_from("<H", data, peoff + 4)[0] if valid else None
    return {
        "valid_mz": True,
        "valid_pe": valid,
        "pe_offset": peoff,
        "machine_hex": f"0x{machine:04x}" if machine is not None else None,
        "machine_name": {0x8664: "AMD64", 0x014C: "I386", 0xAA64: "ARM64"}.get(machine, "unknown"),
    }


def default_import_resolution() -> dict:
    """Resolve the interpreter's pre-existing install before adding our path."""
    spec = importlib.util.find_spec("dee_universe_v27")
    if spec is None or spec.origin is None:
        return {"found": False}
    origin = Path(spec.origin).resolve()
    package_dir = origin.parent
    files = {}
    for name in (
        "__init__.py",
        "dee_constants_v27.py",
        "dee_universe_v27.py",
        "dee_kernel_v27.cpp",
        "dee_kernel_v27.cp313-win_amd64.pyd",
    ):
        p = package_dir / name
        if p.is_file():
            files[name] = {"path": str(p), "bytes": p.stat().st_size, "sha256": sha256(p)}
    return {
        "found": True,
        "origin": str(origin),
        "submodule_search_locations": [str(x) for x in (spec.submodule_search_locations or ())],
        "files": files,
    }


def api_record(pkg, kernel, Universe) -> dict:
    kernel_public = [x for x in dir(kernel) if not x.startswith("_")]
    functions = {}
    for name in kernel_public:
        obj = getattr(kernel, name)
        if callable(obj):
            try:
                signature = str(inspect.signature(obj))
            except Exception as exc:
                signature = f"unavailable: {type(exc).__name__}: {exc}"
            functions[name] = {"signature": signature, "doc": inspect.getdoc(obj)}
    methods = {}
    for name, obj in inspect.getmembers(Universe, predicate=callable):
        if not name.startswith("_"):
            try:
                methods[name] = str(inspect.signature(obj))
            except Exception as exc:
                methods[name] = f"unavailable: {type(exc).__name__}: {exc}"
    return {
        "package_public_names": [x for x in dir(pkg) if not x.startswith("_")],
        "kernel_public_names": kernel_public,
        "kernel_functions": functions,
        "universe_constructor": str(inspect.signature(Universe)),
        "universe_methods": methods,
    }


def wrapper_smoke(Universe) -> dict:
    invalid = None
    try:
        Universe(N=3, n_hilos=1)
    except Exception as exc:
        invalid = f"{type(exc).__name__}: {exc}"
    u = Universe(N=4, n_hilos=1)
    electron_count = int(u.sembrar_electron(3, 3, 3, 7, 1, 0, -1))
    before_census = u.censo()
    wrapper_failures = {}
    for name, call in (
        ("sembrar_proton", lambda: u.sembrar_proton(1, 1, 1, 7)),
        ("medir_energia_total", u.medir_energia_total),
        ("detectar_estructuras", u.detectar_estructuras),
    ):
        try:
            wrapper_failures[name] = {"raised": False, "return": call()}
        except Exception as exc:
            wrapper_failures[name] = {"raised": True, "error": f"{type(exc).__name__}: {exc}"}
    tick_info = u.tick(1)
    return {
        "N_lt_4": invalid,
        "N": int(u.N),
        "n_hilos": int(u.n_hilos),
        "total": int(u.total),
        "array_contract": {
            name: {"shape": list(getattr(u, name).shape), "dtype": str(getattr(u, name).dtype)}
            for name in ("grid_A", "grid_B", "clock_A", "clock_B")
        },
        "electron_injection_return": electron_count,
        "census_before_tick": before_census,
        "wrapper_contract_checks": wrapper_failures,
        "tick_return": tick_info,
        "tick_global_after": int(u.tick_global),
        "A_B_equal_after_tick": bool(np.array_equal(u.grid_A, u.grid_B) and np.array_equal(u.clock_A, u.clock_B)),
    }


def clock_probe(kernel) -> dict:
    n = 4
    g = np.zeros((n, n, n), dtype=np.uint64)
    c = np.zeros_like(g)
    values = [0, 1, 96, 97, 781, 782, (1 << 64) - 1]
    for j, value in enumerate(values):
        c.reshape(-1)[j] = np.uint64(value)
    expected = c + np.uint64(1)
    modes = {}
    for lazy in (False, True):
        go, co, info, buffers = tick_direct(kernel, g, c, lazy=lazy)
        modes["lazy" if lazy else "dense"] = {
            "raw_all_zero": bool(np.count_nonzero(go) == 0),
            "clock_plus_one_mod_2_64": bool(np.array_equal(co, expected)),
            "sample_before": [int(x) for x in c.reshape(-1)[: len(values)]],
            "sample_after": [int(x) for x in co.reshape(-1)[: len(values)]],
            "buffers_equal_after_direct_call": buffers,
            "telemetry": info,
        }
    return {
        "modes": modes,
        "exact_contract": "clock_out[i] = clock_in[i] + 1 modulo 2^64 for every coordinate",
        "difference_contract": "pairwise differences are invariant modulo 2^64; ordinary integer differences require a no-wrap domain",
    }


def clock_period_probe(kernel) -> dict:
    syntactic_periods = [782 // missing for missing in range(1, 9)]
    claude_common = math.lcm(*syntactic_periods)
    active_periods = [195, 260, 391, 782]
    minimal_common = math.lcm(*active_periods)
    n = 9
    center = np.array([4, 4, 4])
    g = np.zeros((n, n, n), dtype=np.uint64)
    g[tuple(center)] = pack(1, 10, semantic=1)
    for off in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        g[tuple((center + off) % n)] = pack(1, 0, semantic=4)
    c0 = np.zeros_like(g)
    cL = c0 + np.uint64(claude_common)
    cM = c0 + np.uint64(minimal_common)
    c1 = c0.copy()
    c1[tuple(center)] = np.uint64(1)
    one0, _, _, _ = tick_direct(kernel, g, c0)
    oneL, _, _, _ = tick_direct(kernel, g, cL)
    oneM, _, _, _ = tick_direct(kernel, g, cM)
    one1, _, _, _ = tick_direct(kernel, g, c1)
    ga, ca = g.copy(), c0.copy()
    gb, cb = g.copy(), cM.copy()
    trajectory = []
    for t in range(6):
        ga, ca, _, _ = tick_direct(kernel, ga, ca)
        gb, cb, _, _ = tick_direct(kernel, gb, cb)
        trajectory.append({
            "step": t + 1,
            "raw_equal": bool(np.array_equal(ga, gb)),
            "clock_offset_minimal_everywhere": bool(np.array_equal(cb, ca + np.uint64(minimal_common))),
            "no_wrap": bool(np.max(ca) <= np.iinfo(np.uint64).max - minimal_common),
        })

    # Each causally live period is witnessed by a center that survives and whose
    # increment gate differs at p-1 but agrees at 0 and p.
    tet = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)]
    extras = [(-1, 0, 0), (0, -1, 0), (0, 0, -1)]
    witnesses = []
    for n_active, period in ((4, 195), (5, 260), (6, 391), (7, 782)):
        wg = np.zeros((n, n, n), dtype=np.uint64)
        wg[tuple(center)] = pack(1, 10, semantic=1)
        offsets = (tet + extras)[:n_active]
        for j, off in enumerate(offsets):
            # At n_active=7 a nonzero vector sum disables write protection.
            direction = (1, 0, 0) if n_active == 7 and j == 0 else (0, 0, 0)
            wg[tuple((center + off) % n)] = pack(1, 0, direction, semantic=4)
        variants = {}
        for label, value in (("zero", 0), ("period", period), ("period_minus_1", period - 1)):
            wc = np.zeros_like(wg)
            wc[tuple(center)] = np.uint64(value)
            wo, _, _, _ = tick_direct(kernel, wg, wc)
            variants[label] = unpack(wo[tuple(center)])
        witnesses.append({
            "n_active": n_active,
            "missing_anchors": 8 - n_active,
            "period": period,
            "zero_equals_period": variants["zero"] == variants["period"],
            "zero_differs_period_minus_1": variants["zero"] != variants["period_minus_1"],
            "outputs": variants,
        })
    return {
        "syntactic_periods_from_782_floor_div_missing_anchors_1_to_8": syntactic_periods,
        "claude_lcm_valid_but_nonminimal": claude_common,
        "causally_active_periods": active_periods,
        "minimal_causally_active_one_step_raw_period": minimal_common,
        "period_witnesses": witnesses,
        "center_output_clock0": unpack(one0[tuple(center)]),
        "center_output_clockL": unpack(oneL[tuple(center)]),
        "center_output_clock_minimal": unpack(oneM[tuple(center)]),
        "center_output_clock1": unpack(one1[tuple(center)]),
        "one_step_L_raw_equal": bool(np.array_equal(one0, oneL)),
        "one_step_minimal_raw_equal": bool(np.array_equal(one0, oneM)),
        "one_step_plus1_raw_distinguishable": bool(not np.array_equal(one0, one1)),
        "six_step_trajectory": trajectory,
        "scope": "Exact under adding the minimal period (and therefore Claude's multiple L) pointwise while uint64 addition does not cross wrap; not a global quotient across wrap.",
    }


def static_source_audit(source_path: Path) -> dict:
    source = source_path.read_text(encoding="utf-8")
    # Tight L1-gradient maximum: max over sign octants of the linear form.
    coefficient_sum = max(
        sum(max(0, sx * (-dx) + sy * (-dy) + sz * (-dz)) for dx, dy, dz in MOORE)
        for sx in (-1, 1) for sy in (-1, 1) for sz in (-1, 1)
    )
    max_gradient = coefficient_sum * 65535
    threshold = 19665 * int(9.887 ** 3)
    return {
        "P_KERNEL_binary_source": 19665,
        "P_KERNEL_python_constants": 19658,
        "P_KERNEL_mismatch": True,
        "crystallization": {
            "UMBRAL_CRISTALIZACION": int(9.887 ** 3),
            "comparison_effective_required_grad_mag": threshold,
            "tight_max_grad_mag": max_gradient,
            "coefficient_sum": coefficient_sum,
            "branch_unreachable_for_any_valid_raw_neighborhood": max_gradient < threshold,
            "reason": "grad_mag is an L1 norm of three signed sums over 26 nonnegative 16-bit s_reg values; integer division by P_KERNEL must reach 966",
        },
        "demux_edge_min_occurrences": source.count("demux_edge_min"),
        "demux_edge_min_defined_but_never_called": source.count("demux_edge_min") == 1,
        "tick_clock_reads": source.count("const uint64_t tick = clkA[i]"),
        "tick_modulo_gate_occurrences": source.count("tick % (uint64_t)periodo_ticks"),
    }


def noninjective_probe(kernel) -> dict:
    n = 7
    center = (3, 3, 3)
    c = np.zeros((n, n, n), dtype=np.uint64)
    a = np.zeros_like(c)
    b = np.zeros_like(c)
    a[center] = pack(1, 0, semantic=1)
    b[center] = pack(2, 0, semantic=1)
    modes = {}
    for lazy in (False, True):
        ao, ac, ai, _ = tick_direct(kernel, a, c, lazy=lazy)
        bo, bc, bi, _ = tick_direct(kernel, b, c, lazy=lazy)
        modes["lazy" if lazy else "dense"] = {
            "inputs_distinct": bool(not np.array_equal(a, b)),
            "full_outputs_equal": bool(np.array_equal(ao, bo) and np.array_equal(ac, bc)),
            "output_raw_nonzero": int(np.count_nonzero(ao)),
            "telemetry_A": ai,
            "telemetry_B": bi,
        }
    return {"construction": "one isolated SEM_NORMAL voxel with state=1 versus state=2; equal clocks", "modes": modes}


def range0_invariant_probe(kernel) -> dict:
    n = 7
    c = np.arange(n ** 3, dtype=np.uint64).reshape((n, n, n))
    g = np.zeros_like(c)
    observer_sites = [(2, 2, 2), (3, 3, 3), (4, 4, 4)]
    g[observer_sites[0]] = pack(1, 123, (1, -1, 0), 4)
    g[observer_sites[1]] = pack(0, 456, (-1, 0, 1), 4)
    g[observer_sites[2]] = pack(987654321, 65535, (7, -8, 3), 4)

    # A second counterexample to Claude's premise: hidden directional raw with
    # state=0 can seed a neighbour because buscar_fuente_demux does not call
    # exists()/is_alive_for_rule on the directional source.
    hidden = np.zeros_like(g)
    source = (3, 3, 3)
    target = (4, 3, 3)
    hidden[source] = pack(0, 0, (1, 0, 0), 0)

    modes = {}
    for lazy in (False, True):
        key = "lazy" if lazy else "dense"
        cur_g, cur_c = g.copy(), c.copy()
        trajectory = []
        initial_values = [int(cur_g[q]) for q in observer_sites]
        for step in range(4):
            cur_g, cur_c, _, _ = tick_direct(kernel, cur_g, cur_c, lazy=lazy)
            sem = (cur_g >> np.uint64(60)) & np.uint64(0xF)
            trajectory.append({
                "step": step + 1,
                "sem4_count_all_raw": int(np.count_nonzero(sem == 4)),
                "observer_raw_values": [int(cur_g[q]) for q in observer_sites],
                "observer_values_preserved": [int(cur_g[q]) for q in observer_sites] == initial_values,
            })
        ho, _, _, _ = tick_direct(kernel, hidden, np.zeros_like(hidden), lazy=lazy)
        modes[key] = {
            "observer_trajectory": trajectory,
            "state0_direction_input_raw": unpack(hidden[source]),
            "state0_direction_output_target": unpack(ho[target]),
            "state0_direction_does_not_collapse_to_all_zero": bool(np.count_nonzero(ho) > 0),
            "state0_direction_output_nonzero_coords": [[int(v) for v in row] for row in np.argwhere(ho != 0)],
        }
    return {
        "classification": "REFUTED",
        "counterexample_invariant": "Q4 = sum_i 1[semantic(raw_i)=SEM_OBSERVER]",
        "stronger_family": "for any raw-only f, sum over the fixed SEM_OBSERVER sites of f(raw_i) is invariant because each such raw is pointwise fixed",
        "static_reason": "actualizar_voxel returns immediately with gB[i]=gA[i] for semantic 4; aplicar_demux explicitly skips semantic 4; no reachable branch creates semantic 4 because the only inheritance path is unreachable crystallization",
        "claude_collapse_premise_also_false": "state=0 directional raw can be copied to the pointed-to empty destination without an exists/alive guard",
        "modes": modes,
    }


def translation_probe(kernel) -> dict:
    n = 7
    rng = np.random.default_rng(270027)
    states = rng.integers(0, 4, size=(n, n, n))
    sregs = rng.integers(0, 21000, size=(n, n, n))
    dirs = rng.integers(-1, 2, size=(3, n, n, n))
    sems = rng.choice([1, 2, 3, 4, 5, 7], size=(n, n, n))
    g = np.zeros((n, n, n), dtype=np.uint64)
    for q in np.ndindex(g.shape):
        g[q] = pack(states[q], sregs[q], tuple(d[q] for d in dirs), sems[q])
    c = rng.integers(0, 5000, size=g.shape, dtype=np.uint64)
    shift = (2, -1, 3)
    out = {}
    for lazy in (False, True):
        go, co, _, _ = tick_direct(kernel, g, c, lazy=lazy, threads=3)
        gs, cs = shifted(g, shift), shifted(c, shift)
        gso, cso, _, _ = tick_direct(kernel, gs, cs, lazy=lazy, threads=2)
        out["lazy" if lazy else "dense"] = {
            "raw_translation_equivariant": bool(np.array_equal(gso, shifted(go, shift))),
            "clock_translation_equivariant": bool(np.array_equal(cso, shifted(co, shift))),
            "thread_count_changed_3_to_2": True,
        }
    return {"toroidal_shift": list(shift), "modes": out}


def inversion_anisotropy_probe(kernel) -> dict:
    n = 9
    origin = np.array([0, 0, 0])
    g = np.zeros((n, n, n), dtype=np.uint64)
    c = np.ones_like(g)
    g[tuple(origin)] = pack(1, 19665, semantic=1)
    for off in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)):
        g[tuple((origin + off) % n)] = pack(1, 0, semantic=4)
    assert np.array_equal(g, torus_invert(g)) and np.array_equal(c, torus_invert(c))
    out = {}
    for lazy in (False, True):
        go, co, info, _ = tick_direct(kernel, g, c, lazy=lazy)
        mismatch = coords_where(go, torus_invert(go))
        minus = tuple((origin - 1) % n)
        plus = tuple((origin + 1) % n)
        out["lazy" if lazy else "dense"] = {
            "input_inversion_symmetric": True,
            "output_inversion_symmetric": bool(not mismatch),
            "raw_minus_111": unpack(go[minus]),
            "raw_plus_111": unpack(go[plus]),
            "inversion_mismatch_count": len(mismatch),
            "inversion_mismatch_coords": mismatch,
            "telemetry": info,
        }
    return {
        "construction": "inversion-symmetric six-axis support around a central s_reg=19665 source",
        "expected_order_first_offset": [-1, -1, -1],
        "modes": out,
    }


def radius_three_probe(kernel) -> dict:
    n = 11
    x = np.array([5, 5, 5])
    z = x - 1
    y = x + 1
    q = x - 2
    base = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.ones_like(base)
    base[tuple(x)] = pack(1, 19665, semantic=1)
    # All neighbours except z/y get s_reg=1, making z/y the only minimum-s_reg targets.
    for off in MOORE:
        at = tuple((x + off) % n)
        if at not in (tuple(z), tuple(y)):
            base[at] = pack(0, 1, semantic=0)
    # Exactly six live supports around x, none adjacent to z or y.
    for off in ((1, -1, -1), (-1, 1, -1), (-1, -1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)):
        base[tuple((x + off) % n)] = pack(1, 1, semantic=4)
    # z has seven live neighbours: x plus these six.  q is the switchable eighth.
    for off in ((-1, 0, 0), (0, -1, 0), (0, 0, -1), (-1, -1, 0), (-1, 0, -1), (0, -1, -1)):
        base[tuple((z + off) % n)] = pack(1, 0, semantic=4)
    a = base.copy()
    b = base.copy()
    b[tuple(q)] = pack(1, 0, semantic=4)
    out = {}
    for lazy in (False, True):
        ao, ac, ai, _ = tick_direct(kernel, a, clock, lazy=lazy)
        bo, bc, bi, _ = tick_direct(kernel, b, clock, lazy=lazy)
        diff = coords_where(ao, bo)
        out["lazy" if lazy else "dense"] = {
            "input_difference_only_q": coords_where(a, b),
            "q": [int(v) for v in q],
            "y": [int(v) for v in y],
            "chebyshev_q_to_y": int(np.max(np.abs(q - y))),
            "output_y_A": unpack(ao[tuple(y)]),
            "output_y_B": unpack(bo[tuple(y)]),
            "output_y_differs": bool(ao[tuple(y)] != bo[tuple(y)]),
            "all_raw_difference_coords": diff,
            "clocks_equal": bool(np.array_equal(ac, bc)),
            "telemetry_A": ai,
            "telemetry_B": bi,
        }
    return {
        "construction": "q toggles an earlier DEMUX candidate from degree 7 (open) to 8 (closed), redirecting the central overflow to y",
        "static_one_tick_upper_bound": "raw output at y reads local update radius 1 plus DEMUX contributors x at radius 1 whose target comparisons read radius 2 about x, hence <=3 about y",
        "modes": out,
    }


def dense_lazy_probe(kernel) -> dict:
    n = 8
    rng = np.random.default_rng(313027)
    g = np.zeros((n, n, n), dtype=np.uint64)
    for q in rng.choice(g.size, size=45, replace=False):
        coord = np.unravel_index(int(q), g.shape)
        g[coord] = pack(
            int(rng.integers(0, 4)), int(rng.integers(0, 30000)),
            tuple(int(x) for x in rng.integers(-1, 2, size=3)),
            int(rng.choice([1, 2, 3, 4, 5, 7])),
        )
    c = rng.integers(0, 3000, size=g.shape, dtype=np.uint64)
    gd, cd, di, db = tick_direct(kernel, g, c, lazy=False, threads=3)
    gl, cl, li, lb = tick_direct(kernel, g, c, lazy=True, threads=2)
    return {
        "raw_equal": bool(np.array_equal(gd, gl)),
        "clock_equal": bool(np.array_equal(cd, cl)),
        "dense_buffers_equal": db,
        "lazy_buffers_equal": lb,
        "dense_telemetry": di,
        "lazy_telemetry": li,
    }


def main() -> int:
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError(f"CPython 3.13 required, got {sys.version}")
    if not EXTRACTED.is_dir() or not WHEEL.is_file():
        raise FileNotFoundError("wheel or extracted wheel copy missing")
    default_resolution = default_import_resolution()
    sys.path.insert(0, str(EXTRACTED))

    import dee_universe_v27 as pkg
    from dee_universe_v27 import UniversoDEE_v27, dee_kernel_v27 as kernel

    pkg_path = Path(pkg.__file__).resolve()
    kernel_path = Path(kernel.__file__).resolve()
    source_path = pkg_path.parent / "dee_kernel_v27.cpp"
    resolved_under_extracted = pkg_path.is_relative_to(EXTRACTED.resolve()) and kernel_path.is_relative_to(EXTRACTED.resolve())
    observed = {
        "wheel": sha256(WHEEL),
        "package": sha256(pkg_path),
        "kernel": sha256(kernel_path),
        "source": sha256(source_path),
    }
    if not resolved_under_extracted or observed != EXPECTED:
        raise RuntimeError(f"identity gate failed: local={resolved_under_extracted}, observed={observed}")

    files = []
    for p in sorted(x for x in EXTRACTED.rglob("*") if x.is_file()):
        files.append({"path": str(p), "relative": p.relative_to(EXTRACTED).as_posix(), "bytes": p.stat().st_size, "sha256": sha256(p)})

    result = {
        "status": "PASS",
        "execution": {
            "python": sys.version,
            "executable": sys.executable,
            "implementation": platform.python_implementation(),
            "machine": platform.machine(),
            "architecture": platform.architecture(),
            "pointer_bits": struct.calcsize("P") * 8,
            "platform": platform.platform(),
            "numpy_version": np.__version__,
            "numpy_path": np.__file__,
            "soabi": sysconfig.get_config_var("SOABI"),
            "ext_suffix": sysconfig.get_config_var("EXT_SUFFIX"),
            "isolated_flag": int(sys.flags.isolated),
            "no_user_site_flag": int(sys.flags.no_user_site),
            "dont_write_bytecode_flag": int(sys.flags.dont_write_bytecode),
        },
        "identity": {
            "wheel_path": str(WHEEL.resolve()),
            "extracted_root": str(EXTRACTED.resolve()),
            "package_path": str(pkg_path),
            "kernel_path": str(kernel_path),
            "source_path": str(source_path),
            "resolved_under_extracted": resolved_under_extracted,
            "package_version": pkg.__version__,
            "kernel_version": kernel.VERSION,
            "expected_sha256": EXPECTED,
            "observed_sha256": observed,
            "all_expected_hashes_match": observed == EXPECTED,
            "pe": pe_identity(kernel_path),
            "wheel_files": files,
            "record_validation": validate_record(),
            "default_interpreter_import_before_override": default_resolution,
        },
        "metadata": {
            "METADATA": (EXTRACTED / "dee_universe_v27-27.0.0.dist-info" / "METADATA").read_text(encoding="utf-8"),
            "WHEEL": (EXTRACTED / "dee_universe_v27-27.0.0.dist-info" / "WHEEL").read_text(encoding="utf-8"),
            "package_P_KERNEL": int(pkg.P_KERNEL),
            "kernel_version_string": kernel.VERSION,
        },
        "api": api_record(pkg, kernel, UniversoDEE_v27),
        "wrapper_smoke": wrapper_smoke(UniversoDEE_v27),
        "dense_lazy_equivalence_sample": dense_lazy_probe(kernel),
        "static_source_audit": static_source_audit(source_path),
        "T1_locality": radius_three_probe(kernel),
        "T2_clock_affine": clock_probe(kernel),
        "T3_clock_period": clock_period_probe(kernel),
        "T4_range0_invariant": range0_invariant_probe(kernel),
        "T5_noninjective": noninjective_probe(kernel),
        "T6_translation": translation_probe(kernel),
        "T6_inversion_anisotropy": inversion_anisotropy_probe(kernel),
    }
    jdump(result)
    print(json.dumps({"status": result["status"], "output": str(OUTPUT), "identity": observed}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
