#!/usr/bin/env python3
"""Prospective T8 ballistic-singleton holdout against the sealed v27 wheel.

Run with the CPython 3.13 interpreter and ``-I -B``.  Nothing is installed;
the hash-verified package extracted by the binary/API audit is imported.
"""
from __future__ import annotations

import csv
import hashlib
import importlib
import json
import math
import random
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
EXTRACTED = WORK / "ANALYSIS" / "binary_api" / "wheel_extracted"
PACKAGE = EXTRACTED / "dee_universe_v27" / "__init__.py"
KERNEL_FILE = EXTRACTED / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
WHEEL = WORK / "INPUTS" / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
PREREG = WORK / "HOLDOUTS" / "PREREGISTER_T8_BALLISTIC_SINGLETON.md"
PLAN = WORK / "HOLDOUTS" / "T8_EXECUTION_PLAN.md"
OUT = WORK / "RESULTS" / "native_ballistic"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "preregister": "0ea1b97dcdc24d9476ffffd733b941499fe457d0a94e45a5d4716ebdc368b2fb",
}
SEED = 270819665
DIRECTIONS = [
    (dx, dy, dz)
    for dx in (-1, 0, 1)
    for dy in (-1, 0, 1)
    for dz in (-1, 0, 1)
    if (dx, dy, dz) != (0, 0, 0)
]
MODES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 2, 3)]
MASK64 = (1 << 64) - 1


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int = 1) -> np.uint64:
    dx, dy, dz = d
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((dx & 0xF) << 48)
        | ((dy & 0xF) << 52)
        | ((dz & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def clock_pattern(name: str, n: int) -> np.ndarray:
    total = n**3
    if name == "zero":
        return np.zeros(total, dtype=np.uint64)
    ids = np.arange(total, dtype=np.uint64)
    if name == "heterogeneous":
        # Explicit uint64 operations intentionally reduce modulo 2^64.
        return ids * np.uint64(6364136223846793005) + np.uint64(SEED)
    if name == "near_wrap":
        values = np.array([MASK64 - 2, MASK64 - 1, MASK64], dtype=np.uint64)
        return values[(ids % np.uint64(3)).astype(np.intp)]
    raise ValueError(name)


def idx(q: tuple[int, int, int], n: int) -> int:
    x, y, z = q
    return (x * n + y) * n + z


def advance(q: tuple[int, int, int], d: tuple[int, int, int], t: int, n: int) -> tuple[int, int, int]:
    return tuple((q[j] + t * d[j]) % n for j in range(3))


def engine_fn(kernel, engine: str):
    return kernel.tick_universo_lazy if engine == "lazy" else kernel.tick_universo


def fresh_world(n: int, entries: list[tuple[tuple[int, int, int], np.uint64]], clock_name: str):
    ga = np.zeros(n**3, dtype=np.uint64)
    for q, raw in entries:
        ga[idx(q, n)] = raw
    gb = np.zeros_like(ga)
    ca = clock_pattern(clock_name, n)
    cb = np.zeros_like(ca)
    return ga, gb, ca, cb, ca.copy()


def tick(kernel, engine: str, threads: int, n: int, ga, gb, ca, cb):
    info = dict(engine_fn(kernel, engine)(ga, gb, ca, cb, n, threads))
    return info


def singleton_ok(grid: np.ndarray, n: int, q: tuple[int, int, int], raw: np.uint64) -> tuple[bool, str]:
    nz = np.flatnonzero(grid)
    wanted = idx(q, n)
    if len(nz) != 1:
        return False, f"nonzero_count={len(nz)}"
    if int(nz[0]) != wanted:
        return False, f"position={int(nz[0])},wanted={wanted}"
    if int(grid[wanted]) != int(raw):
        return False, f"raw={int(grid[wanted])},wanted={int(raw)}"
    return True, ""


def clocks_ok(clock: np.ndarray, initial: np.ndarray, t: int) -> bool:
    expected = initial + np.uint64(t)
    return bool(np.array_equal(clock, expected))


def add_mismatch(mismatches: list[dict], hypothesis: str, case: str, tick_no: int, detail: str):
    mismatches.append({"hypothesis": hypothesis, "case": case, "tick": tick_no, "detail": detail})


def run_primary(kernel, cases: list[dict], mismatches: list[dict]) -> dict:
    rng = random.Random(SEED)
    total_ticks = 0
    max_fourier_error = 0.0
    fourier_count = 0
    orbit_returns = 0
    for d_i, d in enumerate(DIRECTIONS):
        for n in (11, 13):
            for state in (1, 2, 0xFFFFFFFF):
                for sreg in (0, 1, 19664, 65535):
                    for clock_name in ("zero", "heterogeneous", "near_wrap"):
                        q0 = tuple(rng.randrange(n) for _ in range(3))
                        initial_raw = pack(state, sreg, d)
                        orbit_raw = pack(1, sreg, d)
                        ga, gb, ca, cb, c0 = fresh_world(n, [(q0, initial_raw)], clock_name)
                        horizon = 2 * n + 3
                        case_id = f"P:d{d_i}:N{n}:e{state}:s{sreg}:c{clock_name}"
                        passed = True
                        raw_at_n = None
                        for t in range(1, horizon + 1):
                            tick(kernel, "lazy", 1, n, ga, gb, ca, cb)
                            total_ticks += 1
                            q = advance(q0, d, t, n)
                            ok, detail = singleton_ok(ga, n, q, orbit_raw)
                            if not ok:
                                passed = False
                                add_mismatch(mismatches, "H8.1/H8.2", case_id, t, detail)
                                break
                            if not clocks_ok(ca, c0, t):
                                passed = False
                                add_mismatch(mismatches, "H8.4", case_id, t, "clock mismatch")
                                break
                            if t == n:
                                raw_at_n = sha256_array(ga)
                                if state == 1 and not np.array_equal(ga, fresh_world(n, [(q0, initial_raw)], clock_name)[0]):
                                    passed = False
                                    add_mismatch(mismatches, "H8.3", case_id, t, "raw did not return after N")
                                elif state == 1:
                                    orbit_returns += 1
                            if state == 1 and sreg == 0 and clock_name == "zero" and t <= n + 1:
                                for m in MODES:
                                    phase_now = np.exp(-2j * np.pi * sum(m[j] * q[j] for j in range(3)) / n)
                                    q_prev = advance(q0, d, t - 1, n)
                                    phase_prev = np.exp(-2j * np.pi * sum(m[j] * q_prev[j] for j in range(3)) / n)
                                    predicted = np.exp(-2j * np.pi * sum(m[j] * d[j] for j in range(3)) / n)
                                    error = abs(phase_now / phase_prev - predicted)
                                    max_fourier_error = max(max_fourier_error, float(error))
                                    fourier_count += 1
                                    if error > 1e-12:
                                        passed = False
                                        add_mismatch(mismatches, "H8.3", case_id, t, f"Fourier error={error}")
                                        break
                        cases.append({
                            "family": "primary_factorial",
                            "case": case_id,
                            "passed": passed,
                            "ticks": t,
                            "N": n,
                            "direction": str(d),
                            "state": state,
                            "sreg": sreg,
                            "clock": clock_name,
                            "engine": "lazy",
                            "threads": 1,
                            "final_raw_sha256": sha256_array(ga),
                            "final_clock_sha256": sha256_array(ca),
                            "raw_at_N_sha256": raw_at_n or "",
                        })
    return {
        "trajectories": 26 * 2 * 3 * 4 * 3,
        "ticks_executed": total_ticks,
        "orbit_returns_checked": orbit_returns,
        "fourier_ratios_checked": fourier_count,
        "max_fourier_abs_error": max_fourier_error,
    }


def run_engine_equivalence(kernel, cases: list[dict], mismatches: list[dict]) -> dict:
    comparisons = 0
    total_ticks = 0
    rng = random.Random(SEED ^ 0x84)
    variants = [("dense", 1), ("dense", 2), ("lazy", 1), ("lazy", 2)]
    for d_i, d in enumerate(DIRECTIONS):
        for n in (11, 13):
            for clock_name in ("zero", "heterogeneous", "near_wrap"):
                q0 = tuple(rng.randrange(n) for _ in range(3))
                horizon = (2 * n + 3) if (d_i in (0, 13, 25) and clock_name == "near_wrap") else 4
                outputs = {}
                for engine, threads in variants:
                    ga, gb, ca, cb, _ = fresh_world(n, [(q0, pack(1, 65535, d))], clock_name)
                    trace = []
                    for _t in range(horizon):
                        tick(kernel, engine, threads, n, ga, gb, ca, cb)
                        total_ticks += 1
                        trace.append((sha256_array(ga), sha256_array(ca)))
                    outputs[(engine, threads)] = (ga.copy(), ca.copy(), trace)
                ref = outputs[("dense", 1)]
                case_id = f"E:d{d_i}:N{n}:c{clock_name}:h{horizon}"
                passed = True
                for variant, out in outputs.items():
                    comparisons += 1
                    if not (np.array_equal(out[0], ref[0]) and np.array_equal(out[1], ref[1]) and out[2] == ref[2]):
                        passed = False
                        add_mismatch(mismatches, "H8.4", case_id, horizon, f"variant mismatch {variant}")
                cases.append({
                    "family": "engine_equivalence",
                    "case": case_id,
                    "passed": passed,
                    "ticks": horizon,
                    "N": n,
                    "direction": str(d),
                    "state": 1,
                    "sreg": 65535,
                    "clock": clock_name,
                    "engine": "all",
                    "threads": "1,2",
                    "final_raw_sha256": sha256_array(ref[0]),
                    "final_clock_sha256": sha256_array(ref[1]),
                    "raw_at_N_sha256": "",
                })
    return {"variant_comparisons": comparisons, "ticks_executed": total_ticks}


def two_expected(n: int, entries):
    out = np.zeros(n**3, dtype=np.uint64)
    for q, raw in entries:
        out[idx(q, n)] = raw
    return out


def run_two_particle(kernel, cases: list[dict], mismatches: list[dict]) -> dict:
    variants = [("dense", 1), ("dense", 2), ("lazy", 1), ("lazy", 2)]
    directions = [(1, 0, 0), (1, -1, 0), (-1, 1, 1)]
    checks = 0
    for k, d in enumerate(directions):
        n = 17
        q1 = (2 + k, 3 + k, 4 + k)
        q2 = ((q1[0] + 5) % n, q1[1], q1[2])
        raws = (pack(1, 1, d), pack(1, 65535, d))
        for engine, threads in variants:
            ga, gb, ca, cb, c0 = fresh_world(n, [(q1, raws[0]), (q2, raws[1])], "heterogeneous")
            case_id = f"M{k}:{engine}{threads}"
            passed = True
            for t in range(1, 24):
                tick(kernel, engine, threads, n, ga, gb, ca, cb)
                expected = two_expected(n, [(advance(q1, d, t, n), raws[0]), (advance(q2, d, t, n), raws[1])])
                checks += 1
                if not np.array_equal(ga, expected):
                    passed = False
                    add_mismatch(mismatches, "H8.5", case_id, t, "two-particle raw mismatch")
                    break
                if not clocks_ok(ca, c0, t):
                    passed = False
                    add_mismatch(mismatches, "H8.5", case_id, t, "two-particle clock mismatch")
                    break
            cases.append({
                "family": "two_particle",
                "case": case_id,
                "passed": passed,
                "ticks": t,
                "N": n,
                "direction": str(d),
                "state": 1,
                "sreg": "1,65535",
                "clock": "heterogeneous",
                "engine": engine,
                "threads": threads,
                "final_raw_sha256": sha256_array(ga),
                "final_clock_sha256": sha256_array(ca),
                "raw_at_N_sha256": "",
            })
    return {"step_checks": checks, "cases": len(directions) * len(variants)}


def collision_expected(d1, d2, s1, s2):
    dout = tuple(1 if d1[j] + d2[j] > 0 else (-1 if d1[j] + d2[j] < 0 else 0) for j in range(3))
    sout = min(s1 + s2, 19664)
    return dout, sout, pack(1, sout, dout)


def run_collisions(kernel, cases: list[dict], mismatches: list[dict]) -> dict:
    n = 11
    q = (5, 5, 5)
    loads = [(0, 0), (1, 2), (19664, 1), (65535, 65535)]
    total = 0
    zero_direction = 0
    saturated = 0
    equivalence_subset = []
    for i, d1 in enumerate(DIRECTIONS):
        for j in range(i + 1, len(DIRECTIONS)):
            d2 = DIRECTIONS[j]
            for l_i, (s1, s2) in enumerate(loads):
                total += 1
                p1 = tuple((q[a] - d1[a]) % n for a in range(3))
                p2 = tuple((q[a] - d2[a]) % n for a in range(3))
                dout, sout, raw_out = collision_expected(d1, d2, s1, s2)
                zero_direction += int(dout == (0, 0, 0))
                saturated += int(sout == 19664 and s1 + s2 > 19664)
                ga, gb, ca, cb, c0 = fresh_world(n, [(p1, pack(1, s1, d1)), (p2, pack(1, s2, d2))], "zero")
                case_id = f"C:{i}-{j}:L{l_i}"
                passed = True
                tick(kernel, "lazy", 1, n, ga, gb, ca, cb)
                ok, detail = singleton_ok(ga, n, q, raw_out)
                if not ok:
                    passed = False
                    add_mismatch(mismatches, "H8.6", case_id, 1, detail)
                tick(kernel, "lazy", 1, n, ga, gb, ca, cb)
                if dout == (0, 0, 0):
                    if np.any(ga):
                        passed = False
                        add_mismatch(mismatches, "H8.6", case_id, 2, "zero-direction product persisted")
                else:
                    q2 = advance(q, dout, 1, n)
                    ok, detail = singleton_ok(ga, n, q2, raw_out)
                    if not ok:
                        passed = False
                        add_mismatch(mismatches, "H8.6", case_id, 2, detail)
                if not clocks_ok(ca, c0, 2):
                    passed = False
                    add_mismatch(mismatches, "H8.6", case_id, 2, "clock mismatch")
                if (i * 31 + j * 7 + l_i) % 61 == 0 or len(equivalence_subset) < 16:
                    equivalence_subset.append((case_id, d1, d2, s1, s2, ga.copy(), ca.copy()))
                cases.append({
                    "family": "collision",
                    "case": case_id,
                    "passed": passed,
                    "ticks": 2,
                    "N": n,
                    "direction": f"{d1}+{d2}->{dout}",
                    "state": 1,
                    "sreg": f"{s1}+{s2}->{sout}",
                    "clock": "zero",
                    "engine": "lazy",
                    "threads": 1,
                    "final_raw_sha256": sha256_array(ga),
                    "final_clock_sha256": sha256_array(ca),
                    "raw_at_N_sha256": "",
                })

    # Cross-engine repeat after the complete collision panel.  Selection is fixed
    # solely by indices above and was specified before results in the plan.
    variants = [("dense", 1), ("dense", 2), ("lazy", 1), ("lazy", 2)]
    eq_checks = 0
    for case_id, d1, d2, s1, s2, ref_grid, ref_clock in equivalence_subset:
        p1 = tuple((q[a] - d1[a]) % n for a in range(3))
        p2 = tuple((q[a] - d2[a]) % n for a in range(3))
        for engine, threads in variants:
            ga, gb, ca, cb, _ = fresh_world(n, [(p1, pack(1, s1, d1)), (p2, pack(1, s2, d2))], "zero")
            tick(kernel, engine, threads, n, ga, gb, ca, cb)
            tick(kernel, engine, threads, n, ga, gb, ca, cb)
            eq_checks += 1
            if not (np.array_equal(ga, ref_grid) and np.array_equal(ca, ref_clock)):
                add_mismatch(mismatches, "H8.4/H8.6", case_id, 2, f"collision engine mismatch {engine}/{threads}")
    return {
        "collision_cases": total,
        "zero_direction_cases": zero_direction,
        "strict_saturation_cases": saturated,
        "equivalence_subset_cases": len(equivalence_subset),
        "equivalence_variant_checks": eq_checks,
    }


def write_csv(path: Path, rows: list[dict]):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> int:
    started = datetime.now(timezone.utc).isoformat()
    observed = {
        "wheel": sha256_file(WHEEL),
        "package": sha256_file(PACKAGE),
        "kernel": sha256_file(KERNEL_FILE),
        "preregister": sha256_file(PREREG),
        "execution_plan": sha256_file(PLAN),
    }
    for key, wanted in EXPECTED.items():
        if observed[key] != wanted:
            raise RuntimeError(f"identity failure for {key}: {observed[key]} != {wanted}")

    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    package_path = Path(package.__file__).resolve()
    kernel_path = Path(kernel.__file__).resolve()
    if EXTRACTED.resolve() not in package_path.parents or kernel_path != KERNEL_FILE.resolve():
        raise RuntimeError(f"isolated import failure: {package_path}; {kernel_path}")

    OUT.mkdir(parents=True, exist_ok=True)
    cases: list[dict] = []
    mismatches: list[dict] = []
    sections = {
        "primary": run_primary(kernel, cases, mismatches),
        "engine_equivalence": run_engine_equivalence(kernel, cases, mismatches),
        "two_particle": run_two_particle(kernel, cases, mismatches),
        "collisions": run_collisions(kernel, cases, mismatches),
    }
    adjudications = {}
    for hypothesis in ("H8.1", "H8.2", "H8.3", "H8.4", "H8.5", "H8.6"):
        adjudications[hypothesis] = "FAIL" if any(hypothesis in m["hypothesis"] for m in mismatches) else "PASS"
    result = {
        "experiment": "T8_BALLISTIC_SINGLETON",
        "status": "PASS" if not mismatches else "FAIL",
        "started_utc": started,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "identity": observed,
        "resolved_package": str(package_path),
        "resolved_kernel": str(kernel_path),
        "kernel_version": str(kernel.VERSION),
        "python": sys.version,
        "numpy": np.__version__,
        "seed": SEED,
        "directions": DIRECTIONS,
        "adjudications": adjudications,
        "sections": sections,
        "case_rows": len(cases),
        "mismatch_count": len(mismatches),
        "mismatches": mismatches,
    }
    write_csv(OUT / "t8_cases.csv", cases)
    write_csv(OUT / "t8_mismatches.csv", mismatches)
    (OUT / "t8_result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "adjudications": adjudications,
        "sections": sections,
        "case_rows": len(cases),
        "mismatch_count": len(mismatches),
        "result": str(OUT / "t8_result.json"),
    }, indent=2))
    return 0 if not mismatches else 2


if __name__ == "__main__":
    raise SystemExit(main())
