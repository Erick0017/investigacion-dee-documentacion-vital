#!/usr/bin/env python3
"""Prospective T9 SEM_OBSERVER source/pump holdout for the sealed v27 binary."""
from __future__ import annotations

import csv
import hashlib
import importlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
EXTRACTED = WORK / "ANALYSIS" / "binary_api" / "wheel_extracted"
WHEEL = WORK / "INPUTS" / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_FILE = EXTRACTED / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
PREREG = WORK / "HOLDOUTS" / "PREREGISTER_T9_OBSERVER_PUMP.md"
OUT = WORK / "RESULTS" / "observer_pump"
EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "preregister": "6e60b8cafd19dac9ff04dae7e2b30aed09d944720e99975da71ff0b338602fbe",
}
DIRECTIONS = [(x, y, z) for x in (-1, 0, 1) for y in (-1, 0, 1) for z in (-1, 0, 1) if (x, y, z) != (0, 0, 0)]
MASK64 = (1 << 64) - 1


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def ahash(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()


def pack(state, sreg, d, semantic):
    return np.uint64((state & 0xFFFFFFFF) | ((sreg & 0xFFFF) << 32) | ((d[0] & 15) << 48) | ((d[1] & 15) << 52) | ((d[2] & 15) << 56) | ((semantic & 15) << 60))


def index(q, n):
    return (q[0] * n + q[1]) * n + q[2]


def pos(q, d, k, n):
    return tuple((q[a] + k * d[a]) % n for a in range(3))


def clock0(name, n):
    if name == "zero":
        return np.zeros(n**3, dtype=np.uint64)
    ids = np.arange(n**3, dtype=np.uint64)
    vals = np.array([MASK64 - 2, MASK64 - 1, MASK64], dtype=np.uint64)
    return vals[(ids % np.uint64(3)).astype(np.intp)]


def expected_grid(n, q, observer_raw, d, sreg, t):
    out = np.zeros(n**3, dtype=np.uint64)
    out[index(q, n)] = observer_raw
    mover = pack(1, sreg, d, 1)
    if d != (0, 0, 0):
        for k in range(1, t + 1):
            if k % 2 == t % 2:
                out[index(pos(q, d, k, n), n)] = mover
    return out


def run_trace(kernel, n, q, state, sreg, d, clock_name, engine, threads, horizon, mismatches, case_id):
    observer = pack(state, sreg, d, 4)
    ga = np.zeros(n**3, dtype=np.uint64)
    ga[index(q, n)] = observer
    gb = np.zeros_like(ga)
    ca = clock0(clock_name, n)
    cinit = ca.copy()
    cb = np.zeros_like(ca)
    fn = kernel.tick_universo_lazy if engine == "lazy" else kernel.tick_universo
    trace = []
    passed = True
    for t in range(1, horizon + 1):
        fn(ga, gb, ca, cb, n, threads)
        wanted = expected_grid(n, q, observer, d, sreg, t)
        clock_wanted = cinit + np.uint64(t)
        if not np.array_equal(ga, wanted):
            passed = False
            mismatches.append({"case": case_id, "tick": t, "kind": "raw", "actual_nonzero": int(np.count_nonzero(ga)), "expected_nonzero": int(np.count_nonzero(wanted))})
            break
        if not np.array_equal(ca, clock_wanted):
            passed = False
            mismatches.append({"case": case_id, "tick": t, "kind": "clock", "actual_nonzero": "", "expected_nonzero": ""})
            break
        trace.append((ahash(ga), ahash(ca)))
    return passed, ga.copy(), ca.copy(), trace, t


def main():
    started = datetime.now(timezone.utc).isoformat()
    identity = {"wheel": sha(WHEEL), "kernel": sha(KERNEL_FILE), "preregister": sha(PREREG)}
    for key, wanted in EXPECTED.items():
        if identity[key] != wanted:
            raise RuntimeError(f"identity mismatch {key}: {identity[key]}")
    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(kernel.__file__).resolve() != KERNEL_FILE.resolve():
        raise RuntimeError(f"wrong kernel import {kernel.__file__}")

    rows, mismatches = [], []
    q_by_n = {11: (3, 5, 7), 13: (4, 6, 8)}
    ticks = 0
    for di, d in enumerate(DIRECTIONS):
        for n in (11, 13):
            for state in (0, 1, 0xFFFFFFFF):
                for sreg in (0, 19664, 65535):
                    for cname in ("zero", "near_wrap"):
                        case = f"P:d{di}:N{n}:e{state}:s{sreg}:c{cname}"
                        ok, ga, ca, _, done = run_trace(kernel, n, q_by_n[n], state, sreg, d, cname, "lazy", 1, n - 1, mismatches, case)
                        ticks += done
                        rows.append({"family": "factorial", "case": case, "passed": ok, "ticks": done, "N": n, "direction": str(d), "state": state, "sreg": sreg, "clock": cname, "engine": "lazy", "threads": 1, "raw_sha256": ahash(ga), "clock_sha256": ahash(ca)})

    variants = [("dense", 1), ("dense", 2), ("lazy", 1), ("lazy", 2)]
    engine_checks = 0
    for di, d in enumerate(DIRECTIONS):
        for n in (11, 13):
            outputs = {}
            for engine, threads in variants:
                case = f"E:d{di}:N{n}:{engine}{threads}"
                ok, ga, ca, trace, done = run_trace(kernel, n, q_by_n[n], 0, 65535, d, "near_wrap", engine, threads, n - 1, mismatches, case)
                ticks += done
                outputs[(engine, threads)] = (ga, ca, trace)
                rows.append({"family": "engine", "case": case, "passed": ok, "ticks": done, "N": n, "direction": str(d), "state": 0, "sreg": 65535, "clock": "near_wrap", "engine": engine, "threads": threads, "raw_sha256": ahash(ga), "clock_sha256": ahash(ca)})
            ref = outputs[("dense", 1)]
            for variant, observed in outputs.items():
                engine_checks += 1
                if observed[2] != ref[2] or not np.array_equal(observed[0], ref[0]) or not np.array_equal(observed[1], ref[1]):
                    mismatches.append({"case": f"E:d{di}:N{n}", "tick": n - 1, "kind": f"engine_{variant}", "actual_nonzero": "", "expected_nonzero": ""})

    control_cases = 0
    for n in (11, 13):
        for state in (0, 1, 0xFFFFFFFF):
            for sreg in (0, 19664, 65535):
                case = f"Z:N{n}:e{state}:s{sreg}"
                ok, ga, ca, _, done = run_trace(kernel, n, q_by_n[n], state, sreg, (0, 0, 0), "near_wrap", "lazy", 1, n - 1, mismatches, case)
                ticks += done
                control_cases += 1
                rows.append({"family": "zero_direction_control", "case": case, "passed": ok, "ticks": done, "N": n, "direction": "(0,0,0)", "state": state, "sreg": sreg, "clock": "near_wrap", "engine": "lazy", "threads": 1, "raw_sha256": ahash(ga), "clock_sha256": ahash(ca)})

    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / "t9_cases.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    with (OUT / "t9_mismatches.csv").open("w", newline="", encoding="utf-8") as f:
        fields = ["case", "tick", "kind", "actual_nonzero", "expected_nonzero"]
        writer = csv.DictWriter(f, fieldnames=fields); writer.writeheader(); writer.writerows(mismatches)
    result = {
        "experiment": "T9_OBSERVER_PUMP",
        "status": "PASS" if not mismatches else "FAIL",
        "started_utc": started,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "identity": identity,
        "resolved_package": str(Path(package.__file__).resolve()),
        "resolved_kernel": str(Path(kernel.__file__).resolve()),
        "kernel_version": str(kernel.VERSION),
        "factorial_cases": 26 * 2 * 3 * 3 * 2,
        "engine_runs": 26 * 2 * 4,
        "engine_comparisons": engine_checks,
        "zero_direction_controls": control_cases,
        "ticks_executed": ticks,
        "mismatch_count": len(mismatches),
        "mismatches": mismatches,
    }
    (OUT / "t9_result.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if not mismatches else 2


if __name__ == "__main__":
    raise SystemExit(main())
