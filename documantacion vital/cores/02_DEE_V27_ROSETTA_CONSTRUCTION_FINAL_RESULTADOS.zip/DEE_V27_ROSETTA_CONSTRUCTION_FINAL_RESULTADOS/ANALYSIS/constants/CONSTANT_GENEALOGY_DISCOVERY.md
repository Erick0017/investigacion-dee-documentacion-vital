# Genealogía y sensibilidad de constantes DEE — discovery interno pre-holdout

Raíz autorizada de campaña: `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ROSETTA_CLOSURE`.

## Veredicto

La auditoría separa dos familias que no deben mezclarse:

1. **Estructura y conducta nativas:** conteos cúbicos `{8,12,6,26,13,7,4}`, gates internos, cap, velocidades y periodos de la dinámica. Son reproducibles dentro de DEE, pero no son por ello constantes de la naturaleza.
2. **Cadena constitutiva:** `alpha* -> Delta_nu* -> K* -> {966,782,194422,19665} -> 19664`. Es algebraicamente autoconsistente y varios descendientes sí están materializados en el binario, pero toda la cadena comparte el mismo supuesto aguas arriba. No suministra validaciones externas independientes.

El resultado principal para Rosetta es negativo y útil: **una coincidencia numérica aislada no es el puente mejor preparado**. Los candidatos internos defendibles son relaciones relacionales/adimensionales —traslación, dispersión, first-passage, respuesta y suficiencia causal— que puedan congelarse antes de consultar targets nuevos.

No se ejecutó el kernel, no se repitieron campañas, no se navegó y no se abrió ningún holdout externo. El corpus histórico ya contiene `alpha` y `20 Hz`; por ese hecho ambos quedan contaminados como targets confirmatorios primarios.

## Taxonomía

Las etiquetas no son excluyentes.

| Clase | Significado operacional |
|---|---|
| `input` | ecuación, convención o parámetro introducido; no generado por `F_DEE` |
| `literal` | número codificado en source/binario o metadata |
| `derivada` | consecuencia determinista de otros valores/fórmulas |
| `emergente` | relación demostrada o medida en la conducta de `F_DEE` |
| `preregistrada` | congelada antes de la ejecución relevante; no limpia supuestos upstream |
| `post-hoc` | formulada tras inspeccionar sistema/datos; puede ser teorema, pero no predicción externa prospectiva |
| `externa` | target, unidad o semántica que no nace de la dinámica DEE |

La autoridad usada fue: wheel/binario real, source C++ empaquetado, pruebas/telemetría y, sólo después, documentos para genealogía.

## Grafo de dependencia

```text
retícula cúbica / stencil
  ├─> 8,12,6,26,13,7,4 ─> 2.5,16,XNOR y geometría de regla
  └─> pi_DEE(R) ─> pi
                    └─> [dos ecuaciones constitutivas]
                          └─> alpha* ─> Delta_nu* ─> K*
                               ├─> R(K*^3)        = 966
                               ├─> R(8K*^2)       = 782
                               ├─> R(K*/Delta_nu*)= 194422
                               └─> R(1/Delta_nu*) = 19665 ─> cap 19664

782 + contexto de rama ─> 195,260,391,782 ─> L_raw=304980
dirección + sincronía ─> v_native=1 ─> P=L_sym en sectores preparados

20 Hz (target histórico conocido)
  └─> fórmula tardía vE/(LD) + parámetros atribuidos al cerebro
      [no salida del kernel; alto riesgo de target leakage]
```

Que un descendiente se encuentre en el kernel demuestra implementación, no independencia respecto de la raíz constitutiva.

## Registro compacto

| ID | Cantidad | Clases | Función real | Sensibilidad | Riesgo externo |
|---|---|---|---|---|---|
| CG01 | `{8,12,6,26,13,7,4}` | derivada, literal | combinatoria/stencil | estructuralmente alta; no un knob único | bajo; coincidencias físicas serían post-hoc |
| CG02 | `alpha*=0.00729735259143158029` | input, derivada, externa | solución de leyes constitutivas, no runtime | nula sin editar descendientes | alto; target ya conocido |
| CG03 | `Delta_nu*=0.0000508512980982667994` | input, derivada, externa | pareja constitutiva de alpha | nula como variable runtime | alto; misma evidencia que alpha |
| CG04 | `K*=9.88660490780602448` | derivada | `ln(1/Delta_nu*)` documental | nula runtime | alto heredado |
| CG05 | `K_LIMIT=9.887` | literal, derivada | padre de `int(K^3)` únicamente | sin efecto mientras threshold siga `>=50` | alto externo; bajo para auditar código muerto |
| CG06 | `966` | literal, derivada, preregistrada | threshold de cristalización | **cero en el dominio actual**: máximo cociente 49 | no confirma alpha |
| CG07 | `782` | literal, derivada, preregistrada | numerador de gates de fase | alta sobre cadencias por división entera | no es Hz |
| CG08 | `{195,260,391,782}` | derivada, emergente | periodos causalmente activos | contextual; `391=782//2`, no knob | no ritmos universales |
| CG09 | `L_raw=304980` | derivada, emergente, post-hoc | periodo mínimo del cociente raw sin wrap | cambia con cadencias; no full-state | sólo target nuevo tras freeze |
| CG10 | `L_Claude=1094573220` | derivada, post-hoc | múltiplo no mínimo | no controla el kernel | alto riesgo de numerología |
| CG11 | `P_KERNEL=19665` | literal, derivada, preregistrada | threshold phase-gated | +7 desplazó k=6 exactamente `2737=7*391` ticks | no re-predice alpha |
| CG12 | `cap=19664` | derivada, preregistrada | saturación de suma/delta | alta sólo al saturar; T8: 650 casos estrictos | no es evidencia independiente de 19665 |
| CG13 | wrapper `P=19658` | literal, input | metadata obsoleta | cero sobre binario; alto riesgo analítico | autoridad rechazada |
| CG14 | `TTL_ORFAN=194422` | literal, derivada, preregistrada | payload `state`, no contador | sparse; hit histórico citado `0` | no lifetime ni acierto independiente |
| CG15 | `ORPHAN_TTL=9` | literal, input | payload de siembra | no aislada; no decrementa | convención, no lifetime |
| CG16 | `XNOR_MIN_ACTIVE=8` | literal, input, preregistrada | gate de nacimiento XNOR | alta; unicidad geométrica no demostrada | bajo si se mantiene interno |
| CG17 | `2.5`, `16`, umbrales `{6,16,26}` | derivada, literal, emergente | regla de supervivencia/tetra | alta sobre estados de salida | etiquetas “electroweak/strong” no validadas |
| CG18 | `E/D=12/26` | derivada, input, externa | factor de fórmula histórica | RMSE `21.0146` vs `0` para `P=L` en el sector probado | alto; ligado a 20 Hz |
| CG19 | `kappa=fL/v=1` | emergente, derivada, post-hoc | ley sectorial preparada | causal a simetría; no universal | utilizable sólo con targets nuevos |
| CG20 | `v_native=1 voxel/tick` | emergente, derivada, preregistrada | transporte singleton exacto | robusto a state/carga/fase dentro del sector | no identificar con `c` |
| CG21 | radio causal raw máximo `3/tick` | emergente, derivada, post-hoc | cota de dependencia; transporte común usa 1 | depende de overflow/DEMUX | no es cono de luz |
| CG22 | `20 Hz` | input, externa, post-hoc | target histórico, ausente del kernel | no aplicable; unidades pueden ajustarlo tautológicamente | **crítico; excluir de confirmación primaria** |

El registro completo, incluidos locators y hashes, está en `CONSTANT_GENEALOGY_DISCOVERY.json`.

## Hallazgos de sensibilidad decisivos

### `19665/19664`

El binario real usa `P_KERNEL=UMBRAL_FUSION=19665`; `19664=P_KERNEL-1` es consecuencia, no parámetro adicional. El gate histórico corto distingue el cambio: en la rama k=6, siete unidades de threshold adicionales retrasan el overflow exactamente `7*391=2737` ticks. T8 confirma además la saturación del cap en 650 colisiones estrictas. Esto prueba causalidad interna del número, no su naturalidad externa.

El wrapper Python conserva `19658`; cambiar esa metadata no cambia `F_DEE`. Usarla como autoridad contaminaría cualquier genealogía posterior.

### `782/391`

`782` es literal y organiza `periodo_ticks=782/anclajes_faltantes`. Los periodos que realmente alcanzan raw son `195,260,391,782`. `391` no es literal ni ritmo basal: es `782//2` cuando la rama tiene dos anclajes faltantes. El periodo mínimo causal conjunto es `304980`, condicionado a no cruzar wrap; el gran LCM histórico de Claude es sólo un múltiplo no mínimo.

### `966`

La rama exige `grad_mag >= 19665*966 = 18,996,390`, pero el máximo exacto del packed domain es `983,025`; el cociente entero máximo es 49. Por tanto cualquier threshold `>=50`, incluido 966, produce la misma ausencia de cristalización. Un buen match documental de 966 no aporta poder discriminante en v27 actual.

### `194422/9`

`TTL_ORFAN=194422` se escribe como `state` de 32 bits cuando llega un delta a un orphan; no se decrementa como tiempo. `ORPHAN_TTL=9` es otro payload de `state` usado por el helper de siembra. Son mecanismos y genealogías distintos. Los nombres no autorizan una lectura de lifetime.

### `P=L_sym`, `kappa=1` y `20 Hz`

El antecedente v25.5-C/F-189 es sólido pero sectorial: 60/60 preparaciones direccionales, 2,226 pasos, `shift_hamming=0`, `translation_exact_fraction=1`, `P=L_sym` para packed/state/direction/semantic y `P_sreg=1` porque la carga era cero. Es una ley de traslación de una familia preparada, no una constante universal.

En ese mismo aparato `P=(D/E)L=(26/12)L` dio RMSE `21.0146`, frente a cero para `P=L`. El corpus declara que 20 Hz pasó de frecuencia base a valor obtenido mediante `vE/(LD)` con parámetros atribuidos al cerebro. Sin mapa voxel/tick a SI, 20 Hz no es un resultado DEE. Ajustar la duración del tick o `L` para recuperarlo sería target leakage.

## Diagnóstico de target leakage

1. **No independencia:** contar `alpha`, `Delta_nu`, `K`, 966, 782, 194422, 19665 y 19664 como aciertos separados incurre en multiplicación artificial de evidencia.
2. **Circularidad:** construir enteros desde alpha/Delta_nu y luego “predecir” alpha desde esos enteros no constituye holdout.
3. **Target expuesto:** 20 Hz ya estaba nombrado antes de la fórmula tardía; no puede ser endpoint confirmatorio primario.
4. **Calibración tautológica:** fijar segundos/tick o metros/voxel para hacer coincidir un único target consume ese target. La calibración debe usar datos distintos y predecir varios endpoints nuevos con incertidumbre.
5. **Leakage ontológico:** nombres como `ELECTROWEAK`, `STRONG`, `observer` y `TTL` no transfieren semántica física.
6. **Preregistro limitado:** congelar 19665 antes del gate protege contra un sweep de enteros post-ejecución, pero no vuelve inevitables las ecuaciones constitutivas upstream.
7. **Discovery legítimo:** 304980, radio 3 y otros hallazgos posteriores siguen siendo teoremas internos válidos; cualquier puente externo construido a partir de ellos debe declararse posterior y probarse contra datos aún no vistos.

## Regla para la fase externa

- Excluir `alpha/Delta_nu` y `20 Hz` como targets confirmatorios primarios de esta línea.
- No usar más de un miembro de la familia constitutiva como si fuera evidencia independiente.
- Congelar primero observable DEE, ensemble, ecuación dimensional, parámetros de calibración, incertidumbre y criterio de fallo.
- Calibrar sin el endpoint y exigir predicciones cruzadas sobre más de un target no expuesto.
- Mantener explícitas las unidades nativas; `1 voxel/tick` no equivale por definición a una velocidad física.

## Fuentes cerradas principales

- Source C++ empaquetado: SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.
- Pruebas exactas adversarialmente revisadas: SHA-256 `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.
- Auditoría documental: SHA-256 `a6770d53203767301a7f1601633c7cc5f1b0ed01c655a3f1e7f79b49e0c75fe7`.
- Genealogía v27: SHA-256 `46423a916ef13e4dad1826eaa847f2c7e666a6073af1eb23b9ad56e17b248152`.
- Volumen histórico v25/20 Hz: SHA-256 `eacc72e6c422bebc2e83a34d7f0481b3c9cfb3312eb561fac2c3ede3c9a050c6`.
- T8: SHA-256 `eb4a74b63afe714b6efedee94e318ace82fadd03763eac0c0e00ab60d37c0e92`.

Los paths y once hashes de evidencia están normalizados en el JSON compañero.
