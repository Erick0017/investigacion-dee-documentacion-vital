# Revisión adversarial pre-freeze del contrato externo dimensionless-first

Raíz autorizada: `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ROSETTA_CLOSURE`.

## Veredicto

E1–E4 pueden convertirse en especificaciones falsables, pero **el contrato todavía no debe sellarse**. Antes faltan decisiones de fuente, margen, potencia y modelo de medición, y hay dos problemas que deben quedar resueltos explícitamente:

1. El blind policy prescribe cinco dimensiones con score 0–3, mientras `INTERNAL_BRIDGE_SELECTION.json` usó siete dimensiones 0–5. La evidencia científica no cambia, pero el ranking actual no puede describirse como calculado con la rúbrica preregistrada.
2. Las 26 velocidades Moore de norma Chebyshev uno no admiten una única incrustación espacial lineal euclídea con velocidad positiva común. Esta clase de Rosetta queda descartada antes de mirar ningún dato externo.

La arquitectura viable es jerárquica:

- E3 actúa primero como gate de coherencia del mapa;
- E1 y E2 usan cocientes paired dentro del mismo path, cancelando toda escala común;
- E4 se evalúa aparte como análogo mecanístico controlado de exclusión/fase;
- no se combinan los cuatro resultados en un score omnibus.

No se usó web, red, valores externos ni outcomes de holdout. Los nombres de familias incluidos abajo son sólo candidatos; su existencia, acceso y resultados no se verificaron.

## Separación epistemológica obligatoria

| Capa | Qué contiene | Qué puede adjudicarse |
|---|---|---|
| L0 DEE | teorema/telemetría del sector `M_*/G_*/K_*` | conducta interna de `F_DEE` |
| L1 Rosetta | asignación de fuente, señal, label, path y detector externos | hipótesis de correspondencia |
| L2 medición | transformación de datos crudos, nuisances y exclusiones | identificabilidad del observable |
| L3 holdout | datos externos no vistos | sólo L1+L2 en el dominio congelado |

Un PASS externo no demuestra toda la ontología DEE. Un FAIL externo refuta el puente congelado para esa familia, no los teoremas internos. `INCONCLUSIVE` nunca cuenta como apoyo.

## Auditoría de la política de selección

`EXTERNAL_BLIND_POLICY.md` fija cinco criterios 0–3: exactitud, reutilización del núcleo, ausencia de parámetros ajustados al target, observable externo adimensional y falsabilidad. El registro de selección existente usó otra rúbrica. Como aún no se consultó ningún holdout externo, hay dos correcciones metodológicamente lícitas antes del freeze:

- recalcular la selección con la rúbrica original; o
- enmendar prospectivamente la política, preservando ambos textos y explicando por qué.

No es lícito reescribir silenciosamente el registro ni escoger la rúbrica después de ver outcomes. Usando literalmente la rúbrica 0–3 sólo para esta revisión: E1=15/15, E2=14/15, E3=15/15 y E4=15/15. Esos totales miden preparación formal, no equivalencia física: E2 añade una asignación cross-class y E4 sigue siendo un análogo.

## Reglas comunes congelables

Antes del holdout deben fijarse:

- familia y fuente primaria exactas, elegidas sólo por metadata de diseño;
- reglas de inclusión/exclusión evaluables sin conocer el efecto;
- asignación de cada señal a `kind`, `d`, label/`s_reg`, fuente, path y detector;
- transformación desde datos crudos, origen temporal, missing y censura;
- un estadístico primario por endpoint, secundarios y multiplicidad;
- márgenes de equivalencia `epsilon_E1`, `epsilon_E2`, `epsilon_E4`, cobertura, potencia y stopping rule;
- nuisances permitidos, calibración separada y hashes de datos/código/query/contrato.

Se permiten cocientes/log-cocientes within-path, diferencias normalizadas por una escala común obtenida fuera del holdout y un mapeo monotónico predeclarado de label a `s_reg` para E1. Si se informa velocidad absoluta secundaria, sólo se permite un factor común longitud/tiempo.

Se prohíben escalas por label, clase o dirección; normalizar diagonales silenciosamente; escoger bins/fuentes/covariables por el outcome; lags libres capaces de absorber cualquier efecto; y ajustar reloj, path o periodo al target.

La regla estadística común debe ser de **equivalencia**, no simple ausencia de significación:

- PASS: el intervalo simultáneo cae completamente dentro de la región congelada;
- FAIL: cae completamente fuera del margen en dirección falsante o falla un control lógico;
- INCONCLUSIVE: solapa ambas regiones, falta potencia o el efecto no es identificable.

## E1 — Nondispersión respecto a etiqueta/carga

### Predicción L0

En el sector singleton normal y en el gas libre permitido, la trayectoria es

```text
g_t(x)=g_0(x-t d)
```

y no depende de `s_reg` ni del `state` positivo inicial. `s_reg` y `d` se transportan; el state positivo se normaliza a uno tras un tick. Esto no identifica `s_reg` con energía, frecuencia, masa o amplitud.

### Hipótesis L1

Una etiqueta o carga externa, asignada monotónicamente a `s_reg` antes de ver tiempos de llegada, altera sólo la marca y no la velocidad cuando path, medio, dirección, fuente y frontera pertenecen al mismo estrato libre.

### Transformación congelable

Para cada label `j` dentro de la misma fuente/path:

```text
r_j = log(v_j/v_ref)
D_E1 = max_j |r_j|
```

La predicción primaria es `D_E1=0`. Una pendiente contra rank/log-label puede ser secundaria si su transformación se congela. Cuando la emisión absoluta sea desconocida sólo puede usarse una diferencia de llegada normalizada por tiempo de propagación si el lag intrínseco tiene identificación o cota independiente; de otro modo el resultado es INCONCLUSIVE.

Parámetros de calibración admisibles: offsets instrumentales, escala común, covarianza y `epsilon_E1`, todos derivados de metadata/requerimiento científico o calibración separada. No hay parámetro libre de velocidad por label.

### Supuestos críticos

- mismo estrato no interactuante, path y condiciones;
- label no cambia emisión, detección o medio;
- simultaneidad o lag identificable;
- instrument response calibrado fuera del holdout;
- ningún label/bin se excluye por su residual.

### Adjudicación

- PASS: el límite superior simultáneo de `D_E1` está dentro de `epsilon_E1`, la pendiente es equivalente a cero y pasan controles.
- FAIL: el límite inferior excede el margen o aparece una ley de dispersión reproducible fuera de él.
- INCONCLUSIVE: intervalo ancho, lag/medio no identificable, labels faltantes o potencia insuficiente.

### Familias/fuentes candidatas, todavía no consultadas

1. Pulsos fotónicos multibanda/multifrecuencia en vacío controlado; datos crudos y calibración de un experimento primario de tiempo de vuelo.
2. Transitorios fotónicos astronómicos multibanda; light curves/event lists y respuesta instrumental primarias. Riesgo alto de lag intrínseco y medio.
3. Componentes tiempo-frecuencia de señales gravitacionales transitorias; strain primario. Riesgo alto de dependencia del modelo de waveform/fuente.

La opción controlada es la más identificable. Un no-rechazo astronómico sin cota de emisión no puede ser PASS.

## E2 — Igualdad de velocidad entre dos clases en el mismo estrato libre

### Predicción L0 y salto L1

Si A y B son dos marcas de un mismo `K_free` y dirección, `v_A/v_B=1`. Pero el teorema DEE sólo garantiza independencia de state/`s_reg` dentro de semantic normal. No demuestra que dos semantics arbitrarios ni dos especies externas concretas pertenezcan al mismo estrato. Esa equivalencia es la hipótesis Rosetta que E2 pone a prueba.

La pareja debe seleccionarse por preparación y path, nunca porque sus velocidades conocidas coincidan.

### Transformación congelable

Para pares matched:

```text
theta_i = log(v_A,i/v_B,i)
```

La escala longitud/tiempo común cancela. El análisis debe congelar si usa efecto común o modelo jerárquico, heterogeneidad permitida, offset interinstrumental y un modelo de emisión identificable.

No se permite una velocidad base por clase ni un lag libre por evento/clase. Si el lag puede absorber cualquier diferencia, E2 no es falsable con esa fuente.

### Adjudicación

- PASS: intervalo simultáneo de `theta` contenido en `[-epsilon_E2,+epsilon_E2]`, sincronía/control válidos y heterogeneidad dentro del límite.
- FAIL: intervalo fuera del margen o estructura incompatible con un `K_free` común.
- INCONCLUSIVE: lag de emisión no acotado, path no matched, intervalo ancho o asignación al estrato dependiente del outcome.

### Familias/fuentes candidatas, todavía no consultadas

1. Dos polarizaciones o modos fotónicos copropagantes en vacío controlado; timestamps/waveforms primarios. Es limpio, aunque ontológicamente son subclases cercanas.
2. Transitorios coincidentes electromagnéticos y gravitacionales; event data primarios de ambos instrumentos. Son clases distintas, pero el lag de emisión puede impedir identificación.
3. Transitorios coincidentes fotón-neutrino; event lists y metadata temporal primarias. Riesgos: emisión, interacción, path efectivo y selección de coincidencia.

E2 es congelable condicionalmente. Para opciones multimessenger, la cota/modelo de emisión debe quedar fijada antes del holdout; si no existe, el resultado preasignado debe ser INCONCLUSIVE.

## E3 — No-go del embedding lineal euclídeo de D26

Sea

```text
D26 = {-1,0,1}^3 \ {0}.
```

Todos sus elementos tienen velocidad unitaria en norma Chebyshev. Considérese la Rosetta ingenua

```text
x_ext = A x
t_ext = tau t
```

con `A` lineal común, `tau>0`, norma externa euclídea y una velocidad positiva igual para los 26 pasos.

### Teorema de imposibilidad

No existe tal `A` no nulo. Sea `G=A^T A` y supóngase `d^T G d=c>0` para todo `d`.

- Los ejes `e_i` dan `G_ii=c`.
- `e_i+e_j` da `2c+2G_ij=c`, luego `G_ij=-c/2`.
- `e_i-e_j` da `2c-2G_ij=c`, luego `G_ij=+c/2`.

Contradicción. Si `c=0`, `A` anula los tres ejes y es el mapa trivial. El subconjunto ejes+diagonales de cara ya basta; rotación, shear o escala global no ayudan.

### Consecuencia contractual

E3 no necesita datos externos. Es un gate lógico:

- `PASS_NO_GO`: el contrato mantiene D26 + mapa lineal común + Euclídeo + tiempo común; esa clase de Rosetta se rechaza antes del holdout.
- `FAIL_NO_GO`: aparece un contraejemplo algebraicamente válido `A,tau`; bajo los supuestos no se espera.
- `INCONCLUSIVE`: el contrato restringe direcciones o usa geometría/no linealidad distinta; el teorema deja de aplicarse y hace falta un endpoint nuevo.

Escapes lícitos sólo si se congelan explícitamente:

- limitar el puente a una órbita/subconjunto, perdiendo el claim D26;
- usar geometría Chebyshev/Finsler/poliédrica;
- normalización no lineal dependiente de dirección;
- tiempo por dirección, que añade parámetros y viola el diseño actual.

No se puede llamar lineal/euclídeo a una normalización oculta.

Familias que sólo serían relevantes después de definir una evasión: barrido angular controlado de tiempo de vuelo, o catálogo direccional homogéneo de una única señal con selection function conocida. No se verificó ninguna fuente y no deben abrirse para “decidir” qué geometría conviene.

## E4 — Análogo externo de oclusión/fase del observer

### Predicción L0

En el aparato aislado pre-wrap:

```text
baseline: tau_0(k)=k
oclusor inicial en la boca: tau_1(k)=k+1
paridad: opuesta
soporte diferencial raw: H(t)=t
```

Dentro de la clase binaria `{baseline, una oclusión inicial de la boca}`, el retardo unitario coherente y la paridad opuesta identifican la oclusión ya desaparecida. No hay unicidad frente a toda microhistoria.

### Hipótesis L1

Una fuente externa persistentemente activa, con exclusión/refractariedad local y propagación libre, recibe durante una unidad operacional un bloqueador en su boca. Después el bloqueador desaparece. La firma downstream conserva delay+phase.

Esto es un **análogo de mecanismo**. Diseñar un aparato con la misma exclusión y obtener la firma valida transferencia del mecanismo, no que la realidad fundamental sea DEE.

### Transformación congelable

`tau_step` se estima sólo en calibración baseline o desde metadata. Para detectores ordenados sobre el mismo rayo:

```text
D_k = [tau_occ(k)-tau_base(k)] / tau_step
predicción: D_k=1
```

Una regla de binning/event matching congelada define paridad. El clasificador inverso debe etiquetar `occluded` sólo si coexisten delay unitario coherente y fase opuesta. Los trials se randomizan y las etiquetas permanecen ocultas al análisis.

Se congelan además threshold, origen, duración operacional del blocker, tolerancias, máximo detector pre-boundary, false-positive ceiling y potencia. Se prohíbe realinear cada trial, elegir paridad/detectores por outcome o permitir que una marca obvia de amplitud revele directamente la condición.

### Adjudicación

- PASS: delays equivalentes a uno en todos los detectores obligatorios, fase invertida, clasificador sobre el criterio y sham sin firma.
- FAIL: con potencia, delay equivalente a cero/otro valor, ausencia de inversión, incoherencia espacial o fallo del sham.
- INCONCLUSIVE: blocker persiste, altera path/medio, hay ringing/reflexión, `tau_step` inestable o incertidumbre excesiva.

### Familias/fuentes candidatas, todavía no consultadas

1. Tren de pulsos ópticos en guía/línea con shutter transitorio en la boca; waveforms y control logs primarios.
2. Tren acústico en guía con bloqueo transitorio del emisor; señales multichannel y metadata del actuador.
3. Fuente periódica en medio excitable con bloqueo/refractariedad local; imágenes/series primarias.
4. Línea de paquetes con bloqueo de ingreso de un slot; packet traces/logs. Es el análogo discreto más limpio, pero no física fundamental.

E4 debe congelarse y adjudicarse separado de E1/E2.

## Dependencias y stopping rule

```text
resolver rúbrica PA01
        ↓
E3: aceptar no-go o congelar una evasión explícita
        ↓
E1 / E2 paired within-path, sin escala por clase

E4: rama paralela, análogo mecanístico ciego
```

No se abre holdout mientras falte cualquiera de estos elementos:

- fuente primaria exacta;
- margen/potencia fijados fuera del holdout;
- modelo de emisión identificable para fuentes remotas;
- resolución explícita de E3;
- separación del status análogo de E4;
- reconciliación de la rúbrica de selección.

## Fuentes internas leídas

- `EXTERNAL_BLIND_POLICY.md`, SHA-256 `87390cec15d6549d8486f4853b4ec73772652dd78f6d190459c4fc44e7bca7eb`.
- `CORE_CANDIDATE_V1.md`, SHA-256 `1a56e54c80019cac3725d9fb16ee300a18a4f6ab58c97f373f5b448701eae7a5`.
- `RESPONSE_DISCOVERY_REPORT.md`, SHA-256 `e3761d2dbedf04f3fe98b873eda3716ec1de342eb0139d3611dae3581a8dad93`.
- `RESPONSE_DISCOVERY.json`, SHA-256 `17250964ad61f75e6daf03474bfd55b54d3a04b1452de997ee4cef3feb8fac33`.
- `INTERNAL_BRIDGE_SELECTION.json`, SHA-256 `5ed64e641300d3b1699c65eafc39a67746f7b6edc1eb57793618ee84a18f832a`.
- `EXACT_PROOFS.md`, SHA-256 `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.
- T8/T9, SHA-256 `eb4a74b63afe714b6efedee94e318ace82fadd03763eac0c0e00ab60d37c0e92` y `bbc14a60d254d83829680509d1b38185abfa57628b2ef041affb3b6ed801069f`.

No se modificó ni selló ningún contrato y no se consultó evidencia externa.
