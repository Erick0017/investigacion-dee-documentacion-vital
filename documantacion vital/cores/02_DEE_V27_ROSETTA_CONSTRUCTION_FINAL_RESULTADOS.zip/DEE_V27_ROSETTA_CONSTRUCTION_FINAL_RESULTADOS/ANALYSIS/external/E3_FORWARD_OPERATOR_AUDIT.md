# Auditoría del operador forward de E3

## Resultado

La adjudicación original `E3 = FAIL_BRIDGE` fue demasiado fuerte. Se conserva sin modificar el archivo que registró esa adjudicación (`RESULTS/external/e3_e5_results.json`, SHA-256 `46679f082d5444c8744e0f2604a193ef06727db4653cfedc6dde019ff004f691`), pero queda supersedida para la síntesis final por:

`E3_EXTERNAL = INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`.

No se cambió ningún parámetro, no se propuso un mapa alternativo después de ver el dato y no se reinterpretó el teorema interno.

## Qué sí está demostrado

Para una sola aplicación lineal invertible `A` y una sola escala `tau>0`, las 26 velocidades de un paso

`v(d)=||A d||_2/tau`

satisfacen exactamente

`max_d v(d)/min_d v(d) >= sqrt(3)`.

Por tanto, ninguna identificación lineal directa convierte simultáneamente las 26 direcciones Moore en un conjunto euclídeo equivelocidad. Ésta es una obstrucción algebraica de la clase de puente, independiente de Nagel et al.; no es una inferencia desde el kernel hacia un resonador real.

## Qué no quedó especificado antes del holdout

El endpoint extraído de Nagel et al. es un coeficiente de variación relativa de frecuencia de dos resonadores ortogonales durante rotaciones. El contrato no fijó un operador forward que transforme el conjunto discreto `{v(d): d in D26}` en ese coeficiente. En particular no fijó:

1. cómo una orientación continua de cavidad selecciona o compone direcciones de `D26`;
2. la regla de propagación de ida y vuelta y su armónico angular;
3. la orientación desconocida de la retícula respecto del laboratorio;
4. la contribución de longitud de cavidad, sector electrónico y medio que la propia fuente declara;
5. una distribución o coarse-graining para rayos que no coinciden con un vector de Moore.

Sin ese operador no se sigue que la cota sobre `max(v)/min(v)` fuerce el valor observado de `Delta nu/nu`. El criterio congelado decía `FAIL_BRIDGE` sólo si el bound externo forzaba un ratio de velocidades menor que `sqrt(3)`; el endpoint publicado no es por sí solo ese ratio.

## Adjudicación conservadora

- Obstrucción interna de equivelocidad lineal directa: **PROVEN**.
- Comparación E3 con el resonador de Nagel: **INCONCLUSIVE** por operador forward no identificado.
- Geometría emergente, no lineal, Finsler, estocástica o renormalizada: **OPEN**.

Para reabrir E3 habría que preregistrar primero el operador forward completo, sus orientaciones/nuisances y un estadístico observable; sólo después podría consultarse otro holdout óptico no usado.

