# Auditoría de trazabilidad de las búsquedas E4/E5

Los logs preservan fecha, consultas congeladas, criterios, tope por consulta y adjudicación categórica, pero no enumeran cada candidato inspeccionado con título, URL, posición y motivo de exclusión.

Consecuencias:

- `E4=NOT_IDENTIFIABLE` y `E5=NOT_IDENTIFIABLE` siguen siendo adjudicaciones conservadoras: no existe en el paquete un endpoint externo calificante que pueda compararse.
- No se afirma que el universo externo haya sido agotado ni que otra búsqueda reproduciría el mismo ranking.
- La frase auditable es “ningún dataset calificante quedó documentado bajo la búsqueda congelada”, no “se demostró que no existe dataset”.
- Reabrir la búsqueda exige un preregistro nuevo y un registry candidato-por-candidato; no autoriza reetiquetar E4/E5 como FAIL o PASS.

No se repitió la consulta porque hacerlo después de conocer el resultado produciría una búsqueda nueva, no reconstruiría retrospectivamente el ranking original.
