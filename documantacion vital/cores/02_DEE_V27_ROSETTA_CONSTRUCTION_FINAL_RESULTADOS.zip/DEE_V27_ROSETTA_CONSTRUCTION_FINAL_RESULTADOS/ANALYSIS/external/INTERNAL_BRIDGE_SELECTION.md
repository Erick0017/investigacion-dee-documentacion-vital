# Selección interna de candidatos de puente DEE

Raíz autorizada de campaña: `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ROSETTA_CLOSURE`.

## Cortafuegos pre-holdout

Esta selección se hizo **antes de consultar cualquier holdout externo**. No hubo web, navegación, lookup de constantes ni puntuación por acuerdo con datos físicos. Los únicos targets externos nombrados aquí —`alpha/Delta_nu` y `20 Hz`— ya estaban expuestos dentro del corpus histórico; se marcan como contaminados y no se usan para seleccionar candidatos.

El ranking mide una sola cosa: cuán preparado está cada objeto **dentro de DEE** para ser congelado en un protocolo futuro. No mide plausibilidad física.

## Criterio

Cada dimensión vale 0–5: definición operacional, soporte exacto/empírico, identificación por intervención, alcance transversal, reproducibilidad/freeze, independencia del target externo y falsabilidad. Máximo 35.

- `READY_TO_FREEZE`: total ≥30 sin confound fatal.
- `PREPARATORY`: 23–29.
- `NOT_READY`: ≤22 o ausencia de un observable esencial.

## Ranking

| Rango | ID | Sector | Candidato | Score | Estado |
|---:|---|---|---|---:|---|
| 1 | T1 | transporte/respuesta | advección balística y gas restringido | 35 | READY_TO_FREEZE |
| 2 | G1 | geometría/propagación | grafo temporal de dependencia y first-passage | 34 | READY_TO_FREEZE |
| 2 | T2 | transporte/respuesta | álgebra de colisión y balance capado | 34 | READY_TO_FREEZE |
| 2 | I1 | información/estadística | suficiencia raw+clock frente a occupancy | 34 | READY_TO_FREEZE |
| 5 | T3 | transporte/respuesta | observer como fuente/boundary | 33 | READY_TO_FREEZE |
| 6 | I2 | información/estadística | observadores reducidos y eta→D | 27 | PREPARATORY |
| 7 | G2 | geometría/propagación | pseudométrica de accesibilidad dependiente del sustrato | 26 | PREPARATORY |
| 8 | T5 | transporte/respuesta | termodinámica/hidrodinámica efectiva | 19 | NOT_READY |
| 9 | I4 | información/estadística | Koopman/ciclos como quantum | 18 | NOT_READY |
| 10 | I3 | información/estadística | Shannon de occupancy como entropía física | 17 | NOT_READY |
| 11 | T4 | transporte/respuesta | masa/inercia | 15 | NOT_READY |
| 12 | G3 | geometría/propagación | métrica Lorentziana/GR | 11 | NOT_READY |

Los puntajes por dimensión y todos los locators están en el JSON compañero.

## Paquetes seleccionados

### Geometría/propagación: G1 primario, G2 auxiliar

El objeto nativo mejor definido no es una distancia cartesiana física, sino el **grafo temporal de dependencia** sobre raw y clock.

Predicciones internas congelables:

- una salida en `y` requiere a lo sumo raw en `B3(y)` y clocks en `B1(y)`;
- la influencia raw a `t` ticks queda dentro de radio Chebyshev `3t`, con saturación por el diámetro del toro;
- el portador singleton realiza el subsector de frente exactamente `t`;
- first-passage debe condicionarse por rama, semantic, dirección, obstáculos, clock/historia y topología.

G2 agrega evidencia de V7-C de que organización/historia/topología alteran llegada en su aparato, pero conserva sus límites: hotfix documentado, `receiver_reached=.5`, `hidden-before-visible=0` y `external_physics_claimed=false`. No se promueve una pseudométrica de ese aparato a tensor métrico.

Lo que aún falta para un puente físico: coarse-graining, observable de distancia operacional, transformación entre observadores, isotropización cuantificada y mapa dimensional independiente.

### Transporte/respuesta: T1 primario; T2 y T3 discriminantes

T1 es el candidato interno más fuerte porque combina fórmula exacta, dominio explícito y holdout prospectivo v27:

```text
g_t(x) = g_0(x-t d)
rho_hat_m(t+1) = exp(-2 pi i m·d/N) rho_hat_m(t)
v_native = 1 voxel/tick
```

T8 cubre 1,872 trayectorias, 50,544 ticks primarios, 2,704 cocientes Fourier, 26 direcciones, dos tamaños, estados/cargas/clocks, motores y controles, sin mismatch. El gas común requiere separación Chebyshev toroidal por pares `>=3`.

T2 añade respuesta no trivial y falsable:

```text
s_out = min(sum_j s_j, 19664)
d_out = sign(sum_j d_j)
```

Su dominio exige blanco raw-cero, XNOR falso y ausencia de delta overflow adicional para que la salida base sea final. T8 probó 1,300 colisiones, incluidas 52 salidas de dirección cero y 650 saturaciones estrictas. Es un reducer conmutativo/disipativo, no momentum o energía universales.

T3 convierte una condición de frontera controlable en respuesta exacta: semantic 4 fijo con dirección Moore no nula emite, para `1<=t<N`, un tren alternante con `ceil(t/2)` descendientes. T9: 936 casos factoriales, 208 comparaciones de motores, 18 controles de dirección cero y 12,782 ticks, sin mismatch. “Observer” significa fuente/boundary programada, no medición.

Este paquete puede congelar relaciones adimensionales de dispersión, transmisión, saturación y fuente/respuesta. No autoriza masa inercial: velocidad no depende de state/carga y la colisión no pondera dirección por `s_reg`.

### Información/estadística: I1 primario, I2 auxiliar

I1 evita el sesgo histórico más claro. `occupancy=1[state>0]` no es causalmente suficiente: una flecha con state cero o una fase clock distinta puede cambiar el siguiente occupancy conservando la proyección presente. Para un paso, raw `B3` + clock `B1` sí da una manta suficiente exacta.

Un protocolo futuro puede congelar una competencia de observadores con proper scoring:

1. occupancy-only;
2. soporte + etiquetas/dirección/carga;
3. raw completo;
4. raw + fase clock local.

Debe estratificar por mecanismo y usar fibras matched. La evidencia histórica I2 es útil como plantilla, no cierre global: V6-C produjo 64/64 contrajemplos a M0 en estados muestreados; V6-E obtuvo `R²=.73185` para eta→D en holdout `n=24`, mientras modelos sin fibras iguales no prueban cierre.

Nada de esto identifica entropía termodinámica, conciencia, medición cuántica o “materia” por sí mismo.

## Candidatos rechazados por ahora

| Candidato | Razón interna de no selección |
|---|---|
| coincidencias `alpha/Delta_nu/K/966/782/194422/19665/19664` | una cadena constitutiva compartida; no independencia externa |
| `20 Hz` | target histórico ya expuesto y posteriormente reparametrizado |
| factor `E/D` en frecuencia | no soportado en v25.5-C: RMSE `21.0146` frente a cero para `P=L` |
| masa/inercia | no hay fuerza operacional, aceleración o respuesta dependiente de carga |
| hidrodinámica/termodinámica | faltan ensemble, equilibrio local, temperatura, stress y separación de escalas |
| métrica Lorentz/GR | faltan frames, intervalo, isotropización, métrica y ecuaciones de campo |
| Shannon de occupancy | estadístico de una proyección causalmente insuficiente |
| Koopman/ciclo → quantum/Bell | propiedad formal genérica de un sector permutacional; faltan Born, mediciones y settings |

“No seleccionado” no es teorema de imposibilidad ontológica. Significa que el objeto no está listo para consumir un holdout externo.

## Paquete mínimo a congelar después

Se recomiendan tres preregistros separados, para impedir combinarlos post-hoc en un score conveniente:

1. **G1:** first-passage/alcance sobre grafo temporal raw+clock, con controles de mecanismo, topología e historia.
2. **T1+T2+T3:** cinética adimensional de vuelo libre, colisión y fuente/boundary.
3. **I1:** diferencia de riesgo predictivo entre observadores, con proper scoring y fibras causales.

Antes de abrir cualquier dato externo, cada preregistro debe fijar:

- ensemble/preparación DEE;
- observable y operador de medición;
- ecuación y unidades;
- parámetros que se permite calibrar y datos exclusivamente de calibración;
- endpoints externos múltiples aún no vistos;
- incertidumbres, nulos, multiplicidad y criterio de FAIL;
- regla que prohíba reescoger sector/fórmula/target tras el holdout.

`alpha/Delta_nu` y `20 Hz` deben quedar fuera del set confirmatorio primario de esta línea. La pieza faltante sigue siendo una Rosetta operacional dimensional capaz de predecir más grados de libertad externos de los que consume al calibrarse.

## Estado

- Arquitectura interna lista para freeze selectivo: **sí**.
- Rosetta externa lista: **no**.
- Datos externos consultados en esta selección: **ninguno**.
- Física externa afirmada: **ninguna**.
