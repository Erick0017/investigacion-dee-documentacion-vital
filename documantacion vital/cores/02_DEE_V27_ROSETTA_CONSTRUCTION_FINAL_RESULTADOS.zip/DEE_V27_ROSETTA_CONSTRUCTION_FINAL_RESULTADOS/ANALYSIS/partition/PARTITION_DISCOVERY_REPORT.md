# Descubrimiento por particiones: un (M_*) sectorial para DEE v27

Estado: **PASS sectorial / no global**  
Método: prueba sobre E1–E15 y fuente C++ sellada, más enumeración simbólica de las fórmulas E9–E12. No se ejecutó el wheel, no se abrió un holdout y no se ajustó ninguna fórmula a resultados.

## Qué significa “mínimo”

Hay que fijar observable y horizonte. Para un mapa determinista (F), observable (O) y (H>=1), defino la palabra futura

\[
W_H^+(x)=(O(Fx),O(F^2x),\ldots,O(F^Hx)).
\]

Dos microestados son predictivamente equivalentes si (x\sim_Hy\iff W_H^+(x)=W_H^+(y)). El cociente

\[
M_{*,H}=X/\ker(W_H^+)
\]

es la partición predictiva exacta más gruesa: toda estadística que prediga esa palabra debe refinarla. Un candidato (M) es suficiente si `M -> palabra` es función; es mínimo si además `palabra -> M` es función. Éste es el criterio aplicado por el runner simbólico. Excluir (t=0) es deliberado: se busca estado para predecir el futuro, no una codificación trivial de toda la preimagen. Si se observa también el presente, cualquier campo observado en (t=0) debe conservarse.

No existe un (M_*) independiente del observable: packed raw, occupancy, estado completo y un detector local inducen cocientes distintos.

## Cocientes exactos manejables

En esta sección (O(g,c)=g), el raw global empacado, salvo indicación contraria.

| Clase exacta | (M_*) en coordenadas de laboratorio, futuro desde (t=1) | Cociente por traslación | Razón de suficiencia y minimalidad |
|---|---|---|---|
| Singleton E9, `N>=5` | `(q,d,s)` | `(d,s)` | Tras un tick todo `state>0` se normaliza a 1 y queda un raw en `q+d` que contiene `d,s`; de él se recupera `q`. Clocks no entran en esta rama. |
| Gas E10, `N>=5`, `d` común, separación Chebyshev toroidal por pares `>=3` | `(d, μ)`, donde `μ` es el conjunto no etiquetado posición–carga | `(d,[μ])` | El siguiente raw es la traslación de `μ` por `d`, con cada carga y `d` visibles; invertir esa traslación recupera el macroestado. Etiquetas de partículas no existen y los states positivos se normalizan. |
| Colisión E11 de dos fuentes aisladas | `(q,S,u)`, `S=min(s1+s2,19664)`, `u=sign(d1+d2)` | `(S,u)` | El raw de (t=1) contiene exactamente `q,S,u`. Pares microscópicos con el mismo agregado tienen desde allí el mismo futuro: balístico si `u!=0`, vacío después de (t=1) si `u=0`. |
| Pump E12 preparado, `N>=5`, `1<=t<N` | `(q,R_obs)` | `R_obs` | El observer persiste y hace visibles todos los bits de su raw; su dirección genera el tren cerrado. Para el macroestado a lo largo de la órbita pre-cierre se añade la edad `τ`: `(q,R_obs,τ)` o `(R_obs,τ)` módulo traslación. |

Aquí `μ` es una configuración sin etiquetas: permutar nombres de portadores no crea otro estado. En el gas, la dinámica cocientada por traslaciones es identidad; en laboratorio es `μ -> T_d μ`. No se cocientan rotaciones: E14 excluye `O_h` como simetría global, aunque el sector T8 tenga equivariancia restringida.

La edad del pump no es el `clock` de DEE ni tiempo físico. Antes del cierre se reconstruye del raw relativo: el máximo (k) ocupado en el tren es `τ`, o equivalentemente `ceil(τ/2)` más su paridad. Para `τ>=N`, E12 ya no autoriza esa compresión; hay que refinar de nuevo o retener raw completo.

### Pérdida exacta en la colisión

El reducer es una compresión genuina, no sólo un cambio de coordenadas. Los 325 pares no ordenados de direcciones Moore se proyectan sobre 27 valores de `u`: cada `u!=0` tiene 12 preimágenes y `u=0` tiene 13. Además, todas las sumas de carga por encima del cap caen en `S=19664`. Esta no-invertibilidad microscópica coexiste con un futuro macro determinista.

Si el detector omite (t=1), el cociente vuelve a cambiar: en la rama `u=0` la carga `S` ya no es visible desde (t=2). Con occupancy, `S` nunca es visible y las direcciones sólo se distinguen por la trayectoria. Esto es sesgo por observable, no ambigüedad de la ley raw.

## Refinamiento de fuentes fantasma y persistentes

`buscar_fuente_demux` (C++ líneas 187–225) no consulta `state` ni semantic: acepta cualquier raw vecino con dirección decodificada no nula que apunte al blanco. Por tanto un raw normal con `state=0,d!=0` es una **fuente fantasma efímera**; un raw semantic 4 con los mismos `q,d,s,state=0` es una **fuente persistente**, porque la rama observer copia su raw y DEMUX no lo modifica.

Para un dominio dirigido general, el candidato mínimo proyectado es un conjunto de registros

`z=(q,d,s,a,p,o)`,

donde `a=1[state>0]`, `p=1[semantic=4]` y `o=1[state>0 and semantic=5]`. Se puede omitir `o` sólo si el predicado de dominio excluye orphans activos. La evidencia de minimalidad es:

- `q`, `d` y `s` cambian destino, dirección transportada o payload;
- `p` separa exactamente fantasma normal y fuente observer persistente;
- `a` **no** es necesario para un único emisor no observer aislado cuando sólo se observa desde (t=1): `state=0`, 1 y cualquier positivo generan el mismo hijo normalizado;
- `a` **sí** es necesario en una red general: un registro `state=0` puede aceptar una propuesta entrante mediante la rama de vacío mientras envía la suya, pero el mismo raw con `state>0` toma la rama material y puede rechazarla/morir;
- la magnitud positiva de state no es necesaria dentro del cociente proyectado guardado;
- para packed raw, en cambio, la magnitud state de un observer es necesaria porque semantic 4 conserva el raw bit a bit;
- `p` solo no es globalmente lumpable: semantic 5 activo cambia `is_alive_for_rule` y el tratamiento DEMUX, de modo que necesita `o` o exclusión explícita.

El cociente dirigido es exacto sólo bajo este predicado:

1. `N>=5` y toda dirección emisora es Moore no nula;
2. cada destino admitido tiene `state=0` en la preimagen, no es observer y tiene XNOR falso;
3. todo emisor ocupado no observer tiene salida base cero en su sitio fuente;
4. ningún delta overflow posterior modifica un destino admitido;
5. los efectos de orphan activo se excluyen o representan con `o`.

Bajo el subdominio más estrecho de un único emisor aislado, futuro proyectado desde (t=1), queda `(q,d,s,p)` y módulo traslación `(d,s,p)`; `a` cae para el no observer. Fuera de esas guardas, tetra/supervivencia, XNOR, overflow y semánticas especiales rompen la lumpabilidad y se necesita la regla local completa.

## Observador local general con horizonte acotado

Sea (O_y) el raw en un sitio (y) y (B_r(y)) la bola Chebyshev toroidal. E15 más inducción da una representación cilindro universal suficiente para la palabra hasta (H):

- raw inicial en (B_{3H}(y));
- clocks iniciales potencialmente causales en (B_{3H-2}(y)), para `H>=1`.

Los radios se saturan al diámetro toroidal. La recurrencia es `R_{h+1}=R_h+3`; para clocks, `C_1=1` y `C_{h+1}=C_h+3`, luego `C_H=3H-2`. Es una cota causal suficiente, **no** una afirmación de que cada coordenada de esas bolas sea siempre necesaria. Para `H=1`, el radio raw 3 sí es agudo por E3, y occupancy ya está refutado como estado suficiente por E15.

Para predecir sólo raw no hace falta conservar siempre el entero clock completo. El único uso causal del clock es el patrón de gates para `p in {195,260,391,782}`; basta el código acotado

`κ_H(c)[t,p] = 1[((c+t) mod 2^64) mod p = 0]`, `0<=t<H`.

Sin wrap, `c mod 304980` es suficiente, aunque para horizontes cortos `κ_H` es mucho más grueso. La enumeración de los 304,980 residuos produjo 10 schedules distintos para `H=1`, 27 para `H=2` y 297 para `H=8`. Pero `c mod 304980` no basta a través del wrap: `2^64-1` y `290955` tienen el mismo residuo y schedules `H=2` diferentes. Si se observa el clock mismo, `c_y(0)` exacto es necesario por E1.

La partición local realmente mínima sigue siendo `ker(W_H^+)` sobre ese cilindro. La manta elimina exactamente todo lo exterior, y el refinamiento por palabras puede fusionar configuraciones interiores adicionales. Enumerar la partición global completa no es necesario para estos teoremas sectoriales y no se realizó.

Por E4, se puede cocientar conjuntamente `(mundo,y)` por traslaciones y fijar `y=0`. No se puede hacer lo mismo globalmente con rotaciones por E14.

## Auditoría simbólica y testigos

El runner recorrió paneles redundantes y comparó en ambas direcciones clave candidata/palabra futura:

- singleton: 78,000 microestados; 13,000 clases de laboratorio y 104 módulo traslación;
- gas de dos portadores: 86,268 microestados reducidos; 10,920 clases módulo traslación;
- colisión: 41,600 microestados; 108 clases en el alfabeto de cargas del panel;
- pump preparado: 78,000 microestados; 39,000 clases de laboratorio y 312 módulo traslación;
- órbita pump pre-cierre: 1,560 estados `(R_obs,τ)` distintos.

En los siete tests hubo cero fallos de suficiencia y cero fallos de minimalidad: la partición candidata fue exactamente `ker(W_H^+)` dentro de cada panel. Los paneles incluyen clocks `0`/`2^64-1`, states redundantes y cargas que fuerzan colapsos; por ejemplo, clocks distintos quedan en una misma clase singleton, mientras `q,d,s` distintos separan palabras. Esto audita la implementación algebraica del cociente; la prueba genérica procede de la inyectividad del raw siguiente descrita arriba, no de extrapolar frecuencias del panel.

## Alcance del resultado

El resultado identifica una arquitectura transversal restringida: **registros dirigidos -> propuestas por target -> reducer -> persistencia opcional**, con cocientes exactos para transporte, gas, colisión y pump. No es un (M_*) global de (F_{DEE}). En particular:

- no cubre material superviviente, tetra/XNOR, overflow ni active-orphan sin flags/guardas;
- no prueba una hidrodinámica ni una ontología de partícula;
- no convierte edad del pump o clock modular en tiempo físico;
- no autoriza extrapolar el pump después de `t=N-1`;
- para observación local general sólo se ha probado la manta suficiente y la definición exacta por respuesta, no minimalidad coordenada de todas sus celdas.

## Artefactos y hashes

- `ANALYSIS/partition/PARTITION_DISCOVERY.json`: SHA-256 `e0d72e81f993b898369d7f92049e10e3890ba414eb37cbe4db6b0d4c109a0cf4`;
- `DISCOVERY/partition_refinement_discovery.py`: SHA-256 `db6f77572aa520c367cb471cc5b7f03c233cb27c48dcdc3791c25ae32ff81e26`;
- prueba normativa E1–E15: SHA-256 `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`;
- C++ sellado: SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`;
- binario v27: SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

El bloque `directed_transport_analytic_addendum` del JSON se añadió tras la enumeración, por análisis de fuente y de los testigos ya disponibles, sin volver a correr los paneles; el hash del runner embebido sigue coincidiendo con el archivo copiado.
