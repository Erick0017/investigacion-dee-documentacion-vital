# Auditoría adversarial pre-freeze de `M_*: z=(q,d,s,a,p)`

**Estado:** discovery independiente, anterior al freeze. No se ejecutó ningún
holdout y no se selló ningún contrato.

## Dictamen

El cociente de cinco campos **no es globalmente lumpable tal como está
redactado**. Hay dos correcciones obligatorias antes de cualquier freeze:

1. `p=1[semantic==4]` no distingue `semantic=5` (orphan) de las semánticas
   ordinarias. Dos grids con exactamente el mismo `z` producen distinto `z`
   tras un tick.
2. Una dirección decodificada no nula no implica por sí sola una propuesta.
   La fuente sólo se inspecciona desde el halo Moore del blanco. En general la
   condición exacta es local y modular; dentro del sector normalizado
   `d in V_Moore union {0}` se reduce a `d in V_Moore`.

Sí existe un dominio sintáctico suficiente `D_*` en el que el autómata de
propuestas es exacto. En ese dominio, magnitudes positivas de `state` y todas
las semánticas salvo `4/5` pueden canonizarse, pero `q,d,s,a,p` no pueden
eliminarse uniformemente. Para ampliar el dominio de forma certificable hace
falta al menos una marca orphan-activa adicional, o conservar la clase
semántica completa.

El panel pequeño ejecutado contra el wheel extraído terminó con **98 checks,
76 ticks de kernel y 0 mismatches**.

## 1. Hechos estáticos que controlan el cociente

Fuente auditada:
`ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cpp`,
SHA-256 `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.

- `is_alive_for_rule(v)` es `state>0 && semantic!=5` (líneas 126–129).
  Por tanto `a=1[state>0]` no basta para reconstruir actividad de regla cuando
  se admite orphan positivo.
- XNOR usa exclusivamente `is_alive_for_rule` en los trece pares antípodas
  (160–170).
- `buscar_fuente_demux` recorre sólo los 26 vecinos Moore, exige dirección no
  nula y comprueba geométricamente `source+d==target mod N`; no comprueba ni
  `state` ni `semantic` (187–225).
- `semantic=4` retorna antes de toda lógica de vacío/materia y copia el raw
  exactamente (247).
- Un sitio `state=0`, salvo observer, entra en la regla de vacío aunque su raw
  sea no cero; XNOR precede a DEMUX (299–332).
- Un sitio `state>0` no observer retorna cero antes de reloj de fricción y
  overflow cuando `rule_value==0` (338–347).
- `semantic=5` también es especial al aplicar deltas DEMUX, mientras observer
  los rechaza (427–443).
- `demux_edge_min` lee la magnitud de `state`, pero no tiene ninguna llamada
  (173–185). Las demás lecturas dinámicas de `state` sólo distinguen cero de
  positivo; el observer conserva el raw, pero su futuro proyectado sólo
  necesita `a`.

La rama de cristalización no introduce una excepción oculta. Para
`grad=sum(-m*s_m)` sobre los 26 offsets y `0<=s_m<=65535`,

`||grad||_1 <= 15*65535 = 983025`.

La cota se obtiene de
`max_epsilon sum_m max(0,-epsilon dot m)=15` para
`epsilon in {+1,-1}^3`. La guarda exigiría al menos
`19665*floor(9.887^3)=19665*966=18996390`. Por tanto cristalización es
inalcanzable para cualquier raw, con margen superior a 19 veces.

## 2. Contraejemplo de misma entrada `z`

En `N=13` se rodeó un centro vacío con ocho sitios `state=1,d=0,s=0`
dispuestos en cuatro pares antípodas. En el mundo A los ocho tienen
`semantic=1`. En el mundo B se cambia sólo uno a `semantic=5`.

La proyección de entrada es idéntica en ambos mundos porque los ocho registros
tienen el mismo `(q,d,s,a=1,p=0)`. Sin embargo:

- A satisface los trece pares XNOR y tiene ocho vecinos activos: el centro nace
  como `(state=1,semantic=7)`;
- B excluye el orphan de `is_alive_for_rule`: el centro queda raw-cero.

Así, `pi(v_A)=pi(v_B)` pero `pi(F(v_A))!=pi(F(v_B))`. Esto refuta de forma
constructiva la lumpabilidad global de `z=(q,d,s,a,p)`.

La reparación semántica mínima para calcular actividad es conservar

`b = 1[state>0 && semantic!=5]`

además de `a`, o equivalentemente
`h=1[state>0 && semantic==5]`. `a` sigue siendo necesario porque un orphan
positivo bloquea un blanco aun cuando no cuente como activo de regla. Para una
extensión realmente global aún harían falta clock y las ramas de
supervivencia/overflow; añadir `b` sólo repara esta colisión semántica.

## 3. Corrección exacta de la propuesta direccional

Sea `V_Moore={-1,0,1}^3\{0}` y sea `d` la terna decodificada del nibble. Para
`N>=3`, una fuente propone si y sólo si

`u_N(d)=1[d!=0 and exists m in V_Moore: m+d == 0 (mod N)]`.

Cuando el contrato restringe `d` a `V_Moore union {0}`, esto es simplemente
`u_N(d)=1[d in V_Moore]` y el blanco es `q+d mod N`. Para tamaños pequeños,
direcciones decodificadas fuera de Moore pueden aliasar modularmente a un
vecino; por eso la fórmula modular, no `d!=0`, es la afirmación general.

El probe discriminante en `N=13` mostró que `(2,0,0)` con `state=0` y con
`state=1` desaparece sin emitir, mientras el control `(1,0,0),state=0` crea el
hijo esperado. No hace falta agregar un campo `u`: se deriva exactamente de
`(d,N)`, pero sí hay que corregir la transición escrita.

## 4. Predicado suficiente `D_*`

Definiciones sobre el slice de entrada:

- `A(x)=1[state(x)>0 && semantic(x)!=5]`;
- `n(x)` es la suma de `A` en el halo Moore;
- `tetra(x)` es la firma tetraédrica de la fuente;
- `xnor(x)` es la guarda de líneas 160–170;
- observer significa `semantic(x)==4`.

Un predicado **suficiente de un paso** para el autómata reducido corregido es:

1. `N>=3`, buffers válidos y un registro por coordenada raw-no-cero;
2. para todo `x` con `state(x)>0` y no observer,
   `n(x)<=5 && !tetra(x)`;
3. para todo `x` con `state(x)==0` y no observer, `!xnor(x)`;
4. usar `u_N(d)` arriba, o, si se conserva la regla textual original, exigir
   sintácticamente `d in V_Moore union {0}` para todo registro.

La condición 2 es exactamente la condición de muerte base en este rango:
sin tetra, `n<=5` redondea a cero; `n>=6` sobrevive, y una firma tetra con
`n=4` o `5` también sobrevive. No hace falta añadir una guarda de overflow:
2 hace que cada materia no observer retorne antes de generarlo; observers y
vacíos también retornan antes de esa etapa. Tampoco hace falta una guarda de
cristalización por la imposibilidad global demostrada arriba.

### Prueba de suficiencia por ramas

- Observer: conserva su registro y, si `u_N(d)=1`, sigue siendo visible como
  fuente para el cálculo paralelo de propuestas.
- `state=0`, no observer: por 3 no nace vía XNOR; acepta la reducción exacta de
  propuestas si la hay y, si no, se vuelve cero. Su raw previo no bloquea.
- `state>0`, no observer: bloquea propuestas dirigidas a su coordenada en el
  slice de entrada y por 2 se borra antes de fricción/overflow; aun así puede
  haber propuesto a otro blanco porque las propuestas leen el slice de entrada.
- Cero, una o varias fuentes reproducen literalmente las líneas 217–225:
  fuente única transporta `(s,d)`; varias producen
  `s'=min(sum s,19664)` y `d'=sign(sum d)`.

Esto demuestra `pi(F(v))=F_*(pi(v))` para todo `v in D_*` en un tick. Para un
horizonte `T`, la afirmación válida es condicionada a
`v,F(v),...,F^(T-1)(v) in D_*`. **No se demostró que `D_*` sea invariante**;
el freeze debe declarar esta condición de trayectoria o probar una subclase
invariante separada.

### Variante certificable desde el mesoestado

El `D_*` anterior se puede comprobar sobre raw. Si el certificado debe
calcularse sólo desde el mesoestado, hay dos opciones:

- restringir por construcción a ausencia de orphan positivo, de modo que
  `A=a` y las guardas se calculan desde `(q,a)`;
- extender el registro con `b` o `h` y calcular `A=b`.

Excluir todos los `semantic=5` es suficiente pero no mínimo: el panel confirmó
que un orphan con `state=0` propone igual que un normal latente y que, con
`d=0`, es dinámicamente nulo. La distinción orphan se vuelve necesaria al ser
positivo.

## 5. Qué puede y qué no puede canonizarse

| Campo/clase | Dictamen para dinámica proyectada | Límite |
|---|---|---|
| magnitud positiva de `state` | canonizable a `1` | no reconstruye raw ni censo; `a` no se elimina |
| semánticas `0,1,2,3,6,7,8..15` | canonizables a una clase normal | no preserva conteos por semantic |
| `semantic=5,state=0` | canonizable a normal en la dinámica | cristalización es inalcanzable; si `d=0,p=0`, el registro entero puede omitirse |
| `semantic=5,state>0` | **no** canonizable con sólo `p` | excluir o añadir `b/h` |
| `q` | no omitible | fija blancos, colisiones y geometría |
| `d` | no omitible | fija `u_N`, blanco y reducer vectorial |
| `s` | no omitible uniformemente | se transporta, suma y satura; sí es irrelevante para blockers `a=1,d=0` que mueren bajo `D_*` |
| `a` | no omitible | distingue blanco admisible de blocker y cambia conteos de vecinos observers positivos |
| `p` | no omitible | distingue router efímero de bomba persistente y protege el blanco |
| clock | omitible sólo bajo `D_*` | fuera de `D_*`, línea 360 modifica `s` según fase |

Más precisamente, todo registro no observer con `a=0` y `u_N(d)=0` puede
eliminarse del estado predictivo futuro. El caso pedido `state=0,d=0` con sólo
`s_reg` o semantic no persiste, no bloquea una propuesta y no altera la
dinámica. Los blockers activos `d=0` deben conservar presencia/posición y `a`,
pero bajo la muerte garantizada de `D_*` pueden ignorar magnitud de `state`,
`s` y semantic genérica para ese único paso.

## 6. Panel independiente

El runner cubrió:

- contraejemplo normal/orphan de misma `z`;
- semánticas genéricas en router latente, blocker y contexto material que
  sobrevive fuera de `D_*`;
- orphan `state=0` direccional e inerte;
- observers con `state=1,2,2^32-1` y contraste `state=0` en umbral vecinal;
- blancos raw-cero frente a raws `state=0,d=0` con `s_reg/semantic`, incluido
  `semantic=5`;
- blockers activos `d=0` con magnitudes, `s_reg` y semantics distintas;
- interacción fuente-destino: un router latente recibe y emite en el mismo
  slice; un observer emite, persiste y rechaza la entrada;
- dirección no-Moore frente a control Moore.

Resultado: `ADVERSARIAL_DISCOVERY_PASS`, 98 checks, 76 ticks, cero mismatches,
`holdout_executed=false`, `contract_frozen=false`.

## 7. Evidencia reproducible

- Runner: `ROSETTA_CLOSURE/RUNNERS_NEW/response_mstar_adversarial.py`,
  19,003 bytes, SHA-256
  `1191086940f3a8e8a9a9f3e8634e121bd7e1ec16f30721bc939b812c57a15110`.
- Resultado: `ROSETTA_CLOSURE/DISCOVERY/response_mstar_adversarial_results.json`,
  59,093 bytes, SHA-256
  `1ffacd148683c7db185c309fb5eee57ba9f875ccda33162541e2aed03ca0303e`.
- Wheel: SHA-256
  `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- Kernel importado: SHA-256
  `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Runtime: CPython 3.13.11 AMD64, NumPy 2.2.6,
  `D:\Descargas\ANACONDA MINICONDA\python.exe`.

El import fue forzado al árbol local extraído y el runner aborta si cambian
los hashes del wheel, `.pyd` o fuente. Los comandos y salidas están en
`DISCOVERY/response_mstar_adversarial_commands.md`.

