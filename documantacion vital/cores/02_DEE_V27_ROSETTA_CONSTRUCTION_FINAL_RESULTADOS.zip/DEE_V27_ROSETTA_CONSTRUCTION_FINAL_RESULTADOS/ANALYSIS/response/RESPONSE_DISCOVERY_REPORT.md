# Discovery de un núcleo mesoscópico común de respuesta v27

## Resultado

El candidato más pequeño que simultáneamente describe el singleton balístico,
el gas diluido, la fusión direccional y el observer activo es un **autómata
cinético marcado, excluyente y dirigido sobre el toro**, no una métrica escalar
ni un kernel lineal universal.

Propongo provisionalmente, sólo para discovery:

- `M_*`: medida/configuración cinética marcada de portadores y observers;
- `G_*`: hipergrafo causal dirigido en espacio de fase;
- `K_*`: familia estratificada de propagadores libres, kernels de frontera y
vértices locales no lineales.

Esta construcción operacionaliza el estado de propuestas dirigido introducido
en `DISCOVERY/CORE_CANDIDATE_V1.md` y conserva su notación.

El probe discriminante ejecutó 4,809 checks, 178 ticks del binario v27 y obtuvo
**cero mismatches**. No se ejecutó ningún holdout, no se selló contrato y no se
modificó ningún artefacto V1 previo fuera del nuevo subárbol `ROSETTA_CLOSURE`.

## 1. Mesestado candidato `M_*`

Sea `Lambda_N=Z_N^3` y
`V={-1,0,1}^3\{0}`. En el sector normalizado, el estado mínimo útil es una
configuración excluyente de marcas

`z_i=(q_i,d_i,s_i,a_i,p_i)`,

donde `q in Lambda_N`, `d in V union {0}`, `s=s_reg in [0,65535]`,
`a=1[state>0]` es actividad para la regla material y `p=1` marca persistencia
observer. La presencia del registro codifica que hay un raw, aunque `a=0`.
Todo registro con `d!=0` propone a `q+d`, de modo que un normal con
`a=0,p=0,d!=0` es un **router latente**: no cuenta como occupancy viva, pero
sí propone al blanco. Para reconstruir exactamente el raw fijado de un observer
puede conservarse además su palabra raw completa; para predecir su emisión
aislada bastan `d,s,p`.

Una representación equivalente es

`M_*={z_i}_i`, o en campos `(r_t,a_t,u_t(x,d),n_t(x,d),q_t(x,d),p_t)`,

con presencia de registro `r`, actividad `a`, propuesta derivada
`u=1[d!=0]`, ocupación cinética `n`, carga/etiqueta `q` y persistencia observer
`p`. `u` no puede deducirse de `a`: `buscar_fuente_demux` examina dirección y
geometría, pero no exige `state>0`. `n` tampoco puede eliminarse en favor de `q`: existen
portadores con `s_reg=0`. Tampoco puede colapsarse la distribución de velocidades a su suma:
el reducer pierde magnitud por `sign`, su inversa es degenerada y la
composición binaria comprimida no es asociativa. La marca observer es
indispensable porque un raw semantic 4 permanece fijo y emite, mientras un raw
normal con las mismas `d,s` no lo hace.

El clock no entra en este `M_*` porque los cuatro sectores considerados son
clock-independientes. Esto es una factorización sectorial, no global. Fuera de
ella, el estado Markoviano suficiente vuelve a ser raw etiquetado más clock, y
la manta causal puede alcanzar radio Chebyshev 3.

### Dominio exacto de coincidencia

El autómata reducido coincide con v27 a lo largo de configuraciones que no
excitan supervivencia material, XNOR ni overflow y cuyos eventos ocurren sobre
blancos raw-cero. Incluye exactamente:

- singletons normales y gases de dirección común suficientemente separados;
- raws normales direccionales con state 0 durante su normalización de un tick;
- colisiones entrantes aisladas con XNOR falso;
- el observer aislado y su tren pre-wrap;
- el bloqueo transitorio de la boca del observer estudiado aquí.

No se afirma que toda configuración formada con las mismas marcas permanezca
en ese dominio. Ocho entradas simétricas, blancos ocupados, vecindades densas y
overflow activan otras ramas.

### Transición compacta con occupancy nula

Tres mundos pueden tener el mismo campo inicial `1[state>0]=0` y futuros
distintos:

- vacío: `0 -> 0`;
- normal latente: `L(x,d,s) -> C(x+d,d,s)`; `L` se borra y el destino nace con
  state 1/semantic normal;
- observer state 0: `O(x,d,s) -> O(x,d,s)` más una propuesta guardada hacia
  `x+d`.

El probe ejecutó las tres clases para eje, diagonal de cara y diagonal corporal
durante tres ticks. El vacío siguió vacío; el normal latente se convirtió en
un singleton; el observer conservó su raw state 0 y comenzó el tren. Esto da
una explicación operacional transversal de por qué occupancy histórica no es
causalmente suficiente: hacen falta al menos presencia de marca raw, soporte
de propuesta y clase semantic. El bloqueo tampoco equivale a `raw!=0`: dentro
de este núcleo un normal state 0 entra en la rama de vacío, mientras un
observer state 0 se fija por el retorno temprano.

## 2. Geometría dirigida `G_*`

Los nodos libres son pares `(x,d)`. Sus aristas de transporte son

`(x,d) -> (x+d,d)`.

Cada capa de velocidad se descompone en `N^2` ciclos dirigidos de longitud
`N`. Los observers añaden un self-loop fijado y una propuesta recurrente hacia
`x+d`. Las colisiones son hiperaristas

`{(x-d_j,d_j,s_j)}_j -> (x, sign(sum_j d_j), min(sum_j s_j,19664))`.

hipergrafo dependiente del estado cuando se proyecta al espacio: no debe
confundirse con un tensor métrico ni con el simple grafo Moore.
La rama del blanco actúa como guard: `state>0` bloquea el routing vacío y
semantic 4 se fija incluso con state 0; un normal state 0, en cambio, se trata
como vacío. Por ello `G_*` es un hipergrafo dependiente de estado **y semantic**
cuando se proyecta al espacio: no debe confundirse con un tensor métrico ni
con el simple grafo Moore.
hipergrafo dependiente del estado cuando se proyecta al espacio: no debe
confundirse con un tensor métrico ni con el simple grafo Moore.

### First passage libre

Para velocidad fija,

`tau_d(x,y)=t`

si existe el único `t in {0,...,N-1}` tal que `y=x+t*d mod N`; en otro caso es
infinito. En espacio de fase también se exige conservar la misma capa `d`.

En `N=13`, permitiendo elegir una de las 26 velocidades sólo al tiempo inicial,
la unión espacial accesible desde un punto contiene 157 de 2,197 sitios:

- shell 0: 1 sitio;
- shells mínimos 1 a 6: 26 sitios cada uno;
- 2,040 sitios no son alcanzables por ningún vuelo recto de velocidad Moore.

Por tanto la distancia Chebyshev es sólo una envolvente de control si se
autoriza reorientar el portador en cada tick; no es el first passage espontáneo
del sector libre. La geometría causal global de v27 es todavía más amplia por
la ruta overflow de radio 3, pero pertenece fuera de este núcleo cinético.

## 3. Respuesta `K_*`

### Propagador libre

Para ocupación o carga transportada,

`K_free^t((y,d'),(x,d)) = delta[d'=d] delta[y=x+t*d]`.

Es una matriz de permutación y satisface exactamente

`K_free^(t+s)=K_free^t K_free^s`.

El probe verificó simbólicamente 4,394 composiciones en `N=13` y ejecutó
axis/diagonal de cara/diagonal corporal durante siete ticks. Una traslación
inicial de la fuente conservó Hamming 2 entre mundos y una perturbación de
`s_reg` conservó Hamming 1: el transporte libre es neutral/isométrico mientras
se preserve el dominio no interactuante.

Un router normal con state 0 entra en este mismo propagador después de un tick:
`K_latent^1` crea `C(x+d,d,s)` aunque su occupancy inicial sea cero. El
observer state 0 usa la misma propuesta, pero su self-loop semantic 4 la
repite. La diferencia no está en la geometría de la propuesta sino en la
persistencia de la fuente.

### Kernel del observer

Para un observer aislado en `q`, antes del cierre toroidal, la ocupación normal
sobre su rayo es

`K_obs(t,k)=1[1<=k<=t] 1[k congruente t (mod 2)]`,

en `q+k*d`. No es la convolución lineal de una fuente que inyecta cada tick:
la exclusión de la boca produce la alternancia. En variables booleanas de la
línea, la clausura local es

`u_(t+1)(1)=1-u_t(1)`,

`u_(t+1)(k)=u_t(k-1)(1-u_t(k)), k>=2`,

dentro del tren aislado. El kernel fuente-a-detector solo no compone como un
semigrupo lineal; el estado aumentado que conserva la ocupación de la boca sí
es Markoviano.

### Vértice de colisión

El vértice simultáneo es conmutativo en sus fuentes, pero no lineal:

`C({d_j,s_j})=(sign(sum d_j), min(sum s_j,19664))`.

La operación binaria comprimida `d1 odot d2=sign(d1+d2)` no es asociativa. El
mismo multiconjunto

`{(1,0,0),(1,1,0),(-1,0,0)}`

produce `(1,1,0)` si las tres entradas colisionan simultáneamente, pero
`(0,1,0)` si primero se fusionan las dos primeras y el resultado colisiona un
tick después con la tercera. Ambas salidas retienen `s_reg=10`. El binario
reprodujo ambos caminos exactamente.

Esto no contradice el semigrupo de la dinámica completa: `F^(t+s)=F^t o F^s`
en el estado completo. Sí descarta reemplazar los vértices por un monoide
atemporal de direcciones ya comprimidas. `M_*` debe conservar distribución de
velocidades y capa causal hasta resolver el evento simultáneo.

## 4. Estabilidad y susceptibilidad

El núcleo tiene tres regímenes cualitativamente distintos:

1. **Libre:** estabilidad neutral. Las perturbaciones se trasladan sin crecer
   ni decaer en Hamming.
2. **Colisión:** respuesta por tramos. Al cambiar una carga entrante de 200 a
   201 con la otra fija en 100, la salida cambió 300 a 301; sobre el cap,
   `(19664,1)` y `(19664,2)` produjeron ambos 19664. La susceptibilidad finita
   es 1 bajo el cap y 0 en saturación. `sign(sum d)` introduce superficies
   discretas de umbral y pérdida irreversible de información.
3. **Frontera observer:** sensibilidad de fase convectiva. Una perturbación
   local que desaparece tras un tick puede dejar un desfase persistente cuyo
   soporte diferencial crece linealmente, no exponencialmente.

No aparece un único kernel lineal capaz de cubrir los tres regímenes. La forma
común es un semigrupo no lineal con propagadores lineales por estratos y
vértices/bordes guardados.

## 5. Predicciones inversas nuevas de discovery

### I1 — firma de oclusión transitoria del observer

Se colocó un bloqueador normal, state 1 y dirección cero, sólo inicialmente en
`q+d`. Al tick 1 el bloqueador había desaparecido, pero había impedido la
primera emisión. En las tres clases de dirección probadas:

- first passage basal al detector `q+k*d`: `tau(k)=k`;
- first passage bloqueado: `tau_block(k)=k+1`;
- paridad del tren invertida;
- distancia Hamming raw entre mundos al tick `t`: exactamente `t`, para
  `t=1,...,9`.

La inducción del tren muestra que, para el aparato aislado, la fórmula se
extiende a `1<=t<N` y `1<=k<=N-2`. Esta es una predicción inversa condicional:
dentro de la clase de modelos {tren basal, bloqueo único inicial de la boca},
un retardo unitario coherente en todos los detectores y la paridad opuesta
identifican la oclusión ya desaparecida. No se reclama unicidad frente a toda
historia microscópica imaginable.

### I2 — multiplicidad inversa exacta de una colisión binaria

Los 325 pares no ordenados de velocidades Moore se proyectan en sólo 27
direcciones de salida. Cada salida no nula tiene exactamente 12 pares-preimagen
y la salida cero tiene 13. Se verificó en el binario un representante de cada
una de las 27 clases. Observar sólo `d_out` nunca identifica el par entrante;
la inversión correcta es conjuntista. `s_reg` no remedia esto en general y la
saturación aumenta la degeneración.

## 6. Qué queda abierto

- Probar una clase invariante máxima para `M_*`; aquí sólo se caracterizaron
  trayectorias guardadas concretas.
- Incorporar XNOR y overflow como especies/vértices adicionales sin volver el
  modelo equivalente al raw completo.
- Medir límites de escala de densidad, tiempos de primera colisión y posibles
  ecuaciones de Boltzmann discretas. Aún no existe límite hidrodinámico.
- Definir una norma física o calibración externa. Hamming, first passage y
  carga `s_reg` son observables nativos, no unidades SI.
- Diseñar después un contrato confirmatorio independiente. Ningún contrato se
  congela en este informe.

## 7. Evidencia y hashes

- Runner discovery:
  `ROSETTA_CLOSURE/RUNNERS_NEW/response_discovery_probe.py`, 24,265 bytes,
  SHA-256 `1556cce3db15ac193836947a89b94acb6dfb017efb48a11d6d787aed8eb72818`.
- Resultado discovery:
  `ROSETTA_CLOSURE/DISCOVERY/response_discovery_results.json`, 74,215 bytes,
  SHA-256 `2620fc2dcfa4a92c301c5f35a9c4a6c2055c9e81d9509ebc8ccbc96750559f80`.
- Wheel v27 SHA-256:
  `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- Binario importado SHA-256:
  `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Fuente C++ SHA-256:
  `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.
- Pruebas exactas V1, sólo leídas:
  `ANALYSIS/native_theory/EXACT_PROOFS.md`, SHA-256
  `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.
- Resultados T8/T9, sólo leídos: SHA-256
  `eb4a74b63afe714b6efedee94e318ace82fadd03763eac0c0e00ab60d37c0e92`
  y `bbc14a60d254d83829680509d1b38185abfa57628b2ef041affb3b6ed801069f`.
