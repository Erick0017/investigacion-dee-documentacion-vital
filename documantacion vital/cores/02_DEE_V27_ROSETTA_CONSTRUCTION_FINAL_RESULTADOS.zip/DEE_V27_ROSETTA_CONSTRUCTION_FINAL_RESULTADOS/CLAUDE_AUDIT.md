# Auditoría delta de Claude T1–T7 después de la Rosetta

## Base importada, no repetida

La auditoría adversarial completa de Claude permanece en
`DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/FINAL_PACKAGE/CLAUDE_AUDIT.md`, SHA-256
`d45c8fdb6b0e3a0ec663858293d4dee41ac0d44cbd1bd3b3b5e524042de7fe96`.

Este documento no reabre T1–T7 ni repite la campaña V1. Importa sus dictámenes por referencia y registra sólo el delta producido por la construcción Rosetta. La identidad dinámica sigue siendo el wheel v27 SHA-256 `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`, el `.pyd` `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` y el C++ empaquetado `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.

Nuevas evidencias incorporadas:

| Artefacto | SHA-256 | Función epistemológica |
|---|---|---|
| contrato Rosetta congelado | `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157` | fija `M_*`, `G_*`, `K_*`, dominios y holdouts antes del resultado |
| resultado T10 | `a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872` | falsación literal del par representacional congelado |
| resultado T11 | `207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0` | predicción inversa post-freeze confirmada |
| resultado T12 | `8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b` | reparación estado–evento posterior, congelada y confirmada prospectivamente |
| resultados E1/E2 | `b3931e54325b20e83ed2d6259fddd3214d6a55338bf974bae45385d2cd1203e4` | compatibilidad externa no validante |
| resultados E3–E5 originales | `46679f082d5444c8744e0f2604a193ef06727db4653cfedc6dde019ff004f691` | preserva `FAIL_BRIDGE` original de E3 y endpoints E4/E5 no identificables |
| corrección adversarial E3 | `04b3dbab52da68e5b19b066e49521275cdfb3714e64f1836dc17a4de856d5c8a` | supersede E3 externo como inconcluso por forward operator ausente, sin refit |
| genealogía de constantes | `e5b58389853a361b440698a59ed452203492ca52cc06a39f3eb9025539a3eb0e` | dependencia y target leakage de constantes históricas |

## Matriz delta T1–T7

| Tesis | Dictamen V1 importado | Delta Rosetta | Dictamen vigente |
|---|---|---|---|
| T1 — cono `r_Cheb(t)<=t` | `REFUTED`; la cota raw es `r_Cheb(t)<=min(3t,diam_infty(T_N))` y la velocidad tres es aguda donde el diámetro lo permite | En `D_*`, las propuestas Moore del núcleo recorren un paso, pero overflow fue excluido por dominio. Una cota sectorial no repara la afirmación global. | `REFUTED` globalmente; causalidad dirigida sectorial adicional |
| T2 — `clock'=clock+1` | `PROVEN mod 2^64` | `M_*` puede omitir clock sólo mientras no se alcancen gates. T11 pasa perfiles heterogéneos y near-wrap, pero eso demuestra nuisance en ese aparato, no irrelevancia global. | `PROVEN mod 2^64`, sin identificación con tiempo físico |
| T3 — período/redundancia `L` | `CONDITIONAL/SHARPENED`; período raw mínimo `304980` sin wrap, no gauge full-state | T10 reproduce su conflicto bajo ambos perfiles de clock y T11 es invariante a los perfiles congelados. Ninguno convierte la redundancia raw en simetría global. | Sin cambio |
| T4 — ausencia de invariantes rango 0 | `REFUTED` por la familia observer `semantic=4` | La marca `p` resulta necesaria en los testigos de T10. El FAIL de clausura de T10 no elimina los invariantes observer ni establece energía. | `REFUTED`; invariantes sectoriales, no conservación física global |
| T5 — no-inyectividad | `PROVEN para N>=3`, con testigo state 1/2 corregido | T11 añade una degeneración inversa estructurada: 56 subconjuntos de cinco fuentes se agrupan en 8 salidas, 7 preimágenes por salida. T10 es un fallo del diagrama proyectado, no otra prueba de no-inyectividad de `F_DEE`. | `PROVEN para N>=3`; nuevas fibras de colisión sectoriales |
| T6 — traslaciones y `O_h` | `PARTIAL`; traslaciones exactas, `O_h` global falso por tie overflow | T11 presenta histograma perfectamente simétrico en el reducer de diagonales corporales. Es simetría del panel/reducer, compatible con que `O_h` falle globalmente. El teorema `sqrt(3)` obstruye una lectura lineal equivelocidad; E3 óptico no la adjudica por falta de operador forward. | Sin cambio global; simetrías restringidas mejor caracterizadas |
| T7 — Bell/CHSH | `CONDITIONAL; NO INSTANCIADO` | T10/T11 no definen settings, outcomes, estaciones, independencia ni selección. E1–E3 son propagación/anisotropía, no Bell. | Sin cambio: no hay aparato Bell DEE válido |

## T10: falsación del contrato representacional, no de T1–T7

T10 ejecutó literalmente el preregistro SHA-256 `2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f` sobre el wheel v27 sellado. Todas las identidades y controles de motores pasaron y hubo cero fallos de dominio. Sin embargo, H10.1 registró 96 desacuerdos de clausura proyectada y 96 desacuerdos de alineamiento iterado.

El conflicto estaba ya contenido en las dos cláusulas congeladas:

- `M_*` canoniza a `s=0` todo blocker normal activo con `d=0`;
- `G_*` conserva en todo hijo multifuente `s_out=min(sum s_j,19664)`, sin excepción cuando `d_out=0`.

Cuando dos diagonales corporales opuestas colisionan, `G_*` produce dirección cero y carga capada, mientras `M_*(F_DEE X)` aplica la canonización y reporta carga cero. Por tanto la ecuación literal `M_*F_DEE=G_*M_*` del contrato es falsa para esos casos, aun dentro de `D_*`.

Este FAIL no cambia los dictámenes de Claude. No refuta el reducer raw, el transporte, el observer ni la existencia de un cociente reparable; refuta la **representación congelada exacta** y se conserva sin refit. H10.2 mantuvo todos los testigos de campos requeridos/nuisance y H10.3 pasó 1,872 composiciones libres con cero mismatch.

## T11: predicción nueva que sí sobrevivió

T11 fue derivado después del freeze y sellado con SHA-256 `7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888`. Pasó 448 trayectorias y 896 ticks, sin mismatch, fallo de dominio ni error técnico. Para los 56 subconjuntos de cinco de las ocho diagonales corporales:

- la salida fue la mayoría por coordenada;
- las ocho diagonales de salida aparecieron;
- cada salida tuvo exactamente siete preimágenes;
- el resultado fue invariante a los perfiles de carga, state y clock congelados;
- dense/lazy y uno/dos hilos coincidieron en el control.

Esto fortalece T5 sectorialmente y muestra simetría del reducer relevante para T6, pero no valida momentum físico, una interacción externa ni isotropía global.

## Separación v25/v27

Las fuentes v25 recuperadas —`TORUS_MOVING` y v25.5-C/F-189— son antecedentes históricos de transporte axial y `P=L` en preparaciones específicas. No son la autoridad para T1–T7 ni para T10/T11. La transferencia a v27 se sustentó separadamente mediante el wheel v27 real, la fuente empaquetada, T8/T9 y los nuevos runners.

La genealogía documental también atraviesa versiones: `alpha* -> Delta_nu* -> K* -> enteros` describe cómo se construyeron nombres y valores, mientras su función ejecutable se auditó en el C++ v27. Que un literal sobreviva entre versiones no convierte su interpretación física original en teorema. Ninguna conclusión v25 se importa globalmente sin un testigo o prueba v27.

## Delta externo

- E1 y E2 son `COMPATIBLE_NOT_VALIDATING`: los ceros DEE pertenecen a los bounds primarios, pero no identifican etiquetas ni validan DEE.
- E3 externo es `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`; el `FAIL_BRIDGE` original queda preservado como error de adjudicación. La obstrucción algebraica de equivelocidad lineal directa sí sobrevive y no refuta causalidad ni geometría emergente.
- E4 y E5 son `NOT_IDENTIFIABLE` porque faltan datasets que satisfagan los criterios congelados; no son FAIL del kernel.

Ninguno de esos resultados modifica T7 o promueve T1–T6 a física externa.

## Veredicto delta

Los siete dictámenes V1 sobreviven. La Rosetta añade un FAIL importante de precisión —el par literal `M_*`,`G_*` no cierra en colisiones opuestas—, dos PASS prospectivos —mayoría de cinco fuentes y reparación estado–evento— y una autocorrección externa: E3 no tenía un operador forward suficiente. Esta combinación confirma el método adversarial: una arquitectura útil puede producir predicciones nuevas mientras se conservan tanto una representación falsada como una adjudicación analítica corregida, sin convertir ninguna en juicio ontológico global.
