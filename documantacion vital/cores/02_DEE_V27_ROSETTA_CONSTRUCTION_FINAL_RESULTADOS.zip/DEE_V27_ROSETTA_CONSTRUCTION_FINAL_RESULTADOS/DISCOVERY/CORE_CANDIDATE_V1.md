# Discovery candidate: directed proposal state

Status: post-hoc internal discovery, not a frozen claim.

## Candidate state

For a restricted transport domain, map the packed grid to a finite set of causal records

`z_i = (q_i, d_i, s_i, a_i, p_i)`

where `q` is toroidal position, `d` is the decoded direction, `s` is `s_reg`, `a=1[state>0]`, and `p=1[semantic=SEM_OBSERVER]` marks a persistent site. Numeric positive `state`, absolute clock values and the distinction among non-observer semantics are candidate nuisance variables only inside this restricted domain.

The inclusion of records with `a=0,d!=0` is essential: `buscar_fuente_demux` tests direction but not occupancy. Such a raw can emit one directed proposal even though occupancy reports zero. An observer with the same `a=0,d!=0` persists and emits repeatedly. This is a concrete mechanism behind the V1 result that occupancy is not causally sufficient.

## Candidate transition

Each directed record proposes to `q+d`. Observer records persist. A proposal is admitted only when its target had `state=0` and is not protected as an observer in the input slice. One proposal transports `(s,d)` and normalizes the child to `(state=1,semantic=normal)`. Multiple simultaneous proposals use

`s' = min(sum_i s_i,19664)` and `d' = sign(sum_i d_i)`.

This transition is exact only while the source configuration satisfies a syntactic transport-domain predicate: no competing XNOR birth at a proposed empty target, every non-observer occupied source has zero base survival output, and no later overflow delta alters the target. Outside that predicate the full local rule is required.

## Why this may be the Rosetta core

- first-passage and geometry follow from reachability in the proposal graph;
- free transport is the translation subcase;
- collisions are target-wise proposal reduction;
- the observer pump is a persistent proposal source plus target exclusion;
- intervention response is the finite difference of the same transition, not a separately fitted observable;
- history is unnecessary in the exact transport slice but becomes necessary when a projection omits current proposal records or leaves the slice.

The next step is independent partition refinement and then a frozen binary holdout. No external value has been inspected.

