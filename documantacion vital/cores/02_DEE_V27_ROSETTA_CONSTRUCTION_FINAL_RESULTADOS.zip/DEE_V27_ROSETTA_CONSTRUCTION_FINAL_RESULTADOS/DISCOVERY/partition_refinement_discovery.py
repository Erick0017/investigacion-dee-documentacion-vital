#!/usr/bin/env python3
"""Finite symbolic audit of predictive partitions derived from E1--E15.

This is a discovery calculation, not a kernel runner and not a holdout.  It
implements only the closed-form sector laws E9--E12 and finite partition
comparison.  Its purpose is to expose degeneracies and check candidate
minimal statistics on finite, deliberately redundant parameter panels.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
from pathlib import Path
from typing import Hashable, Iterable


UINT64 = 1 << 64
CAP = 19664
PERIODS = (195, 260, 391, 782)
L_RAW = math.lcm(*PERIODS)
DIRS = tuple(
    (x, y, z)
    for x in (-1, 0, 1)
    for y in (-1, 0, 1)
    for z in (-1, 0, 1)
    if (x, y, z) != (0, 0, 0)
)


def add(q: tuple[int, int, int], d: tuple[int, int, int], n: int, scale: int = 1):
    return tuple((q[k] + scale * d[k]) % n for k in range(3))


def torus_cheb(a: tuple[int, int, int], b: tuple[int, int, int], n: int) -> int:
    ds = []
    for k in range(3):
        z = abs(a[k] - b[k]) % n
        ds.append(min(z, n - z))
    return max(ds)


def sign3(v: tuple[int, int, int]):
    return tuple(1 if z > 0 else (-1 if z < 0 else 0) for z in v)


def raw_entry(q, state, sreg, d, sem):
    return (tuple(q), int(state), int(sreg), tuple(d), int(sem))


def config_key(entries: Iterable[tuple]) -> tuple:
    return tuple(sorted(entries))


def translate_config(entries: Iterable[tuple], shift, n: int) -> tuple:
    return config_key(
        raw_entry(add(e[0], shift, n), e[1], e[2], e[3], e[4]) for e in entries
    )


def canonical_translation(entries: Iterable[tuple], n: int) -> tuple:
    """Canonical nonempty configuration modulo common torus translations.

    It is enough to move each occupied position to the origin in turn; the
    lexicographic minimum is invariant under every common translation.
    """
    entries = config_key(entries)
    if not entries:
        return ()
    candidates = []
    for entry in entries:
        q = entry[0]
        shift = tuple((-q[k]) % n for k in range(3))
        candidates.append(translate_config(entries, shift, n))
    return min(candidates)


def jsonable(obj):
    if isinstance(obj, tuple):
        return [jsonable(x) for x in obj]
    if isinstance(obj, list):
        return [jsonable(x) for x in obj]
    if isinstance(obj, dict):
        return {str(k): jsonable(v) for k, v in obj.items()}
    return obj


class PartitionAudit:
    """Check equality between a candidate-key partition and response words."""

    def __init__(self, name: str):
        self.name = name
        self.micro_count = 0
        self.macro_to_signature: dict[Hashable, Hashable] = {}
        self.signature_to_macro: dict[Hashable, Hashable] = {}
        self.class_sizes: dict[Hashable, int] = {}
        self.first_micro: dict[Hashable, Hashable] = {}
        self.collapse_example = None
        self.sufficiency_failures = 0
        self.minimality_failures = 0

    def add(self, micro: Hashable, macro: Hashable, signature: Hashable):
        self.micro_count += 1
        self.class_sizes[macro] = self.class_sizes.get(macro, 0) + 1
        old_sig = self.macro_to_signature.setdefault(macro, signature)
        if old_sig != signature:
            self.sufficiency_failures += 1
        old_macro = self.signature_to_macro.setdefault(signature, macro)
        if old_macro != macro:
            self.minimality_failures += 1
        if macro in self.first_micro:
            if self.collapse_example is None and self.first_micro[macro] != micro:
                self.collapse_example = {
                    "micro_a": jsonable(self.first_micro[macro]),
                    "micro_b": jsonable(micro),
                    "shared_macro": jsonable(macro),
                }
        else:
            self.first_micro[macro] = micro

    def result(self):
        sizes = list(self.class_sizes.values())
        return {
            "name": self.name,
            "microstates_enumerated": self.micro_count,
            "candidate_classes": len(self.macro_to_signature),
            "response_word_classes": len(self.signature_to_macro),
            "candidate_partition_equals_response_partition": (
                self.sufficiency_failures == 0
                and self.minimality_failures == 0
                and len(self.macro_to_signature) == len(self.signature_to_macro)
            ),
            "sufficiency_failures": self.sufficiency_failures,
            "minimality_failures": self.minimality_failures,
            "candidate_class_size_min": min(sizes) if sizes else 0,
            "candidate_class_size_max": max(sizes) if sizes else 0,
            "collapse_example": self.collapse_example,
        }


def singleton_panel():
    n, horizon = 5, 3
    charges = (0, 1, CAP, 65535)
    states = (1, 2, (1 << 32) - 1)
    clock_tags = (0, UINT64 - 1)
    lab = PartitionAudit("singleton_full_raw_lab")
    trans = PartitionAudit("singleton_full_raw_mod_translation")
    for q in itertools.product(range(n), repeat=3):
        for d in DIRS:
            for s in charges:
                for a in states:
                    for clk in clock_tags:
                        micro = (q, a, s, d, clk)
                        word = tuple(
                            config_key((raw_entry(add(q, d, n, t), 1, s, d, 1),))
                            for t in range(1, horizon + 1)
                        )
                        word_t = tuple(canonical_translation(c, n) for c in word)
                        lab.add(micro, (q, d, s), word)
                        trans.add(micro, (d, s), word_t)
    return {
        "N": n,
        "horizon": horizon,
        "charges": charges,
        "input_states": states,
        "clock_tags": clock_tags,
        "lab": lab.result(),
        "translation_quotient": trans.result(),
    }


def gas_panel():
    n, horizon = 6, 3
    origin = (0, 0, 0)
    rels = tuple(
        q for q in itertools.product(range(n), repeat=3)
        if q != origin and torus_cheb(origin, q, n) >= 3
    )
    charges = (0, 1, CAP)
    states = (1, 2)
    clock_tags = (0, UINT64 - 1)
    audit = PartitionAudit("two_carrier_gas_full_raw_mod_translation")
    seen_micro = set()
    for r in rels:
        for d in DIRS:
            for s1 in charges:
                for s2 in charges:
                    for a1 in states:
                        for a2 in states:
                            input_cfg = (
                                raw_entry(origin, a1, s1, d, 1),
                                raw_entry(r, a2, s2, d, 1),
                            )
                            for clk in clock_tags:
                                micro = (canonical_translation(input_cfg, n), clk)
                                if micro in seen_micro:
                                    continue
                                seen_micro.add(micro)
                                normalized = (
                                    raw_entry(origin, 1, s1, d, 1),
                                    raw_entry(r, 1, s2, d, 1),
                                )
                                macro = canonical_translation(normalized, n)
                                word = []
                                for t in range(1, horizon + 1):
                                    out = (
                                        raw_entry(add(origin, d, n, t), 1, s1, d, 1),
                                        raw_entry(add(r, d, n, t), 1, s2, d, 1),
                                    )
                                    word.append(canonical_translation(out, n))
                                audit.add(micro, macro, tuple(word))
    return {
        "N": n,
        "horizon": horizon,
        "relative_positions_tested": len(rels),
        "minimum_pair_distance": 3,
        "charges": charges,
        "input_states": states,
        "clock_tags": clock_tags,
        "translation_quotient": audit.result(),
    }


def collision_panel():
    n, horizon = 5, 3
    charges = (0, 1, CAP, 65535)
    states = (1, 2)
    clock_tags = (0, UINT64 - 1)
    q = (0, 0, 0)
    audit = PartitionAudit("two_source_collision_full_raw_mod_translation")
    inverse_counts = {u: 0 for u in itertools.product((-1, 0, 1), repeat=3)}
    for d1, d2 in itertools.combinations(DIRS, 2):
        inverse_counts[sign3(tuple(d1[k] + d2[k] for k in range(3)))] += 1
    for d1, d2 in itertools.combinations(DIRS, 2):
        u = sign3(tuple(d1[k] + d2[k] for k in range(3)))
        for s1 in charges:
            for s2 in charges:
                total = min(s1 + s2, CAP)
                macro = (total, u)
                for a1 in states:
                    for a2 in states:
                        for clk in clock_tags:
                            micro = (d1, d2, s1, s2, a1, a2, clk)
                            word = []
                            for t in range(1, horizon + 1):
                                if t == 1:
                                    out = (raw_entry(q, 1, total, u, 1),)
                                elif u == (0, 0, 0):
                                    out = ()
                                else:
                                    out = (raw_entry(add(q, u, n, t - 1), 1, total, u, 1),)
                                word.append(canonical_translation(out, n))
                            audit.add(micro, macro, tuple(word))
    return {
        "N": n,
        "horizon": horizon,
        "direction_pairs": math.comb(len(DIRS), 2),
        "charges": charges,
        "input_states": states,
        "clock_tags": clock_tags,
        "aggregate_charge_values_in_panel": sorted({min(a + b, CAP) for a in charges for b in charges}),
        "direction_inverse_multiplicity": {
            str(u): inverse_counts[u] for u in sorted(inverse_counts)
        },
        "direction_inverse_summary": "12 unordered pairs for each nonzero output direction; 13 for zero",
        "translation_quotient": audit.result(),
    }


def pump_config(q, observer_raw, t: int, n: int):
    state, s, d, sem = observer_raw
    entries = [raw_entry(q, state, s, d, sem)]
    for k in range(1, t + 1):
        if (k - t) % 2 == 0:
            entries.append(raw_entry(add(q, d, n, k), 1, s, d, 1))
    return config_key(entries)


def pump_panel():
    n, horizon = 5, 3
    charges = (0, 1, CAP, 65535)
    states = (0, 1, (1 << 32) - 1)
    clock_tags = (0, UINT64 - 1)
    lab = PartitionAudit("observer_pump_initial_full_raw_lab")
    trans = PartitionAudit("observer_pump_initial_full_raw_mod_translation")
    for q in itertools.product(range(n), repeat=3):
        for d in DIRS:
            for s in charges:
                for a in states:
                    observer_raw = (a, s, d, 4)
                    for clk in clock_tags:
                        micro = (q, observer_raw, clk)
                        word = tuple(pump_config(q, observer_raw, t, n) for t in range(1, horizon + 1))
                        word_t = tuple(canonical_translation(c, n) for c in word)
                        lab.add(micro, (q, observer_raw), word)
                        trans.add(micro, observer_raw, word_t)

    orbit = PartitionAudit("observer_pump_orbit_macrostate_mod_translation")
    orbit_horizon = n - 1
    q = (0, 0, 0)
    for d in DIRS:
        for s in charges:
            for a in states:
                observer_raw = (a, s, d, 4)
                for age in range(0, orbit_horizon + 1):
                    current = canonical_translation(pump_config(q, observer_raw, age, n), n)
                    orbit.add((observer_raw, age), (observer_raw, age), current)
    return {
        "N": n,
        "initial_response_horizon": horizon,
        "orbit_age_range": [0, orbit_horizon],
        "charges": charges,
        "observer_states": states,
        "clock_tags": clock_tags,
        "lab": lab.result(),
        "translation_quotient": trans.result(),
        "orbit_macrostate": orbit.result(),
    }


def gate_schedule(c: int, horizon: int):
    return tuple(
        tuple(int((((c + t) % UINT64) % p) == 0) for p in PERIODS)
        for t in range(horizon)
    )


def clock_panel():
    class_counts = {}
    for horizon in (1, 2, 8):
        schedules = {gate_schedule(c, horizon) for c in range(L_RAW)}
        class_counts[str(horizon)] = len(schedules)
    near = UINT64 - 1
    far = near % L_RAW
    return {
        "periods": PERIODS,
        "L_raw": L_RAW,
        "gate_code": "kappa_H(c)[t,p] = 1[((c+t) mod 2^64) mod p = 0]",
        "no_wrap_residues_enumerated": L_RAW,
        "distinct_gate_schedules_by_horizon": class_counts,
        "wrap_counterexample": {
            "near_wrap_clock": near,
            "far_clock_same_mod_L": far,
            "same_mod_L": (near % L_RAW) == (far % L_RAW),
            "H": 2,
            "near_schedule": gate_schedule(near, 2),
            "far_schedule": gate_schedule(far, 2),
            "schedules_equal": gate_schedule(near, 2) == gate_schedule(far, 2),
        },
    }


def build_result(script_path: Path):
    singleton = singleton_panel()
    gas = gas_panel()
    collision = collision_panel()
    pump = pump_panel()
    all_audits = [
        singleton["lab"], singleton["translation_quotient"],
        gas["translation_quotient"], collision["translation_quotient"],
        pump["lab"], pump["translation_quotient"], pump["orbit_macrostate"],
    ]
    return {
        "schema": "dee.rosetta.partition_discovery.v1",
        "status": "PASS" if all(x["candidate_partition_equals_response_partition"] for x in all_audits) else "FAIL",
        "mode": "symbolic_discovery_from_E9_E12_no_kernel_execution",
        "normative_dependencies": {
            "exact_proofs_sha256": "f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609",
            "kernel_pyd_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
            "cpp_sha256": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
        },
        "definition": {
            "future_word": "W_H^+(x)=(O(Fx),...,O(F^H x))",
            "predictive_equivalence": "x ~_H y iff W_H^+(x)=W_H^+(y)",
            "minimal_partition": "ker(W_H^+), the unique coarsest exact H-step predictive partition",
            "candidate_check": "candidate key is sufficient iff key->word; it is minimal iff word->key",
        },
        "panels": {
            "singleton": singleton,
            "gas": gas,
            "collision": collision,
            "observer_pump": pump,
            "clock_phase": clock_panel(),
        },
        "bounded_local_blanket": {
            "raw_only_H_ge_1": "g restricted to B_{3H}(y), clock gate codes restricted to B_{3H-2}(y)",
            "clock_code": "kappa_H; exact c_y is additionally required if the clock itself is observed",
            "status": "universal sufficient cylinder from E15 by induction; not asserted coordinate-minimal",
            "translation_quotient": "translate the world and target y jointly, then set y=0 using E4",
        },
        "limits": [
            "Finite panels audit algebra and degeneracies; generic minimality claims are proved from the closed-form maps, not inferred statistically.",
            "Observer-pump age macrostate is asserted only before toroidal closure, t<N.",
            "The gas class requires common Moore direction and pairwise toroidal Chebyshev separation at least 3.",
            "Collision aggregate applies only to a raw-zero target with XNOR false and no later overflow delta for the final output.",
            "No global minimal quotient of the full DEE state space is claimed.",
        ],
        "runner_sha256": hashlib.sha256(script_path.read_bytes()).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    script_path = Path(__file__).resolve()
    result = build_result(script_path)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=False) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "output": str(args.output.resolve()),
        "runner_sha256": result["runner_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
