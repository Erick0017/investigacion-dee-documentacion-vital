# Teoremas exactos — addendum Rosetta para DEE v27

Estado: **addendum deductivo y de holdouts internos; alcance sectorial explícito**.

Este archivo no sustituye las pruebas V1 ni modifica un resultado congelado. Se usan cuatro etiquetas epistemológicas:

- **GENÉRICO-ESTÁTICO**: teorema matemático que vale para cualquier sistema determinista bajo el dominio indicado;
- **DEE-ESTÁTICO**: consecuencia exacta de la fuente sellada y de E1–E15;
- **TESTIGO-BINARIO**: ejecución del `.pyd` v27 sellado que comprueba casos concretos;
- **POST-HOC-CONGELADO**: formulación nacida después del FAIL T10, sellada antes de T12; no puede reinterpretar T10 como PASS.

## Importación normativa de E1–E15

Se importan íntegramente, con sus dominios, demostraciones y caveats, las pruebas de `ANALYSIS/native_theory/EXACT_PROOFS.md` de V1, SHA-256:

`f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609`.

La identidad normativa asociada es:

- wheel v27: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`;
- `.pyd` importado: `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`;
- C++ empaquetado: `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`.

La importación comprende explícitamente:

| ID | Resultado importado |
|---|---|
| E1 | dinámica exacta del clock y forma skew-product |
| E2 | cociente de fase raw y período mínimo causal |
| E3 | cono causal raw de radio máximo tres y agudeza donde el diámetro lo permite |
| E4 | equivariancia por traslación y equivalencia de motores en invocaciones válidas |
| E5 | inalcanzabilidad de la cristalización por gradiente |
| E6 | esqueleto booleano de la actualización base antes de DEMUX |
| E7 | no-inyectividad global para `N>=3` |
| E8 | subcampo observer fijo e invariantes aditivos de rango cero |
| E9 | sector balístico singleton para `N>=5` |
| E10 | gas no interactuante restringido y reversibilidad sectorial |
| E11 | álgebra exacta de colisiones entrantes |
| E12 | observer como boundary/source activo antes del cierre toroidal |
| E13 | familia densa de raws fijos |
| E14 | simetría exacta de traslaciones y obstrucción global a `O_h` |
| E15 | manta causal suficiente y contraejemplos a occupancy como estado suficiente |

No se repiten aquí sus pruebas. Sus restricciones forman parte de la importación; en particular, todos los enunciados sobre `F_DEE` presuponen la invocación ABI válida y los buffers disjuntos definidos en el documento hasheado.

## R1 — cociente predictivo universal

**Tipo:** GENÉRICO-ESTÁTICO.

Sea `F:X->X` determinista, sea `O:X->Y` un observable y sea `H>=1`. En cualquier dominio `D subseteq X` sobre el que estén definidas las primeras `H` iteraciones, defínase

`W_H^+(x)=(O(Fx),O(F^2x),...,O(F^H x))`

y

`x ~_H y  iff  W_H^+(x)=W_H^+(y)`.

Entonces `M_{*,H}=D/ker(W_H^+)` es la partición exacta más gruesa que predice la palabra futura. Más precisamente, si una estadística `T:D->S` es suficiente, es decir, existe `h` con `W_H^+=h o T`, entonces

`ker(T) subseteq ker(W_H^+)`.

Por tanto toda estadística suficiente refina `M_{*,H}`. Un candidato `M` induce exactamente el cociente mínimo si y sólo si `M` determina la palabra y la palabra determina `M`.

**Demostración.** Si `T(x)=T(y)`, entonces `W_H^+(x)=h(T(x))=h(T(y))=W_H^+(y)`, que prueba la inclusión de kernels. La relación definida por igualdad de palabras es una equivalencia y la palabra es constante, e inyectiva entre clases distintas, en el cociente. Unicidad salvo renombrado de clases sigue inmediatamente.

**Alcance.** El teorema exige fijar `D`, `O` y `H`; no existe un `M_*` universal independiente del observable. Excluir `t=0` es esencial: incluir el presente obliga a conservar cada campo presente que `O` lea.

## R2 — condición modular exacta de propuesta DEE

**Tipo:** DEE-ESTÁTICO; fuente C++ sellada, función `buscar_fuente_demux`, y E11.

Sea `q in Z_N^3` el target actualizado y sea

`D26={-1,0,1}^3 \ {(0,0,0)}`.

Para cada entrada de scan `r in D26`, el kernel lee el raw en

`x = q+r (mod N)`.

Si `d(x)` es su dirección decodificada, esa entrada aporta una propuesta a `q` exactamente cuando

`d(x) != 0` y `x+d(x) = q (mod N)`,

o equivalentemente `d(x) = -r (mod N)` coordenada a coordenada. El predicado no consulta `state` ni `semantic`; por ello admite routers normales con `state=0` y observers persistentes, además de carriers activos.

En `D_*`, donde `N>=5` y las direcciones decodificadas están restringidas a cero o `D26`, la congruencia implica la igualdad entera única `d(x)=-r`. Así, cada fuente admitida propone una sola vez. Fuera de ese dominio, la forma modular y la multiplicidad por entradas del scan —no una identificación informal `d in D26`— son el enunciado exacto, especialmente en toros pequeños o para direcciones int4 no Moore.

Si el target alcanza la rama de routing —raw de target con `state=0`, no observer y XNOR falso—, cero propuestas producen vacío; una propuesta conserva el raw de la fuente antes del reempaquetado normal; y `k>1` propuestas producen por E11

`u=sign(sum_j d_j)`, `S=min(sum_j s_j,19664)`

con `state=1` y `semantic=1`. Un delta overflow posterior debe excluirse o modelarse para identificar ese valor base con el output final.

**Alcance.** La condición caracteriza la admisión al reducer. No afirma que todo target ejecute esa rama ni que el registro fuente sobreviva en su propia posición.

## R3 — contraejemplo exacto al cierre congelado `M_*/G_*`

**Tipo:** DEE-ESTÁTICO más TESTIGO-BINARIO T10.

Considérese, dentro del `D_*` congelado, un target abierto `q` y dos fuentes aisladas con direcciones opuestas `d` y `-d`, apuntadas simultáneamente a `q`. Sea

`S=min(s_1+s_2,19664)>0`.

Por E11, el raw hijo inmediato es `(state=1,s=S,d=0,semantic=1)`. Sin embargo, las dos cláusulas congeladas codifican ese mismo hijo de forma distinta:

- `M_*` canonicaliza todo blocker activo no observer con `d=0` como `C(q,0,0,1,0)`;
- `G_*` aplica literalmente el reducer multi-source sin excepción `d_out=0`, y entrega `C(q,0,S,1,0)`.

Luego

`M_*(F_DEE X) != G_*(M_*X)`

siempre que `S>0`. Éste es un contraejemplo exacto a la afirmación universal de cierre del par congelado. El raw transitorio sí contiene `S`; la discrepancia está en mezclar una representación de estado futuro canónica con un registro instantáneo de evento.

**Testigo binario.** T10 (`t10_result.json`, SHA-256 `a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872`) ejecutó completamente 1,389 trayectorias y 5,598 ticks primarios con identidad exacta y cero fallos de dominio. La clase fallida fue exhaustiva dentro de su panel B: cuatro pares corporales opuestos × cuatro perfiles de state × tres perfiles de carga × dos perfiles de clock = 96 trayectorias. Produjo 96 mismatches de cierre y 96 de alineación iterada. H10.1 fue FAIL; H10.2 y H10.3 fueron PASS. No hubo refit.

**Alcance.** Esto preserva T10 como FAIL y no refuta la regla raw E11, los testigos de campos de H10.2 ni el semigrupo libre de H10.3. Tampoco autoriza declarar arreglado el contrato original.

## R4 — obstrucción lineal euclídea mínima `sqrt(3)`

**Tipo:** GENÉRICO-ESTÁTICO aplicado al alfabeto direccional DEE `D26`.

Sea `A in GL(3,R)` una única incrustación lineal de las coordenadas crudas y sea `tau>0` una única escala temporal. Para

`v(d)=||A d||_2/tau`, `d in D26`,

se cumple

`max_{d in D26} v(d) / min_{d in D26} v(d) >= sqrt(3)`.

**Demostración.** Escriba las columnas de `A` como `a_1,a_2,a_3` y `R=sum_i ||a_i||^2`. El promedio de `||epsilon_1 a_1+epsilon_2 a_2+epsilon_3 a_3||^2` sobre las ocho elecciones `epsilon_i in {-1,+1}` es `R`; por tanto alguna diagonal corporal tiene norma al menos `sqrt(R)`. Como las tres direcciones axiales pertenecen a `D26`, el mínimo sobre `D26` es a lo sumo `min_i ||a_i||`, y éste es a lo sumo `sqrt(R/3)`. La escala `tau` cancela, dando el cociente `>=sqrt(3)`. Para `A=lambda Q`, con `lambda>0` y `Q` ortogonal, el mínimo es `lambda/tau` y el máximo `sqrt(3)lambda/tau`, así que la cota se alcanza.

**Alcance.** Ninguna única transformación lineal invertible y ninguna escala común hacen iguales las 26 velocidades. El teorema no excluye una geometría emergente no lineal, Finsler, estocástica o renormalizada; sólo cierra el puente euclídeo lineal directo declarado.

## R5 — multiplicidad inversa T11: ocho fibras de siete

**Tipo:** GENÉRICO-ESTÁTICO para la combinatoria, DEE-ESTÁTICO por E11 y TESTIGO-BINARIO T11.

Sea `B8={-1,+1}^3`. Para cada subconjunto no ordenado `S subset B8` con `|S|=5`, defínase

`u(S)=sign(sum_{d in S} d)`.

Cada coordenada de la suma de cinco signos es impar, de modo que `u(S) in B8`. Hay `C(8,5)=56` subconjuntos. El grupo de cambios independientes de signo en los tres ejes actúa biyectivamente sobre los subconjuntos y transitivamente sobre los ocho valores de salida, conservando el tamaño de cada fibra. Por tanto todas las fibras tienen la misma cardinalidad y

`|u^{-1}(b)|=56/8=7` para todo `b in B8`.

E11 añade la predicción DEE `d_out=u(S)` y `s_out=min(sum s_j,19664)` en el target abierto. Las cargas no ponderan la dirección.

**Testigo binario.** T11 (`t11_result.json`, SHA-256 `207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0`) fue una predicción post-freeze sin refit: 448/448 trayectorias y 896/896 ticks exactos, cero mismatches, cero errores técnicos, ocho outputs y siete subconjuntos únicos por output; 4/4 controles de motor pasaron. Los perfiles de state/clock fueron operacionalizados literalmente antes de abrir la salida y dieron cero fallos de invariancia raw en 224 grupos.

**Alcance.** Es una ley exacta del panel de cinco fuentes y del reducer E11, no una regla de momentum físico ni evidencia de una interacción externa.

## R6 — transductor estado–evento `G_dagger/J_dagger`

**Tipo:** POST-HOC-CONGELADO y DEE-ESTÁTICO bajo `D_*`.

Identidad del contrato: `HOLDOUTS/POST_T10_REPAIR_CONTRACT.json`, SHA-256 `b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f`, estado `FROZEN_POST_T10_PRE_T12`. El preregistro prospectivo asociado T12 tiene SHA-256 `ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f`.

Para cada reducción multi-source en un target `q`, defínanse primero las variables del evento raw

`u=sign(sum_j d_j)`, `S=min(sum_j s_j,19664)`

y el readout de transición

`J_dagger({d_j,s_j})=(q,u,S)`.

Sea `G_raw` la transición que forma el hijo raw `(state=1,s=S,d=u,semantic=1)`. Defínase

`canon(q,u,S) = C(q,u,S,1,0)` si `u!=0`,

`canon(q,0,S) = C(q,0,0,1,0)` si `u=0`,

y aplíquese `G_dagger=canon o G_raw` a cada hijo recién reducido, dejando sin cambio las restantes cláusulas del autómata sparse congelado.

**Teorema estado–evento.** Para cada slice de entrada que satisface `D_*`, la rama multi-source satisface simultáneamente:

1. el raw inmediato implementa exactamente `J_dagger=(q,u,S)` por E11;
2. su estado predictivo proyectado es exactamente `canon(q,u,S)`, por la definición congelada de `M_*`;
3. si `u=0`, la carga `S` permanece observable en el evento raw, pero no habilita propuesta y no influye en el siguiente estado dentro de `D_*`; el blocker muere en su actualización base, aunque su bit `a=1` conserva correctamente el cierre del target durante ese slice;
4. si `u!=0`, el estado conserva `S,u` y la propuesta siguiente lo transporta a `q+u` salvo otra interacción ya representada por el conjunto de propuestas y targets cerrados;
5. en consecuencia, al separar estado de evento, la cláusula reparada cumple `M_*(F_DEE X)=G_dagger(M_*X)` en la dinámica sparse declarada, sin borrar del registro de evento la carga transitoria de las colisiones con salida cero.

**Demostración estática.** `D_*` impone `N>=5`, direcciones cero/Moore, a lo sumo siete sitios state-positivos y a lo sumo tres vecinos state-positivos alrededor de cada positivo no-observer. Con ello no se alcanza XNOR, tetra/supervivencia ni overflow en las ramas proyectadas; observers se copian por E8. R2 enumera todas las propuestas y E11 fija de forma única `u,S` y el raw hijo. Aplicar la canonicalización que ya define `M_*` da los dos casos anteriores. Para `u=0`, el hijo no propone y, con menos de cuatro vecinos positivos, su regla material base es muerte; `s` no entra en una rama ulterior. Para `u!=0`, R2 conserva la propuesta `(u,S)`. Las demás cláusulas —persistencia observer, rechazo en target cerrado, emisor normal que no persiste y vacío— coinciden con las ramas exactas importadas.

**Testigo binario prospectivo.** Después del sello, T12 ejecutó una sola vez aridades nuevas 3/4/6 en `N=19`: 748 trayectorias, 1,496 ticks primarios, 514 casos `u=0`, 234 controles `u!=0`, cero fallos de dominio y cero mismatches. Pasaron cierre en ticks 1/2, `J_dagger` raw, muerte/traslación y 16/16 controles de motor. Resultado SHA-256 `8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b`. Este PASS es prospectivo sólo respecto de la hipótesis posterior; la prueba estática anterior no depende de frecuencias del panel.

**Alcance y orden epistémico.** El teorema fue seleccionado después de observar T10 y no cambia su veredicto. No modifica `F_DEE`, no afirma cierre fuera de `D_*` y no identifica `J_dagger`, `s_reg` o direction con energía o momentum. El contrato/preregistro T12 fueron sellados antes de crear el runner y permanecieron inmutables.

## Matriz de cierre lógico

| Resultado | Demostración estática | Testigo binario | Dominio máximo afirmado |
|---|---|---|---|
| `ker(W_H^+)` es el cociente predictivo mínimo | sí, genérica | no necesario | `D,O,H` fijados |
| condición modular de propuesta | sí, fuente sellada | heredado de los probes E11/T8–T11 | ABI válida; simplificación única en `D_*` |
| inconsistencia de `M_*/G_*` para `d_out=0,S>0` | sí | T10 FAIL, 96 casos de cierre | subclase opuesta del panel sparse; basta para refutar cierre universal congelado |
| ratio lineal euclídeo `>=sqrt(3)` | sí | no necesario | una `A` lineal invertible y una escala común sobre `D26` |
| multiplicidad inversa `8×7` | sí, combinatoria | T11 PASS | subconjuntos de cinco de `B8`, reducer E11 |
| transductor `G_dagger/J_dagger` | sí, post-hoc | T12 PASS, 748/1,496, cero mismatch | `D_*` congelado; no global |

Nada en este addendum convierte las propiedades exactas de `F_DEE` en leyes físicas externas. Los puentes físicos siguen siendo hipótesis condicionadas a una transformación operacional independiente.
