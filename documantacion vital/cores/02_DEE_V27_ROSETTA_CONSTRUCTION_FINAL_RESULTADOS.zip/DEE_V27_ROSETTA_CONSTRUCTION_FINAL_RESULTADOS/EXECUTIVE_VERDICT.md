# Veredicto ejecutivo — Rosetta DEE v27

## Resultado principal

**`ROSETTA_PARTIAL`.** Se construyó una Rosetta operacional interna: `X -> M_* -> Z -> (G_dagger,J_dagger) -> K_dagger/O_s`. El objeto unificador es un transductor cinético dirigido con estado predictivo y eventos separados.

La formulación original no pasó íntegra: T10 permanece **FAIL** por 96 colisiones opuestas y 96 desalineaciones derivadas. La reparación fue declarada post-hoc, congelada de nuevo y T12 pasó 748 trayectorias/1,496 ticks nuevos con cero mismatches. T11 pasó independientemente 448 trayectorias/896 ticks y la multiplicidad inversa `8×7`.

Externamente, E1/E2 son `COMPATIBLE_NOT_VALIDATING`; E3 queda `INCONCLUSIVE` porque faltó congelar el operador forward del conjunto discreto de velocidades al observable de resonador; E4/E5 son `NOT_IDENTIFIABLE`. Independientemente del dato óptico, el teorema `sqrt(3)` obstruye la equivelocidad de las 26 direcciones bajo una sola identificación lineal directa. No existe aún una Rosetta física validada ni una escala dimensional.

## Respuestas centrales

| Pregunta | Adjudicación |
|---|---|
| ¿Arquitectura transversal específica? | Sí: registros `L/C/O`, propuestas, guards, reducer, persistencia, estado canónico, eventos `J` y respuesta condicionada `K`. |
| ¿Conjunto pequeño de objetos? | Sí, dentro de `D_*`. T10 mostró que hacen falta dos tipos de salida: estado futuro y evento presente. |
| ¿Conservaciones? | Clock-differences y raws observer globales; número/dirección/carga/patrón en vuelo libre; suma de `s` sólo en el evento antes del cap. No energía/momentum globales. |
| ¿Modos colectivos? | Sí: modos Fourier de advección, gases rígidos y tren observer alternante pre-wrap. Son sectoriales. |
| ¿Materia DEE? | Linajes causales de portadores `C`; no occupancy. `L` es routing latente, `O` frontera/fuente y fases densas son otras clases. |
| ¿Geometría/causalidad? | Hipergrafo dirigido de espacio de fase y first-passage condicionado; cono raw global <=3t. Una sola aplicación lineal no hace equiveloces las 26 direcciones; el contraste óptico E3 quedó inconcluso por falta de operador forward. |
| ¿Clock? | Contador modular y fase de gates; eliminable en `D_*`; no tiempo SI. |
| ¿`s_reg`? | Etiqueta/carga de evento transportada, sumada y capada; otras funciones contextuales fuera del núcleo. No masa/energía universal. |
| ¿`direction`? | Routing, velocidad libre y reducer por signo; no momentum ponderado. |
| ¿semantic? | Selector de ramas: persistencia observer y actividad orphan son causalmente especiales; no especie física demostrada. |
| ¿raw? | Campo computacional causal packed; incluye fuentes state-zero y eventos que un estado predictivo mínimo puede descartar. El estado Markoviano completo es `(raw,clock)`. |
| ¿Rosetta física cuantitativa no arbitraria? | Interna sí; externa no. No se identificaron escalas ni mapas de preparación/medición. |
| ¿Teoría efectiva conocida? | Cinética discreta de advección–exclusión–coagulación con fuente/eventos. No se derivó una teoría fundamental conocida. |
| ¿Masa/inercia? | No identificada; velocidad es independiente de state/s y la colisión no pondera dirección por s. |
| ¿Materia–geometría? | `Z` cambia guards/aristas y por ello la respuesta; no hay curvatura ni equivalencia gravitatoria derivadas. |
| ¿Termo/hidro? | No identificadas. Faltan ensemble, equilibrio, temperatura, energía, stress y límite de escala. |
| ¿Quantum/Bell? | No identificados. Faltan settings/outcomes/independencia/factorización operacional y regla Born. |
| ¿Simetrías/gauge? | Traslaciones exactas; `O_h` global falso por tie DEMUX; gauge físico no identificado. |
| ¿Constantes? | La mayoría histórica forma una cadena constitutiva compartida; 966 es inerte, 782/19665/19664 son causales internos, 20 Hz está contaminado. |
| ¿Descubrimiento nuevo? | Sí: fuentes state-zero, observer como fuente, geometría de fase, T11 7-a-1 y, decisivamente, la separación estado–evento revelada por T10 y confirmada por T12. |

## Claude T1–T7

El cierre V1 permanece vigente y no fue repetido:

| Tesis | Resultado v27 |
|---|---|
| T1 cono radio 1 | **REFUTED**: `r_Cheb(t)<=min(3t,diam_infty(T_N))`; velocidad tres aguda donde el toro la admite. |
| T2 evolución clock | **PROVEN módulo `2^64`**; la forma entera exige no-wrap. |
| T3 período clock/raw | **CONDITIONAL y afinado**: mínimo causal raw 304,980 sin wrap. |
| T4 ausencia de invariantes rango 0 | **REFUTED** por la familia observer. |
| T5 no-inyectividad | **PROVEN para `N>=3`** con testigo state 1/2; la justificación más fuerte histórica era falsa. |
| T6 simetría | **PARTIAL**: traslaciones sí; `O_h` global no. |
| T7 Bell/CHSH | **CONDICIONAL / no instanciado**: falta el aparato operacional. |

## Pieza exacta faltante bajo `H_DEE`

Un mapa independiente y falsable que conecte preparaciones físicas con ensembles `X/Z`, y eventos/historias `Z,J` con resultados de detectores, junto con un coarse-graining que derive geometría aproximadamente Lorentziana y escalas comunes. Ese mapa debe calibrarse en datos separados y predecir al menos dos familias externas nuevas. El kernel solo no puede seleccionar esa correspondencia.
