# E1 — Fermi GRB 090510: nondispersión respecto a etiqueta

## Control de apertura

- Holdout: `E1_LABEL_NONDISPERSION`.
- Contrato leído antes de abrir la fuente: `HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json`.
- SHA-256 esperado y observado del contrato: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157` (`match=true`).
- La fuente se abrió después del sellado. No se cambió el observable, la transformación, los nuisances ni el criterio de adjudicación.
- Sólo se usó como evidencia el análisis primario congelado de Fermi; no se incorporaron valores de artículos secundarios.

## Fuente primaria congelada

La publicación congelada es A. A. Abdo et al. (Fermi GBM/LAT Collaborations), **“A limit on the variation of the speed of light arising from quantum gravity effects”**, *Nature* **462**, 331–334 (2009).

- DOI: https://doi.org/10.1038/nature08574
- Página primaria de la revista: https://www.nature.com/articles/nature08574
- Manuscrito primario de los autores: https://arxiv.org/abs/0908.1832
- PDF del manuscrito: https://arxiv.org/pdf/0908.1832
- Recibido: 2009-08-12.
- Aceptado: 2009-10-12.
- Publicado en línea: 2009-10-28.
- Fecha del número: 2009-11-19.

El manuscrito de arXiv lleva el título anterior **“Testing Einstein’s special relativity with Fermi’s short hard gamma-ray burst GRB090510”**, pero corresponde al mismo análisis primario y remite a la publicación de Nature.

## Valores extraídos

- Evento: GRB 090510; trigger Fermi GBM `T0 = 00:22:59.97 UT` del 2009-05-10.
- Redshift medido: `z = 0.903 ± 0.003`. Para todos los límites de LIV la colaboración fijó conservadoramente el límite inferior de 1 sigma, `z = 0.900`.
- Fotón de mayor energía: aproximadamente `31 GeV`, con llegada en `T0 + 0.829 s`. Para los escenarios (a)–(e) se usó su límite inferior de 1 sigma, `28.0 GeV`.
- El bulk de fotones por encima de 30 MeV llegó `258 ± 34 ms` después del bulk por debajo de 1 MeV. El propio análisis muestra evolución temporal/espectral de la fuente; este desplazamiento observado no fue identificado como una medida no nula de dispersión de propagación.

### Todos los escenarios lineales reportados

No se escogió el escenario que mejor concordara. Se conservaron los siete escenarios de la Tabla 2.

| Escenario | Supuesto/ventana de emisión fijado por Fermi | Límite de retardo | Signo cubierto | Límite reportado `M_QG,1/M_Planck` |
|---|---|---:|---:|---:|
| (a) | comienzo de cualquier emisión `<1 MeV`, `t_start−T0 = −30 ms`, `E_l=0.1 MeV` | `Δt < 859 ms` | `s_n=+1` | `>1.19` |
| (b) | comienzo de la emisión principal `<1 MeV`, `t_start−T0 = 530 ms`, `E_l=0.1 MeV` | `Δt < 299 ms` | `s_n=+1` | `>3.42` |
| (c) | comienzo de la emisión principal `>0.1 GeV`, `t_start−T0 = 648 ms`, `E_l=100 MeV` | `Δt < 181 ms` | `s_n=+1` | `>5.63` |
| (d) | comienzo de la emisión `>1 GeV`, `t_start−T0 = 730 ms`, `E_l=1000 MeV` | `Δt < 99 ms` | `s_n=+1` | `>10.0` |
| (e) | asociación del fotón de 31 GeV con un spike contemporáneo `<1 MeV`, `E_l=0.1 MeV` | `|Δt| < 10 ms` | `s_n=±1` | `>102` |
| (f) | asociación del fotón de 0.75 GeV con el primer spike, `E_l=0.1 MeV`; se usa energía inferior 1 sigma `0.694 GeV` | `|Δt| < 19 ms` | `s_n=−1` | `>1.33` |
| (g) | análisis DisCan de la estructura de spikes por encima de 1 GeV | `|Δt/ΔE| < 30 ms/GeV` | `s_n=±1` | `>1.22` |

En la convención de la fuente, `s_n=+1` representa retardo positivo/sub-luminal y `s_n=−1` retardo negativo/super-luminal. Los escenarios (a)–(d) suponen que el fotón de alta energía fue emitido después del `t_start` elegido; (e)–(f) asocian fotones concretos con spikes de baja energía; (g) limita el smearing lineal de la curva de luz.

## Incertidumbre y supuestos

- El límite del escenario (g), `|Δt/ΔE| < 30 ms/GeV`, se declara al `99%` de confianza.
- Los límites (a)–(f) son límites condicionados por las asociaciones/ventanas de emisión indicadas. Usan entradas conservadoras de 1 sigma donde la fuente lo especifica, pero la Tabla 2 no les asigna un único nivel de confianza frecuentista común.
- El resumen de Nature redondea el resultado robusto a un límite inferior de `1.2 E_Planck` para una dependencia lineal de la energía, sujeto a supuestos razonables sobre la emisión.
- La fuente señala que los modelos de orden `n>1` no quedan significativamente restringidos. Por tanto, esta apertura sólo contrasta el endpoint lineal efectivamente reportado y no convierte el resultado en una prueba universal de nondispersión.

## Transformación congelada y adjudicación

El contrato asocia monótonamente bandas de energía externas con etiquetas `s` distintas y compara velocidad/retardo normalizado en el mismo trayecto. No hay parámetros libres ni un lag ajustado después de ver el resultado. En DEE, el endpoint congelado es

`D_E1 = max_j |log(v_j/v_ref)| = 0`.

El valor de dispersión cero está permitido en **cada** escenario (a)–(g): los resultados son límites superiores sobre el módulo del retardo/coeficiente o límites inferiores sobre una escala de LIV; el límite de dispersión nula corresponde al caso de escala infinita y no es excluido. El desplazamiento de `258 ± 34 ms` entre poblaciones de fotones no cambia esa conclusión porque la colaboración no lo identifica como un coeficiente de propagación no nulo y sus límites separan explícitamente los supuestos de emisión.

**Adjudicación contractual: `COMPATIBLE_NOT_VALIDATING`.**

Esto significa únicamente que la predicción exacta nula de E1 cabe dentro de todos los límites lineales reportados bajo los supuestos declarados. No demuestra equivalencia entre energía y `s_reg`, no identifica una ontología DEE, no prueba nondispersión exacta a toda energía/orden y no valida DEE frente a modelos alternativos que también predicen dispersión nula.

## Registro de consultas

1. Resolución por el título primario congelado en la página de Nature y por `arXiv:0908.1832`.
2. Inspección del PDF primario: Tabla 2 y notas; búsquedas internas `0.903`, `0.829`, `258±34` y `31 GeV photon`.
3. Inspección de metadatos primarios: DOI, fechas de recepción/aceptación/publicación y referencia bibliográfica.

Las páginas abiertas y usadas como evidencia son exclusivamente las cuatro URLs primarias enumeradas arriba.
