# E3 — Nagel et al. (2015): auditoría del puente geométrico lineal directo

## Registro

- Contrato congelado: `HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json`
- SHA-256 del contrato: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`
- Consulta externa posterior al freeze: 2026-09-11 (America/Mexico_City)
- Fuente primaria: Nagel et al., *Direct terrestrial test of Lorentz symmetry in electrodynamics to 10^-18*, Nature Communications 6, 8174 (2015), DOI 10.1038/ncomms9174.
- URL editorial: https://www.nature.com/articles/ncomms9174
- Preprint del mismo trabajo: https://arxiv.org/abs/1412.6954

## Endpoint externo extraído

El experimento compara resonadores ópticos ortogonales mientras cambia su orientación. El artículo informa una variación relativa dependiente de orientación

`Delta nu / nu = (9.2 ± 10.7) × 10^-19` (intervalo de confianza del 95 %)

y resume la ausencia de una violación significativa al nivel de `10^-18`. El propio artículo advierte que el observable de resonador mezcla, en general, sectores fotónico, electrónico y del medio; la lectura puramente fotónica requiere la convención indicada por los autores. Esa salvedad se conserva y no se usa para afinar DEE.

## Predicción DEE congelada

El puente E3 postula una única aplicación lineal invertible `A`, un único paso temporal positivo `tau` y

`v(d)=||A d||_2/tau`, para cada `d` de las 26 direcciones de Moore.

Con `Q=A^T A`, el promedio de `b^T Q b` sobre las ocho diagonales corporales `b in {−1,+1}^3` es `tr(Q)`. Alguna diagonal corporal tiene, por tanto, cuadrado de norma al menos `tr(Q)`, mientras que algún eje tiene cuadrado de norma a lo sumo `tr(Q)/3`. En consecuencia,

`max_d v(d) / min_d v(d) >= sqrt(3) = 1.732050807568877...`.

La cota es invariante frente a la escala global y corresponde a una anisotropía de orden unidad, no de `10^-18`. Además, exigir igualdad exacta entre ejes y diagonales de cara ya produce ecuaciones incompatibles para los términos no diagonales de `Q`.

## Adjudicación congelada

**FAIL_BRIDGE** para la identificación lineal directa de las coordenadas cúbicas crudas de DEE con un espacio euclídeo físico fundamental y un tiempo común.

La comparación es condicional al puente declarado. No refuta una geometría emergente derivada mediante coarse-graining, un mapa no lineal/Finsler, una dinámica estocástica efectiva ni otra identificación de observables. Tampoco transforma el límite de Nagel en evidencia sobre la ontología interna de DEE.

