# E4 — búsqueda congelada de un análogo de oclusión y fase

## Identidad y reglas

- Contrato SHA-256: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`
- Búsqueda realizada después del freeze: 2026-09-11.
- No se alteraron la predicción, la transformación ni los criterios de admisión.
- Tope respetado: no se inspeccionaron más de 20 candidatos por consulta.

Consultas, en el orden preregistrado:

1. `transient shutter pulse train waveguide phase shift experiment`
2. `single pulse blocked periodic source downstream phase experiment`
3. `boundary driven exclusion experiment pulse train`

## Criterio de inclusión congelado

Un resultado debía ser un experimento primario con: (i) fuente persistente, (ii) bloqueo transitorio exactamente de una unidad operacional en la entrada, (iii) al menos dos posiciones aguas abajo resueltas temporalmente y (iv) control sin bloqueo. El endpoint debía permitir probar conjuntamente retraso normalizado uno y reversión de paridad del tren antes del wrap.

## Resultado de la búsqueda

Los candidatos recuperados pertenecieron, entre otros, a desplazamientos de fase de fotón único, control de fase de osciladores, propagación de pulsos en guías y modelos de exclusión impulsados por frontera. Ningún candidato reunió simultáneamente los cuatro requisitos operacionales. En particular, los trabajos de fase no implementaban el bloqueador unitario con control y dos detectores; los de exclusión no ofrecían el registro experimental espacio-temporal exigido; y los de guía no realizaban la perturbación discreta definida en el contrato.

## Adjudicación

**NOT_IDENTIFIABLE**. No existe, entre los candidatos admitidos por la búsqueda congelada, un dataset externo que mida el endpoint E4. Esto no es un FAIL del fenómeno interno: el resultado interno de oclusión sigue siendo una ley computacional de DEE. Tampoco se eligió un análogo sustitutivo después de conocer el resultado.

