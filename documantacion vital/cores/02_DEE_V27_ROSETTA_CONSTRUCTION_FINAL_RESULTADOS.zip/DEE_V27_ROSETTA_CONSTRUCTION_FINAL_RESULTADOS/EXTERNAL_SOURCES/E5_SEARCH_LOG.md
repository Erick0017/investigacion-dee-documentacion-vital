# E5 — búsqueda congelada de un análogo de mayoría de cinco fuentes

## Identidad y reglas

- Contrato SHA-256: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`
- Búsqueda realizada después del freeze: 2026-09-11.
- No se alteraron predicción, mapeo ni criterios de admisión.
- Tope respetado: no se inspeccionaron más de 20 candidatos por consulta.

Consultas, en el orden preregistrado:

1. `experimental five input coalescence output direction input strength`
2. `five beam collision experiment output direction`
3. `multi particle coalescence experiment momentum direction`

## Criterio de inclusión congelado

Se exigió evidencia experimental primaria resuelta temporalmente con al menos cinco entradas simultáneas, intensidades de entrada registradas y dirección de salida medida. El contraste debía distinguir mayoría vectorial no ponderada de suma ponderada por intensidad, sin reponderar después del resultado.

## Resultado de la búsqueda

Los resultados recuperados incluyeron colisiones de iones pesados, condensados de Bose–Einstein, coalescencia de gotas y experimentos de haces que no implementaban cinco entradas simultáneas controladas con intensidades y dirección de salida comparables. Ningún candidato satisfizo el criterio completo. No se sustituyó la aridad, no se aceptaron simulaciones como datos y no se cambió `s_reg` por otra magnitud después de inspeccionar resultados.

## Adjudicación

**NOT_IDENTIFIABLE** para el diccionario externo directo `direction -> dirección de entrada/salida`, `s_reg -> intensidad`. La ausencia de dataset calificante no refuta T11 ni descarta otras funciones de `s_reg` o `direction`.

