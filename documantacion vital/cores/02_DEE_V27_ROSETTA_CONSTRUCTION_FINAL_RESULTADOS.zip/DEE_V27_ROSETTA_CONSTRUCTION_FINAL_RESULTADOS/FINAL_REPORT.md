# Informe final — construcción operacional de la Rosetta DEE v27

## 1. Alcance y resultado

Esta continuación partió del cierre inmutable `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1`; no repitió inventario, auditoría del wheel, Claude T1–T7, D6, T8 ni T9. Su pregunta única fue si el propio `F_DEE` permite descubrir un estado causal efectivo común y convertirlo en una Rosetta falsable.

El resultado es **`ROSETTA_PARTIAL`**:

- existe una arquitectura interna compacta y operacional;
- la primera versión congelada fue falsada exactamente por T10 y el FAIL se conserva;
- el fallo reveló que DEE requiere separar estado predictivo de evento transitorio;
- esa hipótesis posterior fue congelada y pasó T12 en casos nuevos;
- T11 pasó una predicción inversa independiente;
- dos correspondencias externas son compatibles pero no validantes;
- el puente geométrico lineal directo falla;
- faltan datasets para dos analogías y no existe calibración dimensional.

No se concluye que `H_DEE` sea verdadera o falsa. Se construye el objeto interno que una validación podría usar y se identifica la pieza externa exacta que aún falta.

## 2. Identidad normativa

| Objeto | SHA-256 |
|---|---|
| wheel `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl` | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` |
| kernel `.pyd` importado | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` |
| fuente C++ empaquetada | `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab` |
| wrapper `__init__.py` | `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4` |
| constantes Python | `339ebcd5602a09a0b1b4bcdc848b3f357237ee5b07778d05e915312c8faa6241` |
| wrapper API Python | `d777704de34f2df70b259d4f36a12d6a4b7355620517ad1d9537c53c4a5b8454` |
| ZIP padre V1 | `06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4` |
| pruebas exactas V1 | `f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609` |
| contrato Rosetta original | `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157` |
| contrato de reparación post-T10 | `b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f` |

Los runners binarios usaron CPython 3.13.11 AMD64 y NumPy 2.2.6, forzaron `sys.path` al árbol local extraído y verificaron wheel, `.pyd`, C++ y ruta importada. La auditoría final comparó además byte por byte los cinco payloads importables extraídos contra el wheel, incluyendo los tres wrappers Python. No se modificó ni recompiló el kernel.

## 3. Método y orden epistémico

### 3.1 Discovery interno

Se aplicó equivalencia predictiva: para `O,H` fijados, la clase de un microestado se define por su palabra futura `W_H^+`. El cociente `X/ker(W_H^+)` es la partición exacta más gruesa capaz de predecirla. Se usaron sectores analíticos, enumeración reducida y probes del binario, no enumeración ingenua del espacio raw.

El discovery produjo:

- fuentes state-zero direccionales;
- registros marcados `(q,d,s,a,p)`;
- una geometría de propuestas en espacio de fase;
- propagador libre, boundary kernel y reducer de colisión;
- contraejemplo semantic 5 a lumpabilidad global;
- dirección modular exacta de propuesta;
- leyes inversas de colisión y oclusión;
- genealogía de constantes y diagnóstico de target leakage.

### 3.2 Freeze original

Antes de consultar valores externos se sellaron `M_*`, `G_*`, `K_*`, `D_*`, T10, T11, E1–E5, parámetros/nuisances y criterios de adjudicación. El contrato original quedó inmutable. Los externos son *shadow holdouts*: la consulta local fue posterior al sello, aunque no se reclama que el tema fuese desconocido para el modelo antes de la misión.

### 3.3 Falsación y reparación posterior

T10 se abrió literalmente. Tras su FAIL no se cambió el contrato. La reparación se registró como posterior, se congeló en otro contrato y se usaron nuevos tamaños/aridades en T12. Ésta es la secuencia permitida `discovery -> freeze -> holdout -> FAIL conservado -> hipótesis nueva -> freeze nuevo -> holdout nuevo`.

## 4. Rosetta interna construida

### 4.1 `M_*`

En `D_*`, `M_*` convierte el raw/clock completo en registros `(q,d,s,a,p)`. `a` distingue actividad/guard; `p` persistencia observer; `d` la propuesta; `s` la carga legible; `q` la geometría de laboratorio. Magnitud positiva de state, clock y semantic ordinaria son nuisances. Un state-zero direccional permanece porque es causal.

El dominio exige `N>=5`, direcciones Moore/cero, a lo sumo siete positivos y a lo sumo tres vecinos positivos para cada positivo no-observer. No cubre XNOR, tetra/supervivencia, overflow ni gates de fase. Sí admite orphan activo sparse: su etiqueta colapsa en este dominio; el contraejemplo semantic-5 global necesita la configuración XNOR densa de ocho positivos, fuera de `D_*`.

### 4.2 `G_dagger/J_dagger`

La transición usa propuestas a `q+d`, exclusión por `a or p`, persistencia de `p` y reducer

`u=sign(sum d_j)`, `S=min(sum s_j,19664)`.

`J_dagger=(q,u,S)` es el evento raw. `G_dagger` conserva `S` si `u!=0` y lo canoniza a cero si `u=0`. La carga no propagante sigue observable en el evento, pero no ocupa dimensión del estado predictivo futuro.

### 4.3 `K_dagger`

La respuesta se define por diferencias intervenido/baseline sobre `G_dagger`. No es lineal global. El estrato libre sí es una permutación con advección y modos Fourier; el observer produce un tren alternante pre-wrap; la colisión es un vértice no lineal y many-to-one.

La misma arquitectura produce readouts de causalidad, first-passage, transporte, materia, respuesta, memoria e irreversibilidad. Éste es el sentido preciso de “unificación” alcanzado.

## 5. Resultados internos confirmatorios

| Test | Resultado | Diseño | Resultado cuantitativo | Alcance |
|---|---|---|---|---|
| T10 | **FAIL_NO_REFIT** | Cierre original, campos/nuisances, composición | 1,389 trayectorias; 5,598 ticks; 0 domain failures; 96 cierre + 96 alineación | Refuta `M_*/G_*` original para salidas `d=0,S>0`; H10.2/H10.3 pasan |
| T11 | **PASS_NO_REFIT** | 56 subconjuntos de cinco diagonales × perfiles | 448 trayectorias; 896 ticks; 0 mismatch; 8 fibras ×7 | Confirma mayoría/cap e inversa de aridad cinco |
| T12 | **PASS_NO_REFIT** | Reparación estado–evento; aridades 3/4/6 nuevas | 748 trayectorias; 1,496 ticks; 514 `u=0`; 234 controles; 0 mismatch | Confirma prospectivamente `G_dagger/J_dagger` en `D_*`; no repara T10 |

El test T10 fue científicamente productivo: detectó una contradicción conceptual, no un error de motor. Los controles dense/lazy y 1/2 threads pasaron en T10, T11 y T12.

## 6. Resultados externos congelados

| ID | Observable DEE | Fuente/dataset | Resultado | Interpretación |
|---|---|---|---|---|
| E1 | nondispersión por etiqueta `D_E1=0` | Fermi GRB 090510 | `COMPATIBLE_NOT_VALIDATING` | Cero permitido en siete escenarios lineales; energía no identificada con `s` |
| E2 | velocidad común `theta=0` | GW170817/GRB 170817A | `COMPATIBLE_NOT_VALIDATING` | Cero dentro de `[-3e-15,+7e-16]`, bajo lags 0/10 s |
| E3 | embedding lineal común de D26 | Nagel et al. | `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN` | El teorema interno exige ratio `>=sqrt(3)`, pero el contrato no mapeó ese ratio al coeficiente de frecuencia del resonador |
| E4 | retraso/paridad por oclusión | búsqueda congelada | `NOT_IDENTIFIABLE` | ningún dataset calificante quedó documentado; falta registry candidato-por-candidato |
| E5 | mayoría de cinco entradas | búsqueda congelada | `NOT_IDENTIFIABLE` | ningún dataset calificante quedó documentado; falta registry candidato-por-candidato |

E1/E2 comparten `K_free`, pero una predicción nula no es específica de DEE. La obstrucción `sqrt(3)` excluye algebraicamente la equivelocidad de la clase lineal directa; E3 no la contrasta externamente porque faltó el operador forward. E4/E5 no son resultados negativos internos. El `FAIL_BRIDGE` originalmente escrito en `e3_e5_results.json` se conserva como historial y está supersedido por `e3_adjudication_audit.json`.

## 7. Clasificación epistemológica

### Teoremas exactos de `F_DEE`

Se importan E1–E15 de V1 por hash. El addendum prueba además la condición modular de propuesta, el contraejemplo T10 y la clausura estado–evento por ramas en `D_*`.

### Teoremas genéricos y puentes matemáticos condicionados

El cociente por palabras futuras es un teorema genérico de sistemas deterministas. La cota euclídea `sqrt(3)` es un no-go estático condicionado a una única `A,tau` sobre D26, no una ley de evolución de `F_DEE`. La multiplicidad `8×7` combina combinatoria de diagonales con el reducer DEE y fue confirmada por T11.

### Hechos computacionales

Conteos y mismatches de T10–T12, identidad de motores, fuentes state-zero y paneles adversariales. Se limitan a sus matrices ejecutadas.

### Leyes nativas empíricas

Firma de oclusión, susceptibilidad capada y T11/T12 como confirmaciones prospectivas de consecuencias nuevas. Algunas poseen además prueba estática.

### Resultados negativos

Occupancy insuficiente; `M_*` no global; `G_*` original incoherente; equivelocidad lineal directa obstruida; ausencia de masa/energía/momentum directos; constantes no independientes. El contraste óptico E3 es inconcluso, no un resultado negativo externo.

### Propiedades genéricas

Minimalidad de `ker(W)`, semigrupo determinista y Koopman unitario de una permutación. No se contabilizan como peculiaridades físicas de DEE.

### Estructuras específicas de DEE

Alfabeto `L/C/O`, scan modular, guards, cap 19664, reducer por signo, pump alternante, desempate DEMUX y transductor estado–evento.

### Hipótesis de emergencia y puentes condicionales

Geometría de respuesta dependiente del estado y los diccionarios E1–E5. Sólo los dominios y transformaciones congelados reciben adjudicación.

### No identificable

Escala absoluta, mapa preparación/medición, masa/inercia, termodinámica/hidrodinámica, quantum/Bell, gauge, gravedad y datasets E4/E5.

El ledger CSV/JSON entrega una fila por afirmación con clase, estatus, dominio, evidencia, hash y límite.

## 8. Función de las variables

- `state`: principalmente actividad/guard; su magnitud positiva colapsa en el núcleo.
- `s_reg`: etiqueta y carga de evento transportada/sumada/capada; no energía universal.
- `direction`: propuesta, velocidad de capa y dirección de producto por signo; no momentum.
- `semantic`: selector de control; observer persiste/protege, orphan cambia actividad; no especie física.
- `raw`: campo causal packed; puede ser causal con state cero y contener eventos efímeros. El estado Markoviano completo es `(raw,clock)`.
- `clock`: contador modular y fase de gates; sus diferencias son invariantes, pero no es tiempo SI.

## 9. Conservación, modos y física efectiva

La dinámica global tiene invariantes observer/clock; el vuelo libre conserva número, patrón, `d,s` y posee modos Fourier. Las colisiones destruyen número e información direccional y saturan carga. No existe balance universal identificado como energía–momentum.

La teoría efectiva más cercana en función es una cinética discreta de advección–exclusión–coagulación con fuente y eventos. No se derivó una ecuación relativista, cuántica, hidrodinámica o gravitatoria. La distribución de `Z` modifica las aristas causales —un germen operacional de “campo/geometría”—, pero no establece equivalencia materia–curvatura.

## 10. Claude e historia

La auditoría V1 sigue: T1 y T4 refutados; T2 probado módulo uint64; T3 afinado a 304,980 sin wrap; T5 probado para `N>=3` con testigo corregido; T6 parcial; T7 condicional/no instanciado. Esta continuación no los reejecutó.

Históricamente, `TORUS_MOVING` y F-189 ya contenían movimiento/`P=L`, pero se habían usado con otra interpretación. T8 formalizó v27. Claims que promovían ausencia de modo en aparatos concretos a ausencia global no sobreviven. Las constantes `alpha -> Delta -> K -> enteros` comparten genealogía; `966` es inerte, `782/19665/19664` sí son causales internos y 20 Hz no es holdout limpio.

## 11. Pieza faltante bajo `H_DEE`

Falta exactamente un mapa operacional independiente con cinco componentes:

1. protocolo de preparación física a ensembles de `X/Z`;
2. protocolo de medición de historias/eventos `Z,J` a outcomes y probabilidades;
3. coarse-graining que derive geometría efectiva aproximadamente isotrópica/Lorentziana y un operador forward óptico antes de otro holdout;
4. escala común calibrada en datos distintos;
5. predicciones cruzadas preregistradas en dos o más familias externas con poder discriminante.

Iterar más el mismo kernel no puede decidir qué estado realiza el vacío, qué preparación produce una fuente física, qué raw corresponde a un detector, ni qué voxel/tick vale en SI. Esas incógnitas relacionan modelo y mundo; requieren evidencia externa y un mapa de observación, no otro sweep interno.

## 12. Regla de parada

Las interrogaciones locales capaces de cambiar el veredicto central fueron agotadas:

- se descubrió y refinó el observador;
- se probó el cierre original y falló;
- se caracterizó exhaustivamente la clase fallida del panel;
- se congeló y probó una reparación en aridades nuevas;
- se ejecutó la predicción inversa;
- se abrieron y adjudicaron todos los holdouts externos congelados;
- se auditó calibración y genealogía.

Extender `M_*` a ramas densas sería otra teoría sectorial y no proporcionaría por sí sola el mapa físico faltante. Los endpoints restantes dependen de datasets o definiciones externas que el kernel no contiene. Continuar con sweeps internos no puede promover `ROSETTA_PARTIAL` a `ROSETTA_VALIDATED`, no elimina la obstrucción algebraica `sqrt(3)` y tampoco construye el operador experimental faltante de E3. Se satisface la stopping rule.

## 13. Reproducibilidad

El paquete incluye wheel, binario/fuente extraídos, contratos, preregistros, runners exactos, resultados completos, fuentes externas normalizadas, ledger, manifest y hashes. `REPRODUCE.ps1` verifica por defecto integridad, identidad y conteos; la ejecución opcional usa un scratch separado y nunca sobrescribe los resultados sellados.
