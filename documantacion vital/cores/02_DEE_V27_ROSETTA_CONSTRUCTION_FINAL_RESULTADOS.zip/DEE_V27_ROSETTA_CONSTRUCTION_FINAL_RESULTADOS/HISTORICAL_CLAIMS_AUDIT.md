# Auditoría histórica delta después de la Rosetta

## Documento base y alcance

La campaña histórica completa se conserva, sin reescritura, en
`DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/FINAL_PACKAGE/HISTORICAL_CLAIMS_AUDIT.md`, SHA-256
`2ade66f5d1496bea9d2a1cadab31bda931e324d13c6c62f268c10461c619fb93`.

Esta auditoría sólo registra afirmaciones cuyo estatus cambia o se precisa por T10–T12, los holdouts externos E1–E5, su auditoría adversarial y la genealogía de constantes. Las categorías heredadas siguen siendo `SURVIVES`, `SURVIVES_SCOPED`, `REFUTED`, `SUPERSEDED`, `TECHNICAL_FAILURE`, `NO_IDENTIFICABLE` y `EXTERNAL_UNVALIDATED`; se añade `REFUTED_AS_FROZEN_REPRESENTATION` para evitar confundir un diagrama efectivo fallido con el kernel.

## Evidencia delta sellada

| Evidencia | SHA-256 |
|---|---|
| cierre V1 completo | ZIP `06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4` |
| contrato Rosetta | `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157` |
| preregistro T10 | `2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f` |
| resultado T10 | `a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872` |
| preregistro T11 | `7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888` |
| resultado T11 | `207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0` |
| preregistro T12 | `ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f` |
| resultado T12 | `8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b` |
| corrección adversarial E3 | `04b3dbab52da68e5b19b066e49521275cdfb3714e64f1836dc17a4de856d5c8a` |
| genealogía JSON | `e5b58389853a361b440698a59ed452203492ca52cc06a39f3eb9025539a3eb0e` |
| genealogía narrativa | `0f128492da9da832927bdddb7fb26f3ea64a9387a852f22bc17ae20123632af5` |

## Matriz delta de afirmaciones

| Afirmación | Dictamen delta | Evidencia y alcance exactos |
|---|---|---|
| El par congelado de cinco campos `M_*` y transición literal `G_*` cierra exactamente en todo T10 | `REFUTED_AS_FROZEN_REPRESENTATION` | 96 fallos de clausura y 96 de alineamiento iterado, cero fallos de `D_*`; todos están ligados al conflicto carga/canonización de salidas `d=0` en el panel de diagonales opuestas. |
| El FAIL T10 demuestra que no existe arquitectura causal reducida | `REFUTED_AS_INFERENCE` | T10 sólo prueba que las dos cláusulas congeladas son incompatibles. Los testigos de campos de H10.2 y las 1,872 composiciones libres de H10.3 pasan. Una reparación sería una hipótesis posterior y no se usa para cambiar el FAIL. |
| Separar estado predictivo y evento resuelve prospectivamente la inconsistencia | `SURVIVES_SCOPED_PROSPECTIVE` | T12 pasó 748 trayectorias/1,496 ticks nuevos, aridades 3/4/6 y cero mismatch bajo `D_*`; no repara T10 ni demuestra clausura global. |
| `q,d,s,a,p` contienen campos causalmente necesarios para la familia conjunta, y clock/magnitud/semantic ordinaria pueden ser nuisances en los paneles definidos | `SURVIVES_SCOPED` | H10.2 pasa todos los testigos requeridos, nuisance y traslación. No autoriza minimalidad global ni omisión fuera de `D_*`. |
| El propagador libre compone exactamente | `SURVIVES` en su estrato | H10.3: 1,872 checks, cero mismatch; no implica linealidad global de colisiones o guards. |
| Cinco diagonales corporales producen mayoría coordenada no ponderada | `SURVIVES_SCOPED_PROSPECTIVE` | T11: 448 trayectorias, 896 ticks, dos perfiles de carga, state y clock, cero mismatch/fallo de dominio. |
| Cada dirección corporal de salida tiene siete subconjuntos-preimagen de cinco fuentes | `SURVIVES_SCOPED_PROSPECTIVE` | Las 56 combinaciones se reparten exactamente en 8 fibras de tamaño 7. Es degeneración interna, no ley de scattering físico. |
| El PASS T11 valida `direction=momentum` y `s_reg=intensidad/energía` | `EXTERNAL_UNVALIDATED` | T11 prueba la regla del kernel. E5 no encontró un dataset externo calificante y no existe calibración del diccionario. |
| Nondispersión por etiqueta está externamente validada | `EXTERNAL_UNVALIDATED` | E1 es `COMPATIBLE_NOT_VALIDATING`: cero cabe en todos los escenarios lineales Fermi, pero la asignación energía–`s` no está identificada. |
| Clases GW/EM prueban el estrato común DEE | `EXTERNAL_UNVALIDATED` | E2 es `COMPATIBLE_NOT_VALIDATING`: el bound transformado contiene cero bajo lags fijados; no identifica clases con etiquetas. |
| Coordenadas cúbicas raw admiten una lectura euclídea lineal fundamental equivelocidad | `REFUTED_AS_BRIDGE` | El teorema previo al dato da razón de velocidades `>=sqrt(3)` para toda `A` invertible y `tau` común. El contraste Nagel no es parte de esta prueba. |
| E3 refuta experimentalmente el puente lineal directo o toda geometría emergente | `REFUTED_AS_INFERENCE` | E3 externo es inconcluso: faltó el operador forward al resonador. El teorema interno sólo cubre equivelocidad lineal directa; coarse-graining, mapas no lineales/Finsler y geometría renormalizada no fueron contrastados. |
| E4 o E5 produjeron negativos experimentales | `REFUTED_AS_INFERENCE` | Ambos son `NOT_IDENTIFIABLE`: ningún dataset calificante quedó documentado y los logs carecen de registry candidato-por-candidato. No hubo endpoint experimental que pudiera fallar. |
| Las constantes históricas son predicciones independientes convergentes | `REFUTED` | Forman principalmente una cadena constitutiva `alpha* -> Delta_nu* -> K* -> {966,782,194422,19665} -> 19664`; contar descendientes duplica evidencia. |
| `966` es una constante dinámica discriminante | `REFUTED` en v27 actual | La rama de cristalización es inalcanzable y cualquier threshold `>=50` produce la misma inactividad; no hay sensibilidad al valor específico 966. |
| `782`, `19665` y `19664` no tienen función real | `REFUTED` | Son causales en gates/overflow/saturación de v27, pero su función interna no valida los nombres físicos ni aporta evidencias independientes. |
| `194422` es un lifetime | `REFUTED` | Es payload de `state`, no contador decrementado. |
| `20 Hz` o `alpha` pueden actuar como holdout Rosetta | `REFUTED_FOR_CONFIRMATION` | Ya estaban expuestos y/o alimentaron la construcción. Usarlos para calibrar y luego “predecir” produce target leakage. |

## T10: qué falló y qué sobrevivió

T10 agotó exactamente su matriz prevista: 1,389 trayectorias y 5,598 ticks primarios, 5,716 ticks contando testigos/controles, 30,521 assertions, 45 comparaciones de motores y cero fallos de dominio. Dense/lazy y uno/dos hilos coincidieron.

El veredicto fue `FAIL` porque el criterio exigía cero desacuerdos y H10.1 observó 192 registros de mismatch: 96 en `M_*(F_DEE X)=G_*(M_*X)` y 96 en alineamiento del iterado. La causa no se infirió por búsqueda posterior: el resultado la localiza en una inconsistencia preexistente del contrato. `M_*` borra `s` en blockers activos con dirección cero; `G_*` conserva el `s_out` capado de toda colisión. Las parejas corporales opuestas crean exactamente ese estado.

No se corrige el contrato después de abrir el holdout. El FAIL queda preservado. También quedan preservados los PASS independientes de H10.2, H10.3, identidades, dominio y motores.

## T11: extensión predictiva confirmada

T11 no fue usado para seleccionar `M_*`/`G_*`. Su predicción fue congelada después del contrato y antes de ejecutar la nueva aridad. En `N=23`, todas las `C(8,5)=56` selecciones se probaron bajo ocho combinaciones de carga, state y clock: 448 trayectorias y 896 ticks. El resultado fue `PASS` integral, con cero mismatches, cero fallos de dominio, cero errores técnicos y controles de engine concordantes.

La multiplicidad `7:1` y la mayoría coordenada son, por ello, una ley nativa prospectiva del reducer en el dominio T11. El PASS no repara retroactivamente T10: T11 usa cinco direcciones corporales y siempre produce una dirección corporal no nula, por lo que no excita la fibra `d_out=0` que revela la contradicción.

## T12: reparación estado–evento confirmada prospectivamente

Después de T10 se formuló y selló una hipótesis distinta: `G_dagger` canoniza el estado futuro cuando `u=0`, mientras `J_dagger` conserva el evento raw con carga `S`. T12 pasó una sola vez con 748 trayectorias, 1,496 ticks primarios, 514 productos cero, 234 controles no cero, cero fallos de dominio y cero mismatch. Su estatus es apoyo prospectivo sectorial; el histórico T10 continúa `FAIL_NO_REFIT`.

## Continuidad histórica v25 frente a autoridad v27

Se conserva la corrección V1: `TORUS_MOVING` v25 y v25.5-C/F-189 ya contenían transporte axial/traslación exacta en preparaciones acotadas. Son antecedentes, no una prueba por transferencia automática. T8–T12 ejecutaron el wheel v27 identificado por hash; sus dominios y veredictos pertenecen a v27.

Los documentos v25 participan también en la genealogía de `20 Hz` y `P=L`, pero no autorizan trasladar al kernel v27 ni la identidad física ni toda fórmula histórica. El C++ v27 decide qué constantes son ejecutables: `782` gobierna gates, `19665` un umbral, `19664` el cap, `194422` un payload y `966` queda no discriminante por inalcanzabilidad de rama.

## Estado histórico actualizado

La historia ahora contiene simultáneamente:

- antecedentes v25 de transporte, confirmación/generalización v27 y un nuevo PASS inverso T11;
- un FAIL T10 de representación exacta que no debe ocultarse ni globalizarse;
- dos compatibilidades externas no validantes, un puente directo falsado y dos búsquedas sin endpoint;
- una genealogía que separa constantes causales internas de interpretaciones físicas circulares.

No existe todavía un PASS físico externo ni una calibración dimensional. Esa ausencia no convierte los modos, invariantes o coarse-grainings aún abiertos en imposibles.
