# T10 — frozen internal holdout for the Rosetta core

Status at authorship: **PREREGISTERED; NOT EXECUTED**.

This holdout is new. It does not rerun T8 or T9 as a replication target. It tests the newly proposed quotient `M_*` and transition `G_*` against untouched trajectories of the sealed v27 binary. T8/T9 are prior evidence only.

## Identity and admissible implementation

- Wheel SHA-256: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- Imported pyd SHA-256: `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Python: CPython 3.13 x64, invoked with `-I -B`.
- Import: only the hash-verified extraction in parent V1 `ANALYSIS/binary_api/wheel_extracted`.
- Primary engine: `tick_universo_lazy`, one thread. Three canonical controls also compare dense/lazy and one/two threads.
- Seed: `271017031`; it fixes origins and heterogeneous clocks, not outcome-dependent sampling.

The runner may serialize more diagnostics, but it may not change the cases, predictions or acceptance rule below after this file is hashed.

## Frozen projection `M_*`

For a raw at site `q`, decode `state`, `s_reg=s`, direction `d` and semantic. Directions in this holdout are restricted to `D26={-1,0,1}^3\{0}` or zero. Emit one canonical record only when at least one condition holds: `state>0`, `d in D26`, or `semantic=4`.

The record is `z=(q,d,s,a,p)` with `a=1[state>0]` and `p=1[semantic=4]`. All non-observer semantics are identified. A non-observer `state=0,d=0` raw is canonically empty. For a non-observer active `d=0` blocker, `s` is canonicalized to zero because it neither proposes nor survives in the frozen domain. Absolute positive state magnitude and clock are absent. A translation-free readout may later quotient common translations; the laboratory readout retains `q`.

## Frozen sparse domain `D_*`

The one-step equality is asserted only when:

1. `N>=5` and every decoded direction is zero or in `D26`;
2. there are at most seven sites with `state>0` in the complete world;
3. every state-positive non-observer site has at most three state-positive Moore neighbours;
4. no semantic other than 4 receives special treatment in the projected readout;
5. the same conditions hold at every input slice on which an iterated equality is scored.

Conditions 2–3 are deliberately stronger than necessary. They imply no XNOR birth, no tetra/material survival and no overflow/DEMUX delta. Observer raws take their fixed-point branch. The holdout runner must test and record the domain predicate before each scored tick; a planned case that escapes is a `DOMAIN_FAILURE`, not silently discarded.

## Frozen transition `G_*`

- Every record with `d in D26` proposes `(d,s)` to `q+d mod N`, independently of `a` and `p`.
- The input target is closed when `a=1` or `p=1`; proposals to a closed target are rejected for that tick.
- Every observer (`p=1`) persists with the same canonical record.
- Non-observer input records do not persist locally in `D_*`.
- At every open target with one proposal, create `(state-category active, d, s, non-observer)`.
- At every open target with more than one proposal, create an active non-observer with

  `d_out=sign(sum_j d_j)` componentwise and `s_out=min(sum_j s_j,19664)`.

- No proposal yields canonical empty.

## Hypotheses and fixed panels

### H10.1 — one-step and iterated closure

For every scored slice, `M_*(F_DEE X)=G_*(M_*X)` exactly. Iterating both sides must remain equal while `D_*` holds.

Panel A, normalization/free transport: `N=17`; all 26 directions; `s in {0,37,19663,65535}`; initial normal state in `{0,7,4294967279}`; clocks `heterogeneous` or `near_wrap`; horizon five. Total: 624 trajectories, 3,120 scored ticks.

Panel B, isolated two-source reducer: one unordered pair from the eight body-diagonal directions; source sites are `q-d_j`; activity/state profiles `(0,0),(0,11),(11,0),(11,23)`; charge pairs `(0,37),(1,19663),(19664,65535)`; the two clock patterns above; horizon three. Total: 672 trajectories, 2,016 scored ticks.

Panel C, observer response quotient: directions `(1,0,0),(1,1,0),(1,1,1),(-1,1,-1)`; `s in {37,19663}`; observer state in `{0,9,4294967279}`; both clock patterns; horizon seven. Total: 48 trajectories, 336 scored ticks. Scoring is on `M_*`, not equality of discarded numeric observer states.

Panel D, target guard: for each of `(1,0,0),(1,1,0),(1,1,1)`, a latent normal source points at a target that is respectively (i) canonically empty despite a non-observer state-zero raw, (ii) an active zero-direction normal blocker, or (iii) a state-zero observer. Horizon two. Total: nine trajectories, 18 scored ticks.

Panel E, non-observer semantic nuisance: the three representative direction classes above, semantics `{3,5,14}`, states `{0,17}`, both clock patterns and horizon three. Total: 36 trajectories, 108 scored ticks.

### H10.2 — required and nuisance information

Matched binary witness pairs must behave as follows:

- laboratory position `q`, direction `d`, load `s`, activity/target closure `a`, and observer persistence `p` each have at least one pair with a different projected future when that field alone is omitted;
- common translation of world and detector is equivalent, so absolute origin is removable only in the translation-quotiented readout;
- positive state magnitudes, absolute clock patterns and non-observer semantic labels have identical projected futures inside `D_*`;
- a non-observer state-zero/zero-direction raw is future-equivalent to empty inside `D_*`.

The fixed witnesses are: shifted singleton for `q`; axis versus face-diagonal router for `d`; loads 37 versus 38 for `s`; an incoming latent router aimed at a state-zero versus state-one zero-direction target for `a`; and normal versus observer state-zero sources with the same `(q,d,s)` for `p`. Equality witnesses use states 7 versus 4294967279, the two clock patterns, and semantics 3/5/14.

### H10.3 — response composition

On every Panel-A free trajectory, the permutation kernel must satisfy the exact composition checked at `(t,u) in {(1,1),(1,3),(2,2)}`:

`K_free^(t+u)=K_free^u K_free^t`.

The state-conditioned finite-difference response is diagnostic only; no linear superposition is asserted for collisions or observer boundaries.

## Acceptance and no-refit rule

`PASS` requires all of the following: exact projected equality on every scored tick; zero planned domain failures; every required-field witness diverges as predicted; every nuisance witness agrees as predicted; all composition checks pass; all engine controls agree; and all identity hashes resolve exactly.

Any mismatch is `FAIL`. An identity mismatch or inability to execute is `INVALID_RUN`. No formula, field, domain condition, case, seed or tolerance may be changed after opening results. A later hypothesis would require a new explicitly post-T10 preregistration and T10 remains preserved.

