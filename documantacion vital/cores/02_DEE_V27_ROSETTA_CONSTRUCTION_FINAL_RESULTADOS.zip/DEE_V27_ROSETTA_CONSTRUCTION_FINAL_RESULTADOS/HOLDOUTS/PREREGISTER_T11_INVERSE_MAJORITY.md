# T11 — post-construction inverse prediction: five-source majority

Status at authorship: **PREREGISTERED AFTER ROSETTA FREEZE; NOT EXECUTED**.

Frozen parent contract SHA-256: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`.

This is the required inverse test. `M_*`, `G_*` and the collision vertex were already fixed. Five-source arity, the 56-case exhaustive subset family and its 7-to-1 inverse multiplicity were not used in discovery, T8, T9 or the choice of the Rosetta core.

## Derivation made before execution

Let `B8={-1,+1}^3`. Select any unordered five-element subset `S` of `B8`. Put one state-zero, non-observer latent router at `q-d` with direction `d` for every `d in S`, all aimed at the same raw-zero target `q`.

The sealed collision law predicts

`d_out = sign(sum_{d in S} d)`

and

`s_out = min(sum_{d in S} s_d,19664)`.

Because five is odd, no coordinate sum is zero: `d_out` is a body diagonal and equals coordinatewise majority vote. Cube-sign symmetry plus direct exhaustive combinatorics predicts that the 56 subsets divide uniformly: each of the eight output body diagonals has exactly seven unordered preimages when inputs are observed only through `d_out`.

This is an inverse prediction because an observed output direction determines a seven-member input fiber, not a unique history. It also predicts that changing input loads leaves `d_out` unchanged, while changing only `s_out` up to the cap.

## Frozen execution matrix

- Wheel/pyd/Python/import identity: exactly as in T10 and the parent contract.
- `N=23`; target `q=(11,11,11)`.
- Direction subsets: all `C(8,5)=56`, enumerated lexicographically.
- Load profiles:
  1. `all_one`: every `s_d=1`, so `s_out=5`;
  2. `one_19664_others_65535`: the lexicographically first direction in the subset has 19664 and the other four have 65535, so `s_out=19664`.
- State profiles:
  1. `all_zero`;
  2. `alternating_zero_and_17` in lexicographic source order.
- Clock profiles: deterministic heterogeneous clock from seed `271105607` and a repeating near-wrap pattern.
- Horizon: two ticks.
- Primary engine: lazy/one thread. For the lexicographically first subset under `all_one/all_zero/near_wrap`, compare dense/lazy and one/two threads.

Total primary trajectories: `56*2*2*2=448`; total primary scored ticks: 896.

## Frozen predictions

At tick one:

- all five source sites are canonically empty;
- exactly one canonical active record is at `q`;
- its direction is coordinatewise majority of the subset;
- its load is 5 or 19664 according to profile;
- state and clock profile do not change that projected result.

At tick two:

- exactly one active record is at `q+d_out`;
- direction and load remain those of tick one.

On the restricted `all_one/all_zero` panel, grouping the 56 tick-one outputs by `d_out` yields exactly eight groups of size seven. Direction-only inversion must therefore return a seven-element set for every output.

## Acceptance and no-refit rule

`PASS` requires 448/448 trajectories and 896/896 scored ticks exact, zero mismatches, the exact eight-by-seven inverse histogram, all engine controls identical and all frozen hashes valid.

Any divergent raw projection, count, load, direction, position, domain predicate, engine trace or identity hash is `FAIL` or `INVALID_RUN` as appropriate. The formula, arity, subsets, profiles, seed, horizon and acceptance rule may not change after this file is hashed. T11 remains preserved if it fails.

