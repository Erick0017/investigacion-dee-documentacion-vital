# T12 — preregistro de la reparación estado–evento posterior a T10

Estado al redactar: **POST-T10 / PRE-T12 / NO EJECUTADO**.

Este documento no modifica, reemplaza ni reinterpreta T10. El `FAIL` de T10 y sus 192 discrepancias permanecen resultados inmutables. La hipótesis siguiente fue formulada después de observar que el contrato congelado exigía simultáneamente:

- `M_*`: canonizar `s=0` para todo blocker activo no observer con `d=0`;
- `G_*`: conservar `S=min(sum s_j,19664)` en toda salida multifFuente, incluso cuando `sign(sum d_j)=0`.

## Hipótesis posterior H12

La arquitectura apropiada es un transductor estado–evento y no un único registro que deba servir a la vez como estado predictivo mínimo y como registro instantáneo de colisión.

Defínase `canon(C(q,u,S))` por

- `C(q,u,S,1,0)` si `u!=0`;
- `C(q,0,0,1,0)` si `u=0`.

El estado predictivo reparado conserva el mismo `M_*` congelado. Su transición es `G_dagger=canon o G_raw` en el vértice multifFuente. Además emite un observable de arista/transición

`J_dagger({d_j,s_j})=(q, sign(sum_j d_j), min(sum_j s_j,19664))`.

Así, cuando `u=0`, el raw del tick de colisión contiene transitoriamente `S`, `J_dagger` lo registra, y el estado predictivo lo canoniza porque el portador `d=0` no puede transmitir esa carga y desaparece en el siguiente tick dentro de `D_*`. Para `u!=0`, estado y evento conservan `S`.

H12 afirma, sobre los casos congelados abajo:

1. `M_*(F X)=G_dagger(M_*X)` exactamente en ticks 1 y 2;
2. el raw del tick 1 implementa exactamente `J_dagger` antes de la canonización;
3. si `u=0`, el único producto muere al tick 2; si `u!=0`, se traslada a `q+u` conservando `u,S`;
4. semantic state-zero ordinaria/orphan y clock son nuisances en esta familia;
5. dense/lazy y 1/2 threads coinciden en los controles.

No se afirma que `J_dagger` sea energía, momentum o un observable físico externo. Tampoco se afirma una reparación global fuera de `D_*`.

## Holdout nuevo y no reutilizado

- Tamaño: `N=19`.
- Blanco: `q=(9,9,9)`.
- Fuentes: routers `state=0` colocados en `q-d`, con direcciones distintas `d` de `D26`, apuntando simultáneamente a `q`.
- Arities: `k in {3,4,6}`. T10 sólo usó pares en su panel de colisión y T11 usó selecciones de cinco diagonales corporales; estas aridades/configuraciones no reutilizan esos casos.
- Orden de `D26`: orden lexicográfico producido por `product((-1,0,1), repeat=3)`, omitiendo `(0,0,0)`.
- Subconjuntos cero:
  - los 44 subconjuntos de tres direcciones distintas cuya suma vectorial es exactamente cero;
  - los 214 subconjuntos de cuatro direcciones distintas cuya suma es exactamente cero;
  - los primeros 256 subconjuntos lexicográficos de seis direcciones distintas cuya suma es exactamente cero.
- Controles no cero: para cada `k`, se recorre la misma enumeración lexicográfica y se retienen los primeros tres subconjuntos para cada una de las 26 salidas no nulas `u=sign(sum d_j)`: 78 controles por aridad, 234 en total.
- Total primario fijo: `44+214+256+3*78=748` trayectorias, dos ticks puntuados por trayectoria, `1,496` ticks.

## Perfiles fijados antes de ejecutar

Sea `r` el índice global de caso, desde cero, en el orden: ceros k=3, ceros k=4, ceros k=6, controles k=3, controles k=4, controles k=6.

- Si `r` es par, cargas `s_j=j+1` en el orden del subconjunto; no saturan.
- Si `r` es impar, `s_0=19664` y `s_j=65535` para `j>0`; la salida satura en 19664.
- Semánticas de las fuentes: ciclo `(1,3,5,14)` según `j`; todas tienen `state=0`.
- Si `r` es par, el clock completo inicia en cero excepto fuentes y blanco, que reciben `(27120517 + 104729*r + 17*j) mod 2^64`.
- Si `r` es impar, cada fuente recibe `2^64-1-(j mod 3)` y el blanco `2^64-2`.
- Motor primario: `tick_universo_lazy`, un thread.

## Controles de motor

Se seleccionan cuatro casos fijos: primer cero k=3, primer cero k=6, primer control no cero k=3 y último control no cero k=6. Cada uno se ejecuta dos ticks en dense/lazy por 1/2 threads y se exige igualdad full raw/full clock con la referencia primaria.

## Identidad y aceptación

El runner debe abortar antes de resultados científicos si no coinciden hashes de wheel, `.pyd`, C++, contrato Rosetta original, preregistro T10, resultado T10, este preregistro y contrato de reparación. Debe importar sólo el paquete extraído sellado bajo CPython 3.13 x64.

`PASS` exige simultáneamente:

- exactamente 748 trayectorias y 1,496 ticks primarios;
- exactamente 514 casos `u=0` y 234 controles `u!=0`;
- cero fallos de `D_*` en todos los slices puntuados;
- cero mismatches de cierre, evento, movimiento/muerte, clock o identidad;
- 16/16 trayectorias de control de motor coincidentes.

Cualquier discrepancia es `FAIL`; no se ajustará fórmula, selección, carga, clock ni semántica después de abrir T12.

