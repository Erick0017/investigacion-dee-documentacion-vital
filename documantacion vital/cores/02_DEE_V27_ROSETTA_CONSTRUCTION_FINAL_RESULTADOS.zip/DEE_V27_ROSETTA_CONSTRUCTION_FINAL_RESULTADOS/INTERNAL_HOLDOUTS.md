# Holdouts internos congelados

Estado final: **T10 FAIL; T11 PASS; T12 PASS prospectivo para la reparación posterior**. Cada contrato se conserva sin refit dentro de su propio holdout; ni T11 ni T12 reparan o anulan retrospectivamente el FAIL literal de T10.

Contrato padre congelado: `HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json`, SHA-256 `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`.

## T10 — cierre del núcleo Rosetta

Resultado: **FAIL** bajo la regla de aceptación congelada.

- Preregistro: `HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md`, SHA-256 `2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f`.
- Identidad: wheel, `.pyd`, fuente/contrato aplicables, preregistro y runtime CPython 3.13 x64 fueron comprobados; `identity.all_exact=true`.
- Ejecución primaria completa: 1,389 trayectorias y 5,598 ticks puntuados, exactamente los conteos preregistrados.
- Dominio: 5,716 slices comprobados incluyendo testigos y controles; cero fallos de dominio.
- H10.1: **FAIL**, con 96 discrepancias de cierre proyectado y 96 discrepancias derivadas de alineación iterada.
- H10.2: **PASS**. Los cinco campos requeridos `q,d,s,a,p` tuvieron testigos divergentes; traslación común, magnitud positiva de state, clock absoluto, semantic no observer y raw `state=0,d=0` se comportaron como nuisances bajo los testigos congelados.
- H10.3: **PASS**, 1,872/1,872 comprobaciones de composición del kernel libre.
- Controles del motor: **PASS**; 45 comparaciones entre dense/lazy y uno/dos threads, sin discrepancias.

### Causa exacta del FAIL

Las 192 filas de mismatch pertenecen exclusivamente al panel B y se distribuyen como `96 PROJECTED_CLOSURE + 96 ITERATED_INPUT_ALIGNMENT`. Afectan las colisiones entre pares de diagonales corporales opuestas, para las que `u=sign(d1+d2)=0`.

El conflicto estaba ya en la especificación congelada:

1. `M_*` canonicaliza a carga cero todo hijo activo normal con `d=0`, porque lo trata como blocker sin propuesta;
2. la cláusula multi-source de `G_*` conserva literalmente `S=min(sum s_j,19664)` sin excepción cuando `d_out=0`.

Por eso `M_*(F_DEE X)` contiene carga canónica cero, mientras `G_*(M_*X)` conserva `S`. T10 ejecutó ambas cláusulas literalmente y no las armonizó después de observar el binario. El resultado falsifica la igualdad de cierre **tal como fue congelada** sobre esa subclase de `D_*`; no falsifica por sí solo la regla raw de colisión. Cualquier cambio que canonicalice también la salida de `G_*`, o que retenga la carga del blocker en `M_*`, sería una hipótesis posterior y requiere un contrato nuevo. No se aplica aquí.

Artefactos cerrados:

| Archivo | Filas | SHA-256 |
|---|---:|---|
| `RESULTS/t10_rosetta_core/t10_result.json` | — | `a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872` |
| `RESULTS/t10_rosetta_core/t10_cases.csv` | 5,716 | `5cd881b75ea2a0c8257fc047267df4a903bb3463c34e70a9bc9df222be1c3907` |
| `RESULTS/t10_rosetta_core/t10_mismatches.csv` | 192 | `91217abe77ef5fa16379b52c20b7af3e59b5ee51590842e9d9f6f7ceee1f2b29` |
| `RESULTS/t10_rosetta_core/t10_SHA256SUMS.txt` | 8 entradas referenciadas | `b1099d94eed3ac4a1854fb939ccd27c87cea29b62e535a0b86e08fec31f596d1` |

La lista `t10_SHA256SUMS.txt` fue revalidada contra disco: 8/8 referencias presentes y coincidentes. Runner T10: SHA-256 `24733db55c64c16dcbe6897f030c2b94f572f1c8fb605237b8bfa0ef4c4ed49c`.

## T11 — predicción inversa de mayoría de cinco fuentes

Resultado: **PASS** post-freeze y sin refit.

- Preregistro: `HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.md`, SHA-256 `7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888`.
- Identidad: todos los hashes normativos coincidieron; el `.pyd` verificado fue importado con CPython 3.13.11 x64 bajo `-I -B`.
- Matriz primaria completa: 448/448 trayectorias y 896/896 ticks puntuados.
- Predicción directa: en `t=1`, cada subconjunto de cinco diagonales corporales produjo en `q` la dirección de mayoría coordenada a coordenada y carga 5 o 19,664; en `t=2`, el mismo registro apareció en `q+d_out`.
- Predicción inversa: los 56 subconjuntos únicos se dividieron en ocho fibras, una por diagonal corporal de salida, con exactamente siete preimágenes en cada fibra.
- Discrepancias y dominio: cero mismatches, cero fallos de dominio y cero errores técnicos.
- Invariancia de perfiles: 224 grupos comparables y cero grupos con más de un hash raw.
- Controles del motor: 4/4 trayectorias de control dense/lazy × uno/dos threads, con ocho ticks coincidentes.

T11 no cae en la subclase conflictiva de T10: con cinco entradas de signos `{-1,+1}`, cada suma coordenada es impar y `d_out` nunca es cero. Su PASS confirma la predicción congelada de mayoría/cap y la multiplicidad inversa 7-a-1 en el panel T11, pero no demuestra el cierre completo de `M_*` y `G_*`.

### Caveat de operacionalización de perfiles

El preregistro fijó los nombres, seed, orden lexicográfico y tipo de los perfiles, pero no escribió cada secuencia literal completa. Antes de obtener la salida binaria, el runner fijó:

- state alternante: `[0,17,0,17,0]` en orden de fuente;
- clock heterogéneo: `numpy.PCG64(271105607).random_raw(N^3)`;
- clock near-wrap: repetición plana de `[2^64-3,2^64-2,2^64-1]`;
- carga alta: 19,664 para la primera dirección lexicográfica del subconjunto y 65,535 para las otras cuatro.

Éste es un caveat de precisión del preregistro, no un refit por resultado. La predicción no depende de esos valores de state/clock dentro del dominio y la invariancia raw cruzada fue comprobada explícitamente.

Artefactos cerrados:

| Archivo | Filas | SHA-256 |
|---|---:|---|
| `RESULTS/t11_inverse_majority/t11_result.json` | — | `207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0` |
| `RESULTS/t11_inverse_majority/t11_cases.csv` | 448 | `8b10eb9d7adeec0914ef2199883582bb25130b35c5eeee057ef2925a5fbfbbd6` |
| `RESULTS/t11_inverse_majority/t11_mismatches.csv` | 0 | `dc1cbfdc3f157c6b5d1e46f5ee7e23e6c433cddddc0b441c2414a082f7202b65` |
| `RESULTS/t11_inverse_majority/HASHES.sha256` | 6 entradas referenciadas | `44fb1eec8a1c02000eb04e74b15c0a61b209841accd30b5d39d868a109038a98` |

La lista `HASHES.sha256` fue revalidada contra disco: 6/6 referencias presentes y coincidentes. Runner T11: SHA-256 `dce34cbd699390b98f3e95775e3a50e4ff133bd414d45de7a254678c5a630f18`.

## Lectura conjunta

Los dos holdouts originales responden preguntas distintas. T11 confirma una consecuencia inversa nueva del reducer de cinco fuentes en un sector donde la salida direccional es necesariamente no nula. T10 rechaza el cierre global **del par congelado** `M_*,G_*` incluso dentro del panel sparse declarado, debido a la convención incompatible para la carga de un hijo `d=0`. Por la regla de no-refit, el balance original permanece `T10 FAIL / T11 PASS`; no puede presentarse como validación íntegra del núcleo Rosetta congelado.

## T12 — reparación posterior como transductor estado–evento

Resultado: **PASS** prospectivo respecto de la reparación, sin alterar T10.

Después del FAIL se formalizó una hipótesis nueva: mantener el `M_*` predictivo, aplicar a la salida la misma canonización que define su codominio (`G_dagger`) y registrar por separado el evento raw `J_dagger=(q,u,S)`. El preregistro y contrato se sellaron antes de crear/ejecutar el runner:

- `HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.md`, SHA-256 `ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f`;
- `HOLDOUTS/POST_T10_REPAIR_CONTRACT.json`, SHA-256 `b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f`.

T12 usó `N=19`, aridades 3/4/6 no empleadas por los pares de T10 ni por la aridad cinco de T11. Ejecutó 748 trayectorias y 1,496 ticks primarios: 514 subconjuntos con suma vectorial cero y 234 controles no cero. Pasaron exactamente:

- cierre `M_*(F X)=G_dagger(M_*X)` en ticks 1 y 2;
- evento raw `J_dagger` en tick 1;
- muerte del producto `u=0` y traslación del producto `u!=0` en tick 2;
- invariancia respecto de clocks y semánticas state-zero congeladas;
- 16/16 controles dense/lazy × uno/dos threads.

Hubo 1,528 slices/ticks totales con controles, 1,528 checks de `D_*`, cero fallos de dominio, 12,070 assertions y cero mismatches. El resultado JSON tiene SHA-256 `8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b`; el runner, `5ed7fb7de8660cee9dac79cfd12b9c8ae2b56c8b63c76616b4d9075fe8a44922`; el manifiesto de 14 entradas fue revalidado.

El preregistro no asignó explícitamente el índice `j` del clock par al blanco; antes de ejecutar se fijó `j=k`, continuación del orden de las `k` fuentes. El resultado raw, `M_*`, `J_dagger` y movimiento son clock-independientes en `D_*`, pero el caveat permanece registrado.

T12 demuestra que la reparación separa correctamente estado predictivo y evento en este nuevo panel. No convierte T10 en PASS, no reescribe el contrato original y no prueba cierre global fuera de `D_*`.

## Balance interno final

- Rosetta congelada original: **T10 FAIL**, preservado.
- Predicción inversa independiente: **T11 PASS**.
- Hipótesis posterior estado–evento, congelada antes de casos nuevos: **T12 PASS**.

El resultado interno no es una validación retrospectiva de una única especificación. Es evidencia de que el objeto transversal correcto necesita dos salidas distintas: un estado predictivo canónico y un ledger de eventos transitorios.
