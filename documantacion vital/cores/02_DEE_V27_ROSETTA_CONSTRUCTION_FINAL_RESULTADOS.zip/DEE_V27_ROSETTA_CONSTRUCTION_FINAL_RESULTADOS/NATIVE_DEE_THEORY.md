# Teoría nativa efectiva de DEE v27 — cierre Rosetta

## Núcleo

La estructura transversal específica identificada es un **transductor cinético marcado, dirigido, excluyente y con eventos** sobre `Z_N^3`.

Sus objetos mínimos son:

- registros `L,C,O` con coordenadas `(q,d,s,a,p)`;
- propuestas dirigidas a `q+d`;
- guards de blanco `a or p`;
- un reducer simultáneo `u=sign(sum d)`, `S=min(sum s,19664)`;
- persistencia de `O`;
- salida de evento `J=(q,u,S)` y estado canónico posterior separado;
- cociclo de respuesta condicionado `K[Z;I]`.

Esta arquitectura explica con el mismo estado transporte, first-passage, colisión, respuesta, fuente, memoria aparente e irreversibilidad. No explica todas las ramas densas de v27: `D_*` excluye supervivencia/tetra, XNOR, overflow y gates de clock. Admite orphan activo sparse como etiqueta colapsada; su distinción reaparece en extensiones que activan las ramas semánticas densas.

## Razón de la salida doble

T10 demostró que estado predictivo y observación de evento no son el mismo objeto. Una colisión opuesta escribe temporalmente una carga `S` en un hijo `d=0`. Esa carga es visible en raw, pero no puede propagarse y no altera el futuro sparse; `M_*` la canoniza. El `G_*` original intentó retenerla dentro del estado canónico y falló.

La teoría reparada produce simultáneamente:

`Z_(t+1)=G_dagger(Z_t)` y `E_(t+1)=J_dagger(Z_t)`.

T12 confirmó esa separación en aridades 3/4/6. Éste es el descubrimiento conceptual nuevo de la continuación: los observables naturales de DEE incluyen **variables de transición** además de variables de estado.

## Leyes e invariantes

### Exactos globales/importados

- clock afín módulo `2^64` y diferencias de clock invariantes;
- traslaciones toroidales;
- no-inyectividad para `N>=3`;
- raws observer fijos y cargas aditivas arbitrarias soportadas sobre ellos;
- cota causal raw `min(3t,diam_infty(T_N))`, con velocidad tres aguda donde el diámetro lo permite;
- cristalización por threshold 966 inalcanzable.

### Exactos sectoriales

- singleton y gas separado: advección sin dispersión, conservación de `d,s`, número y patrón relativo;
- `K_free` es permutación y tiene modos Fourier exactos;
- observer: self-loop y tren alternante pre-wrap;
- colisión: balance de `s` sólo como evento hasta el cap; compresión direccional y pérdida de número;
- transductor sparse: cierre de `Z` bajo `G_dagger` y lectura `J_dagger` en `D_*`.

No se identificó una suma local universal interpretable como energía o momentum. La ausencia de una forma concreta no excluye invariantes relacionales o macroscópicos de sectores aún no reducidos.

## Materia

“Materia DEE” no es `state>0`. La clase móvil demostrada es el linaje causal de un registro `C`: cada raw local puede destruirse y recrearse, pero posición orbital, dirección y `s` forman una identidad de trayectoria. Un gas es una configuración no etiquetada de esos linajes. `L` es un precursor/router causal con occupancy cero. `O` es una condición de frontera fija. Fases densas fijas son otra organización y no deben mezclarse con esta especie cinética.

No hay masa/inercia positiva en el núcleo: ni state ni `s` cambian velocidad, y `s` no pondera la dirección de colisión. Una masa colectiva sigue abierta, pero necesitaría predecir respuesta bajo una intervención definida independientemente.

## Geometría y causalidad

Los nodos naturales son `(q,d)`. El vuelo libre define `(q,d)->(q+d,d)`; las colisiones son hiperaristas y los guards las eliminan según `Z`. La distancia nativa es first-passage condicionado a preparación y capa cinética. La distancia Chebyshev es una envolvente del scan; no es métrica física.

El enlace materia–geometría existente es operacional: la distribución de `a,p` modifica las aristas admisibles y, por tanto, el kernel de respuesta. No se obtuvo curvatura, equivalencia universal ni ecuación tipo Einstein. El embedding lineal directo a geometría euclídea queda descartado por la cota `sqrt(3)`.

## Clock, raw y campos

El clock es una rotación modular independiente que selecciona gates en ramas fuera del núcleo. Su residuo causal mínimo raw sin wrap es `304980`; no es período del full-state ni tiempo físico. En `D_*` desaparece del estado mínimo.

`s_reg` tiene varias funciones contextuales: etiqueta transportada, carga sumada/capada de eventos, payload y threshold/gradiente en ramas externas. `direction` es routing y capa de velocidad; semantic selecciona control/persistencia/actividad. Raw es el campo packed causal, no un observable físico directo; el estado Markoviano completo es `(raw,clock)`, pues clock puede cambiar futuros raw fuera de `D_*`.

## Colectividad, estadística y escala

Los modos colectivos positivos identificados son:

- densidades por capa `d` transportadas por fases Fourier;
- tren alternante pre-wrap de una frontera `O`;
- gases rígidos no interactuantes;
- respuestas convectivas de una oclusión.

Son modos exactos sectoriales. No se encontró un límite de escala con equilibrio local, temperatura, stress o cierre hidrodinámico. Ensembles sobre `Z` son legítimos, pero escogerlos físicamente requiere una regla de preparación externa.

## Irreversibilidad e información

La dinámica pierde información por normalización de state, muerte, reducción many-to-one, compresión por signo, pérdida del número de fuentes y cap. Las fibras inversas son cuantificables: pares direccionales dan multiplicidades 12/13; T11 probó ocho fibras de siete para cinco diagonales. Para `N>=3`, la evolución full-state es un semigrupo determinista no reversible; los estratos libres son excepciones permutacionales.

## Física efectiva conocida y no identificada

La teoría nativa se reconoce matemáticamente como una cinética discreta de advección–exclusión–coagulación con fuente y transductor de eventos. Esa correspondencia de estructura no identifica partículas del Modelo Estándar ni unidades físicas.

- termodinámica/hidrodinámica: no identificadas;
- quantum/Bell/Born: no identificados;
- gauge: no identificado;
- gravedad: no identificada;
- masa/inercia: no identificada;
- geometría emergente isotrópica: abierta; la equivelocidad lineal directa está obstruida y E3 externo quedó inconcluso por falta de operador forward.

## Estatus

La teoría interna reparada es exacta por ramas en `D_*` y está apoyada prospectivamente por T12. El contrato original conserva su FAIL T10. La interpretación externa permanece `ROSETTA_PARTIAL`: E1/E2 no contradicen dos ratios nulos pero no validan DEE; la cota `sqrt(3)` obstruye internamente la equivelocidad lineal directa, mientras E3 externo es inconcluso; E4/E5 no aportan endpoints.
