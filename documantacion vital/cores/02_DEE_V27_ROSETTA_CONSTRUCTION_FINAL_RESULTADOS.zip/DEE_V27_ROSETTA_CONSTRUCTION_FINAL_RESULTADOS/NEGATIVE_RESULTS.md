# Resultados negativos — delta Rosetta

## Base importada

Los negativos exactos e históricos V1 permanecen en
`DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/FINAL_PACKAGE/NEGATIVE_RESULTS.md`, SHA-256
`efbd43daa46defcb09e74f23cd93c55ce3aaaf09099671da7ecf226cba0593f6`.

No se repiten aquí la cota causal `min(3t,diam_infty(T_N))` —con velocidad 3 aguda donde el diámetro la permite—, la no-inyectividad para `N>=3`, la inalcanzabilidad de cristalización, la obstrucción global a `O_h`, la insuficiencia de occupancy, los límites de masa en T8 ni los FAIL de campañas históricas. Este documento añade únicamente negativos abiertos por la construcción Rosetta y especifica qué afirmaciones **no** autorizan.

## Nuevos negativos adjudicados

| ID | Resultado negativo | Evidencia | Dominio que realmente cierra | No implica |
|---|---|---|---|---|
| N-R1 | La ecuación literal congelada `M_*F_DEE=G_*M_*` es falsa | T10: 96 mismatches de clausura y 96 de alineamiento, cero fallos de dominio | `M_*`,`G_*` exactamente como se escribieron; colisiones de diagonales opuestas en Panel B | inexistencia de todo cociente efectivo o falsedad del reducer raw |
| N-R2 | La canonización `s=0` para blockers activos `d=0` es incompatible con que todo hijo multifuente retenga `s_out` | testigos T10 con `d_out=0` y carga no nula | combinación de esas dos cláusulas | que `s` sea siempre irrelevante o que deba reinterpretarse físicamente |
| N-R3 | Una sola aplicación lineal y escala común no hacen equiveloces las 26 direcciones | teorema interno: razón extrema mínima `sqrt(3)` | un `A` invertible común y un `tau` común | predicción del resonador o imposibilidad de geometría emergente/no lineal/coarse-grained |
| N-R4 | E1–E5 no validan externamente DEE | E1/E2 sólo compatibles; E3 inconcluso por forward operator; E4/E5 no identificables | set externo y transformaciones congelados más auditoría E3 | falsedad ontológica de `H_DEE` |
| N-R5 | No existe calibración dimensional identificable a partir de estos holdouts | E1–E3 cancelan escala; E4/E5 carecen de datos | parámetros y endpoints E1–E5 | imposibilidad de calibrar con nuevos datos y mapa preregistrado |
| N-R6 | Las coincidencias `alpha/Delta_nu/K/enteros` no son evidencias independientes | grafo genealógico compartido | uso de sus descendientes como “aciertos” separados | inactividad de todos los enteros en el kernel |
| N-R7 | `966` no discrimina la dinámica v27 actual | rama inalcanzable; thresholds `>=50` son equivalentes en el dominio | interpretación de 966 como constante causal medida | que otros umbrales/gates sean inertes |
| N-R8 | `20 Hz` no es un holdout confirmatorio válido | target histórico expuesto y calibración circular | esta campaña Rosetta | que no pueda plantearse otra predicción temporal independiente |

## Anatomía exacta del FAIL T10

El resultado T10 SHA-256 `a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872` ejecutó sin refit el preregistro `2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f`. Las 1,389 trayectorias y 5,598 ticks primarios fueron completados; identidades, dominio y engine controls pasaron.

El caso falsador es estructural y reproducible. Dos fuentes con direcciones corporales opuestas llegan al mismo blanco. El reducer del kernel genera un portador activo con `d_out=0` y carga capada. Al proyectarlo, `M_*` aplica su regla de blocker `d=0` y lo representa con `s=0`; al evolucionar la representación, `G_*` conserva `s_out`. Las dos rutas del diagrama producen registros distintos.

El FAIL es de **representación exacta congelada**, no técnico. No se reparó después del resultado. Una transición poscanonizada u otro alfabeto sería una nueva hipótesis y necesitaría nuevo freeze/holdout.

## Resultados que no son negativos

### T11 es PASS

T11, resultado SHA-256 `207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0`, pasó 448 trayectorias y 896 ticks sin mismatch. Las 56 selecciones de cinco diagonales corporales producen mayoría coordenada y ocho fibras de siete preimágenes. No debe citarse como reparación de T10, porque no genera dirección de salida cero; tampoco como validación física.

### E1 y E2 no son FAIL

Sus predicciones nulas permanecen dentro de los bounds primarios. El estado es `COMPATIBLE_NOT_VALIDATING`, no confirmación ni refutación. La falta de poder discriminante limita la Rosetta externa, pero no contradice el endpoint interno.

### E4 y E5 no son FAIL

Las búsquedas congeladas no encontraron datasets con los metadatos requeridos. `NOT_IDENTIFIABLE` expresa ausencia de observación admisible. Convertirlo en un negativo del mecanismo sería confundir “no medido” con “medido y falso”.

## Genealogía: negativos de interpretación, no de ejecución

La cadena

`alpha* -> Delta_nu* -> K* -> {966,782,194422,19665} -> 19664`

impide contar cada entero como confirmación independiente. Sin embargo, la auditoría v27 distingue sus funciones:

- `782` sí controla gates de fase y deriva cadencias `195,260,391,782`;
- `19665` sí actúa como threshold phase-gated;
- `19664=19665-1` sí capa sumas/deltas;
- `194422` se escribe como payload, no lifetime;
- `966` queda sin efecto por inalcanzabilidad de cristalización;
- `alpha*`, `Delta_nu*`, `K*`, `20 Hz` y wrapper `19658` no controlan el binario actual.

El negativo correcto afecta la independencia y el significado físico de la genealogía. No borra causalidad interna donde está demostrada.

## Alcance externo de N-R4 y N-R5

E1 y E2 prueban sólo que dos ceros relativos no son excluidos por Fermi GRB 090510 y GW170817/GRB 170817A bajo los supuestos congelados. La cota `sqrt(3)` elimina la equivelocidad lineal directa, pero E3 no conecta esa cota con el resonador mediante un forward model. E4/E5 no aportan datos. Por tanto no existe un conjunto de dos familias con apoyo discriminante ni una escala absoluta identificada.

Esto no es un teorema contra masa, termodinámica, hidrodinámica, quantum/Bell, gauge o gravedad emergentes. Es un negativo sobre el paquete de puentes y datos actualmente congelado. Para cambiarlo se necesita un mapa operacional independiente, geometría coarse-grained derivada, calibración separada y nuevas predicciones cruzadas.

## Negativos que continúan abiertos como problemas, no como resultados

No se ha demostrado ausencia de:

- un cociente corregido o ampliado que cierre fuera del caso T10;
- invariantes rango 1–2, relacionales o topológicos en otros sectores;
- masa o inercia colectiva de una clase diferente;
- límite termodinámico/hidrodinámico con ensemble y separación de escalas;
- teoría cuántica operacional o aparato Bell debidamente construido;
- gauge emergente con conexiones/cargas;
- isotropización bajo un coarse-graining especificado.

Estas alternativas permanecen abiertas porque ningún teorema o holdout del paquete cuantifica exhaustivamente sobre ellas. Preservar esa frontera es parte del resultado negativo, no una reserva retórica.
