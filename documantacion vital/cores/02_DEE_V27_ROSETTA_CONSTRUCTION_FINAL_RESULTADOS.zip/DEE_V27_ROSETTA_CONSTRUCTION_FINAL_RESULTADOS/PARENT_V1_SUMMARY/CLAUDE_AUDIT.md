# Auditoría adversarial de Claude T1–T7

Claude se trató como generador de hipótesis. La autoridad usada fue el wheel v27 ejecutado, su C++ sellado, runners y telemetría primaria. El supuesto traspaso global v25→v27 no se aceptó: el bundle decisional Phase0 y el wheel v25 no están en el corte, aunque las propiedades actuales pueden decidirse directamente sobre v27.

## Matriz final

| Tesis | Dictamen | Evidencia decisiva |
|---|---|---|
| T1, cono `r_Cheb(t)<=t` | **REFUTED** | Fuente overflow lee dos vecindades anidadas; testigo binario alcanza distancia 3 en un tick. Cota correcta ≤3t. |
| T2, clock `c_i(t)=c_i(0)+t` | **PROVEN modulo `2^64`** | Todas las ramas y prefill lazy hacen `+1`; wrap ejecutado. Diferencias invariantes mod `2^64`. |
| T3, redundancia con `L=1,094,573,220` | **CONDITIONAL / SHARPENED** | L es múltiplo válido sin wrap. Sólo períodos causalmente activos 195,260,391,782; mínimo 304,980. Preserva raw, no clock; no acción global en wrap. |
| T4, ausencia de invariante aditivo rango 0 | **REFUTED** | Semantic 4 queda fijo punto a punto y no se crea: `Q_obs` y una familia `Q_f` son invariantes. |
| T5, no-inyectividad | **PROVEN con razón corregida** | Dos singletons normales state 1/2, sin dirección/carga y clocks iguales, mapean al mismo vacío+clock. La frase “todos los `2^64` raws” es falsa. |
| T6, traslaciones/`O_h` | **PARTIAL** | Traslaciones exactas y reducer SYM1 conmutativo. `O_h` global refutado por desempate lexicográfico overflow. |
| T7, Bell/CHSH | **CONDITIONAL; NO INSTANCIADO** | La desigualdad requiere outcomes, settings, `lambda`, independencia, factorización y no postselección. No existe ese aparato DEE; además T1 usaba el cono equivocado. |

## T1 — causalidad

`actualizar_voxel(y)` lee radio 1, pero `y` también puede recibir un delta de un emisor vecino `x`. Para seleccionar el destino, `x` recorre candidato `z=x+d` y cuenta vecinos `q=z+e`. Respecto de `y=x+d*`, `q-y=d+e-d*`, radio máximo 3. No hay cascada intratick, por lo que 3 es cota.

El probe v27 construyó dos preimágenes distintas sólo en `q=(3,3,3)` y una salida distinta en `y=(6,6,6)`, distancia 3. Dense y lazy coinciden. V7-C sigue siendo válido en su aparato low-s_reg: midió una subdinámica que no excitó overflow. El error fue generalizar su resultado.

## T2 — clock

La igualdad exacta es modular. Para todo sitio:

`c_i(t)=c_i(0)+t mod 2^64`.

Así, `c_i-c_j` es invariante en el grupo finito. Restar una media real o hablar de edad absoluta exige unwrapping y horizonte sin wrap; no es teorema global.

## T3 — fase y “gauge”

El único gate clock→raw usa `782//(8-n_active)` después de descartar `rule_value=0`. Las cadencias sintácticas de Claude incluyen cuatro ramas que nunca alcanzan el gate. Los períodos necesarios son:

| vecinos activos | período |
|---:|---:|
| 4 tetra | 195 |
| 5 tetra | 260 |
| 6 superviviente | 391 |
| 7 no protegido | 782 |

Su LCM es 304,980; testigos binarios hacen visible cada factor. Desplazar clocks por ese múltiplo preserva raw por inducción mientras no haya wrap. No preserva el full-state, no hay variables de enlace ni carga gauge, y el wrap rompe la acción porque esos períodos no dividen `2^64`.

## T4 — conservación

La prueba de ausencia cuantificaba sobre full-state y falla por un contraejemplo exacto: semantic 4 copia su raw y `aplicar_demux` lo omite. La cristalización, única ruta que podría heredar semantic vecino, es inalcanzable. Luego cualquier suma de una función local soportada sólo en observer es invariante rango 0.

Además, un raw con state 0 y dirección no nula puede crear un vecino; por tanto el argumento “raw aislado colapsa” confundía occupancy con estado causal. Los negativos históricos F-114/F-150 conservan valor sólo para sus bancos/ensembles.

## T5 — many-to-one

La conclusión es correcta. State 1 y state 2 sólo se usan como “no cero” en el singleton inmóvil; ambos tienen `n_active=0`, mueren y dejan clocks idénticos. Esto prueba una colisión de preimágenes, no una cardinalidad de fibra `2^64`. Observer, flechas y semantics aportan excepciones.

## T6 — simetría

Las traslaciones preservan offsets relativos y wrap. Los joins atómicos son sumas conmutativas, y dense/lazy computan el mismo mapa. El reducer de varias fuentes es también independiente del orden.

No lo es el selector overflow: conserva el primer mínimo en el array `MOORE_DXYZ`. Un input invariante bajo inversión deposita en `(-1,-1,-1)` pero no `(1,1,1)`. Las 48/48 transformaciones históricas cubrieron patrones sin el empate causal decisivo; son evidencia sectorial, no un teorema global.

## T7 — Bell

La proposición matemática estándar se mantiene: con outcomes binarios locales, independencia de settings respecto de `lambda`, factorización según el cono correcto y muestreo sin postselección, CHSH≤2. Pero determinismo y alcance finito no prueban esas premisas. El corpus no define fuente, estaciones, settings, outcomes ni `lambda`, y no mide independencia. No es legítimo inferir compatibilidad cuántica, contradicción o “superdeterminismo”.

## Predicciones ausentes de Claude

Claude señaló como posibles piezas faltantes una carga, un modo propagante y una clase móvil. La primera existe al menos en el sector observer y en sectores restringidos, aunque no como energía global. T8 formalizó, generalizó y confirmó prospectivamente las otras dos sobre v27: el singleton direccional ofrece `q(t)`, 26 velocidades y dispersión exacta. La auditoría posterior recuperó antecedentes sectoriales en `TORUS_MOVING` v25 y v25.5-C/F-189, por lo que T8 no se presenta como primera observación histórica. Esto muestra por qué un negativo de aparatos históricos no debía elevarse a imposibilidad global.

Evidencia primaria: `ANALYSIS/binary_api/runtime_probe.json`, `ANALYSIS/binary_api/AUDIT_REPORT.md`, `ANALYSIS/native_theory/EXACT_PROOFS.md`, `RESULTS/native_ballistic/t8_result.json` y `RESULTS/observer_pump/t9_result.json`.
