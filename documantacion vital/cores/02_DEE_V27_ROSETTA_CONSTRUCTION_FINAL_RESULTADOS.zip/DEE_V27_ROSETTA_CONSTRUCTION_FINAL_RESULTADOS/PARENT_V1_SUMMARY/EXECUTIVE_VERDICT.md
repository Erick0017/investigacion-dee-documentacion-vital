# Veredicto ejecutivo — DEE v27

## Respuesta corta

DEE v27 **sí posee una arquitectura matemática transversal interna**, pero **no posee todavía una Rosetta física externa validada**. La arquitectura mínima es un autómata celular finito y determinista sobre un toro 3D, síncrono, etiquetado y dirigido, con un clock afín independiente. Su raw combina soporte, flechas, carga/procedencia y controles semánticos; el clock aporta fase local congelada. Esa misma descomposición explica supervivencia, nacimiento, transporte, colisión, overflow, causalidad, anisotropía, invariantes y sectores reversibles.

El cierre nuevo decisivo es que, para `N>=5`, DEE sí contiene una clase móvil exacta: un singleton normal con cualquiera de las 26 direcciones Moore se traslada un voxel por tick, conserva `s_reg`, posee coordenada `q(t)=q(0)+td mod N`, período raw N y dispersión de advección. Tras T8 se recuperó que el fixture v25 `TORUS_MOVING` ya era el caso especial `d=(1,0,0)` y sus 12 hashes reconstruyen esa trayectoria, aunque históricamente sólo se usó para equivalencia dense/lazy. También se recuperó v25.5-C/F-189: 60/60 carriles separados y 2,226 pasos coinciden exactamente con `np.roll`, con `P=L` en packed/state/direction/semantic y `P=1` en `s_reg` constante. T8 es la formalización y confirmación prospectiva exhaustiva realizada por esta misión sobre v27: pasó 1,872 trayectorias/50,544 ticks más 1,300 colisiones sin mismatches; una réplica independiente pasó 624 trayectorias, 36 casos de dos cuerpos y 15,600 colisiones en cuatro implementaciones, también sin mismatches. Esto refuta la promoción de “no se resolvió modo/paquete en esos aparatos” a “no existe ninguno”. No convierte al singleton en partícula física externa ni hace de `P=L` una ley universal.

El segundo descubrimiento es que `SEM_OBSERVER` no es un aparato de medición: es un raw fijado punto a punto y, en el aparato aislado para `N>=5`, una dirección Moore no nula lo convierte en fuente persistente cuyo tren tiene fórmula cerrada para `1<=t<N`, incluso con `state=0`. T9 pasó 936 casos, 208 repeticiones cruzadas y 18 controles, cero mismatches.

## Identidad ejecutada

| Objeto | SHA-256 | Dictamen |
|---|---|---|
| wheel `cp313-win_amd64` | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` | verificado |
| kernel `.pyd` | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` | verificado y ejecutado |
| package | `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4` | verificado |
| C++ incluido | `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab` | verificado contra `RECORD` |

Se usó CPython 3.13.11 x64, NumPy 2.2.6, `-I -B` e importación desde una extracción hash-verificada dentro del workspace. La instalación histórica coincide por hash, pero no fue aceptada por nombre. El binario usa `P_KERNEL=19665`, cap 19664. El módulo Python exporta erróneamente 19658 y contiene métodos públicos rotos; el binario, no el wrapper narrativo, es la autoridad dinámica.

## Qué es exactamente `F_DEE`

`F_DEE` es un mapa finito

`F:(raw,clock) -> (raw',clock')`

sobre `N^3` sitios de un toro cúbico. Es determinista, many-to-one y traslacionalmente equivariante. Es un skew-product: `clock'=clock+1 mod 2^64`, mientras raw es actualizado por una regla local por ramas y gates de fase. La dependencia raw máxima de un tick tiene radio Chebyshev 3, no 1, por la selección anidada de destino overflow.

Su núcleo específico consta de:

- supervivencia por conteo Moore y firma tetraédrica;
- nacimiento XNOR por pares antipodales;
- transporte por flechas y reducer conmutativo de colisiones;
- `s_reg` como label/counter/threshold/gradiente;
- semantic como selector de control;
- un segundo transporte overflow con desempate lexicográfico.

La eventual periodicidad de cualquier estado finito, la existencia formal de basins y la representación Koopman de una permutación son propiedades genéricas de sistemas finitos. Los predicados, sectores y reducer anteriores sí son específicos de DEE v27.

## Respuestas a las preguntas centrales

| Pregunta | Adjudicación |
|---|---|
| ¿Arquitectura transversal específica? | **Sí, interna:** `support + arrows + s_reg + semantic controls + frozen clock phase`. Explica múltiples mecanismos y predijo T8/T9. |
| ¿Conjunto pequeño de objetos nativos? | **Sí:** soporte activo/existente, campo direccional, carga/procedencia, semantic y fase. Occupancy solo no es suficiente. |
| ¿Conservaciones/invariantes? | **Sí, con nivel declarado:** offsets de clock módulo `2^64`; raws observer punto a punto y sus sumas rango 0; invariantes de órbita y transporte en el sector balístico; balance de `s_reg` en colisión sólo antes del cap. No se identificó energía global. |
| ¿Modos colectivos? | **Modo de transporte exacto sectorial:** 26 velocidades y `omega=k·d`. Es extensible a gases no interactuantes separados. No se estableció un modo interactuante universal ni una clase de universalidad. |
| ¿Qué es materia DEE? | La clase operacional mínima demostrada es el portador direccional singleton y sus gases restringidos: persiste, tiene identidad raw, `q`, velocidad y colisión. Fases densas fijas y defects observer son otras clases, no la misma materia. Occupancy genérico no equivale a materia. |
| ¿Geometría/causalidad? | Toro combinatorio fijo más grafo temporal de dependencias/first-passage dependiente del estado. Cota universal `3t`, transporte común `t`. V7-C mostró modulación por organización/historia/topología en su aparato. No hay tensor métrico ni gravedad derivados. |
| ¿Función de clock? | Contador modular afín y fase local congelada. Sus diferencias son invariantes; raw ve un período mínimo común 304,980 sin wrap. No es tiempo SI ni gauge físico demostrado. |
| ¿Función de `s_reg`? | Label transportado; suma capada en colisiones; contador de procedencia phase-gated; gradiente y threshold overflow. No energía universal ni masa. |
| ¿Función de `direction`? | Routing y velocidad exacta en el singleton; en materia superviviente puede reemplazarse por el signo del gradiente. No momentum aditivo global. |
| ¿Función de `semantic`? | Control de ramas/protección/proveniencia programada. `observer` fija/inyecta; `orphan` cambia actividad y respuesta a delta; routing normaliza a semantic 1. No especie física establecida. |
| ¿Función de raw? | Estado computacional causal completo del sitio. Incluso `state=0` con dirección puede causar un nacimiento; raw no es un observable físico directo. |
| ¿Rosetta cuantitativa no arbitraria? | **No.** No existe una transformación dimensionada, congelada y validada contra holdout externo que prediga varios observables sin refit. |
| ¿Teoría efectiva conocida? | Sólo un puente exacto restringido a advección/lattice-gas sin colisiones. No se derivaron Newton, Lorentz/Einstein, Navier–Stokes, Schrödinger/Born ni Yang–Mills. |
| ¿Masa/inercia? | No identificada. En T8 velocidad es independiente de state y `s_reg`; las colisiones tampoco ponderan dirección por `s_reg`. No hay fuerza–aceleración ni parámetro inercial congelado. |
| ¿Materia–geometría? | Hay respuesta causal del sustrato en V7-C y materia móvil T8, pero no una misma clase con `M_I` y `M_G` definidos independientemente. El puente de equivalencia permanece no identificable, no refutado globalmente. |
| ¿Termodinámica/hidrodinámica? | Hay entropías informacionales y una continuidad sectorial de vuelo libre; colisiones introducen fuentes/sumideros y cap. Faltan energía, temperatura, ensemble/equilibrio, campos lentos, stress y cierre constitutivo. No identificadas; tampoco imposibles por T4. |
| ¿Quantum/Bell? | Ciclos/permutaciones admiten formalismo unitario genérico, no mecánica cuántica. No existen observables, Born ni composición física. CHSH≤2 es condicional a un aparato Bell y a independencia/factorización; ese aparato no existe. |
| ¿Simetrías/gauge? | Traslaciones toroidales exactas. `O_h` global es falso por tie overflow, aunque sobrevive en sectores. El clock tiene una redundancia raw sin wrap, no gauge dinámico global. |
| ¿Constantes históricas? | 19665/19664, 782 y 194422 son inputs/literales o derivados internos; 391 es contextual; 966 está compilado pero su rama es inalcanzable; alpha/Delta_nu y 20 Hz son genealogía constitutiva/externa, no predicciones independientes. |
| ¿Descubrimiento no anticipado? | Sí: promoción matemática/confirmación v27 del sector balístico históricamente subinterpretado, álgebra de colisiones completa, observador-bomba, manta suficiente `raw B3 + clock B1`, período causal mínimo 304,980 y diagnóstico de bins de ventana D6. |

## Claude T1–T7

| ID | Dictamen v27 | Corrección |
|---|---|---|
| T1 | **REFUTED** | Radio raw de un tick ≤3 y se alcanza; cono ≤3t. |
| T2 | **PROVEN mod `2^64`** | La versión en enteros requiere no-wrap. |
| T3 | **CONDITIONAL / sharpened** | 1,094,573,220 funciona sin wrap, pero el mínimo causal es 304,980; sólo preserva raw, no full-state, y falla como acción global en wrap. |
| T4 | **REFUTED** | El contador y toda función local de raws observer son invariantes rango 0 no triviales. |
| T5 | **PROVEN con testigo corregido** | State 1 y 2 aislados colisionan; no todos los `2^64` raws aislados colapsan. |
| T6 | **PARTIAL** | Traslaciones y reducer SYM1 exactos; `O_h` global refutado por tie lexicográfico. |
| T7 | **CONDITIONAL / no instanciado** | Bell exige fuente, settings, outcomes, independencia y factorización operacional; no hay test DEE legítimo. |

## Qué sobrevivió y qué no en la historia

Sobrevive:

- identidad/hash del kernel reportado por las campañas;
- equivalencia dense/lazy para el dominio válido;
- el fixture v25 `TORUS_MOVING`, ahora reconstruido como un singleton balístico que cruza el toro, aunque su PASS publicado sólo certificaba equivalencia de backends;
- many-to-one, con prueba corregida;
- pluralidad de regímenes morfológicos y basins empíricos;
- V7-C como evidencia interna de mediación causal distribuida y first-passage dependiente de organización/historia/topología;
- V7-B como transferencia de un lector de cociente en 24/24, no como trayectoria de materia;
- los negativos acotados de V6-D, V6-F y Part-C.

No sobrevive:

- cono universal radio 1;
- ausencia universal de invariantes rango 0;
- simetría cúbica global;
- cristalización como mecanismo ejecutable activo;
- `TTL_ORFAN=194422` como lifetime observado;
- cualquier promoción de occupancy a materia, `s_reg` a energía, direction a momentum o clock a tiempo físico;
- cualquier PASS de Rosetta física externa.

Los “períodos” D6 tampoco sobreviven como periodicidad: 284/300 picos son los primeros cinco bins de la ventana; seis controles no periódicos reproducen exactamente las secuencias `T/j`. El resultado correcto es “escalas FFT de ventana”, no osciladores.

## Alcance de los negativos

La ausencia histórica de paquete o velocidad de grupo cierra esos detectores, no todos los modos: T8 suministra un contraejemplo constructivo. Los grados C de V7-A/B cierran relaciones simples en sus dominios, no toda materia emergente. No hallar una carga energía-like fuera de observer/sectores no es un teorema de imposibilidad de hidrodinámica. Los fallos A6/C4 de campañas fueron técnicos y no cuentan como negativos científicos.

## Bajo `H_DEE`: la pieza exacta que falta

Falta una **Rosetta operacional congelada y externamente identificable**:

`(distribución de preparaciones DEE, coarse-graining causalmente suficiente, mapa de observables y unidades) -> (resultados físicos operacionales)`.

Debe calibrarse una sola vez sin usar los targets como inputs y predecir en holdouts externos, con incertidumbre, al menos dos sectores independientes. Dentro de esa misma construcción deben aparecer energía–momentum conservado/efectivo, un límite espaciotemporal compatible con Lorentz, probabilidades de medición/Born y el aparato Bell con independencia auditable. Sin esa pieza, no existe forma de decidir desde el kernel qué estado representa nuestro vacío, qué tick/voxel vale en SI, qué ensemble es físico ni qué raw corresponde a una medición. Esa información no puede obtenerse mediante más interrogaciones internas del mismo `F_DEE`; requiere una correspondencia externa y datos independientes.

## Stopping rule

Las ambigüedades locales capaces de cambiar el veredicto central fueron interrogadas: identidad, T1–T6, transporte/movilidad, modos, reversibilidad sectorial, colisiones, semantic observer y el sesgo temporal D6. Las preguntas restantes o bien son abiertas matemáticas no cubiertas por un teorema total —por ejemplo invariantes de rango superior fuera de los sectores descritos— pero no alteran el hecho de que ya existen invariantes/transportes sectoriales, o bien requieren la Rosetta/datos externos anteriores. Por ello se satisface la regla de cierre B+C sin convertir lo no identificado en imposibilidad ontológica.
