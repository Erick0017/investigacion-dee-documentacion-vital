# Auditoría de afirmaciones históricas

## Criterio

Esta auditoría separa lo que un artefacto **ejecutó**, lo que su aparato podía decidir y la interpretación posterior. Se revisaron 8,922 archivos, 17 ZIP de campañas, 11 manifiestos JSON, telemetría primaria seleccionada, runners y 51 fuentes documentales extraídas. No se reejecutaron campañas ya selladas. El wheel v27 se auditó y ejecutó de forma independiente.

Las categorías usadas son: `SURVIVES`, `SURVIVES_SCOPED`, `REFUTED`, `SUPERSEDED`, `TECHNICAL_FAILURE`, `NO_IDENTIFICABLE` y `EXTERNAL_UNVALIDATED`. Un FAIL de un detector sólo se aplica al dominio y al observable congelados por ese detector.

## Corrección genealógica sobre movilidad

La primera lectura del corpus limitado a `tests` encontró el nombre `TORUS_MOVING`, pero no su constructor. Una extensión forense posterior, sólo de lectura, recuperó dos primarios v25 fuera de ese corte:

1. `VERSION_25/tests/test_v25_lazy_audit.py` construye `TORUS_MOVING` como un único raw normal `state=1`, `s_reg=0`, `direction=(1,0,0)`, `semantic=1` en un toro `N=24`. El JSON histórico compara dense v24 y lazy v25 durante 12 ticks y pasa 12/12. Los hashes de estado publicados concuerdan con la trayectoria reconstruida `q(t)=((23+t) mod 24,12,12)`.
2. La campaña v25.5-C prepara carriles de singletons con dirección positiva de eje y separación `L>=4`, y compara cada paso con `np.roll(previous,1)`. El primario registra 60/60 trials, 2,226 pasos, `shift_hamming=0`, `translation_exact_fraction=1` y ocupación preservada. El período `P=L` en packed/state/direction/semantic es corolario de traslación sobre un toro y de la simetría de la preparación; `sreg_projection` tiene período 1 porque todo `s_reg=0`.

Por tanto, el movimiento exacto no apareció por primera vez en T8. Históricamente ya existían instancias directas, aunque `TORUS_MOVING` se usó como regresión entre backends y v25.5-C como protocolo sectorial. T8 aporta otra cosa: una formulación fuente-primero, congelada antes del holdout, generalizada a las 26 direcciones, estados/cargas/clocks, dos tamaños, motores y colisiones sobre el wheel v27 real. La afirmación correcta es **continuidad histórica más generalización y confirmación prospectiva v27**, no descubrimiento ex nihilo.

## Matriz de afirmaciones decisivas

| Afirmación histórica | Veredicto actual | Alcance exacto |
|---|---|---|
| El kernel de campañas es el v27 congelado de hash `0b17ba...c6ff` | `SURVIVES` | El `.pyd` extraído del wheel local coincide y fue el módulo importado bajo `-I -B`. |
| Dense y lazy son equivalentes | `SURVIVES` | Para invocaciones ABI válidas, con buffers separados y `n_hilos>=1`; la fuente lo prueba y T8/T9 lo verifican en 980 comparaciones discriminantes. |
| `TORUS_MOVING` era sólo un nombre sin trayectoria recuperable | `SUPERSEDED` | El constructor v25 y los 12 hashes se recuperaron fuera del corte inicial de `tests`; sí implementa el caso balístico axial. |
| v25.5-C/F-189 exhibe traslación exacta | `SURVIVES_SCOPED` | Carriles axialmente dirigidos y separados; no prueba movilidad de toda morfología ni reduce F-137 random-cloud al sector T8. |
| No se resolvió modo de grupo en Part-C/C7 | `SURVIVES_SCOPED` | 9/9 preparaciones y el detector congelado de C7; no es ausencia global de modos. |
| No se resolvió paquete en V6-D | `SURVIVES_SCOPED` | Los cuatro protocolos y gates de screen usados; T8 no convierte ese FAIL en PASS. |
| No existe ningún modo/portador móvil en DEE | `REFUTED` | T8 da un contraejemplo constructivo exacto y v25/v25.5-C muestran antecedentes sectoriales. |
| V6-F validó una familia de transferencia completa | `REFUTED` | Pasaron soporte causal/dirección/corredor; fallaron decodificación ciega, repertorio y robustez. |
| V7-A identificó materia universal | `REFUTED` | La campaña terminó en grado C y verificó cero clusters bajo su gate `matter-like`. |
| V7-B validó una cadena Rosetta simple | `REFUTED` | Grado C; el lector de cociente sí transfirió 24/24, pero la cadena física simple no. |
| V7-C demuestra mediación causal distribuida interna | `SURVIVES_SCOPED` | Modulación por geometría, historia y topología en el aparato, con `external_physics_claimed=false`; no prueba gravedad o relatividad. |
| El cono causal global tiene radio 1 por tick | `REFUTED` | La rama overflow alcanza radio raw 3 en un tick; V7-C sólo observó un régimen sin esa ruta. |
| El clock avanza exactamente una unidad | `SURVIVES` | Exacto módulo `2^64`; no como igualdad entera sin wrap. |
| `L=1,094,573,220` es el período/gauge fundamental | `SUPERSEDED` | Es un múltiplo raw válido sin wrap, no mínimo ni simetría del full-state. El período causal mínimo común es 304,980. |
| No hay invariantes aditivos de rango 0 | `REFUTED` | Los raws `semantic=4` quedan fijos y generan `Q_f`; no se identificó por ello una energía general. |
| `F_DEE` es no inyectiva | `SURVIVES` | Testigo corregido state 1/state 2 aislado. La promoción “todos los `2^64` raws colapsan” es falsa. |
| El grupo cúbico completo es simetría global | `REFUTED` | El desempate lexicográfico overflow rompe inversión; traslaciones sí son exactas y `O_h` puede sobrevivir sectorialmente. |
| Cristalización por gradiente opera en el kernel | `REFUTED` | Máximo posible 983,025 frente a requisito 18,996,390; la rama es inalcanzable. |
| `TTL_ORFAN=194422` es una vida media observada | `REFUTED` | Es un payload literal escrito bajo una rama; el subtest histórico reportó `hit_count=0`. |
| Los picos D6 son períodos nativos/Fibonacci | `REFUTED_AS_INFERENCE` | 284/300 son bins FFT 1–5 y seis controles no periódicos producen `T/j`; el cálculo espectral mismo es correcto. |
| Occupancy es materia o estado causal suficiente | `REFUTED` | Un raw con `state=0` y dirección puede crear soporte; se requieren raw `B3` y clock `B1` para un paso exacto. |
| `s_reg` es energía o masa | `EXTERNAL_UNVALIDATED` | Es carga/etiqueta transportada, suma capada, contador y fuente de gradiente; no existe calibración ni balance energético universal. |
| `direction` es momentum | `EXTERNAL_UNVALIDATED` | Es velocidad/routing exacto en T8, pero las colisiones usan `sign(sum d)` sin ponderación por `s_reg`. |
| Semantic `observer` mide el sistema | `REFUTED` | T9 demuestra un sitio fijado y una fuente/boundary pump; no hay protocolo de medición. |
| Formula Bridge identifica clásica/GR/hidro | `NO_IDENTIFICABLE` | QM/termo sólo tienen paralelos formales y SR condiciones internas parciales; no hay PASS externo. |
| DEE reproduce nuestra física | `EXTERNAL_UNVALIDATED` | Falta una Rosetta operacional congelada y holdouts físicos externos independientes. |

## Campañas: qué permanece abierto y qué queda cerrado

- Refoundation-A y Replay-A aportan módulos científicos utilizables, pero sus estados globales `completed_with_failures` provienen de A6 técnico. Un `LNK1104` o un `PermissionError` no son evidencia científica.
- Part-C/C7 y V6-D son negativos reales de sus aparatos. Quedan conservados como FAIL aun después de T8; lo refutado es su universalización.
- Part-D demuestra pluralidad de regímenes y entrega telemetría útil. No promovió automáticamente una forma natural. La lectura periódica posterior de D6 no supera los controles de ventana.
- V6-C refuta cierre M0 en 64/64 y V6-E muestra divergencia de fibras iguales para M0/M1 en 24/24. M2/M3 no tuvieron pares iguales, por lo que no deciden suficiencia.
- V7-A/B cierran relaciones simples congeladas, no todas las ontologías colectivas. V7-C es la evidencia interna más fuerte de mediación por sustrato, no una validación externa.
- La ruta nominal `...V7_B..._WORK` contiene un fallo técnico; el resultado final corregido está en `tests/RESULTS` y es espejo exacto del ZIP de 824 miembros.

## Constantes y genealogía

| Constante/nombre | Estatus ejecutable | Lectura permitida |
|---|---|---|
| `P_KERNEL=19665`, cap 19664 | Binario real | Umbral y saturación internos; el wrapper publica erróneamente 19658. |
| 782 | Literal del gate de procedencia | Cadencia interna; 391 es `782//2` en un contexto, no constante universal. |
| 966 | Literal de cristalización | Código inalcanzable, no fenómeno. |
| 194422 | Payload de ORPHAN | No lifetime observado. |
| `alpha*`, `Delta_nu*` | Construcción documental | Inputs/ley constitutiva, no predicción independiente. |
| 20 Hz | Correspondencia externa propuesta | Sin calibración/holdout; no validada. |
| “masa informacional”, entropía binaria | Funciones de occupancy | Conteo/entropía informacional, no masa o termodinámica física. |

## Integridad de evidencia y ausencias

Los 17 ZIP son legibles; los 11 manifiestos JSON concuerdan exactamente con 8,512 miembros y 139 hashes muestreados. Persisten ausencias genealógicas: bundle decisional Phase0, Part-E1, cierre final de V6-A y algunos runners/detalles sólo en ZIP o WORK. Estas ausencias impiden ciertas afirmaciones de continuidad histórica, pero no afectan los teoremas v27 probados directamente.

Fuentes de auditoría compactas: `ANALYSIS/campaigns/CAMPAIGN_AUDIT.md`, `ANALYSIS/docs_claims/DOCUMENT_CLAIMS_AUDIT.md`, `ANALYSIS/historical_bias/D6_PERIOD_BIN_AUDIT.md`, `ANALYSIS/ballistic_independent/HISTORICAL_GENEALOGY.md` y `ANALYSIS/binary_api/AUDIT_REPORT.md`.
