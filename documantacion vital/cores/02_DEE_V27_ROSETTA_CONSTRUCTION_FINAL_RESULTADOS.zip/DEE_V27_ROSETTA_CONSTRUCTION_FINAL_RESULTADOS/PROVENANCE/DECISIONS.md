# Rosetta decision log

## R-0001 — Immutable V1 base

- V1 is imported by hashes and treated as closed evidence.
- No inventory, wheel audit, T1–T9, D6 or historical campaign is repeated unless a new Rosetta claim logically requires an independent check.
- All continuation writes remain under `ROSETTA_CLOSURE`.

## R-0002 — Evidence order

1. Discover predictive equivalence and response objects internally.
2. Select bridge families using DEE evidence only.
3. Freeze `M_*`, `G_*`, `K_*`, calibration allowances, predictions and falsifiers.
4. Execute untouched internal holdouts and an inverse prediction.
5. Only then retrieve external holdout values from primary sources.
6. Classify the result as validated, partial, refuted for an exhaustive class, or not identifiable.

## R-0003 — Prospective resolution of the external rubric

- `EXTERNAL_BLIND_POLICY.md` (five dimensions scored 0--3) retains normative authority.
- The broader exploratory rubric in `INTERNAL_BRIDGE_SELECTION.*` is preserved as an auxiliary analysis; it will not be represented as the preregistered rubric.
- Re-evaluation before any external lookup gives: E1 nondispersion 15/15; E2 common speed across assigned classes 14/15; E3 Euclidean-linear embedding no-go 15/15; E4 observer occlusion/phase analogue 15/15. These scores measure readiness for falsification, not physical truth.
- E3 is a logical gate: no common nonzero linear spatial map makes all 26 Moore directions equispeed in a Euclidean norm. The direct `raw Cartesian -> Euclidean space` Rosetta is rejected before external data are opened.
- E1 and E2 will be dimensionless shadow holdouts with no scale fitted by label or class. Compatibility will not be described as DEE-specific validation.
- E4 is evaluated separately as mechanism transfer. If no external dataset satisfies the frozen design, its status is `NOT_IDENTIFIABLE`, not support for or refutation of the internal core.

## R-0004 — T10 se conserva FAIL; reparación estado–evento posterior

- T10 se ejecutó sin refit y falló sólo en la clase exhaustiva de pares body-diagonal opuestos: 96 fallos de cierre y 96 desalineaciones iteradas, con cero fallos de dominio. No se cambia su veredicto.
- El conflicto pertenece a la especificación congelada: `M_*` canoniza `s=0` para un portador activo `d=0`, mientras `G_*` conservaba la suma `S` de toda colisión multifuente.
- La reparación posterior separa estado predictivo y evento instantáneo: `G_dagger` canoniza el producto `d=0`, mientras `J_dagger=(q,u,S)` retiene el raw de colisión antes de la canonización.
- La fórmula, selección de casos y criterios de T12 quedaron congelados antes de crear/ejecutar su runner. T12 usa aridades 3/4/6 y `N=19`, no los pares T10 ni las selecciones de cinco de T11.
- Un PASS T12 sólo podrá confirmar prospectivamente esta hipótesis posterior en su nuevo dominio. No convertirá T10 en PASS ni reparará retrospectivamente el contrato original.

## R-0005 — T12 adjudica la reparación, no reabre T10

- T12 pasó en su única ejecución: 748 trayectorias/1,496 ticks primarios, 514 productos `u=0`, 234 controles `u!=0`, cero fallos de dominio, cero mismatches y 16/16 controles de motor.
- Se acepta prospectivamente `G_dagger/J_dagger` en el panel nuevo y bajo `D_*`: el estado predictivo canoniza la carga no propagante de `d=0`, mientras el evento raw conserva `S`.
- T10 continúa `FAIL_NO_REFIT`; el contrato original continúa inmutable. El resultado final distingue `Rosetta congelada original fallida` de `reparación estado–evento confirmada internamente`.
- La clasificación global de la misión es `ROSETTA_PARTIAL`: existe una transformación operacional interna común, pero no una Rosetta física externa validada ni una geometría/escala independiente.

## R-0006 — Corrección adversarial de E3 sin refit

- Se preserva el resultado original `e3_e5_results.json` y su `FAIL_BRIDGE`; no se reescribe el historial.
- Una auditoría independiente detectó que el contrato no define el operador forward entre las 26 velocidades discretas y el coeficiente de frecuencia de resonador rotante. El endpoint de Nagel no es literalmente el ratio `max(v)/min(v)`.
- La síntesis final supersede por ello la adjudicación externa con `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`.
- Sobrevive intacto el teorema algebraico `max(v)/min(v)>=sqrt(3)` y, con él, la imposibilidad de convertir las 26 direcciones en equivelocidad mediante una sola `A` lineal y una escala común.
- No se ajusta un operador alternativo tras ver el dato. Una prueba externa futura exige un forward model preregistrado y un holdout óptico nuevo.

## R-0007 — Stopping rule y sello único

- La auditoría científica final no encontró contradicciones residuales después de restaurar explícitamente los dominios `N>=3`, pre-wrap, `D_*` y la saturación por diámetro toroidal.
- Los ledgers finales contienen 45 claims y 13 experimentos; sus CSV fueron materializados, inspeccionados y reimportados con `artifact_tool`, con paridad íntegra respecto de JSON y hashes de evidencia renovados.
- Ningún sweep interno adicional puede crear el operador forward óptico ausente, una calibración dimensional independiente o los endpoints externos no documentados. Esas piezas son el obstáculo estructural que satisface la stopping rule.
- El estado científico queda `ROSETTA_PARTIAL`. Se construirá exactamente un ZIP final; su SHA-256 se mantendrá adyacente porque incluir el hash del contenedor dentro del propio contenedor sería autorreferencial.
