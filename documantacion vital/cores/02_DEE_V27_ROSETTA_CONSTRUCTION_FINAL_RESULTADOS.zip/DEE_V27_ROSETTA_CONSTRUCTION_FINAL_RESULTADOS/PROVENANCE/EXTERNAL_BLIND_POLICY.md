# External holdout blindness policy

No external numerical value, uncertainty or holdout outcome may be retrieved before the bridge-selection record and the Rosetta contract are frozen and hashed.

Bridge families are ranked only from internal DEE evidence using five preregistered dimensions, each scored 0–3:

1. exactness of the DEE relation;
2. reuse of the same `M_* / G_* / K_*` core;
3. absence of target-fitted parameters;
4. existence of a dimensionless external observable;
5. ability to falsify rather than merely resemble.

Permitted external calibration is limited to one common length/time conversion if an absolute speed is reported. Dimensionless speed differences, phase slopes and anisotropy ratios receive no fitted scale. A monotone association between the DEE transported label and an external carrier label is permitted only when the DEE prediction is label-independent, so the association cannot tune the result.

Primary papers, primary datasets and authoritative CODATA/PDG-like compilations are admissible. Review articles, blogs and search snippets are not evidence.

