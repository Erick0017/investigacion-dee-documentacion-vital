# Dependency plan

| Stage | Question | Decisive output | Cost control |
|---|---|---|---|
| P1 | What predictive quotient does `F_DEE` induce in exact reachable sectors? | Stable partition, minimal sufficient labels, proof domain | Restricted enumeration and symbolic branch analysis |
| P2 | Can one `Z` support causality, geometry, transport and response? | Common `M_*`, closed `G_*`, compositional `K_*` | Reuse T8/T9 and small discovery probes |
| P3 | What bridge families are internally best prepared? | Selection frozen before external values | Score only existing DEE evidence |
| P4 | Does the frozen core predict unused v27 trajectories/responses? | Internal holdout and inverse-prediction adjudication | Small factorial design with exact falsifiers |
| P5 | Do at least two external observable families preserve the same relations? | External holdout table with primary sources | Dimensionless relations; minimal calibration |
| P6 | What closure status is justified? | Constructed Rosetta, limits, ledger, reproducible package | Stop when remaining uncertainty is structurally external |

