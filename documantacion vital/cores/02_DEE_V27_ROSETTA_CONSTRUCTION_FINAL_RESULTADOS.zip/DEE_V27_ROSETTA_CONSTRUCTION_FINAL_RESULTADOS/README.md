# DEE v27 Rosetta Construction — paquete final

Este paquete cierra la continuación Rosetta de `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1` sin reabrir T1–T9, D6, el inventario o la auditoría del wheel.

Empiece por:

1. `EXECUTIVE_VERDICT.md` — veredicto compacto;
2. `DEE_ROSETTA_V27_CONSTRUCTED.md` — transformación operacional completa;
3. `INTERNAL_HOLDOUTS.md` — T10 FAIL, T11 PASS y T12 PASS sin refit;
4. `ROSETTA_EXTERNAL_HOLDOUTS.md` — E1–E5;
5. `ROSETTA_CLAIM_LEDGER.csv` — cada afirmación clasificada y enlazada a evidencia;
6. `REPRODUCE.ps1` — verificación y reproducción opcional.

Los scripts `prepare_rosetta_final_package.py`, `generate_rosetta_tables.py`, `validate_rosetta_ledger.mjs`, `build_rosetta_manifest.py` y `create_rosetta_zip.py` son helpers de construcción del árbol fuente; la entrada portable del paquete ya construido es `REPRODUCE.ps1`. `verify_wheel_extraction.py` sí puede ejecutarse sobre los paths empaquetados para comprobar paridad byte a byte con el wheel.

No invoque directamente `run_t10_rosetta_core_holdout.py` ni `run_t12_state_event_repair.py` dentro del árbol sellado: ambos escriben en rutas de salida fijas. Use exclusivamente `REPRODUCE.ps1 -RunHoldouts`, que prepara un scratch externo nuevo y conserva intactos los resultados originales.

Identidad normativa:

- wheel: `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`;
- wrappers Python extraídos: `__init__.py` `7e2991b1...`, constantes `339ebcd5...`, API `d777704d...`;
- `.pyd`: `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`;
- fuente C++: `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab`;
- contrato original: `d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`;
- contrato post-T10: `b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f`.

El estado científico es `ROSETTA_PARTIAL`: arquitectura interna construida y reparada prospectivamente; identidad física externa no validada.
