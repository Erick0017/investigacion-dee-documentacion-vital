[CmdletBinding()]
param(
    [string]$PythonPath = 'D:\Descargas\ANACONDA MINICONDA\python.exe',
    [switch]$RunHoldouts,
    [string]$ParentV1Zip = '',
    [string]$ScratchPath = ''
)

$ErrorActionPreference = 'Stop'
if (Get-Variable -Name PSNativeCommandUseErrorActionPreference -ErrorAction SilentlyContinue) {
    $PSNativeCommandUseErrorActionPreference = $false
}
$packageRoot = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd([char[]]@('\', '/'))
$hashList = Join-Path $packageRoot 'HASHES.sha256'

function Test-IsSameOrDescendant {
    param([string]$Candidate, [string]$Base)
    $candidateFull = [IO.Path]::GetFullPath($Candidate).TrimEnd([char[]]@('\', '/'))
    $baseFull = [IO.Path]::GetFullPath($Base).TrimEnd([char[]]@('\', '/'))
    if ($candidateFull.Equals($baseFull, [StringComparison]::OrdinalIgnoreCase)) { return $true }
    return $candidateFull.StartsWith($baseFull + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase)
}

if (-not (Test-Path -LiteralPath $hashList -PathType Leaf)) { throw "Missing HASHES.sha256" }
$failures = [System.Collections.Generic.List[string]]::new()
$listed = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
foreach ($line in Get-Content -LiteralPath $hashList) {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    if ($line -notmatch '^([0-9a-fA-F]{64})\s+\*(.+)$') {
        $failures.Add("Malformed checksum row: $line")
        continue
    }
    $expected = $Matches[1].ToLowerInvariant()
    $relativePosix = $Matches[2].Replace('\', '/')
    if (-not $listed.Add($relativePosix)) { $failures.Add("Duplicate checksum path: $relativePosix"); continue }
    $target = [IO.Path]::GetFullPath((Join-Path $packageRoot $relativePosix.Replace('/', [IO.Path]::DirectorySeparatorChar)))
    if (-not (Test-IsSameOrDescendant -Candidate $target -Base $packageRoot)) { $failures.Add("Path escapes package: $relativePosix"); continue }
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { $failures.Add("Missing: $relativePosix"); continue }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { $failures.Add("Hash mismatch: $relativePosix") }
}

$manifestPath = Join-Path $packageRoot 'MANIFEST.json'
if (-not (Test-Path -LiteralPath $manifestPath -PathType Leaf)) {
    $failures.Add('Missing MANIFEST.json')
} else {
    $manifest = Get-Content -Raw -LiteralPath $manifestPath | ConvertFrom-Json
    if ($manifest.schema -ne 'dee.v27.rosetta.final_package.v1' -or $manifest.package -ne 'DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS' -or $manifest.status -ne 'COMPLETE' -or $manifest.scientific_verdict -ne 'ROSETTA_PARTIAL') { $failures.Add('Manifest header/status changed') }
    if (-not $manifest.freeze.discovery_then_freeze_then_holdout -or -not $manifest.freeze.original_t10_contract_unchanged_after_t10 -or -not $manifest.freeze.t12_repair_frozen_before_t12 -or -not $manifest.freeze.no_refit_within_each_holdout) { $failures.Add('Manifest freeze assertions changed') }
    $manifestSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
    [int64]$manifestByteSum = 0
    foreach ($item in $manifest.files) {
        $relativePosix = ([string]$item.path).Replace('\', '/')
        if ([string]::IsNullOrWhiteSpace($relativePosix)) { $failures.Add('Manifest contains a blank path'); continue }
        if (-not $manifestSet.Add($relativePosix)) { $failures.Add("Duplicate manifest path: $relativePosix"); continue }
        $target = [IO.Path]::GetFullPath((Join-Path $packageRoot $relativePosix.Replace('/', [IO.Path]::DirectorySeparatorChar)))
        if (-not (Test-IsSameOrDescendant -Candidate $target -Base $packageRoot)) { $failures.Add("Manifest path escapes package: $relativePosix"); continue }
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { $failures.Add("Manifest file missing: $relativePosix"); continue }
        $fileInfo = Get-Item -LiteralPath $target
        if ([int64]$item.bytes -ne [int64]$fileInfo.Length) { $failures.Add("Manifest byte count mismatch: $relativePosix") }
        $manifestByteSum += [int64]$item.bytes
        $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLowerInvariant()
        if ($actual -ne ([string]$item.sha256).ToLowerInvariant()) { $failures.Add("Manifest hash mismatch: $relativePosix") }
    }
    if ([int64]$manifest.file_count_excluding_manifest_and_hash_list -ne [int64]$manifestSet.Count -or [int64]$manifest.payload_bytes_excluding_manifest_and_hash_list -ne $manifestByteSum) { $failures.Add('Manifest aggregate counts changed') }
    [void]$manifestSet.Add('MANIFEST.json')
    foreach ($item in $manifestSet) { if (-not $listed.Contains($item)) { $failures.Add("Manifest entry lacks checksum: $item") } }
    foreach ($item in $listed) { if (-not $manifestSet.Contains($item)) { $failures.Add("Checksum entry lacks manifest declaration: $item") } }
}

$actualSet = [System.Collections.Generic.HashSet[string]]::new([StringComparer]::OrdinalIgnoreCase)
$rootPrefix = $packageRoot + [IO.Path]::DirectorySeparatorChar
foreach ($file in Get-ChildItem -LiteralPath $packageRoot -Recurse -File -Force) {
    $relativePosix = $file.FullName.Substring($rootPrefix.Length).Replace('\', '/')
    if ($relativePosix -eq 'HASHES.sha256') { continue }
    if (-not $actualSet.Add($relativePosix)) { $failures.Add("Case-colliding package path: $relativePosix") }
}
foreach ($item in $actualSet) { if (-not $listed.Contains($item)) { $failures.Add("Unlisted package file: $item") } }
foreach ($item in $listed) { if (-not $actualSet.Contains($item)) { $failures.Add("Checksum path absent from package scan: $item") } }

$expectedIdentity = @{
    'INPUTS\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl' = '69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939'
    'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\__init__.py' = '7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4'
    'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_constants_v27.py' = '339ebcd5602a09a0b1b4bcdc848b3f357237ee5b07778d05e915312c8faa6241'
    'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_universe_v27.py' = 'd777704de34f2df70b259d4f36a12d6a4b7355620517ad1d9537c53c4a5b8454'
    'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_kernel_v27.cp313-win_amd64.pyd' = '0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff'
    'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_kernel_v27.cpp' = '44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab'
    'ROSETTA_FROZEN_CONTRACT.json' = 'd942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157'
    'HOLDOUTS\POST_T10_REPAIR_CONTRACT.json' = 'b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f'
    'HOLDOUTS\PREREGISTER_T10_ROSETTA_CORE.md' = '2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f'
    'HOLDOUTS\PREREGISTER_T11_INVERSE_MAJORITY.md' = '7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888'
    'HOLDOUTS\PREREGISTER_T12_STATE_EVENT_REPAIR.md' = 'ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f'
    'RUNNERS_NEW\run_t10_rosetta_core_holdout.py' = '24733db55c64c16dcbe6897f030c2b94f572f1c8fb605237b8bfa0ef4c4ed49c'
    'RUNNERS_NEW\run_t11_inverse_majority.py' = 'dce34cbd699390b98f3e95775e3a50e4ff133bd414d45de7a254678c5a630f18'
    'RUNNERS_NEW\run_t12_state_event_repair.py' = '5ed7fb7de8660cee9dac79cfd12b9c8ae2b56c8b63c76616b4d9075fe8a44922'
    'RESULTS\t10_rosetta_core\t10_result.json' = 'a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872'
    'RESULTS\t11_inverse_majority\t11_result.json' = '207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0'
    'RESULTS\t12_state_event_repair\t12_result.json' = '8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b'
    'RESULTS\external\e3_e5_results.json' = '46679f082d5444c8744e0f2604a193ef06727db4653cfedc6dde019ff004f691'
    'RESULTS\external\e3_adjudication_audit.json' = '04b3dbab52da68e5b19b066e49521275cdfb3714e64f1836dc17a4de856d5c8a'
}
foreach ($relative in $expectedIdentity.Keys) {
    $target = Join-Path $packageRoot $relative
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { $failures.Add("Missing identity input: $relative"); continue }
    $actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $target).Hash.ToLowerInvariant()
    if ($actual -ne $expectedIdentity[$relative]) { $failures.Add("Identity mismatch: $relative") }
}
if ($null -ne $manifest) {
    if ($manifest.kernel_identity.wheel_sha256 -ne $expectedIdentity['INPUTS\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl'] -or $manifest.kernel_identity.package_init_sha256 -ne $expectedIdentity['ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\__init__.py'] -or $manifest.kernel_identity.constants_wrapper_sha256 -ne $expectedIdentity['ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_constants_v27.py'] -or $manifest.kernel_identity.api_wrapper_sha256 -ne $expectedIdentity['ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_universe_v27.py'] -or $manifest.kernel_identity.kernel_pyd_sha256 -ne $expectedIdentity['ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_kernel_v27.cp313-win_amd64.pyd'] -or $manifest.kernel_identity.kernel_cpp_sha256 -ne $expectedIdentity['ANALYSIS\binary_api\wheel_extracted\dee_universe_v27\dee_kernel_v27.cpp'] -or -not $manifest.kernel_identity.all_five_importable_wheel_payloads_byte_identical) { $failures.Add('Manifest kernel identity declaration changed') }
    if ($manifest.freeze.contract_sha256 -ne $expectedIdentity['ROSETTA_FROZEN_CONTRACT.json']) { $failures.Add('Manifest contract identity declaration changed') }
}

try {
    $t10 = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\t10_rosetta_core\t10_result.json') | ConvertFrom-Json
    if ($t10.verdict -ne 'FAIL' -or $t10.observed.domain_failures -ne 0 -or $t10.observed.mismatches -ne 192) { $failures.Add('T10 adjudication/counts changed') }
    $t11 = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\t11_inverse_majority\t11_result.json') | ConvertFrom-Json
    if ($t11.verdict -ne 'PASS' -or $t11.mismatch_count -ne 0 -or $t11.counts.primary_trajectories -ne 448 -or $t11.counts.primary_scored_ticks -ne 896) { $failures.Add('T11 adjudication/counts changed') }
    $t12 = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\t12_state_event_repair\t12_result.json') | ConvertFrom-Json
    if ($t12.verdict -ne 'PASS' -or $t12.observed.mismatches -ne 0 -or $t12.observed.domain_failures -ne 0 -or $t12.observed.primary_trajectories -ne 748 -or $t12.observed.primary_ticks -ne 1496) { $failures.Add('T12 adjudication/counts changed') }
    $external12 = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\external\e1_e2_results.json') | ConvertFrom-Json
    if ($external12.summary.E1_LABEL_NONDISPERSION -ne 'COMPATIBLE_NOT_VALIDATING' -or $external12.summary.E2_COMMON_SIGNAL_SPEED -ne 'COMPATIBLE_NOT_VALIDATING') { $failures.Add('E1/E2 adjudication changed') }
    $external35 = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\external\e3_e5_results.json') | ConvertFrom-Json
    $states = @{}; foreach ($item in $external35.results) { $states[[string]$item.id] = [string]$item.status }
    if ($states['E3_DIRECT_LINEAR_EUCLIDEAN_GEOMETRY'] -ne 'FAIL_BRIDGE' -or $states['E4_OBSERVER_OCCLUSION_PHASE_ANALOGUE'] -ne 'NOT_IDENTIFIABLE' -or $states['E5_FIVE_SOURCE_MAJORITY_ANALOGUE'] -ne 'NOT_IDENTIFIABLE') { $failures.Add('Preserved original E3-E5 result changed') }
    $external3Audit = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'RESULTS\external\e3_adjudication_audit.json') | ConvertFrom-Json
    if ($external3Audit.original_result.recorded_status -ne 'FAIL_BRIDGE' -or -not $external3Audit.original_result.preserved_unchanged -or $external3Audit.original_result.sha256 -ne '46679f082d5444c8744e0f2604a193ef06727db4653cfedc6dde019ff004f691') { $failures.Add('E3 audit no longer preserves the original result') }
    if ($external3Audit.corrected_adjudication.E3_EXTERNAL -ne 'INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN' -or $external3Audit.corrected_adjudication.E3_INTERNAL_EQUAL_SPEED_LINEAR_MAP -ne 'REFUTED_BY_EXACT_SQRT3_OBSTRUCTION' -or -not $external3Audit.integrity.no_parameter_refit -or -not $external3Audit.integrity.no_alternative_bridge_selected) { $failures.Add('Corrected E3 adjudication changed') }
} catch { $failures.Add("Result JSON validation failed: $($_.Exception.Message)") }

$ledgerCsv = Import-Csv -LiteralPath (Join-Path $packageRoot 'ROSETTA_CLAIM_LEDGER.csv')
$ledgerJson = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'ROSETTA_CLAIM_LEDGER.json') | ConvertFrom-Json
if ($ledgerCsv.Count -ne 45 -or $ledgerJson.claims.Count -ne 45) { $failures.Add('Claim ledger count changed') }
$claimFields = @('claim_id','claim','epistemic_class','status','scope','phase','preregistered','method','evidence_path','evidence_sha256','assumptions_limits','external_status')
if ((@($ledgerCsv[0].PSObject.Properties.Name) -join '|') -ne ($claimFields -join '|')) { $failures.Add('Claim CSV schema changed') }
for ($rowIndex = 0; $rowIndex -lt [Math]::Min($ledgerCsv.Count, $ledgerJson.claims.Count); $rowIndex++) {
    $jsonFields = @($ledgerJson.claims[$rowIndex].PSObject.Properties.Name)
    if (($jsonFields -join '|') -ne ($claimFields -join '|')) { $failures.Add("Claim JSON schema changed at row $rowIndex"); continue }
    foreach ($field in $claimFields) {
        if ([string]$ledgerCsv[$rowIndex].$field -cne [string]$ledgerJson.claims[$rowIndex].$field) { $failures.Add("Claim CSV/JSON mismatch at row $rowIndex field $field") }
    }
}
$ledgerCsvHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $packageRoot 'ROSETTA_CLAIM_LEDGER.csv')).Hash
$ledgerAliasCsvHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $packageRoot 'CLAIM_LEDGER.csv')).Hash
$ledgerJsonHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $packageRoot 'ROSETTA_CLAIM_LEDGER.json')).Hash
$ledgerAliasJsonHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $packageRoot 'CLAIM_LEDGER.json')).Hash
if ($ledgerCsvHash -ne $ledgerAliasCsvHash -or $ledgerJsonHash -ne $ledgerAliasJsonHash) { $failures.Add('Claim-ledger aliases are not byte-identical') }
foreach ($claim in $ledgerCsv) {
    $evidence = [IO.Path]::GetFullPath((Join-Path $packageRoot ([string]$claim.evidence_path).Replace('/', [IO.Path]::DirectorySeparatorChar)))
    if (-not (Test-IsSameOrDescendant -Candidate $evidence -Base $packageRoot)) { $failures.Add("Claim evidence escapes package: $($claim.claim_id)"); continue }
    if (-not (Test-Path -LiteralPath $evidence -PathType Leaf)) { $failures.Add("Missing claim evidence: $($claim.claim_id) $($claim.evidence_path)"); continue }
    $actualEvidenceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $evidence).Hash.ToLowerInvariant()
    if ($actualEvidenceHash -ne ([string]$claim.evidence_sha256).ToLowerInvariant()) { $failures.Add("Claim evidence hash mismatch: $($claim.claim_id)") }
}
$experiments = Import-Csv -LiteralPath (Join-Path $packageRoot 'EXPERIMENT_INDEX.csv')
$experimentsJson = Get-Content -Raw -LiteralPath (Join-Path $packageRoot 'EXPERIMENT_INDEX.json') | ConvertFrom-Json
if ($experiments.Count -ne 13 -or $experimentsJson.experiments.Count -ne 13) { $failures.Add('Experiment index count changed') }
$experimentFields = @('experiment_id','phase','question','status','sample','mismatches','preregistered','evidence_path','evidence_sha256','notes')
if ((@($experiments[0].PSObject.Properties.Name) -join '|') -ne ($experimentFields -join '|')) { $failures.Add('Experiment CSV schema changed') }
for ($rowIndex = 0; $rowIndex -lt [Math]::Min($experiments.Count, $experimentsJson.experiments.Count); $rowIndex++) {
    $jsonFields = @($experimentsJson.experiments[$rowIndex].PSObject.Properties.Name)
    if (($jsonFields -join '|') -ne ($experimentFields -join '|')) { $failures.Add("Experiment JSON schema changed at row $rowIndex"); continue }
    foreach ($field in $experimentFields) {
        if ([string]$experiments[$rowIndex].$field -cne [string]$experimentsJson.experiments[$rowIndex].$field) { $failures.Add("Experiment CSV/JSON mismatch at row $rowIndex field $field") }
    }
}
foreach ($experiment in $experiments) {
    $evidence = [IO.Path]::GetFullPath((Join-Path $packageRoot ([string]$experiment.evidence_path).Replace('/', [IO.Path]::DirectorySeparatorChar)))
    if (-not (Test-IsSameOrDescendant -Candidate $evidence -Base $packageRoot)) { $failures.Add("Experiment evidence escapes package: $($experiment.experiment_id)"); continue }
    if (-not (Test-Path -LiteralPath $evidence -PathType Leaf)) { $failures.Add("Missing experiment evidence: $($experiment.experiment_id) $($experiment.evidence_path)"); continue }
    $actualEvidenceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $evidence).Hash.ToLowerInvariant()
    if ($actualEvidenceHash -ne ([string]$experiment.evidence_sha256).ToLowerInvariant()) { $failures.Add("Experiment evidence hash mismatch: $($experiment.experiment_id)") }
}

if ($failures.Count -gt 0) { throw ("Verification failed:`n" + ($failures -join "`n")) }
Write-Host 'Integrity, identity, ledgers and adjudications: PASS'

if (-not $RunHoldouts) {
    Write-Host 'Verification-only reproduction complete. Add -RunHoldouts for fresh T10/T11/T12 executions in a separate scratch tree.'
    return
}

if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) { throw "CPython path not found: $PythonPath" }
$runtimeJson = & $PythonPath -I -B -c "import json,platform,struct,sys,numpy; ok=(platform.python_implementation()=='CPython' and sys.version_info[:2]==(3,13) and struct.calcsize('P')*8==64); print(json.dumps({'implementation':platform.python_implementation(),'version':'.'.join(map(str,sys.version_info[:3])),'bits':struct.calcsize('P')*8,'numpy':numpy.__version__})); raise SystemExit(0 if ok else 2)"
if ($LASTEXITCODE -ne 0) { throw "Holdouts require CPython 3.13 x64 plus NumPy: $runtimeJson" }
Write-Host "Runtime: $runtimeJson"

$wheelAuditJson = & $PythonPath -I -B (Join-Path $packageRoot 'RUNNERS_NEW\verify_wheel_extraction.py') --wheel (Join-Path $packageRoot 'INPUTS\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl') --extracted (Join-Path $packageRoot 'ANALYSIS\binary_api\wheel_extracted\dee_universe_v27')
if ($LASTEXITCODE -ne 0) { throw "Wheel extraction parity failed: $wheelAuditJson" }
Write-Host "Wheel extraction parity: $wheelAuditJson"

if ([string]::IsNullOrWhiteSpace($ScratchPath)) {
    $ScratchPath = Join-Path ([IO.Path]::GetTempPath()) ("DEE_ROSETTA_REPRO_" + (Get-Date -Format 'yyyyMMdd_HHmmss'))
}
$scratch = [IO.Path]::GetFullPath($ScratchPath)
if ((Test-IsSameOrDescendant -Candidate $scratch -Base $packageRoot) -or (Test-IsSameOrDescendant -Candidate $packageRoot -Base $scratch)) { throw 'ScratchPath must be separate from the package.' }
if (Test-Path -LiteralPath $scratch) { throw "ScratchPath already exists: $scratch" }

$testsStage = Join-Path $scratch 'tests'
$v1Stage = Join-Path $testsStage 'DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK'
$rosettaStage = Join-Path $v1Stage 'ROSETTA_CLOSURE'
$reproduced = Join-Path $scratch 'REPRODUCED_RESULTS'
New-Item -ItemType Directory -Path $rosettaStage,$reproduced -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $packageRoot 'RUNNERS_NEW') -Destination $rosettaStage -Recurse
Copy-Item -LiteralPath (Join-Path $packageRoot 'HOLDOUTS') -Destination $rosettaStage -Recurse
New-Item -ItemType Directory -Path (Join-Path $v1Stage 'ANALYSIS\binary_api'),(Join-Path $v1Stage 'ANALYSIS\native_theory'),(Join-Path $v1Stage 'RESULTS\native_ballistic'),(Join-Path $v1Stage 'RESULTS\observer_pump'),(Join-Path $rosettaStage 'RESULTS') -Force | Out-Null
Copy-Item -LiteralPath (Join-Path $packageRoot 'ANALYSIS\binary_api\wheel_extracted') -Destination (Join-Path $v1Stage 'ANALYSIS\binary_api') -Recurse
Copy-Item -LiteralPath (Join-Path $packageRoot 'PARENT_V1_INPUTS\ANALYSIS\native_theory\EXACT_PROOFS.md') -Destination (Join-Path $v1Stage 'ANALYSIS\native_theory\EXACT_PROOFS.md')
Copy-Item -LiteralPath (Join-Path $packageRoot 'PARENT_V1_INPUTS\RESULTS\native_ballistic\t8_result.json') -Destination (Join-Path $v1Stage 'RESULTS\native_ballistic\t8_result.json')
Copy-Item -LiteralPath (Join-Path $packageRoot 'PARENT_V1_INPUTS\RESULTS\observer_pump\t9_result.json') -Destination (Join-Path $v1Stage 'RESULTS\observer_pump\t9_result.json')
Copy-Item -LiteralPath (Join-Path $packageRoot 'INPUTS\dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl') -Destination (Join-Path $testsStage 'dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl')
Copy-Item -LiteralPath (Join-Path $packageRoot 'RESULTS\t10_rosetta_core') -Destination (Join-Path $rosettaStage 'RESULTS') -Recurse

# T12 needs the immutable original T10 JSON as a bound input, so it runs first.
& $PythonPath -I -B (Join-Path $rosettaStage 'RUNNERS_NEW\run_t12_state_event_repair.py')
if ($LASTEXITCODE -ne 0) { throw "T12 reproduction failed with exit $LASTEXITCODE" }
$freshT12 = Get-Content -Raw -LiteralPath (Join-Path $rosettaStage 'RESULTS\t12_state_event_repair\t12_result.json') | ConvertFrom-Json
if ($freshT12.verdict -ne 'PASS' -or $freshT12.observed.mismatches -ne 0) { throw 'Fresh T12 did not reproduce PASS.' }
Copy-Item -LiteralPath (Join-Path $rosettaStage 'RESULTS\t12_state_event_repair') -Destination $reproduced -Recurse

# T10 is expected to return exit 2 because the frozen scientific verdict is FAIL.
& $PythonPath -I -B (Join-Path $rosettaStage 'RUNNERS_NEW\run_t10_rosetta_core_holdout.py')
$t10Exit = $LASTEXITCODE
if ($t10Exit -ne 2) { throw "T10 reproduction returned unexpected exit $t10Exit (expected 2 for frozen FAIL)" }
$freshT10 = Get-Content -Raw -LiteralPath (Join-Path $rosettaStage 'RESULTS\t10_rosetta_core\t10_result.json') | ConvertFrom-Json
if ($freshT10.verdict -ne 'FAIL' -or $freshT10.observed.domain_failures -ne 0 -or $freshT10.observed.mismatches -ne 192) { throw 'Fresh T10 did not reproduce the frozen scoped FAIL.' }
Copy-Item -LiteralPath (Join-Path $rosettaStage 'RESULTS\t10_rosetta_core') -Destination $reproduced -Recurse

if ([string]::IsNullOrWhiteSpace($ParentV1Zip)) {
    Write-Warning 'T11 fresh execution skipped: pass -ParentV1Zip pointing to the original V1 results ZIP (required hash 06c9721e...de1e4). Its 2.2 MB payload is intentionally not nested in this package.'
} else {
    $parentZipFull = [IO.Path]::GetFullPath($ParentV1Zip)
    if (-not (Test-Path -LiteralPath $parentZipFull -PathType Leaf)) { throw "Parent V1 ZIP not found: $parentZipFull" }
    $parentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $parentZipFull).Hash.ToLowerInvariant()
    if ($parentHash -ne '06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4') { throw "Parent V1 ZIP hash mismatch: $parentHash" }
    Copy-Item -LiteralPath $parentZipFull -Destination (Join-Path $v1Stage 'DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip')
    & $PythonPath -I -B (Join-Path $rosettaStage 'RUNNERS_NEW\run_t11_inverse_majority.py') --output-dir (Join-Path $reproduced 't11_inverse_majority')
    if ($LASTEXITCODE -ne 0) { throw "T11 reproduction failed with exit $LASTEXITCODE" }
    $freshT11 = Get-Content -Raw -LiteralPath (Join-Path $reproduced 't11_inverse_majority\t11_result.json') | ConvertFrom-Json
    if ($freshT11.verdict -ne 'PASS' -or $freshT11.mismatch_count -ne 0) { throw 'Fresh T11 did not reproduce PASS.' }
}

Write-Host "Fresh reproduction outputs: $reproduced"
