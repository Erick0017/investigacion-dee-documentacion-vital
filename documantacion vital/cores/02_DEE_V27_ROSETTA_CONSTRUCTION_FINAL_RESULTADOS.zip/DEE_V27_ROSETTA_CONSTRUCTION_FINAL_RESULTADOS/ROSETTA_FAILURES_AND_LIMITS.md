# Fallos y límites de la Rosetta DEE v27

## Regla de lectura

Un resultado negativo sólo elimina la representación, dominio o transformación que realmente fue contrastada. En particular:

- un fallo de `occupancy` no es un fallo de todo coarse-graining;
- un contraejemplo a `M_*` fuera de `D_*` no invalida su clausura dentro de `D_*`;
- la ausencia de una masa, entropía o gauge operacional no demuestra su imposibilidad emergente;
- un `FAIL_BRIDGE` externo no refuta `F_DEE` salvo que el puente fallido sea una consecuencia necesaria y exhaustiva de la hipótesis;
- `NOT_IDENTIFIABLE` significa que falta un dataset o un mapa operacional, no que el endpoint sea falso.

## Matriz de límites

| Objeto o afirmación | Estado sustentado | Dominio exacto | Lo que no se concluye |
|---|---|---|---|
| `M_*=(q,d,s,a,p)` | estado predictivo sectorial; su canon de `d=0` es incompatible con el `G_*` original | respuesta dispersa en `D_*`, observables y horizontes declarados | cociente mínimo global de todo `F_DEE` |
| `G_*` original | **FAIL T10** por conservar `S` donde `M_*` exige `s=0` | 96 colisiones opuestas, cero fallos de dominio | fallo del kernel raw o de todo coarse-graining |
| `(G_dagger,J_dagger)` | reparación estado–evento, prueba por ramas y **PASS T12** | `D_*`; 748 trayectorias nuevas, 1,496 ticks | reparación retrospectiva de T10 o ley de sectores densos |
| `K_dagger` | cociclo de respuesta dependiente del baseline; propagador lineal sólo por estratos | intervenciones y sectores congelados | convolución lineal o superposición global |
| `occupancy` | causalmente insuficiente por testigos constructivos | predicción de raws direccionales/observer y ramas de clock | que sea inútil como readout contextual |
| materia DEE | linajes de portadores `C`, routers `L` y fuentes/fronteras `O` son objetos internos operacionales | núcleo cinético marcado | partículas, masa o materia de nuestra realidad |
| vuelo libre | permutación, advección y modos Fourier exactos | dirección común, separación y demás guardas del sector | Lorentz, ondas físicas o movilidad de toda morfología |
| colisión | reducer simultáneo capado, conmutativo y many-to-one | blanco abierto, evento simultáneo y sin ramas externas al núcleo | conservación universal de energía o momentum |
| geometría | reachability y first-passage sobre hipergrafo causal de fase | preparación y estado condicionantes | métrica euclídea o lorentziana fundamental |
| E3 | `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`; obstrucción interna `sqrt(3)` probada | comparación óptica sin forward model; teorema sobre `A,tau` comunes | fallo de toda geometría emergente o exclusión experimental |
| E4/E5 | `NOT_IDENTIFIABLE` | búsquedas, criterios y topes congelados | falsedad de oclusión interna, T11 u otros diccionarios |

## FAIL T10 y reparación T12

T10 ejecutó literalmente el contrato original: 1,389 trayectorias, 5,598 ticks primarios, cero fallos de `D_*`, 30,521 assertions y 192 mismatches. Los 96 fallos primarios fueron exactamente los cuatro pares body-diagonal opuestos multiplicados por los perfiles congelados; las otras 96 filas fueron la desalineación iterada consecuente. H10.2 y H10.3 pasaron. Ese resultado continúa `FAIL_NO_REFIT`.

La reparación posterior no cambia el raw: distingue el evento de colisión `J_dagger=(q,u,S)` del estado predictivo canónico. Si `u=0`, el evento conserva `S` pero `G_dagger` entrega `s=0`, porque el blocker no propone y muere en el siguiente tick dentro de `D_*`. Si `u!=0`, estado y evento conservan `S`.

La fórmula y un panel nuevo de aridades 3/4/6 se sellaron antes de T12. T12 pasó 748 trayectorias/1,496 ticks, 514 casos `u=0`, 234 controles no cero, cero fallos de dominio, cero mismatches y 16/16 controles de motor. Es apoyo prospectivo para la hipótesis posterior, no una reclasificación del holdout original ni una demostración global.

## Frontera de `M_*` y `D_*`

El registro congelado retiene posición de laboratorio `q`, dirección Moore `d`, carga transportada `s`, actividad binaria `a=1[state>0]` y persistencia observer `p=1[semantic=4]`. Su minimalidad depende conjuntamente de la familia de readouts seleccionada. Una partición predictiva es siempre relativa a observable y horizonte: packed raw, occupancy, estado completo y un detector local inducen cocientes distintos.

La clausura se licencia sólo cuando cada slice puntuado satisface:

1. `N>=5`;
2. todas las direcciones son cero o Moore no nulas;
3. existen como máximo siete sitios `state>0`;
4. cada positivo no observer tiene a lo sumo tres vecinos Moore positivos.

Estas condiciones excluyen por construcción supervivencia material/tetra, XNOR, overflow y gates dependientes del clock. No se ha demostrado invariancia de `D_*` para preparaciones arbitrarias. Una trayectoria de varios ticks queda cubierta sólo mientras cada pre-slice permanezca en el dominio.

Fuera de esa frontera aparecen separaciones reales entre fibras colapsadas:

- al extender a configuraciones densas que activan XNOR/alive semantics, `semantic=5,state>0` requiere una marca orphan-activa o una exclusión explícita; dentro de `D_*` sparse la etiqueta sí colapsa;
- magnitud positiva de `state` vuelve a importar si se exige reconstruir packed raw de un observer;
- el clock vuelve a importar cuando se alcanzan sus gates;
- direcciones no Moore requieren el predicado modular de propuesta y pueden no emitir;
- supervivencia, tetra, XNOR y overflow introducen especies, guardas o vértices ausentes en `G_dagger`;
- el pump observer usa una edad orbital pre-wrap; esa edad no es el clock y su compresión no se autoriza automáticamente después del cierre toroidal.

El fallback general no es occupancy: para raw local hasta horizonte `H`, la manta suficiente usa raw inicial en `B_{3H}` y clock en `B_{3H-2}`. Es una cota suficiente; no prueba que cada coordenada sea necesaria en cada contexto.

## Límites de la respuesta unificada

`K_dagger^t[Z;I]` es una diferencia finita entre una evolución intervenida y su baseline. Como el cierre de blancos, las colisiones y la saturación dependen del estado, las respuestas delta no se superponen en general. La composición exacta pertenece al par de estados bajo `G_dagger`, no a un kernel lineal aislado. `J_dagger` debe consultarse cuando el readout requiere la carga del evento presente que el estado futuro canoniza.

En vuelo libre sí existe una matriz de permutación y modos Fourier exactos. En el observer aparece un tren alternante pre-wrap y sensibilidad de fase convectiva. En colisiones, la compresión `sign(sum d)` y el cap `19664` destruyen información; comprimir por pares e insertar un tick no es asociativo. Esta pluralidad descarta un único propagador lineal global, pero no la existencia de linealizaciones, modos lentos o cierres estadísticos en otros sectores.

## Obstrucción geométrica interna y contraste E3 inconcluso

El puente congelado intentó `v(d)=||A d||_2/tau` para las 26 direcciones Moore, con un solo `A` lineal invertible y un solo `tau>0`. Para toda elección permitida,

`max_d v(d)/min_d v(d) >= sqrt(3)`.

La dispersión mínima de las 26 velocidades es de orden unidad, lo que descarta su equivelocidad bajo esa clase de mapa. El experimento primario de Nagel et al. reporta `Delta nu/nu=(9.2 +/- 10.7)e-19` al 95 %, pero el contrato no especificó un operador desde D26 a la respuesta de dos resonadores rotantes, incluyendo ida/vuelta, orientación y nuisances del aparato. Por ello `E3_EXTERNAL=INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`.

El cuantificador hace exhaustiva sólo la obstrucción de equivelocidad dentro de la clase lineal directa: cambiar la escala común no la repara. No hace exhaustiva la predicción del resonador. El `FAIL_BRIDGE` original se conserva como auditoría fallida y queda supersedido sin refit. Un mapa no lineal, Finsler, estocástico, renormalizado o coarse-grained permanece abierto, pero debe derivarse y congelarse antes de nuevos holdouts.

## Ausencias de endpoint E4 y E5

E4 exigía una fuente persistente, una oclusión de entrada de una unidad operacional, dos detectores aguas abajo resueltos temporalmente y control sin bloqueo. Ningún candidato de la búsqueda congelada reunió esos cuatro metadatos. Por ello no existe dato con el que contrastar conjuntamente retraso normalizado uno e inversión de paridad: `E4=NOT_IDENTIFIABLE`.

E5 exigía cinco entradas simultáneas controladas, intensidades registradas, salida direccional y resolución temporal. Ningún candidato calificó. No se pudo distinguir mayoría no ponderada de suma ponderada por intensidad: `E5=NOT_IDENTIFIABLE` para el diccionario directo `direction -> dirección` y `s_reg -> intensidad`.

Ninguna ausencia es un resultado negativo sobre la dinámica interna. Tampoco autoriza reducir la aridad, aceptar simulaciones como datos o redefinir `s_reg` después de observar candidatos.

## Masa e inercia

En el núcleo libre, velocidad y trayectoria no dependen de la magnitud positiva de `state` ni de `s_reg`. En el reducer, `s_reg` se suma y satura, pero no pondera la dirección de salida. Esto descarta interpretar directamente esos dos campos como masa inercial o momentum en ese sector.

No existe todavía una intervención tipo fuerza definida independientemente de la respuesta, una aceleración reproducible, ni un parámetro que prediga conjuntamente respuesta, propagación y colisión en varias escalas. Permanece abierta una masa colectiva de otra clase estable o un coeficiente efectivo surgido de coarse-graining; no está demostrada ni refutada por los resultados actuales.

## Termodinámica e hidrodinámica

Existen balances exactos restringidos: en vuelo libre se conservan número de portadores, cargas individuales, direcciones y patrón relativo; en colisión la carga sólo es aditiva antes del cap y aparecen pérdida de número e información direccional. Esto permite formular una cinética discreta con fuentes y sumideros.

No se han identificado energía física, temperatura operacional, ensemble estacionario, equilibrio local, producción entrópica, separación de escalas, stress constitutivo ni cierre de flujo. La entropía de Shannon de occupancy sería un estadístico de una proyección causalmente insuficiente, no entropía termodinámica por definición. Los bancos históricos negativos de cargas no agotan invariantes rango 1–2, relacionales, topológicos o de coarse-graining. El estado correcto es no identificado, no imposible.

## Quantum y Bell

La unitariedad de Koopman y los espectros de ciclos del estrato libre son propiedades genéricas de una permutación finita. No suministran por sí mismos un espacio de estados físico compuesto, observables, amplitudes, regla de Born ni protocolo de preparación/medición.

La cota `CHSH<=2` es sólo condicional: requiere un aparato DEE con fuente, dos estaciones, settings independientes, outcomes binarios, una variable `lambda`, factorización local respecto del cono causal verdadero, ausencia de señalización y muestreo sin postselección. Ese aparato no ha sido instanciado ni auditado. Por tanto no se ha demostrado quantum físico, una violación Bell ni una imposibilidad de ella; el endpoint permanece no identificable.

## Simetría y gauge

Las traslaciones toroidales son simetrías exactas. El grupo cúbico completo `O_h` no es simetría global porque un empate overflow resuelto por orden rompe inversión; puede sobrevivir en sectores que no excitan ese empate. Este testigo no clasifica el grupo global completo ni excluye estabilizadores emergentes de basins.

El desplazamiento de fase del clock preserva ciertos prefijos raw sin wrap, pero cambia el full-state y deja de ser una acción global al cruzar `uint64`. No constituye gauge físico. Faltan variables de enlace o conexión, una transformación local que preserve estados físicos, curvatura/holonomía y una carga acoplada. Que no estén identificadas no prueba que ningún cociente emergente pueda tener redundancia gauge.

## Límite final bajo `H_DEE`

La Rosetta interna describe funciones causales de objetos DEE, pero no decide su identidad física. La pieza que falta no es otro nombre para `state`, `s_reg` o `clock`; es una construcción externa e independiente que incluya simultáneamente:

1. mapa de preparación desde procedimientos de laboratorio a un ensemble de estados DEE;
2. mapa de medición desde historias DEE a resultados y probabilidades observables;
3. coarse-graining derivado que produzca geometría efectiva, escalas, transformaciones entre observadores y un operador forward experimental;
4. calibración dimensional con parámetros fijados una vez en datos separados;
5. predicciones cruzadas preregistradas sobre varias familias externas, con más grados observables que parámetros calibrados.

El kernel solo no puede seleccionar cuál estado representa el vacío físico, qué raws corresponden a fuentes o detectores, qué voxel/tick equivale a metro/segundo, qué distribución de estados realiza la naturaleza, ni qué lectura interna es energía, masa, temperatura o outcome cuántico. Esas son correspondencias entre el modelo y el mundo, no propiedades identificables por iterar `F_DEE` sin información externa.

En consecuencia, el déficit actual es **de identificación física y de un operador geométrico-experimental**; existe además una obstrucción algebraica de equivelocidad lineal directa. Ninguno es un FAIL ontológico global de `H_DEE`.
