#!/usr/bin/env python3
"""Validate the Rosetta deliverables and create MANIFEST.json/HASHES.sha256."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


REQUIRED = (
    "FINAL_REPORT.md",
    "EXECUTIVE_VERDICT.md",
    "DEE_ROSETTA_V27_CONSTRUCTED.md",
    "NATIVE_DEE_THEORY.md",
    "EXACT_THEOREMS.md",
    "ROSETTA_FROZEN_CONTRACT.json",
    "MINIMAL_CAUSAL_OBSERVER.md",
    "PARTITION_REFINEMENT_RESULTS.json",
    "EFFECTIVE_STATE_SPACE.md",
    "UNIFIED_RESPONSE_KERNEL.md",
    "INTERNAL_HOLDOUTS.md",
    "ROSETTA_CALIBRATION.md",
    "ROSETTA_EXTERNAL_HOLDOUTS.md",
    "ROSETTA_FAILURES_AND_LIMITS.md",
    "CONSTANT_GENEALOGY_AUDIT.md",
    "ROSETTA_CLAIM_LEDGER.csv",
    "ROSETTA_CLAIM_LEDGER.json",
    "CLAIM_LEDGER.csv",
    "CLAIM_LEDGER.json",
    "CLAUDE_AUDIT.md",
    "HISTORICAL_CLAIMS_AUDIT.md",
    "NEGATIVE_RESULTS.md",
    "OPEN_EXTERNAL_GAPS.md",
    "EXPERIMENT_INDEX.csv",
    "EXPERIMENT_INDEX.json",
    "REPRODUCE.ps1",
)

REQUIRED_REPRODUCTION = (
    "INPUTS/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl",
    "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/__init__.py",
    "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_constants_v27.py",
    "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_universe_v27.py",
    "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd",
    "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cpp",
    "HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json",
    "HOLDOUTS/ROSETTA_FROZEN_CONTRACT.sha256",
    "HOLDOUTS/POST_T10_REPAIR_CONTRACT.json",
    "HOLDOUTS/POST_T10_REPAIR_CONTRACT.sha256",
    "HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md",
    "HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.md",
    "HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.sha256",
    "HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.md",
    "HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.sha256",
    "RUNNERS_NEW/run_t10_rosetta_core_holdout.py",
    "RUNNERS_NEW/run_t11_inverse_majority.py",
    "RUNNERS_NEW/run_t12_state_event_repair.py",
    "RUNNERS_NEW/verify_wheel_extraction.py",
    "RESULTS/t10_rosetta_core/t10_result.json",
    "RESULTS/t11_inverse_majority/t11_result.json",
    "RESULTS/t12_state_event_repair/t12_result.json",
    "RESULTS/external/e1_e2_results.json",
    "RESULTS/external/e3_e5_results.json",
    "RESULTS/external/e3_adjudication_audit.json",
    "RESULTS/ledger_validation.json",
    "RESULTS/wheel_extraction_audit.json",
    "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md",
    "PARENT_V1_INPUTS/RESULTS/native_ballistic/t8_result.json",
    "PARENT_V1_INPUTS/RESULTS/observer_pump/t9_result.json",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def evidence_path(root: Path, relative: str) -> Path:
    candidate = (root / Path(relative)).resolve()
    if candidate != root and root not in candidate.parents:
        raise SystemExit(f"evidence path escapes package: {relative}")
    if not candidate.is_file():
        raise SystemExit(f"missing evidence: {relative}")
    return candidate


def role(relative: str) -> str:
    if relative in REQUIRED or relative == "README.md":
        return "primary_deliverable"
    for prefix, name in (
        ("INPUTS/", "sealed_input"),
        ("HOLDOUTS/", "frozen_protocol"),
        ("RESULTS/", "result"),
        ("RUNNERS_NEW/", "reproduction_code"),
        ("EXTERNAL_SOURCES/", "external_evidence"),
        ("ANALYSIS/", "supporting_analysis"),
        ("DISCOVERY/", "discovery_evidence"),
        ("PROVENANCE/", "provenance"),
        ("PARENT_V1_SUMMARY/", "parent_audit_summary"),
        ("PARENT_V1_INPUTS/", "parent_compact_evidence"),
    ):
        if relative.startswith(prefix):
            return name
    return "support"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", required=True)
    args = parser.parse_args()
    root = Path(args.package_root).resolve()
    missing = [name for name in REQUIRED + REQUIRED_REPRODUCTION if not (root / name).is_file()]
    if missing:
        raise SystemExit(f"missing required deliverables: {missing}")

    ledger_csv = rows(root / "ROSETTA_CLAIM_LEDGER.csv")
    ledger_json = json.loads((root / "ROSETTA_CLAIM_LEDGER.json").read_text(encoding="utf-8"))
    if ledger_csv != ledger_json["claims"]:
        raise SystemExit("Rosetta ledger CSV/JSON full-row parity failure")
    if len(ledger_csv) != 45:
        raise SystemExit(f"claim ledger count changed: {len(ledger_csv)}")
    if len({row["claim_id"] for row in ledger_csv}) != len(ledger_csv):
        raise SystemExit("duplicate claim_id")
    experiments = rows(root / "EXPERIMENT_INDEX.csv")
    if len({row["experiment_id"] for row in experiments}) != len(experiments):
        raise SystemExit("duplicate experiment_id")
    experiment_json = json.loads((root / "EXPERIMENT_INDEX.json").read_text(encoding="utf-8"))
    if experiments != experiment_json["experiments"]:
        raise SystemExit("experiment CSV/JSON full-row parity failure")
    if len(experiments) != 13:
        raise SystemExit(f"experiment index count changed: {len(experiments)}")
    if (root / "ROSETTA_CLAIM_LEDGER.csv").read_bytes() != (root / "CLAIM_LEDGER.csv").read_bytes():
        raise SystemExit("claim ledger CSV alias differs")
    if (root / "ROSETTA_CLAIM_LEDGER.json").read_bytes() != (root / "CLAIM_LEDGER.json").read_bytes():
        raise SystemExit("claim ledger JSON alias differs")
    for item in ledger_csv:
        actual = sha256(evidence_path(root, item["evidence_path"]))
        if actual != item["evidence_sha256"]:
            raise SystemExit(f"claim evidence hash mismatch: {item['claim_id']}")
    for item in experiments:
        actual = sha256(evidence_path(root, item["evidence_path"]))
        if actual != item["evidence_sha256"]:
            raise SystemExit(f"experiment evidence hash mismatch: {item['experiment_id']}")

    contract_hash = sha256(root / "ROSETTA_FROZEN_CONTRACT.json")
    if contract_hash != "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157":
        raise SystemExit(f"frozen contract changed: {contract_hash}")

    expected_identity = {
        "INPUTS/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
        "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
        "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_constants_v27.py": "339ebcd5602a09a0b1b4bcdc848b3f357237ee5b07778d05e915312c8faa6241",
        "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_universe_v27.py": "d777704de34f2df70b259d4f36a12d6a4b7355620517ad1d9537c53c4a5b8454",
        "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        "ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cpp": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
        "ROSETTA_FROZEN_CONTRACT.json": "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157",
        "HOLDOUTS/POST_T10_REPAIR_CONTRACT.json": "b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f",
        "HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md": "2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f",
        "HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.md": "7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888",
        "HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.md": "ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f",
        "RUNNERS_NEW/run_t10_rosetta_core_holdout.py": "24733db55c64c16dcbe6897f030c2b94f572f1c8fb605237b8bfa0ef4c4ed49c",
        "RUNNERS_NEW/run_t11_inverse_majority.py": "dce34cbd699390b98f3e95775e3a50e4ff133bd414d45de7a254678c5a630f18",
        "RUNNERS_NEW/run_t12_state_event_repair.py": "5ed7fb7de8660cee9dac79cfd12b9c8ae2b56c8b63c76616b4d9075fe8a44922",
        "RESULTS/t10_rosetta_core/t10_result.json": "a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872",
        "RESULTS/t11_inverse_majority/t11_result.json": "207cff5e77eb0818b86a87198f9e2c9da7df9b4ffd23df3890ec654bacbd70e0",
        "RESULTS/t12_state_event_repair/t12_result.json": "8f9fd783307df156d7d7d6bafd1e9f454853a0a068c97dc3046bc62205cbf67b",
        "RESULTS/external/e3_e5_results.json": "46679f082d5444c8744e0f2604a193ef06727db4653cfedc6dde019ff004f691",
        "RESULTS/external/e3_adjudication_audit.json": "04b3dbab52da68e5b19b066e49521275cdfb3714e64f1836dc17a4de856d5c8a",
    }
    for relative, expected in expected_identity.items():
        actual = sha256(root / relative)
        if actual != expected:
            raise SystemExit(f"sealed identity mismatch: {relative}: {actual}")

    e3_audit = json.loads((root / "RESULTS/external/e3_adjudication_audit.json").read_text(encoding="utf-8"))
    if (
        e3_audit["corrected_adjudication"]["E3_EXTERNAL"] != "INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN"
        or e3_audit["corrected_adjudication"]["E3_INTERNAL_EQUAL_SPEED_LINEAR_MAP"] != "REFUTED_BY_EXACT_SQRT3_OBSTRUCTION"
        or not e3_audit["original_result"]["preserved_unchanged"]
    ):
        raise SystemExit("corrected E3 adjudication changed")

    reparse = [str(path.relative_to(root)) for path in root.rglob("*") if path.is_symlink()]
    if reparse:
        raise SystemExit(f"package contains symlink/reparse entries: {reparse}")

    payload = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in {"MANIFEST.json", "HASHES.sha256"}:
            continue
        payload.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256(path), "role": role(relative)})

    manifest = {
        "schema": "dee.v27.rosetta.final_package.v1",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "package": "DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS",
        "status": "COMPLETE",
        "scientific_verdict": "ROSETTA_PARTIAL",
        "kernel_identity": {
            "wheel_sha256": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
            "kernel_pyd_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
            "kernel_cpp_sha256": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
            "package_init_sha256": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
            "constants_wrapper_sha256": "339ebcd5602a09a0b1b4bcdc848b3f357237ee5b07778d05e915312c8faa6241",
            "api_wrapper_sha256": "d777704de34f2df70b259d4f36a12d6a4b7355620517ad1d9537c53c4a5b8454",
            "all_five_importable_wheel_payloads_byte_identical": True,
            "abi": "CPython 3.13 x64 / Windows AMD64",
        },
        "freeze": {
            "contract_sha256": contract_hash,
            "discovery_then_freeze_then_holdout": True,
            "original_t10_contract_unchanged_after_t10": True,
            "post_t10_repair_disclosed": True,
            "t12_repair_frozen_before_t12": True,
            "no_refit_within_each_holdout": True,
        },
        "primary_results": {
            "T10": "FAIL_NO_REFIT: 1389 trajectories, 5598 primary ticks, 96 closure mismatches plus 96 dependent iterated-alignment mismatches; 0 domain failures",
            "T11": "PASS: 448 trajectories, 896 scored ticks, 0 mismatches; 8 inverse fibers x 7 subsets",
            "T12": "PASS_NO_REFIT: 748 trajectories, 1496 primary ticks, 0 mismatches; prospective test of the disclosed post-T10 state-event repair; T10 remains FAIL",
            "E1": "COMPATIBLE_NOT_VALIDATING",
            "E2": "COMPATIBLE_NOT_VALIDATING",
            "E3_INTERNAL": "PROVEN algebraic obstruction: no one A,tau makes D26 equispeed; ratio >= sqrt(3)",
            "E3_EXTERNAL": "INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN; original FAIL_BRIDGE result preserved and superseded by audit",
            "E4": "NOT_IDENTIFIABLE",
            "E5": "NOT_IDENTIFIABLE",
        },
        "tables": {"claim_rows": len(ledger_csv), "experiment_rows": len(experiments), "csv_json_claim_parity": True, "csv_json_experiment_parity": True, "evidence_hashes_verified": True},
        "required_deliverables": list(REQUIRED),
        "required_reproduction_inputs": list(REQUIRED_REPRODUCTION),
        "deliberate_omissions": [
            {
                "artifact": "parent V1 ZIP payload",
                "sha256": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
                "reason": "Not nested: essential parent conclusions and exact input identities are included; the original archive remains adjacent in the workspace.",
            },
            {"artifact": "historical giant ZIP corpus", "reason": "Avoids redundant multi-gigabyte payloads; provenance hashes and compact audits are retained."},
        ],
        "file_count_excluding_manifest_and_hash_list": len(payload),
        "payload_bytes_excluding_manifest_and_hash_list": sum(item["bytes"] for item in payload),
        "files": payload,
    }
    (root / "MANIFEST.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    hash_rows = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative == "HASHES.sha256":
            continue
        hash_rows.append(f"{sha256(path)} *{relative}")
    (root / "HASHES.sha256").write_text("\n".join(hash_rows) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps({"status": "PASS", "files": len(payload), "hash_rows": len(hash_rows), "claims": len(ledger_csv), "experiments": len(experiments)}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
