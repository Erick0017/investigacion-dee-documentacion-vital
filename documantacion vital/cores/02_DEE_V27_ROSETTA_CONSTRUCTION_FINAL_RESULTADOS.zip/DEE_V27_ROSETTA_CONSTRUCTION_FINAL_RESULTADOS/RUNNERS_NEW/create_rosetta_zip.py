#!/usr/bin/env python3
"""Create the one required Rosetta ZIP and verify its CRC/entry set."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


PREFIX = "DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    root, output = Path(args.package_root).resolve(), Path(args.output).resolve()
    if not root.is_dir():
        raise SystemExit(f"package not found: {root}")
    if output.exists():
        raise SystemExit(f"refusing overwrite: {output}")
    if output.parent == root or root in output.parents:
        raise SystemExit("ZIP must be outside package root")
    for name in ("MANIFEST.json", "HASHES.sha256", "FINAL_REPORT.md", "REPRODUCE.ps1"):
        if not (root / name).is_file():
            raise SystemExit(f"missing {name}")
    files = sorted(path for path in root.rglob("*") if path.is_file())
    with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for path in files:
            archive.write(path, (Path(PREFIX) / path.relative_to(root)).as_posix())
    with zipfile.ZipFile(output) as archive:
        bad, names = archive.testzip(), archive.namelist()
    if bad or len(names) != len(files) or len(set(names)) != len(files):
        raise SystemExit(f"ZIP verification failure: bad={bad}, entries={len(names)}, files={len(files)}")
    if not all(name.startswith(PREFIX + "/") for name in names):
        raise SystemExit("ZIP prefix failure")
    print(json.dumps({"status": "PASS", "output": str(output), "bytes": output.stat().st_size, "sha256": sha256(output), "entries": len(names), "crc": "PASS"}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

