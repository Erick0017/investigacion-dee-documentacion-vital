#!/usr/bin/env python3
"""Small discovery probe for state-zero directional raws and predictive equivalence."""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import sys
from pathlib import Path

import numpy as np


WHEEL_SHA = "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939"
KERNEL_SHA = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"
MASK_STATE = (1 << 32) - 1


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def pack(state: int, sreg: int, direction: tuple[int, int, int], semantic: int) -> np.uint64:
    dx, dy, dz = direction
    raw = (
        (state & MASK_STATE)
        | ((sreg & 0xFFFF) << 32)
        | ((dx & 0xF) << 48)
        | ((dy & 0xF) << 52)
        | ((dz & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )
    return np.uint64(raw)


def decode(raw: int) -> dict[str, int | list[int]]:
    def nibble(shift: int) -> int:
        value = (raw >> shift) & 0xF
        return value - 16 if value & 8 else value

    return {
        "state": raw & MASK_STATE,
        "sreg": (raw >> 32) & 0xFFFF,
        "direction": [nibble(48), nibble(52), nibble(56)],
        "semantic": (raw >> 60) & 0xF,
    }


def run_case(kernel, n: int, state: int, sreg: int, semantic: int, clock_mode: str) -> dict:
    q = np.array([n // 2] * 3, dtype=int)
    direction = np.array([1, 0, 0], dtype=int)
    total = n**3
    ga = np.zeros(total, dtype=np.uint64)
    gb = np.zeros_like(ga)
    if clock_mode == "zero":
        ca = np.zeros(total, dtype=np.uint64)
    else:
        ca = (np.arange(total, dtype=np.uint64) % np.uint64(3)) + np.uint64((1 << 64) - 3)
    cb = np.zeros_like(ca)

    def index(pos: np.ndarray) -> int:
        x, y, z = (int(v % n) for v in pos)
        return (x * n + y) * n + z

    ga[index(q)] = pack(state, sreg, tuple(int(v) for v in direction), semantic)
    trace = []
    for tick in range(3):
        nonzero_raw = np.flatnonzero(ga)
        causal = []
        for idx in nonzero_raw:
            x, rem = divmod(int(idx), n * n)
            y, z = divmod(rem, n)
            causal.append({"q": [x, y, z], **decode(int(ga[idx]))})
        trace.append({"tick": tick, "records": causal, "raw_sha256": hashlib.sha256(ga.tobytes()).hexdigest()})
        if tick < 2:
            kernel.tick_universo_lazy(ga, gb, ca, cb, n, 1)
            ga, gb = gb, ga
            ca, cb = cb, ca
            gb.fill(0)
            cb.fill(0)
    return {
        "input": {"state": state, "sreg": sreg, "semantic": semantic, "clock_mode": clock_mode},
        "trace": trace,
    }


def projected(trace: list[dict], omit_observer_state: bool = False) -> list:
    out = []
    for frame in trace:
        records = []
        for record in frame["records"]:
            row = dict(record)
            if omit_observer_state and row["semantic"] == 4:
                row["state"] = int(row["state"] > 0)
            records.append(row)
        out.append(records)
    return out


def emitted_only(trace: list[dict]) -> list:
    return [
        [dict(record) for record in frame["records"] if record["semantic"] != 4]
        for frame in trace
    ]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--v1-root", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    v1 = Path(args.v1_root).resolve()
    extracted = v1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
    wheel = v1.parent / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
    if not wheel.is_file():
        candidates = list(v1.parent.glob("*v27*.whl"))
        if len(candidates) != 1:
            raise RuntimeError("verified wheel not uniquely located")
        wheel = candidates[0]
    kernel_file = extracted / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
    if sha256(wheel) != WHEEL_SHA or sha256(kernel_file) != KERNEL_SHA:
        raise RuntimeError("identity mismatch")
    sys.path.insert(0, str(extracted))
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(kernel.__file__).resolve() != kernel_file.resolve():
        raise RuntimeError("isolated import mismatch")

    cases = [
        run_case(kernel, 11, state, sreg, semantic, clock_mode)
        for semantic in (1, 4)
        for state in (0, 1, 2, MASK_STATE)
        for sreg in (0, 7, 65535)
        for clock_mode in ("zero", "near_wrap")
    ]
    normal_groups: dict[str, list[int]] = {}
    observer_emission_groups: dict[str, list[int]] = {}
    observer_positive_groups: dict[str, list[int]] = {}
    for case in cases:
        signature = json.dumps(projected(case["trace"])[1:], sort_keys=True)
        target = normal_groups if case["input"]["semantic"] == 1 else observer_emission_groups
        key = f"sreg={case['input']['sreg']};clock={case['input']['clock_mode']}"
        if case["input"]["semantic"] == 1:
            target.setdefault(key, []).append(hash(signature))
        else:
            emission_signature = json.dumps(emitted_only(case["trace"])[1:], sort_keys=True)
            target.setdefault(key, []).append(hash(emission_signature))
            if case["input"]["state"] > 0:
                alive_signature = json.dumps(projected(case["trace"], omit_observer_state=True)[1:], sort_keys=True)
                observer_positive_groups.setdefault(key, []).append(hash(alive_signature))

    checks = {
        "normal_positive_and_zero_state_same_future_by_sreg_clock": all(len(set(values)) == 1 for values in normal_groups.values()),
        "observer_all_states_same_emitted_future_by_sreg_clock": all(len(set(values)) == 1 for values in observer_emission_groups.values()),
        "observer_positive_state_magnitudes_same_alive_bit_quotient": all(len(set(values)) == 1 for values in observer_positive_groups.values()),
    }
    for semantic in (1, 4):
        for state in (0, 1, 2, MASK_STATE):
            for sreg in (0, 7, 65535):
                z = next(c for c in cases if c["input"] == {"state": state, "sreg": sreg, "semantic": semantic, "clock_mode": "zero"})
                w = next(c for c in cases if c["input"] == {"state": state, "sreg": sreg, "semantic": semantic, "clock_mode": "near_wrap"})
                if projected(z["trace"]) != projected(w["trace"]):
                    checks["raw_clock_invariance"] = False
                    break
            else:
                continue
            break
        else:
            continue
        break
    else:
        checks["raw_clock_invariance"] = True

    result = {
        "experiment": "DISCOVERY_GHOST_SOURCES",
        "status": "PASS" if all(checks.values()) else "DISCOVERY_MISMATCH",
        "identity": {"wheel_sha256": sha256(wheel), "kernel_sha256": sha256(kernel_file), "kernel_version": str(kernel.VERSION)},
        "cases": len(cases),
        "ticks": len(cases) * 2,
        "checks": checks,
        "cases_detail": cases,
        "interpretation": "Directional state-zero raws are causal proposal sources. In the isolated apparatus, numeric normal state and clock collapse from the t>=1 predictive quotient. Observer state is preserved in self-readout, but all states induce the same emitted trace; observer persistence remains distinguishable.",
    }
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"status": result["status"], "cases": len(cases), "ticks": len(cases) * 2, "checks": checks, "output": str(output)}))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
