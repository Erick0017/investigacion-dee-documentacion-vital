#!/usr/bin/env python3
"""Generate the Rosetta claim ledger and experiment index with hash locators."""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parent.parent
V1 = ROOT.parent
PACKAGE = ROOT / "FINAL_PACKAGE"
T12 = ROOT / "RESULTS" / "t12_state_event_repair" / "t12_result.json"

FIELDS = (
    "claim_id", "claim", "epistemic_class", "status", "scope", "phase",
    "preregistered", "method", "evidence_path", "evidence_sha256",
    "assumptions_limits", "external_status",
)

ALLOWED_CLASSES = {
    "TEOREMA_EXACTO_F_DEE",
    "HECHO_COMPUTACIONAL",
    "LEY_NATIVA_EMPIRICA",
    "RESULTADO_NEGATIVO",
    "PROPIEDAD_GENERICA_SISTEMAS_DINAMICOS",
    "ESTRUCTURA_ESPECIFICA_DEE",
    "HIPOTESIS_EMERGENCIA",
    "PUENTE_CONDICIONAL",
    "CORRESPONDENCIA_EXTERNA",
    "NO_IDENTIFICABLE",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def evidence_source(relative: str) -> Path:
    if relative.startswith("PARENT_V1_SUMMARY/"):
        return V1 / "FINAL_PACKAGE" / relative.removeprefix("PARENT_V1_SUMMARY/")
    if relative == "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md":
        return V1 / "ANALYSIS" / "native_theory" / "EXACT_PROOFS.md"
    if relative == "PARENT_V1_INPUTS/RESULTS/native_ballistic/t8_result.json":
        return V1 / "RESULTS" / "native_ballistic" / "t8_result.json"
    if relative == "PARENT_V1_INPUTS/RESULTS/observer_pump/t9_result.json":
        return V1 / "RESULTS" / "observer_pump" / "t9_result.json"
    candidate = ROOT / relative
    if candidate.is_file():
        return candidate
    candidate = PACKAGE / relative
    if candidate.is_file():
        return candidate
    raise FileNotFoundError(f"evidence not found: {relative}")


def row(
    claim_id: str,
    claim: str,
    epistemic_class: str,
    status: str,
    scope: str,
    phase: str,
    preregistered: str,
    method: str,
    evidence_path: str,
    assumptions_limits: str,
    external_status: str = "NOT_APPLICABLE",
) -> dict[str, str]:
    if epistemic_class not in ALLOWED_CLASSES:
        raise ValueError(epistemic_class)
    source = evidence_source(evidence_path)
    return {
        "claim_id": claim_id,
        "claim": claim,
        "epistemic_class": epistemic_class,
        "status": status,
        "scope": scope,
        "phase": phase,
        "preregistered": preregistered,
        "method": method,
        "evidence_path": evidence_path,
        "evidence_sha256": sha256(source),
        "assumptions_limits": assumptions_limits,
        "external_status": external_status,
    }


def main() -> int:
    t12 = json.loads(T12.read_text(encoding="utf-8"))
    t12_verdict = str(t12["verdict"])
    t12_counts = t12["observed"]
    t12_status = (
        f"{t12_verdict}: {t12_counts['primary_trajectories']} trayectorias; "
        f"{t12_counts['primary_ticks']} ticks; {t12_counts['mismatches']} mismatches"
    )

    claims = [
        row("R001", "Para N>=3, el estado completo X=(raw,clock) define un mapa determinista sincrono, many-to-one y traslacionalmente equivariante sobre el toro.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "ABI valida v27; N>=3 para no-inyectividad", "IMPORTED_V1", "V1_CLOSED", "Prueba estatica y testigos binarios", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "No implica reversibilidad ni fisica externa."),
        row("R002", "Para O,H fijados, X/ker(W_H^+) es el cociente predictivo exacto mas grueso.", "PROPIEDAD_GENERICA_SISTEMAS_DINAMICOS", "PROVEN", "Sistema determinista y dominio de H iteraciones", "ROSETTA_THEORY", "NOT_APPLICABLE", "Demostracion por factorizacion de palabras futuras", "EXACT_THEOREMS.md", "No existe un minimo independiente de observable, horizonte y dominio."),
        row("R003", "M_*=(q,d,s,a,p) es un cociente causal sectorial suficiente para propuestas, exclusion, colision y fuentes en D_* salvo la clausula conflictiva congelada de salida d=0.", "ESTRUCTURA_ESPECIFICA_DEE", "PARTIAL_T10", "D_* sparse", "DISCOVERY_AND_HOLDOUT", "T10_YES", "Refinamiento simbolico, auditoria adversarial y T10", "RESULTS/t10_rosetta_core/t10_result.json", "No es lumpable global; T10 refuto el G_* original en d_out=0."),
        row("R004", "El cociente de cinco campos no es global: semantic=5 activo separa fibras con igual (q,d,s,a,p) cuando se activa la rama XNOR densa.", "RESULTADO_NEGATIVO", "PROVEN_BY_COUNTEREXAMPLE", "Ocho positivos alrededor de un centro; fuera de D_* por densidad", "DISCOVERY", "NO_DISCOVERY", "Contraejemplo binario normal/orphan", "ANALYSIS/response/MSTAR_CLOSURE_ADVERSARIAL.md", "D_* admite orphan activo sparse; para la extension densa se requiere marca orphan-activa o semantic completo."),
        row("R005", "Una propuesta existe exactamente por la congruencia modular fuente+d=target; en D_* equivale a d Moore no nula.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Scan DEMUX y N>=5 para la simplificacion", "DISCOVERY", "NO_DISCOVERY", "Lectura de fuente sellada mas probes", "EXACT_THEOREMS.md", "No dice que el target alcance la rama de routing."),
        row("R006", "Un raw normal state=0 con direccion Moore no nula es una fuente causal efimera.", "HECHO_COMPUTACIONAL", "PASS", "Singleton aislado N>=5", "DISCOVERY", "NO_DISCOVERY", "48 casos y 96 ticks del pyd", "DISCOVERY/ghost_sources_result.json", "No es occupancy viva ni fuente persistente."),
        row("R007", "Occupancy no es estado causal suficiente: vacio, router latente y observer state-zero pueden compartir occupancy cero y divergir.", "RESULTADO_NEGATIVO", "PROVEN_BY_WITNESSES", "Familia dirigida aislada", "DISCOVERY", "NO_DISCOVERY", "Testigos full-raw pareados", "ANALYSIS/response/RESPONSE_DISCOVERY_REPORT.md", "Descarta occupancy, no toda representacion coarse-grained."),
        row("R008", "Un singleton normal se traslada q(t)=q0+t d, conserva d,s y tiene periodo raw N.", "TEOREMA_EXACTO_F_DEE", "PROVEN_AND_T8_PASS", "N>=5, singleton no interactuante, d en D26", "IMPORTED_V1", "T8_YES", "Prueba por ramas y holdout T8", "PARENT_V1_INPUTS/RESULTS/native_ballistic/t8_result.json", "Clock completo no tiene periodo N; no identifica particula fisica."),
        row("R009", "K_free es una permutacion, compone como semigrupo y posee modos Fourier de adveccion por capa d.", "PROPIEDAD_GENERICA_SISTEMAS_DINAMICOS", "PROVEN_AND_CHECKED", "Sector libre no interactuante", "DISCOVERY_AND_T10", "T10_YES", "Algebra y 1872 checks de composicion", "RESULTS/t10_rosetta_core/t10_result.json", "Modo colectivo sectorial, no onda fisica universal."),
        row("R010", "Semantic observer fija su raw y con d no nula actua como fuente persistente de un tren alternante pre-wrap.", "TEOREMA_EXACTO_F_DEE", "PROVEN_AND_T9_PASS", "Observer aislado; formula pre-wrap", "IMPORTED_V1", "T9_YES", "Prueba por induccion y T9", "PARENT_V1_INPUTS/RESULTS/observer_pump/t9_result.json", "Observer es frontera/fuente, no aparato de medicion."),
        row("R011", "Una oclusion inicial de la boca del observer causa retraso unitario coherente, paridad opuesta y crecimiento Hamming lineal.", "LEY_NATIVA_EMPIRICA", "DISCOVERY_PASS", "Aparato aislado pre-wrap", "DISCOVERY", "NO_DISCOVERY", "Intervencion pareada en tres clases direccionales", "ANALYSIS/response/RESPONSE_DISCOVERY_REPORT.md", "Prediccion inversa condicional a la clase de historias probada."),
        row("R012", "El reducer simultaneo usa u=sign(sum d_j), S=min(sum s_j,19664); es conmutativo, no lineal y many-to-one.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Target abierto, rama multi-source sin overflow posterior", "IMPORTED_V1", "V1_CLOSED", "Prueba de fuente sellada y colisiones", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "s no pondera direccion; no es momentum fisico."),
        row("R013", "La composicion binaria de direcciones ya comprimidas por sign no es asociativa.", "ESTRUCTURA_ESPECIFICA_DEE", "PASS_WITNESS", "Eventos escalonados frente a simultaneos", "DISCOVERY", "NO_DISCOVERY", "Triple discriminante ejecutado", "ANALYSIS/response/RESPONSE_DISCOVERY_REPORT.md", "F completo si compone; falla el monoide atemporal reducido."),
        row("R014", "En colision binaria, cada salida no nula tiene 12 pares-preimagen y la salida cero 13.", "TEOREMA_EXACTO_F_DEE", "PROVEN_AND_CHECKED", "325 pares no ordenados de D26", "DISCOVERY", "NO_DISCOVERY", "Enumeracion exhaustiva y 27 testigos binarios", "ANALYSIS/partition/PARTITION_DISCOVERY_REPORT.md", "Inversion correcta es conjuntista."),
        row("R015", "T10 refuto el cierre universal del par congelado M_*,G_*.", "RESULTADO_NEGATIVO", "FAIL_NO_REFIT", "Panel T10 completo en D_*", "FROZEN_HOLDOUT", "YES", "1389 trayectorias, 5598 ticks, cero fallos de dominio", "RESULTS/t10_rosetta_core/t10_result.json", "96 fallos primarios y 96 desalineaciones derivadas; no refuta F_DEE."),
        row("R016", "La clase fallida T10 se agota en cuatro pares body-diagonal opuestos y el conflicto carga S versus canon s=0.", "HECHO_COMPUTACIONAL", "EXHAUSTIVELY_CHARACTERIZED_IN_PANEL", "Panel B T10", "FROZEN_HOLDOUT", "YES", "Ledger completo de mismatches", "RESULTS/t10_rosetta_core/t10_mismatches.csv", "Exhaustividad del panel, no de todos los coarse-grainings posibles."),
        row("R017", "H10.2 paso: q,d,s,a,p tienen testigos requeridos y los nuisances congelados colapsan en el panel.", "HECHO_COMPUTACIONAL", "PASS", "Familia de testigos T10", "FROZEN_HOLDOUT", "YES", "Witness panel", "RESULTS/t10_rosetta_core/t10_result.json", "Minimalidad conjunta/sectorial, no global."),
        row("R018", "H10.3 paso 1872/1872 checks de composicion K_free.", "HECHO_COMPUTACIONAL", "PASS", "Composiciones congeladas", "FROZEN_HOLDOUT", "YES", "Comparacion exacta", "RESULTS/t10_rosetta_core/t10_result.json", "No implica superposicion en colisiones guardadas."),
        row("R019", "T11 confirmo mayoria coordenada de cinco fuentes y ocho fibras inversas de siete subconjuntos.", "LEY_NATIVA_EMPIRICA", "PASS_NO_REFIT", "56 subconjuntos B8 x perfiles; N=23", "FROZEN_HOLDOUT", "YES", "448 trayectorias, 896 ticks, cero mismatches", "RESULTS/t11_inverse_majority/t11_result.json", "Aridad impar evita d_out=0; caveat de secuencias de perfiles documentado."),
        row("R020", "T12 probo prospectivamente la reparacion estado-evento G_dagger/J_dagger en aridades nuevas.", "LEY_NATIVA_EMPIRICA", t12_status, "D_*; aridades 3,4,6; N=19", "POSTHOC_REPAIR_HOLDOUT", "POSTHOC_TO_T10_YES_TO_T12", "Holdout nuevo de 748 trayectorias", "RESULTS/t12_state_event_repair/t12_result.json", "No repara retrospectivamente T10 ni demuestra cierre global."),
        row("R021", "Separar estado predictivo canonico y evento transitorio preserva S en J_dagger aunque d_out=0 y cierra el futuro en D_*.", "ESTRUCTURA_ESPECIFICA_DEE", "POSTHOC_THEOREM_AND_T12_" + t12_verdict, "Transductor sparse D_*", "POSTHOC_REPAIR", "POSTHOC_TO_T10_YES_TO_T12", "Prueba por ramas mas T12", "EXACT_THEOREMS.md", "No hay identidad fisica asignada al evento."),
        row("R022", "clock_i(t)=clock_i(0)+t mod 2^64 y sus diferencias son invariantes modulares.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Full state ABI valido", "IMPORTED_V1", "V1_CLOSED", "Prueba de todos los returns y wrap binario", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "La igualdad entera ordinaria requiere no-wrap."),
        row("R023", "El periodo causal raw minimo comun sin wrap es 304980, no 1094573220.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Shifts de clock que no cruzan wrap", "IMPORTED_V1", "V1_CLOSED", "LCM de gates alcanzables y testigos", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "No es periodo del full-state ni tiempo SI."),
        row("R024", "La dependencia raw satisface r_Cheb(t)<=min(3t,diam_infty(T_N)); la velocidad 3 por tick es aguda cuando el diametro toroidal permite distancia 3.", "TEOREMA_EXACTO_F_DEE", "PROVEN_SHARP_WHERE_GEOMETRY_PERMITS", "Full raw v27", "IMPORTED_V1", "V1_CLOSED", "Analisis estatico DEMUX y testigo a distancia 3", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "En toros pequenos satura el diametro; no es automaticamente cono de luz fisico."),
        row("R025", "F_DEE no es inyectiva para N>=3.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "ABI valida", "IMPORTED_V1", "V1_CLOSED", "Preimagenes state 1/2 con imagen completa comun", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "No todo raw aislado colapsa."),
        row("R026", "Raws semantic=4 son fijos punto a punto y generan una familia de invariantes aditivos de rango cero.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Full v27", "IMPORTED_V1", "V1_CLOSED", "Prueba de ramas y testigos", "PARENT_V1_INPUTS/ANALYSIS/native_theory/EXACT_PROOFS.md", "No implica energia global."),
        row("R027", "Traslaciones toroidales son simetrias exactas; O_h global falla por desempate lexicografico DEMUX.", "TEOREMA_EXACTO_F_DEE", "TRANSLATION_PROVEN_OH_REFUTED", "Full v27", "IMPORTED_V1", "V1_CLOSED", "Prueba y testigo de inversion", "PARENT_V1_SUMMARY/CLAUDE_AUDIT.md", "Simetrias cubicas pueden sobrevivir sectorialmente."),
        row("R028", "Todo embedding lineal euclideo directo de D26 tiene ratio de velocidades al menos sqrt(3).", "PUENTE_CONDICIONAL", "PROVEN_ALGEBRAIC_OBSTRUCTION", "A invertible y tau comun", "ROSETTA_THEORY", "PRE_EXTERNAL", "Cota por promedio de diagonales corporales", "EXACT_THEOREMS.md", "Teorema estatico condicionado al embedding; no es ley de F_DEE ni cubre geometria emergente."),
        row("R029", "La nondispersion libre respecto de etiqueta es compatible con los siete escenarios lineales Fermi.", "CORRESPONDENCIA_EXTERNA", "COMPATIBLE_NOT_VALIDATING", "Asignacion monotona energia-s; mismo camino", "EXTERNAL_SHADOW", "YES_SHADOW", "Comparacion con paper primario", "RESULTS/external/e1_e2_results.json", "No identifica energia con s_reg ni discrimina DEE.", "COMPATIBLE_NOT_VALIDATING"),
        row("R030", "La igualdad de velocidad libre entre dos etiquetas es compatible con el bound GW/EM [-3e-15,+7e-16].", "CORRESPONDENCIA_EXTERNA", "COMPATIBLE_NOT_VALIDATING", "Asignacion condicional GW/EM a etiquetas comunes", "EXTERNAL_SHADOW", "YES_SHADOW", "Comparacion con paper conjunto primario", "RESULTS/external/e1_e2_results.json", "Depende de lags 0/10 s; no identifica clases DEE.", "COMPATIBLE_NOT_VALIDATING"),
        row("R031", "El contraste E3 con Nagel es inconcluso porque no se congelo el operador forward de velocidades D26 a frecuencia de resonador.", "NO_IDENTIFICABLE", "INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN", "Holdout optico E3", "EXTERNAL_SHADOW_AUDIT", "YES_SHADOW_AUDIT_CORRECTED", "Auditoria adversarial conservando el resultado original", "RESULTS/external/e3_adjudication_audit.json", "La obstruccion interna sqrt(3) sobrevive; no se ajusto un mapa alternativo.", "INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN"),
        row("R032", "No se identifico dataset externo calificante para la firma de oclusion/fase E4.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "Busqueda congelada con cuatro criterios", "EXTERNAL_SHADOW", "YES_SHADOW", "Tres consultas, maximo 20 candidatos por consulta", "EXTERNAL_SOURCES/E4_SEARCH_LOG.md", "No es FAIL de la ley interna.", "NOT_IDENTIFIABLE"),
        row("R033", "No se identifico dataset externo calificante de coalescencia simultanea de cinco entradas E5.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "Busqueda congelada", "EXTERNAL_SHADOW", "YES_SHADOW", "Tres consultas, criterios de aridad/intensidad/direccion", "EXTERNAL_SOURCES/E5_SEARCH_LOG.md", "No refuta T11 ni otros significados de s/d.", "NOT_IDENTIFIABLE"),
        row("R034", "Los holdouts disponibles no identifican metros/voxel, segundos/tick ni una escala absoluta comun.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "E1-E5", "SYNTHESIS", "CONTRACT_FROZEN", "Analisis de rango de calibracion", "ROSETTA_CALIBRATION.md", "E1/E2 son ratios; E3 carece de likelihood forward; E4/E5 carecen de datos."),
        row("R035", "No se identifico masa/inercia: velocidad no depende de state/s y la direccion de colision no esta ponderada por s.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "Nucleo sparse/libre", "SYNTHESIS", "NOT_APPLICABLE", "Comparacion funcional de respuestas", "EFFECTIVE_STATE_SPACE.md", "No constituye teorema de imposibilidad para otros sectores."),
        row("R036", "Z distribuido cambia guards y aristas causales, dando geometria de respuesta dependiente del estado.", "HIPOTESIS_EMERGENCIA", "INTERNAL_OPERATIONAL_ONLY", "D_*", "SYNTHESIS", "NOT_APPLICABLE", "Lectura comun de G_dagger/K_dagger", "UNIFIED_RESPONSE_KERNEL.md", "No se ha derivado gravedad ni equivalencia universal materia-geometria."),
        row("R037", "No se identificaron termodinamica o hidrodinamica cerradas.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "v27 y sectores estudiados", "SYNTHESIS", "NOT_APPLICABLE", "Auditoria de variables funcionales", "ROSETTA_FAILURES_AND_LIMITS.md", "Faltan energia, ensemble, equilibrio, temperatura, stress y limite de escala."),
        row("R038", "No existe un experimento Bell/CHSH operacional DEE ni regla Born identificada.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "Kernel/runners disponibles", "SYNTHESIS", "NOT_APPLICABLE", "Auditoria de settings/outcomes/independencia", "CLAUDE_AUDIT.md", "Determinismo solo no adjudica Bell; faltan variables operacionales."),
        row("R039", "No se identifico gauge fisico; hay traslaciones exactas y redundancia de fase raw condicionada.", "NO_IDENTIFICABLE", "NOT_IDENTIFIABLE", "Full v27", "SYNTHESIS", "NOT_APPLICABLE", "Auditoria de simetrias", "PARENT_V1_SUMMARY/EXECUTIVE_VERDICT.md", "Redundancia de clock sin wrap no es gauge dinamico global."),
        row("R040", "19665/19664,782,966 y 194422 descienden de una misma cadena constitutiva y no son predicciones independientes.", "RESULTADO_NEGATIVO", "GENEALOGY_CONFIRMED", "Corpus y kernel v27", "DISCOVERY", "NO_DISCOVERY", "Grafo de dependencia y locators", "ANALYSIS/constants/CONSTANT_GENEALOGY_DISCOVERY.json", "Implementacion no demuestra naturalidad externa."),
        row("R041", "El threshold 966 tiene sensibilidad runtime cero en v27 porque el cociente maximo alcanzable es 49.", "TEOREMA_EXACTO_F_DEE", "PROVEN", "Packed raw valido", "IMPORTED_V1_AND_AUDIT", "V1_CLOSED", "Cota exacta del gradiente", "CONSTANT_GENEALOGY_AUDIT.md", "Prueba codigo muerto, no relacion con alpha."),
        row("R042", "20 Hz es un target historico contaminado y no una salida del kernel sin mapa dimensional independiente.", "RESULTADO_NEGATIVO", "TARGET_LEAKAGE", "Formulas historicas", "DISCOVERY", "NO_DISCOVERY", "Genealogia y comparacion RMSE", "ANALYSIS/constants/CONSTANT_GENEALOGY_DISCOVERY.md", "Ajustar tick o voxel al mismo target seria tautologico."),
        row("R043", "La arquitectura transversal mas economica es un transductor de registros dirigidos, guards, reducer, persistencia y eventos; no un diccionario de nombres.", "ESTRUCTURA_ESPECIFICA_DEE", "CONSTRUCTED_INTERNAL_PARTIAL", "D_* mas sectores V1", "SYNTHESIS", "POSTHOC_REPAIR_DISCLOSED", "Sintesis de M_*,G_dagger,J_dagger,K_dagger", "DEE_ROSETTA_V27_CONSTRUCTED.md", "El patron abstracto puede ser generico; alfabeto, cap, guards y firmas son de v27."),
        row("R044", "El estado de cierre es ROSETTA_PARTIAL: nucleo interno reparado/sectorial y puentes nulos condicionados, sin validacion fisica externa.", "PUENTE_CONDICIONAL", "ROSETTA_PARTIAL", "Mision Rosetta", "SYNTHESIS", "NO_RETROACTIVE_RECLASSIFICATION", "Adjudicacion conjunta con T10 y auditoria E3 preservados", "EXECUTIVE_VERDICT.md", "T10 permanece FAIL; E3 externo inconcluso; E4/E5 no identificables."),
        row("R045", "Bajo H_DEE falta un mapa independiente de preparacion/medicion y una geometria/escala coarse-grained que haga predicciones cruzadas nuevas.", "NO_IDENTIFICABLE", "EXACT_EXTERNAL_GAP", "Conexion con realidad fisica", "SYNTHESIS", "NOT_APPLICABLE", "Analisis de identificabilidad", "OPEN_EXTERNAL_GAPS.md", "Esa identidad no puede deducirse interrogando solo F_DEE."),
    ]

    ids = [item["claim_id"] for item in claims]
    if len(ids) != len(set(ids)) or ids != sorted(ids):
        raise SystemExit("claim ids not unique/sorted")
    PACKAGE.mkdir(parents=True, exist_ok=True)
    ledger_json = PACKAGE / "ROSETTA_CLAIM_LEDGER.json"
    ledger_json.write_text(json.dumps({
        "schema": "dee.v27.rosetta.claim_ledger.v1",
        "claim_count": len(claims),
        "allowed_epistemic_classes": sorted(ALLOWED_CLASSES),
        "t12_verdict_at_generation": t12_verdict,
        "claims": claims,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.copy2(ledger_json, PACKAGE / "CLAIM_LEDGER.json")

    experiments = [
        {"experiment_id":"D01","phase":"DISCOVERY","question":"Fuentes state-zero","status":"PASS","sample":"48 casos; 96 ticks","mismatches":"0","preregistered":"NO","evidence_path":"DISCOVERY/ghost_sources_result.json","evidence_sha256":sha256(evidence_source("DISCOVERY/ghost_sources_result.json")),"notes":"Primer fallo de instrumentacion preservado aparte."},
        {"experiment_id":"D02","phase":"DISCOVERY","question":"Nucleo comun de respuesta","status":"PASS","sample":"4809 checks; 178 ticks","mismatches":"0","preregistered":"NO","evidence_path":"DISCOVERY/response_discovery_results.json","evidence_sha256":sha256(evidence_source("DISCOVERY/response_discovery_results.json")),"notes":"Construccion, no confirmacion."},
        {"experiment_id":"D03","phase":"ADVERSARIAL_DISCOVERY","question":"Lumpabilidad M_* y nuisances","status":"PASS_WITH_GLOBAL_COUNTEREXAMPLE","sample":"98 checks; 76 ticks","mismatches":"0 del runner; counterexample esperado","preregistered":"NO","evidence_path":"DISCOVERY/response_mstar_adversarial_results.json","evidence_sha256":sha256(evidence_source("DISCOVERY/response_mstar_adversarial_results.json")),"notes":"El contraejemplo semantic5 es denso/XNOR y queda fuera de D_*; extension requiere flag/exclusion."},
        {"experiment_id":"D04","phase":"PARTITION_REFINEMENT","question":"Cocientes predictivos sectoriales","status":"PASS_7_OF_7","sample":"paneles simbolicos documentados","mismatches":"0 suficiencia; 0 minimalidad","preregistered":"NO","evidence_path":"ANALYSIS/partition/PARTITION_DISCOVERY.json","evidence_sha256":sha256(evidence_source("ANALYSIS/partition/PARTITION_DISCOVERY.json")),"notes":"No minimo global."},
        {"experiment_id":"D05","phase":"DISCOVERY","question":"Genealogia/sensibilidad de constantes","status":"COMPLETE","sample":"22 cantidades clasificadas","mismatches":"NOT_APPLICABLE","preregistered":"NO","evidence_path":"ANALYSIS/constants/CONSTANT_GENEALOGY_DISCOVERY.json","evidence_sha256":sha256(evidence_source("ANALYSIS/constants/CONSTANT_GENEALOGY_DISCOVERY.json")),"notes":"Sin web y pre-holdout."},
        {"experiment_id":"T10","phase":"FROZEN_INTERNAL_HOLDOUT","question":"Cierre M_*/G_*","status":"FAIL_NO_REFIT","sample":"1389 trayectorias; 5598 ticks","mismatches":"192 = 96 cierre + 96 alineacion","preregistered":"YES","evidence_path":"RESULTS/t10_rosetta_core/t10_result.json","evidence_sha256":sha256(evidence_source("RESULTS/t10_rosetta_core/t10_result.json")),"notes":"0 domain failures; H10.2/H10.3 PASS."},
        {"experiment_id":"T11","phase":"FROZEN_INTERNAL_HOLDOUT","question":"Inversa mayoria cinco fuentes","status":"PASS_NO_REFIT","sample":"448 trayectorias; 896 ticks","mismatches":"0","preregistered":"YES","evidence_path":"RESULTS/t11_inverse_majority/t11_result.json","evidence_sha256":sha256(evidence_source("RESULTS/t11_inverse_majority/t11_result.json")),"notes":"8 fibras x 7 subconjuntos."},
        {"experiment_id":"T12","phase":"POSTHOC_REPAIR_HOLDOUT","question":"Transductor estado-evento","status":t12_verdict,"sample":f"{t12_counts['primary_trajectories']} trayectorias; {t12_counts['primary_ticks']} ticks","mismatches":str(t12_counts["mismatches"]),"preregistered":"POSTHOC_TO_T10_YES_TO_T12","evidence_path":"RESULTS/t12_state_event_repair/t12_result.json","evidence_sha256":sha256(evidence_source("RESULTS/t12_state_event_repair/t12_result.json")),"notes":"No cambia T10."},
        {"experiment_id":"E1","phase":"EXTERNAL_SHADOW","question":"Nondispersion por etiqueta","status":"COMPATIBLE_NOT_VALIDATING","sample":"7 escenarios lineales Fermi","mismatches":"NOT_APPLICABLE","preregistered":"YES_SHADOW","evidence_path":"RESULTS/external/e1_e2_results.json","evidence_sha256":sha256(evidence_source("RESULTS/external/e1_e2_results.json")),"notes":"Cero permitido; no DEE-specific."},
        {"experiment_id":"E2","phase":"EXTERNAL_SHADOW","question":"Velocidad comun GW/EM","status":"COMPATIBLE_NOT_VALIDATING","sample":"delta en [-3e-15,+7e-16]","mismatches":"NOT_APPLICABLE","preregistered":"YES_SHADOW","evidence_path":"RESULTS/external/e1_e2_results.json","evidence_sha256":sha256(evidence_source("RESULTS/external/e1_e2_results.json")),"notes":"Supuestos de emision 0/10 s."},
        {"experiment_id":"E3","phase":"EXTERNAL_SHADOW_AUDIT","question":"Geometria euclidea lineal directa frente a resonador","status":"INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN","sample":"ratio D26 interno y coeficiente de frecuencia externo no enlazados operacionalmente","mismatches":"NOT_ADJUDICABLE","preregistered":"YES_SHADOW; AUDIT_CORRECTION","evidence_path":"RESULTS/external/e3_adjudication_audit.json","evidence_sha256":sha256(evidence_source("RESULTS/external/e3_adjudication_audit.json")),"notes":"FAIL_BRIDGE original preservado; teorema sqrt(3) sobrevive; sin refit."},
        {"experiment_id":"E4","phase":"EXTERNAL_SHADOW","question":"Analogo oclusion/fase","status":"NOT_IDENTIFIABLE","sample":"3 consultas; cap 20/query","mismatches":"NO_QUALIFYING_DATASET_DOCUMENTED","preregistered":"YES_SHADOW","evidence_path":"EXTERNAL_SOURCES/E4_SEARCH_LOG.md","evidence_sha256":sha256(evidence_source("EXTERNAL_SOURCES/E4_SEARCH_LOG.md")),"notes":"No es FAIL interno; falta registry candidato-por-candidato."},
        {"experiment_id":"E5","phase":"EXTERNAL_SHADOW","question":"Analogo cinco fuentes","status":"NOT_IDENTIFIABLE","sample":"3 consultas; cap 20/query","mismatches":"NO_QUALIFYING_DATASET_DOCUMENTED","preregistered":"YES_SHADOW","evidence_path":"EXTERNAL_SOURCES/E5_SEARCH_LOG.md","evidence_sha256":sha256(evidence_source("EXTERNAL_SOURCES/E5_SEARCH_LOG.md")),"notes":"No es FAIL de T11; falta registry candidato-por-candidato."},
    ]
    experiment_json = PACKAGE / "EXPERIMENT_INDEX.json"
    experiment_json.write_text(json.dumps({
        "schema": "dee.v27.rosetta.experiment_index.v1",
        "experiment_count": len(experiments),
        "experiments": experiments,
    }, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    print(json.dumps({
        "status": "PASS",
        "claims": len(claims),
        "experiments": len(experiments),
        "t12": t12_verdict,
        "ledger_json_sha256": sha256(ledger_json),
        "experiment_json_sha256": sha256(experiment_json),
        "next": "materialize and validate CSVs with artifact_tool",
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
