#!/usr/bin/env python3
"""Copy the sealed Rosetta evidence into the compact final package.

The script never deletes source artifacts and never traverses FINAL_PACKAGE as
an input. It preflights identities and refuses any pre-existing generated tree,
so a stale package cannot be accumulated or silently overwritten.
"""
from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parent.parent
V1 = ROOT.parent
TESTS = V1.parent
PACKAGE = ROOT / "FINAL_PACKAGE"
EXPECTED_IDENTITIES = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package_init": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "constants_wrapper": "339ebcd5602a09a0b1b4bcdc848b3f357237ee5b07778d05e915312c8faa6241",
    "api_wrapper": "d777704de34f2df70b259d4f36a12d6a4b7355620517ad1d9537c53c4a5b8454",
    "kernel_pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "kernel_cpp": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
    "contract": "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157",
    "repair_contract": "b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def copy_file(source: Path, destination: Path) -> None:
    if not source.is_file():
        raise FileNotFoundError(source)
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)


def copy_tree(source: Path, destination: Path) -> None:
    if not source.is_dir():
        raise FileNotFoundError(source)
    for path in sorted(source.rglob("*")):
        if not path.is_file() or "__pycache__" in path.parts:
            continue
        copy_file(path, destination / path.relative_to(source))


def main() -> int:
    wheel_candidates = [
        TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl",
        V1 / "FINAL_PACKAGE" / "INPUTS" / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl",
    ]
    wheel = next((path for path in wheel_candidates if path.is_file()), None)
    if wheel is None:
        raise FileNotFoundError("sealed v27 wheel")
    extracted = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
    kernel_package = extracted / "dee_universe_v27"
    source_identities = {
        "wheel": sha256(wheel),
        "package_init": sha256(kernel_package / "__init__.py"),
        "constants_wrapper": sha256(kernel_package / "dee_constants_v27.py"),
        "api_wrapper": sha256(kernel_package / "dee_universe_v27.py"),
        "kernel_pyd": sha256(kernel_package / "dee_kernel_v27.cp313-win_amd64.pyd"),
        "kernel_cpp": sha256(kernel_package / "dee_kernel_v27.cpp"),
        "contract": sha256(ROOT / "HOLDOUTS" / "ROSETTA_FROZEN_CONTRACT.json"),
        "repair_contract": sha256(ROOT / "HOLDOUTS" / "POST_T10_REPAIR_CONTRACT.json"),
    }
    if source_identities != EXPECTED_IDENTITIES:
        raise SystemExit(f"source identity mismatch before package mutation: {source_identities}")

    parent_docs = (
        "EXECUTIVE_VERDICT.md",
        "EXACT_THEOREMS.md",
        "CLAUDE_AUDIT.md",
        "HISTORICAL_CLAIMS_AUDIT.md",
        "NATIVE_DEE_THEORY.md",
    )
    provenance_files = ("README.md", "STATE.json", "RUN_LOG.ndjson", "DECISIONS.md", "RESEARCH_PLAN.md", "EXTERNAL_BLIND_POLICY.md")
    tree_sources = [*(ROOT / name for name in ("HOLDOUTS", "DISCOVERY", "ANALYSIS", "RESULTS", "EXTERNAL_SOURCES", "RUNNERS_NEW")), extracted]
    file_sources = [
        *(ROOT / name for name in provenance_files),
        *(V1 / "FINAL_PACKAGE" / name for name in parent_docs),
        V1 / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip.sha256",
        V1 / "ANALYSIS" / "native_theory" / "EXACT_PROOFS.md",
        V1 / "RESULTS" / "native_ballistic" / "t8_result.json",
        V1 / "RESULTS" / "observer_pump" / "t9_result.json",
    ]
    missing = [str(path) for path in tree_sources if not path.is_dir()] + [str(path) for path in file_sources if not path.is_file()]
    if missing:
        raise SystemExit(f"missing source inputs before package mutation: {missing}")
    reparse_sources = [str(path) for tree in tree_sources for path in (tree, *tree.rglob("*")) if path.is_symlink()]
    if reparse_sources:
        raise SystemExit(f"refusing symlinked/reparse source inputs: {reparse_sources}")

    generated_paths = [
        *(PACKAGE / name for name in ("HOLDOUTS", "DISCOVERY", "ANALYSIS", "RESULTS", "EXTERNAL_SOURCES", "RUNNERS_NEW")),
        *(PACKAGE / name for name in ("PROVENANCE", "INPUTS", "PARENT_V1_SUMMARY", "PARENT_V1_INPUTS")),
        PACKAGE / "ROSETTA_FROZEN_CONTRACT.json",
    ]
    preexisting = [str(path) for path in generated_paths if path.exists() or path.is_symlink()]
    if preexisting:
        raise SystemExit(f"refusing stale/generated destinations: {preexisting}")
    if PACKAGE.is_symlink():
        raise SystemExit("FINAL_PACKAGE must not be a symlink or junction")

    PACKAGE.mkdir(parents=True, exist_ok=True)

    for dirname in ("HOLDOUTS", "DISCOVERY", "ANALYSIS", "RESULTS", "EXTERNAL_SOURCES", "RUNNERS_NEW"):
        copy_tree(ROOT / dirname, PACKAGE / dirname)

    for filename in provenance_files:
        copy_file(ROOT / filename, PACKAGE / "PROVENANCE" / filename)

    copy_file(ROOT / "HOLDOUTS" / "ROSETTA_FROZEN_CONTRACT.json", PACKAGE / "ROSETTA_FROZEN_CONTRACT.json")

    copy_file(wheel, PACKAGE / "INPUTS" / wheel.name)

    copy_tree(extracted, PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted")

    for filename in parent_docs:
        copy_file(V1 / "FINAL_PACKAGE" / filename, PACKAGE / "PARENT_V1_SUMMARY" / filename)
    copy_file(
        V1 / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip.sha256",
        PACKAGE / "PARENT_V1_SUMMARY" / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip.sha256",
    )
    for source, destination in (
        (V1 / "ANALYSIS" / "native_theory" / "EXACT_PROOFS.md", PACKAGE / "PARENT_V1_INPUTS" / "ANALYSIS" / "native_theory" / "EXACT_PROOFS.md"),
        (V1 / "RESULTS" / "native_ballistic" / "t8_result.json", PACKAGE / "PARENT_V1_INPUTS" / "RESULTS" / "native_ballistic" / "t8_result.json"),
        (V1 / "RESULTS" / "observer_pump" / "t9_result.json", PACKAGE / "PARENT_V1_INPUTS" / "RESULTS" / "observer_pump" / "t9_result.json"),
    ):
        copy_file(source, destination)

    identities = {
        "wheel": sha256(PACKAGE / "INPUTS" / wheel.name),
        "package_init": sha256(PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "__init__.py"),
        "constants_wrapper": sha256(PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "dee_constants_v27.py"),
        "api_wrapper": sha256(PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "dee_universe_v27.py"),
        "kernel_pyd": sha256(PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"),
        "kernel_cpp": sha256(PACKAGE / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "dee_kernel_v27.cpp"),
        "contract": sha256(PACKAGE / "ROSETTA_FROZEN_CONTRACT.json"),
        "repair_contract": sha256(PACKAGE / "HOLDOUTS" / "POST_T10_REPAIR_CONTRACT.json"),
    }
    if identities != EXPECTED_IDENTITIES:
        raise SystemExit(f"identity mismatch: {identities}")

    print(json.dumps({"status": "PASS", "package": str(PACKAGE), "identity": identities}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
