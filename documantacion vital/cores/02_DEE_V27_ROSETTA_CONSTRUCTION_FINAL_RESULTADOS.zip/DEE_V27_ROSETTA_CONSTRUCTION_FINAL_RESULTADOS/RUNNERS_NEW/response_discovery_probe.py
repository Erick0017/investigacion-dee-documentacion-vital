#!/usr/bin/env python3
"""Economic discovery probes for a mesoscopic v27 response core.

This is deliberately not a holdout and freezes no contract.  It reads the
accepted v27 wheel extraction from the completed V1 audit without modifying
those upstream artifacts, executes selected discriminating examples, and
writes only beneath ROSETTA_CLOSURE/DISCOVERY.
"""
from __future__ import annotations

import hashlib
import importlib
import itertools
import json
import platform
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROSETTA = HERE.parents[1]
V1 = ROSETTA.parent
TESTS = V1.parent
EXTRACTED = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKG = EXTRACTED / "dee_universe_v27"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_FILE = PKG / "dee_kernel_v27.cp313-win_amd64.pyd"
SOURCE_FILE = PKG / "dee_kernel_v27.cpp"
OUTDIR = ROSETTA / "DISCOVERY"
OUTPUT = OUTDIR / "response_discovery_results.json"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "source": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
}
MASK64 = (1 << 64) - 1
N = 13
DIRECTIONS = [
    d
    for d in itertools.product((-1, 0, 1), repeat=3)
    if d != (0, 0, 0)
]
REPRESENTATIVE_DIRECTIONS = [(1, 0, 0), (1, 1, 0), (1, 1, 1)]


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(a)).cast("B")).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 0xF) << 48)
        | ((d[1] & 0xF) << 52)
        | ((d[2] & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def unpack(raw: int | np.uint64) -> dict[str, int]:
    value = int(raw)

    def signed_nibble(shift: int) -> int:
        nibble = (value >> shift) & 0xF
        return nibble - 16 if nibble & 8 else nibble

    return {
        "raw": value,
        "state": value & 0xFFFFFFFF,
        "s_reg": (value >> 32) & 0xFFFF,
        "direction": [
            signed_nibble(48),
            signed_nibble(52),
            signed_nibble(56),
        ],
        "semantic": (value >> 60) & 0xF,
    }


def index(q: tuple[int, int, int], n: int = N) -> int:
    return (q[0] * n + q[1]) * n + q[2]


def add(q: tuple[int, int, int], d: tuple[int, int, int], k: int = 1, n: int = N) -> tuple[int, int, int]:
    return tuple((q[a] + k * d[a]) % n for a in range(3))


def sign_sum(ds: tuple[tuple[int, int, int], ...] | list[tuple[int, int, int]]) -> tuple[int, int, int]:
    sums = [sum(d[a] for d in ds) for a in range(3)]
    return tuple((x > 0) - (x < 0) for x in sums)


def support(raw: np.ndarray, n: int = N) -> list[list[int]]:
    return [
        [int(v) for v in row]
        for row in np.argwhere(raw.reshape(n, n, n) != 0)
    ]


def active_support(raw: np.ndarray, n: int = N) -> list[list[int]]:
    active = np.bitwise_and(raw, np.uint64(0xFFFFFFFF)) != 0
    return [
        [int(v) for v in row]
        for row in np.argwhere(active.reshape(n, n, n))
    ]


class Simulation:
    def __init__(self, kernel, raw: np.ndarray, n: int = N) -> None:
        self.n = n
        self.raw_a = np.ascontiguousarray(raw, dtype=np.uint64).reshape(-1).copy()
        self.raw_b = np.zeros_like(self.raw_a)
        self.clock_a = np.zeros(n**3, dtype=np.uint64)
        self.clock_b = np.zeros_like(self.clock_a)
        self.fn = kernel.tick_universo

    def step(self) -> dict:
        info = dict(
            self.fn(
                self.raw_a,
                self.raw_b,
                self.clock_a,
                self.clock_b,
                self.n,
                1,
            )
        )
        return {
            "buffers_equal": bool(
                np.array_equal(self.raw_a, self.raw_b)
                and np.array_equal(self.clock_a, self.clock_b)
            ),
            "kernel_info": {
                str(k): int(v) if isinstance(v, (int, np.integer)) else float(v)
                for k, v in info.items()
            },
        }


def one_raw(q: tuple[int, int, int], word: np.uint64, n: int = N) -> np.ndarray:
    raw = np.zeros(n**3, dtype=np.uint64)
    raw[index(q, n)] = word
    return raw


def expected_singleton(q0, d, sreg, t, n=N) -> np.ndarray:
    return one_raw(add(q0, d, t, n), pack(1, sreg, d, 1), n)


def record_check(result: dict, condition: bool, family: str, case: str, detail: dict | None = None) -> None:
    result["check_count"] += 1
    if not condition:
        result["mismatches"].append(
            {"family": family, "case": case, "detail": detail or {}}
        )


def geometry_and_free_response(kernel, result: dict) -> dict:
    q_origin = (0, 0, 0)
    orbit_lengths = {}
    first_passage: dict[tuple[int, int, int], int] = {q_origin: 0}
    for d in DIRECTIONS:
        orbit = [add(q_origin, d, t) for t in range(N)]
        orbit_lengths[str(d)] = len(set(orbit))
        for t, point in enumerate(orbit):
            first_passage[point] = min(t, first_passage.get(point, N + 1))

    shells = Counter(first_passage.values())
    semigroup_checks = 0
    for d in DIRECTIONS:
        for a in range(N):
            for b in range(N):
                left = add(add(q_origin, d, a), d, b)
                right = add(q_origin, d, a + b)
                semigroup_checks += 1
                record_check(result, left == right, "free_semigroup", f"{d}:{a}+{b}")

    traces = []
    q0 = (3, 4, 5)
    displacement = (0, 3, 0)
    shifted_q0 = add(q0, displacement)
    for d in REPRESENTATIVE_DIRECTIONS:
        base = Simulation(kernel, one_raw(q0, pack(1, 7, d, 1)))
        shifted = Simulation(kernel, one_raw(shifted_q0, pack(1, 7, d, 1)))
        charged = Simulation(kernel, one_raw(q0, pack(1, 8, d, 1)))
        per_tick = []
        for t in range(1, 8):
            info_base = base.step()
            info_shift = shifted.step()
            info_charge = charged.step()
            result["kernel_ticks"] += 3
            expected_base = expected_singleton(q0, d, 7, t)
            expected_shift = expected_singleton(shifted_q0, d, 7, t)
            expected_charge = expected_singleton(q0, d, 8, t)
            record_check(result, np.array_equal(base.raw_a, expected_base), "free_kernel", f"{d}:base:t{t}")
            record_check(result, np.array_equal(shifted.raw_a, expected_shift), "free_kernel", f"{d}:shift:t{t}")
            record_check(result, np.array_equal(charged.raw_a, expected_charge), "free_kernel", f"{d}:charge:t{t}")
            record_check(result, info_base["buffers_equal"] and info_shift["buffers_equal"] and info_charge["buffers_equal"], "copyback", f"free:{d}:t{t}")
            spatial_hamming = int(np.count_nonzero(base.raw_a != shifted.raw_a))
            charge_hamming = int(np.count_nonzero(base.raw_a != charged.raw_a))
            record_check(result, spatial_hamming == 2, "free_stability", f"{d}:spatial:t{t}")
            record_check(result, charge_hamming == 1, "free_stability", f"{d}:charge:t{t}")
            per_tick.append(
                {
                    "tick": t,
                    "base_hash": sha256_array(base.raw_a),
                    "shifted_hash": sha256_array(shifted.raw_a),
                    "charge_hash": sha256_array(charged.raw_a),
                    "spatial_hamming": spatial_hamming,
                    "charge_hamming": charge_hamming,
                }
            )
        traces.append({"direction": list(d), "ticks": per_tick})

    return {
        "N": N,
        "phase_space_graph": "(x,d)->(x+d,d)",
        "velocity_count": len(DIRECTIONS),
        "all_orbit_lengths": sorted(set(orbit_lengths.values())),
        "semigroup_symbolic_checks": semigroup_checks,
        "spatial_union_reachable_sites": len(first_passage),
        "spatial_union_inaccessible_sites": N**3 - len(first_passage),
        "first_passage_shells": {str(k): shells[k] for k in sorted(shells)},
        "free_response_traces": traces,
    }


def observer_expected(q, d, observer_raw, sreg, tick, delayed=False) -> np.ndarray:
    raw = one_raw(q, observer_raw)
    effective_tick = tick - 1 if delayed else tick
    if effective_tick > 0:
        for k in range(1, effective_tick + 1):
            if k % 2 == effective_tick % 2:
                raw[index(add(q, d, k))] = pack(1, sreg, d, 1)
    return raw


def observer_phase_response(kernel, result: dict) -> dict:
    q = (6, 6, 6)
    horizon = 9
    cases = []
    for d in REPRESENTATIVE_DIRECTIONS:
        observer = pack(0, 7, d, 4)
        baseline_raw = one_raw(q, observer)
        blocked_raw = baseline_raw.copy()
        blocked_raw[index(add(q, d))] = pack(1, 0, (0, 0, 0), 1)
        baseline = Simulation(kernel, baseline_raw)
        blocked = Simulation(kernel, blocked_raw)
        first_baseline: dict[int, int] = {}
        first_blocked: dict[int, int] = {}
        blocker_absent_after_tick_1 = False
        trace = []
        for t in range(1, horizon + 1):
            info_base = baseline.step()
            info_block = blocked.step()
            result["kernel_ticks"] += 2
            expected_base = observer_expected(q, d, observer, 7, t, delayed=False)
            expected_block = observer_expected(q, d, observer, 7, t, delayed=True)
            record_check(result, np.array_equal(baseline.raw_a, expected_base), "observer", f"{d}:baseline:t{t}")
            record_check(result, np.array_equal(blocked.raw_a, expected_block), "observer", f"{d}:blocked:t{t}")
            record_check(result, info_base["buffers_equal"] and info_block["buffers_equal"], "copyback", f"observer:{d}:t{t}")
            hamming = int(np.count_nonzero(baseline.raw_a != blocked.raw_a))
            record_check(result, hamming == t, "observer_phase_memory", f"{d}:hamming:t{t}", {"actual": hamming, "expected": t})
            if t == 1:
                blocker_absent_after_tick_1 = bool(blocked.raw_a[index(add(q, d))] == 0)
                record_check(result, blocker_absent_after_tick_1, "observer_phase_memory", f"{d}:blocker_gone:t1")
            for k in range(1, horizon):
                detector = index(add(q, d, k))
                if baseline.raw_a[detector] != 0 and k not in first_baseline:
                    first_baseline[k] = t
                if blocked.raw_a[detector] != 0 and k not in first_blocked:
                    first_blocked[k] = t
            trace.append(
                {
                    "tick": t,
                    "baseline_support": support(baseline.raw_a),
                    "blocked_support": support(blocked.raw_a),
                    "response_hamming": hamming,
                    "baseline_hash": sha256_array(baseline.raw_a),
                    "blocked_hash": sha256_array(blocked.raw_a),
                }
            )
        for k in range(1, horizon):
            record_check(result, first_baseline.get(k) == k, "first_passage", f"{d}:baseline:k{k}")
            record_check(result, first_blocked.get(k) == k + 1, "first_passage", f"{d}:blocked:k{k}")
        cases.append(
            {
                "direction": list(d),
                "transient_blocker": "normal state=1,s_reg=0,d=0 at q+d only at t=0",
                "blocker_absent_after_tick_1": blocker_absent_after_tick_1,
                "baseline_first_passage": {str(k): first_baseline[k] for k in sorted(first_baseline)},
                "blocked_first_passage": {str(k): first_blocked[k] for k in sorted(first_blocked)},
                "trace": trace,
            }
        )
    return {
        "N": N,
        "horizon": horizon,
        "cases": cases,
        "prediction": "one-tick mouth occlusion delays every pre-wrap detector first passage by one, flips train parity, and gives raw Hamming distance t at tick t",
    }


def zero_state_routing_response(kernel, result: dict) -> dict:
    """Contrast empty, normal latent-router, and fixed-observer worlds.

    All three have identical conventional state>0 occupancy at t=0.  Direction
    bits nevertheless make the latter two causal sources because the DEMUX
    source scan does not test state; semantic=4 additionally fixes the source.
    """
    q = (6, 6, 6)
    sreg = 9
    horizon = 3
    cases = []
    for d in REPRESENTATIVE_DIRECTIONS:
        empty_initial = np.zeros(N**3, dtype=np.uint64)
        normal_initial = one_raw(q, pack(0, sreg, d, 1))
        observer_word = pack(0, sreg, d, 4)
        observer_initial = one_raw(q, observer_word)
        record_check(
            result,
            not active_support(empty_initial)
            and not active_support(normal_initial)
            and not active_support(observer_initial),
            "zero_state_routing",
            f"{d}:identical_empty_occupancy_t0",
        )
        empty = Simulation(kernel, empty_initial)
        normal = Simulation(kernel, normal_initial)
        observer = Simulation(kernel, observer_initial)
        trace = []
        for t in range(1, horizon + 1):
            info_empty = empty.step()
            info_normal = normal.step()
            info_observer = observer.step()
            result["kernel_ticks"] += 3
            expected_empty = np.zeros(N**3, dtype=np.uint64)
            expected_normal = expected_singleton(q, d, sreg, t)
            expected_observer = observer_expected(q, d, observer_word, sreg, t)
            record_check(result, np.array_equal(empty.raw_a, expected_empty), "zero_state_routing", f"{d}:empty:t{t}")
            record_check(result, np.array_equal(normal.raw_a, expected_normal), "zero_state_routing", f"{d}:normal:t{t}")
            record_check(result, np.array_equal(observer.raw_a, expected_observer), "zero_state_routing", f"{d}:observer:t{t}")
            record_check(
                result,
                info_empty["buffers_equal"] and info_normal["buffers_equal"] and info_observer["buffers_equal"],
                "copyback",
                f"zero_state_routing:{d}:t{t}",
            )
            trace.append(
                {
                    "tick": t,
                    "empty_active_support": active_support(empty.raw_a),
                    "normal_active_support": active_support(normal.raw_a),
                    "observer_active_support": active_support(observer.raw_a),
                    "empty_raw_support": support(empty.raw_a),
                    "normal_raw_support": support(normal.raw_a),
                    "observer_raw_support": support(observer.raw_a),
                    "empty_hash": sha256_array(empty.raw_a),
                    "normal_hash": sha256_array(normal.raw_a),
                    "observer_hash": sha256_array(observer.raw_a),
                }
            )
        cases.append(
            {
                "direction": list(d),
                "s_reg": sreg,
                "initial_state_occupancy_equal_and_empty": True,
                "normal_transition": "state0 directional normal source clears and creates one state1 normal carrier at q+d",
                "observer_transition": "state0 directional observer persists at q and starts the parity pump",
                "trace": trace,
            }
        )
    return {
        "N": N,
        "horizon": horizon,
        "cases": cases,
        "compact_rule": {
            "proposal_support": "p_d(x)=1 when raw direction d is nonzero, independently of state>0 occupancy",
            "normal_state0": "L(x,d,s)->C(x+d,d,s) in one tick; source L is cleared",
            "observer_state0": "O(x,d,s)->O(x,d,s) plus a guarded proposal toward x+d",
            "empty": "remains empty",
        },
        "causal_sufficiency_result": "state>0 occupancy is not sufficient; encoded-raw presence, proposal support, and semantic kind must be retained; target blocking is state/semantic dependent",
    }


def collision_raw(kernel, directions, charges, q) -> tuple[np.ndarray, dict]:
    raw = np.zeros(N**3, dtype=np.uint64)
    for d, sreg in zip(directions, charges, strict=True):
        raw[index(add(q, d, -1))] = pack(1, sreg, d, 1)
    sim = Simulation(kernel, raw)
    info = sim.step()
    return sim.raw_a.copy(), info


def collision_response(kernel, result: dict) -> dict:
    q = (6, 6, 6)
    inverse: dict[tuple[int, int, int], list[tuple[tuple[int, int, int], tuple[int, int, int]]]] = defaultdict(list)
    for pair in itertools.combinations(DIRECTIONS, 2):
        inverse[sign_sum(pair)].append(pair)
    multiplicities = {str(k): len(v) for k, v in sorted(inverse.items())}
    record_check(result, sum(map(len, inverse.values())) == 325, "collision_inverse", "all_pairs")
    record_check(result, len(inverse) == 27, "collision_inverse", "all_outputs")
    record_check(result, len(inverse[(0, 0, 0)]) == 13, "collision_inverse", "zero")
    for d in DIRECTIONS:
        record_check(result, len(inverse[d]) == 12, "collision_inverse", f"nonzero:{d}")

    representatives = []
    for output_d, pairs in sorted(inverse.items()):
        pair = pairs[0]
        actual, info = collision_raw(kernel, pair, (7, 11), q)
        result["kernel_ticks"] += 1
        expected = one_raw(q, pack(1, 18, output_d, 1))
        record_check(result, np.array_equal(actual, expected), "collision_representative", str(output_d))
        record_check(result, info["buffers_equal"], "copyback", f"collision:{output_d}")
        representatives.append(
            {
                "output_direction": list(output_d),
                "representative_input_pair": [list(pair[0]), list(pair[1])],
                "preimage_pair_count": len(pairs),
                "actual": unpack(actual[index(q)]),
                "raw_hash": sha256_array(actual),
            }
        )

    d1, d2, d3 = (1, 0, 0), (1, 1, 0), (-1, 0, 0)
    simultaneous, info_sim = collision_raw(kernel, (d1, d2, d3), (2, 3, 5), q)
    result["kernel_ticks"] += 1
    simultaneous_direction = sign_sum((d1, d2, d3))
    record_check(result, simultaneous[index(q)] == pack(1, 10, simultaneous_direction, 1), "collision_composition", "simultaneous")
    record_check(result, info_sim["buffers_equal"], "copyback", "collision:simultaneous")

    d12 = sign_sum((d1, d2))
    q1 = add(q, d12)
    staged_initial = np.zeros(N**3, dtype=np.uint64)
    staged_initial[index(add(q, d1, -1))] = pack(1, 2, d1, 1)
    staged_initial[index(add(q, d2, -1))] = pack(1, 3, d2, 1)
    staged_initial[index(add(q1, d3, -2))] = pack(1, 5, d3, 1)
    staged = Simulation(kernel, staged_initial)
    info_stage_1 = staged.step()
    result["kernel_ticks"] += 1
    expected_stage_1 = np.zeros(N**3, dtype=np.uint64)
    expected_stage_1[index(q)] = pack(1, 5, d12, 1)
    expected_stage_1[index(add(q1, d3, -1))] = pack(1, 5, d3, 1)
    record_check(result, np.array_equal(staged.raw_a, expected_stage_1), "collision_composition", "staged_tick_1")
    info_stage_2 = staged.step()
    result["kernel_ticks"] += 1
    sequential_direction = sign_sum((d12, d3))
    expected_stage_2 = one_raw(q1, pack(1, 10, sequential_direction, 1))
    record_check(result, np.array_equal(staged.raw_a, expected_stage_2), "collision_composition", "staged_tick_2")
    record_check(result, info_stage_1["buffers_equal"] and info_stage_2["buffers_equal"], "copyback", "collision:staged")
    record_check(result, simultaneous_direction != sequential_direction, "collision_composition", "nonassociative_direction")

    susceptibility = []
    for regime, base_loads, perturbed_loads, expected_delta in (
        ("below_cap", (100, 200), (100, 201), 1),
        ("at_cap", (19664, 1), (19664, 2), 0),
    ):
        pair = ((1, 0, 0), (-1, 1, 0))
        base, _ = collision_raw(kernel, pair, base_loads, q)
        perturbed, _ = collision_raw(kernel, pair, perturbed_loads, q)
        result["kernel_ticks"] += 2
        base_s = unpack(base[index(q)])["s_reg"]
        perturbed_s = unpack(perturbed[index(q)])["s_reg"]
        delta = perturbed_s - base_s
        record_check(result, delta == expected_delta, "charge_susceptibility", regime, {"actual": delta, "expected": expected_delta})
        susceptibility.append(
            {
                "regime": regime,
                "base_loads": list(base_loads),
                "perturbed_loads": list(perturbed_loads),
                "base_output_s_reg": base_s,
                "perturbed_output_s_reg": perturbed_s,
                "finite_difference": delta,
            }
        )

    return {
        "unordered_input_pairs": 325,
        "output_directions_including_zero": 27,
        "inverse_multiplicities": multiplicities,
        "inverse_summary": "every nonzero output direction has 12 unordered direction-pair preimages; zero has 13",
        "representative_binary_checks": representatives,
        "composition": {
            "input_direction_multiset": [list(d1), list(d2), list(d3)],
            "charges": [2, 3, 5],
            "simultaneous_output_direction": list(simultaneous_direction),
            "simultaneous_output_raw": unpack(simultaneous[index(q)]),
            "staged_binary_output_direction": list(sequential_direction),
            "staged_binary_output_raw": unpack(staged.raw_a[index(q1)]),
            "same_direction_multiset_different_scheduling": True,
            "binary_sign_reduction_associative": False,
        },
        "charge_susceptibility": susceptibility,
    }


def main() -> int:
    started = datetime.now(timezone.utc).isoformat()
    identity = {
        "wheel": sha256_file(WHEEL),
        "kernel": sha256_file(KERNEL_FILE),
        "source": sha256_file(SOURCE_FILE),
        "runner": sha256_file(HERE),
    }
    for key, expected in EXPECTED.items():
        if identity[key] != expected:
            raise RuntimeError(f"identity mismatch for {key}: {identity[key]} != {expected}")

    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(kernel.__file__).resolve() != KERNEL_FILE.resolve():
        raise RuntimeError(f"unexpected kernel import: {kernel.__file__}")

    result = {
        "schema": "dee.rosetta.response.discovery.v1",
        "mode": "DISCOVERY_ONLY",
        "holdout_executed": False,
        "contract_frozen": False,
        "started_utc": started,
        "runtime": {
            "executable": sys.executable,
            "python": sys.version,
            "architecture": platform.architecture()[0],
            "numpy": np.__version__,
            "package": str(Path(package.__file__).resolve()),
            "kernel": str(Path(kernel.__file__).resolve()),
            "kernel_version": str(kernel.VERSION),
        },
        "identity": identity,
        "check_count": 0,
        "kernel_ticks": 0,
        "mismatches": [],
    }
    result["geometry_free"] = geometry_and_free_response(kernel, result)
    result["observer_phase"] = observer_phase_response(kernel, result)
    result["zero_state_routing"] = zero_state_routing_response(kernel, result)
    result["collision"] = collision_response(kernel, result)
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    result["verdict"] = "DISCOVERY_PASS" if not result["mismatches"] else "DISCOVERY_MISMATCH"

    OUTDIR.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(
        json.dumps(
            {
                "verdict": result["verdict"],
                "checks": result["check_count"],
                "kernel_ticks": result["kernel_ticks"],
                "mismatches": len(result["mismatches"]),
                "output": str(OUTPUT),
            },
            indent=2,
        )
    )
    return 0 if not result["mismatches"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
