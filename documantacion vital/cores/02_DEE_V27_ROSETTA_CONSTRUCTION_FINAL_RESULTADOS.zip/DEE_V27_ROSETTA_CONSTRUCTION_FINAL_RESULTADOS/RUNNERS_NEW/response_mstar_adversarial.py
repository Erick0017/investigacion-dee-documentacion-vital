#!/usr/bin/env python3
"""Pre-freeze adversarial discovery probes for M* = z=(q,d,s,a,p).

This is not a holdout and freezes no contract. It writes only a discovery JSON
under the new ROSETTA_CLOSURE subtree and reads the accepted V1 binary payload
without modifying any upstream artifact.
"""
from __future__ import annotations

import hashlib
import importlib
import itertools
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROSETTA = HERE.parents[1]
V1 = ROSETTA.parent
TESTS = V1.parent
EXTRACTED = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKG = EXTRACTED / "dee_universe_v27"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_FILE = PKG / "dee_kernel_v27.cp313-win_amd64.pyd"
SOURCE_FILE = PKG / "dee_kernel_v27.cpp"
OUT = ROSETTA / "DISCOVERY" / "response_mstar_adversarial_results.json"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "source": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
}
N = 13
Q = (6, 6, 6)
D0 = (0, 0, 0)
DX = (1, 0, 0)
DY = (0, 1, 0)
GENERIC_SEMANTICS = (0, 1, 2, 3, 6, 7, 8, 15)
TET_PATTERNS = (
    ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)),
    ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1)),
    ((1, 0, 0), (0, -1, 0), (0, 0, 1), (1, -1, 1)),
    ((1, 0, 0), (0, 1, 0), (0, 0, -1), (1, 1, -1)),
    ((-1, 0, 0), (0, -1, 0), (0, 0, 1), (-1, -1, 1)),
    ((-1, 0, 0), (0, 1, 0), (0, 0, -1), (-1, 1, -1)),
    ((1, 0, 0), (0, -1, 0), (0, 0, -1), (1, -1, -1)),
    ((-1, 0, 0), (0, -1, 0), (0, 0, -1), (-1, -1, -1)),
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(a)).cast("B")).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 15) << 48)
        | ((d[1] & 15) << 52)
        | ((d[2] & 15) << 56)
        | ((semantic & 15) << 60)
    )


def unpack(raw: int | np.uint64) -> dict[str, int | list[int]]:
    value = int(raw)

    def nibble(shift: int) -> int:
        x = (value >> shift) & 15
        return x - 16 if x & 8 else x

    return {
        "raw": value,
        "state": value & 0xFFFFFFFF,
        "s_reg": (value >> 32) & 0xFFFF,
        "direction": [nibble(48), nibble(52), nibble(56)],
        "semantic": (value >> 60) & 15,
    }


def index(q: tuple[int, int, int], n: int = N) -> int:
    return (q[0] * n + q[1]) * n + q[2]


def add(q: tuple[int, int, int], d: tuple[int, int, int], k: int = 1, n: int = N) -> tuple[int, int, int]:
    return tuple((q[a] + k * d[a]) % n for a in range(3))


def empty() -> np.ndarray:
    return np.zeros(N**3, dtype=np.uint64)


def put(raw: np.ndarray, q: tuple[int, int, int], word: np.uint64) -> None:
    raw[index(q)] = word


def z_projection(raw: np.ndarray) -> list[dict]:
    """The proposed quotient: all non-observer semantics collapse into p=0."""
    records = []
    for flat in np.flatnonzero(raw != 0):
        u = unpack(raw[flat])
        q = np.unravel_index(int(flat), (N, N, N))
        records.append(
            {
                "q": [int(x) for x in q],
                "d": u["direction"],
                "s": u["s_reg"],
                "a": int(int(u["state"]) > 0),
                "p": int(u["semantic"] == 4),
            }
        )
    return records


def support(raw: np.ndarray) -> list[list[int]]:
    return [
        [int(x) for x in q]
        for q in np.argwhere(raw.reshape(N, N, N) != 0)
    ]


class Sim:
    def __init__(self, kernel, raw: np.ndarray) -> None:
        self.a = np.ascontiguousarray(raw, dtype=np.uint64).copy()
        self.b = np.zeros_like(self.a)
        self.ca = np.zeros_like(self.a)
        self.cb = np.zeros_like(self.a)
        self.kernel = kernel

    def step(self) -> dict:
        info = dict(self.kernel.tick_universo(self.a, self.b, self.ca, self.cb, N, 1))
        return {
            "copyback": bool(np.array_equal(self.a, self.b) and np.array_equal(self.ca, self.cb)),
            "info": {str(k): int(v) if isinstance(v, (int, np.integer)) else float(v) for k, v in info.items()},
        }


def check(result: dict, condition: bool, family: str, case: str, detail=None) -> None:
    result["checks"] += 1
    if not condition:
        result["mismatches"].append({"family": family, "case": case, "detail": detail})


def run_trace(kernel, raw: np.ndarray, ticks: int, result: dict) -> tuple[list[dict], np.ndarray]:
    sim = Sim(kernel, raw)
    trace = []
    for t in range(1, ticks + 1):
        meta = sim.step()
        result["kernel_ticks"] += 1
        check(result, meta["copyback"], "copyback", f"tick_{t}")
        trace.append(
            {
                "tick": t,
                "raw_sha256": sha256_array(sim.a),
                "support": support(sim.a),
                "z": z_projection(sim.a),
                "kernel_info": meta["info"],
            }
        )
    return trace, sim.a.copy()


def orphan_same_z_counterexample(kernel, result: dict) -> dict:
    offsets = (DX, (-1, 0, 0), DY, (0, -1, 0), (0, 0, 1), (0, 0, -1), (1, 1, 1), (-1, -1, -1))
    normal = empty()
    orphan = empty()
    for offset in offsets:
        put(normal, add(Q, offset), pack(1, 0, D0, 1))
        put(orphan, add(Q, offset), pack(1, 0, D0, 1))
    put(orphan, add(Q, DX), pack(1, 0, D0, 5))
    same_z = z_projection(normal) == z_projection(orphan)
    check(result, same_z, "orphan_split", "same_input_z")
    normal_trace, normal_out = run_trace(kernel, normal, 1, result)
    orphan_trace, orphan_out = run_trace(kernel, orphan, 1, result)
    center_normal = unpack(normal_out[index(Q)])
    center_orphan = unpack(orphan_out[index(Q)])
    split = z_projection(normal_out) != z_projection(orphan_out)
    check(result, center_normal["semantic"] == 7 and center_normal["state"] == 1, "orphan_split", "normal_xnor_birth", center_normal)
    check(result, center_orphan["raw"] == 0, "orphan_split", "orphan_suppresses_xnor", center_orphan)
    check(result, split, "orphan_split", "different_output_z")
    return {
        "same_input_z": same_z,
        "different_output_z": split,
        "changed_site": list(add(Q, DX)),
        "normal_semantic": 1,
        "orphan_semantic": 5,
        "center_normal": center_normal,
        "center_orphan": center_orphan,
        "normal_trace": normal_trace,
        "orphan_trace": orphan_trace,
        "conclusion": "p=observer alone is not globally lumpable; semantic=5 needs a flag or exclusion",
    }


def generic_semantic_lumping(kernel, result: dict) -> dict:
    contexts = {}

    latent_outputs = {}
    for sem in GENERIC_SEMANTICS:
        raw = empty()
        put(raw, Q, pack(0, 9, DX, sem))
        trace, _ = run_trace(kernel, raw, 2, result)
        latent_outputs[str(sem)] = trace
    ref = [row["z"] for row in latent_outputs["1"]]
    check(result, all([row["z"] for row in trace] == ref for trace in latent_outputs.values()), "generic_semantics", "latent_equal")
    contexts["latent_directional"] = latent_outputs

    blocker_outputs = {}
    for sem in GENERIC_SEMANTICS:
        raw = empty()
        put(raw, add(Q, DX, -1), pack(1, 3, DX, 1))
        put(raw, Q, pack(1, 17, D0, sem))
        trace, _ = run_trace(kernel, raw, 1, result)
        blocker_outputs[str(sem)] = trace
    ref = blocker_outputs["1"][0]["z"]
    check(result, all(trace[0]["z"] == ref for trace in blocker_outputs.values()), "generic_semantics", "blocker_equal")
    contexts["active_d0_blocker"] = blocker_outputs

    survivor_offsets = ((-1, -1, -1), (-1, -1, 0), (-1, -1, 1), (-1, 0, -1), (-1, 0, 0), (1, 0, 0))
    has_tetra = any(set(pattern).issubset(set(survivor_offsets)) for pattern in TET_PATTERNS)
    check(result, not has_tetra, "generic_semantics", "survivor_context_non_tetra")
    survivor_outputs = {}
    for sem in GENERIC_SEMANTICS:
        raw = empty()
        put(raw, Q, pack(1, 5, D0, sem))
        for offset in survivor_offsets:
            put(raw, add(Q, offset), pack(1, 0, D0, 1))
        trace, _ = run_trace(kernel, raw, 2, result)
        survivor_outputs[str(sem)] = trace
    ref = [row["z"] for row in survivor_outputs["1"]]
    check(result, all([row["z"] for row in trace] == ref for trace in survivor_outputs.values()), "generic_semantics", "survivor_projected_equal")
    contexts["surviving_material"] = survivor_outputs

    return {
        "semantics": list(GENERIC_SEMANTICS),
        "contexts": contexts,
        "all_projected_equal": True,
        "static_class": "all semantic nibbles except 4 and 5 are branch-equivalent after projection p",
    }


def state0_orphan_analysis(kernel, result: dict) -> dict:
    """Check whether the orphan distinction is needed when state is exactly zero."""
    directional = {}
    inert = {}
    for sem in (1, 5):
        raw = empty()
        put(raw, Q, pack(0, 9, DX, sem))
        trace, _ = run_trace(kernel, raw, 2, result)
        directional[str(sem)] = trace

        raw = empty()
        put(raw, Q, pack(0, 123, D0, sem))
        trace, _ = run_trace(kernel, raw, 1, result)
        inert[str(sem)] = trace

    directional_equal = [row["z"] for row in directional["1"]] == [row["z"] for row in directional["5"]]
    inert_equal = [row["z"] for row in inert["1"]] == [row["z"] for row in inert["5"]] == [[]]
    check(result, directional_equal, "state0_orphan", "directional_matches_normal")
    check(result, inert_equal, "state0_orphan", "d0_is_dynamically_null")
    return {
        "directional": directional,
        "inert_d0": inert,
        "directional_projected_equal": directional_equal,
        "inert_projected_equal": inert_equal,
        "conclusion": "semantic=5 needs distinguishing power only when state>0; at state=0 it routes like a generic raw and d=0 is inert (crystallization is statically unreachable)",
    }


def observer_state_analysis(kernel, result: dict) -> dict:
    d = (1, 1, 0)
    isolated = {}
    for state in (1, 2, 0xFFFFFFFF):
        raw = empty()
        put(raw, Q, pack(state, 7, d, 4))
        trace, _ = run_trace(kernel, raw, 3, result)
        isolated[str(state)] = trace
    ref = [row["z"] for row in isolated["1"]]
    positives_equal = all([row["z"] for row in trace] == ref for trace in isolated.values())
    check(result, positives_equal, "observer_state", "positive_magnitudes_equal")

    support_offsets = ((-1, -1, -1), (-1, -1, 0), (-1, -1, 1), (-1, 0, -1), (-1, 0, 0))
    threshold = {}
    for state in (0, 1, 2, 0xFFFFFFFF):
        raw = empty()
        put(raw, Q, pack(1, 0, D0, 1))
        for offset in support_offsets:
            put(raw, add(Q, offset), pack(1, 0, D0, 1))
        observer_q = add(Q, DX)
        put(raw, observer_q, pack(state, 7, D0, 4))
        trace, out = run_trace(kernel, raw, 1, result)
        threshold[str(state)] = {"trace": trace, "center": unpack(out[index(Q)])}
    check(result, threshold["0"]["center"]["state"] == 0, "observer_state", "state0_not_active_neighbor")
    check(result, all(threshold[str(s)]["center"]["state"] == 1 for s in (1, 2, 0xFFFFFFFF)), "observer_state", "positive_active_neighbor")
    pos_threshold_z = [threshold[str(s)]["trace"][0]["z"] for s in (1, 2, 0xFFFFFFFF)]
    check(result, pos_threshold_z[0] == pos_threshold_z[1] == pos_threshold_z[2], "observer_state", "threshold_positive_magnitudes_equal")
    return {
        "isolated_positive_states": isolated,
        "positive_magnitudes_projected_equal": positives_equal,
        "threshold_context": threshold,
        "conclusion": "positive state magnitude canonizes to 1 for z dynamics, but activity bit a cannot be dropped",
    }


def target_and_blocker_analysis(kernel, result: dict) -> dict:
    target_variants = {
        "raw_zero": None,
        "state0_sem1_s123": pack(0, 123, D0, 1),
        "state0_sem2_s123": pack(0, 123, D0, 2),
        "state0_sem5_s123": pack(0, 123, D0, 5),
        "state0_sem15_s123": pack(0, 123, D0, 15),
    }
    target_results = {}
    for name, target in target_variants.items():
        raw = empty()
        put(raw, add(Q, DX, -1), pack(1, 3, DX, 1))
        if target is not None:
            put(raw, Q, target)
        trace, out = run_trace(kernel, raw, 1, result)
        target_results[name] = {"trace": trace, "target": unpack(out[index(Q)])}
    target_z = [entry["trace"][0]["z"] for entry in target_results.values()]
    check(result, all(z == target_z[0] for z in target_z), "state0_target", "encoded_state0_accepts_like_zero")
    check(result, all(entry["target"]["s_reg"] == 3 and entry["target"]["direction"] == [1, 0, 0] for entry in target_results.values()), "state0_target", "incoming_source_overwrites")

    blocker_results = {}
    for state, sreg, sem in ((1, 0, 1), (2, 0, 1), (0xFFFFFFFF, 0, 1), (1, 123, 2), (1, 65535, 15)):
        name = f"state{state}_s{sreg}_sem{sem}"
        raw = empty()
        put(raw, add(Q, DX, -1), pack(1, 3, DX, 1))
        put(raw, Q, pack(state, sreg, D0, sem))
        trace, _ = run_trace(kernel, raw, 1, result)
        blocker_results[name] = trace
    blocker_z = [trace[0]["z"] for trace in blocker_results.values()]
    check(result, all(z == [] for z in blocker_z), "active_blocker", "all_die_and_block")

    return {
        "state0_target_variants": target_results,
        "active_d0_blocker_variants": blocker_results,
        "conclusion": "under the death/no-overflow guard, inert state0 d0 records can be dropped and active d0 blockers can canonicalize state magnitude, s_reg and generic semantic for their one-step blocking role",
    }


def source_destination_interaction(kernel, result: dict) -> dict:
    normal = empty()
    put(normal, add(Q, DX, -1), pack(1, 2, DX, 1))
    put(normal, Q, pack(0, 5, DY, 1))
    normal_trace, normal_out = run_trace(kernel, normal, 1, result)
    normal_expected = empty()
    put(normal_expected, Q, pack(1, 2, DX, 1))
    put(normal_expected, add(Q, DY), pack(1, 5, DY, 1))
    check(result, np.array_equal(normal_out, normal_expected), "source_destination", "latent_accepts_and_proposes")

    observer = empty()
    observer_word = pack(0, 5, DY, 4)
    put(observer, add(Q, DX, -1), pack(1, 2, DX, 1))
    put(observer, Q, observer_word)
    observer_trace, observer_out = run_trace(kernel, observer, 1, result)
    observer_expected = empty()
    put(observer_expected, Q, observer_word)
    put(observer_expected, add(Q, DY), pack(1, 5, DY, 1))
    check(result, np.array_equal(observer_out, observer_expected), "source_destination", "observer_blocks_and_proposes")
    return {
        "normal_state0_target": normal_trace,
        "observer_state0_target": observer_trace,
        "normal_output": z_projection(normal_out),
        "observer_output": z_projection(observer_out),
        "conclusion": "proposals are computed from the input slice: a latent target can accept one proposal while sending its own; an observer sends but its fixed-point return blocks the incoming proposal",
    }


def non_moore_direction_guard(kernel, result: dict) -> dict:
    cases = {}
    for state in (0, 1):
        raw = empty()
        put(raw, Q, pack(state, 9, (2, 0, 0), 1))
        trace, out = run_trace(kernel, raw, 1, result)
        cases[f"state{state}"] = trace
        check(result, not np.any(out), "direction_domain", f"non_moore_state{state}_does_not_route")
    raw = empty()
    put(raw, Q, pack(0, 9, DX, 1))
    moore_trace, moore_out = run_trace(kernel, raw, 1, result)
    check(result, unpack(moore_out[index(add(Q, DX))])["state"] == 1, "direction_domain", "moore_routes")
    return {
        "non_moore_direction": [2, 0, 0],
        "non_moore_cases": cases,
        "moore_control": moore_trace,
        "exact_static_predicate": "d!=0 and exists m in Moore with m+d == 0 (mod N); in the normalized d in Moore union {0} sector this is d in Moore",
        "conclusion": "at N=13, d=(2,0,0) is nonzero but proposal-disabled; d!=0 alone is insufficient",
    }


def main() -> int:
    identity = {
        "wheel": sha256_file(WHEEL),
        "kernel": sha256_file(KERNEL_FILE),
        "source": sha256_file(SOURCE_FILE),
        "runner": sha256_file(HERE),
    }
    for key, wanted in EXPECTED.items():
        if identity[key] != wanted:
            raise RuntimeError(f"identity mismatch {key}: {identity[key]} != {wanted}")
    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(kernel.__file__).resolve() != KERNEL_FILE.resolve():
        raise RuntimeError(f"wrong kernel import: {kernel.__file__}")

    result = {
        "schema": "dee.rosetta.mstar.adversarial.discovery.v1",
        "mode": "DISCOVERY_ONLY_PRE_FREEZE",
        "holdout_executed": False,
        "contract_frozen": False,
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "identity": identity,
        "runtime": {
            "python": sys.version,
            "executable": sys.executable,
            "architecture": platform.architecture()[0],
            "numpy": np.__version__,
            "package": str(Path(package.__file__).resolve()),
            "kernel": str(Path(kernel.__file__).resolve()),
            "kernel_version": str(kernel.VERSION),
        },
        "checks": 0,
        "kernel_ticks": 0,
        "mismatches": [],
    }
    result["orphan_same_z_counterexample"] = orphan_same_z_counterexample(kernel, result)
    result["generic_semantic_lumping"] = generic_semantic_lumping(kernel, result)
    result["state0_orphan"] = state0_orphan_analysis(kernel, result)
    result["observer_state"] = observer_state_analysis(kernel, result)
    result["targets_and_blockers"] = target_and_blocker_analysis(kernel, result)
    result["source_destination"] = source_destination_interaction(kernel, result)
    result["direction_domain"] = non_moore_direction_guard(kernel, result)
    result["finished_utc"] = datetime.now(timezone.utc).isoformat()
    result["verdict"] = "ADVERSARIAL_DISCOVERY_PASS" if not result["mismatches"] else "ADVERSARIAL_DISCOVERY_MISMATCH"
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"verdict": result["verdict"], "checks": result["checks"], "kernel_ticks": result["kernel_ticks"], "mismatches": len(result["mismatches"]), "output": str(OUT)}, indent=2))
    return 0 if not result["mismatches"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
