#!/usr/bin/env python3
"""Execute the sealed T10 Rosetta-core holdout without refitting.

Normative inputs (read-only):
  HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json
  HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md

The implementation deliberately keeps both frozen clauses literally:
M_* canonicalizes s=0 on active non-observer d=0 records, while G_* assigns
the stated capped s_out to every multi-source output, including d_out=0.
That pre-existing specification conflict is reported rather than repaired.
"""
from __future__ import annotations

import csv
import hashlib
import importlib
import itertools
import json
import platform
import sys
import traceback
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np


HERE = Path(__file__).resolve()
ROSETTA = HERE.parents[1]
V1 = ROSETTA.parent
TESTS = V1.parent
HOLDOUTS = ROSETTA / "HOLDOUTS"
CONTRACT = HOLDOUTS / "ROSETTA_FROZEN_CONTRACT.json"
PREREG = HOLDOUTS / "PREREGISTER_T10_ROSETTA_CORE.md"
EXTRACTED = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKG = EXTRACTED / "dee_universe_v27"
KERNEL_FILE = PKG / "dee_kernel_v27.cp313-win_amd64.pyd"
SOURCE_FILE = PKG / "dee_kernel_v27.cpp"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
OUTDIR = ROSETTA / "RESULTS" / "t10_rosetta_core"
RESULT_JSON = OUTDIR / "t10_result.json"
CASES_CSV = OUTDIR / "t10_cases.csv"
MISMATCHES_CSV = OUTDIR / "t10_mismatches.csv"
MANIFEST = OUTDIR / "t10_SHA256SUMS.txt"

EXPECTED = {
    "contract": "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157",
    "preregister": "2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f",
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel_pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "kernel_cpp": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
}
SEED = 271017031
UINT64_MAX = (1 << 64) - 1
STATE_MAX_TEST = 4_294_967_279
CAP = 19_664
D0 = (0, 0, 0)
D26 = tuple(d for d in itertools.product((-1, 0, 1), repeat=3) if d != D0)
D26_SET = frozenset(D26)
D8 = tuple(itertools.product((-1, 1), repeat=3))
REP_DIRS = ((1, 0, 0), (1, 1, 0), (1, 1, 1))
OBSERVER_DIRS = ((1, 0, 0), (1, 1, 0), (1, 1, 1), (-1, 1, -1))
CLOCK_MODES = ("heterogeneous", "near_wrap")
COMPOSITION_PAIRS = ((1, 1), (1, 3), (2, 2))

CASE_FIELDS = (
    "run_role", "panel", "case_id", "engine", "threads", "N",
    "input_slice_tick", "scored_tick", "domain_ok", "domain_N_ok",
    "domain_directions_ok", "domain_positive_sites_ok",
    "domain_neighbour_cap_ok", "positive_sites",
    "positive_nonobserver_sites", "max_positive_moore_neighbours",
    "input_alignment", "closure_equal", "input_records",
    "predicted_records", "actual_records", "input_projection_sha256",
    "predicted_projection_sha256", "actual_projection_sha256",
    "raw_after_sha256", "clock_after_sha256", "copyback",
    "overflows", "genesis", "lazy_evaluated",
)
MISMATCH_FIELDS = (
    "category", "panel", "case_id", "tick", "expected", "actual", "detail",
)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(array)).cast("B")).hexdigest()


def stable_hash(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 0xF) << 48)
        | ((d[1] & 0xF) << 52)
        | ((d[2] & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def decode(raw: int | np.uint64) -> tuple[int, int, tuple[int, int, int], int]:
    value = int(raw)

    def signed_nibble(shift: int) -> int:
        nibble = (value >> shift) & 0xF
        return nibble - 16 if nibble & 8 else nibble

    return (
        value & 0xFFFFFFFF,
        (value >> 32) & 0xFFFF,
        (signed_nibble(48), signed_nibble(52), signed_nibble(56)),
        (value >> 60) & 0xF,
    )


def flat_index(q: tuple[int, int, int], n: int) -> int:
    return (q[0] * n + q[1]) * n + q[2]


def add(q: tuple[int, int, int], d: tuple[int, int, int], n: int, scale: int = 1) -> tuple[int, int, int]:
    return tuple((q[axis] + scale * d[axis]) % n for axis in range(3))


def empty_grid(n: int) -> np.ndarray:
    return np.zeros(n**3, dtype=np.uint64)


def put(grid: np.ndarray, q: tuple[int, int, int], word: np.uint64, n: int) -> None:
    grid[flat_index(q, n)] = word


def derived_seed(label: str) -> int:
    digest = hashlib.sha256(f"{SEED}|{label}".encode("utf-8")).digest()
    return int.from_bytes(digest[:16], "little")


def origin_for(n: int, label: str) -> tuple[int, int, int]:
    digest = hashlib.sha256(f"{SEED}|origin|{label}".encode("utf-8")).digest()
    return tuple(int.from_bytes(digest[8 * axis:8 * axis + 8], "little") % n for axis in range(3))


def clock_pattern(n: int, mode: str, label: str) -> np.ndarray:
    rng = np.random.Generator(np.random.PCG64(derived_seed(f"clock|{label}|{mode}")))
    if mode == "heterogeneous":
        return np.asarray(rng.bit_generator.random_raw(n**3), dtype=np.uint64)
    if mode == "near_wrap":
        offsets = rng.integers(0, 32, size=n**3, dtype=np.uint64)
        return np.uint64(UINT64_MAX) - offsets
    raise ValueError(f"unknown clock mode: {mode}")


# A canonical record is (qx,qy,qz,dx,dy,dz,s,a,p).
Record = tuple[int, int, int, int, int, int, int, int, int]


def make_record(q: tuple[int, int, int], d: tuple[int, int, int], s: int, a: int, p: int) -> Record:
    return (q[0], q[1], q[2], d[0], d[1], d[2], int(s), int(a), int(p))


def record_q(record: Record) -> tuple[int, int, int]:
    return record[0:3]


def record_d(record: Record) -> tuple[int, int, int]:
    return record[3:6]


def records_json(records: Iterable[Record]) -> list[list[int]]:
    return [list(record) for record in sorted(records)]


def project_m(grid: np.ndarray, n: int) -> tuple[Record, ...]:
    records: list[Record] = []
    for idx in np.flatnonzero(grid != 0):
        state, sreg, d, semantic = decode(grid[int(idx)])
        if not (state > 0 or d in D26_SET or semantic == 4):
            continue
        q_array = np.unravel_index(int(idx), (n, n, n))
        q = tuple(int(x) for x in q_array)
        a = int(state > 0)
        p = int(semantic == 4)
        # Literal frozen M_* clause.
        if p == 0 and a == 1 and d == D0:
            sreg = 0
        records.append(make_record(q, d, sreg, a, p))
    return tuple(sorted(records))


def g_star_literal(records: tuple[Record, ...], n: int) -> tuple[Record, ...]:
    """Literal frozen G_*; intentionally does not repair its d_out=0 conflict."""
    by_q = {record_q(record): record for record in records}
    output: dict[tuple[int, int, int], Record] = {}
    proposals: dict[tuple[int, int, int], list[tuple[tuple[int, int, int], int]]] = defaultdict(list)

    for record in records:
        q = record_q(record)
        d = record_d(record)
        s, _a, p = record[6], record[7], record[8]
        if p == 1:
            output[q] = record
        if d in D26_SET:
            proposals[add(q, d, n)].append((d, s))

    for target, incoming in proposals.items():
        prior = by_q.get(target)
        closed = prior is not None and (prior[7] == 1 or prior[8] == 1)
        if closed:
            continue
        if len(incoming) == 1:
            d_out, s_out = incoming[0]
        else:
            sums = tuple(sum(item[0][axis] for item in incoming) for axis in range(3))
            d_out = tuple(1 if value > 0 else (-1 if value < 0 else 0) for value in sums)
            s_out = min(sum(item[1] for item in incoming), CAP)
        # Literal G_* says s_out for every multi-source output.  In particular,
        # do not force s_out=0 when d_out=0: doing so would refit the sealed text.
        output[target] = make_record(target, d_out, s_out, 1, 0)
    return tuple(sorted(output.values()))


def domain_check(grid: np.ndarray, n: int) -> dict[str, Any]:
    nonzero: dict[tuple[int, int, int], tuple[int, int, tuple[int, int, int], int]] = {}
    positive: set[tuple[int, int, int]] = set()
    directions_ok = True
    for idx in np.flatnonzero(grid != 0):
        decoded = decode(grid[int(idx)])
        q_array = np.unravel_index(int(idx), (n, n, n))
        q = tuple(int(x) for x in q_array)
        nonzero[q] = decoded
        state, _s, d, _semantic = decoded
        directions_ok = directions_ok and (d == D0 or d in D26_SET)
        if state > 0:
            positive.add(q)

    neighbour_counts: list[int] = []
    for q in positive:
        semantic = nonzero[q][3]
        if semantic == 4:
            continue
        count = sum(1 for d in D26 if add(q, d, n) in positive)
        neighbour_counts.append(count)
    max_neighbours = max(neighbour_counts, default=0)
    checks = {
        "N_ok": n >= 5,
        "directions_ok": directions_ok,
        "positive_sites_ok": len(positive) <= 7,
        "neighbour_cap_ok": max_neighbours <= 3,
        "nonobserver_semantics_identified": True,
    }
    return {
        **checks,
        "ok": all(checks.values()),
        "positive_sites": len(positive),
        "positive_nonobserver_sites": len(neighbour_counts),
        "max_positive_moore_neighbours": max_neighbours,
        "nonzero_raw_sites": len(nonzero),
    }


class Simulator:
    def __init__(self, kernel: Any, grid: np.ndarray, clocks: np.ndarray, n: int, engine: str, threads: int) -> None:
        self.grid_a = np.ascontiguousarray(grid, dtype=np.uint64).copy()
        self.grid_b = np.zeros_like(self.grid_a)
        self.clock_a = np.ascontiguousarray(clocks, dtype=np.uint64).copy()
        self.clock_b = np.zeros_like(self.clock_a)
        self.n = n
        self.engine = engine
        self.threads = threads
        self.kernel = kernel

    def step(self) -> dict[str, Any]:
        if self.engine == "lazy":
            info = dict(self.kernel.tick_universo_lazy(
                self.grid_a, self.grid_b, self.clock_a, self.clock_b, self.n, self.threads
            ))
        elif self.engine == "dense":
            info = dict(self.kernel.tick_universo(
                self.grid_a, self.grid_b, self.clock_a, self.clock_b, self.n, self.threads
            ))
        else:
            raise ValueError(f"unknown engine: {self.engine}")
        return {
            "copyback": bool(
                np.array_equal(self.grid_a, self.grid_b)
                and np.array_equal(self.clock_a, self.clock_b)
            ),
            "info": {str(key): int(value) if isinstance(value, (int, np.integer)) else float(value)
                     for key, value in info.items()},
        }


class Context:
    def __init__(self) -> None:
        self.case_rows: list[dict[str, Any]] = []
        self.mismatches: list[dict[str, Any]] = []
        self.assertions = 0
        self.domain_checks = 0
        self.domain_failures = 0
        self.kernel_ticks = 0
        self.primary_trajectories = Counter()
        self.primary_ticks = Counter()
        self.composition_checks = 0
        self.engine_comparisons = 0

    def check(
        self,
        condition: bool,
        category: str,
        panel: str,
        case_id: str,
        tick: int | str,
        expected: Any,
        actual: Any,
        detail: Any = "",
    ) -> bool:
        self.assertions += 1
        if not condition:
            self.mismatches.append({
                "category": category,
                "panel": panel,
                "case_id": case_id,
                "tick": tick,
                "expected": expected,
                "actual": actual,
                "detail": detail,
            })
        return condition


def run_case(
    ctx: Context,
    kernel: Any,
    *,
    case_id: str,
    panel: str,
    role: str,
    n: int,
    grid: np.ndarray,
    clocks: np.ndarray,
    horizon: int,
    engine: str = "lazy",
    threads: int = 1,
    keep_snapshots: bool = False,
) -> dict[str, Any]:
    sim = Simulator(kernel, grid, clocks, n, engine, threads)
    model = project_m(sim.grid_a, n)
    trace: list[dict[str, Any]] = []
    if role == "primary":
        ctx.primary_trajectories[panel] += 1

    for tick in range(1, horizon + 1):
        domain = domain_check(sim.grid_a, n)
        ctx.domain_checks += 1
        if not domain["ok"]:
            ctx.domain_failures += 1
            ctx.check(False, "DOMAIN_FAILURE", panel, case_id, tick - 1, True, False, domain)

        actual_input = project_m(sim.grid_a, n)
        input_alignment = actual_input == model
        ctx.check(
            input_alignment,
            "ITERATED_INPUT_ALIGNMENT",
            panel,
            case_id,
            tick - 1,
            stable_hash(records_json(model)),
            stable_hash(records_json(actual_input)),
            "G_* iterate versus M_* of the current binary input slice",
        )
        predicted = g_star_literal(model, n)
        meta = sim.step()
        ctx.kernel_ticks += 1
        actual = project_m(sim.grid_a, n)
        closure_equal = predicted == actual
        ctx.check(
            closure_equal,
            "PROJECTED_CLOSURE",
            panel,
            case_id,
            tick,
            records_json(predicted),
            records_json(actual),
            "literal M_*(F_DEE X) == G_*(M_* X)",
        )
        ctx.check(meta["copyback"], "ENGINE_COPYBACK", panel, case_id, tick, True, meta["copyback"])
        overflows = int(meta["info"].get("overflows", 0))
        genesis = int(meta["info"].get("genesis", 0))
        ctx.check(overflows == 0, "UNEXPECTED_OVERFLOW", panel, case_id, tick, 0, overflows)
        ctx.check(genesis == 0, "UNEXPECTED_GENESIS", panel, case_id, tick, 0, genesis)

        row = {
            "run_role": role,
            "panel": panel,
            "case_id": case_id,
            "engine": engine,
            "threads": threads,
            "N": n,
            "input_slice_tick": tick - 1,
            "scored_tick": tick,
            "domain_ok": domain["ok"],
            "domain_N_ok": domain["N_ok"],
            "domain_directions_ok": domain["directions_ok"],
            "domain_positive_sites_ok": domain["positive_sites_ok"],
            "domain_neighbour_cap_ok": domain["neighbour_cap_ok"],
            "positive_sites": domain["positive_sites"],
            "positive_nonobserver_sites": domain["positive_nonobserver_sites"],
            "max_positive_moore_neighbours": domain["max_positive_moore_neighbours"],
            "input_alignment": input_alignment,
            "closure_equal": closure_equal,
            "input_records": len(actual_input),
            "predicted_records": len(predicted),
            "actual_records": len(actual),
            "input_projection_sha256": stable_hash(records_json(actual_input)),
            "predicted_projection_sha256": stable_hash(records_json(predicted)),
            "actual_projection_sha256": stable_hash(records_json(actual)),
            "raw_after_sha256": sha256_array(sim.grid_a),
            "clock_after_sha256": sha256_array(sim.clock_a),
            "copyback": meta["copyback"],
            "overflows": overflows,
            "genesis": genesis,
            "lazy_evaluated": meta["info"].get("lazy_evaluated", ""),
        }
        ctx.case_rows.append(row)
        if role == "primary":
            ctx.primary_ticks[panel] += 1
        trace_entry = {
            "tick": tick,
            "domain": domain,
            "model_input": model,
            "binary_input": actual_input,
            "predicted": predicted,
            "actual": actual,
            "raw_sha256": row["raw_after_sha256"],
            "clock_sha256": row["clock_after_sha256"],
        }
        if keep_snapshots:
            trace_entry["raw_snapshot"] = sim.grid_a.copy()
            trace_entry["clock_snapshot"] = sim.clock_a.copy()
        trace.append(trace_entry)
        model = predicted
    return {"trace": trace, "final_grid": sim.grid_a.copy(), "final_clock": sim.clock_a.copy()}


def kfree_advance(records: tuple[Record, ...], steps: int, n: int) -> tuple[Record, ...]:
    return tuple(sorted(
        make_record(add(record_q(record), record_d(record), n, steps), record_d(record), record[6], record[7], record[8])
        for record in records
    ))


def run_panel_a(ctx: Context, kernel: Any) -> None:
    n = 17
    for d in D26:
        for sreg in (0, 37, 19_663, 65_535):
            for state in (0, 7, STATE_MAX_TEST):
                base = f"A|d={d}|s={sreg}|state={state}"
                q = origin_for(n, base)
                for clock_mode in CLOCK_MODES:
                    case_id = f"{base}|clock={clock_mode}"
                    grid = empty_grid(n)
                    put(grid, q, pack(state, sreg, d, 1), n)
                    result = run_case(
                        ctx, kernel, case_id=case_id, panel="A", role="primary", n=n,
                        grid=grid, clocks=clock_pattern(n, clock_mode, base), horizon=5,
                    )
                    actual_trace = [entry["actual"] for entry in result["trace"]]
                    for t, u in COMPOSITION_PAIRS:
                        ctx.composition_checks += 1
                        expected = kfree_advance(actual_trace[t - 1], u, n)
                        actual = actual_trace[t + u - 1]
                        ctx.check(
                            expected == actual,
                            "K_FREE_COMPOSITION",
                            "A",
                            case_id,
                            f"{t}+{u}",
                            records_json(expected),
                            records_json(actual),
                        )


def run_panel_b(ctx: Context, kernel: Any) -> None:
    n = 17
    for pair_index, (d1, d2) in enumerate(itertools.combinations(D8, 2)):
        for state1, state2 in ((0, 0), (0, 11), (11, 0), (11, 23)):
            for s1, s2 in ((0, 37), (1, 19_663), (19_664, 65_535)):
                base = (
                    f"B|pair={pair_index}|d1={d1}|d2={d2}|states={state1},{state2}"
                    f"|loads={s1},{s2}"
                )
                target = origin_for(n, base)
                for clock_mode in CLOCK_MODES:
                    case_id = f"{base}|clock={clock_mode}"
                    grid = empty_grid(n)
                    put(grid, add(target, d1, n, -1), pack(state1, s1, d1, 1), n)
                    put(grid, add(target, d2, n, -1), pack(state2, s2, d2, 1), n)
                    run_case(
                        ctx, kernel, case_id=case_id, panel="B", role="primary", n=n,
                        grid=grid, clocks=clock_pattern(n, clock_mode, base), horizon=3,
                    )


def run_panel_c(ctx: Context, kernel: Any) -> None:
    n = 17
    for d in OBSERVER_DIRS:
        for sreg in (37, 19_663):
            for state in (0, 9, STATE_MAX_TEST):
                base = f"C|d={d}|s={sreg}|state={state}"
                q = origin_for(n, base)
                for clock_mode in CLOCK_MODES:
                    case_id = f"{base}|clock={clock_mode}"
                    grid = empty_grid(n)
                    put(grid, q, pack(state, sreg, d, 4), n)
                    run_case(
                        ctx, kernel, case_id=case_id, panel="C", role="primary", n=n,
                        grid=grid, clocks=clock_pattern(n, clock_mode, base), horizon=7,
                    )


def run_panel_d(ctx: Context, kernel: Any) -> None:
    n = 17
    for d in REP_DIRS:
        for target_kind in ("canonical_empty_raw", "active_d0_blocker", "state0_observer"):
            base = f"D|d={d}|target={target_kind}"
            target = origin_for(n, base)
            grid = empty_grid(n)
            put(grid, add(target, d, n, -1), pack(0, 37, d, 1), n)
            if target_kind == "canonical_empty_raw":
                put(grid, target, pack(0, 123, D0, 14), n)
            elif target_kind == "active_d0_blocker":
                put(grid, target, pack(17, 65_535, D0, 14), n)
            else:
                put(grid, target, pack(0, 123, D0, 4), n)
            run_case(
                ctx, kernel, case_id=base, panel="D", role="primary", n=n,
                grid=grid, clocks=clock_pattern(n, "heterogeneous", base), horizon=2,
            )


def run_panel_e(ctx: Context, kernel: Any) -> None:
    n = 17
    for d in REP_DIRS:
        for semantic in (3, 5, 14):
            for state in (0, 17):
                base = f"E|d={d}|semantic={semantic}|state={state}"
                q = origin_for(n, base)
                for clock_mode in CLOCK_MODES:
                    case_id = f"{base}|clock={clock_mode}"
                    grid = empty_grid(n)
                    put(grid, q, pack(state, 37, d, semantic), n)
                    run_case(
                        ctx, kernel, case_id=case_id, panel="E", role="primary", n=n,
                        grid=grid, clocks=clock_pattern(n, clock_mode, base), horizon=3,
                    )


def translate_records(records: tuple[Record, ...], delta: tuple[int, int, int], n: int) -> tuple[Record, ...]:
    return tuple(sorted(
        make_record(add(record_q(record), delta, n), record_d(record), record[6], record[7], record[8])
        for record in records
    ))


def translated_array(array: np.ndarray, delta: tuple[int, int, int], n: int) -> np.ndarray:
    shaped = array.reshape((n, n, n))
    return np.roll(shaped, shift=delta, axis=(0, 1, 2)).reshape(-1).copy()


def projected_trace(result: dict[str, Any]) -> tuple[tuple[Record, ...], ...]:
    return tuple(entry["actual"] for entry in result["trace"])


def run_witnesses(ctx: Context, kernel: Any) -> dict[str, Any]:
    n = 17
    witnesses: dict[str, Any] = {"required": {}, "nuisance": {}, "translation": {}}

    # q and common-translation witness.
    base = "W|required|q"
    q1 = origin_for(n, base)
    delta = (3, -2, 1)
    raw1 = empty_grid(n)
    put(raw1, q1, pack(7, 37, (1, 0, 0), 1), n)
    clocks1 = clock_pattern(n, "heterogeneous", base)
    raw2 = translated_array(raw1, delta, n)
    clocks2 = translated_array(clocks1, delta, n)
    r1 = run_case(ctx, kernel, case_id=base + "|origin", panel="W", role="witness", n=n,
                  grid=raw1, clocks=clocks1, horizon=3)
    r2 = run_case(ctx, kernel, case_id=base + "|shifted", panel="W", role="witness", n=n,
                  grid=raw2, clocks=clocks2, horizon=3)
    t1, t2 = projected_trace(r1), projected_trace(r2)
    lab_diverges = t1 != t2
    translated_equal = all(translate_records(a, delta, n) == b for a, b in zip(t1, t2))
    ctx.check(lab_diverges, "REQUIRED_FIELD_WITNESS", "W", "q", "future", "different", "equal")
    ctx.check(translated_equal, "COMMON_TRANSLATION", "W", "q", "future", True, translated_equal)
    witnesses["required"]["q"] = lab_diverges
    witnesses["translation"] = {"common_translation_equivalent": translated_equal, "delta": list(delta)}

    def one_source(label: str, d: tuple[int, int, int], s: int, state: int = 0, semantic: int = 1):
        q = origin_for(n, label)
        raw = empty_grid(n)
        put(raw, q, pack(state, s, d, semantic), n)
        clocks = clock_pattern(n, "heterogeneous", label)
        return raw, clocks

    # d witness.
    label = "W|required|d"
    raw_a, clocks = one_source(label, (1, 0, 0), 37)
    q = origin_for(n, label)
    raw_b = empty_grid(n)
    put(raw_b, q, pack(0, 37, (1, 1, 0), 1), n)
    ta = projected_trace(run_case(ctx, kernel, case_id=label + "|axis", panel="W", role="witness", n=n,
                                  grid=raw_a, clocks=clocks, horizon=2))
    tb = projected_trace(run_case(ctx, kernel, case_id=label + "|face", panel="W", role="witness", n=n,
                                  grid=raw_b, clocks=clocks, horizon=2))
    witnesses["required"]["d"] = ta != tb
    ctx.check(ta != tb, "REQUIRED_FIELD_WITNESS", "W", "d", "future", "different", "equal")

    # s witness.
    label = "W|required|s"
    q = origin_for(n, label)
    raws = []
    for sreg in (37, 38):
        raw = empty_grid(n)
        put(raw, q, pack(0, sreg, (1, 0, 0), 1), n)
        raws.append(raw)
    clocks = clock_pattern(n, "heterogeneous", label)
    ts = [projected_trace(run_case(ctx, kernel, case_id=f"{label}|s={sreg}", panel="W", role="witness", n=n,
                                         grid=raw, clocks=clocks, horizon=2))
          for sreg, raw in zip((37, 38), raws)]
    witnesses["required"]["s"] = ts[0] != ts[1]
    ctx.check(ts[0] != ts[1], "REQUIRED_FIELD_WITNESS", "W", "s", "future", "different", "equal")

    # a/target-closure witness.
    label = "W|required|a"
    target = origin_for(n, label)
    a_traces = []
    for state in (0, 1):
        raw = empty_grid(n)
        put(raw, add(target, (1, 0, 0), n, -1), pack(0, 37, (1, 0, 0), 1), n)
        put(raw, target, pack(state, 0, D0, 1), n)
        a_traces.append(projected_trace(run_case(
            ctx, kernel, case_id=f"{label}|target_state={state}", panel="W", role="witness", n=n,
            grid=raw, clocks=clock_pattern(n, "heterogeneous", label), horizon=2,
        )))
    witnesses["required"]["a"] = a_traces[0] != a_traces[1]
    ctx.check(a_traces[0] != a_traces[1], "REQUIRED_FIELD_WITNESS", "W", "a", "future", "different", "equal")

    # p/persistence witness.
    label = "W|required|p"
    q = origin_for(n, label)
    p_traces = []
    for semantic in (1, 4):
        raw = empty_grid(n)
        put(raw, q, pack(0, 37, (1, 0, 0), semantic), n)
        p_traces.append(projected_trace(run_case(
            ctx, kernel, case_id=f"{label}|semantic={semantic}", panel="W", role="witness", n=n,
            grid=raw, clocks=clock_pattern(n, "heterogeneous", label), horizon=3,
        )))
    witnesses["required"]["p"] = p_traces[0] != p_traces[1]
    ctx.check(p_traces[0] != p_traces[1], "REQUIRED_FIELD_WITNESS", "W", "p", "future", "different", "equal")

    # Positive state magnitude nuisance.
    label = "W|nuisance|state"
    q = origin_for(n, label)
    state_traces = []
    for state in (7, STATE_MAX_TEST):
        raw = empty_grid(n)
        put(raw, q, pack(state, 37, (1, 1, 0), 1), n)
        state_traces.append(projected_trace(run_case(
            ctx, kernel, case_id=f"{label}|state={state}", panel="W", role="witness", n=n,
            grid=raw, clocks=clock_pattern(n, "heterogeneous", label), horizon=3,
        )))
    witnesses["nuisance"]["positive_state_magnitude"] = state_traces[0] == state_traces[1]
    ctx.check(state_traces[0] == state_traces[1], "NUISANCE_WITNESS", "W", "state", "future", "equal", "different")

    # Absolute clock nuisance.
    label = "W|nuisance|clock"
    q = origin_for(n, label)
    raw = empty_grid(n)
    put(raw, q, pack(7, 37, (1, 1, 1), 1), n)
    clock_traces = [projected_trace(run_case(
        ctx, kernel, case_id=f"{label}|{mode}", panel="W", role="witness", n=n,
        grid=raw, clocks=clock_pattern(n, mode, label), horizon=3,
    )) for mode in CLOCK_MODES]
    witnesses["nuisance"]["absolute_clock"] = clock_traces[0] == clock_traces[1]
    ctx.check(clock_traces[0] == clock_traces[1], "NUISANCE_WITNESS", "W", "clock", "future", "equal", "different")

    # Non-observer semantic nuisance at both frozen states.
    semantic_groups: dict[str, bool] = {}
    for state in (0, 17):
        label = f"W|nuisance|semantic|state={state}"
        q = origin_for(n, label)
        clocks = clock_pattern(n, "heterogeneous", label)
        traces = []
        for semantic in (3, 5, 14):
            raw = empty_grid(n)
            put(raw, q, pack(state, 37, (1, 0, 0), semantic), n)
            traces.append(projected_trace(run_case(
                ctx, kernel, case_id=f"{label}|semantic={semantic}", panel="W", role="witness", n=n,
                grid=raw, clocks=clocks, horizon=3,
            )))
        equal = traces[0] == traces[1] == traces[2]
        semantic_groups[str(state)] = equal
        ctx.check(equal, "NUISANCE_WITNESS", "W", f"semantic_state_{state}", "future", "equal", "different")
    witnesses["nuisance"]["nonobserver_semantic"] = semantic_groups

    # State-zero/zero-direction raw versus empty.
    label = "W|nuisance|inert_raw"
    q = origin_for(n, label)
    raw_empty = empty_grid(n)
    raw_inert = empty_grid(n)
    put(raw_inert, q, pack(0, 65_535, D0, 14), n)
    clocks = clock_pattern(n, "heterogeneous", label)
    inert_traces = [projected_trace(run_case(
        ctx, kernel, case_id=f"{label}|{kind}", panel="W", role="witness", n=n,
        grid=raw_variant, clocks=clocks, horizon=2,
    )) for kind, raw_variant in (("empty", raw_empty), ("raw", raw_inert))]
    witnesses["nuisance"]["state0_d0_raw"] = inert_traces[0] == inert_traces[1]
    ctx.check(inert_traces[0] == inert_traces[1], "NUISANCE_WITNESS", "W", "inert_raw", "future", "equal", "different")
    return witnesses


def control_world(kind: str) -> tuple[int, np.ndarray, np.ndarray, int]:
    n = 17
    base = f"CTRL|{kind}"
    q = origin_for(n, base)
    raw = empty_grid(n)
    if kind == "free":
        put(raw, q, pack(7, 37, (1, 1, 0), 1), n)
        mode, horizon = "heterogeneous", 5
    elif kind == "collision":
        d1, d2 = (-1, -1, -1), (-1, -1, 1)
        put(raw, add(q, d1, n, -1), pack(11, 1, d1, 1), n)
        put(raw, add(q, d2, n, -1), pack(23, 19_663, d2, 1), n)
        mode, horizon = "near_wrap", 3
    elif kind == "observer":
        put(raw, q, pack(9, 19_663, (1, 1, 1), 4), n)
        mode, horizon = "heterogeneous", 7
    else:
        raise ValueError(kind)
    return n, raw, clock_pattern(n, mode, base), horizon


def run_engine_controls(ctx: Context, kernel: Any) -> dict[str, Any]:
    controls: dict[str, Any] = {}
    variants = (("lazy", 1), ("lazy", 2), ("dense", 1), ("dense", 2))
    for kind in ("free", "collision", "observer"):
        n, raw, clocks, horizon = control_world(kind)
        runs = {}
        for engine, threads in variants:
            label = f"CTRL|{kind}|{engine}|threads={threads}"
            runs[(engine, threads)] = run_case(
                ctx, kernel, case_id=label, panel="CTRL", role="engine_control", n=n,
                grid=raw, clocks=clocks, horizon=horizon, engine=engine, threads=threads,
                keep_snapshots=True,
            )
        reference = runs[("lazy", 1)]["trace"]
        comparisons = {}
        for variant in variants[1:]:
            trace = runs[variant]["trace"]
            per_tick = []
            for ref_entry, entry in zip(reference, trace):
                same = (
                    np.array_equal(ref_entry["raw_snapshot"], entry["raw_snapshot"])
                    and np.array_equal(ref_entry["clock_snapshot"], entry["clock_snapshot"])
                )
                ctx.engine_comparisons += 1
                ctx.check(
                    same, "ENGINE_CONTROL", "CTRL", f"{kind}|{variant[0]}|{variant[1]}",
                    entry["tick"], "lazy/1 exact raw+clock", "different" if not same else "equal",
                )
                per_tick.append(same)
            comparisons[f"{variant[0]}_{variant[1]}"] = per_tick
        controls[kind] = {
            "horizon": horizon,
            "variants": [f"{engine}_{threads}" for engine, threads in variants],
            "comparisons_to_lazy_1": comparisons,
            "all_equal": all(all(values) for values in comparisons.values()),
        }
    return controls


def verify_identity() -> tuple[dict[str, Any], Any]:
    observed = {
        "contract": sha256_file(CONTRACT),
        "preregister": sha256_file(PREREG),
        "wheel": sha256_file(WHEEL),
        "kernel_pyd": sha256_file(KERNEL_FILE),
        "kernel_cpp": sha256_file(SOURCE_FILE),
        "runner": sha256_file(HERE),
    }
    mismatched = {key: {"expected": EXPECTED[key], "actual": observed[key]}
                  for key in EXPECTED if observed[key] != EXPECTED[key]}
    if mismatched:
        raise RuntimeError(f"identity mismatch: {mismatched}")
    if sys.version_info[:2] != (3, 13) or platform.architecture()[0] != "64bit":
        raise RuntimeError(f"runtime mismatch: {sys.version}; {platform.architecture()[0]}")

    contract_data = json.loads(CONTRACT.read_text(encoding="utf-8"))
    if contract_data.get("status") != "FROZEN_PRE_HOLDOUT" or contract_data.get("mutable") is not False:
        raise RuntimeError("contract is not sealed immutable FROZEN_PRE_HOLDOUT")
    if contract_data["normative_identity"]["t10_preregister_sha256"] != EXPECTED["preregister"]:
        raise RuntimeError("contract does not bind the expected T10 preregistration")

    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(kernel.__file__).resolve() != KERNEL_FILE.resolve():
        raise RuntimeError(f"wrong kernel import: {kernel.__file__}")
    if Path(package.__file__).resolve().parent != PKG.resolve():
        raise RuntimeError(f"wrong package import: {package.__file__}")
    observed.update({
        "python": sys.version,
        "executable": sys.executable,
        "architecture": platform.architecture()[0],
        "numpy": np.__version__,
        "package_path": str(Path(package.__file__).resolve()),
        "kernel_path": str(Path(kernel.__file__).resolve()),
        "kernel_version": str(kernel.VERSION),
        "all_exact": True,
    })
    return observed, kernel


def assert_planned_counts(ctx: Context) -> None:
    expected_trajectories = {"A": 624, "B": 672, "C": 48, "D": 9, "E": 36}
    expected_ticks = {"A": 3120, "B": 2016, "C": 336, "D": 18, "E": 108}
    for panel, expected in expected_trajectories.items():
        ctx.check(ctx.primary_trajectories[panel] == expected, "PLANNED_COUNT", panel, "trajectories", 0,
                  expected, ctx.primary_trajectories[panel])
    for panel, expected in expected_ticks.items():
        ctx.check(ctx.primary_ticks[panel] == expected, "PLANNED_COUNT", panel, "ticks", 0,
                  expected, ctx.primary_ticks[panel])
    ctx.check(sum(ctx.primary_trajectories.values()) == 1389, "PLANNED_COUNT", "ALL", "trajectories", 0,
              1389, sum(ctx.primary_trajectories.values()))
    ctx.check(sum(ctx.primary_ticks.values()) == 5598, "PLANNED_COUNT", "ALL", "ticks", 0,
              5598, sum(ctx.primary_ticks.values()))
    ctx.check(ctx.composition_checks == 1872, "PLANNED_COUNT", "A", "composition", 0,
              1872, ctx.composition_checks)


def csv_safe(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def write_outputs(result: dict[str, Any], ctx: Context) -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    with CASES_CSV.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=CASE_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in ctx.case_rows:
            writer.writerow({key: csv_safe(row.get(key, "")) for key in CASE_FIELDS})
    with MISMATCHES_CSV.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=MISMATCH_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in ctx.mismatches:
            writer.writerow({key: csv_safe(row.get(key, "")) for key in MISMATCH_FIELDS})
    RESULT_JSON.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")

    manifest_entries = (
        (RESULT_JSON, "t10_result.json"),
        (CASES_CSV, "t10_cases.csv"),
        (MISMATCHES_CSV, "t10_mismatches.csv"),
        (HERE, "../../RUNNERS_NEW/run_t10_rosetta_core_holdout.py"),
        (CONTRACT, "../../HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json"),
        (PREREG, "../../HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md"),
        (WHEEL, "../../../../dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"),
        (KERNEL_FILE, "../../../ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd"),
    )
    MANIFEST.write_text(
        "".join(f"{sha256_file(path)}  {label}\n" for path, label in manifest_entries),
        encoding="ascii",
    )


def main() -> int:
    started = datetime.now(timezone.utc).isoformat()
    ctx = Context()
    identity: dict[str, Any] = {}
    witnesses: dict[str, Any] = {}
    engine_controls: dict[str, Any] = {}
    fatal: dict[str, Any] | None = None
    try:
        identity, kernel = verify_identity()
        run_panel_a(ctx, kernel)
        run_panel_b(ctx, kernel)
        run_panel_c(ctx, kernel)
        run_panel_d(ctx, kernel)
        run_panel_e(ctx, kernel)
        witnesses = run_witnesses(ctx, kernel)
        engine_controls = run_engine_controls(ctx, kernel)
        assert_planned_counts(ctx)
    except Exception as exc:  # Preserve an invalid attempt rather than editing the frozen test.
        fatal = {
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": traceback.format_exc(),
        }

    mismatch_categories = Counter(str(row["category"]) for row in ctx.mismatches)
    if fatal is not None:
        verdict = "INVALID_RUN"
    elif ctx.mismatches or ctx.domain_failures:
        verdict = "FAIL"
    else:
        verdict = "PASS"

    result = {
        "schema": "dee.v27.rosetta.t10.result.v1",
        "test": "T10_ROSETTA_CORE_FROZEN_HOLDOUT",
        "verdict": verdict,
        "started_utc": started,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "no_refit": True,
        "identity": identity,
        "fatal": fatal,
        "frozen_inputs": {
            "contract": str(CONTRACT.resolve()),
            "contract_sha256": EXPECTED["contract"],
            "preregister": str(PREREG.resolve()),
            "preregister_sha256": EXPECTED["preregister"],
        },
        "specification_consistency": {
            "status": "PREEXISTING_CONFLICT_EXECUTED_LITERALLY",
            "M_star_clause": "active non-observer d=0 blockers canonicalize s to zero",
            "G_star_clause": "every multi-source child retains capped s_out, with no d_out=0 exception",
            "affected_frozen_cases": "Panel B opposite body-diagonal pairs",
            "implementation": "M_* applies its zero-load canonicalization; G_* applies literal s_out without post-hoc canonicalization",
            "no_repair": True,
        },
        "implementation_choices_fixed_before_binary_outcome": {
            "D26_order": [list(d) for d in D26],
            "D8_order": [list(d) for d in D8],
            "unordered_pair_order": "itertools.combinations(D8,2) in listed D8 order",
            "origin": "SHA256(seed|origin|case-base), three little-endian uint64 residues modulo N; clock mode excluded",
            "heterogeneous_clock": "PCG64 derived from SHA256(seed|clock|case-base|mode), raw uint64 at every site",
            "near_wrap_clock": "UINT64_MAX minus PCG64 offsets in [0,31] at every site",
            "panel_D_clock": "one heterogeneous profile; no clock factor was frozen for Panel D",
            "panel_D_payloads": {
                "source": "state=0,s=37,semantic=1",
                "canonical_empty_raw": "state=0,s=123,d=0,semantic=14",
                "active_blocker": "state=17,s=65535,d=0,semantic=14",
                "observer": "state=0,s=123,d=0,semantic=4",
            },
            "panel_E_load": 37,
            "primary_engine": "tick_universo_lazy, one thread",
        },
        "planned_primary": {
            "trajectories": {"A": 624, "B": 672, "C": 48, "D": 9, "E": 36, "total": 1389},
            "scored_ticks": {"A": 3120, "B": 2016, "C": 336, "D": 18, "E": 108, "total": 5598},
            "composition_checks": 1872,
        },
        "observed": {
            "primary_trajectories": {**dict(ctx.primary_trajectories), "total": sum(ctx.primary_trajectories.values())},
            "primary_scored_ticks": {**dict(ctx.primary_ticks), "total": sum(ctx.primary_ticks.values())},
            "all_kernel_ticks_including_witnesses_and_controls": ctx.kernel_ticks,
            "domain_checks_before_slices": ctx.domain_checks,
            "domain_failures": ctx.domain_failures,
            "assertions": ctx.assertions,
            "composition_checks": ctx.composition_checks,
            "engine_comparisons": ctx.engine_comparisons,
            "mismatches": len(ctx.mismatches),
            "mismatch_categories": dict(mismatch_categories),
        },
        "hypotheses": {
            "H10.1": {
                "pass": mismatch_categories["PROJECTED_CLOSURE"] == 0
                        and mismatch_categories["ITERATED_INPUT_ALIGNMENT"] == 0
                        and ctx.domain_failures == 0,
                "closure_mismatches": mismatch_categories["PROJECTED_CLOSURE"],
                "iterated_alignment_mismatches": mismatch_categories["ITERATED_INPUT_ALIGNMENT"],
                "domain_failures": ctx.domain_failures,
            },
            "H10.2": {
                "pass": mismatch_categories["REQUIRED_FIELD_WITNESS"] == 0
                        and mismatch_categories["NUISANCE_WITNESS"] == 0
                        and mismatch_categories["COMMON_TRANSLATION"] == 0,
                "witnesses": witnesses,
            },
            "H10.3": {
                "pass": mismatch_categories["K_FREE_COMPOSITION"] == 0,
                "checks": ctx.composition_checks,
                "mismatches": mismatch_categories["K_FREE_COMPOSITION"],
            },
        },
        "engine_controls": {
            "pass": mismatch_categories["ENGINE_CONTROL"] == 0,
            "controls": engine_controls,
            "mismatches": mismatch_categories["ENGINE_CONTROL"],
        },
        "mismatch_sample": ctx.mismatches[:20],
        "ledgers": {
            "all_input_slices_and_case_results": "t10_cases.csv",
            "all_mismatches": "t10_mismatches.csv",
            "sha256_manifest": "t10_SHA256SUMS.txt",
        },
        "acceptance_rule": "PASS only with zero mismatches, zero domain failures, all identities, witnesses, composition, counts and engine controls passing",
    }
    write_outputs(result, ctx)
    print(json.dumps({
        "verdict": verdict,
        "primary_trajectories": sum(ctx.primary_trajectories.values()),
        "primary_scored_ticks": sum(ctx.primary_ticks.values()),
        "all_kernel_ticks": ctx.kernel_ticks,
        "domain_failures": ctx.domain_failures,
        "mismatches": len(ctx.mismatches),
        "mismatch_categories": dict(mismatch_categories),
        "output": str(RESULT_JSON),
    }, indent=2, sort_keys=True))
    return 0 if verdict == "PASS" else (2 if verdict == "FAIL" else 3)


if __name__ == "__main__":
    raise SystemExit(main())
