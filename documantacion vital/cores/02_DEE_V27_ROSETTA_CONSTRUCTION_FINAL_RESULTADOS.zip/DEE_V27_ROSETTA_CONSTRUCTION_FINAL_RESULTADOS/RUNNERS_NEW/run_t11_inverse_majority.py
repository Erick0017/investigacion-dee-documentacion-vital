#!/usr/bin/env python3
"""T11 frozen post-construction inverse prediction.

Implements HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.md literally.  The
scientific matrix and acceptance rule are constants; the only CLI option is a
fresh output directory so the frozen run can be reproduced without overwrite.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib
import itertools
import json
import platform
import struct
import sys
import traceback
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np


HERE = Path(__file__).resolve()
ROSETTA = HERE.parents[1]
V1 = ROSETTA.parent
TESTS = V1.parent
HOLDOUTS = ROSETTA / "HOLDOUTS"
EXTRACTED = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKG = EXTRACTED / "dee_universe_v27"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_FILE = PKG / "dee_kernel_v27.cp313-win_amd64.pyd"
SOURCE_FILE = PKG / "dee_kernel_v27.cpp"
CONTRACT = HOLDOUTS / "ROSETTA_FROZEN_CONTRACT.json"
PREREG = HOLDOUTS / "PREREGISTER_T11_INVERSE_MAJORITY.md"
T10_PREREG = HOLDOUTS / "PREREGISTER_T10_ROSETTA_CORE.md"
EXACT_PROOFS = V1 / "ANALYSIS" / "native_theory" / "EXACT_PROOFS.md"
T8_RESULT = V1 / "RESULTS" / "native_ballistic" / "t8_result.json"
T9_RESULT = V1 / "RESULTS" / "observer_pump" / "t9_result.json"
PARENT_ZIP = V1 / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip"
DEFAULT_OUT = ROSETTA / "RESULTS" / "t11_inverse_majority"

EXPECTED_HASHES = {
    "contract": "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157",
    "preregister": "7e2e38062d23b4812abd655596bebe778d1c21a3e4f06db00aa3932ba0415888",
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel_pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "kernel_cpp": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
    "parent_v1_zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "exact_proofs": "f7fc8f526598d74802c0ed3e0e5dd37190c87d91ef132f251562e76a04c1c609",
    "t8_result": "eb4a74b63afe714b6efedee94e318ace82fadd03763eac0c0e00ab60d37c0e92",
    "t9_result": "bbc14a60d254d83829680509d1b38185abfa57628b2ef041affb3b6ed801069f",
    "t10_preregister": "2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f",
}
IDENTITY_PATHS = {
    "contract": CONTRACT,
    "preregister": PREREG,
    "wheel": WHEEL,
    "kernel_pyd": KERNEL_FILE,
    "kernel_cpp": SOURCE_FILE,
    "parent_v1_zip": PARENT_ZIP,
    "exact_proofs": EXACT_PROOFS,
    "t8_result": T8_RESULT,
    "t9_result": T9_RESULT,
    "t10_preregister": T10_PREREG,
}

N = 23
M = N**3
Q = (11, 11, 11)
HORIZON = 2
SEED = 271105607
CAP = 19664
SEM_NORMAL = 1
SEM_OBSERVER = 4
MOORE = tuple(
    (x, y, z)
    for x in (-1, 0, 1)
    for y in (-1, 0, 1)
    for z in (-1, 0, 1)
    if (x, y, z) != (0, 0, 0)
)
MOORE_SET = frozenset(MOORE)
BODY8 = tuple(itertools.product((-1, 1), repeat=3))
SUBSETS = tuple(itertools.combinations(BODY8, 5))
LOAD_PROFILES = ("all_one", "one_19664_others_65535")
STATE_PROFILES = ("all_zero", "alternating_zero_and_17")
CLOCK_PROFILES = ("heterogeneous", "near_wrap")

CASE_COLUMNS = (
    "case_id", "subset_index", "subset", "load_profile", "state_profile", "clock_profile",
    "expected_direction", "expected_s_reg", "domain_tick0", "domain_tick1",
    "tick1_position", "tick1_direction", "tick1_s_reg", "tick1_state", "tick1_semantic",
    "tick1_raw_nonzero", "tick1_active", "tick1_sources_empty", "tick1_raw_sha256", "tick1_clock_sha256",
    "tick2_position", "tick2_direction", "tick2_s_reg", "tick2_state", "tick2_semantic",
    "tick2_raw_nonzero", "tick2_active", "tick2_raw_sha256", "tick2_clock_sha256",
    "case_mismatches", "case_status",
)
MISMATCH_COLUMNS = ("scope", "case_id", "tick", "check", "expected", "actual", "detail")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(a)).cast("B")).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 15) << 48)
        | ((d[1] & 15) << 52)
        | ((d[2] & 15) << 56)
        | ((semantic & 15) << 60)
    )


def unpack(raw: int | np.uint64) -> dict[str, Any]:
    value = int(raw)

    def nibble(shift: int) -> int:
        x = (value >> shift) & 15
        return x - 16 if x & 8 else x

    return {
        "raw": value,
        "state": value & 0xFFFFFFFF,
        "s_reg": (value >> 32) & 0xFFFF,
        "direction": (nibble(48), nibble(52), nibble(56)),
        "semantic": (value >> 60) & 15,
    }


def index(q: tuple[int, int, int]) -> int:
    return (q[0] * N + q[1]) * N + q[2]


def position(flat: int) -> tuple[int, int, int]:
    q = np.unravel_index(flat, (N, N, N))
    return tuple(int(v) for v in q)


def add(q: tuple[int, int, int], d: tuple[int, int, int], scale: int = 1) -> tuple[int, int, int]:
    return tuple((q[k] + scale * d[k]) % N for k in range(3))


def sub(q: tuple[int, int, int], d: tuple[int, int, int]) -> tuple[int, int, int]:
    return add(q, d, -1)


def sign3(v: tuple[int, int, int]) -> tuple[int, int, int]:
    return tuple(1 if x > 0 else (-1 if x < 0 else 0) for x in v)


def vec_text(v) -> str:
    return json.dumps([int(x) for x in v], separators=(",", ":"))


def json_text(v) -> str:
    return json.dumps(v, separators=(",", ":"), sort_keys=True)


def clock_array(name: str) -> np.ndarray:
    if name == "heterogeneous":
        # Frozen operationalization of "deterministic heterogeneous clock from seed".
        return np.asarray(np.random.PCG64(SEED).random_raw(M), dtype=np.uint64)
    if name == "near_wrap":
        pattern = np.asarray([(1 << 64) - 3, (1 << 64) - 2, (1 << 64) - 1], dtype=np.uint64)
        return np.resize(pattern, M).copy()
    raise ValueError(name)


def loads_for(subset, name: str) -> tuple[int, ...]:
    if name == "all_one":
        return (1, 1, 1, 1, 1)
    if name == "one_19664_others_65535":
        # itertools.combinations preserves BODY8 lexicographic order.
        return (19664, 65535, 65535, 65535, 65535)
    raise ValueError(name)


def states_for(name: str) -> tuple[int, ...]:
    if name == "all_zero":
        return (0, 0, 0, 0, 0)
    if name == "alternating_zero_and_17":
        # Frozen before opening T11: starts with zero in lexicographic source order.
        return (0, 17, 0, 17, 0)
    raise ValueError(name)


def initial_raw(subset, load_name: str, state_name: str) -> np.ndarray:
    raw = np.zeros(M, dtype=np.uint64)
    for d, s, state in zip(subset, loads_for(subset, load_name), states_for(state_name), strict=True):
        raw[index(sub(Q, d))] = pack(state, s, d, SEM_NORMAL)
    return raw


def expected_raw(direction: tuple[int, int, int], sreg: int, tick: int) -> np.ndarray:
    raw = np.zeros(M, dtype=np.uint64)
    raw[index(add(Q, direction, tick - 1))] = pack(1, sreg, direction, SEM_NORMAL)
    return raw


def active_count(raw: np.ndarray) -> int:
    return int(np.count_nonzero((raw & np.uint64(0xFFFFFFFF)) != 0))


def domain_predicate(raw: np.ndarray) -> dict[str, Any]:
    decoded = []
    active_positions = []
    directions_valid = True
    for flat in np.flatnonzero(raw != 0):
        u = unpack(raw[int(flat)])
        q = position(int(flat))
        decoded.append((q, u))
        if u["direction"] != (0, 0, 0) and u["direction"] not in MOORE_SET:
            directions_valid = False
        if int(u["state"]) > 0:
            active_positions.append(q)
    active_set = set(active_positions)
    max_neighbors = 0
    per_site = []
    for q, u in decoded:
        if int(u["state"]) <= 0 or int(u["semantic"]) == SEM_OBSERVER:
            continue
        count = sum(1 for d in MOORE if add(q, d) in active_set)
        max_neighbors = max(max_neighbors, count)
        per_site.append({"q": list(q), "active_neighbors": count})
    ok = N >= 5 and directions_valid and len(active_positions) <= 7 and max_neighbors <= 3
    return {
        "ok": bool(ok),
        "N_ok": N >= 5,
        "directions_valid": bool(directions_valid),
        "active_sites": len(active_positions),
        "max_active_neighbors_nonobserver": max_neighbors,
        "per_active_nonobserver": per_site,
    }


def canonical_projection(raw: np.ndarray) -> list[dict[str, Any]]:
    records = []
    for flat in np.flatnonzero(raw != 0):
        u = unpack(raw[int(flat)])
        d = u["direction"]
        state = int(u["state"])
        sem = int(u["semantic"])
        p = int(sem == SEM_OBSERVER)
        if not (state > 0 or d in MOORE_SET or p):
            continue
        s = int(u["s_reg"])
        if p == 0 and state > 0 and d == (0, 0, 0):
            s = 0
        records.append({
            "q": list(position(int(flat))),
            "d": list(d),
            "s": s,
            "a": int(state > 0),
            "p": p,
        })
    records.sort(key=lambda z: (z["q"], z["d"], z["s"], z["a"], z["p"]))
    return records


def info_json(info) -> dict[str, Any]:
    out = {}
    for key, value in dict(info).items():
        if isinstance(value, (int, np.integer)):
            out[str(key)] = int(value)
        elif isinstance(value, (float, np.floating)):
            out[str(key)] = float(value)
        else:
            out[str(key)] = str(value)
    return out


class Simulation:
    def __init__(self, kernel, raw: np.ndarray, clock: np.ndarray):
        self.kernel = kernel
        self.raw_a = np.ascontiguousarray(raw, dtype=np.uint64).copy()
        self.raw_b = np.zeros_like(self.raw_a)
        self.clock_a = np.ascontiguousarray(clock, dtype=np.uint64).copy()
        self.clock_b = np.zeros_like(self.clock_a)

    def step(self, engine: str, threads: int) -> dict[str, Any]:
        fn = self.kernel.tick_universo_lazy if engine == "lazy" else self.kernel.tick_universo
        info = fn(self.raw_a, self.raw_b, self.clock_a, self.clock_b, N, threads)
        return {
            "info": info_json(info),
            "copyback_raw": bool(np.array_equal(self.raw_a, self.raw_b)),
            "copyback_clock": bool(np.array_equal(self.clock_a, self.clock_b)),
        }


def add_mismatch(mismatches: list[dict[str, str]], *, scope: str, case_id: str = "", tick: Any = "",
                 check: str, expected: Any, actual: Any, detail: Any = "") -> None:
    mismatches.append({
        "scope": str(scope),
        "case_id": str(case_id),
        "tick": str(tick),
        "check": str(check),
        "expected": json_text(expected) if not isinstance(expected, str) else expected,
        "actual": json_text(actual) if not isinstance(actual, str) else actual,
        "detail": json_text(detail) if not isinstance(detail, str) else detail,
    })


def check(mismatches, condition: bool, *, scope: str, case_id: str = "", tick: Any = "",
          name: str, expected: Any, actual: Any, detail: Any = "") -> None:
    if not condition:
        add_mismatch(
            mismatches, scope=scope, case_id=case_id, tick=tick, check=name,
            expected=expected, actual=actual, detail=detail,
        )


def preflight() -> tuple[dict[str, Any], list[str]]:
    actual = {}
    errors = []
    for key, path in IDENTITY_PATHS.items():
        if not path.is_file():
            actual[key] = None
            errors.append(f"missing {key}: {path}")
            continue
        actual[key] = sha256_file(path)
        if actual[key] != EXPECTED_HASHES[key]:
            errors.append(f"hash mismatch {key}: {actual[key]} != {EXPECTED_HASHES[key]}")

    runtime = {
        "implementation": platform.python_implementation(),
        "version": platform.python_version(),
        "executable": str(Path(sys.executable).resolve()),
        "pointer_bits": struct.calcsize("P") * 8,
        "machine": platform.machine(),
        "platform": platform.platform(),
        "numpy": np.__version__,
        "isolated_flag": int(sys.flags.isolated),
        "dont_write_bytecode": bool(sys.dont_write_bytecode),
    }
    if runtime["implementation"] != "CPython" or sys.version_info[:2] != (3, 13):
        errors.append("runtime is not CPython 3.13")
    if runtime["pointer_bits"] != 64:
        errors.append("runtime is not 64-bit")
    if runtime["isolated_flag"] != 1 or not runtime["dont_write_bytecode"]:
        errors.append("runner was not invoked with both -I and -B")

    seal_checks = {}
    for path, expected in (
        (HOLDOUTS / "ROSETTA_FROZEN_CONTRACT.sha256", EXPECTED_HASHES["contract"]),
        (HOLDOUTS / "PREREGISTER_T11_INVERSE_MAJORITY.sha256", EXPECTED_HASHES["preregister"]),
    ):
        text = path.read_text(encoding="utf-8").strip() if path.is_file() else ""
        seal_checks[path.name] = text
        if not text.lower().startswith(expected):
            errors.append(f"seal file mismatch: {path}")

    contract_object = None
    if CONTRACT.is_file():
        try:
            contract_object = json.loads(CONTRACT.read_text(encoding="utf-8"))
            fixed = contract_object["inverse_prediction_T11"]["fixed_test"]
            literal = {
                "N": fixed["N"] == N,
                "target": tuple(fixed["target"]) == Q,
                "subsets": fixed["subsets"] == "all C(8,5)=56",
                "loads": tuple(fixed["load_profiles"]) == LOAD_PROFILES,
                "states": tuple(fixed["state_profiles"]) == STATE_PROFILES,
                "clocks": tuple(fixed["clock_profiles"]) == CLOCK_PROFILES,
                "horizon": fixed["horizon"] == HORIZON,
                "no_refit": contract_object["inverse_prediction_T11"]["no_refit"] is True,
            }
            if not all(literal.values()):
                errors.append(f"contract literal mismatch: {literal}")
        except Exception as exc:  # technical invalidity, never scientific evidence
            errors.append(f"contract parse/structure error: {exc}")
            literal = {}
    else:
        literal = {}

    return {
        "expected_sha256": EXPECTED_HASHES,
        "actual_sha256": actual,
        "seal_file_contents": seal_checks,
        "contract_literal_checks": literal,
        "runtime": runtime,
        "runner_sha256": sha256_file(HERE),
    }, errors


def import_kernel(identity: dict[str, Any]):
    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    package_path = Path(package.__file__).resolve()
    kernel_path = Path(kernel.__file__).resolve()
    identity["import"] = {
        "package": str(package_path),
        "kernel": str(kernel_path),
        "kernel_version": str(kernel.VERSION),
    }
    if package_path != (PKG / "__init__.py").resolve():
        raise RuntimeError(f"unexpected package import: {package_path}")
    if kernel_path != KERNEL_FILE.resolve():
        raise RuntimeError(f"unexpected kernel import: {kernel_path}")
    return kernel


def write_csv(path: Path, columns, rows: list[dict[str, Any]]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    tmp.replace(path)


def write_json(path: Path, obj: dict[str, Any]) -> None:
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(path)


def finalize(out: Path, result: dict[str, Any], rows, mismatches) -> None:
    out.mkdir(parents=True, exist_ok=True)
    cases_path = out / "t11_cases.csv"
    mismatches_path = out / "t11_mismatches.csv"
    result_path = out / "t11_result.json"
    write_csv(cases_path, CASE_COLUMNS, rows)
    write_csv(mismatches_path, MISMATCH_COLUMNS, mismatches)
    result["artifacts"] = {
        "t11_cases.csv": {"rows": len(rows), "sha256": sha256_file(cases_path)},
        "t11_mismatches.csv": {"rows": len(mismatches), "sha256": sha256_file(mismatches_path)},
    }
    write_json(result_path, result)
    hash_paths = [
        result_path,
        cases_path,
        mismatches_path,
        HERE,
        CONTRACT,
        PREREG,
    ]
    labels = [
        "t11_result.json",
        "t11_cases.csv",
        "t11_mismatches.csv",
        "../../RUNNERS_NEW/run_t11_inverse_majority.py",
        "../../HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json",
        "../../HOLDOUTS/PREREGISTER_T11_INVERSE_MAJORITY.md",
    ]
    text = "".join(f"{sha256_file(path)} *{label}\n" for path, label in zip(hash_paths, labels, strict=True))
    (out / "HASHES.sha256").write_text(text, encoding="ascii")


def run_science(kernel, result, rows, mismatches):
    profile_hashes: dict[tuple, set[str]] = defaultdict(set)
    inverse_fibers: dict[tuple[int, int, int], set[int]] = defaultdict(set)
    designated_reference = None
    primary_trajectories = 0
    primary_scored_ticks = 0
    domain_checks = 0

    for subset_index, subset in enumerate(SUBSETS):
        summed = tuple(sum(d[k] for d in subset) for k in range(3))
        expected_direction = sign3(summed)
        check(
            mismatches, expected_direction in BODY8,
            scope="combinatorics", case_id=f"S{subset_index:02d}", name="odd_majority_body_diagonal",
            expected="one of B8", actual=list(expected_direction), detail={"coordinate_sum": summed},
        )
        for load_name in LOAD_PROFILES:
            loads = loads_for(subset, load_name)
            expected_s = min(sum(loads), CAP)
            for state_name in STATE_PROFILES:
                for clock_name in CLOCK_PROFILES:
                    case_id = f"S{subset_index:02d}_{load_name}_{state_name}_{clock_name}"
                    before_mismatches = len(mismatches)
                    raw0 = initial_raw(subset, load_name, state_name)
                    clock0 = clock_array(clock_name)
                    sim = Simulation(kernel, raw0, clock0)
                    domain0 = domain_predicate(sim.raw_a)
                    domain_checks += 1
                    check(
                        mismatches, domain0["ok"], scope="domain", case_id=case_id, tick=0,
                        name="D_star_input", expected=True, actual=domain0["ok"], detail=domain0,
                    )

                    tick_data = {}
                    domain1 = None
                    for tick in (1, 2):
                        meta = sim.step("lazy", 1)
                        primary_scored_ticks += 1
                        expected = expected_raw(expected_direction, expected_s, tick)
                        expected_clock = clock0 + np.uint64(tick)
                        check(mismatches, meta["copyback_raw"], scope="engine", case_id=case_id, tick=tick,
                              name="raw_copyback", expected=True, actual=meta["copyback_raw"])
                        check(mismatches, meta["copyback_clock"], scope="engine", case_id=case_id, tick=tick,
                              name="clock_copyback", expected=True, actual=meta["copyback_clock"])
                        check(mismatches, np.array_equal(sim.raw_a, expected), scope="prediction", case_id=case_id, tick=tick,
                              name="full_raw_exact", expected=sha256_array(expected), actual=sha256_array(sim.raw_a))
                        check(mismatches, np.array_equal(sim.clock_a, expected_clock), scope="clock", case_id=case_id, tick=tick,
                              name="clock_plus_tick", expected=sha256_array(expected_clock), actual=sha256_array(sim.clock_a))

                        expected_q = add(Q, expected_direction, tick - 1)
                        actual_word = unpack(sim.raw_a[index(expected_q)])
                        projection = canonical_projection(sim.raw_a)
                        nonzero = int(np.count_nonzero(sim.raw_a))
                        active = active_count(sim.raw_a)
                        check(mismatches, nonzero == 1, scope="prediction", case_id=case_id, tick=tick,
                              name="one_canonical_raw", expected=1, actual=nonzero)
                        check(mismatches, active == 1, scope="prediction", case_id=case_id, tick=tick,
                              name="one_active_record", expected=1, actual=active)
                        check(mismatches, len(projection) == 1, scope="projection", case_id=case_id, tick=tick,
                              name="one_M_star_record", expected=1, actual=len(projection), detail=projection)
                        check(mismatches, actual_word["direction"] == expected_direction, scope="prediction", case_id=case_id, tick=tick,
                              name="majority_direction", expected=list(expected_direction), actual=list(actual_word["direction"]))
                        check(mismatches, int(actual_word["s_reg"]) == expected_s, scope="prediction", case_id=case_id, tick=tick,
                              name="capped_load", expected=expected_s, actual=int(actual_word["s_reg"]))
                        check(mismatches, int(actual_word["state"]) == 1 and int(actual_word["semantic"]) == SEM_NORMAL,
                              scope="prediction", case_id=case_id, tick=tick, name="canonical_state_semantic",
                              expected={"state": 1, "semantic": 1},
                              actual={"state": int(actual_word["state"]), "semantic": int(actual_word["semantic"])})

                        sources_empty = sum(int(sim.raw_a[index(sub(Q, d))] == 0) for d in subset)
                        if tick == 1:
                            check(mismatches, sources_empty == 5, scope="prediction", case_id=case_id, tick=tick,
                                  name="five_sources_empty", expected=5, actual=sources_empty)
                            domain1 = domain_predicate(sim.raw_a)
                            domain_checks += 1
                            check(mismatches, domain1["ok"], scope="domain", case_id=case_id, tick=1,
                                  name="D_star_iterated_input", expected=True, actual=domain1["ok"], detail=domain1)

                        tick_data[tick] = {
                            "position": expected_q,
                            "word": actual_word,
                            "nonzero": nonzero,
                            "active": active,
                            "sources_empty": sources_empty,
                            "raw_hash": sha256_array(sim.raw_a),
                            "clock_hash": sha256_array(sim.clock_a),
                            "info": meta["info"],
                            "raw_snapshot": sim.raw_a.copy(),
                            "clock_snapshot": sim.clock_a.copy(),
                        }

                    profile_hashes[(subset_index, load_name, 1)].add(tick_data[1]["raw_hash"])
                    profile_hashes[(subset_index, load_name, 2)].add(tick_data[2]["raw_hash"])
                    if load_name == "all_one" and state_name == "all_zero":
                        inverse_fibers[expected_direction].add(subset_index)

                    if (
                        subset_index == 0 and load_name == "all_one" and state_name == "all_zero"
                        and clock_name == "near_wrap"
                    ):
                        designated_reference = {
                            "subset": subset,
                            "raw0": raw0.copy(),
                            "clock0": clock0.copy(),
                            "ticks": {
                                tick: {
                                    "raw": tick_data[tick]["raw_snapshot"].copy(),
                                    "clock": tick_data[tick]["clock_snapshot"].copy(),
                                }
                                for tick in (1, 2)
                            },
                        }

                    row = {
                        "case_id": case_id,
                        "subset_index": subset_index,
                        "subset": json_text([list(d) for d in subset]),
                        "load_profile": load_name,
                        "state_profile": state_name,
                        "clock_profile": clock_name,
                        "expected_direction": vec_text(expected_direction),
                        "expected_s_reg": expected_s,
                        "domain_tick0": domain0["ok"],
                        "domain_tick1": domain1["ok"] if domain1 else False,
                        "tick1_position": vec_text(tick_data[1]["position"]),
                        "tick1_direction": vec_text(tick_data[1]["word"]["direction"]),
                        "tick1_s_reg": tick_data[1]["word"]["s_reg"],
                        "tick1_state": tick_data[1]["word"]["state"],
                        "tick1_semantic": tick_data[1]["word"]["semantic"],
                        "tick1_raw_nonzero": tick_data[1]["nonzero"],
                        "tick1_active": tick_data[1]["active"],
                        "tick1_sources_empty": tick_data[1]["sources_empty"],
                        "tick1_raw_sha256": tick_data[1]["raw_hash"],
                        "tick1_clock_sha256": tick_data[1]["clock_hash"],
                        "tick2_position": vec_text(tick_data[2]["position"]),
                        "tick2_direction": vec_text(tick_data[2]["word"]["direction"]),
                        "tick2_s_reg": tick_data[2]["word"]["s_reg"],
                        "tick2_state": tick_data[2]["word"]["state"],
                        "tick2_semantic": tick_data[2]["word"]["semantic"],
                        "tick2_raw_nonzero": tick_data[2]["nonzero"],
                        "tick2_active": tick_data[2]["active"],
                        "tick2_raw_sha256": tick_data[2]["raw_hash"],
                        "tick2_clock_sha256": tick_data[2]["clock_hash"],
                        "case_mismatches": len(mismatches) - before_mismatches,
                        "case_status": "PASS" if len(mismatches) == before_mismatches else "FAIL",
                    }
                    rows.append(row)
                    primary_trajectories += 1

    invariance_failures = []
    for key, hashes in profile_hashes.items():
        if len(hashes) != 1:
            invariance_failures.append({"key": key, "raw_hashes": sorted(hashes)})
            add_mismatch(mismatches, scope="profile_invariance", check="state_clock_invariance",
                         expected=1, actual=len(hashes), detail={"key": key, "hashes": sorted(hashes)})

    inverse_histogram = {vec_text(d): len(inverse_fibers.get(d, set())) for d in BODY8}
    inverse_fiber_members = {
        vec_text(d): [
            {"subset_index": i, "subset": [list(v) for v in SUBSETS[i]]}
            for i in sorted(inverse_fibers.get(d, set()))
        ]
        for d in BODY8
    }
    extra_inverse_directions = [list(d) for d in inverse_fibers if d not in BODY8]
    check(mismatches, len(inverse_fibers) == 8 and not extra_inverse_directions,
          scope="inverse", name="exactly_eight_body_diagonal_outputs", expected=8,
          actual=len(inverse_fibers), detail={"extra": extra_inverse_directions})
    for d in BODY8:
        check(mismatches, len(inverse_fibers.get(d, set())) == 7,
              scope="inverse", name="seven_preimages_per_output", expected=7,
              actual=len(inverse_fibers.get(d, set())), detail={"direction": list(d)})

    controls = []
    if designated_reference is None:
        add_mismatch(mismatches, scope="engine_control", check="designated_reference_exists",
                     expected=True, actual=False)
    else:
        for engine in ("dense", "lazy"):
            for threads in (1, 2):
                control_id = f"{engine}_{threads}"
                before = len(mismatches)
                sim = Simulation(kernel, designated_reference["raw0"], designated_reference["clock0"])
                trace = []
                for tick in (1, 2):
                    meta = sim.step(engine, threads)
                    ref = designated_reference["ticks"][tick]
                    raw_equal = bool(np.array_equal(sim.raw_a, ref["raw"]))
                    clock_equal = bool(np.array_equal(sim.clock_a, ref["clock"]))
                    check(mismatches, raw_equal, scope="engine_control", case_id=control_id, tick=tick,
                          name="raw_equal_reference", expected=True, actual=raw_equal)
                    check(mismatches, clock_equal, scope="engine_control", case_id=control_id, tick=tick,
                          name="clock_equal_reference", expected=True, actual=clock_equal)
                    check(mismatches, meta["copyback_raw"] and meta["copyback_clock"],
                          scope="engine_control", case_id=control_id, tick=tick, name="copyback",
                          expected=True, actual=meta)
                    trace.append({
                        "tick": tick,
                        "raw_sha256": sha256_array(sim.raw_a),
                        "clock_sha256": sha256_array(sim.clock_a),
                        "raw_equal_reference": raw_equal,
                        "clock_equal_reference": clock_equal,
                        "kernel_info": meta["info"],
                    })
                controls.append({
                    "engine": engine,
                    "threads": threads,
                    "trace": trace,
                    "status": "PASS" if len(mismatches) == before else "FAIL",
                })

    result["matrix"] = {
        "N": N,
        "target": list(Q),
        "body_diagonal_directions": [list(d) for d in BODY8],
        "direction_subsets": len(SUBSETS),
        "load_profiles": list(LOAD_PROFILES),
        "state_profiles": list(STATE_PROFILES),
        "clock_profiles": list(CLOCK_PROFILES),
        "horizon": HORIZON,
        "operationalization_frozen_before_run": {
            "subset_order": "Python tuple lexicographic order over product((-1,+1), repeat=3)",
            "alternating_state_sequence": [0, 17, 0, 17, 0],
            "heterogeneous_clock": f"numpy.PCG64({SEED}).random_raw(N^3)",
            "near_wrap_clock": "flat repeating [2^64-3,2^64-2,2^64-1]",
            "high_load_assignment": "lexicographically first subset direction gets 19664; other four get 65535",
        },
    }
    result["counts"] = {
        "primary_trajectories": primary_trajectories,
        "primary_scored_ticks": primary_scored_ticks,
        "expected_primary_trajectories": 448,
        "expected_primary_scored_ticks": 896,
        "domain_checks": domain_checks,
        "case_rows": len(rows),
        "engine_control_trajectories": len(controls),
        "engine_control_ticks": sum(len(c["trace"]) for c in controls),
    }
    result["profile_invariance"] = {
        "groups": len(profile_hashes),
        "groups_with_more_than_one_raw_hash": len(invariance_failures),
        "failures": invariance_failures,
    }
    result["inverse_prediction"] = {
        "histogram_unique_subsets": inverse_histogram,
        "fibers": inverse_fiber_members,
        "number_of_outputs": len(inverse_fibers),
        "unique_subsets_scored": len(set().union(*inverse_fibers.values())) if inverse_fibers else 0,
        "clock_profiles_deduplicated_by_subset": True,
        "expected": "eight body-diagonal outputs, seven unordered five-subset preimages each",
    }
    result["engine_controls"] = {
        "frozen_case": {
            "subset_index": 0,
            "subset": [list(d) for d in SUBSETS[0]],
            "load_profile": "all_one",
            "state_profile": "all_zero",
            "clock_profile": "near_wrap",
        },
        "runs": controls,
    }

    acceptance = {
        "trajectory_count_448": primary_trajectories == 448,
        "scored_tick_count_896": primary_scored_ticks == 896,
        "case_rows_448": len(rows) == 448,
        "all_cases_pass": all(row["case_status"] == "PASS" for row in rows),
        "zero_domain_failures": not any(m["scope"] == "domain" for m in mismatches),
        "state_clock_projection_invariance": len(invariance_failures) == 0,
        "inverse_outputs_8": len(inverse_fibers) == 8,
        "inverse_histogram_all_7": all(inverse_histogram[vec_text(d)] == 7 for d in BODY8),
        "inverse_unique_subsets_56": len(set().union(*inverse_fibers.values())) == 56,
        "all_engine_controls_pass": len(controls) == 4 and all(c["status"] == "PASS" for c in controls),
        "zero_mismatches": len(mismatches) == 0,
    }
    result["acceptance"] = acceptance


def main() -> int:
    parser = argparse.ArgumentParser(description="Run frozen T11 inverse-majority holdout")
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    protected = (ROSETTA / "HOLDOUTS").resolve()
    if out == protected or protected in out.parents:
        raise SystemExit("Refusing to write inside frozen HOLDOUTS")
    known_outputs = [out / "t11_result.json", out / "t11_cases.csv", out / "t11_mismatches.csv", out / "HASHES.sha256"]
    if any(path.exists() for path in known_outputs):
        raise SystemExit(f"Refusing to overwrite an existing T11 result set: {out}")

    rows: list[dict[str, Any]] = []
    mismatches: list[dict[str, str]] = []
    identity, preflight_errors = preflight()
    result: dict[str, Any] = {
        "schema": "dee.rosetta.t11.inverse_majority.v1",
        "test": "T11_POST_FREEZE_INVERSE_MAJORITY",
        "started_utc": utc_now(),
        "epistemic_status": "post_freeze_prediction_no_refit",
        "contract_sha256": EXPECTED_HASHES["contract"],
        "preregister_sha256": EXPECTED_HASHES["preregister"],
        "identity": identity,
        "technical_errors": [],
    }

    if preflight_errors:
        result["technical_errors"] = preflight_errors
        result["verdict"] = "INVALID_RUN"
        result["finished_utc"] = utc_now()
        finalize(out, result, rows, mismatches)
        print(json.dumps({"verdict": result["verdict"], "technical_errors": preflight_errors, "output": str(out)}, indent=2))
        return 3

    try:
        kernel = import_kernel(identity)
        run_science(kernel, result, rows, mismatches)
        result["mismatch_count"] = len(mismatches)
        result["verdict"] = "PASS" if all(result["acceptance"].values()) else "FAIL"
    except Exception as exc:
        result["technical_errors"].append({
            "type": type(exc).__name__,
            "message": str(exc),
            "traceback": traceback.format_exc(),
        })
        result["mismatch_count"] = len(mismatches)
        result["verdict"] = "INVALID_RUN"

    result["finished_utc"] = utc_now()
    finalize(out, result, rows, mismatches)
    print(json.dumps({
        "verdict": result["verdict"],
        "primary_trajectories": result.get("counts", {}).get("primary_trajectories", 0),
        "primary_scored_ticks": result.get("counts", {}).get("primary_scored_ticks", 0),
        "mismatches": len(mismatches),
        "technical_errors": len(result["technical_errors"]),
        "output": str(out),
    }, indent=2))
    return 0 if result["verdict"] == "PASS" else (2 if result["verdict"] == "FAIL" else 3)


if __name__ == "__main__":
    raise SystemExit(main())
