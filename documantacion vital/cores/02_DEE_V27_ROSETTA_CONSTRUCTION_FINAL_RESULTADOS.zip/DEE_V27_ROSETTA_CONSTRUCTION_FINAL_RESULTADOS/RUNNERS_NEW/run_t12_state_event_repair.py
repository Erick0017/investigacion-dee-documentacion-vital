#!/usr/bin/env python3
"""One-shot executor for sealed T12 state-event repair holdout.

No T10/T11 artifact or frozen input is modified. Scientific execution starts
only after every bound identity, seal, runtime and import path is verified.
"""
from __future__ import annotations

import ast
import csv
import hashlib
import importlib
import itertools
import json
import platform
import sys
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

import numpy as np


HERE = Path(__file__).resolve()
ROSETTA = HERE.parents[1]
V1 = ROSETTA.parent
TESTS = V1.parent
HOLDOUTS = ROSETTA / "HOLDOUTS"
ORIGINAL_CONTRACT = HOLDOUTS / "ROSETTA_FROZEN_CONTRACT.json"
T10_PREREG = HOLDOUTS / "PREREGISTER_T10_ROSETTA_CORE.md"
T10_RESULT = ROSETTA / "RESULTS" / "t10_rosetta_core" / "t10_result.json"
T12_PREREG = HOLDOUTS / "PREREGISTER_T12_STATE_EVENT_REPAIR.md"
T12_PREREG_SEAL = HOLDOUTS / "PREREGISTER_T12_STATE_EVENT_REPAIR.sha256"
REPAIR_CONTRACT = HOLDOUTS / "POST_T10_REPAIR_CONTRACT.json"
REPAIR_CONTRACT_SEAL = HOLDOUTS / "POST_T10_REPAIR_CONTRACT.sha256"
EXTRACTED = V1 / "ANALYSIS" / "binary_api" / "wheel_extracted"
PKG = EXTRACTED / "dee_universe_v27"
WHEEL = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
KERNEL_FILE = PKG / "dee_kernel_v27.cp313-win_amd64.pyd"
SOURCE_FILE = PKG / "dee_kernel_v27.cpp"
OUTDIR = ROSETTA / "RESULTS" / "t12_state_event_repair"
RESULT_JSON = OUTDIR / "t12_result.json"
CASES_CSV = OUTDIR / "t12_cases.csv"
MISMATCHES_CSV = OUTDIR / "t12_mismatches.csv"
MANIFEST = OUTDIR / "t12_SHA256SUMS.txt"

EXPECTED = {
    "original_contract": "d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157",
    "t10_preregister": "2bb574fc1cea3e6fc00f92d63848885ac8600200be116dbddb8b305115da871f",
    "t10_result": "a150acbd92347be9ff5b4624a7eb7560017755698ba211dac58318b67c508872",
    "t12_preregister": "ff5bc18b2be29cb8728f9c9003ab651cec1464eaf3a425963b59e151c0d2209f",
    "repair_contract": "b5f08d8ceb3368acb8b0183b9ebeb46e6d5da25efd30e8853af98eb65cef211f",
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "kernel_pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
    "kernel_cpp": "44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab",
}

N = 19
TARGET = (9, 9, 9)
SEED_TAG = 27_120_517
CLOCK_STRIDE = 104_729
CAP = 19_664
UINT64_MAX = (1 << 64) - 1
D0 = (0, 0, 0)
D26 = tuple(d for d in itertools.product((-1, 0, 1), repeat=3) if d != D0)
D26_SET = frozenset(D26)
SEMANTICS = (1, 3, 5, 14)
ARITIES = (3, 4, 6)
CONTROL_VARIANTS = (("lazy", 1), ("lazy", 2), ("dense", 1), ("dense", 2))

# Canonical record: qx,qy,qz,dx,dy,dz,s,a,p.
Record = tuple[int, int, int, int, int, int, int, int, int]

CASE_FIELDS = (
    "run_role", "case_index", "case_id", "case_class", "arity", "subset_rank",
    "engine", "threads", "input_slice_tick", "scored_tick", "u", "S",
    "load_profile", "clock_profile", "domain_ok", "domain_N_ok",
    "domain_directions_ok", "domain_positive_sites_ok",
    "domain_neighbour_cap_ok", "positive_sites",
    "max_positive_moore_neighbours", "input_alignment", "closure_equal",
    "event_equal", "movement_or_death_equal", "clock_equal", "copyback",
    "input_projection_sha256", "predicted_projection_sha256",
    "actual_projection_sha256", "raw_after_sha256", "clock_after_sha256",
    "overflows", "genesis", "engine_matches_primary",
)
MISMATCH_FIELDS = (
    "category", "case_index", "case_id", "tick", "expected", "actual", "detail",
)


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    return hashlib.sha256(memoryview(np.ascontiguousarray(array)).cast("B")).hexdigest()


def stable_hash(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 0xF) << 48)
        | ((d[1] & 0xF) << 52)
        | ((d[2] & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def decode(raw: int | np.uint64) -> tuple[int, int, tuple[int, int, int], int]:
    value = int(raw)

    def signed_nibble(shift: int) -> int:
        nibble = (value >> shift) & 0xF
        return nibble - 16 if nibble & 8 else nibble

    return (
        value & 0xFFFFFFFF,
        (value >> 32) & 0xFFFF,
        (signed_nibble(48), signed_nibble(52), signed_nibble(56)),
        (value >> 60) & 0xF,
    )


def flat_index(q: tuple[int, int, int]) -> int:
    return (q[0] * N + q[1]) * N + q[2]


def add(q: tuple[int, int, int], d: tuple[int, int, int], scale: int = 1) -> tuple[int, int, int]:
    return tuple((q[axis] + scale * d[axis]) % N for axis in range(3))


def put(grid: np.ndarray, q: tuple[int, int, int], word: np.uint64) -> None:
    grid[flat_index(q)] = word


def make_record(q: tuple[int, int, int], d: tuple[int, int, int], s: int, a: int, p: int) -> Record:
    return (q[0], q[1], q[2], d[0], d[1], d[2], int(s), int(a), int(p))


def record_q(record: Record) -> tuple[int, int, int]:
    return record[:3]


def record_d(record: Record) -> tuple[int, int, int]:
    return record[3:6]


def records_json(records: Iterable[Record]) -> list[list[int]]:
    return [list(record) for record in sorted(records)]


def project_m(grid: np.ndarray) -> tuple[Record, ...]:
    records: list[Record] = []
    for index in np.flatnonzero(grid != 0):
        state, sreg, d, semantic = decode(grid[int(index)])
        if not (state > 0 or d in D26_SET or semantic == 4):
            continue
        q_values = np.unravel_index(int(index), (N, N, N))
        q = tuple(int(value) for value in q_values)
        a = int(state > 0)
        p = int(semantic == 4)
        if p == 0 and a == 1 and d == D0:
            sreg = 0
        records.append(make_record(q, d, sreg, a, p))
    return tuple(sorted(records))


def sign_vector(directions: Iterable[tuple[int, int, int]]) -> tuple[int, int, int]:
    directions = tuple(directions)
    sums = tuple(sum(d[axis] for d in directions) for axis in range(3))
    return tuple(1 if value > 0 else (-1 if value < 0 else 0) for value in sums)


def exact_sum(directions: Iterable[tuple[int, int, int]]) -> tuple[int, int, int]:
    directions = tuple(directions)
    return tuple(sum(d[axis] for d in directions) for axis in range(3))


def g_dagger(records: tuple[Record, ...]) -> tuple[tuple[Record, ...], tuple[tuple[int, int, int, int, int, int, int], ...]]:
    """Return repaired canonical state and raw collision events (q,u,S)."""
    by_q = {record_q(record): record for record in records}
    output: dict[tuple[int, int, int], Record] = {}
    proposals: dict[tuple[int, int, int], list[tuple[tuple[int, int, int], int]]] = defaultdict(list)
    events: list[tuple[int, int, int, int, int, int]] = []
    for record in records:
        q = record_q(record)
        d = record_d(record)
        s, a, p = record[6], record[7], record[8]
        if p == 1:
            output[q] = record
        if d in D26_SET:
            proposals[add(q, d)].append((d, s))

    for target, incoming in proposals.items():
        prior = by_q.get(target)
        closed = prior is not None and (prior[7] == 1 or prior[8] == 1)
        if closed:
            continue
        if len(incoming) == 1:
            d_out, s_out = incoming[0]
        else:
            d_out = sign_vector(item[0] for item in incoming)
            s_out = min(sum(item[1] for item in incoming), CAP)
            events.append((*target, *d_out, s_out))
        canonical_s = 0 if d_out == D0 else s_out
        output[target] = make_record(target, d_out, canonical_s, 1, 0)
    return tuple(sorted(output.values())), tuple(sorted(events))


def enumerate_frozen_cases() -> list[dict[str, Any]]:
    zero_cases: dict[int, list[tuple[tuple[int, int, int], ...]]] = {}
    control_cases: dict[int, list[tuple[tuple[int, int, int], ...]]] = {}
    for arity in ARITIES:
        zeros: list[tuple[tuple[int, int, int], ...]] = []
        limit = 256 if arity == 6 else None
        for subset in itertools.combinations(D26, arity):
            if exact_sum(subset) == D0:
                zeros.append(subset)
                if limit is not None and len(zeros) == limit:
                    break
        zero_cases[arity] = zeros

        selected: list[tuple[tuple[int, int, int], ...]] = []
        by_output: Counter[tuple[int, int, int]] = Counter()
        for subset in itertools.combinations(D26, arity):
            u = sign_vector(subset)
            if u == D0 or by_output[u] >= 3:
                continue
            selected.append(subset)
            by_output[u] += 1
            if len(by_output) == 26 and all(by_output[d] == 3 for d in D26):
                break
        control_cases[arity] = selected
        if set(by_output) != D26_SET or any(by_output[d] != 3 for d in D26):
            raise RuntimeError(f"nonzero control enumeration incomplete at arity {arity}: {by_output}")

    expected_zero = {3: 44, 4: 214, 6: 256}
    if {arity: len(values) for arity, values in zero_cases.items()} != expected_zero:
        raise RuntimeError(f"zero-subset count mismatch: { {k: len(v) for k, v in zero_cases.items()} }")
    if any(len(control_cases[arity]) != 78 for arity in ARITIES):
        raise RuntimeError(f"control-subset count mismatch: { {k: len(v) for k, v in control_cases.items()} }")

    ordered: list[tuple[str, int, tuple[tuple[int, int, int], ...], int]] = []
    for arity in ARITIES:
        ordered.extend(("zero", arity, subset, rank) for rank, subset in enumerate(zero_cases[arity]))
    for arity in ARITIES:
        ordered.extend(("nonzero_control", arity, subset, rank) for rank, subset in enumerate(control_cases[arity]))

    cases: list[dict[str, Any]] = []
    for case_index, (case_class, arity, subset, subset_rank) in enumerate(ordered):
        loads = tuple(range(1, arity + 1)) if case_index % 2 == 0 else (CAP,) + (65_535,) * (arity - 1)
        semantics = tuple(SEMANTICS[j % len(SEMANTICS)] for j in range(arity))
        u = sign_vector(subset)
        S = min(sum(loads), CAP)
        case = {
            "case_index": case_index,
            "case_id": f"T12|r={case_index:03d}|class={case_class}|k={arity}|rank={subset_rank:03d}",
            "case_class": case_class,
            "arity": arity,
            "subset_rank": subset_rank,
            "directions": subset,
            "loads": loads,
            "semantics": semantics,
            "u": u,
            "S": S,
            "load_profile": "j_plus_one" if case_index % 2 == 0 else "first_19664_rest_65535",
            "clock_profile": "frozen_heterogeneous" if case_index % 2 == 0 else "frozen_near_wrap",
        }
        cases.append(case)

    counts = Counter("zero" if case["u"] == D0 else "nonzero" for case in cases)
    if len(cases) != 748 or counts != Counter({"zero": 514, "nonzero": 234}):
        raise RuntimeError(f"final case count mismatch: total={len(cases)}, classes={counts}")
    return cases


def prepare_case(case: dict[str, Any]) -> tuple[np.ndarray, np.ndarray]:
    grid = np.zeros(N**3, dtype=np.uint64)
    clocks = np.zeros(N**3, dtype=np.uint64)
    r = int(case["case_index"])
    for j, (d, sreg, semantic) in enumerate(zip(case["directions"], case["loads"], case["semantics"])):
        source = add(TARGET, d, -1)
        put(grid, source, pack(0, sreg, d, semantic))
        if r % 2 == 0:
            clocks[flat_index(source)] = np.uint64((SEED_TAG + CLOCK_STRIDE * r + 17 * j) & UINT64_MAX)
        else:
            clocks[flat_index(source)] = np.uint64(UINT64_MAX - (j % 3))
    if r % 2 == 0:
        # The frozen expression contains j for both sources and target; the
        # natural next enumeration index j=k is used for the target.
        clocks[flat_index(TARGET)] = np.uint64((SEED_TAG + CLOCK_STRIDE * r + 17 * case["arity"]) & UINT64_MAX)
    else:
        clocks[flat_index(TARGET)] = np.uint64(UINT64_MAX - 1)
    return grid, clocks


def domain_check(grid: np.ndarray) -> dict[str, Any]:
    decoded_by_q: dict[tuple[int, int, int], tuple[int, int, tuple[int, int, int], int]] = {}
    positive: set[tuple[int, int, int]] = set()
    directions_ok = True
    for index in np.flatnonzero(grid != 0):
        decoded = decode(grid[int(index)])
        q_values = np.unravel_index(int(index), (N, N, N))
        q = tuple(int(value) for value in q_values)
        decoded_by_q[q] = decoded
        state, _s, d, _semantic = decoded
        directions_ok = directions_ok and (d == D0 or d in D26_SET)
        if state > 0:
            positive.add(q)
    neighbour_counts = []
    for q in positive:
        if decoded_by_q[q][3] == 4:
            continue
        neighbour_counts.append(sum(1 for d in D26 if add(q, d) in positive))
    maximum = max(neighbour_counts, default=0)
    conditions = {
        "N_ok": N >= 5,
        "directions_ok": directions_ok,
        "positive_sites_ok": len(positive) <= 7,
        "neighbour_cap_ok": maximum <= 3,
    }
    return {
        **conditions,
        "ok": all(conditions.values()),
        "positive_sites": len(positive),
        "positive_nonobserver_sites": len(neighbour_counts),
        "max_positive_moore_neighbours": maximum,
    }


class Simulator:
    def __init__(self, kernel: Any, grid: np.ndarray, clocks: np.ndarray, engine: str, threads: int) -> None:
        self.grid_a = np.ascontiguousarray(grid, dtype=np.uint64).copy()
        self.grid_b = np.zeros_like(self.grid_a)
        self.clock_a = np.ascontiguousarray(clocks, dtype=np.uint64).copy()
        self.clock_b = np.zeros_like(self.clock_a)
        self.kernel = kernel
        self.engine = engine
        self.threads = threads

    def step(self) -> dict[str, Any]:
        function = self.kernel.tick_universo_lazy if self.engine == "lazy" else self.kernel.tick_universo
        info = dict(function(self.grid_a, self.grid_b, self.clock_a, self.clock_b, N, self.threads))
        return {
            "copyback": bool(np.array_equal(self.grid_a, self.grid_b) and np.array_equal(self.clock_a, self.clock_b)),
            "info": {str(key): int(value) if isinstance(value, (int, np.integer)) else float(value)
                     for key, value in info.items()},
        }


class Context:
    def __init__(self) -> None:
        self.rows: list[dict[str, Any]] = []
        self.mismatches: list[dict[str, Any]] = []
        self.assertions = 0
        self.kernel_ticks = 0
        self.domain_checks = 0
        self.domain_failures = 0

    def check(
        self,
        condition: bool,
        category: str,
        case: dict[str, Any],
        tick: int | str,
        expected: Any,
        actual: Any,
        detail: str = "",
    ) -> bool:
        self.assertions += 1
        if not condition:
            self.mismatches.append({
                "category": category,
                "case_index": case["case_index"],
                "case_id": case["case_id"],
                "tick": tick,
                "expected": expected,
                "actual": actual,
                "detail": detail,
            })
        return condition


def expected_raw(case: dict[str, Any], tick: int) -> np.ndarray:
    expected = np.zeros(N**3, dtype=np.uint64)
    if tick == 1:
        put(expected, TARGET, pack(1, case["S"], case["u"], 1))
    elif tick == 2 and case["u"] != D0:
        put(expected, add(TARGET, case["u"]), pack(1, case["S"], case["u"], 1))
    return expected


def run_primary_case(ctx: Context, kernel: Any, case: dict[str, Any], keep_snapshots: bool) -> list[dict[str, Any]]:
    grid, initial_clock = prepare_case(case)
    sim = Simulator(kernel, grid, initial_clock, "lazy", 1)
    model = project_m(grid)
    trace: list[dict[str, Any]] = []
    for tick in (1, 2):
        domain = domain_check(sim.grid_a)
        ctx.domain_checks += 1
        if not domain["ok"]:
            ctx.domain_failures += 1
            ctx.check(False, "DOMAIN_FAILURE", case, tick - 1, True, False, json.dumps(domain, sort_keys=True))

        binary_input = project_m(sim.grid_a)
        input_alignment = binary_input == model
        ctx.check(input_alignment, "ITERATED_INPUT_ALIGNMENT", case, tick - 1,
                  records_json(model), records_json(binary_input))
        predicted, events = g_dagger(model)
        meta = sim.step()
        ctx.kernel_ticks += 1
        actual = project_m(sim.grid_a)
        closure_equal = actual == predicted
        ctx.check(closure_equal, "PROJECTED_CLOSURE", case, tick,
                  records_json(predicted), records_json(actual))

        expected_grid = expected_raw(case, tick)
        if tick == 1:
            expected_events = ((*TARGET, *case["u"], case["S"]),)
            model_event_equal = events == expected_events
            ctx.check(model_event_equal, "MODEL_EVENT_J_DAGGER", case, tick,
                      expected_events, events, "G_dagger transition-event readout")
            raw_event_equal = np.array_equal(sim.grid_a, expected_grid)
            event_equal = model_event_equal and raw_event_equal
            movement_equal: bool | str = ""
            actual_word = decode(sim.grid_a[flat_index(TARGET)])
            event_detail = {
                "J_expected": [*TARGET, *case["u"], case["S"]],
                "raw_target_decoded": {
                    "state": actual_word[0], "s": actual_word[1],
                    "d": list(actual_word[2]), "semantic": actual_word[3],
                },
            }
            ctx.check(raw_event_equal, "RAW_EVENT_J_DAGGER", case, tick,
                      sha256_array(expected_grid), sha256_array(sim.grid_a), json.dumps(event_detail, sort_keys=True))
        else:
            event_equal = ""
            ctx.check(events == (), "UNEXPECTED_MODEL_EVENT", case, tick, (), events,
                      "tick 2 has at most one proposal source")
            movement_equal = np.array_equal(sim.grid_a, expected_grid)
            ctx.check(bool(movement_equal), "MOVEMENT_OR_DEATH", case, tick,
                      sha256_array(expected_grid), sha256_array(sim.grid_a),
                      "u=0 must die; u!=0 must translate once with u,S")

        expected_clock = np.add(initial_clock, np.uint64(tick), dtype=np.uint64)
        clock_equal = np.array_equal(sim.clock_a, expected_clock)
        ctx.check(clock_equal, "CLOCK", case, tick,
                  sha256_array(expected_clock), sha256_array(sim.clock_a))
        ctx.check(meta["copyback"], "ENGINE_COPYBACK", case, tick, True, meta["copyback"])
        overflows = int(meta["info"].get("overflows", 0))
        genesis = int(meta["info"].get("genesis", 0))
        ctx.check(overflows == 0, "UNEXPECTED_OVERFLOW", case, tick, 0, overflows)
        ctx.check(genesis == 0, "UNEXPECTED_GENESIS", case, tick, 0, genesis)

        row = {
            "run_role": "primary",
            "case_index": case["case_index"],
            "case_id": case["case_id"],
            "case_class": case["case_class"],
            "arity": case["arity"],
            "subset_rank": case["subset_rank"],
            "engine": "lazy",
            "threads": 1,
            "input_slice_tick": tick - 1,
            "scored_tick": tick,
            "u": json.dumps(case["u"]),
            "S": case["S"],
            "load_profile": case["load_profile"],
            "clock_profile": case["clock_profile"],
            "domain_ok": domain["ok"],
            "domain_N_ok": domain["N_ok"],
            "domain_directions_ok": domain["directions_ok"],
            "domain_positive_sites_ok": domain["positive_sites_ok"],
            "domain_neighbour_cap_ok": domain["neighbour_cap_ok"],
            "positive_sites": domain["positive_sites"],
            "max_positive_moore_neighbours": domain["max_positive_moore_neighbours"],
            "input_alignment": input_alignment,
            "closure_equal": closure_equal,
            "event_equal": event_equal,
            "movement_or_death_equal": movement_equal,
            "clock_equal": clock_equal,
            "copyback": meta["copyback"],
            "input_projection_sha256": stable_hash(records_json(binary_input)),
            "predicted_projection_sha256": stable_hash(records_json(predicted)),
            "actual_projection_sha256": stable_hash(records_json(actual)),
            "raw_after_sha256": sha256_array(sim.grid_a),
            "clock_after_sha256": sha256_array(sim.clock_a),
            "overflows": overflows,
            "genesis": genesis,
            "engine_matches_primary": "",
        }
        ctx.rows.append(row)
        entry = {
            "tick": tick,
            "raw_sha256": row["raw_after_sha256"],
            "clock_sha256": row["clock_after_sha256"],
            "actual": actual,
        }
        if keep_snapshots:
            entry["raw"] = sim.grid_a.copy()
            entry["clock"] = sim.clock_a.copy()
        trace.append(entry)
        model = predicted
    return trace


def run_engine_control(
    ctx: Context,
    kernel: Any,
    case: dict[str, Any],
    reference: list[dict[str, Any]],
    engine: str,
    threads: int,
) -> bool:
    grid, initial_clock = prepare_case(case)
    sim = Simulator(kernel, grid, initial_clock, engine, threads)
    trajectory_equal = True
    for tick in (1, 2):
        domain = domain_check(sim.grid_a)
        ctx.domain_checks += 1
        if not domain["ok"]:
            ctx.domain_failures += 1
            ctx.check(False, "DOMAIN_FAILURE_CONTROL", case, tick - 1, True, False,
                      f"{engine}/{threads}: {json.dumps(domain, sort_keys=True)}")
        meta = sim.step()
        ctx.kernel_ticks += 1
        equal = (
            np.array_equal(sim.grid_a, reference[tick - 1]["raw"])
            and np.array_equal(sim.clock_a, reference[tick - 1]["clock"])
        )
        trajectory_equal = trajectory_equal and equal
        ctx.check(equal, "ENGINE_CONTROL", case, tick, "exact primary raw+clock",
                  "equal" if equal else "different", f"{engine}/{threads}")
        ctx.check(meta["copyback"], "ENGINE_COPYBACK_CONTROL", case, tick, True, meta["copyback"],
                  f"{engine}/{threads}")
        expected_clock = np.add(initial_clock, np.uint64(tick), dtype=np.uint64)
        clock_equal = np.array_equal(sim.clock_a, expected_clock)
        ctx.check(clock_equal, "CLOCK_CONTROL", case, tick,
                  sha256_array(expected_clock), sha256_array(sim.clock_a), f"{engine}/{threads}")
        ctx.rows.append({
            "run_role": "engine_control",
            "case_index": case["case_index"],
            "case_id": case["case_id"],
            "case_class": case["case_class"],
            "arity": case["arity"],
            "subset_rank": case["subset_rank"],
            "engine": engine,
            "threads": threads,
            "input_slice_tick": tick - 1,
            "scored_tick": tick,
            "u": json.dumps(case["u"]),
            "S": case["S"],
            "load_profile": case["load_profile"],
            "clock_profile": case["clock_profile"],
            "domain_ok": domain["ok"],
            "domain_N_ok": domain["N_ok"],
            "domain_directions_ok": domain["directions_ok"],
            "domain_positive_sites_ok": domain["positive_sites_ok"],
            "domain_neighbour_cap_ok": domain["neighbour_cap_ok"],
            "positive_sites": domain["positive_sites"],
            "max_positive_moore_neighbours": domain["max_positive_moore_neighbours"],
            "input_alignment": "",
            "closure_equal": "",
            "event_equal": "",
            "movement_or_death_equal": "",
            "clock_equal": clock_equal,
            "copyback": meta["copyback"],
            "input_projection_sha256": "",
            "predicted_projection_sha256": "",
            "actual_projection_sha256": stable_hash(records_json(project_m(sim.grid_a))),
            "raw_after_sha256": sha256_array(sim.grid_a),
            "clock_after_sha256": sha256_array(sim.clock_a),
            "overflows": int(meta["info"].get("overflows", 0)),
            "genesis": int(meta["info"].get("genesis", 0)),
            "engine_matches_primary": equal,
        })
    return trajectory_equal


def verify_seal(path: Path, expected_hash: str, expected_name: str) -> None:
    tokens = path.read_text(encoding="ascii").strip().split()
    if len(tokens) != 2 or tokens[0].lower() != expected_hash or tokens[1].lstrip("*") != expected_name:
        raise RuntimeError(f"invalid seal {path}: {tokens}")


def verify_identity_and_import() -> tuple[dict[str, Any], Any]:
    # Syntax is validated without importing or executing the scientific module.
    ast.parse(HERE.read_text(encoding="utf-8"), filename=str(HERE))
    paths = {
        "original_contract": ORIGINAL_CONTRACT,
        "t10_preregister": T10_PREREG,
        "t10_result": T10_RESULT,
        "t12_preregister": T12_PREREG,
        "repair_contract": REPAIR_CONTRACT,
        "wheel": WHEEL,
        "kernel_pyd": KERNEL_FILE,
        "kernel_cpp": SOURCE_FILE,
    }
    observed = {name: sha256_file(path) for name, path in paths.items()}
    failures = {name: {"expected": EXPECTED[name], "actual": observed[name]}
                for name in EXPECTED if observed[name] != EXPECTED[name]}
    if failures:
        raise RuntimeError(f"identity mismatch: {json.dumps(failures, sort_keys=True)}")
    verify_seal(T12_PREREG_SEAL, EXPECTED["t12_preregister"], T12_PREREG.name)
    verify_seal(REPAIR_CONTRACT_SEAL, EXPECTED["repair_contract"], REPAIR_CONTRACT.name)
    if sys.version_info[:2] != (3, 13) or platform.architecture()[0] != "64bit":
        raise RuntimeError(f"runtime mismatch: {sys.version}; {platform.architecture()[0]}")

    repair = json.loads(REPAIR_CONTRACT.read_text(encoding="utf-8"))
    if repair.get("status") != "FROZEN_POST_T10_PRE_T12" or repair.get("mutable") is not False:
        raise RuntimeError("repair contract is not immutable FROZEN_POST_T10_PRE_T12")
    contract_identity = repair.get("identity", {})
    bindings = {
        "original_contract_sha256": EXPECTED["original_contract"],
        "t10_preregister_sha256": EXPECTED["t10_preregister"],
        "t10_result_sha256": EXPECTED["t10_result"],
        "t12_preregister_sha256": EXPECTED["t12_preregister"],
        "wheel_sha256": EXPECTED["wheel"],
        "kernel_pyd_sha256": EXPECTED["kernel_pyd"],
        "kernel_cpp_sha256": EXPECTED["kernel_cpp"],
    }
    if any(contract_identity.get(key) != value for key, value in bindings.items()):
        raise RuntimeError("repair contract identity bindings do not match sealed expectations")
    t10 = json.loads(T10_RESULT.read_text(encoding="utf-8"))
    if t10.get("verdict") != "FAIL":
        raise RuntimeError(f"bound T10 result no longer reports FAIL: {t10.get('verdict')}")

    sys.path.insert(0, str(EXTRACTED))
    package = importlib.import_module("dee_universe_v27")
    kernel = importlib.import_module("dee_universe_v27.dee_kernel_v27")
    if Path(package.__file__).resolve().parent != PKG.resolve():
        raise RuntimeError(f"wrong package import: {package.__file__}")
    if Path(kernel.__file__).resolve() != KERNEL_FILE.resolve():
        raise RuntimeError(f"wrong kernel import: {kernel.__file__}")
    observed.update({
        "runner": sha256_file(HERE),
        "ast_valid": True,
        "t12_preregister_seal_valid": True,
        "repair_contract_seal_valid": True,
        "python": sys.version,
        "executable": sys.executable,
        "architecture": platform.architecture()[0],
        "numpy": np.__version__,
        "package_path": str(Path(package.__file__).resolve()),
        "kernel_path": str(Path(kernel.__file__).resolve()),
        "kernel_version": str(kernel.VERSION),
        "all_exact": True,
    })
    return observed, kernel


def csv_safe(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True, separators=(",", ":"))
    return value


def write_outputs(result: dict[str, Any], ctx: Context) -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    with CASES_CSV.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=CASE_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in ctx.rows:
            writer.writerow({key: csv_safe(row.get(key, "")) for key in CASE_FIELDS})
    with MISMATCHES_CSV.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=MISMATCH_FIELDS, extrasaction="ignore")
        writer.writeheader()
        for row in ctx.mismatches:
            writer.writerow({key: csv_safe(row.get(key, "")) for key in MISMATCH_FIELDS})
    RESULT_JSON.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    manifest_entries = (
        (RESULT_JSON, "t12_result.json"),
        (CASES_CSV, "t12_cases.csv"),
        (MISMATCHES_CSV, "t12_mismatches.csv"),
        (HERE, "../../RUNNERS_NEW/run_t12_state_event_repair.py"),
        (T12_PREREG, "../../HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.md"),
        (T12_PREREG_SEAL, "../../HOLDOUTS/PREREGISTER_T12_STATE_EVENT_REPAIR.sha256"),
        (REPAIR_CONTRACT, "../../HOLDOUTS/POST_T10_REPAIR_CONTRACT.json"),
        (REPAIR_CONTRACT_SEAL, "../../HOLDOUTS/POST_T10_REPAIR_CONTRACT.sha256"),
        (ORIGINAL_CONTRACT, "../../HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json"),
        (T10_PREREG, "../../HOLDOUTS/PREREGISTER_T10_ROSETTA_CORE.md"),
        (T10_RESULT, "../t10_rosetta_core/t10_result.json"),
        (WHEEL, "../../../../dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"),
        (KERNEL_FILE, "../../../ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd"),
        (SOURCE_FILE, "../../../ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cpp"),
    )
    MANIFEST.write_text(
        "".join(f"{sha256_file(path)}  {label}\n" for path, label in manifest_entries),
        encoding="ascii",
    )


def main() -> int:
    # Identity/import errors intentionally abort before OUTDIR creation or any
    # scientific result. Do not wrap this call in a permissive fallback.
    identity, kernel = verify_identity_and_import()
    cases = enumerate_frozen_cases()
    started = datetime.now(timezone.utc).isoformat()
    ctx = Context()

    first_zero_k3 = next(case for case in cases if case["case_class"] == "zero" and case["arity"] == 3)
    first_zero_k6 = next(case for case in cases if case["case_class"] == "zero" and case["arity"] == 6)
    first_nonzero_k3 = next(case for case in cases if case["case_class"] == "nonzero_control" and case["arity"] == 3)
    last_nonzero_k6 = next(case for case in reversed(cases) if case["case_class"] == "nonzero_control" and case["arity"] == 6)
    selected_control_indices = {
        first_zero_k3["case_index"], first_zero_k6["case_index"],
        first_nonzero_k3["case_index"], last_nonzero_k6["case_index"],
    }
    primary_references: dict[int, list[dict[str, Any]]] = {}
    for case in cases:
        trace = run_primary_case(ctx, kernel, case, case["case_index"] in selected_control_indices)
        if case["case_index"] in selected_control_indices:
            primary_references[case["case_index"]] = trace

    control_trajectories: list[dict[str, Any]] = []
    cases_by_index = {case["case_index"]: case for case in cases}
    for case_index in (
        first_zero_k3["case_index"], first_zero_k6["case_index"],
        first_nonzero_k3["case_index"], last_nonzero_k6["case_index"],
    ):
        case = cases_by_index[case_index]
        for engine, threads in CONTROL_VARIANTS:
            equal = run_engine_control(ctx, kernel, case, primary_references[case_index], engine, threads)
            control_trajectories.append({
                "case_index": case_index,
                "case_id": case["case_id"],
                "engine": engine,
                "threads": threads,
                "full_raw_and_clock_equal_primary": equal,
            })

    counts = Counter("zero" if case["u"] == D0 else "nonzero" for case in cases)
    primary_rows = sum(1 for row in ctx.rows if row["run_role"] == "primary")
    control_rows = sum(1 for row in ctx.rows if row["run_role"] == "engine_control")
    ctx.check(len(cases) == 748, "PLANNED_COUNT", cases[0], 0, 748, len(cases), "primary trajectories")
    ctx.check(primary_rows == 1496, "PLANNED_COUNT", cases[0], 0, 1496, primary_rows, "primary ticks")
    ctx.check(counts["zero"] == 514, "PLANNED_COUNT", cases[0], 0, 514, counts["zero"], "u=0 cases")
    ctx.check(counts["nonzero"] == 234, "PLANNED_COUNT", cases[0], 0, 234, counts["nonzero"], "u!=0 controls")
    ctx.check(len(control_trajectories) == 16, "PLANNED_COUNT", cases[0], 0, 16,
              len(control_trajectories), "engine-control trajectories")
    ctx.check(control_rows == 32, "PLANNED_COUNT", cases[0], 0, 32, control_rows, "engine-control ticks")

    categories = Counter(str(row["category"]) for row in ctx.mismatches)
    verdict = "PASS" if not ctx.mismatches and ctx.domain_failures == 0 else "FAIL"
    result = {
        "schema": "dee.v27.rosetta.t12.state_event_repair.result.v1",
        "test": "T12_STATE_EVENT_REPAIR_FROZEN_HOLDOUT",
        "verdict": verdict,
        "started_utc": started,
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "one_shot_execution": True,
        "no_refit": True,
        "identity": identity,
        "frozen_design": {
            "N": N,
            "target": list(TARGET),
            "D26_order": [list(d) for d in D26],
            "arities": list(ARITIES),
            "semantics_cycle": list(SEMANTICS),
            "target_even_clock_index_interpretation": "j=k, the next index after the k ordered sources",
            "target_even_clock_caveat": "The preregistered expression includes j for sources and target but does not name the target's j; j=k is the direct enumeration continuation. This cannot affect raw, M_*, J_dagger or movement outcomes.",
        },
        "planned": {
            "primary_trajectories": 748,
            "primary_ticks": 1496,
            "u_zero_cases": 514,
            "u_nonzero_cases": 234,
            "engine_control_trajectories": 16,
            "engine_control_ticks": 32,
        },
        "observed": {
            "primary_trajectories": len(cases),
            "primary_ticks": primary_rows,
            "u_zero_cases": counts["zero"],
            "u_nonzero_cases": counts["nonzero"],
            "all_kernel_ticks": ctx.kernel_ticks,
            "domain_checks_before_slices": ctx.domain_checks,
            "domain_failures": ctx.domain_failures,
            "assertions": ctx.assertions,
            "mismatches": len(ctx.mismatches),
            "mismatch_categories": dict(categories),
        },
        "hypothesis_H12": {
            "projected_closure_ticks_1_2": categories["PROJECTED_CLOSURE"] == 0
                                                   and categories["ITERATED_INPUT_ALIGNMENT"] == 0,
            "raw_event_J_dagger_tick_1": categories["RAW_EVENT_J_DAGGER"] == 0,
            "movement_or_death_tick_2": categories["MOVEMENT_OR_DEATH"] == 0,
            "clock_nuisance_profiles": categories["CLOCK"] == 0,
            "semantic_nuisance_profiles": categories["PROJECTED_CLOSURE"] == 0,
            "engine_controls": categories["ENGINE_CONTROL"] == 0
                               and categories["CLOCK_CONTROL"] == 0,
            "pass": verdict == "PASS",
        },
        "engine_controls": {
            "selected_case_indices": [
                first_zero_k3["case_index"], first_zero_k6["case_index"],
                first_nonzero_k3["case_index"], last_nonzero_k6["case_index"],
            ],
            "trajectories": control_trajectories,
            "passed": sum(1 for item in control_trajectories if item["full_raw_and_clock_equal_primary"]),
            "total": len(control_trajectories),
        },
        "case_enumeration": {
            "zero_counts": {str(k): sum(1 for case in cases if case["arity"] == k and case["u"] == D0)
                            for k in ARITIES},
            "nonzero_counts": {str(k): sum(1 for case in cases if case["arity"] == k and case["u"] != D0)
                               for k in ARITIES},
            "nonzero_output_counts": {
                str(k): {str(list(d)): sum(1 for case in cases if case["arity"] == k and case["u"] == d)
                         for d in D26}
                for k in ARITIES
            },
        },
        "mismatch_sample": ctx.mismatches[:20],
        "ledgers": {
            "all_scored_slices": "t12_cases.csv",
            "all_mismatches": "t12_mismatches.csv",
            "sha256_manifest": "t12_SHA256SUMS.txt",
        },
        "acceptance": "PASS iff exact frozen counts, zero domain failures, zero closure/event/movement/clock/identity mismatches, and 16/16 engine controls",
    }
    write_outputs(result, ctx)
    print(json.dumps({
        "verdict": verdict,
        "primary_trajectories": len(cases),
        "primary_ticks": primary_rows,
        "u_zero_cases": counts["zero"],
        "u_nonzero_cases": counts["nonzero"],
        "all_kernel_ticks": ctx.kernel_ticks,
        "domain_failures": ctx.domain_failures,
        "engine_controls": f"{result['engine_controls']['passed']}/{result['engine_controls']['total']}",
        "mismatches": len(ctx.mismatches),
        "mismatch_categories": dict(categories),
        "output": str(RESULT_JSON),
    }, indent=2, sort_keys=True))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
