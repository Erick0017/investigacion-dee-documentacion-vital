#!/usr/bin/env node
/** Materialize and validate the Rosetta CSV ledgers through artifact_tool. */
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Workbook } from "@oai/artifact-tool";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);
const packageRoot = path.join(root, "FINAL_PACKAGE");

const claimFields = [
  "claim_id", "claim", "epistemic_class", "status", "scope", "phase",
  "preregistered", "method", "evidence_path", "evidence_sha256",
  "assumptions_limits", "external_status",
];
const experimentFields = [
  "experiment_id", "phase", "question", "status", "sample", "mismatches",
  "preregistered", "evidence_path", "evidence_sha256", "notes",
];

function sha256(text) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

function quoteCsv(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function a1Column(index) {
  let n = index + 1;
  let out = "";
  while (n > 0) {
    n -= 1;
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26);
  }
  return out;
}

async function workbookCsv(records, fields, sheetName) {
  for (const [rowIndex, record] of records.entries()) {
    if (!record || typeof record !== "object" || Array.isArray(record)) {
      throw new Error(`${sheetName} row ${rowIndex + 2} is not an object`);
    }
    const missing = fields.filter((field) => !Object.hasOwn(record, field));
    if (missing.length) throw new Error(`${sheetName} row ${rowIndex + 2} missing keys: ${missing}`);
    const unexpected = Object.keys(record).filter((key) => !fields.includes(key));
    if (unexpected.length) throw new Error(`${sheetName} row ${rowIndex + 2} unexpected keys: ${unexpected}`);
  }
  const matrix = [fields, ...records.map((record) => fields.map((field) => String(record[field] ?? "")))];

  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add(sheetName);
  sheet.getRangeByIndexes(0, 0, matrix.length, fields.length).values = matrix;
  const used = sheet.getUsedRange(true);
  if (!used) throw new Error(`${sheetName}: artifact_tool returned no used range`);
  const roundTrip = used.values;
  if (JSON.stringify(roundTrip) !== JSON.stringify(matrix)) {
    throw new Error(`${sheetName}: artifact_tool in-memory value mismatch`);
  }
  const end = `${a1Column(fields.length - 1)}${matrix.length}`;
  const inspection = await workbook.inspect({
    kind: "region",
    sheetId: sheetName,
    range: `A1:${end}`,
    maxChars: 5000,
    tableMaxRows: 4,
    tableMaxCols: fields.length,
    tableMaxCellChars: 80,
  });

  const csv = `${matrix.map((row) => row.map(quoteCsv).join(",")).join("\r\n")}\r\n`;
  const imported = await Workbook.fromCSV(csv, { sheetName: `${sheetName}_Reimport` });
  const importedSheet = imported.worksheets.getItem(`${sheetName}_Reimport`);
  const importedUsed = importedSheet.getUsedRange(true);
  if (!importedUsed) throw new Error(`${sheetName}: artifact_tool CSV reimport returned no range`);
  const importedValues = importedUsed.values;
  if (importedValues.length !== matrix.length || importedValues.some((row) => row.length !== fields.length)) {
    throw new Error(`${sheetName}: CSV dimensions changed on artifact_tool reimport`);
  }
  if (JSON.stringify(importedValues) !== JSON.stringify(matrix)) {
    let first = null;
    for (let row = 0; row < matrix.length && first === null; row += 1) {
      for (let col = 0; col < fields.length; col += 1) {
        if (String(importedValues[row][col] ?? "") !== String(matrix[row][col] ?? "")) {
          first = { row: row + 1, column: col + 1, expected: matrix[row][col], observed: importedValues[row][col] };
          break;
        }
      }
    }
    throw new Error(`${sheetName}: CSV values changed on artifact_tool reimport: ${JSON.stringify(first)}`);
  }
  return {
    csv,
    rowsIncludingHeader: matrix.length,
    columns: fields.length,
    inspectExcerpt: String(inspection?.ndjson ?? inspection).slice(0, 5000),
  };
}

const claimPayload = JSON.parse(await fs.readFile(path.join(packageRoot, "ROSETTA_CLAIM_LEDGER.json"), "utf8"));
const experimentPayload = JSON.parse(await fs.readFile(path.join(packageRoot, "EXPERIMENT_INDEX.json"), "utf8"));
if (claimPayload.claim_count !== claimPayload.claims.length) throw new Error("claim_count mismatch");
if (experimentPayload.experiment_count !== experimentPayload.experiments.length) throw new Error("experiment_count mismatch");

const claims = await workbookCsv(claimPayload.claims, claimFields, "Claims");
const experiments = await workbookCsv(experimentPayload.experiments, experimentFields, "Experiments");
await fs.writeFile(path.join(packageRoot, "ROSETTA_CLAIM_LEDGER.csv"), claims.csv, "utf8");
await fs.writeFile(path.join(packageRoot, "CLAIM_LEDGER.csv"), claims.csv, "utf8");
await fs.writeFile(path.join(packageRoot, "EXPERIMENT_INDEX.csv"), experiments.csv, "utf8");

const report = {
  schema: "dee.v27.rosetta.artifact_tool_csv_validation.v1",
  status: "PASS",
  library: "@oai/artifact-tool",
  validations: {
    claim_ledger: {
      data_rows: claimPayload.claims.length,
      rows_including_header: claims.rowsIncludingHeader,
      columns: claims.columns,
      csv_sha256: sha256(claims.csv),
      alias_byte_identical: true,
      artifact_tool_memory_roundtrip: true,
      artifact_tool_csv_reimport: true,
    },
    experiment_index: {
      data_rows: experimentPayload.experiments.length,
      rows_including_header: experiments.rowsIncludingHeader,
      columns: experiments.columns,
      csv_sha256: sha256(experiments.csv),
      artifact_tool_memory_roundtrip: true,
      artifact_tool_csv_reimport: true,
    },
  },
  inspection_excerpts: {
    claims: claims.inspectExcerpt,
    experiments: experiments.inspectExcerpt,
  },
};
await fs.mkdir(path.join(root, "RESULTS"), { recursive: true });
await fs.writeFile(path.join(root, "RESULTS", "ledger_validation.json"), `${JSON.stringify(report, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify(report.validations)}\n`);
