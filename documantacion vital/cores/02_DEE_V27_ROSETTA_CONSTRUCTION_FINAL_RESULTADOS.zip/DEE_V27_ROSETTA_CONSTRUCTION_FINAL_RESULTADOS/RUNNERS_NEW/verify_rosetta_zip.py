#!/usr/bin/env python3
"""Read-only parity verification of the final Rosetta ZIP."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path


PREFIX = "DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS"
HASH_RE = re.compile(r"^([0-9a-f]{64}) [ *](.+)$")


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--package-root", required=True)
    parser.add_argument("--zip", required=True)
    args = parser.parse_args()
    root, archive_path = Path(args.package_root).resolve(), Path(args.zip).resolve()
    live = sorted(path for path in root.rglob("*") if path.is_file()) if root.is_dir() else []
    live_names = {path.relative_to(root).as_posix() for path in live}
    mismatches: list[str] = []
    names: list[str] = []
    rows: dict[str, str] = {}
    manifest_rows: dict[str, tuple[int, str]] = {}
    bad_crc: str | None = None
    if not root.is_dir():
        mismatches.append("package_root_missing")
    if not archive_path.is_file():
        mismatches.append("zip_missing")
    try:
        with zipfile.ZipFile(archive_path) as archive:
            bad_crc = archive.testzip()
            names = archive.namelist()
            if len(set(names)) != len(names):
                mismatches.append("duplicate_zip_entry")
            rel_names_list: list[str] = []
            for name in names:
                if not name.startswith(PREFIX + "/") or name.endswith("/"):
                    mismatches.append("entry_prefix_or_directory")
                    continue
                relative = name[len(PREFIX) + 1 :]
                if not relative or "\\" in relative or any(part in {"", ".", ".."} for part in relative.split("/")):
                    mismatches.append("unsafe_zip_entry")
                    continue
                rel_names_list.append(relative)
            rel_names = set(rel_names_list)
            if len(rel_names) != len(names) or rel_names != live_names:
                mismatches.append("entry_set_or_prefix")

            def member(relative: str) -> bytes:
                return archive.read(f"{PREFIX}/{relative}")

            for line in member("HASHES.sha256").decode("utf-8").splitlines():
                match = HASH_RE.fullmatch(line)
                if not match or match.group(2) in rows:
                    mismatches.append("malformed_or_duplicate_hash_row")
                else:
                    rows[match.group(2)] = match.group(1)
            if set(rows) != rel_names - {"HASHES.sha256"}:
                mismatches.append("embedded_hash_set")
            for relative, expected in rows.items():
                if digest(member(relative)) != expected:
                    mismatches.append(f"embedded_hash:{relative}")

            manifest = json.loads(member("MANIFEST.json").decode("utf-8"))
            if (
                manifest.get("schema") != "dee.v27.rosetta.final_package.v1"
                or manifest.get("package") != PREFIX
                or manifest.get("status") != "COMPLETE"
                or manifest.get("scientific_verdict") != "ROSETTA_PARTIAL"
                or not isinstance(manifest.get("files"), list)
            ):
                mismatches.append("manifest_header_or_schema")
            for index, item in enumerate(manifest.get("files", [])):
                if not isinstance(item, dict):
                    mismatches.append(f"manifest_item_type:{index}")
                    continue
                relative = item.get("path")
                expected = item.get("sha256")
                expected_bytes = item.get("bytes")
                if (
                    not isinstance(relative, str)
                    or not relative
                    or "\\" in relative
                    or any(part in {"", ".", ".."} for part in relative.split("/"))
                    or not isinstance(expected, str)
                    or not re.fullmatch(r"[0-9a-f]{64}", expected)
                    or not isinstance(expected_bytes, int)
                    or expected_bytes < 0
                ):
                    mismatches.append(f"manifest_item_invalid:{index}")
                    continue
                if relative in manifest_rows:
                    mismatches.append(f"manifest_duplicate:{relative}")
                    continue
                manifest_rows[relative] = (expected_bytes, expected)
                data = member(relative)
                if len(data) != expected_bytes:
                    mismatches.append(f"manifest_bytes:{relative}")
                if digest(data) != expected:
                    mismatches.append(f"manifest_hash:{relative}")
            expected_manifest_set = rel_names - {"MANIFEST.json", "HASHES.sha256"}
            if set(manifest_rows) != expected_manifest_set:
                mismatches.append("manifest_entry_set")
            if manifest.get("file_count_excluding_manifest_and_hash_list") != len(manifest_rows):
                mismatches.append("manifest_file_count")
            if manifest.get("payload_bytes_excluding_manifest_and_hash_list") != sum(size for size, _ in manifest_rows.values()):
                mismatches.append("manifest_payload_bytes")

            for path in live:
                relative = path.relative_to(root).as_posix()
                if digest(member(relative)) != digest(path.read_bytes()):
                    mismatches.append(f"live_parity:{relative}")
    except (OSError, KeyError, ValueError, UnicodeError, json.JSONDecodeError, zipfile.BadZipFile) as exc:
        mismatches.append(f"archive_error:{type(exc).__name__}:{exc}")
    result = {
        "status": "PASS" if bad_crc is None and not mismatches else "FAIL",
        "zip_sha256": digest(archive_path.read_bytes()) if archive_path.is_file() else None,
        "zip_bytes": archive_path.stat().st_size if archive_path.is_file() else None,
        "entries": len(names),
        "embedded_hash_rows": len(rows),
        "manifest_rows": len(manifest_rows),
        "crc": "PASS" if bad_crc is None else f"FAIL:{bad_crc}",
        "live_package_parity": not any(item.startswith("live_parity") for item in mismatches),
        "mismatches": mismatches,
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
