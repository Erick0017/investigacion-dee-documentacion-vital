#!/usr/bin/env python3
"""Read-only byte-parity audit of the five importable v27 wheel payloads."""
from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path


PREFIX = "dee_universe_v27/"


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wheel", type=Path, required=True)
    parser.add_argument("--extracted", type=Path, required=True)
    args = parser.parse_args()
    wheel = args.wheel.resolve()
    extracted = args.extracted.resolve()
    if not wheel.is_file() or not extracted.is_dir():
        raise SystemExit("wheel or extracted package missing")

    with zipfile.ZipFile(wheel) as archive:
        members = sorted(
            name for name in archive.namelist()
            if name.startswith(PREFIX) and not name.endswith("/")
        )
        expected = {name.removeprefix(PREFIX): archive.read(name) for name in members}
    actual_paths = sorted(path for path in extracted.rglob("*") if path.is_file())
    actual_names = {path.relative_to(extracted).as_posix() for path in actual_paths}
    if actual_names != set(expected):
        raise SystemExit(json.dumps({
            "status": "FAIL",
            "missing": sorted(set(expected) - actual_names),
            "extra": sorted(actual_names - set(expected)),
        }))

    rows = []
    mismatches = []
    for name, wheel_bytes in expected.items():
        disk_bytes = (extracted / Path(name)).read_bytes()
        wheel_hash, disk_hash = digest(wheel_bytes), digest(disk_bytes)
        rows.append({"path": name, "bytes": len(wheel_bytes), "sha256": wheel_hash})
        if wheel_bytes != disk_bytes:
            mismatches.append({"path": name, "wheel_sha256": wheel_hash, "disk_sha256": disk_hash})
    result = {
        "status": "PASS" if not mismatches else "FAIL",
        "wheel": str(wheel),
        "extracted": str(extracted),
        "payload_count": len(rows),
        "payloads": rows,
        "mismatches": mismatches,
    }
    print(json.dumps(result, ensure_ascii=False))
    return 0 if not mismatches else 1


if __name__ == "__main__":
    raise SystemExit(main())
