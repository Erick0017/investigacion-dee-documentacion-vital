# DEE v27 multiscale emergence and Rosetta results

This is the single portable audit package for the completed campaign. The authoritative reports, state, ledgers, runners, holdouts, locks, checkpoints and evidence are under `tests/DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/MULTISCALE_ROSETTA_CLOSURE/`. The exact wheel and extracted binary runtime retain their original relative positions, so the frozen runners resolve them without source edits.

Run `REPRODUCE.ps1` from this directory for a non-mutating integrity audit. Scientific holdouts are not rerun by that audit. For an actual Windows kernel import, extract to a short path such as `C:\DEE27`; the CPython 3.13 native DLL loader can reject deeply nested paths even when all content hashes are correct.
