param()

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

function Get-DeeStreamSha256 {
    param([System.IO.Stream]$Stream)
    $deeSha = [Security.Cryptography.SHA256]::Create()
    try {
        $deeBytes = $deeSha.ComputeHash($Stream)
        return ([BitConverter]::ToString($deeBytes).Replace('-', '').ToLowerInvariant())
    }
    finally {
        $deeSha.Dispose()
    }
}

$deeScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$deeCandidates = @((Join-Path $deeScriptRoot 'FINAL_PACKAGE'), $deeScriptRoot)
$deePackageRoot = $null
foreach ($deeCandidate in $deeCandidates) {
    if ((Test-Path (Join-Path $deeCandidate 'MANIFEST.json')) -and
        (Test-Path (Join-Path $deeCandidate 'HASHES.sha256'))) {
        $deePackageRoot = $deeCandidate
        break
    }
}
if ($null -eq $deePackageRoot) {
    throw 'No verified final-package root found next to this script.'
}

$deeHashLines = Get-Content -LiteralPath (Join-Path $deePackageRoot 'HASHES.sha256')
$deeHashFailures = @()
$deeHashPaths = @()
foreach ($deeLine in $deeHashLines) {
    if ($deeLine -notmatch '^([0-9a-f]{64})  (.+)$') { throw "Malformed hash line: $deeLine" }
    $deeExpected = $Matches[1]
    $deeRelative = $Matches[2]
    if ([IO.Path]::IsPathRooted($deeRelative) -or $deeRelative -match '(^|/)\.\.(/|$)') {
        throw "Non-portable hash path: $deeRelative"
    }
    $deeHashPaths += $deeRelative
    $deeTarget = Join-Path $deePackageRoot ($deeRelative -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $deeTarget)) {
        $deeHashFailures += "MISSING:$deeRelative"
        continue
    }
    $deeActual = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeTarget).Hash.ToLowerInvariant()
    if ($deeActual -ne $deeExpected) { $deeHashFailures += "HASH:$deeRelative" }
}
if ($deeHashFailures.Count -ne 0) { throw ('Hash verification failed: ' + ($deeHashFailures -join ', ')) }
if (($deeHashPaths | Sort-Object -Unique).Count -ne $deeHashPaths.Count) { throw 'Duplicate path in HASHES.sha256.' }

$deeManifest = Get-Content -Raw -LiteralPath (Join-Path $deePackageRoot 'MANIFEST.json') | ConvertFrom-Json
if ($deeManifest.file_count -ne $deeManifest.files.Count) { throw 'Manifest file-count mismatch.' }
$deeManifestPaths = @($deeManifest.files | ForEach-Object { [string]$_.path })
if (($deeManifestPaths | Sort-Object -Unique).Count -ne $deeManifestPaths.Count) { throw 'Duplicate manifest path.' }
$deeManifestBytes = ($deeManifest.files | Measure-Object -Property size -Sum).Sum
if ($deeManifest.total_bytes -ne $deeManifestBytes) { throw 'Manifest total-byte mismatch.' }
foreach ($deeManifestEntry in $deeManifest.files) {
    $deeRelative = [string]$deeManifestEntry.path
    if ([IO.Path]::IsPathRooted($deeRelative) -or $deeRelative -match '(^|/)\.\.(/|$)') {
        throw "Non-portable manifest path: $deeRelative"
    }
    $deeTarget = Join-Path $deePackageRoot ($deeRelative -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $deeTarget)) { throw "Missing manifest file: $deeRelative" }
    $deeActualSize = (Get-Item -LiteralPath $deeTarget).Length
    $deeActualHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeTarget).Hash.ToLowerInvariant()
    if ($deeActualSize -ne $deeManifestEntry.size -or $deeActualHash -ne $deeManifestEntry.sha256) {
        throw "Manifest size/hash mismatch: $deeRelative"
    }
}
$deeExpectedHashPaths = @($deeManifestPaths + 'MANIFEST.json')
if (@(Compare-Object ($deeExpectedHashPaths | Sort-Object) ($deeHashPaths | Sort-Object)).Count -ne 0) {
    throw 'HASHES.sha256 path set differs from MANIFEST files plus MANIFEST.json.'
}
$deeManifestFullPath = (Join-Path $deePackageRoot 'MANIFEST.json')
$deeHashesFullPath = (Join-Path $deePackageRoot 'HASHES.sha256')
$deeActualPayloadPaths = @(Get-ChildItem -LiteralPath $deePackageRoot -Recurse -File | Where-Object {
    $_.FullName -ne $deeManifestFullPath -and $_.FullName -ne $deeHashesFullPath
} | ForEach-Object {
    [IO.Path]::GetRelativePath($deePackageRoot, $_.FullName).Replace('\', '/')
})
if (@(Compare-Object ($deeManifestPaths | Sort-Object) ($deeActualPayloadPaths | Sort-Object)).Count -ne 0) {
    throw 'Manifest path set differs from the actual package payload.'
}

$deeWorkCandidates = @(
    (Join-Path $deePackageRoot 'tests/DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/MULTISCALE_ROSETTA_CLOSURE'),
    (Join-Path $deePackageRoot 'MULTISCALE_ROSETTA_CLOSURE')
)
$deeWork = $null
foreach ($deeWorkCandidate in $deeWorkCandidates) {
    if (Test-Path -LiteralPath (Join-Path $deeWorkCandidate 'STATE.json')) {
        $deeWork = $deeWorkCandidate
        break
    }
}
if ($null -eq $deeWork) { throw 'Packaged multiscale work root not found.' }
$deeJsonFiles = @(Get-ChildItem -LiteralPath $deeWork -Recurse -File -Filter '*.json')
foreach ($deeJsonFile in $deeJsonFiles) {
    try { $null = Get-Content -Raw -LiteralPath $deeJsonFile.FullName | ConvertFrom-Json }
    catch { throw "Invalid JSON: $($deeJsonFile.FullName)" }
}
$deeState = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'STATE.json') | ConvertFrom-Json
$deeTree = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'HYPOTHESIS_TREE.json') | ConvertFrom-Json
if ($deeState.status -ne 'COMPLETE_HIERARCHY_FOUND_EXTERNAL_FRONTIER') { throw 'Unexpected final state.' }
if ($deeState.current_cycle -ne 11) { throw 'Unexpected STATE cycle.' }
$deeAdaptive = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'ADAPTIVE_STATE.json') | ConvertFrom-Json
if ($deeAdaptive.cycle -ne 11 -or $deeAdaptive.last_valid_checkpoint -ne 'CHECKPOINTS/checkpoint_0012') { throw 'Unexpected ADAPTIVE_STATE checkpoint.' }
$deeCheckpoint = Join-Path $deeWork 'CHECKPOINTS/checkpoint_0012'
foreach ($deeCheckpointFile in @('STATE.json','ADAPTIVE_STATE.json','HYPOTHESIS_TREE.json','DECISIONS.md')) {
    $deeCurrentHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeCheckpointFile)).Hash
    $deeCheckpointHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeCheckpoint $deeCheckpointFile)).Hash
    if ($deeCurrentHash -ne $deeCheckpointHash) { throw "Current state differs from checkpoint_0012: $deeCheckpointFile" }
}
$deeCheckpointHashLines = Get-Content -LiteralPath (Join-Path $deeCheckpoint 'HASHES.sha256')
foreach ($deeCheckpointLine in $deeCheckpointHashLines) {
    if ($deeCheckpointLine -notmatch '^([0-9a-f]{64})  ([^/\\]+)$') { throw "Malformed checkpoint hash line: $deeCheckpointLine" }
    $deeCheckpointExpected = $Matches[1]
    $deeCheckpointTarget = Join-Path $deeCheckpoint $Matches[2]
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $deeCheckpointTarget).Hash.ToLowerInvariant() -ne $deeCheckpointExpected) {
        throw "checkpoint_0012 hash mismatch: $($Matches[2])"
    }
}

$deeAllowed = @('ACTIVE','SUPPORTED','REFUTED','SUPERSEDED','DORMANT','WEAK_SIGNAL_DORMANT','NOT_IDENTIFIABLE','STAGNATED_NO_INFORMATION_GAIN')
foreach ($deeHypothesis in $deeTree.hypotheses) {
    if ($deeHypothesis.status -notin $deeAllowed) { throw "Invalid hypothesis status: $($deeHypothesis.id)" }
}

$deeRunLine = 0
$deeLastRunRecord = $null
Get-Content -LiteralPath (Join-Path $deeWork 'RUN_LOG.ndjson') | ForEach-Object {
    $deeRunLine++
    try { $deeLastRunRecord = $_ | ConvertFrom-Json } catch { throw "Invalid NDJSON line $deeRunLine" }
}
if ($null -eq $deeLastRunRecord -or $deeLastRunRecord.event -ne 'CHECKPOINT_CREATED' -or $deeLastRunRecord.checkpoint -ne 'CHECKPOINTS/checkpoint_0012') {
    throw 'RUN_LOG does not end at checkpoint_0012.'
}

$deeClaims = Import-Csv -LiteralPath (Join-Path $deeWork 'CLAIM_LEDGER.csv')
$deeExperiments = Import-Csv -LiteralPath (Join-Path $deeWork 'EXPERIMENT_INDEX.csv')
$deeMagnitudes = Import-Csv -LiteralPath (Join-Path $deeWork 'DEE_NATIVE_MAGNITUDES.csv')
$deeFlexibility = Import-Csv -LiteralPath (Join-Path $deeWork 'FLEXIBILITY_LEDGER.csv')
$deeWhlLedger = Import-Csv -LiteralPath (Join-Path $deeWork 'WHL_INTERROGATION_LEDGER.csv')
if (($deeClaims.claim_id | Sort-Object -Unique).Count -ne $deeClaims.Count) { throw 'Duplicate claim id.' }
if (($deeExperiments.experiment_id | Sort-Object -Unique).Count -ne $deeExperiments.Count) { throw 'Duplicate experiment id.' }
if (($deeMagnitudes.magnitude_id | Sort-Object -Unique).Count -ne $deeMagnitudes.Count) { throw 'Duplicate magnitude id.' }
foreach ($deeLedgerName in @('CLAIM_LEDGER.csv','EXPERIMENT_INDEX.csv','DEE_NATIVE_MAGNITUDES.csv','FLEXIBILITY_LEDGER.csv','WHL_INTERROGATION_LEDGER.csv')) {
    if ((Get-Content -Raw -LiteralPath (Join-Path $deeWork $deeLedgerName)) -match 'PENDING_MANIFEST') {
        throw "Canonical ledger still contains PENDING_MANIFEST: $deeLedgerName"
    }
}

$deeClaimsJson = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'CLAIM_LEDGER.json') | ConvertFrom-Json
if ($deeClaimsJson.Count -ne $deeClaims.Count) { throw 'Claim CSV/JSON row-count mismatch.' }
if (@(Compare-Object ($deeClaims.claim_id | Sort-Object) ($deeClaimsJson.claim_id | Sort-Object)).Count -ne 0) {
    throw 'Claim CSV/JSON id mismatch.'
}
$deeClaimFields = @($deeClaims[0].PSObject.Properties.Name)
for ($deeClaimIndex = 0; $deeClaimIndex -lt $deeClaims.Count; $deeClaimIndex++) {
    $deeJsonFields = @($deeClaimsJson[$deeClaimIndex].PSObject.Properties.Name)
    if (@(Compare-Object ($deeClaimFields | Sort-Object) ($deeJsonFields | Sort-Object)).Count -ne 0) {
        throw "Claim CSV/JSON field mismatch at row $deeClaimIndex."
    }
    foreach ($deeClaimField in $deeClaimFields) {
        if ([string]$deeClaims[$deeClaimIndex].$deeClaimField -cne [string]$deeClaimsJson[$deeClaimIndex].$deeClaimField) {
            throw "Claim CSV/JSON value mismatch at row $deeClaimIndex field $deeClaimField."
        }
    }
}

foreach ($deeClaim in $deeClaims) {
    $deeEvidence = Join-Path $deeWork ($deeClaim.evidence_path -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $deeEvidence)) { throw "Missing claim evidence: $($deeClaim.claim_id)" }
    if ($deeClaim.evidence_sha256 -notmatch '^[0-9a-f]{64}$') { throw "Malformed claim evidence hash: $($deeClaim.claim_id)" }
    $deeEvidenceHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeEvidence).Hash.ToLowerInvariant()
    if ($deeEvidenceHash -ne $deeClaim.evidence_sha256) { throw "Claim evidence hash mismatch: $($deeClaim.claim_id)" }
}
foreach ($deeExperiment in $deeExperiments) {
    $deeResult = Join-Path $deeWork ($deeExperiment.result_path -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $deeResult)) { throw "Missing experiment output: $($deeExperiment.experiment_id)" }
    if ($deeExperiment.output_hash -notmatch '^[0-9a-f]{64}$') { throw "Malformed experiment hash: $($deeExperiment.experiment_id)" }
    $deeResultHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeResult).Hash.ToLowerInvariant()
    if ($deeResultHash -ne $deeExperiment.output_hash) { throw "Experiment hash mismatch: $($deeExperiment.experiment_id)" }
}
foreach ($deeMagnitude in $deeMagnitudes) {
    $deeEvidence = Join-Path $deeWork ($deeMagnitude.evidence_path -replace '/', [IO.Path]::DirectorySeparatorChar)
    if (-not (Test-Path -LiteralPath $deeEvidence)) { throw "Missing magnitude evidence: $($deeMagnitude.magnitude_id)" }
}

$deeMsh01Lock = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'HOLDOUT_LOCKS/HOLDOUT_MSH01_LOCK.json') | ConvertFrom-Json
$deeMsh01Result = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'HOLDOUTS/MSH01_results.json') | ConvertFrom-Json
$deeMsh01LockHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork 'HOLDOUT_LOCKS/HOLDOUT_MSH01_LOCK.json')).Hash.ToLowerInvariant()
$deeMsh01RunnerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeMsh01Lock.contract.runner)).Hash.ToLowerInvariant()
$deeMsh01CoreHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeMsh01Lock.contract.core_runner)).Hash.ToLowerInvariant()
$deeMsh01FoundationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeMsh01Lock.contract.foundation_runner)).Hash.ToLowerInvariant()
if ($deeMsh01LockHash -ne $deeMsh01Result.lock_file_sha256) { throw 'MSH01 lock/result chain mismatch.' }
if ($deeMsh01Lock.contract_payload_sha256 -ne $deeMsh01Result.contract_payload_sha256) { throw 'MSH01 contract/result chain mismatch.' }
if ($deeMsh01RunnerHash -ne $deeMsh01Lock.contract.runner_sha256 -or $deeMsh01RunnerHash -ne $deeMsh01Result.runner_sha256) { throw 'MSH01 runner chain mismatch.' }
if ($deeMsh01CoreHash -ne $deeMsh01Lock.contract.core_runner_sha256 -or $deeMsh01CoreHash -ne $deeMsh01Result.core_runner_sha256) { throw 'MSH01 core-runner chain mismatch.' }
if ($deeMsh01FoundationHash -ne $deeMsh01Lock.contract.foundation_runner_sha256 -or $deeMsh01FoundationHash -ne $deeMsh01Result.foundation_runner_sha256) { throw 'MSH01 foundation-runner chain mismatch.' }
if (($deeMsh01Lock.contract | ConvertTo-Json -Compress -Depth 100) -cne ($deeMsh01Result.contract | ConvertTo-Json -Compress -Depth 100)) { throw 'MSH01 frozen contract copy mismatch.' }
if ($deeMsh01Result.environment.threads -ne 1) { throw 'MSH01 thread-count mismatch.' }
if ($deeMsh01Result.primary_adjudication.verdict -ne 'INCONCLUSIVE_CLASS_DIVERSITY') { throw 'MSH01 verdict mismatch.' }

$deeLock = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'HOLDOUT_LOCKS/HOLDOUT_MSH02_LOCK.json') | ConvertFrom-Json
$deeResult = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'HOLDOUTS/MSH02_results.json') | ConvertFrom-Json
$deeLockHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork 'HOLDOUT_LOCKS/HOLDOUT_MSH02_LOCK.json')).Hash.ToLowerInvariant()
$deeRunnerHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeLock.contract.runner)).Hash.ToLowerInvariant()
$deeCoreHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeLock.contract.core_runner)).Hash.ToLowerInvariant()
$deeFoundationHash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $deeWork $deeLock.contract.foundation_runner)).Hash.ToLowerInvariant()
if ($deeLockHash -ne $deeResult.lock_file_sha256) { throw 'MSH02 lock/result chain mismatch.' }
if ($deeLock.contract_payload_sha256 -ne $deeResult.contract_payload_sha256) { throw 'MSH02 contract/result chain mismatch.' }
if ($deeRunnerHash -ne $deeLock.contract.runner_sha256 -or $deeRunnerHash -ne $deeResult.runner_sha256) { throw 'MSH02 runner chain mismatch.' }
if ($deeCoreHash -ne $deeLock.contract.core_runner_sha256 -or $deeCoreHash -ne $deeResult.core_runner_sha256) { throw 'MSH02 core-runner chain mismatch.' }
if ($deeFoundationHash -ne $deeLock.contract.foundation_runner_sha256 -or $deeFoundationHash -ne $deeResult.foundation_runner_sha256) { throw 'MSH02 foundation-runner chain mismatch.' }
if (($deeLock.contract | ConvertTo-Json -Compress -Depth 100) -cne ($deeResult.contract | ConvertTo-Json -Compress -Depth 100)) { throw 'MSH02 frozen contract copy mismatch.' }
if ($deeResult.environment.threads -ne 1) { throw 'MSH02 thread-count mismatch.' }
if ($deeResult.primary_adjudication.verdict -ne 'PASS_CONFIRMED_PROGRESS') { throw 'MSH02 verdict mismatch.' }
$deeMsh02Audit = Get-Content -Raw -LiteralPath (Join-Path $deeWork 'ANALYSIS/MSH02_RESULT_AUDIT.json') | ConvertFrom-Json
if ($deeMsh02Audit.status -ne 'PASS' -or $deeMsh02Audit.independent_verdict -ne 'PASS_CONFIRMED_PROGRESS') { throw 'MSH02 independent audit mismatch.' }
foreach ($deeAuditCheck in $deeMsh02Audit.checks.PSObject.Properties) {
    if ($deeAuditCheck.Value -ne $true) { throw "MSH02 audit check failed: $($deeAuditCheck.Name)" }
}
foreach ($deeHoldoutId in @('MSH01','MSH02')) {
    $deeHoldoutLockPath = Join-Path $deeWork "HOLDOUT_LOCKS/HOLDOUT_${deeHoldoutId}_LOCK.json"
    $deeHoldoutLock = Get-Content -Raw -LiteralPath $deeHoldoutLockPath | ConvertFrom-Json
    $deeHoldoutLockHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeHoldoutLockPath).Hash.ToLowerInvariant()
    $deeSidecar = (Get-Content -Raw -LiteralPath ($deeHoldoutLockPath + '.sha256')).Trim()
    if ($deeSidecar -cne ($deeHoldoutLockHash + '  ' + [IO.Path]::GetFileName($deeHoldoutLockPath))) { throw "$deeHoldoutId lock sidecar mismatch." }
    $deeDraftPath = Join-Path $deeWork "ANALYSIS/HOLDOUT_${deeHoldoutId}_LOCK_DRAFT.json"
    if ((Get-FileHash -Algorithm SHA256 -LiteralPath $deeDraftPath).Hash.ToLowerInvariant() -ne $deeHoldoutLock.draft_file_sha256) { throw "$deeHoldoutId draft/lock hash mismatch." }
}

$deeWheel = Join-Path $deePackageRoot 'tests/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl'
$deeWheelHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $deeWheel).Hash.ToLowerInvariant()
if ($deeWheelHash -ne '69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939') { throw 'Wheel hash mismatch.' }
$deeParentWork = Split-Path -Parent $deeWork
$deeResolvedTests = Split-Path -Parent $deeParentWork
if ([IO.Path]::GetFullPath($deeWheel) -ne [IO.Path]::GetFullPath((Join-Path $deeResolvedTests 'dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl'))) {
    throw 'Frozen-runner wheel layout mismatch.'
}
$deePackageFile = Join-Path $deeParentWork 'ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/__init__.py'
$deeKernelFile = Join-Path $deeParentWork 'ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd'
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $deePackageFile).Hash.ToLowerInvariant() -ne '7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4') { throw 'Package hash mismatch.' }
if ((Get-FileHash -Algorithm SHA256 -LiteralPath $deeKernelFile).Hash.ToLowerInvariant() -ne '0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff') { throw 'Kernel hash mismatch.' }
foreach ($deeEnvironment in @($deeMsh01Result.environment, $deeResult.environment)) {
    if ($deeEnvironment.observed_hashes.wheel -ne '69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939' -or
        $deeEnvironment.observed_hashes.package -ne '7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4' -or
        $deeEnvironment.observed_hashes.kernel -ne '0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff') {
        throw 'Holdout runtime identity mismatch.'
    }
}
$deeExtractedRoot = Join-Path $deeParentWork 'ANALYSIS/binary_api/wheel_extracted'
$deeWheelMembers = @{}
$deeWheelArchive = [IO.Compression.ZipFile]::OpenRead($deeWheel)
try {
    foreach ($deeEntry in $deeWheelArchive.Entries) {
        if ([string]::IsNullOrEmpty($deeEntry.Name)) { continue }
        if ($deeWheelMembers.ContainsKey($deeEntry.FullName)) { throw "Duplicate wheel member: $($deeEntry.FullName)" }
        $deeEntryStream = $deeEntry.Open()
        try { $deeWheelMembers[$deeEntry.FullName] = Get-DeeStreamSha256 -Stream $deeEntryStream }
        finally { $deeEntryStream.Dispose() }
    }
}
finally {
    $deeWheelArchive.Dispose()
}
$deeExtractedMembers = @{}
Get-ChildItem -LiteralPath $deeExtractedRoot -Recurse -File | ForEach-Object {
    $deeRelative = [IO.Path]::GetRelativePath($deeExtractedRoot, $_.FullName).Replace('\', '/')
    $deeExtractedMembers[$deeRelative] = (Get-FileHash -Algorithm SHA256 -LiteralPath $_.FullName).Hash.ToLowerInvariant()
}
if (@(Compare-Object ($deeWheelMembers.Keys | Sort-Object) ($deeExtractedMembers.Keys | Sort-Object)).Count -ne 0) {
    throw 'Extracted runtime member set differs from exact wheel.'
}
foreach ($deeMemberName in $deeWheelMembers.Keys) {
    if ($deeWheelMembers[$deeMemberName] -ne $deeExtractedMembers[$deeMemberName]) {
        throw "Extracted runtime member hash differs from wheel: $deeMemberName"
    }
}
if (@(Get-ChildItem -LiteralPath $deePackageRoot -Recurse -File -Filter '*.zip').Count -ne 0) { throw 'Nested ZIP found.' }

[pscustomobject]@{
    status = 'PASS'
    package_root = $deePackageRoot
    verified_hashes = $deeHashLines.Count
    manifest_files = $deeManifest.file_count
    claims = $deeClaims.Count
    experiments = $deeExperiments.Count
    magnitudes = $deeMagnitudes.Count
    flexibility_rows = $deeFlexibility.Count
    whl_interrogation_rows = $deeWhlLedger.Count
    json_files = $deeJsonFiles.Count
    run_log_lines = $deeRunLine
    runner_layout = 'PASS'
    wheel_extracted_members = $deeWheelMembers.Count
    stopping_state = $deeState.status
    msh01 = $deeMsh01Result.primary_adjudication.verdict
    msh02 = $deeResult.primary_adjudication.verdict
} | ConvertTo-Json -Depth 4
