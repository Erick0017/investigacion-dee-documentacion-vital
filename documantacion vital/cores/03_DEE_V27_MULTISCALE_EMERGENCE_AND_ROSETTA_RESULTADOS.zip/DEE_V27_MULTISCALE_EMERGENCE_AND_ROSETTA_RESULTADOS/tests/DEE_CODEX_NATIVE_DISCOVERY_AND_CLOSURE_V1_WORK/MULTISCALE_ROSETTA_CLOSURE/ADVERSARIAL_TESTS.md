# Adversarial tests and anti-pareidolia controls

| Test | Adversary/control | Result | Consequence |
|---|---|---|---|
| T1 | distance-3 one-step witness | radius-1 claim failed | exact raw cone is <=3t |
| T4 | semantic-4 fixed raws | no-range0 claim failed | nontrivial Q_f family exists |
| T6 | rotations/reflections with tie/overflow cases | global O_h failed | retain translations/sector symmetries only |
| T10/T12 | merged versus separated state/event observers | original FAIL, repair PASS | keep J_dagger separate |
| MSD01 | joint raw+clock inventory shuffle | responses changed 4/4 | organization matters beyond content |
| MSD02 | majority and static feature bank | no static feature beat the majority error count materially | reject tested static sufficiency |
| MSD04 | one-count support versus two-time/direction formulas | one count matched 60/60 discovery labels | remove routing-specific overinterpretation |
| MSH01 | unopened sizes/seeds and frozen size/early competitors | inconclusive; four OTHER | preserve FAIL/inconclusive, inspect censoring only post-hoc |
| MSD05 | exact 4N overlap then 16N extension | all nine non-dense rows period N | refute stable third class in panel |
| MSD06 | state/direction deletion factorial and direction permutation | q/state not sole carrier | separate order from mechanism |
| MSH02 | zero OTHER tolerance, best-of-three nuisance null and pre-crossing subset | literal PASS | bounded Q2 promotion |
| MSH02 secondary | frozen direction-support comparator | also 60/60 | q_N not uniquely selected |

## Multiple-testing firewall

MSD01–MSD06 are discovery or post-holdout mechanism work. Every inspected feature, time, formula, endpoint and intervention is charged in `FLEXIBILITY_LEDGER.csv`. MSH01 and MSH02 each have immutable lock, transitive runner hashes and a single-use output. MSH01 was not repaired retrospectively. MSH02 froze the refined endpoint on entirely unused sizes and mechanically derived seeds.

Only MSH02 produced `CONFIRMED_PROGRESS`. Technical interruptions with no atomic output did not change counters or hypotheses.
