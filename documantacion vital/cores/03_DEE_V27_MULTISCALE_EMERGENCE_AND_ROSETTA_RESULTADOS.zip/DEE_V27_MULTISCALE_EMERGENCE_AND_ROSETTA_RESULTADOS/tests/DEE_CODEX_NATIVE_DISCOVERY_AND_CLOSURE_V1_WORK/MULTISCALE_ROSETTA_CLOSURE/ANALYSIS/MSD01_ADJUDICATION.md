# MSD01 discovery adjudication

## Integrity

The real v27 wheel/kernel pair was used under CPython 3.13 with exact path and hash checks. Thirty-three trajectories and 1,776 universe-ticks were executed at N=32 and N=40. All four same-inventory controls preserved the exact joint outer raw+clock multiset and changed its spatial arrangement. A duplicate trajectory reproduced byte-identical raw and clock endpoints. All paired raw differences stayed inside the `3t` causal envelope.

## What the layers built

The inward-directed outer records produced causal lineages whose first influence matched the geometric free-flight gap: middle/inner first raw divergence was 4/8 ticks for N32 and 5/10 ticks for N40 under ablation, direction removal, `s_reg` removal and joint-inventory shuffling. The shuffle retained content but reduced straight-line inner hits from 30–46 to 8–9 and changed all four inner response words. This establishes `content != organization` again in a new v27 apparatus and identifies directed reachability as a concrete mediator candidate.

Outer ablation and outer direction-zero produced identical response words and final raw states in 4/4 cases. Here the positive `state/s_reg/semantic` inventory without arrows died without downstream function: routing was necessary. Common `+17` and spatial shuffling of the declared outer clock multiset were raw-inert in 4/4, so clock organization did not mediate this panel. Removing `s_reg` sometimes changed raw but not occupancy, independently exposing `microscopic field difference != selected macro difference`.

## Unexpected regime signal

World occupancy separated into sparse (~10^2 sites) and near-full dense (>0.99 of sites) outcomes. N40 replicate 0 ended at 113 sites under baseline but at 63,393/64,000 under the semantic-4 source intervention. N40 replicate 1 was dense already; both N32 cases became dense. Therefore semantic sources can trigger a basin crossing, but are not alone a sufficient basin label. This post-hoc observation is a `SIGNAL`, not a confirmed emergent level.

## Level adjudication

The first-passage effect itself is explained by Q1 causal lineages and does not justify Q2. A Q2 may exist if a compact collective growth/path-collision state predicts the sparse/dense basin and source-induced crossings across fresh preparations. MSD02 will test that in discovery against inventory/size constants and near-microscopic identifiers. No threshold or model from MSD01 will be treated as frozen.
