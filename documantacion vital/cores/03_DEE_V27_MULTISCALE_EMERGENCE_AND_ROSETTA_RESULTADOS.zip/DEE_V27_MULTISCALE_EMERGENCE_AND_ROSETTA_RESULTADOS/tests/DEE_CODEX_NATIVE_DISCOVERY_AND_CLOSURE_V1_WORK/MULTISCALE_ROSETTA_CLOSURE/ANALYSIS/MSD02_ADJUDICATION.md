# MSD02 discovery adjudication

MSD02 ran 60 trajectories (4,140 universe-ticks) over 20 independent seed groups at N36/N40. Every baseline/shuffle pair preserved the exact joint raw+clock inventory of the outer layer. Terminal occupancy at t66/t72 showed a large gap: 10 rows below 0.5, 50 above, and no row between 0.39284375 and 0.9540252058.

Grouped leave-one-seed-out majority prediction had balanced accuracy 0.50. The best tested inventory stump also scored 0.50; the best tested static path/organization stump scored 0.54. In contrast, the best inspected early-response variables scored 0.95; `direction_nonzero/N^3` at t20 made one error in 60 and its fold thresholds lay in [0.0041474, 0.0042438]. This is a compact collective field density, but it was selected after examining multiple fields/times and is therefore only a `SIGNAL`.

The error is scientifically informative: an N40 semantic-source world was at 0.3928 at t72 but accelerating, while its baseline was at 0.0763 and also accelerating. Hence the label was a time-censored regime, not a demonstrated basin. Stable-looking N36 low worlds retained ~10^2 moving directional records with changing raw hashes. MSD03 must distinguish delayed ignition from recurrent sparse motion before any Q2 law can be frozen.

Semantic sources changed three of four baseline-low groups to high by the finite horizon. Exact same-inventory shuffling changed one baseline-high group to low. This supports causal control of ignition latency by organization and persistent sources, but not a static object identity or external field analogy.
