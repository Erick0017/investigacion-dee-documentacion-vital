# MSD03 long-horizon adjudication

MSD03 is complete discovery evidence. It executed 14 deterministically reconstructed v27 trajectories for 7,168 universe ticks through `t=512`; every overlap raw+clock hash agreed with MSD02.

Seven rows remained sparse below occupancy fraction 0.01 and their raw projections repeated with period `N=36` over the tested tail. Seven rows were above 0.9 and their raw projections were fixed over the tested tail. The three ambiguous N40 rows crossed occupancy 0.5 at ticks 81, 74 and 95, so finite-horizon censoring and a genuine sparse recurrent sector both occur.

The period/fixed labels apply only to the sampled raw projection over a finite window. They are not full-state `(raw,clock)` periodicity theorems and do not establish infinite-time attraction.

The discovery law `Delta_A_N` classified all 60 resolved trajectories, but it was chosen after inspection and cannot be promoted. MSD04 further showed that one-time occupancy at `t=N` is strictly simpler and equally discriminative on discovery data.

Hashes:

- runner: `23c0558c6a856aaff368758b1b2cfdb490d4e314dc3a6b7cb0cd910dd8aa5348`
- result: `adb9e1482dd7d9b2218997bde4934b0d16c055b67be667e74716e8d2a3c393f2`
- growth analysis: `ba4b170085b5b691839b4def701c53d5bd00b393695367df417a2b6ce12bd10e`
- adversarial candidate competition: `32550ae2159f3df247f64eaad20a960b087ac45a1e3586f92461d417e608838e`
