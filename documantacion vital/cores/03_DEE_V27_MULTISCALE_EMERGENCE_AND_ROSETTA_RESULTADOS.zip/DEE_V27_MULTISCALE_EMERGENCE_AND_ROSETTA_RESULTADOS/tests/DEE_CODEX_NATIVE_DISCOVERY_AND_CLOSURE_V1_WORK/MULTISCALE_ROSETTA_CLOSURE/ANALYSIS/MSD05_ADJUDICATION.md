# MSD05 adjudication

MSD05 is valid post-holdout discovery, not confirmation. The first attempt was a technical no-output abort caused by a wrong decoded-field key; the corrected hash-pinned runner then passed audit and completed.

For all nine non-dense MSH01 rows:

- the raw and clock hashes at 4N exactly match MSH01;
- no row crossed occupancy 0.5 after 4N;
- every raw, state, positive-mask, direction, s_reg and semantic projection has exact tail period N by 16N;
- every recorded aggregate count is constant from 4N onward.

Thus the four MSH01 OTHER rows do not define a stable third recurrence class in this panel. They expose a too-short witness window. The unchanged q_N rule becomes 60/60 only after changing the endpoint post-hoc, so this is SIGNAL and cannot be reported as a repaired PASS.

Hashes: runner `11ec7f7b73434ba69489fe4cf3de86727f9d1018405ef28dbb0d2aa7e3f74385`; result `11178ba62e0ada18274688a3a75db8ca181d196f6798ee2ef036b3cb5cd50eba`; refined analysis `ab372218845e62a743265436c8c242e489845172d9b931be3b5bd6663c644266`.
