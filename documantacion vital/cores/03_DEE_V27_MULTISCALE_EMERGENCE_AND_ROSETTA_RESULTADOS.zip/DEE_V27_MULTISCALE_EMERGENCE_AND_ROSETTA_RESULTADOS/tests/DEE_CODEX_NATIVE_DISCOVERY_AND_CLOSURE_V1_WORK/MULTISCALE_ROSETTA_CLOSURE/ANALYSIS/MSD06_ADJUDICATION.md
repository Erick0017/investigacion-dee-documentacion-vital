# MSD06 adjudication — causal carrier discovery

## Integrity and epistemic class

MSD06 used the hash-pinned v27 kernel for 70 trajectory segments and 9,010 universe ticks. Runner SHA-256: `9bb9df294c6a0d77259478d1528e200b70a1f01c4644d798d74a85466951a1bc`; result SHA-256: `30a2136fe1ee9ff3ab8a55d2990616b0e4be581510709f41cc73313f3dd77d10`. All six baseline replays matched raw and clock at N and 4N; both precursor replays matched at N and 2N. Every factorial bit-field audit, matched clock check and exact one-step DEMUX destination check passed.

All contexts were selected after MSH01 was opened and the whole-torus deletions are mathematical, potentially off-manifold interventions. Therefore every inference here is `SIGNAL`/computational discovery, never `CONFIRMED_PROGRESS` and never an assertion of physical preparability.

## Exact computational findings

The initial outer-shell factorial reproduces and sharpens MSD01. In all six groups, the direction-zero, state+direction-zero-with-metadata, and total-ablation arms became raw-identical at t=1 and remained identical. The state-zero/direction-retained arm created exactly the union of encoded routing destinations: 108/108, 107/108 and 108/108 unique destinations at N35; 116/116, 116/116 and 114/116 at N37.

At the unmodified t=N snapshot, deleting every state bit while retaining direction, s_reg, semantic and clock produced at t=N+1 exactly the routed-destination positive mask in all eight tested contexts; the matched state-and-direction null remained positive-empty. Thus positive state is not required at the intervention instant for one-step positive-support reinstantiation.

In the four sparse long contexts and the sparse precursor shuffle, FULL and state-zero/direction-retained became exactly raw-identical at N+1 and stayed identical for the entire measured future. In the six long contexts, state deletion changed the finite 8N witness class in 0/6; direction deletion with every state value retained changed it in 5/6.

The clean pre-crossing baseline had q_N=310/50,653=0.006120071861, above the frozen q*=0.003417106053. FULL crossed 0.5 at t=61 and reached q_2N=0.9927348824. Direction deletion preserved q and every state value at t=N but never crossed and ended at q_2N=7/50,653=0.0001381952. Conversely, state deletion with routing retained regenerated 300 exact destinations at one tick and reached q_2N=0.1077132648, but did not reproduce FULL by 2N. The final-density factorial interaction was 0.884883: dense onset is strongly non-additive in this context.

In mature dense contexts, either complement could sustain/rebuild macroscopic support without microscopic equivalence. State deletion plus routing rebuilt q from zero to 0.5797/0.5348 in one tick and ended dense near 0.9955. Direction deletion yielded two direction-free raw-fixed windows from t=38 through 280 at q=0.993539 and from t=41 through 296 at q=0.849703. The second is a new intervention-induced intermediate-density fixed window, not a natural-preparation third class or infinite-time theorem.

The direction-word control held q and every state value sitewise, direction support sitewise, s_reg, semantic, clock and the direction-vector histogram fixed while changing 66.3%–86.4% of direction words. It changed the raw trajectory through 8N in 6/6 but the coarse witness class in 0/6 (two dense, four sparse). Hence direction organization matters microscopically, while this coarse label was robust to this single perturbation away from the boundary.

## Adjudication

`q_N` remains the simplest successful natural-preparation order parameter among the tested competitors, but it is refuted as a sufficient autonomous carrier: the same complete state field and q at the precursor collapsed when direction was removed. It is also not necessary at an instant for reinstantiation when direction-bearing records and their other fields remain.

The current parsimonious tested mechanistic candidate is a phase-dependent pair plus relations: positive support P; a routing complement R=(direction, s_reg, semantic, clock) on source records; and the geometry/multiplicity of routed destinations. Sparse recurrence is R-dominated with P redundant after one tick. Dense onset uses a strong P×R interaction. Mature dense configurations exhibit macroscopic redundancy and microscopic memory. MSD06 did not ablate every component inside R separately or compare every simpler observer, so minimality is unproved. This does not identify P with matter, direction with momentum, or R alone as sufficient outside the tested panel.

The refined q_N law may now be tested only as a predictive law on natural preparations. Its causal interpretation is frozen as “order parameter, not sole carrier.” MSH02 must use unopened seeds/sizes, preserve the MSH01 FAIL, and cannot include the off-manifold arms in its primary sample.
