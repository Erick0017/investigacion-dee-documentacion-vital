# MSH01 literal holdout adjudication

MSH01 executed exactly once after the lock hash `6c5ee4b7d4e0b2f5d2be91e6be0ef4aadfa6a384d54ba41a139b3dc32fd353ee` was frozen and verified with the output absent. All 60 declared rows completed using the exact v27 wheel/package/kernel and one thread. Result SHA-256: `c87eff9a9ab54531d82922141e9d9976876953ae4c894d72f0758a12fa81c67f`.

The frozen verdict is **INCONCLUSIVE_CLASS_DIVERSITY**:

- 51 dense raw-fixed finite windows;
- 5 sparse raw-period-N finite windows;
- 4 OTHER outcomes, all counted as primary errors;
- sparse outcomes in 3 independent groups, below the frozen minimum 4;
- 3 mixed seed groups;
- joint-inventory integrity PASS;
- primary BA over the two named classes 1.0, but total accuracy 56/60 because OTHER is not silently collapsed;
- size-only BA 0.617647 and size-specificity challenge PASS;
- independent all-arms group success 18/20, Wilson 95% `[0.69897,0.97213]`;
- pre-crossing subanalysis `INCONCLUSIVE_PRE_CROSSING_DIVERSITY`: 10 delayed-dense groups, 3 sparse groups, 4 OTHER errors.

No Q2 is promoted and no stagnation counter resets. `q_N` does separate dense from all non-dense outcomes 60/60 after the fact, but that was not the frozen binary endpoint and is only a new SIGNAL. The four OTHER rows motivate targeted discovery; they cannot be excluded, relabeled retroactively or used as confirmation.
