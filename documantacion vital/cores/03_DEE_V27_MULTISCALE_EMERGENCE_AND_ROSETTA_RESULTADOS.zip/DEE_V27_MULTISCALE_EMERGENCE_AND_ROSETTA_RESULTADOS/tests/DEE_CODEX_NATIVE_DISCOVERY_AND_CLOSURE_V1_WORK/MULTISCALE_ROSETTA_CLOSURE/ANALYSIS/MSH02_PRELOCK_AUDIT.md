# MSH02 pre-lock audit

MSH02 remained unopened throughout construction and audit. The final draft SHA-256 before freeze is `c999727819c3d9476aabe8c43080b41214cd7a922eebb57dfdab9fb5b482c53e`; its canonical contract SHA-256 is `ce6a2ef35cc267c000b99fb93d8e316e009477159f0116947fbe95621913e1a5`.

The executable chain was checked independently and locally. Final hashes before freeze are:

- holdout runner: `85f6cccf3d7925702b9119514dc90351c0f8102ad525437f788a4569c219d1f7`;
- core runner: `c79de8d09e9063a074d97fad1f892cdf057ff137e3bb99c1a5f5399ef89e8fe1`;
- foundation runner: `133106a495ab684ee4d49b6dace76570a25585b19515f4116a167db5fc22cb45`;
- freeze runner: `be6bc16fd18e2e040f5b50c09a77cf317acb25bb3aa8b629498c77b63ca4c6e4`;
- draft validator: `b30204487ad589d7a69fb8b07917cbe8ceda797135578a1152d3e44b134ce784`;
- frozen verifier: `b1eabaae2b7df991e9cab09350531f9534e0c2a77c4033010fccd1a10f17ab67`.

The draft validator passed all transitive hashes, exact threshold cutoffs 123/188, 20 globally unique mechanically derived seeds, absence of those seeds and both sizes from prior JSON results throughout `tests`, exact 60-row/8,520-minimum/34,080-worst-case counts, adaptive 4N-to-16N execution, exact minimal-period contract and every frozen criterion. A separate adversarial review returned no blocker. Synthetic adjudication checks covered literal PASS, OTHER, dense/sparse error before diversity, missing diversity, incremental-value failure, pre-crossing diversity and incomplete protocol.

The eligible pre-crossing set is a prospectively defined subset, not a requirement that all 60 rows remain below 0.5 through N. Any OTHER or primary error fails before diversity is considered. PASS requires full-panel and eligible-subset advantage of at least 0.10 over the best of the frozen always-dense, size-only and size-plus-arm nulls. Direction support at N is descriptive and cannot rescue the primary. Causal wording remains restricted: q_N is tested as a predictor/order parameter, never as the sole carrier.

The final two narrative falsifiers were aligned with the already correct executable ordering after the independent audit; the validator, runner audit and freeze preflight were rerun on the final hashes above. No holdout datum was opened by this wording-only correction.
