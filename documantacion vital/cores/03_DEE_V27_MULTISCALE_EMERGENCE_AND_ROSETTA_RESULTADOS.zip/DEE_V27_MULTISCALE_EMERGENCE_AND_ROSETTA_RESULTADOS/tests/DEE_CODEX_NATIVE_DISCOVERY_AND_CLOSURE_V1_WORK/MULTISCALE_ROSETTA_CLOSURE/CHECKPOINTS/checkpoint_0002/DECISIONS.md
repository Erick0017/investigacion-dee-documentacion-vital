# Checkpoint 0002 decisions

MSD01 is complete discovery evidence. Exact same-inventory shuffles changed every inner response; routing mediated first passage; clock arms were inert; all differences respected 3t. A post-hoc sparse/dense basin signal created H-Q2-BASIN-GROWTH. No confirmation claim or retrospective threshold is permitted. Next: MSD02 fresh-seed discovery.
