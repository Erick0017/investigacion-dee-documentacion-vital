# Checkpoint 0003 decisions

MSD02 is discovery only. A selected early collective variable strongly predicts the finite-horizon class, but model/time selection prevents promotion. Static tested features failed. One negative was accelerating, so no basin label is accepted. Next: long-horizon recurrence versus delayed ignition.
