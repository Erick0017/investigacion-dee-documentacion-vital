# Checkpoint 0004 decisions

MSD03 resolves both a sparse raw-period-N finite-window sector and delayed dense ignition. The original two-time direction-growth classifier is not minimal: MSD04 found an identical one-count occupancy classifier and near-identical occupancy/direction deltas. Direction specificity is rejected. No holdout has been opened. Next: revise and independently audit MSH01, then freeze exactly once.
