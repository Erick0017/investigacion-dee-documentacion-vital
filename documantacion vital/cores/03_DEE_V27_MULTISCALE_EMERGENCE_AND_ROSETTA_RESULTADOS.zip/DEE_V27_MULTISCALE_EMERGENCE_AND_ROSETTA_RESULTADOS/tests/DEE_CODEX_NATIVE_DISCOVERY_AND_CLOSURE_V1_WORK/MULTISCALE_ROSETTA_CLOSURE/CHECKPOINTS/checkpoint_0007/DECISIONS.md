# Checkpoint 0007

MSD05 establishes that all nine MSH01 non-dense rows reach exact period N by 16N. The refined 60/60 law is post-hoc and not confirmation. Stagnation counter is two. Next: one bounded causal-discrimination experiment before a new lock or branch stop.
