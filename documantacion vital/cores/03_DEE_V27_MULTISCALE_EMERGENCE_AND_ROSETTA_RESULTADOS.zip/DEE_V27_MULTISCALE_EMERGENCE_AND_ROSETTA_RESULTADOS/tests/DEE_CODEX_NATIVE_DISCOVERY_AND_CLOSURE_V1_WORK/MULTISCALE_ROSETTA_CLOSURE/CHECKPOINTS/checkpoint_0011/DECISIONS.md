# Decision ledger

## D0001 — One-time recovery after technical interruption

The complete `tests` tree was searched for `MULTISCALE_ROSETTA_CLOSURE`. No such directory, state, checkpoint, runner, result, or partial output existed. Therefore the prior interruption occurred before initialization of this continuation. It is classified as `TECHNICAL_INTERRUPTION`; it is neither PASS, FAIL, stagnation, nor evidence. The sealed V1 and Rosetta ZIPs were hash-verified and remain untouched.

## D0002 — Reuse boundary

The exact Q0/Q1 results, T8–T12, V6-E and V7-A/B/C are imported only in their declared domains. Historical `MATCHEDMULTISCALE231X` and `NESTEDSCALE21X` are v25 evidence and may generate hypotheses, but no mechanism is transferred to v27 without execution.

## D0003 — First dependency-graph pivot

The first new question is the carrier/descriptor of cross-scale response. It has high information gain because it can jointly constrain Q2 existence, same-inventory organization, transfer identity, observer sufficiency, object/medium separation, and the admissible Rosetta level. It is cheaper and more falsifiable than opening thermal, inertia, gravity, or quantum sectors before a Q2 exists.

## D0004 — Historical multiscale reanalysis is discovery only

Exact matched-copy v25 traces show channel-specific inward effects: semantic=4 altered inner/middle occupancy by tick 72 in all three replicates; ablation and direction removal altered the middle by 72 and inner by 216; common clock=17 was inert; s_reg removal changed hashes without occupancy changes. These timings were computed from existing telemetry and are not a v27 confirmation. The multiple inspected channels incur flexibility cost and cannot define a retrospective lock.

## D0005 — Confirmation firewall

MSD01 will be labeled discovery. No case from it can become confirmatory. If it yields a candidate, one exact descriptor/model/metric/domain and minimum effect will be written to `HOLDOUT_LOCKS`, SHA-256 hashed, copied into `ADAPTIVE_STATE.json`, `RUN_LOG.ndjson`, and `EXPERIMENT_INDEX.csv`, and only then evaluated on unopened seeds/sizes.

## D0006 — MSD01 integrity and immediate adjudication

MSD01 executed the real hash-pinned v27 binary for 33 trajectories and 1,776 universe-ticks at N=32/40. Exact joint raw+clock inventory preservation and geometry change passed in all four shuffle controls; deterministic replay passed; no raw difference violated the proven `3t` envelope. The result and compressed endpoint states hash to `7966f4c...f5b20` and `e10fe1b...b3211`.

The outer ablation and direction-zero worlds became exactly response-equivalent in all four cases. Thus positive inventory without routing was dynamically equivalent to removal in this apparatus. Both clock interventions were raw-inert. The same-inventory shuffle reduced straight inner ballistic hits and changed all inner response words. These are computational facts from discovery, not confirmation of a selected Q2.

## D0007 — Unexpected basin branch

MSD01 revealed sparse and near-full dense terminal regimes. One N40 preparation stayed sparse at 113/64,000 occupied sites, while changing only outer semantic to persistent source behavior drove 63,393/64,000. Another N40 preparation was already dense under baseline. Because the signal was found after inspecting variants and seeds, it remains `SIGNAL`; it creates `H-Q2-BASIN-GROWTH` and mandates MSD02 discovery rather than retrospective promotion.

## D0008 — MSD02 model-selection result

MSD02 executed 60 fresh trajectories/4,140 universe-ticks across 20 seed groups at N36/N40. Exact joint-inventory preservation passed for every baseline/shuffle pair. The finite-horizon occupancy distribution split 10 below and 50 above 0.5; its largest adjacent gap was 0.39284375–0.9540252058. Grouped leave-one-seed-out majority and tested single inventory/static-organization stumps had balanced accuracy 0.50/0.54. The best inspected early-response stumps reached 0.95, with `direction_nonzero/N^3` at t20 making one error in 60.

Because the feature, time and model were selected from a bank, this is `SIGNAL`, not `PROVISIONAL_PROGRESS` or confirmation. The narrow tested claim that a single static feature from this bank suffices is marked REFUTED; untested static descriptors remain open.

## D0009 — Do not mislabel a transient as a basin

The one error was an N40 semantic-source world at occupancy 0.3928 whose density was still accelerating at t72; its baseline was also beginning a delayed cascade. Therefore the t66/t72 class is a finite-horizon regime, not yet a basin. MSD03 will rerun only the deterministically reconstructible overlap needed to verify prior endpoint hashes, then extend all low/censored paths and representative high controls. This limited repetition is scientifically necessary because MSD02 did not persist endpoint arrays.

## D0010 — MSD03 resolves recurrence versus censoring

MSD03 reconstructed 14 trajectories, verified every MSD02 overlap raw+clock hash, and extended them through t=512 (7,168 kernel ticks). Seven N36 trajectories remained below 0.01 occupancy and their raw projections repeated with period N over the tested tail; seven controls/censored worlds entered occupancy above 0.9 with raw fixed over the tested tail. The three N40 censored variants crossed 0.5 at ticks 81, 74 and 95. These are finite-window raw-projection facts, not proofs that the exact full state `(raw,clock)` is periodic or fixed.

## D0011 — Discovery growth law and compression

Across all 60 MSD02 rows with MSD03-resolved outcomes, `Delta_A_N=[count(direction!=0,N)-count(direction!=0,ceil(N/2))]/N^3` separated 53 dense-window and seven sparse-period-N-window cases without error or abstention. The separation margin was 0.00135537 and two integer counts require 32 bits versus 5.97–8.19 million raw+clock bits. Because the field, times, formula, threshold and endpoint were selected after viewing MSD01–03, this is `SIGNAL` only.

## D0012 — Adversarial simplification before holdout

MSD04 tested simpler frozen-candidate competitors on discovery data. `occupancy_fraction(N)` alone separated the same 60/60 cases (max sparse 0.00319359, min dense 0.00364063), and the chosen Delta-direction rule made predictions identical to both Delta-occupancy and the best one-time occupancy stump. Delta-direction and Delta-occupancy correlated 0.999933. Thus routing specificity and uniqueness of the two-time descriptor are not supported. The leading minimal candidate is now the one-count positive-state-support fraction `q_N`; state-zero directed sources proven elsewhere mean this is not synonymous with causal activity, and it is not identified with matter. MSH01 remained unopened, so revising its unsealed runner/contract is valid discovery adaptation rather than refitting.

## D0013 — MSH01 pre-holdout freeze

After an independent adversarial audit, the final runner hash `344dc5bb...861771` was frozen with its transitive MSD02/MSD01 hashes and exact wheel/package/kernel identities. The contract fixes `q_N`, threshold `0.003417106052812071`, a size-only adversary, earlier-time/direction/delta competitors, raw-window outcome definitions, twenty independent seed groups at unseen N35/N37/N42, two mixed-group and four-groups-per-class minima, and a separate pre-crossing subanalysis. The frozen lock hash is `6c5ee4b7...353ee`; its canonical payload hash is `8849be50...591a`. Verification passed while `HOLDOUTS/MSH01_results.json` was absent. Neither runner nor lock may now be edited.

## D0014 — Literal MSH01 adjudication

The frozen runner executed once on all 60 rows and wrote result hash `c87eff9a...1c67f`. Kernel/package/wheel hashes and threads=1 matched. The literal verdict is `INCONCLUSIVE_CLASS_DIVERSITY`, not PASS: there were 51 `DENSE_RAW_FIXED_WINDOW`, five `SPARSE_RAW_PERIOD_N_WINDOW`, and four `OTHER` outcomes. Sparse outcomes occupied only three independent `(N,seed)` groups against the preregistered minimum four. Three groups were mixed and size specificity passed, but neither fact overrides the frozen diversity rule. The four OTHER rows are primary errors and remain included. The pre-crossing subanalysis is separately `INCONCLUSIVE_PRE_CROSSING_DIVERSITY` (10 delayed-dense groups, three sparse groups, four OTHER errors). No stagnation counter resets.

## D0015 — Unexpected non-dense heterogeneity

All 51 dense outcomes lay above the frozen `q_N` threshold and all nine non-dense outcomes lay below it; interpreting the endpoint as dense versus non-dense would therefore be 60/60, but this is post-hoc and is recorded only as `SIGNAL`. The four OTHER rows had stable very low occupancy counts over the terminal window yet lacked raw period 1 or N. This motivates two new discovery branches: a broad Q2 dense/non-dense order candidate and a subordinate Q3 recurrence/phase candidate. MSD05 may reconstruct only these rows plus declared controls, must verify their sealed t=4N raw+clock hashes, and cannot alter MSH01.

## D0016 — MSD05 technical abort and repair

The first MSD05 attempt aborted on its first selected trajectory before writing any result because the analysis wrapper requested decoded key `s_reg`; the actual inherited API key is `sreg`. `RESULTS/MSD05_results.json` and temporaries were absent. This is `TECHNICAL_INTERRUPTION`, not a scientific result or stagnation event. The two key references were corrected, the runner hash changed, and a new static audit is required before the full deterministic rerun.

## D0017 — MSD05 resolves OTHER as horizon censoring

The repaired MSD05 runner hash `11ec7f7b...74385` passed static audit and executed nine non-dense rows for 5,200 v27 ticks. All 4N raw+clock overlaps match MSH01. None became dense. By 16N, every one—including all four prior OTHER rows—had exact period N in raw, state, positive mask, direction, s_reg and semantic projections over the tested tail; aggregate counts were constant from 4N onward. The proposed stable third recurrence class is therefore refuted in this panel. What differed was the time at which the period-N witness became demonstrable under MSH01's backward-looking tail criterion.

## D0018 — Refined endpoint remains post-hoc

Changing the endpoint to an asymmetric witness—dense raw-fixed by 4N versus sparse exact raw-period-N by 16N—makes the unchanged q_N threshold classify 60/60 MSH01 rows, with 20/5 independent class groups, five mixed groups, BA advantage 0.38235 over size-only and 0/25 pre-crossing errors. These numbers are explicitly counterfactual/post-hoc; they do not repair MSH01. Before a new holdout, MSD06 must distinguish positive-state support from routed lineage population because q_N and direction-based competitors tied throughout the existing panel.

## D0019 — Ledger-write interruption reconciled without scientific effect

The prior turn ended while the idempotent artifact-tool upsert for MSD05/MSA05/C0007 was running. Recovery found no updater process, no report, no requested rows and all five ledgers at their exact pre-upsert hashes, proving that no partial write occurred. The same update specification was then executed once to completion. All five ledgers passed artifact-tool in-memory round-trip and CSV reimport validation; the report hash is `1212ec1c...f42ad`. This interruption is purely technical, does not alter evidence or counters, and the next scientific action remains MSD06.

## D0020 — MSD06 hybrid intervention and integrity

An adversarial review found that initial outer-shell interventions alone could identify preparation effects but not the causal role of post-treatment q_N. Before execution, the unsealed MSD06 runner was therefore strengthened to two stages: an outer 2x2 field-deletion panel through N, followed by a whole-torus 2x2 deletion at the exact unmodified N snapshot through 8N. A q/state/direction-support/histogram-preserving direction-word permutation and an opened pre-crossing matched pair were included as declared discovery controls. Two independent audits found no blocker. The final runner `9bb9df29...a1bc` executed once; all replays and exact mechanistic controls passed.

## D0021 — q_N is an order parameter, not the sole carrier

MSD06 refutes a single-field causal reading without refuting the natural-manifold predictive candidate. Deleting direction while holding q and every state value fixed changed the 8N witness in 5/6 and prevented the clean precursor cascade. Deleting state while retaining the routing complement preserved the witness in 6/6 and reconstructed all sparse trajectories exactly after one tick. Dense onset nevertheless required a large P×R interaction, and mature dense states could persist under either complement. The mechanistic candidate is therefore phase-dependent P + routing complement R + destination geometry. This remains `SIGNAL`; MSH02 will test only the frozen q_N predictive law on unopened natural preparations.

## D0022 — Unexpected direction-free fixed window preserved

The N37 mature-dense direction-deletion arm reached a raw-fixed window at q=43,040/50,653=0.84970288 from global tick 41 through 296. It was labeled `OTHER_BY_8N` only because q<0.9, not because recurrence failed. This is recorded as an intervention-induced intermediate fixed window, not a stable natural third class or an infinite-time fixed-point theorem. Its existence prevents the endpoint thresholds from being treated as an exhaustive ontology.

## D0023 — MSD06 closure and MSH02 gate

MSD06 was entered into all five ledgers through the existing idempotent artifact-tool workflow. Every in-memory CSV round-trip and exported CSV reimport passed; report SHA-256 is `69cd3f5d...57374`. Because MSD06 is post-holdout, off-manifold discovery, it does not reset the stagnation counter. The current parsimonious tested architecture P+R+destination geometry is not claimed minimal because the components inside R were not separately ablated. The next and final local Q2 discriminator is MSH02 on unopened natural preparations. Its primary law remains the unchanged q_N threshold and asymmetric witness; its causal wording is frozen as prediction/order only. PASS additionally requires a prospectively defined pre-crossing cohort with adequate delayed-dense and sparse group diversity and incremental value over the best named null. A primary counterexample is a FAIL even if diversity is insufficient; lack of counterexamples with insufficient diversity is inconclusive.

## D0024 — MSH02 frozen unopened and ready for single execution

The final MSH02 draft passed static contract validation, direct runner audit and frozen-transitive-hash verification while `HOLDOUTS/MSH02_results.json` was absent. It fixes two unused sizes (N33/N38), twenty mechanically SHA-derived unused seed groups, three inherited natural preparation arms, the unchanged exact integer q_N rule, the asymmetric 4N/16N raw witness, an independently defined no-crossing-by-N subset, and the best of three frozen nuisance nulls. Runner SHA-256 is `85f6cccf...9d1f7`; draft SHA-256 is `c9997278...c53e`; canonical contract SHA-256 is `ce6a2ef3...e1a5`; final lock SHA-256 is `e0cf5309...24f88`.

The first lock-publication attempt was denied by the workspace sandbox before creating a lock, temporary, sidecar or result file. Verification found no partial artifact, after which the identical audited freeze was executed successfully. This is `TECHNICAL_INTERRUPTION` with no scientific effect. The frozen-lock ledger upsert then passed artifact-tool round-trip and CSV reimport checks; report SHA-256 is `57f7b62f...83c9`. No criterion, hypothesis, evidence label or stagnation counter changed. The only authorized next action is the single frozen MSH02 execution.

## D0025 — Literal MSH02 PASS and bounded Q2 promotion

The frozen MSH02 runner executed exactly once with CPython 3.13 x64, `threads=1`, the hash-pinned wheel/package/kernel, all 60 specified rows and no exclusions. Its atomic result SHA-256 is `83b8cc52...9b52`. It observed 50 dense raw-fixed windows, ten sparse minimal exact raw-period-N windows and zero OTHER. The q_N primary was correct 60/60 and in each size; all 20 seed groups had every arm correct, dense/sparse classes occupied 20/5 groups and five were mixed. Full-panel BA was 1 versus 33/50 for the best frozen nuisance null, an exact advantage 17/50. The prospectively defined pre-crossing cohort contained 22 rows and passed 22/22 across eight delayed-dense and five sparse groups, with exact BA advantage 1/2. Minimum compression gain was 287495/287496.

The executable self-adjudication and two independent recalculations found zero discrepancy, so the literal result is `PASS_CONFIRMED_PROGRESS`. Q2 is promoted only for the declared N33/N38 natural preparations, raw projection and 4N/16N horizons; the Q2/global stagnation counter resets to zero. This does not repair or relabel MSH01, prove an asymptotic basin, identify matter/energy, establish full-state periodicity or reverse MSD06's causal negative. The frozen descriptive direction-support comparator also scored 60/60, so q_N is a confirmed compact order coordinate but is not uniquely selected as the underlying causal object.

## D0026 — Audit-wrapper schema correction has no scientific effect

The first post-holdout audit-wrapper execution hard-coded a guessed result-schema literal and therefore emitted `AUDIT_FAIL` even though every numerical, hash, protocol, outcome and adjudication check was true. The observed schema literal was read directly from the immutable result, the wrapper alone was corrected, and the audit was rerun without executing the kernel. Final audit SHA-256 is `0747222f...67c7` and status is PASS. This is analysis-instrumentation repair, not a repeat holdout, evidence change or scientific FAIL.

## D0027 — External Rosetta gate and stopping rule

MSH02 supplies the previously missing confirmed internal dimensionless relation, but it does not create a physical dictionary. The inherited external contract and already-opened results were audited without repetition. E1/E2 remain `COMPATIBLE_NOT_VALIDATING` and cancel the common scale; E3 remains `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`; E4/E5 have no qualifying local dataset. The workspace contains no independent map from laboratory preparation to an ensemble over X/Z/Q2, no detector/measurement forward operator, no dimensional calibration split and no unopened external holdout tied to q_N.

No further local execution of F_DEE can determine which DEE preparation nature realizes, what a detector reads, or the voxel/tick-to-SI scale. Those are external identification inputs, not latent kernel outputs. The mission therefore closes under the explicitly authorized state `HIERARCHY_FOUND_EXTERNAL_FRONTIER`, not as a FAIL of H_DEE. The exact missing construction is `physical preparation -> DEE ensemble -> causal/coarse-grained history -> measurement/forward operator -> distribution of detector records`, calibrated separately and tested on at least two new external families with more observables than parameters.

## D0028 — Final portability reconciliation

Pre-package QA found legacy ledger rows with `PENDING_MANIFEST`, parent-relative evidence paths and two anchor/hash mismatches. Five sealed or verified foundation sources were copied byte-for-byte into `EVIDENCE_FOUNDATION`; additional V6/V7 and Rosetta evidence was copied for standalone audit. The existing artifact-tool workflow then replaced nine claim rows, two experiment rows and four magnitude rows with portable paths and real hashes. All CSV memory round-trips and exported reimports passed; report SHA-256 is `42a57a53...e55f`. The hypothesis tree's status values were normalized to the mandated vocabulary while retaining scope in a separate `qualification` field. No scientific status was promoted by this mechanical reconciliation.
