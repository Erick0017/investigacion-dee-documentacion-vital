# Independent audit of Claude T1–T7

Claude was treated as an adversarial hypothesis generator, not an authority. Every item below was checked against the actual v27 wheel/source contract and executable runners; v25 arguments were not transferred silently.

## T1 — causal cone

**Verdict: REFUTED as stated.** Radius one is not the universal raw cone. The exact one-step upper bound is Chebyshev radius three, and a distance-three witness exists. The multi-step bound is `r_infinity<=3t`. Clock dependence is radius one.

## T2 — exact clock evolution

**Verdict: SURVIVES, with modular wording.** Every clock cell advances by one modulo `2^64`; clock differences are invariant modulo `2^64`.

## T3 — clock redundancy/period

**Verdict: CONDITIONED AND CORRECTED.** The proposed 1,094,573,220 is not the minimal active raw period. In the no-wrap audited gate algebra, primitive periods 195,260,391,782 have LCM 304,980. Clock cannot be quotiented globally from the full state because it continues to evolve and controls gates. It may be eliminated only in certified phase-insensitive sectors.

## T4 — no additive range-zero invariants

**Verdict: REFUTED.** Persistent semantic-4 raws generate a nontrivial family of range-zero charges `Q_f`. State-zero directed sources also defeat occupancy-only intuitions. This refutes only Claude's universal statement; it does not establish a useful global energy.

## T5 — non-injectivity

**Verdict: SURVIVES with corrected witness and scope.** Distinct singleton state-1/state-2 raws collide for `N>=3`, proving global non-injectivity. The result does not imply that every raw has multiple preimages or that no reversible sector exists.

## T6 — symmetry group and DEMUX anisotropy

**Verdict: PARTIAL.** Torus translations are exact. Full cubic `O_h` is not a global symmetry because lexicographic/tie and overflow behavior provides counterexamples. Some sectors retain larger stabilizers and rigid-translation symmetries; a global failure does not eliminate emergent or sectorial isotropy.

## T7 — Bell/CHSH

**Verdict: CONDITIONAL MATHEMATICS, NOT A DEE RESULT.** Generic CHSH statements require defined preparations, subsystems, settings, outcomes and a probability/measurement rule. DEE v27 currently supplies none of those as a frozen physical apparatus. No Bell violation or Bell-local model has been established for DEE.

## Transfer audit

Claims whose proofs used v25 remain historical unless their premises were shown invariant or rerun on v27. The v27 wheel identity is SHA-256 `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`; the loaded kernel is `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

MSH02 does not alter T1–T7. It adds a finite-domain empirical Q2 law and simultaneously reinforces the warning that predictive observables need not be unique or causally sufficient.
