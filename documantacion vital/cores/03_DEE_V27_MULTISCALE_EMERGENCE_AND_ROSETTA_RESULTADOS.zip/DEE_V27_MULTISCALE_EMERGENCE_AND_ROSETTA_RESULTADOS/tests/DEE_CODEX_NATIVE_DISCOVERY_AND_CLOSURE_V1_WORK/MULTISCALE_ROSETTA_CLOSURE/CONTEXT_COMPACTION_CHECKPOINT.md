# Context compaction checkpoint

WHAT_IS_PROVEN: Q0 exact; Q1 exact only in `D_*`; T10 FAIL and T12 repair; v27 V7-C same-inventory/history modulation and local mediation; V7-B frozen reader transfer; V6-E observer fiber failures.

WHAT_IS_REFUTED: Automatic occupancy ontology; single state/event ledger; automatic v25-to-v27 transfer; validated external Rosetta.

WHAT_IS_SECTORIAL: `M_*`, `G_dagger`, `J_dagger`, ballistic lineages, free advection and collision laws.

WHAT_IS_PROVISIONAL: v25 matched nested-shell channel-specific inward effects.

WEAK_SIGNALS: None registered yet.

WHAT_IS_ACTIVE: Q2 relational-response, cross-scale carrier, transfer functional identity, shared-Q* Rosetta, microscopic-only null.

WHAT_IS_UNKNOWN: Minimal causal descriptor, compression/predictive retention, effective Q2 law, preparation/readout bridge.

CURRENT_HIERARCHY: `Q0 -> Q1 -> Q2 candidate`.

CURRENT_ROSETTA: internal partial chain only; external target closed.

CURRENT_BLOCKER: none.

NEXT_BEST_TEST: Implement and execute MSD01 discovery on the real v27 wheel.
