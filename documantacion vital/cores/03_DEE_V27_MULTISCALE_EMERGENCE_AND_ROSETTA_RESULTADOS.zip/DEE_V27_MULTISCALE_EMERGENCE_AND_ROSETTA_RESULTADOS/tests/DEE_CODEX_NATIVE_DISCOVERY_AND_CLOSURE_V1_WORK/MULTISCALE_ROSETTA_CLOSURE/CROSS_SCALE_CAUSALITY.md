# Cross-scale causality

## Native causal chain

`packed fields + clock phase`
`-> guarded proposals`
`-> routed destinations and multiplicities`
`-> collision/event reduction`
`-> support growth, transport or annihilation`
`-> first-passage and recurrence history`
`-> finite Q2 regime witness`.

The exact raw cone is `r_infinity(t)<=3t`, not radius one. The substrate is a periodic combinatorial torus; the effective causal graph is directed and state/phase dependent.

## Evidence across scales

- MSD01: causal differences propagated inward within the 3t envelope; same inventory with different spatial organization changed all tested inner responses.
- MSD02: static descriptors failed, while an evolved collective support/routing population predicted the finite-horizon class.
- MSD03–05: long histories separated delayed ignition from sparse exact recurrence and removed the false third-class interpretation.
- MSD06: component deletion showed that q/state predicts on the natural manifold but does not carry the dynamics alone. R regenerated support; P×R interaction dominated selected onset.
- MSH02: the frozen q_N law generalized prospectively at unused sizes/seeds and before dense crossing.

## Geometry

DEE has three distinct geometries that must not be conflated:

1. fixed torus adjacency/stencil;
2. instantaneous directed proposal/destination graph;
3. effective geometry inferred from response and first-passage histories.

Only the first two are directly defined. The third is empirically accessible but no dynamic metric, curvature or gravitational backreaction has been identified.

## Causal sufficiency

Q0 is sufficient globally. Q1 is sufficient in `D_*`. q_N is sufficient only for one declared projected endpoint on one natural preparation family; it is neither sufficient for raw trajectory nor a minimal causal observer. This layered use of “sufficient” prevents a predictive scalar from being mistaken for ontology.
