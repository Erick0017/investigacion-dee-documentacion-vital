# Cycle 0002

QUESTION: Which variables transmit nested outer-to-inner effects on v27, and did a higher-level signal appear?

COMPETING_HYPOTHESES: directed causal lineages; scalar inventory; clock organization; semantic sources; microscopic-only null.

DISCOVERY_OR_CONFIRMATION: DISCOVERY.

PREHOLDOUT_LOCK_IF_ANY: None; result is ineligible for confirmation by design.

TEST: MSD01 exact matched nested shells, N=32/40, 33 trajectories, 1,776 ticks, eight arms and exact joint-inventory shuffles.

RESULT: Routing carries first-passage; content without direction equals ablation; clock interventions are raw-inert; same inventory with changed direction-position relations changes 4/4 response words; all differences obey 3t. Sparse/dense regimes and one semantic-source basin crossing appeared.

PROGRESS_CLASSIFICATION: SIGNAL.

WHAT_DIED: Scalar inventory sufficiency in this apparatus; clock mediation in this apparatus; promotion of first-passage alone to Q2.

WHAT_SURVIVED: Directed reachability as mediator candidate; functional organization; microscopic-only null remains for basin prediction.

UNEXPECTED_RESULT: Preparation-dependent sparse/dense bifurcation and semantic-source crossing.

WHAT_WAS_DISCOVERED: A falsifiable candidate collective basin/growth variable.

LEVEL_IMPLICATION: Q1 explains causal arrival; Q2 remains unpromoted pending basin compression and prediction.

ROSETTA_IMPLICATION: A basin/response Q* could be more plausible than raw state for preparation/readout mapping; external search stays closed.

STAGNATION_COUNTER: 0.

NEXT_TEST: MSD02 fresh-seed basin/growth discovery.
