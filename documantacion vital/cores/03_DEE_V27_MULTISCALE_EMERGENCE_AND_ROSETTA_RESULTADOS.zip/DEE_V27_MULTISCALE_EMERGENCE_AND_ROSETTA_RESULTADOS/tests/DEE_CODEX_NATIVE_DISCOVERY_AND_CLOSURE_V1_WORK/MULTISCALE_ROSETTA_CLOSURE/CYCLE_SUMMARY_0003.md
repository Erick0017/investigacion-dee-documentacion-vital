# Cycle 0003

QUESTION: Can compact variables predict the sparse/dense outcome across fresh preparations?

COMPETING_HYPOTHESES: inventory; static path organization; early collective growth; microscopic-only null.

DISCOVERY_OR_CONFIRMATION: DISCOVERY/model selection.

PREHOLDOUT_LOCK_IF_ANY: None.

TEST: MSD02, 60 trajectories, 4,140 ticks, N36/N40, grouped CV across 20 seeds.

RESULT: Static tested features did not beat majority; selected early routing density at t20 made 1/60 grouped-CV errors (BA 0.95). Outcome gap was large, but one negative was still accelerating.

PROGRESS_CLASSIFICATION: SIGNAL.

WHAT_DIED: The exact tested claim that one static feature in the MSD02 bank suffices; the right to call t66/t72 labels basins.

WHAT_SURVIVED: Dynamic growth/ignition Q2 candidate; organization and semantic sources as latency controls.

UNEXPECTED_RESULT: The classifier error exposed time censoring rather than random failure.

WHAT_WAS_DISCOVERED: Candidate active-routing density and ignition-time formulation.

LEVEL_IMPLICATION: Q2, if real, is dynamic/response-based rather than a static picture descriptor.

ROSETTA_IMPLICATION: A detector may map to transition time/rate instead of raw snapshot; external search remains closed.

STAGNATION_COUNTER: 0.

NEXT_TEST: MSD03 long-horizon recurrence versus delayed ignition.
