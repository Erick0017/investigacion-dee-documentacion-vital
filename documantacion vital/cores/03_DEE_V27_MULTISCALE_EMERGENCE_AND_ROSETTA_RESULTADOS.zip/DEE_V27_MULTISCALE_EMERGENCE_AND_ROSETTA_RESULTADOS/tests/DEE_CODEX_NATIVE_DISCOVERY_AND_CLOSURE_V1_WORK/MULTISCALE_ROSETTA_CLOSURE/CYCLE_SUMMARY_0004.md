# Cycle 0004 — recurrence, latency and candidate minimization

MSD03 resolved the horizon ambiguity: seven tested worlds occupy sparse raw-period-N windows, seven occupy dense raw-fixed windows, and three previously low N40 worlds were merely delayed. This is a DEE-specific projected-sector split in the tested nested preparations.

The first discovery classifier, a two-time direction-growth delta, separated all 60 resolved cases with extreme microstate compression. An adversarial comparison then found an equally accurate one-count observable, `q_N=occupancy_fraction(t=N)`. This removes evidence for direction specificity and makes `q_N` the minimal holdout candidate. It is named positive-state support, not causal activity or matter: DEE also admits state-zero directed sources.

Progress remains `SIGNAL`; no holdout has been opened. MSH01 must be revised before sealing to verify the full transitive runner chain, include odd/even unseen sizes, report locked competitor models, use independent seed-group diversity, and label only finite raw-projection windows.
