# Cycle 0008 — MSD06 causal discrimination

MSD06 completed 9,010 v27 ticks with all raw+clock replays, bitwise intervention audits, clock nulls and one-step DEMUX predictions passing. The result changes the mechanistic interpretation but remains post-holdout discovery.

`q_N` is retained as a compact order coordinate on natural preparations and demoted as a causal carrier. The current parsimonious tested discovery architecture is phase-dependent P+R+destination geometry: routing-complement R regenerates support exactly in sparse paths; P and R interact at dense onset; mature dense paths show coarse redundancy. Minimality remains unproved because MSD06 did not separately ablate every field inside R. A direction-histogram-preserving permutation changed raw trajectories 6/6 and coarse class 0/6. A direction-free intervention also exposed an exact intermediate-density raw-fixed window through 256 consecutive observed ticks.

No `CONFIRMED_PROGRESS` occurred, so the stagnation counter remains two. The next step is the decisive MSH02 pre-holdout lock for the natural-manifold predictive law q_N -> dense-fixed by4N versus sparse exact period-N by16N. A literal PASS resets the counter; a non-confirming result reaches the branch stopping rule.
