# DEE v27 multiscale emergence and Rosetta

## Scope and stopping state

This report is authoritative for the resumed multiscale campaign. It preserves all sealed predecessor results, every literal FAIL and both holdout outcomes. The stopping state is `HIERARCHY_FOUND_EXTERNAL_FRONTIER`: an internal hierarchy is established through a finite-domain confirmed Q2, while physical identification requires a specifically defined external experiment and mapping.

### 1. Which levels are demonstrated?

`Q0=X=(raw,clock)` is exact and global. `Q1=(Z,G_dagger,J_dagger)` is exact/predictively validated only in its certified sparse domain `D_*`. `Q2` is prospectively confirmed within the MSH02 domain: the collective support coordinate `q_N` predicts an asymmetric dense-fixed or sparse-period-N raw witness. No Q3 was promoted; a stable third sparse class was refuted in the MSD05 panel.

### 2. Which degrees of freedom are microscopic?

The packed `raw` record contains decoded `state`, `direction`, `s_reg` and `semantic`; `clock` is a separate uint64 field. Exact future raw generally requires both raw and clock. Occupancy/state alone is not a microscopic causal state.

### 3. What do those degrees construct jointly?

They construct state- and phase-dependent proposals, routed destination sets, collision multiplicities, semantic guards/sources, persistence and annihilation. Those objects define a directed causal hypergraph over the fixed torus.

### 4. Which higher entities appear?

Certified causal lineages, latent routers, persistent observer/source sites, collision events, free gases, dense raw-fixed organizations, sparse period-N organizations and a Q2 quotient of future raw behavior appear. “Basin” is used only for finite tested witnesses unless asymptotic attraction was proved.

### 5. Which properties exist only collectively?

Dense ignition/fixation, the sparse/dense regime split, response to inventory-preserving spatial rearrangement, pre-crossing predictability and robustness of a coarse witness under direction-word permutation are collective. No single initial inventory count explained MSD02; a time-evolved support population did.

### 6. What survives component replacement?

In sparse MSD06 paths, deleting positive state while retaining routing coalesced exactly after one tick. Mature dense states could preserve macroscopic support after deleting either complement, although raw microstates differed. Direction-word permutation changed every tested raw trajectory but no 8N witness class. These are bounded intervention facts, not universal equivalences.

### 7. What distinguishes content from organization?

MSD01 joint outer raw+clock shuffles preserved content inventory exactly but changed geometry and all four tested inner responses. V7-C independently supports the same distinction in its apparatus. Content-only observables therefore miss causally relevant arrangement.

### 8. What distinguishes state from event?

T10 showed a single reduced state that retained collision outputs failed exact closure. T12 repaired this by separating predictive state `G_dagger` from instantaneous event ledger `J_dagger`. An event may be necessary for accounting without persisting as the next causal state.

### 9. What distinguishes object from medium?

There is no absolute split. In `D_*`, carriers and persistent sources have operational roles, while latent routers can have `state=0` yet remain causally active. Outside that sector, the organized proposal field and destination geometry jointly act as medium and object. Role is functional and relational.

### 10. What role does history play?

Clock phase changes guarded transitions; first-passage time distinguishes delayed ignition from already-dense trajectories; recurrence witnesses require trajectory windows; same endpoint counts can arise from causally different histories. History cannot generally be replaced by an instantaneous occupancy snapshot.

### 11. Which cross-scale laws exist?

The confirmed law is: within the frozen MSH02 family, compare the positive-state count at `t=N` with the declared integer cutoff (123 for N33, 188 for N38). It predicts dense raw fixation by 4N or sparse minimal exact raw period N by 16N. It achieved 60/60 and passed a 22-row pre-crossing challenge. The direction-support comparator tied it, so the predictor is not unique.

### 12. Which coarse-grainings close?

Q0 closes globally by definition. `M_*` with `G_dagger/J_dagger` closes in `D_*`. The MSH02 q_N quotient closes only for a binary finite-horizon raw witness within its frozen preparation domain; it is not a Markovian autonomous dynamics.

### 13. Which coarse-grainings fail?

Occupancy alone, the original mixed state/event reduction, tested macro/distribution fibers in V6-E, a tested bank of static inventory/path features, and q_N/the positive-state field as a sole causal carrier fail in their declared panels. None of these bounded FAILs proves that all relational or higher-order observers fail.

### 14. Which native DEE magnitudes were identified?

Raw causal radius, modular clock offsets, ballistic direction/velocity, collision event load, joint inventory hash, directed-path collision measures, first-divergence time, active routing density, ignition time, q_N, projected regime label, recurrence phase, asymmetric regime witness, routing complement and routed destination geometry. Definitions and domains are in `DEE_NATIVE_MAGNITUDES.csv`.

### 15. How are they measured?

By exact bit decoding, integer counts, modular subtraction, full-array equality, cryptographic hashes, directed proposal maps, collision multiplicities, first-passage scans and frozen intervention-response words. No physical instrument interpretation is assumed.

### 16. What do they predict?

They predict causal envelopes, free translation, collision outcomes, source trains, first divergence, finite-horizon ignition/recurrence and the MSH02 regime witness. Only predictions with declared domain and evidence status are licensed.

### 17. Which historical results receive a common explanation?

Ballistic motion, collision responses, persistent observer pumping, transfer/reinstantiation, nested-shell inward influence, delayed dense cascades and sparse recurrence all fit the proposal-routing-guard-event architecture. Historical v25 results remain v25 evidence unless rerun on v27.

### 18. Which results were observer/level artifacts?

Radius-1 causality arose from inspecting too shallow a dependency; raw periodicity was confused with full-state periodicity; FFT-window bins were called native periods; occupancy hid state-zero routers; finite 4N censorship created apparent third outcomes; and a predictive order parameter was at risk of being called a carrier.

### 19. Which results do not belong to this architecture?

External constants fitted constitutionally, generic eventual periodicity of finite systems, abstract Koopman unitarity, and analogies to quantum, gravity or thermodynamics do not become DEE-specific mechanisms merely by coexistence.

### 20. What Q* is the best Rosetta candidate?

No single scalar is sufficient. The best internal candidate is a structured Q*: certified Q1 causal records/events plus phase-dependent `P+R+destination geometry`, with q_N as a compact finite-domain order readout. q_N alone is too lossy and non-unique.

### 21. What concrete Rosetta was built?

An internal Rosetta:

`X -> M_* -> (G_dagger,J_dagger) -> P/R/destination relations -> q_N -> dense-fixed or sparse-period-N raw witness`.

It maps computation to native function, not yet to laboratory physics.

### 22. Which data calibrate it?

Internal discovery data MSD01–MSD06 selected and mechanistically qualified the objects; MSH01 exposed endpoint censoring; MSH02 independently validated the frozen law. No external data calibrate voxel, tick, energy, mass or detector units.

### 23. Which holdouts tested it?

Inherited T8/T9 test ballistic and observer sectors; T10 preserves the failed reduction; T11/T12 validate inverse multiplicity and the repaired state/event separation. MSH01 is `INCONCLUSIVE_CLASS_DIVERSITY`. MSH02 is `PASS_CONFIRMED_PROGRESS`. The inherited external E1–E5 contract produced compatibility/inconclusiveness, not physical validation.

### 24. Which external predictions were produced?

None that is both non-arbitrary and newly validated. E1/E2 were scale-free compatibility checks, E3 lacked a frozen forward operator and E4/E5 lacked qualifying datasets. No external claim was promoted.

### 25. Which known-physics sectors appear functionally?

Finite-speed causal propagation, marked lattice kinetics, free advection, many-to-one collisions, capped event load, sources/boundaries, order parameters and projected regimes appear functionally. These are mathematical roles, not identifications with relativistic, particle, thermodynamic or quantum ontology.

### 26. Which sectors do not yet appear?

Mass/inertia, a conserved physical energy-momentum tensor, equilibrium temperature, hydrodynamic closure, a dynamic shared metric with backreaction, continuous Lorentz symmetry, gauge redundancy, Born probabilities and a Bell/CHSH measurement apparatus are not identified.

### 27. Which patterns were removed by anti-pareidolia controls?

Direction-specific uniqueness of the early separator, static-feature sufficiency, the apparent third sparse class, raw/full-state period conflation, D6 spectral “constants,” global cubic symmetry and q_N causal sufficiency. Nulls, exact hashes, inventory-preserving shuffles, component deletions and unopened holdouts performed the removal.

### 28. Which weak signals remain dormant?

The N37 direction-free intermediate fixed window, ignition-latency scaling, possible non-linear emergent isotropy, richer relational invariants and shared-Q* external mappings remain weak or active hypotheses. None is promoted by analogy.

### 29. Which branches closed by stagnation?

None closed because of technical interruption. The Q2 counter reached two after MSH01/MSD06 but reset only after the literal MSH02 PASS. Physical sectors close locally by external non-identifiability, not by a three-cycle scientific stagnation declaration.

### 30. How much was the wheel actually interrogated?

The resumed campaign ran seven scientific v27 interrogations totaling 306 trajectories/intervention segments and 48,942 universe-ticks at eight distinct N values. Every execution records wheel/kernel hashes, runner, role, controls, runtime and result in `WHL_INTERROGATION_LEDGER.csv`.

### 31. What remains genuinely unknown?

Global minimality of the P/R decomposition, universality/scaling of Q2, interacting slow modes, topological or higher-range invariants, physical ensembles, preparation and measurement maps, SI calibration, and whether any known effective theory arises under a causally sufficient coarse-graining.

## Epistemic boundary

The exact missing H_DEE link is not “more simulation.” It is an independent, frozen generative model from laboratory preparation through DEE histories to detector-record distributions, with separate calibration and external holdouts. Once supplied, it is testable. Without it, correspondence to reality is `NO_IDENTIFICABLE`.
