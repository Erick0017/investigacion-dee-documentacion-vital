# Discovery index

- MSD01: nested causal propagation and same-inventory organization.
- MSD02: finite-horizon basin discovery and static/early feature comparison.
- MSD03: long-horizon recurrence versus delayed ignition.
- MSD04: adversarial simplification to q_N.
- MSD05: resolution of MSH01 OTHER rows and refined asymmetric endpoint.
- MSD06: separation of predictive order from causal carriage; P/R/destination architecture.

Primary results are in `../RESULTS`; adjudications are in `../ANALYSIS`. All are discovery/post-holdout evidence unless explicitly marked otherwise. MSH01/MSH02 confirmation artifacts live in `../HOLDOUTS` and `../HOLDOUT_LOCKS`.
