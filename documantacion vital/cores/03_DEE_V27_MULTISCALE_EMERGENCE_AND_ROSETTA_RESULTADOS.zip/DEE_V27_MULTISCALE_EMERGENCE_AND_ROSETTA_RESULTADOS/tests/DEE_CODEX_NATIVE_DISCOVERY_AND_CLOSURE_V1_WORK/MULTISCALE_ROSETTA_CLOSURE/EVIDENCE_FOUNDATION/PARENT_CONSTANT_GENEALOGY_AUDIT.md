# Auditoría de genealogía de constantes

## Veredicto

Las constantes históricas no constituyen varias predicciones independientes. Forman principalmente una cadena constitutiva compartida:

`alpha* -> Delta_nu* -> K*=ln(1/Delta_nu*) -> {966,782,194422,19665} -> 19664`.

Que los descendientes estén codificados en el kernel demuestra implementación y causalidad interna cuando su rama es alcanzable; no valida de nuevo el input upstream ni identifica una constante natural.

## Estructura frente a inputs

Los conteos `{8,12,6,26,13,7,4}` proceden de la retícula, el stencil y las guardas. Los valores `2.5` y `16`, el gate XNOR y los umbrales de vecindad son elementos de la regla. `v_native=1 voxel/tick`, `P=L` en transporte preparado, la cota causal 3/tick (aguda donde el diámetro toroidal lo permite) y el período raw `304980` son resultados de la dinámica. Ninguno adquiere unidades o identidad física por sí mismo.

`alpha*`, `Delta_nu*` y 20 Hz, en cambio, ya estaban expuestos en el corpus histórico. Se excluyeron como holdouts confirmatorios primarios.

## Descendientes auditados

| Cantidad | Función ejecutable | Dictamen |
|---|---|---|
| `966` | Threshold de cristalización | Inerte en v27 actual: el cociente máximo posible es 49; cualquier threshold `>=50` da la misma rama nunca alcanzada. |
| `782` | Numerador de gates de fase | Causal. Genera, por división entera y contexto, `195,260,391,782`. No es frecuencia física. |
| `304980` | `lcm(195,260,391,782)` | Período causal raw mínimo sin wrap. No es período del full-state. |
| `19665` | Threshold phase-gated | Causal en overflow; una perturbación `+7` desplaza un gate k=6 en `2737=7*391` ticks. |
| `19664` | Cap de suma/delta | Derivado como `19665-1`; causal sólo al saturar. No es evidencia independiente. |
| `194422` | Payload `state` de orphan | No se decrementa; el nombre TTL no lo convierte en lifetime. |
| wrapper `19658` | Metadata Python obsoleta | No controla el binario ejecutado. |
| `ORPHAN_TTL=9` | Payload de siembra distinto | Convención separada, tampoco lifetime dinámico. |

## Sesgo y fuga de target

Contar varios nodos de una cadena como “aciertos” multiplica artificialmente la evidencia. Reconstruir `alpha` desde enteros construidos a partir de `alpha` es circular. Ajustar metros/voxel o segundos/tick para recuperar 20 Hz consume el mismo target que pretende explicar. Los nombres `ELECTROWEAK`, `STRONG`, `observer` o `TTL` son metadatos, no correspondencias físicas.

La comprobación histórica de `P=L` sí es una ley sectorial reproducible: los portadores preparados se trasladan un voxel por tick. En ese mismo aparato, la alternativa `P=(26/12)L` tuvo RMSE `21.0146` frente a cero para `P=L`. Esto adjudica la fórmula dentro de aquel sector, no una frecuencia cerebral.

## Regla de uso futuro

Una constante sólo puede entrar en una Rosetta cuantitativa si se congela antes:

1. el observable DEE y su dominio;
2. el mapa dimensional y los parámetros de calibración;
3. datos de calibración distintos del endpoint;
4. incertidumbre y criterio de fallo;
5. al menos una predicción externa no usada para construirla.

Hasta entonces, los enteros del kernel son parámetros/literales y las relaciones nativas son adimensionales. Esta misión escogió por ello velocidades relativas, first-passage, anisotropía y respuesta en vez de coincidencias numéricas históricas.
