# DEE Rosetta v27 construida

## Veredicto

**Estado de cierre: `ROSETTA_PARTIAL`.**

Se construyó una transformación operacional interna común y ejecutable. No es un diccionario de nombres: es un transductor causal de estado y eventos, derivado por equivalencia predictiva y contrastado contra el wheel v27 real.

La primera formulación congelada no sobrevivió intacta: T10 encontró una contradicción exacta entre la canonicalización de `M_*` y la salida de colisión de `G_*`. Ese `FAIL` se conserva. Después se formuló y congeló una hipótesis nueva que separa estado predictivo de evento transitorio; T12 la confirmó en casos nuevos. T11 confirmó independientemente una predicción inversa del reducer.

La capa física externa no está validada. Dos relaciones nulas sobreviven como `COMPATIBLE_NOT_VALIDATING`, el embedding euclídeo lineal directo falla y dos analogías no tienen datasets calificantes. Por eso la Rosetta es interna y cuantitativa, pero su identidad con nuestra realidad sigue condicionada.

## Transformación operacional

La construcción final es

```text
X_t = (raw_grid, clock_grid)
          |
          | M_*  [sólo en D_*]
          v
Z_t = { (q,d,s,a,p) }
          |
          | transductor (G_dagger, J_dagger)
          +--------------------------+
          v                          v
Z_(t+1) predictivo          E_(t+1) eventos raw
          |                          |
          +------------+-------------+
                       | O_s
                       v
          causalidad / geometría / transporte /
          materia / respuesta / memoria / colisión
                       |
                       | U_s congelada
                       v
              observable externo condicionado
```

`M_*` es instantáneo en el dominio certificado; no requiere historia. La historia reaparece sólo si se elige un readout que no conserva las variables de guard/propuesta o si se sale de `D_*`.

## Estado microscópico `X`

`X` contiene las dos grillas uint64 completas. Raw codifica `state`, `s_reg`, tres componentes int4 de `direction` y `semantic`; el clock es una grilla separada. El mapa real es determinista, síncrono y traslacionalmente equivariante; para `N>=3` es además many-to-one. El clock cumple

`clock_i(t)=clock_i(0)+t mod 2^64`.

La dependencia raw tiene cota Chebyshev `min(3,diam_infty(T_N))` en un tick por la selección anidada DEMUX; la distancia tres es alcanzable cuando el toro lo permite. Ésta es causalidad computacional, no todavía un cono de luz físico.

## Observador causal `M_*`

Para cada sitio `q`, se decodifica `(state,s,d,semantic)` y se emite

`z=(q,d,s,a,p)`, con `a=1[state>0]`, `p=1[semantic=4]`,

si `state>0`, `d` es Moore no nula o `semantic=4`. Se identifican todas las semánticas no observer, se omite un raw no observer `state=0,d=0` y se fija `s=0` para un blocker activo no observer con `d=0`. La magnitud positiva de `state` y el clock se descartan.

Los roles funcionales son:

- `L`: router latente, `a=0,p=0,d!=0`; propone una vez aunque occupancy sea cero;
- `C`: portador o blocker, `a=1,p=0`; cierra su blanco de entrada;
- `O`: fuente/frontera persistente, `p=1`; conserva el raw, se protege y propone repetidamente.

El cociente fue descubierto como partición predictiva: para observable y horizonte fijados, dos estados se identifican exactamente cuando tienen la misma palabra futura. En siete paneles sectoriales, candidato y `ker(W_H^+)` coincidieron sin fallos de suficiencia/minimalidad. No existe un `M_*` global independiente del observable.

## Dominio `D_*`

La reducción exige en cada slice puntuado:

1. `N>=5`;
2. direcciones cero o Moore;
3. a lo sumo siete sitios con `state>0`;
4. a lo sumo tres vecinos positivos alrededor de cada positivo no observer.

Estas condiciones excluyen tetra/supervivencia, XNOR, overflow y gates de fase. No excluyen por etiqueta a semantic 5 activo sparse: T10 lo trata como nuisance dentro del panel y las ramas especiales no se activan. El contraejemplo ejecutado con el mismo `(q,d,s,a,p)` usa ocho positivos alrededor de un centro, activa XNOR y queda fuera de `D_*`; para esa extensión densa se necesita una marca orphan o volver a raw+clock.

## Dinámica efectiva `G_dagger` y eventos `J_dagger`

En `D_*`:

1. `q` está cerrado si `a(q)=1` o `p(q)=1` en la entrada;
2. todo registro con `d` Moore no nula propone `(d,s)` a `q+d mod N`;
3. `p=1` persiste en la fuente;
4. un normal no persiste localmente;
5. sólo blancos abiertos reducen propuestas;
6. una propuesta crea `C(q,d,s)`;
7. varias propuestas calculan

`u=sign(sum_j d_j)`, `S=min(sum_j s_j,19664)`.

El raw inmediato de colisión emite el evento

`J_dagger=(q,u,S)`.

El estado predictivo nuevo es

`C(q,u,S)` si `u!=0`,

`C(q,0,0)` si `u=0`.

La segunda línea es la diferencia decisiva. El raw de una colisión con suma direccional cero sí contiene `S` durante un tick; pero no puede proponer, su portador muere al tick siguiente y `S` no afecta el futuro dentro de `D_*`. Guardar `S` como evento y canonizarlo en el estado preserva a la vez observación y minimalidad predictiva.

La ecuación correcta es

`M_*(F_DEE X)=G_dagger(M_*X)`,

mientras `J_dagger` registra información de la transición que no tiene que pertenecer a `Z_(t+1)`.

## Respuesta `K_dagger`

Para una intervención `I` y una incrustación indicadora `phi`, se define

`K_dagger^t[Z;I]=phi(G_dagger^t(I Z))-phi(G_dagger^t Z)`.

Es un cociclo de diferencias finitas condicionado al baseline, no una convolución lineal global. La pareja baseline/intervenido compone bajo `G_dagger`; las diferencias no obedecen superposición a través de guards, colisiones o cap.

En vuelo libre sí aparece el propagador exacto

`K_free^t((y,d,s),(x,d,s))=delta[y=x+t d mod N]`,

con `K_free^(t+u)=K_free^u K_free^t` y modo Fourier

`rho_hat_m(t+1)=exp(-2*pi*i*m·d/N) rho_hat_m(t)`.

El observer aislado produce, antes del wrap,

`K_obs(t,k)=1[1<=k<=t] 1[k=t mod 2]`.

Una oclusión inicial de su boca causa retraso de primer paso exactamente uno y paridad opuesta en todos los detectores pre-wrap.

## Holdouts internos

### T10 — formulación original

**FAIL_NO_REFIT.** Ejecutó 1,389 trayectorias y 5,598 ticks primarios, con cero fallos de dominio y 30,521 assertions. Hubo 96 fallos de cierre más 96 desalineaciones iteradas, todos y sólo para los cuatro pares body-diagonal opuestos multiplicados por los perfiles congelados. `M_*` daba `s=0`; `G_*` daba `s=S>0`. H10.2 (campos/nuisances) y H10.3 (1,872 composiciones libres) pasaron; los controles de motor pasaron.

### T11 — predicción inversa no usada en discovery

**PASS_NO_REFIT.** Los 56 subconjuntos de cinco de las ocho diagonales corporales produjeron mayoría coordenada. Las ocho salidas tuvieron exactamente siete preimágenes cada una. Pasaron 448 trayectorias/896 ticks, cero mismatches y 4/4 controles de motor. Las cargas cambian `S` pero no ponderan la dirección.

### T12 — hipótesis posterior congelada

**PASS_NO_REFIT respecto de la reparación.** Tras sellar `G_dagger/J_dagger`, se ejecutaron 748 trayectorias/1,496 ticks en `N=19`, aridades 3/4/6: 514 salidas `u=0` y 234 controles no cero. Cierre, evento raw, muerte/traslación, clocks, semánticas y 16/16 controles pasaron; cero fallos de dominio y cero mismatches.

T12 no reetiqueta T10: confirma prospectivamente otro objeto, construido a partir del fallo.

## Readouts sectoriales del mismo estado/evento

| Sector | `O_s` nativo | Ley |
|---|---|---|
| Causalidad | reachability y respuesta a intervención | cota raw `min(3t,diam_infty)`; velocidad tres aguda donde cabe; aristas dirigidas 1/tick en el sector libre |
| Geometría | first-passage sobre `(q,d)` y guards de `Z` | hipergrafo dirigido dependiente del estado, no métrica presupuesta |
| Transporte | posición, capa `d`, etiqueta `s` | advección exacta, sin dispersión por `s/state` |
| Materia | linajes de `C`; configuración no etiquetada de gases | identidad causal sectorial y colisiones many-to-one |
| Fuente | `O` y ocupación de la boca | self-loop fijo y tren alternante pre-wrap |
| Colisión | evento `J_dagger`, estado canónico posterior | suma capada de `s`, signo no ponderado de direcciones |
| Respuesta | `K_dagger[Z;I]` | finite difference condicionado; lineal sólo por estratos |
| Memoria | información necesaria para cierre | ninguna en `Z` dentro de `D_*`; aparente si se omiten guards/eventos |
| Irreversibilidad | tamaño de fibras inversas | pérdida de número/dirección y exceso sobre cap |

## Puentes externos congelados

### E1 — etiqueta y dispersión

`O_E1=max_j |log(v_j/v_ref)|=0` exactamente en vuelo libre. `U_E1` asocia monotonamente bandas de energía con etiquetas `s`; no hay parámetros porque el factor común cancela. Los siete escenarios lineales del análisis primario de Fermi permiten cero: **COMPATIBLE_NOT_VALIDATING**. No identifica energía con `s_reg`.

### E2 — velocidad común de dos clases

`O_E2=log(v_A/v_B)=0`. La asignación GW/EM a dos etiquetas de un mismo estrato es condicional y sin parámetros. El bound primario `-3e-15 <= (v_GW-v_EM)/v_EM <= 7e-16` contiene cero: **COMPATIBLE_NOT_VALIDATING**. No demuestra que ambas señales sean portadores DEE.

### E3 — embedding euclídeo directo

Para todo `A` lineal invertible y `tau>0`,

`max_d ||A d||/min_d ||A d|| >= sqrt(3)`.

La cota demuestra que una sola `A,tau` no hace equiveloces las 26 direcciones. Sin embargo, el contrato no fijó cómo ese conjunto discreto produce el armónico de frecuencia de dos resonadores rotantes, ni la orientación y nuisances del aparato. Por ello el contraste externo es **INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN**. El `FAIL_BRIDGE` original se conserva, pero una auditoría posterior lo supersede; no se ajustó otro mapa.

### E4 — oclusión/fase

Ningún experimento encontrado reunió fuente persistente, blocker unitario, dos detectores temporales y control: **NOT_IDENTIFIABLE**. La ley interna no falla.

### E5 — mayoría de cinco fuentes

Ningún dataset primario encontrado tuvo cinco entradas simultáneas con intensidades y dirección de salida: **NOT_IDENTIFIABLE**. T11 permanece PASS; falta el endpoint externo.

## Calibración

No se estiman metros/voxel ni segundos/tick. E1–E3 son adimensionales y eliminan la escala; la cota de E3 obstruye equivelocidad lineal pero el dato óptico no calibra `A,tau` sin un forward model; E4/E5 no aportan datos. Introducir escalas por dirección/clase o fijarlas usando el target sería refit.

## Interpretación natural

- **Materia:** linajes de portadores `C`, no occupancy genérica. `L` es capacidad de routing latente; `O` es frontera/fuente. Otras fases requieren otros cocientes.
- **Geometría:** reachability de un hipergrafo en espacio de fase, modificada por guards de estado. No se obtuvo una métrica física universal.
- **Clock:** contador modular y fase para gates fuera de `D_*`; no es tiempo SI. En el núcleo sparse se elimina sin pérdida.
- **`s_reg`:** etiqueta transportada y carga de evento sumada/capada; también participa en otras ramas históricas. No es masa ni energía universal.
- **`direction`:** routing, velocidad libre y reducer por signo. No es momentum aditivo.
- **`semantic`:** control de ramas. Observer y orphan son funcionalmente especiales; no son especies físicas demostradas.
- **raw:** campo computacional causal packed. Puede contener propuestas con `state=0` y eventos transitorios que un estado predictivo mínimo descarta; el estado Markoviano completo es `(raw,clock)`.

## Qué teorías efectivas aparecen

La reducción es una cinética discreta marcada con advección, exclusión, coagulación many-to-one y fuentes persistentes. Su sector libre posee una descripción de transporte exacta y modos de Koopman/Fourier. Esto es una teoría efectiva conocida en forma matemática general, pero con reducer, guards y alfabeto específicos de DEE. No se derivaron relatividad, mecánica cuántica, termodinámica, hidrodinámica, gauge o gravedad.

## Pieza exacta faltante bajo `H_DEE`

Hace falta una construcción independiente que reúna:

1. preparación física -> ensemble de `X/Z`;
2. historias/eventos `Z,J` -> resultados y probabilidades de medición;
3. coarse-graining que derive una geometría aproximadamente isotrópica/Lorentziana, sus escalas y un operador forward experimental preregistrable;
4. una calibración común fijada en datos separados;
5. predicciones cruzadas nuevas de al menos dos familias externas, con más observables que parámetros.

El wheel puede determinar la dinámica condicional a una preparación, pero no cuál preparación realiza la naturaleza ni qué lectura corresponde a un detector físico. Esa correspondencia es la frontera estructural demostrada de esta misión.
