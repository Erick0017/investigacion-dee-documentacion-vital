# Espacio de estados efectivo de la Rosetta v27

## Jerarquía de estados

La investigación distingue cinco resoluciones que no deben confundirse:

1. **Estado computacional completo** `X=(raw_grid,clock_grid)`. Es el dominio Markoviano normativo de `F_DEE`.
2. **Manta causal local**: cilindro raw/clock suficiente para un detector y horizonte finitos.
3. **Estado efectivo marcado** `Z=M_*(X)` en `D_*`, suficiente para transporte, exclusión, colisión y fuentes persistentes.
4. **Eventos de transición** `J_dagger`, necesarios para registrar información instantánea que el estado predictivo puede descartar.
5. **Readouts** como occupancy, densidad, primer paso, carga o respuesta. Son funciones de estado/evento y pueden inducir cocientes aún más gruesos.

No se promueve ningún readout a ontología universal.

## Estado computacional

Cada sitio contiene una palabra raw de 64 bits con campos `state`, `s_reg`, `direction` y `semantic`, más un clock uint64. El mapa completo es determinista, síncrono y traslacionalmente equivariante sobre un toro cúbico; para `N>=3` es además many-to-one. El clock forma una base afín `clock'=clock+1 mod 2^64`; raw es la fibra forzada por clocks sólo en ramas específicas.

Este estado completo es suficiente para cualquier interrogación del kernel, pero conserva información irrelevante para muchas respuestas. La Rosetta busca un cociente predictivo, no otra codificación del raw.

## Estado efectivo marcado

En el dominio disperso congelado, `Z` es una configuración excluyente de registros `(q,d,s,a,p)`. Su función es causal:

- la posición y dirección describen una propuesta dirigida;
- `s` es una marca transportada y reducible;
- `a` implementa cierre de blanco por actividad;
- `p` implementa persistencia y protección de fuente.

La dinámica efectiva no necesita magnitud positiva de `state`, fase de clock o semantic ordinaria. Esto explica simultáneamente por qué un raw state-zero puede ser causal y por qué un observer state-zero no equivale al mismo raw normal.

## Sectores exactos

| Sector | Coordenadas predictivas desde `t=1` | Dinámica |
|---|---|---|
| Singleton, laboratorio | `(q,d,s)` | `q -> q+d`; `d,s` constantes. |
| Singleton, módulo traslación | `(d,s)` | Punto fijo del cociente. |
| Gas separado de dirección común | `(d,mu)` | Traslación rígida de la configuración no etiquetada `mu`. |
| Evento de colisión aislada | `J_dagger=(q,S,u)` | `S=min(sum s_j,19664)`, `u=sign(sum d_j)`. |
| Estado posterior a colisión | `(q,u,S)` si `u!=0`; `(q,0,0)` si `u=0` | Canonización predictiva de `M_*`. |
| Fuente observer pre-wrap | `(q,R_obs,tau)` | Fuente fija más tren alternante pre-wrap; `tau` es edad orbital, no clock. |

Estas coordenadas fueron obtenidas como kernels de palabras futuras. No son aproximaciones estadísticas dentro de sus dominios.

## Objetos naturales

La unidad móvil más sencilla no es un voxel ocupado sino una **línea causal de portador normalizado**: el raw local muere y se recrea en el blanco, pero `(d,s)` y la trayectoria `q(t)` persisten. Un conjunto separado de estas líneas forma un gas exacto. Una colisión las identifica many-to-one. Una marca `p` crea una condición de frontera que genera repetidamente líneas.

Por ello, la interpretación interna más económica de “materia” es una familia de linajes causales de registros `C` y sus colectividades restringidas. `L` representa capacidad de routing latente y `O` una fuente/frontera fija. Fases densas supervivientes pertenecen a otras clases y requieren refinar `M_*`.

## Geometría efectiva

Los nodos naturales del sector libre son `(q,d)`, no sólo `q`. Existe una arista

`(q,d) -> (q+d,d)`.

Las colisiones añaden hiperaristas de varios nodos de entrada a un nodo de salida, y los guards eliminan aristas según el estado. La geometría primaria es, por tanto, un hipergrafo causal dirigido dependiente de estado. La distancia nativa correspondiente es first-passage condicionado a capa de velocidad y preparación. La distancia Chebyshev es una envolvente útil, no la distancia física derivada.

Cada capa libre contiene ciclos de longitud `N`, pero esa periodicidad es topología toroidal finita, no cuantización física. La cota causal global raw es `r_Cheb(t)<=min(3t,diam_infty(T_N))`; la velocidad 3/tick es aguda sólo donde el diámetro permite distancia tres e incluye rutas overflow fuera del núcleo `Z`.

## Balances y pérdida de información

En vuelo libre, el número de portadores, las cargas individuales, las direcciones y el patrón relativo son invariantes; la evolución es una permutación. En colisiones simultáneas, la carga del evento se suma sólo hasta el cap y la dirección sufre compresión por signo. Cuando `u=0`, esa carga permanece en el raw del tick de colisión pero `M_*` la descarta porque no puede propagarse; ésta fue la única clase que refutó el `G_*` original en T10. Número de fuentes, magnitud vectorial y, tras saturación, exceso de carga se pierden. Para `N>=3`, la dinámica completa sigue siendo un semigrupo determinista, pero no es invertible.

No se identificaron energía, masa, temperatura o momentum físico. Las conservaciones anteriores son sectoriales y computacionales. Son suficientes para formular una cinética discreta; no bastan para derivar termodinámica o hidrodinámica.

## Frontera de validez

En configuraciones ampliadas, semantic 5 activo junto con las ramas que lo leen, supervivencia/tetra, XNOR, overflow y gates de fase pueden separar fibras que `M_*` colapsa. La etiqueta semantic 5 por sí sola no viola `D_*`: queda colapsada en el régimen sparse probado. Al activar aquellas ramas debe ampliarse el alfabeto efectivo o volver a la manta raw+clock. Un FAIL fuera de `D_*` sería un fallo de extensión del cociente, no de las leyes ya demostradas en su sector.
