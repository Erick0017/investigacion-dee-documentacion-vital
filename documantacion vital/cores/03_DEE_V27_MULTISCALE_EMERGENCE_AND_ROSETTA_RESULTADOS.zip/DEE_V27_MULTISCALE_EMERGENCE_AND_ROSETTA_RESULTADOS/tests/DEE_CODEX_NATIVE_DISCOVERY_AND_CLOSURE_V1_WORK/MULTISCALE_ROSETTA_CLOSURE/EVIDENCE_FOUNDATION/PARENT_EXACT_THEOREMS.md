# Pruebas exactas sobre `F_DEE` v27

## Dominio y fuente normativa

Estas pruebas se refieren al binario cuyo SHA-256 es `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`, dentro del wheel `69297e6f...bc939`. La fuente C++ incluida en ese mismo wheel tiene SHA-256 `44a80f...207ab` y su `RECORD` coincide.

El dominio operacional es una invocación válida del mapa síncrono: `N` es un entero positivo; `M=N^3` cabe en `size_t` y el indexado/particionado intermedio cabe en los tipos empleados; los cuatro buffers `grid_A`, `grid_B`, `clock_A` y `clock_B` son `uint64`, C-contiguos, escribibles, de al menos `M` elementos y sus regiones relevantes son disjuntas entre sí. Para dense se exige además `n_hilos>=1`. Estas condiciones excluyen alias que sobrescribiría la preimagen durante el scan, solapamiento no válido para `memcpy`, punteros fuera de rango y aritmética de tamaños fuera de contrato.

Sea `M=N^3`, `g in (Z/2^64)^M` el raw y `c in (Z/2^64)^M` el clock. La dinámica completa es `F(g,c)=(g',c')`.

## E1 — dinámica exacta del clock y forma skew-product

Para cada sitio `i` y todo `t>=0`,

`c_i(t)=c_i(0)+t (mod 2^64)`.

Por tanto cada diferencia `c_i-c_j` es invariante en `Z/2^64`. El raw obedece una dinámica forzada `g'=G(g,phi(c))`, mientras el clock no depende de raw: `F` es un skew-product sobre una rotación rígida finita.

**Prueba.** Bajo el dominio de buffers disjuntos anterior, todas las salidas de `actualizar_voxel`, incluida la temprana de semantic 4, asignan `clkB[i]=tick+1`. Lazy hace ese prefill para todo sitio no evaluado. DEMUX no escribe clocks. Inducción en `t`. La igualdad como enteros ordinarios es falsa a través de wrap; el probe binario verificó `2^64-1 -> 0`.

## E2 — cociente de fase raw y período mínimo causal

Sin cruzar wrap uint64, desplazar independientemente cada clock inicial por cualquier múltiplo de

`L_raw=lcm(195,260,391,782)=304,980`

deja idéntico todo prefijo raw pareado durante el cual ni los clocks originales ni los desplazados cruzan el corte `2^64-1 -> 0`. `L_Claude=1,094,573,220` también funciona, pero no es mínimo. Ninguno define una simetría global a través del wrap porque no divide `2^64`.

**Prueba.** El clock sólo entra al raw en `tick % (782//(8-n_active))`. Las ramas que sobreviven y alcanzan ese gate tienen `n_active=4,5,6,7`, con períodos 195,260,391,782. Para `n_active<=3`, `rule_value==0` retorna antes; para `n_active>=8`, no hay período positivo en esa expresión. Existen contextos alcanzables que hacen causalmente visible cada uno de los cuatro residuos: tetraedro para 4 y 5, supervivencia normal para 6 y suma direccional no nula para evitar write-protection con 7. El probe binario contiene un testigo para cada período. Todo período universal debe ser múltiplo de cada uno de los cuatro períodos y, por tanto, de su LCM. La igualdad raw se propaga por inducción porque la diferencia de clocks se conserva mientras no hay wrap.

## E3 — cono causal raw exacto de radio máximo tres

Un raw de salida en `y` depende como máximo de raws de entrada a distancia Chebyshev toroidal 3; por composición,

`r_infty(t) <= min(3t, diametro_infty(Z_N^3))`.

La cota universal de un tick es aguda para tamaños cuyo diámetro permite distancia 3; no se afirma que todo toro pequeño alcance radio 3.

**Prueba superior.** La actualización local y la copia direccional leen radio 1. Un emisor overflow `x` que puede depositar en `y=x+d*` lee candidatos `z=x+d`, y para elegirlos cuenta `q=z+e`; por tanto `||q-y||_infty<=||d||+||e||+||d*||<=3`. Los deltas se aplican una sola vez, sin cascada dentro del tick. **Agudeza para tamaño suficiente:** el probe construyó preimágenes que sólo difieren en `q=(3,3,3)` y salidas distintas en `y=(6,6,6)`, distancia toroidal 3 en el toro ensayado, tanto dense como lazy. Esto refuta `r<=t`; el aparato histórico V7-C sólo midió un régimen sin overflow.

## E4 — traslaciones y equivalencia exacta de motores válidos

Para las invocaciones válidas y buffers disjuntos definidos arriba, trasladar conjuntamente raw y clock por cualquier elemento de `Z_N^3` y luego aplicar `F` equivale a aplicar `F` y trasladar. Dense y lazy calculan el mismo `F`; el resultado raw/clock no depende del número positivo de hilos.

**Prueba.** Todos los accesos físicos usan offsets relativos y `wrap`; el orden de offsets se conserva bajo traslación. Fuera del halo Moore de todo `raw!=0`, un sitio y sus 26 vecinos son raw cero: dense produce raw cero y `clock+1`, exactamente el prefill lazy. Todo destino overflow está en el halo de su emisor. Las escrituras base son disjuntas por sitio; los únicos joins son sumas atómicas conmutativas de enteros. T8 y T9 añadieron 980 comparaciones discriminantes dense/lazy y 1/2 hilos sin mismatch; la prueba estática da el alcance universal.

## E5 — la cristalización por gradiente es inalcanzable

La rama `(grad_mag/P_KERNEL)>=966` nunca se ejecuta para ningún raw válido. En consecuencia todo incremento del contador de telemetría `genesis_count` procede de XNOR y no de esa cristalización. Esto no niega los nacimientos por routing direccional, que no incrementan dicho contador.

**Prueba.** Para `g=-sum_d d*s_d`, `d` en los 26 offsets y `0<=s_d<=65535`,

`||g||_1=max_sigma sigma dot g <= 15*65535=983,025`.

El coeficiente 15 es la suma máxima de coeficientes positivos de un octante sobre el stencil Moore. La condición requiere `19665*966=18,996,390`. Incluso el cociente máximo es 49. El margen es de factor mayor que 19. El helper `demux_edge_min` también es código muerto: sólo aparece en su definición.

## E6 — esqueleto booleano base antes de DEMUX

Para un sitio no observer con `state>0`, sea `n` el número de vecinos con `state>0` y semantic distinto de 5. La salida base de `actualizar_voxel`, antes de `aplicar_demux`, tiene estado no cero exactamente si

`n>=6` o `(n in {4,5} y existe firma tetraédrica)`.

Su estado de salida antes de un posible delta es:

- tetra: 2,3,4 para `n=4,5,6`;
- fuera del caso tetra incompleto, con `n=6..15`: 1;
- `n=16..25`: 2;
- `n=26`: 3.

Para un sitio no observer con `state=0`, la salida base nace por XNOR exactamente cuando sus 13 pares antipodales tienen ocupación igual y hay al menos ocho vecinos activos; XNOR tiene precedencia y retorna inmediatamente. Si XNOR es falso, una fuente direccional Moore que apunta al sitio también puede producir una salida base nacida. La cristalización no aporta nacimientos por E5.

**Prueba.** Sin tetra incompleto, `T=2.5` y `floor(nT/26+1/2)>0` desde `n=6`; los umbrales siguientes son 16 y 26. Con tetra y `n<7`, `T=16` produce estados 2,3,4 para 4,5,6. La rama de vacío implementa literalmente el predicado XNOR y sólo después, si éste es falso, el reducer direccional. Finalmente, `aplicar_demux` puede convertir una salida base con estado cero en `(state=1,s_reg=0,direction=0,semantic=1)`, o reescribir un orphan, si llega un delta overflow. Por eso este teorema caracteriza la regla base, no la supervivencia/natalidad final incondicional de `F`.

## E7 — no inyectividad global

Para todo `N>=3`, `F` no es inyectiva. Dos mundos con clocks iguales que difieren sólo porque un singleton normal sin dirección/s_reg tiene state 1 versus 2 producen exactamente el mismo raw cero y los mismos clocks después de un tick.

**Prueba.** Ambos tienen `n=0`, luego `rule_value=0`; la magnitud no cero de `state` no aparece en otra decisión previa. Testigo ejecutado en dense/lazy. Esto no implica que todos los sectores sean irreversibles.

## E8 — subcampo observer fijado e invariantes aditivos de rango cero

Todo raw con semantic 4 queda fijado punto a punto para todo tiempo. Bajo iteración de `F` no se crean nuevos semantic 4. Para toda función `f` del raw con valores en un grupo aditivo,

`Q_f(g)=sum_i 1[semantic(g_i)=4] f(g_i)`

es un invariante aditivo de rango cero. En particular lo es el número de observers.

**Prueba.** `actualizar_voxel` retorna inmediatamente copiando el raw; `aplicar_demux` omite semantic 4. Ninguna rama alcanzable escribe semantic 4: XNOR escribe 7, routing escribe 1, la regla material preserva semantic propio y la única herencia vecinal estaba en cristalización, imposible por E5. Esto refuta T4 de Claude en su dominio declarado.

## E9 — sector balístico singleton

Para `N>=5`, un único raw normal con `state=1`, carga `s` arbitraria y dirección `d in {-1,0,1}^3\{0}` se traslada exactamente:

`g_t(x)=g_0(x-t*d)`.

Con cualquier state positivo inicial, entra en ese sector tras un tick con state 1. La carga `s_reg` y `d` se transportan exactamente. El raw tiene período `N`, aunque el estado completo no lo tiene por E1.

**Prueba.** El singleton central tiene `n=0` y muere. El único vacío `q+d` encuentra una sola fuente entrante; la rama de una fuente conserva su raw, y el vacío lo reempaqueta como `(1,s,d,SEM_NORMAL)`. Ninguna otra celda nace. Inducción. El aparato histórico `TORUS_MOVING` de v25 ya contenía el caso particular `state=1`, `s_reg=0`, `d=(1,0,0)`, con hashes de trayectoria compatibles con `q(t)`. T8 no fue la primera aparición histórica del movimiento: lo formalizó, generalizó y sometió a holdout en v27 mediante 1,872 trayectorias factoriales, 50,544 ticks primarios, 26 direcciones, dos tamaños, estados, cargas y clocks, con cero mismatches.

Con la convención `rho_hat_m=sum_x rho_x exp(-2*pi*i*m.x/N)`, cada modo satisface

`rho_hat_m(t+1)=exp(-2*pi*i*m.d/N) rho_hat_m(t)`.

T8 verificó 2,704 cocientes; error máximo de punto flotante `5.36e-15`. Es un modo exacto de advección/representación de traslación, no evidencia de mecánica cuántica.

## E10 — gas no interactuante restringido y reversibilidad sectorial

Para `N>=5`, fije una dirección Moore no nula `d`. Toda configuración de singletons normales con `state=1`, dirección común `d`, cargas `s_reg` arbitrarias y posiciones cuya distancia Chebyshev toroidal por pares sea al menos 3 se traslada rígidamente por `d` en cada tick. La separación se conserva bajo la traslación; cada bola Moore contiene a lo sumo un portador, por lo que no hay supervivencia local, XNOR ni colisión.

En ese sector invariante `F_raw` es una permutación y su operador de Koopman es unitario sobre cualquier medida invariante finita. T8 comprobó 12 recorridos de dos cuerpos con separación 5 (tres direcciones por cuatro caminos de ejecución) durante 276 steps; la universalidad para toda configuración que satisface la separación proviene de la prueba anterior, no del tamaño de ese panel.

La unitariedad es una propiedad de una permutación finita y no una dinámica cuántica. Globalmente E7 sigue vigente.

## E11 — álgebra exacta de colisiones entrantes

Sea el blanco un raw exactamente cero cuya vecindad no satisface XNOR. Si `k>1` entradas del scan Moore apuntan al blanco, la salida base del reducer, antes de `aplicar_demux`, tiene:

`state=1`, `semantic=1`, `s_reg=min(sum_j s_j,19664)`,

`d_out=sign(sum_j d_j)` componente a componente.

El reducer es conmutativo en las fuentes. Si además el blanco no recibe un delta overflow, esa salida base es también el producto final del tick; un delta entrante podría aumentar después su `s_reg` hasta el mismo cap. Para dos singletons aislados distintos en `N>=5`, XNOR es necesariamente falso y no hay overflow entrante: si `d_out=0` el producto muere al tick siguiente; en otro caso entra en E9. T8 probó los 325 pares de direcciones por cuatro pares de cargas (1,300 casos), incluidos 52 de salida cero y 650 de saturación estricta, sin mismatch.

Consecuencias: el número de portadores no se conserva; `s_reg` sólo tiene balance aditivo antes del cap; la suma vectorial de direcciones no se conserva en general porque `sign` elimina magnitud. Es una cinética disipativa programada, no conservación universal de masa, energía o momentum.

## E12 — observer como boundary/source activo

Para `N>=5`, un único raw semantic 4 en `q` con dirección Moore no nula `d in {-1,0,1}^3\{0}` permanece fijo y, aun con state 0, emite un tren. Para `1<=t<N` aparecen singletons normales exactamente en `q+k*d`, `1<=k<=t`, `k congruente t (mod 2)`, en número `ceil(t/2)` sin contar el observer. Conservan el `s_reg` del observer. Un observer con dirección cero no emite en el aparato aislado.

**Prueba.** E8 fija la fuente. El sitio vacío `q+d` la ve mediante `buscar_fuente_demux`, que no exige `state>0` ni excluye semantic 4. Cada descendiente obedece E9; la regla de vacío sólo puede volver a poblar una posición cuando ésta estaba vacía en la preimagen, generando la paridad alternante. La inducción es válida para `1<=t<N`, antes de que el orden toroidal de `d` cierre la órbita. T9 prospectivo ejecutó este aparato dentro del dominio declarado para `N in {11,13}`: 936 casos factoriales, 208 runs de equivalencia y 18 controles, 12,782 ticks, cero mismatches. Direcciones codificables fuera de Moore, por ejemplo `(2,0,0)`, no están cubiertas y no emiten en este aparato aislado porque la búsqueda sólo escanea el halo Moore.

Por tanto el nombre `observer` es engañoso: operacionalmente es un sitio fijado que puede ser obstáculo, condición de frontera y fuente persistente; no implementa medición.

## E13 — familia densa fija

En un toro totalmente ocupado por semantic distintos de 4 y 5, con state 3 y dirección cero en todo sitio, el raw es fijo para cualquier distribución de `s_reg` y cualquier mezcla de semantic preservables `{1,2,3,6,7}`.

**Prueba.** Cada sitio cuenta `n=26`, obtiene `rule_value=3` y está write-protected porque la suma direccional es cero. Si `s_reg>=19665`, no existe candidato overflow abierto: cada candidato tiene grado 26. El gradiente no cambia direction porque la dirección propia es cero. Semantic se preserva. Clocks avanzan por E1.

Esto exhibe una familia macroscópica de puntos/fibras raw fijos. No se ha demostrado que sean atractores: una cuenca atractora o su estabilidad frente a huecos requeriría una prueba separada.

## E14 — subgrupo exacto de traslaciones y obstrucción a `O_h`

`Z_N^3` es simetría exacta por E4. El grupo cúbico completo `O_h` no lo es globalmente.

**Prueba negativa.** Los candidatos overflow empatados se resuelven por la primera entrada de `MOORE_DXYZ` y sólo se reemplazan con `<` estricto. Un input invariante bajo inversión, con fuente central en threshold y seis soportes axiales, deposita sólo en `(-1,-1,-1)`, no en su inverso. El testigo binario produce dos mismatches bajo inversión en dense/lazy. `O_h` puede sobrevivir en sectores que nunca excitan ese tie; T8, por ejemplo, posee equivariancia cúbica restringida en su regla de transporte/colisión. Este argumento establece el subgrupo de traslaciones y excluye `O_h` global, pero no clasifica el grupo global completo ni descarta otras simetrías.

## E15 — manta causal suficiente y sesgo de occupancy

Para predecir exactamente `(g'_y,c'_y)` basta conocer los raws en la bola Chebyshev `B_3(y)` y los clocks en `B_1(y)`. La proyección occupancy `1[state>0]` no es causalmente suficiente.

**Prueba de suficiencia.** E3 enumera todas las lecturas raw. El clock de `y` gobierna su update local y clocks de emisores overflow `x` con `||x-y||<=1` pueden gobernar un delta que llega a `y`; ningún otro clock se lee para esa salida. **Contraejemplo para occupancy:** para `N>=3`, dos mundos con occupancy idéntico cero, uno con raw completamente cero y otro con un sitio `state=0` pero dirección Moore no nula, producen occupancy distinto al tick siguiente porque `buscar_fuente_demux` no exige `state>0`. También dos clocks distintos en un contexto superviviente pueden producir distinto `s_reg` con occupancy idéntico.

Así, el objeto Markoviano natural para el estado completo no es occupancy sino el campo raw etiquetado más el clock. El cociente de fase de E2 puede sustituir al clock sólo si el objetivo es predecir raw dentro del prefijo sin-wrap allí especificado. Esto explica por qué análisis históricos basados sólo en occupancy podían perder transporte e identidad causal.

## Alcance y límites de estas pruebas

Los teoremas son propiedades de `F_DEE` v27, varias explícitamente programadas. No son por sí mismos leyes de la naturaleza. No se ha demostrado inexistencia de todo invariante de rango 1–2, de toda conservación efectiva, de todo atractor no descrito ni de toda teoría hidrodinámica posible. Sí quedan descartadas globalmente la localidad radio 1, la simetría cúbica completa, la inyectividad y la alcanzabilidad de cristalización; quedan establecidas las excepciones sectoriales que impiden convertir esos negativos en una negación ontológica total.
