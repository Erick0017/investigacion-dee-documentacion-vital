# Observador causal mínimo de DEE v27

## Resultado

DEE no posee un observador mínimo único independiente de la pregunta. Para un observable `O` y horizonte `H`, la definición exacta es la partición predictiva

`M_{O,H}=X / ker(W_H^+)`, con `W_H^+(x)=(O(Fx),...,O(F^H x))`.

Ésta es la partición más gruesa que predice exactamente la palabra futura seleccionada. Cambiar `O`, incluir el presente o ampliar `H` cambia el cociente. La afirmación correcta es, por tanto, sectorial.

## Cociente seleccionado para la Rosetta

Para la familia conjunta transporte–colisión–fuente persistente, el contrato congeló la configuración de registros

`Z=M_*(X)={z_i}`, `z_i=(q_i,d_i,s_i,a_i,p_i)`,

donde:

- `q` es la coordenada del laboratorio sobre `Z_N^3`;
- `d` es una dirección Moore o cero;
- `s` es el `s_reg` transportable;
- `a=1[state>0]` distingue blancos cerrados por actividad;
- `p=1[semantic=4]` distingue la fuente persistente/protegida.

Se emite un registro si `state>0`, si `d` es Moore no nula o si `semantic=4`. Los raws no observer con `state=0,d=0` se omiten. Para blockers no observer activos con `d=0`, `s` se canoniza a cero. Las semánticas ordinarias se identifican entre sí.

Los tres roles causales resultantes son:

| Rol | Marcas | Función dinámica |
|---|---|---|
| `L`, router latente | `a=0,p=0,d!=0` | Propone una vez aunque occupancy sea cero; luego desaparece. |
| `C`, portador/blocker | `a=1,p=0` | Cierra su blanco de entrada; puede proponer; en el dominio disperso no persiste localmente. |
| `O`, observer/fuente | `p=1` | Conserva el raw fuente, cierra el blanco y vuelve a proponer en cada tick. |

La palabra *observer* es un nombre histórico engañoso: operacionalmente es una condición de frontera fija y una fuente, no un aparato de lectura.

## Dominio certificado

La clausura se afirma sólo en `D_*`:

1. `N>=5`;
2. cada dirección decodificada es cero o una de las 26 direcciones Moore;
3. hay como máximo siete sitios con `state>0` en el mundo completo;
4. cada sitio positivo no observer tiene a lo sumo tres vecinos Moore positivos;
5. esas condiciones se comprueban en cada slice que se puntúa.

Estas guardas excluyen supervivencia material, tetraedro, XNOR, overflow y fricción dependiente del clock. No se ha demostrado que `D_*` sea invariante para toda preparación; las trayectorias se certifican slice a slice.

## Necesidad de campos

Dentro de la familia conjunta congelada:

- `q` fija destinos, colisiones y detectores;
- `d` fija la existencia y el blanco de una propuesta y el reducer vectorial;
- `s` es leído por transporte y suma/cap de colisión;
- `a` distingue un destino abierto de un blocker activo;
- `p` distingue una propuesta efímera de una fuente persistente.

No se necesita la magnitud positiva de `state`, el clock ni la etiqueta semantic no-observer dentro de `D_*`. Esta minimalidad es conjunta respecto de los readouts congelados, no global. Para packed raw de un observer debe retenerse su palabra raw completa, porque semantic 4 la conserva bit a bit. `D_*` sí admite `semantic=5,state>0` sparse: en ese sector la etiqueta es nuisance y T10 la incluyó. `M_*` deja de ser suficiente al ampliar a la configuración densa que activa XNOR/alive semantics; allí se debe añadir una marca orphan-activa o excluir esa rama. El contraejemplo de ocho positivos fue ejecutado antes del freeze y está fuera de `D_*` por densidad, no por la etiqueta sola.

## Manta causal local general

Fuera de `D_*`, para predecir raw en un detector `y` hasta horizonte `H`, una manta suficiente contiene:

- raw inicial en la bola Chebyshev toroidal `B_{3H}(y)`;
- clocks iniciales potencialmente causales en `B_{3H-2}(y)` para `H>=1`.

La cota raw de un tick es `min(3,diam_infty(T_N))`; el radio tres es agudo cuando el diámetro del toro lo permite. Para predecir raw sin wrap no siempre se requiere el clock entero: su residuo módulo `304980` es suficiente; a horizonte corto, el schedule booleano de los gates es aún más grueso. Para predecir el clock observado sí se necesita su valor inicial exacto. Esta manta es suficiente, no una prueba de que cada coordenada interior sea necesaria en todos los contextos.

## Lo que occupancy pierde

Vacío, router latente normal y observer state-zero pueden compartir occupancy inicial nula y tener tres futuros distintos. Así, occupancy falla como estado causal suficiente de manera constructiva. Este resultado localiza el sesgo: el soporte `state>0` no captura propuestas codificadas en `direction` ni persistencia codificada por semantic.

## Evidencia y corrección estado–evento

Los paneles de discovery compararon candidatos con palabras futuras en ambas direcciones. Siete familias sectoriales pasaron sin fallos de suficiencia o minimalidad. La auditoría adversarial adicional encontró y reparó antes del primer freeze los límites de semantic 5 y las direcciones no Moore.

T10, sin embargo, preservó un FAIL real: `M_*` canonizaba `s=0` en un blocker activo `d=0`, mientras el `G_*` congelado retenía la carga de una colisión opuesta. Fueron 96 fallos de cierre y 96 desalineaciones consecuentes, todos en esa clase, con cero fallos de dominio. Esto no vuelve innecesarios los campos ni refuta la regla raw; muestra que un estado predictivo mínimo no puede servir a la vez como ledger completo del evento instantáneo.

La hipótesis posterior separó ambos objetos: `G_dagger` aplica la canonización de `M_*` y `J_dagger=(q,u,S)` conserva la salida raw transitoria. Tras preregistro nuevo, T12 pasó 748 trayectorias/1,496 ticks de aridades 3/4/6, cero mismatches y cero fallos de dominio. La minimalidad aquí sigue siendo respecto del futuro seleccionado; si el observable incluye el evento presente, se debe leer también `J_dagger`.
