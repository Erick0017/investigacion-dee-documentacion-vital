# Arquitectura matemática nativa de DEE v27

## Veredicto estructural

El objeto transversal más pequeño que explica la dinámica no es occupancy, un basin aislado ni una supuesta energía. Es un **autómata reticular síncrono, etiquetado, dirigido y forzado por fase**, sobre el toro fijo `Z_N^3`, con cinco capas acopladas:

1. un esqueleto booleano de soporte/supervivencia;
2. un campo de flechas que copia raws hacia vacíos y posee colisiones conmutativas;
3. un registro escalar transportado que también funciona como contador de procedencia/overflow;
4. etiquetas semánticas que alteran protección, actividad y persistencia;
5. clocks afines cuyos offsets son desorden de fase congelado y fuerzan gates escasos.

La regla no es una única ley de materia. Es un transductor por ramas con sectores cualitativamente distintos. Esta arquitectura es específica de v27 y explica conjuntamente transporte, colisiones, nacimiento, persistencia, causalidad de radio 3, anisotropía DEMUX, invariantes observer, many-to-one y periodicidad de fase.

## Estado y proyecciones naturales

En cada sitio el raw empaca:

`(state:uint32, s_reg:uint16, direction:3×int4, semantic:uint4)`.

Dos máscaras distintas intervienen:

- `exists = 1[state>0]`, usada para gradientes de `s_reg`;
- `alive_for_rule = 1[state>0 and semantic!=5]`, usada para supervivencia, tetraedros y XNOR.

No son equivalentes. Además, `buscar_fuente_demux` puede leer una dirección aunque `state=0`. Por eso occupancy no es siquiera una estadística suficiente de un paso; raw más clock sí lo es con la manta local de E15.

## Descomposición operacional de un tick

### A. Base de fase

Todo clock avanza `+1 mod 2^64`. Raw no retroactúa sobre clock. Los offsets relativos forman invariantes exactos; raw sólo ve cuatro períodos causalmente activos, con LCM 304,980 antes de wrap.

### B. Reacción del soporte

La salida base pre-DEMUX de un sitio ocupado sobrevive por densidad Moore (`n>=6`) o por una firma tetraédrica especial con `n=4,5`. El valor de state de salida es un pequeño rótulo de rama 1–4, no la conservación de la magnitud de state de entrada. Un delta overflow posterior puede reactivar un sitio cuya salida base fue cero. Vacíos nacen por simetría antipodal XNOR o, si XNOR no toma precedencia, por flechas entrantes. La pretendida cristalización por gradiente es imposible.

### C. Transporte por flechas

Para `N>=5`, una flecha Moore sobre un singleton implementa traslación exacta. En un blanco raw-cero con XNOR falso, varias flechas entrantes producen antes de `aplicar_demux` una salida base con suma capada de `s_reg` y signo de la suma direccional; otro delta overflow todavía podría modificar su `s_reg`. El aparato aislado de dos singletons con `N>=5` no recibe ese delta y satisface las condiciones. Este mecanismo soporta sectores reversibles de transporte y colisiones disipativas en el mismo kernel.

### D. Procedencia y overflow

En células supervivientes no protegidas, `s_reg` incrementa sólo en residuos de clock dependientes de `n`. Al cruzar 19665 intenta elegir un vecino abierto de `s_reg` mínimo; el desempate lexicográfico rompe `O_h`. La decisión consulta vecindades anidadas y expande el radio causal raw a 3. Un delta posterior puede crear, reiniciar o aumentar un sitio.

### E. Controles semánticos

Semantic no es una especie física derivada. Es control de flujo:

- 4 (`observer`) fija el raw y bloquea deltas; en el aparato aislado para `N>=5`, una dirección Moore no nula produce el tren demostrado sólo para `1<=t<N`;
- 5 (`orphan`) se excluye de `alive_for_rule` y un delta lo reinicia a `TTL_ORFAN`;
- 7 marca nacimiento XNOR;
- 1–3,6,7 se preservan en supervivencia, pero todo routing direccional produce semantic 1.

No existe en el código una medición asociada a observer ni un decaimiento explícito de TTL que haga de los nombres una ontología.

## Función real de cada variable

| Variable | Función ejecutable | Lo que no queda autorizado |
|---|---|---|
| `state` | cero/no cero para existencia; salida discreta de la rama de supervivencia | masa, cantidad de materia o amplitud |
| `s_reg` | etiqueta conservada en vuelo libre; suma capada en colisión; contador fase-gated; fuente de gradiente y threshold overflow | energía universal |
| `direction` | flecha de routing y velocidad exacta en singleton; en materia superviviente se reemplaza por signo del gradiente si ya era no nula | momentum conservado universal |
| `semantic` | selector de protección/actividad/proveniencia programada | especie física demostrada |
| `clock` | contador afín y fase local congelada que abre gates de procedencia | tiempo físico SI o edad material |
| `raw` | estado computacional causalmente relevante, aun con `state=0` | observable físico directo |

## Sectores e invariantes

- **Globales exactos:** diferencias de clock módulo `2^64`; raws observer punto a punto y toda suma local soportada sobre ellos.
- **Sectoriales exactos:** número/carga/dirección y forma trasladada en gases singleton sin colisión; órbitas raw de período N; familia densa fija con state 3/direction 0.
- **Balances:** `s_reg` suma en una colisión sólo hasta el cap; después hay término disipativo. Soporte tiene fuentes XNOR/DEMUX y sumideros por supervivencia, por lo que no satisface continuidad global.
- **No establecido:** una carga extensiva no trivial que cubra todos los raws no-observer; invariantes relacionales/topológicos globales; cuasi-conservaciones robustas tras coarse-graining.

La refutación de la supuesta ausencia de rango 0 no prueba que exista una energía. Demuestra que el teorema negativo era demasiado amplio y obliga a declarar el dominio de cada búsqueda.

## Modos y reversibilidad

Para `N>=5`, el sector singleton aporta 26 velocidades exactas y una dispersión de advección `omega=k·d (mod 2pi)`. Un gas con igual `d` y separación Chebyshev toroidal por pares al menos 3 es una permutación raw y admite Koopman unitario. Es un modo propagante real de DEE y una clase material operacional mínima: persistencia, identidad transportada, posición colectiva `q`, velocidad y colisión reproducible.

No es todavía un modo colectivo interactuante universal. Al colisionar se pierde número de soportes, se capa carga y se reduce la dirección a signos; la reversibilidad sectorial termina. Los espectros históricos dominados por ventanas o tendencias no se convierten retroactivamente en este modo.

## Causalidad y geometría

La geometría primaria es combinatoria: toro cartesiano fijo, stencil Moore y un hiper-grafo dirigido de dependencia que cambia con las ramas. La cota máxima es `3t`, mientras el transporte singleton usa `t`. Obstáculos, etiquetas, historia de clock, routing y overflow cambian first-passage; ese objeto es un grafo temporal/relación de alcance, no un tensor métrico demostrado. V7-C puede apoyar mediación local dependiente del sustrato en su régimen sin establecer relatividad ni gravedad.

## Materia, masa y teorías efectivas

La materia DEE defendible no es todo occupancy. La clase mínima encontrada es el portador direccional singleton y sus configuraciones de gas; los observers son defects/boundaries fijados; las configuraciones densas son fases fijas. En vuelo libre, state y `s_reg` no cambian velocidad. En colisión, `s_reg` tampoco pondera la suma direccional. Por tanto no hay masa inercial escalar identificada en este sector.

Sí existe un puente matemático condicionado a advección/lattice-gas: densidad y corriente obedecen continuidad en el sector sin colisiones. Fuera de él aparecen términos fuente/sumidero explícitos. No se han obtenido local equilibrium, stress constitutivo, separación de escalas ni límite Navier–Stokes; tampoco Lorentz, Einstein, Schrödinger, Born o gauge local.

## Específico frente a genérico

**Específico de DEE v27:** predicados tetra/XNOR, umbrales 6/16/26, reducer de flechas, cap 19664, gates 195/260/391/782, semantic observer/orphan, tie lexicográfico, sector balístico y pump observer.

**Genérico de un sistema dinámico discreto finito:** eventual periodicidad, existencia formal de basins, representación de una permutación por un Koopman unitario, posibilidad de etiquetar ciclos y recurrencias. Nada de esto, sin estructura adicional, es una predicción física.

## Grado de unificación alcanzado

Sí hay una arquitectura transversal interna: `support + arrows + load + semantic controls + frozen phase`. Un conjunto pequeño de esos objetos explica varias familias de fenómenos y produjo predicciones holdout nuevas T8/T9. No hay todavía una Rosetta externa no arbitraria. La arquitectura unifica mecánica interna de DEE; no unifica por sí sola nuestra física.
