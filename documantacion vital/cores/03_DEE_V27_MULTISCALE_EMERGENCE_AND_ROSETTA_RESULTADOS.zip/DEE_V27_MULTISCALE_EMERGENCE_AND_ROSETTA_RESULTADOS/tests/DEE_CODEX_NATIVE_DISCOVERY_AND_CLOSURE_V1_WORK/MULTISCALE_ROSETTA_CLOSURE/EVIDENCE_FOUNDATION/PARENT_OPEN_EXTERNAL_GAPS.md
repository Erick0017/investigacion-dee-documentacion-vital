# Huecos externos abiertos después de la construcción Rosetta

## Diagnóstico central

La arquitectura interna ya ofrece objetos operacionales —registros causales, propuestas, guards, reducer, persistencia, first-passage y respuesta intervenida—, pero todavía no existe un mapa independiente que los conecte con preparaciones y mediciones de nuestra realidad. Los holdouts externos no cierran ese hueco: E1/E2 son compatibles pero no validantes, E3 es inconcluso por falta de operador forward y E4/E5 no tienen datasets calificantes. La obstrucción algebraica `sqrt(3)` de equivelocidad lineal directa permanece probada por separado.

La pieza exacta faltante bajo `H_DEE` es una **Rosetta física generativa y falsable**:

`procedimiento de preparación -> distribución sobre X o Z -> evolución/coarse-graining -> distribución de lecturas físicas`,

con la preparación y la medición fijadas antes de observar el holdout. Esa construcción debe derivar su geometría y sus escalas, no asumir que coordenada, tick, `state`, `s_reg`, `direction` o semantic ya poseen nombres físicos.

## G0 — mapa independiente de preparación y medición

Debe especificarse:

- qué procedimiento físico selecciona un estado o ensemble DEE y con qué incertidumbre;
- qué equivalencias microscópicas representan la misma preparación;
- qué subsistema constituye fuente, canal y detector;
- qué función de una historia DEE produce cada lectura y cada no-detección;
- cómo se modelan ruido, eficiencia, selección y probabilidades;
- qué datos se reservan para calibración y cuáles permanecen como holdout.

El mapa debe poder fallar. No cuenta una asignación elegida porque reproduce un resultado ya visto, ni una correspondencia semántica basada sólo en los nombres de campos. Sin G0, que E1/E2 admitan cero no identifica energía con `s_reg`, ondas con etiquetas ni detectores con observers.

## G1 — geometría coarse-grained y operador forward para E3

La geometría nativa disponible es un hipergrafo causal dirigido y dependiente del estado en espacio `(q,d)`, con first-passage condicionado por preparación. El teorema interno demuestra que ninguna aplicación lineal invertible común `A` y tiempo común `tau` puede convertir directamente las 26 direcciones Moore en velocidades euclídeas iguales: la razón extrema es al menos `sqrt(3)`. E3 no convierte esa cota en una predicción de resonador porque no se preregistró el operador de orientación, ida/vuelta, armónicos y nuisances; por ello el contraste externo es inconcluso.

Una alternativa legítima debe derivar, antes del nuevo holdout:

1. clases de estados y escalas sobre las que se realiza el límite;
2. una distancia y duración operacionales desde respuestas/first-passage, no desde coordenadas por decreto;
3. cuantificación de anisotropía residual y su escalamiento con tamaño/coarse-graining;
4. transformaciones entre observadores y, si se reclama relatividad, un intervalo y dispersión efectivos;
5. un error controlado que indique dónde deja de valer la descripción continua.

No basta proponer “emergencia” como escape verbal. Debe construirse el operador de coarse-graining, demostrar o medir convergencia y congelar predicciones angulares y multiescala antes de compararlas con datos.

## G2 — escalas y constantes sin circularidad

E1 y E2 usan cocientes adimensionales; el ratio interno de E3 también cancela escala, pero no está conectado a un likelihood externo. E4 habría permitido una unidad temporal de control, pero no existe dataset; E5 no contiene un parámetro dimensional. Por ello no están identificados longitud por voxel, tiempo por tick ni su cociente absoluto.

Una calibración futura requiere al menos un endpoint absoluto para una combinación como `ell_0/t_0` y un segundo endpoint independiente si se quieren separar `ell_0` y `t_0`. Debe fijar todos los parámetros con un subconjunto de datos y predecir otros observables con incertidumbre. No puede reutilizar `alpha`, masas o `20 Hz` que participaron genealógicamente en la construcción de constantes internas, ni introducir escalas por dirección, etiqueta o clase para reparar resultados.

## G3 — materia, masa, inercia y materia–geometría

Los linajes `C` constituyen la clase móvil interna más simple; `L` es routing latente y `O` una fuente/frontera. Esto no identifica materia física. En el sector conocido, todas las magnitudes positivas de `state` y todos los `s_reg` comparten velocidad, y `s_reg` no pondera la composición direccional.

Para una masa o inercia efectiva faltan:

- una clase estable e interactuante seleccionada antes del test;
- una coordenada colectiva `q_eff` y una intervención tipo fuerza definida sin usar la respuesta;
- aceleración o susceptibilidad reproducible en múltiples tamaños y condiciones;
- un parámetro que prediga tanto respuesta como propagación/colisión fuera de la muestra de calibración.

Para materia–geometría se necesitan además dos mediciones independientes sobre las mismas clases: una respuesta inercial `M_I` y una respuesta geométrica `M_G`, seguidas de una relación congelada y contrastada. El kernel puede calcular ambas una vez definidas; no puede decidir que correspondan a masa o curvatura reales.

## G4 — termodinámica e hidrodinámica

El vuelo libre aporta continuidad cinética y balances exactos; colisiones, observers y saturación introducen fuentes, sumideros y pérdida de información. Para obtener una teoría efectiva faltan:

- ensemble físico y medida estacionaria;
- densidad/carga lenta no trivial y su corriente;
- temperatura y energía operacionales;
- equilibrio local y producción entrópica;
- separación entre escala microscópica, camino libre y escala observada;
- tensor de stress o relación constitutiva y cierre controlado;
- predicciones de transporte y fluctuaciones en holdout multiescala.

Las búsquedas previas de cargas locales y la entropía de occupancy no agotan estas posibilidades. Tampoco las establecen. Un límite tipo Boltzmann/Navier–Stokes sólo sería una hipótesis hasta demostrar convergencia y error en un dominio preparado.

## G5 — quantum y Bell

Los modos Fourier y el operador Koopman de un sector permutacional no identifican mecánica cuántica. Para un puente cuántico hacen falta espacio de estados físico y regla de composición, observables, probabilidades/Born, preparaciones equivalentes e interferencia operacional.

Un experimento Bell necesita, como mínimo:

1. fuente y dos estaciones físicamente definidas;
2. settings `a,b` generados independientemente de una variable común `lambda`;
3. outcomes binarios y ventanas de coincidencia fijadas;
4. separación causal auditada con el cono raw verdadero, no un radio supuesto;
5. pruebas de no señalización y ausencia de postselección;
6. cálculo CHSH en holdout.

Sin ese aparato, `CHSH<=2` es un teorema condicionado a premisas no instanciadas, no un resultado empírico DEE; una violación tampoco está predicha. La semilla, el clock o el raw no deben declararse `lambda` sin un protocolo que lo justifique.

## G6 — simetrías, gauge y gravedad

La traslación toroidal es exacta y el grupo cúbico completo falla globalmente por un tie overflow; pueden existir simetrías restringidas o estabilizadores colectivos. El cociente de fase del clock preserva raw sólo en prefijos sin wrap y no preserva el estado completo.

Para gauge faltan variables de enlace/conexión, transformaciones locales que preserven todos los observables físicos, curvatura/holonomía y cargas acopladas. Para gravedad faltan un campo geométrico colectivo dinámico, una fuente efectiva tipo energía–momentum, retroacción y una relación de equivalencia operacional. La dependencia estatal del hipergrafo causal es estructura interna, no una ecuación de campo gravitatoria por sí misma.

## G7 — endpoints externos todavía ausentes

### E3: operador forward óptico

Antes de consultar otro resonador debe congelarse cómo las direcciones D26 o su coarse-graining generan propagación continua, frecuencia de ida/vuelta, armónicos de rotación y efectos de orientación/medio. El resultado `FAIL_BRIDGE` original queda preservado como auditoría fallida; la adjudicación vigente es `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`.

### E4: oclusión y fase

Permanece abierto localizar o producir un dataset primario con fuente persistente, bloqueo unitario en la entrada, al menos dos detectores aguas abajo resueltos en tiempo y control sin bloqueo. Sólo entonces puede congelarse una réplica del endpoint de retraso uno/paridad opuesta. La búsqueda actual concluyó `NOT_IDENTIFIABLE`; ampliarla requiere un preregistro nuevo, no reetiquetar candidatos rechazados.

### E5: mayoría de cinco fuentes

Permanece abierto un experimento con cinco entradas simultáneas, intensidades medidas y dirección de salida. Debe variar intensidades para discriminar mayoría no ponderada frente a suma ponderada. La búsqueda actual concluyó `NOT_IDENTIFIABLE`; cambiar aridad o significado de `s_reg` crea una hipótesis nueva.

### E1/E2: compatibilidad no discriminante

La nondispersión de Fermi y la igualdad condicionada GW/EM incluyen los ceros DEE, pero muchos modelos comparten esos nulos. Para aportar validación se requieren predicciones adicionales, independientes y cuantitativas producidas por el mismo mapa ya calibrado. No debe contarse cada escenario de una misma fuente como confirmación independiente.

## Predicciones cruzadas mínimas requeridas

Una Rosetta no arbitraria debe consumir menos grados de libertad de los que predice. Un programa de cierre debería congelar una sola construcción y exigirle, como mínimo:

- una ley de propagación relativa y otra absoluta;
- anisotropía y dispersión multiescala derivadas de la misma geometría;
- respuesta a una intervención local en más de un detector;
- un endpoint de colisión o interacción no usado para calibrar;
- consistencia del mismo diccionario entre preparación, evolución y lectura.

Cada predicción necesita dominio, incertidumbre, nuisance, criterio de FAIL y holdout separado. Si el mapa cambia entre familias, sólo se han construido analogías locales, no una Rosetta transversal.

## Qué no puede decidir `F_DEE` por sí solo

Ningún número adicional de ejecuciones internas puede identificar sin datos externos:

- cuál ensemble DEE, si alguno, es realizado por nuestra realidad;
- qué estado representa vacío, materia, radiación, aparato o resultado;
- qué equivalencias microscópicas son físicamente invisibles;
- qué voxel y tick corresponden a unidades SI;
- qué lectura debe llamarse masa, energía, temperatura, probabilidad o distancia;
- si las fronteras toroidales o el tamaño `N` tienen significado físico;
- qué ruido y selección caracterizan instrumentos reales.

Esto es subdeterminación semántica y empírica: varias interpretaciones externas pueden compartir exactamente la misma dinámica interna. El kernel sí puede falsar una Rosetta una vez especificada; no puede generar de manera única el diccionario que lo conecta con el mundo.

## Criterio de cierre bajo `H_DEE`

La conexión con realidad quedaría identificada sólo cuando exista:

1. mapa de preparación/medición independiente y reproducible;
2. geometría coarse-grained derivada y operador forward que vuelvan E3 realmente contrastable;
3. calibración dimensional no circular;
4. varias predicciones cruzadas preregistradas y confirmadas fuera de los datos de construcción;
5. contabilidad explícita de alternativas, incertidumbres y fallos.

Hasta entonces, el resultado correcto es que la arquitectura interna puede sostener puentes matemáticos y analogías condicionadas, pero la identidad física bajo `H_DEE` permanece **no identificada**. Este hueco requiere información y experimentos externos; no es resoluble mediante una nueva interrogación local del mismo kernel sin ampliar el contenido empírico.
