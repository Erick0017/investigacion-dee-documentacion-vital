# Calibracion de la Rosetta DEE v27

## Resultado

**No existe una calibracion dimensional identificable con los holdouts congelados `E1`–`E5`.** Los contrastes que poseen datos son adimensionales y eliminan cualquier factor comun; E3 carece del operador forward necesario para usar el resonador como likelihood; y los dos tests que podian aportar una escala o un diccionario mecanistico carecen de dataset calificante.

Esto es una conclusion de identificabilidad, no una declaracion de que DEE no pueda admitir alguna escala efectiva. El contrato permite mostrar un unico factor comun de longitud/tiempo, pero prohibe escalas distintas por etiqueta, clase o direccion. Ninguna evidencia abierta determina ese factor.

## Parametrizacion permitida

Sea `ell_0` una longitud fisica por unidad espacial operacional y `t_0` un tiempo fisico por tick. Una velocidad absoluta tendria un factor comun `c_0=ell_0/t_0`. El contrato solo permite este tipo de conversion comun; no permite introducir `ell_s`, `t_s`, `ell_d` o `t_d` dependientes de etiqueta, clase o direccion para reparar un resultado.

Para el puente `E3`, la generalizacion congelada ya absorbe una transformacion espacial lineal comun `A` y un tiempo comun `tau`:

`v(d)=||A d||_2/tau`.

Su escala global tampoco afecta cocientes. Por consiguiente, aun antes de mirar datos, los endpoints primarios tienen la siguiente dependencia:

| Holdout | Endpoint comparado | Dependencia de escala | Parametros ajustables despues del freeze |
|---|---|---|---|
| E1 | `max_j |log(v_j/v_ref)|` | `c_0` se cancela | ninguno |
| E2 | `log(v_A/v_B)` | `c_0` se cancela | ninguno |
| E3 | ratio interno `max_d v(d)/min_d v(d)` frente a coeficiente externo `Delta nu/nu` | escala global de `A/tau` se cancela | un `A` invertible y un `tau` comunes; falta un operador forward preregistrado entre ambos endpoints |
| E4 | retraso dividido por tiempo de paso basal | requiere un control externo para definir una unidad, luego se normaliza | un tiempo basal fijado por metadata, no por el resultado |
| E5 | direccion de salida, multiplicidad inversa y efecto cualitativo de fuerza | adimensional/categorico | ninguno |

## Que calibran realmente E1 y E2

E1 conserva la prediccion `D_E1=0` dentro de todos los bounds lineales de Fermi. E2 conserva `theta=0` dentro del bound compuesto `[-3e-15,+7e-16]` para `delta`, transformado por `theta=log(1+delta)`. Ambos resultados eliminan exactamente el factor `c_0`.

En consecuencia, estos tests pueden rechazar una dependencia relativa de velocidad si fuera observada bajo los supuestos congelados, pero no pueden estimar `ell_0`, `t_0` ni `c_0`. Tampoco calibran la correspondencia `energia <-> s_reg`, `GW/EM <-> etiquetas`, ni la preparacion de un portador DEE a partir de una fuente fisica. Sus resultados `COMPATIBLE_NOT_VALIDATING` aportan ausencia de contradiccion, no una medicion de parametros Rosetta.

Las incertidumbres externas no se pueden propagar hacia una escala DEE inexistente. En E1, solo el escenario DisCan declara un 99 % comun para su bound; los escenarios (a)–(f) dependen de asociaciones y ventanas de emision, con entradas conservadoras de 1 sigma. En E2, el bound combina timing gamma al 68 %, distancia inferior al 90 % creible y lags astrofisicos fijos de 0 y 10 s; no posee una unica confianza estadistica homogenea. Estas convenciones limitan los endpoints relativos, no generan una posterior para `ell_0/t_0`.

## Por que E3 no calibra espacio y tiempo

El teorema congelado de E3 cuantifica sobre todo `A` invertible y todo `tau>0` comunes:

`max_d v(d)/min_d v(d) >= sqrt(3)`.

Cambiar la norma global de `A` o `tau` multiplica numerador y denominador por el mismo factor y no cambia la razon; por ello ninguna eleccion permitida hace equiveloces las 26 direcciones. Pero el bound de Nagel et al., `Delta nu/nu=(9.2 +/- 10.7)e-19` al 95 %, es un coeficiente de resonador, no el ratio extremo D26. El contrato omitio la regla de orientacion, ida/vuelta y nuisances que los conectaria.

Por eso E3 no entrega un estimador de `A` o `tau` y su contraste externo se adjudica `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`. La cota interna sí elimina la subclase que exige equivelocidad de todas las direcciones. Cualquier calibracion futura necesita una construccion emergente y un operador experimental derivados independientemente, no un ajuste posterior al mismo dato.

## Por que E4 y E5 no aportan calibracion

E4 permitia una unica unidad temporal tomada del control sin bloqueo. Ningún experimento calificante con fuente persistente, oclusion unitaria, dos detectores temporales y control quedó documentado bajo la búsqueda congelada; como el log no conserva un registry candidato-por-candidato, no se afirma exhaustividad. Esa unidad nunca se observa y no existe un numero que pueda asociarse a un tick ni una respuesta externa con la cual estimar el cociente.

E5 no admitia parametros: debia contrastar directamente mayoria no ponderada, robustez frente a intensidades y multiplicidad inversa. Ningún experimento calificante de cinco entradas simultaneas con intensidades y direccion de salida quedó documentado; sin ese endpoint no se calibra `s_reg` como fuerza, energia, amplitud o momento, ni `direction` como direccion fisica. El estado correcto de ambos casos es `NOT_IDENTIFIABLE`, no una estimacion con gran error.

## Deficiencia de rango de la calibracion

Con los datos disponibles, el problema inverso queda subdeterminado:

- E1 y E2 proporcionan solo cocientes nulos y son invariantes bajo `(ell_0,t_0) -> (lambda ell_0,mu t_0)` con el cociente comun absorbido en todas las velocidades.
- E3 no define una likelihood sobre `A,tau`; la cota elimina sólo la subclase lineal equivelocidad y el forward óptico está ausente.
- E4 no proporciona la unidad de tiempo basal prevista.
- E5 no proporciona observaciones para el diccionario de colision.

Por tanto no existe una funcion de verosimilitud identificable para una escala absoluta ni para un mapa de preparacion/deteccion. No hay grados de libertad numericos que ajustar legitimamente, intervalos de calibracion que reportar ni constante fisica que extraer.

## Pieza operacional que falta

Para convertir esta Rosetta interna en una calibracion fisica cuantitativa se requieren, como minimo y sin usar el mismo dato para definir y validar el mapa:

1. una construccion derivada de geometria efectiva que asigne distancias y duraciones operacionales a trayectorias DEE y que sobreviva un test de anisotropia independiente;
2. un protocolo fisico de preparacion y deteccion que identifique que estados o clases DEE corresponden a las fuentes y lecturas externas;
3. al menos un endpoint dimensional absoluto que determine una combinacion como `ell_0/t_0`, mas otro endpoint independiente si se desean `ell_0` y `t_0` por separado;
4. holdouts posteriores que contrasten el mapa ya fijado y no solo relaciones nulas genericas.

Nada en `E1`–`E5` suministra esas piezas. Introducirlas por ajuste posterior, usar escalas por clase/direccion o declarar `c_0` igual a una constante externa por semejanza violaria el contrato y no constituiria una Rosetta no arbitraria.

## Fuentes primarias usadas por los endpoints con datos

- Fermi GRB 090510: https://doi.org/10.1038/nature08574 y https://arxiv.org/abs/0908.1832
- GW170817/GRB 170817A: https://doi.org/10.3847/2041-8213/aa920c y https://arxiv.org/abs/1710.05834
- Test de anisotropia de Nagel et al.: https://www.nature.com/articles/ncomms9174 y https://arxiv.org/abs/1412.6954

`E4` y `E5` no tienen una fuente primaria aceptada porque ninguna de las candidatas inspeccionadas satisfizo los criterios congelados.
