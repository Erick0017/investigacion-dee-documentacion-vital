# Holdouts externos de la Rosetta DEE v27

## Control epistemico

Este documento adjudica exclusivamente los holdouts `E1`–`E5` definidos en `HOLDOUTS/ROSETTA_FROZEN_CONTRACT.json`. El contrato fue sellado antes de abrir los valores externos con SHA-256

`d942e87587be199436d9da10010d77be728bceffe1a263a254679e75d4eec157`.

Se preservaron sin seleccion posterior el observable, la transformacion, los nuisances, los parametros permitidos y el vocabulario de resultados. Las fuentes numericas de `E1`–`E3` son primarias; `E4` y `E5` aplican las busquedas y topes congelados. Estos son *shadow holdouts*: su apertura posterior al sello protege esta ejecucion contra ajuste local, pero no garantiza novedad respecto del conocimiento previo del modelo ni convierte compatibilidad en validacion.

## Resultado conjunto

| ID | Relacion congelada | Parametros permitidos | Resultado | Alcance exacto |
|---|---|---|---|---|
| `E1_LABEL_NONDISPERSION` | `D_E1=max_j |log(v_j/v_ref)|=0` para etiquetas en el mismo camino y direccion libres | ninguno | `COMPATIBLE_NOT_VALIDATING` | Cero permanece permitido en todos los escenarios lineales reportados por Fermi; no identifica energia con `s_reg`. |
| `E2_COMMON_SIGNAL_SPEED` | `theta=log(v_A/v_B)=0` para dos etiquetas del mismo estrato libre | ninguno | `COMPATIBLE_NOT_VALIDATING` | Cero pertenece al bound GW/EM condicionado; no demuestra que GW y EM sean etiquetas DEE ni que compartan `K_free`. |
| `E3_DIRECT_LINEAR_EUCLIDEAN_GEOMETRY` | `v(d)=||A d||_2/tau`, un solo `A` invertible y un solo `tau` | `A` comun y `tau>0` comun | `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN` | La obstruccion algebraica `sqrt(3)` es exacta, pero no se congelo el operador que lleva velocidades D26 al coeficiente de frecuencia del resonador. |
| `E4_OBSERVER_OCCLUSION_PHASE_ANALOGUE` | retraso normalizado uno y paridad opuesta tras una oclusion unitaria | un tiempo de paso basal tomado del control | `NOT_IDENTIFIABLE` | La busqueda congelada no encontro un experimento con los cuatro metadatos operacionales requeridos. No es un FAIL del fenomeno DEE. |
| `E5_FIVE_SOURCE_MAJORITY_ANALOGUE` | mayoria no ponderada de cinco direcciones y multiplicidad inversa `7:1`; `s` solo afecta la carga capada | ninguno | `NOT_IDENTIFIABLE` | No se encontro un experimento primario calificante de cinco entradas. No refuta T11 ni fija el significado externo de `s_reg`. |

No hay validaciones externas DEE: `E1` y `E2` son compatibilidades nulas compartidas por muchas teorias, `E3` es inconcluso como contraste experimental, y `E4`–`E5` carecen de endpoint externo identificable. Separadamente, el teorema `sqrt(3)` descarta que una sola aplicacion lineal haga equiveloces las 26 direcciones.

## E1 — nondispersion respecto de etiqueta

### Fuente y transformacion

La fuente primaria es A. A. Abdo et al. (Fermi GBM/LAT), *A limit on the variation of the speed of light arising from quantum gravity effects*, Nature 462, 331–334 (2009): [DOI](https://doi.org/10.1038/nature08574), [pagina editorial](https://www.nature.com/articles/nature08574), [manuscrito primario](https://arxiv.org/abs/0908.1832).

La transformacion congelada asocia monotonamente bandas externas de energia con distintas etiquetas `s` y compara retardo o velocidad normalizados dentro de un mismo trayecto. La escala comun de longitud/tiempo se cancela. No hay parametros libres y no se permite escoger a posteriori un lag intrinseco.

### Intervalos y supuestos conservados

Fermi uso `z=0.900`, limite inferior de una medicion `0.903 +/- 0.003`, y para los escenarios principales una energia conservadora de `28.0 GeV` para el foton de aproximadamente `31 GeV` que llego `0.829 s` despues de `T0`. Se conservaron los siete escenarios lineales:

| Escenario | Bound temporal reportado | `M_QG,1/M_Planck` | Convencion relevante |
|---|---:|---:|---|
| (a) | `Delta t < 859 ms` | `>1.19` | inicio de cualquier emision `<1 MeV`; entradas conservadoras de 1 sigma |
| (b) | `Delta t < 299 ms` | `>3.42` | inicio de emision principal `<1 MeV`; entradas conservadoras de 1 sigma |
| (c) | `Delta t < 181 ms` | `>5.63` | inicio de emision principal `>0.1 GeV`; entradas conservadoras de 1 sigma |
| (d) | `Delta t < 99 ms` | `>10.0` | inicio de emision `>1 GeV`; entradas conservadoras de 1 sigma |
| (e) | `|Delta t| < 10 ms` | `>102` | asociacion del foton de 31 GeV con un spike contemporaneo |
| (f) | `|Delta t| < 19 ms` | `>1.33` | asociacion de un foton de 0.75 GeV; energia conservadora `0.694 GeV` |
| (g) | `|Delta t/Delta E| < 30 ms/GeV` | `>1.22` | DisCan, 99 % de confianza |

Los escenarios (a)–(f) son bounds condicionados por ventanas o asociaciones de emision y la tabla primaria no les asigna un nivel frecuentista comun. El resumen editorial redondea el limite lineal robusto a `1.2 E_Planck`. El offset poblacional `258 +/- 34 ms` entre bandas no fue identificado por la colaboracion como dispersion de propagacion no nula. La fuente tampoco establece restricciones significativas universales para ordenes superiores.

### Adjudicacion

La dispersion nula pertenece a todos los bounds lineales: corresponde al limite de escala LIV infinita. Por la regla congelada, `E1 = COMPATIBLE_NOT_VALIDATING`. El resultado no demuestra que energia sea `s_reg`, no prueba nondispersion exacta para toda energia y todo orden, y no discrimina DEE de cualquier otra teoria con endpoint nulo.

## E2 — velocidad comun entre clases de senal

### Fuente y transformacion

La fuente primaria conjunta es LIGO Scientific Collaboration, Virgo Collaboration, Fermi GBM e INTEGRAL, *Gravitational Waves and Gamma-Rays from a Binary Neutron Star Merger: GW170817 and GRB 170817A*, ApJL 848, L13 (2017): [DOI](https://doi.org/10.3847/2041-8213/aa920c), [manuscrito primario](https://arxiv.org/abs/1710.05834).

El contrato asigna condicionalmente `A=GW`, `B=EM` y transforma

`delta=(v_GW-v_EM)/v_EM` en `theta_ext=log(1+delta)`.

No hay parametros libres; una escala comun se cancela. Solo se admiten las cotas de lag de emision fijadas en el paper.

### Intervalo, confianza y nuisances

La llegada gamma fue `1.74 +/- 0.05 s` posterior al tiempo GW; la incertidumbre gamma usa una convencion del 68 %. El limite usa `26 Mpc`, extremo inferior del intervalo creible de distancia al 90 %. El bound principal es

`-3e-15 <= delta <= +7e-16`,

equivalente a

`log(1-3e-15) <= theta_ext <= log(1+7e-16)`,

que a la precision reportada es `[-3e-15,+7e-16]` y contiene cero. El extremo positivo supone emision simultanea; el negativo supone que el SGRB fue emitido `10 s` despues del GW. Por mezclar timing al 68 %, distancia al 90 % y supuestos astrofisicos deterministas, no es un intervalo unico con confianza homogenea. La ventana exotica `(-100 s,1000 s)` mencionada por la fuente no se sustituyo por el resultado principal despues de abrirlo.

### Adjudicacion

`theta=0` pertenece al bound condicionado, de modo que `E2 = COMPATIBLE_NOT_VALIDATING`. La igualdad es compatible solo bajo la asignacion Rosetta congelada y la cronologia seleccionada de antemano; no prueba la identidad de clases, el estrato comun ni una escala fisica DEE.

## E3 — geometria euclidea lineal directa

### Fuente y contraste sin escala

La fuente primaria es Nagel et al., *Direct terrestrial test of Lorentz symmetry in electrodynamics to 10^-18*, Nature Communications 6, 8174 (2015): [pagina editorial](https://www.nature.com/articles/ncomms9174), [preprint primario](https://arxiv.org/abs/1412.6954).

El experimento reporta la variacion relativa dependiente de orientacion

`Delta nu/nu = (9.2 +/- 10.7)e-19` al 95 %,

es decir, el intervalo `[-1.5e-19,1.99e-18]`, sin violacion significativa al nivel de `1e-18`. El observable de resonador puede mezclar sectores fotonico, electronico y del medio; una lectura puramente fotonica requiere la convencion del propio analisis. Esta dependencia es un supuesto del puente, no evidencia ontologica.

Para todo `A` lineal invertible y todo `tau>0`, la prediccion interna congelada satisface

`max_d ||A d||_2 / min_d ||A d||_2 >= sqrt(3) = 1.732050807568877...`.

Por tanto el contraste minimo de velocidad entre las 26 direcciones es al menos `sqrt(3)-1 = 0.732050807568877...`, de orden unidad y no removible por una escala comun. Esto refuta algebraicamente la equivelocidad de ese diccionario. No obstante, el contrato no especifico como una orientacion continua de cavidad selecciona/compone D26, la propagacion de ida y vuelta, la orientacion de la reticula ni los nuisances foton/electron/medio. El coeficiente `Delta nu/nu` no es literalmente el ratio extremo de velocidades.

### Adjudicacion

`E3_EXTERNAL = INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`. El `FAIL_BRIDGE` escrito inicialmente en `RESULTS/external/e3_e5_results.json` se conserva sin modificacion, pero una auditoria adversarial lo supersede en `RESULTS/external/e3_adjudication_audit.json`: el criterio congelado exigia que el bound externo forzara un ratio menor que `sqrt(3)`, algo que no puede inferirse del endpoint publicado sin el operador ausente. No hubo refit ni seleccion de otro mapa. La obstruccion interna sigue probada y no cubre coarse-graining, geometria no lineal/Finsler, ni una descripcion estocastica o renormalizada.

## E4 — analogo de oclusion y fase

Se ejecutaron, en el orden congelado, las tres consultas sobre shutter/pulse-train/waveguide, bloqueo de un pulso en una fuente periodica y exclusion impulsada por frontera, con un maximo de 20 candidatos por consulta. Para calificar se exigian conjuntamente fuente persistente, bloqueador de entrada de exactamente una unidad operacional, dos posiciones aguas abajo resueltas en tiempo y control sin bloqueo.

Ningun dataset calificante quedo documentado bajo las consultas y topes congelados; por ello no pudo estimarse simultaneamente `D_k=1` en varios detectores ni la inversion de paridad. El log no conserva un registry candidato-por-candidato, de modo que la cobertura de busqueda no es reproducible independientemente y no se afirma exhaustividad del universo externo. El unico parametro permitido —un tiempo de paso basal procedente del control— no existe sin un dataset calificante. `E4 = NOT_IDENTIFIABLE`, no `FAIL_BRIDGE`: permanece intacta la ley computacional DEE, pero no hay medicion externa del endpoint congelado.

## E5 — analogo de mayoria de cinco fuentes

Se ejecutaron, en el orden congelado, las tres consultas sobre coalescencia de cinco entradas, colision de cinco haces y coalescencia multiparticula, con un maximo de 20 candidatos por consulta. Se exigian al menos cinco entradas simultaneas, intensidades registradas, salida direccional medida y resolucion temporal.

Ningun dataset calificante quedo documentado. El log conserva consultas, criterios y tope, pero no un registry candidato-por-candidato; por ello no se reclama exhaustividad reproducible. No se redujo la aridad, no se aceptaron simulaciones como datos y no se redefinio `s_reg` despues de observar los resultados. `E5 = NOT_IDENTIFIABLE` para el diccionario directo `direction -> direccion` y `s_reg -> intensidad`. Esto no refuta la prediccion interna de mayoria, su multiplicidad inversa `7:1` ni otros significados posibles de `direction` o `s_reg`.

## Veredicto externo

El bloque externo no satisface la condicion contractual de una Rosetta validada: no hay dos familias externas con apoyo discriminante y el operador forward geometrico-optico de E3 no fue identificado. Lo que sobrevive es mas limitado y preciso:

1. dos relaciones nulas internas transfieren condicionalmente sin contradiccion (`E1`, `E2`);
2. una clase completa de equivelocidad lineal directa queda excluida por algebra, mientras el contraste externo E3 queda inconcluso;
3. dos analogos mecanisticos no pueden adjudicarse por ausencia de datasets operacionales (`E4`, `E5`).

No se obtiene equivalencia fisica, escala dimensional, ontologia externa ni validacion especifica de DEE.
