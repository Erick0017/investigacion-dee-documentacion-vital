# Kernel unificado de respuesta `K_dagger`

## Objeto común

No existe un único kernel lineal independiente del estado que describa DEE v27. T10 mostró además que un solo registro no debe confundirse con dos funciones distintas: estado predictivo y evento instantáneo. El objeto transversal reparado es el transductor no lineal `(G_dagger,J_dagger)` sobre el estado aumentado `Z`, junto con su cociclo de diferencias finitas

`K_dagger^t[Z;I] = phi(G_dagger^t(I Z)) - phi(G_dagger^t Z)`.

Aquí `I` es una intervención preregistrada, `phi` embebe los registros canónicos en indicadores con signo y `J_dagger` emite el resultado raw transitorio de cada colisión. `K_dagger` depende del baseline porque exclusión, colisión y saturación rompen superposición. La pareja intervenido/baseline compone exactamente bajo `G_dagger`; la diferencia por sí sola no tiene por qué hacerlo.

## Ley efectiva reparada `G_dagger/J_dagger`

En cada slice certificado:

1. un blanco `q` está cerrado si `a(q)=1` o `p(q)=1` en la entrada;
2. todo registro con `d` Moore no nula propone `(d,s)` a `q+d mod N`, con independencia de `a,p`;
3. cada `p=1` se copia en su posición;
4. los registros no observer no persisten localmente en `D_*`;
5. propuestas sólo se reducen en blancos abiertos;
6. una fuente crea `C(q,d,s)`;
7. varias fuentes producen primero el evento `J_dagger=(q,u,S)`, con `u=sign(sum d_j)` y `S=min(sum s_j,19664)`;
8. el estado hijo es `C(q,u,S)` si `u!=0`, pero `C(q,0,0)` si `u=0`, aplicando la misma canonización que define `M_*`.

El `G_*` original omitía el paso 8 y T10 lo refutó en 96 colisiones opuestas, con otras 96 desalineaciones iteradas. La ecuación corregida es `M_*(F_DEE X)=G_dagger(M_*X)` para cada slice en `D_*`; su prueba es por ramas y T12 la confirmó prospectivamente en 748 trayectorias/1,496 ticks de aridades 3/4/6, con cero mismatches. El evento conserva `S` incluso cuando el estado predictivo la descarta.

## Estrato libre

Para un portador con velocidad fija,

`K_free^t((y,d',s'),(x,d,s)) = delta[d'=d] delta[s'=s] delta[y=x+t d mod N]`.

Es una matriz de permutación y satisface `K_free^(t+u)=K_free^u K_free^t`. En Fourier,

`rho_hat_m(t+1)=exp(-2*pi*i*m·d/N) rho_hat_m(t)`.

Por tanto hay modos colectivos exactos de advección en cada capa cinética. Son modos de un sector preparado; no demuestran ondas físicas, Lorentz invariancia ni un continuo.

## Estrato de frontera observer

Para una fuente aislada en `q`, antes del wrap toroidal y sobre su rayo,

`K_obs(t,k)=1[1<=k<=t] 1[k=t (mod 2)]`.

La exclusión en la boca produce un tren alternante pre-wrap. En variables booleanas,

`u_{t+1}(1)=1-u_t(1)`,

`u_{t+1}(k)=u_t(k-1)(1-u_t(k))` para `k>=2`.

El mapa fuente-a-detector aislado no es un semigrupo lineal, pero el estado aumentado que conserva la boca sí es Markoviano. Una oclusión inicial que desaparece al tick 1 desplaza todos los first-passages pre-wrap una unidad e invierte la paridad; la diferencia Hamming crece linealmente.

## Vértice de colisión

El vértice simultáneo es

`C({d_j,s_j})=(sign(sum_j d_j),min(sum_j s_j,19664))`.

Es conmutativo respecto del multiconjunto de entradas, no lineal y many-to-one. La compresión binaria `d1 odot d2=sign(d1+d2)` no es asociativa después de insertar un tick intermedio. Por ello el estado debe conservar la aridad y simultaneidad del evento hasta resolverlo; una dirección ya comprimida no representa toda su historia.

La susceptibilidad de carga es uno por debajo del cap y cero frente a incrementos que permanecen saturados. La dirección cambia en superficies discretas definidas por el signo de las sumas coordenadas.

## Geometría de respuesta

`G_dagger` induce un hipergrafo en espacio de fase:

- aristas libres `(q,d)->(q+d,d)`;
- self-loop de cada fuente `O`;
- hiperaristas de colisión de varias propuestas a un producto;
- guards de exclusión que abren o cierran hiperaristas según `a,p`.

La causalidad nativa es reachability en este objeto. Un solo `d` sólo alcanza el ciclo generado por esa dirección; incluso la unión de los 26 vuelos rectos no llena generalmente el toro. Permitir reorientación en cada tick define otro aparato y no puede introducirse tácitamente.

## Inversión

La inversión microscópica correcta es conjuntista. Para dos direcciones Moore, 325 pares no ordenados se proyectan en 27 salidas: cada salida no nula tiene 12 preimágenes y cero tiene 13. El contrato T11 congeló una predicción de mayor aridad que no se usó en discovery: para todas las selecciones de cinco de las ocho diagonales corporales, la salida es la mayoría coordenada y cada una de las ocho salidas aparece desde siete subconjuntos en el panel igualitario.

## Lectura científica

El mismo transductor explica transporte, first-passage, respuesta, memoria aparente, irreversibilidad, colectividad y la diferencia entre información de estado e información de evento. La linealidad existe por estratos, no globalmente. La arquitectura es específica de las ramas ejecutadas de v27; que otros autómatas puedan poseer una forma “propuesta–guard–reducer” no convierte en genéricos el alfabeto, las guardas, el cap, el pump alternante ni las multiplicidades de DEE. T10 permanece FAIL para la formulación original; T12 sólo confirma la formulación posterior.
