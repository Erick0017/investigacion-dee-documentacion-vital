# Exact theorems and exact computational identities of DEE v27

## Scope rule

“Exact” below means proved from the hash-pinned v27 implementation or verified by exhaustive equality in the stated finite apparatus. Empirical MSH02 performance is not promoted to theorem. Full proofs and source anchors are in `EVIDENCE_FOUNDATION/PARENT_EXACT_THEOREMS.md`.

## Global theorems of F_DEE

1. **Clock evolution.** For every site, `clock_i(t)=clock_i(0)+t mod 2^64`; pairwise clock offsets are invariant.
2. **Raw causal cone.** One raw update depends on raw records no farther than Chebyshev distance three and on clock no farther than one. Consequently raw influence is bounded by `3t`; a distance-three one-step witness makes the raw bound sharp where the torus permits.
3. **Translation equivariance.** Every torus translation commutes with F_DEE.
4. **Dense/lazy identity.** The two valid execution paths compute the same map under the audited ABI.
5. **Non-injectivity.** For `N>=3`, distinct valid singleton raws with state labels 1 and 2 provide an explicit collision under one update. This is not a claim that every pair of raws collides.
6. **Inactive crystallization branch.** The audited gradient/crystallization predicate is unreachable under the actual field ranges.
7. **Boolean pre-DEMUX rule.** Survival/XNOR/routing predicates have the exact truth tables extracted from the v27 source/binary contract.
8. **Semantic-4 invariant family.** Persistent observer raws support nontrivial range-zero charges `Q_f` obtained by assigning weights to fixed semantic-4 raw values; therefore a universal “no range-zero invariants” claim is false.
9. **Global cubic symmetry fails.** Translations survive, but the full `O_h` action does not commute globally because deterministic lexicographic/tie and overflow choices provide counterexamples.

## Arithmetic/phase theorem

Away from uint64 wrap and within the audited active raw gates, the primitive periods are 195, 260, 391 and 782, with least common multiple 304,980. Claude's 1,094,573,220 is a common raw coefficient period in a restricted no-wrap reading, not the minimal active period and not a full-state gauge period.

## Certified sectorial theorems

10. **Singleton ballistic sector.** For `N>=5`, an isolated normal carrier translates by its Moore direction each tick, has raw period N on the torus and admits exact Fourier dispersion for the 26 directions.
11. **Separated common-direction gas.** Non-colliding carriers of a common direction evolve as a reversible permutation, preserving count, carried fields and relative pattern.
12. **Collision algebra.** A simultaneous collision produces `s_out=min(sum_j s_j,19664)` and direction `sign(sum_j d_j)` componentwise under the certified apparatus.
13. **Persistent observer/source.** The relevant semantic observer is a fixed source/boundary and emits the exact alternating pre-wrap train established in the parent proof.
14. **Dense fixed family.** The declared dense raw configurations are fixed in raw projection.
15. **Repaired Q1 closure.** `G_dagger` plus the separate event ledger `J_dagger` closes prospectively on `D_*`; the merged predecessor does not.

## Exact panel identities, not universal theorems

- MSD01: no observed raw difference escaped the `3t` cone; exact joint-inventory preservation passed for every shuffle pair.
- MSD03/MSD05: declared sparse tails have exact full-array raw period N over the stored/tested windows; declared dense tails have exact raw period 1.
- MSD06: after deleting state and retaining R, the one-step positive mask equaled the exact routed-destination union in 8/8 contexts; five sparse contexts exactly recoalesced with their natural path after one tick.
- MSH02: all lock, runner, wheel, package and kernel hashes match; all 60 row predicates and integer decisions satisfy the frozen contract. This is an exact audit of a finite empirical panel, not a theorem for all states.

## Explicit non-theorems

No theorem here identifies clock as physical time, state as matter, s_reg as energy, direction as momentum, raw periodicity as quantum phase, topology as gravity or q_N as a natural constant. No theorem establishes a universal hydrodynamic limit, asymptotic basin or external physical equivalence.
