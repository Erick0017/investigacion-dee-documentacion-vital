# Executive verdict — DEE v27 multiscale emergence and Rosetta

## Outcome

The mission closes as `HIERARCHY_FOUND_EXTERNAL_FRONTIER`.

DEE v27 has a reproducible internal mathematical architecture across three levels:

- `Q0`: the exact microscopic Markov state `X=(raw,clock)`.
- `Q1`: a certified sectorial causal description `Z=M_*(X)` with lineage/source/router roles and a necessary separation between predictive state `G_dagger` and instantaneous event ledger `J_dagger`.
- `Q2`: a prospectively confirmed finite-domain order law. In MSH02, the one-count observable `q_N=count(state>0,t=N)/N^3` predicted dense raw fixation by `4N` versus sparse minimal exact raw period `N` by `16N` in 60/60 unopened rows.

MSH02 was frozen before opening and executed once. It yielded 50 dense, 10 sparse and zero OTHER outcomes across twenty seed groups at unused `N=33,38`; full balanced accuracy was 1 versus 33/50 for the best frozen nuisance null. Its prospective pre-crossing subset passed 22/22 across eight delayed-dense and five sparse groups. Independent audit found zero discrepancies. Result SHA-256: `83b8cc522e239cf9df847c715e01430b812da1f7749fa0e55ee2ee97fbe89b52`.

## What this means

The smallest currently supported cross-scale picture is not “occupied voxels are matter.” It is a phase-dependent interaction among positive support `P`, a routing complement `R`, destination geometry/collision multiplicity, semantic guards/sources, `s_reg` event load and clock phase. `q_N` is a compact predictor on natural preparations, not a complete state or a sole cause. The frozen descriptive direction-support comparator also scored 60/60; predictive identity is therefore not unique. MSD06 separately showed that deleting direction while holding every state value fixed changed the later witness in 5/6 long contexts, whereas deleting state while retaining routing preserved it in 6/6.

Exact or sectorial conservation exists, but no global physical energy or momentum has been found. Exact clock offsets, observer-supported raw charges and translation symmetries survive; free-flight sectors conserve lineage count, carried `s_reg`, direction and relative pattern. Collisions supply a capped local balance rather than global conservation.

DEE supports collective behavior: exact ballistic/Fourier modes in free sectors, observer-driven alternating trains, and a confirmed dense-versus-sparse projected regime law. It does not yet support a universal interacting hydrodynamic mode, thermodynamic ensemble, mass/inertia law, dynamic metric, Born rule, Bell apparatus or gauge field.

## What remains missing

The internal Rosetta is quantitative:

`X -> M_* -> (G_dagger,J_dagger) -> P/R/destination organization -> q_N -> finite raw regime`.

The physical Rosetta is not identified. The exact missing construction is:

`physical preparation -> ensemble over DEE states -> causal/coarse-grained history -> detector forward operator -> distribution of observed records`,

with separate dimensional calibration and at least two preregistered external validation families. No additional local kernel sweep can choose that dictionary or the voxel/tick-to-SI scale. This is an external identification frontier, not an ontological FAIL of H_DEE.
