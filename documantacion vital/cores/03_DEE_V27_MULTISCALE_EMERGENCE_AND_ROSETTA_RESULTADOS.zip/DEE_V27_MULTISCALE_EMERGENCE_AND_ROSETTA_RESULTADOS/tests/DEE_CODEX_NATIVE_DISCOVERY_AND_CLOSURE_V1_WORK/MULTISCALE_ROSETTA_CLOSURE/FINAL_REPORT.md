# Final report — native discovery and multiscale closure of DEE v27

## Scientific endpoint

The investigation reached the authorized stopping state `HIERARCHY_FOUND_EXTERNAL_FRONTIER`. The exact wheel and binary were interrogated enough to establish an internal hierarchy through a bounded Q2 law; the remaining bridge to observed physics requires external preparation, measurement and calibration information absent from the kernel and workspace.

The resumed campaign executed seven scientific wheel interrogations: 306 trajectories or intervention segments, 48,942 universe-ticks and eight distinct lattice sizes. No sealed parent, frozen lock, wheel or historical artifact was modified. Technical interruptions that produced no complete result were recorded and never counted as scientific outcomes.

## The hierarchy

`Q0` is exact: `X=(raw_grid,clock_grid)` is the microscopic Markov state of `F_DEE`.

`Q1` is sectorial: `M_*` maps certified sparse worlds to causal roles—latent routers `L`, normal carriers `C`, persistent semantic observers `O`—while `G_dagger` closes their predictive transition and `J_dagger` separately records collision events. The original single state/event formulation failed and remains a literal FAIL.

`Q2` is empirical and bounded but prospectively confirmed. The integer support count at system-size time, equivalently `q_N`, predicts one of two exact raw-projection witnesses in the frozen MSH02 family. Promotion is limited to the declared sizes, initial preparations and finite horizons. No full-state or asymptotic closure is asserted.

## Decisive confirmation

MSH02 lock SHA-256 is `e0cf530948057df93c852b3513fb83c751bd7a2c22e30bab2c304b6288c24f88`; its canonical payload is `ce6a2ef35cc267c000b99fb93d8e316e009477159f0116947fbe95621913e1a5`; runner SHA-256 is `85f6cccf3d7925702b9119514dc90351c0f8102ad525437f788a4569c219d1f7`. The single-use result was absent when checkpoint_0009 was sealed.

The one execution produced:

- 60/60 primary predictions and balanced accuracy 1;
- 50 dense raw-fixed and 10 sparse minimal raw-period-N outcomes;
- zero OTHER and zero per-size errors;
- twenty dense-class groups, five sparse-class groups and five mixed groups;
- full-panel advantage `17/50` over the best frozen nuisance null;
- pre-crossing 22/22, with delayed-dense/sparse groups `8/5` and advantage `1/2`;
- minimum compression gain `287495/287496`;
- result hash `83b8cc522e239cf9df847c715e01430b812da1f7749fa0e55ee2ee97fbe89b52`.

The executable and two independent audits agreed. One post-holdout audit wrapper initially guessed the schema label incorrectly; every numerical check was already true, the wrapper alone was corrected, and the kernel was not rerun. Final audit SHA-256 is `0747222f7060dbd88d55551bdac4f358aab5ec6d82f69dad1104d8cd260767c7`.

## Native architecture

The dynamics are best described by proposals, routing, guards, collisions, persistence and phase—not by a single substance field. Positive support `P` is predictive on the natural manifold. The complement `R=(direction,s_reg,semantic,clock)` retains routing and conditional behavior. Destination sets and collision multiplicities are relational objects produced by the proposal map. Their effects depend on phase and regime.

MSD01 showed that rearranging the same joint raw+clock inventory changed all tested inner responses, while removing outer records and deleting direction were response-equivalent in that apparatus. MSD02–04 discovered and simplified an early collective separator to one support count. MSH01 remained literally inconclusive because its endpoint censored four non-dense worlds. MSD05 showed all nine non-dense worlds had exact period N by 16N. MSD06 then separated prediction from causal carriage. MSH02 prospectively confirmed the repaired law without importing the off-manifold interventions.

## Conservations and balances

Exact global invariants include pairwise clock offsets modulo `2^64` and families of charges supported on persistent semantic-4 raw values. Translation equivariance is exact. Free-flight sectors preserve carrier count, directions, carried `s_reg` and relative configuration and possess exact Fourier advection modes. Collisions obey `s_out=min(sum s_j,19664)` and `d_out=sign(sum d_j)`; saturation and direction reduction destroy a general additive conservation law. Birth/death of positive support prevents interpreting its sum as conserved matter.

The absence of low-range additive invariants outside proven families is not a global no-conservation theorem. Relational, sectorial, topological, approximate and coarse-grained balances remain open unless specifically tested.

## Physics status

- Matter: no unique microscopic matter variable. The closest operational objects are causal lineages, routers, sources and collective organized phases.
- Geometry/causality: a fixed periodic combinatorial substrate, state-dependent directed proposal graph and exact raw cone `r_infinity<=3t`; no dynamic metric or gravity.
- Clock: exact modular phase counter controlling gates; not identified with SI time.
- Mass/inertia: not identified; free speed does not depend on state or `s_reg`, and collision direction is not `s_reg`-weighted momentum.
- Thermodynamics/hydrodynamics: order regimes and sectorial kinetics exist, but ensemble, energy, equilibrium, temperature, slow-field closure and constitutive laws do not.
- Quantum/Bell: generic Koopman representations and periodicity are insufficient; no Born map, measurement algebra or DEE CHSH apparatus exists.
- Symmetry/gauge: translations are exact; full cubic `O_h` is broken by deterministic tie/overflow behavior; clock phase is not a full-state gauge.

## Rosetta adjudication

The inherited external tests were not repeated. E1/E2 remain `COMPATIBLE_NOT_VALIDATING`, E3 remains `INCONCLUSIVE_FORWARD_OPERATOR_NOT_FROZEN`, and no qualifying E4/E5 datasets exist locally. MSH02 adds a confirmed internal bridge but no physical preparation/readout dictionary.

The only claim licensed under H_DEE is conditional: if an independently specified laboratory preparation maps to a DEE ensemble and a frozen detector forward model maps DEE histories to observed distributions, the now-defined internal hierarchy can be falsified against reality. Until that construction and independent data exist, physical equivalence is `NO_IDENTIFICABLE`.

Detailed theorem, history, adversarial, hierarchy, object, Rosetta and gap reports accompany this file. `CLAIM_LEDGER.csv` is the authoritative claim-by-claim inventory.

For Windows reproduction, `REPRODUCE.ps1` performs the non-mutating integrity audit without rerunning science. Any actual CPython 3.13 x64 kernel import or runner execution should use a short extraction path (for example `C:\DEE27`) because the native DLL loader can reject deeply nested paths independently of content integrity. The final archive retains the exact relative layout expected by all frozen runners.
