# Historical claims audit — final multiscale update

## Claims that survive with explicit scope

- The audited wheel/package/kernel identities and valid dense/lazy equivalence.
- Exact ballistic singleton and separated-gas sectors, collision algebra and persistent observer pumping.
- Non-injectivity with the corrected state-1/state-2 singleton witness.
- Plural finite raw regimes: free/periodic, observer-driven and dense fixed.
- V7-B's frozen reader performance and V7-C's same-inventory organization/history effects, only in their apparatuses.
- V6-E's negative fiber tests, only for the observers/fibers examined.
- Historical v25 nested-shell traces as discovery provenance; no automatic v27 transfer.
- MSH01's literal `INCONCLUSIVE_CLASS_DIVERSITY` result.

## Claims that do not survive

- Universal radius-one causality.
- Universal absence of range-zero additive invariants.
- Full global cubic symmetry.
- Active crystallization through the unreachable gradient branch.
- `TTL_ORFAN` metadata as a measured lifetime.
- D6 FFT-bin peaks as native oscillation periods.
- Occupancy as complete causal state or matter.
- s_reg as physical energy, direction as physical momentum or clock as SI time.
- A merged predictive-state/event observer.
- The four MSH01 OTHER rows as a stable third sparse class.
- q_N as a sole or unique causal carrier.
- Any already-validated external physical Rosetta.

## Observable biases exposed

1. **Occupancy bias:** hides state-zero routers and many packed-field differences.
2. **Projection-period bias:** raw can repeat while clock/full state does not.
3. **Window-spectrum bias:** FFT window length creates apparent period bins.
4. **Censoring bias:** the 4N endpoint labeled delayed period-N paths as OTHER.
5. **Preparation bias:** imposed translation does not demonstrate spontaneous mobility.
6. **Predictor/ontology bias:** an accurate q_N rule does not make positive support matter or the causal carrier.
7. **Size/arm leakage:** MSH02 explicitly challenged and beat frozen size and arm nuisance rules.
8. **Source-version bias:** v25 statements are not v27 theorems without transfer verification.

## New reconciliation supplied by the campaign

MSD01–06 and MSH02 jointly explain why apparently conflicting historical results coexist. Spatial organization and routing determine causal transmission; early support population predicts a later projected regime on a natural manifold; endpoint horizon determines whether sparse recurrence is recognized; and off-manifold component deletions show that the predictor is not the mechanism.

Thus the confirmed statement is narrower and stronger than the historical ontology: DEE v27 has a compressed finite-domain collective order law embedded in a richer proposal-routing-event dynamics.
