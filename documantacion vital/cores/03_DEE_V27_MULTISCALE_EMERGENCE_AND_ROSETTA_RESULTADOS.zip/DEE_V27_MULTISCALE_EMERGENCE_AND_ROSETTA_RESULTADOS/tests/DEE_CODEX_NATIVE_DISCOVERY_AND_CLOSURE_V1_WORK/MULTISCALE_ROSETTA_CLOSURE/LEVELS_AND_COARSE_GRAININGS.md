# Levels and coarse-grainings

| Level | Object | Closure status | Information retained | Information lost / limit |
|---|---|---|---|---|
| Q0 | `X=(raw,clock)` | Exact, global | Complete computational state | No compression; no physical interpretation |
| Q1 | `Z=M_*(X)`, `G_dagger`, `J_dagger` | Exact/prospectively verified in `D_*` | Causal roles, routing, carried load, semantic source behavior, collision events | Not licensed outside certified sparse sector; state and event must remain separate |
| Q2 | `q_N` plus frozen asymmetric raw witness | Prospectively confirmed in MSH02 domain | One-count order coordinate for dense-fixed vs sparse-period-N future class | Not Markovian, unique, causal-sufficient, asymptotic or physical |
| Q3+ | No promoted object | Open or refuted by branch | — | Stable third sparse class refuted in MSD05 panel; no universal higher closure |

## Q0 to Q1

The mapping is role-based rather than occupancy-based. A decoded state-zero record can be a latent router; a semantic observer can be a persistent source; a collision can be an event that should not persist in the reduced state. The T10 FAIL demonstrates that a reduction which mixes state and event does not close. The T12 repair closes only because `J_dagger` is retained separately.

## Q1 to Q2

Discovery found a collective population coordinate at `t=N`. MSH02 then froze its exact integer rule, preparation family and future quotient. Compression is extreme—at least `287495/287496` relative gain for the stored count—but only for predicting that binary finite-horizon witness. No autonomous Q2 transition law has been demonstrated.

## Coarse-grainings that failed

- Occupancy or positive state as a complete causal state.
- Static inventory/path features in the exact MSD02 bank.
- Macro/distribution observers on tested V6-E fibers.
- Original merged state/event description.
- q_N or the positive-state field as a sole carrier under MSD06 component deletion.
- A 4N-only sparse endpoint, which censored delayed period-N recurrence.

Each FAIL is representation- and domain-specific. It does not exclude relational, topological, higher-range, statistical or approximate closures not covered by its test.

## Natural quotient currently licensed

Within MSH02, two microhistories are Q2-equivalent only with respect to the declared future label. This quotient survived inventory-preserving shuffles, two sizes, semantic intervention, nuisance nulls and a pre-crossing subset. It does not assert equivalence for raw trajectory, intervention repertoire or external observation.
