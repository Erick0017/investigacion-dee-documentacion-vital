# Negative results — scope-preserving final ledger

## Exact/global negatives

- Universal raw locality radius one is false; radius three is sharp.
- F_DEE is not globally injective for `N>=3`.
- Full cubic `O_h` is not a global symmetry.
- The audited crystallization branch is unreachable.
- Clock is not globally redundant in the full state.

## Bounded representation failures

- Occupancy/positive state is not a complete causal state.
- The original merged state/event coarse-graining failed T10.
- Tested V6-E macro/distribution observers do not close their declared fibers.
- The exact MSD02 static feature bank did not supply a useful single-feature classifier beyond the majority baseline.
- q_N or the complete positive-state field is not a sole autonomous carrier in MSD06.
- A stable third sparse recurrence class did not survive MSD05's 16N panel.
- The MSH01 endpoint did not meet its own diversity rule and remains `INCONCLUSIVE_CLASS_DIVERSITY`.

## Physical non-identifications

- No DEE variable is identified as physical mass, inertia, energy, temperature or momentum.
- No dynamic metric, curvature, equivalence principle or gravitational backreaction was found.
- No hydrodynamic slow-field closure, stress tensor or constitutive law was found.
- No Born rule, quantum observable algebra, interference apparatus or Bell experiment was instantiated.
- No physical gauge redundancy was established.
- No external Rosetta passed validation; E1/E2 are compatible-not-validating and E3 is forward-operator-inconclusive.

## Non-globality rule

These results discard the tested representation, apparatus or bridge. They do not become impossibility theorems over untested relational invariants, higher-order coarse-grainings, approximate conservation, emergent isotropy or future external preparation/measurement models.
