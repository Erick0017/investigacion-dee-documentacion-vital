# Open external gaps and exact H_DEE missing piece

## Missing generative map

To connect DEE with observed physics, one must specify before validation:

1. a laboratory preparation map `P_lab -> distribution over X or a certified Z/Q2 ensemble`;
2. the microscopic equivalence relation representing physically invisible DEE detail;
3. a causally sufficient coarse-grained history and operational geometry;
4. a measurement/forward operator from histories/events to distributions of detector readings and non-detections;
5. noise, efficiency, selection effects and nuisance parameters;
6. dimensional calibration on data disjoint from the validation sets;
7. at least two new external families with more independent observables than fitted parameters;
8. frozen PASS/FAIL criteria and literal retention of adverse outcomes.

## Current rank deficiency

E1/E2 use ratios that eliminate the common scale. E3 lacks the lattice-to-resonator forward operator and likelihood. E4 has no basal unit and E5 no qualifying observation set. Consequently `ell_0`, `t_0`, any effective `c_0`, energy mapping and detector normalization cannot be jointly inferred.

## Exact status under H_DEE

The kernel can evaluate consequences after an internal state and readout are specified. It cannot determine what nature prepares or what an instrument measures. The missing piece is therefore external operational identification, not an uncomputed property of F_DEE. H_DEE remains conditionally testable and currently `NO_IDENTIFICABLE` with respect to our physical reality.
