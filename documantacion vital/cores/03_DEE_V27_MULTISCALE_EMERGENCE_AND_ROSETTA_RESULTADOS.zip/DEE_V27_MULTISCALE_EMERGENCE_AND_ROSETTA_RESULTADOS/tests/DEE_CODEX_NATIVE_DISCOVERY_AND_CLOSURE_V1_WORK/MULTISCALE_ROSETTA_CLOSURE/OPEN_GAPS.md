# Open gaps

## Internal mathematical gaps

- Prove or refute minimality of the P/R/destination decomposition by separating direction, s_reg, semantic and clock roles over a declared repertoire.
- Determine whether Q2 extends across sizes, preparation ensembles and horizons or exhibits finite-size transitions/universality.
- Identify interacting slow modes, currents or approximate balances under a frozen coarse-graining.
- Search preregistered relational/topological/higher-range invariants rather than extrapolating from low-range additive failures.
- Derive, or bound the impossibility of, an approximately isotropic effective geometry shared by multiple object classes.
- Determine whether ignition latency has a stable scaling law.

These are real questions but no longer change the present external-identification verdict.

## External identification gap

The decisive missing object is the full operational chain described in `OPEN_EXTERNAL_GAPS.md`. Until it exists, mass, matter-geometric coupling, thermodynamics, hydrodynamics, quantum/Bell and gauge correspondences remain `NO_IDENTIFICABLE` or unsupported rather than globally refuted.

## Reopening condition

A future campaign should not start with more unconstrained sweeps. It should start only when at least one candidate physical preparation map and detector forward operator can be written and hashed before external holdout access.
