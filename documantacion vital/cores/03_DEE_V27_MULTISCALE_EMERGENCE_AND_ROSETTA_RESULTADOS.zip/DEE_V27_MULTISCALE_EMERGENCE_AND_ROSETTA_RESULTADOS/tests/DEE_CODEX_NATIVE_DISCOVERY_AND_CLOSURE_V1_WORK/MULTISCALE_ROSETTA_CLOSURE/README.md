# DEE v27 multiscale emergence and Rosetta closure

Start with `EXECUTIVE_VERDICT.md`, then `DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA.md` and `FINAL_REPORT.md`.

The authoritative machine-readable state is `STATE.json`; claims are in `CLAIM_LEDGER.csv` and `CLAIM_LEDGER.json`; exact executions are indexed by `EXPERIMENT_INDEX.csv` and `WHL_INTERROGATION_LEDGER.csv`. MSH02's immutable chain is lock `e0cf5309...24f88` -> runner `85f6cccf...9d1f7` -> result `83b8cc52...9b52` -> audit `0747222f...67c7`.

Run `REPRODUCE.ps1` for non-destructive structural/hash validation. It does not rerun frozen holdouts by default.

For an actual Windows kernel import or scientific rerun, extract the final ZIP to a short absolute path such as `C:\DEE27`; the CPython 3.13 native DLL loader can fail on deeply nested paths even when every hash is correct. The archive preserves the runners' original relative `tests/work/ANALYSIS` layout and requires CPython 3.13 x64.
