# Adaptive research plan

The dependency pivot is cross-scale causal response. Discovery first builds exact matched v27 counterfactuals, records full-state and field-wise first divergence, and compares inventory, organization, causal-connectivity, and near-microscopic baselines. Candidate Q2 levels must improve prediction while reducing description and must support an explicit transition law.

Only a candidate surviving discovery and an adversarial null may be frozen. Every confirmation requires a prior JSON lock and SHA-256. External data remain closed until an internal dimensionless relation and its admissible preparation/readout map are frozen.

Branches are prioritized by information gain per kernel cost. A branch closes after refutation, operational indistinguishability, lack of an available discriminating test, failure of added complexity to improve holdout/compresion, or three cycles without information gain under the mission rules.
