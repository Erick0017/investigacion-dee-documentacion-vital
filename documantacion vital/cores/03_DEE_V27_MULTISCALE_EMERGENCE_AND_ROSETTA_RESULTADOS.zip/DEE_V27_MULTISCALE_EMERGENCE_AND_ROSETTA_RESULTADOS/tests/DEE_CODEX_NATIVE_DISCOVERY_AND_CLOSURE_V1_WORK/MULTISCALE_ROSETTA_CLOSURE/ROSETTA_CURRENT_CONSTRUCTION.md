# Rosetta — final current construction

## Internal quantitative chain

`Q0: X=(raw,clock)`
`-> Q1: M_*(X)=Z, predictive G_dagger, event J_dagger`
`-> phase-dependent P + routing complement R + destination geometry`
`-> Q2 readout q_N at t=N`
`-> dense raw-fixed by4N or sparse minimal exact raw-period-N by16N`.

Q0 is exact globally. Q1 closes only in certified `D_*`. Q2 is confirmed only in the frozen MSH02 natural-preparation, N33/N38, raw-projection and finite-horizon domain. The q_N compression is predictive, not an autonomous dynamics.

## Information loss

- `Q0 -> Q1` loses irrelevant microscopic labels only inside `D_*`; collision events must remain separately in `J_dagger`.
- `Q1/P/R -> q_N` discards arrangement, field identity and intervention response. Direction-support ties q_N predictively, and MSD06 proves q/state alone is causally insufficient.
- `q_N -> Q2 label` retains only one binary future witness; it cannot reconstruct trajectory or full state.

## Physical bridge status

No physical preparation map or detector forward operator is frozen. No SI scale is calibrated. E1/E2 are compatible-not-validating; E3 is forward-operator-inconclusive; E4/E5 lack qualifying data. Therefore the internal Rosetta is real and quantitative, while the external physical Rosetta is `NO_IDENTIFICABLE`.

## Exact missing arrow

`laboratory preparation -> DEE ensemble -> causal/coarse-grained history -> detector/readout distribution`.

The arrow must be specified independently, calibrated on separate data and tested on at least two new external families. Until then, labels such as matter, energy, mass, geometry, temperature and quantum outcome are conditional correspondences only.
