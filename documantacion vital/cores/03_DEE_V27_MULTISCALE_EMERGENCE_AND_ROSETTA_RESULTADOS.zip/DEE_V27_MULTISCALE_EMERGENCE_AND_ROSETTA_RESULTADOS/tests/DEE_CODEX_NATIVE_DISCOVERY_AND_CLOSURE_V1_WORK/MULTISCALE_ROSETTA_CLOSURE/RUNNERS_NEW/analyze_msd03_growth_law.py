#!/usr/bin/env python3
"""Derive the candidate temporal coarse-graining from MSD02+MSD03 discovery."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
D2 = ROOT / "RESULTS" / "MSD02_results.json"
D3 = ROOT / "RESULTS" / "MSD03_results.json"
OUT = ROOT / "ANALYSIS" / "MSD03_GROWTH_LAW_DISCOVERY.json"
EXPECTED = {
    "MSD02": "52769b58346f23cab9e1f19eda1c2197878ec77e8f827c275b9118ff9b1615df",
    "MSD03": "adb9e1482dd7d9b2218997bde4934b0d16c055b67be667e74716e8d2a3c393f2",
}
DELTA_DENSITY_RELEVANCE = 5e-4


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def scores(y, p):
    classes = sorted(set(y))
    recalls = []
    for klass in classes:
        idx = [i for i, value in enumerate(y) if value == klass]
        recalls.append(sum(int(p[i] == klass) for i in idx) / len(idx))
    return {
        "n": len(y),
        "accuracy": sum(int(a == b) for a, b in zip(y, p)) / len(y),
        "balanced_accuracy": sum(recalls) / len(recalls),
        "errors": sum(int(a != b) for a, b in zip(y, p)),
    }


def main() -> None:
    observed = {"MSD02": sha256_file(D2), "MSD03": sha256_file(D3)}
    if observed != EXPECTED:
        raise RuntimeError(f"input identity mismatch: {observed}")
    d2 = json.loads(D2.read_text(encoding="utf-8"))
    d3 = json.loads(D3.read_text(encoding="utf-8"))
    long_map = {row["row_id"]: row for row in d3["rows"]}
    rows = []
    for source in d2["rows"]:
        n = int(source["N"])
        half = int(math.ceil(n / 2))
        at_half = source["trace"][half]
        at_n = source["trace"][n]
        delta_count = int(at_n["direction_nonzero"] - at_half["direction_nonzero"])
        delta_density = float(delta_count / n**3)
        if int(source["dense_label_ge_0_5"]) == 1:
            observed_class = "DENSE_BY_ORIGINAL_HORIZON"
            label = 1
            t50 = next((int(x["tick"]) for x in source["trace"] if float(x["occupancy_fraction"]) >= 0.5), None)
        else:
            long = long_map[source["row_id"]]
            if long["classification"] == "DENSE_PERSISTENT_TO_512":
                observed_class = "DELAYED_DENSE_PERSISTENT_TO_512"
                label = 1
                t50 = int(long["first_passage"]["0.5"])
            elif long["classification"] == "SPARSE_RAW_PERIODIC_TO_512":
                observed_class = "SPARSE_RAW_PERIOD_N_TO_512"
                label = 0
                t50 = None
            else:
                raise RuntimeError(f"unadjudicated low row: {long}")
        if delta_density >= DELTA_DENSITY_RELEVANCE:
            prediction = 1
            prediction_class = "GROWING"
        elif delta_density <= 0:
            prediction = 0
            prediction_class = "NON_GROWING"
        else:
            prediction = None
            prediction_class = "ABSTAIN_MARGIN"
        rows.append({
            "row_id": source["row_id"],
            "group_id": source["group_id"],
            "N": n,
            "seed": int(source["seed"]),
            "variant": source["variant"],
            "measurement_ticks": [half, n],
            "routing_count_half": int(at_half["direction_nonzero"]),
            "routing_count_N": int(at_n["direction_nonzero"]),
            "delta_routing_count": delta_count,
            "delta_routing_density": delta_density,
            "observed_class": observed_class,
            "observed_label_dense": label,
            "first_passage_occupancy_0_5": t50,
            "candidate_prediction": prediction,
            "candidate_prediction_class": prediction_class,
        })
    decisive = [row for row in rows if row["candidate_prediction"] is not None]
    y = [row["observed_label_dense"] for row in decisive]
    p = [row["candidate_prediction"] for row in decisive]
    sparse_deltas = [row["delta_routing_density"] for row in rows if row["observed_label_dense"] == 0]
    dense_deltas = [row["delta_routing_density"] for row in rows if row["observed_label_dense"] == 1]
    compression = []
    for n in sorted({row["N"] for row in rows}):
        micro_bits = 128 * n**3
        descriptor_bits = 2 * math.ceil(math.log2(n**3 + 1))
        compression.append({
            "N": n,
            "microstate_bits_raw_plus_clock": micro_bits,
            "two_count_descriptor_bits": descriptor_bits,
            "fraction_bits_retained": descriptor_bits / micro_bits,
            "compression_gain_fraction": 1 - descriptor_bits / micro_bits,
        })
    majority = int(sum(row["observed_label_dense"] for row in rows) * 2 >= len(rows))
    result = {
        "schema": "dee.v27.msd03.growth_law_discovery.v1",
        "role": "DISCOVERY_MODEL_SELECTION_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE",
        "input_hashes": observed,
        "candidate": {
            "name": "temporal_active_routing_growth",
            "A_t": "count(direction != 0 at tick t) / N^3",
            "Delta_A_N": "A(N) - A(ceil(N/2))",
            "decision": f"dense if Delta_A_N >= {DELTA_DENSITY_RELEVANCE}; sparse-periodic if Delta_A_N <= 0; otherwise abstain",
            "outcome": "dense first-passage occupancy>=0.5 versus raw-period-N sparse persistence through t=512",
        },
        "discovery_performance": {
            **scores(y, p),
            "coverage": len(decisive) / len(rows),
            "decisive_n": len(decisive),
            "abstentions": len(rows) - len(decisive),
            "class_counts": {"sparse": sum(1 for row in rows if row["observed_label_dense"] == 0), "dense": sum(1 for row in rows if row["observed_label_dense"] == 1)},
            "majority_accuracy": sum(int(row["observed_label_dense"] == majority) for row in rows) / len(rows),
            "majority_balanced_accuracy": 0.5,
            "max_sparse_delta_density": max(sparse_deltas),
            "min_dense_delta_density": min(dense_deltas),
            "separation_margin": min(dense_deltas) - max(sparse_deltas),
        },
        "compression": compression,
        "interpretation": "This two-time response coordinate is a temporal coarse-graining over Q1 routing records. Perfect discovery separation does not count as confirmation because the field, times, margin and outcome were selected after MSD01-MSD03.",
        "rows": rows,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "candidate": result["candidate"],
        "performance": result["discovery_performance"],
        "compression": result["compression"],
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
