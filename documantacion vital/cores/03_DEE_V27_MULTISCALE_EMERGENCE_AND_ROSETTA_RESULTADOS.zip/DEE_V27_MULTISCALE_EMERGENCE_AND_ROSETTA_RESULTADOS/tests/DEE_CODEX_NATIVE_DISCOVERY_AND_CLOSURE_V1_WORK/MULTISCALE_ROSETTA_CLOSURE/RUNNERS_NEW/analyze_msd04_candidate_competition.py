#!/usr/bin/env python3
"""Discovery-only competition between the MSD03 candidate and simpler nulls."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
MSD02 = ROOT / "RESULTS" / "MSD02_results.json"
GROWTH = ROOT / "ANALYSIS" / "MSD03_GROWTH_LAW_DISCOVERY.json"
OUT = ROOT / "ANALYSIS" / "MSD04_CANDIDATE_COMPETITION.json"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def balanced_accuracy(y: list[int], prediction: list[int]) -> float:
    recalls = []
    for label in (0, 1):
        indices = [index for index, item in enumerate(y) if item == label]
        recalls.append(sum(prediction[index] == label for index in indices) / len(indices))
    return float(sum(recalls) / 2)


def best_stump(y: list[int], values: list[float]) -> dict:
    unique = sorted(set(values))
    thresholds = [unique[0] - 1e-15, *[(a + b) / 2 for a, b in zip(unique, unique[1:])], unique[-1] + 1e-15]
    candidates = []
    for sign in (1, -1):
        for threshold in thresholds:
            prediction = [int(value >= threshold) if sign == 1 else int(value <= threshold) for value in values]
            candidates.append((balanced_accuracy(y, prediction), sum(a != b for a, b in zip(y, prediction)), sign, threshold, prediction))
    score, errors, sign, threshold, prediction = sorted(candidates, key=lambda item: (-item[0], item[1], -item[2], item[3]))[0]
    return {
        "balanced_accuracy": score,
        "errors": errors,
        "direction": ">=" if sign == 1 else "<=",
        "threshold": threshold,
        "prediction": prediction,
    }


def main() -> int:
    msd02 = json.loads(MSD02.read_text(encoding="utf-8"))
    growth = json.loads(GROWTH.read_text(encoding="utf-8"))
    labels = {row["row_id"]: int(row["observed_label_dense"]) for row in growth["rows"]}
    rows = []
    for source in msd02["rows"]:
        trace = {int(item["tick"]): item for item in source["trace"]}
        n = int(source["N"])
        half = math.ceil(n / 2)
        at_half = trace[half]
        at_n = trace[n]
        rows.append({
            "row_id": source["row_id"],
            "group_id": source["group_id"],
            "N": n,
            "observed_dense": labels[source["row_id"]],
            "occupancy_fraction_half": float(at_half["occupancy_fraction"]),
            "occupancy_fraction_N": float(at_n["occupancy_fraction"]),
            "direction_fraction_half": float(at_half["direction_nonzero"] / n**3),
            "direction_fraction_N": float(at_n["direction_nonzero"] / n**3),
        })
    for row in rows:
        row["delta_occupancy_fraction"] = row["occupancy_fraction_N"] - row["occupancy_fraction_half"]
        row["delta_direction_fraction"] = row["direction_fraction_N"] - row["direction_fraction_half"]

    y = [row["observed_dense"] for row in rows]
    fields = [
        "occupancy_fraction_N",
        "direction_fraction_N",
        "occupancy_fraction_half",
        "direction_fraction_half",
        "delta_occupancy_fraction",
        "delta_direction_fraction",
    ]
    models = {field: best_stump(y, [row[field] for row in rows]) for field in fields}
    delta_dir_frozen = [1 if row["delta_direction_fraction"] >= 0.0005 else 0 if row["delta_direction_fraction"] <= 0 else -1 for row in rows]
    delta_occ_frozen = [1 if row["delta_occupancy_fraction"] >= 0.0005 else 0 if row["delta_occupancy_fraction"] <= 0 else -1 for row in rows]
    sparse = [row for row in rows if row["observed_dense"] == 0]
    dense = [row for row in rows if row["observed_dense"] == 1]
    descriptor_bits_by_n = {
        str(n): {
            "one_count_bits": math.ceil(math.log2(n**3 + 1)),
            "two_count_bits": 2 * math.ceil(math.log2(n**3 + 1)),
            "raw_plus_clock_bits": 128 * n**3,
        }
        for n in sorted({row["N"] for row in rows})
    }
    output = {
        "schema": "dee.v27.multiscale.msd04.candidate_competition.discovery.v1",
        "role": "DISCOVERY_ADVERSARIAL_MODEL_SELECTION_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE",
        "input_hashes": {"MSD02": sha256_file(MSD02), "growth_analysis": sha256_file(GROWTH)},
        "runner_sha256": sha256_file(HERE),
        "n": len(rows),
        "class_counts": {"dense": sum(y), "sparse": len(y) - sum(y)},
        "best_stumps": {field: {key: value for key, value in model.items() if key != "prediction"} for field, model in models.items()},
        "key_ranges": {
            "max_sparse_occupancy_fraction_N": max(row["occupancy_fraction_N"] for row in sparse),
            "min_dense_occupancy_fraction_N": min(row["occupancy_fraction_N"] for row in dense),
            "max_sparse_delta_direction_fraction": max(row["delta_direction_fraction"] for row in sparse),
            "min_dense_delta_direction_fraction": min(row["delta_direction_fraction"] for row in dense),
        },
        "comparisons": {
            "delta_direction_vs_delta_occupancy_prediction_identical_at_0_0005": delta_dir_frozen == delta_occ_frozen,
            "delta_direction_vs_occupancy_N_best_prediction_identical": delta_dir_frozen == models["occupancy_fraction_N"]["prediction"],
            "pearson_delta_direction_delta_occupancy": float(np.corrcoef(
                [row["delta_direction_fraction"] for row in rows],
                [row["delta_occupancy_fraction"] for row in rows],
            )[0, 1]),
            "one_count_strictly_simpler_than_two_counts": True,
        },
        "descriptor_bits_by_N": descriptor_bits_by_n,
        "adjudication": {
            "delta_direction_specificity": "NOT_SUPPORTED",
            "minimal_discovery_candidate": "occupancy_fraction_N",
            "minimal_candidate_name": "scale_normalized_active_support_at_one_crossing_time",
            "interpretation_limit": "This is a temporal collective state variable, not evidence that occupancy is matter or that direction is a unique carrier.",
            "holdout_requirement": "Freeze one-count law and report the two-count/direction models only as locked competitors; require class diversity across independent seed groups.",
        },
        "rows": rows,
    }
    atomic_json(OUT, output)
    print(json.dumps({
        "status": "COMPLETE",
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
        "runner_sha256": output["runner_sha256"],
        "adjudication": output["adjudication"],
        "key_ranges": output["key_ranges"],
        "comparisons": output["comparisons"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
