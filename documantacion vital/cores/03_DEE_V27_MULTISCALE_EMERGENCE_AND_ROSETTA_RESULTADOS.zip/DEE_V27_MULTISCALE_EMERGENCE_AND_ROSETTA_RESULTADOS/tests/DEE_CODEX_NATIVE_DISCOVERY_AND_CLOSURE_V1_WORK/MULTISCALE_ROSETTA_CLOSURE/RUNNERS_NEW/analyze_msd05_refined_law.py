#!/usr/bin/env python3
"""Post-hoc analysis of the asymmetric dense/sparse witness revealed by MSD05."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
MSH01 = ROOT / "HOLDOUTS" / "MSH01_results.json"
MSD05 = ROOT / "RESULTS" / "MSD05_results.json"
OUT = ROOT / "ANALYSIS" / "MSD05_REFINED_LAW_DISCOVERY.json"
EXPECTED = {
    "MSH01": "c87eff9a9ab54531d82922141e9d9976876953ae4c894d72f0758a12fa81c67f",
    "MSD05": "11178ba62e0ada18274688a3a75db8ca181d196f6798ee2ef036b3cb5cd50eba",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def balanced_accuracy(rows: list[dict], field: str) -> float:
    recalls = []
    for label in ("DENSE_BY_4N", "SPARSE_PERIOD_N_BY_16N"):
        subset = [row for row in rows if row["refined_outcome"] == label]
        recalls.append(sum(row[field] == label for row in subset) / len(subset))
    return sum(recalls) / 2


def main() -> int:
    observed_hashes = {"MSH01": sha256(MSH01), "MSD05": sha256(MSD05)}
    if observed_hashes != EXPECTED:
        raise RuntimeError(f"input identity mismatch: {observed_hashes}")
    msh = json.loads(MSH01.read_text(encoding="utf-8"))
    extension = json.loads(MSD05.read_text(encoding="utf-8"))
    extended = {row["row_id"]: row for row in extension["rows"]}
    rows = []
    threshold = float(msh["contract"]["model"]["positive_state_fraction_threshold"])
    for source in msh["rows"]:
        if source["observed"] == "DENSE_RAW_FIXED_WINDOW":
            outcome = "DENSE_BY_4N"
            extension_status = "NOT_EXTENDED_DENSE_WITNESS_AT_4N"
        else:
            follow = extended[source["row_id"]]
            if follow["classification_16N"] != "RAW_PERIODIC_BY_16N" or follow["tail_periods_max_4N_three_repeats"]["raw"] != int(source["N"]):
                raise RuntimeError(f"non-dense row did not resolve to period N: {source['row_id']}")
            outcome = "SPARSE_PERIOD_N_BY_16N"
            extension_status = "EXTENDED_AND_VERIFIED"
        primary = "DENSE_BY_4N" if source["positive_state_fraction_N"] >= threshold else "SPARSE_PERIOD_N_BY_16N"
        size_only = "DENSE_BY_4N" if int(source["N"]) >= 38 else "SPARSE_PERIOD_N_BY_16N"
        rows.append({
            "row_id": source["row_id"],
            "group_id": source["group_id"],
            "N": int(source["N"]),
            "variant": source["variant"],
            "q_N": source["positive_state_fraction_N"],
            "measurement_pre_crossing": source["first_passage_0_5"] is None or source["first_passage_0_5"] > int(source["N"]),
            "refined_outcome": outcome,
            "primary_prediction": primary,
            "size_only_prediction": size_only,
            "primary_correct": primary == outcome,
            "size_only_correct": size_only == outcome,
            "extension_status": extension_status,
        })
    groups = sorted({row["group_id"] for row in rows})
    class_groups = {
        label: len({row["group_id"] for row in rows if row["refined_outcome"] == label})
        for label in ("DENSE_BY_4N", "SPARSE_PERIOD_N_BY_16N")
    }
    mixed_groups = [
        group for group in groups
        if len({row["refined_outcome"] for row in rows if row["group_id"] == group}) == 2
    ]
    primary_ba = balanced_accuracy(rows, "primary_prediction")
    size_ba = balanced_accuracy(rows, "size_only_prediction")
    pre = [row for row in rows if row["measurement_pre_crossing"]]
    output = {
        "schema": "dee.v27.multiscale.msd05.refined_law.discovery.v1",
        "role": "POST_HOC_DISCOVERY_ONLY_AFTER_MSH01",
        "confirmatory_status": "NOT_ELIGIBLE",
        "input_hashes": observed_hashes,
        "runner_sha256": sha256(HERE),
        "candidate": {
            "observable": "q_N=count(state>0 at t=N)/N^3",
            "threshold": threshold,
            "dense_outcome": "dense raw-fixed witness by 4N",
            "sparse_outcome": "remain below .01 and establish exact raw period N by 16N",
            "asymmetry_reason": "MSH01 showed dense stabilization earlier than some sparse recurrence witnesses.",
        },
        "performance": {
            "total": len(rows),
            "errors": sum(not row["primary_correct"] for row in rows),
            "balanced_accuracy": primary_ba,
            "size_only_balanced_accuracy": size_ba,
            "balanced_accuracy_advantage": primary_ba - size_ba,
            "class_row_counts": {label: sum(row["refined_outcome"] == label for row in rows) for label in ("DENSE_BY_4N", "SPARSE_PERIOD_N_BY_16N")},
            "class_independent_group_counts": class_groups,
            "mixed_seed_groups": mixed_groups,
            "pre_crossing_rows": len(pre),
            "pre_crossing_errors": sum(not row["primary_correct"] for row in pre),
            "pre_crossing_class_groups": {label: len({row["group_id"] for row in pre if row["refined_outcome"] == label}) for label in ("DENSE_BY_4N", "SPARSE_PERIOD_N_BY_16N")},
        },
        "counterfactual_warning": "These metrics would satisfy the earlier numerical criteria only after changing the endpoint using opened outcomes. They are not a repaired MSH01 PASS and require MSH02.",
        "rows": rows,
    }
    atomic_json(OUT, output)
    print(json.dumps({
        "status": "COMPLETE",
        "output": str(OUT),
        "output_sha256": sha256(OUT),
        "runner_sha256": output["runner_sha256"],
        "performance": output["performance"],
        "confirmatory_status": output["confirmatory_status"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
