#!/usr/bin/env python3
"""Hash-pinned post-hoc adjudication of MSD06 causal discovery."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
SOURCE = ROOT / "RESULTS" / "MSD06_results.json"
SOURCE_RUNNER = HERE.with_name("run_msd06_causal_carrier_discovery.py")
OUT = ROOT / "ANALYSIS" / "MSD06_CAUSAL_CARRIER_ANALYSIS.json"
EXPECTED = {
    "source": "30a2136fe1ee9ff3ab8a55d2990616b0e4be581510709f41cc73313f3dd77d10",
    "source_runner": "9bb9df294c6a0d77259478d1528e200b70a1f01c4644d798d74a85466951a1bc",
}
QSTAR = 0.003417106052812071


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def post0_sum(arm: dict, field: str) -> int:
    return sum(int(row[field]) for row in arm["trace"][1:])


def input_checks(arms: dict) -> dict:
    full = arms["full"]["trace"][0]
    d0 = arms["direction0"]["trace"][0]
    s0d = arms["state0_keep_direction"]["trace"][0]
    null = arms["state0_direction0_keep_metadata"]["trace"][0]
    result = {
        "direction0_preserves_positive_count": d0["positive_state"] == full["positive_state"],
        "direction0_zeroes_all_direction": d0["direction_nonzero"] == 0,
        "state0_keep_direction_zeroes_positive_count": s0d["positive_state"] == 0,
        "state0_keep_direction_preserves_direction_count": s0d["direction_nonzero"] == full["direction_nonzero"],
        "factorial_null_zeroes_positive_and_direction": null["positive_state"] == 0 and null["direction_nonzero"] == 0,
    }
    if "direction_permutation" in arms:
        perm = arms["direction_permutation"]["trace"][0]
        result.update({
            "permutation_preserves_positive_count": perm["positive_state"] == full["positive_state"],
            "permutation_preserves_direction_count": perm["direction_nonzero"] == full["direction_nonzero"],
            "permutation_preserves_state_hash": perm["state_sha256"] == full["state_sha256"],
        })
    result["pass"] = all(result.values())
    return result


def long_row(group: dict) -> dict:
    n = int(group["N"])
    outer = group["outer_stage_0_to_N"]
    stage = group["snapshot_stage_N_to_8N"]
    panel = stage["panel"]
    arms = panel["arms"]
    outcomes = panel["outcomes"]
    full_class = outcomes["full"]["observed_8N"]
    direction0_class = outcomes["direction0"]["observed_8N"]
    state0_class = outcomes["state0_keep_direction"]["observed_8N"]
    perm_class = outcomes["direction_permutation"]["observed_8N"]
    full_final = arms["full"]["trace"][-1]
    d0_final = arms["direction0"]["trace"][-1]
    s0d_final = arms["state0_keep_direction"]["trace"][-1]
    null_final = arms["state0_direction0_keep_metadata"]["trace"][-1]
    perm_final = arms["direction_permutation"]["trace"][-1]
    return {
        "group_id": group["group_id"],
        "N": n,
        "opened_selection_role_at_4N": group["selection_role"],
        "source_at_N": {
            "q": arms["full"]["trace"][0]["positive_state_fraction"],
            "direction_fraction": arms["full"]["trace"][0]["direction_fraction"],
            "direction_live": arms["full"]["trace"][0]["direction_live"],
            "direction_ghost": arms["full"]["trace"][0]["direction_ghost"],
        },
        "input_factorial_checks": input_checks(arms),
        "outer_one_tick": outer["one_tick_prediction_audit"],
        "global_demux_one_tick": stage["exact_demux_one_tick"],
        "classes_8N": {
            "full": full_class,
            "direction0": direction0_class,
            "state0_keep_direction": state0_class,
            "factorial_null": outcomes["state0_direction0_keep_metadata"]["observed_8N"],
            "direction_permutation": perm_class,
        },
        "class_contrasts": {
            "direction_deletion_changes_class": direction0_class != full_class,
            "state_deletion_changes_class": state0_class != full_class,
            "direction_permutation_changes_class": perm_class != full_class,
        },
        "final_positive_fractions": {
            "full": full_final["positive_state_fraction"],
            "direction0": d0_final["positive_state_fraction"],
            "state0_keep_direction": s0d_final["positive_state_fraction"],
            "factorial_null": null_final["positive_state_fraction"],
            "direction_permutation": perm_final["positive_state_fraction"],
        },
        "post_intervention_exposure_sums_excluding_step0": {
            name: {
                "positive_state": post0_sum(arm, "positive_state"),
                "direction_all": post0_sum(arm, "direction_nonzero"),
                "direction_live": post0_sum(arm, "direction_live"),
                "direction_ghost": post0_sum(arm, "direction_ghost"),
            }
            for name, arm in arms.items()
        },
        "exact_trace_relations": {
            "full_vs_state0_keep_direction": panel["pairwise_dynamics"]["state_when_direction_present"],
            "full_vs_direction0": panel["pairwise_dynamics"]["direction_when_state_present"],
            "full_vs_direction_permutation": panel["pairwise_dynamics"]["full_vs_direction_permutation"],
        },
        "permutation": {
            **stage["direction_permutation"],
            "raw_equal_to_full_at_8N": panel["pairwise_dynamics"]["full_vs_direction_permutation"]["raw_equal_at_final_tick"],
        },
    }


def precursor_row(context: dict) -> dict:
    panel = context["panel_N_to_2N"]
    arms = panel["arms"]
    return {
        "context_id": context["context_id"],
        "source_q_N": context["source_q_N"],
        "source_direction_fraction_N": context["source_direction_fraction_N"],
        "frozen_qstar_prediction": "DENSE" if context["source_q_N"] >= QSTAR else "NON_DENSE",
        "input_factorial_checks": input_checks(arms),
        "global_demux_one_tick": context["exact_demux_one_tick"],
        "positive_fraction_at_2N": {name: arm["trace"][-1]["positive_state_fraction"] for name, arm in arms.items()},
        "first_0_5_global_tick": {name: arm["first_0_5_tick"] for name, arm in arms.items()},
        "post_intervention_positive_exposure_excluding_step0": {name: post0_sum(arm, "positive_state") for name, arm in arms.items()},
        "exact_trace_relations": panel["pairwise_dynamics"],
        "replay_N_and_2N_pass": context["exact_overlap_at_N"]["pass"] and context["exact_FULL_overlap_at_2N"]["pass"],
    }


def main() -> int:
    hashes = {"source": sha256(SOURCE), "source_runner": sha256(SOURCE_RUNNER)}
    if hashes != EXPECTED:
        raise RuntimeError(f"input hash mismatch: {hashes}")
    if OUT.exists():
        raise RuntimeError(f"refusing overwrite: {OUT}")
    source = json.loads(SOURCE.read_text(encoding="utf-8"))
    long_rows = [long_row(group) for group in source["long_groups"]]
    precursor_rows = [precursor_row(context) for context in source["precursor_contexts"]]
    direction_changed = sum(row["class_contrasts"]["direction_deletion_changes_class"] for row in long_rows)
    state_changed = sum(row["class_contrasts"]["state_deletion_changes_class"] for row in long_rows)
    perm_changed = sum(row["class_contrasts"]["direction_permutation_changes_class"] for row in long_rows)
    sparse_exact_coalescence = [
        row["exact_trace_relations"]["full_vs_state0_keep_direction"]["eventual_exact_coalescence_global_tick"]
        for row in long_rows if row["classes_8N"]["full"] == "SPARSE_RAW_PERIOD_N_BY_8N"
    ]
    result = {
        "schema": "dee.v27.multiscale.msd06.causal_carrier.analysis.v1",
        "role": "POST_HOC_ANALYSIS_OF_OPENED_DISCOVERY",
        "confirmatory_status": "NOT_ELIGIBLE",
        "input_hashes": hashes,
        "analysis_runner_sha256": sha256(HERE),
        "integrity": {
            "source_static_audit_pass": source["static_audit"]["status"] == "PASS",
            "all_replays_pass": source["summary"]["all_long_baseline_N_and_4N_replays_pass"] and source["summary"]["precursor_replays_pass"],
            "all_input_factorial_checks_pass": all(row["input_factorial_checks"]["pass"] for row in long_rows + precursor_rows),
            "all_exact_global_demux_checks_pass": all(row["global_demux_one_tick"]["routed_positive_exactly_expected_destinations"] and row["global_demux_one_tick"]["null_positive_empty"] for row in long_rows + precursor_rows),
            "all_clocks_equal_in_matched_panels": all(group["outer_stage_0_to_N"]["panel"]["all_arm_clocks_equal_every_tick"] and group["snapshot_stage_N_to_8N"]["panel"]["all_arm_clocks_equal_every_tick"] for group in source["long_groups"]) and all(context["panel_N_to_2N"]["all_arm_clocks_equal_every_tick"] for context in source["precursor_contexts"]),
        },
        "aggregate": {
            "long_groups": len(long_rows),
            "direction_deletion_changes_8N_witness_groups": direction_changed,
            "state_deletion_changes_8N_witness_groups": state_changed,
            "direction_permutation_changes_8N_witness_groups": perm_changed,
            "direction_permutation_changes_raw_trajectory_through_8N_groups": sum(not row["permutation"]["raw_equal_to_full_at_8N"] for row in long_rows),
            "state0_keep_direction_recovers_same_8N_witness_groups": len(long_rows) - state_changed,
            "sparse_full_vs_state0_keep_direction_exact_coalescence_ticks": sparse_exact_coalescence,
            "outer_R0_arms_exactly_coalesce_at_t1_groups": source["summary"]["outer_direction0_null_ablation_exactly_coalesce_by_t1_groups"],
        },
        "long_rows": long_rows,
        "precursor_rows": precursor_rows,
        "adjudication": {
            "computational_facts": [
                "For all eight snapshot contexts, global state deletion with direction retained regenerated the exact one-step positive mask equal to the union of routed destinations; the matched state-and-direction null stayed positive-empty.",
                "Across the six long contexts, deleting state at N while retaining direction preserved the same finite 8N witness class in 6/6; the four sparse paths exactly re-coalesced with FULL after one tick.",
                "Deleting direction at N while preserving the complete state field changed the 8N witness class in 5/6 long contexts; the surviving exception was an already mature dense N35 world.",
                "The direction-word permutation preserved state/q sitewise, direction support sitewise, metadata, clocks and vector histogram, changed 66.3%-86.4% of routed direction words, and changed the raw trajectory through 8N in 6/6 while preserving the coarse witness class in 6/6.",
                "In the pre-crossing baseline context q_N=0.006120071861>q*, FULL crossed 0.5 at t=61 and reached q_2N=0.9927348824; direction deletion preserved q_N at intervention but did not cross and ended q_2N=0.0001381952.",
                "In that same precursor, deleting state while retaining direction regenerated state at one tick but reached only q_2N=0.1077132648, showing a finite-time interaction rather than pure one-field sufficiency.",
            ],
            "native_empirical_law": "Within these opened preparations, direction-bearing raw records are a regenerative transport skeleton: they can instantiate positive state from a globally state-zero snapshot, while the state field supplies context-dependent collective persistence/amplification. q_N is a strong natural-manifold order parameter but not the sole causal carrier.",
            "negative_results": [
                "Refuted in this panel: q_N or the complete state field at N is by itself sufficient to determine the later witness under field interventions.",
                "Refuted in this panel: positive state at N is necessary for one-step regeneration or for preserving the 8N witness when the direction field is retained.",
                "Not supported: direction-vector arrangement uniquely determines the coarse dense/sparse witness; one strong histogram-preserving permutation changed every raw trajectory but no witness class.",
            ],
            "limits": [
                "All contexts and interventions are post-holdout discovery; none is CONFIRMED_PROGRESS.",
                "Whole-torus bit deletion is an off-manifold mathematical intervention; operational physical preparability is unproved.",
                "Direction is a routing field in this kernel, not thereby momentum, matter, velocity or a conserved current.",
                "Same witness under permutation is robustness to one deterministic perturbation, not a global invariance theorem.",
                "Witnesses are finite-window raw projection statements; OTHER_BY_8N is not a stable class.",
            ],
            "next_decision": "Retain q_N as the minimal natural-preparation order parameter, explicitly demote it from causal carrier, and freeze MSH02 only for prediction of the asymmetric natural-manifold witness. Treat the paired state/routing architecture as the mechanistic candidate requiring separate future confirmation.",
        },
    }
    if not all(result["integrity"].values()):
        raise RuntimeError(f"integrity failure: {result['integrity']}")
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "aggregate": result["aggregate"],
        "integrity": result["integrity"],
        "output": str(OUT),
        "output_sha256": sha256(OUT),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
