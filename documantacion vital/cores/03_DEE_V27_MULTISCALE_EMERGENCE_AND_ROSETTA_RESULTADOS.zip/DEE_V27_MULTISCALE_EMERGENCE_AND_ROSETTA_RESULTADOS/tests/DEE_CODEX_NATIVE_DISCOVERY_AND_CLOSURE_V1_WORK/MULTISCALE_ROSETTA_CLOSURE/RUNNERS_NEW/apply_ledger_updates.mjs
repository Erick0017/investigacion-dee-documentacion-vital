#!/usr/bin/env node
/** Idempotently upsert ledger rows through artifact_tool and validate CSV roundtrips. */
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Workbook } from "@oai/artifact-tool";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);
const updatePath = process.argv[2] ? path.resolve(process.argv[2]) : null;
if (!updatePath) throw new Error("usage: apply_ledger_updates.mjs UPDATE.json");
const payload = JSON.parse(await fs.readFile(updatePath, "utf8"));

function quoteCsv(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}
function sha256(text) { return crypto.createHash("sha256").update(text, "utf8").digest("hex"); }
function key(row, fields) { return fields.map((field) => String(row[field] ?? "")).join("\u001f"); }

const report = { operation_id: payload.operation_id, library: "@oai/artifact-tool", status: "PASS", outputs: {} };
for (const [name, update] of Object.entries(payload.updates)) {
  const file = path.join(root, name);
  const original = await fs.readFile(file, "utf8");
  const imported = await Workbook.fromCSV(original, { sheetName: "Ledger" });
  const values = imported.worksheets.getItem("Ledger").getUsedRange(true)?.values;
  if (!values?.length) throw new Error(`${name}: empty ledger`);
  const headers = values[0].map(String);
  const records = values.slice(1).map((row) => Object.fromEntries(headers.map((field, i) => [field, String(row[i] ?? "")])));
  const positions = new Map(records.map((row, i) => [key(row, update.key_fields), i]));
  let inserted = 0;
  let replaced = 0;
  for (const candidate of update.rows) {
    const missing = headers.filter((field) => !Object.hasOwn(candidate, field));
    const extra = Object.keys(candidate).filter((field) => !headers.includes(field));
    if (missing.length || extra.length) throw new Error(`${name}: schema mismatch missing=${missing} extra=${extra}`);
    const normalized = Object.fromEntries(headers.map((field) => [field, String(candidate[field] ?? "")]));
    const k = key(normalized, update.key_fields);
    if (positions.has(k)) {
      records[positions.get(k)] = normalized;
      replaced += 1;
    } else {
      positions.set(k, records.length);
      records.push(normalized);
      inserted += 1;
    }
  }
  const matrix = [headers, ...records.map((row) => headers.map((field) => row[field]))];
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add("Validated");
  sheet.getRangeByIndexes(0, 0, matrix.length, headers.length).values = matrix;
  if (JSON.stringify(sheet.getUsedRange(true)?.values) !== JSON.stringify(matrix)) throw new Error(`${name}: memory roundtrip mismatch`);
  const csv = `${matrix.map((row) => row.map(quoteCsv).join(",")).join("\r\n")}\r\n`;
  const check = await Workbook.fromCSV(csv, { sheetName: "Check" });
  if (JSON.stringify(check.worksheets.getItem("Check").getUsedRange(true)?.values) !== JSON.stringify(matrix)) throw new Error(`${name}: CSV reimport mismatch`);
  await fs.writeFile(file, csv, "utf8");
  report.outputs[name] = { inserted, replaced, data_rows: records.length, columns: headers.length, sha256: sha256(csv), artifact_tool_memory_roundtrip: true, artifact_tool_csv_reimport: true };
}
const reportPath = path.join(root, "RESULTS", `ledger_update_${payload.operation_id}.json`);
await fs.writeFile(reportPath, `${JSON.stringify(report, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
