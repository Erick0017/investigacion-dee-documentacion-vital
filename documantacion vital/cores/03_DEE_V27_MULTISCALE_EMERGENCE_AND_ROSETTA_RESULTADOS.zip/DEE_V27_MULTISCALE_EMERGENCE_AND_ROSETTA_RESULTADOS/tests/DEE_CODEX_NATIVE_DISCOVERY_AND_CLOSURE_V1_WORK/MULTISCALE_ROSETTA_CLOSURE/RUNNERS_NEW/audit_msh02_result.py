from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RESULT = ROOT / "HOLDOUTS" / "MSH02_results.json"
LOCK = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json"
OUTPUT = ROOT / "ANALYSIS" / "MSH02_RESULT_AUDIT.json"

DENSE = "DENSE_RAW_FIXED_WINDOW"
SPARSE = "SPARSE_RAW_PERIOD_N_WINDOW"
OTHER = "OTHER"
VARIANTS = ("baseline", "outer_semantic4", "same_inventory_joint_shuffle")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_sha(value: object) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def metric(rows: list[dict], prediction_key: str) -> dict:
    errors = [r["row_id"] for r in rows if r[prediction_key] != r["observed"]]
    dense_rows = [r for r in rows if r["observed"] == DENSE]
    sparse_rows = [r for r in rows if r["observed"] == SPARSE]
    tpr = Fraction(sum(r[prediction_key] == DENSE for r in dense_rows), len(dense_rows))
    tnr = Fraction(sum(r[prediction_key] == SPARSE for r in sparse_rows), len(sparse_rows))
    ba = (tpr + tnr) / 2
    return {
        "total": len(rows),
        "errors": len(errors),
        "error_rows": errors,
        "accuracy_exact": f"{len(rows) - len(errors)}/{len(rows)}",
        "balanced_accuracy_exact": f"{ba.numerator}/{ba.denominator}",
        "balanced_accuracy": float(ba),
    }


result = json.loads(RESULT.read_text(encoding="utf-8"))
lock = json.loads(LOCK.read_text(encoding="utf-8"))
contract = lock["contract"]
rows = result["rows"]
recorded = result["primary_adjudication"]
checks: dict[str, bool] = {}
details: dict[str, object] = {}

checks["result_schema"] = result["schema"] == "dee.v27.multiscale.msh02.holdout.v1"
checks["experiment_and_role"] = result["experiment_id"] == "MSH02" and result["role"] == "CONFIRMATORY_HOLDOUT"
checks["lock_file_hash"] = sha256(LOCK) == result["lock_file_sha256"] == "e0cf530948057df93c852b3513fb83c751bd7a2c22e30bab2c304b6288c24f88"
checks["contract_payload_hash"] = canonical_sha(contract) == lock["contract_payload_sha256"] == result["contract_payload_sha256"]
checks["contract_copy_exact"] = result["contract"] == contract
checks["runner_hash"] = sha256(ROOT / contract["runner"]) == contract["runner_sha256"] == result["runner_sha256"]
checks["foundation_hash"] = sha256(ROOT / contract["foundation_runner"]) == contract["foundation_runner_sha256"] == result["foundation_runner_sha256"]
checks["core_hash"] = sha256(ROOT / contract["core_runner"]) == contract["core_runner_sha256"] == result["core_runner_sha256"]
checks["kernel_identities"] = result["environment"]["observed_hashes"] == contract["kernel_identity"]
checks["runtime_and_threads"] = result["environment"]["threads"] == 1 and result["environment"]["python"].startswith("3.13.")

expected_rows = {
    (case["N"], seed, variant)
    for case in contract["case_specs"]
    for seed in case["seeds"]
    for variant in VARIANTS
}
observed_rows = {(r["N"], r["seed"], r["variant"]) for r in rows}
checks["protocol_exact_60_unique_rows"] = len(rows) == len(observed_rows) == len(expected_rows) == 60 and observed_rows == expected_rows
checks["row_ids_unique"] = len({r["row_id"] for r in rows}) == 60

derived_seeds = {}
for case in contract["case_specs"]:
    N = case["N"]
    seeds = []
    for i in range(10):
        phrase = f"DEE-v27|MSH02|v1|N={N}|group={i}".encode("ascii")
        seeds.append(int.from_bytes(hashlib.sha256(phrase).digest()[:4], "little"))
    derived_seeds[str(N)] = seeds
checks["mechanical_seed_derivation"] = all(derived_seeds[str(c["N"])] == c["seeds"] for c in contract["case_specs"])

cutoffs = {case["N"]: case["positive_count_cutoff_at_N"] for case in contract["case_specs"]}
prediction_checks = []
outcome_checks = []
eligibility_checks = []
horizon_checks = []
numeric_checks = []
for r in rows:
    N = r["N"]
    predicted = DENSE if r["positive_state_count_N"] >= cutoffs[N] else SPARSE
    prediction_checks.append(r["prediction"] == predicted and r["positive_state_count_cutoff_N"] == cutoffs[N])
    dense = (
        r["first_passage_0_5_by_4N"] is not None
        and r["first_passage_0_9_by_4N"] is not None
        and r["dense_tail_ge_0_9_exact"]
        and r["dense_raw_period_1_exact_3N_to_4N"]
    )
    sparse = (
        r["evaluated_horizon"] == 16 * N
        and r["sparse_ceiling_strict_exact"]
        and r["minimal_exact_tail_period_raw"] == N
        and r["period_search_exact_full_arrays"]
    )
    derived_outcome = DENSE if dense else SPARSE if sparse else OTHER
    outcome_checks.append(r["observed"] == derived_outcome)
    expected_eligible = r["first_passage_0_5_observed"] is None or r["first_passage_0_5_observed"] > N
    eligibility_checks.append(r["pre_crossing_cohort_at_N"] == expected_eligible)
    horizon_checks.append(r["evaluated_horizon"] == (4 * N if dense else 16 * N))
    numeric_checks.append(
        math.isclose(r["positive_state_fraction_N"], r["positive_state_count_N"] / (N**3), rel_tol=0.0, abs_tol=1e-15)
        and r["descriptor_bits"] == math.ceil(math.log2(N**3 + 1))
        and math.isclose(r["compression_gain_fraction"], 1 - r["descriptor_bits"] / r["microstate_bits"], rel_tol=0.0, abs_tol=1e-15)
    )
checks["integer_primary_rule_recomputed"] = all(prediction_checks)
checks["outcomes_recomputed_from_frozen_row_witnesses"] = all(outcome_checks)
checks["pre_crossing_membership_recomputed"] = all(eligibility_checks)
checks["adaptive_horizon_rule"] = all(horizon_checks)
checks["fractions_and_compression_recomputed"] = all(numeric_checks)

by_group: dict[str, list[dict]] = defaultdict(list)
for r in rows:
    by_group[r["group_id"]].append(r)
integrity = []
for group_rows in by_group.values():
    vr = {r["variant"]: r for r in group_rows}
    integrity.append(
        set(vr) == set(VARIANTS)
        and vr["baseline"]["initial_outer_joint_inventory_sha256"] == vr["same_inventory_joint_shuffle"]["initial_outer_joint_inventory_sha256"]
        and (
            vr["baseline"]["initial_raw_sha256"] != vr["same_inventory_joint_shuffle"]["initial_raw_sha256"]
            or vr["baseline"]["initial_clock_sha256"] != vr["same_inventory_joint_shuffle"]["initial_clock_sha256"]
        )
    )
checks["joint_inventory_and_shuffle_integrity"] = len(by_group) == 20 and all(integrity)

counts = Counter(r["observed"] for r in rows)
primary_metric = metric(rows, "prediction")
null_metrics = {}
for null_name in ("always_dense", "size_only", "size_plus_arm", "direction_support_N_same_cutoff"):
    null_rows = [dict(r, _null=r["comparator_predictions"][null_name]) for r in rows]
    null_metrics[null_name] = metric(null_rows, "_null")
nuisance_names = ("always_dense", "size_only", "size_plus_arm")
best_null = max(nuisance_names, key=lambda name: Fraction(null_metrics[name]["balanced_accuracy_exact"]))
full_advantage = Fraction(primary_metric["balanced_accuracy_exact"]) - Fraction(null_metrics[best_null]["balanced_accuracy_exact"])

group_classes = {g: {r["observed"] for r in rs} for g, rs in by_group.items()}
groups_dense = sum(DENSE in outcomes for outcomes in group_classes.values())
groups_sparse = sum(SPARSE in outcomes for outcomes in group_classes.values())
mixed_groups = sorted(g for g, outcomes in group_classes.items() if {DENSE, SPARSE} <= outcomes)
all_arms_success = sum(all(r["correct"] and r["prediction"] == r["observed"] for r in rs) for rs in by_group.values())

eligible = [r for r in rows if r["pre_crossing_cohort_at_N"]]
eligible_metric = metric(eligible, "prediction")
eligible_null_metrics = {}
for null_name in nuisance_names:
    null_rows = [dict(r, _null=r["comparator_predictions"][null_name]) for r in eligible]
    eligible_null_metrics[null_name] = metric(null_rows, "_null")
eligible_best_null = max(nuisance_names, key=lambda name: Fraction(eligible_null_metrics[name]["balanced_accuracy_exact"]))
eligible_advantage = Fraction(eligible_metric["balanced_accuracy_exact"]) - Fraction(eligible_null_metrics[eligible_best_null]["balanced_accuracy_exact"])
eligible_dense_groups = len({r["group_id"] for r in eligible if r["observed"] == DENSE})
eligible_sparse_groups = len({r["group_id"] for r in eligible if r["observed"] == SPARSE})

per_n_errors = {str(N): sum(not r["correct"] or r["prediction"] != r["observed"] for r in rows if r["N"] == N) for N in sorted({r["N"] for r in rows})}
minimum_compression = min(r["compression_gain_fraction"] for r in rows)
total_ticks = sum(r["evaluated_horizon"] for r in rows)

recomputed = {
    "counts": dict(sorted(counts.items())),
    "primary_metric": primary_metric,
    "null_metrics": null_metrics,
    "best_nuisance_null": best_null,
    "full_advantage_exact": f"{full_advantage.numerator}/{full_advantage.denominator}",
    "class_groups": {DENSE: groups_dense, SPARSE: groups_sparse},
    "mixed_groups": mixed_groups,
    "all_arms_success_groups": all_arms_success,
    "per_N_errors": per_n_errors,
    "minimum_compression_gain_fraction": minimum_compression,
    "eligible_rows": len(eligible),
    "eligible_primary_metric": eligible_metric,
    "eligible_null_metrics": eligible_null_metrics,
    "eligible_best_nuisance_null": eligible_best_null,
    "eligible_advantage_exact": f"{eligible_advantage.numerator}/{eligible_advantage.denominator}",
    "eligible_delayed_dense_groups": eligible_dense_groups,
    "eligible_sparse_groups": eligible_sparse_groups,
    "total_universe_ticks": total_ticks,
}

checks["recorded_counts"] = recorded["observed_counts"] == {DENSE: counts[DENSE], OTHER: counts[OTHER], SPARSE: counts[SPARSE]}
checks["recorded_primary_metrics"] = recorded["primary_metrics"]["errors"] == primary_metric["errors"] and recorded["primary_metrics"]["balanced_accuracy"] == primary_metric["balanced_accuracy"]
checks["recorded_null_metrics"] = all(recorded["comparator_metrics"][n]["errors"] == null_metrics[n]["errors"] and recorded["comparator_metrics"][n]["balanced_accuracy"] == null_metrics[n]["balanced_accuracy"] for n in null_metrics)
checks["recorded_group_diversity"] = recorded["independent_group_counts_by_class"] == {DENSE: groups_dense, SPARSE: groups_sparse} and recorded["mixed_outcome_seed_groups"] == mixed_groups
checks["recorded_pre_crossing"] = (
    recorded["pre_crossing_cohort_rows"] == len(eligible)
    and recorded["pre_crossing_subanalysis"]["delayed_dense_independent_groups"] == eligible_dense_groups
    and recorded["pre_crossing_subanalysis"]["sparse_independent_groups"] == eligible_sparse_groups
    and recorded["pre_crossing_subanalysis"]["primary_metrics"]["errors"] == eligible_metric["errors"]
)
checks["recorded_summary"] = result["summary"] == {
    "N_values": [33, 38],
    "extended_non_dense_to_16N": counts[SPARSE] + counts[OTHER],
    "seed_groups": 20,
    "stopped_dense_at_4N": counts[DENSE],
    "trajectories": 60,
    "universe_ticks": total_ticks,
}

criteria = contract["adjudication"]
literal_pass = (
    all(checks.values())
    and counts[OTHER] <= criteria["maximum_other_outcomes"]
    and primary_metric["errors"] <= criteria["maximum_primary_errors"]
    and all(v <= criteria["per_size_maximum_errors"] for v in per_n_errors.values())
    and groups_dense >= criteria["minimum_independent_groups_each_class"]
    and groups_sparse >= criteria["minimum_independent_groups_each_class"]
    and len(mixed_groups) >= criteria["minimum_mixed_seed_groups"]
    and Fraction(primary_metric["balanced_accuracy_exact"]) >= Fraction(str(criteria["minimum_balanced_accuracy"]))
    and full_advantage >= Fraction(str(criteria["minimum_balanced_accuracy_advantage_over_best_null"]))
    and minimum_compression >= criteria["minimum_compression_gain_fraction"]
    and eligible_dense_groups >= criteria["minimum_delayed_dense_groups_pre_crossing"]
    and eligible_sparse_groups >= criteria["minimum_sparse_groups_pre_crossing"]
    and eligible_metric["errors"] <= criteria["maximum_pre_crossing_errors"]
    and Fraction(eligible_metric["balanced_accuracy_exact"]) >= Fraction(str(criteria["minimum_pre_crossing_balanced_accuracy"]))
    and eligible_advantage >= Fraction(str(criteria["minimum_pre_crossing_balanced_accuracy_advantage_over_best_null"]))
)
checks["literal_verdict_recomputed"] = literal_pass and recorded["verdict"] == "PASS_CONFIRMED_PROGRESS"

audit = {
    "schema": "dee.v27.msh02.independent_result_audit.v1",
    "result": str(RESULT.relative_to(ROOT)).replace("\\", "/"),
    "result_sha256": sha256(RESULT),
    "lock_sha256": sha256(LOCK),
    "checks": checks,
    "recomputed": recomputed,
    "recorded_verdict": recorded["verdict"],
    "independent_verdict": "PASS_CONFIRMED_PROGRESS" if literal_pass else "AUDIT_FAIL",
    "status": "PASS" if all(checks.values()) else "FAIL",
    "interpretation": "Confirms the frozen finite-domain q_N predictive order law only; it does not establish q_N as a sufficient causal carrier, full-state periodicity, or an external physical identification.",
}
OUTPUT.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(audit, indent=2, sort_keys=True))
raise SystemExit(0 if audit["status"] == "PASS" else 2)
