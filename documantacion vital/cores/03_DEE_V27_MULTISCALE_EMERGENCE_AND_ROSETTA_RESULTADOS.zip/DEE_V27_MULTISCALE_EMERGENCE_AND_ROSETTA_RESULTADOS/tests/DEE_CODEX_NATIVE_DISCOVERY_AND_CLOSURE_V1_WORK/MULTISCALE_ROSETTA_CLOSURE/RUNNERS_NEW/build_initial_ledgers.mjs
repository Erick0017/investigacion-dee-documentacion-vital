#!/usr/bin/env node
/** Create the five canonical multiscale ledgers and validate them through artifact_tool. */
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { Workbook } from "@oai/artifact-tool";

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.dirname(here);

const ledgers = {
  "WHL_INTERROGATION_LEDGER.csv": {
    sheet: "WHL_Interrogation",
    fields: ["cycle_id", "interrogation_type", "runner", "wheel_hash", "kernel_hash", "N", "preparations", "trajectories", "ticks", "interventions", "controls", "discovery_or_holdout", "runtime", "branches_excited", "result", "output_hash"],
    rows: [
      {
        cycle_id: "C0001", interrogation_type: "CODE_INSPECTION", runner: "NONE_RECOVERY_AUDIT",
        wheel_hash: "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
        kernel_hash: "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        N: "NA", preparations: 0, trajectories: 0, ticks: 0, interventions: 0, controls: 0,
        discovery_or_holdout: "RECOVERY", runtime: "NA", branches_excited: "NONE",
        result: "No partial new mission or runner existed; no scientific execution counted.", output_hash: "NA"
      }
    ]
  },
  "FLEXIBILITY_LEDGER.csv": {
    sheet: "Flexibility",
    fields: ["cycle_id", "hypothesis_id", "phase", "choice_type", "alternatives_examined", "selected", "rationale", "flexibility_cost", "confirmatory_effect", "corrective_action"],
    rows: [
      {
        cycle_id: "C0001", hypothesis_id: "H-CROSS-SCALE-CARRIER", phase: "DISCOVERY",
        choice_type: "historical_channels", alternatives_examined: "outer_ablate|outer_clock17|outer_semantic4|outer_direction0|outer_sreg0",
        selected: "none_frozen", rationale: "Decision-relevant reanalysis of existing exact-copy v25 traces.",
        flexibility_cost: "HIGH", confirmatory_effect: "NONE",
        corrective_action: "MSD01 remains discovery; freeze exactly one candidate before any new holdout."
      },
      {
        cycle_id: "C0001", hypothesis_id: "H-Q2-RELATIONAL-RESPONSE", phase: "DISCOVERY",
        choice_type: "observable_level", alternatives_examined: "packed_hash|occupancy|s_reg|first_divergence|response_word",
        selected: "none_frozen", rationale: "Observable audit required because packed differences can occur without occupancy differences.",
        flexibility_cost: "HIGH", confirmatory_effect: "NONE",
        corrective_action: "Report all discovery channels; preregister one primary observable for confirmation."
      }
    ]
  },
  "EXPERIMENT_INDEX.csv": {
    sheet: "Experiments",
    fields: ["experiment_id", "cycle_id", "phase", "question", "status", "preregistered", "lock_id", "runner", "result_path", "output_hash", "notes"],
    rows: [
      {
        experiment_id: "RECOVERY-001", cycle_id: "C0001", phase: "RECOVERY",
        question: "Did the interrupted multiscale mission leave a verifiable partial state?", status: "COMPLETE",
        preregistered: "NO_NOT_SCIENTIFIC", lock_id: "NA", runner: "filesystem_read_only",
        result_path: "STATE.json", output_hash: "PENDING_MANIFEST",
        notes: "No prior directory/runner/result/checkpoint; interruption classified technical only."
      },
      {
        experiment_id: "HIST-MULTI-001", cycle_id: "C0001", phase: "DISCOVERY_REUSE",
        question: "Which historical matched intervention channels changed inner/middle scales and when?", status: "COMPLETE",
        preregistered: "NO_DISCOVERY", lock_id: "NA", runner: "read_only_trace_reanalysis",
        result_path: "DECISIONS.md#D0004", output_hash: "ac4097bc09d38fcc06dc4e4647ae6338d66e7f6e0a877dc0b81ee3756b7c4bad",
        notes: "v25 only; transfer to v27 prohibited without execution."
      },
      {
        experiment_id: "MSD01", cycle_id: "C0002", phase: "DISCOVERY",
        question: "What channel and compact descriptor mediate matched outer-to-inner response in v27?", status: "PENDING",
        preregistered: "NO_DISCOVERY", lock_id: "NA", runner: "RUNNERS_NEW/run_msd01_v27_discovery.py",
        result_path: "RESULTS/MSD01_results.json", output_hash: "PENDING",
        notes: "All descriptor/model selection remains discovery."
      }
    ]
  },
  "CLAIM_LEDGER.csv": {
    sheet: "Claims",
    fields: ["claim_id", "claim", "epistemic_class", "status", "scope", "phase", "preregistered", "evidence_path", "evidence_sha256", "assumptions_limits"],
    rows: [
      {
        claim_id: "MSC-C001", claim: "Q0=(raw,clock) is the exact microscopic Markov state.", epistemic_class: "EXACT_THEOREM_IMPORTED",
        status: "SUPPORTED", scope: "F_DEE v27", phase: "SEALED_PARENT", preregistered: "PARENT_PROTOCOL",
        evidence_path: "../FINAL_PACKAGE/NATIVE_DEE_THEORY.md", evidence_sha256: "PENDING_MANIFEST",
        assumptions_limits: "Imports sealed v27 result; no claim that raw is physically observable."
      },
      {
        claim_id: "MSC-C002", claim: "Q1=(Z,G_dagger,J_dagger) closes only in certified sparse D_* and separates predictive state from instantaneous event.", epistemic_class: "EXACT_SECTORIAL_PLUS_PROSPECTIVE_COMPUTATION",
        status: "SUPPORTED", scope: "D_*", phase: "SEALED_PARENT", preregistered: "T12",
        evidence_path: "../ROSETTA_CLOSURE/FINAL_PACKAGE/UNIFIED_RESPONSE_KERNEL.md", evidence_sha256: "PENDING_MANIFEST",
        assumptions_limits: "T10 original formulation remains FAIL; no extension beyond D_*."
      },
      {
        claim_id: "MSC-C003", claim: "Same raw+clock inventory with different spatial organization changes response in the V7-C apparatus.", epistemic_class: "COMPUTATIONAL_HOLDOUT_IMPORTED",
        status: "SUPPORTED", scope: "V7-C tested pairs", phase: "SEALED_HISTORY", preregistered: "V7-C",
        evidence_path: "../../DEE_V7_C_SUSTRATO_DISTRIBUIDO_CAUSALIDAD_RELACIONAL_FINAL_V1_WORK/RESULTS.json", evidence_sha256: "7ad1e3f102f45bc145bb82b1d2f74a23168a8695354b2702071b16f047cf4b4a",
        assumptions_limits: "Finite apparatus result; does not identify the minimal descriptor."
      },
      {
        claim_id: "MSC-C004", claim: "Historical v25 matched nested shells show channel-specific inward divergence.", epistemic_class: "DISCOVERY_REANALYSIS",
        status: "PROVISIONAL", scope: "MATCHEDMULTISCALE231X v25 only", phase: "DISCOVERY", preregistered: "NO",
        evidence_path: "DECISIONS.md#D0004", evidence_sha256: "ac4097bc09d38fcc06dc4e4647ae6338d66e7f6e0a877dc0b81ee3756b7c4bad",
        assumptions_limits: "Multiple channels/observables inspected; not transferred to v27 and not confirmatory."
      },
      {
        claim_id: "MSC-C005", claim: "A Q2 causal-response level exists.", epistemic_class: "HYPOTHESIS",
        status: "ACTIVE_UNCONFIRMED", scope: "To be defined", phase: "DISCOVERY", preregistered: "NO",
        evidence_path: "HYPOTHESIS_TREE.json", evidence_sha256: "PENDING_MANIFEST",
        assumptions_limits: "Requires compression, predictive retention, effective law, and independent holdout."
      }
    ]
  },
  "DEE_NATIVE_MAGNITUDES.csv": {
    sheet: "Native_Magnitudes",
    fields: ["magnitude_id", "name", "level", "definition", "native_units", "measurement", "domain", "predicts", "status", "evidence_path"],
    rows: [
      {
        magnitude_id: "MAG-001", name: "raw_causal_radius", level: "MICROSTATE",
        definition: "Maximum Chebyshev dependence distance in one raw update.", native_units: "voxel_per_tick",
        measurement: "paired perturbation plus exact branch audit", domain: "v27; radius-3 witness where torus diameter permits",
        predicts: "causal envelope r_infinity(t)<=3t", status: "EXACT_BOUND_IMPORTED", evidence_path: "../FINAL_PACKAGE/EXACT_THEOREMS.md"
      },
      {
        magnitude_id: "MAG-002", name: "clock_offset", level: "MICROSTATE",
        definition: "Pairwise clock difference modulo 2^64.", native_units: "clock_residue",
        measurement: "subtract clock cells modulo 2^64", domain: "all v27 states",
        predicts: "affine phase relation under evolution", status: "EXACT_INVARIANT_IMPORTED", evidence_path: "../FINAL_PACKAGE/EXACT_THEOREMS.md"
      },
      {
        magnitude_id: "MAG-003", name: "ballistic_velocity", level: "CAUSAL_LINEAGE",
        definition: "Moore direction d of an isolated normal carrier with q(t+1)=q(t)+d.", native_units: "voxel_per_tick",
        measurement: "track canonical Q1 carrier position", domain: "N>=5 isolated/sparse certified sector",
        predicts: "translation, first passage, Fourier phase", status: "EXACT_SECTORIAL_IMPORTED", evidence_path: "../FINAL_PACKAGE/NATIVE_DEE_THEORY.md"
      },
      {
        magnitude_id: "MAG-004", name: "collision_event_load", level: "EVENT",
        definition: "S=min(sum_j s_j,19664) retained in J_dagger at a simultaneous collision.", native_units: "s_reg_count",
        measurement: "decode transient collision raw", domain: "certified isolated collision apparatus",
        predicts: "event output and saturation", status: "EXACT_SECTORIAL_IMPORTED", evidence_path: "../ROSETTA_CLOSURE/FINAL_PACKAGE/UNIFIED_RESPONSE_KERNEL.md"
      },
      {
        magnitude_id: "MAG-005", name: "causal_response_word", level: "FIELD_OR_RESPONSE_CANDIDATE",
        definition: "Ordered field-wise detector differences under a declared intervention across time.", native_units: "dimensionless_word",
        measurement: "paired baseline/intervention telemetry", domain: "MSD01 discovery",
        predicts: "candidate Q2 equivalence and cross-scale first passage", status: "CANDIDATE", evidence_path: "RESULTS/MSD01_results.json"
      }
    ]
  }
};

function quoteCsv(value) {
  const text = String(value ?? "");
  return /[",\r\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

function a1Column(index) {
  let n = index + 1;
  let out = "";
  while (n > 0) {
    n -= 1;
    out = String.fromCharCode(65 + (n % 26)) + out;
    n = Math.floor(n / 26);
  }
  return out;
}

function sha256(text) {
  return crypto.createHash("sha256").update(text, "utf8").digest("hex");
}

async function materialize(name, spec) {
  for (const [index, row] of spec.rows.entries()) {
    const missing = spec.fields.filter((field) => !Object.hasOwn(row, field));
    const extra = Object.keys(row).filter((field) => !spec.fields.includes(field));
    if (missing.length || extra.length) throw new Error(`${name} row ${index + 2}: missing=${missing}; extra=${extra}`);
  }
  const matrix = [spec.fields, ...spec.rows.map((row) => spec.fields.map((field) => String(row[field] ?? "")))];
  const workbook = Workbook.create();
  const sheet = workbook.worksheets.add(spec.sheet);
  sheet.getRangeByIndexes(0, 0, matrix.length, spec.fields.length).values = matrix;
  const end = `${a1Column(spec.fields.length - 1)}${matrix.length}`;
  const inspection = await workbook.inspect({ kind: "region", sheetId: spec.sheet, range: `A1:${end}`, maxChars: 4000, tableMaxRows: 5, tableMaxCols: spec.fields.length, tableMaxCellChars: 80 });
  const memoryValues = sheet.getUsedRange(true)?.values;
  if (JSON.stringify(memoryValues) !== JSON.stringify(matrix)) throw new Error(`${name}: in-memory artifact_tool roundtrip mismatch`);
  const csv = `${matrix.map((row) => row.map(quoteCsv).join(",")).join("\r\n")}\r\n`;
  const imported = await Workbook.fromCSV(csv, { sheetName: "Reimport" });
  const importedValues = imported.worksheets.getItem("Reimport").getUsedRange(true)?.values;
  if (JSON.stringify(importedValues) !== JSON.stringify(matrix)) throw new Error(`${name}: artifact_tool CSV reimport mismatch`);
  await fs.writeFile(path.join(root, name), csv, "utf8");
  return { data_rows: spec.rows.length, columns: spec.fields.length, sha256: sha256(csv), artifact_tool_memory_roundtrip: true, artifact_tool_csv_reimport: true, inspection: String(inspection?.ndjson ?? inspection).slice(0, 1200) };
}

const report = { schema: "dee.v27.multiscale.initial_ledgers.v1", status: "PASS", library: "@oai/artifact-tool", outputs: {} };
for (const [name, spec] of Object.entries(ledgers)) report.outputs[name] = await materialize(name, spec);
await fs.mkdir(path.join(root, "RESULTS"), { recursive: true });
await fs.writeFile(path.join(root, "RESULTS", "initial_ledger_validation.json"), `${JSON.stringify(report, null, 2)}\n`, "utf8");
process.stdout.write(`${JSON.stringify({ status: report.status, outputs: Object.fromEntries(Object.entries(report.outputs).map(([name, value]) => [name, { rows: value.data_rows, columns: value.columns, sha256: value.sha256 }])) }, null, 2)}\n`);
