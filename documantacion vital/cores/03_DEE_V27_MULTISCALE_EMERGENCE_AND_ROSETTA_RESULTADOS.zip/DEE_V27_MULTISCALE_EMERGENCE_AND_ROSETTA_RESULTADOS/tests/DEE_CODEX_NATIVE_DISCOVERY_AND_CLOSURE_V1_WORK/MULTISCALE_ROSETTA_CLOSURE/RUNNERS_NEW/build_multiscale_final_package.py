#!/usr/bin/env python3
"""Build and independently verify the single portable DEE v27 result archive.

This script performs no scientific kernel execution.  It validates the already
sealed evidence, creates the CSV/JSON claim-ledger mirror, stages only the
portable audit corpus, writes a content manifest and hashes, creates one ZIP,
then extracts that ZIP to a temporary directory and verifies it again.
"""
from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
PARENT = ROOT.parent
STAGING = ROOT / "FINAL_PACKAGE"
TESTS_DST = STAGING / "tests"
PARENT_DST = TESTS_DST / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK"
WORK_DST = PARENT_DST / "MULTISCALE_ROSETTA_CLOSURE"
ARCHIVE_STEM = "DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS"
ZIP_PATH = ROOT / f"{ARCHIVE_STEM}.zip"
WHEEL_NAME = "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
WHEEL_CANDIDATES = (
    PARENT.parent / WHEEL_NAME,
    PARENT / "FINAL_PACKAGE" / "INPUTS" / WHEEL_NAME,
)
WHEEL_SRC = next((path for path in WHEEL_CANDIDATES if path.is_file()), WHEEL_CANDIDATES[0])
EXTRACTED_SRC = PARENT / "ANALYSIS" / "binary_api" / "wheel_extracted"

EXPECTED_WHEEL_SHA256 = "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939"
EXPECTED_PACKAGE_SHA256 = "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4"
EXPECTED_KERNEL_SHA256 = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"
EXPECTED_MSH01_VERDICT = "INCONCLUSIVE_CLASS_DIVERSITY"
EXPECTED_MSH02_VERDICT = "PASS_CONFIRMED_PROGRESS"

CANONICAL_TABLES = {
    "CLAIM_LEDGER.csv": "claim_id",
    "EXPERIMENT_INDEX.csv": "experiment_id",
    "DEE_NATIVE_MAGNITUDES.csv": "magnitude_id",
    "FLEXIBILITY_LEDGER.csv": None,
    "WHL_INTERROGATION_LEDGER.csv": None,
}

REQUIRED_WORK_FILES = (
    "STATE.json",
    "ADAPTIVE_STATE.json",
    "HYPOTHESIS_TREE.json",
    "DECISIONS.md",
    "RUN_LOG.ndjson",
    "CLAIM_LEDGER.csv",
    "CLAIM_LEDGER.json",
    "EXPERIMENT_INDEX.csv",
    "DEE_NATIVE_MAGNITUDES.csv",
    "FLEXIBILITY_LEDGER.csv",
    "WHL_INTERROGATION_LEDGER.csv",
    "FINAL_REPORT.md",
    "EXECUTIVE_VERDICT.md",
    "NATIVE_DEE_THEORY.md",
    "EXACT_THEOREMS.md",
    "CLAUDE_AUDIT.md",
    "HISTORICAL_CLAIMS_AUDIT.md",
    "NEGATIVE_RESULTS.md",
    "OPEN_EXTERNAL_GAPS.md",
    "DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA.md",
    "REPRODUCE.ps1",
)

REQUIRED_WORK_DIRS = (
    "ANALYSIS",
    "CHECKPOINTS",
    "DISCOVERY",
    "EVIDENCE_FOUNDATION",
    "HOLDOUTS",
    "HOLDOUT_LOCKS",
    "RESULTS",
    "ROSETTA_FROZEN_CONTRACTS",
    "RUNNERS_NEW",
)

ALLOWED_HYPOTHESIS_STATUSES = {
    "ACTIVE",
    "SUPPORTED",
    "REFUTED",
    "SUPERSEDED",
    "DORMANT",
    "WEAK_SIGNAL_DORMANT",
    "NOT_IDENTIFIABLE",
    "STAGNATED_NO_INFORMATION_GAIN",
}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def canonical_hash(value: Any) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def verify_extracted_against_wheel(wheel_path: Path, extracted_root: Path) -> dict[str, Any]:
    """Require the complete imported tree to be a byte-exact wheel extraction."""
    with zipfile.ZipFile(wheel_path, "r") as archive:
        wheel_members: dict[str, str] = {}
        for info in archive.infolist():
            if info.is_dir():
                continue
            relative = portable_relative(info.filename).as_posix()
            if relative in wheel_members:
                raise AssertionError(f"Duplicate wheel member: {relative}")
            wheel_members[relative] = hashlib.sha256(archive.read(info)).hexdigest()
    extracted_members = {
        path.relative_to(extracted_root).as_posix(): sha256_file(path)
        for path in extracted_root.rglob("*")
        if path.is_file()
    }
    if wheel_members != extracted_members:
        missing = sorted(set(wheel_members) - set(extracted_members))
        extra = sorted(set(extracted_members) - set(wheel_members))
        changed = sorted(
            name for name in set(wheel_members) & set(extracted_members)
            if wheel_members[name] != extracted_members[name]
        )
        raise AssertionError(
            f"Extracted runtime differs from wheel; missing={missing}, extra={extra}, changed={changed}"
        )
    return {
        "status": "PASS",
        "member_count": len(wheel_members),
        "aggregate_member_map_sha256": canonical_hash(wheel_members),
    }


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, ensure_ascii=False, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> tuple[list[str], list[dict[str, str]]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None:
            raise AssertionError(f"CSV without header: {path}")
        rows = list(reader)
        return list(reader.fieldnames), rows


def portable_relative(path_text: str) -> PurePosixPath:
    candidate = PurePosixPath(path_text.replace("\\", "/"))
    if candidate.is_absolute() or not candidate.parts or ".." in candidate.parts:
        raise AssertionError(f"Non-portable evidence path: {path_text}")
    return candidate


def resolve_work_relative(work_root: Path, path_text: str) -> Path:
    relative = portable_relative(path_text)
    target = (work_root / Path(*relative.parts)).resolve()
    resolved_root = work_root.resolve()
    try:
        target.relative_to(resolved_root)
    except ValueError as exc:
        raise AssertionError(f"Path escapes work root: {path_text}") from exc
    return target


def verify_checkpoint_manifests(work_root: Path) -> int:
    count = 0
    checkpoint_root = work_root / "CHECKPOINTS"
    checkpoints = sorted(path for path in checkpoint_root.iterdir() if path.is_dir())
    if not checkpoints or checkpoints[-1].name != "checkpoint_0012":
        raise AssertionError("Latest checkpoint is not checkpoint_0012")
    for checkpoint in checkpoints:
        for required in ("STATE.json", "ADAPTIVE_STATE.json", "HYPOTHESIS_TREE.json", "DECISIONS.md"):
            if not (checkpoint / required).is_file():
                raise AssertionError(f"Incomplete checkpoint: {checkpoint.name}/{required}")
        hash_file = checkpoint / "HASHES.sha256"
        if not hash_file.is_file():
            # Cycles 0001--0007 predate checkpoint hash manifests.  Preserve
            # them literally; require and verify hashes for every later one.
            if checkpoint.name >= "checkpoint_0008":
                raise AssertionError(f"Checkpoint hash manifest missing: {checkpoint.name}")
            continue
        for line_number, line in enumerate(hash_file.read_text(encoding="utf-8").splitlines(), 1):
            if not line:
                continue
            try:
                expected, relative_text = line.split("  ", 1)
            except ValueError as exc:
                raise AssertionError(
                    f"Malformed checkpoint hash line {checkpoint.name}:{line_number}"
                ) from exc
            target = resolve_work_relative(checkpoint, relative_text)
            if not target.is_file() or sha256_file(target) != expected:
                raise AssertionError(
                    f"Checkpoint hash mismatch: {checkpoint.name}/{relative_text}"
                )
            count += 1
    return count


def verify_json_and_ndjson(work_root: Path) -> tuple[int, int]:
    json_count = 0
    nested_final_package = work_root / "FINAL_PACKAGE"
    for path in sorted(work_root.rglob("*.json")):
        if nested_final_package in path.parents or "node_modules" in path.parts or path.name == "FINAL_ZIP_QA.json":
            continue
        try:
            read_json(path)
        except Exception as exc:
            raise AssertionError(f"Invalid JSON: {path}") from exc
        json_count += 1
    ndjson_lines = 0
    run_log = work_root / "RUN_LOG.ndjson"
    with run_log.open("r", encoding="utf-8-sig") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                json.loads(line)
            except json.JSONDecodeError as exc:
                raise AssertionError(f"Invalid RUN_LOG line {line_number}") from exc
            ndjson_lines += 1
    if ndjson_lines == 0:
        raise AssertionError("RUN_LOG.ndjson is empty")
    return json_count, ndjson_lines


def verify_ledgers(work_root: Path) -> dict[str, int]:
    counts: dict[str, int] = {}
    all_text: list[str] = []
    parsed: dict[str, list[dict[str, str]]] = {}
    for name, key in CANONICAL_TABLES.items():
        path = work_root / name
        fields, rows = read_csv(path)
        if not fields or not rows:
            raise AssertionError(f"Empty canonical ledger: {name}")
        if any(value is None for row in rows for value in row.values()):
            raise AssertionError(f"Malformed row width in canonical ledger: {name}")
        if key:
            values = [row[key] for row in rows]
            if len(values) != len(set(values)) or any(not value for value in values):
                raise AssertionError(f"Duplicate or empty key in {name}:{key}")
        counts[name] = len(rows)
        parsed[name] = rows
        all_text.extend(value for row in rows for value in row.values())
    if any("PENDING_MANIFEST" in value.upper() for value in all_text):
        raise AssertionError("Canonical ledger contains PENDING_MANIFEST")

    for claim in parsed["CLAIM_LEDGER.csv"]:
        evidence = resolve_work_relative(work_root, claim["evidence_path"])
        if not evidence.is_file():
            raise AssertionError(f"Missing claim evidence: {claim['claim_id']}")
        expected = claim["evidence_sha256"].lower()
        if len(expected) != 64 or sha256_file(evidence) != expected:
            raise AssertionError(f"Claim evidence hash mismatch: {claim['claim_id']}")

    for experiment in parsed["EXPERIMENT_INDEX.csv"]:
        result = resolve_work_relative(work_root, experiment["result_path"])
        if not result.is_file():
            raise AssertionError(f"Missing experiment result: {experiment['experiment_id']}")
        expected = experiment["output_hash"].lower()
        if len(expected) != 64 or sha256_file(result) != expected:
            raise AssertionError(f"Experiment hash mismatch: {experiment['experiment_id']}")

    for magnitude in parsed["DEE_NATIVE_MAGNITUDES.csv"]:
        evidence = resolve_work_relative(work_root, magnitude["evidence_path"])
        if not evidence.is_file():
            raise AssertionError(f"Missing magnitude evidence: {magnitude['magnitude_id']}")

    claim_fields, claim_rows = read_csv(work_root / "CLAIM_LEDGER.csv")
    claims_json = read_json(work_root / "CLAIM_LEDGER.json")
    if not isinstance(claims_json, list) or claims_json != claim_rows:
        raise AssertionError("CLAIM_LEDGER.csv and CLAIM_LEDGER.json differ by row or field")
    if any(set(row) != set(claim_fields) for row in claims_json):
        raise AssertionError("CLAIM_LEDGER.json fields differ from CSV")
    return counts


def verify_holdout_chain(work_root: Path, holdout_id: str, expected_verdict: str) -> dict[str, Any]:
    lock_path = work_root / "HOLDOUT_LOCKS" / f"HOLDOUT_{holdout_id}_LOCK.json"
    result_path = work_root / "HOLDOUTS" / f"{holdout_id}_results.json"
    lock = read_json(lock_path)
    result = read_json(result_path)
    lock_sha = sha256_file(lock_path)
    if result.get("lock_file_sha256") != lock_sha:
        raise AssertionError(f"{holdout_id} lock/result hash chain mismatch")
    if lock.get("contract_payload_sha256") != result.get("contract_payload_sha256"):
        raise AssertionError(f"{holdout_id} contract/result hash chain mismatch")
    if canonical_hash(lock["contract"]) != lock.get("contract_payload_sha256"):
        raise AssertionError(f"{holdout_id} canonical contract hash mismatch")
    if result.get("contract") != lock.get("contract") or canonical_hash(result["contract"]) != lock.get("contract_payload_sha256"):
        raise AssertionError(f"{holdout_id} result contract is not the frozen contract")
    runner_relative = lock["contract"]["runner"]
    runner_path = resolve_work_relative(work_root, runner_relative)
    runner_sha = sha256_file(runner_path)
    if runner_sha != lock["contract"]["runner_sha256"] or runner_sha != result["runner_sha256"]:
        raise AssertionError(f"{holdout_id} frozen runner hash mismatch")
    dependency_hashes: dict[str, str] = {}
    for role in ("core_runner", "foundation_runner"):
        dependency_path = resolve_work_relative(work_root, lock["contract"][role])
        dependency_sha = sha256_file(dependency_path)
        if dependency_sha != lock["contract"][f"{role}_sha256"] or dependency_sha != result[f"{role}_sha256"]:
            raise AssertionError(f"{holdout_id} {role} hash mismatch")
        dependency_hashes[role] = dependency_sha
    sidecar = lock_path.with_suffix(lock_path.suffix + ".sha256")
    sidecar_parts = sidecar.read_text(encoding="utf-8").strip().split("  ", 1)
    if sidecar_parts != [lock_sha, lock_path.name]:
        raise AssertionError(f"{holdout_id} lock sidecar mismatch")
    draft_path = work_root / "ANALYSIS" / f"HOLDOUT_{holdout_id}_LOCK_DRAFT.json"
    if not draft_path.is_file() or sha256_file(draft_path) != lock.get("draft_file_sha256"):
        raise AssertionError(f"{holdout_id} draft/lock hash mismatch")
    observed = result.get("environment", {}).get("observed_hashes")
    if observed != {
        "wheel": EXPECTED_WHEEL_SHA256,
        "package": EXPECTED_PACKAGE_SHA256,
        "kernel": EXPECTED_KERNEL_SHA256,
    } or result.get("environment", {}).get("threads") != 1:
        raise AssertionError(f"{holdout_id} runtime identity or thread count mismatch")
    verdict = result["primary_adjudication"]["verdict"]
    if verdict != expected_verdict:
        raise AssertionError(f"{holdout_id} literal verdict mismatch: {verdict}")
    return {
        "lock_sha256": lock_sha,
        "contract_payload_sha256": lock["contract_payload_sha256"],
        "runner_sha256": runner_sha,
        "dependency_hashes": dependency_hashes,
        "draft_sha256": lock["draft_file_sha256"],
        "result_sha256": sha256_file(result_path),
        "verdict": verdict,
        "trajectories": result["summary"]["trajectories"],
        "universe_ticks": result["summary"]["universe_ticks"],
    }


def verify_scientific_state(work_root: Path) -> dict[str, Any]:
    for relative in REQUIRED_WORK_FILES:
        if not (work_root / relative).is_file():
            raise AssertionError(f"Required work file missing: {relative}")
    for relative in REQUIRED_WORK_DIRS:
        if not (work_root / relative).is_dir():
            raise AssertionError(f"Required work directory missing: {relative}")

    state = read_json(work_root / "STATE.json")
    adaptive = read_json(work_root / "ADAPTIVE_STATE.json")
    tree = read_json(work_root / "HYPOTHESIS_TREE.json")
    if state.get("status") != "COMPLETE_HIERARCHY_FOUND_EXTERNAL_FRONTIER":
        raise AssertionError("Unexpected STATE status")
    if state.get("exact_next_action") != "NONE_MISSION_COMPLETE; FUTURE_WORK_REQUIRES_NEW_EXTERNAL_INPUTS_AND_CONTRACTS":
        raise AssertionError("STATE is not administratively finalized")
    if state.get("pending_experiments") != []:
        raise AssertionError("STATE still lists pending experiments")
    if adaptive.get("last_valid_checkpoint") != "CHECKPOINTS/checkpoint_0012":
        raise AssertionError("ADAPTIVE_STATE does not point to checkpoint_0012")
    if state.get("current_cycle") != 11 or adaptive.get("cycle") != 11:
        raise AssertionError("STATE/ADAPTIVE_STATE cycle mismatch")
    invalid_statuses = {
        item.get("status") for item in tree.get("hypotheses", [])
        if item.get("status") not in ALLOWED_HYPOTHESIS_STATUSES
    }
    if invalid_statuses:
        raise AssertionError(f"Invalid hypothesis statuses: {sorted(invalid_statuses)}")

    json_count, ndjson_lines = verify_json_and_ndjson(work_root)
    checkpoint_hashes = verify_checkpoint_manifests(work_root)
    latest_checkpoint = work_root / "CHECKPOINTS" / "checkpoint_0012"
    for name in ("STATE.json", "ADAPTIVE_STATE.json", "HYPOTHESIS_TREE.json", "DECISIONS.md"):
        if sha256_file(work_root / name) != sha256_file(latest_checkpoint / name):
            raise AssertionError(f"Current state differs from checkpoint_0012: {name}")
    log_records = [
        json.loads(line)
        for line in (work_root / "RUN_LOG.ndjson").read_text(encoding="utf-8-sig").splitlines()
        if line.strip()
    ]
    if not log_records or log_records[-1].get("event") != "CHECKPOINT_CREATED" or log_records[-1].get("checkpoint") != "CHECKPOINTS/checkpoint_0012":
        raise AssertionError("RUN_LOG does not end at checkpoint_0012")
    ledger_counts = verify_ledgers(work_root)
    msh01 = verify_holdout_chain(work_root, "MSH01", EXPECTED_MSH01_VERDICT)
    msh02 = verify_holdout_chain(work_root, "MSH02", EXPECTED_MSH02_VERDICT)

    msh02_result = read_json(work_root / "HOLDOUTS" / "MSH02_results.json")
    primary = msh02_result["primary_adjudication"]
    if primary["total"] != 60 or primary["primary_metrics"]["errors"] != 0:
        raise AssertionError("MSH02 60/60 result mismatch")
    if primary["observed_counts"] != {
        "DENSE_RAW_FIXED_WINDOW": 50,
        "OTHER": 0,
        "SPARSE_RAW_PERIOD_N_WINDOW": 10,
    }:
        raise AssertionError("MSH02 class-count mismatch")
    if primary["pre_crossing_subanalysis"]["primary_metrics"]["total"] != 22:
        raise AssertionError("MSH02 pre-crossing cohort mismatch")

    msh02_audit_path = work_root / "ANALYSIS" / "MSH02_RESULT_AUDIT.json"
    msh02_audit = read_json(msh02_audit_path)
    if msh02_audit.get("status") != "PASS" or any(
        value is not True for value in msh02_audit.get("checks", {}).values()
    ):
        raise AssertionError("MSH02 independent audit is not an all-checks PASS")
    if msh02_audit.get("result_sha256") != msh02["result_sha256"]:
        raise AssertionError("MSH02 independent audit/result hash mismatch")

    return {
        "status": "PASS",
        "state_status": state["status"],
        "cycle": state["current_cycle"],
        "json_files_parsed": json_count,
        "run_log_lines_parsed": ndjson_lines,
        "checkpoint_hashes_verified": checkpoint_hashes,
        "ledger_rows": ledger_counts,
        "msh01": msh01,
        "msh02": msh02,
        "msh02_independent_audit_sha256": sha256_file(msh02_audit_path),
    }


def generate_claim_json(work_root: Path) -> None:
    _, claims = read_csv(work_root / "CLAIM_LEDGER.csv")
    write_json(work_root / "CLAIM_LEDGER.json", claims)


def remove_previous_outputs() -> None:
    if STAGING.exists():
        if STAGING.resolve().parent != ROOT.resolve():
            raise AssertionError("Unsafe staging removal target")
        shutil.rmtree(STAGING)
    if ZIP_PATH.exists():
        if ZIP_PATH.resolve().parent != ROOT.resolve():
            raise AssertionError("Unsafe ZIP removal target")
        ZIP_PATH.unlink()


def ignore_work_copy(directory: str, names: list[str]) -> set[str]:
    ignored: set[str] = set()
    directory_path = Path(directory)
    if directory_path.resolve() == ROOT.resolve():
        ignored.update({"FINAL_PACKAGE", "node_modules", "MANIFEST.json", "HASHES.sha256"})
        ignored.update(name for name in names if name.lower().endswith(".zip"))
    ignored.update({name for name in names if name == "__pycache__" or name.endswith(".pyc")})
    # This sidecar is written only after the new ZIP exists; copying a prior
    # build's sidecar would embed stale self-referential packaging metadata.
    ignored.update({name for name in names if name == "FINAL_ZIP_QA.json"})
    return ignored


def stage_payload() -> None:
    STAGING.mkdir(parents=True, exist_ok=False)
    shutil.copytree(ROOT, WORK_DST, ignore=ignore_work_copy)
    TESTS_DST.mkdir(parents=True, exist_ok=True)
    shutil.copy2(WHEEL_SRC, TESTS_DST / WHEEL_NAME)
    extracted_dst = PARENT_DST / "ANALYSIS" / "binary_api" / "wheel_extracted"
    shutil.copytree(EXTRACTED_SRC, extracted_dst)
    shutil.copy2(ROOT / "REPRODUCE.ps1", STAGING / "REPRODUCE.ps1")
    (STAGING / "README.md").write_text(
        "# DEE v27 multiscale emergence and Rosetta results\n\n"
        "This is the single portable audit package for the completed campaign. "
        "The authoritative reports, state, ledgers, runners, holdouts, locks, "
        "checkpoints and evidence are under "
        "`tests/DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/"
        "MULTISCALE_ROSETTA_CLOSURE/`. The exact wheel and extracted binary "
        "runtime retain their original relative positions, so the frozen "
        "runners resolve them without source edits.\n\n"
        "Run `REPRODUCE.ps1` from this directory for a non-mutating integrity "
        "audit. Scientific holdouts are not rerun by that audit. For an actual "
        "Windows kernel import, extract to a short path such as `C:\\DEE27`; "
        "the CPython 3.13 native DLL loader can reject deeply nested paths even "
        "when all content hashes are correct.\n",
        encoding="utf-8",
        newline="\n",
    )


def payload_files(package_root: Path) -> list[Path]:
    excluded = {package_root / "MANIFEST.json", package_root / "HASHES.sha256"}
    return sorted(
        (
            path for path in package_root.rglob("*")
            if path.is_file() and path not in excluded
        ),
        key=lambda path: path.relative_to(package_root).as_posix().casefold(),
    )


def create_manifest(package_root: Path, scientific_qa: dict[str, Any]) -> dict[str, Any]:
    files = []
    for path in payload_files(package_root):
        relative = path.relative_to(package_root).as_posix()
        files.append({
            "path": relative,
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        })
    lower_paths = [item["path"].casefold() for item in files]
    if len(lower_paths) != len(set(lower_paths)):
        raise AssertionError("Case-insensitive path collision in package")
    manifest = {
        "schema": "dee.v27.multiscale.final-package-manifest.v1",
        "archive_root": ARCHIVE_STEM,
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "mission_status": scientific_qa["state_status"],
        "file_count": len(files),
        "total_bytes": sum(item["size"] for item in files),
        "wheel_sha256": EXPECTED_WHEEL_SHA256,
        "package_sha256": EXPECTED_PACKAGE_SHA256,
        "kernel_sha256": EXPECTED_KERNEL_SHA256,
        "files": files,
    }
    write_json(package_root / "MANIFEST.json", manifest)
    hash_entries = files + [{
        "path": "MANIFEST.json",
        "size": (package_root / "MANIFEST.json").stat().st_size,
        "sha256": sha256_file(package_root / "MANIFEST.json"),
    }]
    lines = [f"{item['sha256']}  {item['path']}" for item in hash_entries]
    (package_root / "HASHES.sha256").write_text(
        "\n".join(lines) + "\n", encoding="utf-8", newline="\n"
    )
    return manifest


def verify_package_root(package_root: Path) -> dict[str, Any]:
    manifest = read_json(package_root / "MANIFEST.json")
    entries = manifest.get("files", [])
    if manifest.get("file_count") != len(entries):
        raise AssertionError("Manifest file-count mismatch")
    expected_paths = {item["path"] for item in entries}
    if len(expected_paths) != len(entries):
        raise AssertionError("Duplicate path in manifest")
    if len({path.casefold() for path in expected_paths}) != len(entries):
        raise AssertionError("Case-insensitive path collision in manifest")
    if manifest.get("total_bytes") != sum(item["size"] for item in entries):
        raise AssertionError("Manifest total-bytes mismatch")
    actual_paths = {
        path.relative_to(package_root).as_posix()
        for path in payload_files(package_root)
    }
    if expected_paths != actual_paths:
        missing = sorted(expected_paths - actual_paths)
        extra = sorted(actual_paths - expected_paths)
        raise AssertionError(f"Manifest filesystem mismatch; missing={missing}, extra={extra}")
    for item in entries:
        target = resolve_work_relative(package_root, item["path"])
        if target.stat().st_size != item["size"] or sha256_file(target) != item["sha256"]:
            raise AssertionError(f"Manifest entry mismatch: {item['path']}")

    hash_lines = (package_root / "HASHES.sha256").read_text(encoding="utf-8").splitlines()
    hash_map: dict[str, str] = {}
    for line in hash_lines:
        expected, relative = line.split("  ", 1)
        if relative in hash_map:
            raise AssertionError(f"Duplicate hash entry: {relative}")
        hash_map[relative] = expected
        target = resolve_work_relative(package_root, relative)
        if not target.is_file() or sha256_file(target) != expected:
            raise AssertionError(f"HASHES.sha256 mismatch: {relative}")
    if set(hash_map) != expected_paths | {"MANIFEST.json"}:
        raise AssertionError("HASHES.sha256 path set differs from manifest plus MANIFEST.json")
    if len({path.casefold() for path in hash_map}) != len(hash_map):
        raise AssertionError("Case-insensitive path collision in HASHES.sha256")

    packaged_parent = package_root / "tests" / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK"
    wheel = package_root / "tests" / WHEEL_NAME
    package_file = packaged_parent / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "__init__.py"
    kernel_file = packaged_parent / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
    identities = {
        "wheel": sha256_file(wheel),
        "package": sha256_file(package_file),
        "kernel": sha256_file(kernel_file),
    }
    if identities != {
        "wheel": EXPECTED_WHEEL_SHA256,
        "package": EXPECTED_PACKAGE_SHA256,
        "kernel": EXPECTED_KERNEL_SHA256,
    }:
        raise AssertionError(f"Runtime identity mismatch: {identities}")
    extraction_qa = verify_extracted_against_wheel(
        wheel, packaged_parent / "ANALYSIS" / "binary_api" / "wheel_extracted"
    )
    if list(package_root.rglob("*.zip")):
        raise AssertionError("Nested ZIP found in final package")
    verify_scientific_state(
        packaged_parent / "MULTISCALE_ROSETTA_CLOSURE"
    )
    return {
        "status": "PASS",
        "manifest_files": len(entries),
        "hash_entries": len(hash_map),
        "total_bytes": sum(item["size"] for item in entries),
        "identities": identities,
        "wheel_extraction": extraction_qa,
    }


def create_zip(package_root: Path, zip_path: Path) -> None:
    compression = zipfile.ZIP_DEFLATED
    with zipfile.ZipFile(zip_path, "w", compression=compression, compresslevel=9) as archive:
        for path in sorted(package_root.rglob("*"), key=lambda p: p.as_posix().casefold()):
            if not path.is_file():
                continue
            relative = path.relative_to(package_root).as_posix()
            archive.write(path, f"{ARCHIVE_STEM}/{relative}")


def verify_zip_roundtrip(zip_path: Path) -> dict[str, Any]:
    with zipfile.ZipFile(zip_path, "r") as archive:
        names = archive.namelist()
        if not names or len(names) != len(set(names)):
            raise AssertionError("ZIP has no files or duplicate members")
        prefix = f"{ARCHIVE_STEM}/"
        if any(not name.startswith(prefix) for name in names):
            raise AssertionError("ZIP member outside declared archive root")
        if any(name.lower().endswith(".zip") for name in names):
            raise AssertionError("Nested ZIP member found")
        bad_member = archive.testzip()
        if bad_member is not None:
            raise AssertionError(f"ZIP CRC failure: {bad_member}")
        with tempfile.TemporaryDirectory(prefix="dee_v27_final_zip_verify_") as temporary:
            temporary_root = Path(temporary)
            archive.extractall(temporary_root)
            extracted = temporary_root / ARCHIVE_STEM
            package_qa = verify_package_root(extracted)
            return {
                "status": "PASS",
                "zip_members": len(names),
                "archive_root": ARCHIVE_STEM,
                "package_qa": package_qa,
            }


def main() -> None:
    generate_claim_json(ROOT)
    source_qa = verify_scientific_state(ROOT)
    if not WHEEL_SRC.is_file() or sha256_file(WHEEL_SRC) != EXPECTED_WHEEL_SHA256:
        raise AssertionError("Exact v27 wheel is missing or has wrong hash")
    if not EXTRACTED_SRC.is_dir():
        raise AssertionError("Extracted v27 runtime is missing")
    source_runtime_qa = verify_extracted_against_wheel(WHEEL_SRC, EXTRACTED_SRC)

    remove_previous_outputs()
    stage_payload()
    staged_scientific_qa = verify_scientific_state(WORK_DST)
    final_package_qa = {
        "schema": "dee.v27.multiscale.final-package-qa.v1",
        "status": "PASS",
        "scientific_execution_performed": False,
        "source_validation": source_qa,
        "source_wheel_extraction": source_runtime_qa,
        "staged_validation": staged_scientific_qa,
        "statement": (
            "The sealed scientific corpus was validated and packaged without rerunning "
            "any completed experiment or opening any new scientific branch."
        ),
    }
    write_json(STAGING / "FINAL_PACKAGE_QA.json", final_package_qa)
    manifest = create_manifest(STAGING, staged_scientific_qa)
    staged_package_qa = verify_package_root(STAGING)
    shutil.copy2(STAGING / "MANIFEST.json", ROOT / "MANIFEST.json")
    shutil.copy2(STAGING / "HASHES.sha256", ROOT / "HASHES.sha256")

    create_zip(STAGING, ZIP_PATH)
    zip_roundtrip = verify_zip_roundtrip(ZIP_PATH)
    final_zip_qa = {
        "schema": "dee.v27.multiscale.final-zip-qa.v1",
        "status": "PASS",
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "zip_path": ZIP_PATH.name,
        "zip_size": ZIP_PATH.stat().st_size,
        "zip_sha256": sha256_file(ZIP_PATH),
        "manifest_sha256": sha256_file(STAGING / "MANIFEST.json"),
        "hashes_sha256": sha256_file(STAGING / "HASHES.sha256"),
        "manifest_file_count": manifest["file_count"],
        "staged_package_qa": staged_package_qa,
        "zip_roundtrip": zip_roundtrip,
        "nested_zip_count": 0,
        "scientific_reruns": 0,
    }
    write_json(ROOT / "RESULTS" / "FINAL_ZIP_QA.json", final_zip_qa)
    print(json.dumps(final_zip_qa, indent=2, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
