#!/usr/bin/env python3
"""Freeze one MSH01 pre-holdout contract and write its SHA-256 sidecar."""
from __future__ import annotations

import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
DRAFT = ROOT / "ANALYSIS" / "HOLDOUT_MSH01_LOCK_DRAFT.json"
FINAL = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json"
SIDECAR = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json.sha256"


def canonical_bytes(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def atomic_write(path: Path, payload: bytes) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def main() -> int:
    if FINAL.exists() or SIDECAR.exists():
        raise RuntimeError("MSH01 final lock or sidecar already exists; refusing overwrite")
    draft_bytes = DRAFT.read_bytes()
    draft = json.loads(draft_bytes.decode("utf-8"))
    if draft.get("status") != "READY_TO_FREEZE_PRE_HOLDOUT":
        raise RuntimeError("draft status is not READY_TO_FREEZE_PRE_HOLDOUT")
    contract = draft["contract"]
    contract_hash = sha256_bytes(canonical_bytes(contract))
    wrapper = {
        "schema": "dee.v27.multiscale.pre_holdout_lock.v1",
        "lock_id": contract["holdout_id"],
        "status": "FROZEN_PRE_HOLDOUT",
        "frozen_utc": datetime.now(timezone.utc).isoformat(),
        "draft_file_sha256": sha256_bytes(draft_bytes),
        "contract_payload_sha256": contract_hash,
        "contract": contract,
    }
    payload = (json.dumps(wrapper, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")
    atomic_write(FINAL, payload)
    file_hash = sha256_bytes(payload)
    atomic_write(SIDECAR, f"{file_hash}  {FINAL.name}\n".encode("ascii"))
    print(json.dumps({
        "status": "FROZEN_PRE_HOLDOUT",
        "lock": str(FINAL),
        "lock_file_sha256": file_hash,
        "contract_payload_sha256": contract_hash,
        "draft_file_sha256": wrapper["draft_file_sha256"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
