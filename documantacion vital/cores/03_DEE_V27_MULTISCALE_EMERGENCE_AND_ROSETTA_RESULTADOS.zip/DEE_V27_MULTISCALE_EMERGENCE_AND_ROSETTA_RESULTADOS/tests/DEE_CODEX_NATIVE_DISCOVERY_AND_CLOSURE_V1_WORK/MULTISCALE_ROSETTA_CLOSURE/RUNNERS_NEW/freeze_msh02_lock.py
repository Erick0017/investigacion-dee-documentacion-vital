#!/usr/bin/env python3
"""Freeze the MSH02 preregistration exactly once, or audit it without writing."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
DRAFT = ROOT / "ANALYSIS" / "HOLDOUT_MSH02_LOCK_DRAFT.json"
FINAL = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json"
SIDECAR = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json.sha256"
RESULT = ROOT / "HOLDOUTS" / "MSH02_results.json"


def canonical_bytes(value) -> bytes:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def atomic_write(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("xb") as handle:
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def inspect_draft() -> tuple[dict, dict]:
    draft_bytes = DRAFT.read_bytes()
    draft = json.loads(draft_bytes.decode("utf-8"))
    contract = draft.get("contract", {})
    checks = {
        "draft_ready": draft.get("status") == "READY_TO_FREEZE_PRE_HOLDOUT",
        "holdout_id_exact": contract.get("holdout_id") == "MSH02",
        "final_lock_absent": not FINAL.exists(),
        "sidecar_absent": not SIDECAR.exists(),
        "holdout_result_absent": not RESULT.exists(),
        "contract_present": bool(contract),
    }
    report = {
        "schema": "dee.v27.msh02.freeze_preflight.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "draft_file_sha256": sha256_bytes(draft_bytes),
        "contract_payload_sha256": sha256_bytes(canonical_bytes(contract)) if contract else None,
    }
    return draft, report


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    args = parser.parse_args()
    draft, report = inspect_draft()
    if args.audit_only:
        print(json.dumps(report, indent=2, sort_keys=True))
        return 0 if report["status"] == "PASS" else 2
    if report["status"] != "PASS":
        raise RuntimeError(f"MSH02 freeze preflight failed: {report['checks']}")

    draft_bytes = DRAFT.read_bytes()
    contract = draft["contract"]
    wrapper = {
        "schema": "dee.v27.multiscale.pre_holdout_lock.v1",
        "lock_id": contract["holdout_id"],
        "status": "FROZEN_PRE_HOLDOUT",
        "frozen_utc": datetime.now(timezone.utc).isoformat(),
        "draft_file_sha256": sha256_bytes(draft_bytes),
        "contract_payload_sha256": sha256_bytes(canonical_bytes(contract)),
        "contract": contract,
    }
    payload = (
        json.dumps(wrapper, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False) + "\n"
    ).encode("utf-8")
    atomic_write(FINAL, payload)
    file_hash = sha256_bytes(payload)
    atomic_write(SIDECAR, f"{file_hash}  {FINAL.name}\n".encode("ascii"))
    print(json.dumps({
        "status": "FROZEN_PRE_HOLDOUT",
        "lock": str(FINAL),
        "lock_file_sha256": file_hash,
        "contract_payload_sha256": wrapper["contract_payload_sha256"],
        "draft_file_sha256": wrapper["draft_file_sha256"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
