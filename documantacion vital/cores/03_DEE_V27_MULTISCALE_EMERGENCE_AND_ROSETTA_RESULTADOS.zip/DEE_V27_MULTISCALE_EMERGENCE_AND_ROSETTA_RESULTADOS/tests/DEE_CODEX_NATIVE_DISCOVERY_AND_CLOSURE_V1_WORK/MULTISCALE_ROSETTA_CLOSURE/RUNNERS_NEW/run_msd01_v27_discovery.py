#!/usr/bin/env python3
"""MSD01: matched nested-scale discovery on the hash-pinned DEE v27 kernel.

This is deliberately a discovery panel.  It may select a candidate descriptor,
but it cannot produce confirmatory evidence and does not open a holdout.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import os
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
PARENT = ROOT.parent
TESTS = PARENT.parent
EXTRACTED = PARENT / "ANALYSIS" / "binary_api" / "wheel_extracted"
PACKAGE_FILE = EXTRACTED / "dee_universe_v27" / "__init__.py"
KERNEL_FILE = EXTRACTED / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
WHEEL_FILE = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
OUT_JSON = ROOT / "RESULTS" / "MSD01_results.json"
OUT_NPZ = ROOT / "RESULTS" / "MSD01_states.npz"

EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "kernel": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}
STATE_MASK = np.uint64((1 << 32) - 1)
SREG_MASK = np.uint64(0xFFFF)
SEM_MASK = np.uint64(0xF)
CLOCK_BANK = np.array([0, 7, 17, 194, 195, 259, 260, 390, 391, 781, 782], dtype=np.uint64)
VARIANTS = (
    "baseline",
    "outer_ablate",
    "outer_direction0",
    "outer_semantic4",
    "outer_sreg0",
    "outer_clock_plus17",
    "same_inventory_joint_shuffle",
    "outer_clock_shuffle",
)
SPECS = (
    {"N": 32, "radii": (3, 7, 12), "counts": (24, 48, 96), "horizon": 48},
    {"N": 40, "radii": (4, 9, 15), "counts": (32, 64, 128), "horizon": 60},
)
REPLICATES = 2
BASE_SEED = 270127031


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).view(np.uint8)).hexdigest()


def canonical_hash(obj) -> str:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def pack(state: int, sreg: int, d: tuple[int, int, int], semantic: int = 1) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF)
        | ((sreg & 0xFFFF) << 32)
        | ((d[0] & 0xF) << 48)
        | ((d[1] & 0xF) << 52)
        | ((d[2] & 0xF) << 56)
        | ((semantic & 0xF) << 60)
    )


def signed_nibble(raw: np.ndarray, shift: int) -> np.ndarray:
    x = ((raw >> np.uint64(shift)) & np.uint64(0xF)).astype(np.int16)
    return np.where(x >= 8, x - 16, x)


def fields(raw: np.ndarray) -> dict[str, np.ndarray]:
    return {
        "state": (raw & STATE_MASK).astype(np.uint32),
        "sreg": ((raw >> np.uint64(32)) & SREG_MASK).astype(np.uint16),
        "dx": signed_nibble(raw, 48),
        "dy": signed_nibble(raw, 52),
        "dz": signed_nibble(raw, 56),
        "semantic": ((raw >> np.uint64(60)) & SEM_MASK).astype(np.uint8),
    }


def tor_delta(coords: np.ndarray, center: np.ndarray, n: int) -> np.ndarray:
    return ((coords - center + n // 2) % n) - n // 2


def cheb_radius_grid(n: int, center: np.ndarray) -> np.ndarray:
    axes = [((np.arange(n) - int(center[j]) + n // 2) % n) - n // 2 for j in range(3)]
    xx, yy, zz = np.meshgrid(*axes, indexing="ij")
    return np.maximum.reduce([np.abs(xx), np.abs(yy), np.abs(zz)]).astype(np.int16)


def shell_candidates(radius_grid: np.ndarray, r: int) -> np.ndarray:
    return np.argwhere((radius_grid <= r) & (radius_grid >= max(1, r - 1)))


def make_base(spec: dict, seed: int) -> tuple[np.ndarray, np.ndarray, list[np.ndarray], dict]:
    n = int(spec["N"])
    center = np.array([n // 2] * 3, dtype=np.int64)
    radius_grid = cheb_radius_grid(n, center)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed)
    layers: list[np.ndarray] = []
    layer_records = []
    for layer, (radius, count) in enumerate(zip(spec["radii"], spec["counts"])):
        candidates = shell_candidates(radius_grid, int(radius))
        order = rng.permutation(len(candidates))[: int(count)]
        coords = candidates[order].astype(np.int16)
        layers.append(coords)
        for index, q16 in enumerate(coords):
            q = q16.astype(np.int64)
            delta = tor_delta(q[None, :], center, n)[0]
            direction = tuple(int(-np.sign(x)) for x in delta)
            if direction == (0, 0, 0):
                raise AssertionError("shell emitted a zero direction")
            sreg = int(rng.integers(1, 65))
            qi = tuple(int(x) for x in q)
            raw[qi] = pack(1, sreg, direction, 1)
            clock[qi] = CLOCK_BANK[(index + 3 * layer + seed) % len(CLOCK_BANK)]
        layer_records.append({"layer": layer, "radius": int(radius), "count": len(coords)})
    return raw, clock, layers, {"center": center.tolist(), "layers": layer_records}


def repack_at(raw: np.ndarray, coords: np.ndarray, *, direction_zero=False, semantic=None, sreg_zero=False) -> None:
    for q16 in coords:
        q = tuple(int(x) for x in q16)
        value = raw[q]
        f = fields(np.array([value], dtype=np.uint64))
        d = (0, 0, 0) if direction_zero else (int(f["dx"][0]), int(f["dy"][0]), int(f["dz"][0]))
        s = 0 if sreg_zero else int(f["sreg"][0])
        sem = int(f["semantic"][0]) if semantic is None else int(semantic)
        raw[q] = pack(int(f["state"][0]), s, d, sem)


def build_variants(base_raw: np.ndarray, base_clock: np.ndarray, outer: np.ndarray, seed: int) -> dict[str, tuple[np.ndarray, np.ndarray]]:
    rng = np.random.default_rng(seed ^ 0x5A17)
    out = {}
    for name in VARIANTS:
        g = base_raw.copy()
        c = base_clock.copy()
        qs = tuple(outer.T.astype(np.intp))
        if name == "outer_ablate":
            g[qs] = np.uint64(0)
        elif name == "outer_direction0":
            repack_at(g, outer, direction_zero=True)
        elif name == "outer_semantic4":
            repack_at(g, outer, semantic=4)
        elif name == "outer_sreg0":
            repack_at(g, outer, sreg_zero=True)
        elif name == "outer_clock_plus17":
            c[qs] = c[qs] + np.uint64(17)
        elif name == "same_inventory_joint_shuffle":
            permutation = rng.permutation(len(outer))
            old_g = g[qs].copy()
            old_c = c[qs].copy()
            g[qs] = old_g[permutation]
            c[qs] = old_c[permutation]
        elif name == "outer_clock_shuffle":
            permutation = rng.permutation(len(outer))
            old_c = c[qs].copy()
            c[qs] = old_c[permutation]
        elif name != "baseline":
            raise ValueError(name)
        out[name] = (g, c)
    return out


def multiset_hash(raw: np.ndarray, clock: np.ndarray, coords: np.ndarray, joint: bool) -> str:
    qs = tuple(coords.T.astype(np.intp))
    g = raw[qs].astype("<u8", copy=False)
    c = clock[qs].astype("<u8", copy=False)
    if joint:
        pairs = np.rec.fromarrays([g, c], names="g,c")
        order = np.argsort(pairs, order=("g", "c"))
        payload = np.column_stack([g[order], c[order]]).astype("<u8", copy=False)
    else:
        payload = np.column_stack([np.sort(g), np.sort(c)]).astype("<u8", copy=False)
    return sha256_array(payload)


def initial_descriptor(raw: np.ndarray, clock: np.ndarray, outer: np.ndarray, center: np.ndarray, inner_radius: int, horizon: int, n: int) -> dict:
    qs = tuple(outer.T.astype(np.intp))
    vals = raw[qs]
    f = fields(vals)
    dirs = np.column_stack([f["dx"], f["dy"], f["dz"]]).astype(np.int16)
    delta = tor_delta(outer.astype(np.int64), center, n)
    target = -np.sign(delta).astype(np.int16)
    active_axes = target != 0
    aligned_axes = (dirs == target) & active_axes
    denom = int(np.count_nonzero(active_axes))
    alignment = float(np.count_nonzero(aligned_axes) / denom) if denom else 0.0
    radial_flux = float(np.sum(-dirs.astype(np.float64) * delta.astype(np.float64)))
    direct_hits = 0
    first_hits = []
    distinct_sites: set[tuple[int, int, int]] = set()
    for q, d in zip(outer.astype(np.int64), dirs.astype(np.int64)):
        if np.all(d == 0):
            continue
        for t in range(1, horizon + 1):
            p = (q + t * d) % n
            dr = tor_delta(p[None, :], center, n)[0]
            if int(np.max(np.abs(dr))) <= inner_radius:
                direct_hits += 1
                first_hits.append(t)
                distinct_sites.add(tuple(int(x) for x in p))
                break
    destinations = (outer.astype(np.int64) + dirs.astype(np.int64)) % n
    unique_destinations = len({tuple(int(x) for x in p) for p in destinations})
    return {
        "outer_sites": int(len(outer)),
        "outer_active": int(np.count_nonzero(f["state"])),
        "outer_raw_nonzero": int(np.count_nonzero(vals)),
        "sreg_sum": int(np.sum(f["sreg"], dtype=np.uint64)),
        "semantic4_count": int(np.count_nonzero(f["semantic"] == 4)),
        "direction_zero_count": int(np.count_nonzero(np.all(dirs == 0, axis=1))),
        "clock_sum_mod2_64": int(np.sum(clock[qs], dtype=np.uint64)),
        "inward_axis_alignment": alignment,
        "radial_flux": radial_flux,
        "straight_line_inner_hits": int(direct_hits),
        "straight_line_first_hit_min": min(first_hits) if first_hits else None,
        "straight_line_distinct_inner_entry_sites": int(len(distinct_sites)),
        "unique_one_tick_destinations": int(unique_destinations),
        "raw_multiset_sha256": multiset_hash(raw, np.zeros_like(clock), outer, False),
        "clock_multiset_sha256": multiset_hash(np.zeros_like(raw), clock, outer, False),
        "joint_raw_clock_multiset_sha256": multiset_hash(raw, clock, outer, True),
    }


def distance_map(n: int, sources: np.ndarray) -> np.ndarray:
    axes = np.indices((n, n, n), dtype=np.int16)
    best = np.full((n, n, n), n, dtype=np.int16)
    for q in sources.astype(np.int16):
        distances = []
        for axis in range(3):
            delta = np.abs(axes[axis] - int(q[axis]))
            distances.append(np.minimum(delta, n - delta))
        best = np.minimum(best, np.maximum.reduce(distances).astype(np.int16))
    return best


def region_metrics(raw: np.ndarray, clock: np.ndarray, mask: np.ndarray) -> dict:
    vals = raw[mask]
    clk = clock[mask]
    f = fields(vals)
    return {
        "sites": int(np.count_nonzero(mask)),
        "occupancy": int(np.count_nonzero(f["state"])),
        "raw_nonzero": int(np.count_nonzero(vals)),
        "state_sum": int(np.sum(f["state"], dtype=np.uint64)),
        "sreg_sum": int(np.sum(f["sreg"], dtype=np.uint64)),
        "direction_nonzero": int(np.count_nonzero((f["dx"] != 0) | (f["dy"] != 0) | (f["dz"] != 0))),
        "semantic4": int(np.count_nonzero(f["semantic"] == 4)),
        "raw_sha256": sha256_array(vals),
        "clock_sha256": sha256_array(clk),
    }


def field_diff_counts(a: np.ndarray, b: np.ndarray) -> dict[str, int]:
    fa, fb = fields(a), fields(b)
    return {
        "raw": int(np.count_nonzero(a != b)),
        "state": int(np.count_nonzero(fa["state"] != fb["state"])),
        "sreg": int(np.count_nonzero(fa["sreg"] != fb["sreg"])),
        "direction": int(np.count_nonzero((fa["dx"] != fb["dx"]) | (fa["dy"] != fb["dy"]) | (fa["dz"] != fb["dz"]))),
        "semantic": int(np.count_nonzero(fa["semantic"] != fb["semantic"])),
    }


class Native:
    def __init__(self, threads: int):
        sys.path.insert(0, str(EXTRACTED))
        importlib.invalidate_caches()
        import dee_universe_v27 as package
        from dee_universe_v27 import UniversoDEE_v27, dee_kernel_v27

        if Path(package.__file__).resolve() != PACKAGE_FILE.resolve():
            raise RuntimeError(f"wrong package imported: {package.__file__}")
        if Path(dee_kernel_v27.__file__).resolve() != KERNEL_FILE.resolve():
            raise RuntimeError(f"wrong kernel imported: {dee_kernel_v27.__file__}")
        observed = {
            "wheel": sha256_file(WHEEL_FILE),
            "package": sha256_file(PACKAGE_FILE),
            "kernel": sha256_file(KERNEL_FILE),
        }
        if observed != EXPECTED:
            raise RuntimeError(f"identity mismatch: {observed}")
        self.cls = UniversoDEE_v27
        self.threads = int(threads)
        self.environment = {
            "observed_hashes": observed,
            "package_path": str(PACKAGE_FILE),
            "kernel_path": str(KERNEL_FILE),
            "python": sys.version,
            "numpy": np.__version__,
            "platform": platform.platform(),
            "threads": self.threads,
            "package_version": getattr(package, "__version__", None),
        }

    def new(self, raw: np.ndarray, clock: np.ndarray):
        n = raw.shape[0]
        u = self.cls(N=n, n_hilos=self.threads)
        np.asarray(u.grid_A).reshape(raw.shape)[:] = raw
        np.asarray(u.grid_B).reshape(raw.shape)[:] = raw
        np.asarray(u.clock_A).reshape(raw.shape)[:] = clock
        np.asarray(u.clock_B).reshape(raw.shape)[:] = clock
        u.tick_global = 0
        return u

    @staticmethod
    def snap(u) -> tuple[np.ndarray, np.ndarray]:
        n = int(u.N)
        return (
            np.asarray(u.grid_A).reshape((n, n, n)).copy(),
            np.asarray(u.clock_A).reshape((n, n, n)).copy(),
        )


def run_case(native: Native, spec: dict, rep: int, seed: int, state_payload: dict) -> dict:
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    base_raw, base_clock, layers, construction = make_base(spec, seed)
    outer = layers[-1]
    variants = build_variants(base_raw, base_clock, outer, seed)
    center = np.array(construction["center"], dtype=np.int64)
    radius_grid = cheb_radius_grid(n, center)
    masks = {
        "inner_ball": radius_grid <= int(spec["radii"][0]),
        "middle_ball": radius_grid <= int(spec["radii"][1]),
        "outer_ball": radius_grid <= int(spec["radii"][2]),
        "world": np.ones((n, n, n), dtype=bool),
    }
    intervention_distance = distance_map(n, outer)
    universes = {name: native.new(g, c) for name, (g, c) in variants.items()}
    descriptors = {
        name: initial_descriptor(g, c, outer, center, int(spec["radii"][0]), horizon, n)
        for name, (g, c) in variants.items()
    }
    joint_inventory_exact = (
        descriptors["baseline"]["joint_raw_clock_multiset_sha256"]
        == descriptors["same_inventory_joint_shuffle"]["joint_raw_clock_multiset_sha256"]
    )
    shuffled_changed = not (
        np.array_equal(variants["baseline"][0], variants["same_inventory_joint_shuffle"][0])
        and np.array_equal(variants["baseline"][1], variants["same_inventory_joint_shuffle"][1])
    )
    traces = {name: [] for name in VARIANTS}
    first = {
        name: {region: {field: None for field in ("raw", "state", "sreg", "direction", "semantic", "clock")} for region in masks}
        for name in VARIANTS if name != "baseline"
    }
    causal_violations = {name: [] for name in VARIANTS if name != "baseline"}
    initial_hashes = {}
    final_hashes = {}
    for name, (g, c) in variants.items():
        safe = f"N{n}_r{rep}_{name}"
        state_payload[f"{safe}_raw_t0"] = g
        state_payload[f"{safe}_clock_t0"] = c
        initial_hashes[name] = {"raw": sha256_array(g), "clock": sha256_array(c)}

    for tick in range(horizon + 1):
        snapshots = {name: native.snap(u) for name, u in universes.items()}
        base_g, base_c = snapshots["baseline"]
        for name in VARIANTS:
            g, c = snapshots[name]
            entry = {"tick": tick, "regions": {region: region_metrics(g, c, mask) for region, mask in masks.items()}}
            if name != "baseline":
                raw_diff_mask = g != base_g
                diff = field_diff_counts(g, base_g)
                diff["clock"] = int(np.count_nonzero(c != base_c))
                entry["world_diff"] = diff
                entry["region_diff"] = {}
                for region, mask in masks.items():
                    d = field_diff_counts(g[mask], base_g[mask])
                    d["clock"] = int(np.count_nonzero(c[mask] != base_c[mask]))
                    entry["region_diff"][region] = d
                    for field, value in d.items():
                        if value and first[name][region][field] is None:
                            first[name][region][field] = tick
                if np.any(raw_diff_mask):
                    max_dist = int(np.max(intervention_distance[raw_diff_mask]))
                    outside = int(np.count_nonzero(raw_diff_mask & (intervention_distance > 3 * tick)))
                else:
                    max_dist = None
                    outside = 0
                entry["raw_difference_max_distance_from_intervention"] = max_dist
                entry["raw_difference_outside_3t"] = outside
                if outside:
                    causal_violations[name].append({"tick": tick, "count": outside, "max_distance": max_dist})
            traces[name].append(entry)
        if tick < horizon:
            for u in universes.values():
                u.tick(1)

    for name, u in universes.items():
        g, c = native.snap(u)
        safe = f"N{n}_r{rep}_{name}"
        state_payload[f"{safe}_raw_tH"] = g
        state_payload[f"{safe}_clock_tH"] = c
        final_hashes[name] = {"raw": sha256_array(g), "clock": sha256_array(c)}

    response_words = {}
    for name in VARIANTS:
        word = [
            {
                "tick": item["tick"],
                "inner_occ": item["regions"]["inner_ball"]["occupancy"],
                "inner_sreg": item["regions"]["inner_ball"]["sreg_sum"],
                "inner_raw_nonzero": item["regions"]["inner_ball"]["raw_nonzero"],
                "middle_occ": item["regions"]["middle_ball"]["occupancy"],
                "middle_sreg": item["regions"]["middle_ball"]["sreg_sum"],
            }
            for item in traces[name]
        ]
        response_words[name] = {"sha256": canonical_hash(word), "word": word}

    return {
        "case_id": f"N{n}_rep{rep}",
        "role": "DISCOVERY",
        "spec": spec,
        "seed": seed,
        "construction": construction,
        "outer_intervention_sites": int(len(outer)),
        "matched_copy_audit": {
            "all_started_from_base_copy_before_declared_intervention": True,
            "same_inventory_joint_shuffle_outer_multiset_exact": bool(joint_inventory_exact),
            "same_inventory_joint_shuffle_geometry_changed": bool(shuffled_changed),
        },
        "initial_descriptors": descriptors,
        "first_divergence_vs_baseline": first,
        "causal_violations": causal_violations,
        "initial_hashes": initial_hashes,
        "final_hashes": final_hashes,
        "response_words": response_words,
        "traces": traces,
    }


def audit() -> dict:
    checks = {
        "wheel_exists": WHEEL_FILE.is_file(),
        "package_exists": PACKAGE_FILE.is_file(),
        "kernel_exists": KERNEL_FILE.is_file(),
        "discovery_label_literal": "DISCOVERY" in HERE.read_text(encoding="utf-8"),
        "no_holdout_output": "HOLDOUTS" not in str(OUT_JSON) and "HOLDOUT_LOCKS" not in str(OUT_JSON),
        "joint_inventory_control_present": "same_inventory_joint_shuffle" in VARIANTS,
        "causal_bound_audited": True,
        "variant_names_unique": len(VARIANTS) == len(set(VARIANTS)),
        "small_first_panel": max(int(x["N"]) for x in SPECS) <= 40,
    }
    observed = {}
    if all((WHEEL_FILE.is_file(), PACKAGE_FILE.is_file(), KERNEL_FILE.is_file())):
        observed = {
            "wheel": sha256_file(WHEEL_FILE),
            "package": sha256_file(PACKAGE_FILE),
            "kernel": sha256_file(KERNEL_FILE),
        }
        checks["identity_hashes_match"] = observed == EXPECTED
    return {
        "schema": "dee.v27.msd01.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "observed_hashes": observed,
        "runner_sha256": sha256_file(HERE),
        "planned_trajectories": sum(REPLICATES * len(VARIANTS) for _ in SPECS) + 1,
        "planned_universe_ticks": sum(REPLICATES * len(VARIANTS) * int(x["horizon"]) for x in SPECS) + int(SPECS[0]["horizon"]),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if static["status"] != "PASS":
        raise RuntimeError(f"static audit failed: {static}")

    started = time.perf_counter()
    native = Native(args.threads)
    cases = []
    state_payload: dict[str, np.ndarray] = {}
    for spec_index, spec in enumerate(SPECS):
        for rep in range(REPLICATES):
            seed = BASE_SEED + spec_index * 1000 + rep
            cases.append(run_case(native, dict(spec), rep, seed, state_payload))

    # One independent deterministic replay sentinel; it is not a new scientific case.
    sentinel_spec = dict(SPECS[0])
    sentinel_seed = BASE_SEED
    raw, clock, _, _ = make_base(sentinel_spec, sentinel_seed)
    u = native.new(raw, clock)
    for _ in range(int(sentinel_spec["horizon"])):
        u.tick(1)
    replay_raw, replay_clock = native.snap(u)
    reference = cases[0]["final_hashes"]["baseline"]
    replay = {"raw": sha256_array(replay_raw), "clock": sha256_array(replay_clock)}

    summary = {
        "case_count": len(cases),
        "trajectory_count": sum(len(VARIANTS) for _ in cases) + 1,
        "universe_ticks": sum(len(VARIANTS) * int(c["spec"]["horizon"]) for c in cases) + int(sentinel_spec["horizon"]),
        "N_values": sorted({int(c["spec"]["N"]) for c in cases}),
        "replicates_per_N": REPLICATES,
        "variants": list(VARIANTS),
        "all_joint_inventory_controls_exact": all(c["matched_copy_audit"]["same_inventory_joint_shuffle_outer_multiset_exact"] for c in cases),
        "all_joint_inventory_controls_changed_geometry": all(c["matched_copy_audit"]["same_inventory_joint_shuffle_geometry_changed"] for c in cases),
        "all_raw_differences_respect_3t": all(not rows for c in cases for rows in c["causal_violations"].values()),
        "deterministic_replay_pass": replay == reference,
        "replay_observed": replay,
        "replay_reference": reference,
    }
    result = {
        "schema": "dee.v27.multiscale.msd01.discovery.v1",
        "campaign": "MULTISCALE_ROSETTA_CLOSURE",
        "experiment_id": "MSD01",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE_NO_PREHOLDOUT_LOCK_BY_DESIGN",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "runner_sha256": sha256_file(HERE),
        "static_audit": static,
        "environment": native.environment,
        "design": {
            "question": "Which channel and compact routing/response descriptor mediates matched outer-to-inner influence on v27?",
            "null": "Inventory-only and exact joint-inventory shuffle controls.",
            "flexibility": "All channels, descriptors and response words are discovery; no primary metric selected.",
            "causal_rule": "Raw differences must remain within Chebyshev distance 3t from the initial intervention support.",
        },
        "summary": summary,
        "cases": cases,
    }
    OUT_NPZ.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(OUT_NPZ, **state_payload)
    result["state_archive"] = {
        "path": str(OUT_NPZ.relative_to(ROOT)).replace("\\", "/"),
        "sha256": sha256_file(OUT_NPZ),
        "arrays": len(state_payload),
    }
    result["elapsed_seconds"] = time.perf_counter() - started
    atomic_json(OUT_JSON, result)
    print(json.dumps({
        "status": "COMPLETE",
        "role": result["role"],
        "summary": summary,
        "output": str(OUT_JSON),
        "output_sha256": sha256_file(OUT_JSON),
        "state_archive_sha256": result["state_archive"]["sha256"],
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
