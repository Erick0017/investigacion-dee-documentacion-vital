#!/usr/bin/env python3
"""MSD02: discovery of compact predictors for DEE v27 sparse/dense regimes.

Fresh seeds are used, but all feature, model and threshold selection in this file
is discovery.  Its cross-validation is model-selection evidence, not a holdout.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
CORE_PATH = HERE.with_name("run_msd01_v27_discovery.py")
OUT = ROOT / "RESULTS" / "MSD02_results.json"
BASE_SEED = 270227100
SEEDS_PER_N = 10
SPECS = (
    {"N": 36, "radii": (4, 8, 13), "counts": (28, 56, 112), "horizon": 66},
    {"N": 40, "radii": (4, 9, 15), "counts": (32, 64, 128), "horizon": 72},
)
VARIANTS = ("baseline", "outer_semantic4", "same_inventory_joint_shuffle")
EARLY_TICKS = (0, 4, 8, 12, 16, 20)


def load_core():
    spec = importlib.util.spec_from_file_location("msd01_core", CORE_PATH)
    if spec is None or spec.loader is None:
        raise RuntimeError("cannot load MSD01 core")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


core = load_core()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def active_records(raw: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    f = core.fields(raw)
    mask = f["state"] > 0
    coords = np.argwhere(mask).astype(np.int16)
    dirs = np.column_stack([f["dx"][mask], f["dy"][mask], f["dz"][mask]]).astype(np.int16)
    return coords, dirs


def linear_indices(coords: np.ndarray, n: int) -> np.ndarray:
    return ((coords[:, 0].astype(np.int64) * n + coords[:, 1]) * n + coords[:, 2]).astype(np.int64)


def free_path_features(raw: np.ndarray, center: np.ndarray, n: int, inner_radius: int, horizon: int = 20) -> dict:
    coords, dirs = active_records(raw)
    max_collision_excess = 0
    max_multiplicity = 1 if len(coords) else 0
    max_collision_sites = 0
    max_neighbor_degree = 0
    max_ge6_sites = 0
    first_ge6_tick = None
    first_collision_tick = None
    total_inner_entries = 0
    min_unique_fraction = 1.0
    offsets = [
        (dx, dy, dz)
        for dx in (-1, 0, 1)
        for dy in (-1, 0, 1)
        for dz in (-1, 0, 1)
        if (dx, dy, dz) != (0, 0, 0)
    ]
    prior_inside = np.zeros(len(coords), dtype=bool)
    trajectory_rows = []
    for tick in range(1, min(horizon, 20) + 1):
        pos = ((coords.astype(np.int64) + tick * dirs.astype(np.int64)) % n).astype(np.int16)
        idx = linear_indices(pos, n)
        _, counts = np.unique(idx, return_counts=True)
        collision_excess = int(np.sum(counts - 1))
        collision_sites = int(np.count_nonzero(counts >= 2))
        multiplicity = int(np.max(counts)) if len(counts) else 0
        unique_fraction = float(len(counts) / max(1, len(pos)))
        points = {tuple(int(x) for x in q) for q in pos}
        degrees = []
        for q in points:
            degrees.append(sum((((q[0] + dx) % n, (q[1] + dy) % n, (q[2] + dz) % n) in points) for dx, dy, dz in offsets))
        ge6 = int(sum(d >= 6 for d in degrees))
        max_degree_tick = max(degrees) if degrees else 0
        delta = core.tor_delta(pos.astype(np.int64), center, n)
        inside = np.max(np.abs(delta), axis=1) <= inner_radius
        new_entries = int(np.count_nonzero(inside & ~prior_inside))
        total_inner_entries += new_entries
        prior_inside |= inside
        if collision_excess and first_collision_tick is None:
            first_collision_tick = tick
        if ge6 and first_ge6_tick is None:
            first_ge6_tick = tick
        max_collision_excess = max(max_collision_excess, collision_excess)
        max_multiplicity = max(max_multiplicity, multiplicity)
        max_collision_sites = max(max_collision_sites, collision_sites)
        max_neighbor_degree = max(max_neighbor_degree, max_degree_tick)
        max_ge6_sites = max(max_ge6_sites, ge6)
        min_unique_fraction = min(min_unique_fraction, unique_fraction)
        trajectory_rows.append({
            "tick": tick,
            "collision_excess": collision_excess,
            "collision_sites": collision_sites,
            "max_multiplicity": multiplicity,
            "unique_fraction": unique_fraction,
            "max_neighbor_degree": max_degree_tick,
            "ge6_sites": ge6,
            "new_inner_entries": new_entries,
        })
    return {
        "initial_carriers": int(len(coords)),
        "max_collision_excess_free20": max_collision_excess,
        "max_collision_sites_free20": max_collision_sites,
        "max_multiplicity_free20": max_multiplicity,
        "min_unique_fraction_free20": min_unique_fraction,
        "max_neighbor_degree_free20": max_neighbor_degree,
        "max_ge6_sites_free20": max_ge6_sites,
        "first_collision_tick_free20": first_collision_tick,
        "first_ge6_tick_free20": first_ge6_tick,
        "distinct_lineages_entering_inner20": total_inner_entries,
        "free_surrogate_trace": trajectory_rows,
    }


def actual_metrics(raw: np.ndarray, n: int, inner_mask: np.ndarray, middle_mask: np.ndarray) -> dict:
    f = core.fields(raw)
    occupied = f["state"] > 0
    return {
        "occupancy": int(np.count_nonzero(occupied)),
        "occupancy_fraction": float(np.count_nonzero(occupied) / n**3),
        "inner_occupancy": int(np.count_nonzero(occupied & inner_mask)),
        "middle_occupancy": int(np.count_nonzero(occupied & middle_mask)),
        "raw_nonzero": int(np.count_nonzero(raw)),
        "direction_nonzero": int(np.count_nonzero((f["dx"] != 0) | (f["dy"] != 0) | (f["dz"] != 0))),
        "semantic4": int(np.count_nonzero(f["semantic"] == 4)),
        "semantic7_xnor": int(np.count_nonzero(f["semantic"] == 7)),
        "sreg_sum": int(np.sum(f["sreg"], dtype=np.uint64)),
    }


def run_trajectory(native, spec: dict, seed: int, variant: str) -> dict:
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    base_raw, base_clock, layers, construction = core.make_base(spec, seed)
    all_variants = core.build_variants(base_raw, base_clock, layers[-1], seed)
    raw0, clock0 = all_variants[variant]
    center = np.array(construction["center"], dtype=np.int64)
    radius_grid = core.cheb_radius_grid(n, center)
    inner_mask = radius_grid <= int(spec["radii"][0])
    middle_mask = radius_grid <= int(spec["radii"][1])
    outer_descriptor = core.initial_descriptor(raw0, clock0, layers[-1], center, int(spec["radii"][0]), horizon, n)
    free_descriptor = free_path_features(raw0, center, n, int(spec["radii"][0]))
    u = native.new(raw0, clock0)
    trace = []
    for tick in range(horizon + 1):
        raw, clock = native.snap(u)
        metrics = actual_metrics(raw, n, inner_mask, middle_mask)
        metrics["tick"] = tick
        if tick in EARLY_TICKS or tick == horizon or tick % 4 == 0:
            metrics["raw_sha256"] = core.sha256_array(raw)
            metrics["clock_sha256"] = core.sha256_array(clock)
        trace.append(metrics)
        if tick < horizon:
            u.tick(1)
    final = trace[-1]
    initial_joint = outer_descriptor["joint_raw_clock_multiset_sha256"]
    return {
        "row_id": f"N{n}_seed{seed}_{variant}",
        "group_id": f"N{n}_seed{seed}",
        "N": n,
        "seed": seed,
        "variant": variant,
        "horizon": horizon,
        "initial_raw_sha256": core.sha256_array(raw0),
        "initial_clock_sha256": core.sha256_array(clock0),
        "initial_outer_joint_inventory_sha256": initial_joint,
        "initial_outer_descriptor": outer_descriptor,
        "initial_free_path_descriptor": free_descriptor,
        "trace": trace,
        "final_occupancy_fraction": final["occupancy_fraction"],
        "dense_label_ge_0_5": int(final["occupancy_fraction"] >= 0.5),
        "final_raw_sha256": final["raw_sha256"],
        "final_clock_sha256": final["clock_sha256"],
    }


def flatten_features(row: dict) -> dict[str, float]:
    outer = row["initial_outer_descriptor"]
    free = row["initial_free_path_descriptor"]
    trace = {int(x["tick"]): x for x in row["trace"]}
    out = {
        "inventory_N": float(row["N"]),
        "inventory_initial_carriers": float(free["initial_carriers"]),
        "inventory_outer_sreg_sum": float(outer["sreg_sum"]),
        "inventory_outer_semantic4": float(outer["semantic4_count"]),
        "inventory_outer_direction_zero": float(outer["direction_zero_count"]),
        "organization_inward_alignment": float(outer["inward_axis_alignment"]),
        "organization_radial_flux": float(outer["radial_flux"]),
        "organization_straight_inner_hits": float(outer["straight_line_inner_hits"]),
        "organization_free_collision_excess": float(free["max_collision_excess_free20"]),
        "organization_free_collision_sites": float(free["max_collision_sites_free20"]),
        "organization_free_max_multiplicity": float(free["max_multiplicity_free20"]),
        "organization_free_min_unique_fraction": float(free["min_unique_fraction_free20"]),
        "organization_free_max_neighbor_degree": float(free["max_neighbor_degree_free20"]),
        "organization_free_max_ge6": float(free["max_ge6_sites_free20"]),
        "organization_free_inner_entries": float(free["distinct_lineages_entering_inner20"]),
    }
    for tick in EARLY_TICKS[1:]:
        m = trace[tick]
        out[f"early_occ_fraction_t{tick}"] = float(m["occupancy_fraction"])
        out[f"early_inner_occ_t{tick}"] = float(m["inner_occupancy"])
        out[f"early_xnor_fraction_t{tick}"] = float(m["semantic7_xnor"] / row["N"] ** 3)
        out[f"early_direction_fraction_t{tick}"] = float(m["direction_nonzero"] / row["N"] ** 3)
    out["early_growth_t8_to_t16"] = out["early_occ_fraction_t16"] - out["early_occ_fraction_t8"]
    out["early_growth_t12_to_t20"] = out["early_occ_fraction_t20"] - out["early_occ_fraction_t12"]
    return out


def best_stump(train: list[tuple[float, int]]) -> tuple[float, int]:
    xs = sorted({float(x) for x, _ in train})
    if len(xs) == 1:
        thresholds = [xs[0]]
    else:
        thresholds = [xs[0] - 1e-12] + [(a + b) / 2 for a, b in zip(xs, xs[1:])] + [xs[-1] + 1e-12]
    best = None
    for direction in (1, -1):
        for threshold in thresholds:
            pred = [int(direction * (x - threshold) >= 0) for x, _ in train]
            error = sum(int(p != y) for p, (_, y) in zip(pred, train))
            candidate = (error, abs(threshold), threshold, direction)
            if best is None or candidate < best:
                best = candidate
    assert best is not None
    return float(best[2]), int(best[3])


def scores(y: list[int], pred: list[int]) -> dict:
    correct = sum(int(a == b) for a, b in zip(y, pred))
    tpr_values = []
    for klass in (0, 1):
        idx = [i for i, value in enumerate(y) if value == klass]
        if idx:
            tpr_values.append(sum(int(pred[i] == klass) for i in idx) / len(idx))
    return {
        "n": len(y),
        "accuracy": correct / max(1, len(y)),
        "balanced_accuracy": sum(tpr_values) / max(1, len(tpr_values)),
        "errors": len(y) - correct,
        "confusion": {
            "tn": sum(int(a == 0 and b == 0) for a, b in zip(y, pred)),
            "fp": sum(int(a == 0 and b == 1) for a, b in zip(y, pred)),
            "fn": sum(int(a == 1 and b == 0) for a, b in zip(y, pred)),
            "tp": sum(int(a == 1 and b == 1) for a, b in zip(y, pred)),
        },
    }


def group_cv(rows: list[dict], feature: str) -> dict:
    groups = sorted({row["group_id"] for row in rows})
    predictions: dict[str, int] = {}
    fold_models = []
    for group in groups:
        train_rows = [row for row in rows if row["group_id"] != group]
        test_rows = [row for row in rows if row["group_id"] == group]
        threshold, direction = best_stump([(row["features"][feature], row["dense_label_ge_0_5"]) for row in train_rows])
        fold_models.append({"test_group": group, "threshold": threshold, "direction": direction})
        for row in test_rows:
            predictions[row["row_id"]] = int(direction * (row["features"][feature] - threshold) >= 0)
    y = [int(row["dense_label_ge_0_5"]) for row in rows]
    pred = [predictions[row["row_id"]] for row in rows]
    result = scores(y, pred)
    result.update({"feature": feature, "folds": len(groups), "fold_models": fold_models})
    return result


def majority_group_cv(rows: list[dict]) -> dict:
    groups = sorted({row["group_id"] for row in rows})
    predictions = {}
    for group in groups:
        train = [int(row["dense_label_ge_0_5"]) for row in rows if row["group_id"] != group]
        majority = int(sum(train) * 2 >= len(train))
        for row in rows:
            if row["group_id"] == group:
                predictions[row["row_id"]] = majority
    y = [int(row["dense_label_ge_0_5"]) for row in rows]
    pred = [predictions[row["row_id"]] for row in rows]
    out = scores(y, pred)
    out["model"] = "training_fold_majority"
    return out


def analyse(rows: list[dict]) -> dict:
    for row in rows:
        row["features"] = flatten_features(row)
    feature_names = sorted(rows[0]["features"])
    cv = [group_cv(rows, feature) for feature in feature_names]
    categories = {
        "inventory": [x for x in cv if x["feature"].startswith("inventory_")],
        "organization": [x for x in cv if x["feature"].startswith("organization_")],
        "early_response": [x for x in cv if x["feature"].startswith("early_")],
    }
    best = {
        name: sorted(values, key=lambda x: (-x["balanced_accuracy"], x["errors"], x["feature"]))[0]
        for name, values in categories.items()
        if values
    }
    fractions = sorted(float(row["final_occupancy_fraction"]) for row in rows)
    gaps = [(b - a, a, b) for a, b in zip(fractions, fractions[1:])]
    largest_gap = max(gaps) if gaps else (0.0, fractions[0], fractions[0])
    grouped = {}
    crossings = Counter()
    for group in sorted({row["group_id"] for row in rows}):
        arms = {row["variant"]: row for row in rows if row["group_id"] == group}
        labels = {name: int(row["dense_label_ge_0_5"]) for name, row in arms.items()}
        grouped[group] = {
            "labels": labels,
            "final_fractions": {name: row["final_occupancy_fraction"] for name, row in arms.items()},
            "joint_inventory_baseline_equals_shuffle": arms["baseline"]["initial_outer_joint_inventory_sha256"] == arms["same_inventory_joint_shuffle"]["initial_outer_joint_inventory_sha256"],
        }
        crossings[f"baseline_{labels['baseline']}_to_semantic4_{labels['outer_semantic4']}"] += 1
        crossings[f"baseline_{labels['baseline']}_to_shuffle_{labels['same_inventory_joint_shuffle']}"] += 1
    return {
        "dense_definition_discovery": "terminal occupancy fraction >= 0.5",
        "class_counts": dict(Counter(int(row["dense_label_ge_0_5"]) for row in rows)),
        "terminal_fraction_min": min(fractions),
        "terminal_fraction_max": max(fractions),
        "largest_adjacent_gap": {"width": largest_gap[0], "lower": largest_gap[1], "upper": largest_gap[2], "midpoint": (largest_gap[1] + largest_gap[2]) / 2},
        "majority_group_cv": majority_group_cv(rows),
        "all_single_feature_group_cv": cv,
        "best_by_category": best,
        "groups": grouped,
        "crossing_counts": dict(crossings),
        "flexibility_warning": "Feature categories, dense threshold and stumps were evaluated after MSD01 signal; every score is discovery/model-selection evidence only.",
    }


def audit() -> dict:
    checks = {
        "core_exists": CORE_PATH.is_file(),
        "fresh_seed_range": BASE_SEED > core.BASE_SEED + 1000,
        "discovery_only_literal": "discovery" in __doc__.lower(),
        "no_holdout_path": "HOLDOUT" not in str(OUT),
        "grouped_cv": True,
        "variant_set_exact": set(VARIANTS) == {"baseline", "outer_semantic4", "same_inventory_joint_shuffle"},
        "early_ticks_precede_horizon": max(EARLY_TICKS) < min(int(x["horizon"]) for x in SPECS),
    }
    return {
        "schema": "dee.v27.msd02.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "runner_sha256": sha256_file(HERE),
        "core_sha256": sha256_file(CORE_PATH),
        "planned_trajectories": len(SPECS) * SEEDS_PER_N * len(VARIANTS),
        "planned_universe_ticks": sum(SEEDS_PER_N * len(VARIANTS) * int(spec["horizon"]) for spec in SPECS),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if static["status"] != "PASS":
        raise RuntimeError(static)
    started = time.perf_counter()
    native = core.Native(args.threads)
    rows = []
    for spec_index, spec in enumerate(SPECS):
        for seed_index in range(SEEDS_PER_N):
            seed = BASE_SEED + spec_index * 1000 + seed_index
            for variant in VARIANTS:
                rows.append(run_trajectory(native, dict(spec), seed, variant))
    analysis = analyse(rows)
    result = {
        "schema": "dee.v27.multiscale.msd02.basin_discovery.v1",
        "experiment_id": "MSD02",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE_NO_PREHOLDOUT_LOCK_BY_DESIGN",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "runner_sha256": sha256_file(HERE),
        "core_sha256": sha256_file(CORE_PATH),
        "static_audit": static,
        "environment": native.environment,
        "design": {
            "specs": SPECS,
            "seeds_per_N": SEEDS_PER_N,
            "variants": VARIANTS,
            "early_ticks": EARLY_TICKS,
            "baselines": ["grouped majority", "inventory-only stumps", "organization stumps", "early-response stumps"],
            "null": "same joint outer raw+clock inventory with shuffled organization",
        },
        "summary": {
            "trajectories": len(rows),
            "universe_ticks": sum(int(row["horizon"]) for row in rows),
            "N_values": sorted({int(row["N"]) for row in rows}),
            "seed_groups": len({row["group_id"] for row in rows}),
            "all_joint_inventory_controls_exact": all(x["joint_inventory_baseline_equals_shuffle"] for x in analysis["groups"].values()),
        },
        "analysis": analysis,
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "role": result["role"],
        "summary": result["summary"],
        "class_counts": analysis["class_counts"],
        "largest_gap": analysis["largest_adjacent_gap"],
        "majority_cv": analysis["majority_group_cv"],
        "best_by_category": {k: {"feature": v["feature"], "accuracy": v["accuracy"], "balanced_accuracy": v["balanced_accuracy"], "errors": v["errors"]} for k, v in analysis["best_by_category"].items()},
        "crossings": analysis["crossing_counts"],
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
