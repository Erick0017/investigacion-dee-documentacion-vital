#!/usr/bin/env python3
"""MSD03 discovery: distinguish sparse recurrence from delayed dense ignition."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
MSD02_RUNNER = HERE.with_name("run_msd02_basin_discovery.py")
MSD02_RESULT = ROOT / "RESULTS" / "MSD02_results.json"
OUT = ROOT / "RESULTS" / "MSD03_results.json"
EXPECTED_MSD02_SHA = "52769b58346f23cab9e1f19eda1c2197878ec77e8f827c275b9118ff9b1615df"
MAX_TICK = 512
THRESHOLDS = (0.01, 0.1, 0.5, 0.9)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


msd02 = load_module(MSD02_RUNNER, "msd02_core")
core = msd02.core


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def projection_hashes(raw: np.ndarray) -> dict[str, str]:
    f = core.fields(raw)
    occupancy = f["state"] > 0
    direction = np.stack([f["dx"], f["dy"], f["dz"]], axis=-1)
    return {
        "raw": core.sha256_array(raw),
        "occupancy": core.sha256_array(occupancy),
        "direction": core.sha256_array(direction),
        "sreg": core.sha256_array(f["sreg"]),
        "semantic": core.sha256_array(f["semantic"]),
    }


def tail_period(sequence: list[str], max_period: int, repeats: int = 3) -> int | None:
    length = len(sequence)
    for period in range(1, min(max_period, length // repeats) + 1):
        block = sequence[-period:]
        if all(sequence[-(k + 1) * period : -k * period if k else None] == block for k in range(repeats)):
            return period
    return None


def select_rows(msd02_result: dict) -> list[dict]:
    rows = msd02_result["rows"]
    selected: dict[str, dict] = {}
    for row in rows:
        if int(row["dense_label_ge_0_5"]) == 0:
            selected[row["row_id"]] = {"source": row, "reason": "all_finite_horizon_low_or_censored"}
    for n in sorted({int(row["N"]) for row in rows}):
        positive = [row for row in rows if int(row["N"]) == n and int(row["dense_label_ge_0_5"]) == 1]
        low = min(positive, key=lambda row: (float(row["final_occupancy_fraction"]), row["row_id"]))
        high = max(positive, key=lambda row: (float(row["final_occupancy_fraction"]), row["row_id"]))
        selected.setdefault(low["row_id"], {"source": low, "reason": "lowest_high_control_for_N"})
        selected.setdefault(high["row_id"], {"source": high, "reason": "highest_high_control_for_N"})
    return [selected[key] for key in sorted(selected)]


def reconstruct_initial(source: dict) -> tuple[dict, np.ndarray, np.ndarray, dict]:
    spec = next(dict(item) for item in msd02.SPECS if int(item["N"]) == int(source["N"]))
    raw, clock, layers, construction = core.make_base(spec, int(source["seed"]))
    variants = core.build_variants(raw, clock, layers[-1], int(source["seed"]))
    raw0, clock0 = variants[source["variant"]]
    if core.sha256_array(raw0) != source["initial_raw_sha256"] or core.sha256_array(clock0) != source["initial_clock_sha256"]:
        raise RuntimeError(f"initial reconstruction mismatch for {source['row_id']}")
    return spec, raw0, clock0, construction


def run_long(native, selection: dict) -> dict:
    source = selection["source"]
    spec, raw0, clock0, construction = reconstruct_initial(source)
    n = int(spec["N"])
    center = np.array(construction["center"], dtype=np.int64)
    radius_grid = core.cheb_radius_grid(n, center)
    inner = radius_grid <= int(spec["radii"][0])
    middle = radius_grid <= int(spec["radii"][1])
    u = native.new(raw0, clock0)
    trace = []
    sequences = {name: [] for name in ("raw", "occupancy", "direction", "sreg", "semantic")}
    first_passage = {str(value): None for value in THRESHOLDS}
    overlap = None
    measurement_tick = int(np.ceil(n / 2))
    measurement = None
    prior_horizon = int(source["horizon"])
    for tick in range(MAX_TICK + 1):
        raw, clock = native.snap(u)
        metric = msd02.actual_metrics(raw, n, inner, middle)
        hashes = projection_hashes(raw)
        for name, value in hashes.items():
            sequences[name].append(value)
        fraction = float(metric["occupancy_fraction"])
        for threshold in THRESHOLDS:
            if first_passage[str(threshold)] is None and fraction >= threshold:
                first_passage[str(threshold)] = tick
        if tick == measurement_tick:
            measurement = {
                "tick": tick,
                "active_routing_density": float(metric["direction_nonzero"] / n**3),
                "occupancy_fraction": fraction,
                "xnor_fraction": float(metric["semantic7_xnor"] / n**3),
            }
        if tick == prior_horizon:
            overlap = {
                "raw_observed": hashes["raw"],
                "raw_expected": source["final_raw_sha256"],
                "clock_observed": core.sha256_array(clock),
                "clock_expected": source["final_clock_sha256"],
            }
            overlap["pass"] = overlap["raw_observed"] == overlap["raw_expected"] and overlap["clock_observed"] == overlap["clock_expected"]
        if tick % 4 == 0 or tick in (measurement_tick, prior_horizon, MAX_TICK):
            trace.append({"tick": tick, **metric, **{f"{name}_sha256": value for name, value in hashes.items()}})
        if tick < MAX_TICK:
            u.tick(1)
    if overlap is None or not overlap["pass"]:
        raise RuntimeError(f"MSD02 overlap verification failed for {source['row_id']}: {overlap}")
    tail_window = trace[-min(len(trace), 2 * n) :]
    tail_fractions = [float(item["occupancy_fraction"]) for item in tail_window]
    periods = {name: tail_period(sequence, 2 * n, 3) for name, sequence in sequences.items()}
    final_fraction = float(trace[-1]["occupancy_fraction"])
    if final_fraction >= 0.9 and min(tail_fractions) >= 0.9:
        classification = "DENSE_PERSISTENT_TO_512"
    elif final_fraction <= 0.01 and max(tail_fractions) <= 0.01 and periods["raw"] is not None:
        classification = "SPARSE_RAW_PERIODIC_TO_512"
    elif final_fraction <= 0.01 and max(tail_fractions) <= 0.01:
        classification = "SPARSE_BOUNDED_TO_512"
    else:
        classification = "INTERMEDIATE_OR_TRANSIENT_AT_512"
    return {
        "row_id": source["row_id"],
        "selection_reason": selection["reason"],
        "N": n,
        "seed": int(source["seed"]),
        "variant": source["variant"],
        "prior_horizon": prior_horizon,
        "overlap_verification": overlap,
        "measurement": measurement,
        "first_passage": first_passage,
        "projection_tail_periods": periods,
        "tail_occupancy_fraction_min": min(tail_fractions),
        "tail_occupancy_fraction_max": max(tail_fractions),
        "final_occupancy_fraction": final_fraction,
        "classification": classification,
        "trace": trace,
    }


def audit() -> dict:
    checks = {
        "msd02_runner_exists": MSD02_RUNNER.is_file(),
        "msd02_result_exists": MSD02_RESULT.is_file(),
        "msd02_result_hash_matches": MSD02_RESULT.is_file() and sha256_file(MSD02_RESULT) == EXPECTED_MSD02_SHA,
        "discovery_only": "discovery" in __doc__.lower(),
        "extension_beyond_clock391": MAX_TICK > 391,
        "overlap_verification_implemented": True,
        "projection_recurrence_implemented": True,
    }
    selected_count = 0
    if checks["msd02_result_hash_matches"]:
        selected_count = len(select_rows(json.loads(MSD02_RESULT.read_text(encoding="utf-8"))))
    return {
        "schema": "dee.v27.msd03.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "runner_sha256": sha256_file(HERE),
        "msd02_runner_sha256": sha256_file(MSD02_RUNNER),
        "selected_trajectories": selected_count,
        "planned_universe_ticks": selected_count * MAX_TICK,
        "max_tick": MAX_TICK,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if static["status"] != "PASS":
        raise RuntimeError(static)
    started = time.perf_counter()
    prior = json.loads(MSD02_RESULT.read_text(encoding="utf-8"))
    selections = select_rows(prior)
    native = core.Native(args.threads)
    rows = [run_long(native, selection) for selection in selections]
    classes = {}
    for row in rows:
        classes[row["classification"]] = classes.get(row["classification"], 0) + 1
    delayed = [row["row_id"] for row in rows if row["first_passage"]["0.5"] is not None and int(row["first_passage"]["0.5"]) > int(row["prior_horizon"])]
    stable_sparse = [row["row_id"] for row in rows if row["classification"].startswith("SPARSE_")]
    result = {
        "schema": "dee.v27.multiscale.msd03.long_horizon_discovery.v1",
        "experiment_id": "MSD03",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE_NO_PREHOLDOUT_LOCK_BY_DESIGN",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "static_audit": static,
        "runner_sha256": sha256_file(HERE),
        "msd02_result_sha256": sha256_file(MSD02_RESULT),
        "environment": native.environment,
        "summary": {
            "trajectories": len(rows),
            "universe_ticks": len(rows) * MAX_TICK,
            "all_overlap_verifications_pass": all(row["overlap_verification"]["pass"] for row in rows),
            "class_counts": classes,
            "delayed_crossing_count": len(delayed),
            "delayed_crossing_rows": delayed,
            "sparse_to_512_count": len(stable_sparse),
            "sparse_to_512_rows": stable_sparse,
        },
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "role": result["role"],
        "summary": result["summary"],
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
