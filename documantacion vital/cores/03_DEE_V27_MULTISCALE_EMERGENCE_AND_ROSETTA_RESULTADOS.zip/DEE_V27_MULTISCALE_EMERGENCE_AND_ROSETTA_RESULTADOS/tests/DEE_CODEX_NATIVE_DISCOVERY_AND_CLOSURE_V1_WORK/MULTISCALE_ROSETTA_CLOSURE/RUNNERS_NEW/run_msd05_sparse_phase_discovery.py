#!/usr/bin/env python3
"""MSD05: discovery of projected recurrence structure in MSH01 non-dense rows."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
MSH01 = ROOT / "HOLDOUTS" / "MSH01_results.json"
MSH01_LOCK = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json"
CORE_RUNNER = HERE.with_name("run_msd02_basin_discovery.py")
FOUNDATION_RUNNER = HERE.with_name("run_msd01_v27_discovery.py")
OUT = ROOT / "RESULTS" / "MSD05_results.json"
EXPECTED = {
    "msh01": "c87eff9a9ab54531d82922141e9d9976876953ae4c894d72f0758a12fa81c67f",
    "msh01_lock": "6c5ee4b7d4e0b2f5d2be91e6be0ef4aadfa6a384d54ba41a139b3dc32fd353ee",
    "core_runner": "c79de8d09e9063a074d97fad1f892cdf057ff137e3bb99c1a5f5399ef89e8fe1",
    "foundation_runner": "133106a495ab684ee4d49b6dace76570a25585b19515f4116a167db5fc22cb45",
}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


msd02 = load_module(CORE_RUNNER, "msd05_core")
core = msd02.core


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def exact_tail_period(sequence: list[str], max_period: int, repeats: int = 3) -> int | None:
    for period in range(1, min(max_period, len(sequence) // repeats) + 1):
        block = sequence[-period:]
        if all(sequence[-(index + 1) * period : -index * period if index else None] == block for index in range(repeats)):
            return period
    return None


def translation_canonical_hash(mask: np.ndarray, values: np.ndarray | None = None) -> str:
    n = int(mask.shape[0])
    coords = np.argwhere(mask).astype(np.int64)
    if len(coords) == 0:
        return hashlib.sha256(b"EMPTY").hexdigest()
    selected = None if values is None else np.asarray(values[mask], dtype="<u8")
    best: bytes | None = None
    for anchor in coords:
        shifted = (coords - anchor) % n
        linear = ((shifted[:, 0] * n + shifted[:, 1]) * n + shifted[:, 2]).astype("<u4")
        order = np.argsort(linear, kind="stable")
        candidate = linear[order].tobytes()
        if selected is not None:
            candidate += selected[order].tobytes()
        if best is None or candidate < best:
            best = candidate
    return hashlib.sha256(best).hexdigest()


def row_case_spec(contract: dict, n: int) -> dict:
    source = next(item for item in contract["case_specs"] if int(item["N"]) == n)
    return {
        "N": n,
        "radii": tuple(int(value) for value in source["radii"]),
        "counts": tuple(int(value) for value in source["counts"]),
        "horizon": 16 * n,
    }


def reconstruct(source: dict, contract: dict):
    spec = row_case_spec(contract, int(source["N"]))
    raw, clock, layers, construction = core.make_base(spec, int(source["seed"]))
    variants = core.build_variants(raw, clock, layers[-1], int(source["seed"]))
    return spec, variants[source["variant"]], construction


def projection_record(raw: np.ndarray, clock: np.ndarray) -> dict:
    fields = core.fields(raw)
    positive = fields["state"] > 0
    nonzero = raw != 0
    direction_code = (fields["dx"].astype(np.int16) + 1) * 9 + (fields["dy"].astype(np.int16) + 1) * 3 + fields["dz"].astype(np.int16) + 1
    return {
        "raw": core.sha256_array(raw),
        "clock": core.sha256_array(clock),
        "positive_mask": core.sha256_array(positive.astype(np.uint8)),
        "state": core.sha256_array(fields["state"]),
        "direction": core.sha256_array(direction_code.astype(np.uint8)),
        "sreg": core.sha256_array(fields["sreg"]),
        "semantic": core.sha256_array(fields["semantic"]),
        "positive_shape_translation_canonical": translation_canonical_hash(positive),
        "raw_pattern_translation_canonical": translation_canonical_hash(nonzero, raw),
        "positive_count": int(np.count_nonzero(positive)),
        "raw_nonzero": int(np.count_nonzero(nonzero)),
        "direction_nonzero": int(np.count_nonzero((fields["dx"] != 0) | (fields["dy"] != 0) | (fields["dz"] != 0))),
        "sreg_sum": int(np.sum(fields["sreg"], dtype=np.uint64)),
        "semantic4": int(np.count_nonzero(fields["semantic"] == 4)),
    }


def run_row(native, source: dict, contract: dict) -> dict:
    spec, (raw0, clock0), construction = reconstruct(source, contract)
    n = int(spec["N"])
    msh_horizon = 4 * n
    max_tick = 16 * n
    expected_at_4n = next(item for item in source["trace"] if int(item["tick"]) == msh_horizon)
    universe = native.new(raw0, clock0)
    sequences = {name: [] for name in (
        "raw", "positive_mask", "state", "direction", "sreg", "semantic",
        "positive_shape_translation_canonical", "raw_pattern_translation_canonical",
    )}
    counts = {name: [] for name in ("positive_count", "raw_nonzero", "direction_nonzero", "sreg_sum", "semantic4")}
    trace = []
    overlap = None
    first_05_after_4n = None
    for tick in range(max_tick + 1):
        raw, clock = native.snap(universe)
        if tick >= msh_horizon:
            record = projection_record(raw, clock)
            for name in sequences:
                sequences[name].append(record[name])
            for name in counts:
                counts[name].append(record[name])
            if tick == msh_horizon:
                overlap = {
                    "raw_expected": expected_at_4n["raw_sha256"],
                    "raw_observed": record["raw"],
                    "clock_expected": expected_at_4n["clock_sha256"],
                    "clock_observed": record["clock"],
                }
                overlap["pass"] = overlap["raw_expected"] == overlap["raw_observed"] and overlap["clock_expected"] == overlap["clock_observed"]
            fraction = record["positive_count"] / n**3
            if first_05_after_4n is None and fraction >= 0.5:
                first_05_after_4n = tick
            if tick % n == 0 or tick in (msh_horizon, max_tick):
                trace.append({"tick": tick, **record})
        if tick < max_tick:
            universe.tick(1)
    if overlap is None or not overlap["pass"]:
        raise RuntimeError(f"MSH01 overlap mismatch for {source['row_id']}")
    periods = {name: exact_tail_period(values, 4 * n, 3) for name, values in sequences.items()}
    constant_counts = {name: len(set(values)) == 1 for name, values in counts.items()}
    if first_05_after_4n is not None:
        class16 = "DELAYED_DENSE_AFTER_4N"
    elif periods["raw"] is not None:
        class16 = "RAW_PERIODIC_BY_16N"
    elif periods["positive_mask"] is not None or periods["positive_shape_translation_canonical"] is not None:
        class16 = "GEOMETRIC_RECURRENCE_WITHOUT_RAW_RECURRENCE_BY_16N"
    else:
        class16 = "BOUNDED_NON_DENSE_NO_PERIOD_LE_4N_BY_16N"
    return {
        "row_id": source["row_id"],
        "source_observed_4N": source["observed"],
        "N": n,
        "seed": int(source["seed"]),
        "variant": source["variant"],
        "max_tick": max_tick,
        "initial_raw_sha256": core.sha256_array(raw0),
        "initial_clock_sha256": core.sha256_array(clock0),
        "overlap_4N": overlap,
        "first_passage_0_5_after_4N": first_05_after_4n,
        "tail_periods_max_4N_three_repeats": periods,
        "counts_constant_from_4N": constant_counts,
        "count_ranges_from_4N": {name: [min(values), max(values)] for name, values in counts.items()},
        "classification_16N": class16,
        "trace_at_multiples_of_N": trace,
        "construction": construction,
    }


def audit() -> dict:
    input_hashes = {
        "msh01": sha256_file(MSH01),
        "msh01_lock": sha256_file(MSH01_LOCK),
        "core_runner": sha256_file(CORE_RUNNER),
        "foundation_runner": sha256_file(FOUNDATION_RUNNER),
    }
    msh01 = json.loads(MSH01.read_text(encoding="utf-8"))
    selected = [row for row in msh01["rows"] if row["observed"] != "DENSE_RAW_FIXED_WINDOW"]
    checks = {
        "input_hashes_match": input_hashes == EXPECTED,
        "msh01_verdict_preserved": msh01["primary_adjudication"]["verdict"] == "INCONCLUSIVE_CLASS_DIVERSITY",
        "selected_exactly_all_non_dense": len(selected) == 9,
        "selected_other_four": sum(row["observed"] == "OTHER" for row in selected) == 4,
        "selected_sparse_five": sum(row["observed"] == "SPARSE_RAW_PERIOD_N_WINDOW" for row in selected) == 5,
        "output_absent": not OUT.exists(),
        "discovery_only": True,
    }
    return {
        "schema": "dee.v27.msd05.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "input_hashes": input_hashes,
        "runner_sha256": sha256_file(HERE),
        "selected_rows": [row["row_id"] for row in selected],
        "planned_trajectories": len(selected),
        "planned_universe_ticks": sum(16 * int(row["N"]) for row in selected),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if static["status"] != "PASS":
        raise RuntimeError(f"static audit failed: {static}")
    msh01 = json.loads(MSH01.read_text(encoding="utf-8"))
    selected = [row for row in msh01["rows"] if row["observed"] != "DENSE_RAW_FIXED_WINDOW"]
    native = core.Native(args.threads)
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    rows = [run_row(native, row, msh01["contract"]) for row in selected]
    class_counts = {name: sum(row["classification_16N"] == name for row in rows) for name in sorted({row["classification_16N"] for row in rows})}
    result = {
        "schema": "dee.v27.multiscale.msd05.sparse_phase_discovery.v1",
        "experiment_id": "MSD05",
        "role": "DISCOVERY_AFTER_FROZEN_INCONCLUSIVE",
        "confirmatory_status": "NOT_ELIGIBLE",
        "started_utc": started_utc,
        "runner_sha256": sha256_file(HERE),
        "input_hashes": static["input_hashes"],
        "static_audit": static,
        "environment": native.environment,
        "summary": {
            "trajectories": len(rows),
            "universe_ticks": sum(row["max_tick"] for row in rows),
            "all_4N_overlap_checks_pass": all(row["overlap_4N"]["pass"] for row in rows),
            "classification_counts": class_counts,
            "delayed_dense_after_4N": sum(row["first_passage_0_5_after_4N"] is not None for row in rows),
            "raw_periods": {row["row_id"]: row["tail_periods_max_4N_three_repeats"]["raw"] for row in rows},
            "positive_mask_periods": {row["row_id"]: row["tail_periods_max_4N_three_repeats"]["positive_mask"] for row in rows},
            "translation_canonical_raw_periods": {row["row_id"]: row["tail_periods_max_4N_three_repeats"]["raw_pattern_translation_canonical"] for row in rows},
        },
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "summary": result["summary"],
        "elapsed_seconds": result["elapsed_seconds"],
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
