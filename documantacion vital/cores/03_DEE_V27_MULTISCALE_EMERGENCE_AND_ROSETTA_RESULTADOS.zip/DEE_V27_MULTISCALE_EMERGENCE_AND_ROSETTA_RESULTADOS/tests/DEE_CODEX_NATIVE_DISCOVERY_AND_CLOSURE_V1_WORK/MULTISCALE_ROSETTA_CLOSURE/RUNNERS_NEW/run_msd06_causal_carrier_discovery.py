#!/usr/bin/env python3
"""MSD06: two-stage causal discovery of positive support versus routing.

Stage A intervenes on the initial outer shell and runs only to t=N. It asks
which outer input fields generate the candidate measurements. Stage B starts
from the unmodified baseline snapshot at t=N and deletes state and direction
fields factorially over the whole torus, then follows each branch to t=8N. A
fifth branch permutes direction words while preserving q, every state value,
direction support and its vector histogram. A small, explicitly selected
pre-crossing panel at N=37 is followed only to 2N.

All cases were opened before this runner was written. This is causal discovery
on deterministic counterfactuals, not holdout confirmation and not evidence
that off-manifold field deletions are physically preparable.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
FOUNDATION_RUNNER = HERE.with_name("run_msd01_v27_discovery.py")
CORE_RUNNER = HERE.with_name("run_msd02_basin_discovery.py")
MSH01_LOCK = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json"
MSH01 = ROOT / "HOLDOUTS" / "MSH01_results.json"
MSD05 = ROOT / "RESULTS" / "MSD05_results.json"
MSA05 = ROOT / "ANALYSIS" / "MSD05_REFINED_LAW_DISCOVERY.json"
OUT = ROOT / "RESULTS" / "MSD06_results.json"

EXPECTED = {
    "foundation_runner": "133106a495ab684ee4d49b6dace76570a25585b19515f4116a167db5fc22cb45",
    "core_runner": "c79de8d09e9063a074d97fad1f892cdf057ff137e3bb99c1a5f5399ef89e8fe1",
    "msh01_lock": "6c5ee4b7d4e0b2f5d2be91e6be0ef4aadfa6a384d54ba41a139b3dc32fd353ee",
    "msh01": "c87eff9a9ab54531d82922141e9d9976876953ae4c894d72f0758a12fa81c67f",
    "msd05": "11178ba62e0ada18274688a3a75db8ca181d196f6798ee2ef036b3cb5cd50eba",
    "msa05": "ab372218845e62a743265436c8c242e489845172d9b931be3b5bd6663c644266",
}
LONG_GROUPS = {
    35: (270427350, 270427354, 270427355),
    37: (270427370, 270427372, 270427374),
}
PRECURSOR_CONTEXTS = ((37, 270427375, "baseline"), (37, 270427375, "same_inventory_joint_shuffle"))
FACTORIAL_ARMS = ("full", "direction0", "state0_keep_direction", "state0_direction0_keep_metadata")
OUTER_ARMS = FACTORIAL_ARMS + ("ablate",)
SNAPSHOT_ARMS = FACTORIAL_ARMS + ("direction_permutation",)

DIRECTION_MASK = np.uint64(0x0FFF000000000000)
CLEAR_STATE = np.uint64(0xFFFFFFFF00000000)
CLEAR_DIRECTION = np.uint64(0xF000FFFFFFFFFFFF)
CLEAR_STATE_AND_DIRECTION = np.uint64(0xF000FFFF00000000)
CONTRASTS = {
    "direction_when_state_present": ("full", "direction0"),
    "state_when_direction_present": ("full", "state0_keep_direction"),
    "direction_when_state_absent": ("state0_keep_direction", "state0_direction0_keep_metadata"),
    "state_when_direction_absent": ("direction0", "state0_direction0_keep_metadata"),
}


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


msd02 = load_module(CORE_RUNNER, "msd06_core")
core = msd02.core


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def atomic_json(path: Path, value: dict) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def make_spec(contract: dict, n: int) -> dict:
    source = next(item for item in contract["case_specs"] if int(item["N"]) == n)
    return {
        "N": n,
        "radii": tuple(int(value) for value in source["radii"]),
        "counts": tuple(int(value) for value in source["counts"]),
        "horizon": 8 * n,
    }


def decoded(raw: np.ndarray) -> dict:
    fields = core.fields(raw)
    positive = fields["state"] > 0
    routed = (fields["dx"] != 0) | (fields["dy"] != 0) | (fields["dz"] != 0)
    return {**fields, "positive": positive, "routed": routed}


def field_counts(raw: np.ndarray) -> dict:
    fields = decoded(raw)
    return {
        "positive_state": int(np.count_nonzero(fields["positive"])),
        "direction_nonzero": int(np.count_nonzero(fields["routed"])),
        "direction_live": int(np.count_nonzero(fields["routed"] & fields["positive"])),
        "direction_ghost": int(np.count_nonzero(fields["routed"] & ~fields["positive"])),
        "raw_nonzero": int(np.count_nonzero(raw)),
        "sreg_sum": int(np.sum(fields["sreg"], dtype=np.uint64)),
        "semantic1": int(np.count_nonzero(fields["semantic"] == 1)),
        "semantic4": int(np.count_nonzero(fields["semantic"] == 4)),
        "semantic7": int(np.count_nonzero(fields["semantic"] == 7)),
    }


def direction_code(fields: dict) -> np.ndarray:
    return ((fields["dx"].astype(np.int16) + 1) * 9 + (fields["dy"].astype(np.int16) + 1) * 3 + fields["dz"].astype(np.int16) + 1).astype(np.uint8)


def build_factorial(source_raw: np.ndarray, source_clock: np.ndarray, mask: np.ndarray, *, ablate: bool, permute_direction: bool) -> tuple[dict, dict | None]:
    variants = {}
    for name in FACTORIAL_ARMS:
        raw = source_raw.copy()
        clock = source_clock.copy()
        if name == "direction0":
            raw[mask] &= CLEAR_DIRECTION
        elif name == "state0_keep_direction":
            raw[mask] &= CLEAR_STATE
        elif name == "state0_direction0_keep_metadata":
            raw[mask] &= CLEAR_STATE_AND_DIRECTION
        variants[name] = (raw, clock)
    if ablate:
        raw = source_raw.copy()
        raw[mask] = np.uint64(0)
        variants["ablate"] = (raw, source_clock.copy())
    permutation = None
    if permute_direction:
        raw = source_raw.copy()
        fields = decoded(raw)
        support = mask & fields["routed"]
        linear = np.flatnonzero(support.ravel()).astype(np.intp)
        words = (raw.ravel()[linear] & DIRECTION_MASK).astype("<u8")
        shifted = np.roll(words, 1)
        if len(words) < 2 or np.array_equal(words, shifted):
            raise RuntimeError("direction permutation is not nontrivial in this snapshot")
        flat = raw.ravel()
        flat[linear] = (flat[linear] & CLEAR_DIRECTION) | shifted
        variants["direction_permutation"] = (raw, source_clock.copy())
        permutation = {
            "algorithm": "cyclic shift by one over linearly sorted direction-support sites",
            "support_sites": len(linear),
            "changed_sites": int(np.count_nonzero(words != shifted)),
            "changed_fraction": float(np.count_nonzero(words != shifted) / len(words)),
            "mapping_sha256": sha256_bytes(np.column_stack([linear.astype("<u8"), words, shifted]).astype("<u8").tobytes()),
            "direction_word_histogram_preserved": bool(np.array_equal(np.sort(words), np.sort(shifted))),
        }
    return variants, permutation


def factorial_design_audit(source_raw: np.ndarray, source_clock: np.ndarray, mask: np.ndarray, variants: dict) -> dict:
    source = decoded(source_raw[mask])
    outside = ~mask
    checks = {
        "full_exact": np.array_equal(variants["full"][0], source_raw),
        "all_clocks_held_sitewise": all(np.array_equal(clock, source_clock) for _raw, clock in variants.values()),
        "outside_scope_held_sitewise": all(np.array_equal(raw[outside], source_raw[outside]) for raw, _clock in variants.values()),
    }
    d0 = decoded(variants["direction0"][0][mask])
    s0 = decoded(variants["state0_keep_direction"][0][mask])
    n0 = decoded(variants["state0_direction0_keep_metadata"][0][mask])
    checks["direction0_only_deletes_direction"] = bool(
        not np.any(d0["routed"])
        and np.array_equal(d0["state"], source["state"])
        and np.array_equal(d0["sreg"], source["sreg"])
        and np.array_equal(d0["semantic"], source["semantic"])
    )
    checks["state0_only_deletes_state"] = bool(
        not np.any(s0["state"])
        and np.array_equal(s0["dx"], source["dx"])
        and np.array_equal(s0["dy"], source["dy"])
        and np.array_equal(s0["dz"], source["dz"])
        and np.array_equal(s0["sreg"], source["sreg"])
        and np.array_equal(s0["semantic"], source["semantic"])
    )
    checks["factorial_null_only_deletes_state_and_direction"] = bool(
        not np.any(n0["state"])
        and not np.any(n0["routed"])
        and np.array_equal(n0["sreg"], source["sreg"])
        and np.array_equal(n0["semantic"], source["semantic"])
    )
    if "ablate" in variants:
        checks["ablation_zeroes_scoped_raw"] = not np.any(variants["ablate"][0][mask])
    if "direction_permutation" in variants:
        permuted = decoded(variants["direction_permutation"][0])
        original = decoded(source_raw)
        checks["direction_permutation_preserves_state_sitewise"] = np.array_equal(permuted["state"], original["state"])
        checks["direction_permutation_preserves_direction_support_sitewise"] = np.array_equal(permuted["routed"], original["routed"])
        checks["direction_permutation_preserves_metadata_sitewise"] = np.array_equal(permuted["sreg"], original["sreg"]) and np.array_equal(permuted["semantic"], original["semantic"])
        checks["direction_permutation_is_nontrivial"] = not np.array_equal(variants["direction_permutation"][0], source_raw)
    return {
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "source_scoped_counts": field_counts(source_raw[mask]),
        "arm_scoped_counts": {name: field_counts(raw[mask]) for name, (raw, _clock) in variants.items()},
    }


def region_masks(spec: dict, construction: dict) -> dict:
    n = int(spec["N"])
    center = np.array(construction["center"], dtype=np.int64)
    radius = core.cheb_radius_grid(n, center)
    return {
        "inner_ball": radius <= int(spec["radii"][0]),
        "middle_ball": radius <= int(spec["radii"][1]),
        "outer_ball": radius <= int(spec["radii"][2]),
        "whole_torus": np.ones((n, n, n), dtype=bool),
    }


def projection_record(raw: np.ndarray, clock: np.ndarray, local_step: int, global_tick: int, n: int, critical: bool) -> dict:
    fields = decoded(raw)
    counts = field_counts(raw)
    result = {
        "local_step": local_step,
        "global_tick": global_tick,
        **counts,
        "positive_state_fraction": counts["positive_state"] / n**3,
        "direction_fraction": counts["direction_nonzero"] / n**3,
        "raw_sha256": core.sha256_array(raw),
        "clock_sha256": core.sha256_array(clock),
    }
    if critical:
        result.update({
            "positive_mask_sha256": core.sha256_array(fields["positive"].astype(np.uint8)),
            "state_sha256": core.sha256_array(fields["state"]),
            "direction_sha256": core.sha256_array(direction_code(fields)),
            "sreg_sha256": core.sha256_array(fields["sreg"]),
            "semantic_sha256": core.sha256_array(fields["semantic"]),
        })
    return result


def jaccard(a: np.ndarray, b: np.ndarray) -> float:
    union = int(np.count_nonzero(a | b))
    return 1.0 if union == 0 else float(np.count_nonzero(a & b) / union)


def compare_traces(left: list[dict], right: list[dict]) -> dict:
    differences = [index for index, (a, b) in enumerate(zip(left, right)) if a["raw_sha256"] != b["raw_sha256"]]
    offset = int(left[0]["global_tick"])
    last_index = len(left) - 1
    return {
        "first_raw_difference_global_tick": offset + differences[0] if differences else None,
        "last_raw_difference_global_tick": offset + differences[-1] if differences else None,
        "eventual_exact_coalescence_global_tick": (offset + differences[-1] + 1) if differences and differences[-1] < last_index else offset if not differences else None,
        "raw_equal_at_final_tick": left[-1]["raw_sha256"] == right[-1]["raw_sha256"],
        "clock_equal_every_tick": all(a["clock_sha256"] == b["clock_sha256"] for a, b in zip(left, right)),
    }


def run_panel(native, variants: dict, n: int, steps: int, tick_offset: int, critical_steps: set[int], masks: dict) -> tuple[dict, dict, dict]:
    universes = {}
    for name, (raw, clock) in variants.items():
        universe = native.new(raw, clock)
        universe.tick_global = int(tick_offset)
        universes[name] = universe
    traces = {name: [] for name in variants}
    captures = {}
    clocks_equal = True
    for step in range(steps + 1):
        snapshots = {name: native.snap(universe) for name, universe in universes.items()}
        global_tick = tick_offset + step
        critical = step in critical_steps
        for name, (raw, clock) in snapshots.items():
            traces[name].append(projection_record(raw, clock, step, global_tick, n, critical))
        clocks_equal &= len({traces[name][-1]["clock_sha256"] for name in traces}) == 1
        if critical:
            captures[step] = snapshots
        if step < steps:
            for universe in universes.values():
                universe.tick(1)
    critical_comparisons = {}
    for step, snapshots in captures.items():
        by_contrast = {}
        for label, (left, right) in CONTRASTS.items():
            if left not in snapshots or right not in snapshots:
                continue
            raw_left, _clock_left = snapshots[left]
            raw_right, _clock_right = snapshots[right]
            left_positive = decoded(raw_left)["positive"]
            right_positive = decoded(raw_right)["positive"]
            by_contrast[label] = {
                "field_hamming_by_region": {region: core.field_diff_counts(raw_left[mask], raw_right[mask]) for region, mask in masks.items()},
                "positive_mask_hamming": int(np.count_nonzero(left_positive != right_positive)),
                "positive_mask_jaccard": jaccard(left_positive, right_positive),
            }
        if "direction_permutation" in snapshots:
            full_raw, _ = snapshots["full"]
            perm_raw, _ = snapshots["direction_permutation"]
            full_positive = decoded(full_raw)["positive"]
            perm_positive = decoded(perm_raw)["positive"]
            by_contrast["full_vs_direction_permutation"] = {
                "field_hamming_by_region": {region: core.field_diff_counts(full_raw[mask], perm_raw[mask]) for region, mask in masks.items()},
                "positive_mask_hamming": int(np.count_nonzero(full_positive != perm_positive)),
                "positive_mask_jaccard": jaccard(full_positive, perm_positive),
            }
        critical_comparisons[str(tick_offset + step)] = by_contrast
    summaries = {}
    for name, trace in traces.items():
        summaries[name] = {
            "positive_state_tick_sum": sum(item["positive_state"] for item in trace),
            "direction_all_tick_sum": sum(item["direction_nonzero"] for item in trace),
            "direction_live_tick_sum": sum(item["direction_live"] for item in trace),
            "direction_ghost_tick_sum": sum(item["direction_ghost"] for item in trace),
            "first_qstar_tick": next((item["global_tick"] for item in trace if item["positive_state_fraction"] >= 0.003417106052812071), None),
            "first_0_5_tick": next((item["global_tick"] for item in trace if item["positive_state_fraction"] >= 0.5), None),
            "first_0_9_tick": next((item["global_tick"] for item in trace if item["positive_state_fraction"] >= 0.9), None),
        }
    pairwise = {label: compare_traces(traces[left], traces[right]) for label, (left, right) in CONTRASTS.items() if left in traces and right in traces}
    if "ablate" in traces:
        pairwise["factorial_null_vs_ablate"] = compare_traces(traces["state0_direction0_keep_metadata"], traces["ablate"])
        pairwise["direction0_vs_ablate"] = compare_traces(traces["direction0"], traces["ablate"])
    if "direction_permutation" in traces:
        pairwise["full_vs_direction_permutation"] = compare_traces(traces["full"], traces["direction_permutation"])
    endpoints = {name: captures[steps][name] if steps in captures else native.snap(universes[name]) for name in universes}
    return ({
        "tick_offset": tick_offset,
        "steps": steps,
        "arms": {name: {"trace": trace, **summaries[name]} for name, trace in traces.items()},
        "all_arm_clocks_equal_every_tick": bool(clocks_equal),
        "pairwise_dynamics": pairwise,
        "critical_comparisons": critical_comparisons,
    }, endpoints, captures)


def routing_geometry(raw: np.ndarray) -> tuple[dict, np.ndarray]:
    n = int(raw.shape[0])
    fields = decoded(raw)
    coords = np.argwhere(fields["routed"]).astype(np.int64)
    directions = np.column_stack([fields["dx"][fields["routed"]], fields["dy"][fields["routed"]], fields["dz"][fields["routed"]]]).astype(np.int64)
    valid = bool(np.all(np.isin(directions, (-1, 0, 1))))
    destinations = (coords + directions) % n
    expected = np.zeros(raw.shape, dtype=bool)
    if len(destinations):
        expected[tuple(destinations.T.astype(np.intp))] = True
    linear = ((destinations[:, 0] * n + destinations[:, 1]) * n + destinations[:, 2]).astype(np.int64) if len(destinations) else np.array([], dtype=np.int64)
    _unique, multiplicities = np.unique(linear, return_counts=True)
    return ({
        "routing_sources": len(coords),
        "unique_destinations": len(multiplicities),
        "collision_excess": int(len(coords) - len(multiplicities)),
        "maximum_destination_multiplicity": int(max(multiplicities)) if len(multiplicities) else 0,
        "directions_all_in_minus1_0_1": valid,
        "expected_destination_mask_sha256": core.sha256_array(expected.astype(np.uint8)),
    }, expected)


def exact_demux_check(source_raw: np.ndarray, captures: dict, local_step: int = 1) -> dict:
    geometry, expected = routing_geometry(source_raw)
    routed_raw, _ = captures[local_step]["state0_keep_direction"]
    null_raw, _ = captures[local_step]["state0_direction0_keep_metadata"]
    routed_positive = decoded(routed_raw)["positive"]
    null_positive = decoded(null_raw)["positive"]
    return {
        **geometry,
        "routed_positive_mask_sha256": core.sha256_array(routed_positive.astype(np.uint8)),
        "null_positive_mask_sha256": core.sha256_array(null_positive.astype(np.uint8)),
        "routed_positive_exactly_expected_destinations": np.array_equal(routed_positive, expected),
        "null_positive_empty": not np.any(null_positive),
        "routed_positive_count": int(np.count_nonzero(routed_positive)),
        "null_positive_count": int(np.count_nonzero(null_positive)),
    }


def classify_long_branch(trace: list[dict], n: int, contract: dict) -> dict:
    steps = 7 * n
    raw_period_1 = all(trace[t]["raw_sha256"] == trace[t - 1]["raw_sha256"] for t in range(6 * n + 1, steps + 1))
    raw_period_n = all(trace[t]["raw_sha256"] == trace[t - n]["raw_sha256"] for t in range(6 * n + 1, steps + 1))
    tail = [item["positive_state_fraction"] for item in trace[-(n + 1):]]
    dense_floor = float(contract["outcome_definition"]["dense_persistence_fraction"])
    sparse_ceiling = float(contract["outcome_definition"]["sparse_ceiling_fraction"])
    if min(tail) >= dense_floor and raw_period_1:
        observed = "DENSE_RAW_FIXED_BY_8N"
        macro = "DENSE"
    elif max(tail) < sparse_ceiling and raw_period_1:
        observed = "NON_DENSE_RAW_FIXED_BY_8N"
        macro = "NON_DENSE"
    elif max(tail) < sparse_ceiling and raw_period_n:
        observed = "SPARSE_RAW_PERIOD_N_BY_8N"
        macro = "NON_DENSE"
    else:
        observed = "OTHER_BY_8N"
        macro = "NON_DENSE" if max(tail) < sparse_ceiling else "INTERMEDIATE"
    return {
        "observed_8N": observed,
        "tail_macro_regime_8N": macro,
        "raw_fixed_last_N": raw_period_1,
        "raw_period_N_last_N": raw_period_n,
        "tail_positive_fraction_min": min(tail),
        "tail_positive_fraction_max": max(tail),
        "final_positive_fraction": trace[-1]["positive_state_fraction"],
    }


def scalar_factorial(panel: dict, getter) -> dict:
    values = {name: float(getter(panel["arms"][name])) for name in FACTORIAL_ARMS}
    y11, y10 = values["full"], values["direction0"]
    y01, y00 = values["state0_keep_direction"], values["state0_direction0_keep_metadata"]
    return {
        **values,
        "direction_effect_at_state_present": y11 - y10,
        "direction_effect_at_state_absent": y01 - y00,
        "state_effect_at_direction_present": y11 - y01,
        "state_effect_at_direction_absent": y10 - y00,
        "interaction": y11 - y10 - y01 + y00,
    }


def find_msh_row(msh01: dict, n: int, seed: int, variant: str) -> dict:
    return next(row for row in msh01["rows"] if int(row["N"]) == n and int(row["seed"]) == seed and row["variant"] == variant)


def trace_at(row: dict, tick: int) -> dict:
    return next(item for item in row["trace"] if int(item["tick"]) == tick)


def run_long_group(native, contract: dict, msh01: dict, n: int, seed: int) -> dict:
    spec = make_spec(contract, n)
    raw0, clock0, layers, construction = core.make_base(spec, seed)
    msh_base = find_msh_row(msh01, n, seed, "baseline")
    if core.sha256_array(raw0) != msh_base["initial_raw_sha256"] or core.sha256_array(clock0) != msh_base["initial_clock_sha256"]:
        raise RuntimeError(f"initial reconstruction mismatch N{n} seed{seed}")
    outer_mask = np.zeros(raw0.shape, dtype=bool)
    outer_mask[tuple(layers[-1].T.astype(np.intp))] = True
    outer_variants, _ = build_factorial(raw0, clock0, outer_mask, ablate=True, permute_direction=False)
    outer_design = factorial_design_audit(raw0, clock0, outer_mask, outer_variants)
    if outer_design["status"] != "PASS":
        raise RuntimeError(f"outer factorial audit failed N{n} seed{seed}")
    masks = region_masks(spec, construction)
    outer_panel, outer_endpoints, outer_captures = run_panel(native, outer_variants, n, n, 0, {0, 1, math.ceil(n / 2), n}, masks)
    observed_n = outer_panel["arms"]["full"]["trace"][-1]
    expected_n = trace_at(msh_base, n)
    overlap_n = {"raw": observed_n["raw_sha256"] == expected_n["raw_sha256"], "clock": observed_n["clock_sha256"] == expected_n["clock_sha256"]}
    overlap_n["pass"] = all(overlap_n.values())
    if not overlap_n["pass"]:
        raise RuntimeError(f"baseline overlap at N failed N{n} seed{seed}")
    isolated_outer_raw = np.zeros_like(raw0)
    isolated_outer_raw[outer_mask] = outer_variants["state0_keep_direction"][0][outer_mask]
    outer_geometry, outer_expected = routing_geometry(isolated_outer_raw)
    outer_routed1 = decoded(outer_captures[1]["state0_keep_direction"][0])["positive"]
    outer_null1 = decoded(outer_captures[1]["state0_direction0_keep_metadata"][0])["positive"]
    outer_diff_mask = outer_routed1 != outer_null1
    outer_one_tick = {
        **outer_geometry,
        "positive_difference_mask_exactly_outer_routing_destinations": np.array_equal(outer_diff_mask, outer_expected),
        "positive_difference_count": int(np.count_nonzero(outer_diff_mask)),
        "direction0_equals_factorial_null_at_t1": np.array_equal(outer_captures[1]["direction0"][0], outer_captures[1]["state0_direction0_keep_metadata"][0]),
        "factorial_null_equals_ablation_at_t1": np.array_equal(outer_captures[1]["state0_direction0_keep_metadata"][0], outer_captures[1]["ablate"][0]),
    }
    source_n_raw, source_n_clock = outer_endpoints["full"]
    full_mask = np.ones(source_n_raw.shape, dtype=bool)
    snapshot_variants, permutation = build_factorial(source_n_raw, source_n_clock, full_mask, ablate=False, permute_direction=True)
    snapshot_design = factorial_design_audit(source_n_raw, source_n_clock, full_mask, snapshot_variants)
    if snapshot_design["status"] != "PASS":
        raise RuntimeError(f"snapshot factorial audit failed N{n} seed{seed}")
    snapshot_panel, _snapshot_endpoints, snapshot_captures = run_panel(native, snapshot_variants, n, 7 * n, n, {0, 1, n, 3 * n, 5 * n, 6 * n, 7 * n}, masks)
    snapshot_panel["outcomes"] = {name: classify_long_branch(arm["trace"], n, contract) for name, arm in snapshot_panel["arms"].items()}
    snapshot_panel["factorial_at_8N"] = {
        "final_positive_fraction": scalar_factorial(snapshot_panel, lambda arm: arm["trace"][-1]["positive_state_fraction"]),
        "positive_state_tick_sum": scalar_factorial(snapshot_panel, lambda arm: arm["positive_state_tick_sum"]),
        "direction_all_tick_sum": scalar_factorial(snapshot_panel, lambda arm: arm["direction_all_tick_sum"]),
    }
    demux = exact_demux_check(source_n_raw, snapshot_captures)
    full4n = snapshot_panel["arms"]["full"]["trace"][3 * n]
    expected4n = trace_at(msh_base, 4 * n)
    overlap4n = {"raw": full4n["raw_sha256"] == expected4n["raw_sha256"], "clock": full4n["clock_sha256"] == expected4n["clock_sha256"]}
    overlap4n["pass"] = all(overlap4n.values())
    if not overlap4n["pass"]:
        raise RuntimeError(f"FULL restart overlap at 4N failed N{n} seed{seed}")
    return {
        "group_id": f"N{n}_seed{seed}",
        "N": n,
        "seed": seed,
        "selection_role": msh_base["observed"],
        "spec": spec,
        "construction": construction,
        "outer_stage_0_to_N": {
            "estimand": "effect of deleting initial outer-shell state and/or direction fields on measurements at N",
            "design_audit": outer_design,
            "exact_baseline_overlap_at_N": overlap_n,
            "one_tick_prediction_audit": outer_one_tick,
            "panel": outer_panel,
            "factorial_at_N": {
                "positive_state_fraction": scalar_factorial(outer_panel, lambda arm: arm["trace"][-1]["positive_state_fraction"]),
                "direction_fraction": scalar_factorial(outer_panel, lambda arm: arm["trace"][-1]["direction_fraction"]),
                "positive_state_tick_sum": scalar_factorial(outer_panel, lambda arm: arm["positive_state_tick_sum"]),
            },
        },
        "snapshot_stage_N_to_8N": {
            "estimand": "effect of deleting whole-torus state and/or direction at N on subsequent trajectory; off-manifold intervention",
            "design_audit": snapshot_design,
            "direction_permutation": permutation,
            "exact_demux_one_tick": demux,
            "exact_FULL_overlap_at_4N": overlap4n,
            "panel": snapshot_panel,
        },
    }


def evolve_source_to_n(native, raw0: np.ndarray, clock0: np.ndarray, n: int) -> tuple[np.ndarray, np.ndarray, list[dict]]:
    universe = native.new(raw0, clock0)
    trace = []
    for tick in range(n + 1):
        raw, clock = native.snap(universe)
        trace.append(projection_record(raw, clock, tick, tick, n, tick in {0, 1, math.ceil(n / 2), n}))
        if tick < n:
            universe.tick(1)
    return raw, clock, trace


def run_precursor_context(native, contract: dict, msh01: dict, n: int, seed: int, variant: str) -> dict:
    spec = make_spec(contract, n)
    raw, clock, layers, construction = core.make_base(spec, seed)
    raw0, clock0 = core.build_variants(raw, clock, layers[-1], seed)[variant]
    source = find_msh_row(msh01, n, seed, variant)
    if core.sha256_array(raw0) != source["initial_raw_sha256"] or core.sha256_array(clock0) != source["initial_clock_sha256"]:
        raise RuntimeError(f"precursor initial mismatch {variant}")
    raw_n, clock_n, prefix_trace = evolve_source_to_n(native, raw0, clock0, n)
    expected_n = trace_at(source, n)
    overlap_n = {"raw": core.sha256_array(raw_n) == expected_n["raw_sha256"], "clock": core.sha256_array(clock_n) == expected_n["clock_sha256"]}
    overlap_n["pass"] = all(overlap_n.values())
    if not overlap_n["pass"]:
        raise RuntimeError(f"precursor overlap at N failed {variant}")
    mask = np.ones(raw_n.shape, dtype=bool)
    arms, _ = build_factorial(raw_n, clock_n, mask, ablate=False, permute_direction=False)
    design = factorial_design_audit(raw_n, clock_n, mask, arms)
    if design["status"] != "PASS":
        raise RuntimeError(f"precursor factorial audit failed {variant}")
    masks = region_masks(spec, construction)
    panel, _endpoints, captures = run_panel(native, arms, n, n, n, {0, 1, 2, 4, 8, math.ceil(n / 2), n}, masks)
    demux = exact_demux_check(raw_n, captures)
    full2n = panel["arms"]["full"]["trace"][n]
    expected2n = trace_at(source, 2 * n)
    overlap2n = {"raw": full2n["raw_sha256"] == expected2n["raw_sha256"], "clock": full2n["clock_sha256"] == expected2n["clock_sha256"]}
    overlap2n["pass"] = all(overlap2n.values())
    if not overlap2n["pass"]:
        raise RuntimeError(f"precursor FULL overlap at 2N failed {variant}")
    panel["factorial_at_2N"] = {
        "final_positive_fraction": scalar_factorial(panel, lambda arm: arm["trace"][-1]["positive_state_fraction"]),
        "positive_state_tick_sum": scalar_factorial(panel, lambda arm: arm["positive_state_tick_sum"]),
    }
    return {
        "context_id": f"N{n}_seed{seed}_{variant}",
        "N": n,
        "seed": seed,
        "variant": variant,
        "selection_role": "opened matched pre-crossing dense/sparse pair selected after MSH01",
        "source_q_N": prefix_trace[-1]["positive_state_fraction"],
        "source_direction_fraction_N": prefix_trace[-1]["direction_fraction"],
        "prefix_trace_0_to_N": prefix_trace,
        "exact_overlap_at_N": overlap_n,
        "design_audit": design,
        "exact_demux_one_tick": demux,
        "exact_FULL_overlap_at_2N": overlap2n,
        "panel_N_to_2N": panel,
    }


def summarise(long_groups: list[dict], precursor: list[dict]) -> dict:
    long_outcomes = Counter()
    permutation_changed_fate = []
    for group in long_groups:
        panel = group["snapshot_stage_N_to_8N"]["panel"]
        for arm, outcome in panel["outcomes"].items():
            long_outcomes[f"{arm}:{outcome['observed_8N']}"] += 1
        permutation_changed_fate.append(panel["outcomes"]["full"]["observed_8N"] != panel["outcomes"]["direction_permutation"]["observed_8N"])
    return {
        "long_snapshot_outcome_counts": dict(long_outcomes),
        "all_long_baseline_N_and_4N_replays_pass": all(group["outer_stage_0_to_N"]["exact_baseline_overlap_at_N"]["pass"] and group["snapshot_stage_N_to_8N"]["exact_FULL_overlap_at_4N"]["pass"] for group in long_groups),
        "all_snapshot_factorial_bitwise_audits_pass": all(group["snapshot_stage_N_to_8N"]["design_audit"]["status"] == "PASS" for group in long_groups),
        "all_snapshot_G01_one_tick_masks_equal_exact_routing_destinations": all(group["snapshot_stage_N_to_8N"]["exact_demux_one_tick"]["routed_positive_exactly_expected_destinations"] for group in long_groups),
        "all_snapshot_G00_one_tick_positive_masks_empty": all(group["snapshot_stage_N_to_8N"]["exact_demux_one_tick"]["null_positive_empty"] for group in long_groups),
        "outer_direction0_null_ablation_exactly_coalesce_by_t1_groups": sum(group["outer_stage_0_to_N"]["one_tick_prediction_audit"]["direction0_equals_factorial_null_at_t1"] and group["outer_stage_0_to_N"]["one_tick_prediction_audit"]["factorial_null_equals_ablation_at_t1"] for group in long_groups),
        "direction_permutation_changed_8N_witness_groups": sum(permutation_changed_fate),
        "precursor_replays_pass": all(item["exact_overlap_at_N"]["pass"] and item["exact_FULL_overlap_at_2N"]["pass"] for item in precursor),
        "warning": "Every group/context was outcome-selected after opening. Counts are cluster-level descriptive discovery, not independent confirmatory trials.",
    }


def static_audit() -> dict:
    paths = {"foundation_runner": FOUNDATION_RUNNER, "core_runner": CORE_RUNNER, "msh01_lock": MSH01_LOCK, "msh01": MSH01, "msd05": MSD05, "msa05": MSA05}
    hashes = {name: sha256_file(path) for name, path in paths.items()}
    lock = json.loads(MSH01_LOCK.read_text(encoding="utf-8"))["contract"]
    msh01 = json.loads(MSH01.read_text(encoding="utf-8"))
    selected_pairs = {(n, seed) for n, seeds in LONG_GROUPS.items() for seed in seeds}
    baseline_rows = [find_msh_row(msh01, n, seed, "baseline") for n, seed in sorted(selected_pairs)]
    initial_checks = []
    outer_design_checks = []
    for source in baseline_rows:
        n, seed = int(source["N"]), int(source["seed"])
        spec = make_spec(lock, n)
        raw, clock, layers, _construction = core.make_base(spec, seed)
        mask = np.zeros(raw.shape, dtype=bool)
        mask[tuple(layers[-1].T.astype(np.intp))] = True
        arms, _ = build_factorial(raw, clock, mask, ablate=True, permute_direction=False)
        initial_checks.append(core.sha256_array(raw) == source["initial_raw_sha256"] and core.sha256_array(clock) == source["initial_clock_sha256"])
        outer_design_checks.append(factorial_design_audit(raw, clock, mask, arms)["status"] == "PASS")
    classes = Counter(row["observed"] for row in baseline_rows)
    precursor_rows = [find_msh_row(msh01, n, seed, variant) for n, seed, variant in PRECURSOR_CONTEXTS]
    precursor_pre_crossing = all(row["first_passage_0_5"] is None or int(row["first_passage_0_5"]) > int(row["N"]) for row in precursor_rows)
    checks = {
        "all_input_hashes_match": hashes == EXPECTED,
        "output_absent": not OUT.exists(),
        "six_unique_long_groups": len(selected_pairs) == 6 and len(baseline_rows) == 6,
        "long_selection_contains_two_dense_two_sparse_two_other_at_4N": classes == Counter({"DENSE_RAW_FIXED_WINDOW": 2, "SPARSE_RAW_PERIOD_N_WINDOW": 2, "OTHER": 2}),
        "all_long_initial_hashes_match_msh01": all(initial_checks),
        "all_outer_factorial_designs_pass": all(outer_design_checks),
        "precursor_pair_same_N_seed_and_two_variants": len(precursor_rows) == 2 and len({(row["N"], row["seed"]) for row in precursor_rows}) == 1,
        "precursor_pair_is_pre_crossing_at_N": precursor_pre_crossing,
        "discovery_only_and_all_cases_previously_opened": True,
    }
    long_n_sum = sum(n * len(seeds) for n, seeds in LONG_GROUPS.items())
    precursor_n_sum = sum(n for n, _seed, _variant in PRECURSOR_CONTEXTS)
    planned_ticks = len(OUTER_ARMS) * long_n_sum + len(SNAPSHOT_ARMS) * 7 * long_n_sum + precursor_n_sum + len(FACTORIAL_ARMS) * precursor_n_sum
    return {
        "schema": "dee.v27.msd06.static_audit.v2",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "input_hashes": hashes,
        "runner_sha256": sha256_file(HERE),
        "long_groups": sorted([list(pair) for pair in selected_pairs]),
        "precursor_contexts": [list(item) for item in PRECURSOR_CONTEXTS],
        "planned_segment_count": 6 * len(OUTER_ARMS) + 6 * len(SNAPSHOT_ARMS) + len(PRECURSOR_CONTEXTS) + len(PRECURSOR_CONTEXTS) * len(FACTORIAL_ARMS),
        "planned_universe_ticks": planned_ticks,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    if args.threads != 1:
        raise RuntimeError("MSD06 is operationally fixed to --threads 1")
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS":
        raise RuntimeError(f"static audit failed: {audit}")
    lock = json.loads(MSH01_LOCK.read_text(encoding="utf-8"))["contract"]
    msh01 = json.loads(MSH01.read_text(encoding="utf-8"))
    native = core.Native(args.threads)
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    long_groups = [run_long_group(native, lock, msh01, n, seed) for n, seeds in LONG_GROUPS.items() for seed in seeds]
    precursor = [run_precursor_context(native, lock, msh01, n, seed, variant) for n, seed, variant in PRECURSOR_CONTEXTS]
    result = {
        "schema": "dee.v27.multiscale.msd06.causal_carrier_discovery.v2",
        "experiment_id": "MSD06",
        "role": "POST_HOLDOUT_CAUSAL_DISCOVERY",
        "confirmatory_status": "NOT_ELIGIBLE",
        "started_utc": started_utc,
        "runner_sha256": sha256_file(HERE),
        "input_hashes": audit["input_hashes"],
        "static_audit": audit,
        "environment": native.environment,
        "design": {
            "stage_A": "initial outer-shell 2x2 state/direction deletion plus ablation, t=0..N",
            "stage_B": "whole-torus snapshot 2x2 state/direction deletion plus direction-word permutation, t=N..8N",
            "precursor_panel": "opened N37 seed270427375 baseline/shuffle pair, whole-torus factorial t=N..2N",
            "ontological_scope": "bit-field causal effects in these constructed worlds; no matter/momentum or physical-preparability identification",
        },
        "long_groups": long_groups,
        "precursor_contexts": precursor,
        "summary": {
            "long_groups": len(long_groups),
            "precursor_contexts": len(precursor),
            "trajectory_segments": audit["planned_segment_count"],
            "universe_ticks": audit["planned_universe_ticks"],
            **summarise(long_groups, precursor),
        },
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({"status": "COMPLETE", "summary": result["summary"], "elapsed_seconds": result["elapsed_seconds"], "output": str(OUT), "output_sha256": sha256_file(OUT)}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
