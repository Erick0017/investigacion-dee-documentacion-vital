#!/usr/bin/env python3
"""MSH01 confirmatory holdout for a frozen positive-state-support law."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
CORE_RUNNER = HERE.with_name("run_msd02_basin_discovery.py")
FOUNDATION_RUNNER = HERE.with_name("run_msd01_v27_discovery.py")
LOCK_PATH = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json"
LOCK_SHA_PATH = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json.sha256"
OUT = ROOT / "HOLDOUTS" / "MSH01_results.json"


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


msd02 = load_module(CORE_RUNNER, "msh01_core")
core = msd02.core


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(obj) -> str:
    text = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def atomic_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        json.dump(obj, f, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def verify_lock() -> tuple[dict, str]:
    if not LOCK_PATH.is_file() or not LOCK_SHA_PATH.is_file():
        raise RuntimeError("frozen lock and SHA sidecar are required")
    expected_file_sha = LOCK_SHA_PATH.read_text(encoding="ascii").strip().split()[0].lower()
    observed_file_sha = sha256_file(LOCK_PATH)
    if observed_file_sha != expected_file_sha:
        raise RuntimeError("lock file SHA mismatch")
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    if canonical_hash(lock["contract"]) != lock["contract_payload_sha256"]:
        raise RuntimeError("contract payload SHA mismatch")
    contract = lock["contract"]
    if sha256_file(HERE) != contract["runner_sha256"]:
        raise RuntimeError("runner SHA mismatch against frozen contract")
    if sha256_file(CORE_RUNNER) != contract["core_runner_sha256"]:
        raise RuntimeError("core runner SHA mismatch against frozen contract")
    if sha256_file(FOUNDATION_RUNNER) != contract["foundation_runner_sha256"]:
        raise RuntimeError("foundation runner SHA mismatch against frozen contract")
    return lock, observed_file_sha


def make_spec(case_spec: dict) -> dict:
    return {
        "N": int(case_spec["N"]),
        "radii": tuple(int(x) for x in case_spec["radii"]),
        "counts": tuple(int(x) for x in case_spec["counts"]),
        "horizon": int(case_spec["horizon_multiplier"] * case_spec["N"]),
    }


def reconstruct(spec: dict, seed: int, variant: str):
    raw, clock, layers, construction = core.make_base(spec, seed)
    variants = core.build_variants(raw, clock, layers[-1], seed)
    return variants[variant], layers, construction


def trajectory(native, case_spec: dict, seed: int, variant: str, contract: dict) -> dict:
    spec = make_spec(case_spec)
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    if horizon != 4 * n:
        raise RuntimeError("frozen raw-window tests require horizon exactly 4*N")
    half = int(math.ceil(n / 2))
    (raw0, clock0), layers, construction = reconstruct(spec, seed, variant)
    center = np.array(construction["center"], dtype=np.int64)
    radius_grid = core.cheb_radius_grid(n, center)
    inner = radius_grid <= int(spec["radii"][0])
    middle = radius_grid <= int(spec["radii"][1])
    u = native.new(raw0, clock0)
    compact_trace = []
    occupancy_fractions = []
    raw_hashes: dict[int, str] = {}
    first_05 = None
    first_09 = None
    routing_half = None
    routing_n = None
    occupancy_half = None
    occupancy_n = None
    for tick in range(horizon + 1):
        raw, clock = native.snap(u)
        metric = msd02.actual_metrics(raw, n, inner, middle)
        fraction = float(metric["occupancy_fraction"])
        occupancy_fractions.append(fraction)
        if first_05 is None and fraction >= float(contract["outcome_definition"]["dense_crossing_fraction"]):
            first_05 = tick
        if first_09 is None and fraction >= float(contract["outcome_definition"]["dense_persistence_fraction"]):
            first_09 = tick
        if tick == half:
            routing_half = int(metric["direction_nonzero"])
            occupancy_half = int(metric["occupancy"])
        if tick == n:
            routing_n = int(metric["direction_nonzero"])
            occupancy_n = int(metric["occupancy"])
        if tick >= 2 * n:
            raw_hashes[tick] = core.sha256_array(raw)
        if tick % 4 == 0 or tick in (half, n, 2 * n, 3 * n, horizon):
            compact_trace.append({
                "tick": tick,
                "occupancy": int(metric["occupancy"]),
                "occupancy_fraction": fraction,
                "direction_nonzero": int(metric["direction_nonzero"]),
                "semantic4": int(metric["semantic4"]),
                "semantic7_xnor": int(metric["semantic7_xnor"]),
                "raw_sha256": core.sha256_array(raw),
                "clock_sha256": core.sha256_array(clock),
            })
        if tick < horizon:
            u.tick(1)
    if routing_half is None or routing_n is None or occupancy_half is None or occupancy_n is None:
        raise AssertionError("measurement ticks missing")
    q_half = float(occupancy_half / n**3)
    q_n = float(occupancy_n / n**3)
    direction_half = float(routing_half / n**3)
    direction_n = float(routing_n / n**3)
    delta_occupancy = q_n - q_half
    delta_direction = direction_n - direction_half
    threshold = float(contract["model"]["positive_state_fraction_threshold"])
    prediction = "DENSE_RAW_FIXED_WINDOW" if q_n >= threshold else "SPARSE_RAW_PERIOD_N_WINDOW"
    dense_tail = occupancy_fractions[-(n + 1) :]
    raw_period_1 = all(raw_hashes[t] == raw_hashes[t - 1] for t in range(3 * n + 1, 4 * n + 1))
    raw_period_n = all(raw_hashes[t] == raw_hashes[t - n] for t in range(3 * n + 1, 4 * n + 1))
    dense = first_05 is not None and first_09 is not None and min(dense_tail) >= float(contract["outcome_definition"]["dense_persistence_fraction"]) and raw_period_1
    sparse = max(occupancy_fractions[n:]) < float(contract["outcome_definition"]["sparse_ceiling_fraction"]) and raw_period_n
    if dense:
        observed = "DENSE_RAW_FIXED_WINDOW"
    elif sparse:
        observed = "SPARSE_RAW_PERIOD_N_WINDOW"
    else:
        observed = "OTHER"
    correct = prediction == observed
    descriptor_bits = math.ceil(math.log2(n**3 + 1))
    micro_bits = 128 * n**3
    comparators = contract["comparators"]
    size_prediction = "DENSE_RAW_FIXED_WINDOW" if n >= int(comparators["size_threshold_N"]) else "SPARSE_RAW_PERIOD_N_WINDOW"
    half_prediction = "DENSE_RAW_FIXED_WINDOW" if q_half >= float(comparators["positive_state_fraction_half_threshold"]) else "SPARSE_RAW_PERIOD_N_WINDOW"
    direction_n_prediction = "DENSE_RAW_FIXED_WINDOW" if direction_n >= float(comparators["direction_fraction_N_threshold"]) else "SPARSE_RAW_PERIOD_N_WINDOW"
    delta_direction_prediction = (
        "DENSE_RAW_FIXED_WINDOW"
        if delta_direction >= float(comparators["delta_direction_dense_threshold"])
        else "SPARSE_RAW_PERIOD_N_WINDOW"
        if delta_direction <= float(comparators["delta_direction_sparse_threshold"])
        else "ABSTAIN"
    )
    delta_occupancy_prediction = (
        "DENSE_RAW_FIXED_WINDOW"
        if delta_occupancy >= float(comparators["delta_occupancy_dense_threshold"])
        else "SPARSE_RAW_PERIOD_N_WINDOW"
        if delta_occupancy <= float(comparators["delta_occupancy_sparse_threshold"])
        else "ABSTAIN"
    )
    return {
        "row_id": f"N{n}_seed{seed}_{variant}",
        "group_id": f"N{n}_seed{seed}",
        "N": n,
        "seed": seed,
        "variant": variant,
        "horizon": horizon,
        "initial_raw_sha256": core.sha256_array(raw0),
        "initial_clock_sha256": core.sha256_array(clock0),
        "initial_outer_joint_inventory_sha256": core.multiset_hash(raw0, clock0, layers[-1], True),
        "routing_count_half": routing_half,
        "routing_count_N": routing_n,
        "positive_state_count_half": occupancy_half,
        "positive_state_count_N": occupancy_n,
        "positive_state_fraction_half": q_half,
        "positive_state_fraction_N": q_n,
        "direction_fraction_half": direction_half,
        "direction_fraction_N": direction_n,
        "delta_positive_state_fraction": delta_occupancy,
        "delta_direction_fraction": delta_direction,
        "prediction": prediction,
        "observed": observed,
        "correct": correct,
        "comparator_predictions": {
            "all_dense": "DENSE_RAW_FIXED_WINDOW",
            "size_only": size_prediction,
            "positive_state_half": half_prediction,
            "direction_N": direction_n_prediction,
            "delta_direction": delta_direction_prediction,
            "delta_positive_state": delta_occupancy_prediction,
        },
        "latency_forecast_eligible_at_N": first_05 is None or first_05 > n,
        "first_passage_0_5": first_05,
        "first_passage_0_9": first_09,
        "raw_period_1_last_N": raw_period_1,
        "raw_period_N_last_N": raw_period_n,
        "tail_occupancy_min": min(dense_tail),
        "tail_occupancy_max": max(dense_tail),
        "final_occupancy_fraction": occupancy_fractions[-1],
        "descriptor_bits": descriptor_bits,
        "microstate_bits": micro_bits,
        "compression_gain_fraction": 1 - descriptor_bits / micro_bits,
        "trace": compact_trace,
    }


def balanced_accuracy(rows: list[dict], prediction_getter=lambda row: row["prediction"]) -> float | None:
    recalls = []
    for label in ("DENSE_RAW_FIXED_WINDOW", "SPARSE_RAW_PERIOD_N_WINDOW"):
        subset = [row for row in rows if row["observed"] == label]
        if subset:
            recalls.append(sum(int(prediction_getter(row) == label) for row in subset) / len(subset))
    return sum(recalls) / len(recalls) if len(recalls) == 2 else None


def evaluate_predictions(rows: list[dict], getter) -> dict:
    decisive = [row for row in rows if getter(row) != "ABSTAIN"]
    errors = [row for row in decisive if getter(row) != row["observed"]]
    return {
        "total": len(rows),
        "decisive": len(decisive),
        "coverage": len(decisive) / len(rows) if rows else None,
        "errors": len(errors),
        "error_rows": [row["row_id"] for row in errors],
        "accuracy": (len(decisive) - len(errors)) / len(decisive) if decisive else None,
        "balanced_accuracy": balanced_accuracy(decisive, getter),
    }


def wilson(successes: int, n: int, z: float = 1.959963984540054) -> dict:
    if n == 0:
        return {"lower": None, "upper": None}
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denominator
    return {"lower": center - half, "upper": center + half}


def adjudicate(rows: list[dict], contract: dict) -> dict:
    decisive = list(rows)
    errors = [row for row in decisive if not row["correct"]]
    labels = ("DENSE_RAW_FIXED_WINDOW", "SPARSE_RAW_PERIOD_N_WINDOW", "OTHER")
    observed_counts = {label: sum(row["observed"] == label for row in decisive) for label in labels}
    coverage = 1.0
    accuracy = (len(decisive) - len(errors)) / len(decisive) if decisive else None
    ba = balanced_accuracy(decisive)
    per_n = {}
    for n in sorted({row["N"] for row in rows}):
        subset = [row for row in rows if row["N"] == n]
        per_n[str(n)] = {
            "decisive": len(subset),
            "errors": sum(not row["correct"] for row in subset),
            "coverage": len(subset) / sum(row["N"] == n for row in rows),
            "observed_counts": {label: sum(row["observed"] == label for row in subset) for label in labels},
        }
    groups = {}
    for group in sorted({row["group_id"] for row in rows}):
        arms = {row["variant"]: row for row in rows if row["group_id"] == group}
        groups[group] = {
            "joint_inventory_baseline_equals_shuffle": arms["baseline"]["initial_outer_joint_inventory_sha256"] == arms["same_inventory_joint_shuffle"]["initial_outer_joint_inventory_sha256"],
            "baseline_observed": arms["baseline"]["observed"],
            "shuffle_observed": arms["same_inventory_joint_shuffle"]["observed"],
            "organization_changed_outcome": arms["baseline"]["observed"] != arms["same_inventory_joint_shuffle"]["observed"],
            "outcomes": sorted({row["observed"] for row in arms.values()}),
            "all_primary_correct": all(row["correct"] for row in arms.values()),
        }
    criteria = contract["adjudication"]
    integrity = all(item["joint_inventory_baseline_equals_shuffle"] for item in groups.values())
    class_groups = {
        label: len({row["group_id"] for row in rows if row["observed"] == label})
        for label in ("DENSE_RAW_FIXED_WINDOW", "SPARSE_RAW_PERIOD_N_WINDOW")
    }
    enough_classes = all(value >= int(criteria["minimum_independent_groups_each_class"]) for value in class_groups.values())
    mixed_sizes = [
        n for n in sorted({row["N"] for row in rows})
        if all(any(row["N"] == n and row["observed"] == label for row in rows) for label in ("DENSE_RAW_FIXED_WINDOW", "SPARSE_RAW_PERIOD_N_WINDOW"))
    ]
    mixed_groups = [
        group for group, value in groups.items()
        if "DENSE_RAW_FIXED_WINDOW" in value["outcomes"] and "SPARSE_RAW_PERIOD_N_WINDOW" in value["outcomes"]
    ]
    primary_metrics = evaluate_predictions(rows, lambda row: row["prediction"])
    comparator_metrics = {
        name: evaluate_predictions(rows, lambda row, name=name: row["comparator_predictions"][name])
        for name in ("all_dense", "size_only", "positive_state_half", "direction_N", "delta_direction", "delta_positive_state")
    }
    size_ba = comparator_metrics["size_only"]["balanced_accuracy"]
    size_specificity = (
        len(mixed_groups) >= int(criteria["minimum_mixed_seed_groups"])
        and size_ba is not None
        and ba is not None
        and ba - size_ba >= float(criteria["minimum_balanced_accuracy_advantage_over_size_only"])
    )
    delayed_dense_groups = len({row["group_id"] for row in rows if row["latency_forecast_eligible_at_N"] and row["observed"] == "DENSE_RAW_FIXED_WINDOW"})
    latency_rows = [row for row in rows if row["latency_forecast_eligible_at_N"]]
    latency_metrics = evaluate_predictions(latency_rows, lambda row: row["prediction"])
    latency_sparse_groups = len({row["group_id"] for row in latency_rows if row["observed"] == "SPARSE_RAW_PERIOD_N_WINDOW"})
    latency_size_metrics = evaluate_predictions(latency_rows, lambda row: row["comparator_predictions"]["size_only"])
    latency_ba = latency_metrics["balanced_accuracy"]
    latency_size_ba = latency_size_metrics["balanced_accuracy"]
    enough_latency_diversity = (
        delayed_dense_groups >= int(criteria["minimum_delayed_dense_groups_for_latency"])
        and latency_sparse_groups >= int(criteria["minimum_sparse_groups_for_latency"])
    )
    latency_advantage = (
        latency_ba is not None
        and latency_size_ba is not None
        and latency_ba - latency_size_ba >= float(criteria["minimum_balanced_accuracy_advantage_over_size_only"])
    )
    latency_verdict = (
        "PASS_PRE_CROSSING_SUBSET"
        if enough_latency_diversity
        and latency_metrics["errors"] == 0
        and latency_ba is not None
        and latency_ba >= float(criteria["minimum_balanced_accuracy"])
        and latency_advantage
        else "FAIL_PRE_CROSSING_SUBSET"
        if enough_latency_diversity
        else "INCONCLUSIVE_PRE_CROSSING_DIVERSITY"
    )
    if not enough_classes or len(mixed_groups) < int(criteria["minimum_mixed_seed_groups"]):
        verdict = "INCONCLUSIVE_CLASS_DIVERSITY"
    elif not integrity:
        verdict = "FAIL_INTEGRITY"
    else:
        passes = (
            coverage >= float(criteria["minimum_coverage"])
            and len(errors) <= int(criteria["maximum_primary_errors"])
            and ba is not None
            and ba >= float(criteria["minimum_balanced_accuracy"])
            and min(row["compression_gain_fraction"] for row in rows) >= float(criteria["minimum_compression_gain_fraction"])
            and all(value["errors"] == 0 for value in per_n.values())
            and size_specificity
        )
        verdict = "PASS_CONFIRMED_PROGRESS" if passes else "FAIL_FROZEN_LAW"
    successful_groups = sum(value["all_primary_correct"] for value in groups.values())
    return {
        "verdict": verdict,
        "total": len(rows),
        "decisive": len(decisive),
        "abstentions": len(rows) - len(decisive),
        "coverage": coverage,
        "errors": len(errors),
        "error_rows": [row["row_id"] for row in errors],
        "accuracy": accuracy,
        "balanced_accuracy": ba,
        "row_accuracy_wilson_95_descriptive_only": wilson(len(decisive) - len(errors), len(decisive)),
        "independent_group_all_arms_successes": successful_groups,
        "independent_group_count": len(groups),
        "independent_group_success_wilson_95": wilson(successful_groups, len(groups)),
        "observed_counts": observed_counts,
        "independent_group_counts_by_class": class_groups,
        "mixed_outcome_sizes": mixed_sizes,
        "mixed_outcome_seed_groups": mixed_groups,
        "per_N": per_n,
        "minimum_compression_gain_fraction": min(row["compression_gain_fraction"] for row in rows),
        "joint_inventory_integrity": integrity,
        "same_inventory_outcome_changes": sum(item["organization_changed_outcome"] for item in groups.values()),
        "groups": groups,
        "primary_metrics": primary_metrics,
        "comparator_metrics": comparator_metrics,
        "size_specificity_pass": size_specificity,
        "latency_subanalysis": {
            "verdict": latency_verdict,
            "delayed_dense_independent_groups": delayed_dense_groups,
            "sparse_independent_groups": latency_sparse_groups,
            "metrics": latency_metrics,
            "size_only_metrics": latency_size_metrics,
            "balanced_accuracy_advantage_over_size_only": (
                latency_ba - latency_size_ba if latency_ba is not None and latency_size_ba is not None else None
            ),
        },
        "interpretation_limits": {
            "raw_projection_only": True,
            "full_state_periodicity_tested": False,
            "direction_specificity_confirmable_here": False,
            "wilson_interval_role": "DESCRIPTIVE_ONLY_DUE_TO_GROUPED_INTERVENTION_ARMS",
        },
    }


def audit() -> dict:
    checks = {
        "core_runner_exists": CORE_RUNNER.is_file(),
        "foundation_runner_exists": FOUNDATION_RUNNER.is_file(),
        "holdout_result_absent": not OUT.exists(),
        "lock_required_for_execution": True,
        "self_hash_verified_against_lock": True,
        "no_discovery_result_input": True,
        "outcome_and_prediction_implemented": True,
    }
    return {
        "schema": "dee.v27.msh01.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "runner_sha256": sha256_file(HERE),
        "core_runner_sha256": sha256_file(CORE_RUNNER),
        "foundation_runner_sha256": sha256_file(FOUNDATION_RUNNER),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if OUT.exists():
        raise RuntimeError("holdout output already exists; frozen run is single-use")
    lock, lock_file_sha = verify_lock()
    contract = lock["contract"]
    if args.threads != int(contract["execution"]["threads"]):
        raise RuntimeError("thread count differs from frozen contract")
    native = core.Native(args.threads)
    if native.environment["observed_hashes"] != contract["kernel_identity"]:
        raise RuntimeError("runtime wheel/package/kernel hashes differ from frozen contract")
    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    rows = []
    for case_spec in contract["case_specs"]:
        for seed in case_spec["seeds"]:
            for variant in contract["preparation"]["variants"]:
                rows.append(trajectory(native, case_spec, int(seed), variant, contract))
    primary = adjudicate(rows, contract)
    result = {
        "schema": "dee.v27.multiscale.msh01.holdout.v1",
        "experiment_id": "MSH01",
        "role": "CONFIRMATORY_HOLDOUT",
        "lock_file_sha256": lock_file_sha,
        "contract_payload_sha256": lock["contract_payload_sha256"],
        "runner_sha256": sha256_file(HERE),
        "core_runner_sha256": sha256_file(CORE_RUNNER),
        "foundation_runner_sha256": sha256_file(FOUNDATION_RUNNER),
        "started_utc": started_utc,
        "environment": native.environment,
        "contract": contract,
        "summary": {
            "trajectories": len(rows),
            "universe_ticks": sum(row["horizon"] for row in rows),
            "N_values": sorted({row["N"] for row in rows}),
            "seed_groups": len({row["group_id"] for row in rows}),
        },
        "primary_adjudication": primary,
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "verdict": primary["verdict"],
        "summary": result["summary"],
        "primary": {key: primary[key] for key in ("decisive", "coverage", "errors", "accuracy", "balanced_accuracy", "observed_counts", "minimum_compression_gain_fraction", "same_inventory_outcome_changes")},
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0 if primary["verdict"].startswith("PASS") else 3


if __name__ == "__main__":
    raise SystemExit(main())
