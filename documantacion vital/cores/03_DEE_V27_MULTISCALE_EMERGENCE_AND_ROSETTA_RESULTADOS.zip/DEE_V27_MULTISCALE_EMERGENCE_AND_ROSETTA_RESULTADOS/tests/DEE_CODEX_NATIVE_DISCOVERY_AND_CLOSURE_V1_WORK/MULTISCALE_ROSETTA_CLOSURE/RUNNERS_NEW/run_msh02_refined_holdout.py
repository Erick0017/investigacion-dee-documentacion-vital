#!/usr/bin/env python3
"""MSH02 prospective holdout for the refined q_N finite-window law.

The holdout is deliberately narrow.  It tests one frozen natural-manifold
classifier on public, mechanically derived and previously unused seeds.  It
does not test the post-hoc carrier decomposition found in MSD06.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
import sys
import time
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
CORE_RUNNER = HERE.with_name("run_msd02_basin_discovery.py")
FOUNDATION_RUNNER = HERE.with_name("run_msd01_v27_discovery.py")
LOCK_PATH = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json"
LOCK_SHA_PATH = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json.sha256"
OUT = ROOT / "HOLDOUTS" / "MSH02_results.json"

VARIANTS = ("baseline", "outer_semantic4", "same_inventory_joint_shuffle")
LABEL_DENSE = "DENSE_RAW_FIXED_WINDOW"
LABEL_SPARSE = "SPARSE_RAW_PERIOD_N_WINDOW"
LABEL_OTHER = "OTHER"
THRESHOLD_NUMERATOR = 3417106052812071
THRESHOLD_DENOMINATOR = 10**18
SEED_PHRASE = "DEE-v27|MSH02|v1|N={N}|group={i}"
CASE_BLUEPRINTS = (
    {"N": 33, "radii": (3, 8, 12), "counts": (25, 50, 100)},
    {"N": 38, "radii": (4, 9, 14), "counts": (30, 60, 120)},
)


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


msd02 = load_module(CORE_RUNNER, "msh02_core")
core = msd02.core


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value) -> str:
    payload = json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def atomic_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as handle:
        json.dump(value, handle, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        handle.write("\n")
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temporary, path)


def public_seed(n: int, group_index: int) -> int:
    phrase = SEED_PHRASE.format(N=int(n), i=int(group_index)).encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:4], byteorder="little", signed=False)


def positive_count_cutoff(n: int) -> int:
    volume = int(n) ** 3
    return (THRESHOLD_NUMERATOR * volume + THRESHOLD_DENOMINATOR - 1) // THRESHOLD_DENOMINATOR


def verify_lock() -> tuple[dict, str]:
    if not LOCK_PATH.is_file() or not LOCK_SHA_PATH.is_file():
        raise RuntimeError("frozen MSH02 lock and SHA sidecar are required")
    expected_file_sha = LOCK_SHA_PATH.read_text(encoding="ascii").strip().split()[0].lower()
    observed_file_sha = sha256_file(LOCK_PATH)
    if observed_file_sha != expected_file_sha:
        raise RuntimeError("MSH02 lock file SHA mismatch")
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    if lock.get("status") != "FROZEN_PRE_HOLDOUT":
        raise RuntimeError("MSH02 lock is not frozen")
    if canonical_hash(lock["contract"]) != lock["contract_payload_sha256"]:
        raise RuntimeError("MSH02 contract payload SHA mismatch")
    contract = lock["contract"]
    files = {
        "runner_sha256": HERE,
        "core_runner_sha256": CORE_RUNNER,
        "foundation_runner_sha256": FOUNDATION_RUNNER,
    }
    for field, path in files.items():
        if sha256_file(path) != contract[field]:
            raise RuntimeError(f"{field} mismatch against frozen contract")
    return lock, observed_file_sha


def verify_contract_mechanics(contract: dict) -> None:
    if contract.get("holdout_id") != "MSH02":
        raise RuntimeError("wrong holdout id")
    rational = contract["model"]["threshold_rational"]
    if int(rational["numerator"]) != THRESHOLD_NUMERATOR or int(rational["denominator"]) != THRESHOLD_DENOMINATOR:
        raise RuntimeError("threshold rational differs from executable constant")
    if tuple(contract["preparation"]["variants"]) != VARIANTS:
        raise RuntimeError("variant order differs from executable constant")
    if int(contract["execution"]["screen_horizon_multiplier"]) != 4:
        raise RuntimeError("screen horizon must be exactly 4N")
    if int(contract["execution"]["extended_horizon_multiplier"]) != 16:
        raise RuntimeError("extended horizon must be exactly 16N")
    if len(contract["case_specs"]) != len(CASE_BLUEPRINTS):
        raise RuntimeError("case count differs from executable blueprint")
    for case, blueprint in zip(contract["case_specs"], CASE_BLUEPRINTS):
        n = int(blueprint["N"])
        expected_seeds = [public_seed(n, i) for i in range(10)]
        if int(case["N"]) != n:
            raise RuntimeError("case size differs from executable blueprint")
        if tuple(int(x) for x in case["radii"]) != blueprint["radii"]:
            raise RuntimeError("case radii differ from executable blueprint")
        if tuple(int(x) for x in case["counts"]) != blueprint["counts"]:
            raise RuntimeError("case counts differ from executable blueprint")
        if [int(x) for x in case["seeds"]] != expected_seeds:
            raise RuntimeError("public seeds differ from SHA-256 derivation")
        if int(case["positive_count_cutoff_at_N"]) != positive_count_cutoff(n):
            raise RuntimeError("integer q_N cutoff differs from exact rational ceiling")
    execution = contract["execution"]
    if (
        int(execution["planned_seed_groups"]) != 20
        or int(execution["planned_trajectories"]) != 60
        or int(execution["planned_minimum_universe_ticks"]) != 8520
        or int(execution["planned_worst_case_universe_ticks"]) != 34080
    ):
        raise RuntimeError("planned execution counts differ from executable design")
    comparators = contract["comparators"]
    if (
        int(comparators["size_threshold_N"]) != 38
        or int(comparators["size_plus_arm_threshold_N"]) != 38
        or comparators["size_plus_arm_dense_override"] != "outer_semantic4"
    ):
        raise RuntimeError("frozen nuisance-null constants differ from executable design")
    criteria = contract["adjudication"]
    required_criteria = {
        "minimum_primary_coverage": 1.0,
        "maximum_primary_errors": 0,
        "maximum_other_outcomes": 0,
        "minimum_balanced_accuracy": 0.95,
        "per_size_maximum_errors": 0,
        "minimum_independent_groups_each_class": 4,
        "minimum_mixed_seed_groups": 2,
        "minimum_balanced_accuracy_advantage_over_best_null": 0.10,
        "minimum_delayed_dense_groups_pre_crossing": 4,
        "minimum_sparse_groups_pre_crossing": 4,
        "maximum_pre_crossing_errors": 0,
        "minimum_pre_crossing_balanced_accuracy": 0.95,
        "minimum_pre_crossing_balanced_accuracy_advantage_over_best_null": 0.10,
        "minimum_compression_gain_fraction": 0.99999,
    }
    if any(criteria.get(field) != value for field, value in required_criteria.items()):
        raise RuntimeError("adjudication criteria differ from executable design")


def make_spec(case_spec: dict) -> dict:
    n = int(case_spec["N"])
    return {
        "N": n,
        "radii": tuple(int(x) for x in case_spec["radii"]),
        "counts": tuple(int(x) for x in case_spec["counts"]),
        "horizon": 16 * n,
    }


def reconstruct(case_spec: dict, seed: int, variant: str):
    spec = make_spec(case_spec)
    raw, clock, layers, construction = core.make_base(spec, seed)
    variants = core.build_variants(raw, clock, layers[-1], seed)
    return variants[variant], layers, construction


def minimal_exact_tail_period(
    raw_series: list[np.ndarray],
    *,
    max_period: int,
    repeats: int,
) -> tuple[int | None, list[str]]:
    """Return the least exact period across the final ``repeats`` blocks.

    SHA-256 is used only as a cheap rejection filter.  Every surviving
    candidate is verified with ``np.array_equal`` for every corresponding
    full raw array, so the returned period is not a hash-only assertion.
    """
    if repeats < 2:
        raise ValueError("repeats must be at least two")
    hashes = [core.sha256_array(raw) for raw in raw_series]
    for period in range(1, int(max_period) + 1):
        span = repeats * period
        if span > len(raw_series):
            continue
        start = len(raw_series) - span
        reference_hashes = hashes[start : start + period]
        if any(
            hashes[start + block * period : start + (block + 1) * period] != reference_hashes
            for block in range(1, repeats)
        ):
            continue
        exact = True
        for offset in range(period):
            reference = raw_series[start + offset]
            for block in range(1, repeats):
                if not np.array_equal(reference, raw_series[start + block * period + offset]):
                    exact = False
                    break
            if not exact:
                break
        if exact:
            return period, hashes
    return None, hashes


def trajectory(native, case_spec: dict, seed: int, variant: str, contract: dict) -> dict:
    spec = make_spec(case_spec)
    n = int(spec["N"])
    volume = n**3
    screen_horizon = 4 * n
    extended_horizon = 16 * n
    q_cutoff = int(case_spec["positive_count_cutoff_at_N"])
    (raw0, clock0), layers, construction = reconstruct(case_spec, seed, variant)
    outer = layers[-1]
    center = np.array(construction["center"], dtype=np.int64)
    radius_grid = core.cheb_radius_grid(n, center)
    inner = radius_grid <= int(spec["radii"][0])
    middle = radius_grid <= int(spec["radii"][1])
    initial_inventory = core.multiset_hash(raw0, clock0, outer, True)
    u = native.new(raw0, clock0)

    first_05 = None
    first_09 = None
    q_count_n = None
    routing_count_n = None
    raw_sha_n = None
    clock_sha_n = None
    max_positive_count_from_n = 0
    stage1_tail: list[np.ndarray] = []
    stage1_tail_counts: list[int] = []
    trace: list[dict] = []
    trace_ticks = {0, int(math.ceil(n / 2)), n, 2 * n, 3 * n, 4 * n, 8 * n, 12 * n, 16 * n}

    def observe(tick: int, raw: np.ndarray, clock: np.ndarray) -> None:
        nonlocal first_05, first_09, q_count_n, routing_count_n, raw_sha_n, clock_sha_n
        nonlocal max_positive_count_from_n
        metric = msd02.actual_metrics(raw, n, inner, middle)
        positive = int(metric["occupancy"])
        crossed_now = False
        if first_05 is None and 2 * positive >= volume:
            first_05 = tick
            crossed_now = True
        if first_09 is None and 10 * positive >= 9 * volume:
            first_09 = tick
            crossed_now = True
        if tick == n:
            q_count_n = positive
            routing_count_n = int(metric["direction_nonzero"])
            raw_sha_n = core.sha256_array(raw)
            clock_sha_n = core.sha256_array(clock)
        if tick >= n:
            max_positive_count_from_n = max(max_positive_count_from_n, positive)
        if tick in trace_ticks or crossed_now:
            trace.append({
                "tick": tick,
                "positive_state_count": positive,
                "positive_state_fraction": positive / volume,
                "direction_nonzero": int(metric["direction_nonzero"]),
                "raw_nonzero": int(metric["raw_nonzero"]),
                "sreg_sum": int(metric["sreg_sum"]),
                "semantic4": int(metric["semantic4"]),
                "semantic7_xnor": int(metric["semantic7_xnor"]),
                "raw_sha256": core.sha256_array(raw),
                "clock_sha256": core.sha256_array(clock),
            })

    for tick in range(screen_horizon + 1):
        raw, clock = native.snap(u)
        observe(tick, raw, clock)
        if tick >= 3 * n:
            stage1_tail.append(raw)
            stage1_tail_counts.append(int(np.count_nonzero(core.fields(raw)["state"] > 0)))
        if tick < screen_horizon:
            u.tick(1)

    if q_count_n is None or routing_count_n is None or raw_sha_n is None or clock_sha_n is None:
        raise AssertionError("tick-N measurement was not recorded")
    first_05_by_4n = first_05
    first_09_by_4n = first_09
    dense_period_1_exact = all(
        np.array_equal(stage1_tail[index - 1], stage1_tail[index])
        for index in range(1, len(stage1_tail))
    )
    dense_tail_persistent = all(10 * count >= 9 * volume for count in stage1_tail_counts)
    dense = (
        first_05_by_4n is not None
        and first_09_by_4n is not None
        and dense_tail_persistent
        and dense_period_1_exact
    )

    evaluated_horizon = screen_horizon
    minimal_period = None
    period_search_hashes: list[str] = []
    if dense:
        observed = LABEL_DENSE
        adaptive_branch = "STOP_DENSE_AT_4N"
    else:
        adaptive_branch = "EXTEND_NON_DENSE_TO_16N"
        long_tail = [stage1_tail[-1]]
        for tick in range(screen_horizon + 1, extended_horizon + 1):
            u.tick(1)
            raw, clock = native.snap(u)
            observe(tick, raw, clock)
            long_tail.append(raw)
        evaluated_horizon = extended_horizon
        minimal_period, period_search_hashes = minimal_exact_tail_period(
            long_tail,
            max_period=4 * n,
            repeats=3,
        )
        sparse = 100 * max_positive_count_from_n < volume and minimal_period == n
        observed = LABEL_SPARSE if sparse else LABEL_OTHER

    prediction = LABEL_DENSE if q_count_n >= q_cutoff else LABEL_SPARSE
    routing_prediction = LABEL_DENSE if routing_count_n >= q_cutoff else LABEL_SPARSE
    size_prediction = LABEL_DENSE if n >= int(contract["comparators"]["size_threshold_N"]) else LABEL_SPARSE
    size_arm_prediction = (
        LABEL_DENSE
        if n >= int(contract["comparators"]["size_plus_arm_threshold_N"])
        or variant == contract["comparators"]["size_plus_arm_dense_override"]
        else LABEL_SPARSE
    )
    descriptor_bits = math.ceil(math.log2(volume + 1))
    microstate_bits = 128 * volume
    pre_crossing_at_n = first_05_by_4n is None or first_05_by_4n > n
    retained_hash_count = 0
    retained_hash_start_tick = None
    retained_hashes: list[str] = []
    if period_search_hashes:
        retained_hash_count = min(len(period_search_hashes), 3 * n)
        retained_hashes = period_search_hashes[-retained_hash_count:]
        retained_hash_start_tick = extended_horizon - retained_hash_count + 1

    return {
        "row_id": f"N{n}_seed{seed}_{variant}",
        "group_id": f"N{n}_seed{seed}",
        "N": n,
        "seed": seed,
        "variant": variant,
        "screen_horizon": screen_horizon,
        "evaluated_horizon": evaluated_horizon,
        "adaptive_branch": adaptive_branch,
        "initial_raw_sha256": core.sha256_array(raw0),
        "initial_clock_sha256": core.sha256_array(clock0),
        "initial_outer_joint_inventory_sha256": initial_inventory,
        "positive_state_count_N": q_count_n,
        "positive_state_fraction_N": q_count_n / volume,
        "positive_state_count_cutoff_N": q_cutoff,
        "direction_nonzero_count_N": routing_count_n,
        "direction_nonzero_fraction_N": routing_count_n / volume,
        "raw_sha256_N": raw_sha_n,
        "clock_sha256_N": clock_sha_n,
        "pre_crossing_cohort_at_N": pre_crossing_at_n,
        "prediction": prediction,
        "observed": observed,
        "correct": prediction == observed,
        "comparator_predictions": {
            "always_dense": LABEL_DENSE,
            "size_only": size_prediction,
            "size_plus_arm": size_arm_prediction,
            "direction_support_N_same_cutoff": routing_prediction,
        },
        "first_passage_0_5_by_4N": first_05_by_4n,
        "first_passage_0_9_by_4N": first_09_by_4n,
        "first_passage_0_5_observed": first_05,
        "first_passage_0_9_observed": first_09,
        "dense_tail_positive_count_min_3N_to_4N": min(stage1_tail_counts),
        "dense_tail_positive_count_max_3N_to_4N": max(stage1_tail_counts),
        "dense_tail_ge_0_9_exact": dense_tail_persistent,
        "dense_raw_period_1_exact_3N_to_4N": dense_period_1_exact,
        "max_positive_state_count_N_to_evaluated_horizon": max_positive_count_from_n,
        "sparse_ceiling_strict_exact": 100 * max_positive_count_from_n < volume,
        "minimal_exact_tail_period_raw": minimal_period,
        "period_search_max_period": 4 * n if not dense else None,
        "period_search_repeats": 3 if not dense else None,
        "period_search_exact_full_arrays": not dense,
        "terminal_raw_hashes_descriptive": {
            "start_tick": retained_hash_start_tick,
            "end_tick": extended_horizon if retained_hashes else None,
            "count": retained_hash_count,
            "sha256": retained_hashes,
            "role": "descriptive audit trail; exact period decision used full arrays",
        },
        "descriptor_bits": descriptor_bits,
        "microstate_bits": microstate_bits,
        "compression_gain_fraction": 1 - descriptor_bits / microstate_bits,
        "trace": trace,
    }


def balanced_accuracy_exact(rows: list[dict], getter) -> Fraction | None:
    recalls = []
    for label in (LABEL_DENSE, LABEL_SPARSE):
        subset = [row for row in rows if row["observed"] == label]
        if subset:
            recalls.append(Fraction(sum(getter(row) == label for row in subset), len(subset)))
    return sum(recalls, Fraction(0, 1)) / 2 if len(recalls) == 2 else None


def balanced_accuracy(rows: list[dict], getter) -> float | None:
    exact = balanced_accuracy_exact(rows, getter)
    return float(exact) if exact is not None else None


def evaluate_predictions(rows: list[dict], getter) -> dict:
    errors = [row for row in rows if getter(row) != row["observed"]]
    return {
        "total": len(rows),
        "coverage": 1.0 if rows else None,
        "errors": len(errors),
        "error_rows": [row["row_id"] for row in errors],
        "accuracy": (len(rows) - len(errors)) / len(rows) if rows else None,
        "balanced_accuracy": balanced_accuracy(rows, getter),
    }


def wilson(successes: int, n: int, z: float = 1.959963984540054) -> dict:
    if n == 0:
        return {"lower": None, "upper": None}
    p = successes / n
    denominator = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denominator
    half = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denominator
    return {"lower": center - half, "upper": center + half}


def adjudicate(rows: list[dict], contract: dict) -> dict:
    labels = (LABEL_DENSE, LABEL_SPARSE, LABEL_OTHER)
    expected_variants = tuple(contract["preparation"]["variants"])
    expected_sizes = {int(case["N"]) for case in contract["case_specs"]}
    expected_groups = int(contract["execution"]["planned_seed_groups"])
    expected_rows = int(contract["execution"]["planned_trajectories"])
    observed_counts = {label: sum(row["observed"] == label for row in rows) for label in labels}
    primary = evaluate_predictions(rows, lambda row: row["prediction"])
    comparator_metrics = {
        name: evaluate_predictions(rows, lambda row, name=name: row["comparator_predictions"][name])
        for name in ("always_dense", "size_only", "size_plus_arm", "direction_support_N_same_cutoff")
    }
    per_n = {}
    for n in sorted(expected_sizes):
        subset = [row for row in rows if row["N"] == n]
        metrics = evaluate_predictions(subset, lambda row: row["prediction"])
        metrics["observed_counts"] = {label: sum(row["observed"] == label for row in subset) for label in labels}
        per_n[str(n)] = metrics

    groups = {}
    for group_id in sorted({row["group_id"] for row in rows}):
        arms = {row["variant"]: row for row in rows if row["group_id"] == group_id}
        variants_exact = tuple(sorted(arms)) == tuple(sorted(expected_variants))
        baseline = arms.get("baseline")
        shuffle = arms.get("same_inventory_joint_shuffle")
        inventory_exact = bool(
            baseline
            and shuffle
            and baseline["initial_outer_joint_inventory_sha256"]
            == shuffle["initial_outer_joint_inventory_sha256"]
        )
        geometry_changed = bool(
            baseline
            and shuffle
            and (
                baseline["initial_raw_sha256"] != shuffle["initial_raw_sha256"]
                or baseline["initial_clock_sha256"] != shuffle["initial_clock_sha256"]
            )
        )
        outcomes = sorted({row["observed"] for row in arms.values()})
        groups[group_id] = {
            "variants_exact": variants_exact,
            "baseline_shuffle_joint_inventory_exact": inventory_exact,
            "baseline_shuffle_geometry_changed": geometry_changed,
            "outcomes": outcomes,
            "mixed_dense_sparse": LABEL_DENSE in outcomes and LABEL_SPARSE in outcomes,
            "all_primary_correct": all(row["correct"] for row in arms.values()),
            "all_pre_crossing_at_N": all(row["pre_crossing_cohort_at_N"] for row in arms.values()),
        }

    class_groups = {
        label: len({row["group_id"] for row in rows if row["observed"] == label})
        for label in (LABEL_DENSE, LABEL_SPARSE)
    }
    mixed_groups = [group for group, value in groups.items() if value["mixed_dense_sparse"]]
    pre_crossing_rows = [row for row in rows if row["pre_crossing_cohort_at_N"]]
    pre_crossing_fraction = len(pre_crossing_rows) / len(rows) if rows else 0.0
    integrity = all(
        value["variants_exact"]
        and value["baseline_shuffle_joint_inventory_exact"]
        and value["baseline_shuffle_geometry_changed"]
        for value in groups.values()
    )
    protocol_complete = (
        len(rows) == expected_rows
        and len(groups) == expected_groups
        and {row["N"] for row in rows} == expected_sizes
        and all(len([row for row in rows if row["N"] == n]) == expected_rows // len(expected_sizes) for n in expected_sizes)
    )
    criteria = contract["adjudication"]
    enough_diversity = (
        all(count >= int(criteria["minimum_independent_groups_each_class"]) for count in class_groups.values())
        and len(mixed_groups) >= int(criteria["minimum_mixed_seed_groups"])
    )
    null_names = ("always_dense", "size_only", "size_plus_arm")
    primary_ba_exact = balanced_accuracy_exact(rows, lambda row: row["prediction"])
    primary_ba = float(primary_ba_exact) if primary_ba_exact is not None else None
    full_null_bas = {name: comparator_metrics[name]["balanced_accuracy"] for name in null_names}
    full_null_bas_exact = {
        name: balanced_accuracy_exact(rows, lambda row, name=name: row["comparator_predictions"][name])
        for name in null_names
    }
    full_defined_null_bas_exact = {name: value for name, value in full_null_bas_exact.items() if value is not None}
    best_full_null_name = (
        max(full_defined_null_bas_exact, key=full_defined_null_bas_exact.get)
        if full_defined_null_bas_exact
        else None
    )
    best_full_null_ba_exact = full_defined_null_bas_exact.get(best_full_null_name) if best_full_null_name else None
    full_best_null_advantage_exact = (
        primary_ba_exact - best_full_null_ba_exact
        if primary_ba_exact is not None and best_full_null_ba_exact is not None
        else None
    )
    best_full_null_ba = float(best_full_null_ba_exact) if best_full_null_ba_exact is not None else None
    full_best_null_advantage = (
        float(full_best_null_advantage_exact) if full_best_null_advantage_exact is not None else None
    )

    pre_primary = evaluate_predictions(pre_crossing_rows, lambda row: row["prediction"])
    pre_null_metrics = {
        name: evaluate_predictions(
            pre_crossing_rows,
            lambda row, name=name: row["comparator_predictions"][name],
        )
        for name in null_names
    }
    pre_primary_ba_exact = balanced_accuracy_exact(pre_crossing_rows, lambda row: row["prediction"])
    pre_null_bas_exact = {
        name: balanced_accuracy_exact(
            pre_crossing_rows,
            lambda row, name=name: row["comparator_predictions"][name],
        )
        for name in null_names
    }
    pre_defined_null_bas_exact = {name: value for name, value in pre_null_bas_exact.items() if value is not None}
    best_pre_null_name = (
        max(pre_defined_null_bas_exact, key=pre_defined_null_bas_exact.get)
        if pre_defined_null_bas_exact
        else None
    )
    best_pre_null_ba_exact = pre_defined_null_bas_exact.get(best_pre_null_name) if best_pre_null_name else None
    pre_best_null_advantage_exact = (
        pre_primary_ba_exact - best_pre_null_ba_exact
        if pre_primary_ba_exact is not None and best_pre_null_ba_exact is not None
        else None
    )
    best_pre_null_ba = float(best_pre_null_ba_exact) if best_pre_null_ba_exact is not None else None
    pre_best_null_advantage = (
        float(pre_best_null_advantage_exact) if pre_best_null_advantage_exact is not None else None
    )
    delayed_dense_groups = len({
        row["group_id"]
        for row in pre_crossing_rows
        if row["observed"] == LABEL_DENSE
    })
    pre_sparse_groups = len({
        row["group_id"]
        for row in pre_crossing_rows
        if row["observed"] == LABEL_SPARSE
    })
    enough_pre_crossing_diversity = (
        delayed_dense_groups >= int(criteria["minimum_delayed_dense_groups_pre_crossing"])
        and pre_sparse_groups >= int(criteria["minimum_sparse_groups_pre_crossing"])
    )
    pre_crossing_core_performance_pass = (
        pre_primary["errors"] <= int(criteria["maximum_pre_crossing_errors"])
        and pre_primary_ba_exact is not None
        and pre_primary_ba_exact >= Fraction(95, 100)
    )
    pre_crossing_incremental_value_pass = (
        pre_best_null_advantage_exact is not None
        and pre_best_null_advantage_exact >= Fraction(1, 10)
    )

    compression_min = min((row["compression_gain_fraction"] for row in rows), default=None)
    full_core_performance_pass = (
        primary["coverage"] == float(criteria["minimum_primary_coverage"])
        and primary["errors"] <= int(criteria["maximum_primary_errors"])
        and primary_ba_exact is not None
        and primary_ba_exact >= Fraction(95, 100)
        and all(metrics["errors"] <= int(criteria["per_size_maximum_errors"]) for metrics in per_n.values())
        and compression_min is not None
        and compression_min >= float(criteria["minimum_compression_gain_fraction"])
    )
    full_incremental_value_pass = (
        full_best_null_advantage_exact is not None
        and full_best_null_advantage_exact >= Fraction(1, 10)
    )
    any_primary_or_per_size_error = (
        primary["errors"] > int(criteria["maximum_primary_errors"])
        or any(metrics["errors"] > int(criteria["per_size_maximum_errors"]) for metrics in per_n.values())
    )

    if not protocol_complete:
        verdict = "FAIL_PROTOCOL_INCOMPLETE"
    elif not integrity:
        verdict = "FAIL_INTEGRITY"
    elif (
        observed_counts[LABEL_OTHER] > int(criteria["maximum_other_outcomes"])
        or any_primary_or_per_size_error
    ):
        verdict = "FAIL_FROZEN_LAW"
    elif not enough_diversity:
        verdict = "INCONCLUSIVE_CLASS_DIVERSITY"
    elif not full_core_performance_pass:
        verdict = "FAIL_FROZEN_LAW"
    elif not full_incremental_value_pass:
        verdict = "FAIL_INCREMENTAL_VALUE"
    elif not enough_pre_crossing_diversity:
        verdict = "INCONCLUSIVE_PRE_CROSSING_DIVERSITY"
    elif not pre_crossing_core_performance_pass:
        verdict = "FAIL_FROZEN_LAW"
    elif not pre_crossing_incremental_value_pass:
        verdict = "FAIL_INCREMENTAL_VALUE"
    else:
        verdict = "PASS_CONFIRMED_PROGRESS"

    pre_crossing_verdict = (
        "INCONCLUSIVE_PRE_CROSSING_DIVERSITY"
        if not enough_pre_crossing_diversity
        else "FAIL_PRE_CROSSING_SUBSET"
        if not pre_crossing_core_performance_pass
        else "FAIL_INCREMENTAL_VALUE"
        if not pre_crossing_incremental_value_pass
        else "PASS_PRE_CROSSING_SUBSET"
    )

    successful_groups = sum(value["all_primary_correct"] for value in groups.values())
    return {
        "verdict": verdict,
        "total": len(rows),
        "prediction_coverage": primary["coverage"],
        "pre_crossing_cohort_rows": len(pre_crossing_rows),
        "pre_crossing_cohort_fraction_descriptive": pre_crossing_fraction,
        "observed_counts": observed_counts,
        "primary_metrics": primary,
        "per_N": per_n,
        "comparator_metrics": comparator_metrics,
        "full_panel_best_null": {
            "name": best_full_null_name,
            "balanced_accuracy": best_full_null_ba,
            "primary_balanced_accuracy_advantage": full_best_null_advantage,
            "primary_balanced_accuracy_advantage_exact": (
                f"{full_best_null_advantage_exact.numerator}/{full_best_null_advantage_exact.denominator}"
                if full_best_null_advantage_exact is not None
                else None
            ),
            "null_balanced_accuracies": full_null_bas,
        },
        "pre_crossing_subanalysis": {
            "verdict": pre_crossing_verdict,
            "eligible_rows": len(pre_crossing_rows),
            "eligible_fraction_descriptive": pre_crossing_fraction,
            "delayed_dense_independent_groups": delayed_dense_groups,
            "sparse_independent_groups": pre_sparse_groups,
            "enough_diversity": enough_pre_crossing_diversity,
            "core_performance_pass": pre_crossing_core_performance_pass,
            "incremental_value_pass": pre_crossing_incremental_value_pass,
            "primary_metrics": pre_primary,
            "null_metrics": pre_null_metrics,
            "best_null_name": best_pre_null_name,
            "best_null_balanced_accuracy": best_pre_null_ba,
            "primary_balanced_accuracy_advantage_over_best_null": pre_best_null_advantage,
            "primary_balanced_accuracy_advantage_over_best_null_exact": (
                f"{pre_best_null_advantage_exact.numerator}/{pre_best_null_advantage_exact.denominator}"
                if pre_best_null_advantage_exact is not None
                else None
            ),
        },
        "independent_group_counts_by_class": class_groups,
        "mixed_outcome_seed_groups": mixed_groups,
        "independent_group_all_arms_successes": successful_groups,
        "independent_group_count": len(groups),
        "independent_group_success_wilson_95": wilson(successful_groups, len(groups)),
        "joint_inventory_and_shuffle_integrity": integrity,
        "protocol_complete": protocol_complete,
        "enough_class_diversity": enough_diversity,
        "full_core_performance_pass": full_core_performance_pass,
        "full_incremental_value_pass": full_incremental_value_pass,
        "minimum_compression_gain_fraction": compression_min,
        "groups": groups,
        "interpretation_limits": {
            "natural_preparation_family_only": True,
            "raw_projection_only": True,
            "finite_horizon_only": True,
            "q_N_causal_sufficiency_tested": False,
            "carrier_decomposition_tested": False,
            "full_state_periodicity_tested": False,
            "secondary_comparators_cannot_rescue_primary": True,
        },
    }


def audit() -> dict:
    expected_seeds = {n: [public_seed(n, i) for i in range(10)] for n in (33, 38)}
    checks = {
        "core_runner_exists": CORE_RUNNER.is_file(),
        "foundation_runner_exists": FOUNDATION_RUNNER.is_file(),
        "holdout_result_absent": not OUT.exists(),
        "single_use_output_guard_present": True,
        "frozen_lock_required_for_execution": True,
        "self_hash_verified_against_lock": True,
        "no_discovery_result_loaded": True,
        "public_seed_derivation_deterministic": len({seed for values in expected_seeds.values() for seed in values}) == 20,
        "exact_integer_threshold_implemented": positive_count_cutoff(33) == 123 and positive_count_cutoff(38) == 188,
        "adaptive_4N_to_16N_implemented": True,
        "minimal_period_uses_full_array_verification": True,
        "pre_crossing_is_prospectively_defined_subset": True,
        "best_of_three_nulls_challenged": True,
        "other_is_primary_error": True,
    }
    return {
        "schema": "dee.v27.msh02.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "public_seeds": expected_seeds,
        "integer_positive_count_cutoffs": {"33": positive_count_cutoff(33), "38": positive_count_cutoff(38)},
        "runner_sha256": sha256_file(HERE),
        "core_runner_sha256": sha256_file(CORE_RUNNER),
        "foundation_runner_sha256": sha256_file(FOUNDATION_RUNNER),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    static = audit()
    if args.audit_only:
        print(json.dumps(static, indent=2, sort_keys=True))
        return 0 if static["status"] == "PASS" else 2
    if OUT.exists():
        raise RuntimeError("MSH02 output already exists; frozen holdout run is single-use")
    lock, lock_file_sha = verify_lock()
    contract = lock["contract"]
    verify_contract_mechanics(contract)
    if args.threads != int(contract["execution"]["threads"]):
        raise RuntimeError("thread count differs from frozen contract")
    native = core.Native(args.threads)
    if native.environment["observed_hashes"] != contract["kernel_identity"]:
        raise RuntimeError("runtime wheel/package/kernel hashes differ from frozen contract")

    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    rows = []
    for case_spec in contract["case_specs"]:
        for seed in case_spec["seeds"]:
            for variant in contract["preparation"]["variants"]:
                rows.append(trajectory(native, case_spec, int(seed), variant, contract))
    primary = adjudicate(rows, contract)
    result = {
        "schema": "dee.v27.multiscale.msh02.holdout.v1",
        "experiment_id": "MSH02",
        "role": "CONFIRMATORY_HOLDOUT",
        "lock_file_sha256": lock_file_sha,
        "contract_payload_sha256": lock["contract_payload_sha256"],
        "runner_sha256": sha256_file(HERE),
        "core_runner_sha256": sha256_file(CORE_RUNNER),
        "foundation_runner_sha256": sha256_file(FOUNDATION_RUNNER),
        "started_utc": started_utc,
        "environment": native.environment,
        "contract": contract,
        "summary": {
            "trajectories": len(rows),
            "universe_ticks": sum(row["evaluated_horizon"] for row in rows),
            "N_values": sorted({row["N"] for row in rows}),
            "seed_groups": len({row["group_id"] for row in rows}),
            "stopped_dense_at_4N": sum(row["adaptive_branch"] == "STOP_DENSE_AT_4N" for row in rows),
            "extended_non_dense_to_16N": sum(row["adaptive_branch"] == "EXTEND_NON_DENSE_TO_16N" for row in rows),
        },
        "primary_adjudication": primary,
        "rows": rows,
        "elapsed_seconds": time.perf_counter() - started,
    }
    atomic_json(OUT, result)
    print(json.dumps({
        "status": "COMPLETE",
        "verdict": primary["verdict"],
        "summary": result["summary"],
        "primary": {
            key: primary[key]
            for key in (
                "prediction_coverage",
                "pre_crossing_cohort_rows",
                "pre_crossing_cohort_fraction_descriptive",
                "observed_counts",
                "full_panel_best_null",
                "pre_crossing_subanalysis",
                "minimum_compression_gain_fraction",
            )
        },
        "output": str(OUT),
        "output_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0 if primary["verdict"].startswith("PASS") else 3


if __name__ == "__main__":
    raise SystemExit(main())
