#!/usr/bin/env python3
"""Read-only preflight validator for the MSH01 draft before irreversible opening."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
DRAFT = ROOT / "ANALYSIS" / "HOLDOUT_MSH01_LOCK_DRAFT.json"
DISCOVERY = ROOT / "RESULTS" / "MSD02_results.json"
FILES = {
    "runner_sha256": ROOT / "RUNNERS_NEW" / "run_msh01_growth_holdout.py",
    "core_runner_sha256": ROOT / "RUNNERS_NEW" / "run_msd02_basin_discovery.py",
    "foundation_runner_sha256": ROOT / "RUNNERS_NEW" / "run_msd01_v27_discovery.py",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    draft = json.loads(DRAFT.read_text(encoding="utf-8"))
    contract = draft["contract"]
    discovery = json.loads(DISCOVERY.read_text(encoding="utf-8"))
    cases = contract["case_specs"]
    sizes = [int(case["N"]) for case in cases]
    seeds = [int(seed) for case in cases for seed in case["seeds"]]
    variants = contract["preparation"]["variants"]
    observed_sizes = sorted({int(row["N"]) for row in discovery["rows"]})
    observed_pairs = {(int(row["N"]), int(row["seed"])) for row in discovery["rows"]}
    proposed_pairs = {(int(case["N"]), int(seed)) for case in cases for seed in case["seeds"]}
    calculated_groups = len(seeds)
    calculated_trajectories = calculated_groups * len(variants)
    calculated_ticks = sum(int(case["N"]) * int(case["horizon_multiplier"]) * len(case["seeds"]) * len(variants) for case in cases)
    checks = {
        "draft_ready": draft["status"] == "READY_TO_FREEZE_PRE_HOLDOUT",
        "holdout_unopened": not (ROOT / "HOLDOUTS" / "MSH01_results.json").exists(),
        "final_lock_absent": not (ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json").exists(),
        "sidecar_absent": not (ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json.sha256").exists(),
        "runner_hashes_match": all(sha256(path) == contract[field] for field, path in FILES.items()),
        "sizes_unseen": not set(sizes).intersection(observed_sizes),
        "seed_pairs_unseen": not proposed_pairs.intersection(observed_pairs),
        "seeds_unique": len(seeds) == len(set(seeds)),
        "odd_even_challenge": any(n % 2 for n in sizes) and any(n % 2 == 0 for n in sizes),
        "horizon_exact_4N": all(int(case["horizon_multiplier"]) == 4 for case in cases),
        "counts_match": contract["execution"]["planned_seed_groups"] == calculated_groups and contract["execution"]["planned_trajectories"] == calculated_trajectories and contract["execution"]["planned_universe_ticks"] == calculated_ticks,
        "threads_one": contract["execution"]["threads"] == 1,
        "primary_threshold_exact": contract["model"]["positive_state_fraction_threshold"] == 0.003417106052812071,
        "size_null_exact": contract["comparators"]["size_threshold_N"] == 38,
        "group_criteria_exact": contract["adjudication"]["minimum_independent_groups_each_class"] == 4 and contract["adjudication"]["minimum_mixed_seed_groups"] == 2,
        "size_advantage_exact": contract["adjudication"]["minimum_balanced_accuracy_advantage_over_size_only"] == 0.10,
        "latency_diversity_exact": contract["adjudication"]["minimum_delayed_dense_groups_for_latency"] == 4 and contract["adjudication"]["minimum_sparse_groups_for_latency"] == 4,
        "direction_N_comparator_present": "direction_fraction_N_threshold" in contract["comparators"],
    }
    output = {
        "schema": "dee.v27.msh01.lock_draft_preflight.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "sizes": sizes,
        "discovery_sizes": observed_sizes,
        "calculated_seed_groups": calculated_groups,
        "calculated_trajectories": calculated_trajectories,
        "calculated_universe_ticks": calculated_ticks,
        "observed_file_hashes": {field: sha256(path) for field, path in FILES.items()},
        "draft_file_sha256": sha256(DRAFT),
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
