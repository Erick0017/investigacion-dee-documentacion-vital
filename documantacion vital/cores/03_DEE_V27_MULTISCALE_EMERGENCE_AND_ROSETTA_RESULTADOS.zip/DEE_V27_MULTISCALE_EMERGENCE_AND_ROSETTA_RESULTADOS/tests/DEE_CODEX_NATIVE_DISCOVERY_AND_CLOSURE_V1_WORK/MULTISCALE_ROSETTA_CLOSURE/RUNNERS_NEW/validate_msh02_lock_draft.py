#!/usr/bin/env python3
"""Read-only, adversarial preflight for the unopened MSH02 draft."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
TESTS = ROOT.parents[1]
DRAFT = ROOT / "ANALYSIS" / "HOLDOUT_MSH02_LOCK_DRAFT.json"
LOCK = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json"
SIDECAR = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH02_LOCK.json.sha256"
RESULT = ROOT / "HOLDOUTS" / "MSH02_results.json"
SELF_EXCLUSIONS = {DRAFT.resolve(), LOCK.resolve(), RESULT.resolve()}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def public_seed(n: int, index: int, phrase_template: str) -> int:
    phrase = phrase_template.format(N=int(n), i=int(index)).encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:4], "little", signed=False)


def prior_numeric_field_hits(field: str, proposed: set[int]) -> list[dict]:
    """Find exact numeric fields in every prior JSON result/holdout under tests."""
    expression = re.compile(rf'"{re.escape(field)}"\s*:\s*(\d+)')
    hits = []
    for path in TESTS.rglob("*.json"):
        resolved = path.resolve()
        if resolved in SELF_EXCLUSIONS:
            continue
        upper_parts = {part.upper() for part in path.parts}
        if not ({"RESULTS", "HOLDOUTS"} & upper_parts):
            continue
        try:
            with path.open("r", encoding="utf-8") as handle:
                for line_number, line in enumerate(handle, start=1):
                    for match in expression.finditer(line):
                        seed = int(match.group(1))
                        if seed in proposed:
                            hits.append({"path": str(path), "line": line_number, "field": field, "value": seed})
        except (OSError, UnicodeError):
            hits.append({"path": str(path), "line": None, "field": field, "value": None, "error": "UNREADABLE_JSON"})
    return hits


def main() -> int:
    draft = json.loads(DRAFT.read_text(encoding="utf-8"))
    contract = draft["contract"]
    cases = contract["case_specs"]
    variants = tuple(contract["preparation"]["variants"])
    phrase = contract["seed_derivation"]["phrase_template"]
    proposed = [int(seed) for case in cases for seed in case["seeds"]]
    derived = {
        int(case["N"]): [public_seed(int(case["N"]), index, phrase) for index in range(10)]
        for case in cases
    }
    declared = {int(case["N"]): [int(seed) for seed in case["seeds"]] for case in cases}
    prior_hits = prior_numeric_field_hits("seed", set(proposed))
    prior_size_hits = prior_numeric_field_hits("N", {33, 38})
    file_paths = {
        "runner_sha256": ROOT / contract["runner"],
        "core_runner_sha256": ROOT / contract["core_runner"],
        "foundation_runner_sha256": ROOT / contract["foundation_runner"],
        "freeze_runner_sha256": ROOT / contract["freeze_runner"],
        "draft_validator_sha256": HERE,
        "frozen_verifier_sha256": ROOT / contract["frozen_verifier"],
    }
    calculated_groups = sum(len(case["seeds"]) for case in cases)
    calculated_rows = calculated_groups * len(variants)
    min_ticks = sum(4 * int(case["N"]) * len(case["seeds"]) * len(variants) for case in cases)
    max_ticks = sum(16 * int(case["N"]) * len(case["seeds"]) * len(variants) for case in cases)
    rational = contract["model"]["threshold_rational"]
    numerator = int(rational["numerator"])
    denominator = int(rational["denominator"])
    calculated_cutoffs = {
        int(case["N"]): (numerator * int(case["N"]) ** 3 + denominator - 1) // denominator
        for case in cases
    }
    declared_cutoffs = {int(case["N"]): int(case["positive_count_cutoff_at_N"]) for case in cases}
    checks = {
        "draft_ready": draft.get("status") == "READY_TO_FREEZE_PRE_HOLDOUT",
        "holdout_id_exact": contract.get("holdout_id") == "MSH02",
        "holdout_unopened": not RESULT.exists(),
        "final_lock_absent": not LOCK.exists(),
        "sidecar_absent": not SIDECAR.exists(),
        "all_transitive_file_hashes_match": all(sha256(path) == contract[field] for field, path in file_paths.items()),
        "public_seed_lists_match_derivation": declared == derived,
        "public_seeds_globally_unique": len(proposed) == len(set(proposed)) == 20,
        "public_seeds_unseen_in_prior_results_across_tests": not prior_hits,
        "sizes_unseen_in_prior_results_across_tests": not prior_size_hits,
        "sizes_exact": [int(case["N"]) for case in cases] == [33, 38],
        "radii_exact": [list(map(int, case["radii"])) for case in cases] == [[3, 8, 12], [4, 9, 14]],
        "counts_exact": [list(map(int, case["counts"])) for case in cases] == [[25, 50, 100], [30, 60, 120]],
        "variants_exact": variants == ("baseline", "outer_semantic4", "same_inventory_joint_shuffle"),
        "threshold_rational_exact": numerator == 3417106052812071 and denominator == 10**18,
        "integer_cutoffs_exact": declared_cutoffs == calculated_cutoffs == {33: 123, 38: 188},
        "adaptive_horizons_exact": contract["execution"]["screen_horizon_multiplier"] == 4 and contract["execution"]["extended_horizon_multiplier"] == 16,
        "counts_match": (
            contract["execution"]["planned_seed_groups"] == calculated_groups
            and contract["execution"]["planned_trajectories"] == calculated_rows
            and contract["execution"]["planned_minimum_universe_ticks"] == min_ticks
            and contract["execution"]["planned_worst_case_universe_ticks"] == max_ticks
        ),
        "threads_one": contract["execution"]["threads"] == 1,
        "primary_performance_exact": (
            contract["adjudication"]["minimum_primary_coverage"] == 1.0
            and contract["adjudication"]["maximum_primary_errors"] == 0
            and contract["adjudication"]["minimum_balanced_accuracy"] == 0.95
            and contract["adjudication"]["per_size_maximum_errors"] == 0
            and contract["adjudication"]["maximum_other_outcomes"] == 0
        ),
        "diversity_exact": (
            contract["adjudication"]["minimum_independent_groups_each_class"] == 4
            and contract["adjudication"]["minimum_mixed_seed_groups"] == 2
        ),
        "full_best_null_advantage_exact": contract["adjudication"]["minimum_balanced_accuracy_advantage_over_best_null"] == 0.10,
        "pre_crossing_subset_exact": (
            contract["adjudication"]["minimum_delayed_dense_groups_pre_crossing"] == 4
            and contract["adjudication"]["minimum_sparse_groups_pre_crossing"] == 4
            and contract["adjudication"]["maximum_pre_crossing_errors"] == 0
            and contract["adjudication"]["minimum_pre_crossing_balanced_accuracy"] == 0.95
            and contract["adjudication"]["minimum_pre_crossing_balanced_accuracy_advantage_over_best_null"] == 0.10
            and "minimum_pre_crossing_cohort_coverage" not in contract["adjudication"]
        ),
        "adjudication_order_frozen": (
            "any OTHER or any total/per-size primary error is FAIL_FROZEN_LAW before diversity"
            in contract["adjudication"]["ordering"]
            and "FAIL_INCREMENTAL_VALUE" in contract["adjudication"]["ordering"]
        ),
        "nulls_exact": (
            contract["comparators"]["size_threshold_N"] == 38
            and contract["comparators"]["size_plus_arm_threshold_N"] == 38
            and contract["comparators"]["size_plus_arm_dense_override"] == "outer_semantic4"
            and contract["comparators"]["always_dense"] == "Always predict DENSE_RAW_FIXED_WINDOW."
        ),
        "minimal_period_contract_exact": (
            contract["outcome_definition"]["sparse_minimal_period"] == "exactly N"
            and contract["outcome_definition"]["period_search_max_multiplier"] == 4
            and contract["outcome_definition"]["period_confirmation_repeats"] == 3
        ),
        "no_post_open_refit": contract["execution"]["no_refit_after_opening"] is True,
    }
    output = {
        "schema": "dee.v27.msh02.lock_draft_preflight.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "prior_seed_hits": prior_hits,
        "prior_size_hits": prior_size_hits,
        "declared_public_seeds": declared,
        "calculated_integer_cutoffs": calculated_cutoffs,
        "calculated_seed_groups": calculated_groups,
        "calculated_trajectories": calculated_rows,
        "calculated_minimum_universe_ticks": min_ticks,
        "calculated_worst_case_universe_ticks": max_ticks,
        "observed_file_hashes": {field: sha256(path) for field, path in file_paths.items()},
        "draft_file_sha256": sha256(DRAFT),
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
