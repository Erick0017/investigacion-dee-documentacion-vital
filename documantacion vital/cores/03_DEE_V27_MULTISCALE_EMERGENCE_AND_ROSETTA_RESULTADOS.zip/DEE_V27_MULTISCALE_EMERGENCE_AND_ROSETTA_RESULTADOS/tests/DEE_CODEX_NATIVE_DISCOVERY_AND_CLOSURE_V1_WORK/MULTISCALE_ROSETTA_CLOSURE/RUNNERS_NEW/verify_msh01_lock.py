#!/usr/bin/env python3
"""Read-only verification of the frozen MSH01 lock and transitive code chain."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
LOCK = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json"
SIDECAR = ROOT / "HOLDOUT_LOCKS" / "HOLDOUT_MSH01_LOCK.json.sha256"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical_hash(value) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    contract = lock["contract"]
    expected_file_hash = SIDECAR.read_text(encoding="ascii").split()[0].lower()
    files = {
        "runner_sha256": ROOT / contract["runner"],
        "core_runner_sha256": ROOT / contract["core_runner"],
        "foundation_runner_sha256": ROOT / contract["foundation_runner"],
    }
    checks = {
        "lock_status_frozen": lock["status"] == "FROZEN_PRE_HOLDOUT",
        "sidecar_matches": sha256(LOCK) == expected_file_hash,
        "contract_payload_matches": canonical_hash(contract) == lock["contract_payload_sha256"],
        "transitive_runner_hashes_match": all(sha256(path) == contract[field] for field, path in files.items()),
        "holdout_output_absent_at_verification": not (ROOT / "HOLDOUTS" / "MSH01_results.json").exists(),
    }
    output = {
        "schema": "dee.v27.msh01.frozen_lock_verification.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "lock_file_sha256": sha256(LOCK),
        "contract_payload_sha256": canonical_hash(contract),
        "runner_hashes": {field: sha256(path) for field, path in files.items()},
    }
    print(json.dumps(output, indent=2, sort_keys=True))
    return 0 if output["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
