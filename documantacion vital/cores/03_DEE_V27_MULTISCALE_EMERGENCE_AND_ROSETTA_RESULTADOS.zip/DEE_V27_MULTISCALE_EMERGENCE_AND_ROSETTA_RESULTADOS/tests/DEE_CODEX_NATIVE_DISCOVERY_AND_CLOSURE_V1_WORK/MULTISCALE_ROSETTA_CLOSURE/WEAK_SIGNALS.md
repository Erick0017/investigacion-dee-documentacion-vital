# Weak signals and dormant/open branches

## Preserved weak signals

- A direction-free N37 intervention entered an exact raw-fixed window at `q=43040/50653` for 256 observed ticks. It is an intervention-induced finite window, not a natural third class.
- Ignition latency and first-passage time vary strongly across preparation/arm. No universal scaling law was preregistered.
- Direction-support and q_N are predictively equivalent on MSH02 while causally separable off manifold. A richer natural-manifold equivalence class may underlie both.
- Mature dense worlds show coarse support redundancy despite microscopic memory.
- Nonlinear or sectorial emergent isotropy remains possible despite global O_h failure.
- Relational, topological, higher-range and approximate invariants remain open outside the tested low-range/additive classes.

## Dormancy rule

None of these signals is promoted. Reopening one requires a new explicit hypothesis, frozen observable/domain/criterion and unopened data. No signal resets stagnation. The mission ended because external identification is structurally unavailable locally, not because these internal details were declared impossible.
