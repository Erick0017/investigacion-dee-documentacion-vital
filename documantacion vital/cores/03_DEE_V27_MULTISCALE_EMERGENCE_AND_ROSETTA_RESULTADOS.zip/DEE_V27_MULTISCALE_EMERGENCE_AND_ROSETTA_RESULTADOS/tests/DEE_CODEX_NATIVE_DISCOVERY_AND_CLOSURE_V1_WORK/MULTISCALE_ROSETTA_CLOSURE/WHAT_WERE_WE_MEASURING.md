# What were we measuring?

| Historical observable | What it actually measures | What it does not establish |
|---|---|---|
| occupancy / `state>0` | support of selected branches; useful Q2 order population | matter, complete causal state, conserved number |
| direction | routed proposal class and free-sector velocity | physical momentum or energy flux |
| `s_reg` | transported label, gated counter and capped collision event load | mass or conserved energy |
| semantic | control/guard/source role | particle species or observer consciousness |
| clock | modular phase and gate input | SI time or removable global gauge |
| raw | complete packed causal record when paired with clock | directly observable physical state |
| raw period | recurrence of one projection | full-state period, quantum phase or energy spectrum |
| FFT peak | windowed spectral bin of a chosen observable | native oscillator without window/holdout controls |
| q_N | compact future-class predictor on MSH02's natural manifold | unique coordinate, causal carrier or universal constant |
| response word | operational equivalence under a finite intervention repertoire | microscopic identity or universal object class |

## Main bias corrections

The campaign repeatedly found that an observable can be useful without being fundamental. Occupancy predicted MSH02 but failed causal sufficiency in MSD06. Direction-support tied q_N predictively, yet direction deletion and state deletion had sharply different causal effects. Raw recurrence revealed exact sparse structure, while clock prevented promotion to full-state recurrence. Spatial inventory hashes controlled content, while shuffles exposed organization.

The correct order is therefore: define the measured projection, state its dynamical function and domain, test interventions and nulls, and only then consider a physical correspondence.
