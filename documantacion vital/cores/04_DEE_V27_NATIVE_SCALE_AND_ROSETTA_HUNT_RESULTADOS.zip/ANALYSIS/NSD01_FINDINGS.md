# NSD01 — support balance and scale-flow findings

Status: **DISCOVERY_EVIDENCE_ONLY**. No formula or threshold selected here is confirmatory.

## Exact results

- Across 7776 executed transitions, `P(t+1)=P(t)+births-deaths` and `births=forced_destination_births+other_births` had zero residual.
- Every eligible empty routed destination became positive: 0 violations. This is an executable witness of the source-level branch theorem, not an emergent conservation law.

## Causal organization result

The exact joint `(raw, clock)` inventory was preserved in all matched arms. Organized inward geometry produced dense outcomes in 13 pairs where the global joint shuffle did not; reverse discordances: 0. The discovery-only exact sign-test value is 0.000244141. Thus inventory count alone is refuted as a sufficient explanation in this panel; spatial organization is a causal component.

## Candidate mechanism

Stationary-positive support strictly preceded the 0.5 crossing in 13/13 dense trajectories, but also appeared in 13/35 non-dense trajectories. Onset alone is therefore not sufficient. The leading discovery stump is `boundary_per_positive_N` with leave-one-size-out balanced accuracy 1.000; its threshold is post-hoc and must be frozen before use.

At the earlier fixed observation `floor(N/4)`, the native interface coordinate `kappa=B6/P=6-mean_face_degree` separated all 48 discovery trajectories using the simple rule `kappa<=5.35`; the discovery gap was 0.114694. This is `PROVISIONAL_PROGRESS`, not confirmation or demonstrated causation.

## Scale and closure

The exponent scan is explicitly post-hoc and does not establish a scale law. The one-step grouped leave-one-size-out macro model has skill 0.830 versus persistence and status `CANDIDATE`. This determines whether the next branch should freeze a low-dimensional closure candidate or intervene on the stationary-support feedback mechanism.
