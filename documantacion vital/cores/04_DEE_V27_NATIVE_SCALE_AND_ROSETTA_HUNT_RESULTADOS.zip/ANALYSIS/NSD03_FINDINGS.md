# NSD03 — exact support operator and causal response

## Exact low-overflow operator

For every audited zero-overflow transition, the next positive mask equalled `S ∪ C ∪ X ∪ R`: local survivors, crystallization births, XNOR births, and routed births in branch-priority order. There were 0 mask mismatches in 222 transitions.

## Causal result

The N/2 joint `(raw,clock)` snapshot shuffle changed 7/18 basin outcomes, all DENSE→NONDENSE. Clock-only shuffling changed 0/18. Therefore spatial relations are causal for the fragile precursor sector; clock arrangement is not required for this tested endpoint.

## New response candidate

Among 10 natural dense worlds, `bar_kappa<=3.60` separated all 3 shuffle-resistant from 7 fragile worlds. This suggests a three-regime stability coordinate, but it is post-hoc discovery and needs a new locked holdout.
