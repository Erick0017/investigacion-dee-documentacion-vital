# NSH01 post-hoc temporal analysis

The original locked verdict remains **FAIL**. This analysis screens 19 temporal summaries and is discovery-only.

Best grouped leave-one-size-out feature: `mean_kappa_N4_N2`; balanced accuracy 0.976190, errors 1/72. Decision: **PROVISIONAL_PROGRESS_TEMPORAL_CANDIDATE**.

No threshold from this file is confirmatory. A new holdout is permitted only for one genuinely temporal formula, never for a moved `kappa(floor(N/4))` threshold.
