# Arquitectura causal de DEE v27

## Núcleo transversal

El conjunto pequeño que conecta más fenómenos es

`(P, S, R, C, X, D, kappa, a, A, Gamma)`.

`P` es soporte positivo; `S/R/C/X/D` son roles de transición exactos; `kappa=B6/P` mide interfaz específica; `a=routed_positive/P` mide capacidad dirigida presente; `A=P_next/P` es reproducción por tick y `Gamma` su integral logarítmica multitik. Estos objetos conectan nacimiento, persistencia, routing, geometría, basins, respuesta a intervención y cambio de escala.

## Grafo funcional

`raw + clock`

`-> guards de fase/semantic + supervivencia local + propuestas direction/s_reg`

`-> destinos y multiplicidad de colisión`

`-> S/R/C/X/D`

`-> A_t y P_(t+1)`

`-> historia Gamma + interfaz activa (kappa,a)`

`-> sector Q2 denso/no denso dentro de dominios certificados`.

La flecha es causal de izquierda a derecha. Las proyecciones a la derecha no reconstruyen en general el microestado de la izquierda.

## Necesidad, suficiencia y contexto

- Inventario completo `raw+clock`: no suficiente. NSD01 produjo 13 pares con inventario conjunto idéntico y endpoints opuestos al reorganizar espacialmente.
- Geometría `kappa`: predictiva y suficiente dentro de NSH02, pero no suficiente para bloques compactos; NSH06 obtuvo especificidad cero.
- Actividad dirigida: causal en los bloques matched; stationary versus inward/outward cambia el basin manteniendo los campos no direccionales.
- Actividad sola: no suficiente entre familias; en NSH07 su null tuvo BA 0.57895.
- Geometría más actividad: suficiente predictivamente en el dominio NSH07; fuera de él el umbral numérico no es universal.
- Historia de soporte: `Gamma` es suficiente en NSH07, pero no con dosis extremadamente escasa.
- Clock espacial: contextual. En NSD03, mezclar sólo clock conservando raw cambió 0/18 endpoints y terminó raw-idéntico; esto no prueba irrelevancia global del clock.

## Función de los registros

- `raw`: paquete causal observable por el kernel; contiene estado, carga de registro, dirección y semantic. Es parte de Q0, no una magnitud física única.
- `state/support`: condición de existencia/supervivencia y una proyección colectiva útil. Pierde causas de routers con state cero.
- `direction`: puntero de propuesta y, en el sector singleton, velocidad discreta exacta. No es momentum: colisiones reducen por signo no ponderado por `s_reg`.
- `s_reg`: carga/procedencia que se transporta en vuelo libre, se suma con saturación en colisiones, cambia bajo supervivencia y activa overflow. Sus varias funciones impiden llamarla energía sin un puente externo.
- `semantic`: control de rama. `4` es boundary/source fijo, `5` orphan no vivo, `7` marca XNOR; los nombres no son ontología.
- `clock`: fase modular `+1 mod 2^64`; sus diferencias son invariantes. Activa guards raw, pero no es tiempo SI ni gauge global.

## Materia DEE

No existe “la materia” como un bit universal. La entidad material mínima demostrada es sectorial: portadores/linajes direccionados con identidad, posición, velocidad y reglas de interacción. En el régimen colectivo, el objeto natural es un proceso organizado de soporte activo, no occupancy aislada. Observers fijos, routers latentes y fases densas son clases funcionales distintas.

## Geometría y causalidad

La geometría fundamental disponible es un toro cúbico combinatorio con vecindad Moore, edge boundary exacto y grafo temporal de propuestas dependiente del estado. El cono raw global es `r_infinity<=3t`; el transporte singleton común avanza una celda/tick. No se deriva métrica dinámica, curvatura, Lorentz ni gravedad.

