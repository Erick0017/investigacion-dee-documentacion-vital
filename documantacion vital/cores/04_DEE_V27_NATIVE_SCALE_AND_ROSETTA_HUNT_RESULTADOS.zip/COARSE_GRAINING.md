# Coarse-graining y cierre efectivo

## Mapas probados

1. `C_support(X)=(q,kappa/6)`: comprime `N^3` raws a dos coordenadas.
2. `C_gate(history)=bar_kappa`: puerta temporal nested-shell.
3. `C_active(history)=(bar_kappa,bar_a)`: interfaz y capacidad dirigida.
4. `C_history(history)=Gamma`: producto logarítmico de reproducción.

## Retención predictiva

`C_support` retuvo capacidad de predicción teacher-forced en NSH05, pero no al componerse autónomamente. `C_active` y `C_history` obtuvieron BA=1 en NSH07 y atravesaron dos familias; ambos tienen contraejemplos fuera del dominio al reducir actividad. La compresión es real, pero condicionada a manifold/preparación.

## Error de cierre

Para `C_history`, el error de composición del conteo acumulado es exactamente cero, pero el error de evolución futura no está definido sin los factores futuros. Para `C_support`, el error recursivo fue grande y dejó el dominio. Por ello se distingue:

- `COMPOSITION_CLOSURE`: sí para el cociente de conteos realizado;
- `PREDICTIVE_LOCAL_CLOSURE`: sí en NSH05/NSH07 dentro de dominio;
- `AUTONOMOUS_DYNAMIC_CLOSURE`: no;
- `PHYSICAL_SCALE_CLOSURE`: no identificable.

## Multi-fidelity

No se usó un emulador para sustituir el kernel. Las regresiones sólo seleccionaron fórmulas; todas las afirmaciones promovidas se evaluaron contra ejecuciones directas de `F_DEE`. Al fallar la recursión, no se extrapoló a N grandes mediante el modelo reducido.

## Qué variable falta

Los contraejemplos apuntan a una coordenada no capturada por `(q,kappa,a,Gamma)`: organización espacial de las propuestas y su multiplicidad/destinos a lo largo de la historia. Un cierre futuro necesitaría una representación de grafo/flujo causal, no otro ajuste escalar de occupancy.

