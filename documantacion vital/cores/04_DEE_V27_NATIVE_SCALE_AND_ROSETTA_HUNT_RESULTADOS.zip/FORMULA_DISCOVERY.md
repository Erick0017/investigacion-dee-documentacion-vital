# Descubrimiento de fórmulas

## Secuencia discovery → freeze → holdout

NSD05 encontró que una regresión global ocultaba dos sectores. NSD06 separó flujo denso e identidad dispersa. NSD07 comparó familias simples y NSD08 aplicó regresión dispersa, dejando seis coeficientes. La fórmula se congeló en NSH05 antes de abrir N nuevos y pasó su prueba local.

La composición posterior se trató como afirmación nueva. NSD10 la refutó sin alterar el PASS teacher-forced. NSD11-12 probaron generadores competidores; ninguno cruzó el umbral de freeze.

Tras el FAIL de geometría sola en NSH06, NSD13 descubrió dos candidatos simples: `Gamma>0` y `(bar_kappa<=5.60 AND bar_a>=0.50)`. Ambos se congelaron conjuntamente pero se adjudicaron por separado en NSH07 y ambos pasaron.

NSD14-16 buscaron generalización de dosis. Preservaron los PASS anteriores y produjeron negativos de dominio. No se ajustó el corte de `bar_a` ni se sustituyó el signo de `Gamma` después de ver los fallos.

## Complejidad y parámetros

- Cociclo exacto: cero parámetros.
- Clasificador `Gamma>0`: cero parámetros ajustados.
- Puerta activa: dos umbrales heredados/conceptuales; `5.60` venía de discovery y `0.50` era midpoint de mayoría, no optimización sobre holdout.
- Flujo NSH05: seis coeficientes; pasó frente a persistencia, pero su complejidad y falta de semigrupo impiden tratarlo como ley fundamental.

## Fórmulas rechazadas o no promovidas

- `kappa(t=N/4)<=5.35`: FAIL NSH01.
- `bar_kappa<=3.60` como profundidad de basin: FAIL NSH03.
- `bar_q>=0.0290` como profundidad de basin: FAIL NSH04 pese a BA 0.9167, porque sensibilidad 0.8333 quedó bajo 0.85.
- generadores cuadráticos y mecanicistas: inestables/fuera de dominio.
- affine-logit: acotado pero no predictivo cross-N.
- regla universal de conteo de routers: thresholds 4–16 según contexto.
- `Gamma>0` sostenido universal: FAIL de generalización en NSD15-16.
- `Gamma≈0.17`: no congelado; hueco post-hoc demasiado estrecho y sin origen natural.

## Resultado metodológico

La fórmula más fundamental no es la regresión de seis parámetros. Es la identidad exacta que integra los roles causales Q1 en factores `A_t`, complementada por leyes predictivas acotadas. La regresión describe un chart local; el cociclo explica la relación entre niveles.

