# Jerarquía nativa adjudicada

## Q0 — microestado exacto

`X=(raw,clock)` es Markoviano y completo para `F_DEE`. Ninguna proyección usada aquí reemplaza Q0 globalmente.

## Q1 — causalidad sectorial y eventos

Se heredan `M_*`, `G_dagger`, `J_dagger`, `K_dagger`, roles `L/C/O`, transporte, colisiones, fuentes, first-passage y separación estado/evento. Campaña 04 añade la descomposición exacta de soporte `S/R/C/X` y su balance. Q1 responde a “qué transición ocurrió y por qué rama”, no a “qué fase macroscópica resultará”.

## Q2 — organización de basin

Q2 es la organización colectiva que discrimina los regímenes densos y no densos. Tiene varias cartas válidas, no una ontología única:

- `q_N`, confirmado por el padre en su dominio natural;
- `bar_kappa`, confirmado para nested shells;
- la puerta conjunta `(bar_kappa,bar_a)`, confirmada por NSH07 a través de nested shells y bloques compactos.

NSH06 es decisivo: bloques estacionarios y activos tenían la misma geometría de soporte y todos satisfacían la puerta `kappa`, pero sólo los activos se densificaron. Así, Q2 no es occupancy ni geometría sola. Es organización de interfaz con capacidad causal dirigida.

## Q3 — clase de historia productiva

Q3 existe en sentido predictivo, compresivo y transversal, pero no como nuevo microestado autónomo. El mapa

`history_[N/4,N/2] -> Gamma=log[P(N/2)/P(N/4)] -> sign(Gamma)`

comprime un producto de factores Q1 y predice Q2 en el holdout NSH07, atravesando N y familia de preparación. Dos microhistorias diferentes pertenecen a la misma clase Q3 si comparten el signo productivo relevante en ese dominio.

La promoción se apoya en:

- forma congelada antes del holdout;
- cero parámetros ajustados;
- 30/30 mundos no vistos;
- ambas familias y tres N;
- mejora sobre nulls de una sola coordenada;
- composición exacta de los factores subyacentes.

El dominio está acotado. NSD15-16 aportan contraejemplos: con 1–8 routers, `Gamma` fue positivo y permaneció positivo en ventanas sucesivas, pero 12 mundos no alcanzaron el basin denso. Q3 es por tanto una clase de historia efectiva en el dominio NSH07, no un clasificador universal.

## Q4 y niveles superiores

No se establece Q4. Los candidatos razonables exigían alguna combinación de:

- dinámica autónoma de Q3;
- ley estable que transformara Q2/Q3 a otra escala;
- compresión adicional con predicción nueva;
- universalidad o fixed point de coarse-graining.

La composición recursiva del mapa `(q,kappa)` falló, los generadores continuo/logit no generalizaron y ninguna regla de persistencia de signo resolvió la dosis escasa. Crear Q4 por clustering sería nominal, no dinámico.

## Veredicto jerárquico

`HIGHER_HIERARCHY_AND_SCALE_LAW_FOUND` y `MULTIPLE_SECTOR_STRUCTURE`.

No se declara `SCALE_CLOSURE_FOUND`: existe composición exacta de historia y una ley local predictiva, pero no una evolución autónoma cerrada ni independencia del microdetalle.

