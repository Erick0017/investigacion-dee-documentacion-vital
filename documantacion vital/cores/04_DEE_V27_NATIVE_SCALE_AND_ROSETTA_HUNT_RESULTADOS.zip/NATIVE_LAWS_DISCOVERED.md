# Leyes nativas descubiertas en la Campaña 04

## Identidad del objeto

Todas las afirmaciones nuevas se refieren al wheel `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl`, SHA-256 `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`, y al binario importado `dee_kernel_v27.cp313-win_amd64.pyd`, SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`. Los tres padres sellados se heredaron literalmente y no se reejecutaron como campañas.

## Teoremas y balances exactos

Sea `P_t` el conjunto de sitios con `state>0`. En transiciones sin depósito por overflow, la máscara siguiente es

`P_(t+1) = S_t ⊔ C_t ⊔ X_t ⊔ R_t`,

donde `S` son supervivientes locales, `C` nacimientos por cristalización, `X` nacimientos XNOR y `R` nacimientos en destinos enrutados. La unión es disjunta por prioridad de ramas. NSD03 verificó 222/222 máscaras sin discrepancia. La ruta `C` permanece formalmente en la descomposición aunque el padre demostró que su condición de gradiente es inalcanzable en v27.

En conteos, con `D_t=P_t-S_t`:

`P_(t+1)-P_t = R_t+C_t+X_t-D_t`.

Dividiendo por `N^3`,

`Δq_t = (R_t+C_t+X_t-D_t)/N^3`.

Si `P_t>0`, el factor de reproducción exacto es

`A_t=P_(t+1)/P_t = σ_t+ρ_R,t+ρ_other,t`,

con `σ=S/P`, `ρ_R=R/P` y `ρ_other=(C+X)/P`. NSD09 verificó las 222 identidades; en ese panel `R` explicó 0.9990458 de los nacimientos, cifra empírica y no teorema global.

Estos factores componen exactamente a cualquier horizonte positivo:

`A_t^(h)=P_(t+h)/P_t=∏_(j=0)^(h-1) A_(t+j)`

y

`Γ_t^(h)=log A_t^(h)=Σ_j log A_(t+j)`.

NSD13 auditó 63,747/63,747 igualdades; NSH07 volvió a verificarlas en aritmética racional y logarítmica en 30/30 casos. La telescopía es una propiedad genérica de cocientes positivos. Lo específico de DEE es que cada factor se descompone mediante los objetos causales `S/R/C/X` del kernel.

Otro teorema nuevo es el nacimiento enrutado: todo destino vacío, no observer, aceptado por `buscar_fuente_demux` se vuelve positivo al tick siguiente. NSD01 observó cero violaciones en 7,776 transiciones científicas. No implica transporte conservativo: un router puede crear soporte neto.

## Leyes empíricas confirmadas

### Puerta de interfaz temporal

En el dominio nested-shell de NSH02,

`bar_kappa = mean_(t=floor(N/4)..floor(N/2)) B6_t/P_t`

y la regla `bar_kappa<=5.60` predijeron el basin denso fijo a `6N` en 72/72 mundos, con sensibilidad, especificidad y balanced accuracy iguales a 1. Superó los nulls congelados `bar_q` y brazo de preparación. NSH06 demostró después que esta puerta geométrica sola no se generaliza a bloques compactos estacionarios/activos: ese resultado es un límite de dominio, no una retractación de NSH02.

### Flujo local de escala

En el dominio nested-shell de NSH05, con `z=(q,k)` y `k=kappa/6`, una puerta Q2 selecciona dos operadores a lag `N/8`:

- sector disperso: identidad aproximada;
- sector denso: el mapa triangular congelado

`Δq = 0.02328702025934721 + 2.574303732734078 q - 2.6162955004776953 q^2 - 1.8822948214354622 q k`,

`Δk = -0.6794269820170623 k + 0.6915825897523803 k^2`.

NSH05 pasó todas las condiciones en 36 mundos no vistos: skill medio denso 0.72765, mediana 0.96438, 9/10 mundos densos mejores que persistencia y puerta con BA 0.95455. Es una ley predictiva local teacher-forced, no una ecuación autónoma: la composición recursiva falló en NSD10.

### Clase de historia productiva

NSH07 congeló antes de abrir el panel

`Gamma=log[P(N/2)/P(N/4)]`

y clasificó como denso si `Gamma>0`. En 30 mundos no vistos, `N={28,36,44}`, dos familias y ambos endpoints, obtuvo 30/30, sensibilidad=especificidad=BA=1 y cero parámetros ajustados. Cada familia y cada N fueron perfectos. Esta es una ley prospectiva de dominio: NSD15 mostró que `Gamma>0` no basta con actividad extremadamente escasa.

### Puerta de interfaz activa

NSH07 confirmó por separado

`bar_kappa<=5.60 AND bar_a>=0.50`,

donde `bar_a=mean(routed_positive/P)` en la misma ventana. También obtuvo 30/30 y BA=1; superó por más de 0.05 a `kappa` sola (BA 0.92105) y actividad sola (BA 0.57895). NSD14 encontró una trayectoria densa fuera del dominio con `bar_a=0.47863`, por lo que `0.50` no es constante universal.

## Resultado causal de dosis

En bloques compactos con soporte, `s_reg`, `semantic` y `clock` idénticos, cambiar sólo direcciones produjo una respuesta monotónica al número de routers. Cero routers dio mundos no densos; los primeros conteos densos fueron 8, 4, 16 y 8 según N/orientación. Por tanto actividad es causal en este aparato, pero su umbral es contextual y no constituye una constante de DEE. Tres ciclos informativos cerraron la rama sin ajustar el estrecho hueco post-hoc de `Gamma`.

## Qué no es una ley

- Los coeficientes del mapa NSH05 son parámetros empíricos congelados, no constantes naturales.
- `5.60`, `0.50` y cualquier corte cercano a `Gamma=0.17` no son universales.
- Correlaciones de `kappa` con retención o amplificación no son teoremas causales.
- Una igualdad algebraica con una familia física no identifica materia, unidades ni observables externos.

