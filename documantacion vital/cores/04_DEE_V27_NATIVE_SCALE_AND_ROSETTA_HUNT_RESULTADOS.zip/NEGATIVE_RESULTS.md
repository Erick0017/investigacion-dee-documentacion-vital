# Resultados negativos preservados

## Holds confirmatorios

- NSH01: `kappa(t=N/4)<=5.35` — FAIL; sensibilidad 0.7619, especificidad 0.9804, BA 0.8711. No se movió el threshold.
- NSH03: `bar_kappa<=3.60` como resistencia a shuffle — FAIL; sensibilidad 0.8333, BA 0.8939.
- NSH04: `bar_q>=0.0290` como resistencia — FAIL literal pese a BA 0.9167; sensibilidad 0.8333 quedó bajo el 0.85 preregistrado.
- NSH06: transferencia de puerta `kappa` y flujo a bloques compactos — FAIL; sensibilidad 1, especificidad 0, BA 0.5. Los 27 casos pasaron auditoría y diversidad.

## Cierre y ecuaciones

- El mapa NSH05 no es semigrupo autónomo: skill recursivo medio -2.1013 y tres mundos fuera de dominio.
- Ningún generador cuadrático continuo, mecanicista o affine-logit probado cerró `(q,kappa)` a través de N.
- No se encontró Q4 ni fixed point de escala predictivo.
- No existe threshold común de conteo de routers en NSD15: 4, 8 o 16 según N/orientación.
- Positividad de `Gamma` temprana o en tres ventanas sucesivas no es suficiente con actividad escasa; 12 contraejemplos nondense en NSD16.

## Causalidad y representaciones

- Inventario conjunto `raw+clock` no determina el basin: 13 pares matched con endpoints opuestos.
- Occupancy/support no es estado causal suficiente; direction a soporte fijo cambia `P_next`.
- Geometría `kappa` sola no es universal; bloques estacionarios compactos son contraejemplos.
- Routing de support no es transporte conservativo.
- Clock placement fue causalmente nulo sólo en el panel NSD03; no se generaliza a irrelevancia global.

## Rosetta

- Contact process binario autónomo: FAIL.
- Transporte/continuidad conservativos para positive support: FAIL.
- GLV/logístico fuerte: FAIL; queda sólo clase monomial local.
- Rosetta física validada: no obtenida.
- Predicción física externa: no obtenida.

Estos negativos descartan fórmulas, proyecciones y dominios concretos. No son teoremas de imposibilidad contra conservaciones relacionales, modos colectivos distintos, termodinámica efectiva, espectros sobre otros objetos o toda emergencia física.

