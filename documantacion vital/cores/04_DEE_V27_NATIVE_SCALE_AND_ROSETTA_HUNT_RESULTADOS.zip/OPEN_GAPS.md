# Fronteras y piezas faltantes

## Cierre interno

La pieza interna más concreta que falta es una coordenada relacional de propuestas/destinos que haga autónoma la evolución coarse. Debe retener organización espacial, multiplicidad de colisión y persistencia histórica suficiente para predecir `A_(t+1)` sin volver a Q0. `(q,kappa,a,Gamma)` no basta globalmente.

Quedan abiertos, sin afirmarse:

- invariantes relacionales, topológicos o aproximados fuera de los sectores probados;
- un operador causal de grafo que cierre a escala;
- modos colectivos interactuantes sobre objetos distintos de occupancy;
- respuesta/susceptibilidad con parámetros estables;
- ensemble estacionario, variables lentas y límite termodinámico;
- Q4 si una representación nueva aporta predicción o cierre real.

## Frontera física externa

Bajo `H_DEE`, la pieza exacta ausente es

`preparación física -> distribución/ensemble sobre Q0 -> coarse-graining causalmente suficiente -> historia efectiva -> operador de medición/forward -> distribución de registros físicos`,

con calibración dimensional separada y validación en más observables externos que parámetros. Debe fijarse antes de ver targets y predecir holdouts independientes.

El kernel no puede decidir por sí solo:

- qué preparación de laboratorio realiza un estado DEE;
- qué voxel/tick corresponde a unidades SI;
- qué objeto DEE es materia, energía, masa o métrica física;
- qué ensemble es físicamente accesible;
- qué raw history produce una lectura detectora;
- qué outcomes/settings implementan Born o Bell.

## Consecuencias por área

- Masa/inercia: falta una intervención force-like, una respuesta acelerativa y una misma carga que prediga también colisiones.
- Materia–geometría: falta medir una clase material y una respuesta geométrica con definiciones independientes; actualmente la geometría es sustrato/relación, no dinámica.
- Termodinámica/hidrodinámica: faltan densidades cerradas, corrientes, constitutivas, ensemble y producción entrópica operacional.
- Quantum/Bell: faltan espacio de observables, probabilidades/Born, composición y aparato CHSH con settings/outcomes auditados.
- Simetría/gauge: hay traslaciones exactas y sectores simétricos, pero no transformación gauge local con conexiones/cargas; `O_h` global está roto por desempate overflow.
- Constantes: 19665/19664, 782, 391 y coeficientes/threshholds son literales o parámetros internos; ninguna constante natural externa ha sido predicha.

La Campaña 04 se detiene por `HIGHER_HIERARCHY_AND_SCALE_LAW_FOUND` más `EXTERNAL_EMPIRICAL_FRONTIER`, no porque DEE esté “terminada”.

