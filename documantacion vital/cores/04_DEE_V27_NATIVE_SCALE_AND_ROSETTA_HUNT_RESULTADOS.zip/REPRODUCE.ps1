param(
    [switch]$AuditKernel,
    [string]$PythonPath = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $Root

if (-not (Test-Path -LiteralPath '.\HASHES.sha256')) {
    throw 'HASHES.sha256 is missing.'
}

$failures = @()
foreach ($line in Get-Content -LiteralPath '.\HASHES.sha256') {
    if ([string]::IsNullOrWhiteSpace($line)) { continue }
    $parts = $line -split '  ', 2
    if ($parts.Count -ne 2) { $failures += "Malformed hash line: $line"; continue }
    $expected = $parts[0].Trim().ToLowerInvariant()
    $relative = $parts[1].Trim().Replace('/', [IO.Path]::DirectorySeparatorChar)
    $path = Join-Path $Root $relative
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { $failures += "Missing: $relative"; continue }
    $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $expected) { $failures += "Hash mismatch: $relative" }
}

foreach ($json in Get-ChildItem -LiteralPath $Root -Recurse -File -Filter '*.json') {
    try { $null = Get-Content -LiteralPath $json.FullName -Raw | ConvertFrom-Json }
    catch { $failures += "Invalid JSON: $($json.FullName.Substring($Root.Length + 1))" }
}

$lineNumber = 0
foreach ($line in Get-Content -LiteralPath '.\SCIENCE_LOG.ndjson') {
    $lineNumber++
    try { $null = $line | ConvertFrom-Json }
    catch { $failures += "Invalid SCIENCE_LOG.ndjson line $lineNumber" }
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { Write-Error $_ }
    exit 2
}

Write-Host 'Campaign 04 payload integrity: PASS'

if ($AuditKernel) {
    if (-not (Test-Path -LiteralPath $PythonPath -PathType Leaf)) { throw "CPython 3.13 not found: $PythonPath" }
    & $PythonPath -I -B '.\RUNNERS\run_nsh05_sector_flow_holdout.py' --audit-only
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    & $PythonPath -I -B '.\RUNNERS\run_nsh06_compact_block_holdout.py' --audit-only
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    & $PythonPath -I -B '.\RUNNERS\run_nsh07_integrated_reproduction_holdout.py' --audit-only
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    Write-Host 'Kernel identity and frozen runner audits: PASS'
}

exit 0
