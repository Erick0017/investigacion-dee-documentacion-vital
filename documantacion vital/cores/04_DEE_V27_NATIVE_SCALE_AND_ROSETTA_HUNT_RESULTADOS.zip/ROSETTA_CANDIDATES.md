# Candidatos Rosetta adjudicados

| Objeto DEE | Clase externa | Estado | Razón del límite |
|---|---|---|---|
| `B6`, `kappa` | edge perimeter / specific surface de red cúbica | `FORMAL_EQUIVALENCE_CANDIDATE` | igualdad exacta, pero sin diccionario físico ni `ell` |
| `S/R/C/X/D` | reacción–colonización con fuentes/sumideros | `STRUCTURAL_ANALOGY` | support no autónomo; routing no conservativo |
| mapa local `(q,k)` | GLV/logístico triangular | `FORMAL_EQUIVALENCE_CANDIDATE`; target fuerte FAIL | monomios iguales, recursión y dominio fallan |
| `A_t`, `Gamma` | crecimiento multiplicativo/log-aditivo finito | `FORMAL_EQUIVALENCE_CANDIDATE` | composición exacta y predicción DEE acotada; telescopía genérica y sin observable externo |

Ningún candidato usa `voxel=metro`, `tick=segundo`, `s_reg=energía` o `direction=momentum`. Ninguno predice un segundo observable físico independiente. Por ello no existe una Rosetta fuerte de pocos parámetros que calibre A y prediga B/C/D.

El candidato interno más informativo es la cadena causal `S/R/C/X -> A -> Gamma`, porque une mecanismo, escala e historia. Su traducción física requiere un forward operator externo, no otro ajuste al kernel.

