# Búsqueda Rosetta

## Procedimiento

La búsqueda empezó después de definir leyes nativas. Cada target registró primero su estructura matemática, parámetros permitidos, PASS, FAIL y límite fuerte. Los tests no renombraron registros DEE como magnitudes físicas.

## Targets ejecutados

### R04-T01 — perímetro cúbico

`B6` coincidió exactamente con el edge boundary cúbico en 28/28 máscaras analíticas y aleatorias. `kappa=B6/P` es specific perimeter adimensional. Resultado: `FORMAL_EQUIVALENCE_CANDIDATE`; falta un mapa independiente de soporte a volumen físico y de spacing a longitud.

### R04-T02 — balance reacción/colonización

El balance nacimiento/muerte es exacto. La hipótesis de transporte conservativo falló porque routing crea soporte neto. La equivalencia con un contact process binario autónomo falló porque support no es Markov-suficiente; cambiar direction a soporte y clock fijos produjo `P_next=27` frente a `53`. Resultado: analogía estructural con balance exacto, no Rosetta fuerte.

### R04-T03 — flujo cuadrático GLV/logístico

El mapa local tiene la misma base monomial que un sistema triangular GLV/logístico con inmigración. El target fuerte exigía composición e invariancia de dominio; ambas fallaron. Resultado: coincidencia formal local, no external compatibility.

### R04-T04 — cociclo de crecimiento finito

El target se fijó después de sellar la ley nativa NSH07 y antes de aplicar la clase externa. Los 30 casos verificaron sin parámetros nuevos

`P(t+h)=P(t) product A_j`, `Gamma=sum log A_j`.

Resultado: `FORMAL_EQUIVALENCE_CANDIDATE`. La parte predictiva es específica de DEE y acotada; la telescopía es genérica. No existe población física, preparación, readout ni unidad identificada.

## Familias consideradas y no abiertas

La matriz `ANALYSIS/R04_structural_family_eligibility.json` documenta la decisión:

- dispersión/ondas: no hay campo autónomo con fase, familia de modos y readout `omega(k)` certificados; el negativo histórico 9/9 está acotado al aparato y no es un no-go global;
- response/susceptibility: existen objetos Q1 de respuesta, pero NSH03/04 fallaron y no quedó kernel de respuesta estable;
- espectral/Koopman: sin operador coarse causalmente suficiente, sus eigenmodos no serían predictivos; un FFT de occupancy impondría el observable;
- estadística/termodinámica: faltan ensemble estacionario, límite termodinámico, exponentes estables y densidad conservada.

No abrir un target estructuralmente incompleto evita fabricar una diana. Ninguna exclusión se eleva a imposibilidad ontológica.

## Resultado

Mayor estado alcanzado: `FORMAL_EQUIVALENCE_CANDIDATE`.

No se alcanza `EXTERNAL_COMPATIBILITY`, `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED`. Sí existe una Rosetta interna cuantitativa:

`Q0 raw+clock -> Q1 S/R/C/X/D -> A_t -> Q3 Gamma / interfaz activa -> Q2 basin`.

La Rosetta física sigue en frontera empírica externa.

