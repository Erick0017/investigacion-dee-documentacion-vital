#!/usr/bin/env python3
"""Analyze NSD01 without promoting discovery-selected relations."""
from __future__ import annotations

import json
import math
import sys
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import atomic_json, canonical_hash, sha256_file


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
SOURCE = WORK / "RESULTS" / "NSD01_results.json"
CASE_DIR = WORK / "RESULTS" / "NSD01_CASES"
OUT = WORK / "ANALYSIS" / "NSD01_analysis.json"
OUT_MD = WORK / "ANALYSIS" / "NSD01_FINDINGS.md"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def load_cases() -> tuple[dict, list[dict]]:
    source = load_json(SOURCE)
    cases = []
    for item in source["case_manifest"]:
        path = WORK / item["path"]
        if sha256_file(path) != item["file_sha256"]:
            raise RuntimeError(f"file hash mismatch: {path}")
        case = load_json(path)
        claimed = case.pop("content_sha256")
        if canonical_hash(case) != claimed:
            raise RuntimeError(f"content hash mismatch: {path}")
        case["content_sha256"] = claimed
        cases.append(case)
    return source, cases


def row_at(case: dict, tick: int) -> dict:
    return case["trace"][tick]


def feature_rows(cases: list[dict]) -> list[dict]:
    rows = []
    for case in cases:
        n = int(case["spec"]["N"])
        volume = n ** 3
        at_n = row_at(case, n)
        state = at_n["state"]
        transition = at_n["transition_to_next"]
        history = case["trace"][: n + 1]
        history_outgoing = history[:-1]
        features = {
            "q_N": state["positive_fraction"],
            "routed_positive_fraction_N": state["routed_positive"] / volume,
            "stationary_positive_fraction_N": state["stationary_positive"] / volume,
            "stationary_positive_count_N": float(state["stationary_positive"]),
            "bare_router_fraction_N": state["bare_routers"] / volume,
            "boundary_density_N": state["boundary_faces"] / volume,
            "boundary_per_positive_N": state["boundary_faces"] / max(1, state["positive"]),
            "unique_destination_fraction_N": state["destination"]["unique_destinations"] / volume,
            "collision_excess_per_source_N": state["destination"]["collision_excess"] / max(1, state["destination"]["source_count"]),
            "forced_target_fraction_N": transition["forced_destination_targets"] / volume,
            "semantic7_fraction_N": state["semantic7"] / volume,
            "sreg_density_N": state["sreg_sum"] / volume,
            "max_stationary_fraction_0_N": max(item["state"]["stationary_positive"] for item in history) / volume,
            "stationary_tick_fraction_0_N": sum(item["state"]["stationary_positive"] > 0 for item in history) / len(history),
            "cumulative_other_births_per_volume_0_N": sum(item["transition_to_next"]["other_births"] for item in history_outgoing) / volume,
            "cumulative_genesis_per_volume_0_N": sum(item["kernel"]["genesis"] for item in history_outgoing) / volume,
            "max_other_birth_fraction_0_N": max(item["transition_to_next"]["other_births"] for item in history_outgoing) / volume,
            "max_collision_excess_per_source_0_N": max(
                item["state"]["destination"]["collision_excess"] / max(1, item["state"]["destination"]["source_count"])
                for item in history
            ),
        }
        rows.append({
            "case_id": case["case_id"],
            "N": n,
            "scaling": case["spec"]["scaling"],
            "arm": case["spec"]["arm"],
            "replicate": case["spec"]["replicate"],
            "total_records": case["construction"]["total_records"],
            "dense": int(case["outcome"]["label"].startswith("DENSE")),
            "outcome": case["outcome"]["label"],
            "features": features,
        })
    return rows


def balanced_accuracy(y: np.ndarray, prediction: np.ndarray) -> float:
    scores = []
    for cls in (0, 1):
        mask = y == cls
        scores.append(float(np.mean(prediction[mask] == cls)) if np.any(mask) else 0.0)
    return float(np.mean(scores))


def fit_stump(x: np.ndarray, y: np.ndarray) -> dict:
    unique = np.unique(x)
    thresholds = np.concatenate((
        [np.nextafter(unique[0], -np.inf)],
        (unique[:-1] + unique[1:]) / 2 if len(unique) > 1 else [],
        [np.nextafter(unique[-1], np.inf)],
    ))
    best = None
    for direction in (1, -1):
        for threshold in thresholds:
            prediction = (direction * (x - threshold) >= 0).astype(int)
            score = balanced_accuracy(y, prediction)
            error = int(np.count_nonzero(prediction != y))
            candidate = (score, -error, -abs(float(threshold)), direction, float(threshold), prediction)
            if best is None or candidate[:5] > best[:5]:
                best = candidate
    assert best is not None
    return {
        "threshold": best[4],
        "direction": ">=" if best[3] == 1 else "<=",
        "sign": best[3],
        "balanced_accuracy": best[0],
        "errors": -best[1],
    }


def apply_stump(model: dict, x: np.ndarray) -> np.ndarray:
    return (model["sign"] * (x - model["threshold"]) >= 0).astype(int)


def stump_screen(rows: list[dict]) -> list[dict]:
    names = sorted(rows[0]["features"])
    y = np.array([row["dense"] for row in rows], dtype=int)
    results = []
    for name in names:
        x = np.array([row["features"][name] for row in rows], dtype=float)
        full = fit_stump(x, y)
        heldout_predictions = np.zeros_like(y)
        folds = []
        for n in sorted({row["N"] for row in rows}):
            train = np.array([row["N"] != n for row in rows])
            test = ~train
            model = fit_stump(x[train], y[train])
            heldout_predictions[test] = apply_stump(model, x[test])
            folds.append({
                "heldout_N": n,
                "threshold": model["threshold"],
                "direction": model["direction"],
                "test_errors": int(np.count_nonzero(heldout_predictions[test] != y[test])),
                "test_count": int(np.count_nonzero(test)),
            })
        results.append({
            "feature": name,
            "full_panel": {key: value for key, value in full.items() if key != "sign"},
            "leave_one_N_out": {
                "balanced_accuracy": balanced_accuracy(y, heldout_predictions),
                "errors": int(np.count_nonzero(heldout_predictions != y)),
                "folds": folds,
            },
        })
    return sorted(results, key=lambda item: (-item["leave_one_N_out"]["balanced_accuracy"], item["leave_one_N_out"]["errors"], item["feature"]))


def paired_organization(rows: list[dict]) -> dict:
    pairs = {}
    for row in rows:
        key = (row["N"], row["scaling"], row["replicate"])
        pairs.setdefault(key, {})[row["arm"]] = row
    contrasts = Counter()
    details = []
    for key, arms in sorted(pairs.items()):
        organized = arms["organized_inward"]["dense"]
        shuffled = arms["global_joint_inventory_shuffle"]["dense"]
        label = f"organized_{organized}_shuffle_{shuffled}"
        contrasts[label] += 1
        details.append({"N": key[0], "scaling": key[1], "replicate": key[2], "organized_dense": organized, "shuffle_dense": shuffled})
    favorable = contrasts["organized_1_shuffle_0"]
    unfavorable = contrasts["organized_0_shuffle_1"]
    discordant = favorable + unfavorable
    if discordant:
        extreme = min(favorable, unfavorable)
        p_two_sided = min(1.0, 2 * sum(math.comb(discordant, k) for k in range(extreme + 1)) / (2 ** discordant))
    else:
        p_two_sided = 1.0
    return {
        "matched_pairs": len(details),
        "contrasts": dict(contrasts),
        "discordant_pairs": discordant,
        "exact_two_sided_sign_test_p_discovery_only": p_two_sided,
        "details": details,
        "interpretation": "The intervention preserves the complete joint raw+clock inventory but changes its spatial organization; discovery selection prohibits confirmatory use of this p-value.",
    }


def scaling_screen(rows: list[dict]) -> dict:
    organized = [row for row in rows if row["arm"] == "organized_inward"]
    y = np.array([row["dense"] for row in organized], dtype=int)
    candidates = []
    for alpha in np.linspace(-1.0, 3.0, 81):
        x = np.array([row["total_records"] / (row["N"] ** alpha) for row in organized], dtype=float)
        model = fit_stump(x, y)
        candidates.append({
            "alpha": float(alpha),
            "threshold": model["threshold"],
            "direction": model["direction"],
            "balanced_accuracy": model["balanced_accuracy"],
            "errors": model["errors"],
        })
    candidates.sort(key=lambda item: (-item["balanced_accuracy"], item["errors"], abs(item["alpha"]), item["alpha"]))
    return {
        "role": "POST_HOC_DISCOVERY_ALPHA_SCAN",
        "grid": {"alpha_min": -1.0, "alpha_max": 3.0, "step": 0.05, "tested": len(candidates)},
        "top_candidates": candidates[:10],
        "warning": "Alpha and threshold were selected on this panel and require freezing plus new-N/seeds holdout before any scale law claim.",
    }


def standardized_fit(train_x: np.ndarray, train_y: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    mean = train_x.mean(axis=0)
    scale = train_x.std(axis=0)
    scale[scale == 0] = 1.0
    standardized = (train_x - mean) / scale
    design = np.column_stack([np.ones(len(standardized)), standardized])
    coefficients = np.linalg.solve(design.T @ design + 1e-6 * np.eye(design.shape[1]), design.T @ train_y)
    return coefficients, mean, scale


def one_step_closure(cases: list[dict]) -> dict:
    feature_names = [
        "positive_fraction",
        "routed_positive_fraction",
        "stationary_positive_fraction",
        "bare_router_fraction",
        "boundary_density",
        "unique_destination_fraction",
        "collision_excess_fraction",
        "forced_target_fraction",
        "semantic7_fraction",
        "sreg_density",
    ]
    records = []
    for case in cases:
        n = int(case["spec"]["N"])
        volume = n ** 3
        # Only the dynamically informative early window is used; each trajectory remains a grouped unit.
        for item in case["trace"][: 2 * n]:
            state = item["state"]
            trans = item["transition_to_next"]
            values = [
                state["positive_fraction"],
                state["routed_positive"] / volume,
                state["stationary_positive"] / volume,
                state["bare_routers"] / volume,
                state["boundary_faces"] / volume,
                state["destination"]["unique_destinations"] / volume,
                state["destination"]["collision_excess"] / volume,
                trans["forced_destination_targets"] / volume,
                state["semantic7"] / volume,
                state["sreg_sum"] / volume,
            ]
            records.append({
                "N": n,
                "case_id": case["case_id"],
                "x": values,
                "delta": trans["net_support_change"] / volume,
            })
    x = np.array([row["x"] for row in records], dtype=float)
    y = np.array([row["delta"] for row in records], dtype=float)
    folds = []
    all_predictions = np.zeros_like(y)
    for n in sorted({row["N"] for row in records}):
        train = np.array([row["N"] != n for row in records])
        test = ~train
        coefficients, mean, scale = standardized_fit(x[train], y[train])
        design_test = np.column_stack([np.ones(np.count_nonzero(test)), (x[test] - mean) / scale])
        prediction = design_test @ coefficients
        all_predictions[test] = prediction
        rmse = float(np.sqrt(np.mean((prediction - y[test]) ** 2)))
        baseline_rmse = float(np.sqrt(np.mean(y[test] ** 2)))
        per_case = []
        for case_id in sorted({records[i]["case_id"] for i in np.where(test)[0]}):
            mask = np.array([row["case_id"] == case_id for row in records]) & test
            per_case.append({
                "case_id": case_id,
                "rmse": float(np.sqrt(np.mean((all_predictions[mask] - y[mask]) ** 2))),
                "persistence_rmse": float(np.sqrt(np.mean(y[mask] ** 2))),
            })
        folds.append({
            "heldout_N": n,
            "samples": int(np.count_nonzero(test)),
            "trajectories": len(per_case),
            "rmse": rmse,
            "persistence_rmse": baseline_rmse,
            "skill_vs_persistence": 1.0 - rmse / baseline_rmse if baseline_rmse else 0.0,
            "per_trajectory": per_case,
        })
    total_rmse = float(np.sqrt(np.mean((all_predictions - y) ** 2)))
    total_baseline = float(np.sqrt(np.mean(y ** 2)))
    return {
        "role": "DISCOVERY_GROUPED_LEAVE_ONE_SIZE_OUT",
        "target": "delta positive-support fraction over one tick, early window t<2N",
        "features": feature_names,
        "samples_are_not_claimed_independent": True,
        "independent_groups": {"trajectories": len(cases), "sizes": len({case["spec"]["N"] for case in cases})},
        "folds": folds,
        "overall_rmse": total_rmse,
        "overall_persistence_rmse": total_baseline,
        "overall_skill_vs_persistence": 1.0 - total_rmse / total_baseline if total_baseline else 0.0,
        "closure_status": "CANDIDATE" if total_rmse < 0.8 * total_baseline and all(fold["skill_vs_persistence"] > 0 for fold in folds) else "NOT_ESTABLISHED",
        "warning": "The model family and feature set were selected in discovery; even a positive score is not confirmation or evidence of an autonomous Q2 state.",
    }


def temporal_mechanism(cases: list[dict]) -> dict:
    dense = [case for case in cases if case["outcome"]["label"].startswith("DENSE")]
    nondense = [case for case in cases if not case["outcome"]["label"].startswith("DENSE")]
    dense_precedence = []
    for case in dense:
        first_z = case["event_ticks"]["first_stationary_positive"]
        first_cross = case["event_ticks"]["first_positive_fraction_ge_0_5"]
        dense_precedence.append({
            "case_id": case["case_id"],
            "first_stationary": first_z,
            "first_half_dense": first_cross,
            "stationary_strictly_precedes_crossing": first_z is not None and first_cross is not None and first_z < first_cross,
        })
    return {
        "dense_cases": len(dense),
        "nondense_cases": len(nondense),
        "stationary_strictly_precedes_crossing_dense": sum(row["stationary_strictly_precedes_crossing"] for row in dense_precedence),
        "nondense_with_any_stationary_support": sum(case["event_ticks"]["first_stationary_positive"] is not None for case in nondense),
        "dense_precedence": dense_precedence,
        "interpretation": "Precedence can support necessity in this panel but stationary onset is not sufficient when nondense trajectories also exhibit it.",
    }


def early_interface_candidate(cases: list[dict]) -> dict:
    rows = []
    for case in cases:
        n = int(case["spec"]["N"])
        tick = n // 4
        state = case["trace"][tick]["state"]
        positive = int(state["positive"])
        boundary = int(state["boundary_faces"])
        kappa = boundary / max(1, positive)
        rows.append({
            "case_id": case["case_id"],
            "N": n,
            "tick": tick,
            "dense": int(case["outcome"]["label"].startswith("DENSE")),
            "q": state["positive_fraction"],
            "positive": positive,
            "boundary_faces": boundary,
            "kappa": kappa,
            "mean_face_neighbor_degree": 6.0 - kappa,
            "collision_excess_per_source": state["destination"]["collision_excess"] / max(1, state["destination"]["source_count"]),
        })
    y = np.array([row["dense"] for row in rows], dtype=int)
    models = {}
    for name in ("q", "kappa", "mean_face_neighbor_degree", "collision_excess_per_source"):
        x = np.array([row[name] for row in rows], dtype=float)
        fitted = fit_stump(x, y)
        models[name] = {key: value for key, value in fitted.items() if key != "sign"}
    frozen_simple_threshold = 5.35
    prediction = np.array([row["kappa"] <= frozen_simple_threshold for row in rows], dtype=int)
    dense_values = [row["kappa"] for row in rows if row["dense"]]
    nondense_values = [row["kappa"] for row in rows if not row["dense"]]
    per_n = []
    for n in sorted({row["N"] for row in rows}):
        mask = np.array([row["N"] == n for row in rows])
        per_n.append({
            "N": n,
            "cases": int(np.count_nonzero(mask)),
            "errors_at_kappa_le_5_35": int(np.count_nonzero(prediction[mask] != y[mask])),
            "balanced_accuracy_at_kappa_le_5_35": balanced_accuracy(y[mask], prediction[mask]),
        })
    return {
        "role": "FORMULA_CANDIDATE_DISCOVERED_POST_HOC",
        "candidate_id": "FC_NSD01_INTERFACE_COMPACTNESS",
        "observation_tick": "floor(N/4)",
        "formula": "kappa=B6/P, where P is positive-support count and B6 is the number of periodic axis-neighbor positive/empty boundary faces",
        "graph_identity": "kappa=6-mean_positive_induced_face_neighbor_degree (exact for P>0)",
        "models_selected_on_discovery": models,
        "simple_candidate_rule": "predict eventual DENSE iff kappa<=5.35",
        "simple_rule_performance": {
            "errors": int(np.count_nonzero(prediction != y)),
            "balanced_accuracy": balanced_accuracy(y, prediction),
            "sensitivity": float(np.mean(prediction[y == 1] == 1)),
            "specificity": float(np.mean(prediction[y == 0] == 0)),
            "per_N": per_n,
        },
        "separation": {
            "max_dense_kappa": max(dense_values),
            "min_nondense_kappa": min(nondense_values),
            "gap": min(nondense_values) - max(dense_values),
            "threshold_margin_to_nearest_observation": min(
                frozen_simple_threshold - max(dense_values),
                min(nondense_values) - frozen_simple_threshold,
            ),
        },
        "rows": rows,
        "adjudication": "PROVISIONAL_PROGRESS: scale-normalized early geometric predictor with a clean four-size discovery gap; neither causality nor confirmation follows.",
        "required_next_step": "Freeze formula, tick, threshold, endpoint and class-diversity relevance; test untouched sizes, preparations and seeds without refitting.",
    }


def render_markdown(analysis: dict) -> str:
    paired = analysis["matched_organization_intervention"]
    temporal = analysis["temporal_mechanism"]
    best = analysis["outcome_stump_screen"][0]
    closure = analysis["one_step_macro_closure"]
    interface = analysis["early_interface_candidate"]
    exact = analysis["exact_balance_audit"]
    return f"""# NSD01 — support balance and scale-flow findings

Status: **DISCOVERY_EVIDENCE_ONLY**. No formula or threshold selected here is confirmatory.

## Exact results

- Across {exact['transitions']} executed transitions, `P(t+1)=P(t)+births-deaths` and `births=forced_destination_births+other_births` had zero residual.
- Every eligible empty routed destination became positive: {exact['forced_destination_violations']} violations. This is an executable witness of the source-level branch theorem, not an emergent conservation law.

## Causal organization result

The exact joint `(raw, clock)` inventory was preserved in all matched arms. Organized inward geometry produced dense outcomes in {paired['contrasts'].get('organized_1_shuffle_0', 0)} pairs where the global joint shuffle did not; reverse discordances: {paired['contrasts'].get('organized_0_shuffle_1', 0)}. The discovery-only exact sign-test value is {paired['exact_two_sided_sign_test_p_discovery_only']:.6g}. Thus inventory count alone is refuted as a sufficient explanation in this panel; spatial organization is a causal component.

## Candidate mechanism

Stationary-positive support strictly preceded the 0.5 crossing in {temporal['stationary_strictly_precedes_crossing_dense']}/{temporal['dense_cases']} dense trajectories, but also appeared in {temporal['nondense_with_any_stationary_support']}/{temporal['nondense_cases']} non-dense trajectories. Onset alone is therefore not sufficient. The leading discovery stump is `{best['feature']}` with leave-one-size-out balanced accuracy {best['leave_one_N_out']['balanced_accuracy']:.3f}; its threshold is post-hoc and must be frozen before use.

At the earlier fixed observation `floor(N/4)`, the native interface coordinate `kappa=B6/P=6-mean_face_degree` separated all 48 discovery trajectories using the simple rule `kappa<=5.35`; the discovery gap was {interface['separation']['gap']:.6g}. This is `PROVISIONAL_PROGRESS`, not confirmation or demonstrated causation.

## Scale and closure

The exponent scan is explicitly post-hoc and does not establish a scale law. The one-step grouped leave-one-size-out macro model has skill {closure['overall_skill_vs_persistence']:.3f} versus persistence and status `{closure['closure_status']}`. This determines whether the next branch should freeze a low-dimensional closure candidate or intervene on the stationary-support feedback mechanism.
"""


def main() -> int:
    source, cases = load_cases()
    rows = feature_rows(cases)
    exact = {
        "transitions": sum(int(case["spec"]["horizon"]) for case in cases),
        "forced_destination_violations": sum(case["exact_audit"]["forced_destination_violations"] for case in cases),
        "absolute_support_partition_residual_sum": sum(case["exact_audit"]["absolute_support_partition_residual_sum"] for case in cases),
        "support_balance": "P(t+1)=P(t)+births(t)-deaths(t)",
        "birth_partition": "births(t)=forced_destination_births(t)+other_births(t)",
    }
    analysis = {
        "schema": "dee.v27.c04.nsd01.analysis.v1",
        "experiment_id": "NSD01",
        "role": "DISCOVERY_ANALYSIS_ONLY",
        "source_path": str(SOURCE.relative_to(WORK)).replace("\\", "/"),
        "source_sha256": sha256_file(SOURCE),
        "runner_sha256": sha256_file(HERE),
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "case_count": len(cases),
        "outcomes": dict(Counter(row["outcome"] for row in rows)),
        "exact_balance_audit": exact,
        "matched_organization_intervention": paired_organization(rows),
        "temporal_mechanism": temporal_mechanism(cases),
        "early_interface_candidate": early_interface_candidate(cases),
        "outcome_stump_screen": stump_screen(rows),
        "preparation_scaling_screen": scaling_screen(rows),
        "one_step_macro_closure": one_step_closure(cases),
        "feature_rows": rows,
        "adjudication_limit": "All selected coordinates, exponents, thresholds and closure models are post-hoc discovery. Only exact identities/source-branch consequences may be stated as exact; empirical candidates require a pre-holdout lock and new worlds.",
    }
    atomic_json(OUT, analysis)
    OUT_MD.write_text(render_markdown(analysis), encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": "COMPLETE",
        "analysis_sha256": sha256_file(OUT),
        "findings_sha256": sha256_file(OUT_MD),
        "outcomes": analysis["outcomes"],
        "matched_contrasts": analysis["matched_organization_intervention"]["contrasts"],
        "best_stumps": analysis["outcome_stump_screen"][:5],
        "temporal_mechanism": analysis["temporal_mechanism"],
        "early_interface_candidate": {key: value for key, value in analysis["early_interface_candidate"].items() if key != "rows"},
        "scaling_top": analysis["preparation_scaling_screen"]["top_candidates"][:3],
        "closure": analysis["one_step_macro_closure"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
