#!/usr/bin/env python3
"""Analyze the exact support operator and matched NSD03 response branches."""
from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import atomic_json, canonical_hash, sha256_file


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
SOURCE = WORK / "RESULTS" / "NSD03_results.json"
OUT = WORK / "ANALYSIS" / "NSD03_analysis.json"
OUT_MD = WORK / "ANALYSIS" / "NSD03_FINDINGS.md"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def load_cases() -> tuple[dict, list[dict]]:
    source = load_json(SOURCE)
    cases = []
    for item in source["case_manifest"]:
        path = WORK / item["path"]
        if sha256_file(path) != item["file_sha256"]:
            raise RuntimeError(f"case hash mismatch: {path}")
        case = load_json(path)
        claimed = case.pop("content_sha256")
        if canonical_hash(case) != claimed:
            raise RuntimeError(f"case content mismatch: {path}")
        case["content_sha256"] = claimed
        cases.append(case)
    return source, cases


def balanced_accuracy(y: np.ndarray, prediction: np.ndarray) -> float:
    return float(np.mean([np.mean(prediction[y == cls] == cls) for cls in (0, 1)]))


def fit_stump(x: np.ndarray, y: np.ndarray) -> dict:
    unique = np.unique(x)
    thresholds = [np.nextafter(unique[0], -np.inf)]
    thresholds.extend(float((a + b) / 2) for a, b in zip(unique[:-1], unique[1:]))
    thresholds.append(np.nextafter(unique[-1], np.inf))
    best = None
    for sign in (1, -1):
        for threshold in thresholds:
            prediction = (sign * (x - threshold) >= 0).astype(int)
            score = balanced_accuracy(y, prediction)
            errors = int(np.count_nonzero(prediction != y))
            candidate = (score, -errors, -abs(float(threshold)), sign, float(threshold))
            if best is None or candidate > best:
                best = candidate
    return {"balanced_accuracy":best[0],"errors":-best[1],"direction":">=" if best[3]==1 else "<=","sign":best[3],"threshold":best[4]}


def feature_rows(cases: list[dict]) -> list[dict]:
    rows = []
    for case in cases:
        n = int(case["spec"]["N"])
        window = case["pre_split"]["trace"][n // 4 : n // 2 + 1]
        qbar = float(np.mean([item["state"]["positive_fraction"] for item in window]))
        audits = [item for item in case["operator_audits"] if item["branch"] == "pre_split_full"]
        mean_viability = float(np.mean([
            audit["counts"]["survivor"] / max(1, audit["counts"]["positive_before"]) for audit in audits
        ]))
        xnor_per_volume = sum(audit["counts"]["xnor_birth"] for audit in audits) / (n ** 3)
        routed_per_volume = sum(audit["counts"]["routed_birth"] for audit in audits) / (n ** 3)
        full_dense = bool(case["branches"]["full"]["endpoint"]["dense"])
        joint_dense = bool(case["branches"]["joint_snapshot_shuffle"]["endpoint"]["dense"])
        clock_dense = bool(case["branches"]["clock_only_shuffle"]["endpoint"]["dense"])
        rows.append({
            "case_id": case["case_id"],
            "N": n,
            "scaling": case["spec"]["scaling"],
            "replicate": case["spec"]["replicate"],
            "full_dense": full_dense,
            "joint_dense": joint_dense,
            "clock_dense": clock_dense,
            "spatially_resistant_given_dense": int(full_dense and joint_dense),
            "features": {
                "bar_kappa": case["pre_split"]["bar_kappa"],
                "bar_q": qbar,
                "kappa_half": window[-1]["state"]["kappa"],
                "q_half": window[-1]["state"]["positive_fraction"],
                "mean_local_viability": mean_viability,
                "cumulative_xnor_per_volume": xnor_per_volume,
                "cumulative_routed_births_per_volume": routed_per_volume,
                "N": float(n),
            },
            "endpoint_raw_hash_equal_full_clock": case["branches"]["full"]["trace"][-1]["state"]["raw_sha256"] == case["branches"]["clock_only_shuffle"]["trace"][-1]["state"]["raw_sha256"],
        })
    return rows


def response_screen(rows: list[dict]) -> list[dict]:
    dense = [row for row in rows if row["full_dense"]]
    y = np.array([row["spatially_resistant_given_dense"] for row in dense], dtype=int)
    results = []
    for feature in sorted(dense[0]["features"]):
        x = np.array([row["features"][feature] for row in dense])
        fit = fit_stump(x, y)
        results.append({"feature": feature, **{key:value for key,value in fit.items() if key!="sign"}})
    return sorted(results, key=lambda item:(-item["balanced_accuracy"],item["errors"],item["feature"]))


def simple_maturity_rule(rows: list[dict]) -> dict:
    dense = [row for row in rows if row["full_dense"]]
    truth = np.array([row["joint_dense"] for row in dense], dtype=bool)
    prediction = np.array([row["features"]["bar_kappa"] <= 3.60 for row in dense], dtype=bool)
    tp = int(np.count_nonzero(truth & prediction)); tn = int(np.count_nonzero(~truth & ~prediction))
    fp = int(np.count_nonzero(~truth & prediction)); fn = int(np.count_nonzero(truth & ~prediction))
    return {
        "role":"FORMULA_CANDIDATE_POST_HOC_DISCOVERY",
        "rule":"Among natural FULL-dense worlds, predict spatial-shuffle resistance iff bar_kappa<=3.60",
        "cases":len(dense),"resistant":int(np.count_nonzero(truth)),"fragile":int(np.count_nonzero(~truth)),
        "tp":tp,"tn":tn,"fp":fp,"fn":fn,"errors":fp+fn,
        "sensitivity":tp/(tp+fn) if tp+fn else None,"specificity":tn/(tn+fp) if tn+fp else None,
        "balanced_accuracy":balanced_accuracy(truth.astype(int),prediction.astype(int)),
        "max_resistant_bar_kappa":max(row["features"]["bar_kappa"] for row in dense if row["joint_dense"]),
        "min_fragile_bar_kappa":min(row["features"]["bar_kappa"] for row in dense if not row["joint_dense"]),
    }


def exact_operator(source: dict, cases: list[dict]) -> dict:
    summary = source["summary"]["operator"]
    audits = [audit for case in cases for audit in case["operator_audits"]]
    if summary["support_mask_mismatches"] != sum(audit["support_mask_mismatch"] for audit in audits):
        raise AssertionError("operator mismatch summary disagrees")
    return {
        "theorem_domain":"F_DEE v27 states/ticks for which delta_demux overflow count is zero; observer and orphan semantics included",
        "mask_equation":"P_{t+1}=S_t union C_t union X_t union R_t (disjoint by current support and empty-branch priority)",
        "S_t":"current semantic-4 positives plus other current positives with >=6 alive Moore neighbors or a tetrahedral signature",
        "C_t":"currently empty non-observer sites meeting crystallization first",
        "X_t":"remaining empty sites meeting all 13 opposite-pair XNOR equalities with >=8 active members",
        "R_t":"remaining empty sites hit by at least one decoded directional source",
        "source_derivation":"Direct case partition of actualizar_voxel, followed by aplicar_demux; zero overflow removes the only post-local support mutation.",
        "executed_audit":summary,
        "all_masks_exact":summary["overflow_events"]==0 and summary["support_mask_mismatches"]==0 and summary["genesis_count_mismatch_sum"]==0,
    }


def main() -> int:
    source,cases=load_cases()
    rows=feature_rows(cases)
    maturity=simple_maturity_rule(rows)
    spatial_changed=sum(row["full_dense"]!=row["joint_dense"] for row in rows)
    clock_changed=sum(row["full_dense"]!=row["clock_dense"] for row in rows)
    analysis={
        "schema":"dee.v27.c04.nsd03.analysis.v1","role":"DISCOVERY_ANALYSIS_WITH_EXACT_SOURCE_THEOREM",
        "source_sha256":sha256_file(SOURCE),"runner_sha256":sha256_file(HERE),"completed_utc":datetime.now(timezone.utc).isoformat(),
        "exact_low_overflow_support_operator":exact_operator(source,cases),
        "causal_intervention":{
            "cases":len(cases),"full_dense":sum(row["full_dense"] for row in rows),
            "joint_snapshot_shuffle_changes_basin":spatial_changed,"clock_only_shuffle_changes_basin":clock_changed,
            "clock_only_endpoint_raw_hash_equal":sum(row["endpoint_raw_hash_equal_full_clock"] for row in rows),
            "interpretation":"Joint raw+clock inventory preservation with destroyed spatial relations changes seven natural dense endpoints; raw-fixed clock-only shuffle changes none. Spatial relation is causal in those precursors, while clock arrangement is dispensable for the tested endpoint/horizon. Three mature dense worlds resist the spatial intervention, limiting necessity to a precursor domain.",
        },
        "maturity_candidate":maturity,
        "response_feature_screen":response_screen(rows),
        "three_regime_candidate":{
            "bar_kappa_gt_5_60":"NONDENSE in the confirmed predictor domain",
            "3_60_lt_bar_kappa_le_5_60":"DENSE but spatially fragile in this discovery panel",
            "bar_kappa_le_3_60":"DENSE and spatial-shuffle resistant in this discovery panel",
            "status":"POST_HOC_RESPONSE_HIERARCHY_CANDIDATE_REQUIRES_LOCKED_HOLDOUT",
        },
        "rows":rows,
        "adjudication":"PROVISIONAL_PROGRESS_RESPONSE_COORDINATE" if maturity["errors"]==0 and maturity["resistant"]>=3 and maturity["fragile"]>=3 else "WEAK_SIGNAL_DORMANT",
    }
    atomic_json(OUT,analysis)
    OUT_MD.write_text(f"""# NSD03 — exact support operator and causal response

## Exact low-overflow operator

For every audited zero-overflow transition, the next positive mask equalled `S ∪ C ∪ X ∪ R`: local survivors, crystallization births, XNOR births, and routed births in branch-priority order. There were {source['summary']['operator']['support_mask_mismatches']} mask mismatches in {source['summary']['operator']['audited_transitions']} transitions.

## Causal result

The N/2 joint `(raw,clock)` snapshot shuffle changed {spatial_changed}/18 basin outcomes, all DENSE→NONDENSE. Clock-only shuffling changed {clock_changed}/18. Therefore spatial relations are causal for the fragile precursor sector; clock arrangement is not required for this tested endpoint.

## New response candidate

Among 10 natural dense worlds, `bar_kappa<=3.60` separated all {maturity['resistant']} shuffle-resistant from {maturity['fragile']} fragile worlds. This suggests a three-regime stability coordinate, but it is post-hoc discovery and needs a new locked holdout.
""",encoding="utf-8",newline="\n")
    print(json.dumps({"status":"COMPLETE","analysis_sha256":sha256_file(OUT),"exact_operator":analysis["exact_low_overflow_support_operator"],"causal":analysis["causal_intervention"],"maturity":maturity,"screen":analysis["response_feature_screen"],"adjudication":analysis["adjudication"]},indent=2,sort_keys=True))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
