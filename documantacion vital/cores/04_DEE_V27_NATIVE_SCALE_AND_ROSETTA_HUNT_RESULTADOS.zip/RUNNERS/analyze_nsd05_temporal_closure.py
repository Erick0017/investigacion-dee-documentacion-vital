#!/usr/bin/env python3
"""NSD05: grouped discovery audit of temporal macrostate closure.

This is discovery only.  It reuses complete NSH02 traces and never treats
successive ticks as independent experimental units: fitting may use several
coarse temporal samples per world, but all evaluation summaries are grouped by
world and each cross-size fold holds out an entire N (hence independent worlds).
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD05_temporal_closure.json"
LAG_FRACTIONS = (1.0 / 16.0, 1.0 / 8.0, 1.0 / 4.0)


def canonical_hash(obj: object) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def verify_case(doc: dict) -> None:
    claimed = doc.get("content_sha256")
    payload = dict(doc)
    payload.pop("content_sha256", None)
    observed = canonical_hash(payload)
    if claimed != observed:
        raise RuntimeError(f"case content hash mismatch: {doc.get('case_id')} {claimed} != {observed}")


def state_vector(row: dict, n: int) -> dict[str, float]:
    s = row["state"]
    p = float(s["positive"])
    volume = float(n**3)
    return {
        "q": p / volume,
        "k": float(s["kappa"]) / 6.0,
        "stationary_frac": float(s["stationary_positive"]) / max(p, 1.0),
        "routed_frac": float(s["routed_positive"]) / max(p, 1.0),
        "bare_router_frac": float(s.get("bare_routers", 0)) / max(p, 1.0),
    }


def feature(v: dict[str, float], name: str) -> list[float]:
    q, k = v["q"], v["k"]
    if name == "q_only":
        return [1.0, q, q * q, q * q * q]
    base = [1.0, q, k, q * q, q * k, k * k]
    if name == "q_kappa":
        return base
    if name == "rich_macro":
        return base + [v["stationary_frac"], v["routed_frac"], v["bare_router_frac"]]
    raise KeyError(name)


def fit_ridge(x: np.ndarray, y: np.ndarray) -> dict[str, np.ndarray]:
    # Leave the intercept unstandardized; standardize other columns to make the
    # tiny numerical ridge invariant to units rather than a tuning parameter.
    mu = x[:, 1:].mean(axis=0)
    sd = x[:, 1:].std(axis=0)
    sd[sd < 1e-12] = 1.0
    xs = x.copy()
    xs[:, 1:] = (xs[:, 1:] - mu) / sd
    penalty = np.eye(xs.shape[1]) * 1e-8
    penalty[0, 0] = 0.0
    beta = np.linalg.solve(xs.T @ xs + penalty, xs.T @ y)
    return {"beta": beta, "mu": mu, "sd": sd}


def predict(model: dict[str, np.ndarray], x: np.ndarray) -> np.ndarray:
    xs = x.copy()
    xs[:, 1:] = (xs[:, 1:] - model["mu"]) / model["sd"]
    return xs @ model["beta"]


def skill(sse: float, baseline_sse: float) -> float | None:
    return None if baseline_sse <= 1e-18 else 1.0 - sse / baseline_sse


def summarize_world_errors(rows: list[dict], errors: np.ndarray, baseline: np.ndarray) -> dict:
    grouped: dict[str, list[int]] = {}
    for i, r in enumerate(rows):
        grouped.setdefault(r["world_id"], []).append(i)
    per_world = []
    for world_id, idx in sorted(grouped.items()):
        ii = np.asarray(idx, dtype=int)
        sse = float(np.square(errors[ii]).sum())
        bse = float(np.square(baseline[ii]).sum())
        per_world.append({"world_id": world_id, "sse": sse, "persistence_sse": bse, "skill": skill(sse, bse)})
    finite = [x["skill"] for x in per_world if x["skill"] is not None]
    return {
        "worlds": len(per_world),
        "median_world_skill": None if not finite else float(np.median(finite)),
        "fraction_worlds_beating_persistence": None if not finite else float(np.mean(np.asarray(finite) > 0.0)),
        "per_world": per_world,
    }


def main() -> None:
    docs = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        verify_case(doc)
        docs.append(doc)
    if len(docs) != 72:
        raise RuntimeError(f"expected 72 complete NSH02 cases, found {len(docs)}")

    results = {}
    for lag_fraction in LAG_FRACTIONS:
        samples: list[dict] = []
        for doc in docs:
            n = int(doc["spec"]["N"])
            lag = max(1, int(round(n * lag_fraction)))
            by_tick = {int(row["tick"]): row for row in doc["trace"] if "state" in row}
            # About 4--13 nonoverlapping coarse observations per trajectory.
            for t in range(n // 4, n + 1, lag):
                if t not in by_tick or t + lag not in by_tick:
                    continue
                current = state_vector(by_tick[t], n)
                future = state_vector(by_tick[t + lag], n)
                samples.append(
                    {
                        "world_id": doc["case_id"],
                        "N": n,
                        "lag": lag,
                        "t_over_N": t / n,
                        "current": current,
                        "delta": np.asarray([future["q"] - current["q"], future["k"] - current["k"]], dtype=float),
                    }
                )

        lag_key = f"tau_{lag_fraction:.6f}"
        fold_results = []
        held_ns = sorted({r["N"] for r in samples})
        for held_n in held_ns:
            train = [r for r in samples if r["N"] != held_n]
            test = [r for r in samples if r["N"] == held_n]
            y_train = np.stack([r["delta"] for r in train])
            y_test = np.stack([r["delta"] for r in test])
            persistence_error = -y_test
            persistence_sse_total = float(np.square(persistence_error).sum())
            models = {}
            for model_name in ("q_only", "q_kappa", "rich_macro"):
                x_train = np.asarray([feature(r["current"], model_name) for r in train], dtype=float)
                x_test = np.asarray([feature(r["current"], model_name) for r in test], dtype=float)
                model = fit_ridge(x_train, y_train)
                prediction = predict(model, x_test)
                error = prediction - y_test
                sse_total = float(np.square(error).sum())
                q_sse = float(np.square(error[:, 0]).sum())
                k_sse = float(np.square(error[:, 1]).sum())
                q_base = float(np.square(y_test[:, 0]).sum())
                k_base = float(np.square(y_test[:, 1]).sum())
                models[model_name] = {
                    "dimensions": int(x_test.shape[1] - 1),
                    "samples_train": len(train),
                    "samples_test": len(test),
                    "skill_vs_persistence_joint": skill(sse_total, persistence_sse_total),
                    "skill_vs_persistence_q": skill(q_sse, q_base),
                    "skill_vs_persistence_kappa": skill(k_sse, k_base),
                    "world_grouped": summarize_world_errors(test, error, persistence_error),
                }
            fold_results.append({"held_out_N": held_n, "test_worlds": len({r['world_id'] for r in test}), "models": models})

        aggregate = {}
        for model_name in ("q_only", "q_kappa", "rich_macro"):
            joint = [f["models"][model_name]["skill_vs_persistence_joint"] for f in fold_results]
            qskill = [f["models"][model_name]["skill_vs_persistence_q"] for f in fold_results]
            kskill = [f["models"][model_name]["skill_vs_persistence_kappa"] for f in fold_results]
            world_frac = [f["models"][model_name]["world_grouped"]["fraction_worlds_beating_persistence"] for f in fold_results]
            aggregate[model_name] = {
                "mean_cross_N_joint_skill": float(np.mean(joint)),
                "min_cross_N_joint_skill": float(np.min(joint)),
                "mean_cross_N_q_skill": float(np.mean(qskill)),
                "mean_cross_N_kappa_skill": float(np.mean(kskill)),
                "mean_fraction_worlds_beating_persistence": float(np.mean(world_frac)),
            }
        qk = aggregate["q_kappa"]
        rich = aggregate["rich_macro"]
        discovery_gate = {
            "joint_mean_gt_0_75": qk["mean_cross_N_joint_skill"] > 0.75,
            "joint_min_gt_0_50": qk["min_cross_N_joint_skill"] > 0.50,
            "q_mean_gt_0_50": qk["mean_cross_N_q_skill"] > 0.50,
            "kappa_mean_gt_0_50": qk["mean_cross_N_kappa_skill"] > 0.50,
            "rich_macro_increment_lt_0_05": (rich["mean_cross_N_joint_skill"] - qk["mean_cross_N_joint_skill"]) < 0.05,
        }
        results[lag_key] = {
            "lag_fraction_of_N": lag_fraction,
            "samples": len(samples),
            "worlds": len({r["world_id"] for r in samples}),
            "folds": fold_results,
            "aggregate": aggregate,
            "discovery_gate": discovery_gate,
            "candidate_worthy": all(discovery_gate.values()),
        }

    output = {
        "schema": "dee.v27.c04.nsd05.temporal_closure.v1",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can a two-coordinate global state (q,kappa) close its own coarse temporal dynamics across N?",
        "input": "72 hash-verified complete NSH02 worlds; no new kernel execution",
        "independent_unit": "world; evaluation holds out every world at one entire N",
        "time_domain": "floor(N/4) through N, nonoverlapping lag samples",
        "targets": ["delta q", "delta(kappa/6)"],
        "baseline": "persistence (zero increment)",
        "results": results,
        "interpretation_rule": "Candidate-worthy requires every listed discovery gate at a lag; this is only a decision rule for whether to freeze a subsequent independent holdout, never confirmation itself.",
    }
    output["content_sha256"] = canonical_hash(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    compact = {
        key: {
            "candidate_worthy": value["candidate_worthy"],
            "q_kappa": value["aggregate"]["q_kappa"],
            "rich_macro": value["aggregate"]["rich_macro"],
        }
        for key, value in results.items()
    }
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "summary": compact}, indent=2))


if __name__ == "__main__":
    main()
