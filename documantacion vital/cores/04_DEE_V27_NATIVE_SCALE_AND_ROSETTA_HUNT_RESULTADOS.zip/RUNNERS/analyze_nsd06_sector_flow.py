#!/usr/bin/env python3
"""NSD06 discovery: Q2-gated two-dimensional flow at temporal scale N/8.

The gate is not learned here: it is the already confirmed NSH02 rule
bar_kappa<=5.60.  The sparse sector uses the simplest possible effective
operator (identity).  A quadratic map is fitted only for the dense sector.
All evaluation is leave-one-size-out and summarized per independent world.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD06_sector_flow.json"
THRESHOLD = 5.60


def canonical_hash(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def verify_case(doc: dict) -> None:
    claimed = doc.get("content_sha256")
    payload = dict(doc)
    payload.pop("content_sha256", None)
    if canonical_hash(payload) != claimed:
        raise RuntimeError(f"content hash mismatch: {doc.get('case_id')}")


def z(row: dict, n: int) -> np.ndarray:
    state = row["state"]
    return np.asarray([float(state["positive"]) / float(n**3), float(state["kappa"]) / 6.0], dtype=float)


def phi(zz: np.ndarray) -> np.ndarray:
    q, k = float(zz[0]), float(zz[1])
    return np.asarray([1.0, q, k, q * q, q * k, k * k], dtype=float)


def fit_raw(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    mu = x[:, 1:].mean(axis=0)
    sd = x[:, 1:].std(axis=0)
    sd[sd < 1e-12] = 1.0
    xs = x.copy()
    xs[:, 1:] = (xs[:, 1:] - mu) / sd
    penalty = np.eye(xs.shape[1]) * 1e-8
    penalty[0, 0] = 0.0
    beta_scaled = np.linalg.solve(xs.T @ xs + penalty, xs.T @ y)
    beta_raw = beta_scaled.copy()
    beta_raw[1:, :] = beta_scaled[1:, :] / sd[:, None]
    beta_raw[0, :] = beta_scaled[0, :] - (mu / sd) @ beta_scaled[1:, :]
    return beta_raw


def per_world(rows: list[dict], prediction: np.ndarray) -> list[dict]:
    grouped: dict[str, list[int]] = {}
    for i, row in enumerate(rows):
        grouped.setdefault(row["world_id"], []).append(i)
    out = []
    for world_id, indices in sorted(grouped.items()):
        ii = np.asarray(indices, dtype=int)
        truth = np.stack([rows[i]["delta"] for i in indices])
        pred = prediction[ii]
        err = pred - truth
        base = -truth
        sse = float(np.square(err).sum())
        bse = float(np.square(base).sum())
        q_rmse = float(np.sqrt(np.mean(np.square(err[:, 0]))))
        k_rmse = float(np.sqrt(np.mean(np.square(err[:, 1]))))
        meta = rows[indices[0]]
        out.append(
            {
                "world_id": world_id,
                "N": meta["N"],
                "sector": "DENSE_FLOW" if meta["dense_gate"] else "SPARSE_IDENTITY",
                "samples": len(indices),
                "joint_sse": sse,
                "persistence_sse": bse,
                "skill_vs_persistence": None if bse <= 1e-18 else 1.0 - sse / bse,
                "q_rmse": q_rmse,
                "kappa_over_6_rmse": k_rmse,
            }
        )
    return out


def summarize(items: list[dict]) -> dict:
    skills = [x["skill_vs_persistence"] for x in items if x["skill_vs_persistence"] is not None]
    return {
        "worlds": len(items),
        "mean_world_skill": None if not skills else float(np.mean(skills)),
        "median_world_skill": None if not skills else float(np.median(skills)),
        "fraction_beating_persistence": None if not skills else float(np.mean(np.asarray(skills) > 0.0)),
        "median_q_rmse": float(np.median([x["q_rmse"] for x in items])),
        "max_q_rmse": float(np.max([x["q_rmse"] for x in items])),
        "median_kappa_over_6_rmse": float(np.median([x["kappa_over_6_rmse"] for x in items])),
        "max_kappa_over_6_rmse": float(np.max([x["kappa_over_6_rmse"] for x in items])),
    }


def main() -> None:
    docs = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        verify_case(doc)
        docs.append(doc)
    if len(docs) != 72:
        raise RuntimeError(f"expected 72 cases, found {len(docs)}")

    rows = []
    gate_endpoint_mismatches = []
    for doc in docs:
        n = int(doc["spec"]["N"])
        lag = max(1, int(round(n / 8.0)))
        dense_gate = float(doc["observation"]["bar_kappa"]) <= THRESHOLD
        endpoint_dense = bool(doc["endpoint"]["dense"])
        if dense_gate != endpoint_dense:
            gate_endpoint_mismatches.append(doc["case_id"])
        by_tick = {int(row["tick"]): row for row in doc["trace"] if "state" in row}
        for t in range(n // 2, n + 1, lag):
            if t not in by_tick or t + lag not in by_tick:
                continue
            current = z(by_tick[t], n)
            future = z(by_tick[t + lag], n)
            rows.append(
                {
                    "world_id": doc["case_id"],
                    "N": n,
                    "dense_gate": dense_gate,
                    "lag": lag,
                    "t": t,
                    "current": current,
                    "delta": future - current,
                }
            )

    folds = []
    all_predictions: dict[str, np.ndarray] = {}
    all_test_rows: dict[str, dict] = {}
    for held_n in sorted({r["N"] for r in rows}):
        train_dense = [r for r in rows if r["N"] != held_n and r["dense_gate"]]
        test = [r for r in rows if r["N"] == held_n]
        x_train = np.stack([phi(r["current"]) for r in train_dense])
        y_train = np.stack([r["delta"] for r in train_dense])
        beta = fit_raw(x_train, y_train)
        prediction = np.zeros((len(test), 2), dtype=float)
        for i, row in enumerate(test):
            if row["dense_gate"]:
                prediction[i] = phi(row["current"]) @ beta
        world_rows = per_world(test, prediction)
        for item in world_rows:
            all_test_rows[item["world_id"]] = item
        dense_items = [x for x in world_rows if x["sector"] == "DENSE_FLOW"]
        sparse_items = [x for x in world_rows if x["sector"] == "SPARSE_IDENTITY"]
        folds.append(
            {
                "held_out_N": held_n,
                "train_dense_worlds": len({r["world_id"] for r in train_dense}),
                "test": summarize(world_rows),
                "dense_flow": summarize(dense_items),
                "sparse_identity": summarize(sparse_items),
            }
        )

    all_worlds = list(all_test_rows.values())
    dense_worlds = [x for x in all_worlds if x["sector"] == "DENSE_FLOW"]
    sparse_worlds = [x for x in all_worlds if x["sector"] == "SPARSE_IDENTITY"]

    dense_rows = [r for r in rows if r["dense_gate"]]
    final_beta = fit_raw(np.stack([phi(r["current"]) for r in dense_rows]), np.stack([r["delta"] for r in dense_rows]))
    output = {
        "schema": "dee.v27.c04.nsd06.sector_flow.v1",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Does confirmed Q2 sector membership gate a compact effective flow rather than one global macro equation?",
        "independent_unit": "world; every evaluation fold holds out a complete N",
        "domain": "NSH02 nested-shell worlds, t/N in [1/2,1], lag=round(N/8)",
        "state": {"z": ["q=positive/N^3", "k=kappa/6"], "dimensions": 2},
        "gate": {"formula": "DENSE_FLOW iff bar_kappa<=5.60, else SPARSE_IDENTITY", "source": "NSH02 previously confirmed frozen rule", "endpoint_mismatches": gate_endpoint_mismatches},
        "dense_operator": {
            "formula": "Delta z = beta0 + beta1*q + beta2*k + beta3*q^2 + beta4*q*k + beta5*k^2",
            "feature_order": ["1", "q", "k", "q^2", "q*k", "k^2"],
            "target_order": ["Delta q", "Delta k"],
            "beta_raw_full_discovery": final_beta.tolist(),
            "free_coefficients": 12,
        },
        "sparse_operator": {"formula": "Delta z = (0,0)", "free_coefficients": 0},
        "folds": folds,
        "aggregate": {"all": summarize(all_worlds), "dense_flow": summarize(dense_worlds), "sparse_identity": summarize(sparse_worlds)},
        "compression": {"micro_state_values": "2*N^3 packed raw/clock values", "effective_state_values": 3, "effective_values": ["bar_kappa gate", "q", "k"]},
        "warning": "This is a discovered mixture-of-sectors candidate. Its coefficients and relevance tolerances must be frozen before any new kernel panel.",
    }
    output["content_sha256"] = canonical_hash(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "gate_mismatches": len(gate_endpoint_mismatches), "aggregate": output["aggregate"], "beta": final_beta.tolist()}, indent=2))


if __name__ == "__main__":
    main()
