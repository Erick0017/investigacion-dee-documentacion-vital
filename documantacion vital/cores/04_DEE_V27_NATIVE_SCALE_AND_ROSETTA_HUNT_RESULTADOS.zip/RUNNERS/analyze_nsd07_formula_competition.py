#!/usr/bin/env python3
"""NSD07 discovery model competition for the dense-sector N/8 flow."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD07_formula_competition.json"
GATE = 5.60
FEATURES = {
    "constant": ("1",),
    "linear_q": ("1", "q"),
    "linear_qk": ("1", "q", "k"),
    "quadratic_q": ("1", "q", "q2"),
    "quadratic_qk": ("1", "q", "k", "q2", "qk", "k2"),
}


def canonical_hash(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def verify(doc: dict) -> None:
    payload = dict(doc)
    claimed = payload.pop("content_sha256")
    if canonical_hash(payload) != claimed:
        raise RuntimeError(f"hash mismatch {doc.get('case_id')}")


def vector(row: dict, n: int) -> np.ndarray:
    s = row["state"]
    return np.asarray([float(s["positive"]) / n**3, float(s["kappa"]) / 6.0])


def design(zz: np.ndarray, feature_names: tuple[str, ...]) -> np.ndarray:
    q, k = map(float, zz)
    values = {"1": 1.0, "q": q, "k": k, "q2": q * q, "qk": q * k, "k2": k * k}
    return np.asarray([values[name] for name in feature_names], dtype=float)


def fit(x: np.ndarray, y: np.ndarray) -> np.ndarray:
    # SVD least squares is deterministic and introduces no tunable regularizer.
    return np.linalg.lstsq(x, y, rcond=None)[0]


def world_metrics(rows: list[dict], pred: np.ndarray) -> list[dict]:
    groups: dict[str, list[int]] = {}
    for i, row in enumerate(rows):
        groups.setdefault(row["world_id"], []).append(i)
    out = []
    for world, indices in sorted(groups.items()):
        truth = np.stack([rows[i]["delta"] for i in indices])
        pp = pred[np.asarray(indices)]
        sse = float(np.square(pp - truth).sum())
        bse = float(np.square(truth).sum())
        out.append({"world_id": world, "skill": None if bse <= 1e-18 else 1.0 - sse / bse})
    return out


def summarize(skills: list[float]) -> dict:
    arr = np.asarray(skills, dtype=float)
    return {
        "mean_world_skill": float(arr.mean()),
        "median_world_skill": float(np.median(arr)),
        "min_world_skill": float(arr.min()),
        "fraction_worlds_beating_persistence": float(np.mean(arr > 0)),
    }


def main() -> None:
    rows = []
    worlds = 0
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        verify(doc)
        if float(doc["observation"]["bar_kappa"]) > GATE:
            continue
        worlds += 1
        n = int(doc["spec"]["N"])
        lag = max(1, int(round(n / 8.0)))
        by_tick = {int(row["tick"]): row for row in doc["trace"] if "state" in row}
        for t in range(n // 2, n + 1, lag):
            if t in by_tick and t + lag in by_tick:
                current = vector(by_tick[t], n)
                rows.append({"world_id": doc["case_id"], "N": n, "current": current, "delta": vector(by_tick[t + lag], n) - current})
    if worlds != 25:
        raise RuntimeError(f"expected 25 dense-gated discovery worlds, got {worlds}")

    results = {}
    for name, names in FEATURES.items():
        folds = []
        all_skills = []
        for held_n in sorted({r["N"] for r in rows}):
            train = [r for r in rows if r["N"] != held_n]
            test = [r for r in rows if r["N"] == held_n]
            beta = fit(np.stack([design(r["current"], names) for r in train]), np.stack([r["delta"] for r in train]))
            pred = np.stack([design(r["current"], names) @ beta for r in test])
            skills = [x["skill"] for x in world_metrics(test, pred) if x["skill"] is not None]
            all_skills.extend(skills)
            folds.append({"held_out_N": held_n, "worlds": len(skills), **summarize(skills)})
        beta_full = fit(np.stack([design(r["current"], names) for r in rows]), np.stack([r["delta"] for r in rows]))
        results[name] = {
            "feature_order": list(names),
            "free_coefficients": len(names) * 2,
            "folds": folds,
            "aggregate": summarize(all_skills),
            "min_fold_mean_skill": min(f["mean_world_skill"] for f in folds),
            "beta_raw_full_discovery": beta_full.tolist(),
        }

    best = max(v["aggregate"]["mean_world_skill"] for v in results.values())
    admissible = [
        name
        for name, value in results.items()
        if value["aggregate"]["mean_world_skill"] >= best - 0.05
        and value["aggregate"]["fraction_worlds_beating_persistence"] >= 0.90
        and value["min_fold_mean_skill"] >= 0.50
    ]
    selected = min(admissible, key=lambda name: (results[name]["free_coefficients"], -results[name]["aggregate"]["mean_world_skill"])) if admissible else None
    output = {
        "schema": "dee.v27.c04.nsd07.formula_competition.v1",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "domain": "confirmed dense-gated NSH02 worlds; t/N in [1/2,1], lag=round(N/8)",
        "target": ["Delta q", "Delta(kappa/6)"],
        "baseline": "persistence",
        "selection_rule": "Among models within 0.05 mean-world skill of best, with >=0.90 worlds beating persistence and every held-N mean skill >=0.50, select fewest coefficients, breaking ties by skill.",
        "best_mean_world_skill": best,
        "admissible": admissible,
        "selected": selected,
        "results": results,
    }
    output["content_sha256"] = canonical_hash(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "selected": selected, "admissible": admissible, "summary": {k: {"coefficients": v["free_coefficients"], **v["aggregate"], "min_fold_mean_skill": v["min_fold_mean_skill"]} for k, v in results.items()}}, indent=2))


if __name__ == "__main__":
    main()
