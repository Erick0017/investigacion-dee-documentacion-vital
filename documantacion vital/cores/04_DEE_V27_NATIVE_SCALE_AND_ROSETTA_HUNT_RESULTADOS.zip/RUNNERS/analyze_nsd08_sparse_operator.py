#!/usr/bin/env python3
"""NSD08 exhaustive sparse-term discovery for the dense-sector map."""

from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD08_sparse_operator.json"
NAMES = ("1", "q", "k", "q2", "qk", "k2")


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def basis(z: np.ndarray) -> np.ndarray:
    q, k = map(float, z)
    return np.asarray([1.0, q, k, q * q, q * k, k * k])


def state(row: dict, n: int) -> np.ndarray:
    s = row["state"]
    return np.asarray([float(s["positive"]) / n**3, float(s["kappa"]) / 6.0])


def data() -> list[dict]:
    rows = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        payload = dict(doc)
        claimed = payload.pop("content_sha256")
        if digest(payload) != claimed:
            raise RuntimeError(f"hash mismatch {path.name}")
        if float(doc["observation"]["bar_kappa"]) > 5.60:
            continue
        n = int(doc["spec"]["N"])
        lag = max(1, int(round(n / 8)))
        trace = {int(x["tick"]): x for x in doc["trace"] if "state" in x}
        for t in range(n // 2, n + 1, lag):
            if t in trace and t + lag in trace:
                z0 = state(trace[t], n)
                rows.append({"world": doc["case_id"], "N": n, "x": basis(z0), "y": state(trace[t + lag], n) - z0})
    return rows


def cv(rows: list[dict], subset: tuple[int, ...], target: int) -> dict:
    world_sse: dict[str, float] = {}
    world_n: dict[str, int] = {}
    fold_mse = []
    for held_n in sorted({r["N"] for r in rows}):
        train = [r for r in rows if r["N"] != held_n]
        test = [r for r in rows if r["N"] == held_n]
        xx = np.stack([r["x"][list(subset)] for r in train])
        yy = np.asarray([r["y"][target] for r in train])
        beta = np.linalg.lstsq(xx, yy, rcond=None)[0]
        fold_errors = []
        for r in test:
            err = float(r["x"][list(subset)] @ beta - r["y"][target])
            world_sse[r["world"]] = world_sse.get(r["world"], 0.0) + err * err
            world_n[r["world"]] = world_n.get(r["world"], 0) + 1
            fold_errors.append(err * err)
        fold_mse.append(float(np.mean(fold_errors)))
    world_mse = [world_sse[w] / world_n[w] for w in sorted(world_sse)]
    return {
        "mean_world_mse": float(np.mean(world_mse)),
        "median_world_mse": float(np.median(world_mse)),
        "max_fold_mse": float(max(fold_mse)),
        "fold_mse": fold_mse,
    }


def main() -> None:
    rows = data()
    candidates = []
    for width in range(1, len(NAMES) + 1):
        for subset in itertools.combinations(range(len(NAMES)), width):
            # A model without either constant or a vanishing-at-origin term can
            # still be tested; discovery must not impose a preferred ontology.
            candidates.append(subset)
    target_results = {}
    selected_subsets = []
    for target, target_name in enumerate(("Delta_q", "Delta_k")):
        scored = []
        for subset in candidates:
            metric = cv(rows, subset, target)
            scored.append({"indices": list(subset), "terms": [NAMES[i] for i in subset], "coefficients": len(subset), **metric})
        full = next(x for x in scored if tuple(x["indices"]) == tuple(range(len(NAMES))))
        admissible = [
            x for x in scored
            if x["mean_world_mse"] <= 1.10 * full["mean_world_mse"]
            and x["max_fold_mse"] <= 1.25 * full["max_fold_mse"]
        ]
        selected = min(admissible, key=lambda x: (x["coefficients"], x["mean_world_mse"], x["max_fold_mse"]))
        subset = tuple(selected["indices"])
        xx = np.stack([r["x"][list(subset)] for r in rows])
        yy = np.asarray([r["y"][target] for r in rows])
        beta = np.linalg.lstsq(xx, yy, rcond=None)[0]
        selected = dict(selected)
        selected["beta_full_discovery"] = beta.tolist()
        selected_subsets.append(subset)
        target_results[target_name] = {
            "full_quadratic_reference": full,
            "admissible_count": len(admissible),
            "selected": selected,
            "top_by_mean_world_mse": sorted(scored, key=lambda x: (x["mean_world_mse"], x["coefficients"]))[:10],
        }

    # Evaluate the two separately selected equations jointly under leave-N-out.
    joint_world: dict[str, dict] = {}
    folds = []
    for held_n in sorted({r["N"] for r in rows}):
        train = [r for r in rows if r["N"] != held_n]
        test = [r for r in rows if r["N"] == held_n]
        betas = []
        for target, subset in enumerate(selected_subsets):
            betas.append(np.linalg.lstsq(np.stack([r["x"][list(subset)] for r in train]), np.asarray([r["y"][target] for r in train]), rcond=None)[0])
        fold_worlds: dict[str, list[tuple[np.ndarray, np.ndarray]]] = {}
        for r in test:
            pred = np.asarray([r["x"][list(selected_subsets[j])] @ betas[j] for j in range(2)])
            fold_worlds.setdefault(r["world"], []).append((pred, r["y"]))
        skills = []
        for world, pairs in fold_worlds.items():
            pred = np.stack([x[0] for x in pairs])
            truth = np.stack([x[1] for x in pairs])
            sse = float(np.square(pred - truth).sum())
            bse = float(np.square(truth).sum())
            value = None if bse <= 1e-18 else 1.0 - sse / bse
            joint_world[world] = {"skill": value, "N": held_n}
            if value is not None:
                skills.append(value)
        folds.append({"held_out_N": held_n, "mean_world_skill": float(np.mean(skills)), "median_world_skill": float(np.median(skills)), "fraction_beating_persistence": float(np.mean(np.asarray(skills) > 0.0))})
    skills = [x["skill"] for x in joint_world.values() if x["skill"] is not None]
    output = {
        "schema": "dee.v27.c04.nsd08.sparse_operator.v1",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "selection_rule": "For each target, keep the fewest monomials with mean world MSE <=110% and worst-fold MSE <=125% of the full quadratic; tie-break by error.",
        "target_results": target_results,
        "joint_selected": {
            "total_coefficients": sum(len(x) for x in selected_subsets),
            "folds": folds,
            "mean_world_skill": float(np.mean(skills)),
            "median_world_skill": float(np.median(skills)),
            "fraction_worlds_beating_persistence": float(np.mean(np.asarray(skills) > 0.0)),
            "min_fold_mean_skill": float(min(x["mean_world_skill"] for x in folds)),
        },
    }
    output["content_sha256"] = digest(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "selected": {k: v["selected"] for k, v in target_results.items()}, "joint": output["joint_selected"]}, indent=2))


if __name__ == "__main__":
    main()
