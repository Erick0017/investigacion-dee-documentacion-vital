#!/usr/bin/env python3
"""NSD09 derives the exact Q1->Q3 reproduction balance and quantifies terms."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSD03_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD09_cross_level_balance.json"


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def state_at(doc: dict, branch: str, tick: int) -> dict:
    trace = doc["pre_split"]["trace"] if branch == "pre_split_full" else doc["branches"][branch]["trace"]
    matches = [row["state"] for row in trace if int(row["tick"]) == tick]
    if len(matches) != 1:
        raise RuntimeError(f"state lookup failed {doc['case_id']} {branch} t={tick}")
    return matches[0]


def outcome(doc: dict, branch: str) -> str:
    key = "full" if branch == "pre_split_full" else branch
    return doc["branches"][key]["endpoint"]["label"]


def summary(rows: list[dict]) -> dict:
    if not rows:
        return {"transitions": 0}
    return {
        "transitions": len(rows),
        "worlds": len({r["case_id"] for r in rows}),
        "mean_q": float(np.mean([r["q"] for r in rows])),
        "mean_kappa": float(np.mean([r["kappa"] for r in rows])),
        "mean_retention_sigma": float(np.mean([r["sigma"] for r in rows])),
        "mean_routed_reproduction_rho": float(np.mean([r["rho_R"] for r in rows])),
        "mean_amplification_A": float(np.mean([r["A"] for r in rows])),
        "fraction_A_gt_1": float(np.mean(np.asarray([r["A"] for r in rows]) > 1.0)),
        "total_P": sum(r["P"] for r in rows),
        "total_survivors": sum(r["S"] for r in rows),
        "total_deaths": sum(r["D"] for r in rows),
        "total_routed_births": sum(r["R"] for r in rows),
        "total_xnor_births": sum(r["X"] for r in rows),
        "total_crystal_births": sum(r["C"] for r in rows),
        "total_net_change": sum(r["net"] for r in rows),
    }


def main() -> None:
    docs = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        payload = dict(doc)
        claimed = payload.pop("content_sha256")
        if digest(payload) != claimed:
            raise RuntimeError(f"case hash mismatch {path.name}")
        docs.append(doc)
    if len(docs) != 18:
        raise RuntimeError(f"expected 18 cases, found {len(docs)}")

    rows = []
    identity_failures = []
    for doc in docs:
        n = int(doc["spec"]["N"])
        for audit in doc["operator_audits"]:
            c = audit["counts"]
            p = int(c["positive_before"])
            ss = int(c["survivor"])
            cc = int(c["crystal_birth"])
            xx = int(c["xnor_birth"])
            rr = int(c["routed_birth"])
            dd = p - ss
            births = cc + xx + rr
            predicted = ss + births
            observed = int(audit["observed_positive_after"])
            net = births - dd
            if predicted != observed or observed - p != net or audit["support_mask_mismatch"] != 0 or audit["kernel"]["overflows"] != 0:
                identity_failures.append({"case_id": doc["case_id"], "branch": audit["branch"], "tick": audit["tick"]})
            st = state_at(doc, audit["branch"], int(audit["tick"]))
            rows.append({
                "case_id": doc["case_id"], "N": n, "branch": audit["branch"], "tick": int(audit["tick"]), "outcome": outcome(doc, audit["branch"]),
                "q": p / n**3, "kappa": float(st["kappa"]), "P": p, "S": ss, "D": dd, "R": rr, "C": cc, "X": xx,
                "births": births, "net": net, "P_next": observed,
                "sigma": ss / p if p else 0.0, "rho_R": rr / p if p else 0.0,
                "rho_other": (cc + xx) / p if p else 0.0, "A": observed / p if p else None,
            })

    all_births = sum(r["births"] for r in rows)
    routed = sum(r["R"] for r in rows)
    dense_rows = [r for r in rows if r["outcome"] == "DENSE"]
    nondense_rows = [r for r in rows if r["outcome"] == "NONDENSE"]
    phase = {
        "q_lt_0_01": summary([r for r in rows if r["q"] < 0.01]),
        "q_0_01_to_0_10": summary([r for r in rows if 0.01 <= r["q"] < 0.10]),
        "q_ge_0_10": summary([r for r in rows if r["q"] >= 0.10]),
    }

    split_effects = []
    full_clock_exact = 0
    for doc in docs:
        split_tick = int(doc["spec"]["split_tick"])
        audits = {(a["branch"], int(a["tick"])): a for a in doc["operator_audits"]}
        ff = audits[("full", split_tick)]["counts"]
        jj = audits[("joint_snapshot_shuffle", split_tick)]["counts"]
        kk = audits[("clock_only_shuffle", split_tick)]["counts"]
        keys = ("positive_before", "survivor", "crystal_birth", "xnor_birth", "routed_birth", "predicted_positive_after")
        if all(int(ff[x]) == int(kk[x]) for x in keys):
            full_clock_exact += 1
        full_next = int(ff["predicted_positive_after"])
        joint_next = int(jj["predicted_positive_after"])
        p = int(ff["positive_before"])
        split_effects.append({
            "case_id": doc["case_id"], "N": int(doc["spec"]["N"]), "full_endpoint": doc["branches"]["full"]["endpoint"]["label"], "joint_endpoint": doc["branches"]["joint_snapshot_shuffle"]["endpoint"]["label"],
            "survivor_change_joint_minus_full": int(jj["survivor"]) - int(ff["survivor"]),
            "routed_birth_change_joint_minus_full": int(jj["routed_birth"]) - int(ff["routed_birth"]),
            "next_support_change_joint_minus_full": joint_next - full_next,
            "amplification_change": joint_next / p - full_next / p,
        })
    fragile = [x for x in split_effects if x["full_endpoint"] == "DENSE" and x["joint_endpoint"] == "NONDENSE"]
    robust = [x for x in split_effects if x["full_endpoint"] == "DENSE" and x["joint_endpoint"] == "DENSE"]

    def effect_summary(items: list[dict]) -> dict:
        return {
            "worlds": len(items),
            "median_survivor_change": None if not items else float(np.median([x["survivor_change_joint_minus_full"] for x in items])),
            "median_routed_birth_change": None if not items else float(np.median([x["routed_birth_change_joint_minus_full"] for x in items])),
            "median_next_support_change": None if not items else float(np.median([x["next_support_change_joint_minus_full"] for x in items])),
            "median_amplification_change": None if not items else float(np.median([x["amplification_change"] for x in items])),
        }

    kappa = np.asarray([r["kappa"] for r in rows])
    sigma = np.asarray([r["sigma"] for r in rows])
    amp = np.asarray([r["A"] for r in rows])
    output = {
        "schema": "dee.v27.c04.nsd09.cross_level_balance.v1",
        "role": "EXACT_DERIVATION_PLUS_DISCOVERY_QUANTIFICATION",
        "exact_law": {
            "set_form": "P_(t+1)=S_t disjoint_union C_t disjoint_union X_t disjoint_union R_t in the zero-overflow sector",
            "count_form": "P_(t+1)=S+C+X+R=P-D+C+X+R",
            "normalized_form": "q_(t+1)=q_t*A_t, A_t=sigma_t+rho_R,t+rho_other,t",
            "increment_form": "Delta q_t=q_t*(A_t-1)=(R+C+X-D)/N^3",
            "definitions": {"D": "P-S", "sigma": "S/P", "rho_R": "R/P", "rho_other": "(C+X)/P"},
            "identity_failures": identity_failures,
            "audited_transitions": len(rows),
        },
        "quantification": {
            "all": summary(rows), "eventual_dense": summary(dense_rows), "eventual_nondense": summary(nondense_rows), "phase_bins": phase,
            "routed_fraction_of_all_births": routed / all_births if all_births else None,
            "pearson_kappa_retention": float(np.corrcoef(kappa, sigma)[0, 1]),
            "pearson_kappa_amplification": float(np.corrcoef(kappa, amp)[0, 1]),
        },
        "split_interventions": {
            "full_clock_one_step_count_vector_exact": full_clock_exact,
            "cases": len(docs),
            "fragile_dense_to_nondense": effect_summary(fragile),
            "robust_dense_to_dense": effect_summary(robust),
            "all_effects": split_effects,
        },
        "cross_level_interpretation": "Q3 is not a new microscopic force. Its Delta-q equation is an N/8 iterated effective approximation to the exact Q1 retention-plus-routing reproduction factor. Kappa is a relational interface coordinate that predicts retention/amplification; C and X are negligible in this audited family but cannot be deleted from the exact law.",
        "limits": ["Quantitative term dominance is empirical and panel-specific.", "Correlations do not make kappa the sole cause.", "The exact formula is conditional on zero overflow; the empirical NSH05 law did not exclude overflow."],
    }
    output["content_sha256"] = digest(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "exact_failures": len(identity_failures), "routed_fraction_of_births": output["quantification"]["routed_fraction_of_all_births"], "correlations": {"kappa_retention": output["quantification"]["pearson_kappa_retention"], "kappa_amplification": output["quantification"]["pearson_kappa_amplification"]}, "split": output["split_interventions"]}, indent=2))


if __name__ == "__main__":
    main()
