#!/usr/bin/env python3
"""NSD10 post-holdout audit of recursive closure for the frozen NSH05 map."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH05_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD10_recursive_closure.json"
C = {"a0": 0.02328702025934721, "a1": 2.574303732734078, "a2": -2.6162955004776953, "a3": -1.8822948214354622, "b1": -0.6794269820170623, "b2": 0.6915825897523803}


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def state(row: dict, n: int) -> np.ndarray:
    s = row["state"]
    return np.asarray([float(s["positive"]) / n**3, float(s["kappa"]) / 6.0])


def step(z: np.ndarray, dense: bool) -> np.ndarray:
    if not dense:
        return z.copy()
    q, k = map(float, z)
    dq = C["a0"] + C["a1"] * q + C["a2"] * q * q + C["a3"] * q * k
    dk = C["b1"] * k + C["b2"] * k * k
    return z + np.asarray([dq, dk])


def summarize(items: list[dict]) -> dict:
    skills = [x["skill"] for x in items if x["skill"] is not None]
    return {
        "worlds": len(items),
        "mean_world_skill": None if not skills else float(np.mean(skills)),
        "median_world_skill": None if not skills else float(np.median(skills)),
        "fraction_beating_initial_persistence": None if not skills else float(np.mean(np.asarray(skills) > 0)),
        "median_q_rmse": float(np.median([x["q_rmse"] for x in items])),
        "max_q_rmse": float(np.max([x["q_rmse"] for x in items])),
        "median_k_rmse": float(np.median([x["k_rmse"] for x in items])),
        "max_k_rmse": float(np.max([x["k_rmse"] for x in items])),
        "worlds_with_any_out_of_bounds_prediction": sum(bool(x["out_of_bounds_steps"]) for x in items),
    }


def main() -> None:
    items = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        payload = dict(doc)
        claimed = payload.pop("content_sha256")
        if digest(payload) != claimed:
            raise RuntimeError(f"hash mismatch {path.name}")
        n = int(doc["spec"]["N"])
        h = n // 8
        trace = {int(r["tick"]): r for r in doc["early_trace"]}
        dense = doc["observation"]["gate"] == "DENSE_FLOW"
        t0 = n // 2
        initial = state(trace[t0], n)
        prediction = initial.copy()
        predictions = []
        truth = []
        bounds = []
        for j in range(1, 6):
            prediction = step(prediction, dense)
            actual = state(trace[t0 + j * h], n)
            predictions.append(prediction.copy())
            truth.append(actual)
            if np.any(prediction < 0.0) or np.any(prediction > 1.0):
                bounds.append(j)
        predictions_a = np.stack(predictions)
        truth_a = np.stack(truth)
        error = predictions_a - truth_a
        persistence_error = np.repeat(initial[None, :], 5, axis=0) - truth_a
        sse = float(np.square(error).sum())
        bse = float(np.square(persistence_error).sum())
        items.append({
            "case_id": doc["case_id"], "N": n, "gate": doc["observation"]["gate"],
            "skill": None if bse <= 1e-18 else 1.0 - sse / bse,
            "q_rmse": float(np.sqrt(np.mean(np.square(error[:, 0])))),
            "k_rmse": float(np.sqrt(np.mean(np.square(error[:, 1])))),
            "out_of_bounds_steps": bounds,
            "initial": initial.tolist(), "predictions": predictions_a.tolist(), "truth": truth_a.tolist(),
        })
    if len(items) != 36:
        raise RuntimeError(f"expected 36 cases, found {len(items)}")
    dense_items = [x for x in items if x["gate"] == "DENSE_FLOW"]
    sparse_items = [x for x in items if x["gate"] == "SPARSE_IDENTITY"]
    k_star = -C["b1"] / C["b2"]
    q_roots = sorted(np.roots([C["a2"], C["a1"], C["a0"]]).tolist())
    q_star = max(q_roots)
    jacobian_eigenvalues = [1 + C["a1"] + 2 * C["a2"] * q_star, 1 + C["b1"]]
    output = {
        "schema": "dee.v27.c04.nsd10.recursive_closure.v1",
        "role": "POST_HOC_DIAGNOSTIC_NOT_CONFIRMATION",
        "test": "Starting from the true z at N/2, recursively compose the frozen NSH05 G for five N/8 steps without teacher forcing; compare against the same already-open NSH05 trajectories and against persistence from the same initial state.",
        "aggregate": {"all": summarize(items), "dense_flow": summarize(dense_items), "sparse_identity": summarize(sparse_items)},
        "per_N_dense": {str(n): summarize([x for x in dense_items if x["N"] == n]) for n in sorted({x["N"] for x in dense_items})},
        "fixed_points": {
            "k": [0.0, float(k_star)],
            "q_at_k0": [float(x) for x in q_roots],
            "dense_physical_fixed_point": [float(q_star), 0.0],
            "one_step_jacobian_eigenvalues_at_dense_fixed_point": [float(x) for x in jacobian_eigenvalues],
            "locally_stable_under_literal_discrete_iteration": all(abs(x) < 1 for x in jacobian_eigenvalues),
        },
        "cases": items,
        "interpretation_rule": "NSH05 remains a literal PASS for its preregistered teacher-forced one-step claim. Recursive failure would separately refute autonomous semigroup closure of that finite-lag map and must not be used to rewrite NSH05.",
    }
    output["content_sha256"] = digest(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "aggregate": output["aggregate"], "fixed_points": output["fixed_points"], "per_N_dense": output["per_N_dense"]}, indent=2))


if __name__ == "__main__":
    main()
