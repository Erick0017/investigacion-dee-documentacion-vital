#!/usr/bin/env python3
"""NSD11 discovery of a composable continuous generator for the Q2-gated flow."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD11_generator_search.json"
MODELS = {
    "mechanistic_reproduction": ((1, 3, 4), (2, 5)),
    "sparse_triangular": ((0, 1, 3, 4), (2, 5)),
    "full_quadratic": ((0, 1, 2, 3, 4, 5), (0, 1, 2, 3, 4, 5)),
}
NAMES = ("1", "q", "k", "q2", "qk", "k2")


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def z(row: dict, n: int) -> np.ndarray:
    s = row["state"]
    return np.asarray([float(s["positive"]) / n**3, float(s["kappa"]) / 6.0])


def basis(zz: np.ndarray) -> np.ndarray:
    q, k = map(float, zz)
    return np.asarray([1.0, q, k, q * q, q * k, k * k])


def fit_generator(worlds: list[dict], subsets: tuple[tuple[int, ...], tuple[int, ...]]) -> list[np.ndarray]:
    xx = []
    yy = []
    ww = []
    for world in worlds:
        n = world["N"]
        trace = world["trace"]
        ticks = list(range(n // 2, n + 1))
        per_row_weight = 1.0 / len(ticks)
        for t in ticks:
            current = z(trace[t], n)
            future = z(trace[t + 1], n)
            xx.append(basis(current))
            yy.append(n * (future - current))
            ww.append(per_row_weight)
    x = np.stack(xx)
    y = np.stack(yy)
    sqrt_w = np.sqrt(np.asarray(ww))
    betas = []
    for target, subset in enumerate(subsets):
        xt = x[:, list(subset)] * sqrt_w[:, None]
        yt = y[:, target] * sqrt_w
        betas.append(np.linalg.lstsq(xt, yt, rcond=None)[0])
    return betas


def field(zz: np.ndarray, subsets: tuple[tuple[int, ...], tuple[int, ...]], betas: list[np.ndarray]) -> np.ndarray:
    bb = basis(zz)
    return np.asarray([bb[list(subsets[j])] @ betas[j] for j in range(2)])


def advance_rk4(zz: np.ndarray, duration: float, subsets, betas) -> np.ndarray:
    # Fixed 1/256 normalized-time maximum substep; numerical choice is fixed for
    # discovery comparison and far below one kernel tick for the fitted sizes.
    steps = max(1, int(np.ceil(duration * 256)))
    dt = duration / steps
    x = zz.copy()
    with np.errstate(all="ignore"):
        for _ in range(steps):
            k1 = field(x, subsets, betas)
            k2 = field(x + 0.5 * dt * k1, subsets, betas)
            k3 = field(x + 0.5 * dt * k2, subsets, betas)
            k4 = field(x + dt * k3, subsets, betas)
            x = x + dt * (k1 + 2 * k2 + 2 * k3 + k4) / 6.0
            if not np.all(np.isfinite(x)) or np.any(np.abs(x) > 1e6):
                return np.asarray([np.nan, np.nan])
    return x


def rollout(world: dict, subsets, betas) -> dict:
    n = world["N"]
    h = max(1, int(round(n / 8)))
    t0 = n // 2
    current = z(world["trace"][t0], n)
    initial = current.copy()
    predictions, truth, bounds = [], [], []
    blowup_step = None
    for j in range(1, 6):
        current = advance_rk4(current, h / n, subsets, betas)
        if not np.all(np.isfinite(current)):
            blowup_step = j
            break
        actual = z(world["trace"][t0 + j * h], n)
        predictions.append(current.copy())
        truth.append(actual)
        if np.any(current < 0) or np.any(current > 1):
            bounds.append(j)
    if blowup_step is not None:
        return {"world_id": world["world_id"], "N": n, "skill": None, "q_rmse": None, "k_rmse": None, "out_of_bounds_steps": bounds, "numerical_blowup_step": blowup_step}
    pp = np.stack(predictions)
    yy = np.stack(truth)
    err = pp - yy
    base = np.repeat(initial[None, :], len(yy), axis=0) - yy
    sse = float(np.square(err).sum())
    bse = float(np.square(base).sum())
    return {
        "world_id": world["world_id"], "N": n, "skill": None if bse <= 1e-18 else 1.0 - sse / bse,
        "q_rmse": float(np.sqrt(np.mean(np.square(err[:, 0])))), "k_rmse": float(np.sqrt(np.mean(np.square(err[:, 1])))),
        "out_of_bounds_steps": bounds, "numerical_blowup_step": None,
    }


def summarize(items: list[dict]) -> dict:
    skills = [x["skill"] for x in items if x["skill"] is not None and np.isfinite(x["skill"])]
    q_values = [x["q_rmse"] for x in items if x["q_rmse"] is not None and np.isfinite(x["q_rmse"])]
    k_values = [x["k_rmse"] for x in items if x["k_rmse"] is not None and np.isfinite(x["k_rmse"])]
    return {
        "worlds": len(items), "finite_worlds": len(skills),
        "mean_world_skill": None if not skills else float(np.mean(skills)), "median_world_skill": None if not skills else float(np.median(skills)),
        "fraction_beating_persistence": None if not skills else float(np.mean(np.asarray(skills) > 0)), "min_world_skill": None if not skills else float(np.min(skills)),
        "median_q_rmse": None if not q_values else float(np.median(q_values)), "max_q_rmse": None if not q_values else float(np.max(q_values)),
        "median_k_rmse": None if not k_values else float(np.median(k_values)), "max_k_rmse": None if not k_values else float(np.max(k_values)),
        "worlds_out_of_bounds": sum(bool(x["out_of_bounds_steps"]) for x in items),
        "worlds_numerical_blowup": sum(x["numerical_blowup_step"] is not None for x in items),
    }


def main() -> None:
    worlds = []
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        payload = dict(doc)
        claimed = payload.pop("content_sha256")
        if digest(payload) != claimed:
            raise RuntimeError(f"hash mismatch {path.name}")
        if float(doc["observation"]["bar_kappa"]) > 5.60:
            continue
        n = int(doc["spec"]["N"])
        worlds.append({"world_id": doc["case_id"], "N": n, "trace": {int(r["tick"]): r for r in doc["trace"]}})
    if len(worlds) != 25:
        raise RuntimeError(f"expected 25 dense-gated worlds, found {len(worlds)}")

    results = {}
    for model_name, subsets in MODELS.items():
        folds = []
        all_items = []
        for held_n in sorted({w["N"] for w in worlds}):
            train = [w for w in worlds if w["N"] != held_n]
            test = [w for w in worlds if w["N"] == held_n]
            betas = fit_generator(train, subsets)
            items = [rollout(w, subsets, betas) for w in test]
            all_items.extend(items)
            folds.append({"held_out_N": held_n, **summarize(items)})
        betas_full = fit_generator(worlds, subsets)
        valid_fold_medians = [x["median_world_skill"] for x in folds if x["median_world_skill"] is not None]
        results[model_name] = {
            "terms": {"dq_dtau": [NAMES[i] for i in subsets[0]], "dk_dtau": [NAMES[i] for i in subsets[1]]},
            "coefficients": len(subsets[0]) + len(subsets[1]),
            "beta_full_discovery": {"dq_dtau": betas_full[0].tolist(), "dk_dtau": betas_full[1].tolist()},
            "folds": folds, "aggregate": summarize(all_items), "min_fold_median_skill": None if not valid_fold_medians else min(valid_fold_medians),
        }
    best = max(results, key=lambda name: ((results[name]["aggregate"]["mean_world_skill"] if results[name]["aggregate"]["mean_world_skill"] is not None else -1e99) - 0.005 * results[name]["coefficients"]))
    selected = results[best]
    candidate_gate = {
        "mean_world_skill_ge_0_65": selected["aggregate"]["mean_world_skill"] is not None and selected["aggregate"]["mean_world_skill"] >= 0.65,
        "median_world_skill_ge_0_85": selected["aggregate"]["median_world_skill"] is not None and selected["aggregate"]["median_world_skill"] >= 0.85,
        "fraction_beating_ge_0_85": selected["aggregate"]["fraction_beating_persistence"] is not None and selected["aggregate"]["fraction_beating_persistence"] >= 0.85,
        "min_fold_median_ge_0_70": selected["min_fold_median_skill"] is not None and selected["min_fold_median_skill"] >= 0.70,
        "no_out_of_bounds": selected["aggregate"]["worlds_out_of_bounds"] == 0 and selected["aggregate"]["worlds_numerical_blowup"] == 0,
    }
    output = {
        "schema": "dee.v27.c04.nsd11.generator_search.v1", "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can a continuous normalized-time generator restore composable Q3 closure?",
        "fit": "world-balanced least squares on one-tick derivatives dz/dtau=N*Delta z over t/N in [1/2,1]",
        "evaluation": "leave-one-N-out five-step recursive RK4 rollouts from N/2 to about 9N/8; worlds are independent units",
        "models": results, "selected_for_possible_freeze": best, "candidate_gate": candidate_gate, "candidate_worthy": all(candidate_gate.values()),
    }
    output["content_sha256"] = digest(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "selected": best, "candidate_gate": candidate_gate, "candidate_worthy": output["candidate_worthy"], "summaries": {k: {**v["aggregate"], "min_fold_median_skill": v["min_fold_median_skill"], "coefficients": v["coefficients"], "beta": v["beta_full_discovery"]} for k, v in results.items()}}, indent=2))


if __name__ == "__main__":
    main()
