#!/usr/bin/env python3
"""NSD12 final discovery attempt: composable affine map in bounded logits."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
INPUT_DIR = ROOT / "RESULTS" / "NSH02_CASES"
OUTPUT = ROOT / "ANALYSIS" / "NSD12_logit_semigroup.json"
EPS = 1e-9
MODELS = {"diagonal_affine": "diagonal", "coupled_affine": "coupled"}


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def z(row: dict, n: int) -> np.ndarray:
    s = row["state"]
    return np.asarray([float(s["positive"]) / n**3, float(s["kappa"]) / 6.0])


def logit(x: np.ndarray) -> np.ndarray:
    y = np.clip(x, EPS, 1.0 - EPS)
    return np.log(y / (1.0 - y))


def logistic(x: np.ndarray) -> np.ndarray:
    # Stable inverse logit.
    out = np.empty_like(x)
    pos = x >= 0
    out[pos] = 1.0 / (1.0 + np.exp(-x[pos]))
    ex = np.exp(x[~pos])
    out[~pos] = ex / (1.0 + ex)
    return out


def features(w: np.ndarray, kind: str, target: int) -> np.ndarray:
    if kind == "diagonal":
        return np.asarray([1.0, w[target]])
    return np.asarray([1.0, w[0], w[1]])


def fit(worlds: list[dict], kind: str) -> list[np.ndarray]:
    x = [[], []]
    y = [[], []]
    weights = []
    for world in worlds:
        n = world["N"]
        h = max(1, int(round(n / 8)))
        ticks = list(range(n // 2, n + 1, h))
        for t in ticks:
            if t + h not in world["trace"]:
                continue
            w0 = logit(z(world["trace"][t], n))
            w1 = logit(z(world["trace"][t + h], n))
            for target in range(2):
                x[target].append(features(w0, kind, target))
                y[target].append(w1[target])
            weights.append(1.0 / len(ticks))
    sw = np.sqrt(np.asarray(weights))
    betas = []
    for target in range(2):
        xx = np.stack(x[target]) * sw[:, None]
        yy = np.asarray(y[target]) * sw
        betas.append(np.linalg.lstsq(xx, yy, rcond=None)[0])
    return betas


def apply(w: np.ndarray, kind: str, betas: list[np.ndarray]) -> np.ndarray:
    return np.asarray([features(w, kind, target) @ betas[target] for target in range(2)])


def rollout(world: dict, kind: str, betas: list[np.ndarray]) -> dict:
    n = world["N"]
    h = max(1, int(round(n / 8)))
    t0 = n // 2
    initial = z(world["trace"][t0], n)
    w = logit(initial)
    pred, truth = [], []
    for j in range(1, 6):
        w = apply(w, kind, betas)
        pred.append(logistic(w))
        truth.append(z(world["trace"][t0 + j * h], n))
    pp, yy = np.stack(pred), np.stack(truth)
    err = pp - yy
    base = np.repeat(initial[None, :], 5, axis=0) - yy
    sse, bse = float(np.square(err).sum()), float(np.square(base).sum())
    return {"world_id": world["world_id"], "N": n, "skill": None if bse <= 1e-18 else 1.0 - sse / bse, "q_rmse": float(np.sqrt(np.mean(np.square(err[:, 0])))), "k_rmse": float(np.sqrt(np.mean(np.square(err[:, 1]))))}


def summarize(items: list[dict]) -> dict:
    skill = np.asarray([x["skill"] for x in items if x["skill"] is not None])
    return {"worlds": len(items), "mean_world_skill": float(skill.mean()), "median_world_skill": float(np.median(skill)), "min_world_skill": float(skill.min()), "fraction_beating_persistence": float(np.mean(skill > 0)), "median_q_rmse": float(np.median([x["q_rmse"] for x in items])), "max_q_rmse": float(np.max([x["q_rmse"] for x in items])), "median_k_rmse": float(np.median([x["k_rmse"] for x in items])), "max_k_rmse": float(np.max([x["k_rmse"] for x in items]))}


def main() -> None:
    worlds = []
    clips = 0
    for path in sorted(INPUT_DIR.glob("*.json")):
        doc = json.loads(path.read_text(encoding="utf-8"))
        payload = dict(doc)
        claimed = payload.pop("content_sha256")
        if digest(payload) != claimed:
            raise RuntimeError(f"hash mismatch {path.name}")
        if float(doc["observation"]["bar_kappa"]) > 5.60:
            continue
        n = int(doc["spec"]["N"])
        trace = {int(r["tick"]): r for r in doc["trace"]}
        worlds.append({"world_id": doc["case_id"], "N": n, "trace": trace})
        for t in range(n // 2, n + max(1, int(round(n / 8))) + 1):
            zz = z(trace[t], n)
            clips += int(np.count_nonzero((zz <= EPS) | (zz >= 1 - EPS)))
    results = {}
    for name, kind in MODELS.items():
        items = []
        folds = []
        for held_n in sorted({w["N"] for w in worlds}):
            train = [w for w in worlds if w["N"] != held_n]
            test = [w for w in worlds if w["N"] == held_n]
            beta = fit(train, kind)
            fold_items = [rollout(w, kind, beta) for w in test]
            items.extend(fold_items)
            folds.append({"held_out_N": held_n, **summarize(fold_items)})
        beta_full = fit(worlds, kind)
        results[name] = {"coefficients": 4 if kind == "diagonal" else 6, "beta_full_discovery": [x.tolist() for x in beta_full], "aggregate": summarize(items), "folds": folds, "min_fold_median_skill": min(x["median_world_skill"] for x in folds)}
    best = max(results, key=lambda n: results[n]["aggregate"]["mean_world_skill"] - 0.005 * results[n]["coefficients"])
    selected = results[best]
    gate = {"mean_skill_ge_0_65": selected["aggregate"]["mean_world_skill"] >= 0.65, "median_skill_ge_0_85": selected["aggregate"]["median_world_skill"] >= 0.85, "fraction_beating_ge_0_85": selected["aggregate"]["fraction_beating_persistence"] >= 0.85, "min_fold_median_ge_0_70": selected["min_fold_median_skill"] >= 0.70, "no_transform_clipping": clips == 0}
    output = {"schema": "dee.v27.c04.nsd12.logit_semigroup.v1", "role": "DISCOVERY_EVIDENCE_ONLY", "transform": "componentwise logit(q),logit(kappa/6)", "epsilon": EPS, "transform_clips_in_scored_domain": clips, "evaluation": "leave-one-N-out recursive five-step affine composition; independent unit world", "models": results, "selected": best, "candidate_gate": gate, "candidate_worthy": all(gate.values()), "stopping_rule": "If no model is candidate-worthy, close the autonomous two-coordinate closure branch; do not try further coordinate transforms without new mechanistic evidence."}
    output["content_sha256"] = digest(output)
    OUTPUT.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(OUTPUT), "content_sha256": output["content_sha256"], "selected": best, "candidate_gate": gate, "candidate_worthy": output["candidate_worthy"], "results": {k: {**v["aggregate"], "min_fold_median_skill": v["min_fold_median_skill"], "coefficients": v["coefficients"], "beta": v["beta_full_discovery"]} for k, v in results.items()}}, indent=2))


if __name__ == "__main__":
    main()
