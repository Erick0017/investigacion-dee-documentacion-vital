#!/usr/bin/env python3
"""NSD13: missing activity coordinate and exact multiplicative scale composition."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "ANALYSIS" / "NSD13_activity_and_exact_scale.json"


def digest(obj: object) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def verify(doc: dict, path: Path) -> None:
    payload = dict(doc); claimed = payload.pop("content_sha256")
    if digest(payload) != claimed: raise RuntimeError(f"hash mismatch {path}")


def metrics(rows: list[dict], pred_key: str) -> dict:
    truth = np.asarray([r["dense"] for r in rows], dtype=bool); pred = np.asarray([r[pred_key] for r in rows], dtype=bool)
    tp,tn=int(np.count_nonzero(truth&pred)),int(np.count_nonzero(~truth&~pred)); fp,fn=int(np.count_nonzero(~truth&pred)),int(np.count_nonzero(truth&~pred))
    sens=tp/(tp+fn) if tp+fn else None; spec=tn/(tn+fp) if tn+fp else None
    return {"tp":tp,"tn":tn,"fp":fp,"fn":fn,"errors":fp+fn,"sensitivity":sens,"specificity":spec,"balanced_accuracy":None if sens is None or spec is None else (sens+spec)/2}


def observation(doc: dict, trace_key: str, panel: str) -> dict:
    n=int(doc["spec"]["N"]); trace=doc[trace_key]; by={int(x["tick"]):x["state"] for x in trace}
    start,end=n//4,n//2
    k=[float(by[t]["kappa"]) for t in range(start,end+1)]
    a=[float(by[t]["routed_positive"])/max(float(by[t]["positive"]),1.0) for t in range(start,end+1)]
    p0,p1=float(by[start]["positive"]),float(by[end]["positive"])
    bar_k=float(np.mean(k)); bar_a=float(np.mean(a)); cumulative=p1/p0
    return {"panel":panel,"case_id":doc["case_id"],"N":n,"dense":bool(doc["endpoint"]["dense"]),"bar_kappa":bar_k,"bar_activity":bar_a,"window_support_ratio":cumulative,"kappa_prediction":bar_k<=5.60,"activity_prediction":bar_a>=0.50,"conjunction_prediction":bar_k<=5.60 and bar_a>=0.50,"growth_prediction":cumulative>1.0}


def composition_audit(trace: list[dict], case_id: str, panel: str) -> dict:
    by={int(x["tick"]):int(x["state"]["positive"]) for x in trace}; ticks=sorted(by); failures=[]; checks=0
    for block in (1,2,4,8):
        for start in ticks:
            end=start+block
            if end not in by or by[start]==0 or any((start+j) not in by or by[start+j]==0 for j in range(block+1)): continue
            # Exact integer telescoping check avoids floating-point tolerance:
            # (P_end/P_start) == product_j(P_{j+1}/P_j).
            numerator=1; denominator=1
            for j in range(block): numerator*=by[start+j+1]; denominator*=by[start+j]
            checks+=1
            if numerator*by[start] != denominator*by[end]: failures.append({"block":block,"start":start})
    return {"panel":panel,"case_id":case_id,"checks":checks,"failures":failures}


def main() -> None:
    rows=[]; audits=[]
    panels=[("NSH02",ROOT/"RESULTS"/"NSH02_CASES","trace"),("NSH05",ROOT/"RESULTS"/"NSH05_CASES","early_trace"),("NSH06",ROOT/"RESULTS"/"NSH06_CASES","early_trace")]
    for panel,directory,trace_key in panels:
        for path in sorted(directory.glob("*.json")):
            doc=json.loads(path.read_text(encoding="utf-8")); verify(doc,path)
            rows.append(observation(doc,trace_key,panel)); audits.append(composition_audit(doc[trace_key],doc["case_id"],panel))
    by_panel={panel:[r for r in rows if r["panel"]==panel] for panel,_,_ in panels}
    model_names=("kappa_prediction","activity_prediction","conjunction_prediction","growth_prediction")
    performance={panel:{name:metrics(values,name) for name in model_names} for panel,values in by_panel.items()}
    performance["COMBINED"]={name:metrics(rows,name) for name in model_names}
    output={
        "schema":"dee.v27.c04.nsd13.activity_exact_scale.v1","role":"POST_HOC_DISCOVERY_PLUS_EXACT_IDENTITY",
        "candidate":{"activity":"bar_a=mean(routed_positive/positive) from N/4 through N/2","formula":"predict DENSE iff bar_kappa<=5.60 AND bar_a>=0.50","threshold_origin":"0.50 is the fixed majority/activity midpoint, not an optimized cut"},
        "performance":performance,"observations":rows,
        "exact_scale_law":{
            "one_step":"A_t=P_(t+1)/P_t=sigma+rho_R+rho_other in the zero-overflow S/C/X/R decomposition",
            "coarse_factor":"A_t^(h)=P_(t+h)/P_t=product_{j=0}^{h-1} A_(t+j)",
            "log_form":"g_t^(h)=log A_t^(h)=sum_j log A_(t+j)",
            "nature":"The telescoping scale composition is generic for positive counts; the decomposition of each factor into DEE S/R/C/X roles is DEE-specific.",
            "audit_checks":sum(x["checks"] for x in audits),"audit_failures":sum(len(x["failures"]) for x in audits),"audits":audits,
        },
        "interpretation":"Kappa measures retained spatial organization; activity measures available directed action. Their conjunction is a new discovery hypothesis, not confirmation. The exact reproduction factor is a scale-composable event/response observable but is not an autonomous state because future factors require the microstate.",
    }
    output["content_sha256"]=digest(output); OUTPUT.write_text(json.dumps(output,indent=2,sort_keys=True)+"\n",encoding="utf-8")
    print(json.dumps({"output":str(OUTPUT),"content_sha256":output["content_sha256"],"performance":performance,"exact_checks":output["exact_scale_law"]["audit_checks"],"exact_failures":output["exact_scale_law"]["audit_failures"]},indent=2))


if __name__=="__main__": main()
