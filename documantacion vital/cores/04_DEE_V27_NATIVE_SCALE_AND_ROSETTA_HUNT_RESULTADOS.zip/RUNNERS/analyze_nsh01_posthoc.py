#!/usr/bin/env python3
"""Post-hoc analysis of the immutable NSH01 FAIL; never changes its verdict."""
from __future__ import annotations

import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import atomic_json, canonical_hash, sha256_file


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
SOURCE = WORK / "RESULTS" / "NSH01_results.json"
OUT = WORK / "ANALYSIS" / "NSH01_POSTHOC_TEMPORAL.json"
OUT_MD = WORK / "ANALYSIS" / "NSH01_POSTHOC_TEMPORAL.md"
FAILED_LOCK_HASH = "81d6efd8888a5fd3b15e0f78bb73c395f5067712d74e8dd121e9482d0f06f786"


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def load_cases() -> tuple[dict, list[dict]]:
    source = load_json(SOURCE)
    if source["lock_sha256"] != FAILED_LOCK_HASH or source["adjudication"]["verdict"] != "FAIL":
        raise RuntimeError("NSH01 source is not the immutable failed holdout")
    cases = []
    for entry in source["case_manifest"]:
        path = WORK / entry["path"]
        if sha256_file(path) != entry["file_sha256"]:
            raise RuntimeError(f"case hash mismatch: {path}")
        case = load_json(path)
        claimed = case.pop("content_sha256")
        if canonical_hash(case) != claimed:
            raise RuntimeError(f"case content mismatch: {path}")
        case["content_sha256"] = claimed
        cases.append(case)
    return source, cases


def longest_true(values: list[bool]) -> int:
    best = current = 0
    for value in values:
        current = current + 1 if value else 0
        best = max(best, current)
    return best


def features(case: dict) -> dict:
    n = int(case["spec"]["N"])
    t5, t4, t3, t2 = n // 5, n // 4, n // 3, n // 2
    early = case["trace"][: t2 + 1]
    kappas = [float(row["state"]["kappa"]) for row in early]
    qs = [float(row["state"]["positive_fraction"]) for row in early]
    below = [value <= 5.35 for value in kappas]
    first = next((index for index, value in enumerate(below) if value), None)
    qtr_to_half = kappas[t4 : t2 + 1]
    return {
        "kappa_N5": kappas[t5],
        "kappa_N4": kappas[t4],
        "kappa_N3": kappas[t3],
        "kappa_N2": kappas[t2],
        "min_kappa_0_N2": min(kappas),
        "mean_kappa_N4_N2": float(np.mean(qtr_to_half)),
        "mean_q_N4_N2": float(np.mean(qs[t4 : t2 + 1])),
        "mean_face_degree_N2": 6.0 - kappas[t2],
        "max_mean_face_degree_0_N2": 6.0 - min(kappas),
        "dwell_le_5_35_fraction_0_N2": sum(below) / len(below),
        "longest_le_5_35_over_N": longest_true(below) / n,
        "first_passage_le_5_35_over_N": first / n if first is not None else 2.0,
        "integrated_below_5_35_0_N2": float(np.mean([max(0.0, 5.35 - value) for value in kappas])),
        "kappa_drop_N4_to_N2": kappas[t4] - kappas[t2],
        "q_N4": qs[t4],
        "q_N3": qs[t3],
        "q_N2": qs[t2],
        "log_support_growth_N4_to_N2": math.log((early[t2]["state"]["positive"] + 1) / (early[t4]["state"]["positive"] + 1)),
        "max_stationary_fraction_0_N2": max(row["state"]["stationary_positive"] for row in early) / (n ** 3),
    }


def balanced_accuracy(y: np.ndarray, prediction: np.ndarray) -> float:
    return float(np.mean([np.mean(prediction[y == cls] == cls) for cls in (0, 1)]))


def fit_stump(x: np.ndarray, y: np.ndarray) -> dict:
    unique = np.unique(x)
    thresholds = [np.nextafter(unique[0], -np.inf)]
    thresholds.extend(float((a + b) / 2) for a, b in zip(unique[:-1], unique[1:]))
    thresholds.append(np.nextafter(unique[-1], np.inf))
    best = None
    for sign in (1, -1):
        for threshold in thresholds:
            prediction = (sign * (x - threshold) >= 0).astype(int)
            score = balanced_accuracy(y, prediction)
            errors = int(np.count_nonzero(prediction != y))
            candidate = (score, -errors, -abs(float(threshold)), sign, float(threshold))
            if best is None or candidate > best:
                best = candidate
    return {"balanced_accuracy": best[0], "errors": -best[1], "sign": best[3], "threshold": best[4], "direction": ">=" if best[3] == 1 else "<="}


def screen(rows: list[dict]) -> list[dict]:
    names = sorted(rows[0]["features"])
    y = np.array([row["dense"] for row in rows], dtype=int)
    results = []
    for name in names:
        x = np.array([row["features"][name] for row in rows])
        full = fit_stump(x, y)
        predictions = np.zeros_like(y)
        folds = []
        for n in sorted({row["N"] for row in rows}):
            train = np.array([row["N"] != n for row in rows])
            test = ~train
            model = fit_stump(x[train], y[train])
            predictions[test] = (model["sign"] * (x[test] - model["threshold"]) >= 0).astype(int)
            folds.append({
                "heldout_N": n,
                "threshold": model["threshold"],
                "direction": model["direction"],
                "errors": int(np.count_nonzero(predictions[test] != y[test])),
            })
        results.append({
            "feature": name,
            "full_panel": {key: value for key, value in full.items() if key != "sign"},
            "leave_one_N_out": {
                "balanced_accuracy": balanced_accuracy(y, predictions),
                "errors": int(np.count_nonzero(predictions != y)),
                "folds": folds,
            },
        })
    return sorted(results, key=lambda result: (-result["leave_one_N_out"]["balanced_accuracy"], result["leave_one_N_out"]["errors"], result["feature"]))


def fixed_snapshot_errors(source: dict, cases: list[dict]) -> list[dict]:
    errors = []
    for case in cases:
        truth = bool(case["endpoint"]["dense"])
        prediction = bool(case["predictions"]["kappa"])
        if truth != prediction:
            errors.append({
                "case_id": case["case_id"],
                "N": case["spec"]["N"],
                "truth": truth,
                "prediction": prediction,
                "kappa_N4": case["observation"]["kappa"],
                "temporal_features": features(case),
            })
    if len(errors) != source["adjudication"]["models"]["kappa"]["errors"]:
        raise AssertionError("failed-lock error count changed")
    return errors


def main() -> int:
    source, cases = load_cases()
    rows = [
        {
            "case_id": case["case_id"],
            "N": int(case["spec"]["N"]),
            "arm": case["spec"]["arm"],
            "dense": int(case["endpoint"]["dense"]),
            "features": features(case),
        }
        for case in cases
    ]
    feature_screen = screen(rows)
    analysis = {
        "schema": "dee.v27.c04.nsh01.posthoc_temporal.v1",
        "role": "POST_HOC_DISCOVERY_AFTER_IMMUTABLE_FAIL",
        "original_verdict": "FAIL",
        "original_lock_sha256": FAILED_LOCK_HASH,
        "source_sha256": sha256_file(SOURCE),
        "runner_sha256": sha256_file(HERE),
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "case_count": len(cases),
        "fixed_snapshot_errors": fixed_snapshot_errors(source, cases),
        "feature_screen": feature_screen,
        "rows": rows,
        "multiple_testing_notice": f"Post-hoc screen of {len(feature_screen)} scalar temporal summaries; no p-value or selected feature is confirmatory.",
        "branch_rule": "A new hypothesis is scientifically distinct only if it uses predeclared interface history/first-passage, not a refitted single-time kappa threshold, and shows grouped cross-size improvement large enough to challenge the arm null.",
    }
    top = feature_screen[0]
    if top["leave_one_N_out"]["balanced_accuracy"] >= 0.90 and top["leave_one_N_out"]["errors"] <= 6:
        analysis["adjudication"] = "PROVISIONAL_PROGRESS_TEMPORAL_CANDIDATE"
        analysis["next"] = "Define one simple temporal/first-passage formula, freeze it, and test entirely new sizes/seeds; the original NSH01 FAIL remains unchanged."
    else:
        analysis["adjudication"] = "WEAK_SIGNAL_DORMANT_CLOSE_INTERFACE_BRANCH"
        analysis["next"] = "Do not run a near-duplicate holdout; retain the interface association as weak and redirect to a different mechanism."
    atomic_json(OUT, analysis)
    text = f"""# NSH01 post-hoc temporal analysis

The original locked verdict remains **FAIL**. This analysis screens {len(feature_screen)} temporal summaries and is discovery-only.

Best grouped leave-one-size-out feature: `{top['feature']}`; balanced accuracy {top['leave_one_N_out']['balanced_accuracy']:.6f}, errors {top['leave_one_N_out']['errors']}/72. Decision: **{analysis['adjudication']}**.

No threshold from this file is confirmatory. A new holdout is permitted only for one genuinely temporal formula, never for a moved `kappa(floor(N/4))` threshold.
"""
    OUT_MD.write_text(text, encoding="utf-8", newline="\n")
    print(json.dumps({
        "status": "COMPLETE",
        "analysis_sha256": sha256_file(OUT),
        "original_verdict": analysis["original_verdict"],
        "fixed_snapshot_errors": analysis["fixed_snapshot_errors"],
        "top_features": feature_screen[:10],
        "adjudication": analysis["adjudication"],
        "next": analysis["next"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
