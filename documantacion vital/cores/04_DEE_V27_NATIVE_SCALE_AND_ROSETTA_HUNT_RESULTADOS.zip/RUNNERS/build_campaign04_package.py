#!/usr/bin/env python3
"""Build and verify the immutable Campaign 04 result archive."""

from __future__ import annotations

import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import atomic_json, sha256_file


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
TESTS = ROOT.parent
MANIFEST = ROOT / "MANIFEST.json"
HASHES = ROOT / "HASHES.sha256"
ZIP_PATH = TESTS / "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip"
FIXED_TIME = (2026, 9, 13, 7, 30, 0)


def payload_files() -> list[Path]:
    excluded = {MANIFEST.resolve(), HASHES.resolve()}
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or path.resolve() in excluded:
            continue
        if path.name.endswith(".tmp") or "__pycache__" in path.parts:
            continue
        files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def entry(path: Path) -> dict:
    return {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)}


def main() -> int:
    if ZIP_PATH.exists():
        raise RuntimeError(f"sealed campaign archive already exists; refusing overwrite: {ZIP_PATH}")
    validation = json.loads((ROOT / "RESULTS" / "CAMPAIGN04_VALIDATION.json").read_text(encoding="utf-8"))
    if validation.get("status") != "PASS":
        raise RuntimeError("final validation is not PASS")
    files = payload_files()
    required = {
        "FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "STATE.json", "SCIENCE_LOG.ndjson", "CLAIMS.json",
        "ROSETTA_TARGETS.json", "NATIVE_LAWS_DISCOVERED.md", "HIERARCHY_DISCOVERED.md", "CAUSAL_ARCHITECTURE.md",
        "SCALE_LAWS.md", "COARSE_GRAINING.md", "FORMULA_DISCOVERY.md", "ROSETTA_SEARCH.md",
        "ROSETTA_CANDIDATES.md", "NEGATIVE_RESULTS.md", "WEAK_SIGNALS.md", "OPEN_GAPS.md", "REPRODUCE.ps1",
    }
    paths = {p.relative_to(ROOT).as_posix() for p in files}
    missing = sorted(required - paths)
    if missing:
        raise RuntimeError(f"missing required payload: {missing}")
    manifest = {
        "schema": "dee.v27.campaign04.manifest.v1",
        "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "scientific_status": ["HIGHER_HIERARCHY_AND_SCALE_LAW_FOUND", "MULTIPLE_SECTOR_STRUCTURE", "EXTERNAL_EMPIRICAL_FRONTIER"],
        "highest_rosetta_status": "FORMAL_EQUIVALENCE_CANDIDATE",
        "autonomous_scale_closure": False,
        "rosetta_validated": False,
        "external_prediction": False,
        "wheel_sha256": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
        "parent_sha256": {
            "01": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
            "02": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
            "03": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
        },
        "central_holdout": {
            "id": "NSH07",
            "verdict": "PRIMARY_PASS_SECONDARY_PASS",
            "lock_sha256": "80a4b3cff667c9da67d0c76e47954607471645ff68a2e0bc7f094465155f1b24",
            "result_sha256": "405b2f068e0078ae6854f148eabeb2c936136099020b5267553fd3c19121a3ae",
        },
        "generated_utc": datetime.now(timezone.utc).isoformat(),
        "payload_file_count_excluding_manifest_and_hash_list": len(files),
        "payload_bytes_excluding_manifest_and_hash_list": sum(p.stat().st_size for p in files),
        "files": [entry(p) for p in files],
    }
    atomic_json(MANIFEST, manifest)
    hash_entries = manifest["files"] + [entry(MANIFEST)]
    HASHES.write_text("".join(f"{item['sha256']}  {item['path']}\n" for item in hash_entries), encoding="utf-8", newline="\n")

    all_files = files + [MANIFEST, HASHES]
    temporary = ZIP_PATH.with_suffix(ZIP_PATH.suffix + ".tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for path in sorted(all_files, key=lambda p: p.relative_to(ROOT).as_posix()):
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    os.replace(temporary, ZIP_PATH)

    expected_names = sorted(p.relative_to(ROOT).as_posix() for p in all_files)
    with zipfile.ZipFile(ZIP_PATH, "r") as archive:
        bad_crc = archive.testzip()
        actual_names = sorted(archive.namelist())
        if bad_crc is not None or actual_names != expected_names:
            raise RuntimeError(f"ZIP structure/CRC failure: bad_crc={bad_crc}")
        mismatches = []
        for path in all_files:
            relative = path.relative_to(ROOT).as_posix()
            if hashlib.sha256(archive.read(relative)).hexdigest() != sha256_file(path):
                mismatches.append(relative)
        if mismatches:
            raise RuntimeError(f"ZIP byte mismatches: {mismatches}")
    print(json.dumps({
        "status": "SEALED",
        "zip": str(ZIP_PATH),
        "zip_sha256": sha256_file(ZIP_PATH),
        "zip_bytes": ZIP_PATH.stat().st_size,
        "members": len(all_files),
        "manifest_sha256": sha256_file(MANIFEST),
        "hashes_sha256": sha256_file(HASHES),
        "crc": "PASS",
        "byte_for_byte_payload": "PASS",
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
