#!/usr/bin/env python3
"""NSD01 discovery: exact support balance and preparation-to-scale flow.

This panel uses only new deterministic worlds. It is discovery evidence and
cannot confirm a law or a Rosetta mapping. Completed trajectories are written
individually so a technical interruption never promotes or loses a partial run.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))

from native_core import (
    EXPECTED,
    KERNEL_FILE,
    PACKAGE_FILE,
    WHEEL_FILE,
    NativeWorld,
    atomic_json,
    canonical_hash,
    fields,
    pack,
    sha256_array,
    sha256_file,
    verify_and_load_kernel,
)


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
OUT = WORK / "RESULTS" / "NSD01_results.json"
CASE_DIR = WORK / "RESULTS" / "NSD01_CASES"
PROGRESS = WORK / "RESULTS" / "NSD01_progress.json"
CLOCK_BANK = np.array([0, 7, 17, 194, 195, 259, 260, 390, 391, 781, 782], dtype=np.uint64)
N_VALUES = (18, 24, 30, 36)
SCALINGS = ("linear", "area", "volume")
ARMS = ("organized_inward", "global_joint_inventory_shuffle")
REPLICATES = 2
HORIZON_MULTIPLIER = 6


def deterministic_seed(n: int, scaling: str, replicate: int) -> int:
    phrase = f"DEE-v27|C04|NSD01|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


def counts_for(n: int, scaling: str) -> tuple[int, tuple[int, int, int]]:
    if scaling == "linear":
        total = max(7, round(5.3 * n))
    elif scaling == "area":
        total = max(7, round(0.15 * n * n))
    elif scaling == "volume":
        total = max(7, round(0.0042 * n * n * n))
    else:
        raise ValueError(scaling)
    inner = max(1, round(total / 7))
    middle = max(2, round(2 * total / 7))
    outer = total - inner - middle
    if outer < 4:
        shift = 4 - outer
        inner = max(1, inner - shift)
        outer = total - inner - middle
    return total, (inner, middle, outer)


def radii_for(n: int) -> tuple[int, int, int]:
    inner = max(2, round(0.10 * n))
    middle = max(inner + 2, round(0.24 * n))
    outer = max(middle + 2, round(0.37 * n))
    if outer >= n // 2:
        outer = n // 2 - 1
    return inner, middle, outer


def tor_delta(coords: np.ndarray, center: np.ndarray, n: int) -> np.ndarray:
    return ((coords - center + n // 2) % n) - n // 2


def cheb_radius_grid(n: int, center: np.ndarray) -> np.ndarray:
    axes = [((np.arange(n) - int(center[j]) + n // 2) % n) - n // 2 for j in range(3)]
    xx, yy, zz = np.meshgrid(*axes, indexing="ij")
    return np.maximum.reduce([np.abs(xx), np.abs(yy), np.abs(zz)]).astype(np.int16)


def shell_candidates(radius_grid: np.ndarray, radius: int) -> np.ndarray:
    return np.argwhere((radius_grid <= radius) & (radius_grid >= max(1, radius - 1)))


def construct_world(n: int, scaling: str, replicate: int) -> tuple[np.ndarray, np.ndarray, dict]:
    seed = deterministic_seed(n, scaling, replicate)
    rng = np.random.default_rng(seed)
    center = np.array([n // 2] * 3, dtype=np.int64)
    radius_grid = cheb_radius_grid(n, center)
    total, counts = counts_for(n, scaling)
    radii = radii_for(n)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    layers = []
    for layer, (radius, count) in enumerate(zip(radii, counts)):
        candidates = shell_candidates(radius_grid, radius)
        if count > len(candidates):
            raise RuntimeError(f"count {count} exceeds shell capacity {len(candidates)}")
        coords = candidates[rng.permutation(len(candidates))[:count]].astype(np.int16)
        for index, q16 in enumerate(coords):
            q = q16.astype(np.int64)
            delta = tor_delta(q[None, :], center, n)[0]
            direction = tuple(int(-np.sign(component)) for component in delta)
            if direction == (0, 0, 0):
                raise AssertionError("zero direction selected on a shell")
            site = tuple(int(x) for x in q)
            raw[site] = pack(1, int(rng.integers(1, 65)), direction, 1)
            clock[site] = CLOCK_BANK[(index + 3 * layer + seed) % len(CLOCK_BANK)]
        layers.append({"radius": radius, "count": count, "capacity": int(len(candidates))})
    if int(np.count_nonzero(raw)) != total:
        raise AssertionError("construction lost or duplicated records")
    return raw, clock, {
        "seed": seed,
        "center": center.tolist(),
        "total_records": total,
        "counts": list(counts),
        "radii": list(radii),
        "layers": layers,
    }


def joint_multiset_hash(raw: np.ndarray, clock: np.ndarray) -> str:
    flat_raw = raw.reshape(-1).astype("<u8", copy=False)
    flat_clock = clock.reshape(-1).astype("<u8", copy=False)
    pairs = np.rec.fromarrays([flat_raw, flat_clock], names="raw,clock")
    order = np.argsort(pairs, order=("raw", "clock"))
    payload = np.column_stack([flat_raw[order], flat_clock[order]]).astype("<u8", copy=False)
    return sha256_array(payload)


def apply_arm(raw: np.ndarray, clock: np.ndarray, arm: str, seed: int) -> tuple[np.ndarray, np.ndarray, dict]:
    result_raw = raw.copy()
    result_clock = clock.copy()
    before = joint_multiset_hash(result_raw, result_clock)
    if arm == "global_joint_inventory_shuffle":
        rng = np.random.default_rng(seed ^ 0x5CA1E04)
        permutation = rng.permutation(result_raw.size)
        result_raw = result_raw.reshape(-1)[permutation].reshape(raw.shape).copy()
        result_clock = result_clock.reshape(-1)[permutation].reshape(clock.shape).copy()
    elif arm != "organized_inward":
        raise ValueError(arm)
    after = joint_multiset_hash(result_raw, result_clock)
    return result_raw, result_clock, {
        "joint_inventory_sha256_before": before,
        "joint_inventory_sha256_after": after,
        "joint_inventory_exact": before == after,
        "sitewise_raw_changed": bool(np.any(result_raw != raw)),
        "sitewise_clock_changed": bool(np.any(result_clock != clock)),
    }


def decode(raw: np.ndarray) -> dict[str, np.ndarray]:
    decoded = fields(raw)
    decoded["positive"] = decoded["state"] != 0
    decoded["routed"] = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    return decoded


def destination_statistics(decoded: dict[str, np.ndarray], n: int) -> tuple[dict, np.ndarray]:
    source_mask = decoded["routed"]
    source_coords = np.argwhere(source_mask)
    destination_mask = np.zeros((n, n, n), dtype=bool)
    if len(source_coords) == 0:
        return {
            "source_count": 0,
            "unique_destinations": 0,
            "collision_excess": 0,
            "multi_source_destinations": 0,
            "max_indegree": 0,
            "vector_cancellation_destinations": 0,
        }, destination_mask
    directions = np.column_stack([
        decoded["dx"][source_mask],
        decoded["dy"][source_mask],
        decoded["dz"][source_mask],
    ]).astype(np.int64)
    destinations = (source_coords.astype(np.int64) + directions) % n
    destination_flat = np.ravel_multi_index(destinations.T, (n, n, n))
    unique, inverse, indegree = np.unique(destination_flat, return_inverse=True, return_counts=True)
    destination_mask.reshape(-1)[unique] = True
    sum_x = np.bincount(inverse, weights=directions[:, 0], minlength=len(unique))
    sum_y = np.bincount(inverse, weights=directions[:, 1], minlength=len(unique))
    sum_z = np.bincount(inverse, weights=directions[:, 2], minlength=len(unique))
    cancellations = (indegree > 1) & (sum_x == 0) & (sum_y == 0) & (sum_z == 0)
    return {
        "source_count": int(len(source_coords)),
        "unique_destinations": int(len(unique)),
        "collision_excess": int(len(source_coords) - len(unique)),
        "multi_source_destinations": int(np.count_nonzero(indegree > 1)),
        "max_indegree": int(np.max(indegree)),
        "vector_cancellation_destinations": int(np.count_nonzero(cancellations)),
    }, destination_mask


def boundary_faces(positive: np.ndarray) -> int:
    return int(sum(np.count_nonzero(positive != np.roll(positive, 1, axis=axis)) for axis in range(3)))


def state_metrics(raw: np.ndarray) -> tuple[dict, dict[str, np.ndarray], np.ndarray]:
    n = raw.shape[0]
    total = n ** 3
    decoded = decode(raw)
    positive = decoded["positive"]
    routed = decoded["routed"]
    destination, destination_mask = destination_statistics(decoded, n)
    routed_positive = positive & routed
    stationary_positive = positive & ~routed
    bare_routers = ~positive & routed
    metric = {
        "positive": int(np.count_nonzero(positive)),
        "positive_fraction": float(np.count_nonzero(positive) / total),
        "routed_positive": int(np.count_nonzero(routed_positive)),
        "stationary_positive": int(np.count_nonzero(stationary_positive)),
        "bare_routers": int(np.count_nonzero(bare_routers)),
        "direction_nonzero": int(np.count_nonzero(routed)),
        "semantic4": int(np.count_nonzero(decoded["semantic"] == 4)),
        "semantic7": int(np.count_nonzero(decoded["semantic"] == 7)),
        "sreg_sum": int(np.sum(decoded["sreg"], dtype=np.uint64)),
        "boundary_faces": boundary_faces(positive),
        "raw_nonzero": int(np.count_nonzero(raw)),
        "raw_sha256": sha256_array(raw),
        "destination": destination,
    }
    return metric, decoded, destination_mask


def transition_metrics(
    before: dict[str, np.ndarray],
    after: dict[str, np.ndarray],
    destination_mask: np.ndarray,
) -> dict:
    positive_before = before["positive"]
    positive_after = after["positive"]
    observer_block = (before["semantic"] == 4) & ~positive_before & destination_mask
    forced = ~positive_before & destination_mask & ~observer_block
    births = ~positive_before & positive_after
    survivors = positive_before & positive_after
    forced_births = forced & positive_after
    other_births = births & ~forced
    deaths = positive_before & ~positive_after
    partition_residual = int(np.count_nonzero(positive_after)) - (
        int(np.count_nonzero(survivors))
        + int(np.count_nonzero(forced_births))
        + int(np.count_nonzero(other_births))
    )
    return {
        "survivors": int(np.count_nonzero(survivors)),
        "deaths": int(np.count_nonzero(deaths)),
        "births": int(np.count_nonzero(births)),
        "forced_destination_targets": int(np.count_nonzero(forced)),
        "forced_destination_births": int(np.count_nonzero(forced_births)),
        "forced_destination_violations": int(np.count_nonzero(forced & ~positive_after)),
        "observer_blocked_destination_targets": int(np.count_nonzero(observer_block)),
        "other_births": int(np.count_nonzero(other_births)),
        "support_partition_residual": partition_residual,
        "net_support_change": int(np.count_nonzero(positive_after) - np.count_nonzero(positive_before)),
        "balance_rhs_births_minus_deaths": int(np.count_nonzero(births) - np.count_nonzero(deaths)),
    }


def outcome_label(trace: list[dict], n: int) -> dict:
    final = trace[-1]["state"]
    hashes = [row["state"]["raw_sha256"] for row in trace]
    fixed_tail_length = 1
    for index in range(len(hashes) - 1, 0, -1):
        if hashes[index] != hashes[index - 1]:
            break
        fixed_tail_length += 1
    period_n_hash_match = len(hashes) > n and hashes[-1] == hashes[-1 - n]
    if final["positive_fraction"] >= 0.9 and fixed_tail_length >= n:
        label = "DENSE_RAW_FIXED_TAIL"
    elif final["positive_fraction"] >= 0.9:
        label = "DENSE_NONFIXED"
    elif final["positive_fraction"] < 0.01 and period_n_hash_match:
        label = "SPARSE_PERIOD_N_HASH_WITNESS"
    elif final["positive_fraction"] < 0.01:
        label = "SPARSE_NONPERIODIC_AT_HORIZON"
    else:
        label = "INTERMEDIATE_OTHER"
    return {
        "label": label,
        "positive_fraction_H": final["positive_fraction"],
        "fixed_tail_length": fixed_tail_length,
        "period_N_hash_match": period_n_hash_match,
        "classification_role": "DISCOVERY_DESCRIPTION_NOT_FROZEN_CONFIRMATION",
    }


def case_specs() -> list[dict]:
    return [
        {"N": n, "scaling": scaling, "replicate": replicate, "arm": arm, "horizon": HORIZON_MULTIPLIER * n}
        for n in N_VALUES
        for scaling in SCALINGS
        for replicate in range(REPLICATES)
        for arm in ARMS
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}_{spec['arm']}"


def run_case(kernel, threads: int, spec: dict, design_sha256: str) -> dict:
    n = int(spec["N"])
    raw, clock, construction = construct_world(n, spec["scaling"], int(spec["replicate"]))
    raw, clock, arm_audit = apply_arm(raw, clock, spec["arm"], int(construction["seed"]))
    if not arm_audit["joint_inventory_exact"]:
        raise AssertionError("joint-inventory arm changed its inventory")
    world = NativeWorld(kernel, raw, clock, threads)
    trace = []
    first_stationary_tick = None
    first_semantic7_tick = None
    first_half_dense_tick = None
    exact_violations = 0
    support_residuals = 0
    for tick in range(int(spec["horizon"]) + 1):
        state, decoded, destinations = state_metrics(world.raw)
        row = {"tick": tick, "state": state}
        if first_stationary_tick is None and state["stationary_positive"] > 0:
            first_stationary_tick = tick
        if first_semantic7_tick is None and state["semantic7"] > 0:
            first_semantic7_tick = tick
        if first_half_dense_tick is None and state["positive_fraction"] >= 0.5:
            first_half_dense_tick = tick
        if tick < int(spec["horizon"]):
            info = world.tick()
            after = decode(world.raw)
            transition = transition_metrics(decoded, after, destinations)
            exact_violations += transition["forced_destination_violations"]
            support_residuals += abs(transition["support_partition_residual"])
            if transition["net_support_change"] != transition["balance_rhs_births_minus_deaths"]:
                raise AssertionError("support balance arithmetic failed")
            row["kernel"] = info
            row["transition_to_next"] = transition
        trace.append(row)
    result = {
        "schema": "dee.v27.c04.nsd01.case.v1",
        "experiment_id": "NSD01",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE_NO_HOLDOUT_LOCK_BY_DESIGN",
        "case_id": case_id(spec),
        "design_sha256": design_sha256,
        "spec": spec,
        "construction": construction,
        "arm_audit": arm_audit,
        "initial_raw_sha256": trace[0]["state"]["raw_sha256"],
        "final_raw_sha256": trace[-1]["state"]["raw_sha256"],
        "exact_audit": {
            "forced_destination_violations": exact_violations,
            "absolute_support_partition_residual_sum": support_residuals,
        },
        "event_ticks": {
            "first_stationary_positive": first_stationary_tick,
            "first_semantic7": first_semantic7_tick,
            "first_positive_fraction_ge_0_5": first_half_dense_tick,
        },
        "outcome": outcome_label(trace, n),
        "trace": trace,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def static_audit() -> dict:
    specs = case_specs()
    checks = {
        "wheel_exists": WHEEL_FILE.is_file(),
        "package_exists": PACKAGE_FILE.is_file(),
        "kernel_exists": KERNEL_FILE.is_file(),
        "discovery_role_literal": "DISCOVERY_EVIDENCE_ONLY" in HERE.read_text(encoding="utf-8"),
        "no_holdout_path": "HOLDOUT_LOCKS" not in str(OUT),
        "at_least_three_unopened_sizes": len(set(N_VALUES) - {28, 30, 32, 35, 40, 42, 48, 56}) >= 3,
        "matched_two_arm_design": ARMS == ("organized_inward", "global_joint_inventory_shuffle"),
        "three_competing_scalings": SCALINGS == ("linear", "area", "volume"),
        "single_thread_default": True,
        "case_ids_unique": len(specs) == len({case_id(spec) for spec in specs}),
        "modest_maximum_size": max(N_VALUES) <= 36,
    }
    observed = {}
    if all((WHEEL_FILE.is_file(), PACKAGE_FILE.is_file(), KERNEL_FILE.is_file())):
        observed = {
            "wheel": sha256_file(WHEEL_FILE),
            "package": sha256_file(PACKAGE_FILE),
            "kernel": sha256_file(KERNEL_FILE),
        }
        checks["identity_hashes_match"] = observed == EXPECTED
    design = {
        "experiment_id": "NSD01",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Does Q2 arise from a scale-stable support-generation mechanism, and can routed/stationary balance close beyond q_N?",
        "hypotheses": [
            "H1: final regime and transition timing collapse primarily by total inventory under one preparation scaling flow.",
            "H2: organization changes the flow despite exact joint inventory, so inventory alone is insufficient.",
            "H3: stationary-positive support or non-routed birth onset is a precursor to dense amplification.",
            "H0: no tested compact support/destination coordinate yields a stable cross-N relation.",
        ],
        "sizes": list(N_VALUES),
        "scalings": list(SCALINGS),
        "arms": list(ARMS),
        "replicates": REPLICATES,
        "horizon": "6N",
        "telemetry": [
            "positive/routed/stationary/bare-router support",
            "destination multiplicity/cancellation",
            "birth-death exact balance",
            "forced routed births",
            "interfaces, semantic7, s_reg, kernel events",
        ],
        "flexibility": "All outcome labels, fits and next hypotheses remain discovery-only; no candidate law is promoted by this panel.",
    }
    return {
        "schema": "dee.v27.c04.nsd01.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "observed_hashes": observed,
        "runner_sha256": sha256_file(HERE),
        "design": design,
        "design_sha256": canonical_hash(design),
        "planned_cases": len(specs),
        "planned_universe_ticks": sum(int(spec["horizon"]) for spec in specs) + HORIZON_MULTIPLIER * N_VALUES[0],
    }


def load_completed(path: Path, spec: dict, design_sha256: str) -> dict | None:
    if not path.is_file():
        return None
    with path.open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if value.get("case_id") != case_id(spec) or value.get("design_sha256") != design_sha256:
        raise RuntimeError(f"stale or foreign completed case: {path}")
    claimed = value.pop("content_sha256", None)
    observed = canonical_hash(value)
    value["content_sha256"] = claimed
    if claimed != observed:
        raise RuntimeError(f"case content hash mismatch: {path}")
    return value


def summarize(cases: list[dict]) -> dict:
    labels = Counter(case["outcome"]["label"] for case in cases)
    by_scaling_arm = {}
    for scaling in SCALINGS:
        for arm in ARMS:
            subset = [case for case in cases if case["spec"]["scaling"] == scaling and case["spec"]["arm"] == arm]
            by_scaling_arm[f"{scaling}|{arm}"] = {
                "cases": len(subset),
                "labels": dict(Counter(case["outcome"]["label"] for case in subset)),
                "final_positive_fraction_mean": float(np.mean([case["outcome"]["positive_fraction_H"] for case in subset])),
                "first_half_dense_ticks": [case["event_ticks"]["first_positive_fraction_ge_0_5"] for case in subset],
                "first_stationary_ticks": [case["event_ticks"]["first_stationary_positive"] for case in subset],
            }
    return {
        "case_count": len(cases),
        "outcome_labels": dict(labels),
        "by_scaling_arm": by_scaling_arm,
        "all_forced_destination_births_exact": all(case["exact_audit"]["forced_destination_violations"] == 0 for case in cases),
        "all_support_partitions_exact": all(case["exact_audit"]["absolute_support_partition_residual_sum"] == 0 for case in cases),
        "joint_inventory_exact_all_arms": all(case["arm_audit"]["joint_inventory_exact"] for case in cases),
    }


def run_replay_sentinel(kernel, threads: int, first_case: dict) -> dict:
    spec = first_case["spec"]
    raw, clock, construction = construct_world(int(spec["N"]), spec["scaling"], int(spec["replicate"]))
    raw, clock, _ = apply_arm(raw, clock, spec["arm"], int(construction["seed"]))
    world = NativeWorld(kernel, raw, clock, threads)
    for _ in range(int(spec["horizon"])):
        world.tick()
    observed = sha256_array(world.raw)
    return {
        "role": "ENGINEERING_REPLAY_NOT_NEW_SCIENTIFIC_CASE",
        "case_id": first_case["case_id"],
        "expected_final_raw_sha256": first_case["final_raw_sha256"],
        "observed_final_raw_sha256": observed,
        "pass": observed == first_case["final_raw_sha256"],
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS":
        raise RuntimeError(f"static audit failed: {audit}")
    if args.threads != 1:
        raise RuntimeError("NSD01 is frozen to one kernel thread for deterministic execution")
    if OUT.exists():
        raise RuntimeError(f"completed result already exists; refusing to repeat: {OUT}")

    started_utc = datetime.now(timezone.utc).isoformat()
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []
    specs = case_specs()
    for index, spec in enumerate(specs, start=1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = load_completed(path, spec, audit["design_sha256"])
        resumed = case is not None
        if case is None:
            case = run_case(kernel, args.threads, spec, audit["design_sha256"])
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {
            "schema": "dee.v27.c04.nsd01.progress.v1",
            "status": "RUNNING" if index < len(specs) else "CASES_COMPLETE",
            "completed_cases": index,
            "total_cases": len(specs),
            "last_case_id": case["case_id"],
            "last_case_resumed": resumed,
            "design_sha256": audit["design_sha256"],
            "next_case_id": case_id(specs[index]) if index < len(specs) else None,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        print(json.dumps({
            "completed": index,
            "total": len(specs),
            "case_id": case["case_id"],
            "outcome": case["outcome"]["label"],
            "q_H": case["outcome"]["positive_fraction_H"],
            "resumed": resumed,
        }), flush=True)

    replay = run_replay_sentinel(kernel, args.threads, cases[0])
    if not replay["pass"]:
        raise RuntimeError(f"deterministic replay failed: {replay}")
    case_manifest = [
        {
            "case_id": case["case_id"],
            "path": str((CASE_DIR / f"{case['case_id']}.json").relative_to(WORK)).replace("\\", "/"),
            "file_sha256": sha256_file(CASE_DIR / f"{case['case_id']}.json"),
            "content_sha256": case["content_sha256"],
            "outcome": case["outcome"],
        }
        for case in cases
    ]
    result = {
        "schema": "dee.v27.c04.nsd01.discovery.v1",
        "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "experiment_id": "NSD01",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "confirmatory_status": "NOT_ELIGIBLE_NO_HOLDOUT_LOCK_BY_DESIGN",
        "started_utc": started_utc,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter() - started,
        "runner_sha256": sha256_file(HERE),
        "static_audit": audit,
        "environment": environment,
        "summary": summarize(cases),
        "replay_sentinel": replay,
        "case_manifest": case_manifest,
    }
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {
        "schema": "dee.v27.c04.nsd01.progress.v1",
        "status": "COMPLETE",
        "completed_cases": len(cases),
        "total_cases": len(cases),
        "result_path": str(OUT.relative_to(WORK)).replace("\\", "/"),
        "result_sha256": sha256_file(OUT),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    })
    print(json.dumps({
        "status": "COMPLETE",
        "result": str(OUT),
        "result_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
        "summary": result["summary"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
