#!/usr/bin/env python3
"""NSD03: exact low-overflow support operator and N/2 snapshot interventions."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh01_holdout as prep
from native_core import (
    EXPECTED, NativeWorld, atomic_json, canonical_hash, fields, sha256_array, sha256_file,
    verify_and_load_kernel,
)


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
OUT = WORK / "RESULTS" / "NSD03_results.json"
CASE_DIR = WORK / "RESULTS" / "NSD03_CASES"
PROGRESS = WORK / "RESULTS" / "NSD03_progress.json"
N_VALUES = (23, 31, 43)
SCALINGS = ("linear", "area", "volume")
REPLICATES = 2
BRANCHES = ("full", "joint_snapshot_shuffle", "clock_only_shuffle")
HORIZON_MULTIPLIER = 6
BAR_KAPPA_THRESHOLD = 5.60
P_KERNEL = 19665
CRYSTAL_THRESHOLD = 966

MOORE = tuple(
    (dx, dy, dz)
    for dx in (-1, 0, 1)
    for dy in (-1, 0, 1)
    for dz in (-1, 0, 1)
    if (dx, dy, dz) != (0, 0, 0)
)
XNOR_PAIRS = (
    (1,0,0), (0,1,0), (0,0,1), (1,1,0), (1,-1,0), (1,0,1), (1,0,-1),
    (0,1,1), (0,1,-1), (1,1,1), (1,1,-1), (1,-1,1), (1,-1,-1),
)
TETRA = (
    ((1,0,0),(0,1,0),(0,0,1),(1,1,1)),
    ((-1,0,0),(0,1,0),(0,0,1),(-1,1,1)),
    ((1,0,0),(0,-1,0),(0,0,1),(1,-1,1)),
    ((1,0,0),(0,1,0),(0,0,-1),(1,1,-1)),
    ((-1,0,0),(0,-1,0),(0,0,1),(-1,-1,1)),
    ((-1,0,0),(0,1,0),(0,0,-1),(-1,1,-1)),
    ((1,0,0),(0,-1,0),(0,0,-1),(1,-1,-1)),
    ((-1,0,0),(0,-1,0),(0,0,-1),(-1,-1,-1)),
)


def seed_for(n: int, scaling: str, replicate: int) -> int:
    payload = f"DEE-v27|C04|NSD03|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


prep.deterministic_seed = seed_for


def shifted(array: np.ndarray, offset: tuple[int, int, int]) -> np.ndarray:
    return np.roll(array, shift=tuple(-component for component in offset), axis=(0, 1, 2))


def direction_destinations(decoded: dict[str, np.ndarray]) -> np.ndarray:
    n = decoded["state"].shape[0]
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    destination = np.zeros_like(routed)
    coords = np.argwhere(routed)
    if len(coords):
        directions = np.column_stack([decoded["dx"][routed], decoded["dy"][routed], decoded["dz"][routed]])
        targets = (coords + directions) % n
        destination[tuple(targets.T.astype(np.intp))] = True
    return destination


def local_support_operator(raw: np.ndarray) -> dict:
    decoded = fields(raw)
    state = decoded["state"]
    semantic = decoded["semantic"]
    positive = state != 0
    alive = positive & (semantic != 5)
    neighbor_count = np.zeros(raw.shape, dtype=np.uint8)
    any_orphan = np.zeros(raw.shape, dtype=bool)
    sreg_positive = np.where(positive, decoded["sreg"].astype(np.int64), 0)
    grad_x = np.zeros(raw.shape, dtype=np.int64)
    grad_y = np.zeros(raw.shape, dtype=np.int64)
    grad_z = np.zeros(raw.shape, dtype=np.int64)
    for dx, dy, dz in MOORE:
        neighbor_count += shifted(alive, (dx, dy, dz)).astype(np.uint8)
        any_orphan |= shifted(semantic == 5, (dx, dy, dz))
        neighbor_sreg = shifted(sreg_positive, (dx, dy, dz))
        grad_x -= dx * neighbor_sreg
        grad_y -= dy * neighbor_sreg
        grad_z -= dz * neighbor_sreg
    tetra = np.zeros(raw.shape, dtype=bool)
    for pattern in TETRA:
        witness = np.ones(raw.shape, dtype=bool)
        for offset in pattern:
            witness &= shifted(alive, offset)
        tetra |= witness

    observer_positive = positive & (semantic == 4)
    matter_survivor = positive & (semantic != 4) & ((neighbor_count >= 6) | tetra)
    survivor = observer_positive | matter_survivor
    empty = ~positive & (semantic != 4)
    grad_mag = np.abs(grad_x) + np.abs(grad_y) + np.abs(grad_z)
    crystal = empty & (neighbor_count > 0) & ((grad_mag // P_KERNEL) >= CRYSTAL_THRESHOLD) & ~any_orphan

    symmetric_count = np.zeros(raw.shape, dtype=np.uint8)
    active_count = np.zeros(raw.shape, dtype=np.uint8)
    for offset in XNOR_PAIRS:
        plus = shifted(alive, offset)
        minus = shifted(alive, tuple(-component for component in offset))
        symmetric_count += (plus == minus).astype(np.uint8)
        active_count += plus.astype(np.uint8) + minus.astype(np.uint8)
    xnor_condition = (symmetric_count == 13) & (active_count >= 8)
    xnor = empty & ~crystal & xnor_condition
    destination = direction_destinations(decoded)
    routed_birth = empty & ~crystal & ~xnor & destination
    predicted = survivor | crystal | xnor | routed_birth
    return {
        "predicted_positive": predicted,
        "counts": {
            "positive_before": int(np.count_nonzero(positive)),
            "survivor": int(np.count_nonzero(survivor)),
            "ordinary_neighbor_survivor": int(np.count_nonzero(matter_survivor & (neighbor_count >= 6))),
            "tetra_rescue_survivor": int(np.count_nonzero(matter_survivor & (neighbor_count < 6) & tetra)),
            "observer_survivor": int(np.count_nonzero(observer_positive)),
            "crystal_birth": int(np.count_nonzero(crystal)),
            "xnor_birth": int(np.count_nonzero(xnor)),
            "routed_birth": int(np.count_nonzero(routed_birth)),
            "predicted_positive_after": int(np.count_nonzero(predicted)),
            "locally_nonviable_positive": int(np.count_nonzero(positive & ~survivor)),
            "positive_with_ge6_alive_neighbors": int(np.count_nonzero(positive & (neighbor_count >= 6))),
        },
    }


def boundary_faces(positive: np.ndarray) -> int:
    return int(sum(np.count_nonzero(positive != np.roll(positive, 1, axis=axis)) for axis in range(3)))


def macro_metrics(raw: np.ndarray, include_hash: bool = False) -> dict:
    decoded = fields(raw)
    positive = decoded["state"] != 0
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    p = int(np.count_nonzero(positive))
    b6 = boundary_faces(positive)
    value = {
        "positive": p,
        "positive_fraction": p / raw.size,
        "B6": b6,
        "kappa": b6 / p if p else None,
        "routed_positive": int(np.count_nonzero(positive & routed)),
        "stationary_positive": int(np.count_nonzero(positive & ~routed)),
        "semantic7": int(np.count_nonzero(decoded["semantic"] == 7)),
        "sreg_sum": int(np.sum(decoded["sreg"], dtype=np.uint64)),
    }
    if include_hash:
        value["raw_sha256"] = sha256_array(raw)
    return value


def joint_hash(raw: np.ndarray, clock: np.ndarray) -> str:
    g = raw.reshape(-1).astype("<u8", copy=False)
    c = clock.reshape(-1).astype("<u8", copy=False)
    records = np.rec.fromarrays([g, c], names="g,c")
    order = np.argsort(records, order=("g", "c"))
    return sha256_array(np.column_stack([g[order], c[order]]).astype("<u8", copy=False))


def make_branches(raw: np.ndarray, clock: np.ndarray, seed: int) -> tuple[dict[str, tuple[np.ndarray, np.ndarray]], dict]:
    rng = np.random.default_rng(seed ^ 0x1A7E4FACE)
    permutation_joint = rng.permutation(raw.size)
    permutation_clock = rng.permutation(clock.size)
    joint_raw = raw.reshape(-1)[permutation_joint].reshape(raw.shape).copy()
    joint_clock = clock.reshape(-1)[permutation_joint].reshape(clock.shape).copy()
    clock_only = clock.reshape(-1)[permutation_clock].reshape(clock.shape).copy()
    branches = {
        "full": (raw.copy(), clock.copy()),
        "joint_snapshot_shuffle": (joint_raw, joint_clock),
        "clock_only_shuffle": (raw.copy(), clock_only),
    }
    audit = {
        "full_joint_hash": joint_hash(raw, clock),
        "joint_shuffle_joint_hash": joint_hash(joint_raw, joint_clock),
        "joint_shuffle_inventory_exact": joint_hash(raw, clock) == joint_hash(joint_raw, joint_clock),
        "joint_shuffle_raw_changed": bool(np.any(joint_raw != raw)),
        "clock_only_raw_exact": bool(np.array_equal(raw, branches["clock_only_shuffle"][0])),
        "clock_only_clock_multiset_exact": sha256_array(np.sort(clock.reshape(-1))) == sha256_array(np.sort(clock_only.reshape(-1))),
        "clock_only_clock_changed": bool(np.any(clock_only != clock)),
    }
    return branches, audit


def audit_transition(world: NativeWorld) -> tuple[dict, dict]:
    operator = local_support_operator(world.raw)
    predicted = operator.pop("predicted_positive")
    world_info = world.tick()
    observed = fields(world.raw)["state"] != 0
    mismatch = int(np.count_nonzero(predicted != observed))
    counts = operator["counts"]
    return {
        "counts": counts,
        "observed_positive_after": int(np.count_nonzero(observed)),
        "support_mask_mismatch": mismatch,
        "genesis_expected_crystal_plus_xnor": counts["crystal_birth"] + counts["xnor_birth"],
        "genesis_observed": int(world_info["genesis"]),
        "genesis_count_mismatch": int(world_info["genesis"]) - counts["crystal_birth"] - counts["xnor_birth"],
        "kernel": world_info,
    }, world_info


def case_specs() -> list[dict]:
    return [
        {"N": n, "scaling": scaling, "replicate": replicate, "split_tick": n // 2, "horizon": HORIZON_MULTIPLIER * n}
        for n in N_VALUES for scaling in SCALINGS for replicate in range(REPLICATES)
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}"


def run_case(kernel, threads: int, spec: dict) -> dict:
    n = int(spec["N"])
    split_tick = int(spec["split_tick"])
    horizon = int(spec["horizon"])
    raw, clock, construction = prep.construct(n, spec["scaling"], int(spec["replicate"]))
    base_world = NativeWorld(kernel, raw, clock, threads)
    base_trace = []
    operator_audits = []
    kappas = []
    window_start = n // 4
    for tick in range(split_tick + 1):
        current = macro_metrics(base_world.raw, include_hash=tick in (0, window_start, split_tick))
        base_trace.append({"tick": tick, "state": current})
        if window_start <= tick <= split_tick:
            kappas.append(current["kappa"])
        if tick < split_tick:
            if tick == 0 or tick >= window_start:
                audit, _ = audit_transition(base_world)
                audit["tick"] = tick
                audit["branch"] = "pre_split_full"
                operator_audits.append(audit)
            else:
                base_world.tick()
    bar_kappa = float(np.mean(kappas))
    split_raw = base_world.raw.copy()
    split_clock = base_world.clock.copy()
    branch_arrays, intervention_audit = make_branches(split_raw, split_clock, int(construction["seed"]))
    branch_results = {}
    for branch, (branch_raw, branch_clock) in branch_arrays.items():
        world = NativeWorld(kernel, branch_raw, branch_clock, threads)
        trace = []
        tail_change_sum = 0
        for tick in range(split_tick, horizon + 1):
            current = macro_metrics(world.raw, include_hash=tick in (split_tick, horizon))
            row = {"tick": tick, "state": current}
            if tick < horizon:
                raw_before = world.raw.copy()
                if tick == split_tick:
                    audit, info = audit_transition(world)
                    audit["tick"] = tick
                    audit["branch"] = branch
                    operator_audits.append(audit)
                else:
                    info = world.tick()
                changed = int(np.count_nonzero(raw_before != world.raw))
                if tick >= horizon - n:
                    tail_change_sum += changed
                row["kernel"] = info
                row["raw_changed_sites_to_next"] = changed
            trace.append(row)
        endpoint = trace[-1]["state"]
        dense = endpoint["positive_fraction"] >= 0.9 and tail_change_sum == 0
        branch_results[branch] = {
            "endpoint": {
                "label": "DENSE" if dense else "NONDENSE",
                "dense": dense,
                "positive_fraction_6N": endpoint["positive_fraction"],
                "tail_raw_changed_sites_sum": tail_change_sum,
            },
            "trace": trace,
        }
    result = {
        "schema": "dee.v27.c04.nsd03.case.v1",
        "experiment_id": "NSD03",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "pre_split": {
            "window_start": window_start,
            "window_end": split_tick,
            "bar_kappa": bar_kappa,
            "confirmed_rule_prediction": bar_kappa <= BAR_KAPPA_THRESHOLD,
            "trace": base_trace,
        },
        "intervention_audit": intervention_audit,
        "operator_audits": operator_audits,
        "branches": branch_results,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict, design_hash: str) -> dict | None:
    if not path.is_file():
        return None
    with path.open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if value.get("case_id") != case_id(spec) or value.get("design_sha256") != design_hash:
        raise RuntimeError(f"stale completed case: {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case content mismatch: {path}")
    value["content_sha256"] = claimed
    return value


def summary(cases: list[dict]) -> dict:
    audits = [audit for case in cases for audit in case["operator_audits"]]
    contrasts = Counter()
    for case in cases:
        full = case["branches"]["full"]["endpoint"]["label"]
        joint = case["branches"]["joint_snapshot_shuffle"]["endpoint"]["label"]
        clock = case["branches"]["clock_only_shuffle"]["endpoint"]["label"]
        contrasts[f"full_{full}|joint_{joint}"] += 1
        contrasts[f"full_{full}|clock_{clock}"] += 1
    return {
        "cases": len(cases),
        "branch_trajectories": len(cases) * len(BRANCHES),
        "outcomes_by_branch": {
            branch: dict(Counter(case["branches"][branch]["endpoint"]["label"] for case in cases)) for branch in BRANCHES
        },
        "matched_contrasts": dict(contrasts),
        "confirmed_bar_kappa_prediction_errors_on_new_discovery_panel": sum(
            case["pre_split"]["confirmed_rule_prediction"] != case["branches"]["full"]["endpoint"]["dense"] for case in cases
        ),
        "intervention_audits_all_pass": all(
            case["intervention_audit"]["joint_shuffle_inventory_exact"]
            and case["intervention_audit"]["clock_only_raw_exact"]
            and case["intervention_audit"]["clock_only_clock_multiset_exact"] for case in cases
        ),
        "operator": {
            "audited_transitions": len(audits),
            "overflow_events": int(sum(audit["kernel"]["overflows"] for audit in audits)),
            "support_mask_mismatches": int(sum(audit["support_mask_mismatch"] for audit in audits)),
            "genesis_count_mismatch_sum": int(sum(abs(audit["genesis_count_mismatch"]) for audit in audits)),
            "crystal_births": int(sum(audit["counts"]["crystal_birth"] for audit in audits)),
            "xnor_births": int(sum(audit["counts"]["xnor_birth"] for audit in audits)),
            "routed_births": int(sum(audit["counts"]["routed_birth"] for audit in audits)),
            "tetra_rescue_survivors": int(sum(audit["counts"]["tetra_rescue_survivor"] for audit in audits)),
        },
    }


def static_audit() -> dict:
    design = {
        "experiment_id": "NSD03", "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Which exact local support terms produce the confirmed temporal relation, and does N/2 spatial or clock shuffling change the basin?",
        "N": list(N_VALUES), "scalings": list(SCALINGS), "replicates": REPLICATES,
        "branches": list(BRANCHES), "split_tick": "floor(N/2)", "horizon": "6N",
        "operator": "survivors + priority-ordered crystal/XNOR/routed empty births, audited exactly when overflow count is zero",
    }
    observed = {"wheel": sha256_file(prep.WHEEL_FILE), "package": sha256_file(prep.PACKAGE_FILE), "kernel": sha256_file(prep.KERNEL_FILE)}
    planned = case_specs()
    checks = {
        "kernel_identity_exact": observed == EXPECTED,
        "new_seed_namespace": "DEE-v27|C04|NSD03|v1" in HERE.read_text(encoding="utf-8"),
        "three_matched_branches": BRANCHES == ("full", "joint_snapshot_shuffle", "clock_only_shuffle"),
        "case_ids_unique": len(planned) == len({case_id(spec) for spec in planned}),
        "discovery_role_literal": "DISCOVERY_EVIDENCE_ONLY" in HERE.read_text(encoding="utf-8"),
    }
    return {
        "schema": "dee.v27.c04.nsd03.static_audit.v1", "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks, "design": design, "design_sha256": canonical_hash(design), "observed_hashes": observed,
        "runner_sha256": sha256_file(HERE), "planned_cases": len(planned),
        "planned_kernel_ticks": sum(spec["split_tick"] + len(BRANCHES) * (spec["horizon"] - spec["split_tick"]) for spec in planned),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(f"static audit failed: {audit}")
    if OUT.exists():
        raise RuntimeError(f"result already complete; refusing repeat: {OUT}")
    started = time.perf_counter()
    started_utc = datetime.now(timezone.utc).isoformat()
    kernel, environment = verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []
    planned = case_specs()
    for index, spec in enumerate(planned, start=1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec, audit["design_sha256"])
        resumed = case is not None
        if case is None:
            case = run_case(kernel, args.threads, spec)
            case["design_sha256"] = audit["design_sha256"]
            # The design hash is part of the content seal.
            case.pop("content_sha256")
            case["content_sha256"] = canonical_hash(case)
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {
            "schema": "dee.v27.c04.nsd03.progress.v1", "status": "RUNNING" if index < len(planned) else "CASES_COMPLETE",
            "completed_cases": index, "total_cases": len(planned), "last_case_id": case["case_id"],
            "last_case_resumed": resumed, "design_sha256": audit["design_sha256"],
            "next_case_id": case_id(planned[index]) if index < len(planned) else None,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        print(json.dumps({
            "completed": index, "total": len(planned), "case_id": case["case_id"],
            "bar_kappa": case["pre_split"]["bar_kappa"],
            "outcomes": {branch: case["branches"][branch]["endpoint"]["label"] for branch in BRANCHES},
            "resumed": resumed,
        }), flush=True)
    result = {
        "schema": "dee.v27.c04.nsd03.discovery.v1", "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "experiment_id": "NSD03", "role": "DISCOVERY_EVIDENCE_ONLY", "confirmatory_status": "NOT_ELIGIBLE_NO_HOLDOUT_LOCK_BY_DESIGN",
        "started_utc": started_utc, "completed_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter() - started, "runner_sha256": sha256_file(HERE),
        "static_audit": audit, "environment": environment, "summary": summary(cases),
        "case_manifest": [
            {"case_id": case["case_id"], "path": str((CASE_DIR / f"{case['case_id']}.json").relative_to(WORK)).replace("\\", "/"),
             "file_sha256": sha256_file(CASE_DIR / f"{case['case_id']}.json"), "content_sha256": case["content_sha256"]}
            for case in cases
        ],
    }
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {"schema":"dee.v27.c04.nsd03.progress.v1","status":"COMPLETE","completed_cases":len(cases),"total_cases":len(cases),"result_sha256":sha256_file(OUT),"timestamp_utc":datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status":"COMPLETE","summary":result["summary"],"result":str(OUT),"result_sha256":sha256_file(OUT),"elapsed_seconds":result["elapsed_seconds"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
