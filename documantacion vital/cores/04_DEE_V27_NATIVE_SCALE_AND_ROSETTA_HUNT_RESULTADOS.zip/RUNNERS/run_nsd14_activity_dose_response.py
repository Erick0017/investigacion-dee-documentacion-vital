#!/usr/bin/env python3
"""NSD14 discovery: matched routed-activity dose response on compact support."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh05_sector_flow_holdout as nsh05
from native_core import EXPECTED, NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
OUT = ROOT / "RESULTS" / "NSD14_results.json"
CASE_DIR = ROOT / "RESULTS" / "NSD14_CASES"
PROGRESS = ROOT / "RESULTS" / "NSD14_progress.json"
N_VALUES = (28, 36)
FRACTIONS = (0.0, 0.125, 0.25, 0.5, 0.75, 1.0)
ORIENTATIONS = ("inward", "outward")


def seed_for(n: int) -> int:
    return int.from_bytes(hashlib.sha256(f"DEE-v27|C04|NSD14|activity-dose|v1|N={n}".encode("ascii")).digest()[:8], "little")


def side_for(n: int) -> int:
    side = int(round(n / 8))
    return side + 1 if side % 2 == 0 else side


def specs() -> list[dict]:
    result = []
    for n in N_VALUES:
        result.append({"N": n, "assigned_fraction": 0.0, "orientation": "stationary", "horizon": 6 * n})
        for fraction in FRACTIONS[1:]:
            for orientation in ORIENTATIONS:
                result.append({"N": n, "assigned_fraction": fraction, "orientation": orientation, "horizon": 6 * n})
    return result


def case_id(spec: dict) -> str:
    fcode = str(spec["assigned_fraction"]).replace(".", "p")
    return f"N{spec['N']}_f{fcode}_{spec['orientation']}"


def construct(spec: dict) -> tuple[np.ndarray, np.ndarray, dict]:
    n = int(spec["N"])
    fraction = float(spec["assigned_fraction"])
    orientation = spec["orientation"]
    seed = seed_for(n)
    rng = np.random.default_rng(seed)
    side = side_for(n)
    center = np.asarray([n // 2] * 3, dtype=int)
    half = side // 2
    coords = np.asarray([
        (i, j, k)
        for i in range(center[0] - half, center[0] + half + 1)
        for j in range(center[1] - half, center[1] + half + 1)
        for k in range(center[2] - half, center[2] + half + 1)
    ], dtype=int)
    sreg = rng.integers(1, 65, size=len(coords))
    bank = nsh05.nsh02.base.CLOCK_BANK
    clocks = np.asarray([bank[int(x)] for x in rng.integers(0, len(bank), size=len(coords))], dtype=np.uint64)
    deltas = np.sign(coords - center).astype(int)
    eligible = np.flatnonzero(np.any(deltas != 0, axis=1))
    priority = eligible[rng.permutation(len(eligible))]
    selected_count = int(round(fraction * len(eligible)))
    selected = set(int(x) for x in priority[:selected_count])
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    for index, pos in enumerate(coords):
        if index not in selected or orientation == "stationary":
            direction = (0, 0, 0)
        elif orientation == "outward":
            direction = tuple(int(x) for x in deltas[index])
        elif orientation == "inward":
            direction = tuple(int(-x) for x in deltas[index])
        else:
            raise ValueError(orientation)
        site = tuple(int(x) for x in pos)
        raw[site] = pack(1, int(sreg[index]), direction, 1)
        clock[site] = clocks[index]
    decoded = fields(raw)
    support = decoded["state"] != 0
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    return raw, clock, {
        "seed": seed,
        "side": side,
        "eligible_sites": int(len(eligible)),
        "selected_sites": selected_count,
        "realized_initial_activity": float(np.count_nonzero(support & routed) / np.count_nonzero(support)),
        "matched_non_direction_hashes": {
            "support": sha256_array(support),
            "state": sha256_array(decoded["state"]),
            "sreg": sha256_array(decoded["sreg"]),
            "semantic": sha256_array(decoded["semantic"]),
            "clock": sha256_array(clock),
        },
    }


def run_case(kernel, spec: dict) -> dict:
    n, horizon = int(spec["N"]), int(spec["horizon"])
    t0, t1 = n // 4, n // 2
    raw, clock, construction = construct(spec)
    world = NativeWorld(kernel, raw, clock, 1)
    window = []
    tail_changes = 0
    overflows = 0
    final_state = None
    for tick in range(horizon + 1):
        capture = t0 <= tick <= t1 or tick == horizon
        state = nsh05.nsh02.base.metrics(world.raw) if capture else None
        if t0 <= tick <= t1:
            p = int(state["positive"])
            window.append({"tick": tick, "positive": p, "kappa": float(state["kappa"]), "activity": float(state["routed_positive"] / p)})
        if tick == horizon:
            final_state = state
            break
        need_tail = tick >= horizon - n
        before = world.raw.copy() if need_tail else None
        info = world.tick()
        overflows += int(info["overflows"])
        if need_tail:
            tail_changes += int(np.count_nonzero(before != world.raw))
    p0, p1 = window[0]["positive"], window[-1]["positive"]
    gamma = math.log(p1 / p0)
    bar_kappa = float(np.mean([x["kappa"] for x in window]))
    bar_activity = float(np.mean([x["activity"] for x in window]))
    dense = bool(final_state["positive_fraction"] >= 0.9 and tail_changes == 0)
    result = {
        "schema": "dee.v27.c04.nsd14.case.v1",
        "experiment_id": "NSD14",
        "role": "DISCOVERY",
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "observation": {
            "Gamma": gamma,
            "bar_kappa": bar_kappa,
            "bar_activity": bar_activity,
            "Gamma_prediction": gamma > 0.0,
            "active_interface_prediction": bar_kappa <= 5.60 and bar_activity >= 0.50,
            "window_sha256": sha256_array(np.asarray([[x["positive"], x["kappa"], x["activity"]] for x in window], dtype="<f8")),
            "window": window,
        },
        "endpoint": {"dense": dense, "label": "DENSE" if dense else "NONDENSE", "positive_fraction_6N": float(final_state["positive_fraction"]), "tail_raw_changed_sites_sum": tail_changes},
        "diagnostics": {"total_overflows": overflows},
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec):
        raise RuntimeError(f"foreign case {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case hash mismatch {path}")
    value["content_sha256"] = claimed
    return value


def summarize(cases: list[dict]) -> dict:
    matched = all(len({json.dumps(c["construction"]["matched_non_direction_hashes"], sort_keys=True) for c in cases if c["spec"]["N"] == n}) == 1 for n in N_VALUES)
    by_track = {}
    monotonic_violations = []
    for n in N_VALUES:
        zero = next(c for c in cases if c["spec"]["N"] == n and c["spec"]["assigned_fraction"] == 0.0)
        for orientation in ORIENTATIONS:
            group = [zero] + sorted([c for c in cases if c["spec"]["N"] == n and c["spec"]["orientation"] == orientation], key=lambda c: c["spec"]["assigned_fraction"])
            endpoint_sequence = [int(c["endpoint"]["dense"]) for c in group]
            gamma_sequence = [float(c["observation"]["Gamma"]) for c in group]
            for left, right in zip(endpoint_sequence[:-1], endpoint_sequence[1:]):
                if right < left:
                    monotonic_violations.append({"N": n, "orientation": orientation, "kind": "endpoint"})
            first_dense = next((float(c["spec"]["assigned_fraction"]) for c in group if c["endpoint"]["dense"]), None)
            first_positive_gamma = next((float(c["spec"]["assigned_fraction"]) for c in group if c["observation"]["Gamma"] > 0), None)
            by_track[f"N{n}_{orientation}"] = {
                "assigned_fractions": [float(c["spec"]["assigned_fraction"]) for c in group],
                "initial_activity": [float(c["construction"]["realized_initial_activity"]) for c in group],
                "Gamma": gamma_sequence,
                "bar_activity": [float(c["observation"]["bar_activity"]) for c in group],
                "bar_kappa": [float(c["observation"]["bar_kappa"]) for c in group],
                "dense": [bool(c["endpoint"]["dense"]) for c in group],
                "first_dense_fraction": first_dense,
                "first_positive_Gamma_fraction": first_positive_gamma,
            }
    gamma_correct = sum(c["observation"]["Gamma_prediction"] == c["endpoint"]["dense"] for c in cases)
    interface_correct = sum(c["observation"]["active_interface_prediction"] == c["endpoint"]["dense"] for c in cases)
    return {
        "audit": {"matched_non_direction_fields_within_N": matched, "all_case_hashes": all(bool(c.get("content_sha256")) for c in cases), "complete_worlds": len(cases) == 22},
        "endpoint_counts": dict(Counter(c["endpoint"]["label"] for c in cases)),
        "Gamma_sign_accuracy": gamma_correct / len(cases),
        "active_interface_accuracy": interface_correct / len(cases),
        "monotonic_endpoint_violations": monotonic_violations,
        "tracks": by_track,
        "interpretation_rule": "Discovery only. A common transition bracket across all four tracks can motivate a new holdout; heterogeneous brackets imply contextual activity. NSH07 remains unchanged.",
    }


def static_audit() -> dict:
    observed = {"wheel": sha256_file(nsh05.nsh02.base.WHEEL_FILE), "package": sha256_file(nsh05.nsh02.base.PACKAGE_FILE), "kernel": sha256_file(nsh05.nsh02.base.KERNEL_FILE)}
    planned = specs()
    checks = {
        "kernel_identity_exact": observed == EXPECTED,
        "N_exact": N_VALUES == (28, 36),
        "fractions_exact": FRACTIONS == (0.0, 0.125, 0.25, 0.5, 0.75, 1.0),
        "orientations_exact": ORIENTATIONS == ("inward", "outward"),
        "cases_exact": len(planned) == 22,
        "seed_namespace_literal": "DEE-v27|C04|NSD14|activity-dose|v1" in HERE.read_text(encoding="utf-8"),
        "case_ids_unique": len(planned) == len({case_id(x) for x in planned}),
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "observed_hashes": observed, "runner_sha256": sha256_file(HERE), "planned_cases": len(planned), "planned_ticks": sum(x["horizon"] for x in planned)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True)); return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(audit)
    if OUT.exists():
        raise RuntimeError("NSD14 already complete; refusing repeat")
    kernel, environment = verify_and_load_kernel(1)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []
    planned = specs()
    started = time.perf_counter()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_case(kernel, spec)
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {"status": "RUNNING" if index < len(planned) else "CASES_COMPLETE", "completed": index, "total": len(planned), "last": case["case_id"], "resumed": resumed, "timestamp_utc": datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed": index, "total": len(planned), "case_id": case["case_id"], "Gamma": case["observation"]["Gamma"], "bar_activity": case["observation"]["bar_activity"], "endpoint": case["endpoint"]["label"], "resumed": resumed}), flush=True)
    summary = summarize(cases)
    result = {
        "schema": "dee.v27.c04.nsd14.activity_dose.v1",
        "experiment_id": "NSD14",
        "role": "DISCOVERY",
        "environment": environment,
        "static_audit": audit,
        "elapsed_seconds": time.perf_counter() - started,
        "summary": summary,
        "case_manifest": [{"case_id": c["case_id"], "file_sha256": sha256_file(CASE_DIR / f"{c['case_id']}.json"), "content_sha256": c["content_sha256"]} for c in cases],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {"status": "COMPLETE", "completed": len(cases), "total": len(cases), "result_sha256": sha256_file(OUT), "timestamp_utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status": "COMPLETE", "summary": summary, "result_sha256": sha256_file(OUT), "elapsed_seconds": result["elapsed_seconds"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
