#!/usr/bin/env python3
"""NSD15 discovery: resolve the 0-to-16 routed-record transition bracket.

The already computed count-0 and count-16 worlds are verified and reused from
NSD14.  Only counts 1, 2, 4 and 8 are newly executed.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsd14_activity_dose_response as base
from native_core import atomic_json, canonical_hash, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
OUT = ROOT / "RESULTS" / "NSD15_results.json"
CASE_DIR = ROOT / "RESULTS" / "NSD15_CASES"
PROGRESS = ROOT / "RESULTS" / "NSD15_progress.json"
N_VALUES = (28, 36)
NEW_COUNTS = (1, 2, 4, 8)
ALL_COUNTS = (0, 1, 2, 4, 8, 16)
ORIENTATIONS = ("inward", "outward")
ELIGIBLE = 124


def specs() -> list[dict]:
    return [
        {"N": n, "assigned_count": count, "assigned_fraction": count / ELIGIBLE, "orientation": orientation, "horizon": 6 * n}
        for n in N_VALUES for count in NEW_COUNTS for orientation in ORIENTATIONS
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_c{spec['assigned_count']}_{spec['orientation']}"


def run_new_case(kernel, spec: dict) -> dict:
    base_spec = {"N": int(spec["N"]), "assigned_fraction": float(spec["assigned_fraction"]), "orientation": spec["orientation"], "horizon": int(spec["horizon"])}
    result = base.run_case(kernel, base_spec)
    result.pop("content_sha256", None)
    result["schema"] = "dee.v27.c04.nsd15.case.v1"
    result["experiment_id"] = "NSD15"
    result["case_id"] = case_id(spec)
    result["spec"] = spec
    if int(result["construction"]["selected_sites"]) != int(spec["assigned_count"]):
        raise AssertionError("assigned-count construction mismatch")
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_new_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec):
        raise RuntimeError(f"foreign case {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case hash mismatch {path}")
    value["content_sha256"] = claimed
    return value


def load_reference(n: int, count: int, orientation: str) -> dict:
    if count == 0:
        path = ROOT / "RESULTS" / "NSD14_CASES" / f"N{n}_f0p0_stationary.json"
    elif count == 16:
        path = ROOT / "RESULTS" / "NSD14_CASES" / f"N{n}_f0p125_{orientation}.json"
    else:
        raise ValueError(count)
    value = json.loads(path.read_text(encoding="utf-8"))
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"reference content mismatch {path}")
    value["content_sha256"] = claimed
    if count == 0 and int(value["construction"]["selected_sites"]) != 0:
        raise AssertionError("bad zero reference")
    if count == 16 and int(value["construction"]["selected_sites"]) != 16:
        raise AssertionError("bad count-16 reference")
    return {"case": value, "path": path, "count": count, "orientation": orientation, "reused": True}


def normalize(item: dict) -> dict:
    c = item["case"]
    return {
        "N": int(c["spec"]["N"]),
        "count": int(item["count"]),
        "orientation": item["orientation"],
        "initial_activity": float(c["construction"]["realized_initial_activity"]),
        "Gamma": float(c["observation"]["Gamma"]),
        "bar_activity": float(c["observation"]["bar_activity"]),
        "bar_kappa": float(c["observation"]["bar_kappa"]),
        "dense": bool(c["endpoint"]["dense"]),
        "reused": bool(item["reused"]),
        "source_file_sha256": sha256_file(item["path"]),
        "source_content_sha256": c["content_sha256"],
    }


def summarize(rows: list[dict]) -> dict:
    tracks = {}
    for n in N_VALUES:
        for orientation in ORIENTATIONS:
            group = sorted([x for x in rows if x["N"] == n and x["orientation"] == orientation], key=lambda x: x["count"])
            first_dense = next((x["count"] for x in group if x["dense"]), None)
            first_gamma = next((x["count"] for x in group if x["Gamma"] > 0), None)
            endpoint_monotone = all(int(b["dense"]) >= int(a["dense"]) for a, b in zip(group[:-1], group[1:]))
            tracks[f"N{n}_{orientation}"] = {"rows": group, "first_dense_count": first_dense, "first_positive_Gamma_count": first_gamma, "endpoint_monotone": endpoint_monotone}
    thresholds = [v["first_dense_count"] for v in tracks.values()]
    gamma_consistency = sum((x["Gamma"] > 0) == x["dense"] for x in rows) / len(rows)
    common = len(set(thresholds)) == 1
    return {
        "tracks": tracks,
        "first_dense_counts": thresholds,
        "common_threshold_in_panel": thresholds[0] if common else None,
        "all_tracks_endpoint_monotone": all(v["endpoint_monotone"] for v in tracks.values()),
        "Gamma_sign_accuracy": gamma_consistency,
        "new_worlds": sum(not x["reused"] for x in rows),
        "reused_world_references": sum(x["reused"] for x in rows),
        "interpretation_rule": "Discovery only. A common small integer threshold motivates an untouched-N/position holdout; otherwise classify routed activity as contextual. No NSH07 criterion is changed.",
    }


def static_audit() -> dict:
    planned = specs()
    base_audit = base.static_audit()
    checks = {
        "base_kernel_audit_pass": base_audit["status"] == "PASS",
        "N_exact": N_VALUES == (28, 36),
        "new_counts_exact": NEW_COUNTS == (1, 2, 4, 8),
        "all_counts_exact": ALL_COUNTS == (0, 1, 2, 4, 8, 16),
        "eligible_exact": ELIGIBLE == 124 and all(base.side_for(n) == 5 for n in N_VALUES),
        "planned_new_worlds": len(planned) == 16,
        "all_six_references_exist": all((ROOT / "RESULTS" / "NSD14_CASES" / (f"N{n}_f0p0_stationary.json" if count == 0 else f"N{n}_f0p125_{orientation}.json")).is_file() for n in N_VALUES for count in (0, 16) for orientation in ORIENTATIONS),
        "case_ids_unique": len(planned) == len({case_id(x) for x in planned}),
    }
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "runner_sha256": sha256_file(HERE), "base_runner_sha256": sha256_file(Path(base.__file__)), "planned_new_worlds": len(planned), "planned_new_ticks": sum(x["horizon"] for x in planned)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True)); return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(audit)
    if OUT.exists():
        raise RuntimeError("NSD15 already complete; refusing repeat")
    kernel, environment = verify_and_load_kernel(1)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    items = []
    planned = specs()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_new_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_new_case(kernel, spec)
            atomic_json(path, case)
        items.append({"case": case, "path": path, "count": int(spec["assigned_count"]), "orientation": spec["orientation"], "reused": False})
        atomic_json(PROGRESS, {"status": "RUNNING" if index < len(planned) else "NEW_CASES_COMPLETE", "completed": index, "total": len(planned), "last": case["case_id"], "resumed": resumed, "timestamp_utc": datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed": index, "total": len(planned), "case_id": case["case_id"], "Gamma": case["observation"]["Gamma"], "endpoint": case["endpoint"]["label"], "resumed": resumed}), flush=True)
    for n in N_VALUES:
        for orientation in ORIENTATIONS:
            items.append(load_reference(n, 0, orientation))
            items.append(load_reference(n, 16, orientation))
    rows = [normalize(x) for x in items]
    summary = summarize(rows)
    result = {"schema": "dee.v27.c04.nsd15.sparse_activity.v1", "experiment_id": "NSD15", "role": "DISCOVERY", "environment": environment, "static_audit": audit, "elapsed_seconds": time.perf_counter() - started, "summary": summary, "rows": sorted(rows, key=lambda x: (x["N"], x["orientation"], x["count"]))}
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {"status": "COMPLETE", "completed_new": len(planned), "result_sha256": sha256_file(OUT), "timestamp_utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status": "COMPLETE", "summary": summary, "result_sha256": sha256_file(OUT), "elapsed_seconds": result["elapsed_seconds"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
