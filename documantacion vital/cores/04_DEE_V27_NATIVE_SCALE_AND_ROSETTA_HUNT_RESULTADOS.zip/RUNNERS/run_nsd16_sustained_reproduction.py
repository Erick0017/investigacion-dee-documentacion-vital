#!/usr/bin/env python3
"""NSD16 discovery of sustained reproduction across successive scale windows."""

from __future__ import annotations

import argparse
import json
import math
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsd14_activity_dose_response as base
from native_core import NativeWorld, atomic_json, canonical_hash, sha256_array, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
OUT = ROOT / "RESULTS" / "NSD16_results.json"
CASE_DIR = ROOT / "RESULTS" / "NSD16_CASES"
PROGRESS = ROOT / "RESULTS" / "NSD16_progress.json"
NSD15 = ROOT / "RESULTS" / "NSD15_results.json"
N_VALUES = (28, 36)
COUNTS = (0, 1, 2, 4, 8, 16)
ORIENTATIONS = ("inward", "outward")
ELIGIBLE = 124


def specs() -> list[dict]:
    result = []
    for n in N_VALUES:
        result.append({"N": n, "assigned_count": 0, "assigned_fraction": 0.0, "orientation": "stationary", "horizon": n})
        result.extend({"N": n, "assigned_count": count, "assigned_fraction": count / ELIGIBLE, "orientation": orientation, "horizon": n} for count in COUNTS[1:] for orientation in ORIENTATIONS)
    return result


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_c{spec['assigned_count']}_{spec['orientation']}"


def endpoint_label_map() -> dict[tuple[int, int, str], bool]:
    value = json.loads(NSD15.read_text(encoding="utf-8"))
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError("NSD15 content hash mismatch")
    result = {}
    for row in value["rows"]:
        key = (int(row["N"]), int(row["count"]), str(row["orientation"]))
        result[key] = bool(row["dense"])
    return result


def run_case(kernel, spec: dict, endpoints: dict) -> dict:
    n, count = int(spec["N"]), int(spec["assigned_count"])
    orientation = str(spec["orientation"])
    raw, clock, construction = base.construct({"N": n, "assigned_fraction": float(spec["assigned_fraction"]), "orientation": orientation, "horizon": 6 * n})
    if int(construction["selected_sites"]) != count:
        raise AssertionError("selected count mismatch")
    world = NativeWorld(kernel, raw, clock, 1)
    boundaries = (n // 4, n // 2, 3 * n // 4, n)
    points = []
    overflows = 0
    for tick in range(n + 1):
        if tick in boundaries:
            state = base.nsh05.nsh02.base.metrics(world.raw, include_hash=True)
            points.append({"tick": tick, "positive": int(state["positive"]), "kappa": float(state["kappa"]), "activity": float(state["routed_positive"] / state["positive"]), "raw_sha256": state["raw_sha256"]})
        if tick < n:
            overflows += int(world.tick()["overflows"])
    gammas = [math.log(right["positive"] / left["positive"]) for left, right in zip(points[:-1], points[1:])]
    label_key = (n, count, orientation if count else "inward")
    dense = endpoints[label_key]
    result = {
        "schema": "dee.v27.c04.nsd16.case.v1",
        "experiment_id": "NSD16",
        "role": "DISCOVERY_SCIENTIFIC_REEXECUTION_FOR_NEW_OBSERVABLE",
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "scale_points": points,
        "Gamma_windows": gammas,
        "Gamma_total": math.log(points[-1]["positive"] / points[0]["positive"]),
        "known_6N_endpoint_dense": dense,
        "diagnostics": {"overflows_through_N": overflows, "scale_points_sha256": sha256_array(np.asarray([[x["positive"], x["kappa"], x["activity"]] for x in points], dtype="<f8"))},
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec):
        raise RuntimeError(f"foreign case {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case hash mismatch {path}")
    value["content_sha256"] = claimed
    return value


def class_metrics(cases: list[dict], predicate) -> dict:
    truth = np.asarray([c["known_6N_endpoint_dense"] for c in cases], dtype=bool)
    pred = np.asarray([predicate(c) for c in cases], dtype=bool)
    tp, tn = int(np.count_nonzero(truth & pred)), int(np.count_nonzero(~truth & ~pred))
    fp, fn = int(np.count_nonzero(~truth & pred)), int(np.count_nonzero(truth & ~pred))
    sens = tp / (tp + fn) if tp + fn else None
    spec = tn / (tn + fp) if tn + fp else None
    return {"tp": tp, "tn": tn, "fp": fp, "fn": fn, "errors": fp + fn, "sensitivity": sens, "specificity": spec, "balanced_accuracy": None if sens is None or spec is None else (sens + spec) / 2}


def summarize(cases: list[dict]) -> dict:
    rules = {
        "Gamma1_positive": lambda c: c["Gamma_windows"][0] > 0,
        "Gamma2_positive": lambda c: c["Gamma_windows"][1] > 0,
        "Gamma3_positive": lambda c: c["Gamma_windows"][2] > 0,
        "all_three_positive": lambda c: all(g > 0 for g in c["Gamma_windows"]),
        "last_two_positive": lambda c: c["Gamma_windows"][1] > 0 and c["Gamma_windows"][2] > 0,
        "at_least_two_positive": lambda c: sum(g > 0 for g in c["Gamma_windows"]) >= 2,
        "total_positive": lambda c: c["Gamma_total"] > 0,
    }
    metrics = {name: class_metrics(cases, fn) for name, fn in rules.items()}
    best_ba = max(v["balanced_accuracy"] for v in metrics.values())
    best = [k for k, v in metrics.items() if v["balanced_accuracy"] == best_ba]
    matched = all(len({json.dumps(c["construction"]["matched_non_direction_hashes"], sort_keys=True) for c in cases if c["spec"]["N"] == n}) == 1 for n in N_VALUES)
    return {
        "audits": {"complete_worlds": len(cases) == 22, "matched_non_direction_fields_within_N": matched, "all_case_hashes": all(bool(c.get("content_sha256")) for c in cases)},
        "rule_metrics": metrics,
        "best_balanced_accuracy": best_ba,
        "best_zero_parameter_rules": best,
        "rows": [{"case_id": c["case_id"], "N": c["spec"]["N"], "count": c["spec"]["assigned_count"], "orientation": c["spec"]["orientation"], "Gamma_windows": c["Gamma_windows"], "Gamma_total": c["Gamma_total"], "dense": c["known_6N_endpoint_dense"]} for c in cases],
        "interpretation_rule": "Discovery only. Freeze at most one structurally simple zero-threshold persistence rule if it materially outperforms Gamma1 sign and has no obvious degenerate leakage; otherwise close the branch after three informative cycles.",
    }


def static_audit() -> dict:
    planned = specs()
    checks = {"kernel_base_audit": base.static_audit()["status"] == "PASS", "NSD15_exists": NSD15.is_file(), "N_exact": N_VALUES == (28, 36), "counts_exact": COUNTS == (0, 1, 2, 4, 8, 16), "worlds_exact": len(planned) == 22, "horizon_exact": all(x["horizon"] == x["N"] for x in planned), "case_ids_unique": len(planned) == len({case_id(x) for x in planned})}
    return {"status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "runner_sha256": sha256_file(HERE), "planned_worlds": len(planned), "planned_ticks": sum(x["horizon"] for x in planned)}


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--audit-only", action="store_true"); parser.add_argument("--threads", type=int, default=1); args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True)); return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(audit)
    if OUT.exists():
        raise RuntimeError("NSD16 already complete; refusing repeat")
    kernel, environment = verify_and_load_kernel(1)
    endpoints = endpoint_label_map(); CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []; planned = specs(); started = time.perf_counter()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"; case = verify_case(path, spec); resumed = case is not None
        if case is None:
            case = run_case(kernel, spec, endpoints); atomic_json(path, case)
        cases.append(case); atomic_json(PROGRESS, {"status": "RUNNING" if index < len(planned) else "CASES_COMPLETE", "completed": index, "total": len(planned), "last": case["case_id"], "resumed": resumed, "timestamp_utc": datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed": index, "total": len(planned), "case_id": case["case_id"], "Gamma_windows": case["Gamma_windows"], "dense": case["known_6N_endpoint_dense"], "resumed": resumed}), flush=True)
    summary = summarize(cases)
    result = {"schema": "dee.v27.c04.nsd16.sustained_reproduction.v1", "experiment_id": "NSD16", "role": "DISCOVERY", "environment": environment, "static_audit": audit, "elapsed_seconds": time.perf_counter() - started, "summary": summary, "case_manifest": [{"case_id": c["case_id"], "file_sha256": sha256_file(CASE_DIR / f"{c['case_id']}.json"), "content_sha256": c["content_sha256"]} for c in cases]}
    result["content_sha256"] = canonical_hash(result); atomic_json(OUT, result); atomic_json(PROGRESS, {"status": "COMPLETE", "completed": len(cases), "result_sha256": sha256_file(OUT), "timestamp_utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status": "COMPLETE", "summary": summary, "result_sha256": sha256_file(OUT), "elapsed_seconds": result["elapsed_seconds"]}, indent=2, sort_keys=True)); return 0


if __name__ == "__main__":
    raise SystemExit(main())
