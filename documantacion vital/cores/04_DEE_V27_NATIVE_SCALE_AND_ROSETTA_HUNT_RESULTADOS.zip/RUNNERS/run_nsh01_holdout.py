#!/usr/bin/env python3
"""NSH01 locked holdout for the early positive-interface candidate."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import (
    EXPECTED,
    KERNEL_FILE,
    PACKAGE_FILE,
    WHEEL_FILE,
    NativeWorld,
    atomic_json,
    canonical_hash,
    fields,
    pack,
    sha256_array,
    sha256_file,
    verify_and_load_kernel,
)


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "NSH01.json"
LOCK_SHA256 = "81d6efd8888a5fd3b15e0f78bb73c395f5067712d74e8dd121e9482d0f06f786"
OUT = WORK / "RESULTS" / "NSH01_results.json"
CASE_DIR = WORK / "RESULTS" / "NSH01_CASES"
PROGRESS = WORK / "RESULTS" / "NSH01_progress.json"
N_VALUES = (20, 26, 34, 38)
SCALINGS = ("linear", "area", "volume")
ARMS = ("organized_inward", "global_joint_inventory_shuffle")
REPLICATES = 3
HORIZON_MULTIPLIER = 6
KAPPA_THRESHOLD = 5.35
Q_THRESHOLD = 0.0044
CLOCK_BANK = np.array([0, 7, 17, 194, 195, 259, 260, 390, 391, 781, 782], dtype=np.uint64)


def deterministic_seed(n: int, scaling: str, replicate: int) -> int:
    phrase = f"DEE-v27|C04|NSH01|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


def counts_for(n: int, scaling: str) -> tuple[int, tuple[int, int, int]]:
    formulas = {
        "linear": round(5.3 * n),
        "area": round(0.15 * n * n),
        "volume": round(0.0042 * n * n * n),
    }
    total = max(7, formulas[scaling])
    inner = max(1, round(total / 7))
    middle = max(2, round(2 * total / 7))
    outer = total - inner - middle
    if outer < 4:
        shift = 4 - outer
        inner = max(1, inner - shift)
        outer = total - inner - middle
    return total, (inner, middle, outer)


def radii_for(n: int) -> tuple[int, int, int]:
    inner = max(2, round(0.10 * n))
    middle = max(inner + 2, round(0.24 * n))
    outer = max(middle + 2, round(0.37 * n))
    if outer >= n // 2:
        outer = n // 2 - 1
    return inner, middle, outer


def tor_delta(coords: np.ndarray, center: np.ndarray, n: int) -> np.ndarray:
    return ((coords - center + n // 2) % n) - n // 2


def radius_grid(n: int, center: np.ndarray) -> np.ndarray:
    axes = [((np.arange(n) - int(center[j]) + n // 2) % n) - n // 2 for j in range(3)]
    xx, yy, zz = np.meshgrid(*axes, indexing="ij")
    return np.maximum.reduce([np.abs(xx), np.abs(yy), np.abs(zz)]).astype(np.int16)


def construct(n: int, scaling: str, replicate: int) -> tuple[np.ndarray, np.ndarray, dict]:
    seed = deterministic_seed(n, scaling, replicate)
    rng = np.random.default_rng(seed)
    center = np.array([n // 2] * 3, dtype=np.int64)
    distances = radius_grid(n, center)
    total, counts = counts_for(n, scaling)
    radii = radii_for(n)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    layers = []
    for layer, (radius, count) in enumerate(zip(radii, counts)):
        candidates = np.argwhere((distances <= radius) & (distances >= max(1, radius - 1)))
        if count > len(candidates):
            raise RuntimeError("declared shell count exceeds capacity")
        coords = candidates[rng.permutation(len(candidates))[:count]]
        for index, q in enumerate(coords):
            delta = tor_delta(q[None, :], center, n)[0]
            direction = tuple(int(-np.sign(component)) for component in delta)
            site = tuple(int(x) for x in q)
            raw[site] = pack(1, int(rng.integers(1, 65)), direction, 1)
            clock[site] = CLOCK_BANK[(index + 3 * layer + seed) % len(CLOCK_BANK)]
        layers.append({"radius": radius, "count": count, "capacity": int(len(candidates))})
    if int(np.count_nonzero(raw)) != total:
        raise AssertionError("record-count mismatch")
    return raw, clock, {
        "seed": seed,
        "total_records": total,
        "counts": list(counts),
        "radii": list(radii),
        "layers": layers,
    }


def joint_multiset_hash(raw: np.ndarray, clock: np.ndarray) -> str:
    g = raw.reshape(-1).astype("<u8", copy=False)
    c = clock.reshape(-1).astype("<u8", copy=False)
    pairs = np.rec.fromarrays([g, c], names="g,c")
    order = np.argsort(pairs, order=("g", "c"))
    return sha256_array(np.column_stack([g[order], c[order]]).astype("<u8", copy=False))


def apply_arm(raw: np.ndarray, clock: np.ndarray, arm: str, seed: int) -> tuple[np.ndarray, np.ndarray, dict]:
    result_raw = raw.copy()
    result_clock = clock.copy()
    before = joint_multiset_hash(result_raw, result_clock)
    if arm == "global_joint_inventory_shuffle":
        rng = np.random.default_rng(seed ^ 0x5CA1E04)
        permutation = rng.permutation(result_raw.size)
        result_raw = result_raw.reshape(-1)[permutation].reshape(raw.shape).copy()
        result_clock = result_clock.reshape(-1)[permutation].reshape(clock.shape).copy()
    elif arm != "organized_inward":
        raise ValueError(arm)
    after = joint_multiset_hash(result_raw, result_clock)
    return result_raw, result_clock, {
        "before": before,
        "after": after,
        "exact": before == after,
        "sitewise_changed": bool(np.any(result_raw != raw) or np.any(result_clock != clock)),
    }


def boundary_faces(positive: np.ndarray) -> int:
    return int(sum(np.count_nonzero(positive != np.roll(positive, 1, axis=axis)) for axis in range(3)))


def metrics(raw: np.ndarray, include_hash: bool = False) -> dict:
    decoded = fields(raw)
    positive = decoded["state"] != 0
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    p = int(np.count_nonzero(positive))
    b6 = boundary_faces(positive)
    result = {
        "positive": p,
        "positive_fraction": p / raw.size,
        "B6": b6,
        "kappa": b6 / p if p else None,
        "mean_positive_face_degree": 6.0 - b6 / p if p else None,
        "routed_positive": int(np.count_nonzero(positive & routed)),
        "stationary_positive": int(np.count_nonzero(positive & ~routed)),
        "bare_routers": int(np.count_nonzero(~positive & routed)),
        "semantic7": int(np.count_nonzero(decoded["semantic"] == 7)),
    }
    if include_hash:
        result["raw_sha256"] = sha256_array(raw)
    return result


def specs() -> list[dict]:
    return [
        {"N": n, "scaling": scaling, "replicate": replicate, "arm": arm, "horizon": HORIZON_MULTIPLIER * n}
        for n in N_VALUES
        for scaling in SCALINGS
        for replicate in range(REPLICATES)
        for arm in ARMS
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}_{spec['arm']}"


def run_case(kernel, threads: int, spec: dict) -> dict:
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    observation_tick = n // 4
    raw, clock, construction = construct(n, spec["scaling"], int(spec["replicate"]))
    raw, clock, inventory_audit = apply_arm(raw, clock, spec["arm"], int(construction["seed"]))
    if not inventory_audit["exact"]:
        raise AssertionError("holdout control changed joint inventory")
    world = NativeWorld(kernel, raw, clock, threads)
    trace = []
    observation = None
    tail_raw_change_sum = 0
    for tick in range(horizon + 1):
        current = metrics(world.raw, include_hash=tick in (0, observation_tick, horizon))
        row = {"tick": tick, "state": current}
        if tick == observation_tick:
            observation = dict(current)
            observation["kappa_prediction_dense"] = current["kappa"] <= KAPPA_THRESHOLD
            observation["q_prediction_dense"] = current["positive_fraction"] >= Q_THRESHOLD
            observation["arm_prediction_dense"] = spec["arm"] == "organized_inward"
        if tick < horizon:
            raw_before = world.raw.copy()
            info = world.tick()
            raw_change = int(np.count_nonzero(raw_before != world.raw))
            if tick >= horizon - n:
                tail_raw_change_sum += raw_change
            row["kernel"] = info
            row["raw_changed_sites_to_next"] = raw_change
        trace.append(row)
    if observation is None:
        raise AssertionError("observation was not captured")
    endpoint = trace[-1]["state"]
    dense = endpoint["positive_fraction"] >= 0.9 and tail_raw_change_sum == 0
    result = {
        "schema": "dee.v27.c04.nsh01.case.v1",
        "experiment_id": "NSH01",
        "role": "LOCKED_HOLDOUT",
        "lock_sha256": LOCK_SHA256,
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "inventory_audit": inventory_audit,
        "observation": observation,
        "endpoint": {
            "positive_fraction_6N": endpoint["positive_fraction"],
            "tail_raw_changed_sites_sum": tail_raw_change_sum,
            "dense": dense,
            "label": "DENSE" if dense else "NONDENSE",
        },
        "predictions": {
            "kappa": bool(observation["kappa_prediction_dense"]),
            "q": bool(observation["q_prediction_dense"]),
            "arm": bool(observation["arm_prediction_dense"]),
        },
        "trace": trace,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    with path.open("r", encoding="utf-8") as stream:
        result = json.load(stream)
    if result.get("case_id") != case_id(spec) or result.get("lock_sha256") != LOCK_SHA256:
        raise RuntimeError(f"foreign or stale holdout case: {path}")
    claimed = result.pop("content_sha256", None)
    if canonical_hash(result) != claimed:
        raise RuntimeError(f"holdout case content hash mismatch: {path}")
    result["content_sha256"] = claimed
    return result


def classification_metrics(cases: list[dict], model: str) -> dict:
    truth = np.array([case["endpoint"]["dense"] for case in cases], dtype=bool)
    pred = np.array([case["predictions"][model] for case in cases], dtype=bool)
    tp = int(np.count_nonzero(truth & pred))
    tn = int(np.count_nonzero(~truth & ~pred))
    fp = int(np.count_nonzero(~truth & pred))
    fn = int(np.count_nonzero(truth & ~pred))
    sensitivity = tp / (tp + fn) if tp + fn else None
    specificity = tn / (tn + fp) if tn + fp else None
    balanced = (sensitivity + specificity) / 2 if sensitivity is not None and specificity is not None else None
    return {
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "errors": fp + fn,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "balanced_accuracy": balanced,
    }


def adjudicate(cases: list[dict]) -> dict:
    dense = [case for case in cases if case["endpoint"]["dense"]]
    nondense = [case for case in cases if not case["endpoint"]["dense"]]
    diversity = {
        "dense_worlds": len(dense),
        "nondense_worlds": len(nondense),
        "dense_N_values": sorted({case["spec"]["N"] for case in dense}),
        "nondense_N_values": sorted({case["spec"]["N"] for case in nondense}),
    }
    diversity["pass"] = (
        diversity["dense_worlds"] >= 9
        and diversity["nondense_worlds"] >= 9
        and len(diversity["dense_N_values"]) >= 2
        and len(diversity["nondense_N_values"]) >= 2
    )
    models = {name: classification_metrics(cases, name) for name in ("kappa", "q", "arm")}
    if not diversity["pass"]:
        verdict = "INCONCLUSIVE"
        conditions = {"class_diversity": False}
    else:
        kappa = models["kappa"]
        conditions = {
            "class_diversity": True,
            "sensitivity_ge_0_85": kappa["sensitivity"] >= 0.85,
            "specificity_ge_0_85": kappa["specificity"] >= 0.85,
            "balanced_accuracy_ge_0_90": kappa["balanced_accuracy"] >= 0.90,
            "increment_over_q_ge_0_10": kappa["balanced_accuracy"] - models["q"]["balanced_accuracy"] >= 0.10,
            "increment_over_arm_ge_0_05": kappa["balanced_accuracy"] - models["arm"]["balanced_accuracy"] >= 0.05,
        }
        verdict = "PASS" if all(conditions.values()) else "FAIL"
    return {
        "verdict": verdict,
        "class_diversity": diversity,
        "models": models,
        "conditions": conditions,
        "no_refit": True,
    }


def static_audit() -> dict:
    planned = specs()
    observed_hashes = {
        "wheel": sha256_file(WHEEL_FILE),
        "package": sha256_file(PACKAGE_FILE),
        "kernel": sha256_file(KERNEL_FILE),
    }
    checks = {
        "lock_exists": LOCK.is_file(),
        "lock_hash_exact": LOCK.is_file() and sha256_file(LOCK) == LOCK_SHA256,
        "kernel_identity_exact": observed_hashes == EXPECTED,
        "N_exact": N_VALUES == (20, 26, 34, 38),
        "replicates_exact": REPLICATES == 3,
        "arms_exact": ARMS == ("organized_inward", "global_joint_inventory_shuffle"),
        "kappa_threshold_exact": KAPPA_THRESHOLD == 5.35,
        "q_threshold_exact": Q_THRESHOLD == 0.0044,
        "horizon_exact": HORIZON_MULTIPLIER == 6,
        "case_ids_unique": len(planned) == len({case_id(spec) for spec in planned}),
    }
    return {
        "schema": "dee.v27.c04.nsh01.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "lock_sha256": LOCK_SHA256,
        "observed_hashes": observed_hashes,
        "runner_sha256": sha256_file(HERE),
        "planned_cases": len(planned),
        "planned_universe_ticks": sum(spec["horizon"] for spec in planned),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS":
        raise RuntimeError(f"static audit failed: {audit}")
    if args.threads != 1:
        raise RuntimeError("the lock fixes one kernel thread")
    if OUT.exists():
        raise RuntimeError(f"holdout already completed; refusing to repeat: {OUT}")
    started = time.perf_counter()
    started_utc = datetime.now(timezone.utc).isoformat()
    kernel, environment = verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    completed = []
    planned = specs()
    for index, spec in enumerate(planned, start=1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_case(kernel, args.threads, spec)
            atomic_json(path, case)
        completed.append(case)
        atomic_json(PROGRESS, {
            "schema": "dee.v27.c04.nsh01.progress.v1",
            "status": "RUNNING" if index < len(planned) else "CASES_COMPLETE",
            "lock_sha256": LOCK_SHA256,
            "completed_cases": index,
            "total_cases": len(planned),
            "last_case_id": case["case_id"],
            "last_case_resumed": resumed,
            "next_case_id": case_id(planned[index]) if index < len(planned) else None,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        print(json.dumps({
            "completed": index,
            "total": len(planned),
            "case_id": case["case_id"],
            "kappa": case["observation"]["kappa"],
            "prediction": case["predictions"]["kappa"],
            "outcome": case["endpoint"]["label"],
            "resumed": resumed,
        }), flush=True)
    adjudication = adjudicate(completed)
    result = {
        "schema": "dee.v27.c04.nsh01.holdout.v1",
        "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "experiment_id": "NSH01",
        "role": "LOCKED_HOLDOUT",
        "lock_path": str(LOCK.relative_to(WORK)).replace("\\", "/"),
        "lock_sha256": LOCK_SHA256,
        "started_utc": started_utc,
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter() - started,
        "runner_sha256": sha256_file(HERE),
        "static_audit": audit,
        "environment": environment,
        "adjudication": adjudication,
        "outcomes": dict(Counter(case["endpoint"]["label"] for case in completed)),
        "case_manifest": [
            {
                "case_id": case["case_id"],
                "path": str((CASE_DIR / f"{case['case_id']}.json").relative_to(WORK)).replace("\\", "/"),
                "file_sha256": sha256_file(CASE_DIR / f"{case['case_id']}.json"),
                "content_sha256": case["content_sha256"],
                "kappa": case["observation"]["kappa"],
                "prediction": case["predictions"]["kappa"],
                "outcome": case["endpoint"]["label"],
            }
            for case in completed
        ],
    }
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {
        "schema": "dee.v27.c04.nsh01.progress.v1",
        "status": "COMPLETE",
        "lock_sha256": LOCK_SHA256,
        "completed_cases": len(completed),
        "total_cases": len(completed),
        "verdict": adjudication["verdict"],
        "result_sha256": sha256_file(OUT),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    })
    print(json.dumps({
        "status": "COMPLETE",
        "verdict": adjudication["verdict"],
        "adjudication": adjudication,
        "result": str(OUT),
        "result_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
