#!/usr/bin/env python3
"""NSH02 locked holdout for temporal coarse-grained support connectivity."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh01_holdout as base
from native_core import EXPECTED, NativeWorld, atomic_json, canonical_hash, sha256_array, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "NSH02.json"
LOCK_SHA256 = "e73395a67383510a7bb40d3bce1d89118a046f218d98cbead39c8a554a05de7c"
OUT = WORK / "RESULTS" / "NSH02_results.json"
CASE_DIR = WORK / "RESULTS" / "NSH02_CASES"
PROGRESS = WORK / "RESULTS" / "NSH02_progress.json"
N_VALUES = (22, 29, 37, 41)
SCALINGS = ("linear", "area", "volume")
ARMS = ("organized_inward", "global_joint_inventory_shuffle")
REPLICATES = 3
HORIZON_MULTIPLIER = 6
BAR_KAPPA_THRESHOLD = 5.60
BAR_Q_THRESHOLD = 0.0057


def deterministic_seed(n: int, scaling: str, replicate: int) -> int:
    phrase = f"DEE-v27|C04|NSH02|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


# Reuse the frozen preparation implementation while replacing only the lock-declared seed namespace.
base.deterministic_seed = deterministic_seed


def specs() -> list[dict]:
    return [
        {"N": n, "scaling": scaling, "replicate": replicate, "arm": arm, "horizon": HORIZON_MULTIPLIER * n}
        for n in N_VALUES
        for scaling in SCALINGS
        for replicate in range(REPLICATES)
        for arm in ARMS
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}_{spec['arm']}"


def run_case(kernel, threads: int, spec: dict) -> dict:
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    window_start, window_end = n // 4, n // 2
    raw, clock, construction = base.construct(n, spec["scaling"], int(spec["replicate"]))
    raw, clock, inventory_audit = base.apply_arm(raw, clock, spec["arm"], int(construction["seed"]))
    if not inventory_audit["exact"]:
        raise AssertionError("holdout arm changed joint raw+clock inventory")
    world = NativeWorld(kernel, raw, clock, threads)
    trace = []
    observed_kappa = []
    observed_q = []
    tail_raw_change_sum = 0
    for tick in range(horizon + 1):
        in_window = window_start <= tick <= window_end
        current = base.metrics(world.raw, include_hash=tick in (0, window_start, window_end, horizon))
        if in_window:
            observed_kappa.append(float(current["kappa"]))
            observed_q.append(float(current["positive_fraction"]))
        row = {"tick": tick, "state": current}
        if tick < horizon:
            raw_before = world.raw.copy()
            info = world.tick()
            changed = int(np.count_nonzero(raw_before != world.raw))
            if tick >= horizon - n:
                tail_raw_change_sum += changed
            row["kernel"] = info
            row["raw_changed_sites_to_next"] = changed
        trace.append(row)
    expected_window_samples = window_end - window_start + 1
    if len(observed_kappa) != expected_window_samples:
        raise AssertionError("temporal observation window mismatch")
    bar_kappa = float(np.mean(observed_kappa))
    bar_q = float(np.mean(observed_q))
    endpoint = trace[-1]["state"]
    dense = endpoint["positive_fraction"] >= 0.9 and tail_raw_change_sum == 0
    result = {
        "schema": "dee.v27.c04.nsh02.case.v1",
        "experiment_id": "NSH02",
        "role": "LOCKED_HOLDOUT",
        "lock_sha256": LOCK_SHA256,
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "inventory_audit": inventory_audit,
        "observation": {
            "window_start": window_start,
            "window_end": window_end,
            "samples": expected_window_samples,
            "bar_kappa": bar_kappa,
            "bar_q": bar_q,
            "kappa_min": min(observed_kappa),
            "kappa_max": max(observed_kappa),
            "window_values_sha256": sha256_array(np.column_stack([observed_kappa, observed_q]).astype("<f8")),
        },
        "endpoint": {
            "positive_fraction_6N": endpoint["positive_fraction"],
            "tail_raw_changed_sites_sum": tail_raw_change_sum,
            "dense": dense,
            "label": "DENSE" if dense else "NONDENSE",
        },
        "predictions": {
            "bar_kappa": bar_kappa <= BAR_KAPPA_THRESHOLD,
            "bar_q": bar_q >= BAR_Q_THRESHOLD,
            "arm": spec["arm"] == "organized_inward",
        },
        "trace": trace,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    with path.open("r", encoding="utf-8") as stream:
        value = json.load(stream)
    if value.get("case_id") != case_id(spec) or value.get("lock_sha256") != LOCK_SHA256:
        raise RuntimeError(f"foreign or stale case: {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case content mismatch: {path}")
    value["content_sha256"] = claimed
    return value


def classification_metrics(cases: list[dict], name: str) -> dict:
    truth = np.array([case["endpoint"]["dense"] for case in cases], dtype=bool)
    prediction = np.array([case["predictions"][name] for case in cases], dtype=bool)
    tp = int(np.count_nonzero(truth & prediction))
    tn = int(np.count_nonzero(~truth & ~prediction))
    fp = int(np.count_nonzero(~truth & prediction))
    fn = int(np.count_nonzero(truth & ~prediction))
    sensitivity = tp / (tp + fn) if tp + fn else None
    specificity = tn / (tn + fp) if tn + fp else None
    return {
        "tp": tp, "tn": tn, "fp": fp, "fn": fn, "errors": fp + fn,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "balanced_accuracy": (sensitivity + specificity) / 2 if sensitivity is not None and specificity is not None else None,
    }


def adjudicate(cases: list[dict]) -> dict:
    dense = [case for case in cases if case["endpoint"]["dense"]]
    nondense = [case for case in cases if not case["endpoint"]["dense"]]
    diversity = {
        "dense_worlds": len(dense),
        "nondense_worlds": len(nondense),
        "dense_N_values": sorted({case["spec"]["N"] for case in dense}),
        "nondense_N_values": sorted({case["spec"]["N"] for case in nondense}),
    }
    diversity["pass"] = len(dense) >= 9 and len(nondense) >= 9 and len(diversity["dense_N_values"]) >= 2 and len(diversity["nondense_N_values"]) >= 2
    models = {name: classification_metrics(cases, name) for name in ("bar_kappa", "bar_q", "arm")}
    if not diversity["pass"]:
        conditions = {"class_diversity": False}
        verdict = "INCONCLUSIVE"
    else:
        primary = models["bar_kappa"]
        conditions = {
            "class_diversity": True,
            "sensitivity_ge_0_85": primary["sensitivity"] >= 0.85,
            "specificity_ge_0_85": primary["specificity"] >= 0.85,
            "balanced_accuracy_ge_0_90": primary["balanced_accuracy"] >= 0.90,
            "increment_over_bar_q_ge_0_10": primary["balanced_accuracy"] - models["bar_q"]["balanced_accuracy"] >= 0.10,
            "increment_over_arm_ge_0_05": primary["balanced_accuracy"] - models["arm"]["balanced_accuracy"] >= 0.05,
        }
        verdict = "PASS" if all(conditions.values()) else "FAIL"
    return {"verdict": verdict, "class_diversity": diversity, "models": models, "conditions": conditions, "no_refit": True}


def static_audit() -> dict:
    planned = specs()
    observed = {"wheel": sha256_file(base.WHEEL_FILE), "package": sha256_file(base.PACKAGE_FILE), "kernel": sha256_file(base.KERNEL_FILE)}
    checks = {
        "lock_hash_exact": LOCK.is_file() and sha256_file(LOCK) == LOCK_SHA256,
        "kernel_identity_exact": observed == EXPECTED,
        "N_exact": N_VALUES == (22, 29, 37, 41),
        "replicates_exact": REPLICATES == 3,
        "arms_exact": ARMS == ("organized_inward", "global_joint_inventory_shuffle"),
        "bar_kappa_threshold_exact": BAR_KAPPA_THRESHOLD == 5.60,
        "bar_q_threshold_exact": BAR_Q_THRESHOLD == 0.0057,
        "horizon_exact": HORIZON_MULTIPLIER == 6,
        "seed_namespace_literal": "DEE-v27|C04|NSH02|v1" in HERE.read_text(encoding="utf-8"),
        "case_ids_unique": len(planned) == len({case_id(spec) for spec in planned}),
    }
    return {
        "schema": "dee.v27.c04.nsh02.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "observed_hashes": observed,
        "lock_sha256": LOCK_SHA256,
        "runner_sha256": sha256_file(HERE),
        "preparation_implementation_sha256": sha256_file(Path(base.__file__)),
        "planned_cases": len(planned),
        "planned_universe_ticks": sum(spec["horizon"] for spec in planned),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(f"locked static audit failed: {audit}")
    if OUT.exists():
        raise RuntimeError(f"holdout already completed; refusing to repeat: {OUT}")
    started = time.perf_counter()
    started_utc = datetime.now(timezone.utc).isoformat()
    kernel, environment = verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []
    planned = specs()
    for index, spec in enumerate(planned, start=1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_case(kernel, args.threads, spec)
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {
            "schema": "dee.v27.c04.nsh02.progress.v1",
            "status": "RUNNING" if index < len(planned) else "CASES_COMPLETE",
            "lock_sha256": LOCK_SHA256,
            "completed_cases": index,
            "total_cases": len(planned),
            "last_case_id": case["case_id"],
            "last_case_resumed": resumed,
            "next_case_id": case_id(planned[index]) if index < len(planned) else None,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        print(json.dumps({
            "completed": index, "total": len(planned), "case_id": case["case_id"],
            "bar_kappa": case["observation"]["bar_kappa"], "prediction": case["predictions"]["bar_kappa"],
            "outcome": case["endpoint"]["label"], "resumed": resumed,
        }), flush=True)
    adjudication = adjudicate(cases)
    result = {
        "schema": "dee.v27.c04.nsh02.holdout.v1",
        "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "experiment_id": "NSH02", "role": "LOCKED_HOLDOUT",
        "lock_path": str(LOCK.relative_to(WORK)).replace("\\", "/"), "lock_sha256": LOCK_SHA256,
        "started_utc": started_utc, "completed_utc": datetime.now(timezone.utc).isoformat(),
        "elapsed_seconds": time.perf_counter() - started, "runner_sha256": sha256_file(HERE),
        "static_audit": audit, "environment": environment, "adjudication": adjudication,
        "outcomes": dict(Counter(case["endpoint"]["label"] for case in cases)),
        "case_manifest": [
            {
                "case_id": case["case_id"],
                "path": str((CASE_DIR / f"{case['case_id']}.json").relative_to(WORK)).replace("\\", "/"),
                "file_sha256": sha256_file(CASE_DIR / f"{case['case_id']}.json"),
                "content_sha256": case["content_sha256"],
                "bar_kappa": case["observation"]["bar_kappa"],
                "bar_q": case["observation"]["bar_q"],
                "prediction": case["predictions"]["bar_kappa"], "outcome": case["endpoint"]["label"],
            } for case in cases
        ],
    }
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {
        "schema": "dee.v27.c04.nsh02.progress.v1", "status": "COMPLETE", "lock_sha256": LOCK_SHA256,
        "completed_cases": len(cases), "total_cases": len(cases), "verdict": adjudication["verdict"],
        "result_sha256": sha256_file(OUT), "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    })
    print(json.dumps({
        "status": "COMPLETE", "verdict": adjudication["verdict"], "adjudication": adjudication,
        "result": str(OUT), "result_sha256": sha256_file(OUT), "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
