#!/usr/bin/env python3
"""NSH03 locked response holdout for the basin-depth candidate."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsd03_support_operator_intervention as discovery
from native_core import EXPECTED, NativeWorld, atomic_json, canonical_hash, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "NSH03.json"
LOCK_SHA256 = "50fead5579fee9ca15acfde8eab1744ad8cca6a9503f6a945f3238de03cc721b"
OUT = WORK / "RESULTS" / "NSH03_results.json"
CASE_DIR = WORK / "RESULTS" / "NSH03_CASES"
PROGRESS = WORK / "RESULTS" / "NSH03_progress.json"
N_VALUES = (33, 40, 47)
SCALINGS = ("linear", "area", "volume")
REPLICATES = 4
HORIZON_MULTIPLIER = 6
BAR_KAPPA_THRESHOLD = 3.60
BAR_Q_THRESHOLD = 0.0290
SIZE_THRESHOLD = 37


def seed_for(n: int, scaling: str, replicate: int) -> int:
    payload = f"DEE-v27|C04|NSH03|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8], "little")


discovery.prep.deterministic_seed = seed_for


def specs() -> list[dict]:
    return [
        {"N":n,"scaling":scaling,"replicate":replicate,"split_tick":n//2,"horizon":HORIZON_MULTIPLIER*n}
        for n in N_VALUES for scaling in SCALINGS for replicate in range(REPLICATES)
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}"


def continue_world(kernel, threads: int, raw: np.ndarray, clock: np.ndarray, start: int, horizon: int, n: int) -> dict:
    world = NativeWorld(kernel, raw, clock, threads)
    trace = []
    tail_changes = 0
    for tick in range(start, horizon + 1):
        current = discovery.macro_metrics(world.raw, include_hash=tick in (start, horizon))
        row = {"tick":tick,"state":current}
        if tick < horizon:
            before = world.raw.copy()
            info = world.tick()
            changed = int(np.count_nonzero(before != world.raw))
            if tick >= horizon - n:
                tail_changes += changed
            row["kernel"] = info
            row["raw_changed_sites_to_next"] = changed
        trace.append(row)
    endpoint = trace[-1]["state"]
    dense = endpoint["positive_fraction"] >= 0.9 and tail_changes == 0
    return {
        "endpoint":{"label":"DENSE" if dense else "NONDENSE","dense":dense,"positive_fraction_6N":endpoint["positive_fraction"],"tail_raw_changed_sites_sum":tail_changes},
        "trace":trace,
    }


def run_case(kernel, threads: int, spec: dict) -> dict:
    n=int(spec["N"]); split=int(spec["split_tick"]); horizon=int(spec["horizon"])
    raw,clock,construction=discovery.prep.construct(n,spec["scaling"],int(spec["replicate"]))
    world=NativeWorld(kernel,raw,clock,threads)
    window_start=n//4
    pre_trace=[]; kappas=[]; qs=[]
    for tick in range(split+1):
        state=discovery.macro_metrics(world.raw,include_hash=tick in (0,window_start,split))
        pre_trace.append({"tick":tick,"state":state})
        if window_start<=tick<=split:
            kappas.append(state["kappa"]); qs.append(state["positive_fraction"])
        if tick<split:
            world.tick()
    split_raw=world.raw.copy(); split_clock=world.clock.copy()
    branches,audit=discovery.make_branches(split_raw,split_clock,int(construction["seed"]))
    full=continue_world(kernel,threads,*branches["full"],split,horizon,n)
    joint=None
    if full["endpoint"]["dense"]:
        joint=continue_world(kernel,threads,*branches["joint_snapshot_shuffle"],split,horizon,n)
    bar_kappa=float(np.mean(kappas)); bar_q=float(np.mean(qs))
    response=None if joint is None else ("ROBUST" if joint["endpoint"]["dense"] else "FRAGILE")
    result={
        "schema":"dee.v27.c04.nsh03.case.v1","experiment_id":"NSH03","role":"LOCKED_HOLDOUT","lock_sha256":LOCK_SHA256,
        "case_id":case_id(spec),"spec":spec,"construction":construction,
        "observation":{"window_start":window_start,"window_end":split,"samples":len(kappas),"bar_kappa":bar_kappa,"bar_q":bar_q,
                       "predictions":{"bar_kappa_robust":bar_kappa<=BAR_KAPPA_THRESHOLD,"bar_q_robust":bar_q>=BAR_Q_THRESHOLD,"size_robust":n>=SIZE_THRESHOLD}},
        "intervention_audit":audit,"reference_full":full,"joint_snapshot_shuffle":joint,
        "response":response,"pre_split_trace":pre_trace,
    }
    result["content_sha256"]=canonical_hash(result)
    return result


def verify_case(path: Path,spec: dict)->dict|None:
    if not path.is_file(): return None
    with path.open("r",encoding="utf-8") as stream: value=json.load(stream)
    if value.get("case_id")!=case_id(spec) or value.get("lock_sha256")!=LOCK_SHA256: raise RuntimeError(f"foreign case: {path}")
    claimed=value.pop("content_sha256",None)
    if canonical_hash(value)!=claimed: raise RuntimeError(f"case hash mismatch: {path}")
    value["content_sha256"]=claimed
    return value


def model_metrics(reference:list[dict],name:str)->dict:
    truth=np.array([case["response"]=="ROBUST" for case in reference],dtype=bool)
    prediction=np.array([case["observation"]["predictions"][f"{name}_robust"] for case in reference],dtype=bool)
    tp=int(np.count_nonzero(truth&prediction));tn=int(np.count_nonzero(~truth&~prediction));fp=int(np.count_nonzero(~truth&prediction));fn=int(np.count_nonzero(truth&~prediction))
    sensitivity=tp/(tp+fn) if tp+fn else None;specificity=tn/(tn+fp) if tn+fp else None
    return {"tp":tp,"tn":tn,"fp":fp,"fn":fn,"errors":fp+fn,"sensitivity":sensitivity,"specificity":specificity,
            "balanced_accuracy":(sensitivity+specificity)/2 if sensitivity is not None and specificity is not None else None}


def adjudicate(cases:list[dict])->dict:
    reference=[case for case in cases if case["reference_full"]["endpoint"]["dense"]]
    robust=[case for case in reference if case["response"]=="ROBUST"]
    fragile=[case for case in reference if case["response"]=="FRAGILE"]
    diversity={"full_dense":len(reference),"robust":len(robust),"fragile":len(fragile),
               "robust_N":sorted({case["spec"]["N"] for case in robust}),"fragile_N":sorted({case["spec"]["N"] for case in fragile})}
    diversity["pass"]=len(reference)>=12 and len(robust)>=4 and len(fragile)>=6 and len(diversity["robust_N"])>=2 and len(diversity["fragile_N"])>=2
    intervention_pass=all(case["intervention_audit"]["joint_shuffle_inventory_exact"] for case in reference)
    models={name:model_metrics(reference,name) for name in ("bar_kappa","bar_q","size")} if reference and robust and fragile else {}
    if not diversity["pass"] or not intervention_pass:
        verdict="INCONCLUSIVE";conditions={"reference_diversity":diversity["pass"],"intervention_audit":intervention_pass}
    else:
        primary=models["bar_kappa"]
        conditions={"reference_diversity":True,"intervention_audit":True,
                    "sensitivity_ge_0_85":primary["sensitivity"]>=0.85,"specificity_ge_0_85":primary["specificity"]>=0.85,
                    "balanced_accuracy_ge_0_90":primary["balanced_accuracy"]>=0.90,
                    "increment_over_size_ge_0_10":primary["balanced_accuracy"]-models["size"]["balanced_accuracy"]>=0.10,
                    "noninferiority_to_bar_q":primary["balanced_accuracy"]>=models["bar_q"]["balanced_accuracy"]-0.05}
        verdict="PASS" if all(conditions.values()) else "FAIL"
    return {"verdict":verdict,"reference_diversity":diversity,"intervention_audit":intervention_pass,"models":models,"conditions":conditions,"no_refit":True}


def static_audit()->dict:
    planned=specs();observed={"wheel":sha256_file(discovery.prep.WHEEL_FILE),"package":sha256_file(discovery.prep.PACKAGE_FILE),"kernel":sha256_file(discovery.prep.KERNEL_FILE)}
    checks={"lock_hash_exact":LOCK.is_file() and sha256_file(LOCK)==LOCK_SHA256,"kernel_identity_exact":observed==EXPECTED,
            "N_exact":N_VALUES==(33,40,47),"replicates_exact":REPLICATES==4,"thresholds_exact":(BAR_KAPPA_THRESHOLD,BAR_Q_THRESHOLD,SIZE_THRESHOLD)==(3.60,0.0290,37),
            "horizon_exact":HORIZON_MULTIPLIER==6,"seed_namespace_literal":"DEE-v27|C04|NSH03|v1" in HERE.read_text(encoding="utf-8"),
            "case_ids_unique":len(planned)==len({case_id(spec) for spec in planned})}
    return {"schema":"dee.v27.c04.nsh03.static_audit.v1","status":"PASS" if all(checks.values()) else "FAIL","checks":checks,"observed_hashes":observed,
            "lock_sha256":LOCK_SHA256,"runner_sha256":sha256_file(HERE),"shared_mechanism_runner_sha256":sha256_file(Path(discovery.__file__)),
            "planned_cases":len(planned),"maximum_kernel_ticks":sum(spec["split_tick"]+2*(spec["horizon"]-spec["split_tick"]) for spec in planned)}


def main()->int:
    parser=argparse.ArgumentParser();parser.add_argument("--audit-only",action="store_true");parser.add_argument("--threads",type=int,default=1);args=parser.parse_args()
    audit=static_audit()
    if args.audit_only:
        print(json.dumps(audit,indent=2,sort_keys=True));return 0 if audit["status"]=="PASS" else 2
    if audit["status"]!="PASS" or args.threads!=1: raise RuntimeError(f"locked audit failed: {audit}")
    if OUT.exists(): raise RuntimeError(f"holdout complete; refusing repeat: {OUT}")
    started=time.perf_counter();started_utc=datetime.now(timezone.utc).isoformat();kernel,environment=verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True,exist_ok=True);cases=[];planned=specs()
    for index,spec in enumerate(planned,start=1):
        path=CASE_DIR/f"{case_id(spec)}.json";case=verify_case(path,spec);resumed=case is not None
        if case is None: case=run_case(kernel,args.threads,spec);atomic_json(path,case)
        cases.append(case)
        atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh03.progress.v1","status":"RUNNING" if index<len(planned) else "CASES_COMPLETE","lock_sha256":LOCK_SHA256,
                              "completed_cases":index,"total_cases":len(planned),"last_case_id":case["case_id"],"last_case_resumed":resumed,
                              "next_case_id":case_id(planned[index]) if index<len(planned) else None,"timestamp_utc":datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed":index,"total":len(planned),"case_id":case["case_id"],"bar_kappa":case["observation"]["bar_kappa"],
                          "full":case["reference_full"]["endpoint"]["label"],"response":case["response"],"prediction_robust":case["observation"]["predictions"]["bar_kappa_robust"],"resumed":resumed}),flush=True)
    adjudication=adjudicate(cases)
    result={"schema":"dee.v27.c04.nsh03.holdout.v1","campaign":"DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT","experiment_id":"NSH03","role":"LOCKED_HOLDOUT",
            "lock_path":str(LOCK.relative_to(WORK)).replace("\\","/"),"lock_sha256":LOCK_SHA256,"started_utc":started_utc,"completed_utc":datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds":time.perf_counter()-started,"runner_sha256":sha256_file(HERE),"static_audit":audit,"environment":environment,"adjudication":adjudication,
            "full_outcomes":dict(Counter(case["reference_full"]["endpoint"]["label"] for case in cases)),"responses":dict(Counter(case["response"] for case in cases if case["response"])),
            "case_manifest":[{"case_id":case["case_id"],"path":str((CASE_DIR/f"{case['case_id']}.json").relative_to(WORK)).replace("\\","/"),"file_sha256":sha256_file(CASE_DIR/f"{case['case_id']}.json"),
                              "content_sha256":case["content_sha256"],"bar_kappa":case["observation"]["bar_kappa"],"full":case["reference_full"]["endpoint"]["label"],"response":case["response"]} for case in cases]}
    atomic_json(OUT,result);atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh03.progress.v1","status":"COMPLETE","completed_cases":len(cases),"total_cases":len(cases),"verdict":adjudication["verdict"],"result_sha256":sha256_file(OUT),"timestamp_utc":datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status":"COMPLETE","verdict":adjudication["verdict"],"adjudication":adjudication,"result":str(OUT),"result_sha256":sha256_file(OUT),"elapsed_seconds":result["elapsed_seconds"]},indent=2,sort_keys=True));return 0


if __name__=="__main__": raise SystemExit(main())
