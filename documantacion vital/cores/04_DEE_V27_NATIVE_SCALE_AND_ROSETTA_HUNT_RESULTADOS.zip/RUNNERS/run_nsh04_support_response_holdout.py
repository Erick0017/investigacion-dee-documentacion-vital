#!/usr/bin/env python3
"""NSH04 locked holdout for support-abundance basin depth."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh03_response_holdout as base
from native_core import EXPECTED, atomic_json, canonical_hash, sha256_file, verify_and_load_kernel


HERE=Path(__file__).resolve();WORK=HERE.parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NSH04.json";LOCK_SHA256="ac510053f99484c80d0367ce08b80dedbe8be558eea41b52c52b8df06610e295"
OUT=WORK/"RESULTS"/"NSH04_results.json";CASE_DIR=WORK/"RESULTS"/"NSH04_CASES";PROGRESS=WORK/"RESULTS"/"NSH04_progress.json"
N_VALUES=(34,42,50);SCALINGS=("linear","area","volume");REPLICATES=3


def seed_for(n:int,scaling:str,replicate:int)->int:
    payload=f"DEE-v27|C04|NSH04|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(payload).digest()[:8],"little")


# The preparation/intervention implementation remains byte-identical to NSH03; only frozen design globals change.
base.N_VALUES=N_VALUES;base.SCALINGS=SCALINGS;base.REPLICATES=REPLICATES;base.LOCK_SHA256=LOCK_SHA256
base.discovery.prep.deterministic_seed=seed_for


def specs()->list[dict]: return base.specs()
def case_id(spec:dict)->str: return base.case_id(spec)


def run_case(kernel,threads:int,spec:dict)->dict:
    result=base.run_case(kernel,threads,spec)
    result.pop("content_sha256")
    result["schema"]="dee.v27.c04.nsh04.case.v1";result["experiment_id"]="NSH04";result["lock_sha256"]=LOCK_SHA256
    result["content_sha256"]=canonical_hash(result)
    return result


def verify_case(path:Path,spec:dict)->dict|None:
    if not path.is_file(): return None
    with path.open("r",encoding="utf-8") as stream: value=json.load(stream)
    if value.get("schema")!="dee.v27.c04.nsh04.case.v1" or value.get("case_id")!=case_id(spec) or value.get("lock_sha256")!=LOCK_SHA256:
        raise RuntimeError(f"foreign case: {path}")
    claimed=value.pop("content_sha256",None)
    if canonical_hash(value)!=claimed: raise RuntimeError(f"case content mismatch: {path}")
    value["content_sha256"]=claimed;return value


def adjudicate(cases:list[dict])->dict:
    reference=[case for case in cases if case["reference_full"]["endpoint"]["dense"]]
    robust=[case for case in reference if case["response"]=="ROBUST"];fragile=[case for case in reference if case["response"]=="FRAGILE"]
    diversity={"full_dense":len(reference),"robust":len(robust),"fragile":len(fragile),
               "robust_N":sorted({case["spec"]["N"] for case in robust}),"fragile_N":sorted({case["spec"]["N"] for case in fragile})}
    diversity["pass"]=len(reference)>=12 and len(robust)>=5 and len(fragile)>=6 and len(diversity["robust_N"])>=2 and len(diversity["fragile_N"])>=2
    intervention_pass=all(case["intervention_audit"]["joint_shuffle_inventory_exact"] for case in reference)
    models={name:base.model_metrics(reference,name) for name in ("bar_q","bar_kappa","size")} if robust and fragile else {}
    if not diversity["pass"] or not intervention_pass:
        verdict="INCONCLUSIVE";conditions={"reference_diversity":diversity["pass"],"intervention_audit":intervention_pass}
    else:
        primary=models["bar_q"]
        conditions={"reference_diversity":True,"intervention_audit":True,
                    "sensitivity_ge_0_85":primary["sensitivity"]>=0.85,"specificity_ge_0_85":primary["specificity"]>=0.85,
                    "balanced_accuracy_ge_0_90":primary["balanced_accuracy"]>=0.90,
                    "increment_over_size_ge_0_10":primary["balanced_accuracy"]-models["size"]["balanced_accuracy"]>=0.10,
                    "noninferiority_to_bar_kappa":primary["balanced_accuracy"]>=models["bar_kappa"]["balanced_accuracy"]-0.05}
        verdict="PASS" if all(conditions.values()) else "FAIL"
    return {"verdict":verdict,"reference_diversity":diversity,"intervention_audit":intervention_pass,"models":models,"conditions":conditions,"no_refit":True}


def static_audit()->dict:
    planned=specs();d=base.discovery
    observed={"wheel":sha256_file(d.prep.WHEEL_FILE),"package":sha256_file(d.prep.PACKAGE_FILE),"kernel":sha256_file(d.prep.KERNEL_FILE)}
    checks={"lock_hash_exact":LOCK.is_file() and sha256_file(LOCK)==LOCK_SHA256,"kernel_identity_exact":observed==EXPECTED,
            "N_exact":N_VALUES==(34,42,50),"replicates_exact":REPLICATES==3,
            "thresholds_inherited_exact":(base.BAR_Q_THRESHOLD,base.BAR_KAPPA_THRESHOLD,base.SIZE_THRESHOLD)==(0.0290,3.60,37),
            "seed_namespace_literal":"DEE-v27|C04|NSH04|v1" in HERE.read_text(encoding="utf-8"),
            "case_ids_unique":len(planned)==len({case_id(spec) for spec in planned})}
    return {"schema":"dee.v27.c04.nsh04.static_audit.v1","status":"PASS" if all(checks.values()) else "FAIL","checks":checks,"observed_hashes":observed,
            "lock_sha256":LOCK_SHA256,"runner_sha256":sha256_file(HERE),"shared_response_runner_sha256":sha256_file(Path(base.__file__)),
            "planned_cases":len(planned),"maximum_kernel_ticks":sum(spec["split_tick"]+2*(spec["horizon"]-spec["split_tick"]) for spec in planned)}


def main()->int:
    parser=argparse.ArgumentParser();parser.add_argument("--audit-only",action="store_true");parser.add_argument("--threads",type=int,default=1);args=parser.parse_args();audit=static_audit()
    if args.audit_only: print(json.dumps(audit,indent=2,sort_keys=True));return 0 if audit["status"]=="PASS" else 2
    if audit["status"]!="PASS" or args.threads!=1: raise RuntimeError(f"locked audit failed: {audit}")
    if OUT.exists(): raise RuntimeError(f"holdout complete; refusing repeat: {OUT}")
    started=time.perf_counter();started_utc=datetime.now(timezone.utc).isoformat();kernel,environment=verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True,exist_ok=True);cases=[];planned=specs()
    for index,spec in enumerate(planned,start=1):
        path=CASE_DIR/f"{case_id(spec)}.json";case=verify_case(path,spec);resumed=case is not None
        if case is None: case=run_case(kernel,args.threads,spec);atomic_json(path,case)
        cases.append(case);atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh04.progress.v1","status":"RUNNING" if index<len(planned) else "CASES_COMPLETE","lock_sha256":LOCK_SHA256,
            "completed_cases":index,"total_cases":len(planned),"last_case_id":case["case_id"],"last_case_resumed":resumed,"next_case_id":case_id(planned[index]) if index<len(planned) else None,"timestamp_utc":datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed":index,"total":len(planned),"case_id":case["case_id"],"bar_q":case["observation"]["bar_q"],
                          "full":case["reference_full"]["endpoint"]["label"],"response":case["response"],"prediction_robust":case["observation"]["predictions"]["bar_q_robust"],"resumed":resumed}),flush=True)
    adjudication=adjudicate(cases)
    result={"schema":"dee.v27.c04.nsh04.holdout.v1","campaign":"DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT","experiment_id":"NSH04","role":"LOCKED_HOLDOUT",
            "lock_path":str(LOCK.relative_to(WORK)).replace("\\","/"),"lock_sha256":LOCK_SHA256,"started_utc":started_utc,"completed_utc":datetime.now(timezone.utc).isoformat(),
            "elapsed_seconds":time.perf_counter()-started,"runner_sha256":sha256_file(HERE),"static_audit":audit,"environment":environment,"adjudication":adjudication,
            "full_outcomes":dict(Counter(case["reference_full"]["endpoint"]["label"] for case in cases)),"responses":dict(Counter(case["response"] for case in cases if case["response"])),
            "case_manifest":[{"case_id":case["case_id"],"path":str((CASE_DIR/f"{case['case_id']}.json").relative_to(WORK)).replace("\\","/"),"file_sha256":sha256_file(CASE_DIR/f"{case['case_id']}.json"),
                              "content_sha256":case["content_sha256"],"bar_q":case["observation"]["bar_q"],"full":case["reference_full"]["endpoint"]["label"],"response":case["response"]} for case in cases]}
    atomic_json(OUT,result);atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh04.progress.v1","status":"COMPLETE","completed_cases":len(cases),"total_cases":len(cases),"verdict":adjudication["verdict"],"result_sha256":sha256_file(OUT),"timestamp_utc":datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status":"COMPLETE","verdict":adjudication["verdict"],"adjudication":adjudication,"result":str(OUT),"result_sha256":sha256_file(OUT),"elapsed_seconds":result["elapsed_seconds"]},indent=2,sort_keys=True));return 0


if __name__=="__main__": raise SystemExit(main())
