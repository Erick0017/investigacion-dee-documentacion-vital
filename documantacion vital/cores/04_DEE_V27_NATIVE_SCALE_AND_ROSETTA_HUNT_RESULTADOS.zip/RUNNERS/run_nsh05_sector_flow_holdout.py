#!/usr/bin/env python3
"""NSH05 locked holdout of the Q2-gated N/8 triangular scale flow."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh02_temporal_holdout as nsh02
from native_core import EXPECTED, NativeWorld, atomic_json, canonical_hash, sha256_array, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "NSH05.json"
LOCK_SHA256 = "238d25ec220181b9ef5bf32d5f393cbc1823cfb7367410c079b20203a77fb00a"
OUT = WORK / "RESULTS" / "NSH05_results.json"
CASE_DIR = WORK / "RESULTS" / "NSH05_CASES"
PROGRESS = WORK / "RESULTS" / "NSH05_progress.json"
N_VALUES = (24, 32, 48)
SCALINGS = ("linear", "area", "volume")
ARMS = ("organized_inward", "global_joint_inventory_shuffle")
REPLICATES = 2
GATE = 5.60
COEFFICIENTS = {
    "a0": 0.02328702025934721,
    "a1": 2.574303732734078,
    "a2": -2.6162955004776953,
    "a3": -1.8822948214354622,
    "b1": -0.6794269820170623,
    "b2": 0.6915825897523803,
}


def deterministic_seed(n: int, scaling: str, replicate: int) -> int:
    phrase = f"DEE-v27|C04|NSH05|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


nsh02.base.deterministic_seed = deterministic_seed


def specs() -> list[dict]:
    return [
        {"N": n, "scaling": scaling, "replicate": rep, "arm": arm, "horizon": 6 * n}
        for n in N_VALUES for scaling in SCALINGS for rep in range(REPLICATES) for arm in ARMS
    ]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_{spec['scaling']}_r{spec['replicate']}_{spec['arm']}"


def z(row: dict, n: int) -> np.ndarray:
    return np.asarray([float(row["positive"]) / n**3, float(row["kappa"]) / 6.0], dtype=float)


def dense_increment(zz: np.ndarray) -> np.ndarray:
    q, k = map(float, zz)
    c = COEFFICIENTS
    return np.asarray([
        c["a0"] + c["a1"] * q + c["a2"] * q * q + c["a3"] * q * k,
        c["b1"] * k + c["b2"] * k * k,
    ])


def run_case(kernel, threads: int, spec: dict) -> dict:
    n = int(spec["N"])
    horizon = int(spec["horizon"])
    lag = n // 8
    early_end = n + lag
    window_start, window_end = n // 4, n // 2
    raw, clock, construction = nsh02.base.construct(n, spec["scaling"], int(spec["replicate"]))
    raw, clock, inventory_audit = nsh02.base.apply_arm(raw, clock, spec["arm"], int(construction["seed"]))
    if not inventory_audit["exact"]:
        raise AssertionError("holdout arm changed joint raw+clock inventory")
    world = NativeWorld(kernel, raw, clock, threads)
    early_trace = []
    tail_raw_change_sum = 0
    total_overflows = 0
    final_state = None
    for tick in range(horizon + 1):
        capture = tick <= early_end or tick == horizon
        current = nsh02.base.metrics(world.raw, include_hash=tick in (0, window_start, window_end, early_end, horizon)) if capture else None
        if tick == horizon:
            final_state = current
            break
        need_changed = tick <= early_end or tick >= horizon - n
        raw_before = world.raw.copy() if need_changed else None
        info = world.tick()
        total_overflows += int(info["overflows"])
        changed = int(np.count_nonzero(raw_before != world.raw)) if need_changed else None
        if tick >= horizon - n:
            tail_raw_change_sum += int(changed)
        if tick <= early_end:
            early_trace.append({"tick": tick, "state": current, "kernel": info, "raw_changed_sites_to_next": changed})
    # Add the final early state, which was reached after the last stored transition.
    if early_trace[-1]["tick"] != early_end:
        raise AssertionError("early trace transition boundary mismatch")
    reached_early = nsh02.base.metrics(world.raw) if horizon == early_end else None
    # world is now at the endpoint; reconstruct early_end from the transition rows:
    # the state at early_end was captured as the final stored row before its tick.
    by_tick = {int(row["tick"]): row["state"] for row in early_trace}
    observed = [float(by_tick[t]["kappa"]) for t in range(window_start, window_end + 1)]
    bar_kappa = float(np.mean(observed))
    dense_gate = bar_kappa <= GATE
    paired = []
    for t in range(n // 2, n + 1, lag):
        current_z = z(by_tick[t], n)
        future_z = z(by_tick[t + lag], n)
        truth = future_z - current_z
        prediction = dense_increment(current_z) if dense_gate else np.zeros(2)
        paired.append({
            "tick": t,
            "future_tick": t + lag,
            "z": current_z.tolist(),
            "truth_delta": truth.tolist(),
            "predicted_delta": prediction.tolist(),
            "error": (prediction - truth).tolist(),
        })
    error = np.asarray([x["error"] for x in paired])
    truth = np.asarray([x["truth_delta"] for x in paired])
    sse = float(np.square(error).sum())
    persistence_sse = float(np.square(truth).sum())
    q_rmse = float(np.sqrt(np.mean(np.square(error[:, 0]))))
    k_rmse = float(np.sqrt(np.mean(np.square(error[:, 1]))))
    endpoint_dense = bool(final_state["positive_fraction"] >= 0.9 and tail_raw_change_sum == 0)
    result = {
        "schema": "dee.v27.c04.nsh05.case.v1",
        "experiment_id": "NSH05",
        "role": "LOCKED_HOLDOUT",
        "lock_sha256": LOCK_SHA256,
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "inventory_audit": inventory_audit,
        "observation": {
            "window_start": window_start,
            "window_end": window_end,
            "bar_kappa": bar_kappa,
            "gate": "DENSE_FLOW" if dense_gate else "SPARSE_IDENTITY",
            "lag": lag,
            "paired_samples": len(paired),
            "window_values_sha256": sha256_array(np.asarray(observed, dtype="<f8")),
        },
        "flow": {
            "paired": paired,
            "joint_sse": sse,
            "persistence_sse": persistence_sse,
            "skill_vs_persistence": None if persistence_sse <= 1e-18 else 1.0 - sse / persistence_sse,
            "q_rmse": q_rmse,
            "k_rmse": k_rmse,
        },
        "endpoint": {
            "positive_fraction_6N": float(final_state["positive_fraction"]),
            "tail_raw_changed_sites_sum": tail_raw_change_sum,
            "dense": endpoint_dense,
            "label": "DENSE" if endpoint_dense else "NONDENSE",
        },
        "diagnostics": {"total_overflows": total_overflows, "arm_dense_prediction": spec["arm"] == "organized_inward"},
        "early_trace": early_trace,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec) or value.get("lock_sha256") != LOCK_SHA256:
        raise RuntimeError(f"foreign or stale case: {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case content mismatch: {path}")
    value["content_sha256"] = claimed
    return value


def class_metrics(truth: np.ndarray, prediction: np.ndarray) -> dict:
    tp = int(np.count_nonzero(truth & prediction))
    tn = int(np.count_nonzero(~truth & ~prediction))
    fp = int(np.count_nonzero(~truth & prediction))
    fn = int(np.count_nonzero(truth & ~prediction))
    sensitivity = tp / (tp + fn) if tp + fn else None
    specificity = tn / (tn + fp) if tn + fp else None
    return {"tp": tp, "tn": tn, "fp": fp, "fn": fn, "errors": fp + fn, "sensitivity": sensitivity, "specificity": specificity, "balanced_accuracy": None if sensitivity is None or specificity is None else (sensitivity + specificity) / 2}


def flow_summary(cases: list[dict]) -> dict:
    skills = [float(c["flow"]["skill_vs_persistence"]) for c in cases if c["flow"]["skill_vs_persistence"] is not None]
    return {
        "worlds": len(cases),
        "mean_world_skill": None if not skills else float(np.mean(skills)),
        "median_world_skill": None if not skills else float(np.median(skills)),
        "fraction_beating_persistence": None if not skills else float(np.mean(np.asarray(skills) > 0)),
        "median_q_rmse": float(np.median([c["flow"]["q_rmse"] for c in cases])),
        "max_q_rmse": float(np.max([c["flow"]["q_rmse"] for c in cases])),
        "median_k_rmse": float(np.median([c["flow"]["k_rmse"] for c in cases])),
        "max_k_rmse": float(np.max([c["flow"]["k_rmse"] for c in cases])),
    }


def adjudicate(cases: list[dict]) -> dict:
    dense = [c for c in cases if c["observation"]["gate"] == "DENSE_FLOW"]
    sparse = [c for c in cases if c["observation"]["gate"] == "SPARSE_IDENTITY"]
    endpoint_dense = [c for c in cases if c["endpoint"]["dense"]]
    endpoint_nondense = [c for c in cases if not c["endpoint"]["dense"]]
    dense_by_n = {n: [c for c in dense if c["spec"]["N"] == n] for n in N_VALUES}
    diversity = {
        "complete_worlds": len(cases),
        "DENSE_FLOW_worlds": len(dense),
        "SPARSE_IDENTITY_worlds": len(sparse),
        "DENSE_FLOW_N": sorted({c["spec"]["N"] for c in dense}),
        "SPARSE_IDENTITY_N": sorted({c["spec"]["N"] for c in sparse}),
        "endpoint_dense_worlds": len(endpoint_dense),
        "endpoint_nondense_worlds": len(endpoint_nondense),
        "dense_worlds_per_N": {str(n): len(v) for n, v in dense_by_n.items()},
    }
    diversity["pass"] = (
        len(cases) == 36 and len(dense) >= 10 and len(sparse) >= 10
        and len(diversity["DENSE_FLOW_N"]) >= 2 and len(diversity["SPARSE_IDENTITY_N"]) >= 2
        and all(len(v) >= 2 for v in dense_by_n.values())
        and len(endpoint_dense) >= 9 and len(endpoint_nondense) >= 9
    )
    dense_summary = flow_summary(dense)
    sparse_summary = flow_summary(sparse)
    per_n_dense = {
        str(n): flow_summary(v) for n, v in dense_by_n.items()
    }
    truth = np.asarray([c["endpoint"]["dense"] for c in cases], dtype=bool)
    gate_pred = np.asarray([c["observation"]["gate"] == "DENSE_FLOW" for c in cases], dtype=bool)
    arm_pred = np.asarray([c["diagnostics"]["arm_dense_prediction"] for c in cases], dtype=bool)
    classifiers = {"gate": class_metrics(truth, gate_pred), "arm": class_metrics(truth, arm_pred)}
    audits = {
        "all_inventory_exact": all(c["inventory_audit"]["exact"] for c in cases),
        "all_five_paired_samples": all(c["observation"]["paired_samples"] == 5 for c in cases),
        "all_case_hashes_present": all(bool(c.get("content_sha256")) for c in cases),
    }
    if not all(audits.values()) or not diversity["pass"]:
        conditions = {"audit": all(audits.values()), "minimum_relevance": diversity["pass"]}
        verdict = "INCONCLUSIVE"
    else:
        gate = classifiers["gate"]
        arm = classifiers["arm"]
        conditions = {
            "audit": True,
            "minimum_relevance": True,
            "dense_mean_skill_ge_0_65": dense_summary["mean_world_skill"] >= 0.65,
            "dense_median_skill_ge_0_85": dense_summary["median_world_skill"] >= 0.85,
            "dense_fraction_beating_ge_0_85": dense_summary["fraction_beating_persistence"] >= 0.85,
            "each_N_dense_median_skill_ge_0_70": all(v["median_world_skill"] >= 0.70 for v in per_n_dense.values()),
            "dense_median_q_rmse_le_0_040": dense_summary["median_q_rmse"] <= 0.040,
            "dense_median_k_rmse_le_0_050": dense_summary["median_k_rmse"] <= 0.050,
            "sparse_max_q_rmse_le_0_001": sparse_summary["max_q_rmse"] <= 0.001,
            "sparse_median_k_rmse_le_0_010": sparse_summary["median_k_rmse"] <= 0.010,
            "gate_sensitivity_ge_0_85": gate["sensitivity"] >= 0.85,
            "gate_specificity_ge_0_85": gate["specificity"] >= 0.85,
            "gate_balanced_accuracy_ge_0_90": gate["balanced_accuracy"] >= 0.90,
            "gate_increment_over_arm_ge_0_05": gate["balanced_accuracy"] - arm["balanced_accuracy"] >= 0.05,
        }
        verdict = "PASS" if all(conditions.values()) else "FAIL"
    return {"verdict": verdict, "diversity": diversity, "audits": audits, "dense_flow": dense_summary, "sparse_identity": sparse_summary, "per_N_dense": per_n_dense, "classifiers": classifiers, "conditions": conditions, "no_refit": True}


def static_audit() -> dict:
    observed = {"wheel": sha256_file(nsh02.base.WHEEL_FILE), "package": sha256_file(nsh02.base.PACKAGE_FILE), "kernel": sha256_file(nsh02.base.KERNEL_FILE)}
    planned = specs()
    checks = {
        "lock_hash_exact": LOCK.is_file() and sha256_file(LOCK) == LOCK_SHA256,
        "kernel_identity_exact": observed == EXPECTED,
        "N_exact": N_VALUES == (24, 32, 48),
        "N_divisible_by_8": all(n % 8 == 0 for n in N_VALUES),
        "replicates_exact": REPLICATES == 2,
        "arms_exact": ARMS == ("organized_inward", "global_joint_inventory_shuffle"),
        "gate_exact": GATE == 5.60,
        "coefficients_exact": COEFFICIENTS == {"a0": 0.02328702025934721, "a1": 2.574303732734078, "a2": -2.6162955004776953, "a3": -1.8822948214354622, "b1": -0.6794269820170623, "b2": 0.6915825897523803},
        "seed_namespace_literal": "DEE-v27|C04|NSH05|v1" in HERE.read_text(encoding="utf-8"),
        "case_ids_unique": len(planned) == len({case_id(s) for s in planned}),
    }
    return {"schema": "dee.v27.c04.nsh05.static_audit.v1", "status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "observed_hashes": observed, "lock_sha256": LOCK_SHA256, "runner_sha256": sha256_file(HERE), "preparation_implementation_sha256": sha256_file(Path(nsh02.base.__file__)), "planned_cases": len(planned), "planned_universe_ticks": sum(s["horizon"] for s in planned)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(f"locked static audit failed: {audit}")
    if OUT.exists():
        raise RuntimeError(f"holdout already completed; refusing to repeat: {OUT}")
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(args.threads)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    cases = []
    planned = specs()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_case(kernel, args.threads, spec)
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {"schema": "dee.v27.c04.nsh05.progress.v1", "status": "RUNNING" if index < len(planned) else "CASES_COMPLETE", "lock_sha256": LOCK_SHA256, "completed_cases": index, "total_cases": len(planned), "last_case_id": case["case_id"], "last_case_resumed": resumed, "next_case_id": case_id(planned[index]) if index < len(planned) else None, "timestamp_utc": datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed": index, "total": len(planned), "case_id": case["case_id"], "gate": case["observation"]["gate"], "skill": case["flow"]["skill_vs_persistence"], "endpoint": case["endpoint"]["label"], "resumed": resumed}), flush=True)
    adjudication = adjudicate(cases)
    result = {
        "schema": "dee.v27.c04.nsh05.holdout.v1",
        "campaign": "DEE_V27_EXPERIMENTO_04_NATIVE_SCALE_AND_ROSETTA_HUNT",
        "experiment_id": "NSH05", "role": "LOCKED_HOLDOUT",
        "lock_path": "HOLDOUT_LOCKS/NSH05.json", "lock_sha256": LOCK_SHA256,
        "completed_utc": datetime.now(timezone.utc).isoformat(), "elapsed_seconds": time.perf_counter() - started,
        "runner_sha256": sha256_file(HERE), "static_audit": audit, "environment": environment,
        "adjudication": adjudication, "gate_counts": dict(Counter(c["observation"]["gate"] for c in cases)), "endpoint_counts": dict(Counter(c["endpoint"]["label"] for c in cases)),
        "case_manifest": [{"case_id": c["case_id"], "path": str((CASE_DIR / f"{c['case_id']}.json").relative_to(WORK)).replace("\\", "/"), "file_sha256": sha256_file(CASE_DIR / f"{c['case_id']}.json"), "content_sha256": c["content_sha256"], "gate": c["observation"]["gate"], "skill": c["flow"]["skill_vs_persistence"], "endpoint": c["endpoint"]["label"]} for c in cases],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {"schema": "dee.v27.c04.nsh05.progress.v1", "status": "COMPLETE", "lock_sha256": LOCK_SHA256, "completed_cases": len(cases), "total_cases": len(cases), "verdict": adjudication["verdict"], "result_sha256": sha256_file(OUT), "timestamp_utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status": "COMPLETE", "verdict": adjudication["verdict"], "adjudication": adjudication, "result": str(OUT), "result_sha256": sha256_file(OUT), "elapsed_seconds": result["elapsed_seconds"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
