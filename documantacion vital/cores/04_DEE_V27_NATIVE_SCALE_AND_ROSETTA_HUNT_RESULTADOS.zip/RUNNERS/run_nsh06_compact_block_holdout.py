#!/usr/bin/env python3
"""NSH06 locked cross-preparation challenge on matched compact blocks."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh05_sector_flow_holdout as nsh05
from native_core import EXPECTED, NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, sha256_file, verify_and_load_kernel


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
LOCK = ROOT / "HOLDOUT_LOCKS" / "NSH06.json"
LOCK_SHA256 = "60cc134de7615423380f63cdeadfccc54d8ea637882e91acaf0f3f98af5b1acf"
OUT = ROOT / "RESULTS" / "NSH06_results.json"
CASE_DIR = ROOT / "RESULTS" / "NSH06_CASES"
PROGRESS = ROOT / "RESULTS" / "NSH06_progress.json"
N_VALUES = (24, 32, 40)
MODES = ("stationary", "inward", "outward")
REPLICATES = 3


def seed_for(n: int, replicate: int) -> int:
    return int.from_bytes(hashlib.sha256(f"DEE-v27|C04|NSH06|v1|N={n}|rep={replicate}".encode()).digest()[:8], "little")


def side_for(n: int) -> int:
    side = int(round(n / 8))
    return side + 1 if side % 2 == 0 else side


def specs() -> list[dict]:
    return [{"N": n, "replicate": rep, "direction_mode": mode, "side": side_for(n), "horizon": 6 * n} for n in N_VALUES for rep in range(REPLICATES) for mode in MODES]


def case_id(spec: dict) -> str:
    return f"N{spec['N']}_r{spec['replicate']}_{spec['direction_mode']}"


def construct(spec: dict) -> tuple[np.ndarray, np.ndarray, dict]:
    n, rep, mode, side = int(spec["N"]), int(spec["replicate"]), spec["direction_mode"], int(spec["side"])
    rng = np.random.default_rng(seed_for(n, rep))
    center = np.asarray([n // 2] * 3, dtype=int)
    half = side // 2
    coords = [(i, j, k) for i in range(center[0] - half, center[0] + half + 1) for j in range(center[1] - half, center[1] + half + 1) for k in range(center[2] - half, center[2] + half + 1)]
    sreg_values = rng.integers(1, 65, size=len(coords))
    clock_values = np.asarray([nsh05.nsh02.base.CLOCK_BANK[int(x)] for x in rng.integers(0, len(nsh05.nsh02.base.CLOCK_BANK), size=len(coords))], dtype=np.uint64)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    for index, pos in enumerate(coords):
        delta = np.sign(np.asarray(pos) - center).astype(int)
        if mode == "stationary":
            direction = (0, 0, 0)
        elif mode == "inward":
            direction = tuple(int(-x) for x in delta)
        elif mode == "outward":
            direction = tuple(int(x) for x in delta)
        else:
            raise ValueError(mode)
        raw[pos] = pack(1, int(sreg_values[index]), direction, 1)
        clock[pos] = clock_values[index]
    f = fields(raw)
    support = f["state"] != 0
    return raw, clock, {
        "seed": seed_for(n, rep), "side": side, "positive": int(support.sum()),
        "matched_hashes": {
            "support": sha256_array(support), "state": sha256_array(f["state"]), "sreg": sha256_array(f["sreg"]),
            "semantic": sha256_array(f["semantic"]), "clock": sha256_array(clock),
        },
        "raw_sha256": sha256_array(raw),
    }


def z(state: dict, n: int) -> np.ndarray:
    return np.asarray([float(state["positive"]) / n**3, float(state["kappa"]) / 6.0])


def run_case(kernel, spec: dict) -> dict:
    n, horizon = int(spec["N"]), int(spec["horizon"])
    lag, early_end = n // 8, n + n // 8
    window_start, window_end = n // 4, n // 2
    raw, clock, construction = construct(spec)
    world = NativeWorld(kernel, raw, clock, 1)
    early_trace, tail_changes, overflows = [], 0, 0
    final_state = None
    for tick in range(horizon + 1):
        capture = tick <= early_end or tick == horizon
        current = nsh05.nsh02.base.metrics(world.raw, include_hash=tick in (0, window_start, window_end, early_end, horizon)) if capture else None
        if tick == horizon:
            final_state = current
            break
        need_change = tick <= early_end or tick >= horizon - n
        before = world.raw.copy() if need_change else None
        info = world.tick()
        overflows += int(info["overflows"])
        changed = int(np.count_nonzero(before != world.raw)) if need_change else None
        if tick >= horizon - n:
            tail_changes += int(changed)
        if tick <= early_end:
            early_trace.append({"tick": tick, "state": current, "kernel": info, "raw_changed_sites_to_next": changed})
    by_tick = {int(row["tick"]): row["state"] for row in early_trace}
    bar_kappa = float(np.mean([float(by_tick[t]["kappa"]) for t in range(window_start, window_end + 1)]))
    dense_gate = bar_kappa <= nsh05.GATE
    paired = []
    for t in range(n // 2, n + 1, lag):
        z0, z1 = z(by_tick[t], n), z(by_tick[t + lag], n)
        truth = z1 - z0
        pred = nsh05.dense_increment(z0) if dense_gate else np.zeros(2)
        paired.append({"tick": t, "future_tick": t + lag, "z": z0.tolist(), "truth_delta": truth.tolist(), "predicted_delta": pred.tolist(), "error": (pred - truth).tolist()})
    error = np.asarray([x["error"] for x in paired])
    truth = np.asarray([x["truth_delta"] for x in paired])
    sse, base_sse = float(np.square(error).sum()), float(np.square(truth).sum())
    if base_sse <= 1e-18:
        skill = 0.0 if sse <= 1e-18 else None
        zero_baseline_loss = sse > 1e-18
    else:
        skill = 1.0 - sse / base_sse
        zero_baseline_loss = False
    endpoint_dense = bool(final_state["positive_fraction"] >= 0.9 and tail_changes == 0)
    result = {
        "schema": "dee.v27.c04.nsh06.case.v1", "experiment_id": "NSH06", "role": "LOCKED_HOLDOUT", "lock_sha256": LOCK_SHA256,
        "case_id": case_id(spec), "spec": spec, "construction": construction,
        "observation": {"window_start": window_start, "window_end": window_end, "bar_kappa": bar_kappa, "gate": "DENSE_FLOW" if dense_gate else "SPARSE_IDENTITY", "lag": lag, "paired_samples": len(paired)},
        "flow": {"paired": paired, "joint_sse": sse, "persistence_sse": base_sse, "skill_vs_persistence": skill, "zero_baseline_model_loss": zero_baseline_loss, "q_rmse": float(np.sqrt(np.mean(np.square(error[:, 0])))), "k_rmse": float(np.sqrt(np.mean(np.square(error[:, 1]))))},
        "endpoint": {"positive_fraction_6N": float(final_state["positive_fraction"]), "tail_raw_changed_sites_sum": tail_changes, "dense": endpoint_dense, "label": "DENSE" if endpoint_dense else "NONDENSE"},
        "diagnostics": {"total_overflows": overflows, "direction_null_dense": spec["direction_mode"] == "outward"}, "early_trace": early_trace,
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file(): return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec) or value.get("lock_sha256") != LOCK_SHA256: raise RuntimeError(f"foreign case {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed: raise RuntimeError(f"case hash mismatch {path}")
    value["content_sha256"] = claimed
    return value


def class_metrics(cases: list[dict], key) -> dict:
    truth = np.asarray([c["endpoint"]["dense"] for c in cases], dtype=bool)
    pred = np.asarray([key(c) for c in cases], dtype=bool)
    tp, tn = int(np.count_nonzero(truth & pred)), int(np.count_nonzero(~truth & ~pred))
    fp, fn = int(np.count_nonzero(~truth & pred)), int(np.count_nonzero(truth & ~pred))
    sens = tp / (tp + fn) if tp + fn else None; spec = tn / (tn + fp) if tn + fp else None
    return {"tp": tp, "tn": tn, "fp": fp, "fn": fn, "errors": fp + fn, "sensitivity": sens, "specificity": spec, "balanced_accuracy": None if sens is None or spec is None else (sens + spec) / 2}


def flow_summary(cases: list[dict]) -> dict:
    skills = [float(c["flow"]["skill_vs_persistence"]) for c in cases if c["flow"]["skill_vs_persistence"] is not None]
    zero_losses = sum(c["flow"]["zero_baseline_model_loss"] for c in cases)
    return {"worlds": len(cases), "defined_skills": len(skills), "zero_baseline_model_losses": zero_losses, "mean_world_skill": None if zero_losses or not skills else float(np.mean(skills)), "median_world_skill": None if zero_losses or not skills else float(np.median(skills)), "fraction_beating_persistence": float(np.mean([c["flow"]["joint_sse"] < c["flow"]["persistence_sse"] for c in cases])), "median_q_rmse": float(np.median([c["flow"]["q_rmse"] for c in cases])), "median_k_rmse": float(np.median([c["flow"]["k_rmse"] for c in cases]))}


def adjudicate(cases: list[dict]) -> dict:
    groups = {}
    for c in cases: groups.setdefault((c["spec"]["N"], c["spec"]["replicate"]), []).append(c)
    matched = all(len(g) == 3 and all(c["construction"]["matched_hashes"] == g[0]["construction"]["matched_hashes"] for c in g) for g in groups.values())
    dense_ep = [c for c in cases if c["endpoint"]["dense"]]; nondense_ep = [c for c in cases if not c["endpoint"]["dense"]]
    gated = [c for c in cases if c["observation"]["gate"] == "DENSE_FLOW"]
    diversity = {"complete_worlds": len(cases), "mode_counts": dict(Counter(c["spec"]["direction_mode"] for c in cases)), "endpoint_dense": len(dense_ep), "endpoint_nondense": len(nondense_ep), "endpoint_dense_N": sorted({c["spec"]["N"] for c in dense_ep}), "endpoint_nondense_N": sorted({c["spec"]["N"] for c in nondense_ep}), "dense_gated": len(gated)}
    diversity["pass"] = len(cases) == 27 and all(diversity["mode_counts"].get(m) == 9 for m in MODES) and len(dense_ep) >= 6 and len(nondense_ep) >= 6 and len(diversity["endpoint_dense_N"]) >= 2 and len(diversity["endpoint_nondense_N"]) >= 2 and len(gated) >= 9
    gate = class_metrics(cases, lambda c: c["observation"]["gate"] == "DENSE_FLOW")
    direction = class_metrics(cases, lambda c: c["diagnostics"]["direction_null_dense"])
    flow = flow_summary(gated)
    by_n = {str(n): flow_summary([c for c in gated if c["spec"]["N"] == n]) for n in N_VALUES if len([c for c in gated if c["spec"]["N"] == n]) >= 2}
    audit = {"matched_non_direction_fields": matched, "all_paired_samples_five": all(c["observation"]["paired_samples"] == 5 for c in cases), "all_hashes": all(bool(c.get("content_sha256")) for c in cases)}
    if not all(audit.values()) or not diversity["pass"]:
        conditions = {"audit": all(audit.values()), "minimum_relevance": diversity["pass"]}; verdict = "INCONCLUSIVE"
    else:
        conditions = {
            "audit": True, "minimum_relevance": True,
            "gate_sensitivity_ge_0_85": gate["sensitivity"] >= 0.85, "gate_specificity_ge_0_85": gate["specificity"] >= 0.85, "gate_BA_ge_0_90": gate["balanced_accuracy"] >= 0.90,
            "gate_no_more_than_0_05_below_direction_null": gate["balanced_accuracy"] >= direction["balanced_accuracy"] - 0.05,
            "no_zero_baseline_model_losses": flow["zero_baseline_model_losses"] == 0,
            "flow_mean_skill_ge_0_65": flow["mean_world_skill"] is not None and flow["mean_world_skill"] >= 0.65,
            "flow_median_skill_ge_0_85": flow["median_world_skill"] is not None and flow["median_world_skill"] >= 0.85,
            "flow_fraction_beating_ge_0_85": flow["fraction_beating_persistence"] >= 0.85,
            "flow_median_q_rmse_le_0_040": flow["median_q_rmse"] <= 0.040, "flow_median_k_rmse_le_0_050": flow["median_k_rmse"] <= 0.050,
            "each_N_median_skill_ge_0_70": all(v["median_world_skill"] is not None and v["median_world_skill"] >= 0.70 for v in by_n.values()),
        }
        verdict = "PASS" if all(conditions.values()) else "FAIL"
    return {"verdict": verdict, "audit": audit, "diversity": diversity, "gate": gate, "direction_null": direction, "gated_flow": flow, "per_N_gated_flow": by_n, "conditions": conditions, "by_mode_endpoint": {m: dict(Counter(c["endpoint"]["label"] for c in cases if c["spec"]["direction_mode"] == m)) for m in MODES}, "no_refit": True}


def static_audit() -> dict:
    observed = {"wheel": sha256_file(nsh05.nsh02.base.WHEEL_FILE), "package": sha256_file(nsh05.nsh02.base.PACKAGE_FILE), "kernel": sha256_file(nsh05.nsh02.base.KERNEL_FILE)}
    planned = specs()
    checks = {"lock_hash_exact": LOCK.is_file() and sha256_file(LOCK) == LOCK_SHA256, "kernel_identity_exact": observed == EXPECTED, "N_exact": N_VALUES == (24, 32, 40), "N_divisible_by_8": all(n % 8 == 0 for n in N_VALUES), "modes_exact": MODES == ("stationary", "inward", "outward"), "replicates_exact": REPLICATES == 3, "side_rule_exact": [side_for(n) for n in N_VALUES] == [3, 5, 5], "seed_namespace_literal": "DEE-v27|C04|NSH06|v1" in HERE.read_text(encoding="utf-8"), "case_ids_unique": len(planned) == len({case_id(x) for x in planned})}
    return {"schema": "dee.v27.c04.nsh06.static_audit.v1", "status": "PASS" if all(checks.values()) else "FAIL", "checks": checks, "observed_hashes": observed, "lock_sha256": LOCK_SHA256, "runner_sha256": sha256_file(HERE), "planned_cases": len(planned), "planned_ticks": sum(x["horizon"] for x in planned)}


def main() -> int:
    parser = argparse.ArgumentParser(); parser.add_argument("--audit-only", action="store_true"); parser.add_argument("--threads", type=int, default=1); args = parser.parse_args()
    audit = static_audit()
    if args.audit_only: print(json.dumps(audit, indent=2, sort_keys=True)); return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1: raise RuntimeError(f"static audit failed {audit}")
    if OUT.exists(): raise RuntimeError("holdout already complete; refusing repeat")
    kernel, environment = verify_and_load_kernel(1); CASE_DIR.mkdir(parents=True, exist_ok=True); started = time.perf_counter(); cases=[]; planned=specs()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"; case=verify_case(path,spec); resumed=case is not None
        if case is None: case=run_case(kernel,spec); atomic_json(path,case)
        cases.append(case); atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh06.progress.v1","status":"RUNNING" if index<len(planned) else "CASES_COMPLETE","completed":index,"total":len(planned),"last":case["case_id"],"resumed":resumed,"lock_sha256":LOCK_SHA256,"timestamp_utc":datetime.now(timezone.utc).isoformat()})
        print(json.dumps({"completed":index,"total":len(planned),"case_id":case["case_id"],"bar_kappa":case["observation"]["bar_kappa"],"gate":case["observation"]["gate"],"skill":case["flow"]["skill_vs_persistence"],"endpoint":case["endpoint"]["label"],"resumed":resumed}),flush=True)
    adjudication=adjudicate(cases)
    result={"schema":"dee.v27.c04.nsh06.holdout.v1","experiment_id":"NSH06","role":"LOCKED_HOLDOUT","lock_sha256":LOCK_SHA256,"runner_sha256":sha256_file(HERE),"environment":environment,"static_audit":audit,"elapsed_seconds":time.perf_counter()-started,"adjudication":adjudication,"case_manifest":[{"case_id":c["case_id"],"path":str((CASE_DIR/f"{c['case_id']}.json").relative_to(ROOT)).replace("\\","/"),"file_sha256":sha256_file(CASE_DIR/f"{c['case_id']}.json"),"content_sha256":c["content_sha256"],"gate":c["observation"]["gate"],"endpoint":c["endpoint"]["label"]} for c in cases]}; result["content_sha256"]=canonical_hash(result); atomic_json(OUT,result)
    atomic_json(PROGRESS,{"schema":"dee.v27.c04.nsh06.progress.v1","status":"COMPLETE","completed":len(cases),"total":len(cases),"verdict":adjudication["verdict"],"result_sha256":sha256_file(OUT),"timestamp_utc":datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"status":"COMPLETE","verdict":adjudication["verdict"],"adjudication":adjudication,"result":str(OUT),"result_sha256":sha256_file(OUT),"elapsed_seconds":result["elapsed_seconds"]},indent=2,sort_keys=True)); return 0


if __name__ == "__main__": raise SystemExit(main())
