#!/usr/bin/env python3
"""NSH07 locked holdout of integrated reproduction and active interface.

This runner is deliberately restart-safe at the independent-world level.  It
opens the frozen panel once, reuses only case files whose canonical hashes and
lock identity verify, and refuses to overwrite a completed adjudication.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh05_sector_flow_holdout as nsh05
from native_core import (
    EXPECTED,
    NativeWorld,
    atomic_json,
    canonical_hash,
    fields,
    pack,
    sha256_array,
    sha256_file,
    verify_and_load_kernel,
)


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
LOCK = ROOT / "HOLDOUT_LOCKS" / "NSH07.json"
LOCK_SHA256 = "80a4b3cff667c9da67d0c76e47954607471645ff68a2e0bc7f094465155f1b24"
OUT = ROOT / "RESULTS" / "NSH07_results.json"
CASE_DIR = ROOT / "RESULTS" / "NSH07_CASES"
PROGRESS = ROOT / "RESULTS" / "NSH07_progress.json"
N_VALUES = (28, 36, 44)
SCALINGS = ("linear", "area", "volume")
NESTED_ARMS = ("organized_inward", "global_joint_inventory_shuffle")
COMPACT_MODES = ("stationary", "inward", "outward", "shuffled_outward")
KAPPA_THRESHOLD = 5.60
ACTIVITY_THRESHOLD = 0.50
HORIZON_MULTIPLIER = 6


def nested_seed(n: int, scaling: str, replicate: int) -> int:
    phrase = f"DEE-v27|C04|NSH07|nested|v1|N={n}|scaling={scaling}|rep={replicate}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


# Reuse the already-audited nested-shell constructor while changing only the
# lock-declared seed namespace.
nsh05.nsh02.base.deterministic_seed = nested_seed


def compact_seed(n: int) -> int:
    phrase = f"DEE-v27|C04|NSH07|compact|v1|N={n}".encode("ascii")
    return int.from_bytes(hashlib.sha256(phrase).digest()[:8], "little")


def side_for(n: int) -> int:
    side = int(round(n / 8))
    return side + 1 if side % 2 == 0 else side


def specs() -> list[dict]:
    nested = [
        {
            "family": "nested",
            "N": n,
            "scaling": scaling,
            "replicate": 0,
            "arm": arm,
            "horizon": HORIZON_MULTIPLIER * n,
        }
        for n in N_VALUES
        for scaling in SCALINGS
        for arm in NESTED_ARMS
    ]
    compact = [
        {
            "family": "compact",
            "N": n,
            "mode": mode,
            "side": side_for(n),
            "horizon": HORIZON_MULTIPLIER * n,
        }
        for n in N_VALUES
        for mode in COMPACT_MODES
    ]
    return nested + compact


def case_id(spec: dict) -> str:
    if spec["family"] == "nested":
        return f"nested_N{spec['N']}_{spec['scaling']}_{spec['arm']}"
    return f"compact_N{spec['N']}_{spec['mode']}"


def joint_multiset_hash(raw: np.ndarray, clock: np.ndarray) -> str:
    flat_raw = raw.reshape(-1).astype("<u8", copy=False)
    flat_clock = clock.reshape(-1).astype("<u8", copy=False)
    pairs = np.rec.fromarrays([flat_raw, flat_clock], names="raw,clock")
    order = np.argsort(pairs, order=("raw", "clock"))
    payload = np.column_stack([flat_raw[order], flat_clock[order]]).astype("<u8", copy=False)
    return sha256_array(payload)


def compact_construct(n: int, mode: str) -> tuple[np.ndarray, np.ndarray, dict, dict]:
    seed = compact_seed(n)
    rng = np.random.default_rng(seed)
    side = side_for(n)
    center = np.asarray([n // 2] * 3, dtype=int)
    half = side // 2
    coords = [
        (i, j, k)
        for i in range(center[0] - half, center[0] + half + 1)
        for j in range(center[1] - half, center[1] + half + 1)
        for k in range(center[2] - half, center[2] + half + 1)
    ]
    sreg_values = rng.integers(1, 65, size=len(coords))
    bank = nsh05.nsh02.base.CLOCK_BANK
    clock_values = np.asarray([bank[int(x)] for x in rng.integers(0, len(bank), size=len(coords))], dtype=np.uint64)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    direction_mode = "outward" if mode == "shuffled_outward" else mode
    for index, pos in enumerate(coords):
        delta = np.sign(np.asarray(pos) - center).astype(int)
        if direction_mode == "stationary":
            direction = (0, 0, 0)
        elif direction_mode == "inward":
            direction = tuple(int(-x) for x in delta)
        elif direction_mode == "outward":
            direction = tuple(int(x) for x in delta)
        else:
            raise ValueError(mode)
        raw[pos] = pack(1, int(sreg_values[index]), direction, 1)
        clock[pos] = clock_values[index]

    decoded = fields(raw)
    support = decoded["state"] != 0
    before_inventory = joint_multiset_hash(raw, clock)
    construction = {
        "seed": seed,
        "side": side,
        "positive": int(np.count_nonzero(support)),
        "pre_intervention_matched_hashes": {
            "support": sha256_array(support),
            "state": sha256_array(decoded["state"]),
            "sreg": sha256_array(decoded["sreg"]),
            "semantic": sha256_array(decoded["semantic"]),
            "clock": sha256_array(clock),
        },
        "pre_intervention_raw_sha256": sha256_array(raw),
    }
    if mode == "shuffled_outward":
        shuffle_rng = np.random.default_rng(seed ^ 0x7A11C04)
        permutation = shuffle_rng.permutation(raw.size)
        raw = raw.reshape(-1)[permutation].reshape(raw.shape).copy()
        clock = clock.reshape(-1)[permutation].reshape(clock.shape).copy()
    after_inventory = joint_multiset_hash(raw, clock)
    inventory = {
        "joint_inventory_sha256_before": before_inventory,
        "joint_inventory_sha256_after": after_inventory,
        "exact": before_inventory == after_inventory,
        "sitewise_changed": mode == "shuffled_outward",
    }
    return raw, clock, construction, inventory


def prepare(spec: dict) -> tuple[np.ndarray, np.ndarray, dict, dict]:
    if spec["family"] == "nested":
        raw, clock, construction = nsh05.nsh02.base.construct(
            int(spec["N"]), spec["scaling"], int(spec["replicate"])
        )
        raw, clock, inventory = nsh05.nsh02.base.apply_arm(
            raw, clock, spec["arm"], int(construction["seed"])
        )
        return raw, clock, construction, inventory
    return compact_construct(int(spec["N"]), spec["mode"])


def run_case(kernel, spec: dict) -> dict:
    n, horizon = int(spec["N"]), int(spec["horizon"])
    window_start, window_end = n // 4, n // 2
    raw, clock, construction, inventory = prepare(spec)
    if not inventory["exact"]:
        raise AssertionError("declared intervention changed joint raw+clock inventory")
    world = NativeWorld(kernel, raw, clock, 1)
    window = []
    tail_changes = 0
    total_overflows = 0
    final_state = None
    for tick in range(horizon + 1):
        in_window = window_start <= tick <= window_end
        capture = in_window or tick in (0, horizon)
        current = nsh05.nsh02.base.metrics(world.raw, include_hash=tick in (0, window_start, window_end, horizon)) if capture else None
        if in_window:
            p = int(current["positive"])
            if p <= 0:
                raise AssertionError("Gamma undefined because P vanished")
            window.append({
                "tick": tick,
                "positive": p,
                "positive_fraction": float(current["positive_fraction"]),
                "B6": int(current["B6"]),
                "kappa": float(current["kappa"]),
                "routed_positive": int(current["routed_positive"]),
                "activity": float(current["routed_positive"] / p),
                **({"raw_sha256": current["raw_sha256"]} if "raw_sha256" in current else {}),
            })
        if tick == horizon:
            final_state = current
            break
        need_change = tick >= horizon - n
        before = world.raw.copy() if need_change else None
        info = world.tick()
        total_overflows += int(info["overflows"])
        if need_change:
            tail_changes += int(np.count_nonzero(before != world.raw))

    expected_samples = window_end - window_start + 1
    if len(window) != expected_samples or window[0]["tick"] != window_start or window[-1]["tick"] != window_end:
        raise AssertionError("observation window mismatch")
    p0, p1 = int(window[0]["positive"]), int(window[-1]["positive"])
    exact_ratio = Fraction(1, 1)
    log_sum = 0.0
    factors = []
    for left, right in zip(window[:-1], window[1:]):
        factor = Fraction(int(right["positive"]), int(left["positive"]))
        exact_ratio *= factor
        log_factor = math.log(int(right["positive"]) / int(left["positive"]))
        log_sum += log_factor
        factors.append({
            "tick": int(left["tick"]),
            "P_t": int(left["positive"]),
            "P_next": int(right["positive"]),
            "reduced_numerator": factor.numerator,
            "reduced_denominator": factor.denominator,
            "log_A": log_factor,
        })
    endpoint_ratio = Fraction(p1, p0)
    gamma = math.log(p1 / p0)
    gamma_error = abs(gamma - log_sum)
    exact_identity = exact_ratio == endpoint_ratio
    bar_kappa = float(np.mean([row["kappa"] for row in window]))
    bar_activity = float(np.mean([row["activity"] for row in window]))
    primary = gamma > 0.0
    kappa_null = bar_kappa <= KAPPA_THRESHOLD
    activity_null = bar_activity >= ACTIVITY_THRESHOLD
    secondary = kappa_null and activity_null
    dense = bool(final_state["positive_fraction"] >= 0.9 and tail_changes == 0)
    preparation_dense = (
        (spec["family"] == "nested" and spec["arm"] == "organized_inward")
        or (spec["family"] == "compact" and spec["mode"] in ("inward", "outward"))
    )
    result = {
        "schema": "dee.v27.c04.nsh07.case.v1",
        "experiment_id": "NSH07",
        "role": "LOCKED_HOLDOUT",
        "lock_sha256": LOCK_SHA256,
        "case_id": case_id(spec),
        "spec": spec,
        "construction": construction,
        "inventory_audit": inventory,
        "observation": {
            "window_start": window_start,
            "window_end": window_end,
            "samples": expected_samples,
            "Gamma": gamma,
            "bar_kappa": bar_kappa,
            "bar_activity": bar_activity,
            "exact_scale_composition": {
                "endpoint_ratio_numerator": endpoint_ratio.numerator,
                "endpoint_ratio_denominator": endpoint_ratio.denominator,
                "product_ratio_numerator": exact_ratio.numerator,
                "product_ratio_denominator": exact_ratio.denominator,
                "exact_rational_identity": exact_identity,
                "sum_log_A": log_sum,
                "absolute_log_error": gamma_error,
            },
            "window_values_sha256": sha256_array(np.asarray([[x["positive"], x["kappa"], x["activity"]] for x in window], dtype="<f8")),
            "one_tick_factors": factors,
            "window": window,
        },
        "predictions": {
            "integrated_reproduction": primary,
            "active_interface": secondary,
            "kappa_only": kappa_null,
            "activity_only": activity_null,
            "preparation_label": preparation_dense,
        },
        "endpoint": {
            "positive_fraction_6N": float(final_state["positive_fraction"]),
            "tail_raw_changed_sites_sum": tail_changes,
            "dense": dense,
            "label": "DENSE" if dense else "NONDENSE",
        },
        "diagnostics": {"total_overflows": total_overflows},
    }
    result["content_sha256"] = canonical_hash(result)
    return result


def verify_case(path: Path, spec: dict) -> dict | None:
    if not path.is_file():
        return None
    value = json.loads(path.read_text(encoding="utf-8"))
    if value.get("case_id") != case_id(spec) or value.get("lock_sha256") != LOCK_SHA256:
        raise RuntimeError(f"foreign or stale case: {path}")
    claimed = value.pop("content_sha256", None)
    if canonical_hash(value) != claimed:
        raise RuntimeError(f"case content mismatch: {path}")
    value["content_sha256"] = claimed
    return value


def class_metrics(cases: list[dict], prediction: str) -> dict:
    truth = np.asarray([c["endpoint"]["dense"] for c in cases], dtype=bool)
    pred = np.asarray([c["predictions"][prediction] for c in cases], dtype=bool)
    tp = int(np.count_nonzero(truth & pred))
    tn = int(np.count_nonzero(~truth & ~pred))
    fp = int(np.count_nonzero(~truth & pred))
    fn = int(np.count_nonzero(truth & ~pred))
    sensitivity = tp / (tp + fn) if tp + fn else None
    specificity = tn / (tn + fp) if tn + fp else None
    return {
        "tp": tp,
        "tn": tn,
        "fp": fp,
        "fn": fn,
        "errors": fp + fn,
        "sensitivity": sensitivity,
        "specificity": specificity,
        "balanced_accuracy": None if sensitivity is None or specificity is None else (sensitivity + specificity) / 2,
    }


def adjudicate_claim(cases: list[dict], prediction: str, diversity_pass: bool, audits_pass: bool) -> dict:
    overall = class_metrics(cases, prediction)
    per_family = {family: class_metrics([c for c in cases if c["spec"]["family"] == family], prediction) for family in ("nested", "compact")}
    kappa = class_metrics(cases, "kappa_only")
    activity = class_metrics(cases, "activity_only")
    if not audits_pass or not diversity_pass:
        conditions = {"audit": audits_pass, "minimum_relevance": diversity_pass}
        verdict = "INCONCLUSIVE"
    else:
        conditions = {
            "audit": True,
            "minimum_relevance": True,
            "sensitivity_ge_0_90": overall["sensitivity"] >= 0.90,
            "specificity_ge_0_90": overall["specificity"] >= 0.90,
            "balanced_accuracy_ge_0_95": overall["balanced_accuracy"] >= 0.95,
            "errors_le_2": overall["errors"] <= 2,
            "each_family_balanced_accuracy_ge_0_90": all(v["balanced_accuracy"] is not None and v["balanced_accuracy"] >= 0.90 for v in per_family.values()),
            "increment_over_kappa_ge_0_05": overall["balanced_accuracy"] - kappa["balanced_accuracy"] >= 0.05,
            "increment_over_activity_ge_0_05": overall["balanced_accuracy"] - activity["balanced_accuracy"] >= 0.05,
        }
        verdict = "PASS" if all(conditions.values()) else "FAIL"
    return {"verdict": verdict, "metrics": overall, "per_family": per_family, "conditions": conditions, "no_refit": True}


def adjudicate(cases: list[dict]) -> dict:
    dense = [c for c in cases if c["endpoint"]["dense"]]
    nondense = [c for c in cases if not c["endpoint"]["dense"]]
    gamma_positive = [c for c in cases if c["observation"]["Gamma"] > 0]
    nested = [c for c in cases if c["spec"]["family"] == "nested"]
    compact = [c for c in cases if c["spec"]["family"] == "compact"]
    diversity = {
        "complete_worlds": len(cases),
        "family_counts": dict(Counter(c["spec"]["family"] for c in cases)),
        "endpoint_dense": len(dense),
        "endpoint_nondense": len(nondense),
        "endpoint_dense_N": sorted({c["spec"]["N"] for c in dense}),
        "endpoint_nondense_N": sorted({c["spec"]["N"] for c in nondense}),
        "Gamma_positive": len(gamma_positive),
        "Gamma_nonpositive": len(cases) - len(gamma_positive),
        "family_endpoint_counts": {
            family: dict(Counter(c["endpoint"]["label"] for c in group))
            for family, group in (("nested", nested), ("compact", compact))
        },
    }
    families_have_both = all(set(diversity["family_endpoint_counts"][f]) == {"DENSE", "NONDENSE"} for f in ("nested", "compact"))
    diversity["pass"] = (
        len(cases) == 30
        and diversity["family_counts"] == {"nested": 18, "compact": 12}
        and len(dense) >= 8
        and len(nondense) >= 8
        and len(diversity["endpoint_dense_N"]) >= 2
        and len(diversity["endpoint_nondense_N"]) >= 2
        and families_have_both
        and len(gamma_positive) >= 8
        and len(cases) - len(gamma_positive) >= 8
    )

    compact_groups: dict[int, list[dict]] = {}
    for c in compact:
        compact_groups.setdefault(int(c["spec"]["N"]), []).append(c)
    compact_matched = all(
        len(group) == 4
        and all(c["construction"]["pre_intervention_matched_hashes"] == group[0]["construction"]["pre_intervention_matched_hashes"] for c in group)
        for group in compact_groups.values()
    )
    audits = {
        "all_case_hashes_present": all(bool(c.get("content_sha256")) for c in cases),
        "all_inventory_exact": all(c["inventory_audit"]["exact"] for c in cases),
        "compact_pre_intervention_non_direction_fields_matched": compact_matched,
        "all_exact_rational_scale_identities": all(c["observation"]["exact_scale_composition"]["exact_rational_identity"] for c in cases),
        "all_log_errors_le_1e_12": all(c["observation"]["exact_scale_composition"]["absolute_log_error"] <= 1e-12 for c in cases),
        "all_observation_windows_complete": all(c["observation"]["samples"] == c["observation"]["window_end"] - c["observation"]["window_start"] + 1 for c in cases),
    }
    audits_pass = all(audits.values())
    models = {name: class_metrics(cases, name) for name in ("integrated_reproduction", "active_interface", "kappa_only", "activity_only", "preparation_label")}
    primary = adjudicate_claim(cases, "integrated_reproduction", diversity["pass"], audits_pass)
    secondary = adjudicate_claim(cases, "active_interface", diversity["pass"], audits_pass)
    return {
        "primary_verdict": primary["verdict"],
        "secondary_verdict": secondary["verdict"],
        "joint_verdict": f"PRIMARY_{primary['verdict']}_SECONDARY_{secondary['verdict']}",
        "audits": audits,
        "diversity": diversity,
        "models": models,
        "primary": primary,
        "secondary": secondary,
        "by_N": {str(n): {name: class_metrics([c for c in cases if c["spec"]["N"] == n], name) for name in ("integrated_reproduction", "active_interface")} for n in N_VALUES},
        "no_refit": True,
    }


def static_audit() -> dict:
    observed = {
        "wheel": sha256_file(nsh05.nsh02.base.WHEEL_FILE),
        "package": sha256_file(nsh05.nsh02.base.PACKAGE_FILE),
        "kernel": sha256_file(nsh05.nsh02.base.KERNEL_FILE),
    }
    planned = specs()
    checks = {
        "lock_hash_exact": LOCK.is_file() and sha256_file(LOCK) == LOCK_SHA256,
        "kernel_identity_exact": observed == EXPECTED,
        "N_exact": N_VALUES == (28, 36, 44),
        "nested_scalings_exact": SCALINGS == ("linear", "area", "volume"),
        "nested_arms_exact": NESTED_ARMS == ("organized_inward", "global_joint_inventory_shuffle"),
        "compact_modes_exact": COMPACT_MODES == ("stationary", "inward", "outward", "shuffled_outward"),
        "side_rule_exact": [side_for(n) for n in N_VALUES] == [5, 5, 7],
        "thresholds_exact": KAPPA_THRESHOLD == 5.60 and ACTIVITY_THRESHOLD == 0.50,
        "horizon_exact": HORIZON_MULTIPLIER == 6,
        "planned_worlds_exact": len(planned) == 30,
        "family_counts_exact": Counter(x["family"] for x in planned) == Counter({"nested": 18, "compact": 12}),
        "seed_namespaces_literal": "DEE-v27|C04|NSH07|nested|v1" in HERE.read_text(encoding="utf-8") and "DEE-v27|C04|NSH07|compact|v1" in HERE.read_text(encoding="utf-8"),
        "case_ids_unique": len(planned) == len({case_id(x) for x in planned}),
    }
    return {
        "schema": "dee.v27.c04.nsh07.static_audit.v1",
        "status": "PASS" if all(checks.values()) else "FAIL",
        "checks": checks,
        "observed_hashes": observed,
        "lock_sha256": LOCK_SHA256,
        "runner_sha256": sha256_file(HERE),
        "nested_preparation_sha256": sha256_file(Path(nsh05.nsh02.base.__file__)),
        "planned_cases": len(planned),
        "planned_universe_ticks": sum(int(x["horizon"]) for x in planned),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--audit-only", action="store_true")
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    audit = static_audit()
    if args.audit_only:
        print(json.dumps(audit, indent=2, sort_keys=True))
        return 0 if audit["status"] == "PASS" else 2
    if audit["status"] != "PASS" or args.threads != 1:
        raise RuntimeError(f"locked static audit failed: {audit}")
    if OUT.exists():
        raise RuntimeError(f"holdout already completed; refusing repeat: {OUT}")
    kernel, environment = verify_and_load_kernel(1)
    CASE_DIR.mkdir(parents=True, exist_ok=True)
    started = time.perf_counter()
    cases = []
    planned = specs()
    for index, spec in enumerate(planned, 1):
        path = CASE_DIR / f"{case_id(spec)}.json"
        case = verify_case(path, spec)
        resumed = case is not None
        if case is None:
            case = run_case(kernel, spec)
            atomic_json(path, case)
        cases.append(case)
        atomic_json(PROGRESS, {
            "schema": "dee.v27.c04.nsh07.progress.v1",
            "status": "RUNNING" if index < len(planned) else "CASES_COMPLETE",
            "completed": index,
            "total": len(planned),
            "last": case["case_id"],
            "last_resumed": resumed,
            "next": case_id(planned[index]) if index < len(planned) else None,
            "lock_sha256": LOCK_SHA256,
            "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        })
        print(json.dumps({
            "completed": index,
            "total": len(planned),
            "case_id": case["case_id"],
            "Gamma": case["observation"]["Gamma"],
            "bar_kappa": case["observation"]["bar_kappa"],
            "bar_activity": case["observation"]["bar_activity"],
            "primary": case["predictions"]["integrated_reproduction"],
            "secondary": case["predictions"]["active_interface"],
            "endpoint": case["endpoint"]["label"],
            "resumed": resumed,
        }), flush=True)
    adjudication = adjudicate(cases)
    result = {
        "schema": "dee.v27.c04.nsh07.holdout.v1",
        "experiment_id": "NSH07",
        "role": "LOCKED_HOLDOUT",
        "completed_utc": datetime.now(timezone.utc).isoformat(),
        "lock_path": "HOLDOUT_LOCKS/NSH07.json",
        "lock_sha256": LOCK_SHA256,
        "runner_sha256": sha256_file(HERE),
        "environment": environment,
        "static_audit": audit,
        "elapsed_seconds": time.perf_counter() - started,
        "adjudication": adjudication,
        "case_manifest": [
            {
                "case_id": c["case_id"],
                "path": str((CASE_DIR / f"{c['case_id']}.json").relative_to(ROOT)).replace("\\", "/"),
                "file_sha256": sha256_file(CASE_DIR / f"{c['case_id']}.json"),
                "content_sha256": c["content_sha256"],
                "family": c["spec"]["family"],
                "endpoint": c["endpoint"]["label"],
            }
            for c in cases
        ],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    atomic_json(PROGRESS, {
        "schema": "dee.v27.c04.nsh07.progress.v1",
        "status": "COMPLETE",
        "completed": len(cases),
        "total": len(cases),
        "joint_verdict": adjudication["joint_verdict"],
        "result_sha256": sha256_file(OUT),
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
    })
    print(json.dumps({
        "status": "COMPLETE",
        "joint_verdict": adjudication["joint_verdict"],
        "adjudication": adjudication,
        "result": str(OUT),
        "result_sha256": sha256_file(OUT),
        "elapsed_seconds": result["elapsed_seconds"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
