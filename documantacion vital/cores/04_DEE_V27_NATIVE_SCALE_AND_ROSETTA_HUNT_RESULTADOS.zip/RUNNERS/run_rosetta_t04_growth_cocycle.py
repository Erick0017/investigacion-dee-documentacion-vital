#!/usr/bin/env python3
"""Frozen formal Rosetta test for the confirmed DEE growth cocycle."""

from __future__ import annotations

import json
import sys
from pathlib import Path

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import atomic_json, canonical_hash, sha256_file


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
LOCK = ROOT / "HOLDOUT_LOCKS" / "R04_T04_GROWTH_COCYCLE.json"
LOCK_SHA256 = "4d2bb1371e3961a5d9f5c6963a8bf2302a50f4d321c1f2e6fe89aa39932f0a0f"
NSH07 = ROOT / "RESULTS" / "NSH07_results.json"
NSH07_SHA256 = "405b2f068e0078ae6854f148eabeb2c936136099020b5267553fd3c19121a3ae"
OUT = ROOT / "RESULTS" / "R04_T04_growth_cocycle.json"


def load_canonical(path: Path) -> tuple[dict, bool]:
    value = json.loads(path.read_text(encoding="utf-8"))
    claimed = value.pop("content_sha256", None)
    valid = claimed is not None and canonical_hash(value) == claimed
    value["content_sha256"] = claimed
    return value, valid


def main() -> int:
    if OUT.exists():
        raise RuntimeError("R04 T04 already complete; refusing repeat")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    native, native_canonical = load_canonical(NSH07)
    case_checks = []
    for item in native["case_manifest"]:
        path = ROOT / item["path"]
        case, canonical = load_canonical(path)
        scale = case["observation"]["exact_scale_composition"]
        exact = (
            scale["exact_rational_identity"]
            and scale["endpoint_ratio_numerator"] == scale["product_ratio_numerator"]
            and scale["endpoint_ratio_denominator"] == scale["product_ratio_denominator"]
            and scale["absolute_log_error"] <= 1e-12
        )
        case_checks.append({
            "case_id": item["case_id"],
            "file_sha256_matches_manifest": sha256_file(path) == item["file_sha256"],
            "content_sha256_matches_manifest": case["content_sha256"] == item["content_sha256"],
            "canonical_content_valid": canonical,
            "exact_multiplicative_and_log_additive_composition": exact,
        })
    checks = {
        "lock_hash_exact": sha256_file(LOCK) == LOCK_SHA256,
        "sealed_native_result_hash_exact": sha256_file(NSH07) == NSH07_SHA256,
        "sealed_native_result_canonical": native_canonical,
        "sealed_native_primary_PASS": native["adjudication"]["primary_verdict"] == "PASS",
        "thirty_cases": len(case_checks) == 30,
        "both_families_and_classes": native["adjudication"]["diversity"]["pass"],
        "all_case_audits": all(all(v for k, v in row.items() if k != "case_id") for row in case_checks),
        "zero_mapping_parameters": lock["parameters"].startswith("Zero fitted"),
        "no_external_dictionary_claimed": "not a physical ontology" in lock["claim"],
    }
    formal_pass = all(checks.values())
    result = {
        "schema": "dee.v27.c04.rosetta_t04.v1",
        "target_id": "R04-T04-FINITE-TIME-GROWTH-COCYCLE",
        "role": "FROZEN_FORMAL_TARGET_TEST_ON_SEALED_NATIVE_RESULT",
        "lock_sha256": LOCK_SHA256,
        "runner_sha256": sha256_file(HERE),
        "native_result_sha256": NSH07_SHA256,
        "checks": checks,
        "case_checks": case_checks,
        "formal_target_verdict": "PASS" if formal_pass else "FAIL",
        "rosetta_status": "FORMAL_EQUIVALENCE_CANDIDATE" if formal_pass else "REJECTED",
        "rosetta_validated": False,
        "external_prediction": False,
        "physical_gate": "BLOCKED_EXTERNAL_PREPARATION_READOUT_AND_DIMENSIONAL_CALIBRATION",
        "interpretation": "The same zero-parameter multiplicative/additive map is exact for DEE support reproduction and a finite-time growth process. Telescoping is generic; DEE-specific content lies in the S/R/C/X one-step factors and their confirmed bounded-domain basin prediction. No observable physical population, unit or measurement operator has been identified.",
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"status": "COMPLETE", "formal_target_verdict": result["formal_target_verdict"], "rosetta_status": result["rosetta_status"], "result": str(OUT), "result_sha256": sha256_file(OUT)}, indent=2, sort_keys=True))
    return 0 if formal_pass else 2


if __name__ == "__main__":
    raise SystemExit(main())
