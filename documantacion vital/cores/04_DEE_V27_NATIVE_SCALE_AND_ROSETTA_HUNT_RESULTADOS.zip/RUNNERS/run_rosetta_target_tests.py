#!/usr/bin/env python3
"""Apply the frozen Campaign-04 Rosetta targets without target refitting."""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
import run_nsh02_temporal_holdout as nsh02
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, sha256_file, verify_and_load_kernel


ROOT = Path(__file__).resolve().parents[1]
TARGETS = ROOT / "ROSETTA_TARGETS.json"
TARGETS_SHA256 = "d3e64dc1fa8eb2b0983451af4f75c70483810e7197c2a47d27dee36f02bedf9b"
OUTPUT = ROOT / "RESULTS" / "R04_rosetta_tests.json"


def explicit_boundary(mask: np.ndarray) -> int:
    n = mask.shape[0]
    count = 0
    for i in range(n):
        for j in range(n):
            for k in range(n):
                value = bool(mask[i, j, k])
                count += value != bool(mask[(i + 1) % n, j, k])
                count += value != bool(mask[i, (j + 1) % n, k])
                count += value != bool(mask[i, j, (k + 1) % n])
    return int(count)


def test_perimeter() -> dict:
    tests = []
    n = 11
    analytic = []
    empty = np.zeros((n, n, n), dtype=bool)
    analytic.append(("empty", empty, 0))
    full = np.ones((n, n, n), dtype=bool)
    analytic.append(("full", full, 0))
    single = empty.copy(); single[5, 5, 5] = True
    analytic.append(("single", single, 6))
    cuboid = empty.copy(); cuboid[2:4, 3:6, 4:8] = True
    analytic.append(("cuboid_2x3x4", cuboid, 2 * (2 * 3 + 2 * 4 + 3 * 4)))
    for name, mask, expected in analytic:
        observed = nsh02.base.boundary_faces(mask)
        explicit = explicit_boundary(mask)
        tests.append({"id": name, "expected": expected, "observer_B6": observed, "explicit_boundary": explicit, "pass": expected == observed == explicit})
    for n in (5, 7, 11):
        for rep in range(8):
            seed = int.from_bytes(hashlib.sha256(f"R04-T01|N={n}|rep={rep}".encode()).digest()[:8], "little")
            rng = np.random.default_rng(seed)
            mask = rng.random((n, n, n)) < (0.1 + 0.1 * (rep % 6))
            observed = nsh02.base.boundary_faces(mask)
            explicit = explicit_boundary(mask)
            p = int(mask.sum())
            degree_sum = sum(int(np.count_nonzero(mask & np.roll(mask, shift, axis=axis))) for axis in range(3) for shift in (-1, 1))
            mean_degree = degree_sum / p if p else None
            identity = p == 0 or abs((6.0 - observed / p) - mean_degree) < 1e-12
            tests.append({"id": f"random_N{n}_r{rep}", "P": p, "observer_B6": observed, "explicit_boundary": explicit, "mean_degree_identity": identity, "pass": observed == explicit and identity})
    passed = all(x["pass"] for x in tests)
    return {
        "target_id": "R04-T01-CUBIC-EDGE-PERIMETER", "tests": len(tests), "all_pass": passed,
        "result": "FORMAL_EQUIVALENCE_CANDIDATE" if passed else "FAIL",
        "exact_mapping": "B6=#edge_boundary; kappa=B6/P; for lattice spacing ell, surface/occupied-volume=kappa/ell",
        "physical_status": "No support-to-matter or ell-to-length dictionary was supplied, so this is not ROSETTA_VALIDATED.",
        "details": tests,
    }


def direction_counterexample(kernel) -> dict:
    n = 9
    raw_stationary = np.zeros((n, n, n), dtype=np.uint64)
    raw_outward = np.zeros_like(raw_stationary)
    clock = np.zeros_like(raw_stationary)
    center = np.asarray([n // 2] * 3)
    for i in range(center[0] - 1, center[0] + 2):
        for j in range(center[1] - 1, center[1] + 2):
            for k in range(center[2] - 1, center[2] + 2):
                raw_stationary[i, j, k] = pack(1, 1, (0, 0, 0), 1)
                delta = np.sign(np.asarray([i, j, k]) - center).astype(int)
                direction = tuple(int(x) for x in delta)
                raw_outward[i, j, k] = pack(1, 1, direction, 1)
    support_before_equal = np.array_equal(fields(raw_stationary)["state"] != 0, fields(raw_outward)["state"] != 0)
    ws = NativeWorld(kernel, raw_stationary, clock, 1)
    wo = NativeWorld(kernel, raw_outward, clock, 1)
    info_s = ws.tick(); info_o = wo.tick()
    support_s = fields(ws.raw)["state"] != 0
    support_o = fields(wo.raw)["state"] != 0
    return {
        "N": n, "same_initial_support": support_before_equal, "same_initial_clock": True,
        "stationary_initial_positive": 27, "outward_initial_positive": 27,
        "stationary_next_positive": int(support_s.sum()), "outward_next_positive": int(support_o.sum()),
        "next_support_equal": bool(np.array_equal(support_s, support_o)),
        "stationary_next_support_sha256": sha256_array(support_s), "outward_next_support_sha256": sha256_array(support_o),
        "stationary_kernel": info_s, "outward_kernel": info_o,
        "counterexample": support_before_equal and not np.array_equal(support_s, support_o),
    }


def test_balance(kernel) -> dict:
    nsd09 = json.loads((ROOT / "ANALYSIS" / "NSD09_cross_level_balance.json").read_text(encoding="utf-8"))
    exact = nsd09["exact_law"]
    quant = nsd09["quantification"]
    counterexample = direction_counterexample(kernel)
    nonconservative_rows = 0
    for group in ("q_lt_0_01", "q_0_01_to_0_10", "q_ge_0_10"):
        # The detailed row table is not persisted; the exact total net already
        # decides global conservation. Count phase groups with nonzero net.
        nonconservative_rows += int(quant["phase_bins"][group]["total_net_change"] != 0)
    balance_pass = exact["audited_transitions"] == 222 and not exact["identity_failures"]
    autonomous_support = not counterexample["counterexample"]
    return {
        "target_id": "R04-T02-REACTION-COLONIZATION-BALANCE",
        "exact_birth_death_balance": balance_pass,
        "routed_fraction_of_births": quant["routed_fraction_of_all_births"],
        "phase_bins_with_nonzero_global_net_support": nonconservative_rows,
        "same_support_different_direction_counterexample": counterexample,
        "conservative_transport_classification": "FAIL",
        "autonomous_binary_contact_process_classification": "FAIL" if not autonomous_support else "NOT_FALSIFIED",
        "reaction_colonization_classification": "FORMAL_EQUIVALENCE_CANDIDATE" if balance_pass else "FAIL",
        "result": "STRUCTURAL_ANALOGY_WITH_EXACT_BALANCE_NOT_STRONG_ROSETTA" if balance_pass and counterexample["counterexample"] else "FAIL",
        "reason": "DEE has an exact operational death/birth/colonization balance, but routing is not a conservative flux and the binary support projection is not Markov-sufficient; direction changes the next support at fixed current support.",
    }


def test_quadratic_flow() -> dict:
    nsh05 = json.loads((ROOT / "RESULTS" / "NSH05_results.json").read_text(encoding="utf-8"))
    nsd10 = json.loads((ROOT / "ANALYSIS" / "NSD10_recursive_closure.json").read_text(encoding="utf-8"))
    nsd11 = json.loads((ROOT / "ANALYSIS" / "NSD11_generator_search.json").read_text(encoding="utf-8"))
    nsd12 = json.loads((ROOT / "ANALYSIS" / "NSD12_logit_semigroup.json").read_text(encoding="utf-8"))
    algebraic_match = nsh05["adjudication"]["verdict"] == "PASS"
    recursive = nsd10["aggregate"]["dense_flow"]
    invariant = nsd10["fixed_points"]["locally_stable_under_literal_discrete_iteration"] and recursive["worlds_with_any_out_of_bounds_prediction"] == 0
    composable = recursive["mean_world_skill"] >= 0.65 and recursive["fraction_beating_initial_persistence"] >= 0.85
    alternatives = bool(nsd11["candidate_worthy"] or nsd12["candidate_worthy"])
    strong_pass = algebraic_match and invariant and composable
    return {
        "target_id": "R04-T03-CLOSED-QUADRATIC-FLOW",
        "algebraic_monomial_match": algebraic_match,
        "one_step_native_holdout": "PASS",
        "recursive_dense_mean_skill": recursive["mean_world_skill"],
        "recursive_dense_fraction_beating_persistence": recursive["fraction_beating_initial_persistence"],
        "recursive_out_of_bounds_worlds": recursive["worlds_with_any_out_of_bounds_prediction"],
        "dense_fixed_point": nsd10["fixed_points"]["dense_physical_fixed_point"],
        "fixed_point_jacobian_eigenvalues": nsd10["fixed_points"]["one_step_jacobian_eigenvalues_at_dense_fixed_point"],
        "any_composable_generator_candidate": alternatives,
        "result": "FORMAL_EQUIVALENCE_CANDIDATE" if algebraic_match else "FAIL",
        "strong_target_verdict": "PASS" if strong_pass else "FAIL",
        "rosetta_status": "FORMAL_EQUIVALENCE_CANDIDATE_NOT_EXTERNAL_COMPATIBILITY",
        "reason": "The frozen DEE map has exactly the target polynomial form, but fails invariant recursive composition and no continuous/logit generator passed discovery.",
    }


def main() -> None:
    if sha256_file(TARGETS) != TARGETS_SHA256:
        raise RuntimeError("Rosetta target file changed after freeze")
    if OUTPUT.exists():
        raise RuntimeError("Rosetta target result already exists; refusing to repeat")
    kernel, environment = verify_and_load_kernel(1)
    results = [test_perimeter(), test_balance(kernel), test_quadratic_flow()]
    output = {
        "schema": "dee.v27.c04.rosetta_tests.v1", "role": "FROZEN_TARGET_TEST",
        "target_file_sha256_before_test": TARGETS_SHA256, "environment": environment, "results": results,
        "highest_status": "FORMAL_EQUIVALENCE_CANDIDATE",
        "rosetta_validated": False,
        "external_prediction": False,
        "global_verdict": "No strong physical Rosetta. One exact mathematical geometry map and two structural/formal class correspondences survive; preparation/readout identifiability and composable effective dynamics do not.",
    }
    output["content_sha256"] = canonical_hash(output)
    atomic_json(OUTPUT, output)
    print(json.dumps({"output": str(OUTPUT), "file_sha256": sha256_file(OUTPUT), "content_sha256": output["content_sha256"], "results": results, "global_verdict": output["global_verdict"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
