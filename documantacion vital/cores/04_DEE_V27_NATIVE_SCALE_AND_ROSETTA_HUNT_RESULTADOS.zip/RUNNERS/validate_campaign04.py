#!/usr/bin/env python3
"""One final non-scientific integrity validation for Campaign 04."""

from __future__ import annotations

import json
import sys
from pathlib import Path

RUNNER_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(RUNNER_DIR))
from native_core import WHEEL_FILE, atomic_json, canonical_hash, sha256_file


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
TESTS = ROOT.parent
OUT = ROOT / "RESULTS" / "CAMPAIGN04_VALIDATION.json"

REQUIRED = (
    "FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "STATE.json", "SCIENCE_LOG.ndjson", "CLAIMS.json",
    "ROSETTA_TARGETS.json", "NATIVE_LAWS_DISCOVERED.md", "HIERARCHY_DISCOVERED.md",
    "CAUSAL_ARCHITECTURE.md", "SCALE_LAWS.md", "COARSE_GRAINING.md", "FORMULA_DISCOVERY.md",
    "ROSETTA_SEARCH.md", "ROSETTA_CANDIDATES.md", "NEGATIVE_RESULTS.md", "WEAK_SIGNALS.md",
    "OPEN_GAPS.md", "REPRODUCE.ps1",
)
EXPECTED_PARENTS = {
    TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "ROSETTA_CLOSURE" / "DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "MULTISCALE_ROSETTA_CLOSURE" / "DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
}
EXPECTED_LOCKS = {
    "NSH01.json": "81d6efd8888a5fd3b15e0f78bb73c395f5067712d74e8dd121e9482d0f06f786",
    "NSH02.json": "e73395a67383510a7bb40d3bce1d89118a046f218d98cbead39c8a554a05de7c",
    "NSH03.json": "50fead5579fee9ca15acfde8eab1744ad8cca6a9503f6a945f3238de03cc721b",
    "NSH04.json": "ac510053f99484c80d0367ce08b80dedbe8be558eea41b52c52b8df06610e295",
    "NSH05.json": "238d25ec220181b9ef5bf32d5f393cbc1823cfb7367410c079b20203a77fb00a",
    "NSH06.json": "60cc134de7615423380f63cdeadfccc54d8ea637882e91acaf0f3f98af5b1acf",
    "NSH07.json": "80a4b3cff667c9da67d0c76e47954607471645ff68a2e0bc7f094465155f1b24",
    "R04_T04_GROWTH_COCYCLE.json": "4d2bb1371e3961a5d9f5c6963a8bf2302a50f4d321c1f2e6fe89aa39932f0a0f",
}
CRITICAL_RESULTS = {
    "NSH02_results.json": "c86acd347a9ab0c75fd69c23498d5fed56ef9f5474d477c713c1a3a3f6eb5361",
    "NSH05_results.json": "3b1b7e50978f2adfe24963583b0a0d12527a98ba4cc053a6973a575f09f33445",
    "NSH06_results.json": "468218da487b45d688a2c3841af97ac80a3b66c4833386abe5b74792e4d316a1",
    "NSH07_results.json": "405b2f068e0078ae6854f148eabeb2c936136099020b5267553fd3c19121a3ae",
    "R04_rosetta_tests.json": "a00831ae344d03c0b0311298026bc8f3e5be491b0058302ea6ac8e7d06d2dad5",
    "R04_T04_growth_cocycle.json": "885039cd84b92074339bc13d2463e0a1beca2972f9f52cddd535953f9eab08b2",
}


def canonical_valid(path: Path) -> tuple[bool, str | None]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        return True, None
    claimed = value.pop("content_sha256", None)
    if claimed is None:
        return True, None
    return canonical_hash(value) == claimed, claimed


def main() -> int:
    failures = []
    parsed_json = 0
    canonical_checked = 0
    for name in REQUIRED:
        if not (ROOT / name).is_file():
            failures.append(f"missing required artifact: {name}")
    for path in ROOT.rglob("*.json"):
        if path == OUT:
            continue
        try:
            valid, claimed = canonical_valid(path)
            parsed_json += 1
            if claimed is not None:
                canonical_checked += 1
                if not valid:
                    failures.append(f"canonical content hash mismatch: {path.relative_to(ROOT)}")
        except Exception as exc:
            failures.append(f"invalid JSON {path.relative_to(ROOT)}: {exc}")
    log_lines = 0
    for index, line in enumerate((ROOT / "SCIENCE_LOG.ndjson").read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            json.loads(line); log_lines += 1
        except Exception as exc:
            failures.append(f"invalid science log line {index}: {exc}")
    parent_checks = {}
    for path, expected in EXPECTED_PARENTS.items():
        actual = sha256_file(path) if path.is_file() else None
        parent_checks[str(path)] = {"expected": expected, "actual": actual, "pass": actual == expected}
        if actual != expected:
            failures.append(f"parent identity mismatch: {path}")
    wheel_hash = sha256_file(WHEEL_FILE) if WHEEL_FILE.is_file() else None
    if wheel_hash != "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939":
        failures.append("wheel identity mismatch")
    lock_checks = {}
    for name, expected in EXPECTED_LOCKS.items():
        path = ROOT / "HOLDOUT_LOCKS" / name
        actual = sha256_file(path) if path.is_file() else None
        lock_checks[name] = {"expected": expected, "actual": actual, "pass": actual == expected}
        if actual != expected:
            failures.append(f"lock mismatch: {name}")
    critical_checks = {}
    for name, expected in CRITICAL_RESULTS.items():
        path = ROOT / "RESULTS" / name
        actual = sha256_file(path) if path.is_file() else None
        critical_checks[name] = {"expected": expected, "actual": actual, "pass": actual == expected}
        if actual != expected:
            failures.append(f"critical result mismatch: {name}")
    progress_checks = {}
    for path in (ROOT / "RESULTS").glob("*progress*.json"):
        status = json.loads(path.read_text(encoding="utf-8")).get("status")
        progress_checks[path.name] = status
        if status != "COMPLETE":
            failures.append(f"incomplete progress: {path.name}={status}")
    state = json.loads((ROOT / "STATE.json").read_text(encoding="utf-8"))
    claims = json.loads((ROOT / "CLAIMS.json").read_text(encoding="utf-8"))
    nsh07 = json.loads((ROOT / "RESULTS" / "NSH07_results.json").read_text(encoding="utf-8"))
    semantic_checks = {
        "state_complete": state.get("status") == "CAMPAIGN04_COMPLETE_READY_TO_SEAL",
        "no_pending_holdout": state.get("pending_holdout") is None,
        "NSH07_joint_PASS": nsh07["adjudication"]["joint_verdict"] == "PRIMARY_PASS_SECONDARY_PASS",
        "claim_ids_unique": len(claims) == len({row["id"] for row in claims}),
        "all_holdout_progress_complete": all(v == "COMPLETE" for v in progress_checks.values()),
    }
    for key, passed in semantic_checks.items():
        if not passed:
            failures.append(f"semantic check failed: {key}")
    result = {
        "schema": "dee.v27.c04.final_validation.v1",
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "required_artifacts": len(REQUIRED),
        "json_files_parsed": parsed_json,
        "canonical_content_hashes_checked": canonical_checked,
        "science_log_lines": log_lines,
        "wheel_sha256": wheel_hash,
        "parent_checks": parent_checks,
        "lock_checks": lock_checks,
        "critical_result_checks": critical_checks,
        "progress_checks": progress_checks,
        "semantic_checks": semantic_checks,
        "validator_sha256": sha256_file(HERE),
        "scientific_reruns": 0,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"status": result["status"], "failures": failures, "json_files_parsed": parsed_json, "canonical_content_hashes_checked": canonical_checked, "result": str(OUT), "result_sha256": sha256_file(OUT)}, indent=2, sort_keys=True))
    return 0 if not failures else 2


if __name__ == "__main__":
    raise SystemExit(main())
