# Leyes de escala

## Escala temporal exacta

Para `P_t>0`, los factores de reproducción forman un cociclo multiplicativo:

`A_t^(h)=A_t A_(t+1)...A_(t+h-1)=P_(t+h)/P_t`.

Su logaritmo es aditivo. Esto permite coarse-graining temporal sin error para el conteo acumulado si se conservan todos los factores o sus extremos. No predice el factor futuro desde `P_t`: exactitud de composición no equivale a cierre dinámico.

La descomposición específica de DEE es

`A_t=(S_t+R_t+C_t+X_t)/P_t`.

Por tanto la ley entre Q1 y Q3 es exacta: eventos causales de Q1 se agregan en una coordenada histórica Q3.

## Escala espacial

`B6` es exactamente el edge perimeter del soporte en el toro cúbico y `kappa=B6/P` es perímetro específico adimensional. Para spacing externo hipotético `ell`, área/volumen ocupado sería `kappa/ell`; `ell` no está identificado físicamente.

La normalización por `P` estabilizó la puerta nested-shell a través de varios N. NSH07 extendió la combinación `(kappa,a)` a `N={28,36,44}` y dos familias. La dosis escasa mostró, sin embargo, que no existe un umbral absoluto de número de routers independiente de N/orientación en el panel probado.

## Flujo finito a lag N/8

El mapa NSH05 de seis coeficientes predice incrementos de `(q,kappa/6)` a un lag proporcional a N y pasó holdout entre N. Es evidencia de similitud de escala local y de dos sectores, no de renormalización autónoma.

## Pruebas de composición

Al iterar el mapa denso cinco veces desde `N/2`, NSD10 obtuvo skill medio -2.1013, sólo 8/10 mundos mejores que persistencia y tres salidas fuera de dominio. El fixed point algebraico `(0.992914,0)` tiene eigenvalor `-1.62121`, inestable para el mapa literal.

NSD11 probó generadores cuadráticos continuos y un generador mecanicista; produjeron blowups o salidas fuera de dominio. NSD12 probó un semigrupo affine-logit acotado; su skill cross-N medio fue negativo. Ningún candidato se congeló.

## Cierre de escala

No se cumple `SCALE_CLOSURE` porque:

- el microdetalle todavía mejora y puede cambiar la predicción;
- parámetros efectivos no convergen a un operador autónomo;
- la recursión no conserva el dominio;
- el mismo soporte/interfaz con distinta dirección cambia el futuro;
- `Gamma` requiere historia realizada y no genera por sí solo el siguiente `Gamma`.

Sí se alcanza una forma más débil y específica: composición temporal exacta, ley local de escala confirmada y clase de historia predictiva acotada.

