# Señales débiles dormantes

## Interfaz temprana NSH01

`kappa(t=N/4)` retuvo especificidad 0.9804 y BA 0.8711 y superó a `q` temprano, pero falló sensibilidad y ventaja sobre brazo. Sólo evidencia mecanística independiente puede reactivarla; no se repite el corte 5.35.

## Profundidad por soporte

`bar_q>=0.0290` obtuvo BA 0.9167 y un error en dos paneles de respuesta, pero sensibilidad 0.8333 falló el contrato. La rama de threshold está cerrada.

## Corte de magnitud Gamma

En NSD15, máximo `Gamma` nondense 0.16654 y mínimo dense 0.17050 dejaron un hueco 0.00396. Es post-hoc, estrecho, sin origen natural y sensible al contexto; se conserva como `WEAK_SIGNAL_DORMANT`, no como fórmula candidata.

## Crecimiento monotónico por dosis

Cada track de bloques compactos fue monotónico en endpoint al aumentar routers. Los conteos críticos no coincidieron y, por tanto, no hay threshold universal. Podría reactivarse con una variable relacional de destino/multiplicidad que explique los cuatro valores sin nuevos cortes por caso.

Ninguna señal dormante se usa en Rosetta ni reinicia estancamiento.

