# De descubrimiento a posible tecnología

## Descubrimiento relevante

DEE implementa un transductor determinista de diferencia temporal a lugar y una memoria distribuida de fase. Ambos usan el mismo sustrato: carriers dirigidos, rutas, coincidencia por fibra y resolución local. El resultado está confirmado como capacidad nativa acotada; no se ha demostrado ventaja tecnológica.

## Qué permite hoy

- discriminar `K` retardos enteros mediante `K` canales;
- producir una salida categórica exacta en background limpio;
- concatenar varias estaciones de medida;
- retener una perturbación transitoria como fase distribuida;
- predecir un tiempo de reaparición condicionado por topología para tamaños pares.

La capacidad demostrada es `log2(K)` bits para inputs balanceados, con `K=7,11,13` en etapas independientes. El coste preparado observado es lineal en canales y carriers.

## Qué no permite afirmar

No se midieron consumo energético físico, densidad de hardware, jitter, ruido analógico, capacidad asintótica, tolerancia a fallos aleatorios, ventaja sobre circuitos de coincidencia, entrenamiento, aprendizaje o utilidad externa. Un algoritmo convencional puede resolver el benchmark trivialmente.

## Programa mínimo antes de aplicación

1. Congelar un modelo de ruido y medir curvas accuracy–jitter y accuracy–densidad.
2. Comparar con lógica digital, delay lines y reservorios simples bajo igual presupuesto.
3. Medir fan-in, interferencia entre canales y profundidad de cascada.
4. Buscar una tarea nativa donde fase/topología aporte una transformación difícil para el baseline.
5. Sólo si aparece una ventaja, diseñar un transductor físico label-blind y un holdout externo.
6. Verificar que la dinámica intacta supere encoder-only y DEE destruida.

## Riesgo principal

La exactitud actual depende de geometría preparada y background limpio. La propia no asociatividad del resolvedor reducido y las guardas de ocupación pueden introducir crosstalk en redes densas. La memoria confirmada es pérdida funcional equivalente a ablación, no corrección de error.

## Clasificación

`NATIVE_COMPUTATIONAL_DISCOVERY_BOUNDED`.

`POTENTIAL_TECHNOLOGICAL_DISCOVERY`: no promovido; sólo ruta de investigación plausible.
