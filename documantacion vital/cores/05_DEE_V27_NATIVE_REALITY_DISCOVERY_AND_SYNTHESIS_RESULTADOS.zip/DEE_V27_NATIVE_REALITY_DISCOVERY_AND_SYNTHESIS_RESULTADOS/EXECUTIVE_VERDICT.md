# Veredicto ejecutivo

## Veredicto central

`F_DEE` construye una realidad operacional no reducible a inventarios escalares: propuestas dirigidas se agrupan por destino, un resolvedor local con guardas transforma cada fibra de propuestas, y las historias de fase/topología determinan qué organizaciones y registros sobreviven. El conjunto pequeño que más fenómenos comprime es:

1. aristas dirigidas de propuesta y sus longitudes/fases;
2. fibras de destino y multiplicidad de llegadas;
3. resolvedor local `R` más guardas de ocupación/semántica;
4. historia retenida por fase, exclusión y recurrencia;
5. órbitas periódicas y paridad topológica;
6. relación sistema–sonda–puerto como observador.

Ese núcleo explica transporte, colisión, medición, integración, memoria distribuida, observadores encadenados y el único candidato Rosetta congelado. No se encontró un `Q4` global ni se necesita inventarlo para expresar estos resultados.

## Resultados promovidos

- `RELATIONAL_CLOSURE_FOUND`, estrictamente sectorial y de un paso: el estado de fibra `Z[y]=(m_y,V_y,S_y)` reconstruyó 200/200 arrays `raw` completos en holdout.
- `INTERNAL_OBSERVER_FOUND` e `INTERNAL_MEASUREMENT_FOUND`, acotados: una sonda y su puerto resolvieron 80/80 interacciones; el shuffle temporal produjo 0/320 falsos registros.
- `NATIVE_COMPUTATIONAL_DISCOVERY`, acotado: una banca de detectores transdujo once retardos relativos a once lugares con 44/44 aciertos y 3.459 bits; el control con calibración destruida obtuvo 4/44.
- `NEW_NATIVE_PHENOMENON_FOUND`: una obstrucción local transitoria dejó memoria distribuida de fase en 40/40 comparaciones, aunque la fuente siguió existiendo.
- `RECURSIVE_OBSERVER_LAW_FOUND`, finito: el mismo operador predijo una cuarta capa observacional no usada en discovery, con 100/100 registros exactos y 0/200 falsos en controles.
- `TOPOLOGY_HISTORY_PARITY_LAW_FOUND`, acotado: 24/24 predicciones prospectivas; para `N` par, primera divergencia a `N+L`; para `N` impar, ninguna divergencia hasta `3N+L`.
- `FROZEN_ROSETTA_CANDIDATE`: equivalencia formal entre el transductor DEE de retardo-a-lugar y un proceso ideal de líneas de retardo, coincidencia y código de lugar; 39/39 casos nuevos, Spearman 1.0.

## Cobertura obligatoria

| Bloque | Adjudicación |
|---|---|
| A. Observador causal relacional | PASS acotado; NRH01 y cierre sectorial NRH03 |
| B. Medición interna | PASS acotado; dirección, `s_reg` censurado y retardo relativo |
| C. Procesamiento nativo | PASS acotado; integración por coincidencia y retardo-a-lugar |
| D. Familia tipo cerebro | Correspondencia funcional parcial; no identidad ni familia completa |
| E. Familia tipo planta | Correspondencia funcional parcial; no adaptación, crecimiento ni homeostasis |
| F. Propagación | Ley de portador acotada; no análogo de luz completo |
| G. Emergencia termodinámica | Balance sectorial e irreversibilidad lógica; no termodinámica física |
| H. Rosetta phenomenon-first | Candidato formal congelado; no validación externa |
| I. Ley recursiva de escala | Recursión observacional finita PASS; coarse-graining direccional FAIL |

## Negativos decisivos

El inventario global, occupancy y `(q,kappa,a,Gamma)` no cierran la dinámica completa. La reducción direccional no es asociativa. La entropía macro elegida no es monótona. No apareció velocidad euclídea isotrópica, reflexión, dispersión ni interferencia. No aparecieron aprendizaje, reparación, regulación homeostática, temperatura física ni predicción externa. Cada negativo se limita a su representación y dominio; ninguno se generaliza a una imposibilidad ontológica global.

## Qué realidad nativa queda justificada

DEE forma procesos con identidad relacional y de historia, más que objetos definidos por una etiqueta local. Un portador conserva linaje en vuelo libre, pero una colisión puede consumirlo. Una fuente puede persistir mientras su contribución efectiva queda borrada por desfasaje. Un observador no es un registro especial: es otra organización cuya interacción convierte una relación temporal en un estado legible. La medida es por tanto `m=M_B(A)`, no un campo escondido en `A`.

## Frontera exacta bajo H_DEE

Falta un puente empírico bidireccional independiente:

`preparación física -> ensemble Q0 -> historia efectiva DEE -> detector -> registro físico`.

Esta campaña resolvió componentes internos de historia y detector. No identificó cómo una preparación física real selecciona ensembles `Q0`, ni cómo el registro DEE se calibra contra datos físicos independientes con una predicción nueva. Sin esos dos mapas, la Rosetta permanece formal y `H_DEE` no está validada como descripción de nuestra realidad.

## Cierre

Se alcanzó el stopping rule: los nueve bloques recibieron pruebas informativas, seis afirmaciones centrales pasaron holdout congelado y las preguntas restantes cambian de clase sólo con cierre global/asintótico o evidencia externa. Repetir tamaños, profundidades o seeds casi idénticos no elevaría el nivel epistemológico.
