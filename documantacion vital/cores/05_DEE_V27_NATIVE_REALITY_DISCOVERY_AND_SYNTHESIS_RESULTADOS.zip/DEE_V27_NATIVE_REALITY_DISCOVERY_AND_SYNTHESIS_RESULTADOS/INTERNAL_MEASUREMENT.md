# Medición interna

## Principio

Una magnitud nativa no tiene que existir como registro individual. Se define por preparación, interacción y respuesta del detector:

`m = M_B(A)`.

La campaña encontró tres lecturas dentro de un mismo aparato relacional.

## Medida categórica de dirección

Con sonda fija `d_B=(0,1,0)` y ocho clases target en el plano transversal, la respuesta fusionada permite recuperar

`d_A=(d_out.x,0,d_out.z)`.

NRH01 obtuvo 80/80 decodificaciones y 3 bits. El mismo inventario fuera de fase no produjo el registro. Se mide una relación de llegada y contenido direccional, no un supuesto momentum físico.

## Medida de `s_reg`

Debajo de saturación,

`s_A=s_out-s_B`.

Con `s_B` conocido, el detector puede inferir el registro target. Cuando `s_A+s_B>=19664`, sólo se observa el cap: distintos valores altos quedan en la misma clase. La medida es censurada y no convierte `s_reg` en energía.

## Escala nativa de retardo

Una banca de once canales contiene pares de rutas. Para un input con offset `delta`, la ruta target llega al tiempo `L+delta`; el probe del canal `j` llega a `L+j`. Existe colisión sólo si `j=delta`. La definición congelada fue

`m_B(A)=etiqueta del único canal con firma fusionada`.

Holdout NRH05:

- rango: `delta=-5,...,+5`;
- cuatro frames y tamaños no vistos;
- 44/44 lecturas exactas;
- cada clase 4/4;
- `I(delta;m)=log2(11)=3.4594` bits;
- calibración invertida: 4/44 = 1/11;
- target ausente: 4/4 sin registro;
- puertos vacíos antes de evolución: 44/44;
- límite inferior Wilson: 0.9197.

El control invertido preserva carriers, número de canales y etiquetas, pero rompe la correspondencia ruta–lugar. Por tanto, la dinámica y geometría relacional, no una lectura directa del encoder, causan el resultado.

## Robustez e invariancias

El resultado sobrevivió cambios de `N`, traslación, orientación, signos, seeds, valores positivos de `state`, clocks independientes y regímenes con/sin saturación. Es invariante a esas variaciones dentro del diseño, no universal.

## Metrología nativa

La escala tiene cero y orden definidos por la calibración relacional del banco. Sus unidades son offsets enteros de actualización del kernel. No se identificaron segundos, metros o una constante dimensional. La medida existe internamente aun sin traducción SI, del mismo modo que una escala instrumental puede preceder a una teoría externa.

## Medición como transformación

El detector no copia un valor intacto: fusiona entradas y emite una nueva portadora. La lectura conserva una función de la preimagen y pierde otra información. Esto enlaza medición y procesamiento, y explica por qué la información accesible depende del observador/coarse-graining.

## Lo no demostrado

No hay calibración con un sistema físico real, back-action cuántico, regla de Born, observador consciente, medida universal de tiempo ni lectura no destructiva. Es una medición operacional interna en dominios congelados.
