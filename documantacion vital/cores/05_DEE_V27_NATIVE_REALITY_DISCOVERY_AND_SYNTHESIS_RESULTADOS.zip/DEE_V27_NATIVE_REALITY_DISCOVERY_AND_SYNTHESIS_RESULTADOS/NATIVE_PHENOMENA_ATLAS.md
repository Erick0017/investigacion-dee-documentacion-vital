# Atlas de fenómenos nativos

| Fenómeno | Función nativa | Evidencia | Estatus | Límite principal |
|---|---|---|---|---|
| Portador dirigido | Transporta estado de carrier por una ruta | NRD00/NRD03 | Soportado en sector | No partícula física; velocidad euclídea anisotrópica |
| Fibra de destino | Agrupa propuestas causalmente equivalentes para el siguiente tick | NRH03 200/200 | Exacto sectorial | Requiere guardas; raw de un paso |
| Resolvedor de colisión | Integra suma vectorial y `s_reg` con cap | Padres + NRH01/03 | Exacto sectorial | Muchas preimágenes; no global |
| Detector relacional | Convierte coincidencia y clase target en registro | NRH01 80/80; 0/320 null | Confirmado acotado | Consumptivo y preparado |
| Escala retardo-a-lugar | Convierte historia relativa en canal | NRH05 44/44 | Confirmado acotado | Updates enteros, sin SI |
| Cadena de observadores | Mide una salida medida anteriormente | NRH02 100/100 | Confirmado hasta profundidad 4 | No infinito ni espontáneo |
| Fuente persistente | Emite tren alternante aun tras perturbación de la boca | NRD02B/NRH04 | Confirmado en aparato | No metabolismo ni agente |
| Memoria distribuida de fase | Retiene una intervención ausente en la relación fase–hub | NRH04 40/40 | Confirmado acotado | No reparación ni aprendizaje |
| Ley paridad–historia | Topología y fase controlan vida de la memoria | NRH06 24/24 | Confirmado acotado | Rama impar sólo hasta `3N+L` |
| Basin colectivo | Clasifica futuros densos/no densos | Padres 03/04 | Heredado, dominio certificado | No materia por decreto |
| Historia productiva | Resume crecimiento de support en interfaces activas | Padre 04 | Heredado, predictivo | No autonomía global |
| Balance `s_reg` de fibra | Conserva suma bajo cap y cuantifica pérdida por cap | Reducer exacto | Exacto sectorial | No energía global |
| Irreversibilidad lógica | Pierde identidad de preimagen al resolver | Censo 325 pares | Exacto para el censo | No entropía física |
| Interfaz oclusiva | Cambia accesibilidad causal de carriers | NRD03 | Soportado en familias | Sin reflexión ni ley general de medio |

## Fenómeno nuevo principal

La memoria distribuida de fase no se reduce al snapshot del elemento perturbador. El bloqueador desaparece en el primer tick y la fuente sobrevive, pero el tren queda trasladado una fase. La exclusión por ocupación del hub convierte esa fase en ausencia funcional persistente. La recirculación toroidal vuelve a hacer relevante la contribución según la paridad de `N`. El fenómeno completo es por tanto:

`intervención local -> cambio de fase -> exclusión relacional -> memoria distribuida -> retorno topológico condicionado por paridad`.

## Unificación

Detector, integración, memoria y recursión no necesitan cuatro mecanismos fundamentales. Son configuraciones distintas del mismo núcleo: propuestas dirigidas convergen; el resolvedor produce un output; guardas e historia deciden cuándo la convergencia ocurre; el output puede viajar y convertirse en entrada posterior.

Las descripciones completas de `preparation`, `intervention`, `response`, `history`, `geometry`, `scaling` y `detector_response` están en `PHENOMENA.json`.
