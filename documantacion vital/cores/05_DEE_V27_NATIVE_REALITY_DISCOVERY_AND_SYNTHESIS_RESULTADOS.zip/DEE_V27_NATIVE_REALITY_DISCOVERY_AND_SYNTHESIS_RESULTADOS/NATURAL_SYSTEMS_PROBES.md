# Sondas de familias naturales

## Regla de lectura

Las familias se definieron por funciones antes de comparar nombres. Una coincidencia parcial conserva la etiqueta `FUNCTIONAL_ANALOGY`; no demuestra identidad ontológica.

## Familia funcional tipo cerebro

| Firma abstracta | Resultado DEE |
|---|---|
| Distribución | Sí, fuentes y rutas espacialmente separadas |
| Recurrencia | Sí, emisiones persistentes y órbitas toroidales |
| Memoria | Sí, memoria de fase finita confirmada |
| Routing dependiente del contexto | Sí, llegada/ocupación decide integración o exclusión |
| Integración | Sí, resolvedor multi-source |
| Segregación | Parcial; rutas separadas, sin medida formal integrada/segregada |
| Predicción | Aparatos deterministas predictivos, no predictive coding aprendido |
| Robustez | Sí, bajo transformaciones congeladas; frágil a rewiring |
| Selección de atractor | Basins heredados, no unidos causalmente al detector actual |
| Temporal coding | Sí, retardo y fase controlan readout |
| Adaptación/aprendizaje | No encontrada |

Adjudicación: `PARTIAL_FUNCTIONAL_ANALOGY`. La coincidencia-retardo-a-lugar comparte una clase operacional con circuitos de coincidencia conocidos, pero no se demostró red neural, aprendizaje, cognición o cerebro.

## Familia funcional tipo planta

| Firma abstracta | Resultado DEE |
|---|---|
| Procesamiento distribuido | Sí |
| Sin controlador central | Sí en red preparada |
| Sensing local | Intervención local cambia la ruta; no sensor adaptativo |
| Consecuencia global | Sí, registro del hub cambia persistentemente |
| Canales lentos/rápidos | Fase local y retorno toroidal dan dos horizontes; no fisiología |
| Respuesta a gradiente | No probada |
| Redistribución de recursos | No encontrada |
| Memoria persistente | Sí, acotada por horizonte/topología |
| Reconfiguración adaptativa | No; el efecto equivale a pérdida funcional |
| Crecimiento/cambio estructural | Fuentes producen carriers, no crecimiento organizado |
| Reparación/homeostasis | No encontrada |

Adjudicación: `PARTIAL_FUNCTIONAL_ANALOGY`, no `PLANT_LIKE_FOUND` pleno.

## Familia de sistemas vivos/autoorganizados

Se observaron persistencia de fuentes, propagación, respuesta a daño y organización de basin heredada. No se verificaron conjuntamente boundary maintenance, adquisición de recursos, regulación, reparación, reproducción con herencia o adaptación. Resultado: `NO_NATIVE_LIVING_SYSTEM_ANALOGUE_FOUND` dentro de los aparatos probados.

## Mecanismo común

Las coincidencias parciales tipo cerebro y planta no requieren dos ontologías. Ambas provienen de routing distribuido, integración en fibras, persistencia de fuentes e historia de fase. Esta compresión por un solo operador es el resultado positivo; las etiquetas externas son comparaciones posteriores.

## Por qué se cerró la rama

Dos ciclos adicionales después de la cobertura básica profundizaron memoria y topología, produciendo una ley nueva. A partir de allí, demostrar aprendizaje, homeostasis o vida exigiría construir mecanismos no observados o nuevos objetivos externos, no caracterizar más el fenómeno existente. Se conserva la frontera sin fabricar positivos.
