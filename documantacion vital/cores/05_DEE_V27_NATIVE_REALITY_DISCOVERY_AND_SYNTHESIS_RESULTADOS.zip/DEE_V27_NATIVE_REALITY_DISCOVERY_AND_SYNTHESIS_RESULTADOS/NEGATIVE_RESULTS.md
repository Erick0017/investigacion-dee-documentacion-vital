# Resultados negativos

Cada negativo descarta la afirmación y dominio indicados; no se extiende a representaciones no probadas.

| ID | Resultado | Evidencia | Dominio/límite |
|---|---|---|---|
| N01 | Bloque 2x2x2 no fue detector | hit/miss/secuencia dejaron igual el registro local | Aparato NRD00; no todos los bloques |
| N02 | Inventario global no es estado causal | 36/36 discovery y 100/100 holdout pares matched divergieron | Sectores NRD02/NRH03 |
| N03 | Occupancy/support no cierra globalmente | heredado y controles de organización | No niega coarse state más rico |
| N04 | `(q,kappa,a,Gamma)` no cierra globalmente | padre 04 | Conserva dominios predictivos certificados |
| N05 | `Z` sin guardas no es global | mismo incoming proposal, respuesta transparente/oclusiva según target | Fuentes/targets ocupados quedan fuera |
| N06 | Dirección sola no es recursiva | 4058/17576 triples y 126192/456976 cuádruples difieren | No niega graph/history recursion |
| N07 | No H-teorema para macroentropía probada | la entropía sube y baja en 48 ensembles | No niega otros observadores |
| N08 | `s_reg` no es conservación global | pérdida/amplificación fuera de la fibra blank | Balance sectorial permanece exacto |
| N09 | No temperatura/energía física | sin ensemble universal, conjugada intensiva ni calibración | No identificación ontológica |
| N10 | No análogo completo de luz | velocidades euclídeas 1, sqrt2, sqrt3; sin reflexión/dispersion/interference | Familia de carriers probada |
| N11 | No coarse scale closure global | sin parámetros convergentes o autonomía multi-step | Cierres sectoriales sí existen |
| N12 | No jerarquía infinita | profundidad 4 confirmada solamente | Finita no implica infinita |
| N13 | No full brain-like family | sin aprendizaje, plasticidad o predictive coding | Analogía funcional parcial conservada |
| N14 | No full plant-like family | sin crecimiento, recursos, repair o homeostasis | Distributed response parcial conservada |
| N15 | No living-system analogue | propiedades de mantenimiento/herencia no coexisten | Aparatos actuales |
| N16 | No reparación tras daño | hub sigue igual a ablación en horizonte certificado | Memoria de fase sí confirmada |
| N17 | No Rosetta externa validada | RSH01 usa target ideal sin datos físicos | Candidato formal permanece |
| N18 | ECG anterior: no valor añadido | paquete extra sellado | No repetir SLOPE32/N8/32 ticks |
| N19 | No superioridad tecnológica | benchmark computable por lógica simple; sin coste comparable | Capacidad nativa no negada |
| N20 | No persistencia impar infinita | holdout llega sólo a `3N+L` | Predicción finita permanece PASS |

## Contra extrapolaciones

La ausencia de H-teorema en un coarse-graining no prueba ausencia de toda hidrodinámica. La ausencia de modo tipo luz en carriers aislados no prueba ausencia de todo modo colectivo. La no asociatividad de direction no prueba imposibilidad de una transformación gráfica. La falla del bloque detector no prueba que ningún observador exista; NRH01 demuestra lo contrario.

## FAILs preservados

Ningún threshold se movió después de holdout. NRH04 conserva su afirmación de horizonte finito; la divergencia posterior de NRD06 generó NRH06 en vez de redefinir NRH04. La primera ejecución NRD06 que no serializó fue `TECHNICAL_INTERRUPTION`, no evidencia ni FAIL.
