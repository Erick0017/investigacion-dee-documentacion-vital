# Frontera abierta

## 1. Estado relacional global

`Z` cierra exactamente un paso de raw en un sector con guardas congeladas. Falta saber si existe un estado gráfico/histórico compacto que cubra a la vez targets ocupados, fuentes `semantic=4`, cambios de estado, clock, colisiones y multi-step sin regresar a Q0. La alternativa es un teorema de que ninguna compresión no trivial tiene esa suficiencia.

Una prueba útil tendría que comparar modelos con guardas e histories en seeds/preparaciones nuevas y medir retención predictiva frente a Q0. Más ejemplos de la fibra blank no resuelven la pregunta.

## 2. Observadores espontáneos

Los observadores confirmados fueron preparados. No se sabe si basins naturales generan puertos que detecten otros procesos sin diseño externo, ni si esos detectores son estables al ruido. Hallarlos exigiría un criterio label-blind de información causal y controles matched, no buscar formas visuales.

## 3. Asintótica de la memoria impar

NRH06 confirma ausencia de divergencia hasta `3N+L` para tamaños impares probados. No demuestra persistencia infinita. Resolverla requiere derivación exacta del autómata de fase/guardas en el ciclo o un horizonte analíticamente suficiente; ejecutar sólo un múltiplo adicional sería caracterización, no prueba de infinito.

## 4. Procesamiento en régimen no ideal

Faltan capacidad con canales densos, jitter, ruido, múltiples eventos simultáneos, fan-in alto y cascadas profundas. Tampoco se conoce si el resolvedor ofrece una tarea donde supere un algoritmo simple. Sin ese hallazgo no se justifica un benchmark externo nuevo.

## 5. Fenómenos colectivos de propagación

El carrier aislado no cumple el fingerprint de luz. Permanece abierta la existencia de excitaciones colectivas con frente/grupo/espectro estable. Sólo una señal nativa previa justificaría abrir esa rama; no se debe imponer una ecuación de ondas como target de discovery.

## 6. Termodinámica

Faltan ensembles estacionarios, límite de tamaño, observable extensivo global, conjugada intensiva, susceptibilidad y fluctuaciones. La memoria de fase es una variable lenta, pero no establece equilibrio. Esta es una frontera interna tratable sólo después de descubrir un ensemble natural que no dependa arbitrariamente del observador.

## 7. Rosetta externa

La pieza exacta que falta bajo `H_DEE` es un par de mapas empíricos independientes:

`P: preparación física -> distribución sobre Q0`,

`D: historia/estado detector DEE -> registro físico`.

Además, una ley DEE congelada debe predecir una relación adimensional o curva externa no usada para definir `P` o `D`. El mismo mapa y pocos parámetros deben funcionar en varias condiciones y, preferiblemente, más de un observable.

RSH01 sólo proporciona el bloque interno y una equivalencia formal de proceso. No identifica `P`, no calibra `D` y no produce predicción externa. El ECG heredado es negativo y no debe repetirse sin una capacidad nativa que seleccione de antemano otra tarea.

## 8. H_DEE

Los resultados son compatibles con que DEE construya una arquitectura rica de procesos, pero no distinguen entre “modelo matemático con fenómenos internos” y “sustrato de nuestra realidad”. Esa distinción es externa al wheel: requiere preparación y detector físicos, no nuevas etiquetas sobre raw.

## Stopping rule

Todos los bloques obligatorios A–I quedaron adjudicados. Las extensiones que podrían cambiar una conclusión central requieren una nueva representación global, prueba asintótica o datos externos independientes. Variar ligeramente N, seeds o profundidad dentro de los mismos aparatos no cambia el nivel de evidencia. Por ello la campaña cierra en `EXTERNAL_EMPIRICAL_FRONTIER` y `COMPUTATIONAL/THEORETICAL_FRONTIER` delimitadas, sin declarar DEE terminada.
