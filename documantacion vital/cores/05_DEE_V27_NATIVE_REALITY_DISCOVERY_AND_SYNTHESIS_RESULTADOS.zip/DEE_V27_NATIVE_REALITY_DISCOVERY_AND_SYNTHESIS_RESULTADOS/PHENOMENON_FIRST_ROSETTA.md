# Rosetta phenomenon-first

## Cronología sin target leakage

La Rosetta se abrió sólo después de que NRH05 confirmara, sin datos externos, el fenómeno nativo `PHI_DELAY_TO_PLACE`. Se definieron sus variables, respuesta, nulls y límites. Luego se especificó una clase externa independiente: dos streams, líneas de retardo ordenadas, detectores de coincidencia y un código espacial de la diferencia temporal.

Esa clase fue propuesta históricamente como mecanismo de localización auditiva por Jeffress ([PubMed, 1948](https://pubmed.ncbi.nlm.nih.gov/18904764/)) y observada en circuitos de aves mediante axones que actúan como líneas de retardo y neuronas de coincidencia ([Carr y Konishi, PNAS 1988](https://pmc.ncbi.nlm.nih.gov/articles/PMC282419/); [Carr y Konishi, J. Neurosci. 1990](https://pmc.ncbi.nlm.nih.gov/articles/PMC6570189/)). Las fuentes sirven para definir la clase operacional; no se utilizaron datos biológicos para ajustar DEE.

## Fenómeno DEE congelado

`Phi_D` contiene:

- preparación: dos carriers por canal;
- intervención: variar diferencia de longitudes;
- grafo causal: dos rutas convergentes;
- respuesta: output fusionado sólo por coincidencia;
- memoria temporal: arrival history;
- geometría: banco ordenado de destinos;
- detector: índice del canal activo;
- falsador: canal incorrecto/no único, éxito del mapa destruido o registro sin target.

## Diana externa abstracta

`Phi_W` contiene:

- dos streams;
- diferencia temporal de llegada;
- líneas de retardo ordenadas;
- unidades de coincidencia;
- una respuesta de lugar monotónica con el retardo;
- null de calibración invertida;
- ausencia de respuesta sin una de las streams.

No se incluyeron neuronas, voltajes, metros, segundos o organismos en el target matemático.

## Mapa T

| `Phi_D` | `Phi_W` |
|---|---|
| carrier target/probe | stream 1/2 |
| longitud de ruta en updates | delay de conducción abstracto |
| fibra de destino | detector de coincidencia |
| salida fusionada | evento de coincidencia |
| índice del canal | lugar que codifica diferencia temporal |

El mapa tiene cero parámetros ajustados en holdout y conserva orden causal, coincidencia, monotonicidad, número de clases e información.

## Holdout RSH01

El lock `RSH01_DELAY_TO_PLACE_PROCESS_ROSETTA.json` fue hasheado como `8eefdfbcf0c725582498de885ecfb0ca58a4cf39d475f48ff556b512070dedb1` antes de abrir 13 clases nuevas y tres frames:

- mapa nativo: 39/39;
- Spearman entre delta y lugar: 1.0;
- información: `log2(13)=3.70044` bits;
- calibración invertida: 3/39 = 1/13;
- target ausente: 3/3 sin registro;
- límite inferior Wilson: 0.9103.

Veredicto: PASS al techo preregistrado `FROZEN_ROSETTA_CANDIDATE` y `FORMAL_EQUIVALENCE_CANDIDATE`.

## Por qué no es Rosetta validada

No existe todavía:

- preparación física que genere el ensemble Q0 del aparato;
- calibración de update/voxel con magnitudes físicas;
- distribución empírica externa predicha;
- sujeto o registro biológico holdout;
- predicción nueva independiente sin recalibración;
- demostración de que el circuito DEE sea más que una realización matemática de coincidencia.

No se afirma `DEE=cerebro`, `DEE=audición` ni teoría física universal. La correspondencia más fuerte encontrada es proceso-a-proceso y formal.

## Estado de la Rosetta

`STRUCTURAL_ANALOGY`: superado.

`FORMAL_EQUIVALENCE_CANDIDATE`: alcanzado.

`FROZEN_ROSETTA_CANDIDATE`: alcanzado.

`EXTERNAL_COMPATIBILITY`: no probada con datos.

`EXTERNAL_PREDICTION`: no obtenida.

`ROSETTA_VALIDATED`: no obtenida.
