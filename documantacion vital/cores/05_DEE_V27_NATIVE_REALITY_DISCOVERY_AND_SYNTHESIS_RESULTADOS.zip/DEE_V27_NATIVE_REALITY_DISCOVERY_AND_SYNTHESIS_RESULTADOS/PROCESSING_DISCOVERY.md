# Descubrimiento de procesamiento nativo

## Veredicto

`NATIVE_COMPUTATIONAL_DISCOVERY_BOUNDED`: `F_DEE` aporta integración por coincidencia, transformación de contenido, discriminación temporal, retardo-a-lugar y memoria de fase. La afirmación es causal dentro de los aparatos congelados; no implica ventaja computacional general ni tecnología superior.

## Primitivas observadas

1. Routing: un carrier selecciona un destino por su dirección.
2. Integración: varias llegadas se reducen a signo de suma vectorial y suma/cap `s_reg`.
3. Gating temporal: la integración ocurre por coincidencia de llegada.
4. Transducción: un offset temporal se convierte en lugar de salida.
5. Composición: una salida fusionada puede entrar en otra estación.
6. Storage distribuido: un cambio de fase modifica outputs mucho después de desaparecer el perturbador.
7. Many-to-one compression: el output conserva variables de respuesta y descarta identidad de fuentes.

## Prueba de valor añadido de la dinámica

En NRH05, el input se codificó mediante rutas sin usar etiquetas futuras. El puerto antes de evolucionar estuvo vacío en 44/44 casos, así que el encoder solo no contenía el readout. Con `F_DEE`, 44/44 mundos dieron la clase correcta. Al invertir la calibración de rutas pero conservar inventario, canales y etiquetas, el control destruido obtuvo 4/44, exactamente 1/11. Sin targets, 4/4 mundos no registraron salida.

La comparación cumple el criterio funcional:

- encoder -> readout sin evolución: ninguna medida;
- encoder -> `F_DEE` -> readout: exactitud 1.0;
- encoder -> relación destruida -> `F_DEE` -> readout: exactitud 1/11;
- target ausente: ningún output espurio.

La capacidad del banco balanceado de `K` canales es `log2(K)` bits si cada clase produce exactamente un canal. Se confirmó para `K=7`, `11` y `13` en etapas independientes. El coste preparado es `O(K)` canales y dos carriers por canal; no se demostró un esquema sublineal.

## Memoria

La memoria no reside en un bit estable añadido. Una perturbación de un tick cambia la fase del tren emitido; el estado distribuido de rutas y hub retiene esa diferencia. El readout coincide con una ablación durante el horizonte certificado. La topología determina cuándo una órbita de output vuelve a revelar la diferencia.

Esto es storage de historia y transformación contextual. No es memoria asociativa, pattern completion o aprendizaje: no se entrenó ni se mostró recuperación desde claves parciales.

## Robustez y fallo

El transductor sobrevivió N, frames, traducciones, seeds, estados/clocks nuisance y saturación. Falla por construcción si las rutas se solapan de modo no previsto, el background añade propuestas a los hubs o una guarda cambia el sector. La fase-memory depende de fuentes persistentes, hub ocupado y rutas coordinadas; rewiring eliminó el output de hub.

## Comparación con métodos simples

Un circuito o programa convencional puede calcular igualdad de retardos y seleccionar un índice con menos simulación. No se probó superioridad en accuracy, energía, densidad, tolerancia a ruido o complejidad. El descubrimiento es que la dinámica DEE implementa naturalmente la operación, no que la operación sea desconocida fuera de DEE.

## Potencial

El resultado justifica estudiar redes de coincidencia y memoria de fase como sustrato determinista, especialmente bajo perturbaciones y topologías periódicas. Antes de hablar de aplicación deben medirse tolerancia a jitter, ruido, densidad de canales, fan-in, cascadas profundas, coste físico y una tarea donde el resolvedor DEE aporte ventaja sobre lógica convencional. Esos requisitos se detallan en `DISCOVERY_TO_TECH.md`.
