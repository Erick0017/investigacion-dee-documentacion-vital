# Propagación y velocidad causal

## Nociones separadas

La campaña mantuvo distintas cuatro velocidades:

1. cota de dependencia microscópica `raw`: heredada, `L_inf<=3` por tick;
2. desplazamiento de carrier libre: `L_inf=1` por tick;
3. frente de información del aparato: primer tick en que un puerto distingue una intervención;
4. propagación macro/colectiva: no identificada como modo estable independiente.

Confundirlas habría producido una falsa constante fundamental.

## Carrier libre

Los singletons aislados permanecieron singletons y avanzaron exactamente por su vector de dirección en los tamaños y orientaciones probados. En unidades de lattice:

- dirección axial: distancia euclídea 1 por tick;
- diagonal de cara: `sqrt(2)`;
- diagonal corporal: `sqrt(3)`;
- todas: distancia `L_inf=1`.

La velocidad estable es relacional a la métrica de Chebyshev del operador. No existe una única magnitud euclídea isotrópica para las 26 direcciones.

## Respuesta a medios

Se lanzó la misma clase de carrier contra cuatro interfaces, seis direcciones cada una:

| Interfaz | Transmisión | Reflexión observada |
|---|---:|---:|
| vacío | 6/6 | 0/6 |
| punto normal `state=0` | 6/6 | 0/6 |
| bloque estable `state>0` | 0/6 | 0/6 |
| punto fuente `semantic=4` | 0/6 | 0/6 |

El fenómeno neutral es accesibilidad causal dependiente de la guarda: algunas organizaciones son transparentes y otras oclusivas. No se derivó índice de refracción, scattering angular o conservación de flujo.

## Fingerprint tipo luz

Se buscó una excitación con velocidad finita, estable, poco dependiente de amplitud/preparación, cross-N y posiblemente invariante al observador, además de estructura de medio, dispersión o interferencia cuando apareciera.

El carrier satisface finitud y estabilidad en su sector, pero falla el fingerprint completo:

- anisotropía euclídea por clase direccional;
- cota causal microscópica distinta de velocidad del carrier;
- no se observó reflexión;
- no se obtuvo dispersión, velocidad de grupo o relación frecuencia–onda;
- no apareció superposición/interferencia;
- no se demostró invariancia bajo cambio de observador efectivo.

Adjudicación: `PROPAGATION_INVARIANT_FOUND_BOUNDED` y `NO_NATIVE_LIGHT_ANALOGUE_FOUND_IN_TESTED_FAMILY`.

## First-passage y medida

La información del offset llega al detector cuando dos rutas coinciden. En NRH05 la longitud de ruta funciona como delay interno y el canal como lugar. Ésta es una ley de first-passage/response, no una calibración física de velocidad. Sólo ratios y diferencias de ticks se utilizaron.

## Frontera

Un modo colectivo podría tener velocidad distinta y más isotrópica; los negativos actuales no lo imposibilitan. Promoverlo exigiría preparar una familia de excitaciones colectivas, congelar una estimación de frente/fase/grupo y predecir nuevos N y medios. Ninguna evidencia actual justifica afirmar que tal modo existe.
