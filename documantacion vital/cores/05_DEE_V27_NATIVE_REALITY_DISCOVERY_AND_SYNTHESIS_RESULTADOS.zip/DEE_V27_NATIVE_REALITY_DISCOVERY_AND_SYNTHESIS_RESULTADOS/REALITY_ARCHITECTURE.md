# Arquitectura de realidad nativa de DEE

## Resultado

La representación más fértil no es una colección de voxels-material ni un nuevo escalar `Q4`. Es una dinámica de relaciones dirigidas, resolución por destino e historia de interacción.

Para cada actualización, un sitio activo puede inducir una propuesta dirigida `i -> D_t(i)`. Las propuestas que comparten destino `y` forman una fibra. En el sector blank-target congelado, la fibra se resume exactamente por

`Z_t(y) = (m_y, V_y, S_y)`,

donde `m_y` es multiplicidad, `V_y=sum_i d_i` y `S_y=sum_i s_i`. El resolvedor produce

`d_out(y)=sign(V_y)`,

`s_out(y)=min(S_y,19664)`.

La fórmula no es global: una ocupación previa, una fuente `semantic=4`, el estado y otras guardas cambian la rama. Por eso el objeto causal nativo completo dentro de una descripción reducida es más cercano a

`(grafo de propuestas, fibras de destino, guardas, fase/historia, topología)`

que a `(q,kappa,a,Gamma)` o a un histograma global.

## Cadena constructiva

`Q0=(raw,clock)`

`-> propuestas y guardas locales`

`-> fibras de destino y multiplicidades`

`-> resolución R / exclusión / persistencia de fuentes`

`-> rutas, colisiones y secuencias de eventos`

`-> historias de fase y recurrencia`

`-> organizaciones colectivas y basins`

`-> relaciones sistema–detector`

`-> medidas y fenómenos efectivos`.

Esta cadena es una arquitectura causal, no una identificación con categorías físicas humanas.

## Niveles heredados y resultado nuevo

- `Q0`: `raw+clock`, estado Markoviano exacto.
- `Q1`: mecanismos/eventos `S/R/C/X/D`, transporte, colisión, fuente, primer paso y respuesta.
- `Q2`: organización colectiva de basin dentro de dominios certificados.
- `Q3`: clase de histories productivas, predictiva pero no globalmente autónoma.
- Resultado nuevo: `Z` es un estado relacional exacto de un paso en un sector guardado; la relación observacional `O_B(A)` y la fase topológica son coordenadas transversales. No se promueven como `Q4` porque no constituyen un único nivel global autónomo.

La jerarquía observada es parcialmente discreta y parcialmente relacional. Un mismo microestado puede adquirir distinto significado efectivo según la ruta que lo llevó al detector y la fase respecto de otras rutas.

## Cinco geometrías separadas

1. Geometría del lattice: cubo periódico y vecindad de Moore.
2. Geometría causal: cota heredada de dependencia `L_inf <= 3` por actualización.
3. Geometría de transporte: un portador libre recorre un desplazamiento de dirección por actualización.
4. Geometría de destinos: clases de propuestas que convergen en una fibra.
5. Geometría de respuesta: distancias y canales definidos por qué interacción produce qué registro.

El hallazgo de paridad muestra que la topología periódica no es decoración: la longitud orbital `N` se acopla con una fase de periodo 2 y con la distancia de fuente `L`, modificando la vida de una memoria distribuida.

## Qué cuenta como entidad

La identidad más fuerte encontrada es procesual:

- el portador: linaje estable en vuelo libre, consumible en interacción;
- la fuente persistente: organización que vuelve a emitir aunque sus emisiones individuales desaparezcan;
- el tren de emisiones: historia de fase que puede ser desplazada por una perturbación de un tick;
- el hub: relación de integración, no objeto independiente de sus llegadas;
- el detector: sonda más puerto de salida calibrado;
- el basin: clase colectiva de futuros, heredada de campañas anteriores.

Ninguno autoriza por sí solo los nombres partícula, materia, campo u observador cuántico.

## Arquitectura transversal

El mismo operador de convergencia y resolución explica fenómenos que parecen distintos desde fuera:

- colisión: varias propuestas se resuelven en una salida;
- medición: una sonda convierte una propiedad relativa de otra ruta en salida;
- procesamiento: la coincidencia integra y transduce retardo a lugar;
- memoria: una perturbación cambia la fase de una ruta y con ello futuras admisiones al hub;
- recursión observacional: una salida resuelta se convierte en entrada medible de la siguiente estación;
- irreversibilidad lógica: la resolución descarta identidad de preimagen.

La compresión teórica principal es, por tanto, `routing + destination fiber + guarded reducer + retained phase`.

## Lo que no cierra

`Z` falla como descripción global si se omiten guardas: la misma propuesta incidente puede atravesar un target normal `state=0`, ser ocluida por un bloque `state>0` o interactuar con una fuente persistente. Tampoco predice por sí solo `clock`, ni conserva la información de historias necesaria tras varios pasos. El cierre global sigue abierto; el resultado positivo es sectorial, no una sustitución encubierta de `Q0`.

## Criterio de realidad efectiva

Los fenómenos promovidos admiten múltiples preparaciones, una respuesta reproducible, controles causales, variación microscópica irrelevante y un registro que predice algo. Bajo ese criterio son reales dentro de DEE. Su traducción a nuestra realidad exige además el puente experimental externo descrito en `OPEN_FRONTIER.md`.
