# Análisis de recursividad y escala

## Pregunta

¿La misma transformación resume varias escalas y predice una escala no observada, o la jerarquía termina en descripciones sectoriales no recursivas?

## Recursión direccional: negativo exacto enumerativo

El candidato más simple aplica repetidamente el resolvedor `r(d_1,...,d_k)=sign(sum d_i)` a grupos. Si fuera un coarse-graining recursivo, agrupar y volver a resolver debería concordar con resolver todos simultáneamente.

No ocurre:

- triples: 4058/17576 diferencias entre fold izquierdo y resolución simultánea (`0.230883`);
- triples: 7516/17576 diferencias entre folds izquierdo y derecho;
- cuádruples: 126192/456976 diferencias entre agrupación balanceada y simultánea (`0.276146`);
- cuádruples: 186700/456976 diferencias para fold izquierdo (`0.408555`).

La saturación temprana al signo descarta magnitud intermedia; por eso el operador reducido no es asociativo. `direction` sola no define una ley recursiva de escala.

## Recursión observacional: positivo finito

El operador sin reducción prematura sí puede componerse sobre carriers completos:

`R((d,s),(p,r))=(sign(d+p), min(s+r,19664))`.

Cada output viaja y se convierte en target de otra sonda. Discovery llegó a profundidad 3; el holdout predijo profundidad 4 sin refit:

- 100/100 eventos y downstream exactos;
- 20/20 casos de la profundidad nueva;
- 0/200 falsos registros recursivos.

Esto es `RECURSIVE_OBSERVER_LAW_FOUND_BOUNDED`: cierre composicional de una arquitectura preparada, no una prueba de infinitud ni de niveles espontáneos.

## Ley cross-size de historia/topología

La memoria distribuida introdujo otra ley de escala. En el aparato congelado, un retorno tarda `N` ticks y la separación fuente–hub añade `L`. Una fase de periodo 2 interactúa con la paridad del tamaño:

- `N` par: primera divergencia predicha `T_div=N+L`;
- `N` impar: no divergencia hasta el horizonte congelado `3N+L`.

NRH06 acertó 24/24 diseños nuevos. Es una ley cross-N con parámetros estructurales `N` y `L`, no una transformación `Q_k -> Q_{k+1}` ni self-similarity.

## ¿Existe Q4?

No se encontró un nivel único que gane autonomía global, compresión y predicción sobre Q3. `Z` cierra un paso en un sector, la fase explica memoria, y la relación observacional compone aparatos. Son coordenadas complementarias y sectoriales, no evidencia de un nuevo estrato universal.

Adjudicación: `NO_ADDITIONAL_GLOBAL_HIGHER_STRUCTURE`; coexistente con `RELATIONAL_CLOSURE_FOUND_BOUNDED`, `RECURSIVE_OBSERVER_LAW_FOUND_BOUNDED` y `TOPOLOGY_HISTORY_PARITY_LAW_FOUND_BOUNDED`.

## Cierre de escala

No se demostró SCALE_CLOSURE global: faltan convergencia de parámetros, error coarse acotado multi-step y transferencia a nuevos sectores/preparaciones. Dentro de la fibra de destino hay cierre de un paso; dentro del detector hay composición finita; dentro de la memoria hay una ley cross-size. La estructura correcta parece multirama, no una cascada escalar universal.

## Por qué no se prolongó

Probar profundidad 5 o más N con la misma fórmula sólo repetiría una ley ya delimitada. Afirmar recursión ilimitada requeriría una demostración algebraica que incorpore geometría, no más ejemplos. El contraejemplo de asociatividad ya decide el candidato direccional simple. La próxima ganancia cualitativa exige un estado gráfico global o un teorema de imposibilidad.
