# Observador causal relacional

## Definición operacional

Sean `A` un proceso target y `B` una sonda DEE. `B` cuenta como detector de `A` si una intervención sobre la relación `A–B` cambia de forma reproducible un registro posterior de `B`, el registro contiene información sobre `A`, y controles que destruyen sólo la relación eliminan esa información.

El observador mínimo confirmado es:

`O_B(A) = (sonda dirigida B, fibra común, salida resuelta, puerto downstream)`.

No es un campo raw particular ni un agente cognitivo.

## Discovery NRD01

Dos portadores con inventario fijo se hicieron converger o se desfasaron. Las 48 llegadas sincronizadas produjeron exactamente la salida predicha y su registro downstream. Ninguno de 192 controles con desfases `-3,-1,+1,+3` produjo la fusión en el evento nominal. Doce baselines sin target produjeron sólo la sonda.

La variable causal discriminante fue la coincidencia en una fibra de destino, no la presencia de los dos tipos de portador.

## Confirmación NRH01

Antes del holdout se congelaron ocho clases transversales, cinco tamaños nuevos, distancias, translations, estados, clocks y regímenes saturados/no saturados. Sin parámetros ajustados:

- evento exacto: 80/80;
- downstream exacto: 80/80;
- dirección target decodificada: 80/80;
- información: 3.000 bits de 3 posibles;
- falsos merges en shuffle temporal: 0/320;
- límite inferior Wilson 95%: 0.9542.

La salida obedece

`d_out=sign(d_B+d_A)`,

`s_out=min(s_B+s_A,19664)`.

Al conocer `B`, el puerto lee una clase de `A`. El detector altera el sistema: las entradas se consumen y aparece un carrier fusionado. Es medición destructiva.

## Estado causal relacional NRH03

La pregunta de suficiencia se amplió desde dos carriers a muchas propuestas. En el sector congelado, agrupar por destino y conservar multiplicidad, suma vectorial entera y suma `s_reg` reconstruyó 200/200 arrays raw completos. Los 100 pares con inventario global idéntico pero organización diferente produjeron futuros diferentes.

Por tanto, la fibra de destino es una clase predictiva exacta de un paso dentro de ese sector. La distribución espacial completa no se necesita una vez formado `Z`, pero las guardas del target sí.

## Observador de observador NRH02

La salida de una interacción se utilizó como target de la siguiente. El mismo operador se aplicó recursivamente, sin reentrenamiento. El holdout introdujo profundidad 4, tamaños, orientaciones, clocks, estados y saturación nuevos:

- registros de capas presentes: 100/100;
- downstream: 100/100;
- casos específicamente de profundidad 4: 20/20;
- falsos registros recursivos en controles: 0/200;
- límite inferior Wilson: 0.9630.

Esto demuestra composabilidad observacional finita. No demuestra observadores espontáneos, regresión infinita ni escala física.

## Qué información distingue

El aparato distingue:

- coincidencia vs desfase;
- ocho clases direccionales transversales;
- suma `s_reg`, y por resta el valor target debajo del cap;
- retardo relativo cuando varias fibras forman una banca calibrada;
- la salida de un observador anterior.

No distingue en su versión actual la identidad completa de las preimágenes, el `state` nuisance ni `clock`; de hecho, la invariancia frente a esos nuisance fue parte de la prueba.

## Minimalidad y límites

Un bloque estático 2x2x2 no funcionó como detector en el aparato NRD00. Quitar el puerto downstream elimina la lectura persistente; quitar la sonda elimina la interacción informativa; destruir el tiempo relativo elimina la fusión. Esto apoya la minimalidad funcional de sonda + relación de coincidencia + puerto, no un teorema de minimalidad sobre todos los posibles observadores DEE.

El observador confirmado vive en un sector limpio y preparado. Su generalización a backgrounds densos, interfaces mixtas y procesos espontáneos permanece abierta.
