param(
    [string]$Python = $env:DEE_PYTHON,
    [switch]$Full
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$PackageRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

function Get-LocalSha256([string]$Path) {
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

Write-Host 'Validating package file hashes...'
$HashLines = Get-Content -LiteralPath (Join-Path $PackageRoot 'HASHES.sha256')
foreach ($Line in $HashLines) {
    if ($Line -notmatch '^([0-9a-f]{64}) \*(.+)$') {
        throw "Malformed HASHES.sha256 line: $Line"
    }
    $Expected = $Matches[1]
    $Relative = $Matches[2].Replace('/', [IO.Path]::DirectorySeparatorChar)
    $Target = Join-Path $PackageRoot $Relative
    if (-not (Test-Path -LiteralPath $Target -PathType Leaf)) {
        throw "Missing package member: $Relative"
    }
    $Observed = Get-LocalSha256 $Target
    if ($Observed -ne $Expected) {
        throw "Hash mismatch for $Relative`nexpected=$Expected`nobserved=$Observed"
    }
}
Write-Host "Validated $($HashLines.Count) file hashes."

if ([string]::IsNullOrWhiteSpace($Python)) {
    $PinnedCandidate = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
    if (Test-Path -LiteralPath $PinnedCandidate -PathType Leaf) {
        $Python = $PinnedCandidate
    } else {
        $PythonCommand = Get-Command python -ErrorAction SilentlyContinue
        if ($null -ne $PythonCommand) {
            $Python = $PythonCommand.Source
        }
    }
}
if ([string]::IsNullOrWhiteSpace($Python) -or -not (Test-Path -LiteralPath $Python -PathType Leaf)) {
    throw 'CPython 3.13 x64 was not found. Set DEE_PYTHON or pass -Python C:\path\to\python.exe.'
}

$RunnerRoot = Join-Path $PackageRoot 'RUNNERS'
$RuntimeCheck = "import sys; sys.path.insert(0, r'$RunnerRoot'); import native_core; _,e=native_core.verify_and_load_kernel(1); print(e['observed_hashes'])"
& $Python -I -B -c $RuntimeCheck
if ($LASTEXITCODE -ne 0) {
    throw 'The hash-pinned DEE v27 runtime check failed.'
}

if (-not $Full) {
    Write-Host 'Package and runtime are valid. Use -Full to rerun the complete campaign.'
    exit 0
}

$Runners = @(
    'run_nrd00_native_pilots.py',
    'run_nrd01_collision_probe_discovery.py',
    'run_nrh01_internal_relational_measurement_holdout.py',
    'run_nrd02_relational_distributed_discovery.py',
    'run_nrd02b_block_memory_diagnostic.py',
    'analyze_nrd02b_phase_memory.py',
    'run_nrd03_propagation_thermo_scale_coverage.py',
    'run_nrd04_observer_hierarchy_discovery.py',
    'run_nrh02_recursive_observer_chain_holdout.py',
    'run_nrh03_destination_fiber_closure_holdout.py',
    'run_nrh04_distributed_phase_memory_holdout.py',
    'run_nrd05_relational_scale_discovery.py',
    'run_nrh05_native_relational_delay_scale_holdout.py',
    'run_rsh01_delay_to_place_process_rosetta_holdout.py',
    'run_nrd06_phase_memory_long_horizon.py',
    'run_nrd07_toroidal_memory_parity_discovery.py',
    'run_nrh06_toroidal_phase_parity_holdout.py'
)

foreach ($Runner in $Runners) {
    $RunnerPath = Join-Path $RunnerRoot $Runner
    Write-Host "Running $Runner"
    & $Python -I -B $RunnerPath
    if ($LASTEXITCODE -ne 0) {
        throw "Runner failed: $Runner"
    }
}

$HoldoutResults = @(
    'NRH01_internal_relational_measurement_holdout.json',
    'NRH02_recursive_observer_chain_holdout.json',
    'NRH03_destination_fiber_closure_holdout.json',
    'NRH04_distributed_phase_memory_holdout.json',
    'NRH05_native_relational_delay_scale_holdout.json',
    'RSH01_delay_to_place_process_rosetta_holdout.json',
    'NRH06_toroidal_phase_parity_holdout.json'
)
foreach ($ResultName in $HoldoutResults) {
    $ResultPath = Join-Path (Join-Path $PackageRoot 'RESULTS') $ResultName
    $Result = Get-Content -LiteralPath $ResultPath -Raw | ConvertFrom-Json
    if ($Result.verdict -ne 'PASS') {
        throw "Reproduced holdout did not PASS: $ResultName ($($Result.verdict))"
    }
}
Write-Host 'Full reproduction completed; all seven frozen holdouts returned PASS.'
