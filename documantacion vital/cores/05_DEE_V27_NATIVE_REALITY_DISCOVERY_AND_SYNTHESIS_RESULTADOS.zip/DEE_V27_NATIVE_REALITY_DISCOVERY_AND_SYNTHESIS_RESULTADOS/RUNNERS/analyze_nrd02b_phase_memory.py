#!/usr/bin/env python3
"""Adjudicate NRD02B without rerunning the kernel."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import atomic_json, canonical_hash

WORK=Path(__file__).resolve().parents[1]
SOURCE=WORK/"RESULTS"/"NRD02B_block_memory_diagnostic.json"
OUT=WORK/"RESULTS"/"NRD02B_phase_memory_analysis.json"
DIRECTIONS=((1,0,0),(1,1,0),(1,0,1),(1,1,1))
SREGS=(2,3,5,7)

def main():
    data=json.loads(SOURCE.read_text(encoding="utf-8"))
    panels=[]
    for panel in data["panels"]:
        baseline=panel["baseline"]
        base_events=[(r["tick"],r["hub"]["sreg"],r["hub"]["d"]) for r in baseline["trace"] if r["hub"] is not None]
        arms=[]
        for idx in range(4):
            unforced=next(r for r in panel["runs"] if r["mode"]=="unforced_initial_block" and r["blocked_index"]==idx)
            forced=next(r for r in panel["runs"] if r["mode"]=="forced_remove_after_tick1" and r["blocked_index"]==idx)
            mouth=[r["mouths"][idx] for r in unforced["trace"]]
            source=[r["sources"][idx] for r in unforced["trace"]]
            events=[(r["tick"],r["hub"]["sreg"],r["hub"]["d"]) for r in unforced["trace"] if r["hub"] is not None]
            emitted_after=[row for row in mouth[2:] if row is not None]
            arms.append({
                "source_index":idx,
                "initial_block_direction_zero":mouth[0] is not None and mouth[0]["d"]==[0,0,0],
                "initial_block_absent_at_tick1":mouth[1] is None,
                "later_mouth_records_are_emitted_carriers":all(row["d"]==list(DIRECTIONS[idx]) for row in emitted_after),
                "persistent_source_semantic4":all(row is not None and row["semantic"]==4 for row in source),
                "baseline_mouth_emission_ticks":[i for i,row in enumerate([r["mouths"][idx] for r in baseline["trace"]]) if row is not None],
                "post_block_mouth_emission_ticks":[i for i,row in enumerate(mouth) if i>0 and row is not None],
                "hub_events":events,
                "hub_equals_single_ablation_record":all(sreg==17-SREGS[idx] and d==[1,1,1] for _,sreg,d in events),
                "blocker_removal_command_was_noop":all(a["raw_sha256"]==b["raw_sha256"] for a,b in zip(unforced["trace"],forced["trace"],strict=True)),
                "difference_survives_to_last_tick":unforced["trace"][-1]["raw_sha256"]!=baseline["trace"][-1]["raw_sha256"],
            })
        panels.append({"n":panel["n"],"distance":panel["distance"],"baseline_hub_events":base_events,"arms":arms})
    allarms=[a for p in panels for a in p["arms"]]
    summary={
        "arms":len(allarms),
        "blocker_gone_at_tick1":sum(a["initial_block_absent_at_tick1"] for a in allarms),
        "source_persists":sum(a["persistent_source_semantic4"] for a in allarms),
        "emission_parity_shifted":sum(a["baseline_mouth_emission_ticks"]!=a["post_block_mouth_emission_ticks"] for a in allarms),
        "later_mouth_records_are_carriers_not_blocker":sum(a["later_mouth_records_are_emitted_carriers"] for a in allarms),
        "hub_output_indistinguishable_from_source_ablation":sum(a["hub_equals_single_ablation_record"] for a in allarms),
        "difference_survives_to_last_tick":sum(a["difference_survives_to_last_tick"] for a in allarms),
        "forced_removal_identical_to_natural_evolution":sum(a["blocker_removal_command_was_noop"] for a in allarms),
    }
    result={
        "schema":"dee.v27.native_reality.nrd02b.analysis.v1",
        "source_content_sha256":data["content_sha256"],
        "role":"DISCOVERY_EVIDENCE_ONLY",
        "adjudication":"The initial stationary mouth blocker is absent at tick 1. It flips that source train's parity; the persistent source then emits on the opposite parity, but the occupied integration hub excludes every late arrival. Thus a one-tick local intervention produces finite-horizon persistent distributed functional memory equivalent at the hub to source ablation.",
        "not_claimed":["adaptive learning","self-repair","homeostasis","infinite-duration memory","brain or plant identity"],
        "summary":summary,
        "panels":panels,
    }
    result["content_sha256"]=canonical_hash(result)
    atomic_json(OUT,result)
    print(json.dumps(summary,indent=2,sort_keys=True))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
