#!/usr/bin/env python3
"""Create and independently validate the single deterministic campaign archive."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path


WORK = Path(__file__).resolve().parents[1]
TESTS = WORK.parent
ARCHIVE = TESTS / "DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip"
PREFIX = "DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS"
MANIFEST = WORK / "MANIFEST.json"
HASHES = WORK / "HASHES.sha256"

PARENTS = {
    "01": (
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE" / "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip",
        "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    ),
    "02": (
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE" / "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip",
        "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    ),
    "03": (
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE" / "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip",
        "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    ),
    "04": (
        TESTS / "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip",
        "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    ),
    "extra01": (
        TESTS / "EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip",
        "dd8af27c8a836d9a79919fae92c2a19ee12dc5dedf635ccea92c460010484e7e",
    ),
}

EXPECTED_KERNEL = {
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}


def sha256_path(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_text(path: Path, text: str) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(text, encoding="utf-8", newline="\n")
    os.replace(temporary, path)


def role(relative: str) -> str:
    if relative.startswith("RESULTS/"):
        return "PRIMARY_RESULT"
    if relative.startswith("HOLDOUT_LOCKS/"):
        return "PREREGISTRATION"
    if relative.startswith("RUNNERS/"):
        return "REPRODUCTION_CODE"
    if relative.startswith("KERNEL/"):
        return "SEALED_RUNTIME_COPY"
    if relative.startswith("CHECKPOINTS/"):
        return "CHECKPOINT"
    if relative.endswith(".md"):
        return "SCIENTIFIC_DOCUMENT"
    if relative in {"STATE.json", "CLAIMS.json", "PHENOMENA.json", "SCIENCE_LOG.ndjson"}:
        return "SCIENTIFIC_LEDGER"
    return "SUPPORT"


def source_files() -> list[Path]:
    excluded = {MANIFEST.resolve(), HASHES.resolve()}
    files = []
    for path in WORK.rglob("*"):
        if not path.is_file() or path.resolve() in excluded:
            continue
        if path.name.endswith(".tmp") or "__pycache__" in path.parts:
            continue
        files.append(path)
    return sorted(files, key=lambda item: item.relative_to(WORK).as_posix())


def verify_sources() -> dict[str, str]:
    observed = {}
    for key, (path, expected) in PARENTS.items():
        value = sha256_path(path)
        if value != expected:
            raise RuntimeError(f"sealed parent {key} mismatch: {value}")
        observed[key] = value
    for relative, expected in EXPECTED_KERNEL.items():
        value = sha256_path(WORK / relative)
        if value != expected:
            raise RuntimeError(f"kernel identity mismatch for {relative}: {value}")
    return observed


def build_metadata() -> tuple[dict, list[Path]]:
    parents = verify_sources()
    files = source_files()
    entries = []
    for path in files:
        relative = path.relative_to(WORK).as_posix()
        entries.append(
            {
                "path": relative,
                "bytes": path.stat().st_size,
                "sha256": sha256_path(path),
                "role": role(relative),
            }
        )
    manifest = {
        "schema": "dee.v27.native_reality.manifest.v1",
        "campaign": "DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS",
        "status": "SEALED_SCIENTIFIC_CLOSURE",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "archive_root": PREFIX,
        "file_count_excluding_manifest_and_hash_list": len(entries),
        "total_bytes_excluding_manifest_and_hash_list": sum(entry["bytes"] for entry in entries),
        "parent_sha256": parents,
        "kernel_sha256": EXPECTED_KERNEL,
        "holdout_verdicts": {
            "NRH01": "PASS",
            "NRH02": "PASS",
            "NRH03": "PASS",
            "NRH04": "PASS",
            "NRH05": "PASS",
            "RSH01": "PASS_AT_FROZEN_ROSETTA_CANDIDATE_CEILING",
            "NRH06": "PASS",
        },
        "files": entries,
    }
    return manifest, files


def write_manifest_and_hashes() -> list[Path]:
    manifest, _ = build_metadata()
    atomic_text(MANIFEST, json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n")
    files = source_files() + [MANIFEST]
    files = sorted(files, key=lambda item: item.relative_to(WORK).as_posix())
    lines = [f"{sha256_path(path)} *{path.relative_to(WORK).as_posix()}" for path in files]
    atomic_text(HASHES, "\n".join(lines) + "\n")
    return files + [HASHES]


def write_archive(files: list[Path]) -> None:
    temporary = ARCHIVE.with_suffix(ARCHIVE.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files, key=lambda item: item.relative_to(WORK).as_posix()):
            relative = path.relative_to(WORK).as_posix()
            archive.write(path, f"{PREFIX}/{relative}")
    os.replace(temporary, ARCHIVE)


def validate_archive() -> dict:
    with zipfile.ZipFile(ARCHIVE, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"CRC failure: {bad}")
        names = set(archive.namelist())
        hash_member = f"{PREFIX}/HASHES.sha256"
        if hash_member not in names:
            raise RuntimeError("HASHES.sha256 missing from archive")
        lines = archive.read(hash_member).decode("utf-8").splitlines()
        validated = 0
        for line in lines:
            expected, relative = line.split(" *", 1)
            member = f"{PREFIX}/{relative}"
            if member not in names:
                raise RuntimeError(f"archive member missing: {member}")
            observed = hashlib.sha256(archive.read(member)).hexdigest()
            if observed != expected:
                raise RuntimeError(f"archive member hash mismatch: {member}")
            validated += 1
        expected_names = {f"{PREFIX}/{relative}" for _, relative in (line.split(" *", 1) for line in lines)}
        expected_names.add(hash_member)
        if names != expected_names:
            extras = sorted(names - expected_names)
            missing = sorted(expected_names - names)
            raise RuntimeError(f"archive membership mismatch extras={extras} missing={missing}")
    return {
        "archive": str(ARCHIVE),
        "archive_sha256": sha256_path(ARCHIVE),
        "archive_bytes": ARCHIVE.stat().st_size,
        "members": len(names),
        "member_hashes_validated": validated,
        "crc": "PASS",
    }


def main() -> int:
    files = write_manifest_and_hashes()
    write_archive(files)
    validation = validate_archive()
    print(json.dumps(validation, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
