#!/usr/bin/env python3
"""NRD00: cheap native-process pilots used only to choose informative apparatuses."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


HERE = Path(__file__).resolve()
WORK = HERE.parents[1]
OUT = WORK / "RESULTS" / "NRD00_native_pilots.json"


def boundary_faces(mask: np.ndarray) -> int:
    return int(sum(np.count_nonzero(mask != np.roll(mask, 1, axis=axis)) for axis in range(3)))


def proposal_graph(raw: np.ndarray) -> dict:
    decoded = fields(raw)
    positive = decoded["state"] != 0
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    source = np.argwhere(routed)
    if not len(source):
        return {
            "sources": 0,
            "positive": int(np.count_nonzero(positive)),
            "unique_destinations": 0,
            "collision_excess": 0,
            "occupied_destination_fraction": 0.0,
            "reciprocal_edges": 0,
            "cycle_count": 0,
            "cycle_nodes": 0,
            "max_cycle": 0,
            "indegree_entropy": 0.0,
            "boundary_faces": boundary_faces(positive),
        }
    directions = np.column_stack((decoded["dx"][routed], decoded["dy"][routed], decoded["dz"][routed])).astype(np.int64)
    destination = (source.astype(np.int64) + directions) % raw.shape[0]
    source_flat = np.ravel_multi_index(source.T, raw.shape)
    destination_flat = np.ravel_multi_index(destination.T, raw.shape)
    unique, counts = np.unique(destination_flat, return_counts=True)
    probabilities = counts.astype(np.float64) / counts.sum()
    adjacency = {int(a): int(b) for a, b in zip(source_flat, destination_flat)}
    reciprocal = sum(adjacency.get(target) == start for start, target in adjacency.items())
    visited_global: set[int] = set()
    cycles: list[int] = []
    for start in adjacency:
        if start in visited_global:
            continue
        order: dict[int, int] = {}
        node = start
        while node in adjacency and node not in order and node not in visited_global:
            order[node] = len(order)
            node = adjacency[node]
        if node in order:
            cycles.append(len(order) - order[node])
        visited_global.update(order)
    return {
        "sources": int(len(source)),
        "positive": int(np.count_nonzero(positive)),
        "unique_destinations": int(len(unique)),
        "collision_excess": int(len(source) - len(unique)),
        "multi_source_destinations": int(np.count_nonzero(counts > 1)),
        "max_indegree": int(np.max(counts)),
        "occupied_destination_fraction": float(np.mean(positive.reshape(-1)[unique])),
        "reciprocal_edges": int(reciprocal),
        "cycle_count": len(cycles),
        "cycle_nodes": int(sum(cycles)),
        "max_cycle": int(max(cycles, default=0)),
        "indegree_entropy": float(-np.sum(probabilities * np.log(probabilities))),
        "boundary_faces": boundary_faces(positive),
    }


def toroidal_region(shape: tuple[int, int, int], center: tuple[int, int, int], radius: int) -> np.ndarray:
    axes = []
    for size, coordinate in zip(shape, center):
        delta = ((np.arange(size) - coordinate + size // 2) % size) - size // 2
        axes.append(np.abs(delta) <= radius)
    return axes[0][:, None, None] & axes[1][None, :, None] & axes[2][None, None, :]


def region_readout(raw: np.ndarray, clock: np.ndarray, center: tuple[int, int, int], radius: int = 2) -> dict:
    mask = toroidal_region(raw.shape, center, radius)
    decoded = fields(raw)
    positive = decoded["state"] != 0
    routed = (decoded["dx"] != 0) | (decoded["dy"] != 0) | (decoded["dz"] != 0)
    return {
        "positive": int(np.count_nonzero(positive & mask)),
        "routed": int(np.count_nonzero(routed & mask)),
        "raw_nonzero": int(np.count_nonzero((raw != 0) & mask)),
        "state_sum": int(np.sum(decoded["state"][mask], dtype=np.uint64)),
        "sreg_sum": int(np.sum(decoded["sreg"][mask], dtype=np.uint64)),
        "dx_sum": int(np.sum(decoded["dx"][mask], dtype=np.int64)),
        "semantic_hist": np.bincount(decoded["semantic"][mask].astype(np.int64), minlength=16).tolist(),
        "clock_sum": int(np.sum(clock[mask], dtype=np.uint64)),
        "region_raw_sha256": sha256_array(raw[mask]),
    }


def detector_seed(n: int = 18) -> tuple[np.ndarray, np.ndarray, tuple[int, int, int]]:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    center = (10, 8, 8)
    for x in (10, 11):
        for y in (8, 9):
            for z in (8, 9):
                raw[x, y, z] = pack(1, 11 + x + y + z, (0, 0, 0), 1)
                clock[x, y, z] = np.uint64((x + 3 * y + 7 * z) % 17)
    return raw, clock, center


def run_detector(kernel, arm: str, dose: int, translation: int) -> dict:
    raw, clock, center = detector_seed()
    raw = np.roll(raw, translation, axis=2)
    clock = np.roll(clock, translation, axis=2)
    center = (center[0], center[1], (center[2] + translation) % raw.shape[2])
    if arm != "none":
        source = (2, 8, (8 + translation) % raw.shape[2])
        direction = (1, 0, 0) if arm == "hit" else (0, 1, 0)
        raw[source] = pack(1, dose, direction, 1)
        clock[source] = np.uint64(0)
    world = NativeWorld(kernel, raw, clock, 1)
    trace = []
    for tick in range(15):
        trace.append({
            "tick": tick,
            "detector": region_readout(world.raw, world.clock, center, 2),
            "graph": proposal_graph(world.raw),
        })
        if tick < 14:
            world.tick()
    return {
        "arm": arm,
        "dose": dose,
        "translation": translation,
        "center": center,
        "initial_detector": trace[0]["detector"],
        "final_detector": trace[-1]["detector"],
        "trace": trace,
    }


def inject(world: NativeWorld, site: tuple[int, int, int], value: np.uint64) -> None:
    world.raw_a[site] = value
    world.raw_b[site] = value


def run_sequence(kernel, order: str, translation: int) -> dict:
    raw, clock, center = detector_seed()
    raw = np.roll(raw, translation, axis=2)
    clock = np.roll(clock, translation, axis=2)
    center = (center[0], center[1], (center[2] + translation) % raw.shape[2])
    world = NativeWorld(kernel, raw, clock, 1)
    events = {
        "X": ((2, 8, (8 + translation) % 18), pack(1, 29, (1, 0, 0), 1)),
        "Y": ((10, 0, (8 + translation) % 18), pack(1, 47, (0, 1, 0), 1)),
    }
    schedule = [(0, order[0]), (3, order[1])] if order != "simultaneous" else [(0, "X"), (0, "Y")]
    trace = []
    for tick in range(16):
        for event_tick, symbol in schedule:
            if event_tick == tick:
                inject(world, *events[symbol])
        trace.append({"tick": tick, "detector": region_readout(world.raw, world.clock, center, 2), "graph": proposal_graph(world.raw)})
        if tick < 15:
            world.tick()
    return {
        "order": order,
        "translation": translation,
        "schedule": schedule,
        "final_detector": trace[-1]["detector"],
        "trace": trace,
    }


def run_propagation(kernel, n: int, direction: tuple[int, int, int], state: int, sreg: int) -> dict:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    start = np.array((n // 3, n // 3, n // 3), dtype=np.int64)
    raw[tuple(start)] = pack(state, sreg, direction, 1)
    world = NativeWorld(kernel, raw, threads=1)
    trace = []
    for tick in range(min(n // 2, 8) + 1):
        decoded = fields(world.raw)
        coords = np.argwhere(decoded["state"] != 0)
        displacement = []
        for coord in coords:
            delta = ((coord - start + n // 2) % n) - n // 2
            displacement.append(delta.tolist())
        trace.append({
            "tick": tick,
            "positive_sites": len(coords),
            "displacements": displacement,
            "graph": proposal_graph(world.raw),
        })
        if tick < min(n // 2, 8):
            world.tick()
    return {"N": n, "direction": direction, "state": state, "sreg": sreg, "trace": trace}


def random_world(n: int, seed: int, sources: int = 14) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    indices = rng.choice(raw.size, size=sources, replace=False)
    directions = np.asarray(((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)))
    for flat, d_index in zip(indices, rng.integers(0, len(directions), size=sources)):
        site = np.unravel_index(int(flat), raw.shape)
        raw[site] = pack(1, int(rng.integers(1, 65)), tuple(int(x) for x in directions[d_index]), 1)
        clock[site] = np.uint64(rng.integers(0, 32))
    return raw, clock


def ensemble_panel(kernel) -> dict:
    rows = []
    for replicate in range(48):
        seed = int.from_bytes(hashlib.sha256(f"NRD00|ensemble|{replicate}".encode()).digest()[:8], "little")
        raw, clock = random_world(10, seed)
        world = NativeWorld(kernel, raw, clock, 1)
        trace = []
        for tick in range(9):
            graph = proposal_graph(world.raw)
            trace.append({
                "tick": tick,
                "raw_sha256": sha256_array(world.raw),
                "macro": [graph["positive"], graph["sources"], graph["unique_destinations"], graph["collision_excess"], graph["cycle_nodes"], graph["boundary_faces"]],
            })
            if tick < 8:
                world.tick()
        rows.append({"replicate": replicate, "trace": trace})
    by_tick = []
    for tick in range(9):
        raw_hashes = [row["trace"][tick]["raw_sha256"] for row in rows]
        macros = [tuple(row["trace"][tick]["macro"]) for row in rows]
        counts = Counter(macros)
        probability = np.asarray(list(counts.values()), dtype=np.float64) / len(macros)
        by_tick.append({
            "tick": tick,
            "unique_raw_states": len(set(raw_hashes)),
            "unique_macro_states": len(counts),
            "macro_shannon_nats": float(-np.sum(probability * np.log(probability))),
            "largest_macro_fiber": max(counts.values()),
        })
    return {"worlds": len(rows), "by_tick": by_tick, "rows": rows}


def main() -> int:
    kernel, environment = verify_and_load_kernel(1)
    detector_cases = [
        run_detector(kernel, arm, dose, translation)
        for arm in ("none", "miss", "hit")
        for dose in (1, 17, 63)
        for translation in (0, 3)
    ]
    sequence_cases = [run_sequence(kernel, order, translation) for order in ("XY", "YX", "simultaneous") for translation in (0, 3)]
    propagation_cases = [
        run_propagation(kernel, n, direction, state, sreg)
        for n in (14, 18, 22)
        for direction in ((1, 0, 0), (1, 1, 0), (0, 0, -1))
        for state, sreg in ((1, 1), (7, 63))
    ]
    result = {
        "schema": "dee.v27.native_reality.nrd00.v1",
        "experiment_id": "NRD00_NATIVE_PILOTS",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "questions": [
            "Can a localized DEE organization retain information about hit versus matched miss source processes?",
            "Does detector history distinguish source ordering with the same two event types?",
            "Which propagation speed is actually realized by isolated routed carriers?",
            "Do sparse ensembles contract into shared relational macrostates before microstates coincide?"
        ],
        "kernel_environment": environment,
        "detector_cases": detector_cases,
        "sequence_cases": sequence_cases,
        "propagation_cases": propagation_cases,
        "ensemble": ensemble_panel(kernel),
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    detector_counter = Counter((case["arm"], case["final_detector"]["positive"], case["final_detector"]["sreg_sum"]) for case in detector_cases)
    summary = {
        "detector_final": [
            {"arm": key[0], "positive": key[1], "sreg_sum": key[2], "cases": count}
            for key, count in sorted(detector_counter.items())
        ],
        "sequence_final": {f"{case['order']}|z{case['translation']}": (case["final_detector"]["positive"], case["final_detector"]["sreg_sum"], case["final_detector"]["region_raw_sha256"]) for case in sequence_cases},
        "propagation_all_singleton": all(all(row["positive_sites"] == 1 for row in case["trace"]) for case in propagation_cases),
        "ensemble_by_tick": result["ensemble"]["by_tick"],
    }
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
