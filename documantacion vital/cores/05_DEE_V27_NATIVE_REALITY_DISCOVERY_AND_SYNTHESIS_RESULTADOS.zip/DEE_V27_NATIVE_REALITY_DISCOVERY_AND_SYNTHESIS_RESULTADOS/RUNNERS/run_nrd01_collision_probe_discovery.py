#!/usr/bin/env python3
"""NRD01: process-native synchronized interaction and downstream record discovery."""
from __future__ import annotations

import json
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "NRD01_collision_probe_discovery.json"

PROBE_D = (0, 1, 0)
TARGET_DIRECTIONS = ((1, 0, 0), (-1, 0, 0), (0, 0, 1), (0, 0, -1))


def add(q: tuple[int, int, int], d: tuple[int, int, int], scale: int, n: int) -> tuple[int, int, int]:
    return tuple((q[i] + scale * d[i]) % n for i in range(3))


def sparse_snapshot(raw: np.ndarray) -> list[dict]:
    f = fields(raw)
    rows: list[dict] = []
    for coord in np.argwhere(raw != 0):
        q = tuple(int(v) for v in coord)
        rows.append(
            {
                "q": list(q),
                "raw": int(raw[q]),
                "state": int(f["state"][q]),
                "sreg": int(f["sreg"][q]),
                "d": [int(f[axis][q]) for axis in ("dx", "dy", "dz")],
                "semantic": int(f["semantic"][q]),
            }
        )
    return rows


def run_case(
    kernel,
    *,
    n: int,
    center: tuple[int, int, int],
    distance: int,
    target_d: tuple[int, int, int] | None,
    phase: int,
    probe_state: int,
    probe_sreg: int,
    target_state: int,
    target_sreg: int,
    clock_code: int,
) -> dict:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    probe_start = add(center, PROBE_D, -distance, n)
    raw[probe_start] = pack(probe_state, probe_sreg, PROBE_D, 1)
    clock[probe_start] = np.uint64(clock_code)
    target_start = None
    if target_d is not None:
        target_start = add(center, target_d, -(distance + phase), n)
        if target_start == probe_start:
            raise RuntimeError("source overlap in NRD01 design")
        raw[target_start] = pack(target_state, target_sreg, target_d, 1)
        clock[target_start] = np.uint64((clock_code * 7 + 11) & 0xFFFFFFFFFFFFFFFF)

    world = NativeWorld(kernel, raw, clock, threads=1)
    snapshots = [{"tick": 0, "cells": sparse_snapshot(world.raw)}]
    infos = []
    for tick in range(1, distance + 4):
        infos.append(world.tick())
        snapshots.append({"tick": tick, "cells": sparse_snapshot(world.raw)})

    at_event = snapshots[distance]["cells"]
    center_rows = [row for row in at_event if tuple(row["q"]) == center]
    expected_d = None if target_d is None else [int(np.sign(PROBE_D[i] + target_d[i])) for i in range(3)]
    merged_at_center = bool(target_d is not None and phase == 0 and len(at_event) == 1 and len(center_rows) == 1)
    output_direction = center_rows[0]["d"] if len(center_rows) == 1 else None
    expected_sreg = None if target_d is None else min(probe_sreg + target_sreg, 19664)
    exact_response = bool(
        merged_at_center
        and output_direction == expected_d
        and center_rows[0]["sreg"] == expected_sreg
        and center_rows[0]["state"] == 1
        and center_rows[0]["semantic"] == 1
    )
    next_rows = snapshots[distance + 1]["cells"]
    expected_next = add(center, tuple(expected_d), 1, n) if expected_d is not None else None
    downstream_exact = bool(
        exact_response
        and len(next_rows) == 1
        and tuple(next_rows[0]["q"]) == expected_next
        and next_rows[0]["d"] == expected_d
    )
    no_evolution_output_empty = all(tuple(row["q"]) != center for row in snapshots[0]["cells"])
    return {
        "n": n,
        "center": list(center),
        "distance": distance,
        "probe_start": list(probe_start),
        "target_start": None if target_start is None else list(target_start),
        "target_d": None if target_d is None else list(target_d),
        "phase": phase,
        "nuisance": {
            "probe_state": probe_state,
            "probe_sreg": probe_sreg,
            "target_state": target_state,
            "target_sreg": target_sreg,
            "clock_code": clock_code,
        },
        "expected_d": expected_d,
        "expected_sreg": expected_sreg,
        "merged_at_center": merged_at_center,
        "exact_response": exact_response,
        "downstream_exact": downstream_exact,
        "no_evolution_output_empty": no_evolution_output_empty,
        "trace": snapshots,
        "kernel_info": infos,
    }


def main() -> int:
    kernel, environment = verify_and_load_kernel(1)
    designs = [
        (18, (9, 9, 9), 4),
        (23, (11, 12, 10), 5),
        (28, (14, 13, 15), 6),
        (23, (4, 17, 6), 5),
    ]
    nuisances = [
        (1, 3, 1, 5, 0),
        (7, 63, 11, 257, 29),
        (19, 10000, 23, 10000, 65537),
    ]
    cases: list[dict] = []
    # Matched no-target baselines.
    for n, center, distance in designs:
        for nuisance in nuisances:
            cases.append(
                run_case(
                    kernel,
                    n=n,
                    center=center,
                    distance=distance,
                    target_d=None,
                    phase=0,
                    probe_state=nuisance[0],
                    probe_sreg=nuisance[1],
                    target_state=nuisance[2],
                    target_sreg=nuisance[3],
                    clock_code=nuisance[4],
                )
            )
    # Synchronized target and temporal-shuffle controls.
    for n, center, distance in designs:
        for target_d in TARGET_DIRECTIONS:
            for phase in (-2, -1, 0, 1, 2):
                for nuisance in nuisances:
                    cases.append(
                        run_case(
                            kernel,
                            n=n,
                            center=center,
                            distance=distance,
                            target_d=target_d,
                            phase=phase,
                            probe_state=nuisance[0],
                            probe_sreg=nuisance[1],
                            target_state=nuisance[2],
                            target_sreg=nuisance[3],
                            clock_code=nuisance[4],
                        )
                    )

    sync = [case for case in cases if case["target_d"] is not None and case["phase"] == 0]
    async_cases = [case for case in cases if case["target_d"] is not None and case["phase"] != 0]
    no_target = [case for case in cases if case["target_d"] is None]
    class_counter = Counter(tuple(case["trace"][case["distance"]]["cells"][0]["d"]) for case in sync if len(case["trace"][case["distance"]]["cells"]) == 1)
    response_by_target: dict[str, dict] = {}
    for target_d in TARGET_DIRECTIONS:
        group = [case for case in sync if tuple(case["target_d"]) == target_d]
        response_by_target[str(target_d)] = {
            "cases": len(group),
            "exact": sum(case["exact_response"] for case in group),
            "downstream_exact": sum(case["downstream_exact"] for case in group),
            "distinct_records": sorted({tuple(case["expected_d"]) for case in group}),
        }

    result = {
        "schema": "dee.v27.native_reality.nrd01.v1",
        "experiment_id": "NRD01_SYNCHRONIZED_INTERACTION_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can one routed DEE process act as an operational probe whose downstream state records the direction class and temporal coincidence of another routed process?",
        "competing_hypotheses": {
            "H_relational_detector": "A common proposal destination at the same tick creates a robust downstream record determined by the incoming relation.",
            "H_inventory_only": "Matched source inventories give the same relevant output regardless of temporal relation.",
            "H_nuisance": "Any apparent record depends materially on N, placement, source state, s_reg or clock.",
        },
        "operational_roles": {
            "system_A": "transverse target carrier process",
            "apparatus_B": "probe carrier plus the downstream one-tick output port",
            "intervention": "target direction and relative arrival phase",
            "record": "presence, destination, direction and s_reg of the resolved output carrier",
            "destroyed_control": "same source types and values with target arrival shifted by one or two ticks",
            "no_evolution_control": "output destination is empty in the encoded initial world",
        },
        "kernel_environment": environment,
        "summary": {
            "total_cases": len(cases),
            "synchronized_cases": len(sync),
            "synchronized_exact": sum(case["exact_response"] for case in sync),
            "synchronized_downstream_exact": sum(case["downstream_exact"] for case in sync),
            "asynchronous_cases": len(async_cases),
            "asynchronous_merged_at_nominal_event": sum(case["merged_at_center"] for case in async_cases),
            "no_target_cases": len(no_target),
            "no_target_single_probe_at_center": sum(
                len(case["trace"][case["distance"]]["cells"]) == 1
                and tuple(case["trace"][case["distance"]]["cells"][0]["q"]) == tuple(case["center"])
                and case["trace"][case["distance"]]["cells"][0]["d"] == list(PROBE_D)
                for case in no_target
            ),
            "all_initial_output_ports_empty": all(case["no_evolution_output_empty"] for case in cases),
            "response_classes": {str(key): value for key, value in sorted(class_counter.items())},
            "response_by_target": response_by_target,
        },
        "cases": cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(result["summary"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
