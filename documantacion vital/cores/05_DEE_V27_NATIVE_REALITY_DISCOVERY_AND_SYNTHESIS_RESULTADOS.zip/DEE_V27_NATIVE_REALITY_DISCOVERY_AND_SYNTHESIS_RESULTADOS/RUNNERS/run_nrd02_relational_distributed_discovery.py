#!/usr/bin/env python3
"""NRD02: destination-fiber quotient and persistent distributed-source network."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "NRD02_relational_distributed_discovery.json"


def add(q, d, k, n):
    return tuple((int(q[i]) + k * int(d[i])) % n for i in range(3))


def row_at(raw: np.ndarray, q: tuple[int, int, int]) -> dict | None:
    value = int(raw[q])
    if value == 0:
        return None
    f = fields(raw)
    return {
        "raw": value,
        "state": int(f["state"][q]),
        "sreg": int(f["sreg"][q]),
        "d": [int(f[k][q]) for k in ("dx", "dy", "dz")],
        "semantic": int(f["semantic"][q]),
    }


def destination_fibers(raw: np.ndarray) -> list[dict]:
    f = fields(raw)
    groups: dict[tuple[int, int, int], list[tuple[tuple[int, int, int], int]]] = defaultdict(list)
    n = raw.shape[0]
    for coord in np.argwhere(raw != 0):
        q = tuple(int(v) for v in coord)
        d = tuple(int(f[key][q]) for key in ("dx", "dy", "dz"))
        if d != (0, 0, 0):
            groups[add(q, d, 1, n)].append((d, int(f["sreg"][q])))
    result = []
    for target, incoming in sorted(groups.items()):
        vector_sum = tuple(sum(item[0][axis] for item in incoming) for axis in range(3))
        result.append({
            "target": list(target),
            "multiplicity": len(incoming),
            "vector_sum": list(vector_sum),
            "direction_out": [int(np.sign(v)) for v in vector_sum],
            "sreg_sum": sum(item[1] for item in incoming),
            "sreg_out": min(sum(item[1] for item in incoming), 19664),
        })
    return result


def predict_from_fibers(n: int, fibers: list[dict]) -> np.ndarray:
    predicted = np.zeros((n, n, n), dtype=np.uint64)
    for fiber in fibers:
        predicted[tuple(fiber["target"])] = pack(1, fiber["sreg_out"], tuple(fiber["direction_out"]), 1)
    return predicted


def place_inventory(rng, n: int, directions: list[tuple[int, int, int]], sregs: list[int], group_sizes: list[int]) -> np.ndarray:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    used_sources: set[tuple[int, int, int]] = set()
    used_targets: set[tuple[int, int, int]] = set()
    offset = 0
    for group_size in group_sizes:
        group_d = directions[offset : offset + group_size]
        group_s = sregs[offset : offset + group_size]
        offset += group_size
        for _ in range(10000):
            target = tuple(int(x) for x in rng.integers(0, n, size=3))
            sources = [add(target, d, -1, n) for d in group_d]
            if target in used_sources or target in used_targets:
                continue
            if len(set(sources)) != len(sources):
                continue
            if any(source in used_sources or source in used_targets for source in sources):
                continue
            used_targets.add(target)
            used_sources.update(sources)
            for source, d, sreg in zip(sources, group_d, group_s, strict=True):
                raw[source] = pack(0, sreg, d, 1)
            break
        else:
            raise RuntimeError("could not place matched inventory")
    if offset != len(directions):
        raise RuntimeError("group sizes do not consume inventory")
    return raw


def fiber_experiment(kernel) -> dict:
    directions = [
        (1,0,0),(0,1,0),(0,0,1),
        (1,1,0),(1,0,1),(0,1,1),
        (-1,0,0),(0,-1,0),(0,0,-1),
        (1,-1,0),(1,0,-1),(0,1,-1),
    ]
    pairs = []
    for pair_index in range(36):
        n = (11, 13, 17)[pair_index % 3]
        rng = np.random.default_rng(70001 + pair_index * 97)
        sregs = [int(x) for x in rng.integers(0, 5000, size=len(directions))]
        raw_spread = place_inventory(rng, n, directions, sregs, [1] * 12)
        raw_clustered = place_inventory(rng, n, directions, sregs, [3, 3, 3, 3])
        pair_rows = []
        for geometry, raw in (("spread", raw_spread), ("clustered", raw_clustered)):
            fibers = destination_fibers(raw)
            predicted = predict_from_fibers(n, fibers)
            initial_hash = sha256_array(raw)
            world = NativeWorld(kernel, raw, threads=1)
            info = world.tick()
            observed = world.raw.copy()
            pair_rows.append({
                "geometry": geometry,
                "initial_raw_sha256": initial_hash,
                "inventory": {
                    "source_count": len(directions),
                    "direction_multiset": sorted([list(d) for d in directions]),
                    "sreg_multiset": sorted(sregs),
                },
                "fiber_count": len(fibers),
                "fiber_record": fibers,
                "compression_source_to_fiber": len(directions) / len(fibers),
                "predicted_raw_sha256": sha256_array(predicted),
                "observed_raw_sha256": sha256_array(observed),
                "full_raw_exact": bool(np.array_equal(predicted, observed)),
                "positive_out": int(np.count_nonzero(fields(observed)["state"])),
                "kernel_info": info,
            })
        pairs.append({
            "pair_index": pair_index,
            "n": n,
            "same_inventory": pair_rows[0]["inventory"] == pair_rows[1]["inventory"],
            "future_raw_distinct": pair_rows[0]["observed_raw_sha256"] != pair_rows[1]["observed_raw_sha256"],
            "future_support_distinct": pair_rows[0]["positive_out"] != pair_rows[1]["positive_out"],
            "arms": pair_rows,
        })
    arms = [arm for pair in pairs for arm in pair["arms"]]
    return {
        "question": "Does the destination-fiber partition close one-step routed dynamics where matched global inventory does not?",
        "domain": "normal semantic-1 state-zero routers, blank destinations, zero overflow and one tick",
        "candidate_Z": "map target -> (incoming multiplicity, vector sum, summed s_reg), resolved by sign and cap",
        "pairs": pairs,
        "summary": {
            "pairs": len(pairs),
            "same_inventory_pairs": sum(pair["same_inventory"] for pair in pairs),
            "inventory_matched_future_raw_distinct": sum(pair["future_raw_distinct"] for pair in pairs),
            "inventory_matched_future_support_distinct": sum(pair["future_support_distinct"] for pair in pairs),
            "fiber_predictions_exact": sum(arm["full_raw_exact"] for arm in arms),
            "fiber_predictions_total": len(arms),
            "mean_cluster_compression": float(np.mean([pair["arms"][1]["compression_source_to_fiber"] for pair in pairs])),
        },
    }


SOURCE_DIRECTIONS = ((1,0,0),(1,1,0),(1,0,1),(1,1,1))
SOURCE_SREGS = (2,3,5,7)


def network_initial(n: int, center: tuple[int, int, int], distance: int, arm: str) -> tuple[np.ndarray, list[tuple[int,int,int]]]:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    sources = [add(center, d, -distance, n) for d in SOURCE_DIRECTIONS]
    for index, (source, d, sreg) in enumerate(zip(sources, SOURCE_DIRECTIONS, SOURCE_SREGS, strict=True)):
        if arm == f"ablate_{index}":
            continue
        placement = source
        if arm == "spatial_rewire":
            shifts = ((0,2,0),(0,0,2),(0,-2,0),(0,0,-2))
            placement = add(source, shifts[index], 1, n)
        raw[placement] = pack(0, sreg, d, 4)
        if arm == f"block_{index}":
            raw[add(source, d, 1, n)] = pack(1, 1, (0,0,0), 1)
    return raw, sources


def simulate_network(kernel, n, center, distance, arm, ticks) -> dict:
    raw, sources = network_initial(n, center, distance, arm)
    world = NativeWorld(kernel, raw, threads=1)
    snapshots = []
    raws = []
    for tick in range(ticks + 1):
        raws.append(world.raw.copy())
        f = fields(world.raw)
        snapshots.append({
            "tick": tick,
            "raw_nonzero": int(np.count_nonzero(world.raw)),
            "positive": int(np.count_nonzero(f["state"])),
            "semantic4": int(np.count_nonzero(f["semantic"] == 4)),
            "hub": row_at(world.raw, center),
            "downstream": [row_at(world.raw, add(center, (1,1,1), k, n)) for k in range(1, 6)],
            "raw_sha256": sha256_array(world.raw),
        })
        if tick < ticks:
            world.tick()
    return {"arm": arm, "sources": [list(q) for q in sources], "trace": snapshots, "_raws": raws}


def distributed_experiment(kernel) -> dict:
    designs = [
        (25, (12,12,12), 5, 18),
        (31, (16,14,15), 6, 21),
        (35, (7,23,18), 7, 24),
    ]
    results = []
    arms = ["baseline"] + [f"ablate_{i}" for i in range(4)] + [f"block_{i}" for i in range(4)] + ["spatial_rewire"]
    for n, center, distance, ticks in designs:
        runs = {arm: simulate_network(kernel, n, center, distance, arm, ticks) for arm in arms}
        baseline_raws = runs["baseline"]["_raws"]
        baseline_events = [row["tick"] for row in runs["baseline"]["trace"] if row["hub"] is not None]
        summaries = {}
        for arm, run in runs.items():
            hub_events = [row for row in run["trace"] if row["hub"] is not None]
            hamming = [int(np.count_nonzero(a != b)) for a, b in zip(baseline_raws, run["_raws"], strict=True)]
            summaries[arm] = {
                "hub_event_ticks": [row["tick"] for row in hub_events],
                "hub_event_records": [row["hub"] for row in hub_events],
                "hamming_from_baseline": hamming,
                "difference_persists_after_tick_1": any(value > 0 for value in hamming[2:]),
                "semantic4_final": run["trace"][-1]["semantic4"],
            }
            del run["_raws"]
        ablation_records = [record for arm in summaries if arm.startswith("ablate_") for record in summaries[arm]["hub_event_records"]]
        results.append({
            "n": n,
            "center": list(center),
            "distance": distance,
            "ticks": ticks,
            "baseline_event_ticks": baseline_events,
            "all_ablation_hub_directions_111": all(record["d"] == [1,1,1] for record in ablation_records),
            "all_block_differences_persist": all(summaries[f"block_{i}"]["difference_persists_after_tick_1"] for i in range(4)),
            "spatial_rewire_hub_events": len(summaries["spatial_rewire"]["hub_event_ticks"]),
            "summaries": summaries,
            "runs": runs,
        })
    return {
        "question": "Can persistent local sources form a controller-free integration process with redundancy and history-conditioned global output?",
        "apparatus": "four semantic-4 state-zero persistent sources whose directed emission paths meet at one hub",
        "arms": "baseline, each single-source ablation, each one-tick mouth block, and matched source inventory with spatial rewiring",
        "results": results,
        "summary": {
            "designs": len(results),
            "baseline_has_hub_events": sum(bool(r["baseline_event_ticks"]) for r in results),
            "single_ablation_direction_class_robust": sum(r["all_ablation_hub_directions_111"] for r in results),
            "transient_blocks_leave_later_difference": sum(r["all_block_differences_persist"] for r in results),
            "spatial_rewire_total_hub_events": sum(r["spatial_rewire_hub_events"] for r in results),
        },
    }


def main() -> int:
    kernel, environment = verify_and_load_kernel(1)
    result = {
        "schema": "dee.v27.native_reality.nrd02.v1",
        "experiment_id": "NRD02_RELATIONAL_DISTRIBUTED_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "kernel_environment": environment,
        "destination_fiber": fiber_experiment(kernel),
        "distributed_network": distributed_experiment(kernel),
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({
        "destination_fiber": result["destination_fiber"]["summary"],
        "distributed_network": result["distributed_network"]["summary"],
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
