#!/usr/bin/env python3
"""NRD02B: distinguish persistent mouth obstruction from post-removal phase memory."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "NRD02B_block_memory_diagnostic.json"
DIRECTIONS = ((1,0,0),(1,1,0),(1,0,1),(1,1,1))
SREGS = (2,3,5,7)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[k][q]) for k in ("dx","dy","dz")], "semantic": int(f["semantic"][q]), "raw": int(raw[q])}


def make_raw(n, center, distance, blocked_index=None):
    raw = np.zeros((n,n,n), dtype=np.uint64)
    sources = []
    mouths = []
    for i,(d,s) in enumerate(zip(DIRECTIONS,SREGS,strict=True)):
        source = add(center,d,-distance,n)
        mouth = add(source,d,1,n)
        sources.append(source)
        mouths.append(mouth)
        raw[source] = pack(0,s,d,4)
        if blocked_index == i:
            raw[mouth] = pack(1,1,(0,0,0),1)
    return raw,sources,mouths


def simulate(kernel,n,center,distance,ticks,mode,index=None):
    raw,sources,mouths = make_raw(n,center,distance,index if mode != "baseline" else None)
    world = NativeWorld(kernel,raw,threads=1)
    trace=[]
    copies=[]
    for tick in range(ticks+1):
        copies.append(world.raw.copy())
        trace.append({
            "tick":tick,
            "hub":decode(world.raw,center),
            "mouths":[decode(world.raw,q) for q in mouths],
            "sources":[decode(world.raw,q) for q in sources],
            "raw_nonzero":int(np.count_nonzero(world.raw)),
            "raw_sha256":sha256_array(world.raw),
        })
        if tick == ticks:
            break
        world.tick()
        if mode == "forced_remove_after_tick1" and tick+1 == 1:
            mouth = mouths[index]
            world.raw_a[mouth] = np.uint64(0)
            world.raw_b[mouth] = np.uint64(0)
            world.clock_a[mouth] = np.uint64(0)
            world.clock_b[mouth] = np.uint64(0)
    return {"mode":mode,"blocked_index":index,"sources":[list(x) for x in sources],"mouths":[list(x) for x in mouths],"trace":trace,"_raws":copies}


def main():
    kernel,environment=verify_and_load_kernel(1)
    panels=[]
    for n,center,distance,ticks in ((25,(12,12,12),5,18),(31,(16,14,15),6,21),(35,(7,23,18),7,24)):
        baseline=simulate(kernel,n,center,distance,ticks,"baseline")
        runs=[]
        for i in range(4):
            runs.append(simulate(kernel,n,center,distance,ticks,"unforced_initial_block",i))
            runs.append(simulate(kernel,n,center,distance,ticks,"forced_remove_after_tick1",i))
        summaries=[]
        for run in runs:
            idx=run["blocked_index"]
            hamming=[int(np.count_nonzero(a!=b)) for a,b in zip(baseline["_raws"],run["_raws"],strict=True)]
            mouth_present=[row["mouths"][idx] is not None for row in run["trace"]]
            hub=[(row["tick"],row["hub"]) for row in run["trace"] if row["hub"] is not None]
            summaries.append({
                "mode":run["mode"],
                "blocked_index":idx,
                "mouth_present":mouth_present,
                "mouth_present_after_tick1":sum(mouth_present[2:]),
                "hamming_from_baseline":hamming,
                "difference_persists_after_intervention_removed":any(v>0 for v in hamming[2:]),
                "hub_events":hub,
            })
            del run["_raws"]
        del baseline["_raws"]
        panels.append({"n":n,"center":list(center),"distance":distance,"ticks":ticks,"baseline":baseline,"runs":runs,"summaries":summaries})
    forced=[s for p in panels for s in p["summaries"] if s["mode"]=="forced_remove_after_tick1"]
    unforced=[s for p in panels for s in p["summaries"] if s["mode"]=="unforced_initial_block"]
    result={
        "schema":"dee.v27.native_reality.nrd02b.v1",
        "experiment_id":"NRD02B_BLOCK_MEMORY_DIAGNOSTIC",
        "role":"DISCOVERY_DIAGNOSTIC",
        "question":"Did NRD02 measure retained history after damage removal, or merely a surviving obstruction?",
        "kernel_environment":environment,
        "panels":panels,
        "summary":{
            "unforced_arms":len(unforced),
            "unforced_with_mouth_present_after_tick1":sum(s["mouth_present_after_tick1"]>0 for s in unforced),
            "forced_removal_arms":len(forced),
            "forced_mouth_absent_all_ticks_after_removal":sum(s["mouth_present_after_tick1"]==0 for s in forced),
            "forced_with_persistent_post_removal_difference":sum(s["difference_persists_after_intervention_removed"] for s in forced),
        },
    }
    result["content_sha256"]=canonical_hash(result)
    atomic_json(OUT,result)
    print(json.dumps(result["summary"],indent=2,sort_keys=True))
    return 0


if __name__=="__main__":
    raise SystemExit(main())
