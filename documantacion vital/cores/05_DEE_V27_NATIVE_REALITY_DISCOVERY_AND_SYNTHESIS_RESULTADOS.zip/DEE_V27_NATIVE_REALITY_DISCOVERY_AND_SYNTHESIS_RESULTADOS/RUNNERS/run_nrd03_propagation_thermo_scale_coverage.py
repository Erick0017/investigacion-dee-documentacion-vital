#!/usr/bin/env python3
"""NRD03: minimum informative coverage of propagation, ensembles and recursive scale."""
from __future__ import annotations

import itertools
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"NRD03_propagation_thermo_scale_coverage.json"
DIRECTIONS=[d for d in itertools.product((-1,0,1),repeat=3) if d!=(0,0,0)]


def add(q,d,k,n):
    return tuple((q[i]+k*d[i])%n for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:
        return None
    f=fields(raw)
    return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}


def barrier_seed(n,center,kind,with_probe,distance,sreg):
    raw=np.zeros((n,n,n),dtype=np.uint64)
    if kind=="state1_block":
        for x in (center[0],(center[0]+1)%n):
            for y in (center[1],(center[1]+1)%n):
                for z in (center[2],(center[2]+1)%n):
                    raw[x,y,z]=pack(1,11+x+y+z,(0,0,0),1)
    elif kind=="semantic4_point":
        raw[center]=pack(0,37,(0,0,0),4)
    elif kind=="state0_point":
        raw[center]=pack(0,37,(0,0,0),1)
    elif kind!="empty":
        raise ValueError(kind)
    if with_probe:
        raw[add(center,(1,0,0),-distance,n)]=pack(7,sreg,(1,0,0),1)
    return raw


def simulate(raw,kernel,ticks):
    world=NativeWorld(kernel,raw,threads=1)
    copies=[]
    for tick in range(ticks+1):
        copies.append(world.raw.copy())
        if tick<ticks:
            world.tick()
    return copies


def propagation_panel(kernel):
    cases=[]
    for n,center,distance in ((18,(9,8,10),5),(24,(12,13,11),6),(30,(16,14,15),7)):
        for kind in ("empty","state0_point","state1_block","semantic4_point"):
            for sreg in (1,19663):
                ticks=distance+4
                probe=simulate(barrier_seed(n,center,kind,True,distance,sreg),kernel,ticks)
                base=simulate(barrier_seed(n,center,kind,False,distance,sreg),kernel,ticks)
                trace=[]
                for tick,(a,b) in enumerate(zip(probe,base,strict=True)):
                    expected=add(center,(1,0,0),tick-distance,n)
                    f=fields(a)
                    reflected=int(np.count_nonzero((f["semantic"]==1)&(f["dx"]==-1)))
                    trace.append({
                        "tick":tick,
                        "expected_site":list(expected),
                        "expected_record":decode(a,expected),
                        "hamming_from_no_probe":int(np.count_nonzero(a!=b)),
                        "probe_world_sha256":sha256_array(a),
                        "baseline_sha256":sha256_array(b),
                        "negative_x_records":reflected,
                    })
                transmitted=all(
                    (trace[t]["expected_record"] is not None and trace[t]["expected_record"]["d"]==[1,0,0] and trace[t]["expected_record"]["sreg"]==sreg)
                    for t in range(distance+1,ticks+1)
                )
                absorbed=all(trace[t]["hamming_from_no_probe"]==0 for t in range(distance+1,ticks+1))
                reflected=any(trace[t]["negative_x_records"]>0 for t in range(distance,ticks+1))
                cases.append({"n":n,"center":list(center),"distance":distance,"medium":kind,"sreg":sreg,"transmitted_after_interface":transmitted,"absorbed_to_medium_baseline_after_interface":absorbed,"reflection_detected":reflected,"trace":trace})
    by_medium={}
    for kind in ("empty","state0_point","state1_block","semantic4_point"):
        group=[c for c in cases if c["medium"]==kind]
        by_medium[kind]={"cases":len(group),"transmitted":sum(c["transmitted_after_interface"] for c in group),"absorbed":sum(c["absorbed_to_medium_baseline_after_interface"] for c in group),"reflected":sum(c["reflection_detected"] for c in group)}
    return {
        "question":"How does a routed carrier respond to neutral, evanescent and persistent occupied interfaces?",
        "cases":cases,
        "summary":by_medium,
        "kinematic_context":{"free_speed_linf_per_tick":1,"euclidean_speeds_by_direction_support":{"axis":1.0,"face_diagonal":math.sqrt(2),"body_diagonal":math.sqrt(3)},"global_raw_causal_bound_chebyshev_per_tick":"inherited <=3; not identified with carrier speed"},
    }


def graph_macro(raw):
    f=fields(raw)
    coords=np.argwhere(raw!=0)
    n=raw.shape[0]
    dest=[]
    for coord in coords:
        q=tuple(int(v) for v in coord)
        d=tuple(int(f[k][q]) for k in ("dx","dy","dz"))
        if d!=(0,0,0):
            dest.append(add(q,d,1,n))
    counts=Counter(dest)
    positive=int(np.count_nonzero(f["state"]))
    return {
        "positive":positive,
        "raw_nonzero":int(len(coords)),
        "proposals":len(dest),
        "unique_destinations":len(counts),
        "collision_excess":sum(v-1 for v in counts.values()),
        "sreg_total":int(np.sum(f["sreg"],dtype=np.uint64)),
    }


def entropy(values):
    c=Counter(values); n=len(values)
    return -sum((v/n)*math.log2(v/n) for v in c.values())


def ensemble_panel(kernel):
    panels=[]
    for carrier_count in (8,32,96):
        rows=[]
        for world_index in range(48):
            n=10
            rng=np.random.default_rng(910000+carrier_count*1000+world_index)
            raw=np.zeros((n,n,n),dtype=np.uint64)
            flat=rng.choice(n**3,size=carrier_count,replace=False)
            for flat_q in flat:
                q=tuple(int(x) for x in np.unravel_index(int(flat_q),(n,n,n)))
                d=DIRECTIONS[int(rng.integers(0,len(DIRECTIONS)))]
                raw[q]=pack(int(rng.integers(1,32)),int(rng.integers(1,65)),d,1)
            world=NativeWorld(kernel,raw,threads=1)
            initial_sreg=graph_macro(world.raw)["sreg_total"]
            trace=[]
            seen={}
            recurrence=None
            for tick in range(21):
                macro=graph_macro(world.raw)
                digest=sha256_array(world.raw)
                if digest in seen and recurrence is None:
                    recurrence={"first":seen[digest],"repeat":tick,"period":tick-seen[digest]}
                seen.setdefault(digest,tick)
                trace.append({"tick":tick,**macro,"raw_sha256":digest,"sreg_ratio":macro["sreg_total"]/initial_sreg if initial_sreg else 1.0})
                if tick<20:
                    world.tick()
            rows.append({"world":world_index,"initial_sreg":initial_sreg,"recurrence":recurrence,"trace":trace})
        by_tick=[]
        transition_counts=Counter()
        for tick in range(21):
            states=[(r["trace"][tick]["positive"],r["trace"][tick]["proposals"],r["trace"][tick]["unique_destinations"],r["trace"][tick]["collision_excess"]) for r in rows]
            by_tick.append({
                "tick":tick,
                "macro_entropy_bits":entropy(states),
                "unique_macros":len(set(states)),
                "mean_positive":float(np.mean([s[0] for s in states])),
                "mean_sreg_ratio":float(np.mean([r["trace"][tick]["sreg_ratio"] for r in rows])),
                "sreg_exact_worlds":sum(r["trace"][tick]["sreg_total"]==r["initial_sreg"] for r in rows),
            })
            if tick<20:
                for r in rows:
                    a=r["trace"][tick]; b=r["trace"][tick+1]
                    sa=(a["positive"],a["proposals"],a["unique_destinations"],a["collision_excess"])
                    sb=(b["positive"],b["proposals"],b["unique_destinations"],b["collision_excess"])
                    transition_counts[(sa,sb)]+=1
        entropy_deltas=[by_tick[i+1]["macro_entropy_bits"]-by_tick[i]["macro_entropy_bits"] for i in range(20)]
        types=set(transition_counts)
        panels.append({
            "carrier_count":carrier_count,
            "worlds":48,
            "ticks":20,
            "by_tick":by_tick,
            "entropy_decrease_steps":sum(delta< -1e-12 for delta in entropy_deltas),
            "entropy_increase_steps":sum(delta> 1e-12 for delta in entropy_deltas),
            "directed_transition_types":len(types),
            "transition_types_without_observed_reverse":sum((b,a) not in types for a,b in types),
            "raw_recurrences":sum(r["recurrence"] is not None for r in rows),
            "final_sreg_exact_worlds":sum(r["trace"][-1]["sreg_total"]==r["initial_sreg"] for r in rows),
            "rows":rows,
        })
    return {
        "question":"Do natural coarse ensemble observables supply a monotone entropy, stationarity or conserved extensive quantity outside the guarded collision sector?",
        "coarse_observer":"(positive, proposal count, unique destination count, collision excess)",
        "panels":panels,
        "summary":[{k:p[k] for k in ("carrier_count","entropy_decrease_steps","entropy_increase_steps","raw_recurrences","final_sreg_exact_worlds","directed_transition_types","transition_types_without_observed_reverse")} for p in panels],
        "exact_sectoral_balance_context":"For a blank destination fiber, sreg_out=min(sum incoming sreg,19664); hence summed s_reg is conserved below cap and loses exactly max(sum-19664,0) at that vertex. Sources, occupied guards and other branches lie outside this balance statement.",
    }


def sgn(v):
    return tuple(1 if x>0 else -1 if x<0 else 0 for x in v)


def plus(a,b):
    return tuple(a[i]+b[i] for i in range(3))


def recursive_scale_panel():
    triple_total=0; left_mismatch=0; right_mismatch=0; associator=0
    triple_examples=[]
    for a,b,c in itertools.product(DIRECTIONS,repeat=3):
        triple_total+=1
        direct=sgn(plus(plus(a,b),c))
        left=sgn(plus(sgn(plus(a,b)),c))
        right=sgn(plus(a,sgn(plus(b,c))))
        left_mismatch+=left!=direct
        right_mismatch+=right!=direct
        associator+=left!=right
        if left!=direct and len(triple_examples)<12:
            triple_examples.append({"inputs":[list(a),list(b),list(c)],"simultaneous":list(direct),"left_staged":list(left),"right_staged":list(right)})
    quad_total=0; balanced_mismatch=0; left4_mismatch=0
    for a,b,c,d in itertools.product(DIRECTIONS,repeat=4):
        quad_total+=1
        direct=sgn(plus(plus(a,b),plus(c,d)))
        balanced=sgn(plus(sgn(plus(a,b)),sgn(plus(c,d))))
        left=sgn(plus(sgn(plus(sgn(plus(a,b)),c)),d))
        balanced_mismatch+=balanced!=direct
        left4_mismatch+=left!=direct
    return {
        "question":"Can the direction output alone support a grouping-independent recursive coarse law across collision scales?",
        "basis":"Exact inherited v27 collision reducer d_out=sign(sum incoming d); enumeration is mathematical and does not rerun the sealed parent collision census.",
        "triples":{"total":triple_total,"left_vs_simultaneous_mismatch":left_mismatch,"right_vs_simultaneous_mismatch":right_mismatch,"left_vs_right_mismatch":associator,"left_mismatch_rate":left_mismatch/triple_total,"examples":triple_examples},
        "quadruples":{"total":quad_total,"balanced_vs_simultaneous_mismatch":balanced_mismatch,"left_fold_vs_simultaneous_mismatch":left4_mismatch,"balanced_mismatch_rate":balanced_mismatch/quad_total,"left_mismatch_rate":left4_mismatch/quad_total},
        "adjudication":"Direction-only recursive closure is structurally obstructed because intermediate sign compression is non-associative. A lifted integer vector sum is associative for one simultaneous vertex, but v27 does not retain that lift after a staged collision; preserving the full unresolved fiber/history remains an open richer representation, not a demonstrated recursive scale law.",
    }


def main():
    kernel,environment=verify_and_load_kernel(1)
    result={
        "schema":"dee.v27.native_reality.nrd03.v1",
        "experiment_id":"NRD03_PROPAGATION_THERMO_SCALE_COVERAGE",
        "role":"DISCOVERY_AND_NEGATIVE_COVERAGE",
        "kernel_environment":environment,
        "propagation":propagation_panel(kernel),
        "thermodynamic_ensemble":ensemble_panel(kernel),
        "recursive_scale":recursive_scale_panel(),
    }
    result["content_sha256"]=canonical_hash(result)
    atomic_json(OUT,result)
    print(json.dumps({"propagation":result["propagation"]["summary"],"thermodynamic":result["thermodynamic_ensemble"]["summary"],"recursive_scale":{"triples":result["recursive_scale"]["triples"],"quadruples":result["recursive_scale"]["quadruples"]}},indent=2,sort_keys=True))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
