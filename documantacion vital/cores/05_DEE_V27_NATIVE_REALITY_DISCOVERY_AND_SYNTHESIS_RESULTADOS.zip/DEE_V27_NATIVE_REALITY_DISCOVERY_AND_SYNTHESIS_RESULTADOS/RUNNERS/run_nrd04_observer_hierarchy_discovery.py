#!/usr/bin/env python3
"""NRD04: can an internal detector output be detected recursively?"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"NRD04_observer_hierarchy_discovery.json"
TARGET_D=(1,0,0)
PROBES=((0,1,0),(0,0,1),(-1,0,0),(0,-1,0),(1,0,0))
SREGS=(2,3,5,7,11,13)

def add(q,d,k,n): return tuple((q[i]+k*d[i])%n for i in range(3))
def signsum(a,b): return tuple(int(np.sign(a[i]+b[i])) for i in range(3))

def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw)
    return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}

def design(n,origin,t0,gap,depth):
    nodes=[origin]; times=[t0]
    signal_d=[signsum(TARGET_D,PROBES[0])]
    signal_s=[SREGS[0]+SREGS[1]]
    for layer in range(1,depth+1):
        nodes.append(add(nodes[-1],signal_d[-1],gap,n))
        times.append(times[-1]+gap)
        signal_d.append(signsum(signal_d[-1],PROBES[layer]))
        signal_s.append(min(signal_s[-1]+SREGS[layer+1],19664))
    return nodes,times,signal_d,signal_s

def initial_world(n,origin,t0,gap,depth,base_mode):
    nodes,times,signal_d,signal_s=design(n,origin,t0,gap,depth)
    raw=np.zeros((n,n,n),dtype=np.uint64)
    # The first observer probe is always present.
    raw[add(nodes[0],PROBES[0],-t0,n)]=pack(7,SREGS[1],PROBES[0],1)
    if base_mode!="absent":
        phase=0 if base_mode=="present" else 1
        raw[add(nodes[0],TARGET_D,-(t0+phase),n)]=pack(5,SREGS[0],TARGET_D,1)
    for layer in range(1,depth+1):
        start=add(nodes[layer],PROBES[layer],-times[layer],n)
        if int(raw[start])!=0: raise RuntimeError("initial source overlap")
        raw[start]=pack(11+layer,SREGS[layer+1],PROBES[layer],1)
    return raw,nodes,times,signal_d,signal_s

def run_case(kernel,n,origin,t0,gap,depth,base_mode):
    raw,nodes,times,signal_d,signal_s=initial_world(n,origin,t0,gap,depth,base_mode)
    world=NativeWorld(kernel,raw,threads=1)
    trace=[]
    max_tick=times[-1]+2
    for tick in range(max_tick+1):
        planned=[]
        for layer,(node,event_tick) in enumerate(zip(nodes,times,strict=True)):
            if tick in (event_tick,event_tick+1):
                planned.append({"layer":layer,"node":list(node),"event_tick":event_tick,"record":decode(world.raw,node),"downstream":decode(world.raw,add(node,signal_d[layer],1,n))})
        trace.append({"tick":tick,"planned":planned,"raw_nonzero":int(np.count_nonzero(world.raw)),"raw_sha256":sha256_array(world.raw)})
        if tick<max_tick: world.tick()
    layer_results=[]
    for layer,(node,event_tick) in enumerate(zip(nodes,times,strict=True)):
        event=next(item for row in trace if row["tick"]==event_tick for item in row["planned"] if item["layer"]==layer)
        after=next(item for row in trace if row["tick"]==event_tick+1 for item in row["planned"] if item["layer"]==layer)
        if base_mode=="present":
            expected_d=list(signal_d[layer]); expected_s=signal_s[layer]
            event_exact=event["record"] is not None and event["record"]["d"]==expected_d and event["record"]["sreg"]==expected_s and event["record"]["state"]==1 and event["record"]["semantic"]==1
            downstream_exact=after["downstream"] is not None and after["downstream"]["d"]==expected_d and after["downstream"]["sreg"]==expected_s
        else:
            expected_d=list(PROBES[layer]); expected_s=SREGS[layer+1]
            event_exact=event["record"] is not None and event["record"]["d"]==expected_d and event["record"]["sreg"]==expected_s
            downstream_exact=None
        layer_results.append({"layer":layer,"node":list(node),"event_tick":event_tick,"expected_d":expected_d,"expected_sreg":expected_s,"event_record":event["record"],"event_exact":event_exact,"downstream_exact":downstream_exact})
    return {"n":n,"origin":list(origin),"t0":t0,"gap":gap,"depth":depth,"base_mode":base_mode,"nodes":[list(x) for x in nodes],"times":times,"signal_directions":[list(x) for x in signal_d],"signal_sreg":signal_s,"layers":layer_results,"trace":trace}

def main():
    kernel,environment=verify_and_load_kernel(1)
    configurations=((47,(22,23,21),4,3),(53,(11,31,27),5,3),(59,(38,17,29),4,4))
    cases=[]
    for depth in (1,2,3):
        for n,origin,t0,gap in configurations:
            for mode in ("present","absent","phase_shifted"):
                cases.append(run_case(kernel,n,origin,t0,gap,depth,mode))
    present=[c for c in cases if c["base_mode"]=="present"]
    controls=[c for c in cases if c["base_mode"]!="present"]
    result={
        "schema":"dee.v27.native_reality.nrd04.v1",
        "experiment_id":"NRD04_OBSERVER_HIERARCHY_DISCOVERY",
        "role":"DISCOVERY_EVIDENCE_ONLY",
        "question":"Can the output process of one confirmed relational detector become the target process measured by another detector using the same local transformation?",
        "candidate_recursive_law":"At observational layer i, synchronized signal d_i,s_i and probe p_(i+1),r_(i+1) produce d_(i+1)=sign(d_i+p_(i+1)), s_(i+1)=min(s_i+r_(i+1),19664), then travel freely to the next prepared detector.",
        "kernel_environment":environment,
        "cases":cases,
        "summary":{
            "present_cases":len(present),
            "present_layers":sum(len(c["layers"]) for c in present),
            "present_event_exact":sum(layer["event_exact"] for c in present for layer in c["layers"]),
            "present_downstream_exact":sum(layer["downstream_exact"] for c in present for layer in c["layers"]),
            "control_cases":len(controls),
            "control_layers":sum(len(c["layers"]) for c in controls),
            "controls_follow_probe_only_record":sum(layer["event_exact"] for c in controls for layer in c["layers"]),
            "depth3_present_cases_all_layers_exact":sum(all(l["event_exact"] and l["downstream_exact"] for l in c["layers"]) for c in present if c["depth"]==3),
        },
    }
    result["content_sha256"]=canonical_hash(result)
    atomic_json(OUT,result)
    print(json.dumps(result["summary"],indent=2,sort_keys=True))
    return 0

if __name__=="__main__":raise SystemExit(main())
