#!/usr/bin/env python3
"""NRD05: native categorical scale for relative arrival history."""
from __future__ import annotations

import json,math,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"NRD05_relational_scale_discovery.json"
TARGET_D=(1,0,0);PROBE_D=(0,1,0);OUTPUT_D=(1,1,0)

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}

def run_case(kernel,n,base_xy,z0,spacing,L,offsets,input_delta,arm,sreg_pair,clock_pair):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);hubs=[]
    calibration=list(offsets) if arm!="reversed_calibration" else list(reversed(offsets))
    for channel_index,(label,probe_offset) in enumerate(zip(offsets,calibration,strict=True)):
        hub=(base_xy[0],base_xy[1],(z0+channel_index*spacing)%n);hubs.append(hub)
        probe_start=add(hub,PROBE_D,-(L+probe_offset),n)
        raw[probe_start]=pack(7,sreg_pair[1],PROBE_D,1);clock[probe_start]=np.uint64(clock_pair[1])
        if arm!="target_absent":
            target_start=add(hub,TARGET_D,-(L+input_delta),n)
            if int(raw[target_start])!=0:raise RuntimeError("source overlap")
            raw[target_start]=pack(5,sreg_pair[0],TARGET_D,1);clock[target_start]=np.uint64(clock_pair[0])
    initial_hubs_empty=all(int(raw[q])==0 for q in hubs)
    world=NativeWorld(kernel,raw,clock,threads=1);events=[];tick_hashes=[];max_tick=L+max(abs(x) for x in offsets)+3
    for tick in range(max_tick+1):
        tick_hashes.append(sha256_array(world.raw))
        for channel_index,(label,hub) in enumerate(zip(offsets,hubs,strict=True)):
            record=decode(world.raw,hub)
            if record is not None:events.append({"tick":tick,"channel":label,"record":record})
        if tick<max_tick:world.tick()
    collision_events=[e for e in events if e["record"]["d"]==list(OUTPUT_D) and e["record"]["sreg"]==sum(sreg_pair)]
    active_channels=sorted(set(e["channel"] for e in collision_events))
    measured=active_channels[0] if len(active_channels)==1 else None
    expected=None if arm=="target_absent" else input_delta
    return {"n":n,"base_xy":list(base_xy),"z0":z0,"spacing":spacing,"L":L,"offsets":offsets,"input_delta":input_delta,"arm":arm,"calibration":calibration,"sreg_pair":list(sreg_pair),"initial_hubs_empty":initial_hubs_empty,"events":events,"collision_events":collision_events,"active_channels":active_channels,"measured_delta":measured,"expected_delta":expected,"correct":measured==expected if expected is not None else len(active_channels)==0,"tick_hashes":tick_hashes}

def main():
    kernel,environment=verify_and_load_kernel(1);offsets=list(range(-3,4));cases=[]
    designs=(
        (61,(27,29),5,7,8,(2,3),(0,11)),
        (68,(19,41),9,8,9,(17,29),(101,503)),
        (75,(46,22),13,9,10,(7000,9000),(65537,99991)),
    )
    for n,xy,z0,spacing,L,sregs,clocks in designs:
        for delta in offsets:
            cases.append(run_case(kernel,n,xy,z0,spacing,L,offsets,delta,"native",sregs,clocks))
            cases.append(run_case(kernel,n,xy,z0,spacing,L,offsets,delta,"reversed_calibration",sregs,clocks))
        cases.append(run_case(kernel,n,xy,z0,spacing,L,offsets,0,"target_absent",sregs,clocks))
    native=[c for c in cases if c["arm"]=="native"];destroyed=[c for c in cases if c["arm"]=="reversed_calibration"];absent=[c for c in cases if c["arm"]=="target_absent"]
    result={
        "schema":"dee.v27.native_reality.nrd05.v1",
        "experiment_id":"NRD05_RELATIONAL_SCALE_DISCOVERY",
        "role":"DISCOVERY_EVIDENCE_ONLY",
        "question":"Can a bank of internal relational detectors define a native measurement scale for relative arrival history?",
        "phenomenon":"Each channel is calibrated by a path-length relation. Exactly one channel resolves a merged output when its calibration equals the prepared relative arrival offset; channel identity is the measurement record.",
        "scale":"m_B(A)=the unique detector label j whose destination fiber contains both routed processes; labels are integer update offsets, not physical seconds.",
        "controls":{"no_evolution":"all hub ports empty at tick zero","target_absent":"no merged output","destroyed":"reverse the channel calibration while retaining labels and input inventory"},
        "kernel_environment":environment,
        "cases":cases,
        "summary":{
            "native_cases":len(native),"native_correct":sum(c["correct"] for c in native),
            "native_information_bits_if_uniform":math.log2(len(offsets)),
            "destroyed_cases":len(destroyed),"destroyed_frozen_label_correct":sum(c["correct"] for c in destroyed),
            "target_absent_cases":len(absent),"target_absent_no_collision":sum(c["correct"] for c in absent),
            "initial_hubs_empty":sum(c["initial_hubs_empty"] for c in cases),"total_cases":len(cases)
        }
    }
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(result["summary"],indent=2,sort_keys=True));return 0
if __name__=="__main__":raise SystemExit(main())
