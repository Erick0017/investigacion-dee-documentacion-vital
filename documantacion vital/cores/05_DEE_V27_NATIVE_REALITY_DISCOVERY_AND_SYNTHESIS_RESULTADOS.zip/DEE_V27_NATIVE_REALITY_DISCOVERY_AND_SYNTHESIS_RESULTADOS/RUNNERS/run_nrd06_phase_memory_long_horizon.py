#!/usr/bin/env python3
"""NRD06: post-confirmation lifetime/failure-mode probe for distributed phase memory."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"NRD06_phase_memory_long_horizon.json"
BASE_D=((1,0,0),(1,1,0),(1,0,1),(1,1,1));SREGS=(2,3,5,7)

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def transform(v,perm,signs):return tuple(signs[i]*v[perm[i]] for i in range(3))
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}

def simulate(kernel,n,center,distance,directions,mode,index,horizon):
    raw=np.zeros((n,n,n),dtype=np.uint64);sources=[];mouths=[]
    for i,(d,s) in enumerate(zip(directions,SREGS,strict=True)):
        source=add(center,d,-distance,n);mouth=add(source,d,1,n);sources.append(source);mouths.append(mouth)
        if mode=="ablation" and i==index:continue
        raw[source]=pack(0,s,d,4)
        if mode=="block" and i==index:raw[mouth]=pack(1,1,(0,0,0),1)
    world=NativeWorld(kernel,raw,threads=1);trace=[]
    for tick in range(horizon+1):
        trace.append({"tick":tick,"hub":decode(world.raw,center),"blocked_source":None if index is None else decode(world.raw,sources[index]),"blocked_mouth":None if index is None else decode(world.raw,mouths[index]),"raw_nonzero":int(np.count_nonzero(world.raw)),"raw_sha256":sha256_array(world.raw)})
        if tick<horizon:world.tick()
    return {"mode":mode,"index":index,"trace":trace}

def key(row):
    r=row["hub"]
    return None if r is None else (tuple(r["d"]),r["sreg"],r["state"],r["semantic"])

def main():
    kernel,environment=verify_and_load_kernel(1);configs=((23,(11,10,12),4,(2,0,1),(1,-1,1)),(32,(7,19,14),5,(1,2,0),(-1,1,1)),(41,(29,13,21),6,(0,2,1),(1,1,-1)));panels=[]
    for n,center,distance,perm,signs in configs:
        directions=[transform(d,perm,signs) for d in BASE_D];horizon=5*n;baseline=simulate(kernel,n,center,distance,directions,"baseline",None,horizon);comparisons=[]
        for idx in range(4):
            ablation=simulate(kernel,n,center,distance,directions,"ablation",idx,horizon);block=simulate(kernel,n,center,distance,directions,"block",idx,horizon)
            equal=[key(a)==key(b) for a,b in zip(ablation["trace"],block["trace"],strict=True)];start=distance;first_div=next((t for t in range(start,horizon+1) if not equal[t]),None);baseline_equal=[key(a)==key(b) for a,b in zip(baseline["trace"],block["trace"],strict=True)]
            restored4=next((t for t in range(start,horizon-2) if all(baseline_equal[t:t+4])),None)
            comparisons.append({"source_index":idx,"blocker_absent_tick1":block["trace"][1]["blocked_mouth"] is None,"source_persists_all_ticks":all(r["blocked_source"] is not None and r["blocked_source"]["semantic"]==4 for r in block["trace"]),"hub_equal_ablation_fraction_after_first_event":sum(equal[start:])/len(equal[start:]),"first_hub_divergence_from_ablation":first_div,"hub_matches_ablation_through_5N":first_div is None,"first_four_tick_baseline_restoration":restored4,"block":block,"ablation":ablation})
        panels.append({"n":n,"center":list(center),"distance":distance,"horizon":horizon,"directions":[list(d) for d in directions],"comparisons":comparisons,"baseline":baseline})
    comps=[c for p in panels for c in p["comparisons"]]
    result={"schema":"dee.v27.native_reality.nrd06.v1","experiment_id":"NRD06_PHASE_MEMORY_LONG_HORIZON","role":"POST_CONFIRMATION_DISCOVERY_CHARACTERIZATION","question":"Does the confirmed pre-wrap phase-memory equivalence to ablation survive repeated toroidal returns, and if not, when does it first fail?","kernel_environment":environment,"panels":panels,"summary":{"comparisons":len(comps),"blocker_absent_tick1":sum(c["blocker_absent_tick1"] for c in comps),"source_persists_5N":sum(c["source_persists_all_ticks"] for c in comps),"hub_matches_ablation_through_5N":sum(c["hub_matches_ablation_through_5N"] for c in comps),"first_divergence_by_n":{str(p["n"]):[c["first_hub_divergence_from_ablation"] for c in p["comparisons"]] for p in panels},"four_tick_baseline_restorations":sum(c["first_four_tick_baseline_restoration"] is not None for c in comps)},"original_holdout_unchanged":True}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(result["summary"],indent=2,sort_keys=True));return 0
if __name__=="__main__":raise SystemExit(main())
