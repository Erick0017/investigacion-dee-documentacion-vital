#!/usr/bin/env python3
"""NRD07: targeted parity/commensurability test prompted by NRD06 N=32 anomaly."""
from __future__ import annotations

import json,sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import atomic_json,canonical_hash,verify_and_load_kernel
from run_nrd06_phase_memory_long_horizon import BASE_D,key,simulate

WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"NRD07_toroidal_memory_parity_discovery.json"

def main():
    kernel,environment=verify_and_load_kernel(1);distance=5;rows=[]
    for n in range(23,37):
        center=(n//2,(n//2+3)%n,(n//2-2)%n);horizon=3*n+distance
        baseline=simulate(kernel,n,center,distance,list(BASE_D),"baseline",None,horizon)
        ablation=simulate(kernel,n,center,distance,list(BASE_D),"ablation",3,horizon)
        block=simulate(kernel,n,center,distance,list(BASE_D),"block",3,horizon)
        equal_ablation=[key(a)==key(b) for a,b in zip(ablation["trace"],block["trace"],strict=True)]
        equal_baseline=[key(a)==key(b) for a,b in zip(baseline["trace"],block["trace"],strict=True)]
        first_div=next((t for t in range(distance,horizon+1) if not equal_ablation[t]),None)
        first_restore4=next((t for t in range(distance,horizon-2) if all(equal_baseline[t:t+4])),None)
        rows.append({"n":n,"parity":"even" if n%2==0 else "odd","distance":distance,"horizon":horizon,"predicted_first_divergence_if_even":n+distance if n%2==0 else None,"first_hub_divergence_from_ablation":first_div,"matches_even_prediction":(first_div==n+distance) if n%2==0 else (first_div is None),"hub_matches_ablation_through_3N_plus_distance":first_div is None,"first_four_tick_baseline_restoration":first_restore4,"blocker_absent_tick1":block["trace"][1]["blocked_mouth"] is None,"source_persists":all(r["blocked_source"] is not None and r["blocked_source"]["semantic"]==4 for r in block["trace"]),"baseline":baseline,"ablation":ablation,"block":block})
    even=[r for r in rows if r["parity"]=="even"];odd=[r for r in rows if r["parity"]=="odd"]
    result={"schema":"dee.v27.native_reality.nrd07.v1","experiment_id":"NRD07_TOROIDAL_MEMORY_PARITY_DISCOVERY","role":"POST_CONFIRMATION_ANOMALY_DISCOVERY","question":"Is the first long-horizon failure of ablation-equivalent phase memory controlled by parity when the blocked source orbit is collinear with the integrated output orbit?","hypotheses":{"H_even":"for even N, returning output meets the persistent source organization and first changes the hub record at distance+N","H_odd":"for odd N, the return changes parity and ablation-equivalent hub history persists through the tested 3N+distance","H_noise":"N=32 was idiosyncratic"},"kernel_environment":environment,"rows":rows,"summary":{"sizes":len(rows),"even_sizes":len(even),"even_first_divergence_at_N_plus_distance":sum(r["first_hub_divergence_from_ablation"]==r["n"]+distance for r in even),"odd_sizes":len(odd),"odd_no_divergence_through_horizon":sum(r["first_hub_divergence_from_ablation"] is None for r in odd),"all_prediction_matches":sum(r["matches_even_prediction"] for r in rows),"baseline_restoration_cases":sum(r["first_four_tick_baseline_restoration"] is not None for r in rows)},"original_NRH04_verdict_unchanged":True}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(result["summary"],indent=2,sort_keys=True));return 0
if __name__=="__main__":raise SystemExit(main())
