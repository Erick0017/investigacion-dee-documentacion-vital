#!/usr/bin/env python3
"""Frozen NRH01 holdout. Do not modify criteria after reading outputs."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))

from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "NRH01_INTERNAL_RELATIONAL_MEASUREMENT.json"
OUT = WORK / "RESULTS" / "NRH01_internal_relational_measurement_holdout.json"
EXPECTED_LOCK_SHA256 = "1ff8d37a97b5d77b472fbfade6d08bb3a90911e5cbdfd8f753669c87ee5f46f0"
PROBE_D = (0, 1, 0)


def add(q: tuple[int, int, int], d: tuple[int, int, int], scale: int, n: int) -> tuple[int, int, int]:
    return tuple((q[i] + scale * d[i]) % n for i in range(3))


def cell_rows(raw: np.ndarray) -> list[dict]:
    f = fields(raw)
    rows = []
    for coord in np.argwhere(raw != 0):
        q = tuple(int(x) for x in coord)
        rows.append({
            "q": list(q),
            "raw": int(raw[q]),
            "state": int(f["state"][q]),
            "sreg": int(f["sreg"][q]),
            "d": [int(f[k][q]) for k in ("dx", "dy", "dz")],
            "semantic": int(f["semantic"][q]),
        })
    return rows


def wilson(successes: int, total: int, z: float = 1.959963984540054) -> tuple[float, float]:
    if total == 0:
        return (0.0, 1.0)
    p = successes / total
    den = 1.0 + z * z / total
    center = (p + z * z / (2.0 * total)) / den
    half = z * math.sqrt(p * (1.0 - p) / total + z * z / (4.0 * total * total)) / den
    return (center - half, center + half)


def mutual_information(pairs: list[tuple[tuple[int, ...], tuple[int, ...] | str]]) -> float:
    joint = Counter(pairs)
    xs = Counter(x for x, _ in pairs)
    ys = Counter(y for _, y in pairs)
    n = len(pairs)
    return sum((c / n) * math.log2((c * n) / (xs[x] * ys[y])) for (x, y), c in joint.items())


def run_case(kernel, *, n, center, distance, target_d, phase, nuisance) -> dict:
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    probe_start = add(center, PROBE_D, -distance, n)
    raw[probe_start] = pack(nuisance["probe_state"], nuisance["probe_sreg"], PROBE_D, 1)
    clock[probe_start] = np.uint64(nuisance["probe_clock"])
    target_start = None
    if target_d is not None:
        target_start = add(center, target_d, -(distance + phase), n)
        raw[target_start] = pack(nuisance["target_state"], nuisance["target_sreg"], target_d, 1)
        clock[target_start] = np.uint64(nuisance["target_clock"])

    expected_d = PROBE_D if target_d is None else tuple(int(np.sign(PROBE_D[i] + target_d[i])) for i in range(3))
    expected_sreg = nuisance["probe_sreg"] if target_d is None else min(nuisance["probe_sreg"] + nuisance["target_sreg"], 19664)
    output_site = add(center, expected_d, 1, n)
    initial_rows = cell_rows(raw)
    initial_port_empty = bool(raw[output_site] == 0 and raw[center] == 0)
    world = NativeWorld(kernel, raw, clock, threads=1)
    kernel_infos = []
    event_rows = None
    downstream_rows = None
    for tick in range(1, distance + 2):
        kernel_infos.append(world.tick())
        if tick == distance:
            event_rows = cell_rows(world.raw)
        if tick == distance + 1:
            downstream_rows = cell_rows(world.raw)
    assert event_rows is not None and downstream_rows is not None
    center_rows = [r for r in event_rows if tuple(r["q"]) == center]
    merged = bool(
        target_d is not None
        and len(event_rows) == 1
        and len(center_rows) == 1
        and center_rows[0]["state"] == 1
        and center_rows[0]["semantic"] == 1
        and tuple(center_rows[0]["d"]) == expected_d
        and center_rows[0]["sreg"] == expected_sreg
    )
    downstream = bool(
        merged
        and len(downstream_rows) == 1
        and tuple(downstream_rows[0]["q"]) == output_site
        and tuple(downstream_rows[0]["d"]) == expected_d
        and downstream_rows[0]["sreg"] == expected_sreg
    )
    decoded = None
    if len(center_rows) == 1:
        d = tuple(center_rows[0]["d"])
        decoded = (d[0], 0, d[2])
    decode_correct = bool(target_d is not None and phase == 0 and decoded == target_d and merged)
    return {
        "n": n,
        "center": list(center),
        "distance": distance,
        "target_d": None if target_d is None else list(target_d),
        "phase": phase,
        "nuisance": nuisance,
        "probe_start": list(probe_start),
        "target_start": None if target_start is None else list(target_start),
        "expected_d": list(expected_d),
        "expected_sreg": expected_sreg,
        "initial_port_empty": initial_port_empty,
        "merged_record": merged,
        "downstream_record": downstream,
        "decoded_target": None if decoded is None else list(decoded),
        "decode_correct": decode_correct,
        "snapshots": {"initial": initial_rows, "event": event_rows, "downstream": downstream_rows},
        "kernel_info": kernel_infos,
    }


def main() -> int:
    observed_lock_hash = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed_lock_hash != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock mismatch: {observed_lock_hash}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(1)
    directions = [tuple(x) for x in lock["domain"]["target_direction_classes"]]
    sizes = lock["domain"]["sizes"]
    distances = lock["domain"]["distances"]
    offsets = lock["domain"]["arrival_offsets"]
    seeds = lock["parameters"]["seeds"]
    cases = []
    for seed, n, distance in zip(seeds, sizes, distances, strict=True):
        rng = np.random.default_rng(seed)
        for translation_index in range(lock["parameters"]["translations_per_seed"]):
            center = tuple(int(v) for v in rng.integers(0, n, size=3))
            if translation_index == 0:
                probe_sreg = int(rng.integers(0, 8001))
                target_sreg = int(rng.integers(0, 8001))
            else:
                probe_sreg = int(rng.integers(10000, 19665))
                target_sreg = int(rng.integers(10000, 19665))
            nuisance = {
                "probe_state": int(rng.integers(1, 2**31)),
                "probe_sreg": probe_sreg,
                "probe_clock": int(rng.bit_generator.random_raw()),
                "target_state": int(rng.integers(1, 2**31)),
                "target_sreg": target_sreg,
                "target_clock": int(rng.bit_generator.random_raw()),
                "seed": seed,
                "translation_index": translation_index,
            }
            cases.append(run_case(kernel, n=n, center=center, distance=distance, target_d=None, phase=0, nuisance=nuisance))
            for target_d in directions:
                for phase in offsets:
                    cases.append(run_case(kernel, n=n, center=center, distance=distance, target_d=target_d, phase=phase, nuisance=nuisance))

    sync = [c for c in cases if c["target_d"] is not None and c["phase"] == 0]
    async_cases = [c for c in cases if c["target_d"] is not None and c["phase"] != 0]
    exact_n = sum(c["merged_record"] for c in sync)
    downstream_n = sum(c["downstream_record"] for c in sync)
    decode_n = sum(c["decode_correct"] for c in sync)
    false_merge_n = sum(c["merged_record"] for c in async_cases)
    mi_pairs = [
        (tuple(c["target_d"]), tuple(c["decoded_target"]) if c["decoded_target"] is not None else "NO_RECORD")
        for c in sync
    ]
    mi_bits = mutual_information(mi_pairs)
    by_class = {}
    for d in directions:
        group = [c for c in sync if tuple(c["target_d"]) == d]
        by_class[str(d)] = {"n": len(group), "exact": sum(c["merged_record"] for c in group), "rate": sum(c["merged_record"] for c in group) / len(group)}
    by_size = {}
    for n in sizes:
        group = [c for c in sync if c["n"] == n]
        by_size[str(n)] = {"n": len(group), "exact": sum(c["merged_record"] for c in group)}
    rates = {
        "synchronized_exact": exact_n / len(sync),
        "synchronized_downstream": downstream_n / len(sync),
        "synchronized_decode_accuracy": decode_n / len(sync),
        "target_information_bits": mi_bits,
        "temporal_shuffle_false_merge": false_merge_n / len(async_cases),
        "no_evolution_empty": sum(c["initial_port_empty"] for c in cases) / len(cases),
    }
    interval = wilson(exact_n, len(sync))
    thresholds = lock["minimum_relevance"]
    pass_conditions = {
        "synchronized_exact": rates["synchronized_exact"] >= thresholds["synchronized_exact_rate"],
        "synchronized_downstream": rates["synchronized_downstream"] >= thresholds["synchronized_downstream_rate"],
        "decode": rates["synchronized_decode_accuracy"] >= thresholds["synchronized_target_decode_accuracy"],
        "information": rates["target_information_bits"] >= thresholds["synchronized_target_information_bits"],
        "shuffle_control": rates["temporal_shuffle_false_merge"] <= thresholds["temporal_shuffle_false_merge_rate_max"],
        "wilson": interval[0] >= thresholds["wilson_95_lower_bound_for_pooled_synchronized_exact_rate"],
        "classes": all(row["rate"] >= thresholds["every_target_class_exact_rate"] for row in by_class.values()),
        "no_evolution": rates["no_evolution_empty"] >= thresholds["no_evolution_empty_rate"],
        "sizes": all(row["exact"] > 0 for row in by_size.values()),
    }
    fail_conditions = {
        "synchronized_exact": rates["synchronized_exact"] < 0.95,
        "synchronized_downstream": rates["synchronized_downstream"] < 0.95,
        "decode": rates["synchronized_decode_accuracy"] < 0.95,
        "information": rates["target_information_bits"] < 2.5,
        "shuffle_control": rates["temporal_shuffle_false_merge"] > 0.05,
        "classes": any(row["rate"] < 0.8 for row in by_class.values()),
        "no_evolution": rates["no_evolution_empty"] < 1.0,
    }
    verdict = "PASS" if all(pass_conditions.values()) else ("FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE")
    result = {
        "schema": "dee.v27.native_reality.nrh01.v1",
        "experiment_id": lock["hypothesis_id"],
        "role": "FROZEN_CONFIRMATION",
        "lock_sha256": observed_lock_hash,
        "kernel_environment": environment,
        "sample_sizes": {"all": len(cases), "synchronized": len(sync), "temporal_shuffle": len(async_cases)},
        "rates": rates,
        "synchronized_exact_wilson_95": list(interval),
        "by_target_class": by_class,
        "by_size": by_size,
        "pass_conditions": pass_conditions,
        "fail_conditions": fail_conditions,
        "verdict": verdict,
        "cases": cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({k: result[k] for k in ("sample_sizes", "rates", "synchronized_exact_wilson_95", "by_target_class", "by_size", "pass_conditions", "verdict")}, indent=2, sort_keys=True))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
