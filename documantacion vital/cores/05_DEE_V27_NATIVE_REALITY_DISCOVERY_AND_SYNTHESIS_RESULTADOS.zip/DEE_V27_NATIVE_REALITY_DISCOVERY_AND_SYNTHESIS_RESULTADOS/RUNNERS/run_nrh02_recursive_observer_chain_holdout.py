#!/usr/bin/env python3
"""Frozen depth-4 recursive observer holdout."""
from __future__ import annotations

import hashlib,json,math,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NRH02_RECURSIVE_OBSERVER_CHAIN.json"
OUT=WORK/"RESULTS"/"NRH02_recursive_observer_chain_holdout.json"
EXPECTED_LOCK_SHA256="f65b02b4ee1950c00ceac586a0d8d8e42f152e83b3e6c1ddc75fab32a526dda1"

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def signsum(a,b):return tuple(int(np.sign(a[i]+b[i])) for i in range(3))
def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw)
    return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}

def recurrence(n,origin,t0,gap,target_d,probes,sregs):
    nodes=[origin];times=[t0];ds=[signsum(target_d,probes[0])];ss=[min(sregs[0]+sregs[1],19664)]
    for i in range(1,len(probes)):
        nodes.append(add(nodes[-1],ds[-1],gap,n));times.append(times[-1]+gap);ds.append(signsum(ds[-1],probes[i]));ss.append(min(ss[-1]+sregs[i+1],19664))
    return nodes,times,ds,ss

def prepare(n,origin,t0,gap,mode,target_d,probes,sregs,states,clocks):
    nodes,times,signal_d,signal_s=recurrence(n,origin,t0,gap,target_d,probes,sregs)
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
    occupied=[]
    def put(q,value,c):
        if int(raw[q])!=0:raise RuntimeError(f"initial overlap {q}")
        raw[q]=value;clock[q]=np.uint64(c);occupied.append(q)
    put(add(nodes[0],probes[0],-t0,n),pack(states[1],sregs[1],probes[0],1),clocks[1])
    if mode!="absent":
        phase=0 if mode=="present" else 1
        put(add(nodes[0],target_d,-(t0+phase),n),pack(states[0],sregs[0],target_d,1),clocks[0])
    for i in range(1,len(probes)):
        put(add(nodes[i],probes[i],-times[i],n),pack(states[i+1],sregs[i+1],probes[i],1),clocks[i+1])
    ports=[]
    for node,d in zip(nodes,signal_d,strict=True):ports.extend((node,add(node,d,1,n)))
    no_evolution_empty=all(int(raw[q])==0 for q in ports)
    return raw,clock,nodes,times,signal_d,signal_s,no_evolution_empty,occupied

def run_case(kernel,*,n,origin,t0,gap,mode,target_d,probes,sregs,states,clocks,seed,translation_index):
    raw,clock,nodes,times,signal_d,signal_s,no_evolution_empty,occupied=prepare(n,origin,t0,gap,mode,target_d,probes,sregs,states,clocks)
    world=NativeWorld(kernel,raw,clock,threads=1);event_records={};downstream_records={};tick_hashes=[]
    final_tick=times[-1]+1
    for tick in range(final_tick+1):
        tick_hashes.append(sha256_array(world.raw))
        for i,T in enumerate(times):
            if tick==T:event_records[i]=decode(world.raw,nodes[i])
            if tick==T+1:downstream_records[i]=decode(world.raw,add(nodes[i],signal_d[i],1,n))
        if tick<final_tick:world.tick()
    layers=[]
    for i in range(len(nodes)):
        event=event_records[i];down=downstream_records[i]
        signal_exact=event is not None and event["state"]==1 and event["semantic"]==1 and event["d"]==list(signal_d[i]) and event["sreg"]==signal_s[i]
        downstream_exact=down is not None and down["d"]==list(signal_d[i]) and down["sreg"]==signal_s[i]
        probe_exact=event is not None and event["d"]==list(probes[i]) and event["sreg"]==sregs[i+1]
        layers.append({"layer":i,"node":list(nodes[i]),"event_tick":times[i],"signal_d":list(signal_d[i]),"signal_sreg":signal_s[i],"event_record":event,"downstream_record":down,"signal_exact":signal_exact,"downstream_exact":downstream_exact,"probe_only_exact":probe_exact})
    return {"seed":seed,"translation_index":translation_index,"n":n,"origin":list(origin),"t0":t0,"gap":gap,"mode":mode,"sregs":sregs,"states":states,"clocks":clocks,"initial_positions":[list(q) for q in occupied],"no_evolution_ports_empty":no_evolution_empty,"layers":layers,"tick_hashes":tick_hashes}

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1)
    target_d=tuple(lock["domain"]["target_direction"]);probes=[tuple(x) for x in lock["domain"]["probe_directions"]]
    cases=[]
    for seed_index,(seed,n) in enumerate(zip(lock["parameters"]["seeds"],lock["domain"]["new_sizes"],strict=True)):
        rng=np.random.default_rng(seed)
        t0=4+seed_index%2
        for tr in range(lock["parameters"]["translations_per_size"]):
            origin=tuple(int(x) for x in rng.integers(0,n,size=3));gap=3+tr%2
            if tr<2:sregs=[int(x) for x in rng.integers(1,1001,size=6)]
            else:sregs=[int(x) for x in rng.integers(9000,15001,size=6)]
            states=[int(x) for x in rng.integers(1,2**31,size=6)]
            clocks=[int(rng.bit_generator.random_raw()) for _ in range(6)]
            for mode in ("present","absent","phase_shifted_plus_one"):
                normalized="phase_shifted" if mode.startswith("phase") else mode
                cases.append(run_case(kernel,n=n,origin=origin,t0=t0,gap=gap,mode=normalized,target_d=target_d,probes=probes,sregs=sregs,states=states,clocks=clocks,seed=seed,translation_index=tr))
    present=[c for c in cases if c["mode"]=="present"];controls=[c for c in cases if c["mode"]!="present"]
    present_layers=[l for c in present for l in c["layers"]];control_layers=[l for c in controls for l in c["layers"]]
    k=sum(l["signal_exact"] for l in present_layers);downk=sum(l["downstream_exact"] for l in present_layers)
    falsek=sum(l["signal_exact"] for l in control_layers);probek=sum(l["probe_only_exact"] for l in control_layers)
    by_layer={}
    for i in range(5):
        p=[l for l in present_layers if l["layer"]==i];q=[l for l in control_layers if l["layer"]==i]
        by_layer[str(i)]={"present_n":len(p),"present_exact":sum(l["signal_exact"] for l in p),"present_rate":sum(l["signal_exact"] for l in p)/len(p),"control_n":len(q),"control_false_signal":sum(l["signal_exact"] for l in q),"control_probe_only":sum(l["probe_only_exact"] for l in q)}
    rates={"present_event":k/len(present_layers),"present_downstream":downk/len(present_layers),"depth4_event":by_layer["4"]["present_rate"],"control_false_signal":falsek/len(control_layers),"control_probe_only":probek/len(control_layers),"no_evolution_empty":sum(c["no_evolution_ports_empty"] for c in cases)/len(cases)}
    interval=wilson(k,len(present_layers));thr=lock["minimum_relevance"]
    pass_conditions={"present_event":rates["present_event"]>=thr["present_all_layer_event_rate"],"present_downstream":rates["present_downstream"]>=thr["present_all_layer_downstream_rate"],"depth4":rates["depth4_event"]>=thr["new_depth4_event_rate"],"every_layer":all(v["present_rate"]>=thr["every_layer_event_rate"] for v in by_layer.values()),"controls_false":rates["control_false_signal"]<=thr["control_recursive_false_positive_rate_max"],"controls_probe":rates["control_probe_only"]>=thr["control_probe_only_rate"],"no_evolution":rates["no_evolution_empty"]>=thr["no_evolution_empty_rate"],"wilson":interval[0]>=thr["wilson_95_lower_present_event_rate"],"sizes":all(any(c["n"]==n and all(l["signal_exact"] for l in c["layers"]) for c in present) for n in lock["domain"]["new_sizes"])}
    fail_conditions={"present_event":rates["present_event"]<.95,"present_downstream":rates["present_downstream"]<.95,"depth4":rates["depth4_event"]<.95,"any_layer":any(v["present_rate"]<.90 for v in by_layer.values()),"controls_false":rates["control_false_signal"]>.05,"controls_probe":rates["control_probe_only"]<.95,"no_evolution":rates["no_evolution_empty"]<1.0}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.nrh02.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"worlds":len(cases),"present_worlds":len(present),"present_layers":len(present_layers),"control_layers":len(control_layers)},"rates":rates,"present_event_wilson_95":list(interval),"by_layer":by_layer,"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"cases":cases}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result)
    print(json.dumps({k:result[k] for k in ("sample_sizes","rates","present_event_wilson_95","by_layer","pass_conditions","verdict")},indent=2,sort_keys=True))
    return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
