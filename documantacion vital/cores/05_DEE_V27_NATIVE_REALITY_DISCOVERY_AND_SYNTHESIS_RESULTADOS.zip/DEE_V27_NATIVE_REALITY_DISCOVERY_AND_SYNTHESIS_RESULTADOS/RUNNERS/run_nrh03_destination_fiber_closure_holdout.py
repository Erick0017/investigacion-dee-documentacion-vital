#!/usr/bin/env python3
"""Frozen NRH03 destination-fiber closure holdout."""
from __future__ import annotations

import hashlib,itertools,json,math,sys
from collections import defaultdict
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NRH03_DESTINATION_FIBER_CLOSURE.json"
OUT=WORK/"RESULTS"/"NRH03_destination_fiber_closure_holdout.json"
EXPECTED_LOCK_SHA256="4e4dc454a8050133f64c08f4cf00e5b5323164aa27d134379086691697e795c7"
DIRS=[d for d in itertools.product((-1,0,1),repeat=3) if d!=(0,0,0)]

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half

def place(rng,n,directions,sregs,clocks,groups):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);sources=set();targets=set();offset=0
    for size in groups:
        ds=directions[offset:offset+size];ss=sregs[offset:offset+size];cs=clocks[offset:offset+size];offset+=size
        for _ in range(20000):
            target=tuple(int(x) for x in rng.integers(0,n,size=3));new_sources=[add(target,d,-1,n) for d in ds]
            if target in sources or target in targets or len(set(new_sources))!=len(new_sources):continue
            if any(q in sources or q in targets for q in new_sources):continue
            targets.add(target);sources.update(new_sources)
            for q,d,s,c in zip(new_sources,ds,ss,cs,strict=True):raw[q]=pack(0,s,d,1);clock[q]=np.uint64(c)
            break
        else:raise RuntimeError("placement failure")
    if offset!=len(directions):raise RuntimeError("partition mismatch")
    return raw,clock

def fibers(raw):
    f=fields(raw);n=raw.shape[0];g=defaultdict(list)
    for coord in np.argwhere(raw!=0):
        q=tuple(int(x) for x in coord);d=tuple(int(f[k][q]) for k in ("dx","dy","dz"));g[add(q,d,1,n)].append((d,int(f["sreg"][q])))
    rows=[]
    for target,incoming in sorted(g.items()):
        v=tuple(sum(x[0][i] for x in incoming) for i in range(3));s=sum(x[1] for x in incoming)
        rows.append({"target":list(target),"multiplicity":len(incoming),"vector_sum":list(v),"sreg_sum":s,"direction_out":[int(np.sign(x)) for x in v],"sreg_out":min(s,19664),"saturated":s>19664})
    return rows

def prediction(n,z):
    out=np.zeros((n,n,n),dtype=np.uint64)
    for r in z:out[tuple(r["target"])]=pack(1,r["sreg_out"],tuple(r["direction_out"]),1)
    return out

def inventory(raw,clock):
    f=fields(raw);rows=[]
    for coord in np.argwhere(raw!=0):
        q=tuple(int(x) for x in coord);rows.append((tuple(int(f[k][q]) for k in ("dx","dy","dz")),int(f["sreg"][q]),int(clock[q])))
    return sorted(rows)

def arm(kernel,n,raw,clock,geometry):
    z=fibers(raw);pred=prediction(n,z);inv=inventory(raw,clock);world=NativeWorld(kernel,raw,clock,threads=1);info=world.tick();obs=world.raw.copy()
    return {"geometry":geometry,"inventory":inv,"source_count":len(inv),"fiber_count":len(z),"compression":len(inv)/len(z),"saturated_fibers":sum(r["saturated"] for r in z),"Z":z,"predicted_raw_sha256":sha256_array(pred),"observed_raw_sha256":sha256_array(obs),"raw_exact":bool(np.array_equal(pred,obs)),"positive_out":int(np.count_nonzero(fields(obs)["state"])),"kernel_info":info}

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);pairs=[]
    cluster_groups=lock["domain"]["geometries"]["clustered"]
    for n,master in zip(lock["domain"]["new_sizes"],lock["parameters"]["master_seeds"],strict=True):
        for pair_index in range(lock["parameters"]["pairs_per_size"]):
            seed=master+1009*pair_index;rng=np.random.default_rng(seed)
            directions=[]
            for size in cluster_groups:
                directions.extend(DIRS[i] for i in rng.choice(len(DIRS),size=size,replace=False))
            sregs=[int(x) for x in rng.integers(0,18001,size=24)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(24)]
            raw_s,clock_s=place(rng,n,directions,sregs,clocks,[1]*24);raw_c,clock_c=place(rng,n,directions,sregs,clocks,cluster_groups)
            spread=arm(kernel,n,raw_s,clock_s,"spread");cluster=arm(kernel,n,raw_c,clock_c,"clustered")
            pairs.append({"n":n,"pair_index":pair_index,"seed":seed,"same_global_inventory":spread["inventory"]==cluster["inventory"],"future_raw_distinct":spread["observed_raw_sha256"]!=cluster["observed_raw_sha256"],"future_support_distinct":spread["positive_out"]!=cluster["positive_out"],"arms":[spread,cluster]})
    arms=[a for p in pairs for a in p["arms"]];exact=sum(a["raw_exact"] for a in arms);interval=wilson(exact,len(arms));sat=sum(p["arms"][1]["saturated_fibers"] for p in pairs)
    rates={"exact_full_raw":exact/len(arms),"matched_inventory":sum(p["same_global_inventory"] for p in pairs)/len(pairs),"future_raw_distinct":sum(p["future_raw_distinct"] for p in pairs)/len(pairs),"future_support_distinct":sum(p["future_support_distinct"] for p in pairs)/len(pairs),"min_cluster_compression":min(p["arms"][1]["compression"] for p in pairs),"saturated_cluster_fibers":sat}
    t=lock["minimum_relevance"]
    pass_conditions={"exact":rates["exact_full_raw"]>=t["exact_full_raw_rate"],"inventory":rates["matched_inventory"]>=t["matched_inventory_rate"],"raw_distinct":rates["future_raw_distinct"]>=t["paired_future_raw_distinct_rate"],"support_distinct":rates["future_support_distinct"]>=t["paired_future_support_distinct_rate"],"compression":rates["min_cluster_compression"]>=t["cluster_compression_min"],"saturation":sat>=t["saturated_cluster_fibers_min"],"wilson":interval[0]>=t["wilson_95_lower_exact_rate"]}
    fail_conditions={"exact":exact<len(arms),"inventory":any(not p["same_global_inventory"] for p in pairs),"future":any(not p["future_raw_distinct"] or not p["future_support_distinct"] for p in pairs),"compression":rates["min_cluster_compression"]<4.0,"saturation":sat<20,"wilson":interval[0]<.95}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.nrh03.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"pairs":len(pairs),"worlds":len(arms)},"rates":rates,"exact_wilson_95":list(interval),"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"pairs":pairs}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result)
    print(json.dumps({k:result[k] for k in ("sample_sizes","rates","exact_wilson_95","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
