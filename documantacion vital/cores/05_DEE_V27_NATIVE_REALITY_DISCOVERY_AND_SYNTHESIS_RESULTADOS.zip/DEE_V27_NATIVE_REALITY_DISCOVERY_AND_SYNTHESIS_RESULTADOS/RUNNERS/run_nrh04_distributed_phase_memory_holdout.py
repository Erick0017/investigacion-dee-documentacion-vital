#!/usr/bin/env python3
"""Frozen NRH04 distributed phase-memory holdout."""
from __future__ import annotations

import hashlib,json,math,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NRH04_DISTRIBUTED_PHASE_MEMORY.json"
OUT=WORK/"RESULTS"/"NRH04_distributed_phase_memory_holdout.json"
EXPECTED_LOCK_SHA256="e3e361808515f0a949d2cf6978edf6b73a4631927927f0ca1557cefeaffcd7a8"
BASE_D=((1,0,0),(1,1,0),(1,0,1),(1,1,1))
BASE_SHIFTS=((0,2,0),(0,0,2),(0,2,0),(1,-1,0))

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def transform(v,permutation,signs):return tuple(signs[i]*v[permutation[i]] for i in range(3))
def sgnsum(ds):return tuple(int(np.sign(sum(d[i] for d in ds))) for i in range(3))
def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}

def prepare(n,center,distance,directions,shifts,sregs,clocks,mode,index,block_sreg):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);sources=[];mouths=[]
    for i,(d,shift,s,c) in enumerate(zip(directions,shifts,sregs,clocks,strict=True)):
        source=add(center,d,-distance,n);mouth=add(source,d,1,n);sources.append(source);mouths.append(mouth)
        if mode=="ablation" and i==index:continue
        placement=add(source,shift,1,n) if mode=="rewire" else source
        if int(raw[placement])!=0:raise RuntimeError("source overlap")
        raw[placement]=pack(0,s,d,4);clock[placement]=np.uint64(c)
        if mode=="block" and i==index:
            if int(raw[mouth])!=0:raise RuntimeError("mouth overlap")
            raw[mouth]=pack(1,block_sreg,(0,0,0),1)
    return raw,clock,sources,mouths

def simulate(kernel,n,center,distance,directions,shifts,sregs,clocks,mode,index,block_sreg,horizon):
    raw,clock,sources,mouths=prepare(n,center,distance,directions,shifts,sregs,clocks,mode,index,block_sreg)
    world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(horizon+1):
        trace.append({"tick":tick,"hub":decode(world.raw,center),"mouths":[decode(world.raw,q) for q in mouths],"sources":[decode(world.raw,q) for q in sources],"raw_nonzero":int(np.count_nonzero(world.raw)),"raw_sha256":sha256_array(world.raw)})
        if tick<horizon:world.tick()
    return {"mode":mode,"index":index,"trace":trace}

def hub_signature(run):return [(r["tick"],r["hub"]["d"],r["hub"]["sreg"]) for r in run["trace"] if r["hub"] is not None]

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);designs=[]
    for design_index,(seed,n,distance,trspec) in enumerate(zip(lock["parameters"]["seeds"],lock["domain"]["new_sizes"],lock["domain"]["distances"],lock["domain"]["direction_transforms"],strict=True)):
        rng=np.random.default_rng(seed);perm=trspec["permutation"];signs=trspec["signs"]
        directions=[transform(v,perm,signs) for v in BASE_D];shifts=[transform(v,perm,signs) for v in BASE_SHIFTS];out_d=sgnsum(directions)
        for translation_index in range(lock["domain"]["translations_per_size"]):
            center=tuple(int(x) for x in rng.integers(0,n,size=3));sregs=[int(x) for x in rng.integers(1,1001,size=4)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(4)];block_sreg=int(rng.integers(1,1001));horizon=distance+12
            baseline=simulate(kernel,n,center,distance,directions,shifts,sregs,clocks,"baseline",None,block_sreg,horizon)
            rewired=simulate(kernel,n,center,distance,directions,shifts,sregs,clocks,"rewire",None,block_sreg,horizon)
            base_sig=hub_signature(baseline);total_s=sum(sregs)
            baseline_exact=len(base_sig)>=lock["minimum_relevance"]["minimum_hub_events_per_design"] and all(t>=distance and (t-distance)%2==0 and d==list(out_d) and s==total_s for t,d,s in base_sig)
            comparisons=[]
            for idx in range(4):
                ablation=simulate(kernel,n,center,distance,directions,shifts,sregs,clocks,"ablation",idx,block_sreg,horizon)
                blocked=simulate(kernel,n,center,distance,directions,shifts,sregs,clocks,"block",idx,block_sreg,horizon)
                a_sig=hub_signature(ablation);b_sig=hub_signature(blocked)
                base_emission=[r["tick"] for r in baseline["trace"][1:] if r["mouths"][idx] is not None]
                block_emission=[r["tick"] for r in blocked["trace"][1:] if r["mouths"][idx] is not None]
                blocker_absent_tick1=blocked["trace"][1]["mouths"][idx] is None
                source_persistent=all(r["sources"][idx] is not None and r["sources"][idx]["semantic"]==4 and r["sources"][idx]["d"]==list(directions[idx]) for r in blocked["trace"])
                parity_inverted=all(((t in base_emission) != (t in block_emission)) for t in range(1,horizon+1))
                expected_s=total_s-sregs[idx]
                ablation_robust=len(a_sig)>=lock["minimum_relevance"]["minimum_hub_events_per_design"] and all(d==list(out_d) and s==expected_s for _,d,s in a_sig)
                memory_exact=blocker_absent_tick1 and source_persistent and parity_inverted and b_sig==a_sig and blocked["trace"][-1]["raw_sha256"]!=baseline["trace"][-1]["raw_sha256"] and ablation_robust
                comparisons.append({"source_index":idx,"source_direction":list(directions[idx]),"source_sreg":sregs[idx],"blocker_absent_tick1":blocker_absent_tick1,"source_persistent":source_persistent,"baseline_mouth_emission_ticks":base_emission,"blocked_mouth_emission_ticks":block_emission,"parity_inverted":parity_inverted,"ablation_hub_signature":a_sig,"blocked_hub_signature":b_sig,"block_hub_equals_ablation":b_sig==a_sig,"ablation_direction_robust":ablation_robust,"post_removal_difference_final":blocked["trace"][-1]["raw_sha256"]!=baseline["trace"][-1]["raw_sha256"],"memory_exact":memory_exact,"ablation":ablation,"blocked":blocked})
            designs.append({"design_index":design_index,"translation_index":translation_index,"seed":seed,"n":n,"center":list(center),"distance":distance,"directions":[list(x) for x in directions],"output_direction":list(out_d),"sregs":sregs,"clocks":clocks,"horizon":horizon,"baseline_exact":baseline_exact,"baseline_hub_signature":base_sig,"rewire_hub_signature":hub_signature(rewired),"rewire_zero_hub":len(hub_signature(rewired))==0,"comparisons":comparisons,"baseline":baseline,"rewired":rewired})
    comps=[c for d in designs for c in d["comparisons"]];memory=sum(c["memory_exact"] for c in comps);interval=wilson(memory,len(comps));rates={"baseline_exact":sum(d["baseline_exact"] for d in designs)/len(designs),"blocker_absent_tick1":sum(c["blocker_absent_tick1"] for c in comps)/len(comps),"source_persistent":sum(c["source_persistent"] for c in comps)/len(comps),"parity_inversion":sum(c["parity_inverted"] for c in comps)/len(comps),"block_hub_equals_ablation":sum(c["block_hub_equals_ablation"] for c in comps)/len(comps),"post_removal_difference_final":sum(c["post_removal_difference_final"] for c in comps)/len(comps),"single_ablation_direction_robust":sum(c["ablation_direction_robust"] for c in comps)/len(comps),"rewire_zero_hub":sum(d["rewire_zero_hub"] for d in designs)/len(designs),"memory_exact":memory/len(comps)}
    t=lock["minimum_relevance"]
    pass_conditions={"baseline":rates["baseline_exact"]>=t["baseline_exact_design_rate"],"blocker":rates["blocker_absent_tick1"]>=t["blocker_absent_tick1_rate"],"source":rates["source_persistent"]>=t["source_persistent_rate"],"parity":rates["parity_inversion"]>=t["parity_inversion_rate"],"ablation_match":rates["block_hub_equals_ablation"]>=t["block_hub_equals_ablation_rate"],"final_memory":rates["post_removal_difference_final"]>=t["post_removal_difference_final_rate"],"robust_direction":rates["single_ablation_direction_robust"]>=t["single_ablation_direction_robust_rate"],"rewire":rates["rewire_zero_hub"]>=t["rewire_zero_hub_rate"],"event_count":all(len(d["baseline_hub_signature"])>=t["minimum_hub_events_per_design"] for d in designs),"wilson":interval[0]>=t["wilson_95_lower_block_memory_rate"]}
    fail_conditions={"central":any(rates[k]<.90 for k in ("baseline_exact","blocker_absent_tick1","source_persistent","parity_inversion","block_hub_equals_ablation","post_removal_difference_final","single_ablation_direction_robust")),"events":any(len(d["baseline_hub_signature"])<4 for d in designs),"rewire":rates["rewire_zero_hub"]<.90,"wilson":interval[0]<.85}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.nrh04.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"designs":len(designs),"block_ablation_pairs":len(comps)},"rates":rates,"memory_wilson_95":list(interval),"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"designs":designs}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("sample_sizes","rates","memory_wilson_95","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
