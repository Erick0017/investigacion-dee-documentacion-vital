#!/usr/bin/env python3
"""Frozen NRH05 eleven-value relational measurement holdout."""
from __future__ import annotations

import hashlib,json,math,sys
from collections import Counter
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NRH05_NATIVE_RELATIONAL_DELAY_SCALE.json"
OUT=WORK/"RESULTS"/"NRH05_native_relational_delay_scale_holdout.json"
EXPECTED_LOCK_SHA256="b39c5ddb868d74b54f27116a283fefdabd6b764e143814b3f5a69c1309a5f533"

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def sgnsum(a,b):return tuple(int(np.sign(a[i]+b[i])) for i in range(3))
def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half
def mi(pairs):
    joint=Counter(pairs);xs=Counter(x for x,_ in pairs);ys=Counter(y for _,y in pairs);n=len(pairs)
    return sum((c/n)*math.log2(c*n/(xs[x]*ys[y])) for (x,y),c in joint.items())
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q]),"raw":int(raw[q])}

def run_bank(kernel,n,base,separation,spacing,L,labels,target_d,probe_d,delta,arm,sregs,states,clocks,seed):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);hubs=[];calibration=labels if arm!="reversed" else list(reversed(labels))
    for idx,(label,j) in enumerate(zip(labels,calibration,strict=True)):
        hub=add(base,separation,idx*spacing,n);hubs.append(hub)
        probe_start=add(hub,probe_d,-(L+j),n)
        if int(raw[probe_start])!=0:raise RuntimeError("probe overlap")
        raw[probe_start]=pack(states[1],sregs[1],probe_d,1);clock[probe_start]=np.uint64(clocks[1])
        if arm!="absent":
            target_start=add(hub,target_d,-(L+delta),n)
            if int(raw[target_start])!=0:raise RuntimeError("target overlap")
            raw[target_start]=pack(states[0],sregs[0],target_d,1);clock[target_start]=np.uint64(clocks[0])
    initial_empty=all(int(raw[q])==0 for q in hubs);out_d=sgnsum(target_d,probe_d);out_s=min(sum(sregs),19664);world=NativeWorld(kernel,raw,clock,threads=1);events=[];tick_hashes=[];max_tick=L+max(abs(x) for x in labels)+3
    for tick in range(max_tick+1):
        tick_hashes.append(sha256_array(world.raw))
        for label,hub in zip(labels,hubs,strict=True):
            r=decode(world.raw,hub)
            if r is not None:events.append({"tick":tick,"channel":label,"record":r})
        if tick<max_tick:world.tick()
    merged=[e for e in events if e["record"]["state"]==1 and e["record"]["semantic"]==1 and e["record"]["d"]==list(out_d) and e["record"]["sreg"]==out_s]
    channels=sorted(set(e["channel"] for e in merged));measurement=channels[0] if len(channels)==1 else None;correct=(len(channels)==0 if arm=="absent" else measurement==delta)
    return {"seed":seed,"n":n,"base":list(base),"frame":{"target":list(target_d),"probe":list(probe_d),"separation":list(separation)},"L":L,"labels":labels,"calibration":calibration,"delta":delta,"arm":arm,"sregs":sregs,"states":states,"clocks":clocks,"output_direction":list(out_d),"output_sreg":out_s,"initial_hubs_empty":initial_empty,"events":events,"merged_events":merged,"active_channels":channels,"measurement":measurement,"correct":correct,"tick_hashes":tick_hashes}

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);labels=lock["domain"]["scale_labels"];cases=[]
    for idx,(seed,n,frame) in enumerate(zip(lock["parameters"]["seeds"],lock["domain"]["new_sizes"],lock["domain"]["direction_frames"],strict=True)):
        rng=np.random.default_rng(seed);base=tuple(int(x) for x in rng.integers(0,n,size=3));target_d=tuple(frame["target"]);probe_d=tuple(frame["probe"]);sep=tuple(frame["separation"])
        sregs=[int(x) for x in (rng.integers(1,7001,size=2) if idx<2 else rng.integers(10000,18001,size=2))];states=[int(x) for x in rng.integers(1,2**31,size=2)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(2)]
        for delta in labels:
            cases.append(run_bank(kernel,n,base,sep,lock["domain"]["channel_spacing"],lock["domain"]["base_path_length"],labels,target_d,probe_d,delta,"native",sregs,states,clocks,seed))
            cases.append(run_bank(kernel,n,base,sep,lock["domain"]["channel_spacing"],lock["domain"]["base_path_length"],labels,target_d,probe_d,delta,"reversed",sregs,states,clocks,seed))
        cases.append(run_bank(kernel,n,base,sep,lock["domain"]["channel_spacing"],lock["domain"]["base_path_length"],labels,target_d,probe_d,0,"absent",sregs,states,clocks,seed))
    native=[c for c in cases if c["arm"]=="native"];destroyed=[c for c in cases if c["arm"]=="reversed"];absent=[c for c in cases if c["arm"]=="absent"]
    correct=sum(c["correct"] for c in native);interval=wilson(correct,len(native));pairs=[(c["delta"],c["measurement"] if c["measurement"] is not None else "NONE") for c in native];info=mi(pairs)
    by_class={str(label):{"n":sum(c["delta"]==label for c in native),"correct":sum(c["delta"]==label and c["correct"] for c in native)} for label in labels}
    rates={"native_accuracy":correct/len(native),"native_information_bits":info,"destroyed_frozen_label_accuracy":sum(c["correct"] for c in destroyed)/len(destroyed),"absent_no_record":sum(c["correct"] for c in absent)/len(absent),"no_evolution_empty":sum(c["initial_hubs_empty"] for c in cases)/len(cases)};t=lock["minimum_relevance"]
    pass_conditions={"accuracy":rates["native_accuracy"]>=t["native_accuracy"],"information":info>=t["native_information_bits"],"classes":all(v["correct"]==v["n"] for v in by_class.values()),"destroyed":rates["destroyed_frozen_label_accuracy"]<=t["destroyed_frozen_label_accuracy_max"],"absent":rates["absent_no_record"]>=t["absent_no_record_rate"],"no_evolution":rates["no_evolution_empty"]>=t["no_evolution_empty_rate"],"wilson":interval[0]>=t["wilson_95_lower_native_accuracy"]}
    fail_conditions={"accuracy":rates["native_accuracy"]<.90,"information":info<3.0,"class":any(v["correct"]/v["n"]<.75 for v in by_class.values()),"destroyed":rates["destroyed_frozen_label_accuracy"]>.30,"absent":rates["absent_no_record"]<1.0,"no_evolution":rates["no_evolution_empty"]<1.0}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.nrh05.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"native":len(native),"destroyed":len(destroyed),"absent":len(absent)},"rates":rates,"native_wilson_95":list(interval),"by_class":by_class,"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"cases":cases}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("sample_sizes","rates","native_wilson_95","by_class","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
