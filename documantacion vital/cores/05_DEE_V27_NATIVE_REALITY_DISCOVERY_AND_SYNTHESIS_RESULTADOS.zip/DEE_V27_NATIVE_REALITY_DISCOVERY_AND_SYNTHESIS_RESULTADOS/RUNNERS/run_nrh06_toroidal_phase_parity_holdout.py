#!/usr/bin/env python3
"""Frozen NRH06 toroidal phase-parity holdout."""
from __future__ import annotations

import hashlib,json,math,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,atomic_json,canonical_hash,fields,pack,sha256_array,verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"NRH06_TOROIDAL_PHASE_PARITY_LAW.json"
OUT=WORK/"RESULTS"/"NRH06_toroidal_phase_parity_holdout.json"
EXPECTED_LOCK_SHA256="569a95b3850f3317ffa570164b07e7700b59d66612b958e665e38e9938b19b58"
BASE_D=((1,0,0),(1,1,0),(1,0,1),(1,1,1))

def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def transform(v,p,s):return tuple(s[i]*v[p[i]] for i in range(3))
def sgnsum(ds):return tuple(int(np.sign(sum(d[i] for d in ds))) for i in range(3))
def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half
def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[k][q]) for k in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}
def hkey(row):
    r=row["hub"];return None if r is None else (tuple(r["d"]),r["sreg"],r["state"],r["semantic"])

def simulate(kernel,n,center,distance,directions,sregs,clocks,mode,horizon):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);sources=[];mouths=[]
    for i,(d,s,c) in enumerate(zip(directions,sregs,clocks,strict=True)):
        source=add(center,d,-distance,n);mouth=add(source,d,1,n);sources.append(source);mouths.append(mouth)
        if mode=="ablation" and i==3:continue
        raw[source]=pack(0,s,d,4);clock[source]=np.uint64(c)
        if mode=="block" and i==3:raw[mouth]=pack(1,1,(0,0,0),1)
    world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(horizon+1):
        trace.append({"tick":tick,"hub":decode(world.raw,center),"source3":decode(world.raw,sources[3]),"mouth3":decode(world.raw,mouths[3]),"raw_nonzero":int(np.count_nonzero(world.raw)),"raw_sha256":sha256_array(world.raw)})
        if tick<horizon:world.tick()
    return {"mode":mode,"trace":trace}

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);rows=[]
    transforms=lock["domain"]["signed_permutations"];distances=lock["domain"]["distances"]
    for seed,n in zip(lock["parameters"]["seeds"],lock["domain"]["new_sizes"],strict=True):
        rng=np.random.default_rng(seed)
        for design_index,(tr,distance) in enumerate(zip(transforms,distances,strict=True)):
            center=tuple(int(x) for x in rng.integers(0,n,size=3));directions=[transform(d,tr["permutation"],tr["signs"]) for d in BASE_D];out_d=sgnsum(directions)
            if directions[3]!=out_d:raise RuntimeError("collinearity lost")
            sregs=[int(x) for x in rng.integers(1,501,size=4)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(4)];horizon=distance+3*n
            baseline=simulate(kernel,n,center,distance,directions,sregs,clocks,"baseline",horizon);ablation=simulate(kernel,n,center,distance,directions,sregs,clocks,"ablation",horizon);block=simulate(kernel,n,center,distance,directions,sregs,clocks,"block",horizon)
            equal_ab=[hkey(a)==hkey(b) for a,b in zip(ablation["trace"],block["trace"],strict=True)];equal_base=[hkey(a)==hkey(b) for a,b in zip(baseline["trace"],block["trace"],strict=True)];first_div=next((t for t in range(distance,horizon+1) if not equal_ab[t]),None);restored=next((t for t in range(distance,horizon-2) if all(equal_base[t:t+4])),None)
            expected=(distance+n) if n%2==0 else None;prediction_exact=(first_div==expected) if n%2==0 else first_div is None;blocker_absent=block["trace"][1]["mouth3"] is None;source_persistent=all(r["source3"] is not None and r["source3"]["semantic"]==4 for r in block["trace"])
            rows.append({"seed":seed,"n":n,"parity":"even" if n%2==0 else "odd","design_index":design_index,"center":list(center),"distance":distance,"directions":[list(d) for d in directions],"output_direction":list(out_d),"sregs":sregs,"clocks":clocks,"horizon":horizon,"expected_first_divergence":expected,"observed_first_divergence":first_div,"prediction_exact":prediction_exact,"blocker_absent_tick1":blocker_absent,"source_persistent":source_persistent,"first_four_tick_baseline_restoration":restored,"no_baseline_restoration":restored is None,"baseline":baseline,"ablation":ablation,"block":block})
    even=[r for r in rows if r["parity"]=="even"];odd=[r for r in rows if r["parity"]=="odd"];correct=sum(r["prediction_exact"] for r in rows);interval=wilson(correct,len(rows));rates={"pooled_prediction":correct/len(rows),"even_exact":sum(r["prediction_exact"] for r in even)/len(even),"odd_no_divergence":sum(r["prediction_exact"] for r in odd)/len(odd),"blocker_absent_tick1":sum(r["blocker_absent_tick1"] for r in rows)/len(rows),"source_persistent":sum(r["source_persistent"] for r in rows)/len(rows),"no_baseline_restoration":sum(r["no_baseline_restoration"] for r in rows)/len(rows)};t=lock["minimum_relevance"]
    pass_conditions={"even":rates["even_exact"]>=t["even_exact_rate"],"odd":rates["odd_no_divergence"]>=t["odd_no_divergence_rate"],"blocker":rates["blocker_absent_tick1"]>=t["blocker_absent_tick1_rate"],"source":rates["source_persistent"]>=t["source_persistent_rate"],"no_restore":rates["no_baseline_restoration"]>=t["no_baseline_restoration_rate"],"wilson":interval[0]>=t["wilson_95_lower_pooled_prediction_rate"]}
    fail_conditions={"even":rates["even_exact"]<.85,"odd":rates["odd_no_divergence"]<.85,"pooled":rates["pooled_prediction"]<.90,"controls":rates["blocker_absent_tick1"]<.90 or rates["source_persistent"]<.90,"restore":rates["no_baseline_restoration"]<.90,"wilson":interval[0]<.80}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.nrh06.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"designs":len(rows),"even":len(even),"odd":len(odd)},"rates":rates,"prediction_wilson_95":list(interval),"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"rows":rows}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("sample_sizes","rates","prediction_wilson_95","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
