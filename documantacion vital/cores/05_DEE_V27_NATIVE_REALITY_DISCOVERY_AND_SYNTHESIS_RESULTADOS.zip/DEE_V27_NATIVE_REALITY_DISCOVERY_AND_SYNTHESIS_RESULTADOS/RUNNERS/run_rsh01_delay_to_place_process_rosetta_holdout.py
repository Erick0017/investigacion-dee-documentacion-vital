#!/usr/bin/env python3
"""Frozen phenomenon-first delay-to-place Rosetta process holdout."""
from __future__ import annotations

import hashlib,json,sys
from pathlib import Path
import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import atomic_json,canonical_hash,verify_and_load_kernel
from run_nrh05_native_relational_delay_scale_holdout import mi,run_bank,wilson

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"RSH01_DELAY_TO_PLACE_PROCESS_ROSETTA.json"
OUT=WORK/"RESULTS"/"RSH01_delay_to_place_process_rosetta_holdout.json"
EXPECTED_LOCK_SHA256="8eefdfbcf0c725582498de885ecfb0ca58a4cf39d475f48ff556b512070dedb1"

def correlation(xs,ys):
    a=np.asarray(xs,dtype=float);b=np.asarray(ys,dtype=float)
    if len(a)<2 or np.std(a)==0 or np.std(b)==0:return 0.0
    return float(np.corrcoef(a,b)[0,1])

def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);spec=lock["new_holdout"];labels=spec["labels"];cases=[]
    for idx,(seed,n,frame) in enumerate(zip(spec["seeds"],spec["sizes"],spec["frames"],strict=True)):
        rng=np.random.default_rng(seed);base=tuple(int(x) for x in rng.integers(0,n,size=3));target_d=tuple(frame["target"]);probe_d=tuple(frame["probe"]);sep=tuple(frame["separation"])
        sregs=[int(x) for x in (rng.integers(1,8001,size=2) if idx==0 else rng.integers(9000,18001,size=2))];states=[int(x) for x in rng.integers(1,2**31,size=2)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(2)]
        for delta in labels:
            cases.append(run_bank(kernel,n,base,sep,spec["channel_spacing"],spec["base_path_length"],labels,target_d,probe_d,delta,"native",sregs,states,clocks,seed))
            cases.append(run_bank(kernel,n,base,sep,spec["channel_spacing"],spec["base_path_length"],labels,target_d,probe_d,delta,"reversed",sregs,states,clocks,seed))
        cases.append(run_bank(kernel,n,base,sep,spec["channel_spacing"],spec["base_path_length"],labels,target_d,probe_d,0,"absent",sregs,states,clocks,seed))
    native=[c for c in cases if c["arm"]=="native"];rev=[c for c in cases if c["arm"]=="reversed"];absent=[c for c in cases if c["arm"]=="absent"]
    k=sum(c["correct"] for c in native);interval=wilson(k,len(native));info=mi([(c["delta"],c["measurement"] if c["measurement"] is not None else "NONE") for c in native]);rho=correlation([c["delta"] for c in native],[c["measurement"] if c["measurement"] is not None else 999 for c in native])
    by_label={str(x):{"n":sum(c["delta"]==x for c in native),"correct":sum(c["delta"]==x and c["correct"] for c in native)} for x in labels}
    rates={"native_accuracy":k/len(native),"native_information_bits":info,"spearman_for_ordered_unique_labels":rho,"reversed_accuracy":sum(c["correct"] for c in rev)/len(rev),"absent_no_response":sum(c["correct"] for c in absent)/len(absent),"no_evolution_empty":sum(c["initial_hubs_empty"] for c in cases)/len(cases)};t=lock["minimum_relevance"]
    pass_conditions={"accuracy":rates["native_accuracy"]>=t["native_accuracy"],"rank":rho>=t["spearman"],"labels":all(v["correct"]==v["n"] for v in by_label.values()),"reversal":rates["reversed_accuracy"]<=t["reversed_accuracy_max"],"absent":rates["absent_no_response"]>=t["absent_no_response_rate"],"wilson":interval[0]>=t["wilson_95_lower_native_accuracy"],"structure":all(len(c["active_channels"])==1 for c in native)}
    fail_conditions={"accuracy":rates["native_accuracy"]<.90,"rank":rho<.90,"label":any(v["correct"]/v["n"]<.67 for v in by_label.values()),"reversal":rates["reversed_accuracy"]>.30,"absent":rates["absent_no_response"]<1.0}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL" if any(fail_conditions.values()) else "INCONCLUSIVE";classification="FROZEN_ROSETTA_CANDIDATE" if verdict=="PASS" else "ROSETTA_CANDIDATE_REJECTED" if verdict=="FAIL" else "INCONCLUSIVE"
    result={"schema":"dee.v27.native_reality.rsh01.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_PHENOMENON_FIRST_ROSETTA_TEST","lock_sha256":observed,"kernel_environment":environment,"external_target":lock["external_target"],"map":lock["map"],"sample_sizes":{"native":len(native),"reversed":len(rev),"absent":len(absent)},"rates":rates,"native_wilson_95":list(interval),"by_label":by_label,"pass_conditions":pass_conditions,"fail_conditions":fail_conditions,"verdict":verdict,"classification":classification,"classification_ceiling":lock["classification_ceiling"],"cases":cases}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("sample_sizes","rates","native_wilson_95","pass_conditions","verdict","classification")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2
if __name__=="__main__":raise SystemExit(main())
