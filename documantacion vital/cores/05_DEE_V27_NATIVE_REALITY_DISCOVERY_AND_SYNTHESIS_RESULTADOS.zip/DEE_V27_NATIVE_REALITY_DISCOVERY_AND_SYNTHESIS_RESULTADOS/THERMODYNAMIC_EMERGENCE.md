# Emergencia termodinámica

## Veredicto

Se encontraron balance exacto sectorial e irreversibilidad lógica dependiente del observador. No se encontró una termodinámica nativa completa, temperatura, energía global, H-teorema, detailed balance ni ensemble de equilibrio validado.

## Balance de fibra

Para una fibra de destino inicialmente vacía dentro del sector de colisión,

`s_out=min(sum_j s_j,19664)`.

Por tanto:

- si `sum_j s_j<=19664`, el total `s_reg` incidente se conserva en la salida;
- si `sum_j s_j>19664`, la pérdida observada es exactamente `sum_j s_j-19664`.

Es una ley de balance y sink de saturación. Fuera de ese sector, fuentes persistentes, guardas y otras ramas pueden crear, conservar o eliminar registros. El total global no es una carga conservada y no se denomina energía.

## Irreversibilidad de resolución

El resolvedor direccional no es inyectivo. En el censo completo de 325 pares no ordenados de las 26 direcciones no nulas:

- cada output no nulo posee 12 preimágenes;
- el output cero posee 13;
- `H(input)=log2(325)=8.3442959` bits;
- `H(output)=4.7547143` bits;
- `H(input|output)=3.5895816` bits.

La pérdida corresponde a identidad de preimagen respecto del observador que sólo ve dirección de salida. El microestado determinista completo no se vuelve estocástico por ello. Ésta es irreversibilidad lógica/coarse, no producción de entropía termodinámica.

## Ensembles

NRD03 ejecutó 48 mundos independientes `N=10`, con inventarios iniciales `K=8,32,96`, durante 20 ticks. Se construyó un macroobservador relacional con conteos de support, direcciones y multiplicidades. Su entropía empírica exhibió incrementos y decrementos. Los mundos sparse mostraron recurrencias de periodo `N`; los densos entraron en la dinámica de basin heredada.

La no monotonicidad rechaza un H-teorema para ese observable y ensemble. No rechaza todos los coarse-grainings posibles.

## Variables lentas

La variable lenta nueva más clara no es un total extensivo: es una relación de fase entre trenes persistentes y hub. Una perturbación local desaparece inmediatamente, pero su efecto sobre el registro persiste. Su vida depende de la órbita topológica y de la paridad de N. Es memoria dinámica, no una temperatura.

Los basins y el signo de historia productiva heredados también son lentos/predictivos en sus dominios, pero no forman una familia de equilibrio.

## Dependencia del observador

El mismo update puede ser reversible a nivel de trayectoria completa y many-to-one para un puerto que ve sólo la salida. Entropía de raw, de fibers, de histories y entropy rate son objetos diferentes. Esta campaña cuantificó sólo la pérdida de identidad de una fibra y la distribución de un macroobservador elegido; no los colapsó en una entropía física.

## Qué faltaría para termodinámica

Se necesitarían, con definiciones congeladas:

- ensembles estacionarios reproducibles y límite en N;
- una cantidad extensiva o quasi-conservada más allá de sectores triviales;
- variable intensiva conjugada que controle distribuciones y respuestas de varios sistemas;
- fluctuaciones, susceptibilidad y relación de balance consistentes;
- independencia razonable del coarse-graining;
- predicciones holdout cross-N/preparación.

Nada de eso puede inferirse de la forma algebraica de `s_reg` o de una entropía descriptiva aislada.
