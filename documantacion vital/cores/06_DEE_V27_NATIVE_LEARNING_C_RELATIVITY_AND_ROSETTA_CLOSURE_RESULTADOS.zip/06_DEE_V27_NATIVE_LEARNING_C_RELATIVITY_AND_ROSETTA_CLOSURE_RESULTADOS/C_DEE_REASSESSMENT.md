# Revaluación de `c_DEE`

## Cinco magnitudes que no deben colapsarse

1. `c_transport=1`: un portador normal libre se desplaza una arista Moore por actualización.
2. `c_raw_max<=3`: dependencia causal raw máxima por actualización; el bound heredado es agudo en contexto overflow.
3. `c_apparatus`: first-passage medido por un detector concreto.
4. `c_group`: velocidad de una envolvente colectiva, si existe.
5. `c_observed`: distancia de regla interna dividida por intervalos de clock interno.

Ninguna de ellas es automáticamente `c` física.

## Medición interna C6H05

Una regla DEE fue el número de aristas en el grafo de destino entre fuente y detector. Un clock de carrier contó llegadas; un clock independiente basado en fuente semantic-4 tuvo período dos. En cuatro casos nuevos, el vuelo libre midió exactamente una arista por intervalo. Esto elimina la dependencia exclusiva del contador externo de Python.

Con observadores consumptivos móviles de velocidad `w`, la llegada fue gobernada por la velocidad de cierre `||u-w||_infinity`. Los casos congelados produjeron clases `0`, `1` y `2`. Por tanto los aparatos válidos no midieron una velocidad común independiente del movimiento.

## Búsqueda colectiva C6D09

Nueve paquetes diluidos fueron traslaciones rígidas exactas y conservaron magnitud Fourier; tres trenes de fuente fueron secuencias no dispersivas de período dos. No apareció una velocidad de grupo distinta: eran productos del shift de portador y de la cadencia de fuente. Hojas de colisión sufrieron reducción many-to-one, no superposición lineal.

## Dictámenes

- `CARRIER_SPEED_CONFIRMED`.
- `RAW_CAUSAL_BOUND_CONFIRMED` por herencia exacta.
- `OPERATIONAL_SUBSTRATE_GRAPH_SPEED_FOUND`.
- No `OPERATIONAL_INVARIANT_SPEED_FOUND` para observadores móviles probados.
- No `COLLECTIVE_PROPAGATION_MODE_FOUND` más allá del producto balístico heredado.
- No `RELATIVISTIC_STRUCTURE_FOUND`.
- `NO_LIGHT_ROSETTA_FOUND` en la familia finita examinada.

Calibrar un voxel/tick a 299792458 m/s sería una elección de unidad, no una predicción.
