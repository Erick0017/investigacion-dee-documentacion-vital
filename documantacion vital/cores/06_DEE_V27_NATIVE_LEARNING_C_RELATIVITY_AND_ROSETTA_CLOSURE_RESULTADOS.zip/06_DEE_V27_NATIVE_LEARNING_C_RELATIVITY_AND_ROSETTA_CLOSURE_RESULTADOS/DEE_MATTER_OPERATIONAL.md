# Materia DEE operacional

## Definición

Una organización cuenta como materia DEE si mantiene identidad operacional suficiente, puede detectarse e interactuar y produce respuestas reproducibles. Esto no implica masa física.

## Clases encontradas

### Portador normal libre

Conserva un único soporte móvil, dirección, `s_reg` y semantic en el sector vacío. C6H06 mostró 30/30 casos tras más de dos wraps. El `state` inicial arbitrario normaliza a `1` después del primer destino; seis controles iniciados en `state=1` conservaron raw completo. La identidad pertinente es un cociente de raw, no raw completo.

### Colisión normal

En 2600/2600 colisiones de direcciones distintas sobre destino vacío:

`d_out=sign(u+v)`

`s_out=min(s_u+s_v,19664)`.

Dos linajes pasan a uno. Antes de saturación hay balance aditivo de `s_reg`; al cap se pierde información. Un probe fijo comprimió 25 direcciones de target a 17 fibras de respuesta: 4.644 bits de entrada a 4.004 bits de salida.

### Fuente persistente

Fuentes semantic-4 conservaron identidad en 3/3 y emitieron con período dos en 3/3. Son organizaciones persistentes, pero no la misma clase que un carrier libre.

### Interface estable

El control evanescente/state0 atravesó 4/4; el portador normal state1 fue absorbido hasta baseline en 4/4. No hubo reflexión. Es oclusión/absorción sectorial, no índice de refracción.

## Mecánica mínima

DEE tiene transporte, identidad cociente, composición no lineal capada, exclusión/consumo, detección y oclusión. No se encontró parámetro común de masa, ley fuerza–aceleración, conservación de momentum ponderado por `s_reg`, penetrabilidad universal ni scattering elástico.

## Dictamen

`DEE_MATTER_OPERATIONAL_MECHANICS_FOUND` es válido sólo para estas clases. Identificación con materia física externa, masa inercial o masa gravitacional permanece abierta.
