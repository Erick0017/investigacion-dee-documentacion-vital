# External-source provenance for C6R01

The only external candidate opened in CORE06 is the zero-parameter delay/coincidence/place process map inherited frozen from CORE05.

Independent study screened: Koppl and Carr, *Maps of interaural time difference in the chicken's brainstem nucleus laminaris* (2008), DOI `10.1007/s00422-008-0220-6`, PMID `18491165`, PMCID `PMC3170859`.

Authoritative records:

- https://pubmed.ncbi.nlm.nih.gov/18491165/
- https://pmc.ncbi.nlm.nih.gov/articles/PMC3170859/

The study reports relationships compatible with the frozen process map, but no unit-level machine-readable table or supplement was located. Files named `PMC3170859_oa.xml`, `PMC3170859_Fig15.jpg`, `PMC3170859_bioc.json`, and `Koppl_Carr_2008_chicken_ITD.pdf` are failed access responses (HTML/error text, not the advertised scientific objects) and must not be treated as evidence or packaged as primary data. `CARpnas88.pdf` is a valid primary article but belongs to the already-used barn-owl source family and therefore is not the independent test.

The exact missing object is a row-level table linking recording site, animal/penetration, anatomical position, monaural delay/phase, best ITD/IPD, characteristic frequency and characteristic delay. Aggregate paper statistics support only `EXTERNAL_COMPATIBILITY`, not a recomputed holdout or `ROSETTA_VALIDATED`.
