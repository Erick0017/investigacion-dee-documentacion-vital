# Relatividad interna

## Pregunta operacional

Se preguntó qué mide una organización DEE cuando ella misma se mueve y consume una excitación. No se aplicó sólo un cambio de coordenadas externo.

## Resultado

Para carrier `u` y detector `w`, el aparato probado obedeció el cierre sobre el grafo Moore:

`v_relative = ||u-w||_infinity`.

Se observaron cero (comovimiento sin encuentro), uno y dos (aproximación opuesta). El mismo carrier no tuvo la misma velocidad para todos los observadores.

## Consecuencia

La velocidad uno es especial respecto al sustrato/grafo de actualización, no como invariante Lorentz de los observadores construidos. Tampoco emergieron reglas de composición relativista, factor `gamma`, Doppler común, contracción ni intervalo preservado.

El cono raw `<=3t` tampoco coincide con el frente del carrier uno. DEE posee jerarquía de causalidades/transportes, no un único cono físico identificado.

## Alcance del negativo

Esto refuta la estructura relativista en el aparato móvil congelado y los modos colectivos finitos explorados. No es un teorema sobre toda organización posible de DEE. Una reclamación futura exigiría un clock/ruler móvil distinto, motivado independientemente, y varias relaciones adimensionales prospectivas; no basta buscar un número de velocidad.
