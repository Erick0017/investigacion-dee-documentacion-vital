# Resultados negativos y límites

## Aprendizaje

- Entrenar la phase de una fuente semantic-4 mediante llegada ordinaria no produjo cambio persistente en 36 celdas; 16 perturbaciones transitorias terminaron en <=8 ticks.
- No se demostró suma/carry aprendidos: el reducer no entrenado ganó como modelo más simple.
- No se demostró multiplicación, composición general, bit-width transfer ni aprendizaje universal.

## Propagación/relatividad

- Observadores móviles no midieron una velocidad común.
- Paquetes/trenes no añadieron group speed, dispersión, interferencia o isotropía mejorada.
- No se encontró estructura Lorentz ni Rosetta de luz.

## Materia

- No se encontró masa, inercia, fuerza–aceleración, momentum global o scattering elástico.
- La interface probada absorbió en vez de reflejar.
- `state` no es identidad persistente del carrier libre.

## Quantum

- El aparato congelado dio `|CHSH|=2`, no violación.
- No se encontró Born, entanglement, contextualidad cuántica o teleportation operacional.

## Termodinámica

- `s_reg` no es conservación global; soporte se contrae en mezclas.
- No temperatura, energía física, detailed balance, equilibrio común ni cierre hidrodinámico.

## Rosetta

- Ningún candidato alcanzó `EXTERNAL_PREDICTION` o `ROSETTA_VALIDATED`.
- La compatibilidad delay/place carece de filas unitarias y preregistro externo de efecto.

Todos estos negativos están limitados a las representaciones y dominios probados. No se promueven a imposibilidades ontológicas globales.
