# Descubrimientos nuevos de CORE06

## 1. Aprendizaje por linaje móvil

Una coincidencia de experiencia escribe una entidad que transporta la relación y modifica una respuesta posterior. La memoria no reside necesariamente en un sitio o peso; reside en historia, routing e interacción futura.

## 2. Álgebra aprendida acotada

La misma memoria implementa traslaciones enteras sobre valores no vistos y dos memorias se componen. Es aprendizaje de una clase de operador, no mero replay del ejemplo.

## 3. Cociente de identidad material

El `state` local no forma parte de la identidad persistente del carrier normal libre: se normaliza a uno mientras otras coordenadas se conservan. Esto separa preparación/evento de identidad transportada.

## 4. Bell operacional local

Los observers de CORE05 permitieron por primera vez un aparato con settings/outcomes explícitos. El resultado fue clásico exacto, aclarando qué faltaba en claims históricos.

## 5. Relajación direccional sectorial

Con inventario igual, alinear direcciones preserva el gas y mezclarlas induce contracción many-to-one. Organización, no cantidad sola, selecciona régimen disipativo.

## 6. Compatibilidad externa de proceso

El mapa DEE retardo/coincidencia/lugar comparte estructura operacional cuantificada con un estudio independiente de otro sistema biológico. Es el avance externo más fuerte hasta ahora, aunque permanece por debajo de predicción/validación.

## Unificación

Fibras de destino, reducer e historia explican aprendizaje, colisión material, observers, Bell local, composición y disipación. `UNIFIED_NATIVE_MECHANISM_FOUND` se justifica internamente en estos sectores; no significa teoría física unificada externa.
