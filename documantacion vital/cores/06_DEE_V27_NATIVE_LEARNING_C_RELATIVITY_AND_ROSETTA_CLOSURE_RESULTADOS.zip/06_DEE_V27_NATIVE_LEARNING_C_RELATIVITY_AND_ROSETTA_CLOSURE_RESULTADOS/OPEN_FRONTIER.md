# Frontera abierta

## Externa prioritaria

La única siguiente acción capaz de elevar el candidato Rosetta principal requiere datos externos row-level independientes: sitio, sujeto/penetración, anatomía, retardos/fases monaurales, best ITD/IPD y frecuencia. Antes de abrirlos debe congelarse el residual, efecto mínimo, clustering y predicción.

## Preparación física

Falta decidir qué procedimiento físico produce qué distribución sobre `Q0`. El kernel no puede seleccionar ese diccionario desde dentro. Sin él no se pueden fijar unidades, vacío, materia externa o probabilidades de detector.

## Fronteras internas legítimas

- teoremas asintóticos de relajación para clases mayores;
- capacidad/olvido/interferencia de bancos de memoria más densos;
- otros clocks/rulers móviles motivados por nueva estructura, no por rescatar Lorentz;
- clasificación completa de interfaces y colisiones con guards;
- posibles invariantes relacionales de rango superior.

Estas preguntas no cambian los dictámenes centrales con un sweep incremental de los aparatos actuales. Requerirían nueva teoría, escalas computacionales mayores o una nueva hipótesis causal independiente.

## Stopping rule

Aprendizaje, generalización, composición, `c_DEE`, observadores móviles, modo colectivo, materia operacional, quantum/Bell, disipación y Rosetta recibieron pruebas informativas. Las afirmaciones fuertes usaron locks previos; los FAIL se conservaron. La única promoción externa restante depende de datos que no están accesibles localmente. CORE06 alcanza cierre científico, no “fin de DEE”.
