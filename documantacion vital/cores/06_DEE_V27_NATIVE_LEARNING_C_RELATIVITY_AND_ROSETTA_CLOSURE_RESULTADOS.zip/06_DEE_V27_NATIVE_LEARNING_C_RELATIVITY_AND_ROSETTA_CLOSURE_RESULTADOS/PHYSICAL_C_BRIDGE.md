# Puente físico para `c`

## Candidato evaluado

El candidato más simple era identificar el shift balístico con una señal límite. Falló el requisito estructural: los observadores internos móviles miden cierre `0/1/2`, la cota causal raw es tres y los paquetes no añadieron un modo de grupo independiente o isotrópico en métrica euclídea.

## Por qué la escala SI no resuelve el problema

Una libertad dimensional permite definir `voxel/tick` para que una velocidad resulte 299792458 m/s. Eso consume el observable como calibración. No predice isotropía, composición de velocidades, ratios Doppler, propagación bidireccional o una segunda cantidad.

## Fingerprint que faltó

Para un puente fuerte se requerían, con el mismo mapa:

- velocidad límite independiente del observador interno;
- isotropía operacional o ley cuantitativa de anisotropía que coincida externamente;
- composición de velocidades y/o relación Doppler;
- respuesta a medio y scattering reproducibles;
- una predicción no usada para fijar unidades.

No surgió ese conjunto. El estado final es `NO_LIGHT_ROSETTA_FOUND`, no imposibilidad global de toda propagación efectiva.
