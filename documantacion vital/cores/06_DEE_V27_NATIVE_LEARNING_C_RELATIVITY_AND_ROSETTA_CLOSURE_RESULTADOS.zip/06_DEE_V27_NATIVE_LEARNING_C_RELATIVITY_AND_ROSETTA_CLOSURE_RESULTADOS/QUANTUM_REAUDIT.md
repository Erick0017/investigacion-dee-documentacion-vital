# Reauditoría quantum CORE 01–06

## Separación epistemológica

| Elemento | Estado |
|---|---|
| dinámica finita/periódica | hecho genérico de mapa finito |
| representación Koopman/permutacional | formalismo matemático |
| phase/history en DEE | estructura causal interna |
| observer interno | detector operacional, no conciencia ni postulado cuántico |
| Born | no identificado |
| entanglement | no identificado |
| Bell/CHSH | ahora operacionalmente formulable; aparato probado local |
| quantum físico | no validado |

## Aparato C6H07

Se construyó una fuente explícita `lambda` uniforme sobre ocho diagonales del cubo. Cada wing recibió `lambda` o `-lambda`, eligió entre dos settings locales y colisionó con su detector. El outcome binario fue el signo lexicográfico del primer componente no nulo de la dirección de salida. Preparación, settings, outcomes y muestreo quedaron congelados.

Resultado:

- 64/64 trials completos y retenidos;
- 128/128 registros locales;
- correlaciones congeladas `(-0.75,-1,-1,-0.75)`;
- `CHSH=-2` en dos frames traducidos;
- distribuciones locales exactamente invariantes al setting remoto.

## Dictamen

DEE puede instanciar un aparato Bell operacional y local. Eso corrige la antigua frase “no hay aparato” pero no produce violación. El aparato satura la cota clásica y es compatible con variable oculta local determinista.

No se encontró espacio de amplitudes físicas, regla Born, normalización probabilística no clásica, contextualidad certificada, entanglement o teleportation operacional. Las referencias históricas a periodicidad, phase, Koopman o “observer” no ascienden por sí solas de formalismo a quantum físico.

Estado: `QUANTUM_FORMAL_STRUCTURE_ONLY`. El resultado no es un teorema de imposibilidad para todos los aparatos DEE.
