param(
    [ValidateSet('verify','holdouts','all')]
    [string]$Mode = 'verify',
    [string]$Python = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Runner = Join-Path $Root 'RUNNERS'

if (-not (Test-Path -LiteralPath $Python)) {
    $Python = (Get-Command python -ErrorAction Stop).Source
}

& $Python -I -B (Join-Path $Runner 'validate_core06.py')
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

if ($Mode -in @('holdouts','all')) {
    $holdouts = @(
        'run_c6h01_associative_plasticity_holdout.py',
        'run_c6h02_class_generalization_reversal_holdout.py',
        'run_c6h03_native_successor_translation_holdout.py',
        'run_c6h04_compositional_translation_holdout.py',
        'run_c6h05_internal_kinematics_holdout.py',
        'run_c6h06_free_carrier_state_normalization_holdout.py',
        'run_c6h07_local_bell_apparatus_holdout.py',
        'run_c6h08_dissipative_ensemble_holdout.py'
    )
    foreach ($name in $holdouts) {
        & $Python -I -B (Join-Path $Runner $name)
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
}

if ($Mode -eq 'all') {
    $discoveries = Get-ChildItem -LiteralPath $Runner -Filter 'run_c6d*.py' | Sort-Object Name
    foreach ($script in $discoveries) {
        & $Python -I -B $script.FullName
        if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    }
}

Write-Output "CORE06 reproduction mode '$Mode' completed."
