# Cierre Rosetta

## Ranking después de CORE06

1. Retardo/coincidencia/lugar: `EXTERNAL_COMPATIBILITY`.
2. Transporte/causalidad: ley interna, pero relatividad y puente de luz negativos en el aparato probado.
3. Topología–fase–historia: ley interna sin mapa externo independiente.
4. Materia/interface: mecánica operacional interna sin masa/preparación física.
5. Disipación estadística: ley sectorial sin conjugadas ni mapa de ensemble físico.
6. Quantum: aparato formal local con `|CHSH|=2`, sin Born.

## Compuerta externa C6R01

El mapa congelado en CORE05 es:

`retardo relativo -> coincidencia -> lugar ordenado`.

No tiene parámetros libres internos. Se comparó con una fuente independiente de los papers de barn owl usados por CORE05: Koppl y Carr (2008), pollo, DOI `10.1007/s00422-008-0220-6`.

El estudio reporta:

- diferencia monaural de click-delay versus best ITD: Spearman `rho=-0.68`, `p<0.001`, `n=35` para CF>0.4 kHz;
- diferencia de fase monaural versus best ITD: `rho=-0.84`, `p<0.001`, `n=40`;
- posición versus best IPD y best ITD: `rho=0.77`, `p<0.001`, `n=33`;
- characteristic delay versus posición: `rho=0.66`, `p<0.001`, `n=28` (lineal `r=0.72`, `p<0.001`, `n=26`).

Estas relaciones contienen los tres eslabones operacionales del candidato. No se cambiaron variables DEE al verlas.

## Por qué no es validación

No se localizó una tabla pública con filas por sitio/animal/penetración. Tampoco había un mínimo externo de relevancia hasheado antes de inspeccionar estas estadísticas. Sin filas no pueden recalcularse residual, incertidumbre clusterizada, generalización por animal ni predicción unitaria. El veredicto máximo permitido es `EXTERNAL_COMPATIBILITY` como discovery evidence.

Fuentes primarias:

- https://pubmed.ncbi.nlm.nih.gov/18491165/
- https://pmc.ncbi.nlm.nih.gov/articles/PMC3170859/

## Pieza exacta faltante

Un dataset independiente y row-level, más un protocolo prospectivo que fije:

`preparación física -> ensemble DEE -> transformador de escala -> detector/readout`,

umbral, clustering y predicciones antes de abrir los datos. El mismo mapa debe predecir más de un observable sin refit.

No hay `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED` en CORE06.
