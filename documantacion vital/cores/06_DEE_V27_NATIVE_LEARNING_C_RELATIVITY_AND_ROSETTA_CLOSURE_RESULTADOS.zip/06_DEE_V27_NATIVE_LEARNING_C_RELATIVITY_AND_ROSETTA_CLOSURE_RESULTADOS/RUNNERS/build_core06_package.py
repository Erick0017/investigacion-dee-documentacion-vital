"""Build the self-contained CORE06 archive with manifest and hashes."""
from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip"
ZIP_ROOT = "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS"

TOP_FILES = {
    "FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "TRANSVERSAL_01_TO_06.md",
    "NATIVE_LEARNING.md", "ARITHMETIC_LEARNING.md", "LEARNING_CAUSAL_MECHANISM.md",
    "C_DEE_REASSESSMENT.md", "INTERNAL_RELATIVITY.md", "PHYSICAL_C_BRIDGE.md",
    "DEE_MATTER_OPERATIONAL.md", "QUANTUM_REAUDIT.md", "THERMODYNAMIC_REAUDIT.md",
    "ROSETTA_CLOSURE.md", "NEW_DISCOVERIES.md", "NEGATIVE_RESULTS.md", "OPEN_FRONTIER.md",
    "STATE.json", "SCIENCE_LOG.ndjson", "CLAIMS.json", "ROSETTA_CANDIDATES.json",
    "LEARNING_STATE.json", "REPRODUCE.ps1", "MANIFEST.json", "HASHES.sha256",
}
DIRS = {"HOLDOUT_LOCKS", "RUNNERS", "RESULTS", "KERNEL", "CHECKPOINTS"}

def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def payload_files(include_generated: bool = False) -> list[Path]:
    files = [p for p in ROOT.iterdir() if p.is_file() and p.name in TOP_FILES]
    for dirname in DIRS:
        files.extend(p for p in (ROOT / dirname).rglob("*") if p.is_file())
    if (ROOT / "EXTERNAL_SOURCES" / "README.md").is_file():
        files.append(ROOT / "EXTERNAL_SOURCES" / "README.md")
    if not include_generated:
        files = [p for p in files if p.name not in {"MANIFEST.json", "HASHES.sha256"}]
    return sorted(set(files), key=lambda p: p.relative_to(ROOT).as_posix())

def main() -> None:
    base = payload_files(False)
    manifest = {
        "schema": "dee.v27.core06.manifest.v1",
        "package": OUT.name,
        "zip_root": ZIP_ROOT,
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "CORE06 only; parents are referenced by SHA-256 and are not duplicated",
        "excluded_external_scratch": "Failed HTML/error downloads are intentionally excluded; only EXTERNAL_SOURCES/README.md is packaged.",
        "files": [
            {"path": p.relative_to(ROOT).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p)}
            for p in base
        ],
    }
    (ROOT / "MANIFEST.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    hash_files = payload_files(True)
    (ROOT / "HASHES.sha256").write_text(
        "".join(f"{digest(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in hash_files if p.name != "HASHES.sha256"),
        encoding="utf-8",
    )
    final_files = payload_files(True)
    with zipfile.ZipFile(OUT, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for path in final_files:
            archive.write(path, f"{ZIP_ROOT}/{path.relative_to(ROOT).as_posix()}")
    expected_entries = {f"{ZIP_ROOT}/{p.relative_to(ROOT).as_posix()}" for p in final_files}
    recorded = {}
    for line in (ROOT / "HASHES.sha256").read_text(encoding="utf-8").splitlines():
        value, rel = line.split("  ", 1)
        recorded[f"{ZIP_ROOT}/{rel}"] = value
    with zipfile.ZipFile(OUT, "r") as archive:
        observed_entries = set(archive.namelist())
        if observed_entries != expected_entries:
            raise RuntimeError("archive entry set mismatch")
        for entry, expected_hash in recorded.items():
            observed_hash = hashlib.sha256(archive.read(entry)).hexdigest()
            if observed_hash != expected_hash:
                raise RuntimeError(f"archive payload hash mismatch: {entry}")
    print(json.dumps({"archive": str(OUT), "bytes": OUT.stat().st_size, "sha256": digest(OUT), "files": len(final_files), "internal_hash_validation": "PASS"}, indent=2))

if __name__ == "__main__":
    main()
