#!/usr/bin/env python3
"""C6D01: can an ordinary routed experience persistently alter a source learner?"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D01_ordinary_experience_phase_scan.json"
SOURCE_D = (1, 0, 0)
TRAIN_DS = ((0, 1, 0), (0, 0, 1), (0, -1, 0), (0, 1, 1))


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {
        "state": int(f["state"][q]),
        "sreg": int(f["sreg"][q]),
        "d": [int(f[name][q]) for name in ("dx", "dy", "dz")],
        "semantic": int(f["semantic"][q]),
    }


def prepare(n, source, arrival_tick, train_d, mode):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    raw[source] = pack(0, 17, SOURCE_D, 4)
    mouth = add(source, SOURCE_D, 1, n)
    if mode != "untrained":
        if mode == "trained":
            target = mouth
        else:
            # Shift the entire matched-exposure route transversely.  The
            # discovery-v0 offset (0,0,2) cancelled a two-tick +z route and
            # accidentally initialized one sham carrier at the mouth.
            sham_shift = (0, 0, 3) if train_d[2] == 0 else (0, 3, 0)
            target = add(mouth, sham_shift, 1, n)
        start = add(target, train_d, -arrival_tick, n)
        if int(raw[start]) != 0:
            raise RuntimeError("training start overlaps source")
        raw[start] = pack(1, 101, train_d, 1)
    return raw, clock, mouth


def simulate(kernel, n, source, arrival_tick, train_d, mode, horizon):
    raw, clock, mouth = prepare(n, source, arrival_tick, train_d, mode)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    line_points = [add(source, SOURCE_D, k, n) for k in range(1, 15)]
    for tick in range(horizon + 1):
        trace.append(
            {
                "tick": tick,
                "mouth": decode(world.raw, mouth),
                "source": decode(world.raw, source),
                "line": [decode(world.raw, q) for q in line_points],
                "raw_sha256": sha256_array(world.raw),
                "raw_nonzero": int(np.count_nonzero(world.raw)),
                "raw_copy": world.raw.copy(),
            }
        )
        if tick < horizon:
            world.tick()
    return trace


def source_line_signature(row):
    return [
        None if item is None else (item["sreg"], tuple(item["d"]), item["semantic"])
        for item in row["line"]
    ]


def main():
    kernel, environment = verify_and_load_kernel(1)
    n = 41
    source = (20, 20, 20)
    horizon = 32
    rows = []
    for arrival_tick in range(2, 11):
        for train_d in TRAIN_DS:
            runs = {
                mode: simulate(kernel, n, source, arrival_tick, train_d, mode, horizon)
                for mode in ("untrained", "trained", "sham")
            }
            learner_differences = []
            full_train_sham_hamming = []
            full_train_untrained_hamming = []
            for tick in range(horizon + 1):
                learner_differences.append(
                    source_line_signature(runs["trained"][tick])
                    != source_line_signature(runs["sham"][tick])
                )
                full_train_sham_hamming.append(
                    int(np.count_nonzero(runs["trained"][tick]["raw_copy"] != runs["sham"][tick]["raw_copy"]))
                )
                full_train_untrained_hamming.append(
                    int(np.count_nonzero(runs["trained"][tick]["raw_copy"] != runs["untrained"][tick]["raw_copy"]))
                )
            for run in runs.values():
                for row in run:
                    del row["raw_copy"]
            late_start = arrival_tick + 6
            late = learner_differences[late_start:]
            rows.append(
                {
                    "arrival_tick": arrival_tick,
                    "arrival_parity": arrival_tick % 2,
                    "train_direction": list(train_d),
                    "learner_line_differs_from_sham": learner_differences,
                    "late_difference_ticks": int(sum(late)),
                    "late_persistent_all": bool(late and all(late)),
                    "full_train_sham_hamming": full_train_sham_hamming,
                    "full_train_untrained_hamming": full_train_untrained_hamming,
                    "runs": runs,
                }
            )
    result = {
        "schema": "dee.v27.core06.c6d01.v1",
        "experiment_id": "C6D01_ORDINARY_EXPERIENCE_PHASE_SCAN",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can a normal routed carrier, rather than an initially written blocker, cause persistent change in the future source-line response?",
        "hypotheses": {
            "H_plastic": "at least one arrival phase/direction changes the source-line response beyond the transient relative to matched sham exposure",
            "H_memory_only": "the experience remains only as its own carrier lineage and does not alter the source organization",
            "H_exclusion": "arrival at an already occupied source mouth is excluded or changes only one emission without persistent phase reset",
        },
        "kernel_environment": environment,
        "design": {"n": n, "source": list(source), "horizon": horizon, "arrival_ticks": list(range(2, 11)), "directions": [list(x) for x in TRAIN_DS]},
        "rows": rows,
        "summary": {
            "cases": len(rows),
            "cases_with_any_late_source_line_difference": sum(row["late_difference_ticks"] > 0 for row in rows),
            "cases_with_persistent_late_source_line_difference": sum(row["late_persistent_all"] for row in rows),
            "maximum_late_difference_ticks": max(row["late_difference_ticks"] for row in rows),
        },
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(result["summary"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
