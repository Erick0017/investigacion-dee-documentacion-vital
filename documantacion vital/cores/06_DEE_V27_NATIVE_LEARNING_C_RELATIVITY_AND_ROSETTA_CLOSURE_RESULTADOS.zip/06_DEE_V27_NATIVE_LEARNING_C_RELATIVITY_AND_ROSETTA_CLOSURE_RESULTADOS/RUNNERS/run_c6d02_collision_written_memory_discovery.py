#!/usr/bin/env python3
"""C6D02: one-shot experience writes a routed memory that changes a later probe."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D02_collision_written_memory_discovery.json"

CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
WRONG_TEACHER = (-1, 0, 1)
MEMORY = (0, 1, 0)
ERASER = (1, -1, 0)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {
        "state": int(f["state"][q]),
        "sreg": int(f["sreg"][q]),
        "d": [int(f[name][q]) for name in ("dx", "dy", "dz")],
        "semantic": int(f["semantic"][q]),
        "raw": int(raw[q]),
    }


def place_arrival(raw, clock, target, tick, direction, sreg, state, clk, n):
    start = add(target, direction, -tick, n)
    if int(raw[start]) != 0:
        raise RuntimeError(f"overlap at {start}")
    raw[start] = pack(state, sreg, direction, 1)
    clock[start] = np.uint64(clk)
    return start


def prepare(n, junction, train_tick, query_tick, mode, translation_shift=(0, 0, 0)):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    readout = add(junction, MEMORY, query_tick - train_tick, n)
    starts = {}
    train_junction = junction
    if mode == "matched_exposure":
        train_junction = add(junction, translation_shift, 1, n)
    if mode not in {"untrained", "teacher_only"}:
        starts["training_cue"] = place_arrival(raw, clock, train_junction, train_tick, CUE, 5, 3, 101, n)
    if mode not in {"untrained", "cue_only"}:
        teacher = WRONG_TEACHER if mode == "label_shuffled" else TEACHER
        teacher_tick = train_tick + 1 if mode == "history_shuffled" else train_tick
        starts["teacher"] = place_arrival(raw, clock, train_junction, teacher_tick, teacher, 7, 5, 103, n)
    if mode != "query_absent":
        starts["query"] = place_arrival(raw, clock, readout, query_tick, CUE, 11, 9, 107, n)
    if mode == "reset_experience":
        erase_tick = train_tick + 4
        erase_point = add(junction, MEMORY, erase_tick - train_tick, n)
        starts["eraser"] = place_arrival(raw, clock, erase_point, erase_tick, ERASER, 13, 7, 109, n)
    return raw, clock, readout, starts


def simulate(kernel, n, junction, train_tick, query_tick, mode, translation_shift=(0, 0, 5)):
    raw, clock, readout, starts = prepare(n, junction, train_tick, query_tick, mode, translation_shift)
    world = NativeWorld(kernel, raw, clock, threads=1)
    horizon = query_tick + 2
    train_record = None
    readout_record = None
    downstream_record = None
    trace = []
    ablation_tick = train_tick + 4
    ablation_point = add(junction, MEMORY, ablation_tick - train_tick, n)
    for tick in range(horizon + 1):
        if tick == train_tick:
            train_record = decode(world.raw, junction)
        if tick == query_tick:
            readout_record = decode(world.raw, readout)
        if tick == query_tick + 1:
            expected_out_d = (1, 1, 0)
            downstream_record = decode(world.raw, add(readout, expected_out_d, 1, n))
        trace.append(
            {
                "tick": tick,
                "junction": decode(world.raw, junction),
                "memory_expected_position": decode(world.raw, add(junction, MEMORY, max(0, tick - train_tick), n)) if tick >= train_tick else None,
                "readout": decode(world.raw, readout),
                "raw_nonzero": int(np.count_nonzero(world.raw)),
                "raw_sha256": sha256_array(world.raw),
            }
        )
        if tick == ablation_tick and mode == "memory_ablation":
            world.raw_a[ablation_point] = np.uint64(0)
            world.raw_b[ablation_point] = np.uint64(0)
            world.clock_a[ablation_point] = np.uint64(0)
            world.clock_b[ablation_point] = np.uint64(0)
        if tick < horizon:
            world.tick()
    trained_signature = readout_record is not None and readout_record["d"] == [1, 1, 0] and readout_record["sreg"] == 23
    query_only_signature = readout_record is not None and readout_record["d"] == [1, 0, 0] and readout_record["sreg"] == 11
    memory_only_signature = readout_record is not None and readout_record["d"] == [0, 1, 0] and readout_record["sreg"] == 12
    return {
        "mode": mode,
        "n": n,
        "junction": list(junction),
        "train_tick": train_tick,
        "query_tick": query_tick,
        "readout": list(readout),
        "starts": {key: list(value) for key, value in starts.items()},
        "train_record": train_record,
        "readout_record": readout_record,
        "downstream_record": downstream_record,
        "trained_signature": trained_signature,
        "query_only_signature": query_only_signature,
        "memory_only_signature": memory_only_signature,
        "trace": trace,
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    designs = (
        (43, (20, 20, 20), 4, 13),
        (47, (13, 29, 17), 5, 14),
        (53, (31, 11, 27), 6, 17),
    )
    modes = (
        "trained_pair",
        "untrained",
        "cue_only",
        "teacher_only",
        "history_shuffled",
        "label_shuffled",
        "matched_exposure",
        "reset_experience",
        "memory_ablation",
        "query_absent",
    )
    cases = [simulate(kernel, *design, mode) for design in designs for mode in modes]
    by_mode = {
        mode: {
            "cases": sum(case["mode"] == mode for case in cases),
            "trained_signature": sum(case["mode"] == mode and case["trained_signature"] for case in cases),
            "query_only_signature": sum(case["mode"] == mode and case["query_only_signature"] for case in cases),
            "memory_only_signature": sum(case["mode"] == mode and case["memory_only_signature"] for case in cases),
        }
        for mode in modes
    }
    result = {
        "schema": "dee.v27.core06.c6d02.v1",
        "experiment_id": "C6D02_COLLISION_WRITTEN_MEMORY_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can an ordinary paired experience create a persistent internal carrier lineage that changes a later cue response?",
        "hypotheses": {
            "H_plasticity": "synchronous cue+teacher creates a memory-route carrier and a later cue is transformed; controls do not",
            "H_exposure": "the response follows carrier inventory or exposure rather than paired history",
            "H_direct_encoding": "the future readout is already occupied before evolution or appears without the query",
        },
        "mechanism_candidate": "cue (1,0,0) plus teacher (-1,1,0) collide to create memory direction (0,1,0); a later cue intersects that lineage and is transformed to (1,1,0)",
        "kernel_environment": environment,
        "cases": cases,
        "summary": {"designs": len(designs), "modes": len(modes), "by_mode": by_mode},
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(result["summary"], indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
