#!/usr/bin/env python3
"""C6D03: sequential port injection, persistence and stimulus-specific response."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_array, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D03_sequential_association_generalization.json"
CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
WRONG_TEACHER = (-1, 0, 1)
MEMORY = (0, 1, 0)
ERASER = (1, -1, 0)
OFF_SHIFT = (0, 0, 4)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def place_arrival(raw, clock, target, tick, direction, sreg, state, clk, n):
    start = add(target, direction, -tick, n)
    if int(raw[start]) != 0:
        raise RuntimeError(f"overlap {start}")
    raw[start] = pack(state, sreg, direction, 1)
    clock[start] = np.uint64(clk)
    return start


def simulate(kernel, n, junction, train_tick, delay, mode):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    teacher = WRONG_TEACHER if mode == "label_shuffled" else TEACHER
    teacher_tick = train_tick + 1 if mode == "history_shuffled" else train_tick
    if mode != "untrained":
        place_arrival(raw, clock, junction, train_tick, CUE, 5, 3, 101, n)
        place_arrival(raw, clock, junction, teacher_tick, teacher, 7, 5, 103, n)
    query_tick = train_tick + delay
    query_path = 5
    inject_tick = query_tick - query_path
    readout = add(junction, MEMORY, delay, n)
    query_target = add(readout, OFF_SHIFT, 1, n) if mode == "off_channel" else readout
    query_port = add(query_target, CUE, -query_path, n)
    reset_tick = train_tick + 3
    reset_point = add(junction, MEMORY, reset_tick - train_tick, n)
    if mode == "reset_experience":
        place_arrival(raw, clock, reset_point, reset_tick, ERASER, 13, 7, 109, n)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    injected = False
    port_was_empty = None
    ablated = False
    for tick in range(query_tick + 2):
        if tick == inject_tick and mode != "query_absent":
            port_was_empty = int(world.raw[query_port]) == 0
            if not port_was_empty:
                raise RuntimeError(f"occupied input port at {tick}: {query_port}")
            world.raw_a[query_port] = pack(9, 11, CUE, 1)
            world.raw_b[query_port] = world.raw_a[query_port]
            world.clock_a[query_port] = np.uint64(107)
            world.clock_b[query_port] = np.uint64(107)
            injected = True
        if tick == reset_tick and mode == "memory_ablation":
            expected_memory = add(junction, MEMORY, tick - train_tick, n)
            ablated = int(world.raw[expected_memory]) != 0
            world.raw_a[expected_memory] = np.uint64(0)
            world.raw_b[expected_memory] = np.uint64(0)
            world.clock_a[expected_memory] = np.uint64(0)
            world.clock_b[expected_memory] = np.uint64(0)
        trace.append({
            "tick": tick,
            "junction": decode(world.raw, junction),
            "readout": decode(world.raw, readout),
            "query_target": decode(world.raw, query_target),
            "memory_expected": decode(world.raw, add(junction, MEMORY, max(0, tick-train_tick), n)) if tick >= train_tick else None,
            "raw_nonzero": int(np.count_nonzero(world.raw)),
            "raw_sha256": sha256_array(world.raw),
        })
        if tick < query_tick + 1:
            world.tick()
    main_record = trace[query_tick]["readout"]
    query_record = trace[query_tick]["query_target"]
    return {
        "mode": mode,
        "n": n,
        "junction": list(junction),
        "train_tick": train_tick,
        "delay": delay,
        "query_tick": query_tick,
        "query_inject_tick": inject_tick,
        "readout": list(readout),
        "query_target": list(query_target),
        "query_port": list(query_port),
        "port_was_empty": port_was_empty,
        "query_injected": injected,
        "memory_ablated": ablated,
        "main_record": main_record,
        "query_record": query_record,
        "trained_response": main_record is not None and main_record["d"] == [1,1,0] and main_record["sreg"] == 23,
        "neutral_response": main_record is not None and main_record["d"] == [1,0,0] and main_record["sreg"] == 11,
        "memory_only_response": main_record is not None and main_record["d"] == [0,1,0] and main_record["sreg"] == 12,
        "off_channel_neutral": mode == "off_channel" and query_record is not None and query_record["d"] == [1,0,0] and query_record["sreg"] == 11 and main_record is not None and main_record["d"] == [0,1,0],
        "trace": trace,
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    n = 31
    junction = (15, 14, 16)
    train_tick = 4
    delays = (9, n + 7)
    modes = ("trained_pair", "untrained", "history_shuffled", "label_shuffled", "reset_experience", "memory_ablation", "query_absent", "off_channel")
    cases = [simulate(kernel, n, junction, train_tick, delay, mode) for delay in delays for mode in modes]
    summary = {
        "cases": len(cases),
        "trained_pair_exact": sum(c["mode"] == "trained_pair" and c["trained_response"] for c in cases),
        "trained_pair_total": sum(c["mode"] == "trained_pair" for c in cases),
        "negative_controls_neutral": sum(c["mode"] in {"untrained","history_shuffled","label_shuffled","reset_experience","memory_ablation"} and c["neutral_response"] for c in cases),
        "negative_controls_total": sum(c["mode"] in {"untrained","history_shuffled","label_shuffled","reset_experience","memory_ablation"} for c in cases),
        "query_absent_memory_only": sum(c["mode"] == "query_absent" and c["memory_only_response"] for c in cases),
        "query_absent_total": sum(c["mode"] == "query_absent" for c in cases),
        "off_channel_specific": sum(c["off_channel_neutral"] for c in cases),
        "off_channel_total": sum(c["mode"] == "off_channel" for c in cases),
        "all_injection_ports_empty": all(c["port_was_empty"] is not False for c in cases),
    }
    result = {
        "schema": "dee.v27.core06.c6d03.v1",
        "experiment_id": "C6D03_SEQUENTIAL_ASSOCIATION_GENERALIZATION",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Does collision-written memory persist across a torus cycle and alter a newly injected cue at its designated channel, while matched controls remain neutral?",
        "kernel_environment": environment,
        "cases": cases,
        "summary": summary,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
