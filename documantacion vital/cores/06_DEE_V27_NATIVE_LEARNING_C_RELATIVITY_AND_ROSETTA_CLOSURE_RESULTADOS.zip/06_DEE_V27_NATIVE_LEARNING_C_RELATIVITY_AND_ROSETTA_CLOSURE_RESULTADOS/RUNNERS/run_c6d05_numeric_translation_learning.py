#!/usr/bin/env python3
"""C6D05: discovery of a learned integer-translation operator.

Fixed code (chosen before any holdout): an example input x is encoded as B-x,
its supervised label y as y, and a query n as n. The ordinary collision writes
B+(y-x); a later collision yields B+n+(y-x). The frozen decoder subtracts B.
No query encoder contains its answer. Discovery tests several unseen n and delta.
"""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
OUT=WORK/"RESULTS"/"C6D05_numeric_translation_learning.json"
B=4096
CUE=(1,0,0); TEACHER=(-1,1,0); MEMORY=(0,1,0); WRONG_ERASER=(1,-1,0)


def add(q,d,k,n): return tuple((q[i]+k*d[i])%n for i in range(3))


def decode(raw,q):
    if int(raw[q])==0: return None
    f=fields(raw)
    return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}


def place_initial(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0: raise RuntimeError(f"initial overlap {q}")
    raw[q]=pack(state,sreg,d,1); clock[q]=np.uint64(clk)


def inject(world,q,d,sreg,state,clk):
    if int(world.raw[q])!=0: raise RuntimeError(f"occupied query port {q}")
    value=pack(state,sreg,d,1)
    world.raw_a[q]=value; world.raw_b[q]=value
    world.clock_a[q]=np.uint64(clk); world.clock_b[q]=np.uint64(clk)


def simulate(kernel,delta,query,mode,seed):
    n=55; train_tick=4; delay=12; query_tick=train_tick+delay; query_path=4
    train_x=[3,7,11,15]
    train_y=[x+delta for x in train_x]
    if mode=="label_shuffled": train_y=train_y[1:]+train_y[:1]
    junctions=[(20,16,8+9*i) for i in range(4)]
    raw=np.zeros((n,n,n),dtype=np.uint64); clock=np.zeros_like(raw)
    rng=np.random.default_rng(seed)
    states=[int(x) for x in rng.integers(1,2**32,size=20,dtype=np.uint64)]
    clocks=[int(rng.bit_generator.random_raw()) for _ in range(20)]
    if mode!="untrained":
        for i,(j,x,y) in enumerate(zip(junctions,train_x,train_y,strict=True)):
            tj=add(j,(0,0,3),1,n) if mode=="matched_exposure" else j
            tt=train_tick+1 if mode=="history_shuffled" else train_tick
            place_initial(raw,clock,tj,train_tick,CUE,B-x,states[2*i],clocks[2*i],n)
            place_initial(raw,clock,tj,tt,TEACHER,y,states[2*i+1],clocks[2*i+1],n)
            if mode=="ordinary_reset":
                reset_tick=train_tick+3
                reset_target=add(j,MEMORY,reset_tick-train_tick,n)
                place_initial(raw,clock,reset_target,reset_tick,WRONG_ERASER,31,states[10+i],clocks[10+i],n)
    world=NativeWorld(kernel,raw,clock,threads=1)
    inject_tick=query_tick-query_path
    ports=[]; targets=[]; ablation_present=[]
    for j in junctions:
        target=add(j,MEMORY,delay,n); targets.append(target); ports.append(add(target,CUE,-query_path,n))
    records=None; ports_empty=None
    for tick in range(query_tick+1):
        if tick==train_tick+3 and mode=="memory_ablation":
            for j in junctions:
                q=add(j,MEMORY,3,n); ablation_present.append(int(world.raw[q])!=0)
                world.raw_a[q]=np.uint64(0); world.raw_b[q]=np.uint64(0); world.clock_a[q]=np.uint64(0); world.clock_b[q]=np.uint64(0)
        if tick==inject_tick:
            ports_empty=all(int(world.raw[q])==0 for q in ports)
            for i,q in enumerate(ports): inject(world,q,CUE,query,states[15+i],clocks[15+i])
        if tick==query_tick: records=[decode(world.raw,q) for q in targets]
        if tick<query_tick: world.tick()
    decoded=[None if r is None else r["sreg"]-B for r in records]
    correct=[value==query+delta for value in decoded]
    memory_values=[B+(y-x) for x,y in zip(train_x,train_y,strict=True)]
    return {"delta":delta,"query":query,"mode":mode,"train_x":train_x,"train_y":train_y,"memory_values_predicted":memory_values,"targets":[list(q) for q in targets],"ports_empty":ports_empty,"ablation_present":ablation_present,"records":records,"decoded_outputs":decoded,"expected":query+delta,"channel_correct":correct,"all_channels_correct":all(correct),"any_channel_correct":any(correct)}


def main():
    kernel,environment=verify_and_load_kernel(1)
    deltas=(-2,1,2,4); queries=(0,2,5,9,12,16,20)
    modes=("trained","untrained","label_shuffled","history_shuffled","matched_exposure","ordinary_reset","memory_ablation")
    cases=[]
    for di,delta in enumerate(deltas):
        for qi,query in enumerate(queries):
            for mi,mode in enumerate(modes):
                cases.append(simulate(kernel,delta,query,mode,620000+di*1000+qi*10+mi))
    trained=[c for c in cases if c["mode"]=="trained"]
    controls=[c for c in cases if c["mode"]!="trained"]
    summary={
        "translation_rules":len(deltas),"unseen_queries_per_rule":len(queries),"training_examples_per_rule":4,
        "trained_exact":sum(c["all_channels_correct"] for c in trained),"trained_total":len(trained),
        "controls_without_full_correct":sum(not c["all_channels_correct"] for c in controls),"controls_total":len(controls),
        "controls_with_any_correct_channel":sum(c["any_channel_correct"] for c in controls),
        "all_ports_empty":all(c["ports_empty"] for c in cases),
        "all_ablation_targets_present":all(all(c["ablation_present"]) for c in cases if c["mode"]=="memory_ablation"),
    }
    result={
        "schema":"dee.v27.core06.c6d05.v1","experiment_id":"C6D05_NUMERIC_TRANSLATION_LEARNING","role":"DISCOVERY_EVIDENCE_ONLY",
        "question":"Can ordinary supervised examples write a translation parameter that maps unseen n to n+delta under one fixed encoder and decoder?",
        "fixed_representation":{"base":B,"training_input":"B-x","teacher_label":"y","query":"n","decoder":"observed_sreg-B","derived_memory":"B+(y-x)","derived_output":"n+(y-x)"},
        "anti_leakage":"The query encoder receives n only. Its expected n+delta is neither placed in the query nor used by the decoder. Labels y occur only during training.",
        "epistemic_ceiling":"Even a positive result is learned integer translation/successor, not general arithmetic; the encoder uses a deliberately chosen complement code exploiting the exact reducer.",
        "kernel_environment":environment,"summary":summary,"cases":cases,
    }
    result["content_sha256"]=canonical_hash(result); atomic_json(OUT,result)
    print(json.dumps(summary,indent=2,sort_keys=True)); return 0


if __name__=="__main__": raise SystemExit(main())
