#!/usr/bin/env python3
"""C6D06 M2/M3: trained gate versus simpler untrained collision addition.

This guards against calling an intrinsic reducer operation 'learned arithmetic'.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1];OUT=WORK/"RESULTS"/"C6D06_binary_addition_simpler_model.json"
B=4096;CUE=(1,0,0);TEACHER=(-1,1,0);MEMORY=(0,1,0);OP_A=(1,0,0);OP_B=(-1,0,0)


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"state":int(f["state"][q]),"semantic":int(f["semantic"][q])}


def place(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0:raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk)


def simulate(kernel,a,b,bits,mode,seed):
    n=31;j=(15,15,15);t0=3;delay=10;tq=t0+delay;target=add(j,MEMORY,delay,n)
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);rng=np.random.default_rng(seed)
    states=[int(x) for x in rng.integers(1,2**32,size=5,dtype=np.uint64)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(5)]
    if mode!="untrained":
        y=6 if mode=="label_shuffled" else 5
        tt=t0+1 if mode=="history_shuffled" else t0
        place(raw,clock,j,t0,CUE,B-5,states[0],clocks[0],n);place(raw,clock,j,tt,TEACHER,y,states[1],clocks[1],n)
    place(raw,clock,target,tq,OP_A,a,states[2],clocks[2],n);place(raw,clock,target,tq,OP_B,b,states[3],clocks[3],n)
    world=NativeWorld(kernel,raw,clock,threads=1);ablation_present=None;record=None
    for tick in range(tq+1):
        if tick==t0+3 and mode=="memory_ablation":
            q=add(j,MEMORY,3,n);ablation_present=int(world.raw[q])!=0
            world.raw_a[q]=np.uint64(0);world.raw_b[q]=np.uint64(0);world.clock_a[q]=np.uint64(0);world.clock_b[q]=np.uint64(0)
        if tick==tq:record=decode(world.raw,target)
        if tick<tq:world.tick()
    raw_sum=None if record is None else record["sreg"]
    gated_decoded=None if raw_sum is None else raw_sum-B
    direct_decoded=raw_sum
    expected=a+b
    return {"bits":bits,"a":a,"b":b,"carry":expected!=(a^b),"mode":mode,"record":record,"expected":expected,"gated_decoded":gated_decoded,"direct_decoded":direct_decoded,"gated_correct":gated_decoded==expected,"direct_correct":direct_decoded==expected,"ablation_present":ablation_present}


def main():
    kernel,environment=verify_and_load_kernel(1);modes=("trained_gate","untrained","label_shuffled","history_shuffled","memory_ablation");cases=[]
    index=0
    for bits in (2,3):
        for a in range(2**bits):
            for b in range(2**bits):
                for mode in modes:
                    cases.append(simulate(kernel,a,b,bits,mode,640000+index));index+=1
    trained=[c for c in cases if c["mode"]=="trained_gate"]
    untrained=[c for c in cases if c["mode"]=="untrained"]
    carry_untrained=[c for c in untrained if c["carry"]]
    width2=[c for c in untrained if c["bits"]==2];width3=[c for c in untrained if c["bits"]==3]
    negative_gated=[c for c in cases if c["mode"] in {"untrained","label_shuffled","history_shuffled","memory_ablation"}]
    summary={
        "pairs_2bit":len(width2),"pairs_3bit":len(width3),"carry_pairs":len(carry_untrained),
        "trained_offset_gate_exact":sum(c["gated_correct"] for c in trained),"trained_offset_gate_total":len(trained),
        "negative_gate_incorrect":sum(not c["gated_correct"] for c in negative_gated),"negative_gate_total":len(negative_gated),
        "untrained_direct_exact_2bit":sum(c["direct_correct"] for c in width2),
        "untrained_direct_exact_3bit":sum(c["direct_correct"] for c in width3),
        "untrained_direct_exact_carry":sum(c["direct_correct"] for c in carry_untrained),
        "untrained_direct_total_carry":len(carry_untrained),
        "learning_added_accuracy":0.0,
        "simpler_model_wins":all(c["direct_correct"] for c in untrained) and all(c["gated_correct"] for c in trained),
    }
    result={"schema":"dee.v27.core06.c6d06.v1","experiment_id":"C6D06_BINARY_ADDITION_SIMPLER_MODEL","role":"DISCOVERY_NEGATIVE_FOR_LEARNING_AND_EXACT_CROSSCHECK","question":"Does training add two-operand addition/carry capability beyond the untrained reducer?","models":{"trained_offset_gate":"identity examples write B; three-way collision plus decoder s-B outputs a+b","simpler_untrained":"two operand carriers collide at a blank destination; identity readout returns min(a+b,19664)"},"adjudication":"The trained gate can score perfectly, but the untrained direct reducer is equally exact with lower description length. Therefore M2/M3 do not evidence learned addition or learned carry; they cross-check an intrinsic arithmetic primitive.","kernel_environment":environment,"summary":summary,"cases":cases};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(summary,indent=2,sort_keys=True));return 0


if __name__=="__main__":raise SystemExit(main())
