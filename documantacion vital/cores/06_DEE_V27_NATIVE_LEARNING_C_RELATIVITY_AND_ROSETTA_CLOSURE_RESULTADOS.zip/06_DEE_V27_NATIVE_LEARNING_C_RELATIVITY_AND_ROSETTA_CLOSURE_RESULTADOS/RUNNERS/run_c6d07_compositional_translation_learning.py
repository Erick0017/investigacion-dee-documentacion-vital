#!/usr/bin/env python3
"""C6D07: discovery of sequential composition of two learned translations."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1];OUT=WORK/"RESULTS"/"C6D07_compositional_translation_learning.json"
B=4096;C=(1,0,0);T1=(-1,1,0);M1=(0,1,0);T2=(-1,0,1);M2=(0,0,1);R1=(1,1,0);R2=(1,1,1)


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"state":int(f["state"][q]),"semantic":int(f["semantic"][q])}


def place(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0:raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk)


def simulate(kernel,d1,d2,query,mode,seed):
    n=61;t0=4;t_first=t0+12;t_second=t_first+8
    j1=(19,17,23);p1=add(j1,M1,t_first-t0,n);p2=add(p1,R1,t_second-t_first,n);j2=add(p2,M2,-(t_second-t0),n)
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);rng=np.random.default_rng(seed)
    states=[int(x) for x in rng.integers(1,2**32,size=8,dtype=np.uint64)];clocks=[int(rng.bit_generator.random_raw()) for _ in range(8)]
    pair1=mode not in {"untrained","second_only"};pair2=mode not in {"untrained","first_only"}
    y1=5+d1+(1 if mode=="first_label_shuffled" else 0);y2=11+d2+(-1 if mode=="second_label_shuffled" else 0)
    if pair1:
        tt=t0+1 if mode=="first_history_shuffled" else t0
        place(raw,clock,j1,t0,C,B-5,states[0],clocks[0],n);place(raw,clock,j1,tt,T1,y1,states[1],clocks[1],n)
    if pair2:
        tt=t0+1 if mode=="second_history_shuffled" else t0
        place(raw,clock,j2,t0,C,B-11,states[2],clocks[2],n);place(raw,clock,j2,tt,T2,y2,states[3],clocks[3],n)
    world=NativeWorld(kernel,raw,clock,threads=1);query_path=4;query_port=add(p1,C,-query_path,n);port_empty=None;record1=None;record2=None;ablated=None
    for tick in range(t_second+1):
        if tick==t0+3 and mode in {"first_ablation","second_ablation"}:
            j,m=(j1,M1) if mode=="first_ablation" else (j2,M2);q=add(j,m,3,n);ablated=int(world.raw[q])!=0
            world.raw_a[q]=np.uint64(0);world.raw_b[q]=np.uint64(0);world.clock_a[q]=np.uint64(0);world.clock_b[q]=np.uint64(0)
        if tick==t_first-query_path:
            port_empty=int(world.raw[query_port])==0
            if not port_empty:raise RuntimeError("occupied query port")
            value=pack(states[4],query,C,1);world.raw_a[query_port]=value;world.raw_b[query_port]=value;world.clock_a[query_port]=np.uint64(clocks[4]);world.clock_b[query_port]=np.uint64(clocks[4])
        if tick==t_first:record1=decode(world.raw,p1)
        if tick==t_second:record2=decode(world.raw,p2)
        if tick<t_second:world.tick()
    decoded=None if record2 is None else record2["sreg"]-2*B;expected=query+d1+d2
    exact=record2 is not None and record2["d"]==list(R2) and decoded==expected
    return {"d1":d1,"d2":d2,"query":query,"mode":mode,"junction1":list(j1),"junction2":list(j2),"first_collision":list(p1),"second_collision":list(p2),"port_empty":port_empty,"ablation_present":ablated,"record1":record1,"record2":record2,"decoded":decoded,"expected":expected,"composition_exact":exact}


def main():
    kernel,environment=verify_and_load_kernel(1);pairs=((-2,3),(1,4),(5,-3));queries=(0,2,9,17);modes=("both_trained","first_only","second_only","untrained","first_label_shuffled","second_label_shuffled","first_history_shuffled","second_history_shuffled","first_ablation","second_ablation")
    cases=[];i=0
    for d1,d2 in pairs:
        for q in queries:
            for mode in modes:cases.append(simulate(kernel,d1,d2,q,mode,650000+i));i+=1
    trained=[c for c in cases if c["mode"]=="both_trained"];controls=[c for c in cases if c["mode"]!="both_trained"]
    summary={"learned_rule_pairs":len(pairs),"unseen_queries_per_pair":len(queries),"trained_compositions_exact":sum(c["composition_exact"] for c in trained),"trained_total":len(trained),"control_compositions_false":sum(not c["composition_exact"] for c in controls),"control_total":len(controls),"all_ports_empty":all(c["port_empty"] for c in cases),"all_ablation_targets_present":all(c["ablation_present"] for c in cases if c["mode"] in {"first_ablation","second_ablation"})}
    result={"schema":"dee.v27.core06.c6d07.v1","experiment_id":"C6D07_COMPOSITIONAL_TRANSLATION_LEARNING","role":"DISCOVERY_EVIDENCE_ONLY","question":"Can two independently learned delta memories be applied sequentially to an unseen n without an answer-bearing encoder?","law_candidate":"two ordinary example collisions write B+d1 and B+d2; a query sequentially intersects both, producing 2B+n+d1+d2; frozen decoder subtracts 2B","epistemic_ceiling":"composition of the confirmed translation family only; not multiplication or general program induction","kernel_environment":environment,"summary":summary,"cases":cases};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(summary,indent=2,sort_keys=True));return 0


if __name__=="__main__":raise SystemExit(main())
