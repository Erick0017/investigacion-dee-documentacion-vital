#!/usr/bin/env python3
"""C6D08: DEE-native ruler/clock, moving detectors, and raw-radius witness."""
from __future__ import annotations

import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1];OUT=WORK/"RESULTS"/"C6D08_internal_kinematics_discovery.json"


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def signsum(a,b):return tuple(int(np.sign(a[i]+b[i])) for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"raw":int(raw[q]),"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}


def place(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0:raise RuntimeError(f"initial overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk);return q


def source_clock(kernel,initial_clock):
    n=31;source=(15,15,15);d=(1,0,0);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);raw[source]=pack(0,17,d,4);clock[source]=np.uint64(initial_clock);world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(13):
        f=fields(world.raw);normal=[]
        for q0 in np.argwhere((world.raw!=0)&(f["semantic"]==1)):
            q=tuple(int(x) for x in q0);normal.append({"q":list(q),"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")]})
        trace.append({"tick":tick,"source":decode(world.raw,source),"mouth":decode(world.raw,add(source,d,1,n)),"normal":normal})
        if tick<12:world.tick()
    mouth_ticks=[r["tick"] for r in trace if r["mouth"] is not None and r["mouth"]["semantic"]==1]
    intervals=[b-a for a,b in zip(mouth_ticks,mouth_ticks[1:])]
    return {"initial_clock":initial_clock,"trace":trace,"mouth_ticks":mouth_ticks,"intervals":intervals}


def detector_channel(kernel,n,hub,L,T,target_d,probe_d,target_present=True):
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
    probe_start=place(raw,clock,hub,T,probe_d,23,103,1003,n)
    target_start=None
    if target_present:target_start=place(raw,clock,hub,L,target_d,17,101,1001,n)
    out_d=signsum(target_d,probe_d);out_s=40;records=[];world=NativeWorld(kernel,raw,clock,threads=1)
    for tick in range(max(L,T)+2):
        r=decode(world.raw,hub)
        if r is not None:records.append({"tick":tick,"record":r})
        if tick<max(L,T)+1:world.tick()
    merged=[r for r in records if r["record"]["d"]==list(out_d) and r["record"]["sreg"]==out_s]
    return {"L":L,"clock_label_T":T,"hub":list(hub),"target_d":list(target_d),"probe_d":list(probe_d),"target_start":None if target_start is None else list(target_start),"probe_start":list(probe_start),"records":records,"merged":merged,"sync_record":len(merged)==1 and merged[0]["tick"]==L==T}


def speed_scale(kernel,target_d,probe_d,L,case_index):
    n=47;hub=(20+(case_index%3),21+(case_index%5),22+(case_index%7));labels=list(range(L-2,L+3));channels=[detector_channel(kernel,n,hub,L,T,target_d,probe_d,True) for T in labels];active=[c["clock_label_T"] for c in channels if c["sync_record"]];absent=detector_channel(kernel,n,hub,L,L,target_d,probe_d,False)
    support=sum(abs(x) for x in target_d);measurement=active[0] if len(active)==1 else None
    return {"target_d":list(target_d),"probe_d":list(probe_d),"ruler_graph_edges":L,"clock_channel_labels":labels,"active_channels":active,"measured_clock_edges":measurement,"v_graph":None if measurement is None else L/measurement,"euclidean_displacement":L*math.sqrt(support),"v_euclidean_per_reference_edge":None if measurement is None else L*math.sqrt(support)/measurement,"target_absent_no_merge":not absent["sync_record"],"channels":channels,"absent":absent}


def moving_observer(kernel,name,u,w,T,colliding=True):
    n=61;event=(30,25,25);clock_hub=(30,44,44);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
    if colliding:
        target_start=place(raw,clock,event,T,u,101,501,5001,n);observer_start=place(raw,clock,event,T,w,199,503,5003,n)
    else:
        target_start=add(event,u,-T,n);observer_start=add(target_start,(0,3,0),1,n);raw[target_start]=pack(501,101,u,1);clock[target_start]=np.uint64(5001);raw[observer_start]=pack(503,199,w,1);clock[observer_start]=np.uint64(5003)
    cp=(0,1,0);cq=(0,0,1);place(raw,clock,clock_hub,T,cp,401,505,5005,n);place(raw,clock,clock_hub,T,cq,799,507,5007,n)
    world=NativeWorld(kernel,raw,clock,threads=1);event_record=None;clock_record=None
    for tick in range(T+2):
        if tick==T:event_record=decode(world.raw,event);clock_record=decode(world.raw,clock_hub)
        if tick<T+1:world.tick()
    if colliding:
        delta=np.array(target_start,dtype=int)-np.array(observer_start,dtype=int);distance=int(np.max(np.abs(delta)));expected_d=list(signsum(u,w));event_exact=event_record is not None and event_record["d"]==expected_d and event_record["sreg"]==300
    else:
        delta=np.array(target_start,dtype=int)-np.array(observer_start,dtype=int);distance=int(np.max(np.abs(delta)));expected_d=None
        # The target itself crosses `event`; the no-catch control asks whether the
        # merged target+observer signature (s_reg=300) is absent, not whether the
        # site is blank.
        event_exact=not (event_record is not None and event_record["sreg"]==300)
    clock_exact=clock_record is not None and clock_record["d"]==[0,1,1] and clock_record["sreg"]==1200
    return {"name":name,"target_d":list(u),"observer_d":list(w),"target_start":list(target_start),"observer_start":list(observer_start),"native_clock_interval_edges":T,"initial_graph_separation":distance,"closing_speed_graph":0.0 if not colliding else distance/T,"collision_expected":colliding,"event_record":event_record,"event_exact":event_exact,"clock_record":clock_record,"clock_exact":clock_exact}


def radius_three_witness(kernel):
    n=11;x=np.array([5,5,5]);z=x-1;y=x+1;q=x-2;base=np.zeros((n,n,n),dtype=np.uint64);clock=np.ones_like(base);base[tuple(x)]=pack(1,19665,(0,0,0),1)
    moore=[o for o in itertools.product((-1,0,1),repeat=3) if o!=(0,0,0)]
    for off in moore:
        at=tuple((x+off)%n)
        if at not in (tuple(z),tuple(y)):base[at]=pack(0,1,(0,0,0),0)
    for off in ((1,-1,-1),(-1,1,-1),(-1,-1,1),(1,1,-1),(1,-1,1),(-1,1,1)):base[tuple((x+off)%n)]=pack(1,1,(0,0,0),4)
    for off in ((-1,0,0),(0,-1,0),(0,0,-1),(-1,-1,0),(-1,0,-1),(0,-1,-1)):base[tuple((z+off)%n)]=pack(1,0,(0,0,0),4)
    a=base.copy();b=base.copy();b[tuple(q)]=pack(1,0,(0,0,0),4);wa=NativeWorld(kernel,a,clock,threads=1);wb=NativeWorld(kernel,b,clock,threads=1);wa.tick();wb.tick();diff=[list(map(int,c)) for c in np.argwhere(wa.raw!=wb.raw)]
    return {"q":list(map(int,q)),"y":list(map(int,y)),"chebyshev_q_to_y":int(np.max(np.abs(q-y))),"input_difference_only_q":int(np.count_nonzero(a!=b))==1,"output_y_A":decode(wa.raw,tuple(y)),"output_y_B":decode(wb.raw,tuple(y)),"output_y_differs":int(wa.raw[tuple(y)])!=int(wb.raw[tuple(y)]),"all_output_difference_coords":diff,"witness_attains_radius_three":int(wa.raw[tuple(y)])!=int(wb.raw[tuple(y)])}


def main():
    kernel,environment=verify_and_load_kernel(1)
    clocks=[source_clock(kernel,c) for c in (0,1,2,3,987654321)]
    frames=[((1,0,0),(0,1,0)),((1,1,0),(0,0,1)),((1,1,1),(-1,0,0))]
    scales=[];idx=0
    for td,pd in frames:
        for L in (5,8,13):scales.append(speed_scale(kernel,td,pd,L,idx));idx+=1
    moving=[]
    for T in (4,7,10):
        moving.extend([
            moving_observer(kernel,"head_on_axis",(1,0,0),(-1,0,0),T),
            moving_observer(kernel,"transverse_axis",(1,0,0),(0,1,0),T),
            moving_observer(kernel,"axis_vs_body",(1,0,0),(-1,1,1),T),
            moving_observer(kernel,"same_direction_no_catch",(1,0,0),(1,0,0),T,False),
        ])
    radius3=radius_three_witness(kernel)
    summary={
        "source_clock_mouth_ticks_by_phase":{str(c["initial_clock"]):c["mouth_ticks"] for c in clocks},
        "graph_speed_exact":sum(s["v_graph"]==1.0 for s in scales),"graph_speed_cases":len(scales),
        "euclidean_speed_classes":sorted(set(round(s["v_euclidean_per_reference_edge"],12) for s in scales)),
        "speed_absent_controls":sum(s["target_absent_no_merge"] for s in scales),
        "moving_apparatus_cases_correct":sum(r["event_exact"] for r in moving),"moving_cases":len(moving),
        "moving_collision_events_exact":sum(r["event_exact"] for r in moving if r["collision_expected"]),
        "same_direction_no_catch_controls":sum(r["event_exact"] for r in moving if not r["collision_expected"]),
        "native_clock_events_exact":sum(r["clock_exact"] for r in moving),
        "moving_closing_speed_classes":sorted(set(r["closing_speed_graph"] for r in moving)),
        "raw_radius_three_witness":radius3["witness_attains_radius_three"],
    }
    result={"schema":"dee.v27.core06.c6d08.v1","experiment_id":"C6D08_INTERNAL_KINEMATICS_DISCOVERY","role":"DISCOVERY_AND_INHERITED_WITNESS","question":"What speed is measured by DEE detector relations, and does a moving detector see an observer-independent speed?","definitions":{"RULER_DEE":"shortest directed Moore-hop count along a prepared destination route","CLOCK_DEE":"path-length calibrated reference-carrier coincidence scale; semantic-4 source cadence is separately characterized","v_observed":"RULER_DEE graph edges divided by the active reference-clock channel","moving_observer":"a normal carrier whose collision with the target creates a consumptive internal record"},"epistemic_note":"The graph ruler and carrier clock share the same update dynamics, so v_graph=1 is an exact internal calibration, not an external dimensional prediction. Euclidean embedding and moving-probe encounter rates remain separate.","kernel_environment":environment,"summary":summary,"source_clocks":clocks,"speed_scales":scales,"moving_observers":moving,"raw_radius_three":radius3};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(summary,indent=2,sort_keys=True));return 0


if __name__=="__main__":raise SystemExit(main())
