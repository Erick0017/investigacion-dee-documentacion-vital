#!/usr/bin/env python3
"""C6D09: finite collective packet/source-train propagation search."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1];OUT=WORK/"RESULTS"/"C6D09_collective_propagation_search.json"


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"state":int(f["state"][q]),"semantic":int(f["semantic"][q])}


PATTERNS={
    "line":[(0,j,0) for j in range(-3,4)],
    "checker_plane":[(0,y,z) for y in range(-3,4) for z in range(-3,4) if (y+z)%2==0],
    "sparse_cluster":[(-2,-1,0),(-1,2,1),(0,0,0),(1,-2,2),(2,1,-1),(3,0,2),(-3,1,-2)],
}


def packet(kernel,pattern_name,d,sreg_base):
    n=41;center=(20,20,20);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);offsets=PATTERNS[pattern_name]
    for i,off in enumerate(offsets):
        q=tuple(center[j]+off[j] for j in range(3));raw[q]=pack(1,min(sreg_base+i,19664),d,1);clock[q]=np.uint64(1000+i)
    initial=raw.copy();initial_mag=np.abs(np.fft.fftn(initial!=0));world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(9):
        expected=np.roll(initial,shift=tuple(tick*x for x in d),axis=(0,1,2));support_exact=np.array_equal(world.raw!=0,expected!=0);raw_exact=np.array_equal(world.raw,expected);trace.append({"tick":tick,"support_exact_translation":support_exact,"raw_exact_translation":raw_exact,"count":int(np.count_nonzero(world.raw))})
        if tick<8:world.tick()
    final_mag=np.abs(np.fft.fftn(world.raw!=0));mag_error=float(np.max(np.abs(final_mag-initial_mag)))
    return {"pattern":pattern_name,"direction":list(d),"members":len(offsets),"sreg_base":sreg_base,"trace":trace,"all_support_exact":all(r["support_exact_translation"] for r in trace),"all_raw_exact":all(r["raw_exact_translation"] for r in trace),"fourier_magnitude_max_error":mag_error,"graph_front_speed":1.0,"euclidean_front_speed":float(np.sqrt(sum(abs(x) for x in d)))}


def source_train(kernel,d,sreg):
    n=43;source=(21,21,21);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);raw[source]=pack(0,sreg,d,4);clock[source]=np.uint64(987654321);world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(15):
        occupied=[]
        for k in range(1,tick+2):
            r=decode(world.raw,add(source,d,k,n))
            if r is not None and r["semantic"]==1:occupied.append(k)
        trace.append({"tick":tick,"normal_distances":occupied,"mouth":1 in occupied,"front":max(occupied) if occupied else None})
        if tick<14:world.tick()
    exact=all((r["front"]==r["tick"] if r["tick"]>0 else r["front"] is None) for r in trace) and [r["tick"] for r in trace if r["mouth"]]==[1,3,5,7,9,11,13]
    return {"direction":list(d),"sreg":sreg,"trace":trace,"period_two_nondispersive_train":exact,"front_speed_graph":1.0}


def collision_sheet(kernel):
    n=37;t=5;hubs=[(18,18,8+4*i) for i in range(5)];u=(1,0,0);v=(0,1,0)
    def make(which):
        raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
        for i,h in enumerate(hubs):
            if which in {"both","u"}:
                q=add(h,u,-t,n);raw[q]=pack(1,100+i,u,1);clock[q]=np.uint64(1000+i)
            if which in {"both","v"}:
                q=add(h,v,-t,n);raw[q]=pack(1,200+i,v,1);clock[q]=np.uint64(2000+i)
        w=NativeWorld(kernel,raw,clock,threads=1)
        for _ in range(t):w.tick()
        return w.raw.copy()
    both=make("both");only_u=make("u");only_v=make("v");records=[decode(both,h) for h in hubs];exact=all(r is not None and r["d"]==[1,1,0] and r["sreg"]==300+2*i for i,r in enumerate(records));return {"hubs":[list(h) for h in hubs],"merged_records":records,"merged_exact":exact,"combined_support":int(np.count_nonzero(both)),"sum_separate_supports":int(np.count_nonzero(only_u))+int(np.count_nonzero(only_v)),"many_to_one_contraction":int(np.count_nonzero(both))<int(np.count_nonzero(only_u))+int(np.count_nonzero(only_v)),"interpretation":"collision breaks dilute packet superposition by destination-fiber reduction; this is merging, not an interference fringe"}


def main():
    kernel,environment=verify_and_load_kernel(1);directions=((1,0,0),(1,-1,0),(-1,1,1));packets=[packet(kernel,p,d,1 if i%2==0 else 12000) for i,d in enumerate(directions) for p in PATTERNS];trains=[source_train(kernel,d,s) for d,s in zip(directions,(1,137,19000),strict=True)];collision=collision_sheet(kernel)
    summary={"rigid_packet_cases":len(packets),"rigid_packet_support_exact":sum(p["all_support_exact"] for p in packets),"rigid_packet_raw_exact":sum(p["all_raw_exact"] for p in packets),"fourier_magnitude_invariant":sum(p["fourier_magnitude_max_error"]<1e-9 for p in packets),"source_train_cases":len(trains),"period_two_source_trains":sum(t["period_two_nondispersive_train"] for t in trains),"collision_sheet_exact":collision["merged_exact"],"collision_many_to_one":collision["many_to_one_contraction"]}
    result={"schema":"dee.v27.core06.c6d09.v1","experiment_id":"C6D09_COLLECTIVE_PROPAGATION_SEARCH","role":"DISCOVERY_PLUS_EXACT_SECTOR_CROSSCHECK","question":"Does a finite collective family support propagation beyond the singleton carrier law?","candidate_equations":{"collision_free_packet":"rho_t(q)=rho_0(q-t*d); Fourier magnitude is invariant and phase advances linearly","source_train":"period-two emission plus the same shift operator; front speed one graph edge/update","collision":"destination-fiber reduction contracts two incoming sheets to one merged sheet and breaks dilute superposition"},"adjudication":"Rigid packets and source trains are exact collective/product modes, but introduce no new group speed, isotropy, observer invariance or dispersive law beyond carrier shift plus source cadence. Collisions are nonlinear many-to-one mergers, not wave interference.","kernel_environment":environment,"summary":summary,"packets":packets,"source_trains":trains,"collision_sheet":collision};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps(summary,indent=2,sort_keys=True));return 0


if __name__=="__main__":raise SystemExit(main())
