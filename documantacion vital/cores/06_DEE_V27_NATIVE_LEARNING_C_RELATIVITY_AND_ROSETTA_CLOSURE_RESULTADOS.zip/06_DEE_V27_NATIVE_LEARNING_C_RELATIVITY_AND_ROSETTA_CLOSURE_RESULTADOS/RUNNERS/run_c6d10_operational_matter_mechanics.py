#!/usr/bin/env python3
"""C6D10: minimal operational mechanics of persistent/interacting DEE organizations."""
from __future__ import annotations

import itertools
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D10_operational_matter_mechanics.json"
DIRECTIONS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {
        "raw": int(raw[q]),
        "state": int(f["state"][q]),
        "sreg": int(f["sreg"][q]),
        "d": [int(f[key][q]) for key in ("dx", "dy", "dz")],
        "semantic": int(f["semantic"][q]),
    }


def sign_sum(u, v):
    return tuple(0 if u[i] + v[i] == 0 else (1 if u[i] + v[i] > 0 else -1) for i in range(3))


def free_persistence(kernel):
    n = 23
    start = (11, 11, 11)
    horizon = 2 * n + 3
    specs = [
        ((1, 0, 0), 1, 1, 1001),
        ((1, 1, 0), 137, 7, 2002),
        ((-1, 1, 1), 19664, 1, 3003),
    ]
    cases = []
    for d, sreg, state, clock_token in specs:
        raw = np.zeros((n, n, n), dtype=np.uint64)
        clock = np.zeros_like(raw)
        token = pack(state, sreg, d, 1)
        raw[start] = token
        clock[start] = np.uint64(clock_token)
        world = NativeWorld(kernel, raw, clock, threads=1)
        exact = True
        count_exact = True
        spatial_returns = []
        for tick in range(horizon + 1):
            expected = add(start, d, tick, n)
            exact = exact and int(world.raw[expected]) == int(token)
            count_exact = count_exact and int(np.count_nonzero(world.raw)) == 1
            if tick and expected == start:
                spatial_returns.append(tick)
            if tick < horizon:
                world.tick()
        cases.append({
            "direction": list(d),
            "sreg": sreg,
            "state": state,
            "horizon": horizon,
            "raw_identity_exact": exact,
            "single_organization_exact": count_exact,
            "spatial_returns": spatial_returns,
            "graph_speed": 1,
        })
    return {
        "cases": cases,
        "exact_cases": sum(c["raw_identity_exact"] and c["single_organization_exact"] for c in cases),
        "interpretation": "normal carriers retain their raw operational identity under free toroidal transport; spatial return is recurrence of position, not creation of a new object",
    }


def collision_reducer(kernel):
    pairs = [(u, v) for u in DIRECTIONS for v in DIRECTIONS if u != v]
    grid = list(itertools.product(range(3, 44, 5), repeat=3))
    assert len(grid) >= len(pairs)
    n = 47
    sreg_pairs = [(1, 2), (137, 4096), (10000, 9000), (19664, 19664)]
    panels = []
    all_rows = []
    for panel_index, (sa, sb) in enumerate(sreg_pairs):
        raw = np.zeros((n, n, n), dtype=np.uint64)
        clock = np.zeros_like(raw)
        active = []
        for index, ((u, v), hub) in enumerate(zip(pairs, grid, strict=False)):
            qa = add(hub, u, -1, n)
            qb = add(hub, v, -1, n)
            assert qa != qb and int(raw[qa]) == 0 and int(raw[qb]) == 0
            raw[qa] = pack(1, sa, u, 1)
            raw[qb] = pack(1, sb, v, 1)
            clock[qa] = np.uint64(100000 * panel_index + index + 1)
            clock[qb] = np.uint64(900000 + 100000 * panel_index + index + 1)
            active.append((u, v, hub, int(clock[qa]), int(clock[qb])))
        before_count = int(np.count_nonzero(raw))
        before_sreg = before_count // 2 * (sa + sb)
        world = NativeWorld(kernel, raw, clock, threads=1)
        world.tick()
        output_clock_categories = Counter()
        rows = []
        for u, v, hub, ca, cb in active:
            record = decode(world.raw, hub)
            out_clock = int(world.clock[hub])
            output_clock_categories["input_a" if out_clock == ca else "input_b" if out_clock == cb else "other"] += 1
            expected_d = sign_sum(u, v)
            expected_sreg = min(sa + sb, 19664)
            exact = record is not None and record["d"] == list(expected_d) and record["sreg"] == expected_sreg and record["semantic"] == 1
            row = {
                "u": list(u), "v": list(v), "hub": list(hub),
                "expected_d": list(expected_d), "expected_sreg": expected_sreg,
                "record": record, "exact": exact, "output_clock": out_clock,
            }
            rows.append(row)
            all_rows.append({"sa": sa, "sb": sb, **row})
        after_count = int(np.count_nonzero(world.raw))
        output_sreg_total = sum((r["record"] or {}).get("sreg", 0) for r in rows)
        panels.append({
            "input_sreg": [sa, sb],
            "collisions": len(rows),
            "exact_reducer_outputs": sum(r["exact"] for r in rows),
            "before_count": before_count,
            "after_count": after_count,
            "count_contraction_exact": after_count == len(rows),
            "input_sreg_total": before_sreg,
            "output_sreg_total": output_sreg_total,
            "sreg_additive": output_sreg_total == before_sreg,
            "sreg_loss_from_cap": before_sreg - output_sreg_total,
            "output_clock_categories": dict(output_clock_categories),
        })

    probe = (1, 0, 0)
    probe_rows = [r for r in all_rows if r["sa"] == 137 and r["sb"] == 4096 and tuple(r["u"]) == probe]
    signatures = Counter((tuple(r["record"]["d"]), r["record"]["sreg"]) for r in probe_rows if r["record"] is not None)
    total = sum(signatures.values())
    entropy = -sum((count / total) * math.log2(count / total) for count in signatures.values())
    return {
        "valid_ordered_direction_pairs": len(pairs),
        "panels": panels,
        "all_exact": all(p["exact_reducer_outputs"] == p["collisions"] for p in panels),
        "direction_law": "d_out = sign(u+v) componentwise for distinct incoming directions sharing a blank destination",
        "register_law": "s_reg_out = min(s_reg_u+s_reg_v,19664)",
        "cardinality_law": "two proposals to one blank destination resolve to one output",
        "fixed_probe_measurement": {
            "probe_direction": list(probe),
            "target_directions": len(probe_rows),
            "distinct_output_signatures": len(signatures),
            "output_entropy_bits_uniform_targets": entropy,
            "input_entropy_bits_uniform_targets": math.log2(len(probe_rows)),
            "largest_equivalence_class": max(signatures.values()),
            "interpretation": "the consumptive collision detector is informative but coarse: multiple target directions occupy the same response fiber",
        },
    }


def interface_seed(n, center, kind, with_probe, d, distance, sreg):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    if kind == "state1_block":
        for offset in itertools.product((0, 1), repeat=3):
            q = tuple((center[i] + offset[i]) % n for i in range(3))
            raw[q] = pack(1, 700 + sum(offset), (0, 0, 0), 1)
    elif kind == "semantic4_point":
        raw[center] = pack(0, 37, (0, 0, 0), 4)
    elif kind == "state0_point":
        raw[center] = pack(0, 37, (0, 0, 0), 1)
    elif kind != "empty":
        raise ValueError(kind)
    if with_probe:
        raw[add(center, d, -distance, n)] = pack(7, sreg, d, 1)
    return raw


def simulate(kernel, raw, ticks):
    world = NativeWorld(kernel, raw, threads=1)
    out = []
    for tick in range(ticks + 1):
        out.append(world.raw.copy())
        if tick < ticks:
            world.tick()
    return out


def interfaces(kernel):
    n = 29
    center = (14, 14, 14)
    distance = 5
    ticks = 9
    directions = [(1, 0, 0), (1, 1, 0), (-1, 1, 1), (0, -1, 1)]
    kinds = ("empty", "state0_point", "state1_block", "semantic4_point")
    cases = []
    for d in directions:
        for kind in kinds:
            sreg = 4321
            probe = simulate(kernel, interface_seed(n, center, kind, True, d, distance, sreg), ticks)
            baseline = simulate(kernel, interface_seed(n, center, kind, False, d, distance, sreg), ticks)
            trace = []
            for tick, (a, b) in enumerate(zip(probe, baseline, strict=True)):
                expected = add(center, d, tick - distance, n)
                record = decode(a, expected)
                f = fields(a)
                reverse = tuple(-x for x in d)
                reflected = int(np.count_nonzero((f["semantic"] == 1) & (f["dx"] == reverse[0]) & (f["dy"] == reverse[1]) & (f["dz"] == reverse[2])))
                trace.append({
                    "tick": tick,
                    "expected": list(expected),
                    "record": record,
                    "hamming_from_baseline": int(np.count_nonzero(a != b)),
                    "reverse_records": reflected,
                })
            transmitted = all(
                trace[t]["record"] is not None and trace[t]["record"]["d"] == list(d) and trace[t]["record"]["sreg"] == sreg
                for t in range(distance + 1, ticks + 1)
            )
            absorbed = all(trace[t]["hamming_from_baseline"] == 0 for t in range(distance + 1, ticks + 1))
            reflected = any(trace[t]["reverse_records"] > 0 for t in range(distance, ticks + 1))
            cases.append({"direction": list(d), "medium": kind, "transmitted": transmitted, "absorbed_to_baseline": absorbed, "reflected": reflected, "trace": trace})
    summary = {}
    for kind in kinds:
        group = [c for c in cases if c["medium"] == kind]
        summary[kind] = {
            "cases": len(group),
            "transmitted": sum(c["transmitted"] for c in group),
            "absorbed_to_baseline": sum(c["absorbed_to_baseline"] for c in group),
            "reflected": sum(c["reflected"] for c in group),
        }
    return {"cases": cases, "summary": summary, "note": "new diagonal/translated operational controls; the state-0 point is evanescent, whereas the state-1 block and semantic-4 point test persistent occupied sectors"}


def persistent_source(kernel):
    n = 23
    source = (11, 11, 11)
    cases = []
    for d, sreg in [((1, 0, 0), 1), ((1, 1, 0), 137), ((-1, 1, 1), 19000)]:
        raw = np.zeros((n, n, n), dtype=np.uint64)
        clock = np.zeros_like(raw)
        token = pack(0, sreg, d, 4)
        raw[source] = token
        clock[source] = np.uint64(987654321)
        world = NativeWorld(kernel, raw, clock, threads=1)
        horizon = 2 * n + 3
        source_exact = True
        emission_ticks = []
        for tick in range(horizon + 1):
            source_exact = source_exact and int(world.raw[source]) == int(token)
            mouth = decode(world.raw, add(source, d, 1, n))
            if mouth is not None and mouth["semantic"] == 1 and mouth["d"] == list(d):
                emission_ticks.append(tick)
            if tick < horizon:
                world.tick()
        cases.append({"direction": list(d), "sreg": sreg, "horizon": horizon, "source_raw_identity_exact": source_exact, "mouth_emission_ticks": emission_ticks, "period_two_initial_segment": emission_ticks[:8] == [1, 3, 5, 7, 9, 11, 13, 15]})
    return {"cases": cases, "source_identity_exact": sum(c["source_raw_identity_exact"] for c in cases), "period_two_cases": sum(c["period_two_initial_segment"] for c in cases)}


def main():
    kernel, environment = verify_and_load_kernel(1)
    persistence = free_persistence(kernel)
    collisions = collision_reducer(kernel)
    interface = interfaces(kernel)
    sources = persistent_source(kernel)
    summary = {
        "free_identity_exact": f'{persistence["exact_cases"]}/{len(persistence["cases"])}',
        "collision_panels_exact": f'{sum(p["exact_reducer_outputs"] == p["collisions"] for p in collisions["panels"])}/{len(collisions["panels"])}',
        "collision_instances_exact": f'{sum(p["exact_reducer_outputs"] for p in collisions["panels"])}/{sum(p["collisions"] for p in collisions["panels"])}',
        "interfaces": interface["summary"],
        "source_identity_exact": f'{sources["source_identity_exact"]}/{len(sources["cases"])}',
        "source_period_two": f'{sources["period_two_cases"]}/{len(sources["cases"])}',
    }
    result = {
        "schema": "dee.v27.core06.c6d10.v1",
        "experiment_id": "C6D10_OPERATIONAL_MATTER_MECHANICS",
        "role": "DIRECT_KERNEL_DISCOVERY_AND_EXACT_SECTOR_SYNTHESIS",
        "question": "What minimal operational mechanics is shared by persistent, interacting and detectable DEE organizations?",
        "operational_definition": "an organization that retains enough identity to be tracked, interacts through destination fibers, and produces reproducible detector responses",
        "kernel_environment": environment,
        "free_persistence": persistence,
        "blank_destination_collisions": collisions,
        "interfaces": interface,
        "persistent_sources": sources,
        "summary": summary,
        "adjudication": {
            "shared": "normal carriers, learned memories and dilute packets share exact directed transport; carriers also participate in a deterministic destination-fiber reducer that acts as interaction and consumptive measurement",
            "sector_specific": "semantic-4 sources are persistent productive organizations; stable occupied interfaces can occlude; normal carriers do not reproduce and blank collisions contract cardinality",
            "mechanics": "persistence, transport, nonlinear composition, coarse detection and sector-dependent occlusion are operational mechanics; no universal inertia, force, elastic scattering, conserved particle count or mass law follows",
            "architecture": "state/information -> directed proposal -> destination fiber/guard -> resolved record -> transported history/organization -> detector response",
        },
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
