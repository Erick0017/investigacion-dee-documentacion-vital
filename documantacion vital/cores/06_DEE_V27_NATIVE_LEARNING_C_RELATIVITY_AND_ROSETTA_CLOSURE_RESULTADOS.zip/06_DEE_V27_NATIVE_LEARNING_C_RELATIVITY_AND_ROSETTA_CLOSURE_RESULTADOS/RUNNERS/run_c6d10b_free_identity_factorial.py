#!/usr/bin/env python3
"""C6D10b: minimal factorial isolating the one failed free-identity cell from C6D10."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D10b_free_identity_factorial.json"


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"raw": int(raw[q]), "state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[k][q]) for k in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def main():
    kernel, environment = verify_and_load_kernel(1)
    n = 17
    start = (8, 8, 8)
    horizon = 20
    states = (0, 1, 2, 3, 7, 2147483647, 4294967295)
    sregs = (1, 137, 19664)
    directions = ((1, 0, 0), (1, 1, 0), (-1, 1, 1))
    cases = []
    for state in states:
        for sreg in sregs:
            for d in directions:
                raw = np.zeros((n, n, n), dtype=np.uint64)
                token = pack(state, sreg, d, 1)
                raw[start] = token
                world = NativeWorld(kernel, raw, threads=1)
                trace = []
                for tick in range(horizon + 1):
                    q = add(start, d, tick, n)
                    trace.append({"tick": tick, "count": int(np.count_nonzero(world.raw)), "record": decode(world.raw, q)})
                    if tick < horizon:
                        world.tick()
                raws = [(r["record"] or {}).get("raw") for r in trace]
                normalized = [None if r["record"] is None else (r["record"]["sreg"], tuple(r["record"]["d"]), r["record"]["semantic"]) for r in trace]
                first_change = next((r["tick"] for r in trace if (r["record"] or {}).get("raw") != int(token)), None)
                cases.append({
                    "initial_state": state, "sreg": sreg, "direction": list(d),
                    "raw_identity_all_ticks": all(x == int(token) for x in raws),
                    "normalized_transport_identity_all_ticks": all(x == normalized[0] for x in normalized),
                    "count_one_all_ticks": all(r["count"] == 1 for r in trace),
                    "first_raw_change_tick": first_change,
                    "state_sequence": [None if r["record"] is None else r["record"]["state"] for r in trace],
                    "trace": trace,
                })
    by_state = {}
    for state in states:
        group = [c for c in cases if c["initial_state"] == state]
        by_state[str(state)] = {
            "cases": len(group),
            "raw_identity": sum(c["raw_identity_all_ticks"] for c in group),
            "normalized_transport_identity": sum(c["normalized_transport_identity_all_ticks"] for c in group),
            "count_one": sum(c["count_one_all_ticks"] for c in group),
            "distinct_state_sequences": sorted({tuple(c["state_sequence"]) for c in group}),
        }
    result = {
        "schema": "dee.v27.core06.c6d10b.v1",
        "experiment_id": "C6D10B_FREE_IDENTITY_FACTORIAL",
        "role": "TARGETED_UNEXPECTED_RESULT_ABLATION",
        "question": "Was the C6D10 free raw-identity failure caused by state, s_reg or direction?",
        "kernel_environment": environment,
        "factorial": {"states": list(states), "sregs": list(sregs), "directions": [list(d) for d in directions], "horizon": horizon},
        "summary_by_initial_state": by_state,
        "cases": cases,
        "adjudication": "raw identity and normalized transport identity are reported separately; a state normalization does not imply loss of the transported organization when support, direction, semantic and s_reg remain exact",
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(by_state, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
