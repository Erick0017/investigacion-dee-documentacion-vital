#!/usr/bin/env python3
"""C6D12: matched ensemble probe of balances, contraction and stationarity."""
from __future__ import annotations

import itertools
import json
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D12_matched_ensemble_thermodynamics.json"
DIRECTIONS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]


def entropy(values):
    if not values:
        return 0.0
    counts = Counter(values)
    total = len(values)
    return -sum((count / total) * math.log2(count / total) for count in counts.values())


def macro(raw):
    f = fields(raw)
    mask = raw != 0
    coords = np.argwhere(mask)
    directions = [(int(f["dx"][tuple(q)]), int(f["dy"][tuple(q)]), int(f["dz"][tuple(q)])) for q in coords]
    sregs = [int(f["sreg"][tuple(q)]) for q in coords]
    states = [int(f["state"][tuple(q)]) for q in coords]
    semantics = [int(f["semantic"][tuple(q)]) for q in coords]
    return {
        "support": len(coords),
        "sreg_sum": sum(sregs),
        "sreg_max": max(sregs) if sregs else 0,
        "direction_entropy_bits": entropy(directions),
        "sreg_entropy_bits": entropy(sregs),
        "raw_entropy_bits_occupied": entropy([int(raw[tuple(q)]) for q in coords]),
        "state_one_fraction": (sum(x == 1 for x in states) / len(states)) if states else None,
        "semantic_one_fraction": (sum(x == 1 for x in semantics) / len(semantics)) if semantics else None,
        "direction_zero": sum(d == (0, 0, 0) for d in directions),
    }


def prepared_support(n, count, rng):
    k = n // 3
    grid = list(itertools.product((3 * i for i in range(k)), repeat=3))
    if count > len(grid):
        raise ValueError((n, count, len(grid)))
    indices = rng.choice(len(grid), size=count, replace=False)
    return [grid[int(i)] for i in indices]


def simulate(kernel, n, support, sregs, clocks, directions, ticks):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    for q, sreg, token, d in zip(support, sregs, clocks, directions, strict=True):
        raw[q] = pack(1, sreg, d, 1)
        clock[q] = np.uint64(token)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    tick_info = []
    for tick in range(ticks + 1):
        trace.append({"tick": tick, **macro(world.raw)})
        if tick < ticks:
            tick_info.append(world.tick())
    return trace, tick_info


def summarize_trace(trace):
    initial = trace[0]
    final = trace[-1]
    tail = trace[-min(8, len(trace)):]
    return {
        "initial_support": initial["support"],
        "final_support": final["support"],
        "support_ratio": final["support"] / initial["support"],
        "support_nonincreasing": all(b["support"] <= a["support"] for a, b in zip(trace, trace[1:])),
        "sreg_sum_initial": initial["sreg_sum"],
        "sreg_sum_final": final["sreg_sum"],
        "sreg_sum_exact_all_ticks": all(row["sreg_sum"] == initial["sreg_sum"] for row in trace),
        "tail_support_constant": len({row["support"] for row in tail}) == 1,
        "tail_direction_entropy_range": max(row["direction_entropy_bits"] for row in tail) - min(row["direction_entropy_bits"] for row in tail),
        "final_direction_entropy_bits": final["direction_entropy_bits"],
        "final_sreg_entropy_bits": final["sreg_entropy_bits"],
        "final_sreg_max": final["sreg_max"],
        "final_zero_direction": final["direction_zero"],
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    cases = []
    for n in (16, 22):
        capacity = (n // 3) ** 3
        for fill_fraction in (0.30, 0.75):
            count = int(round(capacity * fill_fraction))
            for replicate in range(4):
                seed = 661200 + 1000 * n + 100 * int(fill_fraction * 100) + replicate
                rng = np.random.default_rng(seed)
                support = prepared_support(n, count, rng)
                sregs = [int(x) for x in rng.integers(1, 8, size=count)]
                clocks = [int(x) for x in rng.integers(0, 2**32, size=count, dtype=np.uint64)]
                mixed = [DIRECTIONS[int(i)] for i in rng.integers(0, len(DIRECTIONS), size=count)]
                aligned = [(1, 0, 0)] * count
                ticks = 2 * n
                for preparation, dirs in (("aligned_separated", aligned), ("mixed_separated", mixed)):
                    trace, tick_info = simulate(kernel, n, support, sregs, clocks, dirs, ticks)
                    cases.append({
                        "n": n, "fill_fraction_of_separated_grid": fill_fraction, "replicate": replicate,
                        "seed": seed, "preparation": preparation, "count": count, "ticks": ticks,
                        "initial_inventory": {"sreg_sum": sum(sregs), "sreg_max": max(sregs), "state": 1, "semantic": 1},
                        "summary": summarize_trace(trace), "trace": trace, "tick_info": tick_info,
                    })
    by_preparation = {}
    for preparation in ("aligned_separated", "mixed_separated"):
        group = [c for c in cases if c["preparation"] == preparation]
        by_preparation[preparation] = {
            "cases": len(group),
            "sreg_exact_cases": sum(c["summary"]["sreg_sum_exact_all_ticks"] for c in group),
            "support_nonincreasing_cases": sum(c["summary"]["support_nonincreasing"] for c in group),
            "tail_support_constant_cases": sum(c["summary"]["tail_support_constant"] for c in group),
            "support_ratio_range": [min(c["summary"]["support_ratio"] for c in group), max(c["summary"]["support_ratio"] for c in group)],
            "mean_support_ratio": sum(c["summary"]["support_ratio"] for c in group) / len(group),
            "final_direction_entropy_range": [min(c["summary"]["final_direction_entropy_bits"] for c in group), max(c["summary"]["final_direction_entropy_bits"] for c in group)],
            "max_tail_direction_entropy_range": max(c["summary"]["tail_direction_entropy_range"] for c in group),
        }
    paired = []
    for n in (16, 22):
        for fraction in (0.30, 0.75):
            for replicate in range(4):
                aligned = next(c for c in cases if c["n"] == n and c["fill_fraction_of_separated_grid"] == fraction and c["replicate"] == replicate and c["preparation"] == "aligned_separated")
                mixed = next(c for c in cases if c["n"] == n and c["fill_fraction_of_separated_grid"] == fraction and c["replicate"] == replicate and c["preparation"] == "mixed_separated")
                paired.append({
                    "n": n, "fill_fraction": fraction, "replicate": replicate,
                    "same_support_sreg_clock_inventory": True,
                    "aligned_final_support": aligned["summary"]["final_support"],
                    "mixed_final_support": mixed["summary"]["final_support"],
                    "mixed_minus_aligned_support": mixed["summary"]["final_support"] - aligned["summary"]["final_support"],
                    "both_sreg_exact": aligned["summary"]["sreg_sum_exact_all_ticks"] and mixed["summary"]["sreg_sum_exact_all_ticks"],
                })
    result = {
        "schema": "dee.v27.core06.c6d12.v1",
        "experiment_id": "C6D12_MATCHED_ENSEMBLE_THERMODYNAMICS",
        "role": "DIRECT_KERNEL_DISCOVERY",
        "question": "Do interacting normal-carrier ensembles expose an extensive balance, relaxation, stationarity or preparation-independent statistical law?",
        "hypotheses": {
            "H_balance":"total s_reg is exactly conserved when all local sums remain below the cap in the tested normal sector",
            "H_relax":"mixed routing contracts support and approaches a preparation-insensitive stationary macrostate",
            "H_control":"same-direction separated gases remain exact translations",
        },
        "design":"matched support, s_reg and clock inventories; only direction organization differs; independent worlds are replicates, not ticks",
        "kernel_environment": environment,
        "summary_by_preparation": by_preparation,
        "paired_cases": paired,
        "cases": cases,
        "adjudication": {
            "balance_candidate":"promote only if every mixed and aligned trajectory conserves total s_reg exactly and no local cap is reached",
            "thermodynamic_gate":"requires cross-preparation stationary distributions/slow variables, not merely deterministic contraction or information loss",
            "pseudoreplication":"ticks are trajectory samples; inferential units are the 16 matched preparation worlds per arm",
        },
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(by_preparation, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
