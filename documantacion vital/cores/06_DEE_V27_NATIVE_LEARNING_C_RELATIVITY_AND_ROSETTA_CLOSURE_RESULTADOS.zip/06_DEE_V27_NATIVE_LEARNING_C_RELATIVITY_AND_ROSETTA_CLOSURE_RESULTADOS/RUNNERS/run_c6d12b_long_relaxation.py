#!/usr/bin/env python3
"""C6D12b: extend only the seven C6D12 mixed worlds not stationary at 2N."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, pack, verify_and_load_kernel
from run_c6d12_matched_ensemble_thermodynamics import DIRECTIONS, macro, prepared_support


WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C6D12b_long_relaxation.json"
PARENT = WORK / "RESULTS" / "C6D12_matched_ensemble_thermodynamics.json"


def main():
    parent = json.loads(PARENT.read_text(encoding="utf-8"))
    selected = [
        c for c in parent["cases"]
        if c["preparation"] == "mixed_separated" and not c["summary"]["tail_support_constant"]
    ]
    if len(selected) != 7:
        raise RuntimeError(f"expected seven nonstationary discovery worlds, observed {len(selected)}")
    kernel, environment = verify_and_load_kernel(1)
    cases = []
    for prior in selected:
        n = prior["n"]
        fill_fraction = prior["fill_fraction_of_separated_grid"]
        replicate = prior["replicate"]
        count = prior["count"]
        seed = prior["seed"]
        rng = np.random.default_rng(seed)
        support = prepared_support(n, count, rng)
        sregs = [int(x) for x in rng.integers(1, 8, size=count)]
        clocks = [int(x) for x in rng.integers(0, 2**32, size=count, dtype=np.uint64)]
        directions = [DIRECTIONS[int(i)] for i in rng.integers(0, len(DIRECTIONS), size=count)]
        raw = np.zeros((n, n, n), dtype=np.uint64)
        clock = np.zeros_like(raw)
        for q, sreg, token, d in zip(support, sregs, clocks, directions, strict=True):
            raw[q] = pack(1, sreg, d, 1)
            clock[q] = np.uint64(token)
        world = NativeWorld(kernel, raw, clock, threads=1)
        horizon = 8 * n
        trace = []
        for tick in range(horizon + 1):
            trace.append({"tick": tick, **macro(world.raw)})
            if tick < horizon:
                world.tick()
        support_changes = [b["tick"] for a, b in zip(trace, trace[1:]) if b["support"] != a["support"]]
        sreg_changes = [b["tick"] for a, b in zip(trace, trace[1:]) if b["sreg_sum"] != a["sreg_sum"]]
        tail = trace[-2 * n:]
        cases.append({
            "n": n, "fill_fraction": fill_fraction, "replicate": replicate, "seed": seed,
            "horizon": horizon, "prior_horizon": 2 * n,
            "initial_support": trace[0]["support"], "support_at_2N": trace[2 * n]["support"], "final_support": trace[-1]["support"],
            "initial_sreg_sum": trace[0]["sreg_sum"], "sreg_at_2N": trace[2 * n]["sreg_sum"], "final_sreg_sum": trace[-1]["sreg_sum"],
            "support_nonincreasing": all(b["support"] <= a["support"] for a, b in zip(trace, trace[1:])),
            "sreg_nonincreasing": all(b["sreg_sum"] <= a["sreg_sum"] for a, b in zip(trace, trace[1:])),
            "last_support_change_tick": max(support_changes) if support_changes else None,
            "last_sreg_change_tick": max(sreg_changes) if sreg_changes else None,
            "tail_2N_support_constant": len({r["support"] for r in tail}) == 1,
            "tail_2N_sreg_constant": len({r["sreg_sum"] for r in tail}) == 1,
            "tail_2N_direction_entropy_range": max(r["direction_entropy_bits"] for r in tail) - min(r["direction_entropy_bits"] for r in tail),
            "trace": trace,
        })
    summary = {
        "extended_cases": len(cases),
        "support_nonincreasing": sum(c["support_nonincreasing"] for c in cases),
        "sreg_nonincreasing": sum(c["sreg_nonincreasing"] for c in cases),
        "tail_2N_support_constant": sum(c["tail_2N_support_constant"] for c in cases),
        "tail_2N_sreg_constant": sum(c["tail_2N_sreg_constant"] for c in cases),
        "continued_support_contraction_after_2N": sum(c["final_support"] < c["support_at_2N"] for c in cases),
        "continued_sreg_loss_after_2N": sum(c["final_sreg_sum"] < c["sreg_at_2N"] for c in cases),
        "last_support_change_range": [min(c["last_support_change_tick"] for c in cases), max(c["last_support_change_tick"] for c in cases)],
    }
    result = {
        "schema": "dee.v27.core06.c6d12b.v1",
        "experiment_id": "C6D12B_LONG_RELAXATION",
        "role": "TARGETED_DISCOVERY_EXTENSION",
        "question": "Do the seven C6D12 mixed worlds still changing at 2N settle into a common stationary ensemble by 8N?",
        "selection":"exactly the seven worlds whose final eight-tick support window was nonconstant; no replacement or refit",
        "parent_result": str(PARENT),
        "kernel_environment": environment,
        "summary": summary,
        "cases": cases,
        "adjudication":"support/s_reg freezing identifies collision exhaustion or a finite orbit of coarse counts, not thermodynamic equilibrium; a thermodynamic promotion additionally requires preparation-independent ensembles, response and conjugate variables",
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
