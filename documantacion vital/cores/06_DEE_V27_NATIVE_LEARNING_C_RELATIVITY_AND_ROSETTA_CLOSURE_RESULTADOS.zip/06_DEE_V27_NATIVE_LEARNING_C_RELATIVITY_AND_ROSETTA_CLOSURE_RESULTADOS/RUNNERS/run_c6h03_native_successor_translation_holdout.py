#!/usr/bin/env python3
"""Frozen C6H03: native SUCCESSOR and integer-translation learning holdout."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"C6H03_NATIVE_SUCCESSOR_AND_TRANSLATION_LEARNING.json"
OUT=WORK/"RESULTS"/"C6H03_native_successor_translation_holdout.json"
EXPECTED_LOCK_SHA256="7bee9ee3b2c597f0afc420ab8569c4b7bbb04b2bb523262aeed8ebd46f88317f"
BASE={"cue":(1,0,0),"teacher":(-1,1,0),"memory":(0,1,0),"eraser":(1,-1,0),"channel_offset":(0,0,1)}


def add(q,d,k,n): return tuple((q[i]+k*d[i])%n for i in range(3))
def transform(v,p,s): return tuple(s[i]*v[p[i]] for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw)
    return {"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}


def wilson(k,n,z=1.959963984540054):
    p=k/n; den=1+z*z/n; center=(p+z*z/(2*n))/den
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half


def place_initial(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0: raise RuntimeError(f"initial overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk)


def inject(world,q,d,sreg,state,clk):
    if int(world.raw[q])!=0:raise RuntimeError(f"occupied frozen port {q}")
    value=pack(state,sreg,d,1);world.raw_a[q]=value;world.raw_b[q]=value;world.clock_a[q]=np.uint64(clk);world.clock_b[q]=np.uint64(clk)


def simulate(kernel,cell,query,mode):
    n=cell["n"];t0=cell["train_tick"];delay=cell["query_delay"];tq=t0+delay;path=cell["query_path"]
    cue=tuple(cell["vectors"]["cue"]);teacher=tuple(cell["vectors"]["teacher"]);memory=tuple(cell["vectors"]["memory"]);eraser=tuple(cell["vectors"]["eraser"]);off=tuple(cell["vectors"]["channel_offset"])
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
    ys=[x+cell["delta"] for x in cell["train_x"]]
    if mode=="label_shuffled":ys=ys[1:]+ys[:1]
    if mode!="untrained":
        for i,(j,x,y) in enumerate(zip(cell["junctions"],cell["train_x"],ys,strict=True)):
            j=tuple(j);tj=add(j,off,cell["matched_shift"],n) if mode=="matched_exposure" else j
            tt=t0+1 if mode=="history_shuffled" else t0
            place_initial(raw,clock,tj,t0,cue,cell["B"]-x,cell["states"][2*i],cell["clocks"][2*i],n)
            place_initial(raw,clock,tj,tt,teacher,y,cell["states"][2*i+1],cell["clocks"][2*i+1],n)
            if mode=="ordinary_reset":
                rt=t0+3;rp=add(j,memory,rt-t0,n)
                place_initial(raw,clock,rp,rt,eraser,43,cell["states"][8+i],cell["clocks"][8+i],n)
    world=NativeWorld(kernel,raw,clock,threads=1)
    targets=[add(tuple(j),memory,delay,n) for j in cell["junctions"]]
    ports=[add(q,cue,-path,n) for q in targets]
    ports_empty=None;ablation=[];records=None
    for tick in range(tq+1):
        if tick==t0+3 and mode=="memory_ablation":
            for j in cell["junctions"]:
                q=add(tuple(j),memory,3,n);ablation.append(int(world.raw[q])!=0)
                world.raw_a[q]=np.uint64(0);world.raw_b[q]=np.uint64(0);world.clock_a[q]=np.uint64(0);world.clock_b[q]=np.uint64(0)
        if tick==tq-path:
            ports_empty=all(int(world.raw[q])==0 for q in ports)
            for i,q in enumerate(ports):inject(world,q,cue,query,cell["states"][12+i],cell["clocks"][12+i])
        if tick==tq:records=[decode(world.raw,q) for q in targets]
        if tick<tq:world.tick()
    decoded=[None if r is None else r["sreg"]-cell["B"] for r in records]
    correct=[x==query+cell["delta"] for x in decoded]
    return {"cell":cell["cell"],"n":n,"delta":cell["delta"],"query":query,"mode":mode,"train_x":cell["train_x"],"train_y":ys,"expected":query+cell["delta"],"targets":[list(q) for q in targets],"ports_empty":ports_empty,"ablation_present":ablation,"records":records,"decoded":decoded,"channel_correct":correct,"world_exact":all(correct),"any_correct_channel":any(correct)}


def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1)
    cells=[]
    for i,(n,t0,delta,xs,queries,frame,seed) in enumerate(zip(lock["domain"]["new_sizes"],lock["domain"]["train_ticks"],lock["domain"]["new_deltas"],lock["domain"]["training_x_by_cell"],lock["domain"]["final_holdout_queries_by_cell"],lock["domain"]["frames"],lock["parameters"]["seeds"],strict=True)):
        if set(xs)&set(queries):raise RuntimeError("holdout input leaked into training x")
        rng=np.random.default_rng(seed);vectors={k:list(transform(v,frame["permutation"],frame["signs"])) for k,v in BASE.items()}
        off=tuple(vectors["channel_offset"]);base=tuple(int(x) for x in rng.integers(12,n-12,size=3));junctions=[list(add(base,off,lock["parameters"]["channel_spacing"]*j,n)) for j in range(4)]
        cells.append({"cell":i,"n":n,"train_tick":t0,"delta":delta,"train_x":xs,"queries":queries,"B":lock["domain"]["base_offset"],"query_delay":lock["domain"]["query_delay"],"query_path":lock["domain"]["query_path_length"],"matched_shift":lock["parameters"]["matched_exposure_shift"],"vectors":vectors,"junctions":junctions,"states":[int(x) for x in rng.integers(1,2**32,size=16,dtype=np.uint64)],"clocks":[int(rng.bit_generator.random_raw()) for _ in range(16)]})
    cases=[simulate(kernel,cell,q,mode) for cell in cells for q in cell["queries"] for mode in lock["parameters"]["modes"]]
    trained=[c for c in cases if c["mode"]=="trained"];controls=[c for c in cases if c["mode"]!="trained"];successor=[c for c in trained if c["delta"]==1];ablations=[c for c in cases if c["mode"]=="memory_ablation"]
    exact=sum(c["world_exact"] for c in trained);interval=wilson(exact,len(trained))
    rates={"trained_world_exact":exact/len(trained),"trained_channel_exact":sum(sum(c["channel_correct"]) for c in trained)/(4*len(trained)),"successor_world_exact":sum(c["world_exact"] for c in successor)/len(successor),"control_world_incorrect":sum(not c["world_exact"] for c in controls)/len(controls),"control_any_correct_channel":sum(c["any_correct_channel"] for c in controls)/len(controls),"ports_empty":sum(c["ports_empty"] for c in cases)/len(cases),"ablation_targets_present":sum(sum(c["ablation_present"]) for c in ablations)/(4*len(ablations))}
    m=lock["minimum_relevance"]
    pass_conditions={"trained":rates["trained_world_exact"]>=m["trained_world_exact_rate"],"every_world":all(c["world_exact"] for c in trained),"wilson":interval[0]>=m["trained_world_wilson_95_lower"],"successor":rates["successor_world_exact"]>=m["successor_world_exact_rate"],"channels":rates["trained_channel_exact"]>=m["all_channel_exact_rate"],"controls":rates["control_world_incorrect"]>=m["control_world_incorrect_rate"],"control_channels":rates["control_any_correct_channel"]<=m["control_any_correct_channel_rate_max"],"ports":rates["ports_empty"]>=m["ports_empty_rate"],"ablation":rates["ablation_targets_present"]>=m["ablation_targets_present_rate"]}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL"
    result={"schema":"dee.v27.core06.c6h03.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"learners":4,"trained_worlds":len(trained),"control_worlds":len(controls),"successor_worlds":len(successor),"channel_readouts":4*len(cases)},"rates":rates,"trained_world_wilson_95":interval,"pass_conditions":pass_conditions,"verdict":verdict,"cells":cells,"cases":cases}
    result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result)
    print(json.dumps({k:result[k] for k in ("sample_sizes","rates","trained_world_wilson_95","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2


if __name__=="__main__":raise SystemExit(main())
