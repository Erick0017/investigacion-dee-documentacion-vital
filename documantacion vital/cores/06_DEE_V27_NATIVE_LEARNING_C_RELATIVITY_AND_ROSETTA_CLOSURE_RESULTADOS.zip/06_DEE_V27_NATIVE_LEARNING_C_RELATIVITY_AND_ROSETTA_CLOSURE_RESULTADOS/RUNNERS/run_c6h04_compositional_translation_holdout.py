#!/usr/bin/env python3
"""Frozen C6H04: composition of two learned translations in both orders."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1]
LOCK=WORK/"HOLDOUT_LOCKS"/"C6H04_COMPOSITIONAL_TRANSLATION_LEARNING.json"
OUT=WORK/"RESULTS"/"C6H04_compositional_translation_holdout.json"
EXPECTED_LOCK_SHA256="d82d9a1f155f732b5c2935fc8f06d91dc6562697b1aad742e21972cd7d37000b"
BASE={"cue":(1,0,0),"teacher_1":(-1,1,0),"memory_1":(0,1,0),"teacher_2":(-1,0,1),"memory_2":(0,0,1)}


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def transform(v,p,s):return tuple(s[i]*v[p[i]] for i in range(3))
def signsum(a,b):return tuple(int(np.sign(a[i]+b[i])) for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"state":int(f["state"][q]),"semantic":int(f["semantic"][q])}


def wilson(k,n,z=1.959963984540054):
    p=k/n;den=1+z*z/n;center=(p+z*z/(2*n))/den;half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/den
    return center-half,center+half


def place(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0:raise RuntimeError(f"initial overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk)


def simulate(kernel,cell,query,order,mode):
    n=cell["n"];t0=cell["train_tick"];cue=tuple(cell["vectors"]["cue"]);B=cell["B"]
    identities=[1,2] if order=="M1_THEN_M2" else [2,1]
    items=[]
    for ident in identities:
        items.append({"ident":ident,"memory":tuple(cell["vectors"][f"memory_{ident}"]),"teacher":tuple(cell["vectors"][f"teacher_{ident}"]),"delta":cell[f"d{ident}"],"x":cell[f"x{ident}"]})
    first,second=items;t_first=t0+cell["first_delay"];t_second=t_first+cell["second_gap"]
    jfirst=tuple(cell["base_junction"]);pfirst=add(jfirst,first["memory"],t_first-t0,n);rfirst=signsum(cue,first["memory"]);psecond=add(pfirst,rfirst,t_second-t_first,n);jsecond=add(psecond,second["memory"],-(t_second-t0),n);rfinal=signsum(rfirst,second["memory"])
    raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw)
    present_first=mode not in {"untrained","second_only"};present_second=mode not in {"untrained","first_only"}
    for position,item,present,which in ((jfirst,first,present_first,"first"),(jsecond,second,present_second,"second")):
        if not present:continue
        label=item["x"]+item["delta"]+(1 if mode==f"{which}_label_shuffled" else 0)
        teacher_tick=t0+1 if mode==f"{which}_history_shuffled" else t0
        offset=0 if which=="first" else 2
        place(raw,clock,position,t0,cue,B-item["x"],cell["states"][offset],cell["clocks"][offset],n)
        place(raw,clock,position,teacher_tick,item["teacher"],label,cell["states"][offset+1],cell["clocks"][offset+1],n)
    world=NativeWorld(kernel,raw,clock,threads=1);port=add(pfirst,cue,-cell["query_path"],n);port_empty=None;ablation_present=None;rec1=None;rec2=None
    for tick in range(t_second+1):
        if tick==t0+3 and mode in {"first_ablation","second_ablation"}:
            item=first if mode=="first_ablation" else second;j=jfirst if mode=="first_ablation" else jsecond;q=add(j,item["memory"],3,n);ablation_present=int(world.raw[q])!=0
            world.raw_a[q]=np.uint64(0);world.raw_b[q]=np.uint64(0);world.clock_a[q]=np.uint64(0);world.clock_b[q]=np.uint64(0)
        if tick==t_first-cell["query_path"]:
            port_empty=int(world.raw[port])==0
            if not port_empty:raise RuntimeError(f"occupied frozen query port {port}")
            value=pack(cell["states"][4],query,cue,1);world.raw_a[port]=value;world.raw_b[port]=value;world.clock_a[port]=np.uint64(cell["clocks"][4]);world.clock_b[port]=np.uint64(cell["clocks"][4])
        if tick==t_first:rec1=decode(world.raw,pfirst)
        if tick==t_second:rec2=decode(world.raw,psecond)
        if tick<t_second:world.tick()
    decoded=None if rec2 is None else rec2["sreg"]-2*B;expected=query+cell["d1"]+cell["d2"]
    exact=rec2 is not None and rec2["d"]==list(rfinal) and decoded==expected
    return {"cell":cell["cell"],"order":order,"mode":mode,"query":query,"expected":expected,"decoded":decoded,"n":n,"junction_first":list(jfirst),"junction_second":list(jsecond),"collision_first":list(pfirst),"collision_second":list(psecond),"expected_final_direction":list(rfinal),"port_empty":port_empty,"ablation_present":ablation_present,"record_first":rec1,"record_second":rec2,"composition_exact":exact}


def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);cells=[]
    for i,(n,t0,ds,xs,queries,frame,seed) in enumerate(zip(lock["domain"]["new_sizes"],lock["domain"]["train_ticks"],lock["domain"]["new_delta_pairs"],lock["domain"]["training_x_pairs"],lock["domain"]["final_holdout_queries"],lock["domain"]["frames"],lock["parameters"]["seeds"],strict=True)):
        if any(q in xs for q in queries):raise RuntimeError("query leaked into training x")
        rng=np.random.default_rng(seed);vectors={k:list(transform(v,frame["permutation"],frame["signs"])) for k,v in BASE.items()};base=[int(x) for x in rng.integers(14,n-14,size=3)]
        cells.append({"cell":i,"n":n,"train_tick":t0,"d1":ds[0],"d2":ds[1],"x1":xs[0],"x2":xs[1],"queries":queries,"B":lock["domain"]["base_offset"],"first_delay":lock["domain"]["first_collision_delay"],"second_gap":lock["domain"]["second_collision_gap"],"query_path":lock["domain"]["query_path_length"],"vectors":vectors,"base_junction":base,"states":[int(x) for x in rng.integers(1,2**32,size=5,dtype=np.uint64)],"clocks":[int(rng.bit_generator.random_raw()) for _ in range(5)]})
    cases=[simulate(kernel,cell,q,order,mode) for cell in cells for q in cell["queries"] for order in lock["domain"]["orders"] for mode in lock["parameters"]["modes"]]
    trained=[c for c in cases if c["mode"]=="both_trained"];controls=[c for c in cases if c["mode"]!="both_trained"];ablations=[c for c in cases if c["mode"] in {"first_ablation","second_ablation"}]
    exact=sum(c["composition_exact"] for c in trained);interval=wilson(exact,len(trained));rates={"trained_world_exact":exact/len(trained),"order_M1_M2_exact":sum(c["composition_exact"] for c in trained if c["order"]=="M1_THEN_M2")/len([c for c in trained if c["order"]=="M1_THEN_M2"]),"order_M2_M1_exact":sum(c["composition_exact"] for c in trained if c["order"]=="M2_THEN_M1")/len([c for c in trained if c["order"]=="M2_THEN_M1"]),"control_world_false":sum(not c["composition_exact"] for c in controls)/len(controls),"ports_empty":sum(c["port_empty"] for c in cases)/len(cases),"ablation_targets_present":sum(c["ablation_present"] is True for c in ablations)/len(ablations)}
    m=lock["minimum_relevance"];pass_conditions={"trained":rates["trained_world_exact"]>=m["trained_world_exact_rate"],"every_trained":all(c["composition_exact"] for c in trained),"wilson":interval[0]>=m["trained_world_wilson_95_lower"],"order_1":rates["order_M1_M2_exact"]>=m["each_order_exact_rate"],"order_2":rates["order_M2_M1_exact"]>=m["each_order_exact_rate"],"controls":rates["control_world_false"]>=m["control_world_false_rate"],"ports":rates["ports_empty"]>=m["ports_empty_rate"],"ablations":rates["ablation_targets_present"]>=m["ablation_targets_present_rate"]}
    verdict="PASS" if all(pass_conditions.values()) else "FAIL";result={"schema":"dee.v27.core06.c6h04.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"sample_sizes":{"cells":3,"trained_worlds":len(trained),"control_worlds":len(controls),"total_worlds":len(cases)},"rates":rates,"trained_world_wilson_95":interval,"pass_conditions":pass_conditions,"verdict":verdict,"cells":cells,"cases":cases};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("sample_sizes","rates","trained_world_wilson_95","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2


if __name__=="__main__":raise SystemExit(main())
