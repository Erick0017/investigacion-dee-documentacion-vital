#!/usr/bin/env python3
"""Frozen C6H05 internal metrology and moving-observer holdout."""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK=Path(__file__).resolve().parents[1];LOCK=WORK/"HOLDOUT_LOCKS"/"C6H05_INTERNAL_KINEMATICS_AND_MOVING_OBSERVERS.json";OUT=WORK/"RESULTS"/"C6H05_internal_kinematics_holdout.json"
EXPECTED_LOCK_SHA256="9c75bcef805f0b79dd3be454ddffa82b2e0859e3dbb2b3d6a701786e7c2d32c9"


def add(q,d,k,n):return tuple((q[i]+k*d[i])%n for i in range(3))
def signsum(a,b):return tuple(int(np.sign(a[i]+b[i])) for i in range(3))


def decode(raw,q):
    if int(raw[q])==0:return None
    f=fields(raw);return {"raw":int(raw[q]),"state":int(f["state"][q]),"sreg":int(f["sreg"][q]),"d":[int(f[x][q]) for x in ("dx","dy","dz")],"semantic":int(f["semantic"][q])}


def place(raw,clock,target,tick,d,sreg,state,clk,n):
    q=add(target,d,-tick,n)
    if int(raw[q])!=0:raise RuntimeError(f"initial overlap {q}")
    raw[q]=pack(state,sreg,d,1);clock[q]=np.uint64(clk);return q


def run_source(kernel,spec,seed,horizon):
    n=spec["n"];d=tuple(spec["direction"]);rng=np.random.default_rng(seed);source=tuple(int(x) for x in rng.integers(0,n,size=3));raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);raw[source]=pack(0,spec["sreg"],d,4);clock[source]=np.uint64(spec["clock"]);world=NativeWorld(kernel,raw,clock,threads=1);trace=[]
    for tick in range(horizon+1):
        trace.append({"tick":tick,"source":decode(world.raw,source),"mouth":decode(world.raw,add(source,d,1,n))})
        if tick<horizon:world.tick()
    mouths=[r["tick"] for r in trace if r["mouth"] is not None and r["mouth"]["semantic"]==1];intervals=[b-a for a,b in zip(mouths,mouths[1:])]
    exact=mouths==[1,3,5,7,9,11] and all(r["source"] is not None and r["source"]["semantic"]==4 for r in trace)
    return {"spec":spec,"seed":seed,"source":list(source),"mouth_ticks":mouths,"intervals":intervals,"period_two_exact":exact,"trace":trace}


def run_channel(kernel,spec,hub,T,target_present,nuisance):
    n=spec["n"];L=spec["L"];td=tuple(spec["target"]);pd=tuple(spec["probe"]);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);place(raw,clock,hub,T,pd,nuisance["probe_sreg"],nuisance["probe_state"],nuisance["probe_clock"],n)
    if target_present:place(raw,clock,hub,L,td,nuisance["target_sreg"],nuisance["target_state"],nuisance["target_clock"],n)
    out_d=signsum(td,pd);out_s=min(nuisance["target_sreg"]+nuisance["probe_sreg"],19664);world=NativeWorld(kernel,raw,clock,threads=1);events=[]
    for tick in range(max(L,T)+2):
        r=decode(world.raw,hub)
        if r is not None:events.append({"tick":tick,"record":r})
        if tick<max(L,T)+1:world.tick()
    merged=[e for e in events if e["record"]["d"]==list(out_d) and e["record"]["sreg"]==out_s]
    return {"T":T,"target_present":target_present,"events":events,"merged":merged,"sync_exact":target_present and len(merged)==1 and merged[0]["tick"]==L==T,"absent_no_merge":not target_present and len(merged)==0}


def run_ruler(kernel,spec,seed,offsets):
    rng=np.random.default_rng(seed);n=spec["n"];hub=tuple(int(x) for x in rng.integers(0,n,size=3));nuisance={"target_sreg":int(rng.integers(1,8001)),"probe_sreg":int(rng.integers(1,8001)),"target_state":int(rng.integers(1,2**31)),"probe_state":int(rng.integers(1,2**31)),"target_clock":int(rng.bit_generator.random_raw()),"probe_clock":int(rng.bit_generator.random_raw())};labels=[spec["L"]+o for o in offsets];channels=[run_channel(kernel,spec,hub,T,True,nuisance) for T in labels];active=[c["T"] for c in channels if c["sync_exact"]];absent=run_channel(kernel,spec,hub,spec["L"],False,nuisance);support=sum(abs(x) for x in spec["target"]);measured=active[0] if len(active)==1 else None
    return {"spec":spec,"seed":seed,"hub":list(hub),"nuisance":nuisance,"labels":labels,"active":active,"measured_T":measured,"v_graph":None if measured is None else spec["L"]/measured,"v_source_clock":None if measured is None else 2*spec["L"]/measured,"v_euclidean":None if measured is None else math.sqrt(support)*spec["L"]/measured,"exact":active==[spec["L"]],"absent_no_merge":absent["absent_no_merge"],"channels":channels,"absent":absent}


def run_moving(kernel,spec,seed):
    n=spec["n"];T=spec["T"];u=tuple(spec["target"]);w=tuple(spec["observer"]);event=(n//4,n//4,n//4);clock_hub=(3*n//4,3*n//4,3*n//4);rng=np.random.default_rng(seed);raw=np.zeros((n,n,n),dtype=np.uint64);clock=np.zeros_like(raw);ts=int(rng.integers(1,9001));os=int(rng.integers(9001,18001));tstate=int(rng.integers(1,2**31));ostate=int(rng.integers(1,2**31));tc=int(rng.bit_generator.random_raw());oc=int(rng.bit_generator.random_raw())
    if spec["collision"]:
        tstart=place(raw,clock,event,T,u,ts,tstate,tc,n);ostart=place(raw,clock,event,T,w,os,ostate,oc,n)
    else:
        tstart=add(event,u,-T,n);off=(0,3,0) if u!=(0,1,0) else (3,0,0);ostart=add(tstart,off,1,n);raw[tstart]=pack(tstate,ts,u,1);clock[tstart]=np.uint64(tc);raw[ostart]=pack(ostate,os,w,1);clock[ostart]=np.uint64(oc)
    place(raw,clock,clock_hub,T,(0,1,0),401,701,7001,n);place(raw,clock,clock_hub,T,(0,0,1),799,703,7003,n);world=NativeWorld(kernel,raw,clock,threads=1);event_record=None;clock_record=None
    for tick in range(T+1):
        if tick==T:event_record=decode(world.raw,event);clock_record=decode(world.raw,clock_hub)
        if tick<T:world.tick()
    frozen_speed=max(abs(u[i]-w[i]) for i in range(3));separation=frozen_speed*T if spec["collision"] else int(max(abs(tstart[i]-ostart[i]) for i in range(3)));merged=event_record is not None and event_record["sreg"]==min(ts+os,19664) and event_record["d"]==list(signsum(u,w));event_correct=merged if spec["collision"] else not merged;clock_exact=clock_record is not None and clock_record["sreg"]==1200 and clock_record["d"]==[0,1,1]
    return {"spec":spec,"seed":seed,"event":list(event),"target_start":list(tstart),"observer_start":list(ostart),"initial_graph_separation":separation,"frozen_speed":frozen_speed,"observed_speed":frozen_speed if not spec["collision"] else separation/T,"event_record":event_record,"merged":merged,"event_correct":event_correct,"clock_record":clock_record,"clock_exact":clock_exact,"law_exact":event_correct and (not spec["collision"] or separation/T==frozen_speed)}


def radius_three(kernel):
    n=11;x=np.array([5,5,5]);z=x-1;y=x+1;q=x-2;base=np.zeros((n,n,n),dtype=np.uint64);clock=np.ones_like(base);base[tuple(x)]=pack(1,19665,(0,0,0),1)
    for off in [o for o in itertools.product((-1,0,1),repeat=3) if o!=(0,0,0)]:
        at=tuple((x+off)%n)
        if at not in (tuple(z),tuple(y)):base[at]=pack(0,1,(0,0,0),0)
    for off in ((1,-1,-1),(-1,1,-1),(-1,-1,1),(1,1,-1),(1,-1,1),(-1,1,1)):base[tuple((x+off)%n)]=pack(1,1,(0,0,0),4)
    for off in ((-1,0,0),(0,-1,0),(0,0,-1),(-1,-1,0),(-1,0,-1),(0,-1,-1)):base[tuple((z+off)%n)]=pack(1,0,(0,0,0),4)
    a=base.copy();b=base.copy();b[tuple(q)]=pack(1,0,(0,0,0),4);wa=NativeWorld(kernel,a,clock,threads=1);wb=NativeWorld(kernel,b,clock,threads=1);wa.tick();wb.tick()
    return {"q":list(map(int,q)),"y":list(map(int,y)),"distance":3,"output_y_A":decode(wa.raw,tuple(y)),"output_y_B":decode(wb.raw,tuple(y)),"attained":int(wa.raw[tuple(y)])!=int(wb.raw[tuple(y)])}


def main():
    observed=hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed!=EXPECTED_LOCK_SHA256:raise RuntimeError(f"lock mismatch {observed}")
    lock=json.loads(LOCK.read_text(encoding="utf-8"));kernel,environment=verify_and_load_kernel(1);seeds=lock["parameters"]["seeds"]
    sources=[run_source(kernel,spec,seeds[i],lock["domain"]["source_clock_horizon"]) for i,spec in enumerate(lock["domain"]["source_clock_cases"])]
    rulers=[run_ruler(kernel,spec,seeds[i]+100,lock["domain"]["clock_channel_offsets"]) for i,spec in enumerate(lock["domain"]["ruler_cases"])]
    moving=[run_moving(kernel,spec,seeds[i]+200) for i,spec in enumerate(lock["domain"]["moving_cases"])];raw3=radius_three(kernel)
    counts={"source_period_two":sum(c["period_two_exact"] for c in sources),"ruler_exact":sum(c["exact"] for c in rulers),"ruler_absent_no_merge":sum(c["absent_no_merge"] for c in rulers),"graph_speed_one":sum(c["v_graph"]==1 for c in rulers),"moving_apparatus_correct":sum(c["event_correct"] for c in moving),"moving_law_exact":sum(c["law_exact"] for c in moving),"internal_clock_records":sum(c["clock_exact"] for c in moving)};classes=sorted(set(c["observed_speed"] for c in moving));m=lock["minimum_relevance"]
    pass_conditions={"source":counts["source_period_two"]==m["source_period_two_cases"],"ruler":counts["ruler_exact"]==m["ruler_exact_cases"],"absent":counts["ruler_absent_no_merge"]==m["ruler_absent_no_merge_cases"],"graph_speed":counts["graph_speed_one"]==m["graph_speed_one_cases"],"moving":counts["moving_apparatus_correct"]==m["moving_apparatus_correct_cases"],"moving_law":counts["moving_law_exact"]==m["moving_law_exact_cases"],"speed_classes":classes==m["moving_speed_classes"],"clock_records":counts["internal_clock_records"]==m["internal_clock_records"],"raw3":raw3["attained"] is m["raw_radius_three_witness"]};verdict="PASS" if all(pass_conditions.values()) else "FAIL"
    result={"schema":"dee.v27.core06.c6h05.v1","experiment_id":lock["hypothesis_id"],"role":"FROZEN_CONFIRMATION","lock_sha256":observed,"kernel_environment":environment,"counts":counts,"moving_speed_classes":classes,"pass_conditions":pass_conditions,"verdict":verdict,"source_clocks":sources,"rulers":rulers,"moving_observers":moving,"raw_radius_three":raw3};result["content_sha256"]=canonical_hash(result);atomic_json(OUT,result);print(json.dumps({k:result[k] for k in ("counts","moving_speed_classes","pass_conditions","verdict")},indent=2,sort_keys=True));return 0 if verdict=="PASS" else 2


if __name__=="__main__":raise SystemExit(main())
