#!/usr/bin/env python3
"""C6H06 frozen confirmation of free-carrier state normalization."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_file, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "C6H06_FREE_CARRIER_STATE_NORMALIZATION.json"
OUT = WORK / "RESULTS" / "C6H06_free_carrier_state_normalization_holdout.json"
EXPECTED_LOCK_SHA256 = "0844ea487cba70ce4d47f1880d232bf9ab5a7c51a8abbf5553a37d5512b3b427"


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"raw": int(raw[q]), "state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[k][q]) for k in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def main():
    observed_lock = sha256_file(LOCK)
    if observed_lock != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"holdout lock mismatch: {observed_lock}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(1)
    rng = np.random.default_rng(660601)
    states = (1, 4, 15, 123456789, 4294967294)
    directions = ((-1, 0, 0), (0, -1, 1), (1, -1, -1))
    sregs = (2, 8191, 19663)
    cases = []
    case_index = 0
    for n in (19, 31):
        for state in states:
            for direction_index, d in enumerate(directions):
                sreg = sregs[(case_index + direction_index) % len(sregs)]
                origin = tuple(int(x) for x in rng.integers(0, n, size=3))
                raw = np.zeros((n, n, n), dtype=np.uint64)
                initial = pack(state, sreg, d, 1)
                normalized = pack(1, sreg, d, 1)
                raw[origin] = initial
                world = NativeWorld(kernel, raw, threads=1)
                horizon = 2 * n + 3
                trace = []
                for tick in range(horizon + 1):
                    q = add(origin, d, tick, n)
                    record = decode(world.raw, q)
                    trace.append({
                        "tick": tick,
                        "count": int(np.count_nonzero(world.raw)),
                        "expected_site": list(q),
                        "record": record,
                        "normalized_raw_exact": tick == 0 or (record is not None and record["raw"] == int(normalized)),
                    })
                    if tick < horizon:
                        world.tick()
                support_exact = all(r["count"] == 1 and r["record"] is not None for r in trace)
                transport_exact = all(
                    r["record"] is not None and r["record"]["d"] == list(d) and r["record"]["sreg"] == sreg and r["record"]["semantic"] == 1
                    for r in trace
                )
                state_one = all(r["record"] is not None and r["record"]["state"] == 1 for r in trace[1:])
                raw_normalized = all(r["normalized_raw_exact"] for r in trace[1:])
                raw_control = state != 1 or all(r["record"] is not None and r["record"]["raw"] == int(initial) for r in trace)
                cases.append({
                    "case": case_index, "n": n, "origin": list(origin), "initial_state": state,
                    "sreg": sreg, "direction": list(d), "horizon": horizon,
                    "support_count_one_all_ticks": support_exact,
                    "transport_identity_exact_all_ticks": transport_exact,
                    "state_one_from_tick_one": state_one,
                    "normalized_raw_exact_from_tick_one": raw_normalized,
                    "state_one_control_raw_exact": raw_control,
                    "trace": trace,
                })
                case_index += 1
    summary = {
        "complete_cases": len(cases),
        "support_count_one_all_ticks": sum(c["support_count_one_all_ticks"] for c in cases),
        "transport_identity_exact_all_ticks": sum(c["transport_identity_exact_all_ticks"] for c in cases),
        "state_one_from_tick_one": sum(c["state_one_from_tick_one"] for c in cases),
        "normalized_raw_exact_from_tick_one": sum(c["normalized_raw_exact_from_tick_one"] for c in cases),
        "state_one_control_raw_exact": sum(c["initial_state"] == 1 and c["state_one_control_raw_exact"] for c in cases),
    }
    thresholds = lock["minimum_relevance"]
    passed = (
        summary["complete_cases"] == thresholds["complete_cases"]
        and summary["support_count_one_all_ticks"] == thresholds["support_count_one_all_ticks"]
        and summary["transport_identity_exact_all_ticks"] == thresholds["transport_identity_exact_all_ticks"]
        and summary["state_one_from_tick_one"] == thresholds["state_one_from_tick_one"]
        and summary["state_one_control_raw_exact"] == thresholds["state_one_control_raw_exact"]
        and summary["normalized_raw_exact_from_tick_one"] == 30
    )
    result = {
        "schema": "dee.v27.core06.c6h06.v1",
        "experiment_id": "C6H06_FREE_CARRIER_STATE_NORMALIZATION",
        "role": "FROZEN_CONFIRMATION",
        "lock_sha256": observed_lock,
        "kernel_environment": environment,
        "summary": summary,
        "verdict": "PASS" if passed else "FAIL",
        "promotion": lock["promotion_if_pass"] if passed else [],
        "cases": cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"verdict": result["verdict"], **summary}, indent=2, sort_keys=True))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
