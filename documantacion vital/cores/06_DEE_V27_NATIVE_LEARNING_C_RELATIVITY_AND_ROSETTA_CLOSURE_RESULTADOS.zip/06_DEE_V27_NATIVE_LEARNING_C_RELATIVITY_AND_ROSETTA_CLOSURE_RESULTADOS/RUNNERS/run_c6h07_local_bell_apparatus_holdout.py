#!/usr/bin/env python3
"""C6H07: frozen complete local Bell/CHSH apparatus using collision observers."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from native_core import NativeWorld, atomic_json, canonical_hash, fields, pack, sha256_file, verify_and_load_kernel


WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "C6H07_LOCAL_BELL_APPARATUS.json"
OUT = WORK / "RESULTS" / "C6H07_local_bell_apparatus_holdout.json"
EXPECTED_LOCK_SHA256 = "ed9b017b8254aeeec5242248631d2f36e8160f9a0a3e698f6375e4a7b7da8bf6"
LAMBDA = list(itertools.product((-1, 1), repeat=3))
A_SETTINGS = ((-1, -1, 0), (-1, 0, -1))
B_SETTINGS = ((1, 0, -1), (1, 1, 0))


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"raw": int(raw[q]), "state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[k][q]) for k in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def outcome(direction):
    for value in direction:
        if value != 0:
            return 1 if value > 0 else -1
    raise ValueError("zero direction has no frozen binary outcome")


def sign_sum(u, v):
    return [0 if u[i] + v[i] == 0 else (1 if u[i] + v[i] > 0 else -1) for i in range(3)]


def trial(kernel, n, hubs, lam, li, a, b):
    hub_a, hub_b = hubs
    target_a = tuple(lam)
    target_b = tuple(-x for x in lam)
    setting_a = A_SETTINGS[a]
    setting_b = B_SETTINGS[b]
    raw = np.zeros((n, n, n), dtype=np.uint64)
    entries = [
        (add(hub_a, target_a, -1, n), pack(1, 100 + li, target_a, 1)),
        (add(hub_a, setting_a, -1, n), pack(1, 1000 + a, setting_a, 1)),
        (add(hub_b, target_b, -1, n), pack(1, 100 + li, target_b, 1)),
        (add(hub_b, setting_b, -1, n), pack(1, 1000 + b, setting_b, 1)),
    ]
    assert len({q for q, _ in entries}) == 4
    for q, token in entries:
        raw[q] = token
    world = NativeWorld(kernel, raw, threads=1)
    world.tick()
    record_a = decode(world.raw, hub_a)
    record_b = decode(world.raw, hub_b)
    expected_a = sign_sum(target_a, setting_a)
    expected_b = sign_sum(target_b, setting_b)
    valid_a = record_a is not None and record_a["d"] == expected_a and record_a["semantic"] == 1 and record_a["sreg"] == 1100 + li + a
    valid_b = record_b is not None and record_b["d"] == expected_b and record_b["semantic"] == 1 and record_b["sreg"] == 1100 + li + b
    return {
        "lambda_index": li, "lambda": list(lam), "a": a, "b": b,
        "A_setting": list(setting_a), "B_setting": list(setting_b),
        "A_record": record_a, "B_record": record_b,
        "A_valid": valid_a, "B_valid": valid_b,
        "A_outcome": outcome(record_a["d"]) if valid_a else None,
        "B_outcome": outcome(record_b["d"]) if valid_b else None,
    }


def main():
    observed_lock = sha256_file(LOCK)
    if observed_lock != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"holdout lock mismatch: {observed_lock}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(1)
    frames = [
        {"n": 61, "hubs": ((15, 20, 20), (45, 20, 20))},
        {"n": 67, "hubs": ((18, 33, 30), (48, 33, 30))},
    ]
    frame_results = []
    all_trials = []
    for frame_index, frame in enumerate(frames):
        trials = [trial(kernel, frame["n"], frame["hubs"], lam, li, a, b) for li, lam in enumerate(LAMBDA) for a in range(2) for b in range(2)]
        correlations = []
        for a in range(2):
            for b in range(2):
                cell = [t for t in trials if t["a"] == a and t["b"] == b]
                correlations.append(sum(t["A_outcome"] * t["B_outcome"] for t in cell) / len(cell))
        chsh = correlations[0] + correlations[1] + correlations[2] - correlations[3]
        a_remote = all(
            next(t for t in trials if t["lambda_index"] == li and t["a"] == a and t["b"] == 0)["A_record"] == next(t for t in trials if t["lambda_index"] == li and t["a"] == a and t["b"] == 1)["A_record"]
            for li in range(8) for a in range(2)
        )
        b_remote = all(
            next(t for t in trials if t["lambda_index"] == li and t["a"] == 0 and t["b"] == b)["B_record"] == next(t for t in trials if t["lambda_index"] == li and t["a"] == 1 and t["b"] == b)["B_record"]
            for li in range(8) for b in range(2)
        )
        frame_result = {
            "frame": frame_index, "n": frame["n"], "hubs": [list(q) for q in frame["hubs"]],
            "hub_separation_chebyshev": max(abs(frame["hubs"][0][i] - frame["hubs"][1][i]) for i in range(3)),
            "trials": len(trials), "valid_local_records": sum(t["A_valid"] + t["B_valid"] for t in trials),
            "retained_trials": sum(t["A_outcome"] is not None and t["B_outcome"] is not None for t in trials),
            "correlations_E00_E01_E10_E11": correlations, "CHSH": chsh,
            "A_remote_setting_invariance": a_remote, "B_remote_setting_invariance": b_remote,
            "lambda_counts_by_setting_pair": {f"{a}{b}": sum(t["a"] == a and t["b"] == b for t in trials) for a in range(2) for b in range(2)},
        }
        frame_results.append(frame_result)
        all_trials.extend({"frame": frame_index, **t} for t in trials)
    summary = {
        "complete_trials": len(all_trials),
        "local_collision_records": sum(t["A_valid"] + t["B_valid"] for t in all_trials),
        "retained_trials": sum(t["A_outcome"] is not None and t["B_outcome"] is not None for t in all_trials),
        "A_remote_setting_invariance": all(f["A_remote_setting_invariance"] for f in frame_results),
        "B_remote_setting_invariance": all(f["B_remote_setting_invariance"] for f in frame_results),
        "frame_correlations": [f["correlations_E00_E01_E10_E11"] for f in frame_results],
        "frame_CHSH": [f["CHSH"] for f in frame_results],
        "max_abs_CHSH": max(abs(f["CHSH"]) for f in frame_results),
    }
    thresholds = lock["minimum_relevance"]
    passed = (
        summary["complete_trials"] == thresholds["complete_trials"]
        and summary["local_collision_records"] == thresholds["local_collision_records"]
        and summary["retained_trials"] == thresholds["retained_trials"]
        and summary["A_remote_setting_invariance"] is thresholds["A_remote_setting_invariance"]
        and summary["B_remote_setting_invariance"] is thresholds["B_remote_setting_invariance"]
        and summary["frame_correlations"] == thresholds["frame_correlations"]
        and summary["frame_CHSH"] == thresholds["frame_CHSH"]
    )
    result = {
        "schema": "dee.v27.core06.c6h07.v1",
        "experiment_id": "C6H07_LOCAL_BELL_APPARATUS",
        "role": "FROZEN_CONFIRMATION",
        "lock_sha256": observed_lock,
        "kernel_environment": environment,
        "verdict": "PASS" if passed else "FAIL",
        "summary": summary,
        "frame_results": frame_results,
        "trials": all_trials,
        "promotion": lock["promotion_if_pass"] if passed else [],
        "interpretation": "This instantiates the formerly missing operational Bell variables but yields an explicitly local deterministic model at the classical bound. It is evidence against a quantum claim for this apparatus, not a theorem excluding every possible DEE apparatus.",
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"verdict": result["verdict"], **summary}, indent=2, sort_keys=True))
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
