"""Read-only integrity and scientific-completeness audit for CORE06."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

EXPECTED_KERNEL = {
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}

EXPECTED_LOCKS = {
    "C6H01_COLLISION_WRITTEN_ASSOCIATIVE_PLASTICITY.json": "d803b826c106a30317691c55411e34595aa6e86eb98afac651fab5e792652de7",
    "C6H02_CLASS_GENERALIZATION_AND_REVERSIBLE_PLASTICITY.json": "0bcddcf4c84b144c54c83cd3a200d4df3b4bdae144108781350d5970348d7553",
    "C6H03_NATIVE_SUCCESSOR_AND_TRANSLATION_LEARNING.json": "7bee9ee3b2c597f0afc420ab8569c4b7bbb04b2bb523262aeed8ebd46f88317f",
    "C6H04_COMPOSITIONAL_TRANSLATION_LEARNING.json": "d82d9a1f155f732b5c2935fc8f06d91dc6562697b1aad742e21972cd7d37000b",
    "C6H05_INTERNAL_KINEMATICS_AND_MOVING_OBSERVERS.json": "9c75bcef805f0b79dd3be454ddffa82b2e0859e3dbb2b3d6a701786e7c2d32c9",
    "C6H06_FREE_CARRIER_STATE_NORMALIZATION.json": "0844ea487cba70ce4d47f1880d232bf9ab5a7c51a8abbf5553a37d5512b3b427",
    "C6H07_LOCAL_BELL_APPARATUS.json": "ed9b017b8254aeeec5242248631d2f36e8160f9a0a3e698f6375e4a7b7da8bf6",
    "C6H08_DISSIPATIVE_NORMAL_ENSEMBLE_RELAXATION.json": "25c601b4eb589ec5ae583f094c90e9b0589e4eb526a42fb2a6e2ae8b0afebd0f",
}

EXPECTED_RESULTS = {
    "C6H01_associative_plasticity_holdout.json": "5ed5766c9058e0bd728bd959ddfd5db6667b8f372c54395a1d7803d3cf47eb85",
    "C6H02_class_generalization_reversal_holdout.json": "e273ee8200233e0f481648b724af137da4d149278528d8c951149410c9236fbe",
    "C6H03_native_successor_translation_holdout.json": "8acc1605a95ee655e64dd23fd951fa7f4ba9a7022c5989f408c8e940a9fd7eba",
    "C6H04_compositional_translation_holdout.json": "3f61ead2415dcf75a45e18c8089ecec45f8956d36aee1e16cbe53afea879fb98",
    "C6H05_internal_kinematics_holdout.json": "f45f48b42d6524c6018da933b835456047b9960e0ec45f20559bb2d86725de2c",
    "C6H06_free_carrier_state_normalization_holdout.json": "9c39f140d301bfe0013652504d40824b6229463503afda36b54d86111eeef0b4",
    "C6H07_local_bell_apparatus_holdout.json": "5512d067249b9c1ef2183ebf20ac15903ca2ab8ae4f5b0991f9a38c20a0e9a1b",
    "C6H08_dissipative_ensemble_holdout.json": "953ef98735e54c788c2897f6322f4fb139222f1aba7a65add98d27a642953f82",
    "C6R01_external_delay_place_rosetta_gate.json": "7faea0aefbba1383607ac18d84977e81d97aafd60291775752343f077c392d57",
}

REQUIRED_DOCS = [
    "FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "TRANSVERSAL_01_TO_06.md",
    "NATIVE_LEARNING.md", "ARITHMETIC_LEARNING.md", "LEARNING_CAUSAL_MECHANISM.md",
    "C_DEE_REASSESSMENT.md", "INTERNAL_RELATIVITY.md", "PHYSICAL_C_BRIDGE.md",
    "DEE_MATTER_OPERATIONAL.md", "QUANTUM_REAUDIT.md", "THERMODYNAMIC_REAUDIT.md",
    "ROSETTA_CLOSURE.md", "NEW_DISCOVERIES.md", "NEGATIVE_RESULTS.md", "OPEN_FRONTIER.md",
]

def sha(path: Path) -> str:
    h = hashlib.sha256()
    if path.is_dir():
        for child in sorted(p for p in path.rglob("*") if p.is_file()):
            h.update(child.relative_to(path).as_posix().encode())
            h.update(child.read_bytes())
    else:
        h.update(path.read_bytes())
    return h.hexdigest()

def main() -> None:
    errors: list[str] = []
    for name in ["STATE.json", "CLAIMS.json", "ROSETTA_CANDIDATES.json", "LEARNING_STATE.json"]:
        try:
            json.loads((ROOT / name).read_text(encoding="utf-8-sig"))
        except Exception as exc:
            errors.append(f"invalid {name}: {exc}")
    for path in sorted((ROOT / "RESULTS").glob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            errors.append(f"invalid result {path.name}: {exc}")
    for path in sorted((ROOT / "HOLDOUT_LOCKS").glob("*.json")):
        try:
            json.loads(path.read_text(encoding="utf-8-sig"))
        except Exception as exc:
            errors.append(f"invalid lock {path.name}: {exc}")
    for index, line in enumerate((ROOT / "SCIENCE_LOG.ndjson").read_text(encoding="utf-8-sig").splitlines(), 1):
        try:
            json.loads(line)
        except Exception as exc:
            errors.append(f"invalid SCIENCE_LOG line {index}: {exc}")
    for rel, digest in EXPECTED_KERNEL.items():
        path = ROOT / rel
        if not path.exists() or sha(path) != digest:
            errors.append(f"kernel hash mismatch: {rel}")
    for name, digest in EXPECTED_LOCKS.items():
        path = ROOT / "HOLDOUT_LOCKS" / name
        if not path.exists() or sha(path) != digest:
            errors.append(f"lock hash mismatch: {name}")
    for name, digest in EXPECTED_RESULTS.items():
        path = ROOT / "RESULTS" / name
        if not path.exists() or sha(path) != digest:
            errors.append(f"result hash mismatch: {name}")
    for name in EXPECTED_RESULTS:
        if name.startswith("C6H"):
            value = json.loads((ROOT / "RESULTS" / name).read_text(encoding="utf-8-sig"))
            if value.get("verdict") != "PASS":
                errors.append(f"non-PASS frozen result: {name}")
    for name in REQUIRED_DOCS:
        if not (ROOT / name).is_file():
            errors.append(f"missing document: {name}")
    if errors:
        raise SystemExit("CORE06 VALIDATION FAILED\n" + "\n".join(errors))
    print(f"CORE06 VALIDATION PASS: {len(EXPECTED_LOCKS)} locks, {len(EXPECTED_RESULTS)} adjudicated results, {len(REQUIRED_DOCS)} documents")

if __name__ == "__main__":
    main()
