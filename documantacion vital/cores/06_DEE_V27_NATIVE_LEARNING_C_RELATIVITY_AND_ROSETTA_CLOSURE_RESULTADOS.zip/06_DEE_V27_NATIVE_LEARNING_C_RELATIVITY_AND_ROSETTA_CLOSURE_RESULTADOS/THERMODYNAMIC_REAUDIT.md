# Reauditoría termodinámica

## Diseño

Se compararon ensembles con inventario, posiciones, `state`, `s_reg`, semantic y clock igualados. Sólo cambió la organización direccional: todos alineados frente a mezcla de direcciones. Las unidades independientes fueron mundos, no ticks.

## Discovery

- Alineados: soporte y `s_reg` exactos en 16/16; traslación rígida.
- Mixtos: soporte y `s_reg` no crecientes en 16/16.
- Ratio medio de soporte final: 0.5400, rango 0.3307–0.8158.
- Siete casos aún activos a `2N` se extendieron a `8N`: 7/7 mantuvieron monotonicidad, 4/7 siguieron contrayendo soporte después de `2N`, 0/7 perdieron más `s_reg` después de `2N`, y todos tuvieron cola constante de longitud `2N`.

## Holdout C6H08

En 32 mundos nuevos:

- alineados: soporte/raw trasladado exacto 16/16 y `s_reg` exacto 16/16;
- mixtos: soporte y `s_reg` no crecientes 16/16, contracción 16/16 y ventana terminal constante 16/16;
- el gap de contracción entre baja y alta densidad fue 0.2917 para `N=18` y 0.2598 para `N=25`, superior al mínimo 0.10.

## Interpretación

En este sector, soporte total y `s_reg` total son funciones Lyapunov-like no crecientes. Las colisiones many-to-one y el cap producen irreversibilidad informacional. La densidad controla la frecuencia de interacción y la magnitud de contracción.

## Lo que no se deriva

- no energía física;
- no temperatura o variable conjugada;
- no ensemble estacionario común;
- no detailed balance;
- no entropía termodinámica monotónica demostrada;
- no teorema asintótico global;
- no hidrodinámica constitutiva.

Estado: `THERMODYNAMIC_STRUCTURE_FOUND` sólo como relajación disipativa y observables Lyapunov-like sectoriales.
