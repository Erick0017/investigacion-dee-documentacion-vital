# Síntesis transversal CORE 01–06

## Jerarquía que sobrevivió

- `Q0=(raw,clock)`: estado microscópico Markoviano exacto.
- `Q1`: roles y eventos causales —portadores, fuentes, guards, propuestas, destinos, colisiones y first-passage— con separación necesaria entre estado predictivo y evento instantáneo.
- `Q2`: organización de basin prospectivamente predecible en preparaciones certificadas; `q_N` es predictor, no causa completa.
- `Q3`: clases de histories productivas, descritas por reproducción/interfaz/actividad, confirmadas en dominio acotado; no estado global autónomo.
- No existe `Q4` global demostrado. CORE05 encontró, en cambio, recursión observacional finita y leyes topología–fase–historia.
- CORE06 añade memoria escrita por experiencia, función de respuesta aprendida y composición de memorias sin postular un nivel nominal nuevo.

## Qué añadió cada CORE

| CORE | Aporte que se hereda | Límite preservado |
|---|---|---|
| 01 | Kernel real, teoremas internos, cono raw `<=3t`, sectores balísticos, fuentes, colisiones, invariantes sectoriales | ninguna Rosetta externa |
| 02 | Rosetta interna `X -> M_* -> (G_dagger,J_dagger)`, roles L/C/O y separación estado/evento | T10 FAIL literal; física externa no identificada |
| 03 | Q2 y predictor multiescala confirmado | dominio finito; predictor no causa |
| 04 | Q3, cociclo `Gamma`, ley de histories y múltiples sectores | no cierre recursivo global ni Q4 |
| 05 | fibras de destino, observers, medición, retardo-a-lugar, recursión observacional y topología–fase–historia | candidato Rosetta sólo formal; aprendizaje no encontrado en aquella arquitectura |
| 06 | aprendizaje por linajes de colisión, generalización/composición, cinemática interna, materia operacional, Bell local y relajación sectorial | sin Lorentz, masa, Born, temperatura o Rosetta validada |

## Arquitectura transversal actual

La compresión causal más útil es:

`(raw,clock)`

`-> propuestas dirigidas + guards`

`-> fibras de destino + reducer`

`-> linajes/fuentes/historia de fase`

`-> organización colectiva`

`-> observador-interacción`

`-> registro/medida/fenómeno efectivo`.

CORE06 muestra que “experiencia” puede insertarse en esa cadena: una interacción crea un linaje que modifica una interacción futura. El mismo reducer explica memoria, cálculo de traslación, composición, colisión material, medición y pérdida de información. Esto es una unificación funcional interna, no una identificación ontológica externa.

## Correcciones epistemológicas preservadas

1. Occupancy no es materia por definición.
2. `s_reg` no es energía; funciona como etiqueta, suma capada y control contextual.
3. `direction` enruta y transporta, pero no es momentum global.
4. Clock es contador modular/fase; no tiempo SI.
5. Periodicidad finita o Koopman no implican quantum.
6. Un FAIL de un observable no elimina todas las representaciones colectivas.
7. Un aparato interno exige preparación, settings, outcomes y controles; el nombre “observer” no basta.
8. Aprendizaje exige cambio inducido por experiencia y generalización frente a controles, no búsqueda externa de configuración.

## Frontera física

La cadena interna ahora contiene mecanismos de historia y detector cada vez más precisos. Lo aún no identificable desde `F_DEE` solo es qué preparación física selecciona el ensemble DEE y qué mapa de lectura/unidades convierte registros DEE en medidas del mundo. Ésa es una frontera empírica, no una licencia para declarar equivalencias por analogía.
