# Computación, aritmética y factorización

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


Se heredan suma nativa de colisiones, aprendizaje de traducciones enteras y composición acotada. EXTRA02 muestra que el mismo reductor puede acumular evidencia por clase; C7H02 muestra que su capacidad depende de fibras separadas y que overlap integra.

No apareció en CORE07 un mecanismo nuevo de iteración, residuos, divisibilidad o reutilización de operador que altere FactorX. Repetir su genealogía trial-division-like sólo reproduciría un negativo cerrado. No hay ventaja asintótica o práctica de factorización demostrada.

El descubrimiento computacional real es la equivalencia exacta entre dinámica del kernel y un reductor categórico explicable. Es causal y robusto, pero no competitivo con baselines simples.
