# Resultados de cross-feeding

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


| Conexión | Prueba | Veredicto | Información nueva |
|---|---|---|---|
| learning→transfer | C7H01 | PASS | la función aprendida reaparece en B para queries no usadas en training |
| fiber topology→capacity | C7H02 | PASS | K≥40 si destinos se separan; el overlap integra y destruye identidad separada |
| learning→matter | C7H03 | PASS acotado | el mismo linaje puede adquirir y conservar un repertoire nuevo |
| learning→repair | C7H03 | FAIL | direction-zero, load erasure y support destruction no se reparan tarde |
| observer→control | C7H04 | PASS one-pass | un record interno causa acción y retorno sin elección Python |
| resource→feedback | C7H04 | NEGATIVO reusable | soporte 6→1; aparatos consumidos |
| learning→external task | EXTRA02 | PASS causal/robusto | generalización multiclase no vista y tolerancia a daño |
| computation→baseline | EXTRA02 | FAIL competitive | histograma/reductor no supera kNN/logística |

El ranking de `DEPENDENCY_GRAPH.json` fue usado para ejecutar sólo conexiones que separaban hipótesis. Factorización, relatividad y quantum no se reabrieron porque ningún resultado cambió sus premisas operacionales.
