# Veredicto ejecutivo — CORE07

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


CORE07 encuentra un mecanismo nativo transversal real, pero sectorial: el **operador de fibras de destino con reducción guardada**. El estado relacional útil es un multigrafo dirigido de propuestas agrupado por destino, anotado por guardas, ocupación del destino, fuente y contexto de fase/historia; sus salidas continúan como linajes. En el sector normal fuente-libre y destino vacío, el cociente

`Z_f = (k, Σs_reg, sign(Σdirection))`

cierra exactamente, debajo del cap, los observables declarados: una fibra no vacía produce un soporte, suma `s_reg` con saturación y compone la dirección por signo; por ello cada colisión de `k` entradas contrae soporte en `k-1`. No es un Q4 global: fuentes, destinos ocupados, guardas semánticas/clock, procedencia de eventos y Q2/Q3 requieren anotaciones adicionales.

Resultados nuevos fuertes:

- **FUNCTIONAL_LEARNING_TRANSFER_CONFIRMED:** 48/48 transferencias exactas y 128/128 controles causales inexactos, con límite Wilson 95% de 0.9259.
- **DESTINATION_FIBER_CAPACITY_LAW:** 86/86 canales separados exactos hasta `K=40`; 8/8 solapamientos integraron las memorias y 0/8 preservaron identidad individual.
- **MATTER_REPROGRAMMING_FOUND**, en sentido operacional: 48/48 cambios funcionales exactos y 96/96 controles inexactos. La identidad preservada es un cociente de respuesta/linaje, no el microestado.
- **INTERNAL_ONE_PASS_FEEDBACK_CIRCUIT_FOUND:** 12/12 circuitos cerraron espacialmente, 28/28 controles fallaron; el soporte se contrajo 6→1, sin memoria ni actuadores reutilizables.
- **EXTRA02:** aprendizaje multiclase causal y robusto sobre `digits`, con 81.11% de accuracy estable bajo daño 10/64, 95.74% de retención y controles entre 1.11% y 12.22%. No es competitivo: kNN obtuvo 86.67% y regresión logística 83.06%.

La compresión teórica nueva es: **función = cociente de respuesta de un linaje; capacidad = separación relacional entre fibras; cómputo y recurso son dos caras del mismo reductor; el observador puede estar dentro de la cadena causal**.

Negativos conservados: no reparación genérica retardada, no ciclo fuente-libre reutilizable, no clasificador competitivo, no Q4 global, no nueva estructura Lorentz/luz, Bell permanece local con CHSH=-2, no termodinámica completa y ninguna Rosetta externa está validada.

Rosetta: `retardo relativo → coincidencia → lugar ordenado` permanece en **EXTERNAL_COMPATIBILITY**. Falta un dataset independiente a nivel de registro que una anatomía, retardo/fase monaural, best ITD/IPD, frecuencia característica y jerarquía animal/penetración; sin él no existe predicción externa válida.

Cierre: se agotaron las interrogaciones internas de alta información que dependían sólo de mecanismos ya demostrados. Las fronteras restantes requieren datos externos, nueva teoría, nuevo kernel o escala computacional; no se inventa CORE08.
