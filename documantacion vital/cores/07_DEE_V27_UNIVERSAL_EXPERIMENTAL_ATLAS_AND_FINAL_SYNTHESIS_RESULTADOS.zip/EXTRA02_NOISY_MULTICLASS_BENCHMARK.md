# EXTRA02 — Noisy Multiclass Topological Stress

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## Protocolo congelado

Dataset oficial scikit-learn digits, SHA-256 `09f66e6d...aa22`; 1797 imágenes únicas 8×8. Split estratificado determinista train/validation/final = 1078/359/360. Curriculum: 20 imágenes por clase. Encoder label-blind: pixel activo si intensidad≥8. Teacher: uno de diez puertos fijos durante training. Readout: argmax fijo; respuesta estable W=3. Daño primario: 10/64 píxeles a cero.

## FINAL TEST

| Métrica | Clean | Daño 10/64 |
|---|---:|---:|
| accuracy estable | 84.72% | 81.11% |
| balanced accuracy | 84.91% | 81.20% |
| macro F1 | 84.38% | 80.76% |
| stable-answer W=3 | 100.00% | 100.00% |

Retención: 95.74%. Controles: untrained/reset/memory-ablation/encoder-only 9.72%; no-teacher 9.44%; label-shuffle 1.11%; rewiring 12.22%. Todos los márgenes bootstrap preregistrados fueron positivos. La equivalencia kernel↔reductor analítico fue 100% en todas las corridas auditadas.

Baselines matched 20-shot: kNN-3 86.67%, logística multinomial 83.06%. Conclusiones: `CAUSAL_MULTICLASS_LEARNING_FOUND` y `ROBUST_MULTICLASS_CLASSIFIER_FOUND`; `COMPETITIVE_ARCHITECTURE_CANDIDATE=false`; `SUPERIORITY_CANDIDATE=false`.

No es una prueba de H_DEE. Es una demostración de capacidad de ingeniería causal con mecanismo explícito y no novedoso: acumulación categórica por fibras.
