# Frontera final de la etapa

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## EXTERNAL_DATA_REQUIRED

- Dataset row-level auditivo definido en `ROSETTA_MASTER.md` para probar delay/place sin leakage.
- Preparaciones y detectores físicos independientes para cualquier traducción materia/recurso.

## NEW_THEORY_REQUIRED

- Un cociente que comprima sources, semantic/clock guards, history y global basin dynamics sin reconstruir Q0.
- Una definición de ensemble y conjugación que vaya más allá de disipación sectorial.
- Una estructura operacional nueva antes de reabrir Lorentz o quantum.

## NEW_KERNEL_REQUIRED

- Plasticidad/autoreparación persistente que no pueda construirse con la contracción normal actual, si se quiere investigar ciclos adaptativos reusables.

## COMPUTATIONAL_SCALE_REQUIRED

- Estimar capacidad máxima más allá de K=40 sólo si aparece una ley de saturación o interferencia nueva; un sweep mayor no cambia el veredicto actual.
- Benchmarks externos mayores sólo después de una arquitectura que pueda superar el histograma/reductor simple.

## CLOSED_NEGATIVE

- Reparación tardía genérica en la clase normal probada.
- Ciclo reusable fuente-libre con el aparato C7H04.
- Competitividad/superioridad de EXTRA02 en el protocolo congelado.
- Reapertura de FactorX, Bell o moving-observer con el mismo mecanismo.

No queda una pregunta interna de alta información tratable con los mecanismos actuales sin repetir un aparato, escalar una cota ya decidida o introducir una nueva premisa. Esto cierra la etapa CORE actual; no afirma que DEE esté terminada.
