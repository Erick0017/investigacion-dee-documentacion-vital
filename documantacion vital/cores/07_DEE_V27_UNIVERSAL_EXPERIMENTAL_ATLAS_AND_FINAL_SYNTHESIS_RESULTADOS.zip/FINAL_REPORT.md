# Informe final — CORE07 Universal Experimental Atlas, Cross-Feeding and Final Synthesis

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## 1. Objeto y procedencia

Se verificaron por SHA-256 y se copiaron byte por byte CORE01–06 y EXTRA01. El wheel ejecutado fue `69297e6f...abc939`, el binario `.pyd` `0b17ba32...2c6ff` y el paquete Python `7e2991b1...df8b4`, bajo CPython 3.13 x64. Los padres permanecen inmutables dentro de `PARENTS/`.

El atlas normaliza **283 claims**, **25 capacidades**, **28 relaciones** y **25 testigos canónicos**. Las afirmaciones históricas se conservaron con su estado actual; un nombre histórico nunca sustituyó bytes, runner, resultado o holdout.

## 2. Ciclo científico nuevo

La prioridad fue probar el cross-feed entre capacidades ya separadas. Cada afirmación fuerte se descubrió en dominio diferente, se congeló en `HOLDOUT_LOCKS/`, se hasheó y se abrió una sola vez.

| Módulo | Pregunta | Resultado | Alcance |
|---|---|---|---|
| C7H01 | ¿se transfiere una función aprendida? | PASS: 48/48; 128/128 controles | transporte continuo por corredor, no teleportación |
| C7H02 | ¿qué controla capacidad/interferencia? | PASS: 86/86 separados; 8/8 fusiones | sector normal fuente-libre; K=40 es cota inferior |
| C7H03 | ¿materia operacional retiene una reprogramación? | PASS: 48/48; 96/96 controles | cociente funcional, no microidentidad ni materia externa |
| C7H04 | ¿puede cerrarse detector→memoria→acción→detector? | PASS: 12/12; 28/28 controles | circuito one-pass; no agencia ni ciclo reusable |
| EXTRA02 | ¿escala a diez clases con daño? | PASS causal/robusto; FAIL competitivo | histograma/reductor categórico supervisado |

## 3. Ley transversal

Para cada actualización se forma el grafo de propuestas `P_t: x→d`. Las entradas con destino común forman `F_d`; una guarda `g_d` incluye sector semántico, ocupación, source flag y contexto clock/fase/historia. El kernel aplica `ρ(F_d,g_d)` y las salidas forman linajes futuros. El candidato global es:

`Z_rel(t) = (P_t, {F_d}, {g_d}, lineages, sources, phase/history)`.

En destinos normales vacíos, fuente-libre y debajo de saturación, el subcociente `Z_f=(k,Σs,signΣd)` es exacto para soporte, `s_reg` y dirección. Esta ley explica simultáneamente integración de memorias, interferencia por solapamiento, suma nativa, contracción disipativa, registro de detector, transferencia de función y scores de EXTRA02.

La extensión no constituye cierre comprimido global. En el peor caso, conservar destinos, guardas, historias y linajes puede aproximarse en complejidad a Q0. Por eso el veredicto correcto es **RELATIONAL_CLOSURE_EXTENDED_CROSS_DOMAIN + NO_GLOBAL_Q4**.

## 4. Aprendizaje, función y materia

CORE06 ya demostró plasticidad asociativa, generalización por clase, traducciones enteras y composición en dominios acotados. CORE07 añade una propiedad cualitativamente distinta: el repertoire aprendido puede viajar por relays y reaparecer en B ante queries nuevas. La intervención sobre corredor, fuente, dirección, carga o memoria destruye la respuesta esperada.

La misma construcción permite reprogramar una entidad operacional sin reconstruirla: una experiencia cambia su respuesta futura de `R0` a `R1` y el cambio persiste al transporte y a nuisances de estado/clock. Sin embargo, borrar soporte, carga o dirección no fue reparado por un scaffold tardío. Hay materia funcional reprogramable, no materia auto-reparadora en la clase probada.

## 5. Procesamiento externo EXTRA02

Se usó el `load_digits` oficial: 1797 imágenes 8×8, sin duplicados exactos. El split estratificado 60/20/20 y sus hashes se congelaron. Veinte ejemplos por clase alimentaron diez teacher ports mediante interacciones DEE normales; el encoder umbraliza intensidades sin labels y el readout es argmax fijo.

En FINAL TEST de 360 imágenes: clean=84.72%; daño cero en 10/64=81.11%; balanced=81.20%; macro-F1=80.76%; estabilidad W=3=100%; retención=95.74%. Los 15,120 calls reales del kernel reprodujeron exactamente el score analítico del reductor.

Los controles obligatorios colapsaron y sus intervalos bootstrap quedaron por debajo del efecto. Pero kNN y logística, con los mismos veinte ejemplos/clase, obtuvieron 86.67% y 83.06%. La arquitectura demuestra aprendizaje causal DEE y robustez, no superioridad computacional ni evidencia de H_DEE.

## 6. Recursos y circuito interno

La reducción many-to-one consume soporte: en C7H04, seis carriers preconfigurados producen un registro final y dejan cero memoria/actuadores. El circuito contiene sensing, memoria, acción y retorno dentro de DEE, sin decisión Python durante la evolución, pero no puede iterar sin fuente o nueva inyección. `s_reg` lleva un accounting exacto en el sector, pero no se identifica con energía física.

## 7. Ramas condicionales

- FactorX: no reabierto; no surgió operador iterativo/modular nuevo que supere la genealogía trial-division-like.
- Propagación: se heredan `c_transport=1` y radio raw ≤3. La transferencia usa carriers continuos y no aporta un modo/clock/ruler nuevo; no hay Rosetta de luz.
- Quantum: no cambiaron settings, factorización ni normalización. CHSH=-2; estructura formal solamente.
- Termodinámica: avanzó el accounting y la disipación sectorial, pero faltan estacionariedad universal, variable conjugada, fluctuación y ciclo reusable.
- Rosetta: se renovó la búsqueda; sólo permanece compatibilidad externa del candidato delay/place.

## 8. Revisión adversarial

La revisión única obtuvo `PASS_WITH_SCOPE_CORRECTIONS` y no exigió rerun. Confirmó hashes de locks, ausencia de uso del FINAL TEST durante discovery, unidad estadística correcta y controles causales. Impuso el lenguaje conservador de este informe: el clasificador simple explica la eficacia externa; “materia”, “observador” y “feedback” son categorías operacionales; ninguna correspondencia física está validada.

## 9. Stopping rule

Se adjudicaron todas las conexiones de prioridad máxima y EXTRA02. Reabrir relatividad, quantum o factorización sin una nueva premisa repetiría aparatos negativos. Escalar K sólo aumentaría una cota inferior ya decidida; mejorar el clasificador exigiría una arquitectura nueva, no un sweep. La Rosetta requiere datos externos inexistentes. CORE07 cierra esta etapa con fronteras explícitas, no con una afirmación de que DEE esté terminada.
