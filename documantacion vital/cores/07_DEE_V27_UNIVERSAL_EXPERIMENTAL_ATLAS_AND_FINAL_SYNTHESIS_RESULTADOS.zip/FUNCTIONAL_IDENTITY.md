# Identidad funcional

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


Definición operacional: dos realizaciones son equivalentes respecto de un probe set Q si producen el mismo `R:Q→outputs` dentro de tolerancia y bajo nuisances congelados. C7H01 muestra que esta identidad puede sobrevivir a relay/translation; C7H03 muestra que puede cambiar por experiencia sin reconstrucción externa; C7H02 muestra que colisionar dos identidades en una misma fibra produce una identidad compuesta y elimina la lectura individual.

Así, la identidad DEE útil tiene tres componentes: continuidad causal del linaje, repertoire de respuesta y dominio de probes. No es identidad de bits, alma de partícula ni conservación global. Esta formulación comprime aprendizaje, transferencia y materia operacional con un solo objeto.
