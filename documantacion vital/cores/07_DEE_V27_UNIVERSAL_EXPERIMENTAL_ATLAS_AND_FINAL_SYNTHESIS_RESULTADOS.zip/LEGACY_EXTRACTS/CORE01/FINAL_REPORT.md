# Informe final — descubrimiento nativo y cierre DEE v27

## 1. Veredicto

DEE v27 contiene una arquitectura matemática transversal interna, reproducible y específica del kernel. El objeto natural no es `occupancy` aislado, sino un campo raw etiquetado y dirigido, acoplado a una fase clock: **soporte + flechas + carga/procedencia + controles semánticos + fase congelada**. Esta descomposición explica con un mismo vocabulario la reacción local, el transporte, las colisiones, la procedencia/overflow, los invariantes, la causalidad y las excepciones sectoriales de reversibilidad.

También existe una clase móvil exacta para `N>=5`. Un singleton normal con dirección Moore no nula se traslada un voxel por tick, conserva `s_reg` y dirección, tiene período raw `N` y una dispersión advectiva exacta. Un gas con dirección común y separación Chebyshev toroidal por pares al menos 3 se traslada rígidamente. Las colisiones de dos fuentes aisladas obedecen un reducer conmutativo pero disipativo. No se identificó masa inercial: la velocidad no depende de `state` ni de `s_reg`, y la composición direccional no está ponderada por carga.

Ninguno de estos resultados constituye todavía una equivalencia con nuestra física. Falta una Rosetta operacional, congelada y externamente validada que asigne preparaciones, coarse-graining, observables, probabilidades y unidades a resultados físicos independientes. Esa pieza no puede inferirse sólo interrogando otra vez el mismo mapa finito.

## 2. Procedencia y reanudación

La ejecución se reanudó desde `DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK`; no se creó otra versión ni se reinterpretó el agotamiento de créditos como un resultado. `STATE.json`, `RUN_LOG.ndjson`, timestamps, hashes, artefactos de análisis y runners permitieron reconstruir el estado real.

La inspección forense registró 8,922 originales y 3,418,485,589 bytes. `INVENTORY.csv` tiene SHA-256 `00d8334e68ce0877fee93c2805621e87aeb0f14caaa9f84d8c0712e7cc002d94`. Ningún original fue modificado. Se reutilizaron extracciones, manifiestos, hashes y campañas ya verificables; sólo se ejecutaron probes que podían cambiar conclusiones centrales.

## 3. Identidad del objeto ejecutado

| Objeto | SHA-256 / versión | Resultado |
|---|---|---|
| wheel `dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl` | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` | Localizado y sellado |
| kernel `.pyd` | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` | Importado y ejecutado |
| fuente C++ en wheel | `44a80f7863d78f596099ddf7d41c9947fa8513503f65067097f1f3b05a8207ab` | Coincide con `RECORD` |
| package Python | `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4` | Auditado |
| runtime | CPython 3.13.11 x64, NumPy 2.2.6 | Compatible con `cp313-win_amd64` |
| `version()` del binario | `DEE Universe Kernel v27.0-PKCANON (v26-SYM1 fork; canonical P_KERNEL=19665)` | Autoridad dinámica |

La ejecución usó `-I -B` e importación desde una extracción hash-verificada, evitando otra instalación global. El binario usa `P_KERNEL=19665` y cap 19664. El wrapper publica 19658, conserva metadata obsoleta, devuelve timing cero y tiene métodos de alto nivel rotos; esas discrepancias son de API, no cambios del kernel ejecutado.

Los teoremas se aplican a invocaciones válidas: `N` entero positivo; cuatro buffers `uint64` C-contiguos, escribibles, con al menos `N^3` elementos y regiones relevantes disjuntas; tamaño/indexado representables; y `n_hilos>=1` para dense.

## 4. Método científico y grafo de dependencias

La secuencia real fue:

```text
identidad wheel/binario
  -> contrato ABI y regla fuente
  -> T1–T6, alcance causal, clocks, invariantes y simetrías
  -> clase móvil y modos
       -> T8 congelado -> transporte, Fourier, gas y colisiones
  -> semantic/control causal
       -> T9 congelado -> observer pump
  -> auditoría de campañas/documentos
       -> corrección TORUS_MOVING/v25.5-C y sesgo D6
  -> teoría nativa + auditoría adversarial
  -> límites físicos, stopping rule y paquete reproducible
```

Se priorizaron preguntas por capacidad de falsar afirmaciones amplias y desbloquear varias ramas. T8 y T9 se preregistraron antes de ejecutar sus holdouts; fórmula, dominio, criterios y hashes quedaron congelados. No hubo refit después de observar resultados. La réplica balística independiente partió de una reducción estática separada y no reutilizó el resultado primario.

No se lanzaron sweeps morfológicos ciegos: Part-D ya contiene 189 mundos y su repetición no cambiaba el árbol. Tampoco se repitieron extracciones documentales ni ZIP. El análisis D6 reutilizó el JSON primario y aplicó un control metodológico corto.

## 5. Clasificación epistemológica

### 5.1 Teoremas exactos de `F_DEE`

En el dominio ABI declarado se prueban:

1. `clock_i(t)=clock_i(0)+t mod 2^64`; las diferencias de clock son invariantes.
2. El raw sólo usa las cadencias causalmente activas 195, 260, 391 y 782; su LCM mínimo es 304,980 para prefijos pareados sin wrap. No es simetría del full-state.
3. La manta raw de un tick tiene radio Chebyshev máximo 3, y la cota es aguda para tamaños suficientemente grandes; por composición, `r(t)<=min(3t,diametro_infty)`.
4. Las traslaciones de `Z_N^3` son equivariancias exactas. Dense/lazy y todo número positivo de hilos implementan el mismo mapa.
5. La rama de cristalización por gradiente es inalcanzable: `grad_mag<=983,025`, mientras el umbral exige 18,996,390.
6. La regla base pre-DEMUX de soporte se decide por conteo Moore y firma tetraédrica. Un delta posterior puede reactivar un sitio cuya salida base fue cero.
7. `F_DEE` no es inyectiva; un testigo explícito usa singletons state 1 y 2 sin carga/dirección.
8. Cada raw `semantic=4` queda fijado y no se crea internamente. Esto induce una familia de invariantes aditivos de rango 0.
9. Para `N>=5`, el singleton normal con dirección Moore no nula es un sector balístico exacto y su Fourier obedece `rho_hat_m(t+1)=exp(-2pi i m·d/N)rho_hat_m(t)`.
10. Para `N>=5`, configuraciones de tales singletons con dirección común y separación Chebyshev toroidal por pares al menos 3 forman un sector invariante de traslación/permutación.
11. En un blanco raw-cero con XNOR falso, múltiples fuentes entrantes producen, antes de `aplicar_demux`, una salida base state/semantic 1, carga capada y `sign(sum d)`. Sólo es la salida final si no llega otro delta overflow; dos singletons aislados con `N>=5` satisfacen esas condiciones.
12. Para `N>=5`, un observer con dirección Moore no nula genera, en el aparato aislado y sólo para `1<=t<N`, un tren de paridad alterna; dirección cero no lo hace.
13. Los toros completamente ocupados state 3, dirección cero y semantics preservables forman una familia de puntos raw fijos para cualquier distribución de `s_reg`.
14. El grupo cúbico completo no es simetría global: un empate overflow rompe inversión. Esto no clasifica todo el grupo de simetría.
15. Para un paso en `y`, raw `B3(y)` y clocks `B1(y)` son suficientes. Occupancy no lo es.

Las pruebas completas y sus caveats están en `EXACT_THEOREMS.md`; una auditoría adversarial independiente corrigió el dominio y cinco formulaciones antes de su promoción.

### 5.2 Hechos computacionales

- El probe ABI ejecutó el binario sellado, comprobó wrap, períodos activos, testigo causal de radio 3, no-inyectividad, equivalencia de motores y anisotropía overflow.
- T8 pasó H8.1–H8.6: 1,872 trayectorias primarias, 50,544 ticks, 624 ciclos raw, 2,704 cocientes Fourier, 624 comparaciones de variantes, 12 casos de dos cuerpos y 1,300 colisiones, cero mismatches. El error Fourier máximo fue `5.36e-15`.
- La réplica independiente pasó 624 trayectorias, 16,848 ticks, 36 runs de dos portadores, 15,600 colisiones en cuatro implementaciones y 10,816 cocientes Fourier, cero mismatches; error máximo `7.75e-15`.
- T9 pasó 936 casos factoriales, 208 comparaciones de ejecución y 18 controles durante 12,782 ticks, cero mismatches.
- La auditoría de 17 ZIP verificó directorios/CRC; 11 manifiestos JSON concuerdan con 8,512 miembros y 139 hashes muestreados.
- D6 reportó 300 picos; 284 están en bins 1–5 y 56/60 señales ordenan exactamente esos cinco bins. Seis controles no periódicos reproducen `T/j`.

### 5.3 Leyes nativas empíricas

T8 y T9 son confirmaciones prospectivas de leyes cuya universalidad en el dominio se apoya además en prueba por ramas. Empíricamente, también sobreviven la equivalencia dense/lazy, los antecedentes v25 de traslación y la mediación causal interna de V7-C. Se las denomina leyes nativas porque predicen ejecuciones DEE; no son leyes de la naturaleza sin Rosetta.

### 5.4 Resultados negativos

Quedan descartados globalmente para v27: cono radio 1, inyectividad, simetría cúbica completa, cristalización alcanzable, suficiencia causal de occupancy y ausencia universal de invariantes rango 0. Quedan descartadas sólo en sus aparatos: las relaciones simples de V7-A/B, el paquete de V6-D, el modo de C7 y la familia completa de V6-F. Los fallos técnicos A6/C4 no son ciencia.

### 5.5 Propiedades genéricas y estructuras específicas

Son genéricas: eventual periodicidad de un mapa finito, basins formales, etiquetado de ciclos y un Koopman unitario para una permutación. Son específicas de v27: tetra/XNOR, umbrales 6/16/26, reducer de flechas, cap 19664, gates 195/260/391/782, observer/orphan, tie lexicográfico, sector T8 y pump T9.

### 5.6 Hipótesis, puentes y no identificables

- Hipótesis de emergencia: otros modos interactuantes, cargas relacionales/topológicas, separación de escalas y coarse-graining hidrodinámico. Permanecen abiertos, no afirmados.
- Puente exacto condicionado: el sector sin colisiones es advección/lattice gas discreto y admite continuidad de densidad/corriente.
- Correspondencias externas: masa, energía, temperatura, métrica, quantum, gauge y constantes SI siguen sin validación.
- `NO_IDENTIFICABLE`: las preguntas que requieren elegir preparación física, ensemble, observable/unidad o datos externos y no pueden resolverse desde el kernel solo.

## 6. Arquitectura nativa

### Soporte/reacción

`exists=1[state>0]` y `alive_for_rule=1[state>0 and semantic!=5]` son máscaras distintas. La salida base de un sitio activo depende de densidad Moore y tetraedros. Vacíos pueden nacer por XNOR o routing. Como routing lee dirección aun si `state=0`, occupancy pierde causas.

### Flechas/transporte

`direction` es un puntero de copia hacia un vacío Moore. En el singleton se convierte exactamente en velocidad. Fuentes múltiples se combinan con suma de cargas y signo vectorial; no conservan número de portadores ni magnitud direccional.

### Carga/procedencia

`s_reg` viaja sin cambio en vuelo libre, se suma hasta 19664 en colisiones, se incrementa en supervivencia según fase y activa overflow desde 19665. Su gradiente puede reorientar materia superviviente. Son varias funciones computacionales, no una energía única derivada.

### Semantic/control

`semantic=4` es un defecto/boundary fijado que puede inyectar; `semantic=5` no cuenta como activo y recibe un payload al ser impactado; 7 marca XNOR; routing normaliza a 1. Los nombres no autorizan ontología física.

### Clock/fase

El clock es una rotación modular independiente. Sus diferencias son desorden congelado de fase; sólo algunos residuos alteran raw. No es tiempo SI ni gauge físico establecido.

## 7. Respuestas físicas

### Materia y modos

La clase material operacional mínima demostrada es el portador direccional singleton y sus gases separados: tiene identidad raw, posición `q`, velocidad, persistencia y regla de colisión. No toda ocupación es materia, y un observer o una fase densa fija pertenece a otra clase. Existe un modo de transporte exacto, no todavía un modo colectivo interactuante universal.

### Masa e inercia

No hay parámetro inercial identificado. En T8 todas las cargas/estados positivos convergen a la misma velocidad discreta, y la colisión no pondera dirección por `s_reg`. Falta una intervención force-like, aceleración y una ley cruzada que prediga respuesta y colisión.

### Geometría y causalidad

La geometría primaria es el toro combinatorio con stencil Moore y un grafo temporal de dependencias dependiente de la rama. La velocidad causal máxima es tres voxels raw por tick; el portador común viaja a uno. V7-C mide first-passage sensible a organización/historia/topología en su aparato. No hay métrica dinámica, curvatura ni gravedad derivadas.

### Materia–geometría

Ahora hay materia móvil sectorial y evidencia de mediación por sustrato, pero no se midieron `M_I` y `M_G` de la misma clase con definiciones independientes. La equivalencia permanece no identificada, no refutada para toda emergencia posible.

### Termodinámica e hidrodinámica

Hay balances exactos restringidos y una continuidad de vuelo libre. En colisiones aparecen pérdida de portadores, saturación y fuentes/sumideros. Faltan energía/temperatura operacionales, ensemble estacionario, equilibrio, producción entrópica, variables lentas, stress y cierre. Las entropías de occupancy son informacionales, no termodinámicas por nombre.

### Quantum y Bell

La unitariedad Koopman sectorial es genérica a una permutación y no aporta Hilbert físico, composición, observables ni Born. CHSH≤2 sólo se sigue tras definir settings/outcomes/lambda e imponer independencia, factorización según el cono correcto y muestreo sin postselección. No existe ese aparato DEE, por lo que Bell es condicional/no instanciado.

### Simetría y gauge

Las traslaciones son exactas; `O_h` global es falso por el tie overflow, aunque aparece en sectores que no lo excitan. El cociente de fase del clock preserva raw en prefijos sin wrap, pero no el full-state ni define una transformación gauge local con conexiones/cargas.

### Constantes

19665/19664, 782 y 194422 son literales/inputs internos; 391 es contextual; 966 está compilado pero inalcanzable. `alpha`, `Delta_nu` y 20 Hz forman parte de una genealogía constitutiva/externa. Ninguno es hoy una constante natural predicha independientemente por el kernel.

## 8. Auditoría de Claude T1–T7

| Tesis | Adjudicación |
|---|---|
| T1 | `REFUTED`: cota correcta raw ≤3t, aguda en un tick. |
| T2 | `PROVEN_MODULAR`: clock `+1 mod 2^64`. |
| T3 | `CONDITIONAL_SHARPENED`: 1,094,573,220 funciona sin wrap; mínimo causal raw 304,980; no full-state/gauge global. |
| T4 | `REFUTED`: familia observer de invariantes rango 0. |
| T5 | `PROVEN_CORRECTED`: no-inyectividad por testigo state 1/2; no colapso de todos los raws. |
| T6 | `PARTIAL`: traslaciones y reducer exactos; `O_h` global falso. |
| T7 | `CONDITIONAL_NOT_INSTANTIATED`: premisas Bell no construidas ni auditadas. |

Claude no se usó como autoridad. Cada dictamen proviene de fuente v27, binario, runner o telemetría. Las transferencias desde v25 se auditaron por mecanismo y versión.

## 9. Descubrimientos nuevos y correcciones históricas

1. **Generalización balística v27:** T8 formaliza las 26 direcciones, carga, estados, fase, Fourier, gas y álgebra completa de dos fuentes.
2. **Antecedente recuperado:** `TORUS_MOVING` y v25.5-C ya contenían instancias de traslación exacta. T8 no es la primera observación histórica; es la confirmación prospectiva exhaustiva localizada en v27.
3. **Observer pump:** semantic 4 es un control fijo/inyector, no medición.
4. **Objeto causal suficiente:** raw `B3` + clock `B1`; occupancy puede omitir una flecha causal con state cero.
5. **Período mínimo:** 304,980 reemplaza el LCM sintáctico no mínimo como cociente raw causal sin wrap.
6. **Sesgo D6:** las escalas reportadas son bins de ventana reproducibles por señales no periódicas.
7. **Cristalización muerta y anisotropía:** una rama nombrada físicamente nunca corre, mientras un detalle de orden de iteración rompe una simetría global.

## 10. Pieza exacta faltante bajo `H_DEE`

Se requiere un único objeto experimental externo, congelado antes de los targets:

`R:(distribución de preparaciones DEE, coarse-graining causalmente suficiente, observables, probabilidades, unidades) -> resultados físicos operacionales`.

`R` debe calibrarse sin target leakage y predecir, con incertidumbre, holdouts externos en al menos dos sectores independientes. La misma construcción debe producir energía–momentum efectivo, un límite espaciotemporal Lorentz-compatible y una teoría de medición/Born/Bell operacional. Sin `R`, el kernel no decide qué estado representa el vacío real, qué tick o voxel son unidades SI, qué ensemble es físico ni qué raw corresponde a un resultado de laboratorio.

## 11. Stopping rule

Se cerraron todas las interrogaciones locales cortas capaces de cambiar el veredicto central: identidad, API, T1–T6, clocks/wrap, movilidad, Fourier, gases, colisiones, semantic observer, sesgo de occupancy, sesgo D6 y genealogía móvil. Las preguntas internas infinitas —clasificación total de invariantes relacionales, basins o universalidad— no admiten agotamiento por un sweep finito y no pueden por sí solas resolver la equivalencia externa. Las preguntas físicas restantes requieren `R` y datos externos. Continuar con variaciones aleatorias del kernel ya no discriminaría las conclusiones principales.

Por ello la misión alcanza cierre razonable: **teoría interna específica, resultados exactos y prospectivos positivos, negativos correctamente acotados y obstáculo externo definido; Rosetta física aún no identificada**.

## 12. Mapa del paquete

- `EXECUTIVE_VERDICT.md`: respuesta compacta a todas las preguntas centrales.
- `NATIVE_DEE_THEORY.md`: teoría matemática nativa.
- `EXACT_THEOREMS.md`: teoremas, pruebas y dominios.
- `CLAIM_LEDGER.csv/json`: adjudicación trazable por claim.
- `CLAUDE_AUDIT.md`: T1–T7.
- `HISTORICAL_CLAIMS_AUDIT.md`: campañas, documentos y correcciones de linaje.
- `NEGATIVE_RESULTS.md`: negativos con dominio.
- `OPEN_EXTERNAL_GAPS.md`: abiertos y Rosetta faltante.
- `EXPERIMENT_INDEX.csv`: índice de ejecuciones/reutilizaciones.
- `REPRODUCE.ps1`: verificación y rerun local de T8/T9.
- `MANIFEST.json` y `HASHES.sha256`: integridad del paquete.
