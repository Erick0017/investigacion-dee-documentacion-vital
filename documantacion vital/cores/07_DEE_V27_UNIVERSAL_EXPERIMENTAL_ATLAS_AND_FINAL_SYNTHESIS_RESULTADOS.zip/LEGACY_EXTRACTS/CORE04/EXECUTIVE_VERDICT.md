# Veredicto ejecutivo — Campaña 04 DEE v27

## Resultado

La campaña alcanza `HIGHER_HIERARCHY_AND_SCALE_LAW_FOUND`, `MULTIPLE_SECTOR_STRUCTURE` y `EXTERNAL_EMPIRICAL_FRONTIER`.

Sí existe una arquitectura transversal específica de DEE. El conjunto pequeño

`S/R/C/X/D -> A_t -> Gamma`, junto con `kappa` y actividad dirigida `a`,

une causalidad microscópica, geometría de soporte, reproducción, historia, basins y escala. La ley exacta es

`P_(t+1)=S+R+C+X`, `A_t=P_(t+1)/P_t`, `Gamma=Σ log A_t`.

Q3 existe como clase predictiva de historias productivas en un dominio certificado: en NSH07, `Gamma>0` y, por separado, `bar_kappa<=5.60 AND bar_a>=0.50` predijeron 30/30 mundos nuevos, con sensibilidad, especificidad y BA iguales a 1 en `N={28,36,44}` y dos familias. Ningún parámetro se refitió.

Q3 no es un estado autónomo ni universal. Con actividad muy escasa, `Gamma` fue positivo en mundos que no llegaron al basin; los conteos críticos dependieron de N y orientación. El flujo `(q,kappa)` pasó predicción one-step pero falló composición recursiva. Por ello no hay `SCALE_CLOSURE` ni Q4 demostrados.

## Qué construyen conjuntamente los grados

No construyen una sola sustancia por voxel. Construyen propuestas dirigidas, supervivencia, fuentes, colisiones y nacimientos sobre una geometría combinatoria. Su organización produce factores de reproducción; su acumulación define histories; las histories, junto con interfaz y actividad, seleccionan basins colectivos.

La mejor definición operacional de “materia DEE” es sectorial: linajes/portadores dirigidos y procesos de soporte activo organizado. Occupancy sola no es materia ni estado causal suficiente.

## Conservación y modos

Se heredan invariantes exactos de diferencias clock, cargas sobre observers persistentes, traslaciones y conservaciones de sectores de vuelo libre. La Campaña 04 añade balances exactos de soporte y un cociclo temporal. No existe conservación global de positive support, energía o momentum. Hay modos balísticos/Fourier exactos en sectores libres y regímenes colectivos densos/no densos; no se confirmó un modo hidrodinámico interactuante universal.

## Rosetta

Los mejores puentes son formales:

- `B6/kappa` ↔ edge perimeter/specific surface cúbico;
- `A/Gamma` ↔ crecimiento multiplicativo/log-aditivo finito;
- mapa local `(q,kappa)` ↔ clase monomial GLV/logística, con target fuerte fallido.

Support no es contact process autónomo y routing no es transporte conservativo. Dispersión, response, espectro y termodinámica no tenían los grados operacionales necesarios para abrir targets nuevos sin fabricar observables. Mayor estado: `FORMAL_EQUIVALENCE_CANDIDATE`; no hay `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED`.

## Física conocida

- Masa/inercia: no identificada.
- Materia–geometría: arquitectura relacional sí; equivalencia física no.
- Termodinámica/hidrodinámica: balances y sectores sí; ensemble/cierre/constitutivas no.
- Quantum/Bell: no hay Born, measurement algebra ni aparato CHSH DEE.
- Simetría/gauge: traslaciones exactas; `O_h` global roto; clock no es gauge global.
- Constantes: literales y thresholds internos no son constantes naturales.

## Claude e historia

Se preserva la auditoría del padre: T1 refutada y corregida a cono raw `<=3t`; T2 modular probada; T3 condicional y período raw mínimo 304,980 sin wrap; T4 refutada por invariantes observer; T5 probada con testigo corregido; T6 parcial; T7 condicional no instanciada. Ningún resultado de Campaña 04 revierte esto.

Los negativos históricos de occupancy, modos de grupo o cargas de bajo rango permanecen acotados a sus representaciones. La Campaña 04 confirma precisamente que un FAIL de geometría sola no elimina una ley conjunta geometría–actividad.

## Pieza exacta faltante bajo H_DEE

Falta un diccionario externo congelado:

`preparación física -> ensemble DEE -> coarse history -> forward detector -> distribución observada`,

con calibración dimensional independiente y predicción de varios observables en holdout. El kernel local no puede identificar ese mapa. Ésta es una frontera empírica, no un FAIL ontológico de `H_DEE`.

