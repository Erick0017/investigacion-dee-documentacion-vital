# Informe final — Campaña 04: escala nativa y búsqueda Rosetta DEE v27

## 1. Veredicto científico

La cuarta campaña no repitió los padres sellados. Interrogó directamente el wheel v27 y llegó a una extensión real de la jerarquía:

- `Q0`: microestado exacto `X=(raw,clock)`;
- `Q1`: roles causales/eventos y, ahora, balance exacto `S/R/C/X/D`;
- `Q2`: organización colectiva de basin expresada por cartas predictivas acotadas;
- `Q3`: clase de histories productivas, confirmada prospectivamente en un dominio transversal;
- `Q4+`: no demostrado.

Estado de cierre: `HIGHER_HIERARCHY_AND_SCALE_LAW_FOUND`, `MULTIPLE_SECTOR_STRUCTURE`, `EXTERNAL_EMPIRICAL_FRONTIER`. No se alcanza `SCALE_CLOSURE_FOUND` ni una Rosetta física validada.

## 2. Provenance

Se verificaron antes de la ciencia:

| Objeto | SHA-256 |
|---|---|
| Wheel v27 | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` |
| Binario importado | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` |
| Experimento 01 | `06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4` |
| Experimento 02 | `4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058` |
| Experimento 03 | `553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640` |

El import real apuntó al `.pyd` hash-pinned extraído del wheel; CPython 3.13 x64 y un thread. Los padres no se modificaron ni reejecutaron completos.

## 3. Secuencia adaptativa

1. NSD01 descubrió nacimiento enrutado exacto, balance y no suficiencia del inventario.
2. NSH01 hizo FAIL literal de la interfaz temprana.
3. Análisis temporal produjo `bar_kappa`; NSH02 lo confirmó 72/72.
4. NSD03 derivó `P_next=S⊔C⊔X⊔R` y realizó intervenciones spatial/clock.
5. NSH03/04 fallaron dos leyes de profundidad de basin.
6. NSD05-08 descubrieron dos sectores y el mapa local de seis coeficientes; NSH05 lo confirmó one-step.
7. NSD09 derivó el factor exacto de reproducción; NSD10-12 refutaron semigrupo/generadores.
8. R04-T01..T03 probaron geometría, balance/transport y flujo cerrado.
9. NSH06 hizo FAIL de la generalización geométrica a bloques compactos.
10. NSD13 incorporó actividad y cociclo; NSH07 confirmó `Gamma` y puerta activa 30/30.
11. NSD14-16 delimitaron la ley con dosis escasa y cerraron la rama tras tres ciclos informativos.
12. R04-T04 aplicó una diana congelada de crecimiento multiplicativo; sólo equivalencia formal.

Cada holdout tenía lock y SHA previo. Los FAIL se conservaron, y un resultado inesperado sólo creó una hipótesis posterior.

## 4. Clasificación epistemológica

### Teoremas exactos de F_DEE

- `raw+clock` es estado Markov completo.
- clock avanza `+1 mod 2^64`; diferencias modulares son invariantes.
- cono causal raw global `r_infinity<=3t`.
- traslaciones exactas; `O_h` global no.
- no inyectividad global por testigo.
- familia de invariantes rango cero sobre semantic-4 persistente.
- nacimiento en destino enrutado elegible.
- en cero overflow, `P_next=S⊔C⊔X⊔R` y su balance de conteo.
- composición exacta de factores `A_t` y suma de `Gamma`.

### Hechos computacionales

- 13 pares de inventario conjunto idéntico terminaron en basins opuestos por organización.
- shuffle espacial cambió 7/10 precursores densos; clock-only cambió 0/18 en NSD03.
- bloques compactos matched responden causal y monotónicamente al número de routers, con threshold contextual.
- todos los resultados y casos promovidos tienen hashes canónicos y auditorías de identidad.

### Leyes nativas empíricas

- `bar_kappa<=5.60` en el dominio nested-shell NSH02: 72/72.
- mapa local sectorial NSH05 a lag `N/8`: PASS acotado.
- `Gamma>0` en dominio NSH07: 30/30.
- puerta `(bar_kappa<=5.60,bar_a>=0.50)` en NSH07: 30/30.

### Propiedades genéricas

La telescopía de cocientes y una representación Koopman de una permutación son genéricas; por sí solas no prueban física específica. Edge perimeter es geometría de red estándar. La especificidad DEE reside en sus guards, roles `S/R/C/X`, propuestas, colisiones, saturación, semantic y dominios predictivos ejecutados.

### Hipótesis y no identificables

Una representación causal de grafo/destinos podría cerrar mejor que escalares; no está demostrada. Masa, energía, métrica, temperatura, Born y unidades SI requieren un puente externo y son `NO_IDENTIFICABLE` desde el kernel solo.

## 5. Arquitectura transversal

Sí existe. La arquitectura mínima actualmente explicativa es:

`(raw,clock) -> guards/proposals -> (S,R,C,X,D) -> A_t -> Gamma`,

con `kappa` describiendo organización espacial y `a` disponibilidad de acción dirigida. Explica:

- por qué occupancy pierde causas;
- cómo nace y muere support;
- por qué inventario no fija el basin;
- por qué geometría sola falla en bloques stationary;
- por qué una history corta predice basins en un manifold amplio;
- por qué el flujo local no se vuelve autónomo al omitir destinos/multiplicidad.

No es una teoría de todo DEE. Es específica, reproducible y falsable en los dominios declarados.

## 6. Mecanismo causal mínimo de Q2

El resultado conjunto más fuerte es `retención + acción + geometría de destino`:

- `P/S` aporta soporte sobreviviente;
- `R` aporta colonización causal;
- `kappa` aporta interfaz/compactación;
- `a` aporta fracción capaz de actuar;
- multiplicidad/destinos determina colisión y compensación;
- `Gamma` integra el balance realizado.

Necesidad/suficiencia es contextual. Direction puede cambiar Q2 a soporte, `s_reg`, semantic y clock fijos; spatial shuffle puede destruirlo conservando inventario. Pero una cantidad mínima universal de direction no existe en el panel. La representación mínima definitiva probablemente requiere grafo de destinos, no sólo cuatro escalares.

## 7. Escala, cierre y niveles superiores

Q3 está demostrado porque ofrece compresión extrema, mejora predictiva, generalización a nuevos N/preparaciones y una ley exacta entre niveles. Es una clase de history, no un estado instantáneo.

No existe cierre autónomo:

- el mapa local de `(q,kappa)` falla al recursar;
- generadores continuo/logit fallan cross-N;
- microintervenciones de direction cambian el futuro a macrocoordenadas similares;
- histories de crecimiento positivo pueden divergir en basin.

Así, el cambio de escala posee un cociclo exacto pero no un RG fixed point identificado. Q4 no se crea por clustering.

## 8. Conservaciones, balances y modos

Existen invariantes exactos globales de fase relativa clock y cargas observer, además de traslaciones. En sectores libres se conservan conteo de portadores, direction, `s_reg` transportado y configuración relativa; allí hay modos Fourier/advección exactos. Colisiones cumplen suma saturada `s_out=min(sum s_j,19664)` y reducción direccional por signo, lo que impide interpretarlas como momentum aditivo general.

La Campaña 04 añade balance exacto de support y cociclo de reproducción. No hay conservación global de `P`; nacimientos, muertes y fuentes son explícitos. Tampoco se demuestra energía, entropía termodinámica o corriente hidrodinámica global.

## 9. Qué son realmente los campos

- `raw`: registro causal empaquetado, no observable físico único.
- `state/support`: existencia/supervivencia y parámetro de orden útil; no materia universal.
- `direction`: propuesta de destino y velocidad sectorial; no momentum.
- `s_reg`: carga/procedencia multifunción con transporte, suma saturada, incremento y overflow; no energía identificada.
- `semantic`: control de ramas y fuentes/boundaries; no “significado” físico.
- `clock`: fase modular que controla guards; no tiempo SI.

La “materia DEE” operacional es una familia de portadores/linajes y procesos colectivos activos. Dense support, observers y routers latentes no deben colapsarse en una sola clase material.

## 10. Geometría y causalidad

La geometría real demostrada es:

- toro cúbico periódico;
- stencil Moore;
- edge boundary `B6`;
- grafo dirigido de propuestas dependiente del estado;
- first-passage dependiente de organización/historia/topología;
- cono causal raw máximo tres celdas Chebyshev por tick.

No se deriva espacio-tiempo físico, métrica dinámica, curvatura, equivalencia materia–geometría ni Lorentz. `B6` ofrece una equivalencia geométrica formal exacta, no gravedad.

## 11. Rosetta y teorías efectivas

La Rosetta interna es cuantitativa y no arbitraria. La Rosetta externa no está identificada.

Sobreviven dos equivalencias formales exactas: perímetro específico cúbico y cociclo de crecimiento finito. La clase reacción/colonización es estructural; el mapa GLV es sólo local. No surge una teoría conocida completa porque faltan cierre, unidades, preparación y medición.

Transporte conservativo y contact process de support fallan. Ondas/dispersion, response, espectro y termodinámica fueron evaluados por requisitos; no se abrieron targets sin campo/operator/ensemble certificados. Esto no prueba que ningún nivel futuro pueda contenerlos.

No hay predicción externa nueva. La mejor pista Rosetta es funcional: un observable físico candidato tendría que leer factores de reproducción y geometría/actividad de una history, no un raw aislado.

## 12. Masa, materia–geometría, termodinámica, quantum y gauge

- Masa/inercia: velocidad libre no depende de `state` o `s_reg`; colisión no pondera direction por `s_reg`. Falta ley fuerza–respuesta.
- Materia–geometría: hay mediación por sustrato y geometría relacional; no hay respuesta métrica ni equivalencia de masas.
- Termodinámica/hidrodinámica: existen basins, balances y kinetics sectoriales; faltan ensemble, variables lentas, densidades cerradas, constitutivas y entropía operacional.
- Quantum/Bell: periodicidad y Koopman no bastan; faltan Born, observables, composición y aparato CHSH. Bell queda condicional.
- Simetría/gauge: traslaciones exactas; reducer de fuentes conmutativo; tie overflow rompe `O_h`; shift clock no es gauge full-state.

## 13. Claude T1–T7

La auditoría heredada permanece:

| Tesis | Veredicto |
|---|---|
| T1 cono `<=t` | Refutada; cota raw correcta `<=3t` y aguda |
| T2 clock lineal | Probada módulo `2^64` |
| T3 redundancia/período | Condicional; 1,094,573,220 funciona sin wrap, mínimo causal raw 304,980 |
| T4 sin invariantes rango cero | Refutada por familia observer |
| T5 no inyectividad | Probada con razón/testigo corregidos |
| T6 `O_h` | Parcial: traslaciones sí, `O_h` global no |
| T7 Bell | Condicional no instanciada |

Los nuevos resultados no transfieren teoremas de v25: se ejecutó y auditó v27.

## 14. Afirmaciones históricas y sesgo de observable

No sobrevivieron las generalizaciones “occupancy es materia”, “no hay modo”, “no hay conservación” o “simetría cúbica global”. Sí sobreviven como negativos acotados los aparatos y bancos donde se midieron. El sesgo central fue proyectar demasiado pronto a occupancy o a un solo escalar: direction con state cero puede causar nacimientos, y `kappa` necesita actividad/contexto.

Los números 19665/19664, 782, 391, 966, 20 Hz y los coefficients/thresholds de esta campaña conservan su genealogía como literales, inputs o fits. Ninguno se promueve a constante natural.

## 15. Descubrimiento nuevo principal

La pieza no anticipada es que el nivel superior natural no es necesariamente otro snapshot. Es una clase de histories construida por un cociclo de reproducción exacto. Q3 funciona como observador temporal compacto y conecta eventos Q1 con basin Q2. Su éxito y sus contraejemplos muestran simultáneamente qué comprime y qué información pierde.

## 16. Pieza exacta faltante bajo H_DEE

Se necesita fijar externamente

`R: preparación física -> ensemble Q0 -> historia/coarse-graining -> detector forward -> distribución observada`,

calibrar dimensiones sin target leakage y predecir múltiples observables/condiciones con pocos parámetros en holdout. Sin `R`, ninguna ejecución adicional decide unidades, accesibilidad física o lectura experimental.

## 17. Stopping rule

La rama central produjo confirmación, luego tres ciclos de dosis separaron universalidad de contexto y cerraron por ausencia de nueva ganancia: threshold variable, sign-only insuficiente y persistencia sign-only insuficiente. Las familias Rosetta restantes carecen de grados operacionales congelados. Otra variación escalar local no cambiaría el veredicto; un avance requeriría un operador relacional nuevo o información externa.

La campaña se sella aquí. No se afirma que DEE esté terminada.

