# Veredicto ejecutivo — CORE 06 DEE v27

## Resultado central

CORE06 confirma que `F_DEE` posee aprendizaje nativo, pero de una clase precisa y acotada: una experiencia ordinaria de colisión sincrónica escribe un linaje móvil; una consulta posterior interactúa con ese linaje y su respuesta cambia de manera específica, reversible y generalizable. La misma construcción aprendió traslaciones enteras `n -> n+delta`, incluido SUCCESSOR, y dos memorias se compusieron como `n -> n+d1+d2`. No es una red neuronal ni prueba aprendizaje universal.

El resultado no es un artefacto del encoder: entrenados pasaron 20/20 en asociación, 69/69 en clases direccionales nuevas, 24/24 mundos y 96/96 canales en traslación aritmética, y 30/30 en composición. Controles no entrenados, de exposición igualada, de historia/labels barajados, reset y ablación fueron negativos en sus dominios congelados. La suma de dos operandos no cuenta como aprendizaje: el reducer no entrenado ya resolvió exactamente los 16 casos de 2 bits y los 64 de 3 bits, incluidos 44 carries.

La reapertura de `c_DEE` separa cinco nociones. Se preservan `c_transport=1` y el bound raw `r_inf<=3` por actualización. Reglas y clocks internos midieron vuelo a uno y período de fuente a dos. Observadores consumptivos en movimiento midieron velocidades de cierre `0,1,2`, no una velocidad común. Los paquetes finitos fueron traducciones rígidas del modo portador, sin nueva velocidad de grupo, dispersión, interferencia ni estructura Lorentz. Por tanto: `CARRIER_SPEED_CONFIRMED` y `RAW_CAUSAL_BOUND_CONFIRMED`; `NO_LIGHT_ROSETTA_FOUND` en las familias probadas.

La mecánica material operacional es sectorial. Portadores libres conservan soporte móvil, dirección, `s_reg` y semantic, mientras `state` arbitrario normaliza a `1` tras el primer salto. Colisiones normales distintas obedecieron en 2600/2600 casos:

`d_out = sign(u+v)`, `s_out = min(s_u+s_v,19664)`.

Interfaces estables transmitieron el control evanescente y absorbieron el portador normal probado; no reflejaron. Esto demuestra persistencia, composición capada, detección y oclusión, no masa ni inercia físicas.

El nuevo aparato Bell interno es completo operacionalmente pero local: 64/64 trials, 128/128 registros, invariancia exacta ante el setting remoto y `CHSH=-2` en dos marcos. El dictamen es `QUANTUM_FORMAL_STRUCTURE_ONLY`, sin Born, violación Bell, entanglement ni Rosetta cuántica.

En ensembles normales, la organización direccional separa dos regímenes: gases alineados trasladan exactamente; gases mixtos tienen soporte y `s_reg` total no crecientes, contraen soporte y alcanzan una ventana macro constante en el horizonte congelado. El llenado alto contrajo más. Es una estructura disipativa/Lyapunov-like sectorial, no energía, entropía termodinámica, temperatura, equilibrio ni teorema asintótico global.

## Rosetta

El candidato de retardo/coincidencia/lugar congelado en CORE05 avanza a `EXTERNAL_COMPATIBILITY`. Un estudio independiente en pollo reporta que diferencias de retardo/fase predicen el mejor ITD y que la respuesta está ordenada anatómicamente por lugar. No se encontró la tabla unitaria pública necesaria ni existía un mínimo externo hasheado antes de mirar sus estadísticas; por ello no hay `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED`.

La pieza exacta que falta bajo `H_DEE` sigue siendo un mapa independiente:

`preparación física -> ensemble Q0 -> historia/organización DEE -> detector -> registro físico`,

calibrado fuera del holdout y capaz de predecir varios observables externos sin refit. CORE06 mejora el bloque interno de aprendizaje, observador, medición y fenómenos; no identifica la preparación física.

## Estados finales

- `NATIVE_LEARNING_FOUND`.
- `NATIVE_ARITHMETIC_LEARNING_CONFIRMED_WITHIN_TRANSLATION_DOMAIN`.
- `COMPOSITIONAL_LEARNING_CONFIRMED_WITHIN_TRANSLATION_DOMAIN`.
- `DEE_MATTER_OPERATIONAL_MECHANICS_FOUND`.
- `CARRIER_SPEED_CONFIRMED`; `RAW_CAUSAL_BOUND_CONFIRMED`.
- `NO_LIGHT_ROSETTA_FOUND` en el dominio probado.
- `QUANTUM_FORMAL_STRUCTURE_ONLY`.
- `THERMODYNAMIC_STRUCTURE_FOUND` sólo en sentido sectorial disipativo.
- `EXTERNAL_COMPATIBILITY` para la Rosetta retardo/coincidencia/lugar.
- `EXTERNAL_EMPIRICAL_FRONTIER` para validación física.

No se declara que DEE sea cerebro, materia física, luz, relatividad, quantum o termodinámica fundamental.
