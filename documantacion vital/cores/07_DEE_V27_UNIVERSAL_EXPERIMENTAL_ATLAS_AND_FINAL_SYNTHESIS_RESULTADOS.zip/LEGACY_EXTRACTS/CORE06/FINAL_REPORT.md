# Informe final — CORE 06 DEE v27

## 1. Misión y resultado

CORE06 consolidó CORE05 en el expediente, interrogó aprendizaje nativo, reabrió las velocidades DEE con observadores internos, caracterizó materia operacional, reauditoró quantum y termodinámica y llevó la búsqueda Rosetta hasta la frontera empírica disponible.

Los estados finales son:

- `NATIVE_LEARNING_FOUND`;
- `PLASTICITY_CONFIRMED`, `ASSOCIATIVE_LEARNING_CONFIRMED`, `CONTEXTUAL_LEARNING_CONFIRMED`;
- `RULE_GENERALIZATION_CONFIRMED` y `NATIVE_ARITHMETIC_LEARNING_CONFIRMED_WITHIN_TRANSLATION_DOMAIN`;
- `COMPOSITIONAL_LEARNING_CONFIRMED_WITHIN_TRANSLATION_DOMAIN`;
- `CARRIER_SPEED_CONFIRMED`, `RAW_CAUSAL_BOUND_CONFIRMED`, pero `NO_LIGHT_ROSETTA_FOUND`;
- `DEE_MATTER_OPERATIONAL_MECHANICS_FOUND`;
- `QUANTUM_FORMAL_STRUCTURE_ONLY`;
- `THERMODYNAMIC_STRUCTURE_FOUND` en un sector disipativo, no termodinámica física completa;
- `EXTERNAL_COMPATIBILITY` para retardo/coincidencia/lugar;
- `EXTERNAL_EMPIRICAL_FRONTIER` para una Rosetta validada.

## 2. Provenance ejecutada

El wheel v27 fue copiado dentro del WORK, verificado e importado en aislamiento con CPython 3.13 x64. Identidad:

| objeto | SHA-256 |
|---|---|
| wheel | `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939` |
| package | `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4` |
| `.pyd` | `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff` |

Los padres 01–05 permanecieron sellados. CORE05 fuente y copia byte-for-byte en el expediente comparten `aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b`.

## 3. Arquitectura heredada y refinada

Se preserva:

- `Q0=(raw,clock)` como estado Markoviano completo;
- `Q1` como mecanismos y eventos causales;
- `Q2` como organización/basin confirmada en dominio;
- `Q3` como clase de histories productivas acotada;
- ausencia de `Q4` global probado.

La mejor arquitectura transversal después de CORE06 es:

`state/information -> directed proposals/guards -> destination fibers/resolver -> phase/history/lineages -> organization -> observer/intervention -> record/phenomenon`.

CORE06 descubre que el aprendizaje es una transformación dentro de esta misma arquitectura: una experiencia crea un linaje que cambia una resolución futura.

## 4. Programa experimental

| ID | Pregunta | Resultado |
|---|---|---|
| C6D01 | ¿una experiencia reentrena phase de fuente? | negativo persistente; sólo transitorios |
| C6D02–04 | ¿colisión escribe memoria, generaliza, se extingue/invierte? | señal fuerte; mecanismos/controles delimitados |
| C6H01 | asociación/plasticidad contextual | PASS |
| C6H02 | generalización de clase e inversión | PASS |
| C6D05/C6H03 | successor/traslación en valores no vistos | PASS |
| C6D06 | suma/carry aprendidos vs modelo simple | modelo no entrenado gana; claim aprendido rechazado |
| C6D07/C6H04 | composición de memorias | PASS |
| C6D08/C6H05 | regla, clock y observers móviles | speed uno del sustrato; no invariancia |
| C6D09 | excitación colectiva | traducciones/trenes producto; sin nuevo modo |
| C6D10/C6H06 | mecánica e identidad de materia | leyes exactas sectoriales; cociente de identidad PASS |
| C6H07 | aparato Bell con observers | PASS formal local; CHSH=-2 |
| C6D12/C6H08 | ensembles/relajación | PASS disipativo sectorial |
| C6R01 | compuerta Rosetta externa | EXTERNAL_COMPATIBILITY, no validación |

Los dos abortos de runner documentados fueron técnicos, anteriores a outputs, reparados sin modificar hipótesis u observables. No se cuentan como PASS/FAIL.

## 5. Aprendizaje nativo

La experiencia cue+teacher llega por canales ordinarios. En coincidencia se forma una memoria con:

`d_mem=sign(d_cue+d_teacher)`

`s_mem=min(s_cue+s_teacher,19664)`.

El linaje viaja y una consulta posterior colisiona con él. C6H01 confirmó 20/20 entrenados y controles neutrales; C6H02 confirmó 69/69 clases direccionales nuevas y reversión/reacquisición. Shuffles de historia/label, matched exposure, reset y ablación separan experiencia causal de carga o lectura.

Para números se congeló `s_cue=B-x`, `s_teacher=y`, `s_query=n`, de modo que la memoria codifica `B+(y-x)` y el readout produce `n+(y-x)`. C6H03 pasó 24/24 mundos, 96/96 canales y 6/6 successor, con cero aciertos de canal entre 576 controles. C6H04 compuso dos traslaciones en 30/30 mundos y ambos órdenes; 270/270 controles fallaron la composición completa.

La suma binaria no fue promovida: la suma capada del reducer no entrenado resolvió exactamente 2 y 3 bits. Aprendizaje no equivale a que el aparato compute.

## 6. Velocidad y relatividad

`c_transport=1` y la cota causal raw `<=3` son magnitudes diferentes. Regla y reloj internos confirmaron el primer valor; una fuente semantic-4 proporcionó reloj de período dos. Observadores consumptivos móviles midieron `||u-w||_infinity`, con clases 0,1,2. No hay velocidad observador-invariante en ese aparato.

Los paquetes diluidos conservaron forma/espectro por ser traducciones exactas; los trenes reflejaron la cadencia de fuente. Colisiones destruyeron superposición mediante reducer. No apareció relación Lorentz, Doppler, composición relativista, group speed independiente o fingerprint de luz. La conversión a SI sería sólo calibración.

## 7. Materia operacional

El carrier libre conserva soporte móvil, dirección, `s_reg` y semantic; `state` se normaliza a uno. Esto define una clase de equivalencia de identidad. Colisiones distintas obedecen la suma-signo y suma capada en 2600/2600 casos. Un probe convierte targets en fibras de respuesta many-to-one. Fuentes son otra clase persistente e interfaces otra clase de medio/obstáculo.

Existe una mecánica mínima de persistencia, transporte, colisión, oclusión y detección. No aparece masa/inercia, fuerza–aceleración o conservación de momentum físico.

## 8. Quantum/Bell

El observer de CORE05 permitió formular un aparato con fuente, dos settings locales, outcomes y estadística. C6H07 dio 64/64 trials, 128/128 registros, no-signaling exacto y `CHSH=-2`. Esto es una construcción clásica local en DEE. No hay Born, amplitud física, entanglement o violación Bell. Los formalismos Koopman/phase históricos permanecen formalismos.

## 9. Estructura estadística

Con inventario igualado, gases alineados traducen sin pérdida y mezclados contraen por interacción. C6H08 confirmó monotonicidad de soporte y `s_reg`, contracción, ventana macro terminal y respuesta a densidad en 32 mundos. Soporte y `s_reg` son Lyapunov-like en ese sector. No se asignan nombres de energía, entropía o temperatura sin ensembles físicos, conjugadas y leyes de respuesta.

## 10. Rosetta phenomenon-first

El candidato más fuerte heredado estaba congelado antes de abrir el estudio externo:

`delay difference -> coincidence tuning -> ordered place`.

Datos publicados independientes en pollo contienen las tres relaciones con correlaciones significativas. Esto mejora de formal a `EXTERNAL_COMPATIBILITY`. La tabla unitaria no fue localizable y no existía umbral externo preregistrado; no se calculó un holdout ni se produjo predicción nueva. Candidatos de luz, materia, estadística y quantum tienen peor identificabilidad y no se abrieron contra targets fabricados.

## 11. Teoremas/hechos/interpretaciones

### Exactos o heredados exactos

- determinismo finito de `F_DEE` y clock modular;
- bound causal raw `<=3t`;
- shift balístico sectorial;
- reducer de direcciones/carga en colisión normal;
- normalización de `state` del carrier libre en el dominio confirmado;
- Bell local del aparato congelado y su CHSH calculado.

### Hechos computacionales prospectivos

- aprendizaje asociativo, generalización, traslación y composición;
- medición cinemática interna y clases relativas;
- relajación disipativa sectorial;
- compatibilidad externa agregada del candidato delay/place.

### Hipótesis no promovidas

- velocidad física fundamental;
- masa/inercia;
- termodinámica física;
- quantum físico;
- Rosetta universal.

## 12. Modelo de realidad que mejor comprime la evidencia

Entre los modelos comparados, la evidencia favorece:

`state/information -> causal relations -> operational geometry -> history -> organization -> observer -> phenomenon`.

“Información -> geometría -> materia” es demasiado corta: omite fibras, reducer, historia y observer que son causalmente necesarios en los positivos. La arquitectura favorecida es sectorial y operacional, no dogma ontológico.

## 13. Pieza faltante bajo H_DEE

Falta exactamente un puente bidireccional y prospectivo:

`physical preparation -> distribution over Q0 -> effective DEE history -> detector map -> physical records`,

con unidad/escala separada, pocos parámetros y predicción de varios observables externos. El kernel puede mostrar qué procesos construye, pero no decide qué preparación del mundo los instancia.

## 14. Regla de parada

Todas las ramas centrales recibieron una prueba capaz de cambiar conclusión. Aprendizaje fue profundizado hasta composición y el límite de suma aprendida; `c` hasta observers móviles y paquetes; materia hasta identidad/collision/interface; quantum hasta Bell; termodinámica hasta holdout de ensembles; Rosetta hasta una fuente independiente. Repetir seeds o tamaños de los mismos aparatos sólo estrecharía errores dentro de conclusiones ya separadas. La promoción física restante requiere datos externos unitarios o una nueva hipótesis causal independiente. Se alcanza el stopping rule por cierre local más frontera empírica.
