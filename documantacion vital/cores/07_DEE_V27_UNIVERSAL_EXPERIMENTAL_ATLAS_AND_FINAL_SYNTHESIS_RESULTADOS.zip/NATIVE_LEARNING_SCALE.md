# Escala del aprendizaje nativo

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


La escalera acumulada es: memoria/plasticidad asociativa → discriminación y generalización por clase → traducciones enteras acotadas → composición → transferencia funcional → memoria multiclase dañada. La experiencia siempre entra por interfaces normales; no se edita el estado final para escribir respuestas.

C7H01 demuestra transferencia, C7H02 separa capacidad de interferencia, C7H03 demuestra reprogramación monotónica y EXTRA02 prueba 10 clases. La capacidad probada alcanza K=40 fibras separadas y 1003 celdas no cero en el estado aprendido de EXTRA02; K=40 es una cota inferior experimental, no una capacidad máxima.

La ley de interferencia es simple: destinos distintos conservan respuestas; un destino compartido reduce a un único linaje con respuesta compuesta. Esto da multi-memory por topología, pero no demuestra memoria densa óptima, rule induction universal ni aprendizaje continuo sin interferencia.

EXTRA02 generaliza a imágenes inéditas y daño, pero su estado es un histograma categórico con tamaño ligado a clase×feature. No hay evidencia de una representación semántica compacta, few-shot excepcional ni ventaja de complejidad.
