# Resultados negativos conservados

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


- No existe Q4 global demostrado ni estado relacional comprimido globalmente suficiente.
- Delayed direction repair, load repair y support repair: 0% en el aparato C7H03.
- El circuito C7H04 no es reusable: soporte 6→1, memoria=0 y actuadores=0 al final.
- No teleportación discontinua: C7H01 requiere corredor y estados intermedios.
- EXTRA02 no es competitivo ni superior; pierde ante kNN y logística matched.
- No evidencia de prototypes semánticos compactos o memoria sublineal por ejemplo/clase.
- FactorX no obtiene mecanismo o ventaja nueva.
- No operational invariant speed, Lorentz structure o light Rosetta nuevos.
- Bell no viola el límite local: CHSH=-2; no Born/quantum físico.
- No temperatura, energía, variable conjugada, equilibrio universal o ciclo de recurso físico.
- Rosetta delay/place no tiene holdout row-level externo; permanece compatible, no validada.
- EXTRA01 ECG conserva `NO_ADDED_PREDICTIVE_VALUE`.

Cada negativo está limitado al aparato/dominio salvo donde existe una ley exacta sectorial. Ninguno se convierte en imposibilidad ontológica global.
