# Descubrimientos nuevos de CORE07

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## Confirmados

1. **Transferencia funcional aprendida:** un repertoire entrenado se recupera en B para queries nuevas mediante un corredor causal.
2. **Ley de capacidad por fibras:** la separación de destinos, no el conteo bruto de carriers, controla memoria independiente; K≥40 confirmado.
3. **Materia funcional reprogramable:** una identidad de respuesta/linaje cambia por experiencia y persiste a nuisances y transporte.
4. **Feedback interno one-pass:** observación, memoria, acción y retorno pueden componerse dentro de F_DEE.
5. **Aprendizaje robusto multiclase:** 81.11% bajo 15.625% de daño estructural en digits con controles causales.
6. **Operador unificador sectorial:** guardas→propuestas→fibras→reductor→linajes explica al menos aprendizaje, transferencia, materia, observador, cómputo y disipación.

## Leyes/ideas nuevas

- función como cociente de respuesta de linaje;
- capacidad como propiedad relacional/topológica;
- dualidad operacional cómputo-recurso;
- observador como subsistema causal, no lectura necesariamente externa.

Cada una conserva su dominio; ninguna es una correspondencia física externa.
