# Propagación y relatividad — estado final

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


Se heredan dos velocidades distintas: carrier normal libre `c_transport=1 L∞/tick` y cota de dependencia raw `r∞≤3` por ramas del kernel. CORE06 construyó ruler/clock internos, pero moving observers no midieron una velocidad universal ni relaciones Lorentz.

C7H01 no cambia el problema: la función viaja de forma continua por carriers y relays, con estados intermedios causales. No emergió un modo colectivo, clock/ruler o transformación de observador nuevos. Por la regla condicional, el aparato relativista no se repitió.

Estados: `CARRIER_SPEED_CONFIRMED`; `RAW_CAUSAL_BOUND_CONFIRMED`; no `OPERATIONAL_INVARIANT_SPEED`, no `RELATIVISTIC_STRUCTURE`, no `LIGHT_ROSETTA`. Esto no es un teorema de ausencia global de modos colectivos.
