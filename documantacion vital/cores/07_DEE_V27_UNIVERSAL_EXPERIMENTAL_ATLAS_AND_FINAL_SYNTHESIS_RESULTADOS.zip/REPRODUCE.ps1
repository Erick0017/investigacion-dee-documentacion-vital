$ErrorActionPreference = 'Stop'
$Work = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = 'D:\Descargas\ANACONDA MINICONDA\python.exe'

if (-not (Test-Path -LiteralPath $Python)) {
    throw "CPython 3.13 runtime not found at the recorded path: $Python"
}

Push-Location -LiteralPath $Work
try {
    & $Python -I -B '.\run_core07_universal.py'
    if ($LASTEXITCODE -ne 0) { throw "CORE07 reproduction failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}
