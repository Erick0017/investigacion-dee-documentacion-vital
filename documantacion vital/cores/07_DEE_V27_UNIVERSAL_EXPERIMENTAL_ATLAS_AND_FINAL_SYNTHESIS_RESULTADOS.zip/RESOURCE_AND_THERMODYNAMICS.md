# Recursos y termodinámica

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


En el sector normal fuente-libre, una fibra con k entradas produce un soporte: `Δsupport=-(k-1)`. `s_reg` suma hasta 19664. C7H02 confirmó el accounting durante training/read; C7H04 siguió un circuito completo 6→1. El mismo evento que integra información gasta grados activos: **computation-resource duality**.

Esto extiende la disipación sectorial de CORE06, pero no es energía ni termodinámica completa. No se obtuvo regeneración en reposo, ciclo reusable, ensemble estacionario universal, detailed balance, variable intensiva conjugada, ley de fluctuaciones o límite termodinámico. Sources/inyección externa cambian el accounting y deben incluirse explícitamente.

Veredictos: `RESOURCE_ACCOUNTING_STRUCTURE_FOUND`; `NO_NATIVE_REUSABLE_RESOURCE_CYCLE` en el aparato fuente-libre probado; `THERMODYNAMIC_STRUCTURE_FOUND` sólo en sentido de ensamble/disipación sectorial, no equivalencia física.
