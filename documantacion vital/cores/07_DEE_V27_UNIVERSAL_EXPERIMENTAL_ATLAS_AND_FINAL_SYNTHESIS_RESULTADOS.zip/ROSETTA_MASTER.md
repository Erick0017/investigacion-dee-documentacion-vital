# Rosetta maestra

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## Ranking final

1. `relative delay → coincidence → ordered place`: **EXTERNAL_COMPATIBILITY**. Mapa interno congelado, cero parámetros funcionales por caso y compatibilidad con organización binaural publicada.
2. destination-fiber integration/resource: ley interna fuerte, pero sin observable externo y preparación física independientes; **FORMAL_EQUIVALENCE_CANDIDATE** como clase many-to-one, no Rosetta.
3. functional lineage/transfer: fenómeno interno nuevo, sin target externo preregistrable; **STRUCTURAL_ANALOGY** con transducción/identidad funcional.
4. ballistic/causal transport: estructura interna, pero sin invariancia de observador; **NO_LIGHT_ROSETTA_FOUND**.
5. Bell/quantum: **FORMAL_ONLY**.

La búsqueda externa renovada confirmó que el trabajo de Köppl y Carr (2008; PMID 18491165, PMCID PMC3170859) es relevante a la familia delay/place, pero no proporcionó el objeto row-level independiente requerido para un holdout.

Objeto exacto faltante: tabla por sitio de registro con identificador de animal/penetración, coordenada anatómica, retardo/fase monaural, best ITD/IPD, frecuencia/retardo característico y cluster unit; además deben congelarse mapa de preparación/escala, residual y efecto mínimo antes de abrirla.

Ningún candidato alcanza `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED`. Calibrar voxel/tick a SI o renombrar `s_reg` no constituye traducción.
