"""Single, final adversarial audit for CORE07.

This audit is intentionally read-only with respect to scientific outputs.  It
checks the frozen contracts, implementation boundaries and claim language; it
does not tune or rerun a holdout.
"""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import ROOT, atomic_json, atomic_text, sha256_file


def load(relative: str):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def main() -> int:
    result_map = {
        "C7H01": "RESULTS/C7H01_functional_learning_transfer.json",
        "C7H02": "RESULTS/C7H02_destination_fiber_capacity_budget.json",
        "C7H03": "RESULTS/C7H03_reprogrammable_functional_matter.json",
        "C7H04": "RESULTS/C7H04_internal_feedback_resource_closure.json",
        "EXTRA02": "RESULTS/EXTRA02_noisy_multiclass_final.json",
    }
    lock_map = {
        "C7H01": "HOLDOUT_LOCKS/C7H01_FUNCTIONAL_LEARNING_TRANSFER.json",
        "C7H02": "HOLDOUT_LOCKS/C7H02_DESTINATION_FIBER_CAPACITY_AND_BUDGET.json",
        "C7H03": "HOLDOUT_LOCKS/C7H03_REPROGRAMMABLE_FUNCTIONAL_MATTER.json",
        "C7H04": "HOLDOUT_LOCKS/C7H04_INTERNAL_FEEDBACK_AND_RESOURCE_CLOSURE.json",
        "EXTRA02": "HOLDOUT_LOCKS/EXTRA02_NOISY_MULTICLASS_FINAL.json",
    }
    results = {key: load(path) for key, path in result_map.items()}
    lock_hashes = {key: sha256_file(ROOT / path) for key, path in lock_map.items()}
    lock_links = {key: results[key].get("lock_sha256") == lock_hashes[key] for key in result_map}
    extra = results["EXTRA02"]
    source = (ROOT / "RUNNERS/extra02_common.py").read_text(encoding="utf-8")
    final_runner = (ROOT / "RUNNERS/run_extra02_final_holdout.py").read_text(encoding="utf-8")
    split = load("RESULTS/EXTRA02_dataset_split.json")

    checks = [
        {
            "question": "Were holdout contracts frozen and linked to results?",
            "finding": "PASS" if all(lock_links.values()) else "FAIL",
            "evidence": lock_links,
            "correction": None,
        },
        {
            "question": "Does the EXTRA02 encoder contain the answer?",
            "finding": "NO, within the tested implementation",
            "evidence": "The image encoder thresholds pixel intensities without labels. Labels select one of ten fixed teacher ports only during supervised exposure; the final readout is fixed argmax over ten destination-fiber scores.",
            "correction": "Describe the architecture as supervised categorical count learning, not autonomous concept discovery.",
        },
        {
            "question": "Was the readout or encoder fitted to FINAL TEST?",
            "finding": "NO",
            "evidence": {
                "dataset_sha256": split["provenance"]["sha256"],
                "final_index_hash": extra["dataset"]["final_index_hash"],
                "threshold_selected_on_validation": 8,
                "lock_records_final_hash": True,
                "runner_uses_frozen_threshold": "THRESHOLD = 8" in final_runner or "threshold" in final_runner.lower(),
            },
            "correction": None,
        },
        {
            "question": "Is there split leakage or pseudoreplication?",
            "finding": "NO DETECTED",
            "evidence": "Exact duplicate groups across the 1797 images were zero; deterministic stratified train/validation/final indices were frozen. The inferential unit is the image/world, never ticks or corruption realizations.",
            "correction": None,
        },
        {
            "question": "Does a simpler baseline explain EXTRA02 performance?",
            "finding": "YES",
            "evidence": {
                "DEE_primary_accuracy": extra["mode_metrics"]["trained_primary"]["strict_stable_accuracy"],
                "knn3_primary_accuracy": extra["baselines"]["knn3_20shot_primary"]["accuracy"],
                "logistic_primary_accuracy": extra["baselines"]["multinomial_logistic_20shot_primary"]["accuracy"],
                "mechanism": "categorical per-pixel destination-fiber histogram/reducer",
            },
            "correction": "Retain causal-learning and robustness PASS; retain competitive and superiority FAIL. Do not claim a novel classifier.",
        },
        {
            "question": "Were analogies promoted to external physics?",
            "finding": "NO AFTER CORRECTION",
            "evidence": "Functional transfer is continuous and corridor-mediated; matter is an operational response quotient; the loop is one-pass; s_reg is accounting, not energy; delay/place remains external compatibility only; Bell remains local CHSH=-2.",
            "correction": "All final documents must retain these scope qualifiers.",
        },
        {
            "question": "Were negative outcomes repaired post hoc?",
            "finding": "NO",
            "evidence": "Delayed direction/load/support repair remains 0%; W=3 was preserved after one discovery instability; reusable source-free cycle, competitive EXTRA02, Lorentz/light bridge and quantum violation remain negative or unopened for stated dependency reasons.",
            "correction": None,
        },
        {
            "question": "Is the unifying quotient globally sufficient?",
            "finding": "NO",
            "evidence": "Z_f=(k,sum_s,signsum_d) is exact only for source-free semantic-1 proposals to blank destinations below cap and for its declared observables. Sources, preoccupied destinations, semantic/clock guards, event provenance and global Q2/Q3 require additional state.",
            "correction": "Use RELATIONAL_CLOSURE_EXTENDED_CROSS_DOMAIN and NO_GLOBAL_Q4, never global closure.",
        },
        {
            "question": "Did source-free feedback establish agency or a reusable resource cycle?",
            "finding": "NO",
            "evidence": "The apparatus is fully preconfigured; Python does not choose actions, but support contracts 6->1 and no memory/actuator carriers survive.",
            "correction": "Call it an internal one-pass feedback circuit only.",
        },
        {
            "question": "Is the Rosetta externally validated?",
            "finding": "NO",
            "evidence": "The delay/coincidence/place map remains structurally compatible with aggregate auditory literature. The preregistrable row-level dataset joining anatomy, delay/phase, best ITD/IPD and recording hierarchy was not available.",
            "correction": "Keep EXTERNAL_COMPATIBILITY and EXTERNAL_DATA_REQUIRED; no external prediction.",
        },
    ]
    hard_fail = any(row["finding"] == "FAIL" for row in checks)
    audit = {
        "schema": "dee.v27.core07.adversarial_audit.v1",
        "module_id": "C7A04_FINAL_ADVERSARIAL_AUDIT",
        "status": "COMPLETE",
        "scientific_rerun_required": hard_fail,
        "checks": checks,
        "final_adjudication": "PASS_WITH_SCOPE_CORRECTIONS" if not hard_fail else "TECHNICAL_ERROR_REQUIRES_CORRECTION",
        "epistemic_boundary": "Internal computation establishes laws of F_DEE in declared sectors. It does not by itself establish that DEE describes external reality.",
    }
    atomic_json(ROOT / "RESULTS/C7A04_adversarial_audit.json", audit)
    lines = [
        "# Revisión adversarial final de CORE07",
        "",
        f"Veredicto: **{audit['final_adjudication']}**. No se abrió ni reajustó ningún holdout.",
        "",
    ]
    for item in checks:
        lines += [f"## {item['question']}", "", f"**{item['finding']}**", "", str(item["evidence"]), ""]
        if item["correction"]:
            lines += [f"Corrección de alcance: {item['correction']}", ""]
    lines += ["## Límite", "", audit["epistemic_boundary"], ""]
    atomic_text(ROOT / "ADVERSARIAL_AUDIT.md", "\n".join(lines))
    stamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    with (ROOT / "SCIENCE_LOG.ndjson").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({
            "timestamp_utc": stamp,
            "event": "C7A04_FINAL_ADVERSARIAL_AUDIT_COMPLETE",
            "result_file": "RESULTS/C7A04_adversarial_audit.json",
            "verdict": audit["final_adjudication"],
            "scientific_rerun_required": hard_fail,
            "principal_corrections": ["scope sectorial relational closure", "EXTRA02 causal but not competitive", "no physical Rosetta validation"],
        }, separators=(",", ":"), ensure_ascii=False) + "\n")
    print(json.dumps({"verdict": audit["final_adjudication"], "rerun": hard_fail, "lock_links": lock_links}, indent=2))
    return 1 if hard_fail else 0


if __name__ == "__main__":
    raise SystemExit(main())
