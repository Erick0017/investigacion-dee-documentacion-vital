#!/usr/bin/env python3
"""Integrate confirmed CORE07 cross-feeds into the executable atlas."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import atomic_json, canonical_hash, sha256_file

WORK = Path(__file__).resolve().parents[1]
RESULTS = WORK / "RESULTS"


def read_json(path): return json.loads(path.read_text(encoding="utf-8"))


def unique_append(rows, additions, key):
    present = {row[key] for row in rows}
    for item in additions:
        if item[key] not in present: rows.append(item); present.add(item[key])


def main():
    sources = {
        "C7H01": RESULTS / "C7H01_functional_learning_transfer.json",
        "C7H02": RESULTS / "C7H02_destination_fiber_capacity_budget.json",
        "C7H03": RESULTS / "C7H03_reprogrammable_functional_matter.json",
        "C7H04": RESULTS / "C7H04_internal_feedback_resource_closure.json",
        "EXTRA02": RESULTS / "EXTRA02_noisy_multiclass_final.json",
    }
    data = {key: read_json(path) for key, path in sources.items()}
    if any(value["verdict"] != "PASS" for value in data.values()): raise RuntimeError("a central input is not PASS")
    evidence = {
        "functional_transfer": {"witness": "C7H01", "positive": data["C7H01"]["sample_sizes"]["positive_cases"], "controls": data["C7H01"]["sample_sizes"]["negative_controls"]},
        "fiber_capacity_and_interference": {"witness": "C7H02", "separated_channels": data["C7H02"]["sample_sizes"]["separated_channels"], "max_K": data["C7H02"]["sample_sizes"]["max_K"], "overlap_panels": data["C7H02"]["sample_sizes"]["overlap_panels"]},
        "functional_reprogramming": {"witness": "C7H03", "positive": data["C7H03"]["sample_sizes"]["positive_cases"], "controls": data["C7H03"]["sample_sizes"]["negative_cases"]},
        "internal_feedback": {"witness": "C7H04", "positive": data["C7H04"]["sample_sizes"]["positive"], "controls": data["C7H04"]["sample_sizes"]["controls"], "final_support": data["C7H04"]["rates"]["final_support"]},
        "external_multiclass": {"witness": "EXTRA02", "primary_accuracy": data["EXTRA02"]["mode_metrics"]["trained_primary"]["strict_stable_accuracy"], "retention": data["EXTRA02"]["robustness_retention"], "causal": data["EXTRA02"]["descriptive_levels"]["CAUSAL_MULTICLASS_LEARNING_FOUND"], "competitive": data["EXTRA02"]["descriptive_levels"]["COMPETITIVE_ARCHITECTURE_CANDIDATE"]},
    }
    unification = {
        "schema": "dee.v27.core07.unification.v1", "module_id": "C7A02_UNIFIED_RELATIONAL_OPERATOR", "status": "COMPLETE",
        "question": "What is the smallest relation that predicts multiple previously separate DEE families?",
        "global_operator": {
            "name": "GUARDED_DESTINATION_FIBER_OPERATOR",
            "state": "Z_rel(t) is the directed proposal multigraph grouped by destination, annotated with destination occupancy, semantic/guard class, source flag and phase/history context.",
            "transition": "guards select proposals; proposals form destination fibers; each fiber is resolved; outputs continue as lineages carrying state/load/direction/history.",
            "global_closure": "NOT_DEMONSTRATED_AS_COMPRESSED_GLOBAL_MARKOV_STATE; raw+clock remains Q0 and special/source/preoccupied branches require annotations that can approach microstate complexity.",
        },
        "exact_normal_sector_quotient": {
            "name": "Z_f=(k, sum_s, signsum_d)",
            "domain": "source-free semantic-1 proposals to blank destinations, below cap, for declared support/s_reg/direction observables",
            "law": "support_out=1 for k>=1; s_reg_out=min(sum_s,19664); d_out=componentwise_sign(sum d_i); support contraction=k-1",
            "causal_sufficiency": "one-step exact for the declared quotient; raw state and event provenance require additional reducer/state annotations",
        },
        "unified_families": [
            {"family": "learning", "role": "experience writes a fiber reduction into a transported lineage"},
            {"family": "transfer", "role": "zero-load fibers redirect a response repertoire without changing its scalar map"},
            {"family": "operational matter", "role": "persistent/interacting carrier lineages instantiate the same reducer mechanics"},
            {"family": "observer and measurement", "role": "detector coupling is a destination-fiber interaction with a reproducible record"},
            {"family": "resource/dissipation", "role": "many-to-one resolution contracts support and bounds source-free collision-mediated operations"},
            {"family": "computation", "role": "feature-event fibers accumulate counts and score classes"},
            {"family": "feedback", "role": "successive reducer outputs causally feed later interactions, but consume the apparatus"},
        ],
        "new_principles": [
            "FUNCTION_IS_A_LINEAGE_RESPONSE_QUOTIENT: functional identity can survive raw-state nuisance and relay mergers while strict particle identity does not.",
            "CAPACITY_IS_RELATIONAL: independent memory count is controlled by collision-separated destination fibers; overlap integrates and destroys separate readout identity.",
            "COMPUTATION_RESOURCE_DUALITY: each normal binary reducer operation both computes/integrates and spends one active carrier; sources or new injections are required for reuse.",
            "OBSERVER_IS_NOT_EXTERNAL: a preconfigured DEE detector chain can route its record into later DEE actions and back to the sensing coordinate without Python choice.",
        ],
        "not_unified": ["global Q2/Q3 dynamics", "semantic-4 source resource accounting", "clock/phase guard sectors", "physical units or external matter", "Lorentz/quantum/Born structure", "thermodynamic conjugate variables"],
        "evidence": evidence,
        "classification": "UNIFIED_NATIVE_MECHANISM_FOUND_SECTORIALLY; RELATIONAL_CLOSURE_EXTENDED_CROSS_DOMAIN; NO_GLOBAL_Q4",
    }
    unification["content_sha256"] = canonical_hash(unification); atomic_json(RESULTS / "C7A02_unified_relational_operator.json", unification)

    branches = {
        "schema": "dee.v27.core07.branch_adjudication.v1", "module_id": "C7A03_CONDITIONAL_BRANCH_ADJUDICATION", "status": "COMPLETE",
        "branches": [
            {"id": "FACTORING", "decision": "NOT_REOPENED", "status": "NEGATIVE_IN_TESTED_APPARATUS_INHERITED", "reason": "CORE07 adds parallel fiber counting/classification but no iterative divisor-search, modular-generalization or complexity mechanism beyond intrinsic addition; rerunning trial-division-like FactorX would add no information."},
            {"id": "PROPAGATION_RELATIVITY", "decision": "NOT_REOPENED", "status": "CARRIER_SPEED_1_AND_RAW_BOUND_3; NO_LIGHT_ROSETTA_FOUND_IN_TESTED_FAMILIES", "reason": "No new collective propagation mode, ruler/clock or observer transform emerged. C7H01 transfer is continuous carrier transport and adds no new speed class."},
            {"id": "QUANTUM", "decision": "NOT_REOPENED", "status": "QUANTUM_FORMAL_STRUCTURE_ONLY", "reason": "No new settings, factorization, Born normalization or nonlocal measurement context changes the CORE06 Bell premises; CHSH=-2 remains the operative result."},
            {"id": "THERMODYNAMICS_RESOURCE", "decision": "ADVANCED_AND_CLOSED_SECTORIALLY", "status": "RESOURCE_ACCOUNTING_STRUCTURE_FOUND; NO_FULL_THERMODYNAMICS", "reason": "C7H02/H04 prove support budgets and one-pass dissipation, but no stationary preparation-independent ensemble, conjugate intensive variable, fluctuation law or reusable closed cycle appears."},
            {"id": "ROSETTA_DELAY_PLACE", "decision": "EXTERNAL_SEARCH_RENEWED", "status": "EXTERNAL_COMPATIBILITY; EXTERNAL_DATA_REQUIRED", "reason": "The zero-parameter delay/coincidence/place process remains externally compatible. Search still found no independent row-level table joining recording site/animal, anatomical position, monaural delay/phase and best ITD/IPD; no external prediction or validation is legal."},
            {"id": "HIGH_RISK", "decision": "ADJUDICATED", "status": "FUNCTIONAL_TRANSFER_AND_REPROGRAMMING_POSITIVE; DISCONTINUOUS_TRANSFER_SELF_REPAIR_REUSABLE_CYCLE_NEGATIVE", "reason": "The major positive is causal functional transfer/reprogramming. It uses a corridor and reducer lineages; it is neither discontinuous teleportation nor autonomous repair/resource regeneration."},
        ],
        "rosetta_source_urls": ["https://pubmed.ncbi.nlm.nih.gov/18491165/", "https://pmc.ncbi.nlm.nih.gov/articles/PMC3170859/"],
        "exact_external_missing_object": "Independent row-level data with recording-site and animal/penetration identifiers, anatomical coordinate, monaural delay/phase, best ITD/IPD, characteristic frequency/delay, plus a prospective scale/preparation map and effect threshold.",
    }
    branches["content_sha256"] = canonical_hash(branches); atomic_json(RESULTS / "C7A03_conditional_branch_adjudication.json", branches)

    # Promote current claims into the atlas without disturbing inherited records.
    atlas = read_json(WORK / "UNIVERSAL_ATLAS.json")
    ledger_rows = [json.loads(line) for line in (WORK / "CLAIM_LEDGER.ndjson").read_text(encoding="utf-8").splitlines() if line.strip()]
    current = [row for row in ledger_rows if str(row.get("claim_id", "")).startswith("CORE07:")]
    unique_append(atlas["records"], current, "claim_id"); atlas["record_count"] = len(atlas["records"]); atomic_json(WORK / "UNIVERSAL_ATLAS.json", atlas)

    new_witnesses = [
        {"witness_id": "W_FUNCTIONAL_TRANSFER", "capability": "learned response repertoire transfer", "source": "CORE07", "runner": "RUNNERS/run_c7h01_functional_learning_transfer.py", "result_file": "RESULTS/C7H01_functional_learning_transfer.json", "minimal_case": "trained carrier + zero-load relay + unseen remote query", "status": "CANONICAL"},
        {"witness_id": "W_FIBER_CAPACITY", "capability": "relational memory capacity and collision budget", "source": "CORE07", "runner": "RUNNERS/run_c7h02_destination_fiber_capacity_budget.py", "result_file": "RESULTS/C7H02_destination_fiber_capacity_budget.json", "minimal_case": "separated versus overlapping learned fibers", "status": "CANONICAL"},
        {"witness_id": "W_REPROGRAMMING", "capability": "functional matter reprogramming", "source": "CORE07", "runner": "RUNNERS/run_c7h03_reprogrammable_functional_matter.py", "result_file": "RESULTS/C7H03_reprogrammable_functional_matter.json", "minimal_case": "positive-load update + zero-load redirection", "status": "CANONICAL"},
        {"witness_id": "W_FEEDBACK", "capability": "internal one-pass feedback", "source": "CORE07", "runner": "RUNNERS/run_c7h04_internal_feedback_resource_closure.py", "result_file": "RESULTS/C7H04_internal_feedback_resource_closure.json", "minimal_case": "closed spatial path with exact 6-to-1 support accounting", "status": "CANONICAL"},
        {"witness_id": "W_EXTRA02", "capability": "robust causal multiclass learning", "source": "CORE07_EXTRA02", "runner": "RUNNERS/run_extra02_final_holdout.py", "result_file": "RESULTS/EXTRA02_noisy_multiclass_final.json", "minimal_case": "20-shot ten-class digits with 10/64 structural pixel damage", "status": "CANONICAL"},
    ]
    witness_index = read_json(WORK / "CANONICAL_WITNESSES.json"); unique_append(witness_index["witnesses"], new_witnesses, "witness_id"); atomic_json(WORK / "CANONICAL_WITNESSES.json", witness_index)
    for witness in new_witnesses:
        path = sources["EXTRA02" if witness["witness_id"] == "W_EXTRA02" else {"W_FUNCTIONAL_TRANSFER": "C7H01", "W_FIBER_CAPACITY": "C7H02", "W_REPROGRAMMING": "C7H03", "W_FEEDBACK": "C7H04"}[witness["witness_id"]]]
        source_data = read_json(path)
        atomic_json(WORK / "CANONICAL_WITNESSES" / f"{witness['witness_id']}.json", {"schema": "dee.v27.core07.canonical_witness.v1", **witness, "lock_sha256": source_data.get("lock_sha256"), "verdict": source_data.get("verdict"), "source_sha256": sha256_file(path), "summary": source_data.get("sample_sizes", source_data.get("descriptive_levels")), "rates": source_data.get("rates", source_data.get("mode_metrics", {}).get("trained_primary"))})

    graph = read_json(WORK / "CAPABILITY_GRAPH.json")
    new_nodes = [{"id": q} for q in ("FUNCTIONAL_TRANSFER", "RELATIONAL_CAPACITY", "REPROGRAMMABLE_FUNCTIONAL_MATTER", "ONE_PASS_FEEDBACK", "ROBUST_MULTICLASS")]
    unique_append(graph["nodes"], new_nodes, "id")
    new_edges = [
        {"source": "LEARNING_MEMORY", "target": "FUNCTIONAL_TRANSFER", "relation": "transported-as-lineage"},
        {"source": "DESTINATION_FIBERS", "target": "RELATIONAL_CAPACITY", "relation": "separation-controls"},
        {"source": "GUARDED_REDUCER", "target": "RELATIONAL_CAPACITY", "relation": "overlap-integrates"},
        {"source": "FUNCTIONAL_TRANSFER", "target": "REPROGRAMMABLE_FUNCTIONAL_MATTER", "relation": "preserves-response-quotient"},
        {"source": "REPROGRAMMABLE_FUNCTIONAL_MATTER", "target": "ONE_PASS_FEEDBACK", "relation": "feeds-actions"},
        {"source": "OBSERVER_RELATION", "target": "ONE_PASS_FEEDBACK", "relation": "closes-spatial-signal-path"},
        {"source": "RELATIONAL_CAPACITY", "target": "ROBUST_MULTICLASS", "relation": "implements-feature-count-memory"},
        {"source": "GUARDED_REDUCER", "target": "ONE_PASS_FEEDBACK", "relation": "imposes-support-budget"},
    ]
    present_edges = {(e["source"], e["target"], e["relation"]) for e in graph["edges"]}
    graph["edges"].extend(e for e in new_edges if (e["source"], e["target"], e["relation"]) not in present_edges)
    for w in new_witnesses:
        if w["witness_id"] not in graph["canonical_witnesses"]: graph["canonical_witnesses"].append(w["witness_id"])
    atomic_json(WORK / "CAPABILITY_GRAPH.json", graph)
    dep = read_json(WORK / "DEPENDENCY_GRAPH.json")
    # DEPENDENCY_GRAPH stores node identifiers as strings; the capability
    # graph stores {id: ...} objects.  Preserve both schemas.
    dep_node_ids = [item["id"] for item in new_nodes]
    for node_id in dep_node_ids:
        if node_id not in dep["nodes"]:
            dep["nodes"].append(node_id)
    for e in new_edges:
        item = {"prerequisite": e["source"], "dependent": e["target"], "relation": e["relation"]}
        if item not in dep["edges"]: dep["edges"].append(item)
    dep["high_value_crossfeeds"] = [
        {"id": "CF_LEARNING_TRANSFER", "status": "PASS_C7H01", "information_gain": "major"},
        {"id": "CF_RELATIONAL_OPERATOR", "status": "PASS_C7H02_PLUS_SYNTHESIS", "information_gain": "major"},
        {"id": "CF_RESOURCE_ACCOUNTING", "status": "PASS_C7H02; REUSABLE_CYCLE_NEGATIVE_C7H04", "information_gain": "major"},
        {"id": "CF_CLOSED_LOOP", "status": "ONE_PASS_FEEDBACK_PASS_C7H04", "information_gain": "major"},
        {"id": "CF_LEARNING_MATTER_REPAIR", "status": "REPROGRAMMING_PASS; REPAIR_NEGATIVE_C7H03", "information_gain": "major"},
        {"id": "EXTRA02_MULTICLASS", "status": "CAUSAL_ROBUST_PASS; COMPETITIVE_NEGATIVE", "information_gain": "major"},
    ]
    atomic_json(WORK / "DEPENDENCY_GRAPH.json", dep)
    source_index = read_json(WORK / "SOURCE_INDEX.json")
    digits_source = {"source_id": "EXTRA02_DIGITS", "path": "extra02/digits.csv.gz", "role": "OFFICIAL_EXTERNAL_DATASET", "sha256": sha256_file(WORK / "extra02" / "digits.csv.gz"), "bytes": (WORK / "extra02" / "digits.csv.gz").stat().st_size, "url": "https://github.com/scikit-learn/scikit-learn/blob/main/sklearn/datasets/data/digits.csv.gz"}
    unique_append(source_index["sources"], [digits_source], "source_id"); atomic_json(WORK / "SOURCE_INDEX.json", source_index)
    print(json.dumps({"atlas_records": atlas["record_count"], "new_witnesses": len(new_witnesses), "capability_nodes": len(graph["nodes"]), "capability_edges": len(graph["edges"]), "unification": unification["classification"]}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__": raise SystemExit(main())
