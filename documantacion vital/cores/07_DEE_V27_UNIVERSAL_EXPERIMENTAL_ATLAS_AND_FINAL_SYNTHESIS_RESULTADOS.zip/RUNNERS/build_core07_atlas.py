"""C7A00/C7A01: extract sealed evidence and build the executable atlas."""
from __future__ import annotations

import csv
import io
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import ROOT, TESTS, atomic_json, atomic_text, sha256_file

PARENTS = {
    "CORE01": ("01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip", "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4"),
    "CORE02": ("02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip", "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058"),
    "CORE03": ("03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip", "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640"),
    "CORE04": ("04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip", "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2"),
    "CORE05": ("05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip", "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b"),
    "CORE06": ("06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip", "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e"),
    "EXTRA01": ("EXTRAS/EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip", "dd8af27c8a836d9a79919fae92c2a19ee12dc5dedf635ccea92c460010484e7e"),
}

DOCS = [
    "FORMULAS Y CORRESPONDENCIAS  DEE.docx",
    "FISICA GEOMETRICA INFORMACIONAL FUNDAMENTAL DEE.docx",
    "ENCICLOPEDIA OPERATIVA Y MANUAL DEL INVESTIGADOR DEE.docx",
    "EMERGENCIA DEL SISTEMA DEE.docx",
    "DOCUMENTO MAESTRO.docx",
    "DEE_CORPUS_INTEGRAL_VOLUMENES_1_A_7_Y_ATLAS_COMPLETO.docx",
    "DEE MODELO DE LA REALIDAD.docx",
]

ALLOWED = {
    "EXACT_THEOREM", "EXACT_SECTOR_LAW", "HOLDOUT_CONFIRMED_INTERNAL",
    "BOUNDED_EMPIRICAL", "FORMAL_ONLY", "EXTERNAL_COMPATIBILITY",
    "EXTERNAL_PREDICTION", "ROSETTA_VALIDATED", "NEGATIVE_IN_TESTED_APPARATUS",
    "SUPERSEDED", "HISTORICAL_UNVERIFIED", "OPEN",
}

def find_entry(archive: zipfile.ZipFile, suffixes: tuple[str, ...]) -> zipfile.ZipInfo | None:
    matches = [e for e in archive.infolist() if any(e.filename.endswith(s) for s in suffixes)]
    if not matches:
        return None
    matches.sort(key=lambda e: (e.filename.count("/"), len(e.filename)))
    return matches[0]

def read_json_entry(archive: zipfile.ZipFile, suffixes: tuple[str, ...]):
    entry = find_entry(archive, suffixes)
    if entry is None:
        return None, None
    return json.loads(archive.read(entry).decode("utf-8-sig")), entry.filename

def read_text_entry(archive: zipfile.ZipFile, suffix: str) -> tuple[str | None, str | None]:
    entry = find_entry(archive, (suffix,))
    if entry is None:
        return None, None
    return archive.read(entry).decode("utf-8-sig", errors="replace"), entry.filename

def extract_docx(path: Path, out: Path) -> int:
    w = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    paragraphs = 0
    temporary = out.with_suffix(out.suffix + ".tmp")
    with zipfile.ZipFile(path) as archive, archive.open("word/document.xml") as stream, temporary.open("w", encoding="utf-8", newline="\n") as sink:
        for _, element in ET.iterparse(stream, events=("end",)):
            if element.tag == w + "p":
                text = "".join(node.text or "" for node in element.iter(w + "t")).strip()
                if text:
                    sink.write(text + "\n")
                    paragraphs += 1
                element.clear()
    temporary.replace(out)
    return paragraphs

def infer_family(record: dict) -> str:
    text = " ".join(str(record.get(k, "")) for k in ("category", "class", "epistemic_class", "domain", "claim", "name")).lower()
    rules = [
        ("LEARNING", ("learn", "plastic", "memoria", "memory", "successor", "arithmetic", "translation", "composition")),
        ("OBSERVER_MEASUREMENT", ("observer", "measurement", "detector", "delay-to-place", "coincidence")),
        ("PROPAGATION_CAUSALITY", ("causal", "cone", "transport", "ballistic", "velocity", "speed", "propagation")),
        ("THERMODYNAMICS_RESOURCE", ("thermo", "dissipat", "entropy", "relax", "resource", "lyapunov")),
        ("QUANTUM_FORMAL", ("quantum", "bell", "chsh", "born", "koopman", "unitary")),
        ("MATTER_INTERACTION", ("matter", "collision", "interface", "carrier", "lineage", "source")),
        ("MULTISCALE_HIERARCHY", ("q2", "q3", "basin", "gamma", "scale", "coarse", "hierarch")),
        ("SYMMETRY_GEOMETRY", ("symmetr", "geometry", "topolog", "translation equiv")),
        ("CLOCK_PHASE", ("clock", "phase", "period")),
        ("ROSETTA_EXTERNAL", ("rosetta", "external", "physical")),
        ("KERNEL_IDENTITY", ("wheel", "kernel", "abi", "hash")),
    ]
    for family, terms in rules:
        if any(term in text for term in terms):
            return family
    return "GENERAL_DYNAMICS"

def normalize_status(record: dict, history: bool = False) -> str:
    raw = " ".join(str(record.get(k, "")) for k in ("status", "adjudication", "disposition", "class", "category", "epistemic_class", "external_status")).upper()
    if "ROSETTA_VALIDATED" in raw:
        return "ROSETTA_VALIDATED"
    if "EXTERNAL_PREDICTION" in raw:
        return "EXTERNAL_PREDICTION"
    if "EXTERNAL_COMPATIBILITY" in raw or "COMPATIBLE_NOT_VALIDATING" in raw:
        return "EXTERNAL_COMPATIBILITY"
    if "SUPERSEDED" in raw or "REFUTED_AS_STATED" in raw or "RETRACT" in raw:
        return "SUPERSEDED" if history else "NEGATIVE_IN_TESTED_APPARATUS"
    if any(x in raw for x in ("FAIL", "NEGATIVE", "REFUTED", "NO_ADDED", "NOT_IDENTIFIABLE")):
        return "NEGATIVE_IN_TESTED_APPARATUS"
    if "FORMAL" in raw or "CONDITIONAL" in raw:
        return "FORMAL_ONLY"
    if any(x in raw for x in ("HOLDOUT", "CONFIRMED", "PASS")):
        return "HOLDOUT_CONFIRMED_INTERNAL"
    if "THEOREM" in raw or "TEOREMA_EXACTO" in raw:
        return "EXACT_THEOREM"
    if "EXACT" in raw or "PROVEN" in raw:
        return "EXACT_SECTOR_LAW"
    if history and any(x in raw for x in ("UNVERIFIED", "UNVERIFIABLE", "HISTORICAL")):
        return "HISTORICAL_UNVERIFIED"
    if any(x in raw for x in ("EMPIRICAL", "BOUNDED", "PROVISIONAL", "SUPPORTED", "VERIFIED")):
        return "BOUNDED_EMPIRICAL"
    return "HISTORICAL_UNVERIFIED" if history else "OPEN"

def string_value(record: dict, *keys: str) -> str:
    for key in keys:
        value = record.get(key)
        if value not in (None, "", []):
            return json.dumps(value, ensure_ascii=False) if isinstance(value, (dict, list)) else str(value)
    return "NOT_RECORDED"

def normalize(origin: str, parent_sha: str, entry: str, record: dict, index: int, history: bool = False) -> dict:
    original_id = string_value(record, "claim_id", "id")
    if original_id == "NOT_RECORDED":
        original_id = f"ROW{index:04d}"
    claim = string_value(record, "claim", "name", "outcome", "forensic_finding")
    status = normalize_status(record, history)
    if status not in ALLOWED:
        raise ValueError(status)
    family = infer_family(record)
    dependencies = string_value(record, "dependencies", "source_claim_ids", "lineage_or_uncertainty")
    source = f"PARENTS/{PARENTS[origin][0]}::{entry}"
    return {
        "claim_id": f"{origin}:{original_id}",
        "name": claim[:180],
        "family": family,
        "source": source,
        "core_or_history": origin if not history else "HISTORY",
        "source_sha256": parent_sha,
        "kernel_version": "DEE v27" if not history or "v27" in claim.lower() else "HISTORICAL/MIXED",
        "evidence_type": string_value(record, "evidence_class", "epistemic_class", "class", "claim_type", "category"),
        "domain": string_value(record, "domain", "scope", "campaign_or_scope"),
        "preparation": string_value(record, "preparation", "design", "method"),
        "observable": string_value(record, "observable", "evidence_locator", "primary_locator"),
        "intervention": string_value(record, "intervention", "method"),
        "controls": string_value(record, "controls", "null", "scope_and_caveat"),
        "result": string_value(record, "result", "adjudication", "status", "outcome", "forensic_finding"),
        "status": status,
        "exact_or_empirical": "EXACT" if status in {"EXACT_THEOREM", "EXACT_SECTOR_LAW"} else "EMPIRICAL_OR_FORMAL",
        "holdout_status": string_value(record, "holdout_status", "preregistered", "preregister_path"),
        "known_limits": string_value(record, "known_limits", "limits", "scope_and_caveat", "assumptions_limits", "scope_or_caveat"),
        "known_falsifiers": string_value(record, "known_falsifiers", "falsifier", "priority_test"),
        "dependencies": dependencies,
        "outputs_produced": string_value(record, "outputs_produced", "evidence_path", "evidence_artifact", "primary_result"),
        "possible_inputs_to_other_modules": {
            "LEARNING": ["TRANSFER", "MATTER", "COMPUTATION", "RESOURCE"],
            "OBSERVER_MEASUREMENT": ["LEARNING", "CLOSED_LOOP", "ROSETTA", "QUANTUM_FORMAL"],
            "MATTER_INTERACTION": ["LEARNING", "TRANSFER", "RESOURCE", "THERMODYNAMICS"],
            "THERMODYNAMICS_RESOURCE": ["LEARNING", "REPAIR", "COMPUTATION"],
        }.get(family, ["UNIFIED_ARCHITECTURE"]),
        "canonical_witness": string_value(record, "canonical_witness", "evidence_locator", "primary_locator"),
        "runner": string_value(record, "runner", "runner_path"),
        "result_file": string_value(record, "result_file", "evidence_path", "evidence_artifact", "primary_evidence_path"),
        "external_mapping_status": string_value(record, "external_status", "external_mapping_status", "external_physics_claimed"),
        "current_priority": "HIGH" if family in {"LEARNING", "OBSERVER_MEASUREMENT", "MATTER_INTERACTION", "THERMODYNAMICS_RESOURCE"} else "MEDIUM",
        "historical_claim": claim if history else "NOT_APPLICABLE",
        "current_adjudication": string_value(record, "adjudication", "disposition", "status"),
        "why_changed": string_value(record, "forensic_finding", "historical_update", "known_limits", "limits"),
        "evidence_source": source,
        "original_record": record,
    }

def curated_witnesses() -> list[dict]:
    rows = [
        ("W_Q0_CLOCK", "clock skew-product", "CORE01", "RUNNERS_NEW/probe_v27_binary_api.py", "ANALYSIS/binary_api/runtime_probe.json", "exact modular clock witness"),
        ("W_CAUSAL_R3", "raw radius-three witness", "CORE01", "RUNNERS_NEW/probe_v27_binary_api.py", "ANALYSIS/binary_api/runtime_probe.json", "overflow-context attained bound"),
        ("W_BALLISTIC", "free carrier shift", "CORE01", "RUNNERS_NEW/run_t8_native_ballistic.py", "RESULTS/T8", "one carrier over multiple wraps"),
        ("W_REDUCER", "blank destination reducer", "CORE01", "RUNNERS_NEW/run_t8_native_ballistic.py", "RESULTS/T8", "distinct-direction collision"),
        ("W_STATE_EVENT", "predictive state/event separation", "CORE02", "RUNNERS_NEW/run_t12_corrected_closure.py", "RESULTS/T12", "T10 FAIL plus T12 PASS"),
        ("W_Q2", "basin order predictor", "CORE03", "RUNNERS_NEW/run_msh02_refined_holdout.py", "RESULTS/MSH02", "60 unopened worlds"),
        ("W_Q3", "productive-history law", "CORE04", "RUNNERS/run_nsh07_holdout.py", "RESULTS/NSH07", "Gamma and interface/activity holdout"),
        ("W_FIBER", "destination-fiber closure", "CORE05", "RUNNERS/run_nrh03_fiber_holdout.py", "RESULTS/NRH03", "200/200 guarded one-step arrays"),
        ("W_OBSERVER", "internal measurement", "CORE05", "RUNNERS/run_nrh01_internal_observer_holdout.py", "RESULTS/NRH01", "80/80 interactions"),
        ("W_DELAY_PLACE", "delay to place", "CORE05", "RUNNERS/run_nrh04_rosetta_holdout.py", "RESULTS/NRH04", "39/39 frozen cases"),
        ("W_OBSERVER_RECURSION", "finite observer recursion", "CORE05", "RUNNERS/run_nrh05_observer_recursion_holdout.py", "RESULTS/NRH05", "fourth layer predicted"),
        ("W_PHASE_TOPOLOGY", "topology phase history", "CORE05", "RUNNERS/run_nrh06_topology_history_holdout.py", "RESULTS/NRH06", "24/24 parity predictions"),
        ("W_LEARNING", "associative plasticity", "CORE06", "RUNNERS/run_c6h01_associative_plasticity_holdout.py", "RESULTS/C6H01_associative_plasticity_holdout.json", "20/20 plus causal controls"),
        ("W_RULE", "integer translation learning", "CORE06", "RUNNERS/run_c6h03_native_successor_translation_holdout.py", "RESULTS/C6H03_native_successor_translation_holdout.json", "24/24 worlds, 96/96 channels"),
        ("W_COMPOSITION", "compositional memories", "CORE06", "RUNNERS/run_c6h04_compositional_translation_holdout.py", "RESULTS/C6H04_compositional_translation_holdout.json", "30/30 both orders"),
        ("W_KINEMATICS", "internal moving observers", "CORE06", "RUNNERS/run_c6h05_internal_kinematics_holdout.py", "RESULTS/C6H05_internal_kinematics_holdout.json", "speed classes 0/1/2"),
        ("W_MATTER", "operational matter identity", "CORE06", "RUNNERS/run_c6h06_free_carrier_state_normalization_holdout.py", "RESULTS/C6H06_free_carrier_state_normalization_holdout.json", "30/30 identity quotient"),
        ("W_BELL", "local Bell apparatus", "CORE06", "RUNNERS/run_c6h07_local_bell_apparatus_holdout.py", "RESULTS/C6H07_local_bell_apparatus_holdout.json", "CHSH=-2, no signaling"),
        ("W_DISSIPATION", "mixed gas relaxation", "CORE06", "RUNNERS/run_c6h08_dissipative_ensemble_holdout.py", "RESULTS/C6H08_dissipative_ensemble_holdout.json", "32 matched worlds"),
        ("W_EXTERNAL_NEGATIVE", "organic transduction control", "EXTRA01", "runner in EXTRA01", "sealed EXTRA01 result", "no added predictive value"),
    ]
    return [
        {"witness_id": wid, "capability": cap, "source": src, "runner": runner, "result_file": result, "minimal_case": minimal, "status": "CANONICAL"}
        for wid, cap, src, runner, result, minimal in rows
    ]

def graphs(witnesses: list[dict]) -> tuple[dict, dict]:
    nodes = [
        "Q0_RAW_CLOCK", "GUARDS", "DIRECTED_PROPOSALS", "DESTINATION_FIBERS", "GUARDED_REDUCER",
        "LINEAGES", "SOURCES", "PHASE_HISTORY", "Q2_BASIN", "Q3_PRODUCTIVE_HISTORY",
        "OBSERVER_RELATION", "MEASUREMENT", "DELAY_PLACE", "LEARNING_MEMORY", "RULE_TRANSLATION",
        "COMPOSITION", "OPERATIONAL_MATTER", "LOCAL_BELL", "DISSIPATIVE_ENSEMBLE", "EXTERNAL_ROSETTA",
    ]
    edges = [
        ("Q0_RAW_CLOCK", "DIRECTED_PROPOSALS", "decodes"),
        ("GUARDS", "DIRECTED_PROPOSALS", "selects"),
        ("DIRECTED_PROPOSALS", "DESTINATION_FIBERS", "groups-by-destination"),
        ("DESTINATION_FIBERS", "GUARDED_REDUCER", "feeds"),
        ("GUARDED_REDUCER", "LINEAGES", "creates-or-combines"),
        ("SOURCES", "LINEAGES", "emits"),
        ("PHASE_HISTORY", "SOURCES", "gates"),
        ("LINEAGES", "Q2_BASIN", "organizes"),
        ("PHASE_HISTORY", "Q3_PRODUCTIVE_HISTORY", "accumulates"),
        ("DESTINATION_FIBERS", "OBSERVER_RELATION", "implements-interaction"),
        ("OBSERVER_RELATION", "MEASUREMENT", "transduces"),
        ("MEASUREMENT", "DELAY_PLACE", "orders"),
        ("GUARDED_REDUCER", "LEARNING_MEMORY", "writes-by-experience"),
        ("LINEAGES", "LEARNING_MEMORY", "stores-and-transports"),
        ("LEARNING_MEMORY", "RULE_TRANSLATION", "parameterizes"),
        ("RULE_TRANSLATION", "COMPOSITION", "chains"),
        ("LINEAGES", "OPERATIONAL_MATTER", "instantiates"),
        ("OBSERVER_RELATION", "LOCAL_BELL", "provides-outcome"),
        ("GUARDED_REDUCER", "DISSIPATIVE_ENSEMBLE", "causes-many-to-one-loss"),
        ("DELAY_PLACE", "EXTERNAL_ROSETTA", "externally-compatible"),
    ]
    capability = {
        "schema": "dee.v27.core07.capability_graph.v1",
        "nodes": [{"id": node} for node in nodes],
        "edges": [{"source": a, "target": b, "relation": r} for a, b, r in edges],
        "canonical_witnesses": [w["witness_id"] for w in witnesses],
    }
    dependency = {
        "schema": "dee.v27.core07.dependency_graph.v1",
        "nodes": nodes,
        "edges": [{"prerequisite": a, "dependent": b, "relation": r} for a, b, r in edges],
        "high_value_crossfeeds": [
            {"id": "CF_LEARNING_TRANSFER", "depends_on": ["LEARNING_MEMORY", "LINEAGES", "OBSERVER_RELATION"], "priority": 1},
            {"id": "CF_RELATIONAL_OPERATOR", "depends_on": ["DESTINATION_FIBERS", "GUARDED_REDUCER", "PHASE_HISTORY"], "priority": 2},
            {"id": "CF_RESOURCE_ACCOUNTING", "depends_on": ["LEARNING_MEMORY", "GUARDED_REDUCER", "DISSIPATIVE_ENSEMBLE"], "priority": 3},
            {"id": "CF_CLOSED_LOOP", "depends_on": ["OBSERVER_RELATION", "LEARNING_MEMORY", "LINEAGES"], "priority": 4},
            {"id": "EXTRA02_MULTICLASS", "depends_on": ["LEARNING_MEMORY", "RULE_TRANSLATION", "COMPOSITION"], "priority": 5},
        ],
    }
    return capability, dependency

def main() -> None:
    source_index = {"schema": "dee.v27.core07.source_index.v1", "sources": []}
    normalized: list[dict] = []
    extracts = ROOT / "LEGACY_EXTRACTS"
    extracts.mkdir(exist_ok=True)

    for origin, (relative, expected) in PARENTS.items():
        path = ROOT / "PARENTS" / relative
        observed = sha256_file(path)
        if observed != expected:
            raise RuntimeError(f"parent mismatch {origin}: {observed}")
        source_index["sources"].append({"source_id": origin, "path": f"PARENTS/{relative}", "bytes": path.stat().st_size, "sha256": observed, "role": "SEALED_PARENT"})
        with zipfile.ZipFile(path) as archive:
            if origin.startswith("CORE"):
                report_dir = extracts / origin
                report_dir.mkdir(exist_ok=True)
                for suffix in ("EXECUTIVE_VERDICT.md", "FINAL_REPORT.md"):
                    text, entry = read_text_entry(archive, suffix)
                    if text is not None:
                        atomic_text(report_dir / suffix, text)
                data, entry = read_json_entry(archive, ("CLAIM_LEDGER.json", "CLAIMS.json"))
                if data is not None:
                    rows = data.get("claims", data) if isinstance(data, dict) else data
                    for index, record in enumerate(rows, 1):
                        normalized.append(normalize(origin, expected, entry, record, index))
            if origin == "CORE01":
                for suffix, label in (("CLAIMS_DOCUMENTARY.csv", "DOCUMENTARY"), ("CLAIMS_EXTRACTED.csv", "CAMPAIGN_FORENSIC")):
                    text, entry = read_text_entry(archive, suffix)
                    if text is None:
                        continue
                    for index, record in enumerate(csv.DictReader(io.StringIO(text)), 1):
                        normalized.append(normalize(f"CORE01", expected, entry, record, index, history=True) | {"claim_id": f"HISTORY:{label}:{record.get('claim_id', index)}"})

    corpus_rows = []
    for filename in DOCS:
        path = TESTS / "necesarios" / filename
        if not path.is_file():
            corpus_rows.append({"source_id": filename, "status": "MISSING"})
            continue
        slug = re.sub(r"[^A-Za-z0-9]+", "_", path.stem).strip("_")[:80]
        out = extracts / f"{slug}.txt"
        paragraphs = extract_docx(path, out)
        row = {
            "source_id": f"LEGACY_{slug}", "path": str(path), "bytes": path.stat().st_size,
            "sha256": sha256_file(path), "status": "EXTRACTED", "paragraphs": paragraphs,
            "extract": f"LEGACY_EXTRACTS/{out.name}", "extract_sha256": sha256_file(out),
        }
        corpus_rows.append(row)
        source_index["sources"].append(row | {"role": "HISTORICAL_CORPUS"})

    atlas = {
        "schema": "dee.v27.core07.universal_atlas.v1",
        "record_count": len(normalized),
        "allowed_statuses": sorted(ALLOWED),
        "authority_order": ["executed bytes", "results/holdouts", "exact runners", "theorems/proofs", "same-core reports", "later transverse syntheses", "historical documents", "names/analogies"],
        "records": normalized,
    }
    witnesses = curated_witnesses()
    capability, dependency = graphs(witnesses)
    atomic_json(ROOT / "SOURCE_INDEX.json", source_index)
    atomic_json(ROOT / "UNIVERSAL_ATLAS.json", atlas)
    atomic_json(ROOT / "CAPABILITY_GRAPH.json", capability)
    atomic_json(ROOT / "DEPENDENCY_GRAPH.json", dependency)
    atomic_json(ROOT / "CANONICAL_WITNESSES.json", {"schema": "dee.v27.core07.canonical_witnesses.v1", "witnesses": witnesses})
    atomic_text(ROOT / "CLAIM_LEDGER.ndjson", "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in normalized))
    atomic_text(ROOT / "LEGACY_CORPUS_INDEX.ndjson", "".join(json.dumps(row, ensure_ascii=False, sort_keys=True) + "\n" for row in corpus_rows))
    result = {
        "schema": "dee.v27.core07.c7a01.v1",
        "module_id": "C7A01_UNIVERSAL_ATLAS",
        "status": "COMPLETE",
        "parent_sources": len(PARENTS),
        "core_and_historical_claim_records": len(normalized),
        "legacy_documents": len(corpus_rows),
        "legacy_documents_extracted": sum(r.get("status") == "EXTRACTED" for r in corpus_rows),
        "canonical_witnesses": len(witnesses),
        "capability_nodes": len(capability["nodes"]),
        "capability_edges": len(capability["edges"]),
    }
    atomic_json(ROOT / "RESULTS" / "C7A01_universal_atlas.json", result)
    print(json.dumps(result, indent=2))

if __name__ == "__main__":
    main()
