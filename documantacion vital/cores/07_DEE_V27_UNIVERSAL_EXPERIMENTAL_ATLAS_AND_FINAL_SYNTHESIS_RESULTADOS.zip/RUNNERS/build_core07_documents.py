#!/usr/bin/env python3
"""Build the evidence-linked final scientific documents for CORE07."""
from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import ROOT, atomic_json, atomic_text, sha256_file


def load(relative: str):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def save(name: str, body: str) -> None:
    atomic_text(ROOT / name, body.strip() + "\n")


def main() -> int:
    prior_state_path = ROOT / "STATE.json"
    if prior_state_path.is_file() and (ROOT / "FINAL_REPORT.md").is_file():
        prior_state = load("STATE.json")
        if prior_state.get("status") == "COMPLETE":
            print(json.dumps({"documents": "SKIP_COMPLETE", "state": "COMPLETE"}, indent=2))
            return 0
    h1 = load("RESULTS/C7H01_functional_learning_transfer.json")
    h2 = load("RESULTS/C7H02_destination_fiber_capacity_budget.json")
    h3 = load("RESULTS/C7H03_reprogrammable_functional_matter.json")
    h4 = load("RESULTS/C7H04_internal_feedback_resource_closure.json")
    ex = load("RESULTS/EXTRA02_noisy_multiclass_final.json")
    atlas = load("UNIVERSAL_ATLAS.json")
    cap = load("CAPABILITY_GRAPH.json")
    witnesses = load("CANONICAL_WITNESSES.json")
    audit = load("RESULTS/C7A04_adversarial_audit.json")
    uni = load("RESULTS/C7A02_unified_relational_operator.json")
    primary = ex["mode_metrics"]["trained_primary"]
    clean = ex["mode_metrics"]["trained_clean"]
    knn = ex["baselines"]["knn3_20shot_primary"]["accuracy"]
    logit = ex["baselines"]["multinomial_logistic_20shot_primary"]["accuracy"]
    common_header = (
        "> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado "
        "en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.\n"
    )

    save("EXECUTIVE_VERDICT.md", f"""
# Veredicto ejecutivo — CORE07

{common_header}

CORE07 encuentra un mecanismo nativo transversal real, pero sectorial: el **operador de fibras de destino con reducción guardada**. El estado relacional útil es un multigrafo dirigido de propuestas agrupado por destino, anotado por guardas, ocupación del destino, fuente y contexto de fase/historia; sus salidas continúan como linajes. En el sector normal fuente-libre y destino vacío, el cociente

`Z_f = (k, Σs_reg, sign(Σdirection))`

cierra exactamente, debajo del cap, los observables declarados: una fibra no vacía produce un soporte, suma `s_reg` con saturación y compone la dirección por signo; por ello cada colisión de `k` entradas contrae soporte en `k-1`. No es un Q4 global: fuentes, destinos ocupados, guardas semánticas/clock, procedencia de eventos y Q2/Q3 requieren anotaciones adicionales.

Resultados nuevos fuertes:

- **FUNCTIONAL_LEARNING_TRANSFER_CONFIRMED:** 48/48 transferencias exactas y 128/128 controles causales inexactos, con límite Wilson 95% de 0.9259.
- **DESTINATION_FIBER_CAPACITY_LAW:** 86/86 canales separados exactos hasta `K=40`; 8/8 solapamientos integraron las memorias y 0/8 preservaron identidad individual.
- **MATTER_REPROGRAMMING_FOUND**, en sentido operacional: 48/48 cambios funcionales exactos y 96/96 controles inexactos. La identidad preservada es un cociente de respuesta/linaje, no el microestado.
- **INTERNAL_ONE_PASS_FEEDBACK_CIRCUIT_FOUND:** 12/12 circuitos cerraron espacialmente, 28/28 controles fallaron; el soporte se contrajo 6→1, sin memoria ni actuadores reutilizables.
- **EXTRA02:** aprendizaje multiclase causal y robusto sobre `digits`, con {100*primary['strict_stable_accuracy']:.2f}% de accuracy estable bajo daño 10/64, {100*ex['robustness_retention']:.2f}% de retención y controles entre 1.11% y 12.22%. No es competitivo: kNN obtuvo {100*knn:.2f}% y regresión logística {100*logit:.2f}%.

La compresión teórica nueva es: **función = cociente de respuesta de un linaje; capacidad = separación relacional entre fibras; cómputo y recurso son dos caras del mismo reductor; el observador puede estar dentro de la cadena causal**.

Negativos conservados: no reparación genérica retardada, no ciclo fuente-libre reutilizable, no clasificador competitivo, no Q4 global, no nueva estructura Lorentz/luz, Bell permanece local con CHSH=-2, no termodinámica completa y ninguna Rosetta externa está validada.

Rosetta: `retardo relativo → coincidencia → lugar ordenado` permanece en **EXTERNAL_COMPATIBILITY**. Falta un dataset independiente a nivel de registro que una anatomía, retardo/fase monaural, best ITD/IPD, frecuencia característica y jerarquía animal/penetración; sin él no existe predicción externa válida.

Cierre: se agotaron las interrogaciones internas de alta información que dependían sólo de mecanismos ya demostrados. Las fronteras restantes requieren datos externos, nueva teoría, nuevo kernel o escala computacional; no se inventa CORE08.
""")

    save("FINAL_REPORT.md", f"""
# Informe final — CORE07 Universal Experimental Atlas, Cross-Feeding and Final Synthesis

{common_header}

## 1. Objeto y procedencia

Se verificaron por SHA-256 y se copiaron byte por byte CORE01–06 y EXTRA01. El wheel ejecutado fue `69297e6f...abc939`, el binario `.pyd` `0b17ba32...2c6ff` y el paquete Python `7e2991b1...df8b4`, bajo CPython 3.13 x64. Los padres permanecen inmutables dentro de `PARENTS/`.

El atlas normaliza **{atlas['record_count']} claims**, **{len(cap['nodes'])} capacidades**, **{len(cap['edges'])} relaciones** y **{len(witnesses['witnesses'])} testigos canónicos**. Las afirmaciones históricas se conservaron con su estado actual; un nombre histórico nunca sustituyó bytes, runner, resultado o holdout.

## 2. Ciclo científico nuevo

La prioridad fue probar el cross-feed entre capacidades ya separadas. Cada afirmación fuerte se descubrió en dominio diferente, se congeló en `HOLDOUT_LOCKS/`, se hasheó y se abrió una sola vez.

| Módulo | Pregunta | Resultado | Alcance |
|---|---|---|---|
| C7H01 | ¿se transfiere una función aprendida? | PASS: 48/48; 128/128 controles | transporte continuo por corredor, no teleportación |
| C7H02 | ¿qué controla capacidad/interferencia? | PASS: 86/86 separados; 8/8 fusiones | sector normal fuente-libre; K=40 es cota inferior |
| C7H03 | ¿materia operacional retiene una reprogramación? | PASS: 48/48; 96/96 controles | cociente funcional, no microidentidad ni materia externa |
| C7H04 | ¿puede cerrarse detector→memoria→acción→detector? | PASS: 12/12; 28/28 controles | circuito one-pass; no agencia ni ciclo reusable |
| EXTRA02 | ¿escala a diez clases con daño? | PASS causal/robusto; FAIL competitivo | histograma/reductor categórico supervisado |

## 3. Ley transversal

Para cada actualización se forma el grafo de propuestas `P_t: x→d`. Las entradas con destino común forman `F_d`; una guarda `g_d` incluye sector semántico, ocupación, source flag y contexto clock/fase/historia. El kernel aplica `ρ(F_d,g_d)` y las salidas forman linajes futuros. El candidato global es:

`Z_rel(t) = (P_t, {{F_d}}, {{g_d}}, lineages, sources, phase/history)`.

En destinos normales vacíos, fuente-libre y debajo de saturación, el subcociente `Z_f=(k,Σs,signΣd)` es exacto para soporte, `s_reg` y dirección. Esta ley explica simultáneamente integración de memorias, interferencia por solapamiento, suma nativa, contracción disipativa, registro de detector, transferencia de función y scores de EXTRA02.

La extensión no constituye cierre comprimido global. En el peor caso, conservar destinos, guardas, historias y linajes puede aproximarse en complejidad a Q0. Por eso el veredicto correcto es **RELATIONAL_CLOSURE_EXTENDED_CROSS_DOMAIN + NO_GLOBAL_Q4**.

## 4. Aprendizaje, función y materia

CORE06 ya demostró plasticidad asociativa, generalización por clase, traducciones enteras y composición en dominios acotados. CORE07 añade una propiedad cualitativamente distinta: el repertoire aprendido puede viajar por relays y reaparecer en B ante queries nuevas. La intervención sobre corredor, fuente, dirección, carga o memoria destruye la respuesta esperada.

La misma construcción permite reprogramar una entidad operacional sin reconstruirla: una experiencia cambia su respuesta futura de `R0` a `R1` y el cambio persiste al transporte y a nuisances de estado/clock. Sin embargo, borrar soporte, carga o dirección no fue reparado por un scaffold tardío. Hay materia funcional reprogramable, no materia auto-reparadora en la clase probada.

## 5. Procesamiento externo EXTRA02

Se usó el `load_digits` oficial: 1797 imágenes 8×8, sin duplicados exactos. El split estratificado 60/20/20 y sus hashes se congelaron. Veinte ejemplos por clase alimentaron diez teacher ports mediante interacciones DEE normales; el encoder umbraliza intensidades sin labels y el readout es argmax fijo.

En FINAL TEST de 360 imágenes: clean={100*clean['strict_stable_accuracy']:.2f}%; daño cero en 10/64={100*primary['strict_stable_accuracy']:.2f}%; balanced={100*primary['balanced_accuracy']:.2f}%; macro-F1={100*primary['macro_f1']:.2f}%; estabilidad W=3=100%; retención={100*ex['robustness_retention']:.2f}%. Los 15,120 calls reales del kernel reprodujeron exactamente el score analítico del reductor.

Los controles obligatorios colapsaron y sus intervalos bootstrap quedaron por debajo del efecto. Pero kNN y logística, con los mismos veinte ejemplos/clase, obtuvieron {100*knn:.2f}% y {100*logit:.2f}%. La arquitectura demuestra aprendizaje causal DEE y robustez, no superioridad computacional ni evidencia de H_DEE.

## 6. Recursos y circuito interno

La reducción many-to-one consume soporte: en C7H04, seis carriers preconfigurados producen un registro final y dejan cero memoria/actuadores. El circuito contiene sensing, memoria, acción y retorno dentro de DEE, sin decisión Python durante la evolución, pero no puede iterar sin fuente o nueva inyección. `s_reg` lleva un accounting exacto en el sector, pero no se identifica con energía física.

## 7. Ramas condicionales

- FactorX: no reabierto; no surgió operador iterativo/modular nuevo que supere la genealogía trial-division-like.
- Propagación: se heredan `c_transport=1` y radio raw ≤3. La transferencia usa carriers continuos y no aporta un modo/clock/ruler nuevo; no hay Rosetta de luz.
- Quantum: no cambiaron settings, factorización ni normalización. CHSH=-2; estructura formal solamente.
- Termodinámica: avanzó el accounting y la disipación sectorial, pero faltan estacionariedad universal, variable conjugada, fluctuación y ciclo reusable.
- Rosetta: se renovó la búsqueda; sólo permanece compatibilidad externa del candidato delay/place.

## 8. Revisión adversarial

La revisión única obtuvo `{audit['final_adjudication']}` y no exigió rerun. Confirmó hashes de locks, ausencia de uso del FINAL TEST durante discovery, unidad estadística correcta y controles causales. Impuso el lenguaje conservador de este informe: el clasificador simple explica la eficacia externa; “materia”, “observador” y “feedback” son categorías operacionales; ninguna correspondencia física está validada.

## 9. Stopping rule

Se adjudicaron todas las conexiones de prioridad máxima y EXTRA02. Reabrir relatividad, quantum o factorización sin una nueva premisa repetiría aparatos negativos. Escalar K sólo aumentaría una cota inferior ya decidida; mejorar el clasificador exigiría una arquitectura nueva, no un sweep. La Rosetta requiere datos externos inexistentes. CORE07 cierra esta etapa con fronteras explícitas, no con una afirmación de que DEE esté terminada.
""")

    save("TRANSVERSAL_CORE01_TO_07.md", f"""
# Síntesis transversal CORE01–07

{common_header}

| CORE | Aporte que sobrevive | Límite vigente |
|---|---|---|
| 01 | Q0=`raw+clock`, causalidad local raw≤3, carrier balístico, fuentes/colisiones, leyes sectoriales | no equivalencia física global |
| 02 | estados/eventos separados; M-star, G-dagger, J-dagger, roles L/C/O y fibras predictivas | las fibras certificadas no son cierre universal |
| 03 | Q2 basin/organización y predictor `q_N` en dominio holdout | `q_N` no es causa fundamental ni universal |
| 04 | ledger S/R/C/X/D, `A_t`, Γ y Q3 de histories productivas | no Q4 global ni cierre completo con `(q,κ,a,Γ)` |
| 05 | proposal graph, destination fibers, observador/medición internos, delay-to-place, fase/historia | recurrencia finita; Rosetta sólo interna/estructural |
| 06 | aprendizaje, traducciones/composición, materia operacional, cinemática interna, Bell local, ensambles disipativos, Rosetta compatible | sin regla aritmética general, Lorentz, quantum físico ni termodinámica completa |
| 07 | transferencia funcional, capacidad relacional, reprogramación, feedback one-pass, EXTRA02 y operador unificador | cierre sectorial, no Q4 global ni Rosetta validada |

La jerarquía no es una pirámide única. `raw/clock`, routing, carga/provenance, semantic guards, fibers, linajes, historia, basin, observador, aprendizaje y ensemble son coordenadas cruzadas con dependencias parciales. Q0 es Markoviano completo; Q1–Q3 son cocientes útiles en dominios certificados. CORE07 añade un operador transversal, no un nuevo nivel nominal.

Genealogía de cambio principal: los documentos históricos que llamaron a una constante, forma o aparato “energía”, “luz”, “quantum” o “teleportación” se conservan como historia, pero la adjudicación vigente exige función causal, dominio, control y holdout. `CLAIM_LEDGER.ndjson` conserva simultáneamente fuente y estado actual.
""")

    save("UNIFIED_NATIVE_ARCHITECTURE.md", f"""
# Arquitectura nativa unificada

{common_header}

## Operador

1. `X_t=(raw_t,clock_t)` es el estado microscópico completo.
2. Guardas locales habilitan propuestas dirigidas `x→d`.
3. Propuestas con el mismo destino forman una fibra `F_d`.
4. El reductor guardado `ρ(F_d,g_d)` resuelve colisión, ocupación, source y contexto.
5. Las salidas forman linajes que transportan estado, carga, routing e historia.
6. Conjuntos de linajes forman organización; otra organización puede actuar como detector y su registro alimentar acciones posteriores.

En el sector normal fuente-libre, destino vacío, debajo de cap:

`ρ: (k, {{s_i}}, {{d_i}}) ↦ (support=1, s'=min(Σs_i,19664), d'=sign(Σd_i))`.

La contracción de soporte es exactamente `k-1`. Este cociente explica aprendizaje y composición como escritura por colisión; transferencia como transporte/relay del cociente de respuesta; materia operacional como linaje persistente/interactuable; medición como acoplamiento a una fibra; cómputo como integración; disipación como pérdida many-to-one.

## Cuatro principios nuevos

- **FUNCTION_IS_A_LINEAGE_RESPONSE_QUOTIENT.** La identidad científicamente estable puede ser el repertoire `R(query)`, no el bit pattern.
- **CAPACITY_IS_RELATIONAL.** El número de memorias independientes depende de destinos separados; el solapamiento integra.
- **COMPUTATION_RESOURCE_DUALITY.** El reductor calcula y consume carriers en el mismo evento.
- **OBSERVER_IS_NOT_EXTERNAL.** Detector, registro, acción y retorno pueden estar realizados por DEE.

## Dónde falla el cierre

No están absorbidos globalmente: semantic-4 sources, destinos preocupados, guardas clock/fase, provenance completo, topología global, basins Q2/Q3 y observables físicos externos. Añadirlos puede eliminar la compresión. Por tanto no existe un Q4 global demostrado.

Fuente primaria: `RESULTS/C7A02_unified_relational_operator.json`; testigos C7H01–H04 y EXTRA02.
""")

    save("CROSS_FEED_RESULTS.md", f"""
# Resultados de cross-feeding

{common_header}

| Conexión | Prueba | Veredicto | Información nueva |
|---|---|---|---|
| learning→transfer | C7H01 | PASS | la función aprendida reaparece en B para queries no usadas en training |
| fiber topology→capacity | C7H02 | PASS | K≥40 si destinos se separan; el overlap integra y destruye identidad separada |
| learning→matter | C7H03 | PASS acotado | el mismo linaje puede adquirir y conservar un repertoire nuevo |
| learning→repair | C7H03 | FAIL | direction-zero, load erasure y support destruction no se reparan tarde |
| observer→control | C7H04 | PASS one-pass | un record interno causa acción y retorno sin elección Python |
| resource→feedback | C7H04 | NEGATIVO reusable | soporte 6→1; aparatos consumidos |
| learning→external task | EXTRA02 | PASS causal/robusto | generalización multiclase no vista y tolerancia a daño |
| computation→baseline | EXTRA02 | FAIL competitive | histograma/reductor no supera kNN/logística |

El ranking de `DEPENDENCY_GRAPH.json` fue usado para ejecutar sólo conexiones que separaban hipótesis. Factorización, relatividad y quantum no se reabrieron porque ningún resultado cambió sus premisas operacionales.
""")

    save("NATIVE_LEARNING_SCALE.md", f"""
# Escala del aprendizaje nativo

{common_header}

La escalera acumulada es: memoria/plasticidad asociativa → discriminación y generalización por clase → traducciones enteras acotadas → composición → transferencia funcional → memoria multiclase dañada. La experiencia siempre entra por interfaces normales; no se edita el estado final para escribir respuestas.

C7H01 demuestra transferencia, C7H02 separa capacidad de interferencia, C7H03 demuestra reprogramación monotónica y EXTRA02 prueba 10 clases. La capacidad probada alcanza K=40 fibras separadas y 1003 celdas no cero en el estado aprendido de EXTRA02; K=40 es una cota inferior experimental, no una capacidad máxima.

La ley de interferencia es simple: destinos distintos conservan respuestas; un destino compartido reduce a un único linaje con respuesta compuesta. Esto da multi-memory por topología, pero no demuestra memoria densa óptima, rule induction universal ni aprendizaje continuo sin interferencia.

EXTRA02 generaliza a imágenes inéditas y daño, pero su estado es un histograma categórico con tamaño ligado a clase×feature. No hay evidencia de una representación semántica compacta, few-shot excepcional ni ventaja de complejidad.
""")

    save("EXTRA02_NOISY_MULTICLASS_BENCHMARK.md", f"""
# EXTRA02 — Noisy Multiclass Topological Stress

{common_header}

## Protocolo congelado

Dataset oficial scikit-learn digits, SHA-256 `09f66e6d...aa22`; 1797 imágenes únicas 8×8. Split estratificado determinista train/validation/final = 1078/359/360. Curriculum: 20 imágenes por clase. Encoder label-blind: pixel activo si intensidad≥8. Teacher: uno de diez puertos fijos durante training. Readout: argmax fijo; respuesta estable W=3. Daño primario: 10/64 píxeles a cero.

## FINAL TEST

| Métrica | Clean | Daño 10/64 |
|---|---:|---:|
| accuracy estable | {100*clean['strict_stable_accuracy']:.2f}% | {100*primary['strict_stable_accuracy']:.2f}% |
| balanced accuracy | {100*clean['balanced_accuracy']:.2f}% | {100*primary['balanced_accuracy']:.2f}% |
| macro F1 | {100*clean['macro_f1']:.2f}% | {100*primary['macro_f1']:.2f}% |
| stable-answer W=3 | {100*clean['stable_answer_rate']:.2f}% | {100*primary['stable_answer_rate']:.2f}% |

Retención: {100*ex['robustness_retention']:.2f}%. Controles: untrained/reset/memory-ablation/encoder-only 9.72%; no-teacher 9.44%; label-shuffle 1.11%; rewiring 12.22%. Todos los márgenes bootstrap preregistrados fueron positivos. La equivalencia kernel↔reductor analítico fue 100% en todas las corridas auditadas.

Baselines matched 20-shot: kNN-3 {100*knn:.2f}%, logística multinomial {100*logit:.2f}%. Conclusiones: `CAUSAL_MULTICLASS_LEARNING_FOUND` y `ROBUST_MULTICLASS_CLASSIFIER_FOUND`; `COMPETITIVE_ARCHITECTURE_CANDIDATE=false`; `SUPERIORITY_CANDIDATE=false`.

No es una prueba de H_DEE. Es una demostración de capacidad de ingeniería causal con mecanismo explícito y no novedoso: acumulación categórica por fibras.
""")

    save("MATTER_REPROGRAMMING.md", f"""
# Materia operacional reprogramable

{common_header}

Se usa “materia_DEE” sólo para una organización persistente, interactuable, detectable y con respuesta reproducible. C7H03 mantuvo un linaje, aplicó experiencias normales y cambió su repertoire R0→R1. Resultado: 48/48 positivos exactos, 96/96 controles inexactos; nuisances de state y clock no alteraron la función.

La identidad preservada es `I=[lineage]_R`, clase de equivalencia por respuestas a un conjunto congelado de queries. No se preserva un microestado individual a través de colisiones, por lo que `MATTER_REPROGRAMMING_FOUND` no implica partícula, masa, materia externa ni reprogramación arbitraria.

Negativo fuerte: un scaffold tardío no restauró direction-zero, load borrado ni soporte destruido: 0% en los tres paneles. No se halló reparación o adaptación autónoma en la clase probada.
""")

    save("LEARNING_TRANSFER.md", f"""
# Transferencia de aprendizaje

{common_header}

C7H01 entrena una asociación/traducción en A mediante colisión, transporta el linaje aprendido por un corredor de relays de carga cero y consulta en B con queries no vistas durante ese episodio. Pasó 48/48 casos entre N=53,59,67,73 y cuatro marcos de permutación con signo; 128/128 controles de no-transfer, source removed, corridor cut, off-path cut, direction zero, state nuisance no causal, untrained source, memory ablation y destination sham discriminaron según el lock.

Lo que se transfiere no es el mismo microestado: es un mapa de respuesta `R(q)`. El mecanismo requiere cada paso intermedio del corredor y tiempo de first-passage compatible; por ello no es transferencia discontinua ni teleportación física. Clasificación: **FUNCTIONAL_LEARNING_TRANSFER_CONFIRMED**.
""")

    save("FUNCTIONAL_IDENTITY.md", f"""
# Identidad funcional

{common_header}

Definición operacional: dos realizaciones son equivalentes respecto de un probe set Q si producen el mismo `R:Q→outputs` dentro de tolerancia y bajo nuisances congelados. C7H01 muestra que esta identidad puede sobrevivir a relay/translation; C7H03 muestra que puede cambiar por experiencia sin reconstrucción externa; C7H02 muestra que colisionar dos identidades en una misma fibra produce una identidad compuesta y elimina la lectura individual.

Así, la identidad DEE útil tiene tres componentes: continuidad causal del linaje, repertoire de respuesta y dominio de probes. No es identidad de bits, alma de partícula ni conservación global. Esta formulación comprime aprendizaje, transferencia y materia operacional con un solo objeto.
""")

    save("RESOURCE_AND_THERMODYNAMICS.md", f"""
# Recursos y termodinámica

{common_header}

En el sector normal fuente-libre, una fibra con k entradas produce un soporte: `Δsupport=-(k-1)`. `s_reg` suma hasta 19664. C7H02 confirmó el accounting durante training/read; C7H04 siguió un circuito completo 6→1. El mismo evento que integra información gasta grados activos: **computation-resource duality**.

Esto extiende la disipación sectorial de CORE06, pero no es energía ni termodinámica completa. No se obtuvo regeneración en reposo, ciclo reusable, ensemble estacionario universal, detailed balance, variable intensiva conjugada, ley de fluctuaciones o límite termodinámico. Sources/inyección externa cambian el accounting y deben incluirse explícitamente.

Veredictos: `RESOURCE_ACCOUNTING_STRUCTURE_FOUND`; `NO_NATIVE_REUSABLE_RESOURCE_CYCLE` en el aparato fuente-libre probado; `THERMODYNAMIC_STRUCTURE_FOUND` sólo en sentido de ensamble/disipación sectorial, no equivalencia física.
""")

    save("OBSERVER_CLOSED_LOOP.md", f"""
# Observador y circuito cerrado interno

{common_header}

C7H04 realiza una cadena espacial preconfigurada `sensor→memory→action→return-to-sensor`. El output del detector entra causalmente a subsistemas DEE posteriores; Python no elige la acción tras leer el estado. Doce de doce aparatos cerraron y 28 controles sobre cortes/dirección/memoria/acción no produjeron el record esperado.

El resultado convierte al observador de CORE05 en un componente causal capaz de alimentar conducta futura. Sin embargo, es one-pass: memoria y actuadores son consumidos, y no hay aprendizaje online, acción elegida, homeostasis o ciclo repetible. El nombre admisible es **INTERNAL_ONE_PASS_FEEDBACK_CIRCUIT_FOUND**, no agencia.
""")

    save("COMPUTATION_AND_FACTORING.md", f"""
# Computación, aritmética y factorización

{common_header}

Se heredan suma nativa de colisiones, aprendizaje de traducciones enteras y composición acotada. EXTRA02 muestra que el mismo reductor puede acumular evidencia por clase; C7H02 muestra que su capacidad depende de fibras separadas y que overlap integra.

No apareció en CORE07 un mecanismo nuevo de iteración, residuos, divisibilidad o reutilización de operador que altere FactorX. Repetir su genealogía trial-division-like sólo reproduciría un negativo cerrado. No hay ventaja asintótica o práctica de factorización demostrada.

El descubrimiento computacional real es la equivalencia exacta entre dinámica del kernel y un reductor categórico explicable. Es causal y robusto, pero no competitivo con baselines simples.
""")

    save("PROPAGATION_RELATIVITY_STATUS.md", f"""
# Propagación y relatividad — estado final

{common_header}

Se heredan dos velocidades distintas: carrier normal libre `c_transport=1 L∞/tick` y cota de dependencia raw `r∞≤3` por ramas del kernel. CORE06 construyó ruler/clock internos, pero moving observers no midieron una velocidad universal ni relaciones Lorentz.

C7H01 no cambia el problema: la función viaja de forma continua por carriers y relays, con estados intermedios causales. No emergió un modo colectivo, clock/ruler o transformación de observador nuevos. Por la regla condicional, el aparato relativista no se repitió.

Estados: `CARRIER_SPEED_CONFIRMED`; `RAW_CAUSAL_BOUND_CONFIRMED`; no `OPERATIONAL_INVARIANT_SPEED`, no `RELATIVISTIC_STRUCTURE`, no `LIGHT_ROSETTA`. Esto no es un teorema de ausencia global de modos colectivos.
""")

    save("QUANTUM_STATUS.md", f"""
# Quantum — estado final

{common_header}

El aparato Bell operacional de CORE06 produjo CHSH=-2. Existen phase, observers, settings y outcomes internos, pero no una regla Born, amplitudes normalizadas, interferencia física confirmada, no-factorización operacional o violación Bell.

CORE07 no descubrió una estructura que cambie las premisas de aquel aparato; variar settings hasta hallar una violación habría sido target hacking. La clasificación permanece **QUANTUM_FORMAL_STRUCTURE_ONLY**. Las etiquetas históricas “quantum”, “entanglement”, “teleportation” o “nonlocal” se conservan como formalismo/analogía o claim no verificado, no como física probada.
""")

    save("ROSETTA_MASTER.md", f"""
# Rosetta maestra

{common_header}

## Ranking final

1. `relative delay → coincidence → ordered place`: **EXTERNAL_COMPATIBILITY**. Mapa interno congelado, cero parámetros funcionales por caso y compatibilidad con organización binaural publicada.
2. destination-fiber integration/resource: ley interna fuerte, pero sin observable externo y preparación física independientes; **FORMAL_EQUIVALENCE_CANDIDATE** como clase many-to-one, no Rosetta.
3. functional lineage/transfer: fenómeno interno nuevo, sin target externo preregistrable; **STRUCTURAL_ANALOGY** con transducción/identidad funcional.
4. ballistic/causal transport: estructura interna, pero sin invariancia de observador; **NO_LIGHT_ROSETTA_FOUND**.
5. Bell/quantum: **FORMAL_ONLY**.

La búsqueda externa renovada confirmó que el trabajo de Köppl y Carr (2008; PMID 18491165, PMCID PMC3170859) es relevante a la familia delay/place, pero no proporcionó el objeto row-level independiente requerido para un holdout.

Objeto exacto faltante: tabla por sitio de registro con identificador de animal/penetración, coordenada anatómica, retardo/fase monaural, best ITD/IPD, frecuencia/retardo característico y cluster unit; además deben congelarse mapa de preparación/escala, residual y efecto mínimo antes de abrirla.

Ningún candidato alcanza `EXTERNAL_PREDICTION` ni `ROSETTA_VALIDATED`. Calibrar voxel/tick a SI o renombrar `s_reg` no constituye traducción.
""")

    save("HIGH_RISK_DISCOVERY.md", f"""
# Laboratorio high-risk/high-upside

{common_header}

Los candidatos extraordinarios fueron operacionalizados, no aceptados por nombre.

- Transferencia de función aprendida: positiva, pero continua y corridor-mediated.
- Materia adaptativa/reprogramable: reprogramación funcional positiva; reparación y autonomía negativas.
- Loop interno: feedback espacial positivo; reutilización/autonomía negativa.
- Recurso reusable: negativo bajo accounting cerrado fuente-libre.
- Metric shortcut/discontinuous transfer: no observado.
- Propagación colectiva nueva: no emergió de los cross-feeds.
- Cómputo inesperado: clasificador robusto causal, explicado por histograma/reductor y no competitivo.

El resultado de mayor upside teórico es que la función se conserva como cociente de linaje y puede alimentar otra organización. Su potencia está en la unificación, no en una afirmación de teleportación o inteligencia.
""")

    save("NEW_DISCOVERIES.md", f"""
# Descubrimientos nuevos de CORE07

{common_header}

## Confirmados

1. **Transferencia funcional aprendida:** un repertoire entrenado se recupera en B para queries nuevas mediante un corredor causal.
2. **Ley de capacidad por fibras:** la separación de destinos, no el conteo bruto de carriers, controla memoria independiente; K≥40 confirmado.
3. **Materia funcional reprogramable:** una identidad de respuesta/linaje cambia por experiencia y persiste a nuisances y transporte.
4. **Feedback interno one-pass:** observación, memoria, acción y retorno pueden componerse dentro de F_DEE.
5. **Aprendizaje robusto multiclase:** 81.11% bajo 15.625% de daño estructural en digits con controles causales.
6. **Operador unificador sectorial:** guardas→propuestas→fibras→reductor→linajes explica al menos aprendizaje, transferencia, materia, observador, cómputo y disipación.

## Leyes/ideas nuevas

- función como cociente de respuesta de linaje;
- capacidad como propiedad relacional/topológica;
- dualidad operacional cómputo-recurso;
- observador como subsistema causal, no lectura necesariamente externa.

Cada una conserva su dominio; ninguna es una correspondencia física externa.
""")

    save("NEGATIVE_RESULTS.md", f"""
# Resultados negativos conservados

{common_header}

- No existe Q4 global demostrado ni estado relacional comprimido globalmente suficiente.
- Delayed direction repair, load repair y support repair: 0% en el aparato C7H03.
- El circuito C7H04 no es reusable: soporte 6→1, memoria=0 y actuadores=0 al final.
- No teleportación discontinua: C7H01 requiere corredor y estados intermedios.
- EXTRA02 no es competitivo ni superior; pierde ante kNN y logística matched.
- No evidencia de prototypes semánticos compactos o memoria sublineal por ejemplo/clase.
- FactorX no obtiene mecanismo o ventaja nueva.
- No operational invariant speed, Lorentz structure o light Rosetta nuevos.
- Bell no viola el límite local: CHSH=-2; no Born/quantum físico.
- No temperatura, energía, variable conjugada, equilibrio universal o ciclo de recurso físico.
- Rosetta delay/place no tiene holdout row-level externo; permanece compatible, no validada.
- EXTRA01 ECG conserva `NO_ADDED_PREDICTIVE_VALUE`.

Cada negativo está limitado al aparato/dominio salvo donde existe una ley exacta sectorial. Ninguno se convierte en imposibilidad ontológica global.
""")

    save("FINAL_FRONTIER.md", f"""
# Frontera final de la etapa

{common_header}

## EXTERNAL_DATA_REQUIRED

- Dataset row-level auditivo definido en `ROSETTA_MASTER.md` para probar delay/place sin leakage.
- Preparaciones y detectores físicos independientes para cualquier traducción materia/recurso.

## NEW_THEORY_REQUIRED

- Un cociente que comprima sources, semantic/clock guards, history y global basin dynamics sin reconstruir Q0.
- Una definición de ensemble y conjugación que vaya más allá de disipación sectorial.
- Una estructura operacional nueva antes de reabrir Lorentz o quantum.

## NEW_KERNEL_REQUIRED

- Plasticidad/autoreparación persistente que no pueda construirse con la contracción normal actual, si se quiere investigar ciclos adaptativos reusables.

## COMPUTATIONAL_SCALE_REQUIRED

- Estimar capacidad máxima más allá de K=40 sólo si aparece una ley de saturación o interferencia nueva; un sweep mayor no cambia el veredicto actual.
- Benchmarks externos mayores sólo después de una arquitectura que pueda superar el histograma/reductor simple.

## CLOSED_NEGATIVE

- Reparación tardía genérica en la clase normal probada.
- Ciclo reusable fuente-libre con el aparato C7H04.
- Competitividad/superioridad de EXTRA02 en el protocolo congelado.
- Reapertura de FactorX, Bell o moving-observer con el mismo mecanismo.

No queda una pregunta interna de alta información tratable con los mecanismos actuales sin repetir un aparato, escalar una cota ya decidida o introducir una nueva premisa. Esto cierra la etapa CORE actual; no afirma que DEE esté terminada.
""")

    state = load("STATE.json")
    state.update({
        "status": "SCIENTIFIC_COMPLETE_PACKAGE_PENDING",
        "current_question": "Scientific stopping rule reached; build and validate the self-contained CORE07 package.",
        "active_branch": "FINAL_PACKAGING",
        "completed_modules": list(dict.fromkeys(state["completed_modules"] + [
            "C7A02_UNIFIED_RELATIONAL_OPERATOR",
            "C7A03_CONDITIONAL_BRANCH_ADJUDICATION",
            "C7A04_FINAL_ADVERSARIAL_AUDIT",
            "C7D05_FINAL_DOCUMENTATION",
        ])),
        "provisional": [
            f"The executable atlas contains {atlas['record_count']} claim records, {len(cap['nodes'])} capability nodes, {len(cap['edges'])} edges and {len(witnesses['witnesses'])} canonical witnesses; it is an indexed evidence map, not new confirmation by itself."
        ],
        "next_action": "Build MANIFEST/HASHES, seal ZIP, validate every member and parent hash, copy byte-for-byte into the expediente, and regenerate the portable expediente.",
        "final_verdicts": [
            "UNIFIED_NATIVE_MECHANISM_FOUND_SECTORIALLY",
            "RELATIONAL_CLOSURE_EXTENDED_CROSS_DOMAIN",
            "FUNCTIONAL_LEARNING_TRANSFER_CONFIRMED",
            "MATTER_REPROGRAMMING_FOUND",
            "INTERNAL_ONE_PASS_FEEDBACK_CIRCUIT_FOUND",
            "CAUSAL_MULTICLASS_LEARNING_FOUND",
            "ROBUST_MULTICLASS_CLASSIFIER_FOUND",
            "NO_GLOBAL_Q4",
            "EXTERNAL_EMPIRICAL_FRONTIER",
        ],
        "timestamp_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
    })
    atomic_json(ROOT / "STATE.json", state)
    with (ROOT / "SCIENCE_LOG.ndjson").open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps({
            "timestamp_utc": state["timestamp_utc"],
            "event": "CORE07_SCIENTIFIC_STOPPING_RULE_REACHED",
            "unification": uni["classification"],
            "adversarial": audit["final_adjudication"],
            "atlas_records": atlas["record_count"],
            "stopping_reason": "All maximum-priority cross-feeds and EXTRA02 adjudicated; remaining branches require a new premise, external row-level data, new kernel, or non-discriminating scale expansion.",
            "next": "package and byte-level validation",
        }, separators=(",", ":"), ensure_ascii=False) + "\n")
    print(json.dumps({"documents": 19, "state": state["status"], "atlas": atlas["record_count"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
