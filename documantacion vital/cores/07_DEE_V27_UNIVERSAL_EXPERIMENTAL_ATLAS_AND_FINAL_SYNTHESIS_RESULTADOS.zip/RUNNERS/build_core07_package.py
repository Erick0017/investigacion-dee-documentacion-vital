#!/usr/bin/env python3
"""Seal and byte-validate the self-contained CORE07 package."""
from __future__ import annotations

import hashlib
import json
import os
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import ROOT, atomic_json, atomic_text, sha256_file

TESTS = ROOT.parent
PACKAGE_NAME = "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip"
TARGET = TESTS / PACKAGE_NAME
PARENT_HASHES = {
    "PARENTS/01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "PARENTS/02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "PARENTS/03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "PARENTS/04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "PARENTS/05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "PARENTS/06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "PARENTS/EXTRAS/EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip": "dd8af27c8a836d9a79919fae92c2a19ee12dc5dedf635ccea92c460010484e7e",
}
KERNEL_HASHES = {
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}
REQUIRED = [
    "EXECUTIVE_VERDICT.md", "FINAL_REPORT.md", "TRANSVERSAL_CORE01_TO_07.md",
    "UNIFIED_NATIVE_ARCHITECTURE.md", "UNIVERSAL_ATLAS.json", "CLAIM_LEDGER.ndjson",
    "CAPABILITY_GRAPH.json", "DEPENDENCY_GRAPH.json", "CANONICAL_WITNESSES.json",
    "CROSS_FEED_RESULTS.md", "NATIVE_LEARNING_SCALE.md",
    "EXTRA02_NOISY_MULTICLASS_BENCHMARK.md", "MATTER_REPROGRAMMING.md",
    "LEARNING_TRANSFER.md", "FUNCTIONAL_IDENTITY.md", "RESOURCE_AND_THERMODYNAMICS.md",
    "OBSERVER_CLOSED_LOOP.md", "COMPUTATION_AND_FACTORING.md",
    "PROPAGATION_RELATIVITY_STATUS.md", "QUANTUM_STATUS.md", "ROSETTA_MASTER.md",
    "HIGH_RISK_DISCOVERY.md", "NEW_DISCOVERIES.md", "NEGATIVE_RESULTS.md",
    "FINAL_FRONTIER.md", "SOURCE_INDEX.json", "STATE.json", "SCIENCE_LOG.ndjson",
    "REPRODUCE.ps1", "run_core07_universal.py",
]


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def payload_files() -> list[Path]:
    excluded = {"MANIFEST.json", "HASHES.sha256"}
    rows = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        parts = relative.parts
        if path.name in excluded or path.suffix == ".tmp" or "__pycache__" in parts or path.suffix == ".pyc":
            continue
        rows.append(path)
    return sorted(rows, key=lambda item: item.relative_to(ROOT).as_posix())


def validate_payload() -> dict:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    bad_parents = {name: sha256_file(ROOT / name) for name, expected in PARENT_HASHES.items() if not (ROOT / name).is_file() or sha256_file(ROOT / name) != expected}
    bad_kernel = {name: sha256_file(ROOT / name) for name, expected in KERNEL_HASHES.items() if not (ROOT / name).is_file() or sha256_file(ROOT / name) != expected}
    locks = sorted((ROOT / "HOLDOUT_LOCKS").glob("*.json"))
    # Exclude the validation file that this function itself replaces, so the
    # report is stable on the first and every subsequent idempotent build.
    result_json = sorted(path for path in (ROOT / "RESULTS").glob("*.json") if path.name != "C7V01_payload_validation.json")
    invalid_json = []
    for path in [ROOT / "UNIVERSAL_ATLAS.json", ROOT / "CAPABILITY_GRAPH.json", ROOT / "DEPENDENCY_GRAPH.json", ROOT / "CANONICAL_WITNESSES.json", ROOT / "SOURCE_INDEX.json", ROOT / "STATE.json", *locks, *result_json]:
        try:
            read_json(path)
        except Exception as error:
            invalid_json.append({"path": path.relative_to(ROOT).as_posix(), "error": repr(error)})
    lock_links = {}
    pairs = {
        "C7H01": ("C7H01_FUNCTIONAL_LEARNING_TRANSFER.json", "C7H01_functional_learning_transfer.json"),
        "C7H02": ("C7H02_DESTINATION_FIBER_CAPACITY_AND_BUDGET.json", "C7H02_destination_fiber_capacity_budget.json"),
        "C7H03": ("C7H03_REPROGRAMMABLE_FUNCTIONAL_MATTER.json", "C7H03_reprogrammable_functional_matter.json"),
        "C7H04": ("C7H04_INTERNAL_FEEDBACK_AND_RESOURCE_CLOSURE.json", "C7H04_internal_feedback_resource_closure.json"),
        "EXTRA02": ("EXTRA02_NOISY_MULTICLASS_FINAL.json", "EXTRA02_noisy_multiclass_final.json"),
    }
    for key, (lock_name, result_name) in pairs.items():
        observed = sha256_file(ROOT / "HOLDOUT_LOCKS" / lock_name)
        linked = read_json(ROOT / "RESULTS" / result_name).get("lock_sha256")
        lock_links[key] = {"observed": observed, "result_link": linked, "match": observed == linked}
    ok = not missing and not bad_parents and not bad_kernel and not invalid_json and all(row["match"] for row in lock_links.values())
    return {
        "schema": "dee.v27.core07.payload_validation.v1",
        "module_id": "C7V01_PAYLOAD_VALIDATION",
        "status": "PASS" if ok else "FAIL",
        "required_missing": missing,
        "bad_parent_hashes": bad_parents,
        "bad_kernel_hashes": bad_kernel,
        "invalid_json": invalid_json,
        "lock_result_links": lock_links,
        "result_json_count": len(result_json),
        "holdout_lock_count": len(locks),
    }


def finish_state_and_log(validation: dict) -> None:
    state_path = ROOT / "STATE.json"
    state = read_json(state_path)
    if state.get("status") != "COMPLETE":
        stamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        state.update({
            "status": "COMPLETE",
            "current_question": None,
            "active_branch": None,
            "pending_holdout": None,
            "next_action": None,
            "stopping_rule": "REACHED",
            "stopping_reason": "All maximum-priority cross-feeds and EXTRA02 are adjudicated; remaining questions require external data, a new theory/kernel, or a new mechanism not present in the tested architecture.",
            "package_name": PACKAGE_NAME,
            "timestamp_utc": stamp,
        })
        atomic_json(state_path, state)
        log_path = ROOT / "SCIENCE_LOG.ndjson"
        prior = log_path.read_text(encoding="utf-8") if log_path.exists() else ""
        if '"event":"CORE07_FINAL_PAYLOAD_READY"' not in prior:
            with log_path.open("a", encoding="utf-8", newline="\n") as stream:
                stream.write(json.dumps({
                    "timestamp_utc": stamp,
                    "event": "CORE07_FINAL_PAYLOAD_READY",
                    "validation": validation["status"],
                    "package": PACKAGE_NAME,
                    "next": "deterministic archive construction and byte audit",
                }, separators=(",", ":"), ensure_ascii=False) + "\n")


def build_manifest(files: list[Path]) -> dict:
    entries = []
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        entries.append({"path": relative, "bytes": path.stat().st_size, "sha256": sha256_file(path)})
    atlas = read_json(ROOT / "UNIVERSAL_ATLAS.json")
    caps = read_json(ROOT / "CAPABILITY_GRAPH.json")
    witness = read_json(ROOT / "CANONICAL_WITNESSES.json")
    state = read_json(ROOT / "STATE.json")
    return {
        "schema": "dee.v27.core07.manifest.v1",
        "package": PACKAGE_NAME,
        "status": "SEALED_PAYLOAD",
        "created_utc": state["timestamp_utc"],
        "root_layout": "package members are rooted at CORE07 payload root",
        "manifest_scope": "entries covers every member except MANIFEST.json and HASHES.sha256; HASHES covers MANIFEST plus every payload entry",
        "atlas": {"claims": atlas["record_count"], "capability_nodes": len(caps["nodes"]), "capability_edges": len(caps["edges"]), "canonical_witnesses": len(witness["witnesses"])},
        "parent_hashes": PARENT_HASHES,
        "kernel_hashes": KERNEL_HASHES,
        "final_verdicts": state["final_verdicts"],
        "entries": entries,
        "entry_count": len(entries),
        "payload_bytes": sum(row["bytes"] for row in entries),
    }


def hashes_text(files: list[Path]) -> str:
    rows = [f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}" for path in files]
    rows.append(f"{sha256_file(ROOT / 'MANIFEST.json')}  MANIFEST.json")
    return "\n".join(sorted(rows, key=lambda line: line.split("  ", 1)[1])) + "\n"


def write_zip(members: list[Path]) -> None:
    temporary = TARGET.with_suffix(TARGET.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", allowZip64=True) as archive:
        for path in sorted(members, key=lambda item: item.relative_to(ROOT).as_posix()):
            relative = path.relative_to(ROOT).as_posix()
            info = zipfile.ZipInfo(relative, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED if relative.startswith("PARENTS/") and relative.endswith(".zip") else zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    os.replace(temporary, TARGET)


def validate_zip(expected_members: list[Path]) -> dict:
    expected_names = [path.relative_to(ROOT).as_posix() for path in expected_members]
    expected_set = set(expected_names)
    with zipfile.ZipFile(TARGET, "r") as archive:
        names = archive.namelist()
        unsafe = [name for name in names if PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts]
        duplicates = sorted({name for name in names if names.count(name) > 1})
        missing = sorted(expected_set - set(names))
        extra = sorted(set(names) - expected_set)
        bad_hashes = []
        hash_lines = archive.read("HASHES.sha256").decode("utf-8").splitlines()
        declared = {line.split("  ", 1)[1]: line.split("  ", 1)[0] for line in hash_lines if "  " in line}
        for name in names:
            if name == "HASHES.sha256":
                continue
            observed = sha_bytes(archive.read(name))
            if declared.get(name) != observed:
                bad_hashes.append({"path": name, "declared": declared.get(name), "observed": observed})
        bad_parents = {name: sha_bytes(archive.read(name)) for name, expected in PARENT_HASHES.items() if sha_bytes(archive.read(name)) != expected}
        tests = archive.testzip()
    ok = not unsafe and not duplicates and not missing and not extra and not bad_hashes and not bad_parents and tests is None
    return {
        "status": "PASS" if ok else "FAIL",
        "members": len(expected_members),
        "unsafe": unsafe,
        "duplicates": duplicates,
        "missing": missing,
        "extra": extra,
        "bad_hashes": bad_hashes,
        "bad_parents": bad_parents,
        "zip_test": tests,
        "package_sha256": sha256_file(TARGET),
        "package_bytes": TARGET.stat().st_size,
    }


def main() -> int:
    validation = validate_payload()
    atomic_json(ROOT / "RESULTS/C7V01_payload_validation.json", validation)
    if validation["status"] != "PASS":
        print(json.dumps(validation, indent=2))
        return 2
    finish_state_and_log(validation)
    files = payload_files()
    manifest = build_manifest(files)
    atomic_json(ROOT / "MANIFEST.json", manifest)
    files_with_manifest = payload_files() + [ROOT / "MANIFEST.json"]
    # payload_files excludes MANIFEST by design, so deduplicate after explicit add.
    files_with_manifest = sorted({path.resolve(): path for path in files_with_manifest}.values(), key=lambda item: item.relative_to(ROOT).as_posix())
    atomic_text(ROOT / "HASHES.sha256", hashes_text(files))
    members = files + [ROOT / "MANIFEST.json", ROOT / "HASHES.sha256"]
    write_zip(members)
    audit = validate_zip(members)
    print(json.dumps(audit, indent=2, sort_keys=True))
    return 0 if audit["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
