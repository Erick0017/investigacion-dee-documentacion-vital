"""Shared, label-leakage-auditable machinery for EXTRA02 digits."""
from __future__ import annotations

import gzip
import os
import time
from itertools import product
from pathlib import Path

import numpy as np

from core07_common import NativeWorld, fields, pack

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "extra02" / "digits.csv.gz"
SPLITS = ROOT / "extra02" / "split_indices.npz"
TRAIN_WORLD_N = 47
INFER_WORLD_N = 43
GROUP_LENGTH = 4
SCORE_TICK = 1 + GROUP_LENGTH
STABLE_W = 3
ALL_DIRS = [q for q in product((-1, 0, 1), repeat=3) if q != (0, 0, 0)]
GROUP_DIRECTIONS = ((1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1))
OUTPUT_DIRECTION = (0, 0, 1)
INERT_STATE = 841119940
INERT_CLOCK = 367292013764061809


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def load_data():
    matrix = np.loadtxt(gzip.open(DATA, "rt"), delimiter=",")
    split = np.load(SPLITS)
    return matrix[:, :64].astype(np.uint8), matrix[:, 64].astype(np.int8), {k: split[k].copy() for k in split.files}


def class_targets():
    targets = []
    for iz in range(2):
        for iy in range(2):
            for ix in range(3):
                targets.append((7 + 13 * ix, 7 + 13 * iy, 7 + 13 * iz))
    return targets[:10]


def target_for_memory(index):
    ix = index % 11
    iy = (index // 11) % 11
    iz = index // 121
    return 2 + 4 * ix, 2 + 4 * iy, 2 + 4 * iz


def direction_subset(target_direction, seed):
    rng = np.random.default_rng(seed)
    for _ in range(200000):
        indexes = rng.choice(len(ALL_DIRS), size=16, replace=False)
        chosen = [ALL_DIRS[int(i)] for i in indexes]
        summed = tuple(int(np.sign(sum(q[axis] for q in chosen))) for axis in range(3))
        if summed == tuple(target_direction):
            return chosen
    raise RuntimeError(f"could not find fixed direction subset for {target_direction}")


INPUT_DIRECTION_SETS = [direction_subset(d, 2707040 + i) for i, d in enumerate(GROUP_DIRECTIONS)]


def expected_counts(x, labels, indexes, threshold):
    bits = x[indexes] >= threshold
    result = np.zeros((10, 64, 2), dtype=np.uint16)
    for row, label in zip(bits, labels, strict=True):
        for feature, bit in enumerate(row):
            result[int(label), feature, int(bit)] += 1
    return result


def build_counts_kernel(kernel, x, original_y, indexes, threshold, assigned_labels):
    if len(indexes) != len(assigned_labels):
        raise ValueError("assigned label length mismatch")
    expected = expected_counts(x, assigned_labels, indexes, threshold)
    raw = np.zeros((TRAIN_WORLD_N,) * 3, dtype=np.uint64)
    clock = np.zeros_like(raw)
    bits = x[indexes] >= threshold
    contributions = [[[] for _ in range(2)] for _ in range(10 * 64)]
    for sample_index, row, label in zip(indexes, bits, assigned_labels, strict=True):
        for feature, bit in enumerate(row):
            contributions[int(label) * 64 + feature][int(bit)].append(int(sample_index))
    initial_support = 0
    for c in range(10):
        for feature in range(64):
            for bit in range(2):
                memory_index = (c * 64 + feature) * 2 + bit
                target = target_for_memory(memory_index)
                sample_ids = contributions[c * 64 + feature][bit]
                if len(sample_ids) > 26:
                    raise RuntimeError("training multiplicity exceeds Moore fan-in")
                for direction, sample_id in zip(ALL_DIRS, sample_ids, strict=False):
                    origin = add(target, direction, -1, TRAIN_WORLD_N)
                    if int(raw[origin]) != 0:
                        raise RuntimeError(f"training origin overlap {origin}")
                    raw[origin] = pack(sample_id + 1, 1, direction, 1)
                    clock[origin] = np.uint64((sample_id + 1) * 0x9E3779B97F4A7C15 & ((1 << 64) - 1))
                    initial_support += 1
    before_sreg = int(fields(raw)["sreg"].astype(np.uint64).sum())
    start = time.perf_counter()
    world = NativeWorld(kernel, raw, clock, threads=1)
    world.tick()
    wall = time.perf_counter() - start
    learned = np.zeros_like(expected)
    observed_support = 0
    for c in range(10):
        for feature in range(64):
            for bit in range(2):
                target = target_for_memory((c * 64 + feature) * 2 + bit)
                if int(world.raw[target]) != 0:
                    learned[c, feature, bit] = fields(world.raw)["sreg"][target]
                    observed_support += 1
    exact = np.array_equal(learned, expected)
    return learned, {
        "kernel_exact": bool(exact),
        "kernel_calls": 1,
        "wall_seconds": wall,
        "initial_support": initial_support,
        "expected_input_contributions": len(indexes) * 64,
        "learned_nonzero_cells": int(np.count_nonzero(learned)),
        "output_support": observed_support,
        "initial_sreg_sum": before_sreg,
        "learned_sreg_sum": int(learned.astype(np.uint64).sum()),
        "teacher_port_rule": "fixed class c selects the c-th bank; feature and bit select fixed label-blind ports",
        "labels_match_original": bool(np.array_equal(np.asarray(assigned_labels), original_y[indexes])),
    }


def score_math(counts, images, threshold, feature_permutations=None):
    bits = images >= threshold
    scores = np.zeros((len(images), 10), dtype=np.int32)
    for i, row in enumerate(bits):
        for c in range(10):
            perm = np.arange(64) if feature_permutations is None else feature_permutations[c]
            scores[i, c] = sum(int(counts[c, int(perm[f]), int(row[f])]) for f in range(64))
    return scores


def infer_kernel_one(kernel, counts, image, threshold, feature_permutations=None):
    raw = np.zeros((INFER_WORLD_N,) * 3, dtype=np.uint64)
    clock = np.zeros_like(raw)
    bits = image >= threshold
    targets = class_targets()
    for c, target in enumerate(targets):
        perm = np.arange(64) if feature_permutations is None else feature_permutations[c]
        for group in range(4):
            desired = GROUP_DIRECTIONS[group]
            group_target = add(target, desired, -GROUP_LENGTH, INFER_WORLD_N)
            for offset, incoming in enumerate(INPUT_DIRECTION_SETS[group]):
                feature = group * 16 + offset
                value = int(counts[c, int(perm[feature]), int(bits[feature])])
                origin = add(group_target, incoming, -1, INFER_WORLD_N)
                if int(raw[origin]) != 0:
                    raise RuntimeError(f"inference origin overlap {origin}")
                # This state/clock pair is inherited from an exact CORE06 normal-
                # carrier witness.  Holding nuisance fields constant prevents the
                # large parallel apparatus from sampling unrelated guard sectors.
                raw[origin] = pack(INERT_STATE, value, incoming, 1)
                clock[origin] = np.uint64(INERT_CLOCK)
    initial_support = int(np.count_nonzero(raw))
    world = NativeWorld(kernel, raw, clock, threads=1)
    score_history = []
    support_trace = []
    start = time.perf_counter()
    for tick in range(SCORE_TICK + STABLE_W):
        support_trace.append(int(np.count_nonzero(world.raw)))
        if SCORE_TICK <= tick < SCORE_TICK + STABLE_W:
            f = fields(world.raw)
            position_offset = tick - SCORE_TICK
            score_history.append([int(f["sreg"][add(target, OUTPUT_DIRECTION, position_offset, INFER_WORLD_N)]) for target in targets])
        if tick < SCORE_TICK + STABLE_W - 1:
            world.tick()
    wall = time.perf_counter() - start
    predictions = [int(np.argmax(row)) for row in score_history]
    stable = len(set(predictions)) == 1 and all(row == score_history[0] for row in score_history)
    return np.asarray(score_history[0], dtype=np.int32), {
        "prediction": predictions[0],
        "stable": stable,
        "T_first": SCORE_TICK,
        "T_stable": SCORE_TICK + STABLE_W - 1 if stable else None,
        "kernel_calls": SCORE_TICK + STABLE_W - 1,
        "wall_seconds": wall,
        "initial_active_support": initial_support,
        "peak_active_support": max(support_trace),
        "support_trace": support_trace,
        "score_history": score_history,
    }


def corrupt_zero(images, original_indexes, count, seed):
    result = images.copy()
    masks = []
    for row, original_index in enumerate(original_indexes):
        rng = np.random.default_rng(seed + int(original_index) * 1009 + count * 9176)
        mask = np.sort(rng.choice(64, size=count, replace=False)) if count else np.empty(0, dtype=int)
        result[row, mask] = 0
        masks.append(mask.tolist())
    return result, masks


def corrupt_replace(images, original_indexes, count, seed):
    result = images.copy()
    for row, original_index in enumerate(original_indexes):
        rng = np.random.default_rng(seed + int(original_index) * 1013 + count * 9187)
        mask = rng.choice(64, size=count, replace=False)
        result[row, mask] = rng.integers(0, 17, size=count)
    return result


def corrupt_occlusion(images, original_indexes, seed):
    result = images.reshape(-1, 8, 8).copy()
    for row, original_index in enumerate(original_indexes):
        rng = np.random.default_rng(seed + int(original_index) * 1019)
        a, b = int(rng.integers(0, 6)), int(rng.integers(0, 6))
        result[row, a:a+3, b:b+3] = 0
    return result.reshape(-1, 64)


def translate_one(images, direction):
    source = images.reshape(-1, 8, 8)
    out = np.zeros_like(source)
    dr, dc = direction
    rs = slice(max(0, -dr), min(8, 8 - dr)); rd = slice(max(0, dr), min(8, 8 + dr))
    cs = slice(max(0, -dc), min(8, 8 - dc)); cd = slice(max(0, dc), min(8, 8 + dc))
    out[:, rd, cd] = source[:, rs, cs]
    return out.reshape(-1, 64)


def metrics(y, pred):
    matrix = np.zeros((10, 10), dtype=np.int32)
    for truth, guess in zip(y, pred, strict=True): matrix[int(truth), int(guess)] += 1
    recalls, f1s = [], []
    for c in range(10):
        tp = matrix[c, c]; fn = matrix[c].sum() - tp; fp = matrix[:, c].sum() - tp
        recall = tp / (tp + fn) if tp + fn else 0.0
        precision = tp / (tp + fp) if tp + fp else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        recalls.append(recall); f1s.append(f1)
    return {"accuracy": float(np.mean(pred == y)), "balanced_accuracy": float(np.mean(recalls)), "macro_f1": float(np.mean(f1s)), "per_class_recall": recalls, "confusion_matrix": matrix.tolist()}


def atomic_npz(path, **arrays):
    tmp = path.with_suffix(".tmp.npz")
    np.savez_compressed(tmp, **arrays)
    os.replace(tmp, path)
