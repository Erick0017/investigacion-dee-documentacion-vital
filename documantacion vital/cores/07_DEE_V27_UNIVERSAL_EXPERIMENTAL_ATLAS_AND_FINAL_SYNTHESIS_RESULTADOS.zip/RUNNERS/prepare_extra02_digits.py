#!/usr/bin/env python3
"""Freeze provenance, duplicate groups, splits, and 20-shot curriculum for EXTRA02."""
from __future__ import annotations

import gzip
import json
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import atomic_json, canonical_hash, sha256_file

WORK = Path(__file__).resolve().parents[1]
DATA = WORK / "extra02" / "digits.csv.gz"
SPLIT = WORK / "extra02" / "split_indices.npz"
OUT = WORK / "RESULTS" / "EXTRA02_dataset_split.json"
EXPECTED_DATA_SHA256 = "09f66e6debdee2cd2b5ae59e0d6abbb73fc2b0e0185d2e1957e9ebb51e23aa22"
SPLIT_SEED = 2707002
CURRICULUM_SEED = 2707020


def array_hash(a):
    import hashlib
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def main():
    observed = sha256_file(DATA)
    if observed != EXPECTED_DATA_SHA256:
        raise RuntimeError(f"dataset hash mismatch {observed}")
    matrix = np.loadtxt(gzip.open(DATA, "rt"), delimiter=",")
    x = matrix[:, :-1].astype(np.uint8)
    y = matrix[:, -1].astype(np.int8)
    if x.shape != (1797, 64) or set(y.tolist()) != set(range(10)) or x.min() != 0 or x.max() != 16:
        raise RuntimeError("unexpected digits shape/range")
    groups = defaultdict(list)
    for i, row in enumerate(x):
        groups[row.tobytes()].append(i)
    if any(len(set(int(y[i]) for i in idx)) > 1 for idx in groups.values()):
        raise RuntimeError("exact duplicate group crosses labels")
    rng = np.random.default_rng(SPLIT_SEED)
    train, validation, final_test = [], [], []
    for label in range(10):
        label_groups = [idx for idx in groups.values() if int(y[idx[0]]) == label]
        rng.shuffle(label_groups)
        total = sum(map(len, label_groups))
        target_train, target_validation = round(0.60 * total), round(0.20 * total)
        counts = [0, 0, 0]
        buckets = [train, validation, final_test]
        for group in label_groups:
            bucket = 0 if counts[0] < target_train else (1 if counts[1] < target_validation else 2)
            buckets[bucket].extend(group); counts[bucket] += len(group)
    train = np.asarray(sorted(train), dtype=np.int32)
    validation = np.asarray(sorted(validation), dtype=np.int32)
    final_test = np.asarray(sorted(final_test), dtype=np.int32)
    if set(train) & set(validation) or set(train) & set(final_test) or set(validation) & set(final_test):
        raise RuntimeError("split overlap")
    if len(train) + len(validation) + len(final_test) != len(x):
        raise RuntimeError("split does not cover dataset")
    curriculum_rng = np.random.default_rng(CURRICULUM_SEED)
    curriculum = []
    for label in range(10):
        candidates = train[y[train] == label].copy(); curriculum_rng.shuffle(candidates)
        curriculum.extend(int(q) for q in candidates[:20])
    curriculum = np.asarray(curriculum, dtype=np.int32)
    tmp = SPLIT.with_suffix(".tmp.npz")
    np.savez_compressed(tmp, train=train, validation=validation, final_test=final_test, curriculum=curriculum)
    os.replace(tmp, SPLIT)
    result = {
        "schema": "dee.v27.core07.extra02.dataset.v1",
        "module_id": "EXTRA02_DATASET_SPLIT",
        "status": "COMPLETE_FROZEN_BEFORE_PERFORMANCE",
        "provenance": {
            "name": "scikit-learn load_digits bundled data",
            "official_url": "https://github.com/scikit-learn/scikit-learn/blob/main/sklearn/datasets/data/digits.csv.gz",
            "raw_url": "https://raw.githubusercontent.com/scikit-learn/scikit-learn/main/sklearn/datasets/data/digits.csv.gz",
            "sha256": observed,
            "samples": 1797,
            "features": 64,
            "image_shape": [8, 8],
            "classes": 10,
            "intensity_range": [0, 16],
        },
        "duplicate_grouping": {"exact_unique_images": len(groups), "duplicate_groups": sum(len(v) > 1 for v in groups.values()), "mixed_label_groups": 0},
        "split": {
            "method": "deterministic per-label group-stratified 60/20/20",
            "seed": SPLIT_SEED,
            "sizes": {"train": len(train), "validation": len(validation), "final_test": len(final_test)},
            "class_counts": {name: dict(sorted(Counter(int(y[i]) for i in idx).items())) for name, idx in (("train", train), ("validation", validation), ("final_test", final_test))},
            "index_hashes": {"train": array_hash(train), "validation": array_hash(validation), "final_test": array_hash(final_test)},
        },
        "curriculum": {
            "selection": "20 training images per class; selected only from TRAIN",
            "seed": CURRICULUM_SEED,
            "size": len(curriculum),
            "class_counts": dict(sorted(Counter(int(y[i]) for i in curriculum).items())),
            "index_hash": array_hash(curriculum),
        },
        "split_npz": str(SPLIT.relative_to(WORK)).replace("\\", "/"),
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__": raise SystemExit(main())
