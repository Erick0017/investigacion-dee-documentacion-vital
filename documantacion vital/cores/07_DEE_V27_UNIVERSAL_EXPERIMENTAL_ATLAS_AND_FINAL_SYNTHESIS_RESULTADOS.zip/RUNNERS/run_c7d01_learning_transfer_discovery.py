#!/usr/bin/env python3
"""C7D01 discovery: transfer a learned translation function to a receiver.

Training is the CORE06 collision-written translation code.  A zero-s_reg relay
then redirects the trained memory carrier without changing its learned scalar.
At a remote receiver, a never-trained query collides with that carrier.  The
fixed decoder tests whether the response repertoire n -> n + delta survives.

This is a causal carrier-transfer experiment, not physical teleportation.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C7D01_learning_transfer_discovery.json"

B = 4096
CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
MEMORY = (0, 1, 0)
RELAY = (1, -1, 0)
TRANSFER = (1, 0, 0)
QUERY = (0, 1, 0)
RESPONSE = (1, 1, 0)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {
        "state": int(f["state"][q]),
        "sreg": int(f["sreg"][q]),
        "d": [int(f[x][q]) for x in ("dx", "dy", "dz")],
        "semantic": int(f["semantic"][q]),
    }


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap at {q}")
    raw[q] = pack(state, sreg, d, 1)
    clock[q] = np.uint64(clk)


def inject(world, q, d, sreg, state, clk):
    if int(world.raw[q]) != 0:
        raise RuntimeError(f"occupied injection port {q}")
    value = pack(state, sreg, d, 1)
    world.raw_a[q] = value
    world.raw_b[q] = value
    world.clock_a[q] = np.uint64(clk)
    world.clock_b[q] = np.uint64(clk)


def clear(world, q):
    present = int(world.raw[q]) != 0
    world.raw_a[q] = np.uint64(0)
    world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0)
    world.clock_b[q] = np.uint64(0)
    return present


def simulate(kernel, delta, query, mode, seed, translation=(0, 0, 0)):
    n = 61
    train_tick = 4
    relay_tick = 10
    query_tick = 19
    query_path = 4
    junction = add((17, 13, 11), translation, 1, n)
    relay_point = add(junction, MEMORY, relay_tick - train_tick, n)
    receiver = add(relay_point, TRANSFER, query_tick - relay_tick, n)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed)
    states = [int(x) for x in rng.integers(1, 2**32, size=8, dtype=np.uint64)]
    clocks = [int(rng.bit_generator.random_raw()) for _ in range(8)]

    has_training = mode not in {"source_removed", "untrained_source"}
    learned_delta = delta + 3 if mode == "label_shuffled_source" else delta
    if has_training:
        x = 7
        y = x + learned_delta
        place_initial(raw, clock, junction, train_tick, CUE, B - x, states[0], clocks[0], n)
        place_initial(raw, clock, junction, train_tick, TEACHER, y, states[1], clocks[1], n)
    elif mode == "untrained_source":
        place_initial(raw, clock, junction, train_tick, CUE, B - 7, states[0], clocks[0], n)

    relay_d = (0, -1, 0) if mode == "direction_zero" else RELAY
    if mode != "no_transfer":
        relay_state = states[6] if mode == "state_nuisance" else states[2]
        place_initial(raw, clock, relay_point, relay_tick, relay_d, 0, relay_state, clocks[2], n)

    world = NativeWorld(kernel, raw, clock, threads=1)
    query_port = add(receiver, QUERY, -query_path, n)
    sham_receiver = add(receiver, (0, 0, 1), 3, n)
    injection_target = sham_receiver if mode == "destination_sham" else receiver
    injection_port = add(injection_target, QUERY, -query_path, n)
    cut_tick = relay_tick + 4
    cut_point = add(relay_point, TRANSFER, cut_tick - relay_tick, n)
    off_path_point = add(cut_point, (0, 0, 1), 2, n)
    events = {}
    for tick in range(query_tick + 1):
        if tick == train_tick:
            events["training"] = decode(world.raw, junction)
        if tick == relay_tick:
            events["relay"] = decode(world.raw, relay_point)
        if tick == train_tick + 2 and mode == "memory_ablation":
            q = add(junction, MEMORY, 2, n)
            events["memory_ablation_present"] = clear(world, q)
        if tick == cut_tick and mode == "corridor_cut":
            events["corridor_cut_present"] = clear(world, cut_point)
        if tick == cut_tick and mode == "off_path_cut":
            events["off_path_cut_present"] = clear(world, off_path_point)
        if tick == query_tick - query_path:
            events["query_port_empty"] = int(world.raw[injection_port]) == 0
            inject(world, injection_port, QUERY, query, states[4], clocks[4])
        if tick == query_tick:
            events["receiver"] = decode(world.raw, receiver)
            events["sham_receiver"] = decode(world.raw, sham_receiver)
        if tick < query_tick:
            world.tick()

    record = events["receiver"]
    decoded_value = None if record is None else record["sreg"] - B
    exact = (
        record is not None
        and record["d"] == list(RESPONSE)
        and decoded_value == query + delta
    )
    return {
        "mode": mode,
        "seed": seed,
        "n": n,
        "delta": delta,
        "query": query,
        "expected": query + delta,
        "decoded": decoded_value,
        "exact_function": exact,
        "geometry": {
            "translation": list(translation),
            "junction": list(junction),
            "relay_point": list(relay_point),
            "receiver": list(receiver),
            "query_port": list(query_port),
            "cut_point": list(cut_point),
            "off_path_point": list(off_path_point),
        },
        "events": events,
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    deltas = (-2, 1, 4)
    queries = (2, 5, 9)
    modes = (
        "transferred",
        "no_transfer",
        "source_removed",
        "untrained_source",
        "label_shuffled_source",
        "memory_ablation",
        "corridor_cut",
        "off_path_cut",
        "direction_zero",
        "state_nuisance",
        "destination_sham",
    )
    translations = ((0, 0, 0), (7, 5, 3), (13, 2, 9))
    cases = []
    for di, delta in enumerate(deltas):
        for qi, query in enumerate(queries):
            for ti, translation in enumerate(translations):
                for mi, mode in enumerate(modes):
                    cases.append(
                        simulate(
                            kernel,
                            delta,
                            query,
                            mode,
                            710000 + di * 10000 + qi * 1000 + ti * 100 + mi,
                            translation,
                        )
                    )
    positive_modes = {"transferred", "off_path_cut", "state_nuisance"}
    negative_modes = set(modes) - positive_modes
    by_mode = {
        mode: {
            "exact": sum(c["exact_function"] for c in cases if c["mode"] == mode),
            "total": sum(c["mode"] == mode for c in cases),
        }
        for mode in modes
    }
    summary = {
        "cases": len(cases),
        "positive_exact": sum(c["exact_function"] for c in cases if c["mode"] in positive_modes),
        "positive_total": sum(c["mode"] in positive_modes for c in cases),
        "negative_inexact": sum(not c["exact_function"] for c in cases if c["mode"] in negative_modes),
        "negative_total": sum(c["mode"] in negative_modes for c in cases),
        "by_mode": by_mode,
        "all_injection_ports_empty": all(c["events"].get("query_port_empty") for c in cases),
        "all_memory_ablation_targets_present": all(
            c["events"].get("memory_ablation_present") is True
            for c in cases
            if c["mode"] == "memory_ablation"
        ),
        "all_corridor_cut_targets_present": all(
            c["events"].get("corridor_cut_present") is True
            for c in cases
            if c["mode"] == "corridor_cut"
        ),
        "all_off_path_cut_targets_empty": all(
            c["events"].get("off_path_cut_present") is False
            for c in cases
            if c["mode"] == "off_path_cut"
        ),
    }
    candidate = (
        summary["positive_exact"] == summary["positive_total"]
        and summary["negative_inexact"] == summary["negative_total"]
        and summary["all_injection_ports_empty"]
        and summary["all_memory_ablation_targets_present"]
        and summary["all_corridor_cut_targets_present"]
        and summary["all_off_path_cut_targets_empty"]
    )
    result = {
        "schema": "dee.v27.core07.c7d01.v1",
        "experiment_id": "C7D01_LEARNING_TRANSFER_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can a function learned through ordinary DEE experience be causally transferred to a new receiver and retain its response on unseen queries?",
        "hypotheses": {
            "H_functional_carrier": "the collision-written translation memory is a mobile functional carrier whose response repertoire survives a zero-load relay",
            "H_local_only": "the trained response requires the original channel and cannot be recovered at a remote receiver",
            "H_artifact": "query encoding, nuisance state, or destination coincidence explains the apparent function",
        },
        "fixed_map": {
            "training_input": "B-x",
            "teacher": "x+delta",
            "learned_memory": "B+delta",
            "relay": "ordinary semantic-1 carrier with s_reg=0",
            "receiver_query": "unseen n",
            "decoder": "receiver s_reg-B",
            "predicted_response": "n+delta",
        },
        "causal_scope": "Continuous carrier-mediated transfer through a causal corridor; not instantaneous or physical teleportation.",
        "kernel_environment": environment,
        "summary": summary,
        "promotion_candidate": candidate,
        "cases": cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"summary": summary, "promotion_candidate": candidate}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
