#!/usr/bin/env python3
"""C7D02: multi-memory capacity, destination-fiber interference, accounting.

The experiment asks whether capacity is a scalar limit of an individual
learner or a relational routing property.  It compares separated learned
memory lanes with two learned memories deliberately sent to one destination
fiber, while accounting for support and s_reg through training and readout.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C7D02_capacity_resource_discovery.json"
B = 4096
CUE = (1, 0, 0)
TEACHER_Y = (-1, 1, 0)
TEACHER_Z = (-1, 0, 1)
MY = (0, 1, 0)
MZ = (0, 0, 1)
QUERY = (1, 0, 0)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def totals(raw):
    f = fields(raw)
    return {"support": int(np.count_nonzero(raw)), "sreg_sum": int(f["sreg"].astype(np.uint64).sum())}


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap {q}")
    raw[q] = pack(state, sreg, d, 1)
    clock[q] = np.uint64(clk)


def inject(world, q, d, sreg, state, clk):
    if int(world.raw[q]) != 0:
        raise RuntimeError(f"occupied injection port {q}")
    value = pack(state, sreg, d, 1)
    world.raw_a[q] = value
    world.raw_b[q] = value
    world.clock_a[q] = np.uint64(clk)
    world.clock_b[q] = np.uint64(clk)


def separated(kernel, k, seed):
    n, t0, tq, path = 73, 4, 17, 4
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed)
    channels = []
    for i in range(k):
        j = (5 + 8 * (i % 8), 11, 7 + 13 * (i // 8))
        x = 20 + (i % 7)
        delta = -4 + (i % 9)
        query = 101 + i
        place_initial(raw, clock, j, t0, CUE, B - x, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        place_initial(raw, clock, j, t0, TEACHER_Y, x + delta, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        target = add(j, MY, tq - t0, n)
        port = add(target, QUERY, -path, n)
        channels.append({"index": i, "junction": j, "target": target, "port": port, "x": x, "delta": delta, "query": query})
    initial = totals(raw)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    records = None
    for tick in range(tq + 1):
        event = {"tick": tick, **totals(world.raw)}
        if tick == tq - path:
            event["ports_empty"] = all(int(world.raw[c["port"]]) == 0 for c in channels)
            for c in channels:
                inject(world, c["port"], QUERY, c["query"], int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()))
            event["after_injection"] = totals(world.raw)
        if tick == tq:
            records = [decode(world.raw, c["target"]) for c in channels]
        trace.append(event)
        if tick < tq:
            world.tick()
    expected = [B + c["delta"] + c["query"] for c in channels]
    exact = [r is not None and r["d"] == [1, 1, 0] and r["sreg"] == e for r, e in zip(records, expected, strict=True)]
    training_budget = initial["support"] - trace[t0]["support"]
    read_before = next(x["after_injection"] for x in trace if x["tick"] == tq - path)["support"]
    read_budget = read_before - trace[tq]["support"]
    return {
        "k": k,
        "initial": initial,
        "after_training": {key: trace[t0][key] for key in ("support", "sreg_sum")},
        "after_query": {key: trace[tq][key] for key in ("support", "sreg_sum")},
        "training_collision_budget": training_budget,
        "read_collision_budget": read_budget,
        "sreg_expected_after_query": initial["sreg_sum"] + sum(c["query"] for c in channels),
        "all_exact": all(exact),
        "exact_channels": sum(exact),
        "channels": channels,
        "records": records,
        "trace": trace,
    }


def overlap(kernel, delta_y, delta_z, query, mode, seed):
    n, t0, tm, tq, path = 61, 4, 12, 19, 3
    merge = (31, 29, 27)
    jy = add(merge, MY, -(tm - t0), n)
    jz = add(merge, MZ, -(tm - t0), n)
    if mode == "off_fiber":
        jz = add(jz, (1, 0, 0), 3, n)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed)
    x1, x2 = 9, 14
    place_initial(raw, clock, jy, t0, CUE, B - x1, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
    place_initial(raw, clock, jy, t0, TEACHER_Y, x1 + delta_y, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
    if mode != "single_memory":
        place_initial(raw, clock, jz, t0, CUE, B - x2, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        place_initial(raw, clock, jz, t0, TEACHER_Z, x2 + delta_z, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
    world = NativeWorld(kernel, raw, clock, threads=1)
    merged_direction = (0, 1, 1)
    receiver = add(merge, merged_direction, tq - tm, n)
    port = add(receiver, QUERY, -path, n)
    trace = []
    merge_record = None
    receiver_record = None
    port_empty = None
    for tick in range(tq + 1):
        if tick == tm:
            merge_record = decode(world.raw, merge)
        if tick == tq - path and mode == "overlap":
            port_empty = int(world.raw[port]) == 0
            inject(world, port, QUERY, query, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()))
        if tick == tq:
            receiver_record = decode(world.raw, receiver)
        trace.append({"tick": tick, **totals(world.raw)})
        if tick < tq:
            world.tick()
    expected_merged = 2 * B + delta_y + delta_z
    expected_response = expected_merged + query
    return {
        "mode": mode,
        "delta_y": delta_y,
        "delta_z": delta_z,
        "query": query,
        "merge_record": merge_record,
        "receiver_record": receiver_record,
        "port_empty": port_empty,
        "merged_exact": mode == "overlap" and merge_record is not None and merge_record["d"] == [0, 1, 1] and merge_record["sreg"] == expected_merged,
        "composed_response_exact": mode == "overlap" and receiver_record is not None and receiver_record["d"] == [1, 1, 1] and receiver_record["sreg"] == expected_response,
        "equals_either_individual_translation": receiver_record is not None and receiver_record["sreg"] - B in {query + delta_y, query + delta_z},
        "trace": trace,
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    separated_cases = [separated(kernel, k, 730000 + k) for k in (1, 2, 4, 8, 16, 32)]
    overlap_cases = [overlap(kernel, dy, dz, q, mode, 731000 + i * 10 + j) for i, (dy, dz, q) in enumerate(((-3, 2, 17), (1, 4, 23), (5, -2, 31))) for j, mode in enumerate(("overlap", "off_fiber", "single_memory"))]
    overlapping = [c for c in overlap_cases if c["mode"] == "overlap"]
    summary = {
        "separated_capacity_values": [c["k"] for c in separated_cases],
        "separated_all_exact": sum(c["all_exact"] for c in separated_cases),
        "separated_cases": len(separated_cases),
        "separated_channels_exact": sum(c["exact_channels"] for c in separated_cases),
        "separated_channels_total": sum(c["k"] for c in separated_cases),
        "training_budget_exact": all(c["training_collision_budget"] == c["k"] for c in separated_cases),
        "read_budget_exact": all(c["read_collision_budget"] == c["k"] for c in separated_cases),
        "sreg_accounting_exact": all(c["after_query"]["sreg_sum"] == c["sreg_expected_after_query"] for c in separated_cases),
        "overlap_merge_exact": sum(c["merged_exact"] for c in overlapping),
        "overlap_composed_response_exact": sum(c["composed_response_exact"] for c in overlapping),
        "overlap_cases": len(overlapping),
        "overlap_preserved_either_individual": sum(c["equals_either_individual_translation"] for c in overlapping),
    }
    candidate = (
        summary["separated_all_exact"] == summary["separated_cases"]
        and summary["separated_channels_exact"] == summary["separated_channels_total"]
        and summary["training_budget_exact"]
        and summary["read_budget_exact"]
        and summary["sreg_accounting_exact"]
        and summary["overlap_merge_exact"] == summary["overlap_cases"]
        and summary["overlap_composed_response_exact"] == summary["overlap_cases"]
        and summary["overlap_preserved_either_individual"] == 0
    )
    result = {
        "schema": "dee.v27.core07.c7d02.v1",
        "experiment_id": "C7D02_CAPACITY_RESOURCE_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Is multi-memory capacity controlled by destination-fiber separation, and does the same reducer give a closed accounting of learning/readout cost and overlap interference?",
        "candidate_law": {
            "separated": "K disjoint destination fibers retain K independent translation memories; training and one read each contract active support by K while preserving total s_reg below cap except for injected query load.",
            "overlap": "Two learned memory carriers sharing a destination fiber become one carrier with summed s_reg and sign-summed direction; the individual response repertoires are no longer separately recoverable by the fixed decoder.",
            "collision_budget": "In the source-free normal sector, each productive k-to-one fiber reduction consumes k-1 active carriers, giving a finite collision-mediated transformation budget bounded by initial plus externally injected support.",
        },
        "epistemic_scope": "The finite budget is a sector law, not thermodynamic energy. Separated K=32 is a lower bound on routed capacity, not a global capacity maximum.",
        "kernel_environment": environment,
        "summary": summary,
        "promotion_candidate": candidate,
        "separated": separated_cases,
        "overlap": overlap_cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"summary": summary, "promotion_candidate": candidate}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
