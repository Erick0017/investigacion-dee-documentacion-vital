#!/usr/bin/env python3
"""C7D03: lineage-continuous functional reprogramming and damage/repair.

A learned translation carrier receives an ordinary positive-load programming
collision, is redirected back to its original direction, and is queried later.
Targeted surgeries then distinguish nuisance state/clock, routing damage,
memory-load damage and support destruction.  A generic zero-load direction
carrier tests assisted routing repair without carrying the learned value.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C7D03_reprogrammable_matter_repair.json"
B = 4096
CUE, TEACHER, MEMORY = (1, 0, 0), (-1, 1, 0), (0, 1, 0)
PROGRAMMER, PROGRAMMED = (1, -1, 0), (1, 0, 0)
REDIRECT = (-1, 1, 0)
RESPONSE = (1, 1, 0)
OFF = (0, 0, 1)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"state": int(f["state"][q]), "sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap {q}")
    raw[q] = pack(state, sreg, d, 1)
    clock[q] = np.uint64(clk)


def inject(world, q, d, sreg, state, clk):
    if int(world.raw[q]) != 0:
        raise RuntimeError(f"occupied injection port {q}")
    value = pack(state, sreg, d, 1)
    world.raw_a[q] = value
    world.raw_b[q] = value
    world.clock_a[q] = np.uint64(clk)
    world.clock_b[q] = np.uint64(clk)


def overwrite(world, q, *, state=None, sreg=None, direction=None, clock=None):
    rec = decode(world.raw, q)
    if rec is None:
        return False
    value = pack(
        rec["state"] if state is None else state,
        rec["sreg"] if sreg is None else sreg,
        tuple(rec["d"]) if direction is None else direction,
        rec["semantic"],
    )
    world.raw_a[q] = value
    world.raw_b[q] = value
    if clock is not None:
        world.clock_a[q] = np.uint64(clock)
        world.clock_b[q] = np.uint64(clock)
    return True


def clear(world, q):
    present = int(world.raw[q]) != 0
    world.raw_a[q] = np.uint64(0)
    world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0)
    world.clock_b[q] = np.uint64(0)
    return present


def simulate(kernel, delta, update, query, mode, seed, translation):
    n, t0, tp, tr, td, trepair, tq, query_path = 67, 4, 10, 15, 18, 21, 27, 4
    j = add((16, 12, 19), translation, 1, n)
    program_point = add(j, MEMORY, tp - t0, n)
    redirect_point = add(program_point, PROGRAMMED, tr - tp, n)
    damage_point = add(redirect_point, MEMORY, td - tr, n)
    repair_modes = {"direction_damage_repair", "direction_damage_offpath_repair", "load_damage_repair", "support_damage_repair"}
    repaired_receiver = add(damage_point, MEMORY, tq - trepair, n)
    normal_receiver = add(redirect_point, MEMORY, tq - tr, n)
    receiver = repaired_receiver if mode in repair_modes or mode == "direction_damage_no_repair" else normal_receiver
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed)
    states = [int(x) for x in rng.integers(1, 2**32, size=12, dtype=np.uint64)]
    clocks = [int(rng.bit_generator.random_raw()) for _ in range(12)]
    x = 13
    cue_state = states[9] if mode == "source_state_nuisance" else states[0]
    teacher_state = states[10] if mode == "source_state_nuisance" else states[1]
    place_initial(raw, clock, j, t0, CUE, B - x, cue_state, clocks[0], n)
    place_initial(raw, clock, j, t0, TEACHER, x + delta, teacher_state, clocks[1], n)
    if mode != "programmer_absent":
        ptarget = add(program_point, OFF, 3, n) if mode == "programmer_offpath" else program_point
        place_initial(raw, clock, ptarget, tp, PROGRAMMER, update, states[2], clocks[2], n)
    place_initial(raw, clock, redirect_point, tr, REDIRECT, 0, states[3], clocks[3], n)
    if mode in repair_modes:
        repair_target = add(damage_point, OFF, 2, n) if mode == "direction_damage_offpath_repair" else damage_point
        place_initial(raw, clock, repair_target, trepair, MEMORY, 0, states[4], clocks[4], n)

    world = NativeWorld(kernel, raw, clock, threads=1)
    query_port = add(receiver, CUE, -query_path, n)
    events = {}
    for tick in range(tq + 1):
        if tick == t0:
            events["trained"] = decode(world.raw, j)
        if tick == t0 + 2 and mode == "memory_ablation":
            events["memory_ablation_present"] = clear(world, add(j, MEMORY, 2, n))
        if tick == tp:
            events["programmed"] = decode(world.raw, program_point)
        if tick == tr:
            events["redirected"] = decode(world.raw, redirect_point)
        if tick == td:
            if mode in {"direction_damage_no_repair", "direction_damage_repair", "direction_damage_offpath_repair"}:
                events["damage_target_present"] = overwrite(world, damage_point, direction=(0, 0, 0))
            elif mode == "load_damage_repair":
                events["damage_target_present"] = overwrite(world, damage_point, sreg=0, direction=(0, 0, 0))
            elif mode == "support_damage_repair":
                events["damage_target_present"] = clear(world, damage_point)
            elif mode == "state_damage":
                events["damage_target_present"] = overwrite(world, damage_point, state=states[8])
            elif mode == "clock_damage":
                events["damage_target_present"] = overwrite(world, damage_point, clock=clocks[8])
        if tick == trepair:
            events["repair_event"] = decode(world.raw, damage_point)
        if tick == tq - query_path:
            events["query_port_empty"] = int(world.raw[query_port]) == 0
            inject(world, query_port, CUE, query, states[6], clocks[6])
        if tick == tq:
            events["receiver"] = decode(world.raw, receiver)
        if tick < tq:
            world.tick()
    rec = events["receiver"]
    decoded_value = None if rec is None else rec["sreg"] - B
    expected = query + delta + update
    exact_updated = rec is not None and rec["d"] == list(RESPONSE) and decoded_value == expected
    return {
        "delta": delta,
        "update": update,
        "query": query,
        "mode": mode,
        "expected": expected,
        "decoded": decoded_value,
        "exact_updated_function": exact_updated,
        "events": events,
        "geometry": {"training": list(j), "program": list(program_point), "redirect": list(redirect_point), "damage": list(damage_point), "receiver": list(receiver)},
    }


def main():
    kernel, environment = verify_and_load_kernel(1)
    specs = ((-3, 5, 17), (1, 7, 23), (4, 11, 31))
    modes = (
        "reprogrammed",
        "source_state_nuisance",
        "state_damage",
        "clock_damage",
        "direction_damage_repair",
        "programmer_absent",
        "programmer_offpath",
        "memory_ablation",
        "direction_damage_no_repair",
        "direction_damage_offpath_repair",
        "load_damage_repair",
        "support_damage_repair",
    )
    translations = ((0, 0, 0), (9, 4, 7), (15, 13, 2))
    cases = [simulate(kernel, d, u, q, mode, 750000 + i * 100 + j, translations[i]) for i, (d, u, q) in enumerate(specs) for j, mode in enumerate(modes)]
    positive_modes = {"reprogrammed", "source_state_nuisance", "state_damage", "clock_damage", "direction_damage_repair"}
    negative_modes = set(modes) - positive_modes
    summary = {
        "positive_exact": sum(c["exact_updated_function"] for c in cases if c["mode"] in positive_modes),
        "positive_total": sum(c["mode"] in positive_modes for c in cases),
        "negative_inexact": sum(not c["exact_updated_function"] for c in cases if c["mode"] in negative_modes),
        "negative_total": sum(c["mode"] in negative_modes for c in cases),
        "assisted_routing_repair_exact": sum(c["exact_updated_function"] for c in cases if c["mode"] == "direction_damage_repair"),
        "load_repair_exact": sum(c["exact_updated_function"] for c in cases if c["mode"] == "load_damage_repair"),
        "support_repair_exact": sum(c["exact_updated_function"] for c in cases if c["mode"] == "support_damage_repair"),
        "all_query_ports_empty": all(c["events"].get("query_port_empty") for c in cases),
    }
    candidate = summary["positive_exact"] == summary["positive_total"] and summary["negative_inexact"] == summary["negative_total"] and summary["all_query_ports_empty"]
    result = {
        "schema": "dee.v27.core07.c7d03.v1",
        "experiment_id": "C7D03_REPROGRAMMABLE_MATTER_REPAIR",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "question": "Can an operationally persistent learned carrier be reprogrammed through ordinary interactions, and which damage components can a generic repair interaction restore?",
        "candidate_mechanism": "The response value resides in transported s_reg while routing resides in direction. An ordinary positive-load collision modifies the value; a zero-load relay restores direction. State and clock are nuisance in this sector. A generic zero-load direction carrier repairs routing damage but cannot reconstruct lost load or destroyed support.",
        "identity_scope": "Continuity is a lineage/response-repertoire quotient across mergers, not equality of raw microstate or conserved particle identity.",
        "repair_scope": "Repair is externally assisted routing repair. No autonomous structural or memory repair is claimed.",
        "kernel_environment": environment,
        "summary": summary,
        "promotion_candidate": candidate,
        "cases": cases,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({"summary": summary, "promotion_candidate": candidate}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
