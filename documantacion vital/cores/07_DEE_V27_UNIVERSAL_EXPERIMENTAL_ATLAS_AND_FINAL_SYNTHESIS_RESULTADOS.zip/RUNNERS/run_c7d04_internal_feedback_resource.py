#!/usr/bin/env python3
"""C7D04: an internal spatially closed sensor-memory-action-feedback circuit.

All inputs are scheduled before evolution.  Python never chooses an action from
an observed response.  Four collision events route the learned response around
a closed rectangle back to the sensing location.  Global accounting tests
whether this is a reusable loop or a one-pass consumptive circuit.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "C7D04_internal_feedback_resource.json"
B = 4096
CUE, TEACHER, MEMORY = (1, 0, 0), (-1, 1, 0), (0, 1, 0)
SENSE_INPUT = (1, -1, 0)
D1, ACT2, D2 = (1, 0, 0), (-1, 1, 0), (0, 1, 0)
ACT3, D3 = (-1, -1, 0), (-1, 0, 0)
ACT4, D4 = (1, -1, 0), (0, -1, 0)
OFF = (0, 0, 1)


def add(q, d, k, n): return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0: return None
    f = fields(raw)
    return {"sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def totals(raw):
    f = fields(raw)
    return {"support": int(np.count_nonzero(raw)), "sreg_sum": int(f["sreg"].astype(np.uint64).sum())}


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0: raise RuntimeError(f"initial overlap {q}")
    raw[q] = pack(state, sreg, d, 1); clock[q] = np.uint64(clk)


def simulate(kernel, spec, mode, seed):
    n, L, t0, t1 = spec["n"], spec["L"], 4, 10
    t2, t3, t4, tf = t1 + L, t1 + 2 * L, t1 + 3 * L, t1 + 4 * L
    e1 = tuple(spec["sensor"]); j = add(e1, MEMORY, -(t1 - t0), n)
    e2 = add(e1, D1, L, n); e3 = add(e2, D2, L, n); e4 = add(e3, D3, L, n)
    assert add(e4, D4, L, n) == e1
    raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw)
    rng = np.random.default_rng(seed); states = [int(x) for x in rng.integers(1, 2**32, size=10, dtype=np.uint64)]; clocks = [int(rng.bit_generator.random_raw()) for _ in range(10)]
    x, delta, query = 11, spec["delta"], spec["query"]
    loads = spec["actuator_loads"]
    if mode != "no_training":
        place_initial(raw, clock, j, t0, CUE, B - x, states[0 if mode != "state_nuisance" else 8], clocks[0], n)
        place_initial(raw, clock, j, t0, TEACHER, x + delta, states[1 if mode != "state_nuisance" else 9], clocks[1], n)
    if mode != "no_query": place_initial(raw, clock, e1, t1, SENSE_INPUT, query, states[2], clocks[2 if mode != "clock_nuisance" else 8], n)
    actuators = [(2, e2, t2, ACT2, loads[0]), (3, e3, t3, ACT3, loads[1]), (4, e4, t4, ACT4, loads[2])]
    for ident, target, tick, direction, load in actuators:
        if mode == f"no_actuator_{ident}": continue
        if mode == "route_shuffle_2" and ident == 2: direction = (-1, 0, 1)
        if mode == "off_path_actuator" and ident == 3: target = add(target, OFF, 3, n)
        place_initial(raw, clock, target, tick, direction, load, states[ident + 1], clocks[ident + 1], n)
    initial = totals(raw); world = NativeWorld(kernel, raw, clock, threads=1)
    event_points = {t0: ("training", j), t1: ("sense", e1), t2: ("action_2", e2), t3: ("action_3", e3), t4: ("action_4", e4), tf: ("feedback", e1)}
    events, trace = {}, []
    for tick in range(tf + 1):
        trace.append({"tick": tick, **totals(world.raw)})
        if tick in event_points:
            label, point = event_points[tick]; events[label] = decode(world.raw, point)
        if tick < tf: world.tick()
    expected_sreg = B + delta + query + sum(loads)
    feedback = events["feedback"]
    exact = feedback is not None and feedback["d"] == list(D4) and feedback["sreg"] == expected_sreg
    collision_support = [trace[t]["support"] for t in (0, t0, t1, t2, t3, t4, tf)]
    return {"spec": spec, "mode": mode, "geometry": {"training": list(j), "sensor": list(e1), "action_2": list(e2), "action_3": list(e3), "action_4": list(e4), "feedback": list(e1)}, "times": {"train": t0, "sense": t1, "actions": [t2, t3, t4], "feedback": tf}, "initial": initial, "events": events, "expected_feedback_sreg": expected_sreg, "feedback_exact": exact, "collision_support": collision_support, "intact_budget_exact": mode in {"intact", "state_nuisance", "clock_nuisance"} and collision_support == [6, 5, 4, 3, 2, 1, 1], "intact_sreg_exact": mode in {"intact", "state_nuisance", "clock_nuisance"} and trace[tf]["sreg_sum"] == initial["sreg_sum"], "trace": trace}


def main():
    kernel, environment = verify_and_load_kernel(1)
    specs = (
        {"n": 53, "L": 4, "sensor": (23, 19, 17), "delta": -2, "query": 31, "actuator_loads": [7, 11, 13]},
        {"n": 61, "L": 6, "sensor": (29, 27, 21), "delta": 3, "query": 37, "actuator_loads": [5, 17, 19]},
        {"n": 67, "L": 8, "sensor": (31, 25, 33), "delta": 6, "query": 43, "actuator_loads": [13, 23, 29]},
    )
    modes = ("intact", "state_nuisance", "clock_nuisance", "no_training", "no_query", "no_actuator_2", "no_actuator_3", "no_actuator_4", "route_shuffle_2", "off_path_actuator")
    cases = [simulate(kernel, spec, mode, 770000 + i * 100 + j) for i, spec in enumerate(specs) for j, mode in enumerate(modes)]
    positives = [c for c in cases if c["mode"] in {"intact", "state_nuisance", "clock_nuisance"}]; negatives = [c for c in cases if c["mode"] not in {"intact", "state_nuisance", "clock_nuisance"}]
    summary = {"closed_path_exact": sum(c["feedback_exact"] for c in positives), "closed_path_total": len(positives), "controls_inexact": sum(not c["feedback_exact"] for c in negatives), "controls_total": len(negatives), "support_budget_exact": sum(c["intact_budget_exact"] for c in positives), "sreg_accounting_exact": sum(c["intact_sreg_exact"] for c in positives), "initial_support": 6, "final_support": 1, "productive_collisions": 5, "resource_closed": False, "autonomous_reusable": False}
    result = {"schema": "dee.v27.core07.c7d04.v1", "experiment_id": "C7D04_INTERNAL_FEEDBACK_RESOURCE", "role": "DISCOVERY_EVIDENCE_ONLY", "question": "Can DEE form an internal sensor-memory-action-feedback path without Python decisions, and is the resulting loop reusable under closed accounting?", "adjudication_candidate": "A spatially closed one-pass sensor-memory-action-feedback circuit exists. It is not a reusable autonomous loop: five reducer events contract six prepared carriers to one feedback carrier, leaving no memory or actuator repertoire for a second traversal. Repetition requires new support or a source and therefore is not a closed reusable resource cycle.", "no_python_policy": "Every carrier and interaction is fixed before the first kernel update; Python records only preregistered locations and never selects an action from an observed response.", "kernel_environment": environment, "summary": summary, "cases": cases}
    result["promotion_candidate"] = summary["closed_path_exact"] == summary["closed_path_total"] and summary["controls_inexact"] == summary["controls_total"] and summary["support_budget_exact"] == len(positives) and summary["sreg_accounting_exact"] == len(positives)
    result["content_sha256"] = canonical_hash(result); atomic_json(OUT, result)
    print(json.dumps({"summary": summary, "promotion_candidate": result["promotion_candidate"]}, indent=2, sort_keys=True)); return 0


if __name__ == "__main__": raise SystemExit(main())
