#!/usr/bin/env python3
"""Frozen C7H02: destination-fiber capacity and source-free collision budget."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "C7H02_DESTINATION_FIBER_CAPACITY_AND_BUDGET.json"
OUT = WORK / "RESULTS" / "C7H02_destination_fiber_capacity_budget.json"
EXPECTED_LOCK_SHA256 = "353dbbd96420013e6434e2910b6920c816276a1f031de543247ac849e0e907e6"
CUE, TY, TZ, MY, MZ, QUERY = (1, 0, 0), (-1, 1, 0), (-1, 0, 1), (0, 1, 0), (0, 0, 1), (1, 0, 0)


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0:
        return None
    f = fields(raw)
    return {"sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def totals(raw):
    f = fields(raw)
    return {"support": int(np.count_nonzero(raw)), "sreg_sum": int(f["sreg"].astype(np.uint64).sum())}


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap {q}")
    raw[q] = pack(state, sreg, d, 1)
    clock[q] = np.uint64(clk)


def inject(world, q, d, sreg, state, clk):
    if int(world.raw[q]) != 0:
        raise RuntimeError(f"occupied injection port {q}")
    value = pack(state, sreg, d, 1)
    world.raw_a[q] = value
    world.raw_b[q] = value
    world.clock_a[q] = np.uint64(clk)
    world.clock_b[q] = np.uint64(clk)


def separated_panel(kernel, spec, lock, rng):
    n, k = spec["n"], spec["k"]
    t0, tq, path = lock["domain"]["separated_train_tick"], lock["domain"]["separated_query_tick"], lock["domain"]["separated_query_path"]
    B = lock["domain"]["base_offset"]
    shift = tuple(spec["translation"])
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    channels = []
    delta_cycle = lock["parameters"]["deltas_cycle"]
    for i in range(k):
        base = (5 + 10 * (i % 8), 11, 7 + 14 * (i // 8))
        j = add(base, shift, 1, n)
        x = 25 + i % 11
        delta = delta_cycle[i % len(delta_cycle)]
        query = lock["parameters"]["query_base"] + i
        place_initial(raw, clock, j, t0, CUE, B - x, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        place_initial(raw, clock, j, t0, TY, x + delta, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        target = add(j, MY, tq - t0, n)
        port = add(target, QUERY, -path, n)
        channels.append({"junction": j, "target": target, "port": port, "delta": delta, "query": query})
    initial = totals(raw)
    world = NativeWorld(kernel, raw, clock, threads=1)
    at_train = None
    after_injection = None
    records = None
    ports_empty = None
    for tick in range(tq + 1):
        if tick == t0:
            at_train = totals(world.raw)
        if tick == tq - path:
            ports_empty = all(int(world.raw[c["port"]]) == 0 for c in channels)
            for c in channels:
                inject(world, c["port"], QUERY, c["query"], int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()))
            after_injection = totals(world.raw)
        if tick == tq:
            records = [decode(world.raw, c["target"]) for c in channels]
            after_query = totals(world.raw)
        if tick < tq:
            world.tick()
    exact = [r is not None and r["d"] == [1, 1, 0] and r["sreg"] == B + c["delta"] + c["query"] for r, c in zip(records, channels, strict=True)]
    return {
        "spec": spec,
        "channels": k,
        "ports_empty": ports_empty,
        "exact_channels": sum(exact),
        "all_exact": all(exact),
        "initial": initial,
        "after_training": at_train,
        "after_injection": after_injection,
        "after_query": after_query,
        "training_budget_exact": initial["support"] - at_train["support"] == k,
        "read_budget_exact": after_injection["support"] - after_query["support"] == k,
        "sreg_accounting_exact": after_query["sreg_sum"] == initial["sreg_sum"] + sum(c["query"] for c in channels),
        "records": records,
    }


def overlap_panel(kernel, index, deltas, query, mode, lock, rng):
    n = lock["domain"]["overlap_n"]
    t0, tm, tq = lock["domain"]["overlap_train_tick"], lock["domain"]["overlap_merge_tick"], lock["domain"]["overlap_query_tick"]
    B = lock["domain"]["base_offset"]
    merge = ((17 + 6 * index) % n, (19 + 9 * index) % n, (23 + 11 * index) % n)
    jy = add(merge, MY, -(tm - t0), n)
    jz = add(merge, MZ, -(tm - t0), n)
    if mode == "off_fiber":
        jz = add(jz, (1, 0, 0), 3, n)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    for j, teacher, x, delta in ((jy, TY, 12, deltas[0]), (jz, TZ, 21, deltas[1])):
        place_initial(raw, clock, j, t0, CUE, B - x, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
        place_initial(raw, clock, j, t0, teacher, x + delta, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()), n)
    world = NativeWorld(kernel, raw, clock, threads=1)
    merged_d = (0, 1, 1)
    receiver = add(merge, merged_d, tq - tm, n)
    port = add(receiver, QUERY, -4, n)
    merge_record = None
    receiver_record = None
    port_empty = None
    for tick in range(tq + 1):
        if tick == tm:
            merge_record = decode(world.raw, merge)
        if tick == tq - 4 and mode == "overlap":
            port_empty = int(world.raw[port]) == 0
            inject(world, port, QUERY, query, int(rng.integers(1, 2**32)), int(rng.bit_generator.random_raw()))
        if tick == tq:
            receiver_record = decode(world.raw, receiver)
        if tick < tq:
            world.tick()
    expected_merge = 2 * B + sum(deltas)
    expected_response = expected_merge + query
    return {
        "index": index,
        "mode": mode,
        "deltas": deltas,
        "query": query,
        "port_empty": port_empty,
        "merge_record": merge_record,
        "receiver_record": receiver_record,
        "merge_exact": mode == "overlap" and merge_record is not None and merge_record["d"] == [0, 1, 1] and merge_record["sreg"] == expected_merge,
        "composed_response_exact": mode == "overlap" and receiver_record is not None and receiver_record["d"] == [1, 1, 1] and receiver_record["sreg"] == expected_response,
        "individual_identity": mode == "overlap" and receiver_record is not None and receiver_record["sreg"] - B in {query + deltas[0], query + deltas[1]},
        "false_merge": mode == "off_fiber" and merge_record is not None and merge_record["d"] == [0, 1, 1] and merge_record["sreg"] == expected_merge,
    }


def main():
    observed = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock mismatch {observed}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    rng = np.random.default_rng(lock["parameters"]["seed"])
    separated = [separated_panel(kernel, spec, lock, rng) for spec in lock["domain"]["new_separated_panels"]]
    overlaps = []
    for i, (deltas, query) in enumerate(zip(lock["parameters"]["overlap_delta_pairs"], lock["parameters"]["overlap_queries"], strict=True)):
        overlaps.append(overlap_panel(kernel, i, deltas, query, "overlap", lock, rng))
        overlaps.append(overlap_panel(kernel, i, deltas, query, "off_fiber", lock, rng))
    active_overlap = [x for x in overlaps if x["mode"] == "overlap"]
    off_fiber = [x for x in overlaps if x["mode"] == "off_fiber"]
    rates = {
        "separated_panel_exact_rate": sum(x["all_exact"] for x in separated) / len(separated),
        "separated_channel_exact_rate": sum(x["exact_channels"] for x in separated) / sum(x["channels"] for x in separated),
        "training_budget_exact_rate": sum(x["training_budget_exact"] for x in separated) / len(separated),
        "read_budget_exact_rate": sum(x["read_budget_exact"] for x in separated) / len(separated),
        "sreg_accounting_exact_rate": sum(x["sreg_accounting_exact"] for x in separated) / len(separated),
        "overlap_merge_exact_rate": sum(x["merge_exact"] for x in active_overlap) / len(active_overlap),
        "overlap_composed_response_exact_rate": sum(x["composed_response_exact"] for x in active_overlap) / len(active_overlap),
        "overlap_individual_identity_rate": sum(x["individual_identity"] for x in active_overlap) / len(active_overlap),
        "off_fiber_false_merge_rate": sum(x["false_merge"] for x in off_fiber) / len(off_fiber),
        "ports_empty_rate": (sum(x["ports_empty"] for x in separated) + sum(x["port_empty"] for x in active_overlap)) / (len(separated) + len(active_overlap)),
    }
    m = lock["minimum_relevance"]
    pass_conditions = {
        key: rates[key] >= threshold
        for key, threshold in m.items()
        if not key.endswith("_max")
    }
    pass_conditions["individual_loss"] = rates["overlap_individual_identity_rate"] <= m["overlap_individual_identity_rate_max"]
    pass_conditions["off_fiber"] = rates["off_fiber_false_merge_rate"] <= m["off_fiber_false_merge_rate_max"]
    pass_conditions["ports"] = rates["ports_empty_rate"] == 1.0
    verdict = "PASS" if all(pass_conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core07.c7h02.v1",
        "experiment_id": lock["hypothesis_id"],
        "role": "FROZEN_CONFIRMATION_PLUS_EXACT_SECTOR_ACCOUNTING",
        "lock_sha256": observed,
        "kernel_environment": environment,
        "sample_sizes": {"separated_panels": len(separated), "separated_channels": sum(x["channels"] for x in separated), "max_K": max(x["channels"] for x in separated), "overlap_panels": len(active_overlap), "off_fiber_controls": len(off_fiber)},
        "rates": rates,
        "pass_conditions": pass_conditions,
        "verdict": verdict,
        "exact_sector_derivation": "For a blank destination fiber with k>=1 semantic-1 proposals, the sealed reducer writes one output, so support changes by 1-k. With no source/birth/death or preoccupied destination, summing disjoint fibers gives Delta support=-sum(k_f-1). Below the cap, s_reg sums exactly. Therefore each binary collision-mediated learning/read/relay operation spends one active carrier; a source-free apparatus has a finite such-operation budget.",
        "epistemic_scope": "K=40 is a witnessed lower bound on separated routed memory capacity, not a global maximum. The collision budget is exact only in the stated normal blank-destination sector and is not identified with external energy.",
        "separated": separated,
        "overlap": overlaps,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(OUT, result)
    print(json.dumps({k: result[k] for k in ("sample_sizes", "rates", "pass_conditions", "verdict")}, indent=2, sort_keys=True))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
