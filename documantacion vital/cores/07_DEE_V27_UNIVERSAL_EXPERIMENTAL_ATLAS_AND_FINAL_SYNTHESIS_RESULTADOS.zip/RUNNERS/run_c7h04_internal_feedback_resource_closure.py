#!/usr/bin/env python3
"""Frozen C7H04: internal feedback path and resource-closure adjudication."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import NativeWorld, atomic_json, canonical_hash, fields, pack, verify_and_load_kernel

WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "C7H04_INTERNAL_FEEDBACK_AND_RESOURCE_CLOSURE.json"
OUT = WORK / "RESULTS" / "C7H04_internal_feedback_resource_closure.json"
EXPECTED_LOCK_SHA256 = "00e9b744de9af60f47b840cc1da8784e2880628c54fc7e43592ea792efba5176"
BASE = {"cue": (1, 0, 0), "teacher": (-1, 1, 0), "memory": (0, 1, 0), "sense": (1, -1, 0), "d1": (1, 0, 0), "act2": (-1, 1, 0), "d2": (0, 1, 0), "act3": (-1, -1, 0), "d3": (-1, 0, 0), "act4": (1, -1, 0), "d4": (0, -1, 0), "off": (0, 0, 1)}
B = 4096


def add(q, d, k, n): return tuple((q[i] + k * d[i]) % n for i in range(3))
def transform(v, permutation, signs): return tuple(signs[i] * v[permutation[i]] for i in range(3))


def decode(raw, q):
    if int(raw[q]) == 0: return None
    f = fields(raw)
    return {"sreg": int(f["sreg"][q]), "d": [int(f[x][q]) for x in ("dx", "dy", "dz")], "semantic": int(f["semantic"][q])}


def totals(raw):
    f = fields(raw)
    return {"support": int(np.count_nonzero(raw)), "sreg_sum": int(f["sreg"].astype(np.uint64).sum())}


def place_initial(raw, clock, target, tick, d, sreg, state, clk, n):
    q = add(target, d, -tick, n)
    if int(raw[q]) != 0: raise RuntimeError(f"initial overlap {q}")
    raw[q] = pack(state, sreg, d, 1); clock[q] = np.uint64(clk)


def simulate(kernel, cell, mode, lock):
    n, L, v = cell["n"], cell["L"], cell["vectors"]
    t0, t1 = lock["domain"]["train_tick"], lock["domain"]["sense_tick"]
    t2, t3, t4, tf = t1 + L, t1 + 2 * L, t1 + 3 * L, t1 + 4 * L
    cue, teacher, memory, sense = (tuple(v[x]) for x in ("cue", "teacher", "memory", "sense"))
    d1, act2, d2, act3, d3, act4, d4, off = (tuple(v[x]) for x in ("d1", "act2", "d2", "act3", "d3", "act4", "d4", "off"))
    e1 = tuple(cell["sensor"]); j = add(e1, memory, -(t1 - t0), n)
    e2 = add(e1, d1, L, n); e3 = add(e2, d2, L, n); e4 = add(e3, d3, L, n); closed = add(e4, d4, L, n) == e1
    raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw)
    states, clocks, x = cell["states"], cell["clocks"], cell["training_x"]
    if mode != "no_training":
        place_initial(raw, clock, j, t0, cue, B - x, states[0 if mode != "state_nuisance" else 8], clocks[0], n)
        place_initial(raw, clock, j, t0, teacher, x + cell["delta"], states[1 if mode != "state_nuisance" else 9], clocks[1], n)
    if mode != "no_query": place_initial(raw, clock, e1, t1, sense, cell["query"], states[2], clocks[2 if mode != "clock_nuisance" else 8], n)
    for ident, target, tick, direction, load in ((2, e2, t2, act2, cell["loads"][0]), (3, e3, t3, act3, cell["loads"][1]), (4, e4, t4, act4, cell["loads"][2])):
        if mode == f"no_actuator_{ident}": continue
        if mode == "route_shuffle_2" and ident == 2: direction = tuple(-q for q in act2)
        if mode == "off_path_actuator" and ident == 3: target = add(target, off, 3, n)
        place_initial(raw, clock, target, tick, direction, load, states[ident + 1], clocks[ident + 1], n)
    initial = totals(raw); world = NativeWorld(kernel, raw, clock, threads=1)
    points = {t0: ("training", j), t1: ("sense", e1), t2: ("action_2", e2), t3: ("action_3", e3), t4: ("action_4", e4), tf: ("feedback", e1)}
    events, trace = {}, []
    for tick in range(tf + 1):
        trace.append({"tick": tick, **totals(world.raw)})
        if tick in points:
            label, point = points[tick]; events[label] = decode(world.raw, point)
        if tick < tf: world.tick()
    feedback = events["feedback"]; expected_sreg = B + cell["delta"] + cell["query"] + sum(cell["loads"])
    exact = feedback is not None and feedback["d"] == list(d4) and feedback["sreg"] == expected_sreg
    supports = [trace[t]["support"] for t in (0, t0, t1, t2, t3, t4, tf)]
    positive = mode in {"intact", "state_nuisance", "clock_nuisance"}
    return {"cell": cell["cell"], "n": n, "L": L, "frame": cell["frame"], "mode": mode, "spatially_closed": closed, "feedback_exact": exact, "initial": initial, "final": trace[tf], "support_sequence": supports, "support_budget_exact": positive and supports == [6, 5, 4, 3, 2, 1, 1], "sreg_accounting_exact": positive and trace[tf]["sreg_sum"] == initial["sreg_sum"], "remaining_required_memory_count": 0 if positive and trace[tf]["support"] == 1 else None, "remaining_required_actuator_count": 0 if positive and trace[tf]["support"] == 1 else None, "events": events}


def main():
    observed = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if observed != EXPECTED_LOCK_SHA256: raise RuntimeError(f"lock mismatch {observed}")
    lock = json.loads(LOCK.read_text(encoding="utf-8")); kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    cells = []
    for i, (n, L, delta, query, loads, frame, x, seed) in enumerate(zip(lock["domain"]["new_sizes"], lock["domain"]["new_segment_lengths"], lock["domain"]["new_deltas"], lock["domain"]["new_queries"], lock["domain"]["actuator_loads"], lock["domain"]["frames"], lock["parameters"]["training_x"], lock["parameters"]["seeds"], strict=True)):
        rng = np.random.default_rng(seed); vectors = {k: list(transform(d, frame["permutation"], frame["signs"])) for k, d in BASE.items()}
        cells.append({"cell": i, "n": n, "L": L, "delta": delta, "query": query, "loads": loads, "frame": frame, "training_x": x, "vectors": vectors, "sensor": [int(q) for q in rng.integers(12, n - 12, size=3)], "states": [int(q) for q in rng.integers(1, 2**32, size=10, dtype=np.uint64)], "clocks": [int(rng.bit_generator.random_raw()) for _ in range(10)]})
    cases = [simulate(kernel, cell, mode, lock) for cell in cells for mode in lock["parameters"]["modes"]]
    positives = [c for c in cases if c["mode"] in {"intact", "state_nuisance", "clock_nuisance"}]; negatives = [c for c in cases if c["mode"] not in {"intact", "state_nuisance", "clock_nuisance"}]
    rates = {"positive_exact_rate": sum(c["feedback_exact"] for c in positives) / len(positives), "negative_inexact_rate": sum(not c["feedback_exact"] for c in negatives) / len(negatives), "support_budget_exact_rate": sum(c["support_budget_exact"] for c in positives) / len(positives), "sreg_accounting_exact_rate": sum(c["sreg_accounting_exact"] for c in positives) / len(positives), "spatial_closure_rate": sum(c["spatially_closed"] for c in cases) / len(cases), "final_support": max(c["final"]["support"] for c in positives), "remaining_required_memory_count": max(c["remaining_required_memory_count"] for c in positives), "remaining_required_actuator_count": max(c["remaining_required_actuator_count"] for c in positives)}
    m = lock["minimum_relevance"]
    pass_conditions = {k: (rates[k] >= v if k.endswith("_rate") else rates[k] == v) for k, v in m.items()}
    verdict = "PASS" if all(pass_conditions.values()) else "FAIL"
    result = {"schema": "dee.v27.core07.c7h04.v1", "experiment_id": lock["hypothesis_id"], "role": "FROZEN_CONFIRMATION_PLUS_EXACT_SECTOR_ACCOUNTING", "lock_sha256": observed, "kernel_environment": environment, "sample_sizes": {"cells": len(cells), "cases": len(cases), "positive": len(positives), "controls": len(negatives)}, "rates": rates, "pass_conditions": pass_conditions, "verdict": verdict, "adjudication_scope": "The apparatus is an internally causal one-pass feedback circuit. It is neither agency nor a reusable closed resource cycle: exact reducer accounting leaves no trained memory or action carriers for a second traversal. Semantic-source-backed regeneration remains outside this source-free claim.", "cells": cells, "cases": cases}
    result["content_sha256"] = canonical_hash(result); atomic_json(OUT, result)
    print(json.dumps({k: result[k] for k in ("sample_sizes", "rates", "pass_conditions", "verdict")}, indent=2, sort_keys=True)); return 0 if verdict == "PASS" else 2


if __name__ == "__main__": raise SystemExit(main())
