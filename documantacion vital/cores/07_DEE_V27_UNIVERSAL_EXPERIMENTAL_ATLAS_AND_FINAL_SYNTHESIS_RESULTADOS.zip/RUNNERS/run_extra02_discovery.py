#!/usr/bin/env python3
"""EXTRA02 staged discovery on TRAIN/VALIDATION only; FINAL TEST stays unopened."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import atomic_json, canonical_hash, sha256_file, verify_and_load_kernel
from extra02_common import atomic_npz, build_counts_kernel, corrupt_zero, infer_kernel_one, load_data, metrics, score_math

WORK = Path(__file__).resolve().parents[1]
OUT = WORK / "RESULTS" / "EXTRA02_discovery.json"
LEARNED = WORK / "extra02" / "learned_counts.npz"
THRESHOLDS = (4, 8, 12)
NOISE_SEED = 2707030


def knn_predict(train_x, train_y, query_x, k=3):
    pred = []
    tx = train_x.astype(np.int16)
    for row in query_x.astype(np.int16):
        distance = ((tx - row) ** 2).sum(axis=1)
        nearest = np.argpartition(distance, k - 1)[:k]
        votes = np.bincount(train_y[nearest], minlength=10)
        pred.append(int(np.argmax(votes)))
    return np.asarray(pred, dtype=np.int8)


def logistic_fit_predict(train_x, train_y, query_x, epochs=1200, lr=0.35, l2=0.002):
    x = np.c_[train_x.astype(np.float64) / 16.0, np.ones(len(train_x))]
    q = np.c_[query_x.astype(np.float64) / 16.0, np.ones(len(query_x))]
    onehot = np.eye(10)[train_y]
    w = np.zeros((65, 10), dtype=np.float64)
    for _ in range(epochs):
        logits = x @ w; logits -= logits.max(axis=1, keepdims=True)
        prob = np.exp(logits); prob /= prob.sum(axis=1, keepdims=True)
        grad = x.T @ (prob - onehot) / len(x) + l2 * np.r_[w[:-1], np.zeros((1, 10))]
        w -= lr * grad
    return np.argmax(q @ w, axis=1).astype(np.int8), w


def main():
    kernel, environment = verify_and_load_kernel(1)
    x, y, split = load_data(); curriculum, validation, final_test = split["curriculum"], split["validation"], split["final_test"]
    final_guard_before = sha256_file(WORK / "extra02" / "split_indices.npz")
    validation_noisy, _ = corrupt_zero(x[validation], validation, 10, NOISE_SEED)
    candidate_rows, trained_counts = [], {}
    for threshold in THRESHOLDS:
        counts, train_stats = build_counts_kernel(kernel, x, y, curriculum, threshold, y[curriculum])
        trained_counts[threshold] = counts
        clean_scores = score_math(counts, x[validation], threshold)
        noisy_scores = score_math(counts, validation_noisy, threshold)
        candidate_rows.append({"threshold": threshold, "training": train_stats, "clean": metrics(y[validation], np.argmax(clean_scores, axis=1)), "zero10": metrics(y[validation], np.argmax(noisy_scores, axis=1))})
    chosen = max(candidate_rows, key=lambda r: (r["zero10"]["balanced_accuracy"], r["clean"]["balanced_accuracy"], -r["threshold"]))["threshold"]
    counts = trained_counts[chosen]
    rng = np.random.default_rng(2707050)
    shuffled_labels = y[curriculum].copy(); rng.shuffle(shuffled_labels)
    no_teacher_labels = np.tile(np.arange(10, dtype=np.int8), 20); rng.shuffle(no_teacher_labels)
    label_counts, label_stats = build_counts_kernel(kernel, x, y, curriculum, chosen, shuffled_labels)
    no_teacher_counts, no_teacher_stats = build_counts_kernel(kernel, x, y, curriculum, chosen, no_teacher_labels)
    order = rng.permutation(len(curriculum)); order_counts, order_stats = build_counts_kernel(kernel, x, y, curriculum[order], chosen, y[curriculum][order])
    feature_permutations = np.asarray([rng.permutation(64) for _ in range(10)], dtype=np.int16)
    atomic_npz(LEARNED, trained=counts, label_shuffled=label_counts, no_teacher=no_teacher_counts, order_shuffled=order_counts, untrained=np.zeros_like(counts), memory_ablation=np.zeros_like(counts), feature_permutations=feature_permutations, threshold=np.asarray([chosen], dtype=np.int16))

    clean_kernel_scores, noisy_kernel_scores, inference_stats = [], [], []
    start = time.perf_counter()
    for image in x[validation]:
        score, stats = infer_kernel_one(kernel, counts, image, chosen); clean_kernel_scores.append(score); inference_stats.append(stats)
    for image in validation_noisy:
        score, stats = infer_kernel_one(kernel, counts, image, chosen); noisy_kernel_scores.append(score); inference_stats.append(stats)
    inference_wall = time.perf_counter() - start
    clean_kernel_scores = np.asarray(clean_kernel_scores); noisy_kernel_scores = np.asarray(noisy_kernel_scores)
    clean_math = score_math(counts, x[validation], chosen); noisy_math = score_math(counts, validation_noisy, chosen)
    kernel_equivalence = bool(np.array_equal(clean_kernel_scores, clean_math) and np.array_equal(noisy_kernel_scores, noisy_math))
    pred_clean, pred_noisy = np.argmax(clean_kernel_scores, axis=1), np.argmax(noisy_kernel_scores, axis=1)
    two_mask = np.isin(y[validation], [0, 1]); two_pred = np.argmax(clean_kernel_scores[two_mask, :2], axis=1)
    stage = {"A_two_class_clean": metrics(y[validation][two_mask], two_pred), "B_ten_class_clean": metrics(y[validation], pred_clean), "C_ten_class_zero10": metrics(y[validation], pred_noisy)}
    controls = {}
    for name, table, perm in (("untrained", np.zeros_like(counts), None), ("equal_exposure_no_teacher", no_teacher_counts, None), ("label_shuffled_teacher", label_counts, None), ("memory_ablation", np.zeros_like(counts), None), ("reset", np.zeros_like(counts), None), ("encoder_only_no_evolution", np.zeros_like(counts), None), ("destroyed_relation", counts, feature_permutations)):
        clean_score = score_math(table, x[validation], chosen, perm)
        noisy_score = score_math(table, validation_noisy, chosen, perm)
        controls[name] = {"clean": metrics(y[validation], np.argmax(clean_score, axis=1)), "zero10": metrics(y[validation], np.argmax(noisy_score, axis=1))}
    # Exact-kernel audit on 30 fixed validation cases for causal control tables.
    audit_idx = validation[np.linspace(0, len(validation) - 1, 30, dtype=int)]
    audit = {}
    for name, table, perm in (("trained", counts, None), ("label_shuffled_teacher", label_counts, None), ("equal_exposure_no_teacher", no_teacher_counts, None), ("destroyed_relation", counts, feature_permutations)):
        exact = 0
        for image in x[audit_idx]:
            observed, _ = infer_kernel_one(kernel, table, image, chosen, perm)
            expected = score_math(table, image[None, :], chosen, perm)[0]
            exact += int(np.array_equal(observed, expected))
        audit[name] = {"exact": exact, "total": len(audit_idx)}
    knn_clean = knn_predict(x[curriculum], y[curriculum], x[validation], 3); knn_noisy = knn_predict(x[curriculum], y[curriculum], validation_noisy, 3)
    logistic_clean, weights = logistic_fit_predict(x[curriculum], y[curriculum], x[validation]); logistic_noisy = np.argmax(np.c_[validation_noisy.astype(np.float64) / 16.0, np.ones(len(validation_noisy))] @ weights, axis=1)
    baselines = {"knn3_20shot": {"clean": metrics(y[validation], knn_clean), "zero10": metrics(y[validation], knn_noisy)}, "multinomial_logistic_20shot": {"clean": metrics(y[validation], logistic_clean), "zero10": metrics(y[validation], logistic_noisy)}}
    result = {
        "schema": "dee.v27.core07.extra02.discovery.v1", "experiment_id": "EXTRA02_STAGED_DISCOVERY", "role": "DISCOVERY_VALIDATION_ONLY",
        "final_test_opened": False, "final_test_size_guard": len(final_test), "split_npz_sha256_before": final_guard_before,
        "question": "Can destination-fiber learning implement label-blind ten-class digit generalization under structural damage, before opening FINAL TEST?",
        "apparatus": {"training": "Each of 200 TRAIN images emits 64 unit-load feature-bit carriers into one of ten fixed teacher-selected banks. F_DEE reduces each bank/feature/bit fiber to an empirical count.", "inference": "For each image and class, 64 selected learned counts are reduced through four 16-input fibers to one fixed class output port; fixed argmax readout.", "encoder": "64 independent pixel threshold bits; threshold chosen among three predeclared values using VALIDATION only.", "stable_answer_W": 3, "memory_cells": 1280, "label_blind": True, "readout_trained": False},
        "threshold_candidates": candidate_rows, "chosen_threshold": chosen, "stage_results": stage, "kernel_math_equivalence_full_validation": kernel_equivalence,
        "kernel_control_audit": audit, "controls_validation": controls, "baselines_validation": baselines,
        "training_controls": {"trained": candidate_rows[[r["threshold"] for r in candidate_rows].index(chosen)]["training"], "label_shuffled": label_stats, "equal_exposure_no_teacher": no_teacher_stats, "training_order_shuffle": order_stats, "order_invariant_counts": bool(np.array_equal(counts, order_counts))},
        "timing": {"kernel_validation_inference_wall_seconds": inference_wall, "kernel_inference_cases": len(inference_stats), "kernel_calls": sum(s["kernel_calls"] for s in inference_stats), "mean_inference_seconds": float(np.mean([s["wall_seconds"] for s in inference_stats]))},
        "state": {"learned_counts_path": "extra02/learned_counts.npz", "learned_counts_sha256": sha256_file(LEARNED), "serialized_bytes_uncompressed": int(counts.nbytes), "nonzero_memory_cells": int(np.count_nonzero(counts)), "all_stable": all(s["stable"] for s in inference_stats), "T_first": 5, "T_stable": 7, "peak_active_support": max(s["peak_active_support"] for s in inference_stats)},
        "epistemic_scope": "This architecture is a DEE-executed categorical histogram/reducer, not a novel learning algorithm. FINAL TEST and promotion criteria remain to be frozen.",
    }
    result["content_sha256"] = canonical_hash(result); atomic_json(OUT, result)
    print(json.dumps({"chosen_threshold": chosen, "stage": {k: {m: v[m] for m in ("accuracy", "balanced_accuracy", "macro_f1")} for k, v in stage.items()}, "controls": {k: v["zero10"]["accuracy"] for k, v in controls.items()}, "baselines": {k: v["zero10"]["accuracy"] for k, v in baselines.items()}, "kernel_equivalence": kernel_equivalence, "state": result["state"], "final_test_opened": False}, indent=2, sort_keys=True)); return 0


if __name__ == "__main__": raise SystemExit(main())
