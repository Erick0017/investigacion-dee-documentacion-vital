#!/usr/bin/env python3
"""Frozen EXTRA02 FINAL TEST. Idempotent per-mode partials permit safe resume."""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core07_common import atomic_json, canonical_hash, sha256_file, verify_and_load_kernel
from extra02_common import atomic_npz, corrupt_occlusion, corrupt_replace, corrupt_zero, infer_kernel_one, load_data, metrics, score_math, translate_one

WORK = Path(__file__).resolve().parents[1]
LOCK = WORK / "HOLDOUT_LOCKS" / "EXTRA02_NOISY_MULTICLASS_FINAL.json"
OUT = WORK / "RESULTS" / "EXTRA02_noisy_multiclass_final.json"
LEARNED = WORK / "extra02" / "learned_counts.npz"
EXPECTED_LOCK_SHA256 = "c4577a212111e5c36238069665770f059d2e35f62090ba6392e3a46734268d7f"


def array_hash(a):
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def strict_metrics(y, pred, stable):
    correct = stable & (pred == y)
    matrix = np.zeros((10, 10), dtype=np.int32); abstain = np.zeros(10, dtype=np.int32)
    for truth, guess, ok in zip(y, pred, stable, strict=True):
        if ok: matrix[int(truth), int(guess)] += 1
        else: abstain[int(truth)] += 1
    recalls, f1s = [], []
    for c in range(10):
        tp = matrix[c, c]; fn = int((y == c).sum()) - tp; fp = matrix[:, c].sum() - tp
        recall = tp / (tp + fn) if tp + fn else 0.0; precision = tp / (tp + fp) if tp + fp else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        recalls.append(recall); f1s.append(f1)
    return {"strict_stable_accuracy": float(correct.mean()), "score_tick_accuracy": float((pred == y).mean()), "stable_answer_rate": float(stable.mean()), "balanced_accuracy": float(np.mean(recalls)), "macro_f1": float(np.mean(f1s)), "per_class_recall": recalls, "confusion_matrix_stable_answers": matrix.tolist(), "abstentions_by_true_class": abstain.tolist(), "correct_vector": correct.astype(np.uint8).tolist()}


def bootstrap_difference(a, b, seed, replicates):
    rng = np.random.default_rng(seed); n = len(a); values = np.empty(replicates, dtype=np.float64)
    for i in range(replicates):
        idx = rng.integers(0, n, size=n); values[i] = float((a[idx] - b[idx]).mean())
    return [float(np.quantile(values, 0.025)), float(np.quantile(values, 0.975))]


def knn_predict(train_x, train_y, query_x, k=3):
    tx = train_x.astype(np.int16); pred = []
    for row in query_x.astype(np.int16):
        distance = ((tx - row) ** 2).sum(axis=1); nearest = np.argpartition(distance, k - 1)[:k]
        pred.append(int(np.argmax(np.bincount(train_y[nearest], minlength=10))))
    return np.asarray(pred, dtype=np.int8)


def logistic_weights(train_x, train_y, epochs=1200, lr=0.35, l2=0.002):
    x = np.c_[train_x.astype(np.float64) / 16.0, np.ones(len(train_x))]; onehot = np.eye(10)[train_y]
    w = np.zeros((65, 10), dtype=np.float64)
    for _ in range(epochs):
        logits = x @ w; logits -= logits.max(axis=1, keepdims=True); prob = np.exp(logits); prob /= prob.sum(axis=1, keepdims=True)
        w -= lr * (x.T @ (prob - onehot) / len(x) + l2 * np.r_[w[:-1], np.zeros((1, 10))])
    return w


def logistic_predict(w, q): return np.argmax(np.c_[q.astype(np.float64) / 16.0, np.ones(len(q))] @ w, axis=1).astype(np.int8)


def run_mode(kernel, name, table, images, threshold, feature_permutations=None):
    partial = WORK / "RESULTS" / f"EXTRA02_partial_{name}.npz"
    meta_path = WORK / "RESULTS" / f"EXTRA02_partial_{name}.json"
    if partial.is_file() and meta_path.is_file():
        meta = json.loads(meta_path.read_text(encoding="utf-8"))
        if meta.get("lock_sha256") == EXPECTED_LOCK_SHA256 and meta.get("images") == len(images):
            z = np.load(partial)
            return {k: z[k].copy() for k in z.files}, meta
    scores, predictions, stable, seconds, kernel_calls, peaks = [], [], [], [], [], []
    started = time.perf_counter()
    for i, image in enumerate(images):
        score, stats = infer_kernel_one(kernel, table, image, threshold, feature_permutations)
        scores.append(score); predictions.append(stats["prediction"]); stable.append(stats["stable"]); seconds.append(stats["wall_seconds"]); kernel_calls.append(stats["kernel_calls"]); peaks.append(stats["peak_active_support"])
        if (i + 1) % 60 == 0: print(json.dumps({"mode": name, "complete": i + 1, "total": len(images)}), flush=True)
    arrays = {"scores": np.asarray(scores, dtype=np.int32), "predictions": np.asarray(predictions, dtype=np.int8), "stable": np.asarray(stable, dtype=np.bool_), "seconds": np.asarray(seconds, dtype=np.float64), "kernel_calls": np.asarray(kernel_calls, dtype=np.int16), "peak_support": np.asarray(peaks, dtype=np.int32)}
    atomic_npz(partial, **arrays)
    meta = {"schema": "dee.v27.core07.extra02.partial.v1", "mode": name, "lock_sha256": EXPECTED_LOCK_SHA256, "images": len(images), "wall_seconds": time.perf_counter() - started, "npz": partial.name, "npz_sha256": sha256_file(partial), "status": "COMPLETE"}
    atomic_json(meta_path, meta)
    return arrays, meta


def main():
    observed_lock = sha256_file(LOCK)
    if observed_lock != EXPECTED_LOCK_SHA256: raise RuntimeError(f"lock mismatch {observed_lock}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    if sha256_file(WORK / "extra02" / "digits.csv.gz") != lock["domain"]["dataset_sha256"]: raise RuntimeError("dataset changed")
    if sha256_file(WORK / "extra02" / "split_indices.npz") != lock["domain"]["split_npz_sha256"]: raise RuntimeError("split changed")
    if sha256_file(LEARNED) != lock["domain"]["learned_state_sha256"]: raise RuntimeError("learned state changed")
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    x, y, split = load_data(); test, curriculum = split["final_test"], split["curriculum"]
    if array_hash(test) != lock["domain"]["final_test_index_hash"] or len(test) != lock["domain"]["final_test_images"]: raise RuntimeError("FINAL TEST identity mismatch")
    z = np.load(LEARNED); threshold = int(z["threshold"][0]); primary_images, primary_masks = corrupt_zero(x[test], test, 10, lock["domain"]["primary_corruption_seed"])
    if threshold != lock["parameters"]["threshold"]: raise RuntimeError("threshold mismatch")
    start_all = time.perf_counter()
    mode_specs = {
        "trained_primary": (z["trained"], primary_images, None),
        "trained_clean": (z["trained"], x[test], None),
        "untrained": (z["untrained"], primary_images, None),
        "equal_exposure_no_teacher": (z["no_teacher"], primary_images, None),
        "label_shuffled_teacher": (z["label_shuffled"], primary_images, None),
        "destroyed_relation": (z["trained"], primary_images, z["feature_permutations"]),
    }
    modes, partial_meta = {}, {}
    for name, (table, images, perm) in mode_specs.items():
        arrays, meta = run_mode(kernel, name, table, images, threshold, perm); modes[name] = arrays; partial_meta[name] = meta
    # Byte-identical zero states make these three controls exactly reusable.
    for name in ("memory_ablation", "reset", "encoder_only_no_evolution"):
        modes[name] = modes["untrained"]
        partial_meta[name] = {"status": "EXACT_REUSE", "source": "untrained", "reason": "frozen count state is byte-identical all-zero"}
    modes["training_order_shuffle"] = modes["trained_primary"]
    partial_meta["training_order_shuffle"] = {"status": "EXACT_REUSE", "source": "trained_primary", "reason": "order-shuffled training produced byte-identical count state"}

    mode_metrics = {}
    for name, arrays in modes.items():
        truth = y[test]
        mode_metrics[name] = strict_metrics(truth, arrays["predictions"], arrays["stable"])
        expected = score_math(z["trained"] if name in {"trained_primary", "trained_clean", "training_order_shuffle", "destroyed_relation"} else (z["no_teacher"] if name == "equal_exposure_no_teacher" else (z["label_shuffled"] if name == "label_shuffled_teacher" else z["untrained"])), x[test] if name == "trained_clean" else primary_images, threshold, z["feature_permutations"] if name == "destroyed_relation" else None)
        mode_metrics[name]["kernel_math_equivalence_rate"] = float(np.mean(np.all(arrays["scores"] == expected, axis=1)))
    causal_controls = ("untrained", "equal_exposure_no_teacher", "label_shuffled_teacher", "memory_ablation", "reset", "encoder_only_no_evolution", "destroyed_relation")
    trained_correct = np.asarray(mode_metrics["trained_primary"].pop("correct_vector"), dtype=np.float64)
    differences, margins = {}, {}
    for i, name in enumerate(causal_controls):
        control_correct = np.asarray(mode_metrics[name].pop("correct_vector"), dtype=np.float64)
        margins[name] = float(trained_correct.mean() - control_correct.mean())
        differences[name] = bootstrap_difference(trained_correct, control_correct, lock["parameters"]["bootstrap_seed"] + i, lock["parameters"]["bootstrap_replicates"])
    mode_metrics["trained_clean"].pop("correct_vector", None); mode_metrics["training_order_shuffle"].pop("correct_vector", None)

    baseline_start = time.perf_counter(); w = logistic_weights(x[curriculum], y[curriculum])
    baseline_pred = {
        "knn3_20shot_clean": knn_predict(x[curriculum], y[curriculum], x[test], 3),
        "knn3_20shot_primary": knn_predict(x[curriculum], y[curriculum], primary_images, 3),
        "multinomial_logistic_20shot_clean": logistic_predict(w, x[test]),
        "multinomial_logistic_20shot_primary": logistic_predict(w, primary_images),
    }
    baselines = {name: metrics(y[test], pred) for name, pred in baseline_pred.items()}; baseline_wall = time.perf_counter() - baseline_start

    secondary_images = {}
    for count in lock["domain"]["secondary_zero_counts"]: secondary_images[f"zero_{count}"] = corrupt_zero(x[test], test, count, lock["domain"]["primary_corruption_seed"])[0]
    secondary_images.update({"random_replace_10": corrupt_replace(x[test], test, 10, 2707090), "occlusion_3x3": corrupt_occlusion(x[test], test, 2707100), "translate_row_plus1": translate_one(x[test], (1, 0)), "translate_col_plus1": translate_one(x[test], (0, 1)), "translate_row_minus1": translate_one(x[test], (-1, 0)), "translate_col_minus1": translate_one(x[test], (0, -1))})
    secondary = {}
    for name, images in secondary_images.items(): secondary[name] = metrics(y[test], np.argmax(score_math(z["trained"], images, threshold), axis=1))
    audit_positions = np.linspace(0, len(test) - 1, 5, dtype=int); secondary_audit = {}
    for name, images in secondary_images.items():
        exact = 0
        for pos in audit_positions:
            observed, _ = infer_kernel_one(kernel, z["trained"], images[pos], threshold)
            expected = score_math(z["trained"], images[pos:pos+1], threshold)[0]
            exact += int(np.array_equal(observed, expected))
        secondary_audit[name] = {"exact": exact, "total": len(audit_positions)}

    trained_primary = mode_metrics["trained_primary"]; trained_clean = mode_metrics["trained_clean"]
    retention = trained_primary["strict_stable_accuracy"] / trained_clean["strict_stable_accuracy"] if trained_clean["strict_stable_accuracy"] else 0.0
    m = lock["minimum_relevance"]
    pass_conditions = {
        "clean": trained_clean["strict_stable_accuracy"] >= m["clean_strict_stable_accuracy"],
        "primary_accuracy": trained_primary["strict_stable_accuracy"] >= m["primary_noisy_strict_stable_accuracy"],
        "primary_balanced": trained_primary["balanced_accuracy"] >= m["primary_noisy_balanced_accuracy"],
        "primary_f1": trained_primary["macro_f1"] >= m["primary_noisy_macro_f1"],
        "stable": trained_primary["stable_answer_rate"] >= m["primary_stable_answer_rate"],
        "retention": retention >= m["robustness_retention"],
        "margins": min(margins.values()) >= m["margin_over_each_causal_control"],
        "bootstrap": min(v[0] for v in differences.values()) >= m["paired_bootstrap_difference_95_lower"],
        "kernel_equivalence": min(mode_metrics[name]["kernel_math_equivalence_rate"] for name in mode_metrics) >= m["full_primary_kernel_math_score_equivalence_rate"],
        "order": bool(np.array_equal(z["trained"], z["order_shuffled"])) and mode_metrics["training_order_shuffle"]["strict_stable_accuracy"] == trained_primary["strict_stable_accuracy"],
    }
    causal_pass = all(pass_conditions.values())
    best_baseline = max(baselines["knn3_20shot_primary"]["accuracy"], baselines["multinomial_logistic_20shot_primary"]["accuracy"])
    levels = {"CAUSAL_MULTICLASS_LEARNING_FOUND": causal_pass, "ROBUST_MULTICLASS_CLASSIFIER_FOUND": causal_pass and trained_primary["balanced_accuracy"] >= 0.60 and retention >= 0.75, "COMPETITIVE_ARCHITECTURE_CANDIDATE": causal_pass and trained_primary["strict_stable_accuracy"] >= best_baseline - 0.05, "SUPERIORITY_CANDIDATE": causal_pass and trained_primary["strict_stable_accuracy"] >= best_baseline + 0.02}
    verdict = "PASS" if causal_pass else "FAIL"
    result = {
        "schema": "dee.v27.core07.extra02.final.v1", "experiment_id": lock["hypothesis_id"], "role": "FROZEN_FINAL_HOLDOUT", "lock_sha256": observed_lock, "verdict": verdict, "descriptive_levels": levels,
        "kernel_environment": environment, "dataset": {"final_test_images": len(test), "final_index_hash": array_hash(test), "primary_masks_hash": canonical_hash(primary_masks), "opened_once_by_this_runner": True},
        "mode_metrics": mode_metrics, "robustness_retention": retention, "margins_over_controls": margins, "paired_bootstrap_difference_95": differences, "pass_conditions": pass_conditions,
        "baselines": baselines, "secondary_analytic_exact_reducer": secondary, "secondary_kernel_audit": secondary_audit,
        "timing_and_cost": {"total_holdout_wall_seconds": time.perf_counter() - start_all, "baseline_wall_seconds": baseline_wall, "kernel_primary_cases_actually_run": sum(meta.get("images", 0) for meta in partial_meta.values() if meta.get("status") == "COMPLETE"), "kernel_calls_actually_run": int(sum(arrays["kernel_calls"].sum() for name, arrays in modes.items() if partial_meta[name].get("status") == "COMPLETE")), "mode_partials": partial_meta, "trained_mean_inference_seconds": float(modes["trained_primary"]["seconds"].mean()), "trained_peak_active_support": int(modes["trained_primary"]["peak_support"].max()), "learned_state_uncompressed_bytes": int(z["trained"].nbytes), "learned_nonzero_cells": int(np.count_nonzero(z["trained"]))},
        "interpretation": "The primary claim is causal DEE multiclass generalization if PASS. The classifier is an explicit categorical histogram/destination-fiber reducer and is not a novel state-of-the-art algorithm or evidence for H_DEE. Conventional baseline superiority is adjudicated independently by descriptive levels.",
    }
    result["content_sha256"] = canonical_hash(result); atomic_json(OUT, result)
    print(json.dumps({"verdict": verdict, "levels": levels, "trained_clean": trained_clean, "trained_primary": trained_primary, "retention": retention, "control_margins": margins, "bootstrap_lower": {k: v[0] for k, v in differences.items()}, "baselines": {k: v["accuracy"] for k, v in baselines.items()}, "pass_conditions": pass_conditions, "wall_seconds": result["timing_and_cost"]["total_holdout_wall_seconds"]}, indent=2, sort_keys=True)); return 0 if verdict == "PASS" else 2


if __name__ == "__main__": raise SystemExit(main())
