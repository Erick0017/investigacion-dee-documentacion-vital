# Síntesis transversal CORE01–07

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


| CORE | Aporte que sobrevive | Límite vigente |
|---|---|---|
| 01 | Q0=`raw+clock`, causalidad local raw≤3, carrier balístico, fuentes/colisiones, leyes sectoriales | no equivalencia física global |
| 02 | estados/eventos separados; M\*, G†, J†, roles L/C/O y fibras predictivas | las fibras certificadas no son cierre universal |
| 03 | Q2 basin/organización y predictor `q_N` en dominio holdout | `q_N` no es causa fundamental ni universal |
| 04 | ledger S/R/C/X/D, `A_t`, Γ y Q3 de histories productivas | no Q4 global ni cierre completo con `(q,κ,a,Γ)` |
| 05 | proposal graph, destination fibers, observador/medición internos, delay-to-place, fase/historia | recurrencia finita; Rosetta sólo interna/estructural |
| 06 | aprendizaje, traducciones/composición, materia operacional, cinemática interna, Bell local, ensambles disipativos, Rosetta compatible | sin regla aritmética general, Lorentz, quantum físico ni termodinámica completa |
| 07 | transferencia funcional, capacidad relacional, reprogramación, feedback one-pass, EXTRA02 y operador unificador | cierre sectorial, no Q4 global ni Rosetta validada |

La jerarquía no es una pirámide única. `raw/clock`, routing, carga/provenance, semantic guards, fibers, linajes, historia, basin, observador, aprendizaje y ensemble son coordenadas cruzadas con dependencias parciales. Q0 es Markoviano completo; Q1–Q3 son cocientes útiles en dominios certificados. CORE07 añade un operador transversal, no un nuevo nivel nominal.

Genealogía de cambio principal: los documentos históricos que llamaron a una constante, forma o aparato “energía”, “luz”, “quantum” o “teleportación” se conservan como historia, pero la adjudicación vigente exige función causal, dominio, control y holdout. `CLAIM_LEDGER.ndjson` conserva simultáneamente fuente y estado actual.
