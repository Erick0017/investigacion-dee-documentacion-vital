# Arquitectura nativa unificada

> Alcance epistemológico: los resultados internos caracterizan el binario DEE v27 sellado en los dominios declarados. No demuestran por sí solos que DEE describa la realidad externa.


## Operador

1. `X_t=(raw_t,clock_t)` es el estado microscópico completo.
2. Guardas locales habilitan propuestas dirigidas `x→d`.
3. Propuestas con el mismo destino forman una fibra `F_d`.
4. El reductor guardado `ρ(F_d,g_d)` resuelve colisión, ocupación, source y contexto.
5. Las salidas forman linajes que transportan estado, carga, routing e historia.
6. Conjuntos de linajes forman organización; otra organización puede actuar como detector y su registro alimentar acciones posteriores.

En el sector normal fuente-libre, destino vacío, debajo de cap:

`ρ: (k, {s_i}, {d_i}) ↦ (support=1, s'=min(Σs_i,19664), d'=sign(Σd_i))`.

La contracción de soporte es exactamente `k-1`. Este cociente explica aprendizaje y composición como escritura por colisión; transferencia como transporte/relay del cociente de respuesta; materia operacional como linaje persistente/interactuable; medición como acoplamiento a una fibra; cómputo como integración; disipación como pérdida many-to-one.

## Cuatro principios nuevos

- **FUNCTION_IS_A_LINEAGE_RESPONSE_QUOTIENT.** La identidad científicamente estable puede ser el repertoire `R(query)`, no el bit pattern.
- **CAPACITY_IS_RELATIONAL.** El número de memorias independientes depende de destinos separados; el solapamiento integra.
- **COMPUTATION_RESOURCE_DUALITY.** El reductor calcula y consume carriers en el mismo evento.
- **OBSERVER_IS_NOT_EXTERNAL.** Detector, registro, acción y retorno pueden estar realizados por DEE.

## Dónde falla el cierre

No están absorbidos globalmente: semantic-4 sources, destinos preocupados, guardas clock/fase, provenance completo, topología global, basins Q2/Q3 y observables físicos externos. Añadirlos puede eliminar la compresión. Por tanto no existe un Q4 global demostrado.

Fuente primaria: `RESULTS/C7A02_unified_relational_operator.json`; testigos C7H01–H04 y EXTRA02.
