#!/usr/bin/env python3
"""Idempotent/resumable master entrypoint for CORE07.

Completed atomic result files are validated and skipped.  Frozen holdouts are
never regenerated or refit.  EXTRA02's resumable runner also reuses complete
per-mode partials if the final aggregate is absent.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNERS = ROOT / "RUNNERS"
PARENT_HASHES = {
    "PARENTS/01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "PARENTS/02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "PARENTS/03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "PARENTS/04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "PARENTS/05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "PARENTS/06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "PARENTS/EXTRAS/EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip": "dd8af27c8a836d9a79919fae92c2a19ee12dc5dedf635ccea92c460010484e7e",
}
KERNEL_HASHES = {
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def valid_json(relative: str) -> bool:
    path = ROOT / relative
    if not path.is_file():
        return False
    try:
        json.loads(path.read_text(encoding="utf-8"))
        return True
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False


def verify_identity() -> None:
    if sys.version_info[:2] != (3, 13):
        raise SystemExit(f"CORE07 kernel reproduction requires CPython 3.13; got {sys.version}")
    for relative, expected in {**PARENT_HASHES, **KERNEL_HASHES}.items():
        path = ROOT / relative
        observed = sha256(path)
        if observed != expected:
            raise SystemExit(f"SEALED IDENTITY MISMATCH {relative}: {observed} != {expected}")


MODULES = [
    ("C7A01", "RESULTS/C7A01_universal_atlas.json", "build_core07_atlas.py"),
    ("C7D01", "RESULTS/C7D01_learning_transfer_discovery.json", "run_c7d01_learning_transfer_discovery.py"),
    ("C7H01", "RESULTS/C7H01_functional_learning_transfer.json", "run_c7h01_functional_learning_transfer.py"),
    ("C7D02", "RESULTS/C7D02_capacity_resource_discovery.json", "run_c7d02_capacity_resource_discovery.py"),
    ("C7H02", "RESULTS/C7H02_destination_fiber_capacity_budget.json", "run_c7h02_destination_fiber_capacity_budget.py"),
    ("C7D03", "RESULTS/C7D03_reprogrammable_matter_repair.json", "run_c7d03_reprogrammable_matter_repair.py"),
    ("C7H03", "RESULTS/C7H03_reprogrammable_functional_matter.json", "run_c7h03_reprogrammable_functional_matter.py"),
    ("C7D04", "RESULTS/C7D04_internal_feedback_resource.json", "run_c7d04_internal_feedback_resource.py"),
    ("C7H04", "RESULTS/C7H04_internal_feedback_resource_closure.json", "run_c7h04_internal_feedback_resource_closure.py"),
    ("EXTRA02_SPLIT", "RESULTS/EXTRA02_dataset_split.json", "prepare_extra02_digits.py"),
    ("EXTRA02_DISCOVERY", "RESULTS/EXTRA02_discovery.json", "run_extra02_discovery.py"),
    ("EXTRA02_FINAL", "RESULTS/EXTRA02_noisy_multiclass_final.json", "run_extra02_final_holdout.py"),
    ("C7A02", "RESULTS/C7A02_unified_relational_operator.json", "analyze_core07_unification.py"),
    ("C7A04", "RESULTS/C7A04_adversarial_audit.json", "adversarial_audit.py"),
]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true", help="verify sealed identities and existing result JSON only")
    parser.add_argument("--no-package", action="store_true", help="run/verify science but do not rebuild the ZIP")
    args = parser.parse_args()
    verify_identity()
    missing = []
    for module_id, marker, runner in MODULES:
        if valid_json(marker):
            print(f"SKIP COMPLETE {module_id}: {marker}")
            continue
        missing.append(module_id)
        if args.verify_only:
            continue
        print(f"RUN {module_id}: {runner}", flush=True)
        subprocess.run([sys.executable, "-I", "-B", str(RUNNERS / runner)], cwd=ROOT, check=True)
        if not valid_json(marker):
            raise SystemExit(f"Runner completed without a valid atomic marker: {marker}")
    if args.verify_only:
        if missing:
            raise SystemExit("Missing/invalid modules: " + ", ".join(missing))
        print("ALL SCIENTIFIC MODULES COMPLETE AND IDENTITIES VERIFIED")
        return 0
    state_complete = valid_json("STATE.json") and json.loads((ROOT / "STATE.json").read_text(encoding="utf-8")).get("status") == "COMPLETE"
    docs_complete = all((ROOT / name).is_file() for name in ("FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "FINAL_FRONTIER.md"))
    if state_complete and docs_complete:
        print("SKIP COMPLETE C7D05: final documents and stopping state")
    else:
        subprocess.run([sys.executable, "-I", "-B", str(RUNNERS / "build_core07_documents.py")], cwd=ROOT, check=True)
    if not args.no_package:
        subprocess.run([sys.executable, "-I", "-B", str(RUNNERS / "build_core07_package.py")], cwd=ROOT, check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
