# Revisión adversarial

- ADV01 [MAJOR_CORRECTED]: C8H03 had 2/24 query/training numeric overlaps. Acción: Preserved original result; current adjudication FAIL_PROTOCOL_LEAKAGE; ran newly locked C8H06 with 18/18 disjoint queries and 0/36 controls.
- ADV02 [MAJOR_PRESERVED]: C8H04 reconstruction passed but naive exponent criterion failed. Acción: Preserved FAIL; new C8H05 preregistered exact finite-size K(N) on unused N.
- ADV03 [ANALYTIC_CORRECTED]: Initial discovery text bounded grad_mag by 26*cap and omitted offset L1 weights. Acción: Corrected to 54*cap and max integer ratio 53; theorem remains true; no holdout depended on old bound.
- ADV04 [SCOPE]: C8H02 uses an immutable semantic-4 boundary scaffold and externally scheduled damage. Acción: R7/A7 restricted to fixed scaffold; no learned regeneration, agency, biology, or external energy claim.
- ADV05 [SCOPE]: Boundary time code carries an O(log N) delay for O(N^2) rays. Acción: Report Theta(N^2 log N) bits, not an O(N^2)-bit arbitrary-bulk holographic code.
- ADV06 [SCOPE]: Neutral external score is post-discovery and has no unused external prediction. Acción: Keep at NEUTRAL_STRUCTURAL_MATCH/EXTERNAL_COMPATIBILITY discovery; ROSETTA_VALIDATED=false.

Estado: `PASS_WITH_CORRECTIONS`.
