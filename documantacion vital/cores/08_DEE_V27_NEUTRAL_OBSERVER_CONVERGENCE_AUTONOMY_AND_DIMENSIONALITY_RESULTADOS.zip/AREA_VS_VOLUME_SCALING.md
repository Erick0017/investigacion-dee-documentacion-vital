# Scaling área frente a volumen

La ley confirmada en N=[21, 27, 35, 43, 51] es `K(N)=ceil((N-4)/3)^2`. Los 1292 carriers se reconstruyeron exactamente. Por tanto el número de rayos es `Theta(N^2)`.

El record explícito guarda dos coordenadas superficiales, delay y payload. Su coste es `Theta(N^2 log N)` bits, no `Theta(N^2)` bits estrictos. Muestrear toda la frontera durante `Theta(N)` ticks costaría `Theta(N^3)` muestras. La prueba no ofrece compresión de un bulk binario arbitrario, cuya información escala volumétricamente.
