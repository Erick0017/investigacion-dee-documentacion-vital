# Regeneración autónoma integrada

El aparato positivo contiene desde t0 ocho voxels `semantic=4` en las esquinas Moore y un centro `semantic=7`. Al borrar el centro, la rama de vacío observa 13 pares opuestos concordantes y ocho activos, crea exactamente el centro en un tick y luego cesa porque el destino deja de estar vacío.

Resultado congelado: 32 mundos, 320 ciclos, recovery=1.0, estabilidad=1.0 y scaffold byte-invariante=1.0. Missing-corner, shuffle de inventario, scaffold no persistente, desconexión y relajación libre dieron recovery=0.

Cadena demostrada: daño → condición interna de vacancia/topología → nacimiento endógeno → recuperación estructural/funcional fija → cese. No hay memoria aprendida, selección de política ni reservoir consumible identificado.
