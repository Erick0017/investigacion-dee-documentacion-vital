# Reauditoría de autonomía

Vector final: `{"A0":"PASS","A1":"PASS","A2":"PASS","A3":"PASS","A4":"PASS","A5":"PASS","A6":"INCONCLUSIVE","A7":"PASS"}`.

A0–A3 sobreviven de CORE05–07. C8H02 eleva el aparato fijo a A4 por repetición, A5 por mantenimiento de un sitio frente a borrado y A7 en el dominio de scaffold inmutable presente desde t0. El host fija el calendario de perturbaciones, pero no elige la respuesta: `F_DEE` detecta la vacancia y ejecuta la reposición.

A6 es inconclusa. DEE aprende en otros aparatos, pero CORE08 no integró una política aprendida que mejore autónomamente reparación/control. A7 aquí no implica A6, agencia, vida ni aislamiento; es un ciclo fijo sostenido por una condición interna no agotable del kernel.
