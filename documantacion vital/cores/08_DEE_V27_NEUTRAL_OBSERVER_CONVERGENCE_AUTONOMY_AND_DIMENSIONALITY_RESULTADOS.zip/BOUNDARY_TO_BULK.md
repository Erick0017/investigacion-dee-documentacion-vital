# Frontera a bulk

Instantaneous boundary no determina el interior: con frontera vacía existen al menos `2^((N-2)^3)` soportes binarios interiores. Para histories finitos, el cono causal raw `r_inf≤3T` deja invisible cualquier región más profunda que `3T`.

Boundary history sí determina un bulk funcional restringido cuando hay un carrier por rayo, sin colisiones, dirección normal conocida y payload observable. Cada evento entrega lugar superficial y tiempo de llegada; éstos invierten la coordenada normal. La frontera no contiene una copia trivial del tensor 3D, pero el dominio preparado tampoco contiene `O(N^3)` grados independientes.
