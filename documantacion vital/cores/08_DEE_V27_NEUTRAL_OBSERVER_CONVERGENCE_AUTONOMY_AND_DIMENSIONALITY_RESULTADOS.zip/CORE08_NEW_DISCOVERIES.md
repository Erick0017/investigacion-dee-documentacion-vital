# Descubrimientos nuevos CORE08

1. La fibra de destino no cierra sola: la guardia XNOR tiene prioridad y explica todos los fallos k=8 del observador inicial.
2. `Z_update` y `Z_account` son cocientes exactos, pequeños y task-relative.
3. La rama de cristalización es inalcanzable bajo el cap v27: el bound correcto da cociente máximo 53 frente al umbral 966.
4. Un scaffold cúbico persistente produce regeneración exacta y repetida por una guardia de vacancia.
5. Una función aprendida puede recuperarse por redundancia entrenada, pero no se demostró reparación aprendida internamente disparada.
6. Tres proyecciones integradas siguen siendo causalmente no inyectivas.
7. Boundary history construye un estado lower-dimensional suficiente para rayos, con ley finita exacta `ceil((N-4)/3)^2`.
8. El operador de destino guardado unifica aprendizaje, colisión, transporte, detección y regeneración sin crear Q4 global.
