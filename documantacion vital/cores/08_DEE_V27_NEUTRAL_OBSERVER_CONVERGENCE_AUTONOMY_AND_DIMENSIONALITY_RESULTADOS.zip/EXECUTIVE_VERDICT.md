# CORE08 — veredicto ejecutivo

CORE08 encontró un observador reducido exacto sólo de forma **relativa a la tarea**, no un cociente global de toda `F_DEE`. Para un destino vacío con propuestas normales, `M_ZUPDATE=(guardia_XNOR, suma_s, signo(suma_d))` predijo el raw siguiente en 384/384 mundos. La versión heredada sin guardia falló exactamente en los 96 casos XNOR. Añadir `k` produce `M_ZACCOUNT`, que conserva la contracción local muchos-a-uno.

El resultado unificador es el **operador de destino guardado**. En un destino vacío, la rama de cristalización es inalcanzable bajo el cap v27; luego la topología XNOR tiene prioridad; después opera el reductor de fibras; en destinos ocupados entran topología, semantic y clock. Este operador explica transporte, colisiones/aprendizaje, pérdida muchos-a-uno, detección y la regeneración nueva. No es Q4 global.

La regeneración fija quedó confirmada: 320/320 daños se repararon exactamente en un tick con scaffold byte-invariante; 400 ciclos de controles estructurales dieron tasa 0. Un scaffold `semantic=4` de ocho esquinas detecta operacionalmente la vacancia mediante la guardia XNOR, repone el centro y cesa al ocuparse. Esto certifica R2, R5-fija, R6 y R7 **sólo en ese sector**. No certifica biología ni reparación aprendida.

La reparación de función aprendida es distinta. C8H03 se degradó a `FAIL_PROTOCOL_LEAKAGE` porque 2/24 consultas coincidían con valores de entrenamiento. El nuevo C8H06, congelado después, obtuvo 18/18 respuestas exactas en consultas disjuntas y 0/36 controles. Es R5 por redundancia entrenada finita; no R6/R7 aprendida.

Autonomía: `{"A0":"PASS","A1":"PASS","A2":"PASS","A3":"PASS","A4":"PASS","A5":"PASS","A6":"INCONCLUSIVE","A7":"PASS"}`. A4/A5/A7 se refieren al homeostato fijo; A6 queda inconclusa porque no apareció una política adaptativa integrada.

EXTRA03 falsó la suficiencia general de una vista y de tres proyecciones integradas mediante pares alias con futuros distintos. Un history de frontera sí cerró una familia restringida de rayos: C8H05 confirmó reconstrucción y predicción 1.0 en 1292 carriers y `K(N)=ceil((N-4)/3)^2`; el código explícito cuesta `Theta(N^2 log N)` bits. No apareció señal holográfica fuerte para bulk arbitrario.

La mejor convergencia neutral es delay/lugar DEE frente a medición time-of-flight, pero permanece `NEUTRAL_STRUCTURAL_MATCH / EXTERNAL_COMPATIBILITY`: no hubo predicción externa reservada. `ROSETTA_VALIDATED=false`.
