# Dato externo requerido

Para avanzar el candidato principal se necesita telemetría row-level independiente con unidad experimental identificable, geometría del emisor/detector, dirección, delay bruto, rango ground-truth, condiciones de medio y split reservable. La diana debe incluir una predicción adicional —por ejemplo una relación angular o de respuesta— no usada para calibrar la escala.
