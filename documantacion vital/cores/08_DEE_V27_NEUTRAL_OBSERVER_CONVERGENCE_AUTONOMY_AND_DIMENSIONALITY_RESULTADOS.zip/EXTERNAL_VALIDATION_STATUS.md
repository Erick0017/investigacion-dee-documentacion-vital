# Estado de validación externa

No se abrió un holdout externo row-level capaz de decidir una predicción DEE no usada en el match. El candidato delay/lugar fue comparado con descripciones operacionales independientes de NASA/NIST, pero la proporcionalidad delay–distancia es parte del protocolo externo y la escala sería calibración.

Fuentes operacionales consultadas:

- NASA GLAS: https://science.gsfc.nasa.gov/attic/glas/human.html
- NIST laser ranging: https://www.nist.gov/news-events/news/2014/10/nist-laser-comb-system-maps-3d-surfaces-remotely-manufacturing-forensics

Falta exactamente un dataset externo con preparación, dirección, delay y rango por fila, más una predicción DEE adicional congelable que no sea la definición de time-of-flight. Hasta entonces `ROSETTA_VALIDATED=false`.
