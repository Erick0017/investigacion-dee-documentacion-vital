# EXTRA03 — proyección dimensional

Una vista XY idéntica ocultó dos profundidades con arribos distintos. Más fuerte: dos patrones paridad-even/odd en un cubo 2×2×2 tuvieron exactamente iguales proyecciones XY/XZ/YZ de occupancy, `s_reg` y direction integrada, pero una query común produjo futuros focales distintos. Por tanto ni una vista ni esas tres vistas forman un observador causal suficiente general.

En una familia restringida de carriers normales separados, el history de frontera recupera lateral, profundidad y payload mediante delay. C8H04 quedó FAIL porque el exponente ingenuo preregistrado fue 2.495. C8H05, hipótesis posterior en N nuevos, confirmó la ley discreta exacta y todas las predicciones.
