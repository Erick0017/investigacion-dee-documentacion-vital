# Reparación funcional y memoria

C8H06 entrenó por colisión ordinaria dos lineages independientes con el mismo `delta`. Tras borrar la lineage líder, la copia retrasada reocupó el trayecto y respondió `q→q+delta` a 18 consultas explícitamente disjuntas. Las tasas fueron response=1.0, payload-restored=1.0 y controles=0.0.

La identidad recuperada es un cociente de repertorio de respuesta, no el mismo carrier. El mecanismo es redundancia finita preparada por experiencia. C8H03 permanece supersedido por dos consultas contaminadas; C8H06 usa nueva evidencia y no repara ese holdout.
