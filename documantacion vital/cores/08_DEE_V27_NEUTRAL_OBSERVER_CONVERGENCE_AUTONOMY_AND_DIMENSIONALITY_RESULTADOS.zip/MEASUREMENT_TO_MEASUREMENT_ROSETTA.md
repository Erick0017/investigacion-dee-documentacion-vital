# Rosetta medición-a-medición

Cadena DEE: carrier preparado → transporte causal → frontera/detector → lugar y delay → coordenada normal reconstruida.

Cadena externa neutral: señal preparada → propagación → detector → tiempo de vuelo y geometría → rango.

Coincidencias: orden causal, delay lineal con distancia, necesidad de conocer orientación/lugar del detector y una libertad de escala de velocidad. Diferencias: DEE fue ensayado en seis normales de una retícula cúbica, usa una frontera toroidal y no posee evidencia de isotropía/Lorentz; los protocolos externos reales incluyen retorno, ruido, reflectividad y calibración.

Veredicto: `NEUTRAL_STRUCTURAL_MATCH / EXTERNAL_COMPATIBILITY`. No `CAUSAL_MATCH` promovido, no `EXTERNAL_PREDICTION` y no `ROSETTA_VALIDATED`.
