# Observador mínimo suficiente

## Resultado confirmado

`Z_update = (g_XNOR, Σs_reg, sign(Σd_x), sign(Σd_y), sign(Σd_z))`.

En el dominio congelado, la regla es:

1. si `g_XNOR=1`, escribir `(state=1,s_reg=1,d=0,semantic=7)`;
2. si no, escribir `(state=1,s_reg=min(Σs_reg,19664),d=sign(Σd),semantic=1)`.

C8H01: exactitud 1.000; null sin guardia 0.750. Cada coordenada tuvo contrafactual propio. La minimalidad sólo vale dentro de esa familia de agregados interpretables.

`Z_account=(Z_update,k)` conserva además la multiplicidad entrante y la contracción local `k→1`. No predice evolución no relacionada del resto del mundo.

Para el problema de profundidad, el cociente mínimo cambia: `(surface_place, arrival_delay, s_reg, normal_orientation)` reconstruye el estado funcional del carrier en la familia de rayos. La conclusión transversal es que suficiencia es una relación **observador–tarea–dominio**, no una lista universal de campos.
