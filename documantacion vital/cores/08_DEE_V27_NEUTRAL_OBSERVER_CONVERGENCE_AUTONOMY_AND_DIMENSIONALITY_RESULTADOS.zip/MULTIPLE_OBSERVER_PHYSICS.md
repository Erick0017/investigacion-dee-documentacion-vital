# Física de múltiples observadores

En el mismo carrier que avanza por z:

- full/path observa transporte balístico a un voxel por tick;
- la proyección XY observa un footprint estacionario;
- support global observa un escalar constante;
- la frontera z observa un pulso retardado cuya latencia codifica profundidad.

Las leyes aparentes cambian porque cada M descarta información distinta. Esto demuestra observer-dependence interna, no relatividad física. Los contraejemplos de clock y destino prueban además que omitir una variable causal puede transformar una aparente ley cerrada en alias.
