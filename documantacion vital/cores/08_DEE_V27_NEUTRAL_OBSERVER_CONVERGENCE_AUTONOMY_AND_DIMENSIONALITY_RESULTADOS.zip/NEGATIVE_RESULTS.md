# Resultados negativos preservados

- El observador de fibra sin guardia falló en 96/384 casos XNOR del holdout.
- No se encontró cociente global reducido de `F_DEE`.
- Raw sin clock, inventario sin relaciones y proposal graph sin destination guard son insuficientes.
- Una vista y tres vistas integradas no son observadores causales suficientes generales.
- C8H03: `FAIL_PROTOCOL_LEAKAGE`; su runner PASS no es la adjudicación actual.
- C8H04: FAIL por exponente preregistrado fuera de rango; no fue reparado.
- No hubo R6/R7 de memoria aprendida ni A6 adaptive autonomy integrada.
- No hubo código holográfico fuerte para bulk arbitrario.
- No hubo equilibrio, variable conjugada o temperatura DEE.
- No hubo predicción externa reservada ni Rosetta validada.
