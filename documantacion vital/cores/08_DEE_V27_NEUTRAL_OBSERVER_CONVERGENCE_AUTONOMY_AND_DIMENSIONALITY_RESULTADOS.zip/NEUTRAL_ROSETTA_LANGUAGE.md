# Lenguaje Rosetta neutral

CORE08 usa un fingerprint sin nombres humanos: preparación, intervención, detector, lectura, grafo causal, simetría, kernel de respuesta, scaling, ratios adimensionales, recurrencia, relajación, path-dependence, monotones, fluctuaciones, dependencia del observador y falsadores.

El matching primario opera con IDs ocultos. Un nombre semántico aporta cero puntuación. La promoción requiere mapa congelado, pocos parámetros y predicción no utilizada. Este procedimiento evita convertir `s_reg` en energía, `clock` en tiempo físico o un carrier en partícula por vocabulario.

Los cuatro fingerprints nativos principales están en `NEUTRAL_PHENOMENON_ATLAS.json`. El candidato más cercano describe propagación, delay, lugar de detección y reconstrucción de distancia. El match externo conserva la estructura de time-of-flight, pero no la simetría completa ni una predicción externa nueva; por ello no supera compatibilidad.
