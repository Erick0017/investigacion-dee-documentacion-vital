# Invariantes bajo observador

En los observadores compatibles ensayados sobreviven: orden causal de llegadas, finitud de propagación, payload `s_reg` en transporte collision-free y relaciones de delay relativo. No sobreviven universalmente: posición 3D, identidad microscópica, dirección oculta por proyección, clock/phase ni multiplicidad si se usa sólo inventario.

Los invariantes mejores para Rosetta son relaciones de orden, ratios de delay y estructura de respuesta, no valores absolutos ni nombres de campos.
