# Teoría operacional del observador

Sea `F:S→S` y `M:S→Z`. El cociente es cerrado en un dominio sólo si `M(X)=M(Y)` implica `M(F(X))=M(F(Y))`. CORE08 trató esta condición como prueba, no como metáfora.

Los contraejemplos son decisivos. Un raw global sin clock no cierra: dos grids raw idénticos con clock focal 0/1 produjeron `s_reg` 11/10 en un tick. Un inventario raw sin relaciones no cierra: los mismos dos raws, organizados como colisión o destinos separados, cambiaron support 2→1 o 2→2. Un grafo de propuestas sin guarda de destino tampoco cierra. Una vista XY oculta profundidad y tres vistas integradas conservan aliases de paridad 3D con respuestas causales distintas.

El observador reducido positivo es condicional. En el sector de destino vacío con fuentes normales, `M_ZUPDATE` conserva la guardia XNOR y los agregados que realmente usa el branch. Su cierre exacto no se exporta a destinos ocupados. Para accounting se añade multiplicidad `k`. Para transporte por rayos, una observación completamente distinta —lugar y delay en frontera— es suficiente.

No existe por tanto un “observador mínimo universal” demostrado. Existe una familia de cocientes mínimos para tareas declaradas, conectados por una arquitectura común de guardas, relaciones de destino y history.
