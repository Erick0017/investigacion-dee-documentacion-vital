# Reauditoría de reparación

La genealogía no admite un sí/no único. V12.2–V15.5 mostraron refill parcial guiado por frontera/geometría en v24; la etiqueta observer no fue privilegiada y obtuvo 0/18 victorias de fidelidad en V15/V15.5. V20 HOLISTICREPAIR fue negativo para reconstrucción persistente de su aparato. Vol.5 D7 recuperó descriptores de basin, no el hash. CORE07 falló con scaffolds genéricos retardados.

CORE08 añade dos mecanismos v27 distintos. C8H02 es una guardia XNOR con scaffold persistente: exacta, repetible y no aprendida. C8H06 es redundancia entrenada: recupera función en unseen queries, pero no detecta daño ni regenera repetidamente la memoria. `RECOVERY_TAXONOMY.json` conserva estas distinciones R0–R7.
