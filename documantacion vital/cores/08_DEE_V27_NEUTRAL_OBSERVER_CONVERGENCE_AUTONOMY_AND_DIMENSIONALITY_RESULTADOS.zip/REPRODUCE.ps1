$ErrorActionPreference = 'Stop'
$Work = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = 'D:\Descargas\ANACONDA MINICONDA\python.exe'

if (-not (Test-Path -LiteralPath $Python)) {
    throw "CPython 3.13 runtime not found at the recorded path: $Python"
}

Push-Location -LiteralPath $Work
try {
    & $Python -I -B '.\run_core08_neutral_observer.py'
    if ($LASTEXITCODE -ne 0) { throw "CORE08 reproduction failed with exit code $LASTEXITCODE" }
}
finally {
    Pop-Location
}
