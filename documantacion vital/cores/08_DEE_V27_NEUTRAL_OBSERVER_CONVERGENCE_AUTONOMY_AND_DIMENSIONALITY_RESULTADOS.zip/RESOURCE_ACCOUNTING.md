# Accounting de recursos

En el homeostato XNOR, los ocho raws `semantic=4` y su suma `s_reg` permanecen invariantes; cada centro borrado reaparece por `genesis_count`. No se observó depletion, recovery de reservoir ni variable conjugada. El kernel implementa esos voxels como condición persistente.

En la reparación aprendida, la capacidad se paga mediante redundancia: una segunda memoria fue entrenada y consumida como lineage funcional. No es un ciclo reusable de memoria aprendida.

La ley source-free de CORE07 (contracción de support y conservación acotada de `s_reg` en el reductor) sigue válida; C8H02 está fuera de ese sector porque activa nacimiento XNOR. Ninguno de estos contadores se identifica con energía física.
