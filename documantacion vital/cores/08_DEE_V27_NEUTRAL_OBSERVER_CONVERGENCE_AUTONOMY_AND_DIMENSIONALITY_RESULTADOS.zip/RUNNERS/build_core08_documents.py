#!/usr/bin/env python3
"""Build concise evidence-grounded CORE08 final documentation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, append_log, sha256_file, update_state, utc_now


def load(relative):
    return json.loads((ROOT / relative).read_text(encoding="utf-8"))


def write(name, text):
    atomic_text(ROOT / name, text.strip() + "\n")


def main() -> int:
    h01 = load("RESULTS/C8H01_minimal_guarded_destination_observer.json")
    h02 = load("RESULTS/C8H02_repeated_fixed_scaffold_regeneration.json")
    h04 = load("RESULTS/C8H04_boundary_time_code.json")
    h05 = load("RESULTS/C8H05_finite_size_boundary_code_law.json")
    h06 = load("RESULTS/C8H06_leakage_free_trained_function_recovery.json")
    d05 = load("RESULTS/C8D05_dimensional_observer_discovery.json")
    d06 = load("RESULTS/C8D06_observer_entropy.json")
    audit = load("RESULTS/C8A05_adversarial_review.json")
    recovery = load("RECOVERY_TAXONOMY.json")
    autonomy = load("AUTONOMY_TAXONOMY.json")
    convergence = load("CONVERGENCE_CANDIDATES.json")

    write("EXECUTIVE_VERDICT.md", f"""
# CORE08 — veredicto ejecutivo

CORE08 encontró un observador reducido exacto sólo de forma **relativa a la tarea**, no un cociente global de toda `F_DEE`. Para un destino vacío con propuestas normales, `M_ZUPDATE=(guardia_XNOR, suma_s, signo(suma_d))` predijo el raw siguiente en {h01['sample_sizes']['holdout_worlds']}/{h01['sample_sizes']['holdout_worlds']} mundos. La versión heredada sin guardia falló exactamente en los {h01['unguarded_error_count']} casos XNOR. Añadir `k` produce `M_ZACCOUNT`, que conserva la contracción local muchos-a-uno.

El resultado unificador es el **operador de destino guardado**. En un destino vacío, la rama de cristalización es inalcanzable bajo el cap v27; luego la topología XNOR tiene prioridad; después opera el reductor de fibras; en destinos ocupados entran topología, semantic y clock. Este operador explica transporte, colisiones/aprendizaje, pérdida muchos-a-uno, detección y la regeneración nueva. No es Q4 global.

La regeneración fija quedó confirmada: {h02['sample_sizes']['primary_damage_cycles']}/{h02['sample_sizes']['primary_damage_cycles']} daños se repararon exactamente en un tick con scaffold byte-invariante; {h02['sample_sizes']['control_damage_cycles']} ciclos de controles estructurales dieron tasa 0. Un scaffold `semantic=4` de ocho esquinas detecta operacionalmente la vacancia mediante la guardia XNOR, repone el centro y cesa al ocuparse. Esto certifica R2, R5-fija, R6 y R7 **sólo en ese sector**. No certifica biología ni reparación aprendida.

La reparación de función aprendida es distinta. C8H03 se degradó a `FAIL_PROTOCOL_LEAKAGE` porque 2/24 consultas coincidían con valores de entrenamiento. El nuevo C8H06, congelado después, obtuvo {h06['sample_sizes']['disjoint_queries']}/{h06['sample_sizes']['disjoint_queries']} respuestas exactas en consultas disjuntas y 0/{h06['sample_sizes']['negative_worlds']} controles. Es R5 por redundancia entrenada finita; no R6/R7 aprendida.

Autonomía: `{json.dumps(autonomy['vector'], separators=(',', ':'))}`. A4/A5/A7 se refieren al homeostato fijo; A6 queda inconclusa porque no apareció una política adaptativa integrada.

EXTRA03 falsó la suficiencia general de una vista y de tres proyecciones integradas mediante pares alias con futuros distintos. Un history de frontera sí cerró una familia restringida de rayos: C8H05 confirmó reconstrucción y predicción 1.0 en {h05['sample_sizes']['carriers']} carriers y `K(N)=ceil((N-4)/3)^2`; el código explícito cuesta `Theta(N^2 log N)` bits. No apareció señal holográfica fuerte para bulk arbitrario.

La mejor convergencia neutral es delay/lugar DEE frente a medición time-of-flight, pero permanece `NEUTRAL_STRUCTURAL_MATCH / EXTERNAL_COMPATIBILITY`: no hubo predicción externa reservada. `ROSETTA_VALIDATED=false`.
""")

    write("OBSERVER_THEORY.md", """
# Teoría operacional del observador

Sea `F:S→S` y `M:S→Z`. El cociente es cerrado en un dominio sólo si `M(X)=M(Y)` implica `M(F(X))=M(F(Y))`. CORE08 trató esta condición como prueba, no como metáfora.

Los contraejemplos son decisivos. Un raw global sin clock no cierra: dos grids raw idénticos con clock focal 0/1 produjeron `s_reg` 11/10 en un tick. Un inventario raw sin relaciones no cierra: los mismos dos raws, organizados como colisión o destinos separados, cambiaron support 2→1 o 2→2. Un grafo de propuestas sin guarda de destino tampoco cierra. Una vista XY oculta profundidad y tres vistas integradas conservan aliases de paridad 3D con respuestas causales distintas.

El observador reducido positivo es condicional. En el sector de destino vacío con fuentes normales, `M_ZUPDATE` conserva la guardia XNOR y los agregados que realmente usa el branch. Su cierre exacto no se exporta a destinos ocupados. Para accounting se añade multiplicidad `k`. Para transporte por rayos, una observación completamente distinta —lugar y delay en frontera— es suficiente.

No existe por tanto un “observador mínimo universal” demostrado. Existe una familia de cocientes mínimos para tareas declaradas, conectados por una arquitectura común de guardas, relaciones de destino y history.
""")

    write("MINIMAL_SUFFICIENT_OBSERVER.md", f"""
# Observador mínimo suficiente

## Resultado confirmado

`Z_update = (g_XNOR, Σs_reg, sign(Σd_x), sign(Σd_y), sign(Σd_z))`.

En el dominio congelado, la regla es:

1. si `g_XNOR=1`, escribir `(state=1,s_reg=1,d=0,semantic=7)`;
2. si no, escribir `(state=1,s_reg=min(Σs_reg,19664),d=sign(Σd),semantic=1)`.

C8H01: exactitud {h01['rates']['Z_update_exact_rate']:.3f}; null sin guardia {h01['rates']['unguarded_exact_rate']:.3f}. Cada coordenada tuvo contrafactual propio. La minimalidad sólo vale dentro de esa familia de agregados interpretables.

`Z_account=(Z_update,k)` conserva además la multiplicidad entrante y la contracción local `k→1`. No predice evolución no relacionada del resto del mundo.

Para el problema de profundidad, el cociente mínimo cambia: `(surface_place, arrival_delay, s_reg, normal_orientation)` reconstruye el estado funcional del carrier en la familia de rayos. La conclusión transversal es que suficiencia es una relación **observador–tarea–dominio**, no una lista universal de campos.
""")

    write("NEUTRAL_ROSETTA_LANGUAGE.md", """
# Lenguaje Rosetta neutral

CORE08 usa un fingerprint sin nombres humanos: preparación, intervención, detector, lectura, grafo causal, simetría, kernel de respuesta, scaling, ratios adimensionales, recurrencia, relajación, path-dependence, monotones, fluctuaciones, dependencia del observador y falsadores.

El matching primario opera con IDs ocultos. Un nombre semántico aporta cero puntuación. La promoción requiere mapa congelado, pocos parámetros y predicción no utilizada. Este procedimiento evita convertir `s_reg` en energía, `clock` en tiempo físico o un carrier en partícula por vocabulario.

Los cuatro fingerprints nativos principales están en `NEUTRAL_PHENOMENON_ATLAS.json`. El candidato más cercano describe propagación, delay, lugar de detección y reconstrucción de distancia. El match externo conserva la estructura de time-of-flight, pero no la simetría completa ni una predicción externa nueva; por ello no supera compatibilidad.
""")

    write("MEASUREMENT_TO_MEASUREMENT_ROSETTA.md", """
# Rosetta medición-a-medición

Cadena DEE: carrier preparado → transporte causal → frontera/detector → lugar y delay → coordenada normal reconstruida.

Cadena externa neutral: señal preparada → propagación → detector → tiempo de vuelo y geometría → rango.

Coincidencias: orden causal, delay lineal con distancia, necesidad de conocer orientación/lugar del detector y una libertad de escala de velocidad. Diferencias: DEE fue ensayado en seis normales de una retícula cúbica, usa una frontera toroidal y no posee evidencia de isotropía/Lorentz; los protocolos externos reales incluyen retorno, ruido, reflectividad y calibración.

Veredicto: `NEUTRAL_STRUCTURAL_MATCH / EXTERNAL_COMPATIBILITY`. No `CAUSAL_MATCH` promovido, no `EXTERNAL_PREDICTION` y no `ROSETTA_VALIDATED`.
""")

    write("EXTERNAL_VALIDATION_STATUS.md", """
# Estado de validación externa

No se abrió un holdout externo row-level capaz de decidir una predicción DEE no usada en el match. El candidato delay/lugar fue comparado con descripciones operacionales independientes de NASA/NIST, pero la proporcionalidad delay–distancia es parte del protocolo externo y la escala sería calibración.

Fuentes operacionales consultadas:

- NASA GLAS: https://science.gsfc.nasa.gov/attic/glas/human.html
- NIST laser ranging: https://www.nist.gov/news-events/news/2014/10/nist-laser-comb-system-maps-3d-surfaces-remotely-manufacturing-forensics

Falta exactamente un dataset externo con preparación, dirección, delay y rango por fila, más una predicción DEE adicional congelable que no sea la definición de time-of-flight. Hasta entonces `ROSETTA_VALIDATED=false`.
""")
    write("EXTERNAL_DATA_REQUIRED.md", """
# Dato externo requerido

Para avanzar el candidato principal se necesita telemetría row-level independiente con unidad experimental identificable, geometría del emisor/detector, dirección, delay bruto, rango ground-truth, condiciones de medio y split reservable. La diana debe incluir una predicción adicional —por ejemplo una relación angular o de respuesta— no usada para calibrar la escala.
""")

    write("REPAIR_REAUDIT.md", """
# Reauditoría de reparación

La genealogía no admite un sí/no único. V12.2–V15.5 mostraron refill parcial guiado por frontera/geometría en v24; la etiqueta observer no fue privilegiada y obtuvo 0/18 victorias de fidelidad en V15/V15.5. V20 HOLISTICREPAIR fue negativo para reconstrucción persistente de su aparato. Vol.5 D7 recuperó descriptores de basin, no el hash. CORE07 falló con scaffolds genéricos retardados.

CORE08 añade dos mecanismos v27 distintos. C8H02 es una guardia XNOR con scaffold persistente: exacta, repetible y no aprendida. C8H06 es redundancia entrenada: recupera función en unseen queries, pero no detecta daño ni regenera repetidamente la memoria. `RECOVERY_TAXONOMY.json` conserva estas distinciones R0–R7.
""")

    write("AUTONOMY_REAUDIT.md", f"""
# Reauditoría de autonomía

Vector final: `{json.dumps(autonomy['vector'], separators=(',', ':'))}`.

A0–A3 sobreviven de CORE05–07. C8H02 eleva el aparato fijo a A4 por repetición, A5 por mantenimiento de un sitio frente a borrado y A7 en el dominio de scaffold inmutable presente desde t0. El host fija el calendario de perturbaciones, pero no elige la respuesta: `F_DEE` detecta la vacancia y ejecuta la reposición.

A6 es inconclusa. DEE aprende en otros aparatos, pero CORE08 no integró una política aprendida que mejore autónomamente reparación/control. A7 aquí no implica A6, agencia, vida ni aislamiento; es un ciclo fijo sostenido por una condición interna no agotable del kernel.
""")

    write("AUTONOMOUS_REGENERATION.md", f"""
# Regeneración autónoma integrada

El aparato positivo contiene desde t0 ocho voxels `semantic=4` en las esquinas Moore y un centro `semantic=7`. Al borrar el centro, la rama de vacío observa 13 pares opuestos concordantes y ocho activos, crea exactamente el centro en un tick y luego cesa porque el destino deja de estar vacío.

Resultado congelado: {h02['sample_sizes']['primary_worlds']} mundos, {h02['sample_sizes']['primary_damage_cycles']} ciclos, recovery=1.0, estabilidad=1.0 y scaffold byte-invariante=1.0. Missing-corner, shuffle de inventario, scaffold no persistente, desconexión y relajación libre dieron recovery=0.

Cadena demostrada: daño → condición interna de vacancia/topología → nacimiento endógeno → recuperación estructural/funcional fija → cese. No hay memoria aprendida, selección de política ni reservoir consumible identificado.
""")

    write("FUNCTIONAL_REPAIR_AND_MEMORY.md", f"""
# Reparación funcional y memoria

C8H06 entrenó por colisión ordinaria dos lineages independientes con el mismo `delta`. Tras borrar la lineage líder, la copia retrasada reocupó el trayecto y respondió `q→q+delta` a {h06['sample_sizes']['disjoint_queries']} consultas explícitamente disjuntas. Las tasas fueron response={h06['rates']['positive_exact_rate']:.1f}, payload-restored={h06['rates']['memory_restore_rate']:.1f} y controles={h06['rates']['negative_exact_rate']:.1f}.

La identidad recuperada es un cociente de repertorio de respuesta, no el mismo carrier. El mecanismo es redundancia finita preparada por experiencia. C8H03 permanece supersedido por dos consultas contaminadas; C8H06 usa nueva evidencia y no repara ese holdout.
""")

    write("RESOURCE_ACCOUNTING.md", """
# Accounting de recursos

En el homeostato XNOR, los ocho raws `semantic=4` y su suma `s_reg` permanecen invariantes; cada centro borrado reaparece por `genesis_count`. No se observó depletion, recovery de reservoir ni variable conjugada. El kernel implementa esos voxels como condición persistente.

En la reparación aprendida, la capacidad se paga mediante redundancia: una segunda memoria fue entrenada y consumida como lineage funcional. No es un ciclo reusable de memoria aprendida.

La ley source-free de CORE07 (contracción de support y conservación acotada de `s_reg` en el reductor) sigue válida; C8H02 está fuera de ese sector porque activa nacimiento XNOR. Ninguno de estos contadores se identifica con energía física.
""")

    write("EXTRA03_DIMENSIONAL_PROJECTION.md", f"""
# EXTRA03 — proyección dimensional

Una vista XY idéntica ocultó dos profundidades con arribos distintos. Más fuerte: dos patrones paridad-even/odd en un cubo 2×2×2 tuvieron exactamente iguales proyecciones XY/XZ/YZ de occupancy, `s_reg` y direction integrada, pero una query común produjo futuros focales distintos. Por tanto ni una vista ni esas tres vistas forman un observador causal suficiente general.

En una familia restringida de carriers normales separados, el history de frontera recupera lateral, profundidad y payload mediante delay. C8H04 quedó FAIL porque el exponente ingenuo preregistrado fue {h04['ray_count_scaling_exponent']:.3f}. C8H05, hipótesis posterior en N nuevos, confirmó la ley discreta exacta y todas las predicciones.
""")

    write("BOUNDARY_TO_BULK.md", """
# Frontera a bulk

Instantaneous boundary no determina el interior: con frontera vacía existen al menos `2^((N-2)^3)` soportes binarios interiores. Para histories finitos, el cono causal raw `r_inf≤3T` deja invisible cualquier región más profunda que `3T`.

Boundary history sí determina un bulk funcional restringido cuando hay un carrier por rayo, sin colisiones, dirección normal conocida y payload observable. Cada evento entrega lugar superficial y tiempo de llegada; éstos invierten la coordenada normal. La frontera no contiene una copia trivial del tensor 3D, pero el dominio preparado tampoco contiene `O(N^3)` grados independientes.
""")

    write("AREA_VS_VOLUME_SCALING.md", f"""
# Scaling área frente a volumen

La ley confirmada en N={h05['sample_sizes']['new_N']} es `K(N)=ceil((N-4)/3)^2`. Los {h05['sample_sizes']['carriers']} carriers se reconstruyeron exactamente. Por tanto el número de rayos es `Theta(N^2)`.

El record explícito guarda dos coordenadas superficiales, delay y payload. Su coste es `Theta(N^2 log N)` bits, no `Theta(N^2)` bits estrictos. Muestrear toda la frontera durante `Theta(N)` ticks costaría `Theta(N^3)` muestras. La prueba no ofrece compresión de un bulk binario arbitrario, cuya información escala volumétricamente.
""")

    write("HOLOGRAPHIC_LIKE_STATUS.md", """
# Estado holographic-like

`NO_HOLOGRAPHIC_LIKE_SIGNAL` para estados bulk generales.

Sí existe `LOWER_DIMENSIONAL_EFFECTIVE_STATE` y `BOUNDARY_HISTORY_SUFFICIENT` en una familia área-indexada de transporte. No satisface el criterio fuerte: no reconstruye fenómenos volumétricos con `O(N^3)` grados, no establece un código de bits puramente areal y una pareja de tres-vistas iguales ya falsifica suficiencia general.

Nada de CORE08 permite afirmar `REALITY_IS_2D` ni que el substrato DEE deje de ser la retícula 3D implementada.
""")

    write("MULTIPLE_OBSERVER_PHYSICS.md", """
# Física de múltiples observadores

En el mismo carrier que avanza por z:

- full/path observa transporte balístico a un voxel por tick;
- la proyección XY observa un footprint estacionario;
- support global observa un escalar constante;
- la frontera z observa un pulso retardado cuya latencia codifica profundidad.

Las leyes aparentes cambian porque cada M descarta información distinta. Esto demuestra observer-dependence interna, no relatividad física. Los contraejemplos de clock y destino prueban además que omitir una variable causal puede transformar una aparente ley cerrada en alias.
""")

    write("OBSERVER_INVARIANTS.md", """
# Invariantes bajo observador

En los observadores compatibles ensayados sobreviven: orden causal de llegadas, finitud de propagación, payload `s_reg` en transporte collision-free y relaciones de delay relativo. No sobreviven universalmente: posición 3D, identidad microscópica, dirección oculta por proyección, clock/phase ni multiplicidad si se usa sólo inventario.

Los invariantes mejores para Rosetta son relaciones de orden, ratios de delay y estructura de respuesta, no valores absolutos ni nombres de campos.
""")

    write("CORE08_NEW_DISCOVERIES.md", """
# Descubrimientos nuevos CORE08

1. La fibra de destino no cierra sola: la guardia XNOR tiene prioridad y explica todos los fallos k=8 del observador inicial.
2. `Z_update` y `Z_account` son cocientes exactos, pequeños y task-relative.
3. La rama de cristalización es inalcanzable bajo el cap v27: el bound correcto da cociente máximo 53 frente al umbral 966.
4. Un scaffold cúbico persistente produce regeneración exacta y repetida por una guardia de vacancia.
5. Una función aprendida puede recuperarse por redundancia entrenada, pero no se demostró reparación aprendida internamente disparada.
6. Tres proyecciones integradas siguen siendo causalmente no inyectivas.
7. Boundary history construye un estado lower-dimensional suficiente para rayos, con ley finita exacta `ceil((N-4)/3)^2`.
8. El operador de destino guardado unifica aprendizaje, colisión, transporte, detección y regeneración sin crear Q4 global.
""")

    write("NEGATIVE_RESULTS.md", """
# Resultados negativos preservados

- El observador de fibra sin guardia falló en 96/384 casos XNOR del holdout.
- No se encontró cociente global reducido de `F_DEE`.
- Raw sin clock, inventario sin relaciones y proposal graph sin destination guard son insuficientes.
- Una vista y tres vistas integradas no son observadores causales suficientes generales.
- C8H03: `FAIL_PROTOCOL_LEAKAGE`; su runner PASS no es la adjudicación actual.
- C8H04: FAIL por exponente preregistrado fuera de rango; no fue reparado.
- No hubo R6/R7 de memoria aprendida ni A6 adaptive autonomy integrada.
- No hubo código holográfico fuerte para bulk arbitrario.
- No hubo equilibrio, variable conjugada o temperatura DEE.
- No hubo predicción externa reservada ni Rosetta validada.
""")

    write("FINAL_FRONTIER.md", """
# Frontera final

## EXTERNAL_DATA_REQUIRED

Telemetría row-level independiente para una predicción Rosetta no definicional.

## NEW_THEORY_REQUIRED

Un cociente global debe incorporar destino ocupado, guardas, clock/phase, semantic, source y history sin regresar a Q0. No apareció una representación cerrada de baja dimensión para todos los sectores.

## NEW_KERNEL_REQUIRED

Separar experimentalmente sensor y actuator de la rama XNOR, agotar un recurso de scaffold o estudiar una variante sin `semantic=4` inmutable requeriría cambiar el kernel; no se hizo.

## COMPUTATIONAL_SCALE_REQUIRED

Una búsqueda general de códigos boundary para ensembles volumétricos podría requerir escalas mayores, pero los bounds de no-inyectividad ya cierran proyecciones instantáneas simples.

## CLOSED_NEGATIVE

Suficiencia general de las proyecciones integradas probadas; Rosetta holográfica fuerte en el dominio CORE08; reparación aprendida R6/R7 en la arquitectura de redundancia probada.
""")

    write("TRANSVERSAL_CORE01_TO_08.md", """
# Transversal CORE01–08

- CORE01 fijó Q0=`raw+clock`, causalidad y leyes exactas básicas.
- CORE02 separó estado predictivo de evento y formalizó fibras/roles.
- CORE03 confirmó Q2 de organización colectiva en dominio.
- CORE04 encontró histories productivas Q3 y negó cierre global compacto.
- CORE05 demostró observer/detector interno, delay-to-place y memoria de history.
- CORE06 confirmó aprendizaje nativo, generalización acotada, materia operacional y cinemática interna; Bell local CHSH=-2.
- CORE07 convirtió el programa en atlas, transfirió función aprendida y aisló el reductor común; su loop siguió one-pass.
- CORE08 mostró que la Rosetta puede ser un observador: guardas y relaciones determinan qué ley ve M; confirmó regeneración fija repetida, R5 aprendida por redundancia y un estado boundary-time restringido.

La arquitectura transversal más comprimida es: `(raw,clock) → guardas+propuestas → fibras/destino → reductor o nacimiento → lineages/history → organización → observer → medida`. Sigue siendo sectorial y multidimensional, no una pirámide Q0–Q4 universal.
""")

    write("FINAL_REPORT.md", f"""
# CORE08 — informe final

## Método y estado

Se ejecutó el wheel v27 sellado con CPython 3.13. Los seis locks enlazan exactamente a sus resultados. C8H04 y C8H03 conservan respectivamente FAIL científico y fallo de protocolo; las hipótesis posteriores C8H05/C8H06 usaron N/seeds/dianas nuevas.

## Respuestas obligatorias

1. **Observador más pequeño útil.** No hay uno global. Para update de destino vacío, `Z_update=(g_XNOR,Σs,signΣd)` es suficiente y mínimo en la familia probada; para accounting se añade `k`.
2. **Información invisible.** Clock decide incrementos con raw idéntico; geometría de destinos decide colisiones con inventario idéntico; profundidad y paridad causal quedan ocultas por proyecciones.
3. **Lenguaje neutral.** Sí: fingerprints de preparación–intervención–detector–respuesta comprimen transporte, reparación, aprendizaje y medición. No es aún una teoría externa.
4. **Convergencia externa.** Delay/lugar coincide estructuralmente con time-of-flight; no sobrevivió aún una predicción externa reservada.
5. **Nivel R.** R0–R7 tienen algún PASS sectorial, pero R7 sólo para scaffold fijo; la memoria aprendida llega a R5.
6. **Nivel A.** `{json.dumps(autonomy['vector'], separators=(',', ':'))}`.
7. **Función aprendida reparada.** Sí, 18/18 queries disjuntas por redundancia entrenada; no desde el carrier destruido.
8. **Repetición.** El homeostato fijo pasó 320/320 ciclos; la reparación aprendida no es repetidamente regenerativa.
9. **Recursos.** El scaffold no se agota en los campos observables; la memoria aprendida consume redundancia finita. No se identificó energía.
10. **Representación lower-D.** Sí, boundary event history para rayos normales collision-free.
11. **Scaling.** Rayos `Theta(N^2)`; código con delay `Theta(N^2 logN)`; bulk arbitrario requiere información volumétrica.
12. **Holographic-like.** Restringida como representación efectiva; señal fuerte general negativa.
13. **Cambio con observer.** El mismo movimiento puede verse balístico, estacionario, constante o como pulso retardado.
14. **Invariantes.** Orden causal, finitud de propagación, payload collision-free y ratios de delay; no posición/clock/identidad completa.

## Nueva ley exacta y unificación

La cristalización no puede activarse: `grad_mag≤54·19664`, luego `floor(grad_mag/19665)≤53<966`. Eliminada esa rama, el orden de guardas del vacío es operacionalmente completo: XNOR antes de fiber reducer. Este detalle explica el fracaso inicial y la regeneración posterior con el mismo operador.

## Rosetta

El filtro/observer es efectivamente una parte de la traducción. Sin embargo, una compatibilidad de time-of-flight no identifica el carrier con luz ni la retícula con espacio físico. Faltan simetrías externas, preparación física y predicción no calibrante.

## Stopping rule

Las prioridades internas quedaron adjudicadas. Continuar con variantes de scaffold o más N no cambiaría los veredictos centrales. Las fronteras restantes exigen datos externos, una nueva teoría de cociente global o un kernel donde recursos/sensor/actuator sean separables.
""")

    source_index = {
        "schema": "dee.v27.core08.source_index.v1", "created_utc": utc_now(),
        "parent_core07": {"path": "PARENTS/07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip", "sha256": "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f"},
        "kernel": {"wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939", "pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff", "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4"},
        "historical_audit": {"path": "RESULTS/C8A02_historical_repair_reaudit.json", "source_is_inside_parent_core07": True},
        "external_sources": ["https://science.gsfc.nasa.gov/attic/glas/human.html", "https://www.nist.gov/news-events/news/2014/10/nist-laser-comb-system-maps-3d-surfaces-remotely-manufacturing-forensics"],
    }
    atomic_json(ROOT / "SOURCE_INDEX.json", source_index)
    write("ADVERSARIAL_REVIEW.md", "# Revisión adversarial\n\n" + "\n".join(f"- {row['id']} [{row['severity']}]: {row['finding']} Acción: {row['action']}" for row in audit["findings"]) + f"\n\nEstado: `{audit['status']}`.\n")

    state = load("STATE.json")
    complete = list(dict.fromkeys(state.get("complete_modules", []) + ["C8D06", "C8H06", "C8A05", "C8D07_FINAL_DOCS"]))
    update_state(
        status="COMPLETE", current_question=None, active_branches=[], last_completed_experiment="C8D07_FINAL_DOCUMENTS",
        complete_modules=complete, pending_holdout=None, next_action=None, stopping_rule="REACHED",
        stopping_reason="All internal high-information observer, recovery/autonomy and dimensional branches are adjudicated; remaining Rosetta validation needs external row-level data or new theory/kernel.",
        final_verdicts=["TASK_RELATIVE_SUFFICIENT_OBSERVER_FOUND", "UNIFIED_GUARDED_DESTINATION_OPERATOR_FOUND", "R7_FIXED_SCAFFOLD_REGENERATION", "R5_LEARNED_FUNCTION_RECOVERY", "A6_INCONCLUSIVE", "LOWER_DIMENSIONAL_EFFECTIVE_STATE_RESTRICTED", "NO_HOLOGRAPHIC_LIKE_SIGNAL_GENERAL", "NEUTRAL_STRUCTURAL_MATCH_EXTERNAL_COMPATIBILITY", "ROSETTA_VALIDATED_FALSE"],
        package_name="08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip",
    )
    checkpoint = {"schema": "dee.v27.core08.checkpoint.v1", "checkpoint": "FINAL_PREPACKAGE", "timestamp_utc": utc_now(), "state_sha256": sha256_file(ROOT / "STATE.json"), "adversarial_status": audit["status"], "holdouts": {"C8H01": "PASS", "C8H02": "PASS", "C8H03": "FAIL_PROTOCOL_LEAKAGE", "C8H04": "FAIL", "C8H05": "PASS", "C8H06": "PASS"}, "next_action": "package validation and sealing only"}
    atomic_json(ROOT / "CHECKPOINTS" / "checkpoint_final_prepackage.json", checkpoint)
    append_log({"event": "FINAL_DOCUMENTS_COMPLETE", "module_id": "C8D07", "status": "COMPLETE", "stopping_rule": "REACHED", "next": "package validation"})
    print(json.dumps({"status": "COMPLETE", "documents": len(list(ROOT.glob('*.md'))), "state": str(ROOT / 'STATE.json')}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
