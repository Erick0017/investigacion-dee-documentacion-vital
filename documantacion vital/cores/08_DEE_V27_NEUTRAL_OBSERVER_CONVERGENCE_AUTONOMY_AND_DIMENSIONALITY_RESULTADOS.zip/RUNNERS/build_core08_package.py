#!/usr/bin/env python3
"""Validate, seal, publish and byte-audit the self-contained CORE08 package."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path, PurePosixPath

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, sha256_file

TESTS = ROOT.parent
OUTPUT = ROOT / "output"
PACKAGE_NAME = "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip"
TARGET = OUTPUT / PACKAGE_NAME
EXPEDIENTE = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE"
OFFICIAL = EXPEDIENTE / "CORE" / PACKAGE_NAME
PORTABLE = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE_COMPLETO.zip"

CORE_HASHES = {
    "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip": "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f",
}
PARENT_HASH = {
    "PARENTS/07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip": CORE_HASHES["07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip"],
}
KERNEL_HASHES = {
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}
REQUIRED = [
    "EXECUTIVE_VERDICT.md", "FINAL_REPORT.md", "TRANSVERSAL_CORE01_TO_08.md",
    "CORE08_NEW_DISCOVERIES.md", "OBSERVER_THEORY.md", "MINIMAL_SUFFICIENT_OBSERVER.md",
    "NEUTRAL_ROSETTA_LANGUAGE.md", "NEUTRAL_PHENOMENON_ATLAS.json",
    "MEASUREMENT_TO_MEASUREMENT_ROSETTA.md", "CONVERGENCE_CANDIDATES.json",
    "EXTERNAL_VALIDATION_STATUS.md", "RECOVERY_TAXONOMY.json", "REPAIR_REAUDIT.md",
    "AUTONOMY_TAXONOMY.json", "AUTONOMY_REAUDIT.md", "AUTONOMOUS_REGENERATION.md",
    "FUNCTIONAL_REPAIR_AND_MEMORY.md", "RESOURCE_ACCOUNTING.md", "DIMENSIONALITY_ATLAS.json",
    "EXTRA03_DIMENSIONAL_PROJECTION.md", "BOUNDARY_TO_BULK.md", "AREA_VS_VOLUME_SCALING.md",
    "HOLOGRAPHIC_LIKE_STATUS.md", "MULTIPLE_OBSERVER_PHYSICS.md", "OBSERVER_INVARIANTS.md",
    "NEGATIVE_RESULTS.md", "FINAL_FRONTIER.md", "UNIVERSAL_ATLAS_CORE08.json",
    "CLAIM_LEDGER_CORE08.ndjson", "STATE.json", "SCIENCE_LOG.ndjson", "SOURCE_INDEX.json",
    "REPRODUCE.ps1", "run_core08_neutral_observer.py",
]
LOCK_RESULT_PAIRS = {
    "C8H01": ("C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER.json", "C8H01_minimal_guarded_destination_observer.json"),
    "C8H02": ("C8H02_REPEATED_FIXED_SCAFFOLD_REGENERATION.json", "C8H02_repeated_fixed_scaffold_regeneration.json"),
    "C8H03": ("C8H03_TRAINED_REDUNDANCY_FUNCTIONAL_RECOVERY.json", "C8H03_trained_redundancy_functional_recovery.json"),
    "C8H04": ("C8H04_BOUNDARY_TIME_CODE.json", "C8H04_boundary_time_code.json"),
    "C8H05": ("C8H05_FINITE_SIZE_BOUNDARY_CODE_LAW.json", "C8H05_finite_size_boundary_code_law.json"),
    "C8H06": ("C8H06_LEAKAGE_FREE_TRAINED_FUNCTION_RECOVERY.json", "C8H06_leakage_free_trained_function_recovery.json"),
}


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def payload_files() -> list[Path]:
    excluded_names = {"MANIFEST.json", "HASHES.sha256"}
    rows: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        parts = relative.parts
        if path.name in excluded_names or path.suffix == ".tmp" or path.suffix == ".pyc" or "__pycache__" in parts:
            continue
        if parts[0] == "output" or parts[:2] == ("PARENTS", "CORE07_EXTRACTED"):
            continue
        rows.append(path)
    return sorted(rows, key=lambda item: item.relative_to(ROOT).as_posix())


def validate_payload() -> dict:
    missing = [name for name in REQUIRED if not (ROOT / name).is_file()]
    bad_identity: dict[str, str] = {}
    for relative, expected in {**PARENT_HASH, **KERNEL_HASHES}.items():
        path = ROOT / relative
        observed = sha256_file(path) if path.is_file() else "MISSING"
        if observed != expected:
            bad_identity[relative] = observed
    invalid_json = []
    candidates = [
        ROOT / "STATE.json", ROOT / "SOURCE_INDEX.json", ROOT / "UNIVERSAL_ATLAS_CORE08.json",
        ROOT / "NEUTRAL_PHENOMENON_ATLAS.json", ROOT / "CONVERGENCE_CANDIDATES.json",
        ROOT / "RECOVERY_TAXONOMY.json", ROOT / "AUTONOMY_TAXONOMY.json",
        ROOT / "DIMENSIONALITY_ATLAS.json", *sorted((ROOT / "HOLDOUT_LOCKS").glob("*.json")),
        *sorted(path for path in (ROOT / "RESULTS").glob("*.json") if path.name != "C8V01_payload_validation.json"),
    ]
    for path in candidates:
        try:
            read_json(path)
        except Exception as error:
            invalid_json.append({"path": path.relative_to(ROOT).as_posix(), "error": repr(error)})
    lock_links = {}
    for key, (lock_name, result_name) in LOCK_RESULT_PAIRS.items():
        lock_path = ROOT / "HOLDOUT_LOCKS" / lock_name
        result_path = ROOT / "RESULTS" / result_name
        observed = sha256_file(lock_path) if lock_path.is_file() else "MISSING"
        linked = read_json(result_path).get("lock_sha256") if result_path.is_file() else None
        seal_path = lock_path.with_suffix(".sha256")
        seal = seal_path.read_text(encoding="utf-8").strip().split()[0] if seal_path.is_file() else None
        lock_links[key] = {"observed": observed, "result_link": linked, "sidecar": seal, "match": observed == linked == seal}
    state = read_json(ROOT / "STATE.json") if (ROOT / "STATE.json").is_file() else {}
    scientific_checks = {
        "state_complete": state.get("status") == "COMPLETE" and state.get("stopping_rule") == "REACHED",
        "c8h03_preserved_raw_pass": read_json(ROOT / "RESULTS/C8H03_trained_redundancy_functional_recovery.json").get("verdict") == "PASS",
        "c8h03_currently_superseded": "FAIL_PROTOCOL_LEAKAGE" in (ROOT / "ADVERSARIAL_REVIEW.md").read_text(encoding="utf-8"),
        "c8h04_fail_preserved": read_json(ROOT / "RESULTS/C8H04_boundary_time_code.json").get("verdict") == "FAIL",
        "c8h06_replacement_pass": read_json(ROOT / "RESULTS/C8H06_leakage_free_trained_function_recovery.json").get("verdict") == "PASS",
    }
    ok = not missing and not bad_identity and not invalid_json and all(row["match"] for row in lock_links.values()) and all(scientific_checks.values())
    return {
        "schema": "dee.v27.core08.payload_validation.v1",
        "module_id": "C8V01_PAYLOAD_VALIDATION",
        "status": "PASS" if ok else "FAIL",
        "required_missing": missing,
        "bad_identity_hashes": bad_identity,
        "invalid_json": invalid_json,
        "lock_result_links": lock_links,
        "scientific_checks": scientific_checks,
        "result_json_count": len(list((ROOT / "RESULTS").glob("*.json"))),
        "holdout_lock_count": len(list((ROOT / "HOLDOUT_LOCKS").glob("*.json"))),
    }


def build_manifest(files: list[Path]) -> dict:
    entries = [
        {"path": path.relative_to(ROOT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256_file(path)}
        for path in files
    ]
    state = read_json(ROOT / "STATE.json")
    atlas = read_json(ROOT / "UNIVERSAL_ATLAS_CORE08.json")
    return {
        "schema": "dee.v27.core08.manifest.v1",
        "package": PACKAGE_NAME,
        "status": "SEALED_PAYLOAD",
        "created_utc": state["timestamp_utc"],
        "root_layout": "package members are rooted at CORE08 payload root",
        "manifest_scope": "entries covers every member except MANIFEST.json and HASHES.sha256",
        "excluded_work_cache": ["PARENTS/CORE07_EXTRACTED", "output", "__pycache__", "*.pyc", "*.tmp"],
        "parent_hashes": PARENT_HASH,
        "kernel_hashes": KERNEL_HASHES,
        "final_verdicts": state["final_verdicts"],
        "atlas_records": atlas.get("record_count", len(atlas.get("records", []))),
        "entries": entries,
        "entry_count": len(entries),
        "payload_bytes": sum(row["bytes"] for row in entries),
    }


def hashes_text(files: list[Path]) -> str:
    rows = [f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}" for path in files]
    rows.append(f"{sha256_file(ROOT / 'MANIFEST.json')}  MANIFEST.json")
    return "\n".join(sorted(rows, key=lambda row: row.split("  ", 1)[1])) + "\n"


def write_zip(target: Path, root: Path, members: list[Path], prefix: str = "") -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_suffix(target.suffix + ".tmp")
    if temporary.exists():
        temporary.unlink()
    with zipfile.ZipFile(temporary, "w", allowZip64=True) as archive:
        for path in sorted(members, key=lambda item: item.relative_to(root).as_posix()):
            relative = path.relative_to(root).as_posix()
            arcname = f"{prefix}{relative}"
            info = zipfile.ZipInfo(arcname, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            info.compress_type = zipfile.ZIP_STORED if path.suffix.lower() == ".zip" else zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes(), compresslevel=9)
    os.replace(temporary, target)


def validate_zip(target: Path, root: Path, members: list[Path]) -> dict:
    expected = {path.relative_to(root).as_posix() for path in members}
    with zipfile.ZipFile(target, "r") as archive:
        names = archive.namelist()
        unsafe = [name for name in names if PurePosixPath(name).is_absolute() or ".." in PurePosixPath(name).parts]
        duplicates = sorted({name for name in names if names.count(name) > 1})
        missing = sorted(expected - set(names))
        extra = sorted(set(names) - expected)
        declared = {}
        for line in archive.read("HASHES.sha256").decode("utf-8").splitlines():
            if "  " in line:
                digest, name = line.split("  ", 1)
                declared[name] = digest
        bad_hashes = []
        for name in names:
            if name == "HASHES.sha256":
                continue
            observed = sha_bytes(archive.read(name))
            if declared.get(name) != observed:
                bad_hashes.append({"path": name, "declared": declared.get(name), "observed": observed})
        zip_test = archive.testzip()
    ok = not unsafe and not duplicates and not missing and not extra and not bad_hashes and zip_test is None
    return {
        "status": "PASS" if ok else "FAIL", "members": len(names), "unsafe": unsafe,
        "duplicates": duplicates, "missing": missing, "extra": extra, "bad_hashes": bad_hashes,
        "zip_test": zip_test, "package_sha256": sha256_file(target), "package_bytes": target.stat().st_size,
    }


def update_expediente(core08_hash: str) -> dict:
    core_dir = EXPEDIENTE / "CORE"
    if not core_dir.is_dir():
        return {"status": "SKIPPED", "reason": "expediente not present"}
    for name, expected in CORE_HASHES.items():
        path = core_dir / name
        observed = sha256_file(path) if path.is_file() else "MISSING"
        if observed != expected:
            raise RuntimeError(f"sealed CORE mismatch before publication: {name}: {observed}")
    temporary = OFFICIAL.with_suffix(OFFICIAL.suffix + ".tmp")
    shutil.copyfile(TARGET, temporary)
    if sha256_file(temporary) != core08_hash:
        temporary.unlink(missing_ok=True)
        raise RuntimeError("byte-copy hash mismatch for CORE08")
    os.replace(temporary, OFFICIAL)
    index_path = EXPEDIENTE / "INDICE_EXPEDIENTE.md"
    index = index_path.read_text(encoding="utf-8")
    index = index.replace("las siete campañas científicas principales", "las ocho campañas científicas principales")
    index = index.replace("Los ZIP CORE 01–07 están sellados", "Los ZIP CORE 01–08 están sellados")
    section = (
        "\n### Experimento 08 — observadores neutrales, regeneración y proyección dimensional\n\n"
        f"`{PACKAGE_NAME}`\n\n"
        "Deriva un observador sectorial mínimo guardado; separa información visible e invisible para distintos observadores; "
        "confirma regeneración repetida acotada de scaffold y recuperación funcional aprendida por redundancia; establece una "
        "representación lower-dimensional basada en historia de frontera sólo para rayos collision-free; conserva negativos de "
        "suficiencia 2D general, autonomía adaptativa, holografía fuerte y validación Rosetta externa.\n"
    )
    if "### Experimento 08" not in index:
        index = index.replace("\n## EXTRA\n", section + "\n## EXTRA\n")
    atomic_text(index_path, index)
    extra_path = EXPEDIENTE / "EXTRA" / "EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip"
    hash_rows = [f"{CORE_HASHES[name]}  CORE/{name}" for name in CORE_HASHES]
    hash_rows.append(f"{core08_hash}  CORE/{PACKAGE_NAME}")
    if extra_path.is_file():
        hash_rows.append(f"{sha256_file(extra_path)}  EXTRA/{extra_path.name}")
    hash_rows.append(f"{sha256_file(index_path)}  INDICE_EXPEDIENTE.md")
    atomic_text(EXPEDIENTE / "HASHES.sha256", "\n".join(hash_rows) + "\n")
    core_files = sorted(path.name for path in core_dir.iterdir() if path.is_file())
    expected_files = sorted([*CORE_HASHES, PACKAGE_NAME])
    if core_files != expected_files:
        raise RuntimeError(f"CORE directory is not exactly 01-08: {core_files}")
    observed = sha256_file(OFFICIAL)
    if observed != core08_hash:
        raise RuntimeError("published CORE08 differs byte-for-byte")
    if PORTABLE.exists():
        files = sorted((path for path in EXPEDIENTE.rglob("*") if path.is_file()), key=lambda path: path.relative_to(EXPEDIENTE).as_posix())
        write_zip(PORTABLE, EXPEDIENTE, files, prefix="EXPEDIENTE_EXPERIMENTOS_DEE/")
        with zipfile.ZipFile(PORTABLE, "r") as archive:
            if archive.testzip() is not None:
                raise RuntimeError("portable expediente ZIP failed CRC validation")
    return {"status": "PASS", "official": str(OFFICIAL), "sha256": observed, "core_files": core_files, "portable_regenerated": PORTABLE.exists()}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-payload-only", action="store_true")
    args = parser.parse_args()
    validation = validate_payload()
    atomic_json(ROOT / "RESULTS/C8V01_payload_validation.json", validation)
    if validation["status"] != "PASS":
        print(json.dumps(validation, indent=2, ensure_ascii=False))
        return 2
    if args.verify_payload_only:
        print(json.dumps(validation, indent=2, ensure_ascii=False, sort_keys=True))
        return 0
    files = payload_files()
    atomic_json(ROOT / "MANIFEST.json", build_manifest(files))
    atomic_text(ROOT / "HASHES.sha256", hashes_text(files))
    members = files + [ROOT / "MANIFEST.json", ROOT / "HASHES.sha256"]
    write_zip(TARGET, ROOT, members)
    audit = validate_zip(TARGET, ROOT, members)
    if audit["status"] != "PASS":
        print(json.dumps({"archive": audit}, indent=2, ensure_ascii=False))
        return 3
    publication = update_expediente(audit["package_sha256"])
    result = {"archive": audit, "publication": publication}
    print(json.dumps(result, indent=2, ensure_ascii=False, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
