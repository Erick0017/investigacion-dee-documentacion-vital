#!/usr/bin/env python3
"""Freeze C8H01 before any confirmatory world is generated."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now, update_state


def main() -> int:
    path = ROOT / "HOLDOUT_LOCKS" / "C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER.json"
    if path.exists():
        print(sha256_file(path))
        return 0
    lock = {
        "schema": "dee.v27.core08.holdout_lock.v1",
        "claim_id": "C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER",
        "question": "Does a guarded aggregate observer exactly predict the next raw at a void destination, and is each aggregate coordinate necessary within the declared interpretable family?",
        "domain": {
            "kernel": "sealed DEE v27",
            "destination": "void at observation tick",
            "sources": "1..26 semantic-1 Moore neighbors pointing exactly at the destination; state>=1; no orphan",
            "N": [13, 17, 23, 31],
            "clock_offsets": [0, 1, 77, 781],
            "trial_families": {"generic": 192, "xnor_symmetric": 96, "saturation": 96},
        },
        "observer": {
            "Z_update": ["xnor_guard", "sum_s", "sign(sum_dx)", "sign(sum_dy)", "sign(sum_dz)"],
            "Z_account": ["Z_update", "k"],
        },
        "rule": {
            "xnor": "if all 13 opposite occupancy pairs agree and active>=8: raw=(state1,s_reg1,d0,semantic7)",
            "otherwise": "raw=(state1,min(sum_s,19664),sign(sum_d),semantic1)",
            "account": "k inbound proposals become one destination record; local multiplicity contraction=k-1",
        },
        "parameters": {"seeds": [880101, 880103, 880107, 880109], "threads": 1, "trials": 384},
        "null": "unguarded reducer prediction",
        "controls": ["clock offsets", "translations", "N", "source-state nuisance", "orientation/direction subsets", "XNOR symmetric fibers", "s_reg saturation"],
        "minimum_effect": {"Z_update_exact_rate": 1.0, "Z_account_exact_rate": 1.0, "unguarded_error_count_min": 1, "all_coordinate_counterexamples": True},
        "PASS": "all 384 frozen trials exactly match; null fails on at least one symmetric trial; independent coordinate-deletion witnesses all differ",
        "FAIL": "any guarded mismatch or any required coordinate lacks a counterexample",
        "INCONCLUSIVE": "technical execution failure or sealed identity mismatch",
        "falsifier": "two worlds with identical Z_update in-domain but different destination raw at t+1, or a holdout prediction mismatch",
        "epistemic_scope": "minimal only within the declared aggregate coordinate-deletion family and one-destination task; not a global quotient of F_DEE",
        "frozen_utc": utc_now(),
    }
    lock["content_sha256"] = canonical_hash(lock)
    atomic_json(path, lock)
    digest = sha256_file(path)
    atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    update_state(pending_holdout="C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER", next_action="Open C8H01 frozen holdout exactly once.")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
