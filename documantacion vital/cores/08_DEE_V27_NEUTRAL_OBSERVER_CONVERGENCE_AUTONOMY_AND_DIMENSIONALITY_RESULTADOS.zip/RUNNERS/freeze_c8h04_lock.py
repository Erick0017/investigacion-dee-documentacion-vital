#!/usr/bin/env python3
"""Freeze the restricted boundary time-code confirmation."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now, update_state


def main() -> int:
    path = ROOT / "HOLDOUT_LOCKS" / "C8H04_BOUNDARY_TIME_CODE.json"
    if not path.exists():
        lock = {
            "schema": "dee.v27.core08.holdout_lock.v1",
            "claim_id": "C8H04_BOUNDARY_TIME_CODE",
            "question": "Is a boundary event history a lower-dimensional sufficient observer for collision-free one-carrier-per-ray DEE transport?",
            "domain": {"N": [19, 25, 33, 41], "worlds": 16, "rays": "surface grid spacing 3", "directions": ["+x", "-x", "+y", "-y", "+z", "-z"], "preparation": "at most one carrier per boundary-normal ray; carriers laterally separated; semantic1; s_reg identifies payload"},
            "observer": "ordered boundary event list (two surface coordinates, arrival time, s_reg, direction)",
            "features": ["surface location", "relative arrival delay", "payload", "normal orientation"],
            "rule": "initial normal depth equals distance from arrival boundary, hence equals arrival delay at c_transport=1; lateral coordinate and payload are preserved",
            "parameters": {"seeds": [884001, 884003, 884009, 884011], "threads": 1},
            "null": "equal-size records with event times or surface locations independently permuted",
            "controls": ["time shuffle", "surface-location shuffle", "instantaneous integrated projection", "N", "orientation", "translation/clock nuisance"],
            "minimum_effect": {"reconstruction_rate": 1.0, "trajectory_prediction_rate": 1.0, "time_shuffle_accuracy_max": 0.25, "location_shuffle_accuracy_max": 0.25, "ray_count_scaling_exponent_min": 1.7, "ray_count_scaling_exponent_max": 2.3},
            "PASS": "all holdout carriers are reconstructed and their future support/payload predicted; shuffled controls <=25%; ray count scales near area",
            "FAIL": "any true-code error, controls exceed threshold, or scaling leaves [1.7,2.3]",
            "INCONCLUSIVE": "technical failure or identity mismatch",
            "falsifier": "two in-domain worlds share the boundary event code but have different functional support/s_reg trajectories",
            "claim_scope": "LOWER_DIMENSIONAL_EFFECTIVE_STATE and BOUNDARY_HISTORY_SUFFICIENT only for a family with O(N^2) independent rays; not a code for arbitrary O(N^3) bulk states and not holographic ontology",
            "frozen_utc": utc_now(),
        }
        lock["content_sha256"] = canonical_hash(lock)
        atomic_json(path, lock)
        digest = sha256_file(path)
        atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    digest = sha256_file(path)
    update_state(pending_holdout="C8H04_BOUNDARY_TIME_CODE", next_action="Open C8H04 frozen boundary-code holdout.")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
