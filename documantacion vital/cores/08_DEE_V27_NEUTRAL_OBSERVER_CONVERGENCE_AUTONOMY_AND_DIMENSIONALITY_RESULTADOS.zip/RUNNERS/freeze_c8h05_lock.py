#!/usr/bin/env python3
"""Post-C8H04 lock for an exact discrete finite-size boundary-code law."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now, update_state


def main() -> int:
    path = ROOT / "HOLDOUT_LOCKS" / "C8H05_FINITE_SIZE_BOUNDARY_CODE_LAW.json"
    if not path.exists():
        lock = {
            "schema": "dee.v27.core08.holdout_lock.v1",
            "claim_id": "C8H05_FINITE_SIZE_BOUNDARY_CODE_LAW",
            "predecessor": {"claim_id": "C8H04_BOUNDARY_TIME_CODE", "verdict": "FAIL", "reason": "predeclared naive finite-range log-log exponent was 2.4946 > 2.3; verdict remains unchanged"},
            "question": "Does the newly formalized discrete ray packing law and restricted boundary event decoder generalize to unused N?",
            "domain": {"N": [21, 27, 35, 43, 51], "worlds": 10, "grid": "range(2,N-2,3) on each of two surface coordinates", "transport": "collision-free one-carrier-per-ray normal transport"},
            "observer": "boundary event list (surface coordinates,arrival,s_reg,direction)",
            "features": ["relative delay", "surface place", "payload"],
            "rule": {"ray_count": "K(N)=ceil((N-4)/3)^2 exactly", "decoder": "normal coordinate=N-1-arrival for positive normal and arrival for negative normal", "future": "q_axis(t)=q_axis(0)+sign*t mod N", "asymptotic": "K=Theta(N^2), event bits=Theta(N^2 log N)"},
            "parameters": {"seeds": [885001, 885007], "orientations": ["+x", "-x", "+y", "-y", "+z", "-z"], "threads": 1},
            "null": "time/location shuffled event lists",
            "controls": ["new N only", "new seeds", "six orientations", "time shuffle", "location shuffle"],
            "minimum_effect": {"exact_ray_count_rate": 1.0, "reconstruction_rate": 1.0, "trajectory_prediction_rate": 1.0, "time_shuffle_accuracy_max": 0.25, "location_shuffle_accuracy_max": 0.25},
            "PASS": "all new-N worlds match the exact K formula, decoder and future rule; controls <=25%",
            "FAIL": "any exact-law or decoder mismatch, or a control exceeds 25%",
            "INCONCLUSIVE": "technical failure or identity mismatch",
            "falsifier": "any unused N violates K formula or any in-domain carrier is not decoded/predicted",
            "claim_scope": "restricted area-indexed ballistic family only; the time-bearing code is Theta(N^2 log N), not a demonstrated O(N^2)-bit code for arbitrary volumetric state",
            "frozen_utc": utc_now(),
        }
        lock["content_sha256"] = canonical_hash(lock)
        atomic_json(path, lock)
        digest = sha256_file(path)
        atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    digest = sha256_file(path)
    update_state(pending_holdout="C8H05_FINITE_SIZE_BOUNDARY_CODE_LAW", next_action="Open post-failure C8H05 on unused sizes without altering C8H04.")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
