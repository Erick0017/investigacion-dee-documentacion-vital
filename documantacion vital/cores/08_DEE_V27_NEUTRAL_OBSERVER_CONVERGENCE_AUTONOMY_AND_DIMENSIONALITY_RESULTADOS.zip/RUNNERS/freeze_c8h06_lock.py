#!/usr/bin/env python3
"""Freeze a leakage-free replacement for C8H03; C8H03 remains protocol-failed."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now, update_state


def main() -> int:
    path = ROOT / "HOLDOUT_LOCKS" / "C8H06_LEAKAGE_FREE_TRAINED_FUNCTION_RECOVERY.json"
    if not path.exists():
        lock = {
            "schema": "dee.v27.core08.holdout_lock.v1", "claim_id": "C8H06_LEAKAGE_FREE_TRAINED_FUNCTION_RECOVERY",
            "predecessor": {"claim_id": "C8H03", "original_runner_verdict": "PASS", "current_adjudication": "FAIL_PROTOCOL_LEAKAGE", "reason": "2/24 query values equaled training_x in cell 0; original bytes/results remain preserved"},
            "question": "Does trained redundant functional recovery generalize when every query is explicitly disjoint from both training values?",
            "domain": {"N": [71, 73, 75, 77, 81, 85], "cells": 6, "queries_per_cell": 3, "damage": "leading support deletion", "lag": 2, "frames": "six frozen signed permutations"},
            "observer": ["donor learned payload", "restored payload", "unseen query response"],
            "features": ["ordinary training collision", "lag-2 trained redundancy", "redirect", "unseen query"],
            "rule": "q -> q+delta after deletion, with two-tick recovery delay",
            "parameters": {"seeds": [886101, 886103, 886109, 886127, 886129, 886163], "deltas": [-13, -8, -4, 3, 7, 14], "training_x_main": [37, 41, 43, 47, 49, 53], "training_x_donor": [61, 67, 71, 73, 79, 83], "queries": [[5, 11, 17], [7, 13, 19], [9, 15, 21], [10, 16, 22], [12, 18, 24], [14, 20, 26]], "threads": 1},
            "null": "damaged apparatus without correct trained redundancy",
            "controls": ["no damage", "no donor", "wrong donor", "label shuffle", "offpath", "memory ablation", "direction ablation"],
            "minimum_effect": {"disjoint_rate": 1.0, "positive_exact_rate": 1.0, "memory_restore_rate": 1.0, "negative_exact_rate_max": 0.0, "no_damage_exact_rate": 1.0},
            "PASS": "all 18 explicitly unseen positive queries and six no-damage baselines exact; all 36 causal controls fail",
            "FAIL": "any overlap, positive failure or negative success",
            "INCONCLUSIVE": "technical failure or identity mismatch",
            "falsifier": "response without correct trained donor/path/memory, or failure on any disjoint query",
            "claim_scope": "R5 by finite independently trained redundancy; not R6 learned damage detection or R7 learned-memory regeneration",
            "frozen_utc": utc_now(),
        }
        lock["content_sha256"] = canonical_hash(lock)
        atomic_json(path, lock)
        digest = sha256_file(path); atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    digest = sha256_file(path)
    update_state(pending_holdout="C8H06_LEAKAGE_FREE_TRAINED_FUNCTION_RECOVERY", next_action="Open C8H06 on disjoint queries and new seeds/N.")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
