#!/usr/bin/env python3
"""Freeze the two non-equivalent regeneration claims discovered in C8D03/D04."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now, update_state


def freeze(path: Path, payload: dict) -> str:
    if not path.exists():
        payload["frozen_utc"] = utc_now()
        payload["content_sha256"] = canonical_hash(payload)
        atomic_json(path, payload)
        digest = sha256_file(path)
        atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    return sha256_file(path)


def main() -> int:
    h02 = {
        "schema": "dee.v27.core08.holdout_lock.v1",
        "claim_id": "C8H02_REPEATED_FIXED_SCAFFOLD_REGENERATION",
        "question": "Does an all-t0 persistent geometric scaffold autonomously restore and stabilize a damaged center over repeated cycles?",
        "domain": {"N": [17, 23, 31, 37], "worlds": 32, "cycles_per_world": 10, "damage_interval_ticks": 3, "translations": "frozen seeded", "center_payload": "semantic7,state1,s_reg1,d0", "scaffold": "eight semantic4 Moore corners,d0"},
        "observer": ["center raw", "scaffold raw hash", "support", "s_reg sum", "birth/death telemetry"],
        "features": ["opposite-pair occupancy symmetry", "center vacancy", "persistent scaffold"],
        "rule": "damage -> XNOR vacancy guard -> semantic7 center birth in one tick -> occupied center stops further local birth",
        "parameters": {"seeds": [882001, 882003, 882007, 882011], "threads": 1},
        "null": "free relaxation without a persistent symmetric scaffold",
        "controls": ["missing corner", "shuffled same inventory", "nonpersistent semantic1 scaffold", "disconnected corner", "payload nuisance", "no damage"],
        "minimum_effect": {"primary_cycle_recovery_rate": 1.0, "scaffold_unchanged_rate": 1.0, "center_stability_rate": 1.0, "negative_control_recovery_rate_max": 0.05, "payload_nuisance_recovery_rate": 1.0},
        "PASS": "all 320 primary cycles restore exact center in one tick, persist until next damage, scaffold stays byte-identical; negative structural controls <=5% and payload nuisance remains 100%",
        "FAIL": "any primary cycle misses or a negative structural control exceeds 5%",
        "INCONCLUSIVE": "technical failure or identity mismatch",
        "falsifier": "a frozen primary cycle fails, restoration continues producing excess local support, or symmetry-destroyed equal-inventory controls recover comparably",
        "claim_scope": "R2,R5-fixed,R6 and R7 only for this immutable XNOR scaffold; not learned repair, general morphogenesis, biological homeostasis or resource conservation",
    }
    h03 = {
        "schema": "dee.v27.core08.holdout_lock.v1",
        "claim_id": "C8H03_TRAINED_REDUNDANCY_FUNCTIONAL_RECOVERY",
        "question": "Can a separately trained redundant lineage restore a damaged learned response on unseen queries?",
        "domain": {"N": [79, 83, 89, 97], "cells": 8, "unseen_queries_per_cell": 3, "translations_and_signed_permutations": "frozen", "damage": "delete leading learned carrier", "redundancy_lag_ticks": 2},
        "observer": ["trained donor payload", "restored target payload", "unseen-query response repertoire", "recovery delay"],
        "features": ["ordinary cue+teacher collision", "independently trained redundant donor", "redirect", "query collision"],
        "rule": "both lineages learn the same additive delta through ordinary inputs; deletion removes the leader; lag-2 donor restores the response class and answers unseen q after two-tick delay",
        "parameters": {"seeds": [883001, 883003, 883009, 883013, 883021, 883031, 883037, 883051], "deltas": [-11, -7, -3, 2, 5, 9, 13, 17], "queries": [[19, 23, 31], [17, 29, 37], [11, 25, 41], [13, 27, 43], [15, 33, 47], [21, 35, 49], [17, 39, 53], [23, 41, 59]], "threads": 1},
        "null": "damage without a causally correct trained donor",
        "controls": ["no damage", "no donor", "wrong donor", "label-shuffled donor", "offpath donor", "memory ablation", "actuator direction ablation"],
        "minimum_effect": {"positive_exact_rate": 1.0, "positive_memory_restore_rate": 1.0, "negative_exact_rate_max": 0.0, "no_damage_exact_rate": 1.0},
        "PASS": "all damaged positives restore learned payload and answer all unseen queries; every causal negative control fails; no-damage baseline succeeds",
        "FAIL": "any positive fails or any negative control produces the frozen correct response",
        "INCONCLUSIVE": "technical failure or identity mismatch",
        "falsifier": "correct unseen responses without the trained donor/path/memory, or failure to recover with them",
        "claim_scope": "R5 functional learned-memory recovery by finite pre-trained redundancy; explicitly not R6 damage detection, R7 repeated learned-memory regeneration, or reconstruction from the damaged carrier",
    }
    d2 = freeze(ROOT / "HOLDOUT_LOCKS" / "C8H02_REPEATED_FIXED_SCAFFOLD_REGENERATION.json", h02)
    d3 = freeze(ROOT / "HOLDOUT_LOCKS" / "C8H03_TRAINED_REDUNDANCY_FUNCTIONAL_RECOVERY.json", h03)
    update_state(pending_holdout="C8H02,C8H03", next_action="Run C8H02 and C8H03 exactly under frozen locks.")
    print(f"C8H02 {d2}\nC8H03 {d3}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
