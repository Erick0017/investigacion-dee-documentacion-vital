#!/usr/bin/env python3
"""One-time auditable CORE08 initialization from sealed CORE07 and kernel."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, TESTS, EXPECTED, atomic_json, atomic_text, append_log, sha256_file, utc_now, verify_and_load_kernel

CORE_HASHES = {
    "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip": "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f",
}


def main() -> int:
    _, identity = verify_and_load_kernel()
    core_dir = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
    actual = sorted(path.name for path in core_dir.glob("*.zip"))
    observed = {name: sha256_file(core_dir / name) for name in CORE_HASHES}
    problems = {name: value for name, value in observed.items() if value != CORE_HASHES[name]}
    parent07 = ROOT / "PARENTS" / "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip"
    parent07_hash = sha256_file(parent07)
    if problems or parent07_hash != CORE_HASHES[next(reversed(CORE_HASHES))]:
        raise RuntimeError({"core_mismatches": problems, "parent07": parent07_hash})
    audit = {
        "schema": "dee.v27.core08.initial_audit.v1",
        "module_id": "C8A00_INITIAL_AUDIT",
        "status": "PASS",
        "timestamp_utc": utc_now(),
        "core_archive_count_before_core08": len(actual),
        "core_archive_names": actual,
        "core_hashes": observed,
        "parent07_copy_sha256": parent07_hash,
        "kernel_identity": identity,
        "authority": "executed binary > primary results/locks/runners > same-core reports > later synthesis > history",
    }
    atomic_json(ROOT / "RESULTS" / "C8A00_initial_audit.json", audit)
    if not (ROOT / "RECOVERY_TAXONOMY.json").exists():
        atomic_json(ROOT / "RECOVERY_TAXONOMY.json", {
            "schema": "dee.v27.core08.recovery_taxonomy.v1",
            "levels": {
                "R0": {"name": "DAMAGE_TOLERANCE", "status": "OPEN"},
                "R1": {"name": "PASSIVE_RELAXATION_RECOVERY", "status": "OPEN"},
                "R2": {"name": "MORPHOLOGICAL_REFILL", "status": "OPEN"},
                "R3": {"name": "BASIN_REGIME_RECOVERY", "status": "OPEN"},
                "R4": {"name": "ASSISTED_RESTORATION", "status": "OPEN"},
                "R5": {"name": "FUNCTIONAL_RECOVERY", "status": "OPEN"},
                "R6": {"name": "INTERNALLY_TRIGGERED_REPAIR", "status": "OPEN"},
                "R7": {"name": "REPEATED_HOMEOSTATIC_REGENERATION", "status": "OPEN"},
            },
            "rule": "passing one level does not imply any higher level",
        })
    if not (ROOT / "AUTONOMY_TAXONOMY.json").exists():
        atomic_json(ROOT / "AUTONOMY_TAXONOMY.json", {
            "schema": "dee.v27.core08.autonomy_taxonomy.v1",
            "levels": {f"A{i}": {"status": "OPEN"} for i in range(8)},
            "names": ["SELF_EVOLUTION", "ENDOGENOUS_MEMORY", "INTERNAL_PROCESS_CHAIN", "CLOSED_CAUSAL_FEEDBACK", "REPEATED_CLOSED_LOOP", "SELF_MAINTENANCE", "ADAPTIVE_AUTONOMY", "RESOURCE_SUSTAINED_AUTONOMY"],
            "rule": "resources and interfaces may be present at t0; no host action selection after START",
        })
    for name, schema in (
        ("OBSERVER_ATLAS.json", "dee.v27.core08.observer_atlas.v1"),
        ("NEUTRAL_PHENOMENON_ATLAS.json", "dee.v27.core08.neutral_phenomenon_atlas.v1"),
        ("DIMENSIONALITY_ATLAS.json", "dee.v27.core08.dimensionality_atlas.v1"),
        ("CONVERGENCE_CANDIDATES.json", "dee.v27.core08.convergence_candidates.v1"),
    ):
        if not (ROOT / name).exists():
            atomic_json(ROOT / name, {"schema": schema, "status": "DISCOVERY", "records": []})
    state = {
        "schema": "dee.v27.core08.state.v1",
        "status": "ACTIVE",
        "current_question": "Which observer quotient is minimally sufficient for declared DEE phenomena?",
        "active_branches": ["OBSERVER", "REPAIR_AUTONOMY", "DIMENSIONALITY", "NEUTRAL_ROSETTA"],
        "last_completed_experiment": "C8A00_INITIAL_AUDIT",
        "complete_modules": ["C8A00"],
        "proven": ["sealed CORE01-07 and v27 kernel identities verified"],
        "refuted": [],
        "provisional": [],
        "observer_candidates": [],
        "recovery_vector": {f"R{i}": "OPEN" for i in range(8)},
        "autonomy_vector": {f"A{i}": "OPEN" for i in range(8)},
        "convergence_candidates": [],
        "pending_holdout": None,
        "next_action": "Run C8D01 observer-family discovery against v27 kernel.",
        "technical_interruptions": [],
        "timestamp_utc": utc_now(),
    }
    atomic_json(ROOT / "STATE.json", state)
    if not (ROOT / "SCIENCE_LOG.ndjson").exists():
        atomic_text(ROOT / "SCIENCE_LOG.ndjson", "")
    append_log({"event": "CORE08_INITIALIZED", "module_id": "C8A00", "status": "PASS", "next_action": state["next_action"]})
    print(json.dumps(audit, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
