#!/usr/bin/env python3
"""Discovery: task-relative observer quotients and exact local sufficiency witnesses."""
from __future__ import annotations

import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, fields, pack, unpack_scalar, update_state, verify_and_load_kernel


# Corner sources are pairwise outside one another's Moore neighborhoods, so the
# only interaction in these panels is their shared destination fiber.
NEIGHBORS = list(itertools.product((-1, 1), repeat=3))


def add(a, b, n):
    return tuple((a[i] + b[i]) % n for i in range(3))


def neg(a):
    return tuple(-x for x in a)


def totals(raw):
    f = fields(raw)
    return {"support": int(np.count_nonzero(raw)), "s_reg": int(f["sreg"].astype(np.uint64).sum())}


def run_fiber(kernel, entries, n=17):
    target = (8, 8, 8)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    for i, (sreg, direction) in enumerate(entries):
        position = add(target, neg(direction), n)
        if int(raw[position]) != 0:
            raise ValueError("duplicate source position")
        raw[position] = pack(1000 + i, sreg, direction, 1)
    before = totals(raw)
    world = NativeWorld(kernel, raw)
    world.tick()
    after = totals(world.raw)
    output = unpack_scalar(world.raw[target]) if int(world.raw[target]) else None
    return {
        "input": {"k": len(entries), "sum_s": sum(x[0] for x in entries), "sum_d": [sum(x[1][j] for x in entries) for j in range(3)]},
        "output": output,
        "global_support_delta": after["support"] - before["support"],
        "global_s_reg_delta": after["s_reg"] - before["s_reg"],
    }


def outcome(row):
    out = row["output"]
    return [out["s_reg"] if out else None, *(out["direction"] if out else [None] * 3), row["global_support_delta"]]


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    rng = np.random.default_rng(80801)
    samples = []
    for k in range(1, 9):
        for rep in range(12):
            directions = rng.choice(len(NEIGHBORS), size=k, replace=False)
            entries = [(int(rng.integers(1, 301)), NEIGHBORS[int(index)]) for index in directions]
            row = run_fiber(kernel, entries)
            expected = [
                min(row["input"]["sum_s"], 19664),
                *[int(value > 0) - int(value < 0) for value in row["input"]["sum_d"]],
                1 - k,
            ]
            row["expected"] = expected
            row["exact"] = outcome(row) == expected
            samples.append(row)

    witnesses = {
        "drop_k": [run_fiber(kernel, [(10, (1, 1, 1))]), run_fiber(kernel, [(2, (1, 1, 1)), (3, (1, 1, -1)), (5, (1, -1, 1))])],
        "drop_sum_s": [run_fiber(kernel, [(4, (1, 1, 1)), (6, (-1, -1, -1))]), run_fiber(kernel, [(5, (1, 1, 1)), (8, (-1, -1, -1))])],
        "drop_sign_x": [run_fiber(kernel, [(10, (1, 1, 1))]), run_fiber(kernel, [(10, (-1, 1, 1))])],
        "drop_sign_y": [run_fiber(kernel, [(10, (1, 1, 1))]), run_fiber(kernel, [(10, (1, -1, 1))])],
        "drop_sign_z": [run_fiber(kernel, [(10, (1, 1, 1))]), run_fiber(kernel, [(10, (1, 1, -1))])],
    }
    for key, pair in witnesses.items():
        pair[0]["outcome"] = outcome(pair[0])
        pair[1]["outcome"] = outcome(pair[1])
        pair_same_except = {
            "drop_k": pair[0]["input"]["sum_s"] == pair[1]["input"]["sum_s"],
            "drop_sum_s": pair[0]["input"]["k"] == pair[1]["input"]["k"],
            "drop_sign_x": pair[0]["input"]["k"] == pair[1]["input"]["k"] and pair[0]["input"]["sum_s"] == pair[1]["input"]["sum_s"],
            "drop_sign_y": pair[0]["input"]["k"] == pair[1]["input"]["k"] and pair[0]["input"]["sum_s"] == pair[1]["input"]["sum_s"],
            "drop_sign_z": pair[0]["input"]["k"] == pair[1]["input"]["k"] and pair[0]["input"]["sum_s"] == pair[1]["input"]["sum_s"],
        }[key]
        witnesses[key] = {"pair": pair, "same_on_remaining_coarse_coordinates": pair_same_except, "future_differs": pair[0]["outcome"] != pair[1]["outcome"]}

    # Same raw inventory, different relational arrangement: collision versus separated destinations.
    n = 17
    target = (8, 8, 8)
    collision = np.zeros((n, n, n), dtype=np.uint64)
    separated = np.zeros_like(collision)
    v1, v2 = pack(1, 7, (1, 1, 1), 1), pack(2, 11, (1, -1, -1), 1)
    collision[add(target, (-1, -1, -1), n)] = v1
    collision[add(target, (-1, 1, 1), n)] = v2
    separated[(3, 3, 3)] = v1
    separated[(12, 4, 9)] = v2
    wa, wb = NativeWorld(kernel, collision), NativeWorld(kernel, separated)
    before_a, before_b = totals(wa.raw), totals(wb.raw)
    wa.tick(); wb.tick()
    inventory_pair = {
        "same_raw_multiset_at_t0": sorted(map(int, collision[collision != 0])) == sorted(map(int, separated[separated != 0])),
        "world_a_next": totals(wa.raw),
        "world_b_next": totals(wb.raw),
        "future_differs": not np.array_equal(wa.raw, wb.raw) and totals(wa.raw) != totals(wb.raw),
        "support_delta_a": totals(wa.raw)["support"] - before_a["support"],
        "support_delta_b": totals(wb.raw)["support"] - before_b["support"],
    }

    exact_rate = sum(row["exact"] for row in samples) / len(samples)
    result = {
        "schema": "dee.v27.core08.c8d01.v1",
        "module_id": "C8D01_OBSERVER_FAMILY_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE",
        "status": "COMPLETE",
        "kernel_environment": environment,
        "worlds": len(samples) + 2 * len(witnesses) + 2,
        "kernel_ticks": len(samples) + 2 * len(witnesses) + 2,
        "wall_clock_seconds": time.perf_counter() - started,
        "task": "predict destination s_reg, direction and global support delta in normal source-free blank-destination fibers",
        "candidate_observer": {"name": "Z_f", "coordinates": ["k", "sum_s", "sign(sum_dx)", "sign(sum_dy)", "sign(sum_dz)"], "output_rule": ["min(sum_s,19664)", "sign(sum_d)", "1-k"]},
        "exact_discovery_rate": exact_rate,
        "samples": samples,
        "proper_coordinate_deletion_witnesses": witnesses,
        "inventory_only_counterexample": inventory_pair,
        "interpretation": [
            "Z_f is sufficient for the declared output in this sector, not a global observer of F_DEE.",
            "Each coordinate is necessary within the declared coordinate-deletion family and output tuple.",
            "A global raw inventory loses destination relations and violates closure.",
        ],
        "next_decision": "Freeze an independent cross-N/orientation/translation holdout for task-relative minimality of Z_f; separately search counterexamples outside the sector.",
    }
    atomic_json(ROOT / "RESULTS" / "C8D01_observer_family_discovery.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D01", "status": "DISCOVERY", "exact_rate": exact_rate, "next_action": result["next_decision"]})
    update_state(
        last_completed_experiment="C8D01_OBSERVER_FAMILY_DISCOVERY",
        complete_modules=["C8A00", "C8D01"],
        provisional=["Z_f task-relative sufficient observer candidate", "raw-inventory observer is not closed"],
        observer_candidates=["Z_f=(k,sum_s,sign(sum_d)) for normal blank-destination fibers"],
        pending_holdout="C8H01_MINIMAL_FIBER_OBSERVER",
        next_action=result["next_decision"],
    )
    print(json.dumps({"exact_rate": exact_rate, "witnesses": {k: v["future_differs"] for k, v in witnesses.items()}, "inventory_pair": inventory_pair}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
