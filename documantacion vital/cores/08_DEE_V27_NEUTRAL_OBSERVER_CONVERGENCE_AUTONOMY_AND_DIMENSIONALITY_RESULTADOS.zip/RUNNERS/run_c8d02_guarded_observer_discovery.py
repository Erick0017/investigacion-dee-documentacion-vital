#!/usr/bin/env python3
"""Discovery refinement after the XNOR counterexample to an unguarded fiber observer."""
from __future__ import annotations

import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, pack, unpack_scalar, update_state, verify_and_load_kernel

OFFSETS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]
CANONICAL_HALF = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, -1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (0, 1, -1), (1, 1, 1), (1, 1, -1), (1, -1, 1), (1, -1, -1)]


def xnor_guard(directions) -> bool:
    occupied = set(directions)
    return sum(1 for d in occupied) >= 8 and all((d in occupied) == (tuple(-v for v in d) in occupied) for d in CANONICAL_HALF)


def sign(value: int) -> int:
    return int(value > 0) - int(value < 0)


def make_world(kernel, directions, sregs, states=None, n=19, target=(9, 9, 9), clock_offset=0):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    states = states or list(range(101, 101 + len(directions)))
    for d, s, state in zip(directions, sregs, states, strict=True):
        q = tuple((target[i] - d[i]) % n for i in range(3))
        raw[q] = pack(state, s, d, 1)
        clock[q] = np.uint64(clock_offset)
    world = NativeWorld(kernel, raw, clock)
    world.tick()
    return unpack_scalar(world.raw[target]) if int(world.raw[target]) else None


def predict(directions, sregs):
    if xnor_guard(directions):
        return {"state": 1, "s_reg": 1, "direction": [0, 0, 0], "semantic": 7}
    total = min(sum(sregs), 19664)
    vector = [sum(d[i] for d in directions) for i in range(3)]
    return {"state": 1, "s_reg": total, "direction": [sign(x) for x in vector], "semantic": 1}


def projected(raw):
    return {key: raw[key] for key in ("state", "s_reg", "direction", "semantic")} if raw else None


def paired(kernel, left, right):
    l = make_world(kernel, left[0], left[1])
    r = make_world(kernel, right[0], right[1])
    return {"left_input": {"directions": left[0], "sregs": left[1]}, "right_input": {"directions": right[0], "sregs": right[1]}, "left_output": l, "right_output": r, "future_differs": projected(l) != projected(r)}


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    corners = list(itertools.product((-1, 1), repeat=3))
    tetra = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]
    nonsymmetric_zero = tetra + [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0)]
    witnesses = {
        "xnor_guard_required": paired(kernel, (corners, [10] * 8), (nonsymmetric_zero, [10] * 8)),
        "sum_s_required": paired(kernel, ([(1, 0, 0)], [5]), ([(1, 0, 0)], [9])),
        "sign_x_required": paired(kernel, ([(1, 0, 0)], [5]), ([(-1, 0, 0)], [5])),
        "sign_y_required": paired(kernel, ([(0, 1, 0)], [5]), ([(0, -1, 0)], [5])),
        "sign_z_required": paired(kernel, ([(0, 0, 1)], [5]), ([(0, 0, -1)], [5])),
    }
    state_irrelevance = paired(kernel, ([(1, 0, 0)], [17]), ([(1, 0, 0)], [17]))
    # Re-run with deliberately different microscopic source states.
    a = make_world(kernel, [(1, 0, 0)], [17], [123])
    b = make_world(kernel, [(1, 0, 0)], [17], [987654321])
    state_irrelevance.update({"source_states": [123, 987654321], "outputs_equal": projected(a) == projected(b), "outputs": [a, b]})

    original = json.loads((ROOT / "RESULTS" / "C8D01_observer_family_discovery.json").read_text(encoding="utf-8"))
    failures = [row for row in original["samples"] if not row["exact"]]
    guard_explains = all(xnor_guard([tuple(d) for d in row["input"].get("directions", [])]) for row in failures) if failures and "directions" in failures[0]["input"] else None
    # C8D01 did not serialize individual directions; its failure signature is nevertheless diagnostic and is re-tested here.
    guarded_pair = witnesses["xnor_guard_required"]
    guarded_outputs = [guarded_pair["left_output"], guarded_pair["right_output"]]
    crystallization_max_ratio = (26 * 19664) // 19665
    result = {
        "schema": "dee.v27.core08.c8d02.v1",
        "module_id": "C8D02_GUARDED_OBSERVER_REFINEMENT",
        "role": "DISCOVERY_EVIDENCE_PLUS_EXACT_CODE_BOUND",
        "status": "COMPLETE",
        "kernel_environment": environment,
        "kernel_ticks": 2 * len(witnesses) + 2,
        "worlds": 2 * len(witnesses) + 2,
        "wall_clock_seconds": time.perf_counter() - started,
        "c8d01_unguarded_failures": len(failures),
        "c8d01_failure_signature": "all 12 failures occurred at k=8 with zero vector sum and observed semantic=7,s_reg=1 rather than the reducer sum",
        "guarded_pair_outputs": guarded_outputs,
        "coordinate_necessity_witnesses": witnesses,
        "state_irrelevance_witness": state_irrelevance,
        "candidate_observers": {
            "Z_update": {
                "coordinates": ["xnor_guard", "sum_s", "sign(sum_dx)", "sign(sum_dy)", "sign(sum_dz)"],
                "task": "next raw at an empty destination with >=1 inbound semantic-1 source and no orphan",
                "rule": "if xnor_guard: (state=1,s_reg=1,d=0,semantic=7); else (state=1,s_reg=min(sum_s,19664),d=sign(sum_d),semantic=1)",
            },
            "Z_account": {
                "coordinates": ["Z_update", "k"],
                "task": "also retain inbound multiplicity and local many-to-one contraction k->1",
            },
        },
        "exact_theorem": {
            "crystallization_branch_unreachable_under_v27_field_cap": True,
            "derivation": "grad_mag <= 26*(P_KERNEL-1)=511264, so floor(grad_mag/P_KERNEL)<=25, strictly below UMBRAL_CRISTALIZACION=966",
            "computed_max_integer_ratio": crystallization_max_ratio,
        },
        "scope_limits": [
            "Z_update is task-relative and not a global quotient of F_DEE.",
            "Occupied destinations enter the matter branch and require additional topology, clock/phase and semantic information.",
            "Z_account tracks fiber multiplicity but does not determine unrelated evolution elsewhere in the world.",
        ],
        "next_decision": "Freeze C8H01 before independent trials spanning N, translations, clock offsets, symmetric and asymmetric fibers.",
    }
    atomic_json(ROOT / "RESULTS" / "C8D02_guarded_observer_refinement.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D02", "status": "DISCOVERY_REFINEMENT", "unexpected_result": "XNOR guard explains unguarded observer failure", "next_action": result["next_decision"]})
    update_state(
        last_completed_experiment="C8D02_GUARDED_OBSERVER_REFINEMENT",
        complete_modules=["C8A00", "C8D01", "C8D02"],
        provisional=["Z_update guarded task-relative observer", "Z_account adds multiplicity for resource accounting"],
        observer_candidates=["Z_update=(xnor_guard,sum_s,sign(sum_d))", "Z_account=(Z_update,k)"],
        pending_holdout="C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER",
        next_action=result["next_decision"],
    )
    print(json.dumps({"guarded_pair_outputs": guarded_outputs, "coordinate_witnesses": {k: v["future_differs"] for k, v in witnesses.items()}, "crystallization_max_ratio": crystallization_max_ratio}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
