#!/usr/bin/env python3
"""Discovery of repeated scaffold regeneration and learned-function redundancy repair."""
from __future__ import annotations

import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, fields, pack, unpack_scalar, update_state, verify_and_load_kernel


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def place_for_arrival(raw, clock, destination, tick, direction, sreg, state, n, semantic=1):
    source = add(destination, direction, -tick, n)
    if int(raw[source]) != 0:
        raise RuntimeError(f"initial overlap at {source}")
    raw[source] = pack(state, sreg, direction, semantic)
    clock[source] = np.uint64(state * 17 + tick)


def record(raw, q):
    return unpack_scalar(raw[q]) if int(raw[q]) else None


def scaffold_panel(kernel, mode, cycles=6, n=25):
    center = (12, 12, 12)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    corners = list(itertools.product((-1, 1), repeat=3))
    positions = [add(center, d, 1, n) for d in corners]
    if mode == "shuffled_same_inventory":
        offsets = [(1, 1, 1), (1, 1, -1), (1, -1, -1), (-1, 1, -1), (1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, 0, 1)]
        positions = [add(center, d, 1, n) for d in offsets]
    if mode == "missing_sensor_resource":
        positions = positions[:-1]
    semantic = 1 if mode == "nonpersistent_scaffold" else 4
    for i, q in enumerate(positions):
        raw[q] = pack(9000 + i, 3 + i, (0, 0, 0), semantic)
    raw[center] = pack(1, 1, (0, 0, 0), 7)
    world = NativeWorld(kernel, raw, clock)
    original_scaffold = [int(world.raw[q]) for q in positions]
    damage_ticks = [2 + 3 * i for i in range(cycles)]
    observations = []
    recovery_events = 0
    for tick in range(damage_ticks[-1] + 2):
        if tick in damage_ticks:
            before = record(world.raw, center)
            world.raw_a[center] = np.uint64(0); world.raw_b[center] = np.uint64(0)
            world.clock_a[center] = np.uint64(0); world.clock_b[center] = np.uint64(0)
            observations.append({"cycle": damage_ticks.index(tick), "damage_tick": tick, "before_damage": before})
        if tick < damage_ticks[-1] + 1:
            info = world.tick()
            if tick in damage_ticks:
                after = record(world.raw, center)
                observations[-1]["after_one_tick"] = after
                observations[-1]["recovered_exact"] = after is not None and after["state"] == 1 and after["s_reg"] == 1 and after["direction"] == [0, 0, 0] and after["semantic"] == 7
                observations[-1]["kernel_info"] = info
                recovery_events += int(observations[-1]["recovered_exact"])
    scaffold_after = [int(world.raw[q]) for q in positions]
    f = fields(world.raw)
    return {
        "mode": mode,
        "cycles": cycles,
        "recoveries": recovery_events,
        "recovery_rate": recovery_events / cycles,
        "observations": observations,
        "scaffold_raw_unchanged": scaffold_after == original_scaffold if semantic == 4 else False,
        "final_support": int(np.count_nonzero(world.raw)),
        "final_s_reg": int(f["sreg"].astype(np.uint64).sum()),
        "initial_scaffold_cells": len(positions),
    }


def learned_panel(kernel, mode, delta=-7, query=29, n=79):
    B, t_train, t_damage = 4096, 4, 12
    main_d, donor_d, redirect_d, query_d = (0, 1, 0), (1, 1, 0), (-1, 0, 0), (1, 0, 0)
    main_teacher, donor_teacher = (-1, 1, 0), (0, 1, 0)
    target = (40, 40, 40)
    pretarget = add(target, main_d, -1, n)
    main_j = add(target, main_d, -(t_damage - t_train), n)
    donor_j = add(pretarget, donor_d, -(t_damage - t_train), n)
    receiver = add(target, main_d, 8, n)
    query_tick = t_damage + 8 if mode == "no_damage" else t_damage + 9
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    x_main, x_donor = 23, 31
    place_for_arrival(raw, clock, main_j, t_train, (1, 0, 0), B - x_main, 101, n)
    place_for_arrival(raw, clock, main_j, t_train, main_teacher, x_main + delta, 102, n)
    donor_delta = delta
    if mode in {"wrong_donor", "label_shuffled_donor"}:
        donor_delta = delta + (13 if mode == "wrong_donor" else -11)
    if mode != "no_donor":
        place_for_arrival(raw, clock, donor_j, t_train, (1, 0, 0), B - x_donor, 201, n)
        place_for_arrival(raw, clock, donor_j, t_train, donor_teacher, x_donor + donor_delta, 202, n)
        redirect_target = add(pretarget, (0, 0, 1), 3, n) if mode == "offpath_donor" else pretarget
        place_for_arrival(raw, clock, redirect_target, t_damage, redirect_d, 0, 203, n)
    place_for_arrival(raw, clock, receiver, query_tick, query_d, query, 301, n)
    world = NativeWorld(kernel, raw, clock)
    events = {}
    for tick in range(query_tick + 1):
        if tick == t_train:
            events["main_trained"] = record(world.raw, main_j)
            events["donor_trained"] = record(world.raw, donor_j)
        if tick == t_train + 2 and mode == "memory_ablation":
            q = add(donor_j, donor_d, 2, n)
            prior = record(world.raw, q)
            events["ablated_memory"] = prior
            if prior:
                value = pack(prior["state"], 0, tuple(prior["direction"]), prior["semantic"])
                world.raw_a[q] = value; world.raw_b[q] = value
        if tick == t_damage:
            events["main_at_damage"] = record(world.raw, target)
            events["donor_at_gate"] = record(world.raw, pretarget)
            if mode != "no_damage":
                world.raw_a[target] = np.uint64(0); world.raw_b[target] = np.uint64(0)
                world.clock_a[target] = np.uint64(0); world.clock_b[target] = np.uint64(0)
            if mode == "actuator_direction_ablation" and int(world.raw[pretarget]):
                prior = record(world.raw, pretarget)
                value = pack(prior["state"], prior["s_reg"], (0, 0, 0), prior["semantic"])
                world.raw_a[pretarget] = value; world.raw_b[pretarget] = value
        if tick == t_damage + 1:
            events["post_damage_target"] = record(world.raw, target)
        if tick == query_tick:
            events["query_response"] = record(world.raw, receiver)
        if tick < query_tick:
            world.tick()
    response = events.get("query_response")
    decoded = None if response is None else response["s_reg"] - B
    exact = response is not None and response["direction"] == [1, 1, 0] and decoded == query + delta
    donor_payload = events.get("donor_trained")
    learned_donor = donor_payload is not None and donor_payload["s_reg"] == B + donor_delta and donor_payload["direction"] == list(donor_d)
    recovered_payload = events.get("post_damage_target")
    recovered_memory = recovered_payload is not None and recovered_payload["s_reg"] == B + delta and recovered_payload["direction"] == list(main_d)
    return {
        "mode": mode,
        "delta": delta,
        "donor_delta": donor_delta,
        "unseen_query": query,
        "query_tick": query_tick,
        "expected_decoded": query + delta,
        "decoded": decoded,
        "exact_function": exact,
        "donor_learned": learned_donor,
        "memory_recovered_one_tick": recovered_memory,
        "events": events,
    }


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    scaffold_modes = ["repeated_scaffold", "missing_sensor_resource", "shuffled_same_inventory", "nonpersistent_scaffold"]
    scaffold = [scaffold_panel(kernel, mode) for mode in scaffold_modes]
    learned_modes = ["no_damage", "repair_redundant", "no_donor", "wrong_donor", "label_shuffled_donor", "offpath_donor", "memory_ablation", "actuator_direction_ablation"]
    learned = [learned_panel(kernel, mode) for mode in learned_modes]
    primary = next(row for row in scaffold if row["mode"] == "repeated_scaffold")
    learned_primary = next(row for row in learned if row["mode"] == "repair_redundant")
    result = {
        "schema": "dee.v27.core08.c8d03.v1",
        "module_id": "C8D03_REGENERATION_DISCOVERY",
        "role": "DISCOVERY_EVIDENCE",
        "status": "COMPLETE",
        "kernel_environment": environment,
        "wall_clock_seconds": time.perf_counter() - started,
        "kernel_ticks": sum(row["cycles"] + 3 * row["cycles"] for row in scaffold) + sum(row["query_tick"] for row in learned),
        "scaffold_panels": scaffold,
        "learned_function_panels": learned,
        "signals": {
            "repeated_scaffold_recovery": primary["recovery_rate"] == 1.0 and primary["scaffold_raw_unchanged"],
            "learned_function_redundancy_recovery": learned_primary["exact_function"] and learned_primary["memory_recovered_one_tick"],
            "all_learned_controls_fail": all(not row["exact_function"] for row in learned if row["mode"] not in {"no_damage", "repair_redundant"}),
        },
        "interpretation": [
            "The semantic-4 scaffold is immutable under F_DEE and the empty-center XNOR guard creates a semantic-7 replacement; this is a fixed geometric homeostat, not learned repair.",
            "The redundant donor is written by the same ordinary cue+teacher collision as the main memory. Vacancy at a scheduled gate lets the donor reinstantiate the learned response with one-tick delay.",
            "The learned test is one repair episode and finite redundancy; it does not establish repeated learned-memory regeneration or resource renewal.",
        ],
        "next_decision": "Freeze separate C8H02 repeated fixed-scaffold regeneration and C8H03 learned functional repair holdouts; do not conflate their recovery levels.",
    }
    atomic_json(ROOT / "RESULTS" / "C8D03_regeneration_discovery.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D03", "status": "DISCOVERY", "signals": result["signals"], "next_action": result["next_decision"]})
    update_state(
        last_completed_experiment="C8D03_REGENERATION_DISCOVERY",
        complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03"],
        provisional=["repeated XNOR scaffold regeneration", "one-cycle learned-function repair by trained redundancy"],
        pending_holdout="C8H02,C8H03",
        next_action=result["next_decision"],
    )
    print(json.dumps({"scaffold": {r["mode"]: r["recovery_rate"] for r in scaffold}, "learned": {r["mode"]: {"exact": r["exact_function"], "memory_recovered": r["memory_recovered_one_tick"]} for r in learned}, "signals": result["signals"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
