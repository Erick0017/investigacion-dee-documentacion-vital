#!/usr/bin/env python3
"""Discovery refinement: causal diagnosis and lag-2 trained-redundancy repair."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, pack, unpack_scalar, update_state, verify_and_load_kernel


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def place(raw, clock, destination, tick, direction, sreg, state, n):
    q = add(destination, direction, -tick, n)
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, 1)
    clock[q] = np.uint64(1000 + state)


def read(raw, q):
    return unpack_scalar(raw[q]) if int(raw[q]) else None


def simulate(kernel, mode, delta, query, frame_shift=(0, 0, 0), n=83):
    B, t0, td = 4096, 4, 14
    M, D, R, Q = (0, 1, 0), (1, 1, 0), (-1, 0, 0), (1, 0, 0)
    T = tuple((42 + frame_shift[i]) % n for i in range(3))
    gate = add(T, M, -2, n)
    jm = add(T, M, -(td - t0), n)
    jd = add(gate, D, -(td - t0), n)
    receiver = add(T, M, 9, n)
    tq = td + 9 if mode == "no_damage" else td + 11
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    xm, xd = 19, 27
    place(raw, clock, jm, t0, (1, 0, 0), B - xm, 101, n)
    place(raw, clock, jm, t0, (-1, 1, 0), xm + delta, 102, n)
    donor_delta = delta + (17 if mode == "wrong_donor" else (-13 if mode == "label_shuffled_donor" else 0))
    if mode != "no_donor":
        place(raw, clock, jd, t0, (1, 0, 0), B - xd, 201, n)
        place(raw, clock, jd, t0, (0, 1, 0), xd + donor_delta, 202, n)
        redirect_target = add(gate, (0, 0, 1), 4, n) if mode == "offpath_donor" else gate
        place(raw, clock, redirect_target, td, R, 0, 203, n)
    place(raw, clock, receiver, tq, Q, query, 301, n)
    world = NativeWorld(kernel, raw, clock)
    events, trace = {}, []
    for tick in range(tq + 1):
        if tick >= td - 2 and tick <= td + 3:
            trace.append({"tick": tick, "main_target": read(world.raw, T), "gate": read(world.raw, gate), "gate_plus_one": read(world.raw, add(gate, M, 1, n))})
        if tick == t0:
            events["main_trained"] = read(world.raw, jm); events["donor_trained"] = read(world.raw, jd)
        if tick == t0 + 3 and mode == "memory_ablation":
            q = add(jd, D, 3, n); prior = read(world.raw, q); events["ablated_memory"] = prior
            if prior:
                value = pack(prior["state"], 0, tuple(prior["direction"]), prior["semantic"])
                world.raw_a[q] = value; world.raw_b[q] = value
        if tick == td:
            events["main_at_damage"] = read(world.raw, T); events["donor_at_gate"] = read(world.raw, gate)
            if mode != "no_damage":
                world.raw_a[T] = np.uint64(0); world.raw_b[T] = np.uint64(0)
                world.clock_a[T] = np.uint64(0); world.clock_b[T] = np.uint64(0)
            if mode == "actuator_direction_ablation" and int(world.raw[gate]):
                prior = read(world.raw, gate)
                value = pack(prior["state"], prior["s_reg"], (0, 0, 0), prior["semantic"])
                world.raw_a[gate] = value; world.raw_b[gate] = value
        if tick == td + 2:
            events["restored_at_target"] = read(world.raw, T)
        if tick == tq:
            events["response"] = read(world.raw, receiver)
        if tick < tq:
            world.tick()
    response = events.get("response")
    decoded = None if response is None else response["s_reg"] - B
    restored = events.get("restored_at_target")
    memory_restored = restored is not None and restored["s_reg"] == B + delta and restored["direction"] == list(M)
    exact = response is not None and response["direction"] == [1, 1, 0] and decoded == query + delta
    return {"mode": mode, "delta": delta, "donor_delta": donor_delta, "query": query, "decoded": decoded, "memory_restored": memory_restored, "exact_unseen_response": exact, "recovery_delay_ticks": 2, "events": events, "trace": trace}


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    modes = ["no_damage", "trained_redundancy", "no_donor", "wrong_donor", "label_shuffled_donor", "offpath_donor", "memory_ablation", "actuator_direction_ablation"]
    panels = [simulate(kernel, mode, -7, 29) for mode in modes]
    positive = next(row for row in panels if row["mode"] == "trained_redundancy")
    controls = [row for row in panels if row["mode"] not in {"no_damage", "trained_redundancy"}]
    result = {
        "schema": "dee.v27.core08.c8d04.v1",
        "module_id": "C8D04_LEARNED_REPAIR_REFINEMENT",
        "role": "DISCOVERY_EVIDENCE",
        "status": "COMPLETE",
        "kernel_environment": environment,
        "wall_clock_seconds": time.perf_counter() - started,
        "diagnosis_of_c8d03_failure": "A lag-1 donor cannot enter the gate because the intact leading carrier occupies that destination at the preceding update. Exclusion is itself the blocking mechanism.",
        "new_mechanism": "A lag-2 independently trained donor remains outside the leading carrier's Moore neighborhood, then re-instantiates the same learned payload after support deletion; the future unseen query is answered two ticks late.",
        "panels": panels,
        "signal": positive["memory_restored"] and positive["exact_unseen_response"] and all(not row["exact_unseen_response"] for row in controls),
        "scope": [
            "Functional recovery is achieved by finite trained redundancy, not reconstruction from the damaged carrier.",
            "The donor follows a pre-existing route; it does not detect damage and would trail the main carrier even without damage.",
            "Therefore this can support R5 functional recovery, but not R6 internally triggered learned repair or repeated learned-memory regeneration.",
        ],
        "next_decision": "Freeze C8H03 as R5 trained-redundancy functional recovery with explicit negative exclusions for R6/R7 learned repair.",
    }
    atomic_json(ROOT / "RESULTS" / "C8D04_learned_repair_refinement.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D04", "status": "DISCOVERY", "signal": result["signal"], "next_action": result["next_decision"]})
    update_state(
        last_completed_experiment="C8D04_LEARNED_REPAIR_REFINEMENT",
        complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04"],
        provisional=["R2/R6/R7 fixed-scaffold candidate", "R5 trained-redundancy candidate; not R6 learned repair"],
        pending_holdout="C8H02,C8H03",
        next_action=result["next_decision"],
    )
    print(json.dumps({"signal": result["signal"], "panels": {r["mode"]: {"restored": r["memory_restored"], "response": r["exact_unseen_response"], "decoded": r["decoded"]} for r in panels}}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
