#!/usr/bin/env python3
"""EXTRA03 discovery: projection aliases, boundary time codes and observer dependence."""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, fields, pack, unpack_scalar, update_state, verify_and_load_kernel


def projections(raw):
    f = fields(raw)
    channels = {"occupancy": (raw != 0).astype(np.int32), "s_reg": f["sreg"].astype(np.int64), "dx": f["dx"].astype(np.int64), "dy": f["dy"].astype(np.int64), "dz": f["dz"].astype(np.int64)}
    return {name: {"XY": values.sum(axis=2), "XZ": values.sum(axis=1), "YZ": values.sum(axis=0)} for name, values in channels.items()}


def projection_equal(pa, pb):
    return all(np.array_equal(pa[channel][view], pb[channel][view]) for channel in pa for view in pa[channel])


def parity_alias_panel(kernel, n=23):
    base = (11, 11, 11)
    even = [p for p in np.ndindex(2, 2, 2) if sum(p) % 2 == 0]
    odd = [p for p in np.ndindex(2, 2, 2) if sum(p) % 2 == 1]
    worlds = []
    target = base
    query = ((target[0] - 1) % n, target[1], target[2])
    for pattern in (even, odd):
        raw = np.zeros((n, n, n), dtype=np.uint64)
        for p in pattern:
            q = tuple(base[i] + p[i] for i in range(3))
            raw[q] = pack(100 + sum(p), 3, (0, 0, 0), 1)
        raw[query] = pack(999, 7, (1, 0, 0), 1)
        worlds.append(raw)
    initial_equal = projection_equal(projections(worlds[0]), projections(worlds[1]))
    wa, wb = NativeWorld(kernel, worlds[0]), NativeWorld(kernel, worlds[1])
    wa.tick(); wb.tick()
    ra = unpack_scalar(wa.raw[target]) if int(wa.raw[target]) else None
    rb = unpack_scalar(wb.raw[target]) if int(wb.raw[target]) else None
    return {
        "construction": "even/odd parity switch in a 2x2x2 interior block plus identical query carrier",
        "three_views_equal_for_occupancy_sreg_and_integrated_direction": initial_equal,
        "target": list(target),
        "next_target_even_world": ra,
        "next_target_odd_world": rb,
        "causal_intervention_prediction_differs": ra != rb,
        "conclusion": "three orthogonal integrated views are non-injective and not a sufficient observer for this one-step causal query",
    }


def single_view_depth_panel(kernel, n=23):
    xy = (7, 13)
    starts = [4, 9]
    rows = []
    initial_xy = []
    for index, z in enumerate(starts):
        raw = np.zeros((n, n, n), dtype=np.uint64)
        raw[xy[0], xy[1], z] = pack(1000 + index, 17, (0, 0, 1), 1)
        initial_xy.append(projections(raw)["occupancy"]["XY"])
        world = NativeWorld(kernel, raw)
        arrival = None
        trajectory = []
        for tick in range(n + 2):
            positions = np.argwhere(world.raw != 0)
            trajectory.append({"tick": tick, "positions": positions.tolist()})
            if int(world.raw[xy[0], xy[1], n - 1]) != 0 and arrival is None:
                arrival = tick
            if tick < n + 1:
                world.tick()
        rows.append({"start_depth": z, "boundary_arrival_tick": arrival, "expected": n - 1 - z, "trajectory": trajectory})
    return {"same_XY_projection": np.array_equal(initial_xy[0], initial_xy[1]), "rows": rows, "arrival_differs": rows[0]["boundary_arrival_tick"] != rows[1]["boundary_arrival_tick"]}


def boundary_code_world(kernel, n, seed):
    rng = np.random.default_rng(seed)
    coordinates = list(range(2, n - 2, 3))
    rays = [(x, y) for x in coordinates for y in coordinates]
    raw = np.zeros((n, n, n), dtype=np.uint64)
    truth = {}
    for index, (x, y) in enumerate(rays):
        z = int(rng.integers(1, n - 2))
        sreg = 10 + index
        raw[x, y, z] = pack(1000 + index, sreg, (0, 0, 1), 1)
        truth[f"{x},{y}"] = {"z": z, "s_reg": sreg, "arrival": n - 1 - z}
    world = NativeWorld(kernel, raw)
    events = []
    support_series = []
    xy_series = []
    for tick in range(n):
        active = np.argwhere(world.raw[:, :, n - 1] != 0)
        for x, y in active:
            events.append({"x": int(x), "y": int(y), "tick": tick, "s_reg": int((world.raw[int(x), int(y), n - 1] >> np.uint64(32)) & np.uint64(0xFFFF))})
        support_series.append(int(np.count_nonzero(world.raw)))
        xy_series.append(int(np.count_nonzero((world.raw != 0).sum(axis=2))))
        if tick < n - 1:
            world.tick()
    reconstruction = {f"{e['x']},{e['y']}": {"z": n - 1 - e["tick"], "s_reg": e["s_reg"]} for e in events}
    exact = len(reconstruction) == len(truth) and all(reconstruction[key] == {"z": value["z"], "s_reg": value["s_reg"]} for key, value in truth.items())
    shuffled_ticks = list(reversed([e["tick"] for e in events]))
    shuffled = {f"{e['x']},{e['y']}": n - 1 - shuffled_ticks[i] for i, e in enumerate(events)}
    shuffle_accuracy = sum(shuffled.get(key) == value["z"] for key, value in truth.items()) / len(truth)
    bits_per_event = 3 * math.ceil(math.log2(n)) + 16
    event_bits = len(events) * bits_per_event
    bulk_bits = n**3 * 64
    return {
        "n": n,
        "seed": seed,
        "rays": len(rays),
        "events": events,
        "exact_reconstruction": exact,
        "reconstruction_accuracy": sum(reconstruction.get(key) == {"z": value["z"], "s_reg": value["s_reg"]} for key, value in truth.items()) / len(truth),
        "time_shuffle_depth_accuracy": shuffle_accuracy,
        "event_code_bits": event_bits,
        "full_raw_bulk_bits": bulk_bits,
        "compression_ratio_vs_full_raw": bulk_bits / event_bits,
        "global_support_law": {"min": min(support_series), "max": max(support_series), "constant": len(set(support_series)) == 1},
        "XY_projection_law": {"min_active_pixels": min(xy_series), "max_active_pixels": max(xy_series), "stationary": len(set(xy_series)) == 1},
    }


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    parity = parity_alias_panel(kernel)
    depth = single_view_depth_panel(kernel)
    boundary = [boundary_code_world(kernel, n, 888000 + n) for n in (17, 23, 31)]
    log_n = np.log(np.asarray([r["n"] for r in boundary], dtype=float))
    log_k = np.log(np.asarray([r["rays"] for r in boundary], dtype=float))
    exponent = float(np.polyfit(log_n, log_k, 1)[0])
    result = {
        "schema": "dee.v27.core08.c8d05.v1",
        "module_id": "C8D05_DIMENSIONAL_OBSERVER_DISCOVERY",
        "role": "EXTRA03_DISCOVERY_EVIDENCE",
        "status": "COMPLETE",
        "kernel_environment": environment,
        "wall_clock_seconds": time.perf_counter() - started,
        "single_view_depth_alias": depth,
        "three_view_parity_alias": parity,
        "boundary_time_code": boundary,
        "empirical_ray_count_scaling_exponent": exponent,
        "exact_information_bounds": {
            "instantaneous_empty_boundary_aliases": "at least 2^((N-2)^3) binary interior supports share the same empty boundary snapshot",
            "finite_history_causal_limit": "with raw radius <=3 per tick, boundary history of duration T cannot distinguish center perturbations farther than 3T from the boundary",
            "area_history_cost": "an O(N^2) boundary sampled for O(N) ticks contains O(N^3) samples unless compressed by a restricted event law",
        },
        "multiple_observer_physics": {
            "same_ballistic_world": [
                {"observer": "full trajectory/path", "effective_law": "carrier advances one L_inf cell per tick"},
                {"observer": "XY integrated projection", "effective_law": "stationary footprint for motion along hidden z"},
                {"observer": "global support", "effective_law": "constant scalar"},
                {"observer": "z-boundary", "effective_law": "delayed one-tick pulse whose latency encodes depth"},
            ],
            "invariants": ["causal arrival order", "s_reg payload in collision-free transport", "finite propagation"],
        },
        "adjudication": {
            "single_view": "INSUFFICIENT",
            "three_integrated_views": "INSUFFICIENT_IN_GENERAL",
            "instantaneous_boundary": "INSUFFICIENT_IN_GENERAL",
            "boundary_history": "SUFFICIENT_CANDIDATE_FOR_COLLISION_FREE_ONE_CARRIER_PER_RAY_FAMILY",
            "holographic_like": "NOT_PROMOTED_DISCOVERY_ONLY",
        },
        "next_decision": "Freeze boundary event-code sufficiency in its restricted family and require equal-information time/location controls; retain full-3D counterexample for general worlds.",
    }
    atomic_json(ROOT / "RESULTS" / "C8D05_dimensional_observer_discovery.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D05", "status": "DISCOVERY", "adjudication": result["adjudication"], "next_action": result["next_decision"]})
    update_state(last_completed_experiment="C8D05_DIMENSIONAL_OBSERVER_DISCOVERY", complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04", "C8H02", "C8H03", "C8D05"], provisional=["boundary time-to-depth event code in collision-free ray family"], pending_holdout="C8H04_BOUNDARY_TIME_CODE", next_action=result["next_decision"])
    print(json.dumps({"single_view": {"same": depth["same_XY_projection"], "arrival_differs": depth["arrival_differs"]}, "three_view": parity, "boundary": [{k: r[k] for k in ("n", "rays", "exact_reconstruction", "time_shuffle_depth_accuracy", "compression_ratio_vs_full_raw")} for r in boundary], "ray_exponent": exponent}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
