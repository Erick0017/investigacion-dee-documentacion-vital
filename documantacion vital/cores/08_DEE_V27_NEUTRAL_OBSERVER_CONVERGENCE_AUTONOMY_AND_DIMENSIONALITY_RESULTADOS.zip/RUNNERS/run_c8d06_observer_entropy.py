#!/usr/bin/env python3
"""Discovery: clock/destination aliases and observer-dependent statistical laws."""
from __future__ import annotations

import collections
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, fields, pack, unpack_scalar, update_state, verify_and_load_kernel


def read(raw, q):
    return unpack_scalar(raw[q]) if int(raw[q]) else None


def entropy_counts(values):
    counter = collections.Counter(values)
    total = sum(counter.values())
    return -sum((n / total) * math.log2(n / total) for n in counter.values()) if total else 0.0


def binary_entropy(p):
    if p <= 0 or p >= 1:
        return 0.0
    return -p * math.log2(p) - (1 - p) * math.log2(1 - p)


def clock_alias(kernel):
    n, c = 13, (6, 6, 6)
    raw = np.zeros((n, n, n), dtype=np.uint64)
    raw[c] = pack(1, 10, (1, 0, 0), 1)
    for i, d in enumerate(((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))):
        q = tuple(c[j] + d[j] for j in range(3)); raw[q] = pack(10 + i, 1, (0, 0, 0), 1)
    ca = np.zeros_like(raw); cb = np.zeros_like(raw); ca[c] = np.uint64(0); cb[c] = np.uint64(1)
    wa, wb = NativeWorld(kernel, raw, ca), NativeWorld(kernel, raw, cb)
    wa.tick(); wb.tick()
    return {"raw_grid_identical_t0": True, "target_clock": [0, 1], "next_target": [read(wa.raw, c), read(wb.raw, c)], "future_raw_differs": int(wa.raw[c]) != int(wb.raw[c])}


def destination_guard_alias(kernel):
    n, target, source = 13, (6, 6, 6), (5, 6, 6)
    worlds = []
    for occupied in (False, True):
        raw = np.zeros((n, n, n), dtype=np.uint64); raw[source] = pack(77, 5, (1, 0, 0), 1)
        if occupied:
            raw[target] = pack(88, 3, (0, 0, 0), 1)
        world = NativeWorld(kernel, raw); world.tick(); worlds.append(read(world.raw, target))
    return {"proposal_edge_identical": "source->target", "destination_guard": ["void", "occupied"], "next_target": worlds, "future_differs": worlds[0] != worlds[1]}


def summary(raw):
    f = fields(raw); support = int(np.count_nonzero(raw)); total = raw.size
    return {"support": support, "s_reg": int(f["sreg"].astype(np.uint64).sum()), "occupancy_entropy": binary_entropy(support / total), "xy_active_pixels": int(np.count_nonzero((raw != 0).sum(axis=2))), "raw_unique_nonzero": int(len(np.unique(raw[raw != 0])))}


def ensemble(kernel, mode, worlds=12, n=10, k=20, ticks=12):
    trajectories = []
    directions = [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)]
    for seed in range(worlds):
        rng = np.random.default_rng(886000 + seed)
        raw = np.zeros((n, n, n), dtype=np.uint64)
        chosen = rng.choice(n**3, size=k, replace=False)
        for i, flat in enumerate(chosen):
            q = np.unravel_index(int(flat), raw.shape)
            d = (1, 0, 0) if mode == "aligned" else directions[int(rng.integers(0, len(directions)))]
            raw[q] = pack(1000 + i, int(rng.integers(1, 100)), d, 1)
        world = NativeWorld(kernel, raw); rows = []
        for tick in range(ticks + 1):
            rows.append(summary(world.raw))
            if tick < ticks: world.tick()
        trajectories.append(rows)
    ensemble_entropy = []
    for tick in range(ticks + 1):
        ensemble_entropy.append({"tick": tick, "H_support": entropy_counts([row[tick]["support"] for row in trajectories]), "H_support_sreg": entropy_counts([(row[tick]["support"], row[tick]["s_reg"]) for row in trajectories])})
    def noninc(key):
        return sum(all(rows[i + 1][key] <= rows[i][key] for i in range(ticks)) for rows in trajectories) / len(trajectories)
    return {"mode": mode, "worlds": worlds, "ticks": ticks, "support_nonincreasing_rate": noninc("support"), "s_reg_nonincreasing_rate": noninc("s_reg"), "occupancy_entropy_nonincreasing_rate": noninc("occupancy_entropy"), "ensemble_entropy": ensemble_entropy, "first_world_observers": trajectories[0]}


def main() -> int:
    started = time.perf_counter(); kernel, environment = verify_and_load_kernel(1)
    clock = clock_alias(kernel); guard = destination_guard_alias(kernel)
    ensembles = [ensemble(kernel, mode) for mode in ("mixed", "aligned")]
    result = {
        "schema": "dee.v27.core08.c8d06.v1", "module_id": "C8D06_OBSERVER_ENTROPY", "role": "DISCOVERY_EVIDENCE", "status": "COMPLETE",
        "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started, "worlds": 28, "kernel_ticks": 292,
        "clock_hidden_alias": clock, "destination_guard_alias": guard, "ensembles": ensembles,
        "adjudication": [
            "raw without clock is not globally Markov-sufficient",
            "proposal edges without destination guard are not sufficient",
            "the same deterministic microdynamics yields different apparent statistical laws under support, occupancy-entropy, projection and raw-diversity observers",
            "sectorial support/s_reg monotones remain internal bookkeeping, not physical energy or entropy",
        ],
        "thermodynamic_status": "OBSERVER_DEPENDENT_SECTORIAL_DISSIPATION; no conjugate variable, equilibrium protocol or fluctuation law",
    }
    atomic_json(ROOT / "RESULTS" / "C8D06_observer_entropy.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": "C8D06", "status": "DISCOVERY", "clock_alias": clock["future_raw_differs"], "destination_guard_alias": guard["future_differs"], "thermodynamic_status": result["thermodynamic_status"]})
    update_state(last_completed_experiment="C8D06_OBSERVER_ENTROPY", next_action="Perform the single adversarial audit and close documentation/package.")
    print(json.dumps({"clock": clock, "guard": guard, "ensemble_rates": [{k: v for k, v in row.items() if k.endswith("rate") or k == "mode"} for row in ensembles], "thermodynamic_status": result["thermodynamic_status"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
