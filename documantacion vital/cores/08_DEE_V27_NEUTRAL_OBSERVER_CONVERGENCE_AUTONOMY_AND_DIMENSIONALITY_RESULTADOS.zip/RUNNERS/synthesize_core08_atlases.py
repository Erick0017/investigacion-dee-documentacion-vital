#!/usr/bin/env python3
"""Synthesize observer, recovery, dimensional and neutral-convergence atlases."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, atomic_text, append_log, canonical_hash, sha256_file, update_state, utc_now


def load(name):
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def result_ref(name):
    path = ROOT / "RESULTS" / name
    return {"path": f"RESULTS/{name}", "sha256": sha256_file(path)}


def atlas_record(claim_id, name, family, status, evidence_type, source, domain, result, limits, dependencies, mapping="FORMAL_ONLY", priority="HIGH"):
    return {
        "claim_id": claim_id, "name": name, "family": family, "source": source["path"], "core_or_history": "CORE08",
        "source_sha256": source["sha256"], "kernel_version": "DEE v27", "evidence_type": evidence_type,
        "domain": domain, "preparation": source["path"], "observable": name, "intervention": "see exact runner/result",
        "controls": "see frozen lock or discovery result", "result": result, "status": status,
        "exact_or_empirical": "EXACT" if status in {"EXACT_THEOREM", "EXACT_SECTOR_LAW"} else "BOUNDED_EMPIRICAL",
        "holdout_status": "PASS" if "HOLDOUT" in evidence_type and result == "PASS" else ("FAIL" if "HOLDOUT" in evidence_type and result == "FAIL" else "NOT_APPLICABLE"),
        "known_limits": limits, "known_falsifiers": limits, "dependencies": dependencies,
        "outputs_produced": source["path"], "possible_inputs_to_other_modules": ["OBSERVER", "ROSETTA", "REPAIR", "DIMENSIONALITY"],
        "canonical_witness": claim_id.split(":")[-1], "runner": source["path"].replace("RESULTS/", "RUNNERS/"),
        "result_file": source["path"], "external_mapping_status": mapping, "current_priority": priority,
        "historical_claim": "NOT_APPLICABLE", "current_adjudication": result, "why_changed": "CORE08 new evidence",
    }


def main() -> int:
    # Correct a discovery-only analytic bound without changing any frozen holdout.
    d02_path = ROOT / "RESULTS" / "C8D02_guarded_observer_refinement.json"
    d02 = json.loads(d02_path.read_text(encoding="utf-8"))
    d02["exact_theorem"] = {
        "crystallization_branch_unreachable_under_v27_field_cap": True,
        "derivation": "Each of 26 Moore offsets contributes at most ||offset||_1*(P_KERNEL-1); sum ||offset||_1 over the neighborhood is 54. Thus grad_mag<=54*19664=1061856 and floor(grad_mag/19665)<=53<966.",
        "computed_max_integer_ratio": (54 * 19664) // 19665,
        "correction": "C8A01 corrected the earlier overly small 26*(cap) bound; the corrected valid upper bound leaves the theorem unchanged and predates no holdout claim using crystallization.",
    }
    d02["content_sha256"] = canonical_hash({k: v for k, v in d02.items() if k != "content_sha256"})
    atomic_json(d02_path, d02)

    h01, h02, h03, h06, d05, h04, h05 = (load(f"RESULTS/{name}") for name in (
        "C8H01_minimal_guarded_destination_observer.json", "C8H02_repeated_fixed_scaffold_regeneration.json",
        "C8H03_trained_redundancy_functional_recovery.json", "C8H06_leakage_free_trained_function_recovery.json", "C8D05_dimensional_observer_discovery.json",
        "C8H04_boundary_time_code.json", "C8H05_finite_size_boundary_code_law.json"))
    legacy_path = ROOT / "PARENTS" / "CORE07_EXTRACTED" / "LEGACY_EXTRACTS" / "DEE_CORPUS_INTEGRAL_VOLUMENES_1_A_7_Y_ATLAS_COMPLETO.txt"
    historical = {
        "schema": "dee.v27.core08.historical_repair_audit.v1", "module_id": "C8A02_HISTORICAL_REPAIR_REAUDIT", "status": "COMPLETE",
        "legacy_source": {"path": str(legacy_path), "sha256": sha256_file(legacy_path)},
        "authority_note": "Historical v24/v25 results are taxonomy evidence, not automatic transfer to v27. New v27 C8H02/H03 have priority in their own domains.",
        "records": [
            {"witness": "V12.2 MORPHCHANNELX", "kernel": "v24", "what_recovered": "damaged-coordinate occupancy: slab 38/42, cube 59/67, cross 31/44", "classification": ["R2_BOUNDED", "R4_TEMPLATE_ASSISTED"], "not_recovered": "exact internal state/fidelity; general object identity", "correction": "high partial refill was real, but semantic observer causality was not isolated"},
            {"witness": "V13.5 MORPHDAG135X", "kernel": "v24", "what_recovered": "boundary-dependent induced occupancy and local causal paths", "classification": ["R2_BOUNDED", "R4_BOUNDARY_ASSISTED"], "not_recovered": "unique microscopic morphogenetic cause", "correction": "first_specific_repair_tick=0 exposed contamination by initial mold occupancy"},
            {"witness": "V14.5 MORPHREPLAY/MORPHFACTOR", "kernel": "v24", "what_recovered": "V12.2 occupancy replay", "classification": ["R2_BOUNDED", "R4_TEMPLATE_ASSISTED"], "not_recovered": "observer-specific effect", "correction": "geometry explained most refill; observer label did not add occupancy over normal scaffold"},
            {"witness": "V15 MORPHFIDELITY15X", "kernel": "v24", "what_recovered": "occupancy", "classification": ["R2_BOUNDED"], "not_recovered": "internal fidelity", "correction": "observer won 0/18 fidelity comparisons"},
            {"witness": "V15.5 MORPHKERNEL155X", "kernel": "v24", "what_recovered": "occupancy dependent on boundary distance, porosity and orientation", "classification": ["R2_BOUNDED", "R4_GEOMETRIC"], "not_recovered": "general homeostasis or observer privilege", "correction": "72 trials; observer 0/18 exact-fidelity wins"},
            {"witness": "V19 collective phase/homeostasis", "kernel": "historical", "what_recovered": "connected regime/phase occupancy", "classification": ["R3_BASIN_REGIME_CANDIDATE"], "not_recovered": "finite object microidentity", "correction": "phase homeostasis and object repair are distinct"},
            {"witness": "V20 HOLISTICREPAIR20X", "kernel": "v25", "what_recovered": "none in tested architecture", "classification": ["NEGATIVE_TESTED_APPARATUS"], "not_recovered": "damaged state under free relaxation or persistent cue repair", "correction": "does not refute later macro-regime recovery"},
            {"witness": "Vol.5 D7 balanced_direction", "kernel": "v27", "what_recovered": "macro descriptors toward aged control after 5% random/compact damage", "classification": ["R3_BOUNDED"], "not_recovered": "microstate hash", "correction": "regime resilience, not bitwise self-repair or biological homeostasis"},
            {"witness": "CORE07 C7H03", "kernel": "v27", "what_recovered": "none after direction/load/support damage with delayed generic scaffold", "classification": ["NEGATIVE_TESTED_APPARATUS"], "not_recovered": "learned response in that apparatus", "correction": "bounded negative; does not cover XNOR scaffold or trained redundancy"},
            {"witness": "CORE08 C8H02", "kernel": "v27", "what_recovered": "exact center raw and fixed vacancy response in 320/320 cycles", "classification": ["R2", "R4", "R5_FIXED", "R6", "R7_BOUNDED"], "not_recovered": "learned memory, arbitrary morphology", "correction": "new exact-domain persistent-scaffold mechanism"},
            {"witness": "CORE08 C8H03", "kernel": "v27", "what_recovered": "runner produced 24/24 exact responses", "classification": ["FAIL_PROTOCOL_LEAKAGE", "SUPERSEDED"], "not_recovered": "confirmatory status", "correction": "2/24 query values equaled a training value; original result preserved but cannot certify all-unseen generalization"},
            {"witness": "CORE08 C8H06", "kernel": "v27", "what_recovered": "learned additive response on 18/18 explicitly disjoint queries", "classification": ["R5_TRAINED_REDUNDANCY"], "not_recovered": "endogenous damage detection or repeated memory regeneration", "correction": "new seeds/N and explicit disjointness replace, rather than repair, C8H03"},
        ],
    }
    atomic_json(ROOT / "RESULTS" / "C8A02_historical_repair_reaudit.json", historical)

    recovery = {
        "schema": "dee.v27.core08.recovery_taxonomy.v2", "status": "ADJUDICATED",
        "levels": {
            "R0": {"name": "DAMAGE_TOLERANCE", "status": "PASS", "evidence": ["historical compact/regime tolerance", "C8H02 no-damage stability"], "scope": "sectorial"},
            "R1": {"name": "PASSIVE_RELAXATION_RECOVERY", "status": "PASS", "evidence": ["Vol.5 D7 macro descriptors"], "scope": "v27 balanced_direction basin; not exact hash"},
            "R2": {"name": "MORPHOLOGICAL_REFILL", "status": "PASS", "evidence": ["V12.2-V15.5 historical", "C8H02 320/320 exact center cycles"], "scope": "geometry/scaffold dependent"},
            "R3": {"name": "BASIN_REGIME_RECOVERY", "status": "PASS", "evidence": ["Vol.5 D7"], "scope": "bounded v27 macro-descriptor domain"},
            "R4": {"name": "ASSISTED_RESTORATION", "status": "PASS", "evidence": ["historical template/boundary", "C8H02 persistent scaffold"], "scope": "assistance present from t0"},
            "R5": {"name": "FUNCTIONAL_RECOVERY", "status": "PASS", "evidence": ["C8H02 fixed vacancy function", "C8H06 learned response 18/18 disjoint holdout"], "scope": "fixed scaffold and finite trained redundancy; C8H03 superseded for leakage"},
            "R6": {"name": "INTERNALLY_TRIGGERED_REPAIR", "status": "PASS", "evidence": ["C8H02 XNOR vacancy guard"], "scope": "fixed center/scaffold; actuator and sensor are one guarded update and cannot be independently separated without kernel change"},
            "R7": {"name": "REPEATED_HOMEOSTATIC_REGENERATION", "status": "PASS", "evidence": ["C8H02 320/320 cycles"], "scope": "bounded immutable scaffold; not learned-memory regeneration, general homeostasis or biological autonomy"},
        },
        "nonimplication": "No R level promotes another outside its evidence domain.",
    }
    atomic_json(ROOT / "RECOVERY_TAXONOMY.json", recovery)

    autonomy = {
        "schema": "dee.v27.core08.autonomy_taxonomy.v2", "status": "ADJUDICATED",
        "vector": {"A0": "PASS", "A1": "PASS", "A2": "PASS", "A3": "PASS", "A4": "PASS", "A5": "PASS", "A6": "INCONCLUSIVE", "A7": "PASS"},
        "levels": {
            "A0": {"name": "SELF_EVOLUTION", "evidence": "F_DEE autonomous after preparation"},
            "A1": {"name": "ENDOGENOUS_MEMORY", "evidence": "CORE05 phase/history and CORE06 learning"},
            "A2": {"name": "INTERNAL_PROCESS_CHAIN", "evidence": "CORE05/07 internal chained carriers"},
            "A3": {"name": "CLOSED_CAUSAL_FEEDBACK", "evidence": "CORE07 one-pass sensor-memory-action return"},
            "A4": {"name": "REPEATED_CLOSED_LOOP", "evidence": "C8H02 vacancy->XNOR birth->occupied cessation repeated 10 times/world"},
            "A5": {"name": "SELF_MAINTENANCE", "evidence": "C8H02 single-site deletion maintained over 320 cycles"},
            "A6": {"name": "ADAPTIVE_AUTONOMY", "evidence": "learning exists, but no integrated loop learned a better repair/control policy", "status": "INCONCLUSIVE"},
            "A7": {"name": "RESOURCE_SUSTAINED_AUTONOMY", "evidence": "C8H02 all-t0 immutable scaffold sustains ten cycles without host action selection", "scope": "fixed XNOR sector; resource field is not depleted or independently identified"},
        },
        "caveat": "The vector components are separately adjudicated, not a proof of agency, life or a universal autonomy ladder.",
    }
    atomic_json(ROOT / "AUTONOMY_TAXONOMY.json", autonomy)

    observers = {
        "schema": "dee.v27.core08.observer_atlas.v2", "status": "ADJUDICATED",
        "metric": ["closure", "prediction", "compression", "cross-domain generalization", "interpretability"],
        "records": [
            {"id": "M_Q0", "representation": "full raw+clock", "task": "global exact one-step", "status": "SUFFICIENT_TRIVIAL", "compression": 1.0, "limits": "not reduced"},
            {"id": "M_RAW_ONLY", "representation": "full raw without clock", "task": "global one-step", "status": "INSUFFICIENT", "witness": "C8D06 identical raw grids with target clock 0/1 produce target s_reg 11/10"},
            {"id": "M_LOCAL", "representation": "instantaneous focal raw", "task": "incoming interaction", "status": "INSUFFICIENT", "witness": "same empty target, incoming vs none"},
            {"id": "M_INVENTORY", "representation": "global multiset of raw", "task": "next global support", "status": "INSUFFICIENT", "witness": "C8D01 collision versus separated destinations"},
            {"id": "M_ZUPDATE", "representation": "xnor_guard,sum_s,sign(sum_d)", "task": "void destination raw", "status": "HOLDOUT_CONFIRMED_INTERNAL", "skill": h01["rates"]["Z_update_exact_rate"], "compression": "~5 task coordinates instead of 26 raw+clock neighbors", "limits": h01["scope"]},
            {"id": "M_ZACCOUNT", "representation": "M_ZUPDATE+k", "task": "void destination raw plus multiplicity contraction", "status": "HOLDOUT_CONFIRMED_INTERNAL", "skill": h01["rates"]["Z_account_exact_rate"], "limits": "local fiber accounting only"},
            {"id": "M_XY", "representation": "single integrated 2D view", "task": "boundary-arrival prediction", "status": "INSUFFICIENT", "witness": "C8D05 depth alias"},
            {"id": "M_3VIEW", "representation": "XY+XZ+YZ integrated occupancy/s_reg/direction", "task": "one-step bulk causal query", "status": "INSUFFICIENT", "witness": "C8D05 parity-switch alias"},
            {"id": "M_BOUNDARY_T", "representation": "surface place+delay+s_reg event history", "task": "collision-free normal-ray state and future", "status": "HOLDOUT_CONFIRMED_INTERNAL_POST_FAILURE", "skill": h05["rates"]["reconstruction_rate"], "limits": h05["scope"]},
            {"id": "M_SEM4_XNOR", "representation": "persistent eight-corner physical scaffold", "task": "detect vacancy by endogenous branch response", "status": "HOLDOUT_CONFIRMED_INTERNAL", "skill": h02["rates"]["primary_cycle_recovery_rate"], "limits": h02["scope"]},
            {"id": "M_PROPOSAL_NO_GUARD", "representation": "proposal edges without destination occupancy/branch guard", "task": "next destination raw", "status": "INSUFFICIENT", "witness": "C8D06 same source->target edge, void versus occupied target, different future"},
        ],
        "answer": "There is no globally demonstrated reduced observer. The smallest useful confirmed observer is task-relative: M_ZUPDATE for a void destination; M_BOUNDARY_T for the restricted ray family. Cross-family prediction needs guard/topology/history coordinates and sometimes full Q0.",
    }
    atomic_json(ROOT / "OBSERVER_ATLAS.json", observers)

    dimension = {
        "schema": "dee.v27.core08.dimensionality_atlas.v2", "status": "ADJUDICATED",
        "coordinate_substrate": "3D periodic cubic lattice",
        "records": [
            {"id": "D_SINGLE", "representation": "one integrated 2D view", "status": "FULL_3D_REQUIRED_IN_TESTED_DOMAIN", "evidence": result_ref("C8D05_dimensional_observer_discovery.json")},
            {"id": "D_3VIEW", "representation": "three integrated orthogonal views", "status": "FULL_3D_REQUIRED_IN_TESTED_DOMAIN", "reason": "non-injective parity pair yields different causal query result"},
            {"id": "D_BOUNDARY", "representation": "boundary history event code", "status": "LOWER_DIMENSIONAL_EFFECTIVE_STATE", "domain": "one collision-free carrier per separated boundary-normal ray", "scaling": "K=ceil((N-4)/3)^2; event bits Theta(N^2 logN)", "evidence": result_ref("C8H05_finite_size_boundary_code_law.json")},
            {"id": "D_HOLOGRAPHIC", "status": "NO_HOLOGRAPHIC_LIKE_SIGNAL", "reason": "positive family has only area-indexed degrees; arbitrary interior has at least 2^((N-2)^3) states with one empty boundary snapshot; O(N) history yields O(N^3) samples"},
        ],
        "predecessor_fail": {"claim": "C8H04", "verdict": h04["verdict"], "reason": "naive finite-range exponent criterion failed", "preserved": True},
    }
    atomic_json(ROOT / "DIMENSIONALITY_ATLAS.json", dimension)

    phenomena = {
        "schema": "dee.v27.core08.neutral_phenomenon_atlas.v2", "status": "ADJUDICATED",
        "fingerprint_schema": ["preparation", "intervention", "detector", "readout", "causal_structure", "symmetry", "response_kernel", "scaling", "dimensionless_ratios", "recurrence", "relaxation", "path_dependence", "monotones", "fluctuations", "observer_dependence", "falsifiers"],
        "records": [
            {"id": "P08_01", "neutral_name": "guard-selected many-to-one destination update", "preparation": "void destination with directed neighbors", "intervention": "change occupancy symmetry or proposal fiber", "detector": "destination raw", "readout": "semantic,s_reg,direction", "causal_structure": "guard priority then reducer", "symmetry": "cubic opposite pairs and permutation-invariant sum", "response_kernel": "XNOR birth or capped additive/sign reducer", "scaling": "local", "dimensionless_ratios": ["k", "sum_s/cap"], "recurrence": "none required", "relaxation": "one tick", "path_dependence": "source positions through common destination", "monotones": "multiplicity contracts k->1 in reducer", "fluctuations": "deterministic", "observer_dependence": "inventory hides fiber", "falsifiers": "C8H01"},
            {"id": "P08_02", "neutral_name": "persistent symmetry-conditioned vacancy restoration", "preparation": "eight fixed corner records plus central record", "intervention": "delete center", "detector": "kernel vacuum guard", "readout": "semantic7 center", "causal_structure": "vacancy and opposite-pair symmetry trigger replacement", "symmetry": "cubic corner orbit", "response_kernel": "one-tick exact reset", "scaling": "local, repeated", "dimensionless_ratios": ["recovery_delay/cycle_interval=1/3"], "recurrence": "10 cycles tested", "relaxation": "one tick", "path_dependence": "none across cycles", "monotones": "scaffold invariant", "fluctuations": "zero in holdout", "observer_dependence": "functional identity differs from microhistory", "falsifiers": "C8H02"},
            {"id": "P08_03", "neutral_name": "surface delay/place encoding of hidden normal coordinate", "preparation": "separated normal carriers", "intervention": "vary depth", "detector": "boundary surface over time", "readout": "place,arrival,payload", "causal_structure": "ballistic first passage", "symmetry": "six cubic normals", "response_kernel": "depth=arrival delay", "scaling": "K=Theta(N^2), bits=Theta(N^2 logN)", "dimensionless_ratios": ["delta_depth/delta_delay=1"], "recurrence": "toroidal N", "relaxation": "none", "path_dependence": "collision-free", "monotones": "causal order", "fluctuations": "deterministic", "observer_dependence": "XY view stationary, boundary view pulsed", "falsifiers": "C8H05"},
            {"id": "P08_04", "neutral_name": "trained redundant response reinstantiation", "preparation": "two ordinary cue+teacher collisions", "intervention": "delete leading carrier", "detector": "unseen query collision", "readout": "q+delta", "causal_structure": "parallel histories with lag-2 replacement", "symmetry": "signed-permutation frames", "response_kernel": "exact additive repertoire", "scaling": "finite redundancy", "dimensionless_ratios": ["repair delay/transport tick=2"], "recurrence": "single episode", "relaxation": "none", "path_dependence": "training and route necessary", "monotones": "source-free support consumed", "fluctuations": "zero in holdout", "observer_dependence": "functional class survives, carrier identity does not", "falsifiers": "C8H03"},
        ],
    }
    atomic_json(ROOT / "NEUTRAL_PHENOMENON_ATLAS.json", phenomena)

    external_catalog = {
        "schema": "dee.v27.core08.external_neutral_catalog.v1", "matching_names_hidden": True,
        "sources": [
            {"masked_id": "E_A", "source": "NASA GLAS", "url": "https://science.gsfc.nasa.gov/attic/glas/human.html", "operational_fact": "distance is derived from propagation velocity and travel time; direction and platform position complete 3D localization"},
            {"masked_id": "E_A", "source": "NIST laser ranging", "url": "https://www.nist.gov/news-events/news/2014/10/nist-laser-comb-system-maps-3d-surfaces-remotely-manufacturing-forensics", "operational_fact": "LADAR uses return flight time/delay to calculate range"},
        ],
        "masked_fingerprints": {
            "E_A": {"causal": "propagation->detector delay->range", "response": "distance proportional to one-way delay, or half round-trip delay", "symmetry": "approximately directional Euclidean", "scaling": "linear", "parameters": 1, "unused_prediction_available": False},
            "E_B": {"causal": "multiple entities->single aggregate", "response": "extensive amount adds; identity count contracts", "symmetry": "exchange", "scaling": "additive", "parameters": 1, "unused_prediction_available": False},
            "E_C": {"causal": "damage+template/resources->restored function", "response": "bounded recovery", "symmetry": "apparatus dependent", "scaling": "cycle/resource dependent", "parameters": 2, "unused_prediction_available": False},
            "E_D": {"causal": "ensemble perturbation->relaxation", "response": "stationarity/fluctuation relation", "symmetry": "ensemble", "scaling": "extensive/intensive", "parameters": 2, "unused_prediction_available": False},
        },
        "reveal_map": {"E_A": "time-of-flight ranging family", "E_B": "coalescence/aggregation family", "E_C": "template-assisted restoration family", "E_D": "thermodynamic relaxation family"},
    }
    atomic_json(ROOT / "external" / "NEUTRAL_EXTERNAL_CATALOG.json", external_catalog)

    scores = [
        {"dee_id": "P08_03", "external_id": "E_A", "independent_relations": 6, "free_parameters": 1, "score": 0.82, "causal_structure_compatible": True, "promotion_frozen": False, "mismatches": ["DEE tested axes/cubic symmetry, external ranging is not restricted to cubic axes", "scale parameter is calibration", "no unused external row-level prediction"]},
        {"dee_id": "P08_01", "external_id": "E_B", "independent_relations": 3, "free_parameters": 1, "score": 0.55, "causal_match": False, "mismatches": ["DEE direction uses componentwise sign rather than conserved vector magnitude", "s_reg not externally identified"]},
        {"dee_id": "P08_02", "external_id": "E_C", "independent_relations": 4, "free_parameters": 2, "score": 0.48, "causal_match": False, "mismatches": ["fixed one-site template", "no learned target or depleted resource", "no external quantitative holdout"]},
        {"dee_id": "CORE06_DISSIPATIVE_ENSEMBLE", "external_id": "E_D", "independent_relations": 2, "free_parameters": 2, "score": 0.31, "causal_match": False, "mismatches": ["no equilibrium family", "no conjugate variable", "no fluctuation law"]},
    ]
    convergence = {
        "schema": "dee.v27.core08.convergence_candidates.v2", "status": "ADJUDICATED", "blind_protocol": "masked IDs scored on operational fingerprints before reveal; semantic names contributed zero",
        "ranked_candidates": scores,
        "adjudication": {
            "P08_03_to_E_A": "NEUTRAL_STRUCTURAL_MATCH / EXTERNAL_COMPATIBILITY (discovery); not promoted to CAUSAL_MATCH or EXTERNAL_PREDICTION because no external holdout was frozen and the linear delay law supplied the match",
            "P08_01_to_E_B": "FORMAL_SIMILARITY_ONLY",
            "P08_02_to_E_C": "ANALOGY_FUNCTIONAL_ONLY",
            "dissipation_to_E_D": "FORMAL_SIMILARITY_ONLY",
        },
        "external_validation": "No unused row-level external holdout was available that could test a non-calibrating DEE prediction. ROSETTA_VALIDATED remains false.",
    }
    atomic_json(ROOT / "CONVERGENCE_CANDIDATES.json", convergence)
    atomic_json(ROOT / "RESULTS" / "C8A03_neutral_convergence.json", {"schema": "dee.v27.core08.c8a03.v1", "module_id": "C8A03_NEUTRAL_CONVERGENCE", "status": "COMPLETE", "external_catalog": external_catalog, "convergence": convergence})

    protocols = {
        "Z_NEUTRAL_SCHEMA.json": {"schema": "dee.v27.core08.measurement_protocol.v1", "id": "Z_NEUTRAL", "fields": phenomena["fingerprint_schema"], "rule": "names hidden during primary match"},
        "MP01_GUARDED_DESTINATION.json": {"schema": "dee.v27.core08.measurement_protocol.v1", "id": "MP01", "preparation": "void destination+inbound fibers", "detector": "destination record", "readout": "branch,s_reg,direction", "source": "C8H01"},
        "MP02_REGENERATION.json": {"schema": "dee.v27.core08.measurement_protocol.v1", "id": "MP02", "preparation": "all-t0 scaffold+center", "intervention": "scheduled center deletion", "detector": "endogenous XNOR guard", "readout": "recovery delay,raw,scaffold hash", "source": "C8H02"},
        "MP03_BOUNDARY_DELAY.json": {"schema": "dee.v27.core08.measurement_protocol.v1", "id": "MP03", "preparation": "separated normal rays", "detector": "boundary history", "readout": "surface place+relative delay+payload", "source": "C8H05"},
        "MP04_EXTERNAL_TOF.json": {"schema": "dee.v27.core08.measurement_protocol.v1", "id": "MP04", "preparation": "emitter+target", "detector": "returned/received pulse", "readout": "delay converted to range", "status": "external structural reference; no DEE validation"},
    }
    for name, payload in protocols.items():
        atomic_json(ROOT / "MEASUREMENT_PROTOCOLS" / name, payload)

    synthesis = {
        "schema": "dee.v27.core08.cross_phenomenon_synthesis.v1", "module_id": "C8A04_CROSS_PHENOMENON_SYNTHESIS", "status": "COMPLETE",
        "minimal_common_mechanism": "guarded destination update",
        "operator": "void? -> (crystallization [provably unreachable at v27 cap], else XNOR topology guard, else inbound destination-fiber reducer, else void); occupied? -> topology/phase-dependent matter branch",
        "families_compressed": ["learning/readout collisions", "many-to-one loss", "fixed-scaffold regeneration", "carrier transport", "observer/detector response", "resource-sector split"],
        "missing_terms_for_global_closure": ["occupied-destination topology", "clock phase in incomplete matter", "semantic guards", "source/boundary conditions", "history for multi-tick prediction"],
        "major_result": "One local operator explains at least five previously separated families, but it is a branched sector law rather than a global Q4.",
    }
    atomic_json(ROOT / "RESULTS" / "C8A04_cross_phenomenon_synthesis.json", synthesis)

    atlas = load("UNIVERSAL_ATLAS_CORE08.json")
    new = [
        atlas_record("CORE08:C8_CRYSTALLIZATION_UNREACHABLE", "The crystallization vacuum branch is unreachable under the v27 s_reg cap", "KERNEL_THEORY", "EXACT_THEOREM", "STATIC_PROOF", result_ref("C8D02_guarded_observer_refinement.json"), "all v27 raw fields respecting 16-bit s_reg cap", "PROVEN", "implementation-specific; future kernel change can invalidate", []),
        atlas_record("CORE08:C8_GUARDED_DESTINATION_OBSERVER", "Z_update exactly predicts guarded void-destination raw", "OBSERVER", "EXACT_SECTOR_LAW", "FROZEN_HOLDOUT", result_ref("C8H01_minimal_guarded_destination_observer.json"), "void destination, semantic1 inbound sources", "PASS", h01["scope"], ["CORE07:C7_DESTINATION_FIBER_CAPACITY"]),
        atlas_record("CORE08:C8_REPEATED_SCAFFOLD_REGENERATION", "Persistent cubic scaffold regenerates exact center across repeated damage", "REPAIR_AUTONOMY", "HOLDOUT_CONFIRMED_INTERNAL", "FROZEN_HOLDOUT", result_ref("C8H02_repeated_fixed_scaffold_regeneration.json"), "eight semantic4 corners and central deletion", "PASS", h02["scope"], ["CORE08:C8_GUARDED_DESTINATION_OBSERVER"]),
        atlas_record("CORE08:C8_TRAINED_REDUNDANCY_RECOVERY", "C8H03 original trained-redundancy holdout", "REPAIR_LEARNING", "SUPERSEDED", "FROZEN_HOLDOUT_WITH_PROTOCOL_LEAKAGE", result_ref("C8H03_trained_redundancy_functional_recovery.json"), "additive normal-carrier memories", "FAIL_PROTOCOL_LEAKAGE", "2/24 queries overlapped training values; original runner PASS is not current adjudication", ["CORE07:C7_FUNCTIONAL_LEARNING_TRANSFER"]),
        atlas_record("CORE08:C8_H03_PROTOCOL_AUDIT", "Adversarial audit found query/training overlap in C8H03", "EPISTEMIC_AUDIT", "SUPERSEDED", "POST_HOLDOUT_PROTOCOL_AUDIT", result_ref("C8H06_leakage_free_trained_function_recovery.json"), "C8H03 query/training values", "FAIL_PROTOCOL_LEAKAGE", "does not negate the raw dynamics; it negates the original all-unseen promotion", ["CORE08:C8_TRAINED_REDUNDANCY_RECOVERY"]),
        atlas_record("CORE08:C8_TRAINED_REDUNDANCY_RECOVERY_H06", "Finite trained redundancy recovers learned response on explicitly disjoint queries", "REPAIR_LEARNING", "HOLDOUT_CONFIRMED_INTERNAL", "POST_AUDIT_FROZEN_HOLDOUT", result_ref("C8H06_leakage_free_trained_function_recovery.json"), "new N/seeds; 18 queries disjoint from both training values", "PASS", h06["scope"], ["CORE07:C7_FUNCTIONAL_LEARNING_TRANSFER", "CORE08:C8_TRAINED_REDUNDANCY_RECOVERY"]),
        atlas_record("CORE08:C8_THREE_VIEW_INSUFFICIENT", "Three orthogonal integrated views are not a sufficient causal observer in general", "DIMENSIONALITY", "BOUNDED_EMPIRICAL", "EXACT_COMBINATORIAL_WITNESS_PLUS_KERNEL", result_ref("C8D05_dimensional_observer_discovery.json"), "2x2x2 parity-switch support with common query", "PROVEN_COUNTEREXAMPLE", "rejects these projections, not every lower-dimensional representation", []),
        atlas_record("CORE08:C8_BOUNDARY_H04", "Naive finite-range area-exponent boundary code claim", "DIMENSIONALITY", "NEGATIVE_IN_TESTED_APPARATUS", "FROZEN_HOLDOUT", result_ref("C8H04_boundary_time_code.json"), "N=19,25,33,41", "FAIL", "reconstruction components passed; predeclared exponent failed and remains failed", [], priority="MEDIUM"),
        atlas_record("CORE08:C8_BOUNDARY_FINITE_LAW", "Boundary place-delay code closes collision-free area-indexed ray family", "DIMENSIONALITY", "HOLDOUT_CONFIRMED_INTERNAL", "POST_FAILURE_FROZEN_HOLDOUT", result_ref("C8H05_finite_size_boundary_code_law.json"), "new N=21,27,35,43,51", "PASS", h05["scope"], ["CORE08:C8_BOUNDARY_H04"]),
        atlas_record("CORE08:C8_NEUTRAL_TOF_MATCH", "DEE boundary delay/place protocol matches time-of-flight ranging causally", "ROSETTA", "EXTERNAL_COMPATIBILITY", "BLIND_FINGERPRINT_COMPARISON", result_ref("C8A03_neutral_convergence.json"), "protocol structure only", "EXTERNAL_COMPATIBILITY", "no unused external prediction; one scale calibration and symmetry mismatch", ["CORE08:C8_BOUNDARY_FINITE_LAW"], mapping="EXTERNAL_COMPATIBILITY"),
        atlas_record("CORE08:C8_OBSERVER_ENTROPY_DEPENDENCE", "Clock and destination guards are required beyond simpler raw/proposal observers; coarse statistical laws depend on observer", "OBSERVER_THERMODYNAMICS", "BOUNDED_EMPIRICAL", "KERNEL_DISCOVERY", result_ref("C8D06_observer_entropy.json"), "matched clock/guard witnesses and 24 source-free ensembles", "PROVEN_COUNTEREXAMPLES_AND_BOUNDED_STATISTICS", "no equilibrium, conjugate variable, fluctuation law or physical entropy identification", ["CORE01:X02", "CORE06:C06_DISSIPATIVE_ENSEMBLE_RELAXATION"]),
    ]
    for row in atlas["records"]:
        if row.get("claim_id") == "CORE08:C8_TRAINED_REDUNDANCY_RECOVERY":
            row.update(next(item for item in new if item["claim_id"] == row["claim_id"]))
    existing = {row["claim_id"] for row in atlas["records"]}
    atlas["records"].extend(row for row in new if row["claim_id"] not in existing)
    atlas["record_count"] = len(atlas["records"])
    atlas["schema"] = "dee.v27.core08.universal_atlas.v1"
    atlas["core08_updated_utc"] = utc_now()
    atomic_json(ROOT / "UNIVERSAL_ATLAS_CORE08.json", atlas)
    ledger_path = ROOT / "CLAIM_LEDGER_CORE08.ndjson"
    prior_lines = ledger_path.read_text(encoding="utf-8").splitlines()
    prior_ids = set()
    for line in prior_lines:
        try:
            prior_ids.add(json.loads(line).get("claim_id"))
        except json.JSONDecodeError:
            pass
    with ledger_path.open("a", encoding="utf-8", newline="\n") as stream:
        for row in new:
            if row["claim_id"] not in prior_ids:
                stream.write(json.dumps(row, separators=(",", ":"), ensure_ascii=False) + "\n")
    summary = {"schema": "dee.v27.core08.c8a01.v1", "module_id": "C8A01_ATLAS_SYNTHESIS", "status": "COMPLETE", "atlas_records": atlas["record_count"], "observer_records": len(observers["records"]), "phenomena": len(phenomena["records"]), "new_claims": len(new), "recovery_vector": {k: v["status"] for k, v in recovery["levels"].items()}, "autonomy_vector": autonomy["vector"], "neutral_top_match": scores[0], "unified_mechanism": synthesis["minimal_common_mechanism"]}
    atomic_json(ROOT / "RESULTS" / "C8A01_atlas_synthesis.json", summary)
    append_log({"event": "MODULES_COMPLETE", "module_ids": ["C8A01", "C8A02", "C8A03", "C8A04"], "status": "COMPLETE", "atlas_records": atlas["record_count"], "top_neutral_match": "P08_03->E_A EXTERNAL_COMPATIBILITY"})
    update_state(last_completed_experiment="C8A04_CROSS_PHENOMENON_SYNTHESIS", complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04", "C8H02", "C8H03", "C8D05", "C8H04_FAIL", "C8H05", "C8A01", "C8A02", "C8A03", "C8A04"], proven=["guarded destination observer sector", "repeated fixed-scaffold regeneration", "trained redundancy R5", "restricted boundary time code", "three-view insufficiency counterexample", "crystallization branch unreachable under v27 cap"], recovery_vector={k: v["status"] for k, v in recovery["levels"].items()}, autonomy_vector=autonomy["vector"], convergence_candidates=["boundary delay/place <-> time-of-flight ranging: EXTERNAL_COMPATIBILITY"], next_action="Run one adversarial observer/regeneration audit, then write final documents and package.")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
