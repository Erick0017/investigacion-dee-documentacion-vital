# Transversal CORE01–08

- CORE01 fijó Q0=`raw+clock`, causalidad y leyes exactas básicas.
- CORE02 separó estado predictivo de evento y formalizó fibras/roles.
- CORE03 confirmó Q2 de organización colectiva en dominio.
- CORE04 encontró histories productivas Q3 y negó cierre global compacto.
- CORE05 demostró observer/detector interno, delay-to-place y memoria de history.
- CORE06 confirmó aprendizaje nativo, generalización acotada, materia operacional y cinemática interna; Bell local CHSH=-2.
- CORE07 convirtió el programa en atlas, transfirió función aprendida y aisló el reductor común; su loop siguió one-pass.
- CORE08 mostró que la Rosetta puede ser un observador: guardas y relaciones determinan qué ley ve M; confirmó regeneración fija repetida, R5 aprendida por redundancia y un estado boundary-time restringido.

La arquitectura transversal más comprimida es: `(raw,clock) → guardas+propuestas → fibras/destino → reductor o nacimiento → lineages/history → organización → observer → medida`. Sigue siendo sectorial y multidimensional, no una pirámide Q0–Q4 universal.
