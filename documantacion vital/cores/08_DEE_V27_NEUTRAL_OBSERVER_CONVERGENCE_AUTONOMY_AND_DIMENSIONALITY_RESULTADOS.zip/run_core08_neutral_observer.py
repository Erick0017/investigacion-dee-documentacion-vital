#!/usr/bin/env python3
"""Idempotent/resumable master entry point for DEE v27 CORE08.

Valid atomic result files are skipped. Frozen locks are never regenerated or
refit. The command verifies the sealed CORE07/kernel identities before it can
run any scientific module.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNERS = ROOT / "RUNNERS"
IDENTITIES = {
    "PARENTS/07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip":
        "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f",
    "KERNEL/dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl":
        "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "KERNEL/wheel_extracted/dee_universe_v27/__init__.py":
        "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "KERNEL/wheel_extracted/dee_universe_v27/dee_kernel_v27.cp313-win_amd64.pyd":
        "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def valid_json(relative: str) -> bool:
    path = ROOT / relative
    if not path.is_file():
        return False
    try:
        json.loads(path.read_text(encoding="utf-8"))
        return True
    except (OSError, UnicodeError, json.JSONDecodeError):
        return False


def verify_identity() -> None:
    if sys.version_info[:2] != (3, 13):
        raise SystemExit(f"CORE08 reproduction requires CPython 3.13; got {sys.version}")
    for relative, expected in IDENTITIES.items():
        path = ROOT / relative
        if not path.is_file():
            raise SystemExit(f"SEALED IDENTITY MISSING: {relative}")
        observed = sha256(path)
        if observed != expected:
            raise SystemExit(f"SEALED IDENTITY MISMATCH {relative}: {observed} != {expected}")


MODULES = [
    ("C8A00", "RESULTS/C8A00_initial_audit.json", "initialize_core08.py"),
    ("C8D01", "RESULTS/C8D01_observer_family_discovery.json", "run_c8d01_observer_discovery.py"),
    ("C8D02", "RESULTS/C8D02_guarded_observer_refinement.json", "run_c8d02_guarded_observer_discovery.py"),
    ("C8H01", "RESULTS/C8H01_minimal_guarded_destination_observer.json", "run_c8h01_minimal_guarded_observer.py"),
    ("C8D03", "RESULTS/C8D03_regeneration_discovery.json", "run_c8d03_regeneration_discovery.py"),
    ("C8D04", "RESULTS/C8D04_learned_repair_refinement.json", "run_c8d04_learned_repair_refinement.py"),
    ("C8H02", "RESULTS/C8H02_repeated_fixed_scaffold_regeneration.json", "run_c8h02_repeated_scaffold_regeneration.py"),
    ("C8H03", "RESULTS/C8H03_trained_redundancy_functional_recovery.json", "run_c8h03_trained_redundancy_recovery.py"),
    ("C8D05", "RESULTS/C8D05_dimensional_observer_discovery.json", "run_c8d05_dimensional_observer_discovery.py"),
    ("C8H04", "RESULTS/C8H04_boundary_time_code.json", "run_c8h04_boundary_time_code.py"),
    ("C8H05", "RESULTS/C8H05_finite_size_boundary_code_law.json", "run_c8h05_finite_boundary_law.py"),
    ("C8D06", "RESULTS/C8D06_observer_entropy.json", "run_c8d06_observer_entropy.py"),
    ("C8H06", "RESULTS/C8H06_leakage_free_trained_function_recovery.json", "run_c8h06_leakage_free_recovery.py"),
    ("C8A01_A04", "RESULTS/C8A04_cross_phenomenon_synthesis.json", "synthesize_core08_atlases.py"),
    ("C8A05", "RESULTS/C8A05_adversarial_review.json", "adversarial_review.py"),
]


def run(runner: str, *arguments: str) -> None:
    subprocess.run([sys.executable, "-I", "-B", str(RUNNERS / runner), *arguments], cwd=ROOT, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--verify-only", action="store_true", help="verify identities, locks and completed results")
    parser.add_argument("--no-package", action="store_true", help="verify/run science without rebuilding the official ZIP")
    args = parser.parse_args()
    verify_identity()
    missing: list[str] = []
    for module_id, marker, runner in MODULES:
        if valid_json(marker):
            print(f"SKIP COMPLETE {module_id}: {marker}")
            continue
        missing.append(module_id)
        if args.verify_only:
            continue
        print(f"RUN {module_id}: {runner}", flush=True)
        run(runner)
        if not valid_json(marker):
            raise SystemExit(f"Runner completed without a valid atomic marker: {marker}")
    if args.verify_only:
        if missing:
            raise SystemExit("Missing/invalid modules: " + ", ".join(missing))
        run("build_core08_package.py", "--verify-payload-only")
        return 0
    state_ok = valid_json("STATE.json") and json.loads((ROOT / "STATE.json").read_text(encoding="utf-8")).get("status") == "COMPLETE"
    docs_ok = all((ROOT / name).is_file() for name in ("FINAL_REPORT.md", "EXECUTIVE_VERDICT.md", "FINAL_FRONTIER.md"))
    if state_ok and docs_ok:
        print("SKIP COMPLETE C8D07: final documents and stopping state")
    else:
        run("build_core08_documents.py")
    if not args.no_package:
        run("build_core08_package.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
