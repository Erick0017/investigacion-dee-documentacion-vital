# Autonomía adaptativa A6

## Aparato

Un carrier política elige uno de dos canales. Un sensor y un normalizador fijos entran por interfaces ordinarias. Si el puerto observado es incorrecto, el entorno fijo daña el centro del scaffold y añade valencia a la traza que retorna. La colisión cambia su direction; sin valencia la política persiste. No hay mensaje con la identidad de la acción correcta.

## Holdout

12 mundos primarios, `N=21,23,25`, seeds y marcos rotados/reflejados nuevos, 14 episodios cada uno. Accuracy=0.8571; adquisición posterior al primer episodio=1.0; reversal posterior al primer episodio=1.0; contextos no vistos=1.0; daños medios=2.0. Controles: equal exposure=0.500, memory ablation=0.500, reset=0.500, yoked=0.714, random=0.488, noncontingent=0.429, sensor shuffle=0.000.

## Adjudicación

Todos los gates preregistrados pasaron. `A6_CONFIRMED_BOUNDED_TWO_ACTION_RETURN_LINEAGE`. El resultado demuestra policy change dependiente de experiencia en este aparato; no conciencia, emoción, agente general ni autonomía de recursos.
