# Regeneración adaptativa

**Fast loop:** reparación XNOR fija, 1 tick, recovery=1.000, scaffold byte-invariante=1.000.

**Slow loop:** A6 reduce incidentes futuros mediante cambio de policy; no modifica el scaffold.

`ADAPTIVE_REPAIR_CANDIDATE=false`: la latencia no puede mejorar por debajo de un tick en este aparato, la probabilidad ya es 1.0 y no apareció reducción de coste del mecanismo. El resultado positivo correcto es adaptación para evitar daño, no reparación que aprende.
