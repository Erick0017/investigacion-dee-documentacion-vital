# Revisión adversarial final

- El lock externo precede la descarga de valores; el mapa tiene un solo parámetro y el final se abrió una vez.
- El resultado externo se conserva como FAIL; no se cambió observable, fase, threshold ni competidor.
- Python actúa como entorno fijo en A6: observa action port, no memoria; no inyecta label correcto.
- Los controles de memoria, reset, yoked, random, non-contingent, sensor shuffle y channel swap separan policy de repair/reflex.
- La robustez a typos se atribuye al encoder porque su kNN empata exactamente a DEE.
- El daño aleatorio y dirigido borra bits aprendidos; route damage prueba además accesibilidad.
- El scaffold selectivo es leakage y por eso el aparente refill no se promueve.
- `G_sub` se deriva de puertos ejecutados por F_DEE; se clasifica como algoritmo conocido y no como inteligencia emergente.
- Los ticks no se trataron como réplicas: eventos externos y mundos/seeds son las unidades independientes.
- Los dos fallos técnicos C9H03 ocurrieron antes de guardar resultados; se corrigieron remapeo local/serialización sin tocar el lock.
