# Descubrimientos nuevos de CORE09

1. **A6 binaria causal:** una consequence de valencia puede reescribir mediante F_DEE la direction de la traza de acción que retorna; esa traza gobierna la acción futura, generaliza a nuisances de contexto y revierte tras cambio de contingencia.
2. **Separación fast/slow:** homeostasis XNOR fija repara cada daño; aprendizaje reduce la incidencia de daño sin modificar reparación.
3. **Memoria one-shot 1000:** 31,298 carriers de training convergen en un tick a 15,649 bits relacionales aprendidos, exactamente como predice la fibra de destino.
4. **Resiliencia sin regeneración:** la memoria distribuida tolera borrado parcial, pero no se reconstruye sin que el scaffold contenga el soporte aprendido.
5. **Cociente algorítmico exacto:** un observer etiqueta×feature destila un subsistema nearest-prototype cuya aritmética F_DEE fue exacta en 100/100 ejecuciones.
6. **Negativo Rosetta cuantitativo:** una velocidad única no transfiere de P a S en tiempos de llegada sísmicos, pese a capturar parte de la ordenación por distancia.
