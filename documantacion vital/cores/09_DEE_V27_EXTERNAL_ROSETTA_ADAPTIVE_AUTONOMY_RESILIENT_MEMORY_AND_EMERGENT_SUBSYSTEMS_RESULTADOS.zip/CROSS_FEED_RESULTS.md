# Cross-feed

| Cruce | Resultado | Interpretación |
|---|---|---|
| adaptation × repair | positivo compuesto | slow policy reduce daños; fast XNOR repara |
| adaptation × resource | sistema abierto contabilizado | inputs externos explican aumento de carga |
| learning × regeneration | negativo | no scaffold no-leaking para memoria aprendida |
| subsystem × observer | cociente exacto | cierre de tarea, no global |
| subsystem × robust memory | positivo | degradación gradual bajo borrado, no repair |
| Rosetta × observer | FAIL externo | D09F01 demasiado pobre para P+S |

La compresión transversal más fuerte es `directed proposal → guarded destination reduction → persistent lineage/observer`. Explica tres familias —adaptación, memoria y cálculo efectivo—. La homeostasis XNOR pertenece a otra rama de guardia y sólo se compone externamente con ellas en el aparato probado.
