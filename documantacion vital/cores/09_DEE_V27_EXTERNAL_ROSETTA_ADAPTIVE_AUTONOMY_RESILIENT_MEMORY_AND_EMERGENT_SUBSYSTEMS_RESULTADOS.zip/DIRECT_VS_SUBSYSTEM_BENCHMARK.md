# Benchmark directo frente a subsistema

En typos mixtos, exact lookup=0.005, subsistema DEE=0.955, feature-kNN sin evolución=0.955, Levenshtein=1.000. El subsistema mejora la memoria exacta, pero no aporta robustez por encima del mismo observer de features y pierde contra un baseline especializado simple.

Task B, split fijo 80/20 de sinónimos: DEE=0.150; exact=0.000; Levenshtein=0.150; feature-1NN=0.100; ridge=0.250; MLP pequeño=0.200. Ningún resultado sustenta semántica.
