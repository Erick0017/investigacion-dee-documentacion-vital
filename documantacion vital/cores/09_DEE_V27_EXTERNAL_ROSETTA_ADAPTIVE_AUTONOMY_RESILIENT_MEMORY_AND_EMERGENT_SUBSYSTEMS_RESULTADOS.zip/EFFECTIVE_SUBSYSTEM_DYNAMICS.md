# Dinámica efectiva del subsistema

Sea `z[l,f]∈{0,1}` la ocupación aprendida del feature `f` para label `l`. Training one-shot ejecuta:

`z'[l,f] = OR(z[l,f], cue_f AND teacher_l)`

en el dominio de destinos vacíos y asociaciones únicas. Para query `q`, inference ejecuta en un tick:

`score_l(q)=Σ_{f∈E(q)} z[l,f]`

`prediction=argmax_l score_l(q)`.

La igualdad entre telemetría y `G_sub` fue exacta en 100 casos. La clausura es task-relative: presupone encoder, layout, destinos y lectura congelados. El route-damage negativo prueba que `z` como matriz de bits no basta si se destruye su implementación relacional.
