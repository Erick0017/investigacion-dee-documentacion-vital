# CORE09 — veredicto ejecutivo

CORE09 produjo un positivo central, varios positivos acotados y negativos decisivos.

**A6 quedó confirmada en un aparato de dos acciones.** En 12 mundos holdout nuevos (`N=21,23,25`), la política contingente obtuvo accuracy media 0.857; después del primer error de adquisición y del primer error de reversal alcanzó 1.000, y generalizó a contextos `s_reg` no vistos con 1.000. `memory ablation`, `reset`, `equal exposure` y `fixed reflex` quedaron en 0.500; la contingencia aleatoria en 0.488; la señal no contingente en 0.429. El carrier de acción que retorna es simultáneamente traza de decisión y política persistente. Esto es `A6_CONFIRMED_BOUNDED`, no conciencia ni agencia general.

La composición fast/slow también quedó delimitada: el scaffold XNOR fijo reparó todos los daños en un tick, mientras la política aprendida redujo los daños a 2.0 por 14 episodios. No apareció aprendizaje de la propia reparación: la latencia siguió en el mínimo discreto de un tick y el scaffold no cambió. El sistema es un aparato funcionalmente integrado y abierto a carriers del entorno, no un organismo autosuficiente.

La Rosetta externa R09_01 falló bajo su protocolo congelado. Una sola escala ajustada exclusivamente a P predijo en el holdout final P con medAPE 0.103 y S —no usada en calibración— con 0.501; el competidor estándar obtuvo 0.015. El mapa de velocidad única conserva orden y vence el null de distancia permutada, pero no la estructura cuantitativa de tiempos terrestres. `ROSETTA_VALIDATED=false`.

EXTRA04 confirmó memoria one-shot causal de 1000 asociaciones: 1 tick de entrenamiento, 100% en 200 consultas limpias, 0% con labels barajados y 0% tras ablación total. Tras daño aleatorio del 15% conservó 0.930. En typos mixtos obtuvo 0.955, exactamente igual al kNN del encoder, por lo que no hay ventaja DEE; Levenshtein obtuvo 1.000. El intento de regenerar memoria aprendida falló sin fuga.

EXTRA05 encontró un subsistema efectivo **conocido**: el observer `z=matriz etiqueta×feature` y el reductor de fibras ejecutan exactamente un clasificador por intersección/nearest-prototype en 100/100 auditorías. Es una demostración de microdinámica→cociente→algoritmo efectivo, no superioridad computacional ni semántica.
