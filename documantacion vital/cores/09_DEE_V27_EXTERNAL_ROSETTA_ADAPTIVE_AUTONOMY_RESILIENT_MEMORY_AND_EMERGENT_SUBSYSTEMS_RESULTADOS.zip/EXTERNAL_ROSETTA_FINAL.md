# Rosetta externa — adjudicación final

## Secuencia protegida

`DEE_NEUTRAL_FINGERPRINTS.json` se congeló antes de leer valores externos. Se eligió D09F01 por estructura experimental disponible: fuente, detector, distancia, tiempo de llegada, dos familias de fase y unidad independiente por evento. El lock C9H01 se hasheó antes de descargar filas. Una única escala `alpha=0.083276654892 s/km` se ajustó en 13031 P de calibration, con intercepto cero. El mapa se volvió a congelar antes de abrir final.

## Predicción reservada

`t_hat=alpha·distance` se aplicó sin refit a P y a S. En 6505 picks finales: P medAPE=0.1027, p90=0.2498; S medAPE=0.5015, p90=0.5968. El competidor phase-specific de calibración obtuvo medAPE=0.0153. El null de distancia permutada obtuvo 0.3942.

## Veredicto

`EXTERNAL_ROSETTA_NOT_FOUND_UNDER_CORE09_PROTOCOL`. Pasaron suficiencia de muestra y null de distancia; fallaron accuracy P/S, cola y competidor. D09F01 conserva una relación ordinal de tránsito, pero el cociente de velocidad única omite familia de fase y estructura de trayectoria. No hay `EXTERNAL_PREDICTION`, `ROSETTA_VALIDATED` ni `MULTI_OBSERVABLE_ROSETTA`.
