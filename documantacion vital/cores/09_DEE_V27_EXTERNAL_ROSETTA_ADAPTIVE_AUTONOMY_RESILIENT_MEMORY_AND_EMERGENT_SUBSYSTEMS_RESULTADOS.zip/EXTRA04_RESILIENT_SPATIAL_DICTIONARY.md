# EXTRA04 — memoria simbólica espacial resiliente

El encoder label-blind hashea boundary/unigrams/bigrams en 64 features. Cada asociación cue+teacher se presenta una vez y el kernel realiza una actualización. A 1000 asociaciones: training support 31298→15649, exactitud kernel del estado esperado=true, wall time=1.176s. La muestra reservada limpia obtuvo 1.000; label-shuffle=0.000; memory-ablation=0.000.

Typo mixed: DEE=0.955; feature-kNN=0.955; Levenshtein=1.000. Por tanto `TYPO_ROBUSTNESS_FOUND=false` y `ENCODER_MEDIATED_TYPO_ROBUSTNESS=true`.

Daño aleatorio 15%: accuracy=0.930; daño contiguo 15%=0.995; daño de rutas produce 0.0 desde 5%, aunque conserva los bits. Esto distingue contenido de accesibilidad causal.

La reparación aprendida no pasó: scaffold universal pierde selectividad; scaffold selectivo filtra el patrón a restaurar. Task B obtuvo 0.150; los baselines post-hoc exact/Levenshtein/1NN/linear/MLP fueron {'exact_lookup': 0.0, 'feature_1nn': 0.1, 'levenshtein_nearest_word': 0.15, 'ridge_linear': 0.25, 'small_mlp_24_hidden': 0.2}. No hay comprensión semántica, candidatura competitiva ni superioridad.
