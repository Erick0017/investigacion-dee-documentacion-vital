# EXTRA05 — subsistema computacional efectivo

ARM A construyó una arquitectura congelada de memory banks espaciales, encoder label-blind y puertos reductores. En training, cue+teacher colisionan en un destino y depositan un bit etiqueta×feature. En inference, cada feature de query propone a los destinos de etiqueta; F_DEE suma `s_reg` y el readout toma argmax.

La ejecución del kernel coincidió exactamente con la ecuación reducida en 100/100 consultas auditadas. Esto pasa `KNOWN_EFFECTIVE_SUBSYSTEM_FOUND`: una capa observadora tiene una ley algorítmica distinta y útil respecto al raw. No pasa `COMPETITIVE_SYMBOLIC_MEMORY_CANDIDATE` ni `SUPERIORITY_CANDIDATE`; el algoritmo destilado es nearest-prototype y un control simple con el mismo encoder produce idénticos scores.

ARM B no produjo una arquitectura nativa independiente antes del stopping rule. No se justificó search adicional después de identificar completamente el mecanismo y el baseline equivalente.
