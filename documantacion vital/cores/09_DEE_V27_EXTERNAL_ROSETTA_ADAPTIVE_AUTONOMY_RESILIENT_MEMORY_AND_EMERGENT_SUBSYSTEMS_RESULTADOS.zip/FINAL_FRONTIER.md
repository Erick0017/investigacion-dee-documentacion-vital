# Frontera final CORE09

## EXTERNAL_DATA_REQUIRED

Otra Rosetta sólo es justificable para un fingerprint DEE distinto, con protocolo row-level y observable reservado. R09_01 no debe refitearse.

## NEW_THEORY_REQUIRED

Un observer global debe incorporar guardas, destinos ocupados, semantic, clock/phase, source y history. CORE09 sólo cerró observers relativos a tarea.

## NEW_KERNEL_OR_ARCHITECTURE_REQUIRED

Regeneración de memoria aprendida sin fuga requiere un proceso que detecte/discrimine qué patrón restaurar sin que el soporte target esté precodificado. Una entidad autosuficiente requeriría resource accounting cerrado y fronteras internas.

## CLOSED_NEGATIVE

Una-velocidad P+S; ventaja DEE para typos con este encoder; semántica del Task B; learned-memory regeneration con scaffolds universal/selectivo; superioridad del subsistema construido.

## STOPPING RULE

Cada rama prioritaria recibió una prueba informativa y controles. Extenderlas ahora implicaría cambiar el mecanismo después del holdout o repetir variantes sin nueva predicción. No se crea CORE10 automáticamente.
