# Predicciones multiobservable

R09_01 calibró sólo P y reservó S como segundo observable. La misma escala falló ambos umbrales, con un error especialmente grande en S. Por ello no se promueve a Rosetta multiobservable.

C9H02 sí predijo internamente varias lecturas con un mismo mecanismo —acción, daño, reversal, generalización y estado de memoria— pero son observables DEE internos, no validación física externa.

C9H03 predijo clean recall, corrupción y daño con el mismo estado `z`; sin embargo el éxito en corrupción es replicado por el observer/encoder sin evolución DEE. Sólo storage y reducción causal se atribuyen al kernel.
