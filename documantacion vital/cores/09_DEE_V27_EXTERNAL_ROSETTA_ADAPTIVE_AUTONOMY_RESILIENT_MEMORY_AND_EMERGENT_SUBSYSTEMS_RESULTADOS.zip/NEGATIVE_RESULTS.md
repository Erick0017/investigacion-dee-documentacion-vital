# Resultados negativos

- R09_01: FAIL externo del mapa de una velocidad/una escala para P+S.
- No `ROSETTA_VALIDATED`, `MULTI_OBSERVABLE_ROSETTA` ni cross-domain Rosetta.
- No mejora DEE sobre el encoder-kNN en typos; Levenshtein es mejor.
- No regeneración autónoma no-leaking de memoria aprendida.
- No reparación adaptativa: el scaffold y la latencia permanecen fijos.
- No semántica en Task B; resultados cercanos a chance.
- No superioridad ni competitividad del subsistema frente a baselines simples.
- No entidad autosuficiente ni resource cycle cerrado.
- No Q4/global low-dimensional closure nuevo.

Cada negativo es relativo a su aparato y dominio; ninguno se amplía a una imposibilidad ontológica no demostrada.
