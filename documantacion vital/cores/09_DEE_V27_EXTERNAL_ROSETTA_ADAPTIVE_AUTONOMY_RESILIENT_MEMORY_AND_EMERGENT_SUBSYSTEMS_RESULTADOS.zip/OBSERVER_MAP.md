# Mapa de observadores

## D09F01

Detector DEE: first-arrival/delay observer. Readout: demora hasta detección ordenada. La predicción externa usa exactamente esta demora, no `raw`, `clock` o `direction` como nombres físicos. El FAIL muestra que este observer es demasiado pobre para P+S terrestres con una sola escala.

## A6

Observer del agente: dos puertos físicos de acción. Python observa únicamente el puerto y aplica una regla ambiental congelada; no inspecciona la memoria. La traza que regresa al centro es estado causal, no readout externo entrenado.

## Subsistema simbólico

`M_sub(X)=z[label,feature]`, presencia en destinos de memoria. El output son diez/cien/mil reducciones de intersección leídas en puertos congelados. `M_sub` es suficiente para la tarea declarada y no se reclama suficiente para F_DEE global.
