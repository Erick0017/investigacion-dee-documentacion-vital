# Mapa de preparación R09_01

External preparation: origen de evento asociado, profundidad y estación activa. Distancia: raíz de la suma de (arco great-circle con radio medio WGS84)^2 y profundidad^2. Registros ambiguos de estación se excluyen; `0<travel_time<2000 s`.

Mapa DEE congelado: distancia fuente–detector externa → longitud de trayecto L_inf en el límite de escala. No se construyó un mundo DEE distinto por pick: se transfirió el fingerprint D09F01 ya demostrado, cuya predicción neutral es demora lineal con una velocidad operacional. Calibración permitida: una escala global; offset=0; sin parámetros por fase/evento.

El split por SHA256 del event key (60/20/20) impide que picks del mismo terremoto crucen calibration/validation/final.
