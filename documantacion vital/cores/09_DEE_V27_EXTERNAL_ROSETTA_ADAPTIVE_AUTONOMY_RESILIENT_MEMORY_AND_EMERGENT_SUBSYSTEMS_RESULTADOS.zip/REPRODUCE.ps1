param(
    [string]$Python = "D:\Descargas\ANACONDA MINICONDA\python.exe",
    [switch]$BuildPackage
)

$ErrorActionPreference = "Stop"
$arguments = @("-I", "-B", ".\run_core09_external_rosetta_adaptation.py")
if ($BuildPackage) { $arguments += "--build-package" }
& $Python @arguments
if ($LASTEXITCODE -ne 0) { throw "CORE09 reproduction failed with exit code $LASTEXITCODE" }
