# Auditoría retrospectiva de adaptación

El barrido CORE05–08 encontró 5 líneas relevantes, pero ninguna promovible a A6: CORE06 probó plasticidad/learning sin un ciclo de consecuencia; CORE07 probó una cadena A3 one-pass; CORE08 probó homeostasis de scaffold fijo. Las curvas antiguas no contenían reversal+generalization con consecuencia contingente y controles causales completos. La señal retrospectiva se mantuvo como discovery y C9H02 usó mundos nuevos.
