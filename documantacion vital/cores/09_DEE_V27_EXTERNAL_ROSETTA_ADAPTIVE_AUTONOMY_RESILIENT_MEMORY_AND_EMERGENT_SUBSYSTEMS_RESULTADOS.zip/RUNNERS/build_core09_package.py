"""Build, validate, publish, and index the official CORE09 artifact."""

from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT.parent
OUTPUT = ROOT / "output"
PACKAGE_NAME = "09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip"
PACKAGE = OUTPUT / PACKAGE_NAME
EXPEDIENTE = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE"
OFFICIAL = EXPEDIENTE / "CORE" / PACKAGE_NAME
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core09_common import atomic_json, atomic_text, sha256_file, update_state, utc_now  # noqa: E402


ROOT_FILES = [
    "EXECUTIVE_VERDICT.md", "FINAL_REPORT.md", "TRANSVERSAL_CORE01_TO_09.md",
    "CORE09_NEW_DISCOVERIES.md", "EXTERNAL_ROSETTA_FINAL.md",
    "ROSETTA_CANDIDATE_REGISTRY.json", "EXTERNAL_DATA_REGISTRY.json",
    "ROSETTA_VALIDATION_LEDGER.json", "DEE_NEUTRAL_FINGERPRINTS.json",
    "PREPARATION_MAP.md", "OBSERVER_MAP.md", "MULTI_OBSERVABLE_PREDICTIONS.md",
    "ADAPTIVE_AUTONOMY_A6.md", "RETROSPECTIVE_ADAPTATION_AUDIT.md",
    "SURVIVAL_LOOP.md", "ADAPTIVE_REGENERATION.md", "LEARNING_CURVES.json",
    "REVERSAL_GENERALIZATION.json", "EXTRA04_RESILIENT_SPATIAL_DICTIONARY.md",
    "DICTIONARY_BENCHMARK.json", "EXTRA05_EMERGENT_SUBSYSTEM.md",
    "EFFECTIVE_SUBSYSTEM_DYNAMICS.md", "DIRECT_VS_SUBSYSTEM_BENCHMARK.md",
    "CROSS_FEED_RESULTS.md", "NEGATIVE_RESULTS.md", "ADVERSARIAL_REVIEW.md",
    "FINAL_FRONTIER.md", "CLAIMS_CORE09.json", "PARENT_CHAIN.json", "STATE.json",
    "SCIENCE_LOG.ndjson", "REPRODUCE.ps1", "run_core09_external_rosetta_adaptation.py",
]


def payload() -> list[tuple[Path, str]]:
    rows: list[tuple[Path, str]] = []
    for name in ROOT_FILES:
        path = ROOT / name
        if not path.is_file():
            raise FileNotFoundError(path)
        rows.append((path, name))
    for directory in ("HOLDOUT_LOCKS", "RESULTS", "RUNNERS", "KERNEL"):
        for path in sorted((ROOT / directory).rglob("*")):
            if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
                rows.append((path, path.relative_to(ROOT).as_posix()))
    external = ROOT / "external_data"
    for path in sorted(external.rglob("*")):
        if path.is_file():
            rows.append((path, "EXTERNAL_DATA/" + path.relative_to(external).as_posix()))
    parent = ROOT / "PARENTS" / "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip"
    rows.append((parent, "PARENTS/" + parent.name))
    seen: set[str] = set()
    for _, arcname in rows:
        if arcname in seen:
            raise RuntimeError(f"duplicate archive path {arcname}")
        seen.add(arcname)
    return sorted(rows, key=lambda row: row[1])


def validate_science() -> None:
    required = [
        "RESULTS/C9H01_external_travel_time_rosetta.json",
        "RESULTS/C9H02_adaptive_policy_A6.json",
        "RESULTS/C9H03_symbolic_memory_and_subsystem.json",
        "RESULTS/C9A05_adversarial_review.json",
    ]
    for name in required:
        value = json.loads((ROOT / name).read_text(encoding="utf-8"))
        if value.get("status") != "COMPLETE":
            raise RuntimeError(f"incomplete scientific module: {name}")
    state = json.loads((ROOT / "STATE.json").read_text(encoding="utf-8"))
    if state.get("pending_holdout") is not None:
        raise RuntimeError("pending holdout remains")


def write_manifest(rows: list[tuple[Path, str]]) -> None:
    entries = [{"path": arc, "bytes": path.stat().st_size, "sha256": sha256_file(path)} for path, arc in rows]
    manifest = {
        "schema": "dee.v27.core09.manifest.v1",
        "generated_utc": utc_now(),
        "package": PACKAGE_NAME,
        "payload_scope": "All entries except MANIFEST.json and HASHES.sha256",
        "entries": entries,
        "count": len(entries),
    }
    atomic_json(ROOT / "MANIFEST.json", manifest)
    hash_lines = [f"{entry['sha256']}  {entry['path']}" for entry in entries]
    hash_lines.append(f"{sha256_file(ROOT / 'MANIFEST.json')}  MANIFEST.json")
    atomic_text(ROOT / "HASHES.sha256", "\n".join(hash_lines) + "\n")


def build_zip(rows: list[tuple[Path, str]]) -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    temporary = PACKAGE.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for path, arcname in rows:
            archive.write(path, arcname)
        archive.write(ROOT / "MANIFEST.json", "MANIFEST.json")
        archive.write(ROOT / "HASHES.sha256", "HASHES.sha256")
    os.replace(temporary, PACKAGE)


def validate_zip(rows: list[tuple[Path, str]]) -> dict:
    expected = {arc: sha256_file(path) for path, arc in rows}
    expected["MANIFEST.json"] = sha256_file(ROOT / "MANIFEST.json")
    expected["HASHES.sha256"] = sha256_file(ROOT / "HASHES.sha256")
    with zipfile.ZipFile(PACKAGE) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)) or set(names) != set(expected):
            raise RuntimeError("ZIP inventory mismatch")
        observed = {name: hashlib.sha256(archive.read(name)).hexdigest() for name in names}
        bad = {name: (observed.get(name), digest) for name, digest in expected.items() if observed.get(name) != digest}
        if bad:
            raise RuntimeError(f"ZIP content mismatch: {bad}")
        if archive.testzip() is not None:
            raise RuntimeError("ZIP CRC failure")
    return {"files": len(expected), "bytes": PACKAGE.stat().st_size, "sha256": sha256_file(PACKAGE)}


def publish_and_index(package_hash: str) -> None:
    OFFICIAL.parent.mkdir(parents=True, exist_ok=True)
    if OFFICIAL.exists() and sha256_file(OFFICIAL) != package_hash:
        raise RuntimeError(f"refusing to overwrite different official CORE09: {OFFICIAL}")
    if not OFFICIAL.exists():
        shutil.copyfile(PACKAGE, OFFICIAL)
    if sha256_file(OFFICIAL) != package_hash:
        raise RuntimeError("official byte-copy hash mismatch")

    index_path = EXPEDIENTE / "INDICE_EXPEDIENTE.md"
    index = index_path.read_text(encoding="utf-8")
    index = index.replace("las ocho campañas científicas principales", "las nueve campañas científicas principales")
    index = index.replace("Los ZIP CORE 01–08 están sellados", "Los ZIP CORE 01–09 están sellados")
    section = """
### Experimento 09 — Rosetta externa, autonomía adaptativa y subsistemas

`09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip`

Confirma A6 en un survival loop binario con generalización y reversal; demuestra memoria causal one-shot de 1000 asociaciones y un subsistema nearest-prototype ejecutado exactamente por fibras DEE; delimita tolerancia a daño sin regeneración aprendida; y falsifica prospectivamente una Rosetta externa de velocidad única para tiempos P/S sin convertir ese negativo en imposibilidad global.

"""
    if PACKAGE_NAME not in index:
        marker = "## EXTRA"
        if marker not in index:
            raise RuntimeError("expediente index marker missing")
        index = index.replace(marker, section + marker)
    atomic_text(index_path, index)

    hash_rows = []
    for directory in ("CORE", "EXTRA"):
        base = EXPEDIENTE / directory
        if base.exists():
            for path in sorted(base.glob("*.zip")):
                hash_rows.append(f"{sha256_file(path)}  {directory}/{path.name}")
    hash_rows.append(f"{sha256_file(index_path)}  INDICE_EXPEDIENTE.md")
    atomic_text(EXPEDIENTE / "HASHES.sha256", "\n".join(hash_rows) + "\n")

    core_files = sorted(path.name for path in OFFICIAL.parent.glob("*.zip"))
    expected_prefixes = {f"{index:02d}_" for index in range(1, 10)}
    actual_prefixes = {name[:3] for name in core_files}
    if actual_prefixes != expected_prefixes or len(core_files) != 9:
        raise RuntimeError({"expected_prefixes": sorted(expected_prefixes), "actual_files": core_files})


def main() -> int:
    validate_science()
    update_state(status="COMPLETE", next_action="NONE_CORE09_SEALED", package_name=PACKAGE_NAME)
    rows = payload()
    write_manifest(rows)
    rows = payload()
    build_zip(rows)
    validation = validate_zip(rows)
    publish_and_index(validation["sha256"])
    print(json.dumps({"status": "PASS", "package": str(PACKAGE), "official": str(OFFICIAL), **validation}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
