#!/usr/bin/env python3
"""Freeze the external Rosetta tournament before downloading/reading values."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, atomic_text, append_log, canonical_hash, update_state, utc_now


def main() -> int:
    lock = {
        "schema": "dee.v27.core09.holdout.v1",
        "claim_id": "C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA",
        "question": "Does frozen DEE fingerprint D09F01 predict independent measured transit records with one global scale and a non-calibration phase observable?",
        "fingerprint_id": "D09F01",
        "selection_before_values": True,
        "selection_reason": "USGS metadata exposes preparation (earthquake origin), detector (station), row-level arrival, two phase families, many conditions, public provenance and event-level holdout. No numerical rows were read before this lock.",
        "external_protocol": {
            "primary_dataset": "USGS GSN associated arrival time picks 1997-2005",
            "metadata_url": "https://www.usgs.gov/programs/earthquake-hazards/science/gsn-data",
            "data_url": "https://prd-wret.s3-us-west-2.amazonaws.com/assets/palladium/production/atoms/files/assoc_arrival_time_picks.txt",
            "station_registry_url": "https://service.iris.edu/fdsnws/station/1/query?starttime=1997-01-01&endtime=2005-12-31&level=station&format=text",
            "license": "USGS data public domain; EarthScope/IRIS station metadata terms recorded with download",
            "unit_of_independence": "associated earthquake event",
            "allowed_phases": ["P", "S"],
            "distance": "sqrt((WGS84 mean-radius great-circle arc km)^2 + depth_km^2)",
            "travel_time": "arrival UTC minus associated origin UTC, seconds; retain 0<t<2000",
            "station_resolution": "unique station-code location active during 1997-2005; ambiguous codes excluded",
        },
        "split": {"method": "SHA256(event_key || split_seed) uniform assignment", "split_seed": "CORE09_EXTERNAL_270901", "calibration": "u<0.60", "validation": "0.60<=u<0.80", "final_holdout": "u>=0.80"},
        "map": {
            "DEE_observer": "D09F01 first-arrival delay detector",
            "preparation_map": "external source-receiver slant distance -> integer DEE L_inf path in the large-scale limit",
            "prediction": "t_hat = alpha * distance with zero intercept and the same alpha for P and S",
            "free_parameters": 1,
            "calibration": "least-squares alpha on CALIBRATION P rows only",
            "no_case_refit": True,
            "nondefinitional_observable": "S-family travel times predicted without phase-specific recalibration",
        },
        "nulls": ["event-level distance permutation", "constant median time"],
        "standard_competitor": "phase-specific piecewise-linear interpolation of calibration median travel time in fixed 10-degree distance bins",
        "PASS": {
            "minimum_final_rows_per_phase": 200,
            "median_absolute_percentage_error_P_max": 0.05,
            "median_absolute_percentage_error_S_max": 0.05,
            "p90_absolute_percentage_error_both_max": 0.10,
            "same_alpha_required": True,
            "standard_competitor_median_ape_advantage_max": 0.01,
            "distance_shuffle_median_ape_ratio_min": 2.0,
        },
        "FAIL": "Any PASS gate fails with adequate final sample size.",
        "INCONCLUSIVE": "Fewer than 200 resolvable final rows in either exact phase, corrupt provenance, or unavailable data.",
        "falsifier": "Phase-dependent or path-dependent travel-time structure not captured by the one-scale invariant-speed observer.",
        "created_utc": utc_now(),
    }
    lock["canonical_content_sha256"] = canonical_hash(lock)
    path = ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA.json"
    atomic_json(path, lock)
    import hashlib
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    atomic_text(path.with_suffix(".sha256"), digest + "  " + path.name + "\n")
    registry = {
        "schema": "dee.v27.core09.external.registry.v1", "status": "SELECTED_BEFORE_NUMERICAL_INSPECTION",
        "datasets": [{"dataset_id": "EXT09_USGS_GSN_ASSOC", "title": lock["external_protocol"]["primary_dataset"], "author": "U.S. Geological Survey Earthquake Hazards Program", "institution": "USGS", "publication_date": "2019-09-16 (supporting-file page); observations 1997-2005", "license": "Public Domain", "metadata_url": lock["external_protocol"]["metadata_url"], "data_url": lock["external_protocol"]["data_url"], "local_path": "EXTERNAL_DATA/assoc_arrival_time_picks.txt", "sha256": None, "selection_reason": lock["selection_reason"], "values_opened": False}, {"dataset_id": "EXT09_EARTHSCOPE_STATIONS", "title": "FDSN station metadata active 1997-2005", "author": "EarthScope Consortium Data Services", "institution": "EarthScope/IRIS", "license": "service metadata; citation/provenance retained", "metadata_url": "https://service.iris.edu/fdsnws/station/1/", "data_url": lock["external_protocol"]["station_registry_url"], "local_path": "EXTERNAL_DATA/fdsn_stations_1997_2005.txt", "sha256": None, "selection_reason": "geometry registry required before any source-receiver distance can be computed", "values_opened": False}],
    }
    atomic_json(ROOT / "EXTERNAL_DATA_REGISTRY.json", registry)
    append_log({"event": "HOLDOUT_LOCK_FROZEN", "module_id": lock["claim_id"], "lock_sha256": digest, "external_values_opened": False})
    update_state(last_completed_experiment="C9P01_EXTERNAL_PROTOCOL_FREEZE", pending_holdout="C9H01", next_action="Download hash-verified registered external data, parse calibration/validation only, freeze alpha, then open final event holdout once.")
    print(digest)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
