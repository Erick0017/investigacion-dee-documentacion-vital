#!/usr/bin/env python3
"""Freeze independent A6 policy-learning holdout after C9D02 signal."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, atomic_text, append_log, canonical_hash, sha256_file, update_state, utc_now


def main():
    discovery = ROOT / "RESULTS/C9D02_adaptive_survival_discovery.json"
    lock = {
        "schema": "dee.v27.core09.holdout.v1", "claim_id": "C9H02_ADAPTIVE_POLICY_A6", "question": "Does an action-contingent DEE return-lineage learn, generalize and reverse a damage-avoidance policy while a separate fixed scaffold restores damage?",
        "domain": {"N": [21, 23, 25], "episodes": 14, "worlds_per_primary_mode": 12, "new_context_sreg": [41, 43, 47, 53, 211, 223, 227, 59, 61, 67, 71, 229, 233, 239]},
        "apparatus": {"policy_states": [[1, 0, 0], [0, 1, 0]], "sensor": [-1, 0, 1], "normalizer": [1, 0, -1], "valence_rule": "wrong action only: delete scaffold center and collide a fixed action-specific return-path penalty; correct action: no penalty", "environment_reads": "action port only", "teacher_identity_carrier": False, "all_contingencies_frozen": True},
        "modes": ["contingent", "equal_exposure_no_consequence", "memory_ablation", "reset", "yoked_damage", "random_contingency", "noncontingent_punishment", "sensor_shuffle", "action_channel_swap", "fixed_reflex"],
        "seeds": [930101, 930211, 930307, 930419, 930523, 930617, 930719, 930823, 930929, 931031, 931127, 931229],
        "frames": [{"permutation": [0, 1, 2], "signs": [1, 1, 1]}, {"permutation": [1, 0, 2], "signs": [1, -1, 1]}, {"permutation": [2, 1, 0], "signs": [-1, 1, 1]}, {"permutation": [0, 2, 1], "signs": [1, 1, -1]}],
        "controls": ["memory ablation", "reset", "yoked damage", "random contingency", "non-contingent punishment", "sensor shuffle", "equal exposure", "fixed reflex"],
        "minimum_effect": {"post_first_acquisition_accuracy_min": .95, "post_first_reversal_accuracy_min": .95, "unseen_context_accuracy_min": .95, "primary_mean_damage_max": 2.0, "primary_recovery_rate_min": 1.0, "scaffold_unchanged_rate_min": 1.0, "equal_exposure_accuracy_max": .55, "memory_ablation_accuracy_max": .55, "reset_accuracy_max": .55, "fixed_reflex_accuracy_max": .55, "noncontingent_accuracy_max": .60, "random_accuracy_max": .65, "yoked_mean_damage_min": 3.0, "action_swap_accuracy_min": .80},
        "PASS": "All minimum-effect gates pass on new worlds.", "FAIL": "Any causal/generalization/reversal gate fails.", "INCONCLUSIVE": "Kernel/runtime failure prevents planned worlds.",
        "falsifier": "Improvement persists without memory/contingency, fails new contexts/reversal, or damage reduction is only fixed repair.", "discovery_sha256": sha256_file(discovery), "created_utc": utc_now(),
    }
    lock["canonical_content_sha256"] = canonical_hash(lock); path = ROOT / "HOLDOUT_LOCKS/C9H02_ADAPTIVE_POLICY_A6.json"; atomic_json(path, lock); digest = sha256_file(path); atomic_text(path.with_suffix(".sha256"), digest + "  " + path.name + "\n")
    append_log({"event": "HOLDOUT_LOCK_FROZEN", "module_id": lock["claim_id"], "lock_sha256": digest}); update_state(pending_holdout="C9H02", next_action="Run C9H02 once on new sizes/frames/seeds.")
    print(digest); return 0


if __name__ == "__main__": raise SystemExit(main())
