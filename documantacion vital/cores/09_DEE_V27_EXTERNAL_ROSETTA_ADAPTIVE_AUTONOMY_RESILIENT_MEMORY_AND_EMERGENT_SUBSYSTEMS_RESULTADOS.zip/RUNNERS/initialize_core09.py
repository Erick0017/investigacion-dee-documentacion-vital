#!/usr/bin/env python3
"""One-time CORE09 audit and DEE-only neutral fingerprint freeze."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, TESTS, EXPECTED, atomic_json, atomic_text, append_log, sha256_file, utc_now, verify_and_load_kernel

CORE_HASHES = {
    "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip": "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f",
    "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip": "275d3e665c0d0c97c3da80ee487819078fc55dbca24bd4e40c7dafa5b5e7a5fc",
}


def fingerprint(fid, family, preparation, intervention, detector, readout, causal, symmetries, ratios, scaling, response, relaxation, history, fluctuations, observer, falsifiers):
    return {"fingerprint_id": fid, "family": family, "preparation": preparation, "intervention": intervention, "detector": detector, "readout": readout, "causal_graph": causal, "symmetries": symmetries, "dimensionless_ratios": ratios, "scaling": scaling, "response_function": response, "relaxation": relaxation, "history": history, "fluctuations": fluctuations, "observer": observer, "falsifiers": falsifiers, "external_name_hidden": True}


def main() -> int:
    core_dir = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
    observed = {name: sha256_file(core_dir / name) for name in CORE_HASHES}
    if observed != CORE_HASHES:
        raise RuntimeError({name: (observed.get(name), expected) for name, expected in CORE_HASHES.items() if observed.get(name) != expected})
    parent = ROOT / "PARENTS" / "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip"
    if sha256_file(parent) != CORE_HASHES[next(reversed(CORE_HASHES))]:
        raise RuntimeError("embedded CORE08 parent mismatch")
    _, environment = verify_and_load_kernel(1)
    chain = {"schema": "dee.v27.core09.parent_chain.v1", "cores": [{"core": i + 1, "filename": name, "sha256": digest} for i, (name, digest) in enumerate(CORE_HASHES.items())], "embedded_parent": "PARENTS/" + parent.name, "recursive_chain_note": "CORE08 contains CORE07, which contains CORE01-06 and EXTRA01."}
    atomic_json(ROOT / "PARENT_CHAIN.json", chain)
    fps = [
        fingerprint("D09F01", "P01", "one or more collision-free semantic-1 carriers", "free F_DEE evolution", "arrival cell or internal port", "first-arrival tick and destination", "directed unit Chebyshev step per tick", ["translation", "axis/sign frame covariance in certified free sector"], ["distance/arrival_delay=1"], "delay proportional to integer L_inf path length", "arrival_delta at expected tick", "none in free sector", "path order only", "deterministic", "local arrival detector", ["early/late arrival", "state/amplitude changes speed"]),
        fingerprint("D09F02", "P02", "several delayed carriers aimed at fixed coincidence bank", "relative delay variation", "ordered place-code ports", "winner location/order", "relative arrival -> guarded collision/coincidence -> place", ["common delay shift", "translation"], ["place spacing/delay spacing"], "finite ordered code", "piecewise categorical delay-to-place", "one-pass", "relative phase/history essential", "deterministic", "internal consumptive detector", ["absolute rather than relative delay controls output", "shuffle preserves code"]),
        fingerprint("D09F03", "P03", "k proposals sharing a destination", "synchronous arrival", "destination fiber reducer", "support, summed load, signed direction sum", "guards -> proposal fiber -> many-to-one reducer", ["permutation of arrivals", "payload-state nuisance in sector"], ["support_loss/(k-1)=1"], "one output per active fiber", "sum_s and sign(sum_d) under guard", "instantaneous update", "clock/guard dependent", "deterministic", "guarded destination observer", ["coordinate-deleted observer remains exact", "crystallization reachable under v27 cap"]),
        fingerprint("D09F04", "P04", "source-free normal-sector ensemble", "autonomous evolution", "coarse inventory observer", "support and total registered load", "collision fibers contract support; no sources", ["translation", "inventory permutation only under matched collision structure"], ["support(t+1)/support(t)<=1"], "bounded non-increasing sequences", "sectorial monotone contraction", "until absorbing/ballistic state", "collision history matters", "ensemble-dependent", "inventory observer", ["support/load increase without source", "conjugate family inferred without protocol"]),
        fingerprint("D09F05", "P05", "paired ordinary carrier experience", "unseen cue/query then reversal experience", "moving lineage response port", "direction and load translation", "experience collision -> persistent lineage -> later query reduction", ["frame transformations", "translation"], ["output_delta/input_delta=1"], "class transfer across unseen query values", "affine translation in certified apparatus", "persistent until collision/reset", "ordered experience essential", "deterministic", "lineage/history observer", ["untrained/shuffled controls reproduce", "holdout overlap"]),
        fingerprint("D09F06", "P06", "eight persistent corner scaffold cells around a vacancy", "repeated center deletion", "center cell and functional readout", "one-tick restoration and cycle survival", "vacancy/XNOR birth from fixed semantic-4 scaffold", ["translation", "payload nuisance"], ["recovery_time/damage_interval"], "constant local scaffold size", "binary restore in one tick", "fixed point between damage events", "no adaptive improvement", "deterministic", "local vacancy detector", ["missing/shuffled/disconnected scaffold restores", "resource depletion hidden by accounting"]),
        fingerprint("D09F07", "P07", "trained main lineage plus independent trained donor", "targeted learned-memory deletion", "unseen query response", "exact learned response after donor route", "trained redundancy -> actuator -> reconstructed functional lineage", ["frame", "translation"], ["post/pre functional accuracy"], "finite redundant copy", "exact recovery in bounded apparatus", "two-tick restore", "training provenance essential", "deterministic", "functional equivalence observer", ["wrong/label-shuffled/offpath donor works", "query overlaps training"]),
        fingerprint("D09F08", "P08", "collision-free bulk rays", "free propagation to boundary", "boundary event-time history", "origin/depth and future arrival reconstruction", "bulk path -> boundary time/place code", ["translation within interior", "ray permutation"], ["code_cells/N^2", "time/depth"], "K(N)=ceil((N-4)/3)^2 for frozen family; bits Theta(N^2 log N)", "exact finite-family reconstruction", "finite transit", "time ordering essential", "deterministic", "boundary-history observer", ["time/location shuffle preserves prediction", "general arbitrary bulk reconstruction"]),
        fingerprint("D09F09", "P09", "same world under different quotients", "fixed F_DEE evolution", "multiple observer maps", "effective ballistic/stationary/delayed laws", "Q0 -> observer quotient -> task-relative law", ["observer-dependent"], ["retained predictive information/compression"], "varies with quotient", "distinct exact effective records", "observer-specific", "hidden state produces alias divergence", "deterministic", "family of M maps", ["all observers yield identical law", "simple view is globally Markov"]),
        fingerprint("D09F10", "P10", "operational persistent carrier/organization", "collision, translation, damage, detector probe", "functional identity observer", "response repertoire rather than byte identity", "lineage/history and fiber interaction", ["translation", "payload nuisance in bounded sectors"], ["functional retention"], "bounded apparatus-specific", "interaction fingerprint", "persistent or restored", "history may define identity", "deterministic", "functional quotient", ["response not reproducible", "any microstate is same entity"]),
    ]
    artifact = {"schema": "dee.v27.core09.neutral_fingerprints.v1", "created_before_external_value_inspection": True, "source_parent": {"path": "PARENTS/" + parent.name, "sha256": sha256_file(parent)}, "naming_rule": "family labels P01-P10 carry no external physical noun", "fingerprints": fps, "count": len(fps)}
    atomic_json(ROOT / "DEE_NEUTRAL_FINGERPRINTS.json", artifact)
    atomic_json(ROOT / "EXTERNAL_DATA_REGISTRY.json", {"schema": "dee.v27.core09.external.registry.v1", "status": "METADATA_NOT_YET_QUERIED", "datasets": []})
    state = {"schema": "dee.v27.core09.state.v1", "status": "ACTIVE", "current_question": "Which frozen DEE fingerprint admits a decisive external protocol without semantic matching?", "active_branches": ["external_rosetta", "adaptive_autonomy", "adaptive_regeneration", "emergent_subsystem", "resilient_dictionary"], "last_completed_experiment": "C9A00_INITIAL_AUDIT_AND_DEE_FINGERPRINT_FREEZE", "complete_modules": ["C9A00"], "proven": [], "refuted": [], "provisional": [], "pending_holdout": None, "next_action": "Select external datasets by protocol metadata, register provenance, and freeze the tournament before reading numerical holdouts.", "package_name": "09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip", "timestamp_utc": utc_now()}
    atomic_json(ROOT / "STATE.json", state)
    atomic_text(ROOT / "SCIENCE_LOG.ndjson", "")
    append_log({"event": "CORE09_INITIALIZED", "module_id": "C9A00", "parents_verified": len(CORE_HASHES), "fingerprints_frozen": len(fps), "kernel": environment})
    result = {"schema": "dee.v27.core09.c9a00.v1", "module_id": "C9A00_INITIAL_AUDIT_AND_DEE_FINGERPRINT_FREEZE", "status": "COMPLETE", "parents": observed, "embedded_parent_sha256": sha256_file(parent), "kernel": environment, "fingerprints": len(fps), "external_values_inspected": False}
    atomic_json(ROOT / "RESULTS/C9A00_initial_audit.json", result)
    print(json.dumps({"status": "PASS", "parents": len(observed), "fingerprints": len(fps), "kernel_hashes": EXPECTED}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
