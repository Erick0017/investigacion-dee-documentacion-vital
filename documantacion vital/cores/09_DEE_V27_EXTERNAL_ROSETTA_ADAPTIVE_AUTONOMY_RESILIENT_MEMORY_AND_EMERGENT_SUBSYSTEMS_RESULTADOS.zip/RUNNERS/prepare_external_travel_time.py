#!/usr/bin/env python3
"""Parse registered USGS rows, keep FINAL sealed, and fit only CALIBRATION/VALIDATION."""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, atomic_text, append_log, canonical_hash, sha256_file, update_state, utc_now

LOCK = ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA.json"
ASSOC = ROOT / "external_data/assoc_arrival_time_picks.txt"
STATIONS = ROOT / "external_data/fdsn_stations_1997_2005.txt"
SPLIT_SEED = "CORE09_EXTERNAL_270901"
R_EARTH_KM = 6371.0088


def parse_ydt(year: str, day: str, hms: str) -> datetime:
    hh, mm, sec = hms.split(":")
    return datetime(int(year), 1, 1, tzinfo=timezone.utc) + timedelta(days=int(day) - 1, hours=int(hh), minutes=int(mm), seconds=float(sec))


def parse_compound(value: str) -> datetime:
    year, day, hms = value.replace(",", " ").split()
    return parse_ydt(year, day, hms)


def station_table():
    table = defaultdict(list)
    with STATIONS.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            if not line or line.startswith("#"):
                continue
            p = line.rstrip("\n").split("|")
            if len(p) < 8:
                continue
            try:
                start = datetime.fromisoformat(p[6].replace("Z", "+00:00")); end = datetime.fromisoformat(p[7].replace("Z", "+00:00")) if p[7] else datetime.max.replace(tzinfo=timezone.utc)
                if start.tzinfo is None: start = start.replace(tzinfo=timezone.utc)
                if end.tzinfo is None: end = end.replace(tzinfo=timezone.utc)
                table[(p[0].strip(), p[1].strip())].append((start, end, float(p[2]), float(p[3])))
            except (ValueError, OverflowError):
                continue
    return table


def station_at(table, network, station, when):
    matches = [(lat, lon) for start, end, lat, lon in table.get((network, station), []) if start <= when <= end]
    unique = sorted(set(matches))
    return unique[0] if len(unique) == 1 else None


def split_of(event_key: str) -> str:
    raw = hashlib.sha256((event_key + "|" + SPLIT_SEED).encode()).digest()
    u = int.from_bytes(raw[:8], "big") / 2**64
    return "calibration" if u < .60 else ("validation" if u < .80 else "final_holdout")


def haversine_deg(lat1, lon1, lat2, lon2):
    a1, a2 = math.radians(lat1), math.radians(lat2)
    dlat, dlon = a2 - a1, math.radians(lon2 - lon1)
    h = math.sin(dlat / 2) ** 2 + math.cos(a1) * math.cos(a2) * math.sin(dlon / 2) ** 2
    return math.degrees(2 * math.asin(min(1.0, math.sqrt(h))))


def save_npz(path: Path, rows: list[tuple]):
    path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_suffix(path.suffix + ".tmp")
    phase = np.asarray([r[0] for r in rows], dtype="U1")
    arrays = {"phase": phase, "distance_km": np.asarray([r[1] for r in rows]), "angle_deg": np.asarray([r[2] for r in rows]), "travel_time_s": np.asarray([r[3] for r in rows]), "depth_km": np.asarray([r[4] for r in rows]), "event_key": np.asarray([r[5] for r in rows], dtype="U64"), "station": np.asarray([r[6] for r in rows], dtype="U24")}
    with tmp.open("wb") as stream:
        np.savez_compressed(stream, **arrays); stream.flush(); os.fsync(stream.fileno())
    os.replace(tmp, path)


def metrics(data, alpha):
    y = data["travel_time_s"]; pred = alpha * data["distance_km"]
    ape = np.abs(pred - y) / y
    return {"n": int(len(y)), "median_ape": float(np.median(ape)), "p90_ape": float(np.quantile(ape, .9)), "mae_seconds": float(np.mean(np.abs(pred - y)))}


def main() -> int:
    lock_sha = sha256_file(LOCK)
    side = LOCK.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]
    if lock_sha != side:
        raise RuntimeError("external lock changed")
    table = station_table(); groups = {"calibration": [], "validation": [], "final_holdout": []}; skipped = defaultdict(int)
    with ASSOC.open("r", encoding="utf-8", errors="replace") as stream:
        for line in stream:
            p = line.split()
            if len(p) < 9:
                skipped["malformed"] += 1; continue
            network, station = p[0], p[1]
            phase = p[-1]
            if phase not in {"P", "S"}:
                skipped["phase"] += 1; continue
            try:
                arrival = parse_compound(p[3]); origin = parse_compound(p[4])
                ev_lat, ev_lon, depth = float(p[5]), float(p[6]), float(p[7])
                tt = (arrival - origin).total_seconds()
            except (ValueError, IndexError):
                skipped["parse"] += 1; continue
            if not (0 < tt < 2000 and 0 <= depth <= 700):
                skipped["range"] += 1; continue
            station_coord = station_at(table, network, station, arrival)
            if station_coord is None:
                skipped["station"] += 1; continue
            angle = haversine_deg(ev_lat, ev_lon, *station_coord); arc = R_EARTH_KM * math.radians(angle); distance = math.hypot(arc, depth)
            event_key = f"{p[4]}|{ev_lat:.4f}|{ev_lon:.4f}|{depth:.1f}"
            groups[split_of(event_key)].append((phase, distance, angle, tt, depth, event_key, network + "." + station))
    for name, rows in groups.items():
        save_npz(ROOT / "external_data" / f"usgs_{name}.npz", rows)
    cal = np.load(ROOT / "external_data/usgs_calibration.npz"); val = np.load(ROOT / "external_data/usgs_validation.npz")
    p_mask = cal["phase"] == "P"; alpha = float(np.sum(cal["distance_km"][p_mask] * cal["travel_time_s"][p_mask]) / np.sum(cal["distance_km"][p_mask] ** 2))
    summary = {"alpha_s_per_km": alpha, "counts": {name: {phase: sum(r[0] == phase for r in rows) for phase in ("P", "S")} for name, rows in groups.items()}, "calibration": {phase: metrics({k: cal[k][cal["phase"] == phase] for k in cal.files}, alpha) for phase in ("P", "S")}, "validation": {phase: metrics({k: val[k][val["phase"] == phase] for k in val.files}, alpha) for phase in ("P", "S")}, "skipped": dict(skipped)}
    map_lock = {"schema": "dee.v27.core09.rosetta_map_lock.v1", "parent_lock_sha256": lock_sha, "fingerprint_id": "D09F01", "alpha_s_per_km": alpha, "free_parameters": 1, "zero_intercept": True, "fit_rows": int(p_mask.sum()), "fit_phase": "P", "validation_summary": summary["validation"], "final_holdout_opened": False, "competitor": {"bin_edges_deg": list(range(0, 181, 10)), "rule": "phase-specific calibration median at bin center then fixed linear interpolation"}, "null_seed": 27090101, "created_utc": utc_now()}
    map_lock["canonical_content_sha256"] = canonical_hash(map_lock)
    map_path = ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_MAP_FREEZE.json"; atomic_json(map_path, map_lock)
    map_sha = sha256_file(map_path); atomic_text(ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_MAP_FREEZE.sha256", map_sha + "  " + map_path.name + "\n")
    registry = json.loads((ROOT / "EXTERNAL_DATA_REGISTRY.json").read_text(encoding="utf-8"))
    registry["status"] = "DOWNLOADED_HASHED_CALIBRATION_COMPLETE_FINAL_UNOPENED"
    actual_url = "https://d9-wret.s3.us-west-2.amazonaws.com/assets/palladium/production/s3fs-public/atoms/files/assoc_arrival_time_picks.txt"
    for row in registry["datasets"]:
        local = ROOT / row["local_path"]
        row.update({"sha256": sha256_file(local), "bytes": local.stat().st_size, "downloaded_utc": utc_now(), "values_opened": row["dataset_id"] != "EXT09_USGS_GSN_ASSOC" or True})
        if row["dataset_id"] == "EXT09_USGS_GSN_ASSOC":
            row["resolved_data_url"] = actual_url; row["url_substitution_reason"] = "USGS legacy prd-wret URL returned HTTP 403; current official d9-wret object from the same USGS supporting-file page was used."
    registry["split_files"] = [{"path": f"external_data/usgs_{name}.npz", "sha256": sha256_file(ROOT / "external_data" / f"usgs_{name}.npz"), "rows": len(rows), "opened_for_metrics": name != "final_holdout"} for name, rows in groups.items()]
    atomic_json(ROOT / "EXTERNAL_DATA_REGISTRY.json", registry)
    result = {"schema": "dee.v27.core09.c9d01.v1", "module_id": "C9D01_EXTERNAL_CALIBRATION", "status": "COMPLETE", "role": "CALIBRATION_VALIDATION_ONLY", "parent_lock_sha256": lock_sha, "map_lock_sha256": map_sha, "source_hashes": {"associated": sha256_file(ASSOC), "stations": sha256_file(STATIONS)}, "final_holdout_opened": False, "summary": summary}
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS/C9D01_external_calibration.json", result)
    append_log({"event": "EXTERNAL_MAP_FROZEN", "module_id": "C9D01", "map_lock_sha256": map_sha, "counts": summary["counts"], "final_holdout_opened": False})
    update_state(last_completed_experiment="C9D01_EXTERNAL_CALIBRATION", pending_holdout="C9H01", next_action="Open final USGS event holdout exactly once under the frozen one-scale map.")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
