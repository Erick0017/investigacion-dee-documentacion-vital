#!/usr/bin/env python3
"""Small staged discovery for a character-locality DEE memory subsystem."""
from __future__ import annotations
import json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, append_log, canonical_hash, update_state, verify_and_load_kernel
from symbolic_subsystem import corrupt, generate_tokens, infer_kernel, nearest_levenshtein, score_math, train_kernel


def main():
    started = time.perf_counter(); kernel, environment = verify_and_load_kernel(1); stages = []
    for capacity in (40, 100):
        tokens, labels = generate_tokens(capacity, 940000 + capacity); memory, train = train_kernel(kernel, tokens, labels)
        clean = [int(np.argmax(score_math(memory, token))) == int(label) for token, label in zip(tokens, labels, strict=True)]
        typo = [corrupt(token, "substitution", 941000 + i) for i, token in enumerate(tokens)]; robust = [int(np.argmax(score_math(memory, token))) == int(label) for token, label in zip(typo, labels, strict=True)]
        audit = []
        for i in np.linspace(0, capacity - 1, min(20, capacity), dtype=int):
            observed, stats = infer_kernel(kernel, memory, typo[i]); expected = score_math(memory, typo[i]); audit.append({"index": int(i), "exact": bool(np.array_equal(observed, expected)), "prediction": int(np.argmax(observed)), "truth": int(labels[i]), "stats": stats})
        lev = [int(labels[nearest_levenshtein(tokens, q)]) == int(labels[i]) for i, q in enumerate(typo)]
        stages.append({"capacity": capacity, "training": train, "clean_accuracy": float(np.mean(clean)), "one_substitution_accuracy": float(np.mean(robust)), "kernel_math_exact_rate": float(np.mean([r["exact"] for r in audit])), "levenshtein_accuracy": float(np.mean(lev)), "audit": audit})
    signal = all(r["training"]["kernel_exact"] and r["clean_accuracy"] == 1 and r["one_substitution_accuracy"] >= .9 and r["kernel_math_exact_rate"] == 1 for r in stages)
    result = {"schema": "dee.v27.core09.c9d04.v1", "module_id": "C9D04_SYMBOLIC_SUBSYSTEM_DISCOVERY", "status": "COMPLETE", "role": "DISCOVERY_EVIDENCE_ONLY", "question": "Can ordinary collision training create a DEE-executed character-local nearest-prototype subsystem worth scaling?", "encoder": "label-blind SHA256-indexed set of boundary/unigram/bigram features; max fan-in <=26", "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started, "stages": stages, "promotion_signal": signal, "interpretation": "Robustness must be compared to encoder-only/Levenshtein; exact F_DEE score execution alone does not establish an algorithmic advantage."}
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS/C9D04_symbolic_subsystem_discovery.json", result); append_log({"event": "DISCOVERY_COMPLETE", "module_id": result["module_id"], "promotion_signal": signal, "stages": [{"capacity": r["capacity"], "clean": r["clean_accuracy"], "typo": r["one_substitution_accuracy"]} for r in stages]}); update_state(last_completed_experiment=result["module_id"], provisional=["DEE_EXECUTED_NEAREST_PROTOTYPE_SUBSYSTEM"] if signal else [], next_action="Freeze 1000-association EXTRA04/EXTRA05 joint holdout." if signal else "Close symbolic subsystem after failure at staged capacity.")
    print(json.dumps({"signal": signal, "stages": [{k: r[k] for k in ("capacity", "clean_accuracy", "one_substitution_accuracy", "kernel_math_exact_rate", "levenshtein_accuracy")} for r in stages]}, indent=2)); return 0


if __name__ == "__main__": raise SystemExit(main())
