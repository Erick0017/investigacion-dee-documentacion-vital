#!/usr/bin/env python3
"""Open the final external event holdout once under the frozen D09F01 map."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, append_log, canonical_hash, sha256_file, update_state, utc_now

LOCK = ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA.json"
MAP = ROOT / "HOLDOUT_LOCKS/C9H01_EXTERNAL_MAP_FREEZE.json"


def load(path):
    z = np.load(path)
    return {k: z[k] for k in z.files}


def ape(y, pred): return np.abs(pred - y) / y


def metrics(y, pred):
    a = ape(y, pred)
    return {"n": int(len(y)), "median_ape": float(np.median(a)), "p90_ape": float(np.quantile(a, .9)), "mae_seconds": float(np.mean(np.abs(pred - y))), "rmse_seconds": float(np.sqrt(np.mean((pred - y) ** 2)))}


def binned_model(cal, phase):
    mask = cal["phase"] == phase; edges = np.arange(0, 181, 10.0); centers = (edges[:-1] + edges[1:]) / 2
    values = np.full(len(centers), np.nan)
    for i in range(len(centers)):
        m = mask & (cal["angle_deg"] >= edges[i]) & (cal["angle_deg"] < edges[i + 1])
        if m.any(): values[i] = np.median(cal["travel_time_s"][m])
    known = np.flatnonzero(np.isfinite(values)); values = np.interp(np.arange(len(values)), known, values[known])
    return centers, values


def cluster_bootstrap(data, pred, seed, draws=1000):
    rng = np.random.default_rng(seed); events, inverse = np.unique(data["event_key"], return_inverse=True); stats = []
    groups = [np.flatnonzero(inverse == i) for i in range(len(events))]
    for _ in range(draws):
        chosen = rng.integers(0, len(groups), len(groups)); idx = np.concatenate([groups[i] for i in chosen]); stats.append(float(np.median(ape(data["travel_time_s"][idx], pred[idx]))))
    return {"unit": "event", "draws": draws, "lower": float(np.quantile(stats, .025)), "upper": float(np.quantile(stats, .975))}


def main() -> int:
    started = time.perf_counter()
    lock_sha, map_sha = sha256_file(LOCK), sha256_file(MAP)
    if LOCK.with_suffix(".sha256").read_text(encoding="utf-8").split()[0] != lock_sha or MAP.with_suffix(".sha256").read_text(encoding="utf-8").split()[0] != map_sha:
        raise RuntimeError("frozen external protocol/map changed")
    lock, frozen = json.loads(LOCK.read_text(encoding="utf-8")), json.loads(MAP.read_text(encoding="utf-8"))
    if frozen.get("final_holdout_opened") is not False:
        raise RuntimeError("map was not frozen with final unopened")
    cal = load(ROOT / "external_data/usgs_calibration.npz"); final = load(ROOT / "external_data/usgs_final_holdout.npz")
    alpha = frozen["alpha_s_per_km"]; pred = alpha * final["distance_km"]
    by_phase = {}; ci = {}; standard = np.zeros(len(pred))
    for phase in ("P", "S"):
        mask = final["phase"] == phase; d = {k: v[mask] for k, v in final.items()}; pp = pred[mask]
        by_phase[phase] = metrics(d["travel_time_s"], pp); ci[phase] = cluster_bootstrap(d, pp, frozen["null_seed"] + ord(phase))
        centers, values = binned_model(cal, phase); standard[mask] = np.interp(d["angle_deg"], centers, values)
    combined = metrics(final["travel_time_s"], pred); standard_metrics = metrics(final["travel_time_s"], standard)
    rng = np.random.default_rng(frozen["null_seed"]); perm = rng.permutation(len(final["distance_km"])); null_distance = metrics(final["travel_time_s"], alpha * final["distance_km"][perm])
    constant = metrics(final["travel_time_s"], np.full(len(pred), np.median(cal["travel_time_s"])))
    gates = lock["PASS"]
    conditions = {
        "sample_P": by_phase["P"]["n"] >= gates["minimum_final_rows_per_phase"],
        "sample_S": by_phase["S"]["n"] >= gates["minimum_final_rows_per_phase"],
        "P_accuracy": by_phase["P"]["median_ape"] <= gates["median_absolute_percentage_error_P_max"],
        "S_accuracy": by_phase["S"]["median_ape"] <= gates["median_absolute_percentage_error_S_max"],
        "tail_accuracy": combined["p90_ape"] <= gates["p90_absolute_percentage_error_both_max"],
        "competitor": combined["median_ape"] - standard_metrics["median_ape"] <= gates["standard_competitor_median_ape_advantage_max"],
        "distance_null": null_distance["median_ape"] / combined["median_ape"] >= gates["distance_shuffle_median_ape_ratio_min"],
    }
    adequate = conditions["sample_P"] and conditions["sample_S"]
    verdict = "PASS" if all(conditions.values()) else ("FAIL" if adequate else "INCONCLUSIVE")
    result = {
        "schema": "dee.v27.core09.c9h01.v1", "module_id": lock["claim_id"], "status": "COMPLETE", "role": "FROZEN_EXTERNAL_HOLDOUT",
        "verdict": verdict, "current_rosetta_status": "EXTERNAL_ROSETTA_NOT_FOUND_UNDER_CORE09_PROTOCOL" if verdict == "FAIL" else ("ROSETTA_VALIDATED" if verdict == "PASS" else "EXTERNAL_DATA_BLOCKED"),
        "lock_sha256": lock_sha, "map_lock_sha256": map_sha, "opened_utc": utc_now(), "wall_clock_seconds": time.perf_counter() - started,
        "sample": {"rows": int(len(pred)), "events": int(len(np.unique(final["event_key"]))), "by_phase": {p: by_phase[p]["n"] for p in by_phase}},
        "frozen_map": {"alpha_s_per_km": alpha, "parameters": 1, "zero_intercept": True, "same_alpha_P_S": True},
        "DEE_model": {"by_phase": by_phase, "combined": combined, "event_cluster_bootstrap_95ci_median_ape": ci},
        "competitors": {"phase_specific_10deg_calibration_median_interpolation": standard_metrics, "event_distance_permutation": null_distance, "constant_calibration_median": constant},
        "conditions": conditions,
        "interpretation": "The one-speed D09F01 quotient captures ordering but fails quantitative Earth travel-time structure, especially the unused S observable. This rejects this external map, not DEE or all Rosetta candidates.",
        "nonclaims": ["The substrate is seismic", "carrier is a P wave", "no DEE observer can match any physical protocol"],
    }
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS/C9H01_external_travel_time_rosetta.json", result)
    registry = json.loads((ROOT / "EXTERNAL_DATA_REGISTRY.json").read_text(encoding="utf-8")); registry["status"] = "FINAL_HOLDOUT_OPENED_ONCE_AND_ADJUDICATED"
    for row in registry.get("split_files", []):
        if row["path"].endswith("final_holdout.npz"): row["opened_for_metrics"] = True; row["opened_utc"] = result["opened_utc"]
    atomic_json(ROOT / "EXTERNAL_DATA_REGISTRY.json", registry)
    atomic_json(ROOT / "ROSETTA_CANDIDATE_REGISTRY.json", {"schema": "dee.v27.core09.rosetta.candidates.v1", "candidates": [{"candidate_id": "R09_01", "fingerprint_id": "D09F01", "external_dataset": "EXT09_USGS_GSN_ASSOC", "status": result["current_rosetta_status"], "lock_sha256": lock_sha, "map_lock_sha256": map_sha, "parameters": 1, "holdout_result": "RESULTS/C9H01_external_travel_time_rosetta.json"}], "other_frozen_internal_fingerprints": 9})
    atomic_json(ROOT / "ROSETTA_VALIDATION_LEDGER.json", {"schema": "dee.v27.core09.rosetta.validation.v1", "ROSETTA_VALIDATED": verdict == "PASS", "attempts": [{"candidate_id": "R09_01", "gates": conditions, "verdict": verdict, "epistemic_scope": result["interpretation"]}]})
    append_log({"event": "EXTERNAL_HOLDOUT_COMPLETE", "module_id": lock["claim_id"], "verdict": verdict, "lock_sha256": lock_sha, "map_lock_sha256": map_sha, "conditions": conditions})
    update_state(last_completed_experiment=lock["claim_id"], pending_holdout=None, provisional=[result["current_rosetta_status"]], next_action="Audit retrospective adaptation signals, then construct a minimal hazard-policy-repair discovery loop.")
    print(json.dumps({"verdict": verdict, "sample": result["sample"], "DEE_model": result["DEE_model"], "competitors": result["competitors"], "conditions": conditions}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
