#!/usr/bin/env python3
"""Frozen confirmation of adaptive policy learning and bounded A6."""
from __future__ import annotations
import json, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, atomic_json, append_log, canonical_hash, sha256_file, update_state, verify_and_load_kernel
from run_c9d02_adaptive_loop_discovery import run_world


def main():
    started = time.perf_counter(); path = ROOT / "HOLDOUT_LOCKS/C9H02_ADAPTIVE_POLICY_A6.json"; lock_sha = sha256_file(path)
    if path.with_suffix(".sha256").read_text(encoding="utf-8").split()[0] != lock_sha: raise RuntimeError("A6 lock changed")
    lock = json.loads(path.read_text(encoding="utf-8")); kernel, environment = verify_and_load_kernel(1); contexts = lock["domain"]["new_context_sreg"]
    frames = [(tuple(f["permutation"]), tuple(f["signs"])) for f in lock["frames"]]; modes = lock["modes"]
    cases = []
    for j, mode in enumerate(modes):
        count = 12 if mode in {"contingent", "equal_exposure_no_consequence", "memory_ablation", "reset", "yoked_damage", "random_contingency", "noncontingent_punishment", "fixed_reflex"} else 6
        for i in range(count):
            cases.append(run_world(kernel, lock["seeds"][i] + 10000 * j, lock["domain"]["N"][i % 3], mode, lock["domain"]["episodes"], *frames[i % len(frames)], contexts=contexts))
    grouped = {mode: [r for r in cases if r["mode"] == mode] for mode in modes}
    means = {mode: {key: float(np.mean([r[key] for r in rows])) for key in ("accuracy", "post_first_acquisition_accuracy", "post_first_reversal_accuracy", "unseen_context_accuracy", "damage_count", "recovery_rate")} | {"scaffold_unchanged_rate": float(np.mean([r["scaffold_unchanged"] for r in rows]))} for mode, rows in grouped.items()}
    p, m = means["contingent"], lock["minimum_effect"]
    conditions = {"acquisition": p["post_first_acquisition_accuracy"] >= m["post_first_acquisition_accuracy_min"], "reversal": p["post_first_reversal_accuracy"] >= m["post_first_reversal_accuracy_min"], "generalization": p["unseen_context_accuracy"] >= m["unseen_context_accuracy_min"], "damage_reduction": p["damage_count"] <= m["primary_mean_damage_max"], "repair": p["recovery_rate"] >= m["primary_recovery_rate_min"], "scaffold": p["scaffold_unchanged_rate"] >= m["scaffold_unchanged_rate_min"], "equal_exposure": means["equal_exposure_no_consequence"]["accuracy"] <= m["equal_exposure_accuracy_max"], "memory_ablation": means["memory_ablation"]["accuracy"] <= m["memory_ablation_accuracy_max"], "reset": means["reset"]["accuracy"] <= m["reset_accuracy_max"], "fixed_reflex": means["fixed_reflex"]["accuracy"] <= m["fixed_reflex_accuracy_max"], "noncontingent": means["noncontingent_punishment"]["accuracy"] <= m["noncontingent_accuracy_max"], "random": means["random_contingency"]["accuracy"] <= m["random_accuracy_max"], "yoked": means["yoked_damage"]["damage_count"] >= m["yoked_mean_damage_min"], "action_swap": means["action_channel_swap"]["accuracy"] >= m["action_swap_accuracy_min"]}
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {"schema": "dee.v27.core09.c9h02.v1", "module_id": lock["claim_id"], "status": "COMPLETE", "role": "FROZEN_CONFIRMATION", "verdict": verdict, "lock_sha256": lock_sha, "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started, "sample_sizes": {mode: len(rows) for mode, rows in grouped.items()}, "means": means, "conditions": conditions, "autonomy_adjudication": {"A6": "PASS_BOUNDED_TWO_ACTION_RETURN_LINEAGE" if verdict == "PASS" else "FAIL_IN_TESTED_APPARATUS"}, "mechanism": "The returning action carrier is both decision trace and persistent policy. Wrong-action valence plus a fixed normalizer changes its direction state; absence of valence preserves it. The separate semantic-4 scaffold restores center damage but cannot account for policy improvement.", "cases": cases, "nonclaims": ["consciousness", "general agency", "unsupervised discovery of arbitrary actions", "resource-independent organism"]}
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS/C9H02_adaptive_policy_A6.json", result)
    curves = {
        "schema": "dee.v27.core09.learning.curves.v1",
        "primary": [
            {
                "seed": row["seed"],
                "actions": [
                    {"episode": d["episode"], "correct": not d["wrong"], "damage": d["wrong"], "phase": d["phase"], "unseen_context": d["unseen_context"]}
                    for d in row["decisions"]
                ],
            }
            for row in grouped["contingent"]
        ],
        "means": means,
    }
    atomic_json(ROOT / "LEARNING_CURVES.json", curves)
    atomic_json(ROOT / "REVERSAL_GENERALIZATION.json", {"schema": "dee.v27.core09.reversal.v1", "verdict": verdict, "acquisition": p["post_first_acquisition_accuracy"], "reversal": p["post_first_reversal_accuracy"], "unseen_context": p["unseen_context_accuracy"], "controls": {k: v["accuracy"] for k, v in means.items()}})
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": lock["claim_id"], "verdict": verdict, "lock_sha256": lock_sha, "conditions": conditions}); update_state(last_completed_experiment=lock["claim_id"], pending_holdout=None, proven=["A6_CONFIRMED_BOUNDED"] if verdict == "PASS" else [], next_action="Test whether repeated hazard experience adapts repair latency/cost beyond the fixed one-tick scaffold, then evaluate emergent subsystem and resilient dictionary.")
    print(json.dumps({"verdict": verdict, "means": means, "conditions": conditions}, indent=2)); return 0


if __name__ == "__main__": raise SystemExit(main())
