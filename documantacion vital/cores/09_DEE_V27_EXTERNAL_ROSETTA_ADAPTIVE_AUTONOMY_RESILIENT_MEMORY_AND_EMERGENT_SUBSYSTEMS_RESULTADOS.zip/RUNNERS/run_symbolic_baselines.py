"""Post-holdout classical baseline audit for CORE09 Task B.

This analysis cannot alter C9H03.  It uses the already-open fixed 80/20
lexical split and records deterministic NumPy implementations because the
frozen Python environment does not contain scikit-learn or XGBoost.
"""

from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core09_common import append_log, atomic_json, canonical_hash  # noqa: E402
from run_c9h03_symbolic_subsystem import WORD_GROUPS, F, char_features, nearest_levenshtein  # noqa: E402


def design(words: list[str]) -> np.ndarray:
    return np.asarray([[int(feature in set(char_features(word))) for feature in range(F)] for word in words], dtype=float)


def accuracy(prediction: np.ndarray, truth: np.ndarray) -> float:
    return float(np.mean(prediction == truth))


def main() -> int:
    started = time.perf_counter()
    train = [(word, label) for label, group in enumerate(WORD_GROUPS) for word in group[:8]]
    test = [(word, label) for label, group in enumerate(WORD_GROUPS) for word in group[8:]]
    train_words = [word for word, _ in train]
    test_words = [word for word, _ in test]
    y_train = np.asarray([label for _, label in train], dtype=int)
    y_test = np.asarray([label for _, label in test], dtype=int)
    x_train = design(train_words)
    x_test = design(test_words)
    y_onehot = np.eye(10)[y_train]

    exact = np.asarray([y_train[train_words.index(word)] if word in train_words else -1 for word in test_words])
    lev = np.asarray([y_train[nearest_levenshtein(train_words, word)] for word in test_words])
    distances = ((x_test[:, None, :] - x_train[None, :, :]) ** 2).sum(axis=2)
    knn = y_train[np.argmin(distances, axis=1)]

    ridge = 1e-3
    augmented_train = np.column_stack([x_train, np.ones(len(x_train))])
    augmented_test = np.column_stack([x_test, np.ones(len(x_test))])
    linear_weights = np.linalg.solve(augmented_train.T @ augmented_train + ridge * np.eye(F + 1), augmented_train.T @ y_onehot)
    linear = np.argmax(augmented_test @ linear_weights, axis=1)

    rng = np.random.default_rng(959102)
    hidden = 24
    w1 = rng.normal(0, 0.15, (F, hidden)); b1 = np.zeros(hidden)
    w2 = rng.normal(0, 0.15, (hidden, 10)); b2 = np.zeros(10)
    learning_rate = 0.08
    for _ in range(1200):
        h = np.tanh(x_train @ w1 + b1)
        logits = h @ w2 + b2
        exp = np.exp(logits - logits.max(axis=1, keepdims=True))
        probabilities = exp / exp.sum(axis=1, keepdims=True)
        delta = (probabilities - y_onehot) / len(x_train)
        dw2 = h.T @ delta + 1e-4 * w2; db2 = delta.sum(axis=0)
        delta_h = (delta @ w2.T) * (1 - h * h)
        dw1 = x_train.T @ delta_h + 1e-4 * w1; db1 = delta_h.sum(axis=0)
        w2 -= learning_rate * dw2; b2 -= learning_rate * db2
        w1 -= learning_rate * dw1; b1 -= learning_rate * db1
    mlp = np.argmax(np.tanh(x_test @ w1 + b1) @ w2 + b2, axis=1)

    rows = {
        "exact_lookup": accuracy(exact, y_test),
        "levenshtein_nearest_word": accuracy(lev, y_test),
        "feature_1nn": accuracy(knn, y_test),
        "ridge_linear": accuracy(linear, y_test),
        "small_mlp_24_hidden": accuracy(mlp, y_test),
    }
    result = {
        "schema": "dee.v27.core09.symbolic_baselines.v1",
        "module_id": "C9A06_POSTHOC_CLASSICAL_BASELINES",
        "status": "COMPLETE",
        "role": "POST_HOLDOUT_BASELINE_AUDIT",
        "split": {"train": len(train), "test": len(test), "classes": 10, "test_relation": "held-out lexical synonyms"},
        "same_input_features": "frozen label-blind 64-bit character boundary/unigram/bigram hash",
        "accuracies": rows,
        "xgboost": "UNAVAILABLE_AND_NOT_REQUIRED_AFTER_NO_SIGNAL",
        "fault_model_note": "The encoder-prototype baseline and the DEE effective state are the same label-feature bit matrix, so identical bit deletion yields identical damage curves. Weight deletion for linear/MLP would be a different failure model and is not used to imply superiority.",
        "adjudication": "No method establishes semantic understanding on this small held-out synonym task. This post-hoc audit does not modify C9H03.",
        "wall_clock_seconds": time.perf_counter() - started,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS/C9A06_classical_symbolic_baselines.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": result["module_id"], "adjudication": result["adjudication"]})
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
