"""Character encoder and DEE-executed nearest-prototype quotient for CORE09."""
from __future__ import annotations
import hashlib, math, time
from itertools import product
import numpy as np
from core09_common import NativeWorld, fields, pack

F = 64
ALL_DIRS = [q for q in product((-1, 0, 1), repeat=3) if q != (0, 0, 0)]
INERT_STATE = 841119940
INERT_CLOCK = 367292013764061809
CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)


def add(q, d, k, n): return tuple((q[i] + k * d[i]) % n for i in range(3))


def char_features(token: str, width: int = F) -> np.ndarray:
    framed = "^" + token.lower() + "$"
    keys = {"U:" + c for c in framed} | {"B:" + framed[i:i+2] for i in range(len(framed) - 1)}
    return np.asarray(sorted({int.from_bytes(hashlib.sha256(key.encode()).digest()[:8], "big") % width for key in keys}), dtype=np.int16)


def generate_tokens(count: int, seed: int, length: int = 8):
    rng = np.random.default_rng(seed); alphabet = np.asarray(list("abcdefghijklmnopqrstuvwxyz")); out = []
    while len(out) < count:
        token = "".join(rng.choice(alphabet, size=length).tolist())
        if token not in out: out.append(token)
    labels = rng.permutation(count).astype(np.int32)
    return out, labels


def target_for_slot(slot: int, grid: int):
    return 2 + 3 * (slot % grid), 2 + 3 * ((slot // grid) % grid), 2 + 3 * (slot // (grid * grid))


def train_kernel(kernel, tokens, labels, width=F):
    capacity = len(tokens); slots = capacity * width; grid = math.ceil(slots ** (1/3)); n = 3 * grid + 3
    raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw); expected = np.zeros((capacity, width), dtype=bool); initial_support = 0
    for sample, label in zip(tokens, labels, strict=True):
        for feature in char_features(sample, width):
            expected[int(label), int(feature)] = True; target = target_for_slot(int(label) * width + int(feature), grid)
            for direction, salt in ((CUE, 1), (TEACHER, 2)):
                origin = add(target, direction, -1, n)
                if int(raw[origin]): raise RuntimeError(f"training origin overlap {origin}")
                raw[origin] = pack(INERT_STATE + salt, 1, direction, 1); clock[origin] = np.uint64(INERT_CLOCK + salt); initial_support += 1
    started = time.perf_counter(); world = NativeWorld(kernel, raw, clock); info = world.tick(); wall = time.perf_counter() - started; f = fields(world.raw); learned = np.zeros_like(expected)
    for label, feature in np.argwhere(expected):
        target = target_for_slot(int(label) * width + int(feature), grid); learned[label, feature] = int(world.raw[target]) != 0 and int(f["sreg"][target]) == 2
    return learned, {"capacity": capacity, "features": width, "world_N": n, "initial_support": initial_support, "learned_support": int(learned.sum()), "expected_support": int(expected.sum()), "kernel_exact": bool(np.array_equal(learned, expected)), "kernel_calls": 1, "wall_seconds": wall, "tick_telemetry": {str(k): v for k, v in info.items()}}


def score_math(memory: np.ndarray, token: str):
    features = char_features(token, memory.shape[1]); return memory[:, features].sum(axis=1).astype(np.int16)


def infer_kernel(kernel, memory: np.ndarray, token: str):
    capacity = len(memory); grid = math.ceil(capacity ** (1/3)); n = 3 * grid + 3; raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw); features = set(char_features(token, memory.shape[1]).tolist())
    for label in range(capacity):
        hits = [(int(f), int(memory[label, f])) for f in np.flatnonzero(memory[label]) if int(f) in features]
        if len(hits) > 26: raise RuntimeError("fan-in exceeds Moore neighborhood")
        target = target_for_slot(label, grid)
        for direction, (_, value) in zip(ALL_DIRS, hits, strict=False):
            origin = add(target, direction, -1, n)
            if int(raw[origin]): raise RuntimeError(f"inference origin overlap {origin}")
            raw[origin] = pack(INERT_STATE, value, direction, 1); clock[origin] = np.uint64(INERT_CLOCK)
    started = time.perf_counter(); world = NativeWorld(kernel, raw, clock); info = world.tick(); wall = time.perf_counter() - started; f = fields(world.raw); scores = np.zeros(capacity, dtype=np.int16)
    for label in range(capacity): scores[label] = int(f["sreg"][target_for_slot(label, grid)])
    return scores, {"N": n, "kernel_calls": 1, "wall_seconds": wall, "initial_support": int(np.count_nonzero(raw)), "final_support": int(np.count_nonzero(world.raw)), "telemetry": {str(k): v for k, v in info.items()}}


def corrupt(token: str, kind: str, seed: int) -> str:
    rng = np.random.default_rng(seed); chars = list(token); alphabet = list("abcdefghijklmnopqrstuvwxyz")
    if kind == "substitution":
        i = int(rng.integers(len(chars))); choices = [c for c in alphabet if c != chars[i]]; chars[i] = choices[int(rng.integers(len(choices)))]
    elif kind == "deletion": chars.pop(int(rng.integers(len(chars))))
    elif kind == "insertion": chars.insert(int(rng.integers(len(chars) + 1)), alphabet[int(rng.integers(26))])
    elif kind == "transposition":
        i = int(rng.integers(len(chars) - 1)); chars[i], chars[i + 1] = chars[i + 1], chars[i]
    elif kind == "two_edit": return corrupt(corrupt(token, "substitution", seed), "deletion", seed + 991)
    elif kind == "mixed": return corrupt(token, ("substitution", "deletion", "insertion", "transposition", "two_edit")[seed % 5], seed + 17)
    else: raise ValueError(kind)
    return "".join(chars)


def levenshtein(a: str, b: str) -> int:
    row = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        nxt = [i]
        for j, cb in enumerate(b, 1): nxt.append(min(nxt[-1] + 1, row[j] + 1, row[j - 1] + (ca != cb)))
        row = nxt
    return row[-1]


def nearest_levenshtein(tokens, query): return min(range(len(tokens)), key=lambda i: (levenshtein(tokens[i], query), i))


def damaged(memory, rate, seed, mode="random"):
    rng = np.random.default_rng(seed); out = memory.copy()
    if mode == "random":
        active = np.argwhere(out); count = round(rate * len(active)); chosen = rng.choice(len(active), count, replace=False) if count else []
        for i in chosen: out[tuple(active[int(i)])] = False
    elif mode == "targeted_lineage":
        labels = rng.choice(len(out), round(rate * len(out)), replace=False) if rate else []; out[labels] = False
    elif mode == "contiguous_feature": out[:, :round(rate * out.shape[1])] = False
    elif mode == "route": out = np.roll(out, max(1, round(rate * out.shape[1])), axis=1) if rate else out
    return out
