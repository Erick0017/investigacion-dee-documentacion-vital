"""Evidence-bound synthesis and final scientific documentation for CORE09."""

from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from core09_common import append_log, atomic_json, atomic_text, canonical_hash, update_state, utc_now  # noqa: E402


def load(name: str) -> dict:
    return json.loads((ROOT / name).read_text(encoding="utf-8"))


def save_result(name: str, value: dict) -> None:
    value["content_sha256"] = canonical_hash(value)
    atomic_json(ROOT / "RESULTS" / name, value)


def save_doc(name: str, body: str) -> None:
    atomic_text(ROOT / name, body.strip() + "\n")


def main() -> int:
    ext = load("RESULTS/C9H01_external_travel_time_rosetta.json")
    ext_calibration = load("RESULTS/C9D01_external_calibration.json")
    a6 = load("RESULTS/C9H02_adaptive_policy_A6.json")
    symbolic = load("RESULTS/C9H03_symbolic_memory_and_subsystem.json")
    baselines = load("RESULTS/C9A06_classical_symbolic_baselines.json")
    retrospective = load("RESULTS/C9A02_retrospective_adaptation_audit.json")
    fingerprints = load("DEE_NEUTRAL_FINGERPRINTS.json")
    parent = load("PARENT_CHAIN.json")

    primary = a6["means"]["contingent"]
    controls = {key: value for key, value in a6["means"].items() if key != "contingent"}
    primary_cases = [case for case in a6["cases"] if case["mode"] == "contingent"]
    resource_deltas = [case["resource_accounting"]["final_sreg"] - case["resource_accounting"]["initial_sreg"] for case in primary_cases]
    sensor_loads = [case["resource_accounting"]["external_sensor_load"] for case in primary_cases]
    penalty_loads = [case["resource_accounting"]["penalty_load"] for case in primary_cases]

    adaptive_regeneration = {
        "schema": "dee.v27.core09.adaptive_regeneration.v1",
        "module_id": "C9A03_ADAPTIVE_REGENERATION_RESOURCE",
        "status": "COMPLETE",
        "fast_loop": {
            "mechanism": "fixed semantic-4 eight-corner XNOR scaffold",
            "repair_success": primary["recovery_rate"],
            "repair_latency_ticks": 1,
            "scaffold_byte_invariant_rate": primary["scaffold_unchanged_rate"],
            "inherited_level": "R7_BOUNDED_FIXED_HOMEOSTASIS",
        },
        "slow_loop": {
            "mechanism": "returning action lineage changed by contingent valence",
            "overall_accuracy": primary["accuracy"],
            "post_first_acquisition_accuracy": primary["post_first_acquisition_accuracy"],
            "post_first_reversal_accuracy": primary["post_first_reversal_accuracy"],
            "unseen_context_accuracy": primary["unseen_context_accuracy"],
            "damage_count": primary["damage_count"],
            "adjudication": "A6_PASS_BOUNDED",
        },
        "adaptive_repair": {
            "status": "NOT_FOUND",
            "reason": "Experience reduced how often damage occurred but did not reduce the one-tick discrete repair latency or change the fixed scaffold mechanism.",
        },
        "resource_accounting": {
            "mean_external_sensor_load": statistics.mean(sensor_loads),
            "mean_penalty_load": statistics.mean(penalty_loads),
            "mean_sreg_change": statistics.mean(resource_deltas),
            "support_change": 0,
            "closed_accounting": False,
            "reason": "Sensor, normalizer and contingent valence carriers enter from a fixed external environment; s_reg increase is accounted input, not endogenous recovery or an energy law.",
        },
        "integrated_entity": "FUNCTIONALLY_COUPLED_APPARATUS_NOT_SELF_BOUNDED_ORGANISM",
    }
    save_result("C9A03_adaptive_regeneration_resource.json", adaptive_regeneration)

    crossfeed = {
        "schema": "dee.v27.core09.crossfeed.v1",
        "module_id": "C9A04_CROSSFEED_AND_UNIFICATION",
        "status": "COMPLETE",
        "relations_tested": [
            {"crossfeed": "adaptation x repair", "result": "POSITIVE_COMPOSITION", "limit": "policy reduces damage; fixed scaffold performs repair"},
            {"crossfeed": "adaptation x resource", "result": "ACCOUNTED_OPEN_SYSTEM", "limit": "external carrier inputs prevent a closed resource law"},
            {"crossfeed": "learning x regeneration", "result": "NEGATIVE_FOR_LEARNED_MEMORY", "limit": "universal scaffold destroys selectivity; selective scaffold leaks learned addresses at t0"},
            {"crossfeed": "subsystem x observer", "result": "EXACT_TASK_RELATIVE_QUOTIENT", "limit": "not a global F_DEE closure"},
            {"crossfeed": "subsystem x robust memory", "result": "POSITIVE_DAMAGE_TOLERANCE", "limit": "robustness without regeneration"},
            {"crossfeed": "Rosetta x observer", "result": "EXTERNAL_FAIL", "limit": "one-speed observer does not model phase/path structure"},
        ],
        "minimal_shared_mechanisms": [
            "guarded directed destination fibers",
            "s_reg/direction reduction at a destination",
            "persistent returning lineage/history",
            "task-relative observer quotient",
            "semantic-4 XNOR guard as a distinct fixed-regeneration branch",
        ],
        "unification_claim": "Destination-fiber reduction plus persistent lineage explains policy update, one-shot memory storage and exact effective scoring; XNOR homeostasis composes with it but is not the learned mechanism.",
        "global_Q4": False,
        "unified_native_mechanism": "BOUNDED_CROSS_DOMAIN_OPERATOR_FAMILY_NOT_GLOBAL_CLOSURE",
    }
    save_result("C9A04_crossfeed_unification.json", crossfeed)

    adversarial = {
        "schema": "dee.v27.core09.adversarial.v1",
        "module_id": "C9A05_FINAL_ADVERSARIAL_REVIEW",
        "status": "COMPLETE",
        "checks": {
            "external_holdout_seen_before_freeze": False,
            "external_selection_by_numerical_fit": False,
            "external_map_overparameterized": False,
            "python_encoded_correct_action": False,
            "environment_acted_as_agent_controller": False,
            "A6_improvement_only_repair": False,
            "typo_robustness_was_encoder_only": True,
            "damage_touched_learned_memory": True,
            "subsystem_was_Python_disguised": False,
            "classical_baseline_superiority_established": False,
            "metric_changed_post_hoc": False,
        },
        "language_corrections": [
            "Use bounded A6 adaptive policy, not consciousness or general agency.",
            "Use encoder-mediated typo robustness, not DEE typo correction.",
            "Use known effective nearest-prototype subsystem, not emergent semantic intelligence.",
            "Use structural damage tolerance, not learned-memory regeneration.",
            "Use Rosetta map failure, not global impossibility of Rosetta or failure of DEE.",
        ],
        "scientific_rerun_required": False,
    }
    save_result("C9A05_adversarial_review.json", adversarial)

    p = ext["DEE_model"]["by_phase"]["P"]
    s = ext["DEE_model"]["by_phase"]["S"]
    competitor = ext["competitors"]["phase_specific_10deg_calibration_median_interpolation"]
    mixed = symbolic["corruption"]["mixed"]
    random15 = next(row for row in symbolic["damage_curves"]["random"] if row["rate"] == 0.15)
    taskb = symbolic["task_B"]

    save_doc("EXECUTIVE_VERDICT.md", f"""
# CORE09 — veredicto ejecutivo

CORE09 produjo un positivo central, varios positivos acotados y negativos decisivos.

**A6 quedó confirmada en un aparato de dos acciones.** En 12 mundos holdout nuevos (`N=21,23,25`), la política contingente obtuvo accuracy media {primary['accuracy']:.3f}; después del primer error de adquisición y del primer error de reversal alcanzó 1.000, y generalizó a contextos `s_reg` no vistos con 1.000. `memory ablation`, `reset`, `equal exposure` y `fixed reflex` quedaron en 0.500; la contingencia aleatoria en {controls['random_contingency']['accuracy']:.3f}; la señal no contingente en {controls['noncontingent_punishment']['accuracy']:.3f}. El carrier de acción que retorna es simultáneamente traza de decisión y política persistente. Esto es `A6_CONFIRMED_BOUNDED`, no conciencia ni agencia general.

La composición fast/slow también quedó delimitada: el scaffold XNOR fijo reparó todos los daños en un tick, mientras la política aprendida redujo los daños a {primary['damage_count']:.1f} por 14 episodios. No apareció aprendizaje de la propia reparación: la latencia siguió en el mínimo discreto de un tick y el scaffold no cambió. El sistema es un aparato funcionalmente integrado y abierto a carriers del entorno, no un organismo autosuficiente.

La Rosetta externa R09_01 falló bajo su protocolo congelado. Una sola escala ajustada exclusivamente a P predijo en el holdout final P con medAPE {p['median_ape']:.3f} y S —no usada en calibración— con {s['median_ape']:.3f}; el competidor estándar obtuvo {competitor['median_ape']:.3f}. El mapa de velocidad única conserva orden y vence el null de distancia permutada, pero no la estructura cuantitativa de tiempos terrestres. `ROSETTA_VALIDATED=false`.

EXTRA04 confirmó memoria one-shot causal de 1000 asociaciones: 1 tick de entrenamiento, 100% en 200 consultas limpias, 0% con labels barajados y 0% tras ablación total. Tras daño aleatorio del 15% conservó {random15['accuracy']:.3f}. En typos mixtos obtuvo {mixed['DEE_accuracy']:.3f}, exactamente igual al kNN del encoder, por lo que no hay ventaja DEE; Levenshtein obtuvo {mixed['levenshtein']:.3f}. El intento de regenerar memoria aprendida falló sin fuga.

EXTRA05 encontró un subsistema efectivo **conocido**: el observer `z=matriz etiqueta×feature` y el reductor de fibras ejecutan exactamente un clasificador por intersección/nearest-prototype en 100/100 auditorías. Es una demostración de microdinámica→cociente→algoritmo efectivo, no superioridad computacional ni semántica.
""")

    save_doc("FINAL_REPORT.md", f"""
# CORE09 — informe final

## Preguntas y adjudicación

1. **¿Existe una Rosetta externa validada?** No bajo R09_01. El fingerprint D09F01 fue congelado antes de mirar valores, el dataset USGS se dividió por evento y se abrió una sola vez. Muestra final: {ext['sample']['rows']} picks / {ext['sample']['events']} eventos. P medAPE={p['median_ape']:.4f}, S={s['median_ape']:.4f}; ambos exceden 0.05 y el competidor phase-specific es mucho mejor. El FAIL descarta el mapa `t=alpha·d` de una sola velocidad para P+S, no toda Rosetta.

2. **¿Estaba A6 oculta en CORE05–08?** No. El reanálisis encontró plasticidad, un loop A3 y homeostasis fija, pero no evidencia retrospectiva capaz de promover A6. C9H02 creó y confirmó el mecanismo que faltaba: consecuencia contingente→colisión con la traza que retorna→cambio persistente de direction→política futura diferente.

3. **¿Aprende a evitar daño?** Sí, en el dominio binario probado. Hay dos errores inevitables de información —primera adquisición y primera reversal— y conducta correcta posteriormente, incluida generalización. La ablación de memoria elimina la ventaja. El ambiente aplica una regla fija a puertos de acción y nunca lee el estado oculto para seleccionar la conducta.

4. **¿Se adapta la reparación?** No. El fast loop XNOR permanece fijo y ya ocupa la latencia mínima de un tick. Lo aprendido es evitación, no reparación más rápida o barata.

5. **¿Existe memoria simbólica resiliente grande?** Sí, causal y acotada. La curva limpia fue 40:1.000, 100:1.000, 250:1.000, 500:1.000, 1000:0.998; la muestra final limpia fue 1.000. El estado aprendido ocupa {symbolic['training']['learned_support']} bits activos / {symbolic['capacity_curve'][-1]['bytes']} bytes en la matriz observadora. Bajo borrado aleatorio la accuracy fue 0.990, 0.970, 0.930, 0.870 y 0.700 para 5–30%.

6. **¿Corrige typos DEE?** No de forma incremental respecto al encoder. En corrupción mixta, DEE={mixed['DEE_accuracy']:.3f}, feature-kNN={mixed['feature_knn_encoder_only']:.3f}, Levenshtein={mixed['levenshtein']:.3f}. La robustez proviene de la representación de caracteres. El daño de rutas derrumba la lectura incluso sin borrar bits: relación/routing y contenido son causalmente distintos.

7. **¿Regenera memoria aprendida?** No en los scaffolds probados. El scaffold universal llenó direcciones no entrenadas y perdió selectividad; el selectivo codificó desde t0 qué direcciones debían restaurarse. El FAIL permanece.

8. **¿Existe un subsistema superior?** Existe un cociente de tarea exacto pero conocido, no superior. `G_sub(query,z)=argmax_l Σ_{{f∈encoder(query)}} z[l,f]` coincidió exactamente con las reducciones de F_DEE en 100/100 pruebas. Supera exact lookup bajo typos, pero empata con el mismo kNN del encoder y pierde contra Levenshtein. En el probe de clases semánticas obtuvo {taskb['DEE_accuracy']:.3f}; no demuestra comprensión.

## Arquitectura transversal actualizada

El menor conjunto explicativo de CORE09 es: (i) propuesta dirigida; (ii) fibra de destino y reductor guardado; (iii) lineage que retorna y conserva historia; (iv) observer relativo a tarea; (v) rama XNOR fija para homeostasis. Los tres primeros explican plasticidad contingente, memoria one-shot y scoring efectivo. XNOR se compone con ellos, pero no aprende. No se ha obtenido Q4 global.

## Frontera

Las preguntas internas centrales quedaron adjudicadas con los aparatos actuales. Una Rosetta externa nueva requiere otro fingerprint congelado y un protocolo verdaderamente independiente; no se justifica ajustar R09_01. Reparación adaptativa de memoria requiere un scaffold que descubra qué restaurar sin contenerlo de antemano. Una entidad integrada más fuerte requiere cerrar recursos y fronteras internas sin decisiones post-t0 del host.
""")

    save_doc("TRANSVERSAL_CORE01_TO_09.md", """
# Transversal CORE01–CORE09

| CORE | Aporte que sobrevive | Límite vigente |
|---|---|---|
| 01 | Q0=`raw+clock`, cono raw acotado, transporte singleton, fuentes/colisiones | no ontología física externa |
| 02 | estado predictivo separado de evento; M*, roles y fibras | sectorial |
| 03 | Q2, organización de basin, predictor multiescala acotado | dominio limitado |
| 04 | eventos S/R/C/X/D y Q3 como clases de histories productivas | no Q4 global |
| 05 | grafo de propuestas, observador interno, delay-to-place | Rosetta sólo interna |
| 06 | aprendizaje asociativo/composición, materia operacional, CHSH local | sin relatividad/quantum externos |
| 07 | atlas ejecutable, cross-feed, loop A3 one-pass | A6 no resuelta entonces |
| 08 | reductor guardado, observer task-relative, R7 fijo, boundary history acotado | no Rosetta/holografía global |
| 09 | A6 binaria confirmada; memoria 1000; subsistema efectivo conocido; Rosetta R09_01 falsada | no agencia general, no regeneración aprendida, no Rosetta validada |

La síntesis no es una pirámide lineal. Estado, guardas, relaciones de destino, history/lineage, organización y observer son coordenadas cruzadas cuya suficiencia depende de tarea y dominio.
""")

    save_doc("CORE09_NEW_DISCOVERIES.md", """
# Descubrimientos nuevos de CORE09

1. **A6 binaria causal:** una consequence de valencia puede reescribir mediante F_DEE la direction de la traza de acción que retorna; esa traza gobierna la acción futura, generaliza a nuisances de contexto y revierte tras cambio de contingencia.
2. **Separación fast/slow:** homeostasis XNOR fija repara cada daño; aprendizaje reduce la incidencia de daño sin modificar reparación.
3. **Memoria one-shot 1000:** 31,298 carriers de training convergen en un tick a 15,649 bits relacionales aprendidos, exactamente como predice la fibra de destino.
4. **Resiliencia sin regeneración:** la memoria distribuida tolera borrado parcial, pero no se reconstruye sin que el scaffold contenga el soporte aprendido.
5. **Cociente algorítmico exacto:** un observer etiqueta×feature destila un subsistema nearest-prototype cuya aritmética F_DEE fue exacta en 100/100 ejecuciones.
6. **Negativo Rosetta cuantitativo:** una velocidad única no transfiere de P a S en tiempos de llegada sísmicos, pese a capturar parte de la ordenación por distancia.
""")

    save_doc("EXTERNAL_ROSETTA_FINAL.md", f"""
# Rosetta externa — adjudicación final

## Secuencia protegida

`DEE_NEUTRAL_FINGERPRINTS.json` se congeló antes de leer valores externos. Se eligió D09F01 por estructura experimental disponible: fuente, detector, distancia, tiempo de llegada, dos familias de fase y unidad independiente por evento. El lock C9H01 se hasheó antes de descargar filas. Una única escala `alpha={ext['frozen_map']['alpha_s_per_km']:.12f} s/km` se ajustó en {ext_calibration['summary']['counts']['calibration']['P']} P de calibration, con intercepto cero. El mapa se volvió a congelar antes de abrir final.

## Predicción reservada

`t_hat=alpha·distance` se aplicó sin refit a P y a S. En {ext['sample']['rows']} picks finales: P medAPE={p['median_ape']:.4f}, p90={p['p90_ape']:.4f}; S medAPE={s['median_ape']:.4f}, p90={s['p90_ape']:.4f}. El competidor phase-specific de calibración obtuvo medAPE={competitor['median_ape']:.4f}. El null de distancia permutada obtuvo {ext['competitors']['event_distance_permutation']['median_ape']:.4f}.

## Veredicto

`EXTERNAL_ROSETTA_NOT_FOUND_UNDER_CORE09_PROTOCOL`. Pasaron suficiencia de muestra y null de distancia; fallaron accuracy P/S, cola y competidor. D09F01 conserva una relación ordinal de tránsito, pero el cociente de velocidad única omite familia de fase y estructura de trayectoria. No hay `EXTERNAL_PREDICTION`, `ROSETTA_VALIDATED` ni `MULTI_OBSERVABLE_ROSETTA`.
""")

    save_doc("PREPARATION_MAP.md", """
# Mapa de preparación R09_01

External preparation: origen de evento asociado, profundidad y estación activa. Distancia: raíz de la suma de (arco great-circle con radio medio WGS84)^2 y profundidad^2. Registros ambiguos de estación se excluyen; `0<travel_time<2000 s`.

Mapa DEE congelado: distancia fuente–detector externa → longitud de trayecto L_inf en el límite de escala. No se construyó un mundo DEE distinto por pick: se transfirió el fingerprint D09F01 ya demostrado, cuya predicción neutral es demora lineal con una velocidad operacional. Calibración permitida: una escala global; offset=0; sin parámetros por fase/evento.

El split por SHA256 del event key (60/20/20) impide que picks del mismo terremoto crucen calibration/validation/final.
""")

    save_doc("OBSERVER_MAP.md", """
# Mapa de observadores

## D09F01

Detector DEE: first-arrival/delay observer. Readout: demora hasta detección ordenada. La predicción externa usa exactamente esta demora, no `raw`, `clock` o `direction` como nombres físicos. El FAIL muestra que este observer es demasiado pobre para P+S terrestres con una sola escala.

## A6

Observer del agente: dos puertos físicos de acción. Python observa únicamente el puerto y aplica una regla ambiental congelada; no inspecciona la memoria. La traza que regresa al centro es estado causal, no readout externo entrenado.

## Subsistema simbólico

`M_sub(X)=z[label,feature]`, presencia en destinos de memoria. El output son diez/cien/mil reducciones de intersección leídas en puertos congelados. `M_sub` es suficiente para la tarea declarada y no se reclama suficiente para F_DEE global.
""")

    save_doc("MULTI_OBSERVABLE_PREDICTIONS.md", """
# Predicciones multiobservable

R09_01 calibró sólo P y reservó S como segundo observable. La misma escala falló ambos umbrales, con un error especialmente grande en S. Por ello no se promueve a Rosetta multiobservable.

C9H02 sí predijo internamente varias lecturas con un mismo mecanismo —acción, daño, reversal, generalización y estado de memoria— pero son observables DEE internos, no validación física externa.

C9H03 predijo clean recall, corrupción y daño con el mismo estado `z`; sin embargo el éxito en corrupción es replicado por el observer/encoder sin evolución DEE. Sólo storage y reducción causal se atribuyen al kernel.
""")

    save_doc("RETROSPECTIVE_ADAPTATION_AUDIT.md", f"""
# Auditoría retrospectiva de adaptación

El barrido CORE05–08 encontró {len(retrospective.get('evidence_reviewed', retrospective)) if isinstance(retrospective, dict) else 'varias'} líneas relevantes, pero ninguna promovible a A6: CORE06 probó plasticidad/learning sin un ciclo de consecuencia; CORE07 probó una cadena A3 one-pass; CORE08 probó homeostasis de scaffold fijo. Las curvas antiguas no contenían reversal+generalization con consecuencia contingente y controles causales completos. La señal retrospectiva se mantuvo como discovery y C9H02 usó mundos nuevos.
""")

    save_doc("ADAPTIVE_AUTONOMY_A6.md", f"""
# Autonomía adaptativa A6

## Aparato

Un carrier política elige uno de dos canales. Un sensor y un normalizador fijos entran por interfaces ordinarias. Si el puerto observado es incorrecto, el entorno fijo daña el centro del scaffold y añade valencia a la traza que retorna. La colisión cambia su direction; sin valencia la política persiste. No hay mensaje con la identidad de la acción correcta.

## Holdout

12 mundos primarios, `N=21,23,25`, seeds y marcos rotados/reflejados nuevos, 14 episodios cada uno. Accuracy={primary['accuracy']:.4f}; adquisición posterior al primer episodio=1.0; reversal posterior al primer episodio=1.0; contextos no vistos=1.0; daños medios={primary['damage_count']:.1f}. Controles: equal exposure={controls['equal_exposure_no_consequence']['accuracy']:.3f}, memory ablation={controls['memory_ablation']['accuracy']:.3f}, reset={controls['reset']['accuracy']:.3f}, yoked={controls['yoked_damage']['accuracy']:.3f}, random={controls['random_contingency']['accuracy']:.3f}, noncontingent={controls['noncontingent_punishment']['accuracy']:.3f}, sensor shuffle={controls['sensor_shuffle']['accuracy']:.3f}.

## Adjudicación

Todos los gates preregistrados pasaron. `A6_CONFIRMED_BOUNDED_TWO_ACTION_RETURN_LINEAGE`. El resultado demuestra policy change dependiente de experiencia en este aparato; no conciencia, emoción, agente general ni autonomía de recursos.
""")

    save_doc("SURVIVAL_LOOP.md", """
# Survival loop

Cadena ejecutada: `context sensor → policy carrier → action port → fixed environment consequence → returning decision trace → persistent direction change → next action`. El mismo episodio puede causar daño al scaffold; la rama XNOR lo repone antes de la consulta siguiente. El host aplica una transición ambiental predefinida y no selecciona acciones.

La mejoría no es artefacto de sanación: todos los controles conservan recuperación=1.0, pero sólo el brazo contingente aprende adquisición y reversal. La acción intercambiada físicamente también pasa, mostrando que la codificación espacial particular no es esencial.
""")

    save_doc("ADAPTIVE_REGENERATION.md", f"""
# Regeneración adaptativa

**Fast loop:** reparación XNOR fija, 1 tick, recovery={primary['recovery_rate']:.3f}, scaffold byte-invariante={primary['scaffold_unchanged_rate']:.3f}.

**Slow loop:** A6 reduce incidentes futuros mediante cambio de policy; no modifica el scaffold.

`ADAPTIVE_REPAIR_CANDIDATE=false`: la latencia no puede mejorar por debajo de un tick en este aparato, la probabilidad ya es 1.0 y no apareció reducción de coste del mecanismo. El resultado positivo correcto es adaptación para evitar daño, no reparación que aprende.
""")

    save_doc("EXTRA04_RESILIENT_SPATIAL_DICTIONARY.md", f"""
# EXTRA04 — memoria simbólica espacial resiliente

El encoder label-blind hashea boundary/unigrams/bigrams en 64 features. Cada asociación cue+teacher se presenta una vez y el kernel realiza una actualización. A 1000 asociaciones: training support {symbolic['training']['initial_support']}→{symbolic['training']['learned_support']}, exactitud kernel del estado esperado=true, wall time={symbolic['training']['wall_seconds']:.3f}s. La muestra reservada limpia obtuvo 1.000; label-shuffle=0.000; memory-ablation=0.000.

Typo mixed: DEE={mixed['DEE_accuracy']:.3f}; feature-kNN={mixed['feature_knn_encoder_only']:.3f}; Levenshtein={mixed['levenshtein']:.3f}. Por tanto `TYPO_ROBUSTNESS_FOUND=false` y `ENCODER_MEDIATED_TYPO_ROBUSTNESS=true`.

Daño aleatorio 15%: accuracy={random15['accuracy']:.3f}; daño contiguo 15%={next(row for row in symbolic['damage_curves']['contiguous_feature'] if row['rate']==0.15)['accuracy']:.3f}; daño de rutas produce 0.0 desde 5%, aunque conserva los bits. Esto distingue contenido de accesibilidad causal.

La reparación aprendida no pasó: scaffold universal pierde selectividad; scaffold selectivo filtra el patrón a restaurar. Task B obtuvo {taskb['DEE_accuracy']:.3f}; los baselines post-hoc exact/Levenshtein/1NN/linear/MLP fueron {baselines['accuracies']}. No hay comprensión semántica, candidatura competitiva ni superioridad.
""")

    save_doc("EXTRA05_EMERGENT_SUBSYSTEM.md", """
# EXTRA05 — subsistema computacional efectivo

ARM A construyó una arquitectura congelada de memory banks espaciales, encoder label-blind y puertos reductores. En training, cue+teacher colisionan en un destino y depositan un bit etiqueta×feature. En inference, cada feature de query propone a los destinos de etiqueta; F_DEE suma `s_reg` y el readout toma argmax.

La ejecución del kernel coincidió exactamente con la ecuación reducida en 100/100 consultas auditadas. Esto pasa `KNOWN_EFFECTIVE_SUBSYSTEM_FOUND`: una capa observadora tiene una ley algorítmica distinta y útil respecto al raw. No pasa `COMPETITIVE_SYMBOLIC_MEMORY_CANDIDATE` ni `SUPERIORITY_CANDIDATE`; el algoritmo destilado es nearest-prototype y un control simple con el mismo encoder produce idénticos scores.

ARM B no produjo una arquitectura nativa independiente antes del stopping rule. No se justificó search adicional después de identificar completamente el mecanismo y el baseline equivalente.
""")

    save_doc("EFFECTIVE_SUBSYSTEM_DYNAMICS.md", """
# Dinámica efectiva del subsistema

Sea `z[l,f]∈{0,1}` la ocupación aprendida del feature `f` para label `l`. Training one-shot ejecuta:

`z'[l,f] = OR(z[l,f], cue_f AND teacher_l)`

en el dominio de destinos vacíos y asociaciones únicas. Para query `q`, inference ejecuta en un tick:

`score_l(q)=Σ_{f∈E(q)} z[l,f]`

`prediction=argmax_l score_l(q)`.

La igualdad entre telemetría y `G_sub` fue exacta en 100 casos. La clausura es task-relative: presupone encoder, layout, destinos y lectura congelados. El route-damage negativo prueba que `z` como matriz de bits no basta si se destruye su implementación relacional.
""")

    save_doc("DIRECT_VS_SUBSYSTEM_BENCHMARK.md", f"""
# Benchmark directo frente a subsistema

En typos mixtos, exact lookup={mixed['exact_lookup']:.3f}, subsistema DEE={mixed['DEE_accuracy']:.3f}, feature-kNN sin evolución={mixed['feature_knn_encoder_only']:.3f}, Levenshtein={mixed['levenshtein']:.3f}. El subsistema mejora la memoria exacta, pero no aporta robustez por encima del mismo observer de features y pierde contra un baseline especializado simple.

Task B, split fijo 80/20 de sinónimos: DEE={taskb['DEE_accuracy']:.3f}; exact={baselines['accuracies']['exact_lookup']:.3f}; Levenshtein={baselines['accuracies']['levenshtein_nearest_word']:.3f}; feature-1NN={baselines['accuracies']['feature_1nn']:.3f}; ridge={baselines['accuracies']['ridge_linear']:.3f}; MLP pequeño={baselines['accuracies']['small_mlp_24_hidden']:.3f}. Ningún resultado sustenta semántica.
""")

    save_doc("CROSS_FEED_RESULTS.md", """
# Cross-feed

| Cruce | Resultado | Interpretación |
|---|---|---|
| adaptation × repair | positivo compuesto | slow policy reduce daños; fast XNOR repara |
| adaptation × resource | sistema abierto contabilizado | inputs externos explican aumento de carga |
| learning × regeneration | negativo | no scaffold no-leaking para memoria aprendida |
| subsystem × observer | cociente exacto | cierre de tarea, no global |
| subsystem × robust memory | positivo | degradación gradual bajo borrado, no repair |
| Rosetta × observer | FAIL externo | D09F01 demasiado pobre para P+S |

La compresión transversal más fuerte es `directed proposal → guarded destination reduction → persistent lineage/observer`. Explica tres familias —adaptación, memoria y cálculo efectivo—. La homeostasis XNOR pertenece a otra rama de guardia y sólo se compone externamente con ellas en el aparato probado.
""")

    save_doc("NEGATIVE_RESULTS.md", """
# Resultados negativos

- R09_01: FAIL externo del mapa de una velocidad/una escala para P+S.
- No `ROSETTA_VALIDATED`, `MULTI_OBSERVABLE_ROSETTA` ni cross-domain Rosetta.
- No mejora DEE sobre el encoder-kNN en typos; Levenshtein es mejor.
- No regeneración autónoma no-leaking de memoria aprendida.
- No reparación adaptativa: el scaffold y la latencia permanecen fijos.
- No semántica en Task B; resultados cercanos a chance.
- No superioridad ni competitividad del subsistema frente a baselines simples.
- No entidad autosuficiente ni resource cycle cerrado.
- No Q4/global low-dimensional closure nuevo.

Cada negativo es relativo a su aparato y dominio; ninguno se amplía a una imposibilidad ontológica no demostrada.
""")

    save_doc("ADVERSARIAL_REVIEW.md", """
# Revisión adversarial final

- El lock externo precede la descarga de valores; el mapa tiene un solo parámetro y el final se abrió una vez.
- El resultado externo se conserva como FAIL; no se cambió observable, fase, threshold ni competidor.
- Python actúa como entorno fijo en A6: observa action port, no memoria; no inyecta label correcto.
- Los controles de memoria, reset, yoked, random, non-contingent, sensor shuffle y channel swap separan policy de repair/reflex.
- La robustez a typos se atribuye al encoder porque su kNN empata exactamente a DEE.
- El daño aleatorio y dirigido borra bits aprendidos; route damage prueba además accesibilidad.
- El scaffold selectivo es leakage y por eso el aparente refill no se promueve.
- `G_sub` se deriva de puertos ejecutados por F_DEE; se clasifica como algoritmo conocido y no como inteligencia emergente.
- Los ticks no se trataron como réplicas: eventos externos y mundos/seeds son las unidades independientes.
- Los dos fallos técnicos C9H03 ocurrieron antes de guardar resultados; se corrigieron remapeo local/serialización sin tocar el lock.
""")

    save_doc("FINAL_FRONTIER.md", """
# Frontera final CORE09

## EXTERNAL_DATA_REQUIRED

Otra Rosetta sólo es justificable para un fingerprint DEE distinto, con protocolo row-level y observable reservado. R09_01 no debe refitearse.

## NEW_THEORY_REQUIRED

Un observer global debe incorporar guardas, destinos ocupados, semantic, clock/phase, source y history. CORE09 sólo cerró observers relativos a tarea.

## NEW_KERNEL_OR_ARCHITECTURE_REQUIRED

Regeneración de memoria aprendida sin fuga requiere un proceso que detecte/discrimine qué patrón restaurar sin que el soporte target esté precodificado. Una entidad autosuficiente requeriría resource accounting cerrado y fronteras internas.

## CLOSED_NEGATIVE

Una-velocidad P+S; ventaja DEE para typos con este encoder; semántica del Task B; learned-memory regeneration con scaffolds universal/selectivo; superioridad del subsistema construido.

## STOPPING RULE

Cada rama prioritaria recibió una prueba informativa y controles. Extenderlas ahora implicaría cambiar el mecanismo después del holdout o repetir variantes sin nueva predicción. No se crea CORE10 automáticamente.
""")

    claims = {
        "schema": "dee.v27.core09.claims.v1",
        "generated_utc": utc_now(),
        "claims": [
            {"id": "C9C01", "claim": "A6 bounded adaptive policy", "status": "HOLDOUT_CONFIRMED_INTERNAL", "evidence": "RESULTS/C9H02_adaptive_policy_A6.json"},
            {"id": "C9C02", "claim": "one-shot 1000 association memory", "status": "HOLDOUT_CONFIRMED_INTERNAL", "evidence": "RESULTS/C9H03_symbolic_memory_and_subsystem.json"},
            {"id": "C9C03", "claim": "structural damage tolerance at 15 percent", "status": "HOLDOUT_CONFIRMED_INTERNAL", "evidence": "RESULTS/C9H03_symbolic_memory_and_subsystem.json"},
            {"id": "C9C04", "claim": "known effective nearest-prototype subsystem", "status": "HOLDOUT_CONFIRMED_INTERNAL", "evidence": "RESULTS/C9H03_symbolic_memory_and_subsystem.json"},
            {"id": "C9C05", "claim": "one-speed external travel-time Rosetta", "status": "NEGATIVE_IN_TESTED_APPARATUS", "evidence": "RESULTS/C9H01_external_travel_time_rosetta.json"},
            {"id": "C9C06", "claim": "DEE-added typo robustness", "status": "NEGATIVE_IN_TESTED_APPARATUS", "evidence": "RESULTS/C9H03_symbolic_memory_and_subsystem.json"},
            {"id": "C9C07", "claim": "learned memory regeneration without leakage", "status": "NEGATIVE_IN_TESTED_APPARATUS", "evidence": "RESULTS/C9H03_symbolic_memory_and_subsystem.json"},
            {"id": "C9C08", "claim": "adaptive repair latency/cost", "status": "NEGATIVE_IN_TESTED_APPARATUS", "evidence": "RESULTS/C9A03_adaptive_regeneration_resource.json"},
        ],
    }
    atomic_json(ROOT / "CLAIMS_CORE09.json", claims)

    complete_modules = ["C9A00", "C9D01", "C9H01", "C9D02", "C9H02", "C9D04", "C9H03", "C9A03", "C9A04", "C9A05", "C9A06"]
    update_state(
        status="SCIENCE_COMPLETE_PENDING_PACKAGE",
        current_question="CORE09 scientific stopping rule reached",
        last_completed_experiment="C9A05_FINAL_ADVERSARIAL_REVIEW",
        complete_modules=complete_modules,
        active_branches=[],
        provisional=[],
        proven=["A6_CONFIRMED_BOUNDED", "CAUSAL_1000_ASSOCIATION_MEMORY_FOUND", "ONE_SHOT_LARGE_SCALE_MEMORY_FOUND", "STRUCTURAL_DAMAGE_ROBUSTNESS_FOUND", "KNOWN_EFFECTIVE_SUBSYSTEM_FOUND"],
        refuted=["ROSETTA_R09_01", "DEE_ADDED_TYPO_ADVANTAGE", "NONLEAKING_LEARNED_MEMORY_REGENERATION", "ADAPTIVE_REPAIR", "SEMANTIC_UNDERSTANDING", "SUBSYSTEM_SUPERIORITY"],
        pending_holdout=None,
        next_action="Build, validate, copy and seal the official CORE09 package.",
    )
    append_log({"event": "SCIENCE_CLOSURE", "module_id": "C9A05", "verdicts": {"A6": "PASS_BOUNDED", "ROSETTA_R09_01": "FAIL", "memory_1000": "PASS", "learned_regeneration": "FAIL", "known_subsystem": "PASS"}})
    print(json.dumps({"status": "SCIENCE_COMPLETE_PENDING_PACKAGE", "fingerprints": len(fingerprints.get("fingerprints", [])), "parents": len(parent.get("parents", [])), "documents": 20}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
