# Survival loop

Cadena ejecutada: `context sensor → policy carrier → action port → fixed environment consequence → returning decision trace → persistent direction change → next action`. El mismo episodio puede causar daño al scaffold; la rama XNOR lo repone antes de la consulta siguiente. El host aplica una transición ambiental predefinida y no selecciona acciones.

La mejoría no es artefacto de sanación: todos los controles conservan recuperación=1.0, pero sólo el brazo contingente aprende adquisición y reversal. La acción intercambiada físicamente también pasa, mostrando que la codificación espacial particular no es esencial.
