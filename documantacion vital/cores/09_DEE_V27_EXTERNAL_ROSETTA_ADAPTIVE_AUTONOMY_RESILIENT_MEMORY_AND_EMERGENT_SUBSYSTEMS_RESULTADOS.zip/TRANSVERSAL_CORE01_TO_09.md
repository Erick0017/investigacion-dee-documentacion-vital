# Transversal CORE01–CORE09

| CORE | Aporte que sobrevive | Límite vigente |
|---|---|---|
| 01 | Q0=`raw+clock`, cono raw acotado, transporte singleton, fuentes/colisiones | no ontología física externa |
| 02 | estado predictivo separado de evento; M*, roles y fibras | sectorial |
| 03 | Q2, organización de basin, predictor multiescala acotado | dominio limitado |
| 04 | eventos S/R/C/X/D y Q3 como clases de histories productivas | no Q4 global |
| 05 | grafo de propuestas, observador interno, delay-to-place | Rosetta sólo interna |
| 06 | aprendizaje asociativo/composición, materia operacional, CHSH local | sin relatividad/quantum externos |
| 07 | atlas ejecutable, cross-feed, loop A3 one-pass | A6 no resuelta entonces |
| 08 | reductor guardado, observer task-relative, R7 fijo, boundary history acotado | no Rosetta/holografía global |
| 09 | A6 binaria confirmada; memoria 1000; subsistema efectivo conocido; Rosetta R09_01 falsada | no agencia general, no regeneración aprendida, no Rosetta validada |

La síntesis no es una pirámide lineal. Estado, guardas, relaciones de destino, history/lineage, organización y observer son coordenadas cruzadas cuya suficiencia depende de tarea y dominio.
