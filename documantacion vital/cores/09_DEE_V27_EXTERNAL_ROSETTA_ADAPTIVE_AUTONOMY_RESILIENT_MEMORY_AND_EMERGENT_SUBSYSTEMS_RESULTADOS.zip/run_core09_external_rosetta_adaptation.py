#!/usr/bin/env python3
"""Idempotent/resumable master entrypoint for the sealed CORE09 workflow."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RUNNERS = ROOT / "RUNNERS"


def complete(path: str) -> bool:
    target = ROOT / path
    if not target.exists():
        return False
    try:
        value = json.loads(target.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return False
    return value.get("status") == "COMPLETE"


def execute(script: str) -> None:
    command = [sys.executable, "-I", "-B", str(RUNNERS / script)]
    print("RUN", " ".join(command), flush=True)
    subprocess.run(command, cwd=ROOT, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--build-package", action="store_true", help="build and publish package after validating science")
    args = parser.parse_args()
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("CORE09 DEE kernel requires CPython 3.13")

    stages = [
        ("RESULTS/C9A00_initial_audit.json", "initialize_core09.py"),
        ("RESULTS/C9D01_external_calibration.json", "prepare_external_travel_time.py"),
        ("RESULTS/C9H01_external_travel_time_rosetta.json", "run_c9h01_external_rosetta.py"),
        ("RESULTS/C9D02_adaptive_survival_discovery.json", "run_c9d02_adaptive_loop_discovery.py"),
        ("RESULTS/C9H02_adaptive_policy_A6.json", "run_c9h02_a6_holdout.py"),
        ("RESULTS/C9D04_symbolic_subsystem_discovery.json", "run_c9d04_symbolic_discovery.py"),
        ("RESULTS/C9H03_symbolic_memory_and_subsystem.json", "run_c9h03_symbolic_subsystem.py"),
        ("RESULTS/C9A06_classical_symbolic_baselines.json", "run_symbolic_baselines.py"),
        ("RESULTS/C9A05_adversarial_review.json", "synthesize_core09.py"),
    ]
    resumed = []
    for result, script in stages:
        if complete(result):
            print("SKIP COMPLETE", result)
        else:
            execute(script); resumed.append(result)
    if args.build_package:
        execute("build_core09_package.py")
    print(json.dumps({"status": "COMPLETE", "resumed": resumed, "package_requested": args.build_package}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
