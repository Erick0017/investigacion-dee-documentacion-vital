# Descubrimientos nuevos de CORE10

1. Intercambio bidireccional selectivamente ablacionable entre sistemas separados.
2. Reinstanciación destructiva de una política adquirida por consecuencia, con receiver no autosuficiente y corredor completamente observado.
3. Homeostasis conjunta fija: dos guardas locales comparten una interfaz cuya pérdida de una sola celda elimina ambas restauraciones.
4. Localización de memoria intersistema en los lineages receptores después de la llegada.
5. Observer funcional task-relative que comprime `raw+clock` cúbico a dos endpoints y un horizonte.
6. Unificación arquitectónica de coupling, transfer, repair y measurement sin postular Q4.
