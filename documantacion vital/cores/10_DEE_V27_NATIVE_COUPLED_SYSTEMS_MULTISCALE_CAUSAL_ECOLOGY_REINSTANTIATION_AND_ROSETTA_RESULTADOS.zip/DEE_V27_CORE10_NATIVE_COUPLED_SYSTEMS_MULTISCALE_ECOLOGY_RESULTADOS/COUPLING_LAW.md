# Ley de coupling

En el sector collision-free congelado:

`t_arrival = 1 + d`

`t_query = 1 + d + qN`

`direction_receiver = sgn(direction_source + relay + converter)`.

El residual fue cero para N=27,29,31; d=4,6,8; cuatro frames y uno/dos ciclos. Esta ley no es una ley externa de comunicación ni una velocidad relativista.
