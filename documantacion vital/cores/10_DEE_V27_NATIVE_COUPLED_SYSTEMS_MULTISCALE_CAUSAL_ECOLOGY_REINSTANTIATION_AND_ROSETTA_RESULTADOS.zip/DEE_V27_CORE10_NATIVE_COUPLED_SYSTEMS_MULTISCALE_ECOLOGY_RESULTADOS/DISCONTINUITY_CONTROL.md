# Control de discontinuidad

Estado: `FAILED_IN_TESTED_DOMAIN`. En todos los casos primarios hubo registros consecutivos desde source hasta receiver; la función aparece tras latencia positiva y el corridor cut la elimina. No apareció destino antes de sus mediadores. La palabra teleportación no se usa como veredicto.
