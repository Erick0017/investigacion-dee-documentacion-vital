# CORE10 — veredicto ejecutivo

CORE10 alcanzó cierre científico con cuatro confirmaciones congeladas y dos negativos conservados.

- `BIDIRECTIONAL_CAUSAL_COUPLING`: **CONFIRMED, acotado**. Dos sistemas de dos puertos intercambiaron estados política por canales independientes; las ablaciones A→B y B→A fueron selectivas.
- `FUNCTIONAL_REINSTANTIATION`: **CONFIRMED, destructiva y causal**. Una política adquirida por consecuencia desapareció del puerto fuente, recorrió todos los pasos del corredor y reapareció como el mismo repertorio funcional en un receptor compatible. No se conservó el `raw` y no es teleportación.
- `JOINT_HOMEOSTASIS`: **CONFIRMED, fija y acotada**. Dos estructuras incompletas restauraron ambos centros durante cinco ciclos sólo al completar una interfaz común de cuatro celdas. No es adaptación recíproca.
- `TASK_RELATIVE_FUNCTIONAL_OBSERVER`: **CONFIRMED** en el dominio de intercambio. Dos directions de endpoint y el horizonte predicen la clase funcional; no hay cierre reducido global.
- `C10H04`: **FAIL preservado**. El claim más fuerte de cierre raw y ambigüedad universal de frontera no pasó.
- Rosetta externa: **EXTERNAL_DATA_REQUIRED**. Cinco protocolos fueron cribados; ninguno expuso el fingerprint completo. No se descargaron datos ni se ajustó una curva.

La compresión teórica ganada es una arquitectura `historia/lineage → propuesta dirigida → interfaz/guard → reductor de destino → respuesta observada`. Une cuatro familias, con ramas semánticas distintas; no es una ecuación universal ni un Q4 global.
