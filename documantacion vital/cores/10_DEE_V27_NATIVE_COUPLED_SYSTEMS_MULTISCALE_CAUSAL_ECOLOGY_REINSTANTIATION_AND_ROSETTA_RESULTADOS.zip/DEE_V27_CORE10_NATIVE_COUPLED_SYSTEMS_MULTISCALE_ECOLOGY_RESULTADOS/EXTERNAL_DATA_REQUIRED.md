# Dato externo necesario

Se requiere un protocolo row-level con preparation, donor/source state, receiver class, mediador espacial/temporal, source post-state, latency, receiver functional record, controles de receptor y una segunda observación no usada para calibrar. Idealmente dos laboratorios/datasets. Sin esos campos, borrar relaciones del fingerprint para conseguir un fit sería target leakage metodológico.
