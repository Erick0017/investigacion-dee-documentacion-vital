# CORE10 — informe final

## Autoridad y método

Se verificaron CORE01–09, CORE09=`70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96` y el kernel v27 sellado. La auditoría legacy fue dirigida; los claims v24/v25 quedaron como anclas, no confirmaciones v27. Discovery produjo un aparato inválido por leakage (`C10D01`), se conservó, se formuló otra hipótesis y sólo entonces se congeló `C10H02`.

## Resultados centrales

Los holdouts `C10H01`, `C10H02`, `C10H03` y `C10H05` pasaron todos sus gates exactos en N, seeds, distancias y frames nuevos. `C10H04` falló y permanece fallido. Las leyes de escala congeladas tuvieron residual máximo 0 y 0.

## Arquitectura resultante

`SEMANTICALLY_GUARDED_DESTINATION_INTERFACE_ARCHITECTURE`: source/history define propuestas; la topología y el medio determinan destinos/guardas; el reducer transforma el estado; el lineage conserva historia; el observer forma una equivalence class funcional. La rama semantic-1 media colisiones/transporte; semantic-4 ejecuta guardas de vecindad. La unidad correcta puede ser A+B+interfaz, pero sólo en el dominio fijado.

## Respuestas obligatorias


1. **¿Acoplamiento causal?** Sí, en dos aparatos: intercambio de políticas y guardas compartidas.
2. **¿Bidireccional?** Sí; bloquear A→B borra sólo B y bloquear B→A borra sólo A.
3. **¿El medio forma parte de la unidad?** Sí en estos dominios: relays, converter e interfaz común son causales, no cables pasivos.
4. **¿Ley predictiva?** Sí: `t_arrival=1+d`, `t_query=1+d+qN`; la salida de receptor es el signo del reducer congelado. Residual 0.
5. **¿Phase locking/entrainment/basin coupling?** No adjudicados positivamente: faltan dos osciladores autónomos y una prueba frecuencia–fase. No se renombró recurrencia toroidal como sincronía.
6. **¿La historia cambia la interacción futura?** Sí: la direction adquirida persiste en el receptor y cambia el probe futuro.
7. **¿Adaptación recíproca?** No en el aparato. Hay intercambio de memoria, no mejora/reversal endógeno; `NEW_MECHANISM_REQUIRED`.
8. **¿Joint homeostasis?** Sí, fija: ambos centros se regeneran sólo con la interfaz completa.
9. **¿Micro→macro?** Sensor/consecuencia cambia direction; fiber+relay crea ruta; cada destino del corredor media; converter reconstruye direction; el probe lee función.
10. **¿Observer mínimo?** Dos registros direction de endpoint, horizonte y la intervención declarada, sólo para la tarea binaria.
11. **¿Scaling?** Latencia afín exacta en `d,N`; recuperación local de un tick. No se ajustaron power laws.
12. **¿Función aprendida A→B?** Sí, con nuevos contextos y sin teacher nuevo.
13. **¿Qué necesita el receiver?** Converter compatible; ausente o incorrecto falla, y converter solo no responde.
14. **¿Qué identidad se conserva?** Función y clase organizacional direction; no microidentidad/raw.
15. **¿Multicast?** No demostrado; el kernel no reveló splitter y los anclajes históricos fueron negativos.
16. **¿Discontinuidad?** No. Todos los éxitos mostraron mediación secuencial y el corte de corredor los abolió.
17. **¿Estado colectivo nuevo?** `Z_joint` cierra tareas concretas, no un nivel global.
18. **¿Fingerprint más rico?** Sí: lag+receiver+history+depletion+causal cuts+functional query; y otro de threshold de interfaz+repetición.
19. **¿Justifica Rosetta externa?** Justificó cribado neutral, no fitting.
20. **¿Predicción externa?** No; ninguna fuente admitida.
21. **¿Qué falta?** Un protocolo externo con todas las variables congeladas y, para adaptación recíproca, un consequence loop endógeno entre partners.


## Cierre

No queda una pregunta interna de alta información tratable sin inventar un splitter, un loop de valencia mutua o una nueva familia de receptores. La frontera externa requiere datos; no se crea CORE11 automáticamente.
