# Identidad funcional

`MICROIDENTITY`: no preservada. `ORGANIZATIONAL IDENTITY`: preservada como clase direction/response. `FUNCTIONAL IDENTITY`: preservada en el probe no visto. Esta jerarquía predice continuidad mejor que igualdad de hash en el dominio transferido.
