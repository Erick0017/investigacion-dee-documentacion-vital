# Memoria intersistema

Después del intercambio, resetear sólo el endpoint A elimina sólo su respuesta; resetear B elimina sólo B; resetear ambos elimina ambas; limpiar las lanes vacías no altera las respuestas. En este aparato, la memoria post-arrival reside en el carrier receptor. Antes de la llegada, la historia está en el lineage que atraviesa el corredor.
