# Estado efectivo conjunto

Para exchange, `Z=(policy_A,policy_B,open_AB,open_BA,receiver_A,receiver_B,remaining_delay)` predice la tarea. Para repair, `Z=(vacancy_A,vacancy_B,outer_A,shared_mask4,outer_B)` cierra el resultado. Ambos comprimen Q0 fuertemente, pero son task-relative y no autorizan el nombre Q4.
