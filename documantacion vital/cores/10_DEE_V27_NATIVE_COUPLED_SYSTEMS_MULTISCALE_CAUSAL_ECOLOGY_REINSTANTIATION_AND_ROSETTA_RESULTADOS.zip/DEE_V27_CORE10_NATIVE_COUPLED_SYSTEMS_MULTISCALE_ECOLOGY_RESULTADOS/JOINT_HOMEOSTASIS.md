# Homeostasis conjunta

`C10H03 PASS`: durante cinco ciclos por mundo, ambos centros se restauraron en un tick sólo cuando dos outer half-scaffolds y las cuatro celdas de interfaz estaban presentes. A-only, B-only, vacío, missing-one y same-inventory shuffle tuvieron joint recovery 0. Los scaffolds fueron byte-invariantes. Es homeostasis fija y resource-supported; no aprendizaje ni cooperación intencional.
