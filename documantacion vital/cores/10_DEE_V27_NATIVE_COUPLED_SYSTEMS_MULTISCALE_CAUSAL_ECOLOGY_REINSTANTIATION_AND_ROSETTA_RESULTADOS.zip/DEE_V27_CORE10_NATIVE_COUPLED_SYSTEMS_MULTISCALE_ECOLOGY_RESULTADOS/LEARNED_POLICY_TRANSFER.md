# Transferencia de política aprendida

La política inicial `a` recibió una experiencia ordinaria de consecuencia y normalización que produjo `b`, mecanismo heredado de A6 CORE09. Sin teacher nuevo, `b` fue mediada hacia B. Trained, nuisance s_reg y off-path pasaron; untrained, memory/history/direction ablation, corridor cut, no/wrong receiver y no relay fallaron. El primer converter de discovery contenía accidentalmente la respuesta; ese aparato permanece negativo y motivó un nuevo ID.
