# Medio e interfaz

El medio no fue tratado como cable pasivo. El relay decide qué direction entra al corredor; el converter decide qué clase puede reconstruirse; una interfaz semantic-4 de cuatro celdas completa simultáneamente dos guardas. Receiver ausente/incorrecto, corredor cancelado y pérdida de una celda compartida falsan sus respectivos fenómenos. El control same-inventory shuffled excluye recuento puro, no la geometría: la geometría es precisamente parte causal del mecanismo.
