# Transferencia multicast

Estado: `NEW_MECHANISM_REQUIRED`. CORE10 no descubrió un splitter causal: cada propuesta tiene un destino. Duplicar carriers en Python sería precodificar copias. WARPCAST/INFOCLONE históricos permanecen anclas negativas; no se abrió un holdout sin mecanismo nuevo.
