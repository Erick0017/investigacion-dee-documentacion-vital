# Ecología causal multiescala

MICRO: raw/clock y suma de directions en un destino. MESO: route lineage, receiver interface y shared guard. MACRO: policy response o restoration class. INTERSYSTEM: dos efectos direccionales, lag y estado conjunto. Las ablaciones unen estos niveles causalmente. No se usó mutual information como sustituto de intervención.
