# Observer multiescala

`C10H04` falló y no se repara. `C10H05`, con nueva hipótesis y datos, confirmó sólo cierre funcional: direction en A/B, horizonte N y la intervención declarada predicen la clase de acción. Pares con igual inventario, frontera instantánea y occupancy multiview tuvieron futuros distintos. Direction/history es información invisible para esos observers simples.

La reducción es task-relative. No existe evidencia de observer reducido global.
