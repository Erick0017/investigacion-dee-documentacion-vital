# Sistemas DEE nativos acoplados

`C10H01` confirmó `BIDIRECTIONAL_CAUSAL_COUPLING` mediante dos canales paralelos. `A_only` activó sólo B; `B_only` sólo A; vacío y no-connection no activaron ninguno. Los bloqueos fueron direccionalmente selectivos y el corte fuera de ruta fue nulo. El resultado es suma de dos influencias causales one-way, no acoplamiento no lineal ni sincronía.

`C10H03` confirmó una segunda clase: acoplamiento estructural por guardas superpuestas. Aquí el medio/interfaz pertenece a la unidad funcional.
