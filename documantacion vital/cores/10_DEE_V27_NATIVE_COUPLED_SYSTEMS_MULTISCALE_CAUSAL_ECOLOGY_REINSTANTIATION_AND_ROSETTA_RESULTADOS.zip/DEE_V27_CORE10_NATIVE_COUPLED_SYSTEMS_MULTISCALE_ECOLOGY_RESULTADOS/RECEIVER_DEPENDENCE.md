# Dependencia del receptor

El receiver compatible es necesario pero no suficiente: converter+probe no produce ACTION1, mientras route+converter reconstruye `b`. Receiver ausente o incorrecto falla. CORE10 no reestimó el antiguo umbral de scaffold 27<Smin≤98 porque el aparato actual usa un converter mínimo diferente.
