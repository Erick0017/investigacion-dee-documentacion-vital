# Adaptación recíproca

Estado final: `NEW_MECHANISM_REQUIRED`. La historia A↔B modifica persistentemente los endpoints porque las políticas se intercambian, pero el mapa es fijo: no optimiza estabilidad, no muestra reversal inducido por partner ni contiene valencia endógena mutua. Llamarlo aprendizaje recíproco confundiría transferencia con adaptación.
