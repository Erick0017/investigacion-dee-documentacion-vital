# Causalidad recíproca

Confirmada en el sentido operacional acotado: intervenir A cambia B y no A; intervenir B cambia A y no B; ambos efectos viajan por mediadores distintos y con latencia positiva. No se infiere una interacción instantánea ni un campo externo.
