param(
    [string]$Python = $env:DEE_PYTHON
)

$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($Python)) {
    $Preferred = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
    if (Test-Path -LiteralPath $Preferred) { $Python = $Preferred } else { $Python = 'python' }
}

& $Python -I -B (Join-Path $PSScriptRoot 'run_core10_native_coupled_ecology.py') --validate-only
if ($LASTEXITCODE -ne 0) { throw "CORE10 validation failed with exit code $LASTEXITCODE" }
