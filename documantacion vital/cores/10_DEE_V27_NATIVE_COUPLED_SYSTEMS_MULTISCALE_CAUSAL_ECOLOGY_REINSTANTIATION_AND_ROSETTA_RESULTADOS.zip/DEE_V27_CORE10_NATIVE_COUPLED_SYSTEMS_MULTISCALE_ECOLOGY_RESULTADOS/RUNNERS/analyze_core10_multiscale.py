#!/usr/bin/env python3
"""Derive scale laws, causal ladders, unified architecture and readiness from frozen results."""
from __future__ import annotations

import json
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, update_state, utc_now


def load(name): return json.loads((ROOT / "RESULTS" / name).read_text(encoding="utf-8"))


def main():
    h01=load("C10H01_bidirectional_exchange.json"); h02=load("C10H02_learned_policy_reinstantiation.json"); h03=load("C10H03_joint_interface_homeostasis.json"); h04=load("C10H04_task_relative_observer.json"); h05=load("C10H05_functional_observer.json")
    exchange=[c for c in h01["cases"] if c["mode"]=="AB"]
    transfer=[c for c in h02["cases"] if c["mode"]=="trained"]
    scale={
        "exchange": {"law":"t_arrival=1+d; t_query=1+d+qN","arrival_max_abs_residual":max(abs(c["arrival_tick"]-(1+c["distance"])) for c in exchange),"query_max_abs_residual":max(abs(c["query_tick"]-(1+c["distance"]+c["query_cycles"]*c["n"])) for c in exchange),"N":sorted(set(c["n"] for c in exchange)),"distances":sorted(set(c["distance"] for c in exchange))},
        "learned_transfer": {"law":"t_learn=2N; t_launch=3N; t_arrival=3N+d; t_query=4N+d","max_abs_residual":max(max(abs(c["ticks"]["learned"]-2*c["n"]),abs(c["ticks"]["launch"]-3*c["n"]),abs(c["ticks"]["arrival"]-(3*c["n"]+c["distance"])),abs(c["ticks"]["query"]-(4*c["n"]+c["distance"]))) for c in transfer),"N":sorted(set(c["n"] for c in transfer)),"distances":sorted(set(c["distance"] for c in transfer))},
        "joint_homeostasis": {"law":"t_recovery=1 tick when both outer half-scaffolds and the four-cell interface are complete","cycles_per_case":h03["cycles_per_case"],"N":sorted(set(c["n"] for c in h03["cases"] if c["mode"]=="AB")),"axes":sorted(set(c["axis"] for c in h03["cases"] if c["mode"]=="AB"))},
        "power_law_policy":"No power-law fit was needed: the locked affine/discrete relations have zero residual in-domain.",
    }
    trace={
        "policy_reinstantiation": [
            {"level":"MICRO","event":"sensor collides with policy; fixed consequence+normalizer changes direction a->b"},
            {"level":"FIBER_REDUCER","event":"learned b and relay share destination; guarded reducer emits route direction"},
            {"level":"LINEAGE_HISTORY","event":"direction class b is the persistent experience-dependent state; s_reg nuisance is irrelevant"},
            {"level":"MESO_INTERFACE","event":"one route carrier occupies each successive corridor destination; cancellation cuts function"},
            {"level":"RECEIVER","event":"inverse interface plus route reconstructs b; converter alone is nonfunctional"},
            {"level":"MACRO_FUNCTION","event":"unseen-context query emits ACTION1; source port remains depleted"},
            {"level":"OBSERVER","event":"endpoint direction quotient predicts the functional future exactly"},
        ],
        "joint_homeostasis": [
            {"level":"MICRO","event":"four shared semantic-4 corner cells complete two eight-corner guards"},
            {"level":"MESO_INTERFACE","event":"remove one shared cell and both guards fail; same-count shuffle fails"},
            {"level":"MACRO","event":"two centers restore in one tick for five repeated damage cycles"},
            {"level":"JOINT_STATE","event":"Z=(vacancy_A,vacancy_B,outer_A_complete,shared_mask,outer_B_complete) closes the tested recovery task"},
        ],
        "causal_verification":"direction/history reset, path cancellation, receiver deletion, one-cell interface cut, same-inventory shuffle and off-path controls intervene on successive links",
    }
    observer={
        "global_reduced_observer":"NOT_CLAIMED",
        "task_relative_observers":{
            "coupled_policy_future":"endpoint direction records + horizon + declared intervention",
            "transfer":"learned direction + relay/path/receiver compatibility + remaining causal depth",
            "joint_repair":"two outer-completeness flags + four-bit shared mask + vacancy flags",
        },
        "C10H04":"FAIL preserved: omnibus raw-record and universal boundary gates failed",
        "C10H05":"PASS: distinct functional quotient on new worlds",
        "compression":"upper bound 128+ceil(log2(N+1)) bits versus 128*N^3 raw+clock bits for the coupled response task",
        "invisible_information":"direction/history distinguishes matched worlds with identical occupancy projections, bulk inventory and instantaneous boundary",
        "dimensional_extra":h05["dimensional_adjudication"],
    }
    unified={
        "status":"BOUNDED_CONFIRMED_ARCHITECTURE_NOT_GLOBAL_SINGLE_LAW",
        "name":"SEMANTICALLY_GUARDED_DESTINATION_INTERFACE_ARCHITECTURE",
        "components":["source/policy state", "directed proposal", "destination/interface geometry", "semantic guard branch", "fiber reduction", "lineage/history", "task-relative observer"],
        "domains_explained":["bidirectional policy exchange", "destructive learned-policy reinstantiation", "shared-interface repeated restoration", "functional observer quotient"],
        "common_statement":"A future response is determined by which guarded destination relation is available, what history-bearing lineage proposes into it, and how the receiver/interface reduces that proposal.",
        "branch_specificity":{"semantic_1":"collision/fiber reduction transfers direction/history through a route","semantic_4":"neighborhood guard creates a center when its exact relational scaffold is complete"},
        "why_not_one_equation":"The two semantic branches have different guards and outputs; unification is architectural, not a scalar conservation law.",
        "missing_for_global_closure":["arbitrary preparation families", "multi-lineage congestion", "source/sink sectors", "adaptive reciprocal consequence", "closed resource accounting"],
        "new_level":"No global Q4. Z_joint is an autonomous finite task-relative state only in the locked exchange/repair domains.",
        "major_internal_result":True,
        "major_result_basis":"one guarded-destination/interface architecture survives independent controls in four previously separated families",
    }
    unresolved={
        "reciprocal_adaptation":{"state":"NEW_MECHANISM_REQUIRED","evidence":"coupling exchanges persistent policies in both directions, but the transition is a fixed receiver-mediated permutation; no endogenous improvement/reversal metric or partner-contingent valence exists","not_equivalent_to":"HISTORY_DEPENDENT_COUPLING, which is confirmed"},
        "phase_locking":{"state":"NOT_JUSTIFIED_TO_TEST","reason":"the apparatus carries recurrent policies but has no two autonomous oscillators with frequency response, slips or entrainment threshold"},
        "entrainment":{"state":"NOT_JUSTIFIED_TO_TEST","reason":"no new oscillator-coupling mechanism"},
        "multicast":{"state":"NEW_MECHANISM_REQUIRED","reason":"one DEE proposal has one destination; CORE10 discovered no causal splitter, and historical WARPCAST/INFOCLONE identity was negative"},
        "discontinuous_remote_effect":{"state":"FAILED_IN_TESTED_DOMAIN","evidence":"all successful C10H02 cases contain every sequential corridor step and corridor cancellation abolishes the destination function"},
        "receiver_minimum":{"state":"BOUNDED","evidence":"correct converter required; absent/wrong receiver fails","limit":"minimum scaffold depth outside the one-converter policy apparatus was not remapped"},
        "reciprocal_memory":{"state":"BOUNDED_CONFIRMED","evidence":"selective receiver reset removes only the corresponding future response; clearing empty lanes does not","locus":"receiver endpoint lineage after arrival"},
    }
    fingerprints={
        "schema":"dee.v27.core10.neutral_fingerprints.v1","frozen_utc":utc_now(),"matching_names_hidden":True,"candidates":[
            {"fingerprint_id":"C10PHI01","internal_name":"destructive functional reinstantiation","status":"CONFIRMED_MULTIRELATIONAL","preparation":"experience changes a persistent direction class a->b; causal relay and compatible receiver are prepared","components":["history-bearing lineage","relay","corridor","receiver interface"],"coupling_topology":"directed path","intervention":"unseen-context probe after source depletion","causal_direction":"A->corridor->B","response":"ACTION1 only for learned compatible route","lag":"3N+d arrival; 4N+d queried function","history_dependence":"untrained/history reset fail","threshold":"all path and receiver conditions required","hysteresis":"not established","relaxation":"N-tick toroidal recurrence","scaling":"unit transport lag in d plus recurrence in N","symmetry":"translations and four rotated/reflected frames","observer":"endpoint direction quotient","functional_transfer":True,"adaptation":"policy was consequence-acquired before transfer","resource_change":"s_reg nuisance invariant; no energy interpretation","falsifiers":["converter-only response","path bypass","untrained transfer","source not depleted"],"relations_independent":6},
            {"fingerprint_id":"C10PHI02","internal_name":"joint interface restoration","status":"CONFIRMED_MULTIRELATIONAL","preparation":"two vacant centers, two outer half-scaffolds and shared four-cell interface","components":["A outer guard","B outer guard","shared interface"],"coupling_topology":"overlapping guarded neighborhoods","intervention":"repeated deletion","causal_direction":"interface completeness->two center births","response":"both restore in one tick","lag":1,"history_dependence":"fixed repeated cycles, no adaptation","threshold":"remove one shared cell and joint response is zero","scaling":"N-independent local law in tested N","symmetry":"three axes, translations by construction, payload nuisance","observer":"five Boolean relational features","functional_transfer":False,"adaptation":False,"resource_change":"scaffold byte-invariant; center births accounted","falsifiers":["same-count shuffle restores","isolated incomplete half restores both"],"relations_independent":5},
            {"fingerprint_id":"C10PHI03","internal_name":"bidirectional policy exchange","status":"CONFIRMED_MULTIRELATIONAL","preparation":"two distinct periodic policy lineages and two parallel receiver-mediated paths","components":["A","B","two interfaces","two lanes"],"coupling_topology":"two directed parallel channels","intervention":"source/path/receiver selective ablations","causal_direction":"A->B and B->A independently","response":"persistent swapped functional classes","lag":"1+d; preserved qN","history_dependence":"receiver state records partner policy","threshold":"path open and compatible receiver","scaling":"affine exact lag","symmetry":"N, distance, frames","observer":"two endpoint direction classes","functional_transfer":True,"adaptation":False,"resource_change":"not a closed cycle","falsifiers":["A removal leaves B response","path block has no effect","off-path block changes effect"],"relations_independent":5},
        ]}
    alternatives={"schema":"dee.v27.core10.alternatives.v2","claims":[
        {"claim_id":"C10H01","primary_mechanism":"two independent causal lanes plus receiver reducers","simpler_alternative":"receiver/background or common mode","matched_control":"A/B/empty, no connection, selective path blocks","decisive_intervention":"block A route removes only B response; block B removes only A","holdout_result":"PASS"},
        {"claim_id":"C10H02","primary_mechanism":"experience-bearing direction class mediated and reconstructed","simpler_alternative":"receiver converter contains answer","matched_control":"C10D01 exposed exactly this leakage; redesigned converter null plus all causal ablations","decisive_intervention":"history/direction/corridor/receiver ablations each abolish function while s_reg/off-path do not","holdout_result":"PASS after distinct C10D01 failed discovery; no holdout repaired"},
        {"claim_id":"C10H03","primary_mechanism":"shared exact interface completes both local guards","simpler_alternative":"support count/double resources","matched_control":"same 12-cell inventory shuffled and full single-center positive controls","decisive_intervention":"one shared cell removal abolishes joint restoration","holdout_result":"PASS"},
        {"claim_id":"C10H04","primary_mechanism":"raw endpoint closure plus universal boundary ambiguity","simpler_alternative":"functional rather than raw equivalence and boundary contact in rotated worlds","matched_control":"new C10H05 only after preserving H04 FAIL","decisive_intervention":"none can repair H04; it remains FAIL","holdout_result":"FAIL"},
        {"claim_id":"C10H05","primary_mechanism":"task-relative functional quotient and receiver memory locus","simpler_alternative":"inventory/boundary/occupancy projection or lane memory","matched_control":"interior AB/wrong-receiver pairs, selective resets, lane clear","decisive_intervention":"endpoint reset selective; lane clear null","holdout_result":"PASS"},
    ]}
    result={"schema":"dee.v27.core10.multiscale_analysis.v1","module_id":"C10A04_MULTISCALE_CAUSAL_ECOLOGY_AND_UNIFICATION","status":"COMPLETE","role":"DERIVATION_FROM_FROZEN_RESULTS","scale_laws":scale,"causal_trace":trace,"observer":observer,"unified_architecture":unified,"conditional_fronts":unresolved,"fingerprint_readiness":{"C10PHI01":"INTERNAL_GATE_EARNED","C10PHI02":"INTERNAL_GATE_EARNED","C10PHI03":"INTERNAL_GATE_EARNED","external_gate":"requires a pre-existing external protocol with all relational variables; single t~d is forbidden"},"evidence_files":["C10H01_bidirectional_exchange.json","C10H02_learned_policy_reinstantiation.json","C10H03_joint_interface_homeostasis.json","C10H04_task_relative_observer.json","C10H05_functional_observer.json"]}
    result["content_sha256"]=canonical_hash(result); atomic_json(ROOT/"RESULTS/C10A04_multiscale_unified_analysis.json",result); atomic_json(ROOT/"NEUTRAL_FINGERPRINTS_CORE10.json",fingerprints); atomic_json(ROOT/"ALTERNATIVE_EXPLANATIONS.json",alternatives)
    append_log({"event":"ANALYSIS_COMPLETE","module_id":result["module_id"],"major_internal_result":True,"external_gate":"CONDITIONAL_SCREENING_EARNED"})
    question({"question_id":"C10Q06","parent_question_id":"C10H03","front":"multiscale","why_this_question":"three independent holdouts may share a smaller architecture","kernel_response_that_triggered_it":"exchange, learned transfer and joint restoration all depend on guarded destinations/interfaces","hypotheses_being_separated":["one architecture","unrelated coincidences","global Q4"],"experiment":"cross-holdout causal mediation and compression","controls":["semantic branch separation","alternative explanations","failed H04 retained"],"measurement":"number of domains explained, residual scale laws, observer compression","result":{"unified":unified["status"],"scale_laws":scale,"new_level":unified["new_level"]},"next_questions":["neutral external protocol availability"],"status":"CONFIRMED"})
    question({"question_id":"C10Q07","parent_question_id":"C10H01","front":"adaptation","why_this_question":"bidirectional history could be mistaken for mutual learning","kernel_response_that_triggered_it":"policies exchange persistently but transition is a fixed permutation","hypotheses_being_separated":["reciprocal adaptation","history-dependent transfer","fixed reflex"],"experiment":"inspect repeated qN persistence, selective reset and presence/absence of improvement/reversal operator","controls":["no teacher","resets","fixed interface"],"measurement":"persistent response versus improvement metric","result":unresolved["reciprocal_adaptation"],"next_questions":[],"status":"CLOSED"})
    dialogue("Does one operator explain tree, forest and interacting forests?","C10A04 cross-domain derivation",{"unified":unified,"scale":scale,"unresolved":unresolved},"The common result is an interface architecture with semantic branch specificity, not a global scalar law or nominal Q4.",["geometry-only","inventory-only","single universal law","post-hoc power law"],"Screen external protocols neutrally; fit nothing unless the full fingerprint can be frozen.","HIGH","CROSS_HOLDOUT_DERIVATION")
    prior=json.loads((ROOT/"STATE.json").read_text(encoding="utf-8")); update_state(last_completed_experiment=result["module_id"],complete_modules=prior.get("complete_modules",[])+[result["module_id"]],current_question="Does an independent external protocol expose the full frozen fingerprint, or is external matching not justified?",rosetta_readiness="CONDITIONAL_SCREENING_EARNED",next_action="Perform one neutral external-protocol availability screen; do not fit a single-relation analogue.")
    print(json.dumps({"status":"PASS","unified":unified["status"],"external_screen":"EARNED","scale":scale},indent=2)); return 0


if __name__=="__main__": raise SystemExit(main())
