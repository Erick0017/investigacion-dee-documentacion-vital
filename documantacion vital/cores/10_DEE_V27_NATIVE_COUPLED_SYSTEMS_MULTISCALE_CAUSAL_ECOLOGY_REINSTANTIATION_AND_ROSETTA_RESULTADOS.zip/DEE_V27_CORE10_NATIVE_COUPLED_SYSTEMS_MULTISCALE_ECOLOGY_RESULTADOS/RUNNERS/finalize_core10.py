#!/usr/bin/env python3
"""Adversarial synthesis, documentation, manifest, package and expediente publication."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import time
import zipfile
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from core10_common import ROOT, TESTS, append_log, atomic_json, atomic_text, canonical_hash, sha256_file, utc_now

ZIP_NAME="10_DEE_V27_NATIVE_COUPLED_SYSTEMS_MULTISCALE_CAUSAL_ECOLOGY_REINSTANTIATION_AND_ROSETTA_RESULTADOS.zip"
PREFIX="DEE_V27_CORE10_NATIVE_COUPLED_SYSTEMS_MULTISCALE_ECOLOGY_RESULTADOS"


def load(name): return json.loads((ROOT/"RESULTS"/name).read_text(encoding="utf-8"))
def md(name,title,body): atomic_text(ROOT/name,f"# {title}\n\n{body.strip()}\n")


def selected_files():
    files=[]
    for p in ROOT.iterdir():
        if p.is_file() and p.name not in {"HASHES.sha256"} and p.suffix.lower() in {".md",".json",".ndjson",".ps1",".py"}: files.append(p)
    for dirname in ("HOLDOUT_LOCKS","RESULTS","RUNNERS","KERNEL","questions","CHECKPOINTS"):
        base=ROOT/dirname
        if base.exists(): files.extend(p for p in base.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    parent=ROOT/"PARENTS"/"09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip"
    files.append(parent)
    return sorted(set(files),key=lambda p:p.relative_to(ROOT).as_posix())


def docs(h01,h02,h03,h04,h05,analysis,external):
    scale=analysis["scale_laws"]; unified=analysis["unified_architecture"]
    md("EXECUTIVE_VERDICT.md","CORE10 — veredicto ejecutivo",f"""
CORE10 alcanzó cierre científico con cuatro confirmaciones congeladas y dos negativos conservados.

- `BIDIRECTIONAL_CAUSAL_COUPLING`: **CONFIRMED, acotado**. Dos sistemas de dos puertos intercambiaron estados política por canales independientes; las ablaciones A→B y B→A fueron selectivas.
- `FUNCTIONAL_REINSTANTIATION`: **CONFIRMED, destructiva y causal**. Una política adquirida por consecuencia desapareció del puerto fuente, recorrió todos los pasos del corredor y reapareció como el mismo repertorio funcional en un receptor compatible. No se conservó el `raw` y no es teleportación.
- `JOINT_HOMEOSTASIS`: **CONFIRMED, fija y acotada**. Dos estructuras incompletas restauraron ambos centros durante cinco ciclos sólo al completar una interfaz común de cuatro celdas. No es adaptación recíproca.
- `TASK_RELATIVE_FUNCTIONAL_OBSERVER`: **CONFIRMED** en el dominio de intercambio. Dos directions de endpoint y el horizonte predicen la clase funcional; no hay cierre reducido global.
- `C10H04`: **FAIL preservado**. El claim más fuerte de cierre raw y ambigüedad universal de frontera no pasó.
- Rosetta externa: **EXTERNAL_DATA_REQUIRED**. Cinco protocolos fueron cribados; ninguno expuso el fingerprint completo. No se descargaron datos ni se ajustó una curva.

La compresión teórica ganada es una arquitectura `historia/lineage → propuesta dirigida → interfaz/guard → reductor de destino → respuesta observada`. Une cuatro familias, con ramas semánticas distintas; no es una ecuación universal ni un Q4 global.
""")
    answers="""
1. **¿Acoplamiento causal?** Sí, en dos aparatos: intercambio de políticas y guardas compartidas.
2. **¿Bidireccional?** Sí; bloquear A→B borra sólo B y bloquear B→A borra sólo A.
3. **¿El medio forma parte de la unidad?** Sí en estos dominios: relays, converter e interfaz común son causales, no cables pasivos.
4. **¿Ley predictiva?** Sí: `t_arrival=1+d`, `t_query=1+d+qN`; la salida de receptor es el signo del reducer congelado. Residual 0.
5. **¿Phase locking/entrainment/basin coupling?** No adjudicados positivamente: faltan dos osciladores autónomos y una prueba frecuencia–fase. No se renombró recurrencia toroidal como sincronía.
6. **¿La historia cambia la interacción futura?** Sí: la direction adquirida persiste en el receptor y cambia el probe futuro.
7. **¿Adaptación recíproca?** No en el aparato. Hay intercambio de memoria, no mejora/reversal endógeno; `NEW_MECHANISM_REQUIRED`.
8. **¿Joint homeostasis?** Sí, fija: ambos centros se regeneran sólo con la interfaz completa.
9. **¿Micro→macro?** Sensor/consecuencia cambia direction; fiber+relay crea ruta; cada destino del corredor media; converter reconstruye direction; el probe lee función.
10. **¿Observer mínimo?** Dos registros direction de endpoint, horizonte y la intervención declarada, sólo para la tarea binaria.
11. **¿Scaling?** Latencia afín exacta en `d,N`; recuperación local de un tick. No se ajustaron power laws.
12. **¿Función aprendida A→B?** Sí, con nuevos contextos y sin teacher nuevo.
13. **¿Qué necesita el receiver?** Converter compatible; ausente o incorrecto falla, y converter solo no responde.
14. **¿Qué identidad se conserva?** Función y clase organizacional direction; no microidentidad/raw.
15. **¿Multicast?** No demostrado; el kernel no reveló splitter y los anclajes históricos fueron negativos.
16. **¿Discontinuidad?** No. Todos los éxitos mostraron mediación secuencial y el corte de corredor los abolió.
17. **¿Estado colectivo nuevo?** `Z_joint` cierra tareas concretas, no un nivel global.
18. **¿Fingerprint más rico?** Sí: lag+receiver+history+depletion+causal cuts+functional query; y otro de threshold de interfaz+repetición.
19. **¿Justifica Rosetta externa?** Justificó cribado neutral, no fitting.
20. **¿Predicción externa?** No; ninguna fuente admitida.
21. **¿Qué falta?** Un protocolo externo con todas las variables congeladas y, para adaptación recíproca, un consequence loop endógeno entre partners.
"""
    md("FINAL_REPORT.md","CORE10 — informe final",f"""
## Autoridad y método

Se verificaron CORE01–09, CORE09=`70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96` y el kernel v27 sellado. La auditoría legacy fue dirigida; los claims v24/v25 quedaron como anclas, no confirmaciones v27. Discovery produjo un aparato inválido por leakage (`C10D01`), se conservó, se formuló otra hipótesis y sólo entonces se congeló `C10H02`.

## Resultados centrales

Los holdouts `C10H01`, `C10H02`, `C10H03` y `C10H05` pasaron todos sus gates exactos en N, seeds, distancias y frames nuevos. `C10H04` falló y permanece fallido. Las leyes de escala congeladas tuvieron residual máximo {scale['exchange']['arrival_max_abs_residual']} y {scale['learned_transfer']['max_abs_residual']}.

## Arquitectura resultante

`{unified['name']}`: source/history define propuestas; la topología y el medio determinan destinos/guardas; el reducer transforma el estado; el lineage conserva historia; el observer forma una equivalence class funcional. La rama semantic-1 media colisiones/transporte; semantic-4 ejecuta guardas de vecindad. La unidad correcta puede ser A+B+interfaz, pero sólo en el dominio fijado.

## Respuestas obligatorias

{answers}

## Cierre

No queda una pregunta interna de alta información tratable sin inventar un splitter, un loop de valencia mutua o una nueva familia de receptores. La frontera externa requiere datos; no se crea CORE11 automáticamente.
""")
    md("TRANSVERSAL_CORE01_TO_10.md","Síntesis transversal CORE01–10","""
| CORE | Aporte acumulado relevante para CORE10 |
|---|---|
| 01 | Q0 raw+clock, causalidad local, transporte y reducer sectorial |
| 02 | estado/evento, roles y fibras predictivas |
| 03 | organización Q2 y cierre multiescala acotado |
| 04 | historias productivas Q3; no Q4 global |
| 05 | proposal graph, destination fibers, observer y medición interna |
| 06 | aprendizaje nativo, composición, materia operacional y límites relativistas/cuánticos |
| 07 | atlas, cross-feeding, transferencia funcional y feedback one-pass |
| 08 | observer task-relative, regeneración fija y dimensionalidad acotada |
| 09 | A6 binario, gran memoria causal, subsistema conocido y Rosetta externa P/S fallida |
| 10 | acoplamiento bidireccional, política A6 reinstanciada, interfaz homeostática conjunta y observer funcional reducido |

La secuencia no forma una pirámide universal Q0→Q4. Produce coordenadas cruzadas: estado, direction/routing, guard, fiber, history, interfaz, organización y observer.
""")
    md("CORE10_NEW_DISCOVERIES.md","Descubrimientos nuevos de CORE10","""
1. Intercambio bidireccional selectivamente ablacionable entre sistemas separados.
2. Reinstanciación destructiva de una política adquirida por consecuencia, con receiver no autosuficiente y corredor completamente observado.
3. Homeostasis conjunta fija: dos guardas locales comparten una interfaz cuya pérdida de una sola celda elimina ambas restauraciones.
4. Localización de memoria intersistema en los lineages receptores después de la llegada.
5. Observer funcional task-relative que comprime `raw+clock` cúbico a dos endpoints y un horizonte.
6. Unificación arquitectónica de coupling, transfer, repair y measurement sin postular Q4.
""")
    md("NATIVE_COUPLED_SYSTEMS.md","Sistemas DEE nativos acoplados","""
`C10H01` confirmó `BIDIRECTIONAL_CAUSAL_COUPLING` mediante dos canales paralelos. `A_only` activó sólo B; `B_only` sólo A; vacío y no-connection no activaron ninguno. Los bloqueos fueron direccionalmente selectivos y el corte fuera de ruta fue nulo. El resultado es suma de dos influencias causales one-way, no acoplamiento no lineal ni sincronía.

`C10H03` confirmó una segunda clase: acoplamiento estructural por guardas superpuestas. Aquí el medio/interfaz pertenece a la unidad funcional.
""")
    md("COUPLING_LAW.md","Ley de coupling","""
En el sector collision-free congelado:

`t_arrival = 1 + d`

`t_query = 1 + d + qN`

`direction_receiver = sgn(direction_source + relay + converter)`.

El residual fue cero para N=27,29,31; d=4,6,8; cuatro frames y uno/dos ciclos. Esta ley no es una ley externa de comunicación ni una velocidad relativista.
""")
    md("MEDIUM_AND_INTERFACE.md","Medio e interfaz","""
El medio no fue tratado como cable pasivo. El relay decide qué direction entra al corredor; el converter decide qué clase puede reconstruirse; una interfaz semantic-4 de cuatro celdas completa simultáneamente dos guardas. Receiver ausente/incorrecto, corredor cancelado y pérdida de una celda compartida falsan sus respectivos fenómenos. El control same-inventory shuffled excluye recuento puro, no la geometría: la geometría es precisamente parte causal del mecanismo.
""")
    md("RECIPROCAL_CAUSALITY.md","Causalidad recíproca","""
Confirmada en el sentido operacional acotado: intervenir A cambia B y no A; intervenir B cambia A y no B; ambos efectos viajan por mediadores distintos y con latencia positiva. No se infiere una interacción instantánea ni un campo externo.
""")
    md("RECIPROCAL_ADAPTATION.md","Adaptación recíproca","""
Estado final: `NEW_MECHANISM_REQUIRED`. La historia A↔B modifica persistentemente los endpoints porque las políticas se intercambian, pero el mapa es fijo: no optimiza estabilidad, no muestra reversal inducido por partner ni contiene valencia endógena mutua. Llamarlo aprendizaje recíproco confundiría transferencia con adaptación.
""")
    md("JOINT_HOMEOSTASIS.md","Homeostasis conjunta","""
`C10H03 PASS`: durante cinco ciclos por mundo, ambos centros se restauraron en un tick sólo cuando dos outer half-scaffolds y las cuatro celdas de interfaz estaban presentes. A-only, B-only, vacío, missing-one y same-inventory shuffle tuvieron joint recovery 0. Los scaffolds fueron byte-invariantes. Es homeostasis fija y resource-supported; no aprendizaje ni cooperación intencional.
""")
    md("INTERSYSTEM_MEMORY.md","Memoria intersistema","""
Después del intercambio, resetear sólo el endpoint A elimina sólo su respuesta; resetear B elimina sólo B; resetear ambos elimina ambas; limpiar las lanes vacías no altera las respuestas. En este aparato, la memoria post-arrival reside en el carrier receptor. Antes de la llegada, la historia está en el lineage que atraviesa el corredor.
""")
    md("MULTISCALE_CAUSAL_ECOLOGY.md","Ecología causal multiescala","""
MICRO: raw/clock y suma de directions en un destino. MESO: route lineage, receiver interface y shared guard. MACRO: policy response o restoration class. INTERSYSTEM: dos efectos direccionales, lag y estado conjunto. Las ablaciones unen estos niveles causalmente. No se usó mutual information como sustituto de intervención.
""")
    md("TREE_TO_FOREST_CAUSAL_TRACE.md","Trazado causal árbol→bosque","""
`experience → direction b → relay/fiber → route carrier → cada celda del corridor → receiver reducer → b receptor → unseen sensor → ACTION1`.

En reparación: `shared corner bit → complete eight-corner guards A/B → two center births → joint recovery record`. Un corte causal en cualquier eslabón necesario elimina el efecto; cortes fuera de ruta no.
""")
    md("MULTISCALE_OBSERVER.md","Observer multiescala","""
`C10H04` falló y no se repara. `C10H05`, con nueva hipótesis y datos, confirmó sólo cierre funcional: direction en A/B, horizonte N y la intervención declarada predicen la clase de acción. Pares con igual inventario, frontera instantánea y occupancy multiview tuvieron futuros distintos. Direction/history es información invisible para esos observers simples.

La reducción es task-relative. No existe evidencia de observer reducido global.
""")
    md("SCALE_LAWS.md","Leyes de escala",f"""
- Exchange: `1+d` y `1+d+qN`, residual máximo {scale['exchange']['arrival_max_abs_residual']}.
- Learned transfer: `2N`, `3N`, `3N+d`, `4N+d`, residual máximo {scale['learned_transfer']['max_abs_residual']}.
- Joint repair: un tick, local e independiente de N en {scale['joint_homeostasis']['N']}.

No se ajustó criticality ni power law. El boundary history denso usa O(N²) celdas por O(N) ticks, por lo que su presupuesto es O(N³), no area law.
""")
    md("FUNCTIONAL_REINSTANTIATION.md","Reinstanciación funcional","""
La clase confirmada es `CAUSAL_TRANSPORT + DESTRUCTIVE_FUNCTIONAL_REINSTANTIATION`. El source port queda vacío; el raw cambia en reducers; el receiver conserva la direction class y responde correctamente a un contexto no usado durante adquisición. Cada paso de corredor fue observado y el corte causal abolió la función.

No es continuidad de materia, microidentidad ni efecto remoto discontinuo.
""")
    md("LEARNED_POLICY_TRANSFER.md","Transferencia de política aprendida","""
La política inicial `a` recibió una experiencia ordinaria de consecuencia y normalización que produjo `b`, mecanismo heredado de A6 CORE09. Sin teacher nuevo, `b` fue mediada hacia B. Trained, nuisance s_reg y off-path pasaron; untrained, memory/history/direction ablation, corridor cut, no/wrong receiver y no relay fallaron. El primer converter de discovery contenía accidentalmente la respuesta; ese aparato permanece negativo y motivó un nuevo ID.
""")
    md("RECEIVER_DEPENDENCE.md","Dependencia del receptor","""
El receiver compatible es necesario pero no suficiente: converter+probe no produce ACTION1, mientras route+converter reconstruye `b`. Receiver ausente o incorrecto falla. CORE10 no reestimó el antiguo umbral de scaffold 27<Smin≤98 porque el aparato actual usa un converter mínimo diferente.
""")
    md("FUNCTIONAL_IDENTITY.md","Identidad funcional","""
`MICROIDENTITY`: no preservada. `ORGANIZATIONAL IDENTITY`: preservada como clase direction/response. `FUNCTIONAL IDENTITY`: preservada en el probe no visto. Esta jerarquía predice continuidad mejor que igualdad de hash en el dominio transferido.
""")
    md("MULTICAST_TRANSFER.md","Transferencia multicast","""
Estado: `NEW_MECHANISM_REQUIRED`. CORE10 no descubrió un splitter causal: cada propuesta tiene un destino. Duplicar carriers en Python sería precodificar copias. WARPCAST/INFOCLONE históricos permanecen anclas negativas; no se abrió un holdout sin mecanismo nuevo.
""")
    md("DISCONTINUITY_CONTROL.md","Control de discontinuidad","""
Estado: `FAILED_IN_TESTED_DOMAIN`. En todos los casos primarios hubo registros consecutivos desde source hasta receiver; la función aparece tras latencia positiva y el corridor cut la elimina. No apareció destino antes de sus mediadores. La palabra teleportación no se usa como veredicto.
""")
    md("UNIFIED_OPERATOR_CORE10.md","Operador unificado de CORE10",f"""
Estado: `{unified['status']}`.

Arquitectura: `{unified['name']}`. La misma gramática —lineage/history, propuesta dirigida, interfaz/guard y reducer— explica coupling, reinstantiation, joint repair y observer. Semantic-1 y semantic-4 son ramas distintas; por eso no se promociona una sola ecuación universal. Faltan congestión multilinaje, sources/sinks generales, valencia recíproca y accounting cerrado para una clausura global.
""")
    md("JOINT_EFFECTIVE_STATE.md","Estado efectivo conjunto","""
Para exchange, `Z=(policy_A,policy_B,open_AB,open_BA,receiver_A,receiver_B,remaining_delay)` predice la tarea. Para repair, `Z=(vacancy_A,vacancy_B,outer_A,shared_mask4,outer_B)` cierra el resultado. Ambos comprimen Q0 fuertemente, pero son task-relative y no autorizan el nombre Q4.
""")
    md("ROSETTA_READINESS.md","Readiness Rosetta",f"""
Los fingerprints internos `C10PHI01–03` son confirmados, mecanísticos y multirelacionales, por lo que se permitió un screen neutral. Se revisaron {external['screened_sources']} protocolos primarios. Los datasets de conjugación exponen donor, recipient, tiempo, densidades y receiver dependence; el dataset de interfaces expone ciclos y daño. Ninguno contiene la cadena completa congelada ni una predicción externa reservable. Resultado: `{external['verdict']}`; Rosetta queda en `FORMAL_SIMILARITY_ONLY`.

Fuentes cribadas: [Dryad ff045t7](https://datadryad.org/dataset/doi:10.5061/dryad.ff045t7), [Dryad 8pk0p2nvp](https://datadryad.org/dataset/doi:10.5061/dryad.8pk0p2nvp), [Dryad 12jm63z2t](https://datadryad.org/dataset/doi:10.5061/dryad.12jm63z2t), [Dryad 488dk](https://datadryad.org/dataset/doi:10.5061/dryad.488dk), [Dryad bzkh189rm](https://datadryad.org/dataset/doi:10.5061/dryad.bzkh189rm).
""")
    md("EXTERNAL_DATA_REQUIRED.md","Dato externo necesario","""
Se requiere un protocolo row-level con preparation, donor/source state, receiver class, mediador espacial/temporal, source post-state, latency, receiver functional record, controles de receptor y una segunda observación no usada para calibrar. Idealmente dos laboratorios/datasets. Sin esos campos, borrar relaciones del fingerprint para conseguir un fit sería target leakage metodológico.
""")
    md("NEGATIVE_RESULTS.md","Resultados negativos","""
- `C10D01`: receiver-answer leakage; candidato no promovido.
- `C10H04`: FAIL sellado del observer raw/omnibus.
- No reciprocal adaptation en el intercambio fijo.
- No phase locking/entrainment adjudicable.
- No multicast funcional ni splitter nuevo.
- No efecto remoto discontinuo; toda transferencia fue causal.
- No area-like/holographic claim; boundary space×time denso es cúbico.
- No Rosetta externa, predicción física o equivalencia validada.
""")
    md("ADVERSARIAL_REVIEW.md","Revisión adversarial final","""
| Riesgo | Adjudicación |
|---|---|
| correlación llamada coupling | excluida por ablaciones direccionales |
| recursos duplicados | el mecanismo de joint repair es geometría compartida; same-count shuffle falla y la limitación se declara |
| bridge precodificado | relays/converters están preparados, pero C10D01 mostró y eliminó el caso donde el receiver contenía la respuesta |
| Python decide conducta | scheduling es fijo; no action selection post-response en holdout; la experiencia H02 es acotada y no se llama autonomía mutua |
| functional transfer por setup | untrained/history/direction/receiver/path controls fallan |
| source no desaparece | source port vacío después de launch; no se afirma aniquilación global del lineage |
| corredor no causal | trace consecutivo y corridor cut decisivo |
| observer oculta diferencias | se afirma sólo equivalencia funcional; raw closure H04 falló |
| scale law post-hoc | forma y gates congelados antes de nuevos N/d |
| external match por nombre | fingerprints se congelaron antes del screen; ningún source fue admitido |
| holdout tocado | cinco locks conservan sus hashes; H04 FAIL no se reclasificó |
| reinstantiation llamada teleportation | explícitamente prohibido en claims finales |

No se identificó un error técnico que requiera rerun científico.
""")
    md("FINAL_FRONTIER.md","Frontera final","""
`EXTERNAL_DATA_REQUIRED`: protocolo multirelacional completo para Rosetta.

`NEW_MECHANISM_REQUIRED`: splitter para multicast; consequence loop endógeno para adaptación recíproca; dos osciladores causales para phase locking/entrainment; accounting cerrado para resource cycle.

`CLOSED_NEGATIVE`: discontinuidad remota en el dominio probado; observer raw H04; receiver-leaking C10D01.

`BOUNDED_CONFIRMED`: coupling bidireccional, learned functional reinstantiation, joint fixed homeostasis, functional observer, affine scale laws y arquitectura unificada. No se propone CORE11 automáticamente.
""")


def main():
    started=time.perf_counter(); h01=load("C10H01_bidirectional_exchange.json"); h02=load("C10H02_learned_policy_reinstantiation.json"); h03=load("C10H03_joint_interface_homeostasis.json"); h04=load("C10H04_task_relative_observer.json"); h05=load("C10H05_functional_observer.json"); analysis=load("C10A04_multiscale_unified_analysis.json"); external=load("C10A05_external_rosetta_screen.json")
    adversarial={"schema":"dee.v27.core10.adversarial.v1","module_id":"C10A06_FINAL_ADVERSARIAL_REVIEW","status":"COMPLETE","holdout_integrity":{},"findings":[{"risk":"receiver leakage","result":"C10D01 negative retained; revised C10D02/H02 converter null is nonfunctional"},{"risk":"correlation","result":"direction-specific causal cuts"},{"risk":"inventory","result":"same-count shuffle negative"},{"risk":"raw versus function","result":"H04 raw claim failed; H05 functional claim separate"},{"risk":"external pareidolia","result":"zero datasets admitted; zero fits"}],"scientific_rerun_required":False,"created_utc":utc_now()}
    for p in sorted((ROOT/"HOLDOUT_LOCKS").glob("*.json")): adversarial["holdout_integrity"][p.stem]=sha256_file(p)==p.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]
    adversarial["content_sha256"]=canonical_hash(adversarial); atomic_json(ROOT/"RESULTS/C10A06_final_adversarial_review.json",adversarial)
    claims={"schema":"dee.v27.core10.claims.v1","claims":[
        {"claim_id":"C10H01","claim":"bidirectional causal policy exchange","status":"CONFIRMED","scope":"parallel receiver-mediated lanes"},
        {"claim_id":"C10H02","claim":"destructive functional reinstantiation of consequence-acquired policy","status":"CONFIRMED","scope":"binary direction policy"},
        {"claim_id":"C10H03","claim":"joint fixed homeostasis through shared interface","status":"CONFIRMED","scope":"overlapping semantic-4 guards"},
        {"claim_id":"C10H04","claim":"raw endpoint closure and universal instant-boundary ambiguity","status":"FAILED","scope":"frozen omnibus"},
        {"claim_id":"C10H05","claim":"task-relative functional observer and boundary counterexample","status":"CONFIRMED","scope":"binary coupled response"},
        {"claim_id":"C10N01","claim":"reciprocal adaptation","status":"NEW_MECHANISM_REQUIRED"},
        {"claim_id":"C10N02","claim":"multicast functional transfer","status":"NEW_MECHANISM_REQUIRED"},
        {"claim_id":"C10N03","claim":"discontinuous remote effect","status":"FAILED_IN_TESTED_DOMAIN"},
        {"claim_id":"C10R01","claim":"external Rosetta","status":"EXTERNAL_DATA_REQUIRED"},
    ]}; atomic_json(ROOT/"CLAIMS.json",claims)
    docs(h01,h02,h03,h04,h05,analysis,external)
    state=json.loads((ROOT/"STATE.json").read_text(encoding="utf-8")); state.update({"status":"COMPLETE","current_question":"CORE10 stopping rule reached","active_fronts":[],"last_completed_module":"C10A06_FINAL_ADVERSARIAL_REVIEW","last_completed_experiment":"C10A06_FINAL_ADVERSARIAL_REVIEW","provisional":[],"pending_holdout":None,"front_verdicts":{"native_coupled_systems":"BOUNDED_CONFIRMED","multiscale_causal_ecology":"BOUNDED_CONFIRMED","functional_reinstantiation":"BOUNDED_CONFIRMED","reciprocal_adaptation":"NEW_MECHANISM_REQUIRED","rosetta":"EXTERNAL_DATA_REQUIRED","dimensional_extra":"BOUNDED_CONFIRMED_NO_AREA_LAW"},"stopping_reason":"all high-information questions available to the discovered mechanisms were adjudicated; remaining questions need new mechanisms or external data","next_action":"None; validate and use the sealed CORE10 package.","timestamp_utc":utc_now()}); atomic_json(ROOT/"STATE.json",state)
    append_log({"event":"CAMPAIGN_SCIENTIFIC_CLOSURE","module_id":"C10A06_FINAL_ADVERSARIAL_REVIEW","front_verdicts":state["front_verdicts"],"rerun_required":False})
    atomic_json(ROOT/"CHECKPOINTS/checkpoint_final.json",{"schema":"dee.v27.core10.checkpoint.v1","created_utc":utc_now(),"state":state,"result_hashes":{p.name:sha256_file(p) for p in sorted((ROOT/"RESULTS").glob("*.json"))},"holdout_hashes":adversarial["holdout_integrity"]})

    # Manifest is deliberately non-self-referential; HASHES covers MANIFEST.
    initial=[p for p in selected_files() if p.name not in {"MANIFEST.json","HASHES.sha256"}]
    manifest={"schema":"dee.v27.core10.manifest.v1","created_utc":utc_now(),"package_name":ZIP_NAME,"root_prefix":PREFIX,"kernel_identity":{"wheel":"69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939","package":"7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4","kernel":"0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"},"embedded_parent":{"path":"PARENTS/09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip","sha256":"70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96"},"exclusions":["PARENTS/CORE07_EXTRACTED","PARENTS/CORE09_EXTRACTED","output","__pycache__"],"files":[{"path":p.relative_to(ROOT).as_posix(),"size":p.stat().st_size,"sha256":sha256_file(p)} for p in initial]}; atomic_json(ROOT/"MANIFEST.json",manifest)
    hashed=selected_files(); atomic_text(ROOT/"HASHES.sha256","".join(f"{sha256_file(p)}  {p.relative_to(ROOT).as_posix()}\n" for p in hashed if p.name!="HASHES.sha256"))
    files=selected_files()+[ROOT/"HASHES.sha256"]
    out=ROOT/"output"/ZIP_NAME; out.parent.mkdir(exist_ok=True); temp=out.with_suffix(".zip.tmp")
    with zipfile.ZipFile(temp,"w",zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(set(files),key=lambda x:x.relative_to(ROOT).as_posix()): z.write(p,f"{PREFIX}/{p.relative_to(ROOT).as_posix()}")
    with zipfile.ZipFile(temp,"r") as z:
        if z.testzip() is not None: raise RuntimeError("zip CRC failure")
        parent_entry=f"{PREFIX}/PARENTS/09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip"
        if hashlib.sha256(z.read(parent_entry)).hexdigest()!="70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96": raise RuntimeError("embedded parent bytes changed")
    os.replace(temp,out); digest=sha256_file(out)

    exp=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE"; core=exp/"CORE"; official=core/ZIP_NAME
    if official.exists() and sha256_file(official)!=digest: raise RuntimeError("different official CORE10 already exists")
    shutil.copyfile(out,official)
    if sha256_file(official)!=digest: raise RuntimeError("official copy mismatch")
    index=exp/"INDICE_EXPEDIENTE.md"; text=index.read_text(encoding="utf-8")
    text=text.replace("nueve campañas científicas principales","diez campañas científicas principales").replace("CORE 01–09 están sellados","CORE 01–10 están sellados")
    section=f"\n### Experimento 10 — sistemas acoplados, ecología causal y reinstanciación\n\n`{ZIP_NAME}`\n\nConfirma acoplamiento causal bidireccional, reinstanciación destructiva de una política aprendida, homeostasis conjunta fija mediante interfaz compartida y un observer funcional task-relative; conserva los FAILs de leakage y cierre raw, descarta discontinuidad en el dominio y deja Rosetta externa en `EXTERNAL_DATA_REQUIRED`.\n\n"
    if ZIP_NAME not in text: text=text.replace("## EXTRA",section+"## EXTRA")
    atomic_text(index,text)
    hfile=exp/"HASHES.sha256"; lines=[line for line in hfile.read_text(encoding="utf-8").splitlines() if ZIP_NAME not in line and "INDICE_EXPEDIENTE.md" not in line]
    lines.append(f"{digest}  CORE/{ZIP_NAME}"); lines.append(f"{sha256_file(index)}  INDICE_EXPEDIENTE.md"); atomic_text(hfile,"\n".join(lines)+"\n")
    cores=sorted(p.name for p in core.glob("*.zip")); expected_prefix={f"{i:02d}_" for i in range(1,11)}
    observed_prefix={name[:3] for name in cores};
    if observed_prefix!=expected_prefix or len(cores)!=10: raise RuntimeError({"core_files":cores,"prefixes":sorted(observed_prefix)})

    # Keep the previously authorized portable expediente truthful and current.
    portable=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE_COMPLETO.zip"
    if portable.exists():
        ptemp=portable.with_suffix(".zip.tmp")
        with zipfile.ZipFile(ptemp,"w",zipfile.ZIP_DEFLATED,compresslevel=1) as z:
            for p in sorted(x for x in exp.rglob("*") if x.is_file()): z.write(p,f"EXPEDIENTE_EXPERIMENTOS_DEE/{p.relative_to(exp).as_posix()}")
        os.replace(ptemp,portable)
    print(json.dumps({"status":"SEALED","zip":str(out),"sha256":digest,"bytes":out.stat().st_size,"official":str(official),"official_sha256":sha256_file(official),"core_files":cores,"portable_updated":portable.exists(),"wall_clock_seconds":time.perf_counter()-started},indent=2)); return 0


if __name__=="__main__": raise SystemExit(main())
