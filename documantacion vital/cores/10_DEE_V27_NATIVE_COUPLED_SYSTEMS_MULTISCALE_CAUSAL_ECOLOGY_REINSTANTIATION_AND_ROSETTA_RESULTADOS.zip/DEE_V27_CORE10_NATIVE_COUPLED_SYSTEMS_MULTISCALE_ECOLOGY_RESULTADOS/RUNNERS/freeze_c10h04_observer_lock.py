#!/usr/bin/env python3
"""Freeze multiscale observer, memory-locus and dimensional-extra claims."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_common import ROOT, append_log, atomic_json, atomic_text, sha256_file, update_state, utc_now


def main() -> int:
    claim = "C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS"
    path = ROOT / "HOLDOUT_LOCKS" / f"{claim}.json"
    if path.exists(): raise RuntimeError("immutable lock already exists")
    lock = {
        "schema": "dee.v27.core10.holdout.v1",
        "claim_id": claim,
        "question": "What is the smallest observer sufficient for delayed coupled-policy behavior, where is intersystem memory stored after exchange, and does a lower-dimensional representation earn a bounded claim?",
        "apparatus": "new bidirectional-exchange worlds observed at lane arrival and queried after one/two torus recurrences",
        "domain": {"N": [33, 35, 37], "distances": [5, 7, 9], "frames": 4, "query_cycles": [1, 2]},
        "observer": {"minimal": "two endpoint direction records + N/horizon + declared post-observation intervention", "bulk_inventory": "support/s_reg/semantic counts", "boundary": "outer shell instantaneous raw", "projections": "one/two/three occupancy and integrated-direction views", "random": "same number of full raw cells as endpoint observer"},
        "rule": "for each non-reset endpoint, predicted query direction = component-sign(endpoint_direction + transformed sensor); reset endpoint predicts no valid action",
        "matched_pairs": "same seed/N/distance/frame under AB versus wrong_receiver interface",
        "controls": ["wrong receiver", "A-only", "B-only", "empty", "reset A after arrival", "reset B", "reset both", "clear lanes after arrival", "equal-cell random observer"],
        "nulls": ["inventory is sufficient", "instantaneous outer boundary is sufficient", "occupancy projections contain direction state", "memory remains in empty lanes", "more variables are automatically better"],
        "minimum_effect": {"minimal_observer_accuracy": 1.0, "AB_rate": 1.0, "selective_reset_exact": 1.0, "clear_lanes_rate": 1.0, "matched_boundary_ambiguity_rate": 1.0, "matched_inventory_ambiguity_rate": 1.0, "matched_occupancy_projection_ambiguity_rate": 1.0},
        "PASS": "minimal frozen rule is exact and all memory-locus/ambiguity gates hold across every new domain",
        "FAIL": "minimal rule errs, lane clearing erases memory, reset is nonselective, or boundary/inventory/occupancy distinguishes every matched future",
        "INCONCLUSIVE": "kernel/runtime cannot complete all cases",
        "seeds": list(range(114000, 114096)),
        "falsifier": "two identical minimal observers yield different post-intervention futures in-domain, or a reset-independent lane variable is necessary",
        "dimensional_states_allowed": ["INTERFACE_SUFFICIENT", "BOUNDARY_INSTANTANEOUS_INSUFFICIENT", "LOWER_DIMENSIONAL_EFFECTIVE_STATE", "NO_DIMENSIONAL_REDUCTION_FOUND"],
        "area_law_excluded": "dense boundary history has shell_size times temporal_length information; O(N^2)*O(N)=O(N^3) when history spans N ticks",
        "discovery_sources": {"C10H01": sha256_file(ROOT / "RESULTS/C10H01_bidirectional_exchange.json"), "C10H02": sha256_file(ROOT / "RESULTS/C10H02_learned_policy_reinstantiation.json"), "C10H03": sha256_file(ROOT / "RESULTS/C10H03_joint_interface_homeostasis.json")},
        "created_utc": utc_now(),
    }
    atomic_json(path, lock)
    digest = sha256_file(path)
    atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    append_log({"event": "HOLDOUT_LOCK_FROZEN", "claim_id": claim, "sha256": digest})
    update_state(pending_holdout=claim, dimensional_extra="OPEN_LOCKED", next_action="Open C10H04 new observer/memory-locus worlds.")
    print(digest)
    return 0


if __name__ == "__main__": raise SystemExit(main())
