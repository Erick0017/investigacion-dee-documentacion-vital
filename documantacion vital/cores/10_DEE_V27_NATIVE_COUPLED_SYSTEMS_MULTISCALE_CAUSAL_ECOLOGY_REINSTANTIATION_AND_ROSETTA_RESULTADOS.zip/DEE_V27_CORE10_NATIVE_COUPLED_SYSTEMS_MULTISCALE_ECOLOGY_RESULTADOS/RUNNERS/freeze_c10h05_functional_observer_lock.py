#!/usr/bin/env python3
"""New post-H04 hypothesis: functional, not raw-record, task-relative closure."""
from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_common import ROOT, append_log, atomic_json, atomic_text, sha256_file, update_state, utc_now


def main():
    claim = "C10H05_FUNCTIONAL_OBSERVER_AND_INTERIOR_BOUNDARY_COUNTEREXAMPLE"
    path = ROOT / "HOLDOUT_LOCKS" / f"{claim}.json"
    if path.exists(): raise RuntimeError("immutable lock exists")
    lock = {
        "schema": "dee.v27.core10.holdout.v1", "claim_id": claim,
        "question": "Does endpoint direction close the binary response class despite raw nuisance, and can interior matched worlds prove instantaneous outer-boundary insufficiency by counterexample?",
        "trigger": "C10H04 failed its omnibus gates: raw-record equality was stricter than functional closure, while 10/12 rather than 12/12 matched pairs had identical boundaries.",
        "domain": {"N": [39, 41, 43], "distances": [5, 7, 9], "axis_permutations": 3, "signs": [1, 1, 1], "interior_paths": True, "query_cycles": [1, 2]},
        "observer": "endpoint direction class at arrival + transformed sensor + declared post-arrival reset; output is valid action class, not exact raw nuisance",
        "rule": "A_valid iff sgn(d_A+sensor)=ACTION0; B_valid iff sgn(d_B+sensor)=ACTION1; reset endpoint=false",
        "matched_counterexample": "AB and wrong-receiver worlds have identical seed/N/d/frame and occupancy; if instantaneous boundary is identical but B future differs, boundary M is not sufficient",
        "controls": ["wrong receiver", "A-only", "B-only", "empty", "selective A/B/both reset", "lane clear after arrival", "equal-cell random", "occupancy multiview"],
        "nulls": ["raw residual must be predicted", "boundary always contains policy", "bulk inventory suffices", "memory remains in lanes"],
        "minimum_effect": {"functional_observer_accuracy": 1.0, "selective_reset": 1.0, "lane_clear": 1.0, "boundary_counterexample_each_domain": True, "inventory_counterexample_each_domain": True, "occupancy_counterexample_each_domain": True},
        "PASS": "all functional predictions and causal locus gates are exact, and every interior matched domain supplies the frozen boundary counterexample",
        "FAIL": "any functional prediction/reset/lane gate fails or a planned interior pair lacks the counterexample",
        "INCONCLUSIVE": "kernel/runtime cannot finish",
        "seeds": list(range(115000, 115096)),
        "falsifier": "same endpoint functional observer produces different action class without a declared intervention, or instantaneous boundary separates the planned interior pairs",
        "nonrepair_clause": "C10H04 remains FAIL; C10H05 has a new claim, new functional observable and new worlds.",
        "previous_fail_sha256": sha256_file(ROOT / "RESULTS/C10H04_task_relative_observer.json"), "created_utc": utc_now(),
    }
    atomic_json(path, lock); digest = sha256_file(path); atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    append_log({"event": "NEW_HYPOTHESIS_AFTER_FAIL", "prior": "C10H04", "claim_id": claim, "lock_sha256": digest})
    update_state(pending_holdout=claim, next_action="Open C10H05 on new interior worlds; preserve C10H04 FAIL.")
    print(digest); return 0


if __name__ == "__main__": raise SystemExit(main())
