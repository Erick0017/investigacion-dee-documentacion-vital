#!/usr/bin/env python3
"""Freeze the three independent CORE10 confirmations earned in discovery."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_common import ROOT, append_log, atomic_json, atomic_text, sha256_file, update_state, utc_now


def write_lock(lock: dict) -> dict:
    path = ROOT / "HOLDOUT_LOCKS" / f"{lock['claim_id']}.json"
    if path.exists():
        raise RuntimeError(f"immutable lock already exists: {path}")
    lock["created_utc"] = utc_now()
    atomic_json(path, lock)
    digest = sha256_file(path)
    atomic_text(path.with_suffix(".sha256"), f"{digest}  {path.name}\n")
    return {"claim_id": lock["claim_id"], "sha256": digest}


def main() -> int:
    d1 = ROOT / "RESULTS" / "C10D01_coupled_discovery.json"
    d2 = ROOT / "RESULTS" / "C10D02_refined_policy_transfer.json"
    if not (d1.exists() and d2.exists()):
        raise RuntimeError("discovery evidence missing")
    locks = [
        {
            "schema": "dee.v27.core10.holdout.v1",
            "claim_id": "C10H01_BIDIRECTIONAL_CAUSAL_POLICY_EXCHANGE",
            "question": "Do two separated two-port DEE systems causally exchange distinct policy states in both directions through identifiable lanes/interfaces?",
            "apparatus": "two parallel lanes; source policy plus local relay; inverse receiver interface; delayed unseen-context query",
            "domain": {"N": [27, 29, 31], "distances": [4, 6, 8], "frames": 4, "query_cycles": [1, 2]},
            "parameters": {"policy_A": [0, 1, 0], "policy_B": [1, 0, 0], "sensor": [-1, 0, 1], "lanes": "parallel and four cells apart in the transformed frame"},
            "observer": "two endpoint action directions plus time-stamped lane records",
            "predicted_relation": "AB: both destination functions pass; A-only affects only B; B-only affects only A; arrival tick=1+distance; effect persists for one/two torus recurrences",
            "controls": ["A-only", "B-only", "empty", "no connection", "block A path", "block B path", "off-path block", "wrong receivers", "absent receivers"],
            "nulls": ["independent background", "receiver-only answer", "distance-only readout", "common-mode artifact"],
            "minimum_effect": {"AB_both_rate": 1.0, "offpath_both_rate": 1.0, "empty_both_rate": 0.0, "no_connection_both_rate": 0.0, "block_A_B_response_rate": 0.0, "block_B_A_response_rate": 0.0, "A_only_A_response_rate": 0.0, "A_only_B_response_rate": 1.0, "B_only_A_response_rate": 1.0, "B_only_B_response_rate": 0.0},
            "PASS": "all frozen directional and control rates equal their exact gates across all new domains",
            "FAIL": "any required directional effect/control gate fails",
            "INCONCLUSIVE": "kernel/runtime cannot complete all cases",
            "seeds": list(range(111000, 111072)),
            "topologies": ["two parallel opposite lanes", "blocked lane", "off-path matched perturbation"],
            "falsifier": "either endpoint response survives removal/blocking of its source path or fails under off-path intervention",
            "discovery_sha256": sha256_file(d1),
        },
        {
            "schema": "dee.v27.core10.holdout.v1",
            "claim_id": "C10H02_LEARNED_POLICY_FUNCTIONAL_REINSTANTIATION",
            "question": "Can a policy acquired through ordinary consequence in A be destructively mediated and functionally reinstantiated in B without a new teacher?",
            "apparatus": "CORE09 a->b consequence update; neutral three-component relay; causal corridor; non-answer-bearing inverse converter; unseen-context query",
            "domain": {"N": [27, 29, 31], "distances": [4, 6, 8], "frames": 4},
            "parameters": {"initial_policy": [1, 0, 0], "learned_policy": [0, 1, 0], "relay": [1, -1, 1], "route": [1, 0, 1], "converter": [-1, 1, -1], "sensor": [-1, 0, 1]},
            "observer": "source direction after experience, every expected corridor site/tick, receiver direction and unseen-context action",
            "predicted_relation": "trained/s_reg-nuisance/off-path pass; every causal ablation and receiver null fails; source is empty after launch; no destination effect precedes corridor",
            "controls": ["untrained", "memory ablation", "history reset", "direction ablation", "s_reg nuisance", "corridor cut", "off-path cut", "receiver none", "wrong receiver", "relay none"],
            "nulls": ["receiver converter contains answer", "routing without learned state", "s_reg payload alone", "remote discontinuity", "readout leakage"],
            "minimum_effect": {"trained_rate": 1.0, "sreg_nuisance_rate": 1.0, "offpath_rate": 1.0, "all_causal_negative_rates": 0.0, "trained_source_depletion_rate": 1.0, "trained_complete_corridor_trace_rate": 1.0},
            "PASS": "all positive and negative rates equal exact gates in every new domain",
            "FAIL": "any causal negative reproduces function or any primary misses function/mediation/depletion",
            "INCONCLUSIVE": "kernel/runtime cannot complete all cases",
            "seeds": list(range(112000, 112096)),
            "topologies": ["direct causal corridor", "corridor cancellation", "off-path cancellation", "wrong/absent receiver"],
            "falsifier": "untrained/ablated source or converter alone produces ACTION1, or destination changes without sequential corridor mediation",
            "discovery_sha256": sha256_file(d2),
        },
        {
            "schema": "dee.v27.core10.holdout.v1",
            "claim_id": "C10H03_JOINT_INTERFACE_HOMEOSTASIS",
            "question": "Can two individually incomplete DEE structures form a repeated regenerative unit only through their shared interface?",
            "apparatus": "two centers separated by two cells; four semantic-4 corner cells are the common interface; each isolated component owns only half the interface",
            "domain": {"N": [25, 27, 29, 31], "axes": [0, 1, 2], "cycles": 5, "payloads": "new random state/s_reg/clock"},
            "parameters": {"outer_cells_per_center": 4, "shared_interface_cells": 4, "AB_total_scaffold_cells": 12},
            "observer": "per-cycle restoration of both centers plus byte invariance of the 12-cell scaffold",
            "predicted_relation": "AB and off-path controls restore both centers every cycle; A-only/B-only/empty/missing-one/same-inventory-shuffle never restore both",
            "controls": ["A-only", "B-only", "empty", "missing one shared cell", "same inventory shuffled", "full-A positive", "full-B positive", "off-path intervention"],
            "nulls": ["support count alone", "independent restoration", "duplicated resources", "random geometry"],
            "minimum_effect": {"AB_joint_rate": 1.0, "offpath_joint_rate": 1.0, "negative_joint_rate": 0.0, "scaffold_invariance_rate": 1.0, "cycles": 5},
            "PASS": "all exact gates hold across every new N/axis/payload",
            "FAIL": "isolated/shuffled/missing-interface control restores both or AB/off-path fails",
            "INCONCLUSIVE": "kernel/runtime cannot complete all cases",
            "seeds": list(range(113000, 113096)),
            "topologies": ["shared exact interface", "one-cell cut", "same-count shuffle"],
            "falsifier": "same inventory without the shared interface restores the pair or either incomplete component restores both independently",
            "discovery_sha256": sha256_file(d1),
        },
    ]
    written = [write_lock(lock) for lock in locks]
    state = json.loads((ROOT / "STATE.json").read_text(encoding="utf-8"))
    atomic_json(ROOT / "CHECKPOINTS" / "checkpoint_pre_core10_holdouts.json", {"schema": "dee.v27.core10.checkpoint.v1", "created_utc": utc_now(), "state": state, "locks": written})
    append_log({"event": "HOLDOUT_LOCKS_FROZEN", "locks": written})
    update_state(pending_holdout=[x["claim_id"] for x in written], next_action="Open C10H01-C10H03 independent holdout worlds without modifying locks.")
    print(json.dumps({"status": "LOCKED", "locks": written}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
