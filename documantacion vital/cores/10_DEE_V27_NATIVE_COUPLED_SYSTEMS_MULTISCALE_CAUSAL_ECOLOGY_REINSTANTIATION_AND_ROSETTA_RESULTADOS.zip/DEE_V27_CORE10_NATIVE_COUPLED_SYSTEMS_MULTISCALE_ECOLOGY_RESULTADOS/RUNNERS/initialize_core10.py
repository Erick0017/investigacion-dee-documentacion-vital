#!/usr/bin/env python3
"""One-time parent/kernel audit and directed legacy-anchor ledger."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_common import ROOT, TESTS, atomic_json, atomic_text, append_log, canonical_hash, question, sha256_file, utc_now, verify_and_load_kernel

CORE_HASHES = {
    "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip": "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4",
    "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip": "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058",
    "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip": "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640",
    "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip": "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2",
    "05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip": "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b",
    "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip": "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e",
    "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip": "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f",
    "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip": "275d3e665c0d0c97c3da80ee487819078fc55dbca24bd4e40c7dafa5b5e7a5fc",
    "09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip": "70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96",
}


def main() -> int:
    core = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
    observed = {name: sha256_file(core / name) for name in CORE_HASHES}
    if observed != CORE_HASHES: raise RuntimeError({name: [observed.get(name), expected] for name, expected in CORE_HASHES.items() if observed.get(name) != expected})
    parent = ROOT / "PARENTS" / next(reversed(CORE_HASHES))
    if sha256_file(parent) != CORE_HASHES[parent.name]: raise RuntimeError("embedded CORE09 mismatch")
    _, environment = verify_and_load_kernel(1)
    atomic_json(ROOT / "PARENT_CHAIN.json", {"schema": "dee.v27.core10.parent_chain.v1", "cores": [{"core": index + 1, "filename": name, "sha256": digest} for index, (name, digest) in enumerate(CORE_HASHES.items())], "embedded_parent": "PARENTS/" + parent.name, "recursive_note": "CORE09 contains CORE08 and the prior chain."})
    rows = [
        ("COUPLING145X", "v24/V14.5 documentary", "AB/A/B/empty across five geometries", "12 constructive, 6 approximately additive, 2 weak nonlinear", "geometry/medium dependent; raw JSON absent", "v27 coupled witness"),
        ("MEDIUM145X", "v24/V14.5 documentary", "normal/observer/aperture media", "medium changed coupling magnitude/class", "no external field identified; raw JSON absent", "v27 medium intervention"),
        ("CONTROLREUSE145X", "v24/V14.5 documentary", "prior common-mode then late probe", "reusable control channel not closed", "local negative", "do not repeat without new lineage mechanism"),
        ("OPENCOUPLE145X", "v24/V14.5 documentary", "two-machine novelty descriptors", "non-additive traces; no robust central operator", "discovery-only", "test guarded fiber/lineage hypothesis"),
        ("ITERATE145X", "v24/V14.5 documentary", "repeated interrogation", "no repeatable output-to-input iteration", "local negative", "CORE09 returning lineage is new mechanism"),
        ("WARPPAYLOAD146X", "v24/V14.6 documentary", "cavity16 payload transfer", "8 s_reg levels distinguished; correlation 1", "transduction, not material continuity", "covered mechanistically by destination fibers"),
        ("WARPORG146X", "v24/V14.6 documentary", "six equal-mass source patterns/cavity", "source emptied; pattern-specific destination", "destructive causal transfer; raw JSON absent", "v27 policy reinstantiation"),
        ("WARPCAST146X", "v24/V14.6 documentary", "multiple receivers", "activation reached several; identity not robust", "candidate bus, not cloning", "v27 multicast control"),
        ("DISCONTINUOUSSTATE20X", "v25/V20B documentary", "remote-before-corridor criterion", "no destination effect before corridor; corridor differed from tick0", "negative contextual", "retain as strict control"),
        ("ORGREINSTANTIATE20CX", "v25/V20C primary summarized", "6 patterns × N64/80/96", "18/18; source empty t5; specific destination at t=d-9", "receiver-assisted; not same matter", "v27 learned-policy witness"),
        ("REINSTANTIATIONDEPTH20CX", "v25/V20C primary summarized", "receiver scaffold 0,1,7,27,98", "specific response only at 98; 27<S_min<=98", "minimum unresolved", "compatible/wrong/absent receiver controls"),
        ("COORDADDRESS20CX", "v25/V20C primary summarized", "three candidate receivers", "only receiver0 selectable", "no arbitrary address space", "do not claim random access"),
        ("INFOCLONE20CX", "v25/V20C primary summarized", "three receivers", "one specific, one late generic, one none", "multicast identity failed", "v27 functional multicast"),
    ]
    source_index = ROOT / "PARENTS" / "CORE07_EXTRACTED" / "SOURCE_INDEX.json"
    ledger = {"schema": "dee.v27.core10.legacy_coupling.v1", "authority": "historical anchors only; no automatic v27 promotion", "source": {"extract": "CORE07/LEGACY_EXTRACTS/DEE_CORPUS_INTEGRAL...txt", "source_index_sha256": sha256_file(source_index)}, "claims": [{"module": module, "original_kernel": kernel, "apparatus": apparatus, "computational_report": fact, "controls_and_limit": limit, "current_action": action, "status": "PRIOR_HYPOTHESIS_ANCHOR"} for module, kernel, apparatus, fact, limit, action in rows]}
    atomic_json(ROOT / "LEGACY_COUPLING_AND_REINSTANTIATION_LEDGER.json", ledger)
    atomic_json(ROOT / "ALTERNATIVE_EXPLANATIONS.json", {"schema": "dee.v27.core10.alternatives.v1", "claims": []})
    atomic_text(ROOT / "QUESTION_TREE.ndjson", ""); atomic_text(ROOT / "KERNEL_DIALOGUE.ndjson", ""); atomic_text(ROOT / "SCIENCE_LOG.ndjson", "")
    question({"question_id": "C10Q00", "parent_question_id": None, "front": "legacy", "why_this_question": "decide which historical anchors require v27 witnesses", "kernel_response_that_triggered_it": "none; preflight", "hypotheses_being_separated": ["historical transfer persists in v27", "version/apparatus dependence"], "experiment": "directed documentary audit", "controls": ["authority hierarchy", "source provenance"], "measurement": "primary availability and current scope", "result": "policy/coupling require new v27 witnesses; discontinuity remains negative", "next_questions": ["C10Q01", "C10Q02"], "status": "CLOSED"})
    state = {"schema": "dee.v27.core10.state.v1", "status": "ACTIVE", "current_question": "Can separated DEE systems exchange state causally through an active medium, and what task-relative observer closes the interaction?", "active_fronts": ["coupling", "multiscale_causal_ecology", "policy_reinstantiation", "reciprocal_adaptation"], "last_completed_module": "C10A00_INITIAL_AUDIT", "complete_modules": ["C10A00"], "confirmed": [], "failed": [], "provisional": [], "pending_holdout": None, "rosetta_readiness": "NOT_EARNED", "dimensional_extra": "CONDITIONAL_NOT_OPEN", "next_action": "Run small v27 discovery of AB/A/B/empty coupling and learned-policy reinstantiation." , "timestamp_utc": utc_now()}
    atomic_json(ROOT / "STATE.json", state)
    result = {"schema": "dee.v27.core10.c10a00.v1", "module_id": "C10A00_INITIAL_AUDIT", "status": "COMPLETE", "parent_hashes": observed, "embedded_parent_sha256": sha256_file(parent), "kernel": environment, "legacy_claims": len(rows)}
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS/C10A00_initial_audit.json", result)
    append_log({"event": "MODULE_COMPLETE", "module_id": result["module_id"], "legacy_claims": len(rows), "parents_verified": 9})
    print(json.dumps({"status": "PASS", "parents": 9, "legacy_claims": len(rows), "kernel": environment["observed_hashes"]}, indent=2)); return 0


if __name__ == "__main__": raise SystemExit(main())
