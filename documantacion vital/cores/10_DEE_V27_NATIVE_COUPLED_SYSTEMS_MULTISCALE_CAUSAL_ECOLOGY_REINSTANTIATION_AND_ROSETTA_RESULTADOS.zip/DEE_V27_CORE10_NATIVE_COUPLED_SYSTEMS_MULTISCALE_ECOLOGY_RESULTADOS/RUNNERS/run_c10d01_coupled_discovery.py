#!/usr/bin/env python3
"""Small discovery battery: coupling, joint restoration and learned-policy transfer."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_apparatus import run_bidirectional_exchange, run_joint_scaffold, run_learned_policy_transfer
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, update_state, verify_and_load_kernel


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    frames = [((0, 1, 2), (1, 1, 1)), ((1, 0, 2), (1, -1, 1))]
    exchange_modes = ["AB", "A_only", "B_only", "empty", "no_connection", "block_A_path", "block_B_path", "offpath_cut", "wrong_receivers", "receiver_none"]
    exchange = []
    for i, mode in enumerate(exchange_modes):
        for j in range(2 if mode in {"AB", "offpath_cut"} else 1):
            exchange.append(run_bidirectional_exchange(kernel, 101000 + 100 * i + j, 23 + 2 * j, 5 + 2 * j, mode, *frames[j % 2], query_cycles=1 + j))
    transfer_modes = ["trained", "untrained", "memory_ablation", "history_reset", "direction_ablation", "sreg_nuisance", "corridor_cut", "offpath_cut", "receiver_none", "wrong_receiver", "no_relay"]
    transfer = []
    for i, mode in enumerate(transfer_modes):
        for j in range(2 if mode in {"trained", "sreg_nuisance", "offpath_cut"} else 1):
            transfer.append(run_learned_policy_transfer(kernel, 102000 + 100 * i + j, 23 + 2 * j, 5 + 2 * j, mode, *frames[j % 2]))
    scaffold_modes = ["AB", "A_only", "B_only", "empty", "missing_shared_one", "shuffled_same_inventory", "full_A_only", "full_B_only", "offpath_cut"]
    scaffolds = [run_joint_scaffold(kernel, 103000 + 100 * i + axis, 21 + 2 * (axis % 2), mode, 3, axis) for i, mode in enumerate(scaffold_modes) for axis in (0, 1) if mode in {"AB", "offpath_cut"} or axis == 0]

    by_exchange = {mode: [r for r in exchange if r["mode"] == mode] for mode in exchange_modes}
    by_transfer = {mode: [r for r in transfer if r["mode"] == mode] for mode in transfer_modes}
    by_scaffold = {mode: [r for r in scaffolds if r["mode"] == mode] for mode in scaffold_modes}
    exchange_signal = all(r["functional"]["A_received_B_policy"] and r["functional"]["B_received_A_policy"] for r in by_exchange["AB"]) and all(not (r["functional"]["A_received_B_policy"] and r["functional"]["B_received_A_policy"]) for mode in ("no_connection", "receiver_none", "block_A_path", "block_B_path") for r in by_exchange[mode]) and all(r["functional"]["A_received_B_policy"] and r["functional"]["B_received_A_policy"] for r in by_exchange["offpath_cut"])
    transfer_signal = all(r["functional_policy_reinstantiated"] and r["source_depleted_after_launch"] and r["corridor_all_intermediate_ticks_observed"] for r in by_transfer["trained"]) and all(not r["functional_policy_reinstantiated"] for mode in ("untrained", "memory_ablation", "history_reset", "direction_ablation", "corridor_cut", "receiver_none", "wrong_receiver", "no_relay") for r in by_transfer[mode]) and all(r["functional_policy_reinstantiated"] for mode in ("sreg_nuisance", "offpath_cut") for r in by_transfer[mode])
    joint_signal = all(r["joint_recovery_rate"] == 1 and r["scaffold_unchanged"] for r in by_scaffold["AB"]) and all(r["joint_recovery_rate"] == 0 for mode in ("A_only", "B_only", "empty", "missing_shared_one", "shuffled_same_inventory") for r in by_scaffold[mode]) and all(r["joint_recovery_rate"] == 1 for r in by_scaffold["offpath_cut"])
    summary = {
        "bidirectional_exchange_signal": exchange_signal,
        "learned_policy_reinstantiation_signal": transfer_signal,
        "joint_homeostasis_signal": joint_signal,
        "exchange_functional_rates": {mode: {"A": float(np.mean([r["functional"]["A_received_B_policy"] for r in rows])), "B": float(np.mean([r["functional"]["B_received_A_policy"] for r in rows]))} for mode, rows in by_exchange.items()},
        "transfer_functional_rates": {mode: float(np.mean([r["functional_policy_reinstantiated"] for r in rows])) for mode, rows in by_transfer.items()},
        "joint_recovery_rates": {mode: float(np.mean([r["joint_recovery_rate"] for r in rows])) for mode, rows in by_scaffold.items()},
    }
    result = {
        "schema": "dee.v27.core10.c10d01.v1",
        "module_id": "C10D01_COUPLED_TRANSFER_AND_JOINT_REPAIR_DISCOVERY",
        "status": "COMPLETE",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "kernel_environment": environment,
        "question": "Can active interfaces mediate two-way policy exchange, transfer a consequence-acquired policy, and make two incomplete structures jointly regenerative?",
        "summary": summary,
        "exchange_cases": exchange,
        "learned_transfer_cases": transfer,
        "joint_scaffold_cases": scaffolds,
        "wall_clock_seconds": time.perf_counter() - started,
        "nonclaims": ["teleportation", "physical matter identity", "reciprocal adaptation", "general autonomy", "nonlocality"],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C10D01_coupled_discovery.json", result)
    append_log({"event": "DISCOVERY_COMPLETE", "module_id": result["module_id"], "summary": summary, "wall_clock_seconds": result["wall_clock_seconds"]})
    question({"question_id": "C10Q01", "parent_question_id": "C10Q00", "front": "coupling", "why_this_question": "test whether the guarded destination operator composes into two-way system influence", "kernel_response_that_triggered_it": "legacy AB/A/B interactions lacked a v27 witness", "hypotheses_being_separated": ["causal policy exchange", "independent motion/background", "receiver-preencoded response"], "experiment": "two separated two-port systems with opposite lanes", "controls": ["A-only", "B-only", "empty", "no connection", "path blocks", "off-path block", "wrong/absent receiver"], "measurement": "unseen-context response at both receivers and corridor trace", "result": summary["exchange_functional_rates"], "next_questions": ["C10Q04" if exchange_signal else "close exchange architecture"], "status": "MECHANISM_CANDIDATE" if exchange_signal else "FAILED"})
    question({"question_id": "C10Q02", "parent_question_id": "C10Q00", "front": "reinstantiation", "why_this_question": "functional transfer of a genuinely experience-modified state was not tested in CORE01-09", "kernel_response_that_triggered_it": "CORE09 A6 returning-lineage policy and legacy receiver-assisted transfer", "hypotheses_being_separated": ["learned-policy transfer", "untrained routing", "receiver setup contains answer", "s_reg-only signal"], "experiment": "acquire a->b by fixed consequence; route destructively; query receiver with unseen context", "controls": ["untrained", "memory/history/direction ablations", "s_reg nuisance", "path/off-path cuts", "wrong/absent receiver"], "measurement": "source depletion, every corridor arrival, receiver action", "result": summary["transfer_functional_rates"], "next_questions": ["C10Q05" if transfer_signal else "close learned transfer architecture"], "status": "MECHANISM_CANDIDATE" if transfer_signal else "FAILED"})
    question({"question_id": "C10Q03", "parent_question_id": "C10Q01", "front": "coupling", "why_this_question": "test whether medium/interface can make the pair the smallest regenerative unit", "kernel_response_that_triggered_it": "medium was active historically and semantic-4 guard regenerates fixed centers", "hypotheses_being_separated": ["joint interface-dependent recovery", "simple support count", "independent recovery"], "experiment": "two damaged centers whose exact corner guards share a four-cell interface", "controls": ["A-only", "B-only", "empty", "missing shared cell", "same-inventory shuffle", "full individual positive", "off-path intervention"], "measurement": "both centers restored per cycle and scaffold byte invariance", "result": summary["joint_recovery_rates"], "next_questions": ["C10Q06" if joint_signal else "close joint scaffold architecture"], "status": "MECHANISM_CANDIDATE" if joint_signal else "FAILED"})
    dialogue("Can the inherited guarded reducer connect coupling, learned-state transfer and joint restoration?", "C10D01 three-apparatus v27 discovery", summary, "Promotion candidates require independent locks; any failing control closes its candidate without repair.", ["geometry only", "inventory only", "receiver precoding", "clock recurrence", "external scheduled readout"], "Freeze only signals that survive all discovery controls.", "HIGH" if any((exchange_signal, transfer_signal, joint_signal)) else "MEDIUM", "DISCOVERY")
    provisional = [name for name, ok in (("bidirectional policy exchange", exchange_signal), ("learned-policy reinstantiation", transfer_signal), ("joint interface-dependent restoration", joint_signal)) if ok]
    update_state(last_completed_experiment=result["module_id"], complete_modules=["C10A00", "C10D01"], provisional=provisional, next_action="Freeze independent, diverse-domain holdouts for surviving candidates; do not tune failed candidates.")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
