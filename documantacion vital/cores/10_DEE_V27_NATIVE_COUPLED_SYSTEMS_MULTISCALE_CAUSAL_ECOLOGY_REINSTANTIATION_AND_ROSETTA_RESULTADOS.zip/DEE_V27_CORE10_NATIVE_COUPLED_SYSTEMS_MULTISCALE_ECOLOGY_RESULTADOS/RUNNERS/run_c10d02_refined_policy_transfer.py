#!/usr/bin/env python3
"""Refined discovery after C10D01 exposed receiver-answer leakage."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_apparatus import run_learned_policy_transfer
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, update_state, verify_and_load_kernel


def main() -> int:
    started = time.perf_counter()
    kernel, environment = verify_and_load_kernel(1)
    modes = ["trained", "untrained", "memory_ablation", "history_reset", "direction_ablation", "sreg_nuisance", "corridor_cut", "offpath_cut", "receiver_none", "wrong_receiver", "no_relay"]
    frames = [((0, 1, 2), (1, 1, 1)), ((1, 0, 2), (1, -1, 1)), ((2, 1, 0), (-1, 1, 1))]
    cases = []
    for i, mode in enumerate(modes):
        count = 3 if mode in {"trained", "sreg_nuisance", "offpath_cut"} else 1
        for j in range(count):
            cases.append(run_learned_policy_transfer(kernel, 104000 + 100 * i + j, 25 + 2 * j, 5 + 2 * j, mode, *frames[j % len(frames)]))
    grouped = {mode: [r for r in cases if r["mode"] == mode] for mode in modes}
    rates = {mode: float(np.mean([r["functional_policy_reinstantiated"] for r in rows])) for mode, rows in grouped.items()}
    trace_rates = {mode: float(np.mean([r["corridor_all_intermediate_ticks_observed"] for r in rows])) for mode, rows in grouped.items()}
    positive_modes = ["trained", "sreg_nuisance", "offpath_cut"]
    negative_modes = ["untrained", "memory_ablation", "history_reset", "direction_ablation", "corridor_cut", "receiver_none", "wrong_receiver", "no_relay"]
    signal = all(rates[m] == 1 for m in positive_modes) and all(rates[m] == 0 for m in negative_modes) and all(r["source_depleted_after_launch"] and r["corridor_all_intermediate_ticks_observed"] for m in positive_modes for r in grouped[m])
    receiver_backgrounds = {m: [r["query_record"] for r in grouped[m]] for m in ("untrained", "memory_ablation", "receiver_none", "no_relay")}
    result = {
        "schema": "dee.v27.core10.c10d02.v1",
        "module_id": "C10D02_REFINED_LEARNED_POLICY_TRANSFER_DISCOVERY",
        "status": "COMPLETE",
        "role": "DISCOVERY_EVIDENCE_ONLY",
        "trigger": "C10D01 converter-only plus query produced ACTION1, exposing receiver-answer leakage.",
        "apparatus_revision": "relay=(1,-1,1); route=(1,0,1); converter=(-1,1,-1). Converter+sensor yields (-1,1,0), not ACTION1; route+converter yields learned policy b.",
        "kernel_environment": environment,
        "rates": rates,
        "corridor_trace_rates": trace_rates,
        "receiver_background_records": receiver_backgrounds,
        "promotion_signal": signal,
        "cases": cases,
        "wall_clock_seconds": time.perf_counter() - started,
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C10D02_refined_policy_transfer.json", result)
    append_log({"event": "DISCOVERY_COMPLETE", "module_id": result["module_id"], "triggered_by_failed_apparatus": "C10D01", "promotion_signal": signal, "rates": rates})
    question({"question_id": "C10Q05", "parent_question_id": "C10Q02", "front": "reinstantiation", "why_this_question": "C10D01 failed because the receiver converter encoded the queried response", "kernel_response_that_triggered_it": "converter-only + probe reduced to ACTION1", "hypotheses_being_separated": ["transferred learned direction is necessary", "receiver converter still contains response", "routing alone suffices"], "experiment": "new converter whose null response is algebraically distinct from ACTION1", "controls": negative_modes + positive_modes[1:], "measurement": "unseen-context receiver response, source depletion and every causal corridor step", "result": rates, "next_questions": ["C10Q08 independent holdout" if signal else "close learned-policy transfer after second informative failure"], "status": "MECHANISM_CANDIDATE" if signal else "FAILED"})
    dialogue("Does learned function survive transfer after eliminating receiver-answer leakage?", "C10D02 revised relay/converter algebra", {"rates": rates, "signal": signal}, "C10D01 remains a failed discovery apparatus; C10D02 is a new hypothesis rather than a repaired holdout.", ["untrained lineage", "converter-only response", "s_reg payload", "off-path perturbation", "corridor bypass"], "Freeze a diverse holdout only if all positive/negative controls separate.", "HIGH" if signal else "MEDIUM", "DISCOVERY")
    previous = json.loads((ROOT / "STATE.json").read_text(encoding="utf-8"))
    provisional = [x for x in previous.get("provisional", []) if x != "learned-policy reinstantiation"]
    if signal:
        provisional.append("refined learned-policy reinstantiation")
    update_state(last_completed_experiment=result["module_id"], complete_modules=["C10A00", "C10D01", "C10D02"], provisional=provisional, failed=["C10D01 receiver-leaking transfer apparatus"], next_action="Freeze independent holdouts for exchange, joint restoration and refined transfer signals." if signal else "Freeze exchange/joint-restoration only; close learned transfer in tested family.")
    print(json.dumps({"promotion_signal": signal, "rates": rates, "trace_rates": trace_rates}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
