#!/usr/bin/env python3
"""Frozen holdout for task-relative closure, memory locus and dimensional observer."""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_apparatus import SENSOR, run_bidirectional_exchange, transform
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, sha256_file, update_state, verify_and_load_kernel

FRAMES = [((0, 1, 2), (1, 1, 1)), ((1, 0, 2), (1, -1, 1)), ((2, 1, 0), (-1, 1, 1)), ((0, 2, 1), (-1, -1, 1))]


def signsum(x, y): return tuple(int(np.sign(x[i] + y[i])) for i in range(3))


def valid_prediction(case, endpoint):
    record = case["endpoint_at_arrival"][endpoint]
    if record is None: return None
    sensor = transform(SENSOR, tuple(case["frame"]["permutation"]), tuple(case["frame"]["signs"]))
    return signsum(tuple(record["direction"]), sensor)


def main() -> int:
    started = time.perf_counter(); kernel, environment = verify_and_load_kernel(1)
    claim = "C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS"
    lock_path = ROOT / "HOLDOUT_LOCKS" / f"{claim}.json"; lock_sha = sha256_file(lock_path)
    if lock_sha != lock_path.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]: raise RuntimeError("lock changed")
    domains = [(33 + 2 * (i % 3), (5, 7, 9)[(i // 3) % 3], FRAMES[i % 4], 1 + (i % 2)) for i in range(12)]
    cases = []; seed = 114000
    # AB/wrong pairs share seed and hence inventory/translation; direction at B differs.
    pairs = []
    for n, distance, frame, cycles in domains:
        ab = run_bidirectional_exchange(kernel, seed, n, distance, "AB", *frame, cycles)
        wrong = run_bidirectional_exchange(kernel, seed, n, distance, "wrong_receivers", *frame, cycles)
        cases.extend([ab, wrong]); pairs.append((ab, wrong)); seed += 1
    for mode in ("A_only", "B_only", "empty", "reset_A_after_arrival", "reset_B_after_arrival", "reset_both_after_arrival", "clear_lanes_after_arrival"):
        for n, distance, frame, cycles in domains[:6]:
            cases.append(run_bidirectional_exchange(kernel, seed, n, distance, mode, *frame, cycles)); seed += 1

    action_accuracy = []
    for case in cases:
        pred_A = None if case["mode"] in {"reset_A_after_arrival", "reset_both_after_arrival"} else valid_prediction(case, "A_in")
        pred_B = None if case["mode"] in {"reset_B_after_arrival", "reset_both_after_arrival"} else valid_prediction(case, "B_in")
        actual_A = None if case["query"]["A"] is None else tuple(case["query"]["A"]["direction"])
        actual_B = None if case["query"]["B"] is None else tuple(case["query"]["B"]["direction"])
        action_accuracy.extend([pred_A == actual_A, pred_B == actual_B])
        case["minimal_observer_prediction"] = {"A": pred_A, "B": pred_B, "correct_A": pred_A == actual_A, "correct_B": pred_B == actual_B}
    grouped = {m: [r for r in cases if r["mode"] == m] for m in sorted(set(r["mode"] for r in cases))}
    rates = {m: {"A": float(np.mean([r["functional"]["A_received_B_policy"] for r in rows])), "B": float(np.mean([r["functional"]["B_received_A_policy"] for r in rows])), "both": float(np.mean([r["functional"]["A_received_B_policy"] and r["functional"]["B_received_A_policy"] for r in rows]))} for m, rows in grouped.items()}
    pair_audits = []
    for ab, wrong in pairs:
        oa, ow = ab["arrival_observers"], wrong["arrival_observers"]
        occupancy_same = all(oa["projections"][axis]["occupancy_sha256"] == ow["projections"][axis]["occupancy_sha256"] for axis in ("0", "1", "2"))
        direction_diff = any(oa["projections"][axis]["direction_sha256"] != ow["projections"][axis]["direction_sha256"] for axis in ("0", "1", "2"))
        pair_audits.append({"n": ab["n"], "distance": ab["distance"], "bulk_inventory_same": oa["bulk_inventory"] == ow["bulk_inventory"], "boundary_instant_same": oa["outer_boundary_sha256"] == ow["outer_boundary_sha256"], "occupancy_multiview_same": occupancy_same, "direction_multiview_differs": direction_diff, "random_equal_cell_same": oa["equal_cell_random_observer"] == ow["equal_cell_random_observer"], "B_future_differs": ab["functional"]["B_received_A_policy"] != wrong["functional"]["B_received_A_policy"], "boundary_history_differs": ab["outer_boundary_history"]["sha256"] != wrong["outer_boundary_history"]["sha256"]})
    ambiguity = {key: float(np.mean([p[key] and p["B_future_differs"] for p in pair_audits])) for key in ("bulk_inventory_same", "boundary_instant_same", "occupancy_multiview_same", "random_equal_cell_same")}
    dense_budgets = [{"N": r["n"], "snapshots": r["outer_boundary_history"]["snapshots"], "dense_raw_bits": r["outer_boundary_history"]["dense_raw_bits"], "endpoint_observer_bits_upper_bound": 128 + math.ceil(math.log2(r["n"] + 1))} for r in grouped["AB"]]
    gates = {
        "minimal_observer": float(np.mean(action_accuracy)) == 1,
        "AB": rates["AB"]["both"] == 1,
        "selective_reset": rates["reset_A_after_arrival"]["A"] == 0 and rates["reset_A_after_arrival"]["B"] == 1 and rates["reset_B_after_arrival"]["A"] == 1 and rates["reset_B_after_arrival"]["B"] == 0 and rates["reset_both_after_arrival"]["both"] == 0,
        "lane_clear": rates["clear_lanes_after_arrival"]["both"] == 1,
        "boundary_ambiguity": ambiguity["boundary_instant_same"] == 1,
        "inventory_ambiguity": ambiguity["bulk_inventory_same"] == 1,
        "occupancy_projection_ambiguity": ambiguity["occupancy_multiview_same"] == 1,
    }
    verdict = "PASS" if all(gates.values()) else "FAIL"
    dimensional = {
        "INTERFACE_SUFFICIENT": verdict == "PASS",
        "BOUNDARY_INSTANTANEOUS_INSUFFICIENT": ambiguity["boundary_instant_same"] == 1,
        "LOWER_DIMENSIONAL_EFFECTIVE_STATE": verdict == "PASS",
        "AREA_LIKE_CODE_CANDIDATE": False,
        "reason_no_area_claim": "The dense boundary history uses shell O(N^2) for O(N) recurrence time, hence O(N^3) raw space-time bits; interface state is task-relative, not a global bulk code.",
    }
    result = {"schema": "dee.v27.core10.c10h04.v1", "module_id": claim, "status": "COMPLETE", "role": "FROZEN_CONFIRMATION", "lock_sha256": lock_sha, "kernel_environment": environment, "verdict": verdict, "minimal_observer_accuracy": float(np.mean(action_accuracy)), "rates": rates, "matched_pair_audits": pair_audits, "ambiguity_rates": ambiguity, "gates": gates, "memory_locus": "after arrival the future policy response is stored in the receiver endpoint carrier; empty lane clearing is irrelevant and endpoint reset is selective", "dimensional_adjudication": dimensional, "information_budgets": dense_budgets, "cases": cases, "wall_clock_seconds": time.perf_counter() - started, "nonclaims": ["global observer closure", "reality is 2D", "holographic universe", "static area law", "observer-independent object identity"]}
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS" / "C10H04_task_relative_observer.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": claim, "verdict": verdict, "lock_sha256": lock_sha, "gates": gates})
    question({"question_id": "C10H04", "parent_question_id": "C10H01", "front": "multiscale", "why_this_question": "the confirmed pair state opened the conditional dimensional-observer branch", "kernel_response_that_triggered_it": "C10H01/H03 produced stable joint phenomena", "hypotheses_being_separated": ["task-relative endpoint closure", "bulk/boundary/inventory sufficiency", "memory in bridge versus receiver"], "experiment": claim, "controls": list(grouped), "measurement": "future actions, matched observer signatures, selective resets, space-time bit budget", "result": {"verdict": verdict, "gates": gates, "dimensional": dimensional}, "next_questions": ["unified guarded-destination operator analysis"] if verdict == "PASS" else [], "status": "CONFIRMED" if verdict == "PASS" else "FAILED"})
    dialogue("Which observer closes the coupled task and where does interaction history persist?", claim, {"verdict": verdict, "gates": gates, "dimensional": dimensional}, "The endpoint relation is sufficient only for this response task. Instant boundary, inventory and occupancy-only projections conflate matched states with different futures.", ["boundary temporal leakage", "full-state necessity", "mode-label leakage", "random observer"], "Unify across coupling, transfer and homeostasis without claiming global Q4.", "HIGH", "FROZEN_HOLDOUT")
    prior = json.loads((ROOT / "STATE.json").read_text(encoding="utf-8"))
    confirmed = prior.get("confirmed", []) + ([claim] if verdict == "PASS" else [])
    update_state(last_completed_experiment=claim, complete_modules=prior.get("complete_modules", []) + [claim], confirmed=confirmed, pending_holdout=None, dimensional_extra="ADJUDICATED", next_action="Run unified-operator, scale-law, reciprocal-adaptation, multicast/discontinuity and Rosetta-readiness adjudication.")
    print(json.dumps({"verdict": verdict, "gates": gates, "dimensional": dimensional}, indent=2))
    return 0


if __name__ == "__main__": raise SystemExit(main())
