#!/usr/bin/env python3
"""Frozen functional observer and interior boundary counterexample holdout."""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_apparatus import ACTION0, ACTION1, SENSOR, run_bidirectional_exchange, transform
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, sha256_file, update_state, verify_and_load_kernel

FRAMES = [((0,1,2),(1,1,1)), ((1,0,2),(1,1,1)), ((2,1,0),(1,1,1))]


def ss(a,b): return tuple(int(np.sign(a[i]+b[i])) for i in range(3))


def prediction(case, endpoint, reset):
    if reset: return False
    rec = case["endpoint_at_arrival"][endpoint]
    if rec is None: return False
    perm=tuple(case["frame"]["permutation"]); signs=tuple(case["frame"]["signs"])
    sensor=transform(SENSOR,perm,signs); expected=transform(ACTION0 if endpoint=="A_in" else ACTION1,perm,signs)
    return ss(tuple(rec["direction"]),sensor)==expected


def main():
    started=time.perf_counter(); kernel,env=verify_and_load_kernel(1); claim="C10H05_FUNCTIONAL_OBSERVER_AND_INTERIOR_BOUNDARY_COUNTEREXAMPLE"
    lp=ROOT/"HOLDOUT_LOCKS"/f"{claim}.json"; lock_sha=sha256_file(lp)
    if lock_sha!=lp.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]: raise RuntimeError("lock changed")
    domains=[(39+2*(i%3),(5,7,9)[(i//3)%3],FRAMES[i%3],1+(i%2)) for i in range(12)]
    cases=[]; pairs=[]; seed=115000
    for n,d,frame,q in domains:
        ab=run_bidirectional_exchange(kernel,seed,n,d,"AB",*frame,q); wrong=run_bidirectional_exchange(kernel,seed,n,d,"wrong_receivers",*frame,q)
        cases.extend([ab,wrong]); pairs.append((ab,wrong)); seed+=1
    for mode in ("A_only","B_only","empty","reset_A_after_arrival","reset_B_after_arrival","reset_both_after_arrival","clear_lanes_after_arrival"):
        for n,d,frame,q in domains[:6]: cases.append(run_bidirectional_exchange(kernel,seed,n,d,mode,*frame,q)); seed+=1
    functional_checks=[]
    for c in cases:
        pa=prediction(c,"A_in",c["mode"] in {"reset_A_after_arrival","reset_both_after_arrival"}); pb=prediction(c,"B_in",c["mode"] in {"reset_B_after_arrival","reset_both_after_arrival"})
        aa=c["functional"]["A_received_B_policy"]; ab=c["functional"]["B_received_A_policy"]
        c["functional_observer"]={"pred_A":pa,"pred_B":pb,"actual_A":aa,"actual_B":ab,"correct_A":pa==aa,"correct_B":pb==ab}; functional_checks.extend([pa==aa,pb==ab])
    grouped={m:[c for c in cases if c["mode"]==m] for m in sorted(set(c["mode"] for c in cases))}
    rates={m:{"A":float(np.mean([c["functional"]["A_received_B_policy"] for c in rows])),"B":float(np.mean([c["functional"]["B_received_A_policy"] for c in rows])),"both":float(np.mean([c["functional"]["A_received_B_policy"] and c["functional"]["B_received_A_policy"] for c in rows]))} for m,rows in grouped.items()}
    counter=[]
    for x,y in pairs:
        ox=x["arrival_observers"]; oy=y["arrival_observers"]
        counter.append({"N":x["n"],"distance":x["distance"],"boundary_same":ox["outer_boundary_sha256"]==oy["outer_boundary_sha256"],"inventory_same":ox["bulk_inventory"]==oy["bulk_inventory"],"occupancy_multiview_same":all(ox["projections"][a]["occupancy_sha256"]==oy["projections"][a]["occupancy_sha256"] for a in ("0","1","2")),"random_equal_cell_same":ox["equal_cell_random_observer"]==oy["equal_cell_random_observer"],"future_B_differs":x["functional"]["B_received_A_policy"]!=y["functional"]["B_received_A_policy"],"full_raw_differs":ox["full_raw_sha256"]!=oy["full_raw_sha256"]})
    gates={"functional_observer":float(np.mean(functional_checks))==1,"selective_reset":rates["reset_A_after_arrival"]["A"]==0 and rates["reset_A_after_arrival"]["B"]==1 and rates["reset_B_after_arrival"]["A"]==1 and rates["reset_B_after_arrival"]["B"]==0 and rates["reset_both_after_arrival"]["both"]==0,"lane_clear":rates["clear_lanes_after_arrival"]["both"]==1,"boundary_counterexamples":all(r["boundary_same"] and r["future_B_differs"] for r in counter),"inventory_counterexamples":all(r["inventory_same"] and r["future_B_differs"] for r in counter),"occupancy_counterexamples":all(r["occupancy_multiview_same"] and r["future_B_differs"] for r in counter)}
    verdict="PASS" if all(gates.values()) else "FAIL"
    budgets=[{"N":c["n"],"full_raw_clock_bits":128*c["n"]**3,"instant_boundary_raw_bits":64*(6*c["n"]**2-12*c["n"]+8),"dense_boundary_history_bits":c["outer_boundary_history"]["dense_raw_bits"],"minimal_endpoint_upper_bound_bits":128+math.ceil(math.log2(c["n"]+1))} for c in grouped["AB"]]
    dimensional={"INTERFACE_SUFFICIENT":verdict=="PASS","BOUNDARY_INSTANTANEOUS_INSUFFICIENT":gates["boundary_counterexamples"],"LOWER_DIMENSIONAL_EFFECTIVE_STATE":verdict=="PASS","AREA_LIKE_CODE_CANDIDATE":False,"scope":"binary response after exchange only","space_time_accounting":"dense shell history over N ticks is O(N^3), so it earns no area-law claim"}
    result={"schema":"dee.v27.core10.c10h05.v1","module_id":claim,"status":"COMPLETE","role":"FROZEN_CONFIRMATION_AFTER_DISTINCT_FAILED_H04","lock_sha256":lock_sha,"kernel_environment":env,"verdict":verdict,"functional_observer_accuracy":float(np.mean(functional_checks)),"rates":rates,"matched_counterexamples":counter,"gates":gates,"memory_locus":"receiver endpoint carrier in this apparatus","dimensional_adjudication":dimensional,"information_budgets":budgets,"prior_fail_preserved":"C10H04 FAIL","cases":cases,"wall_clock_seconds":time.perf_counter()-started,"nonclaims":["global Q4","global lower-dimensional universe","holographic code","raw-state closure"]}
    result["content_sha256"]=canonical_hash(result); atomic_json(ROOT/"RESULTS/C10H05_functional_observer.json",result); append_log({"event":"HOLDOUT_COMPLETE","module_id":claim,"verdict":verdict,"lock_sha256":lock_sha,"gates":gates})
    question({"question_id":"C10H05","parent_question_id":"C10H04","front":"multiscale","why_this_question":"separate functional closure from C10H04 raw/boundary omnibus failure","kernel_response_that_triggered_it":"H04 preserved causal locus but failed two observer gates","hypotheses_being_separated":["task-relative functional closure","raw closure","instant boundary sufficiency"],"experiment":claim,"controls":list(grouped),"measurement":"functional class, selective resets, matched boundary signatures, space-time budget","result":{"verdict":verdict,"gates":gates,"dimensional":dimensional},"next_questions":["unified operator and Rosetta readiness"] if verdict=="PASS" else [],"status":"CONFIRMED" if verdict=="PASS" else "FAILED"})
    dialogue("Can a functional quotient close after the stricter raw observer failed?",claim,{"verdict":verdict,"gates":gates},"This new holdout preserves H04 FAIL and adjudicates a distinct functional equivalence relation.",["raw nuisance","boundary contact","inventory","occupancy-only projection"],"Complete unified causal synthesis and stop dimensional expansion.","HIGH","FROZEN_HOLDOUT")
    prior=json.loads((ROOT/"STATE.json").read_text(encoding="utf-8")); confirmed=prior.get("confirmed",[])+([claim] if verdict=="PASS" else []); failed=list(dict.fromkeys(prior.get("failed",[])+["C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS"]+([] if verdict=="PASS" else [claim])))
    update_state(last_completed_experiment=claim,complete_modules=prior.get("complete_modules",[])+[claim],confirmed=confirmed,failed=failed,pending_holdout=None,dimensional_extra="ADJUDICATED_BOUNDED",next_action="Adjudicate unified operator, scale laws, reciprocal adaptation, joint homeostasis, multicast/discontinuity and Rosetta readiness.")
    print(json.dumps({"verdict":verdict,"gates":gates,"dimensional":dimensional},indent=2)); return 0


if __name__=="__main__": raise SystemExit(main())
