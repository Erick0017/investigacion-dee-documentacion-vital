#!/usr/bin/env python3
"""Execute the frozen C10H01-C10H03 holdouts; each module is resumable."""
from __future__ import annotations

import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core10_apparatus import run_bidirectional_exchange, run_joint_scaffold, run_learned_policy_transfer
from core10_common import ROOT, append_log, atomic_json, canonical_hash, dialogue, question, sha256_file, update_state, verify_and_load_kernel

FRAMES = [
    ((0, 1, 2), (1, 1, 1)),
    ((1, 0, 2), (1, -1, 1)),
    ((2, 1, 0), (-1, 1, 1)),
    ((0, 2, 1), (-1, -1, 1)),
]


def locked(claim_id: str):
    path = ROOT / "HOLDOUT_LOCKS" / f"{claim_id}.json"
    digest = sha256_file(path)
    expected = path.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]
    if digest != expected:
        raise RuntimeError(f"lock changed: {claim_id}")
    return json.loads(path.read_text(encoding="utf-8")), digest


def store(result: dict, filename: str) -> None:
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / filename, result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": result["module_id"], "verdict": result["verdict"], "lock_sha256": result["lock_sha256"], "wall_clock_seconds": result["wall_clock_seconds"]})


def h01(kernel, environment):
    claim = "C10H01_BIDIRECTIONAL_CAUSAL_POLICY_EXCHANGE"
    out = ROOT / "RESULTS" / "C10H01_bidirectional_exchange.json"
    if out.exists(): return json.loads(out.read_text(encoding="utf-8"))
    started = time.perf_counter(); lock, lock_sha = locked(claim)
    domains = [(27 + 2 * (i % 3), (4, 6, 8)[(i // 3) % 3], FRAMES[i % 4], 1 + (i % 2)) for i in range(12)]
    cases = []; seed = 111000
    for n, distance, frame, cycles in domains:
        cases.append(run_bidirectional_exchange(kernel, seed, n, distance, "AB", *frame, cycles)); seed += 1
    controls = ["A_only", "B_only", "empty", "no_connection", "block_A_path", "block_B_path", "offpath_cut", "wrong_receivers", "receiver_none"]
    for mode in controls:
        for n, distance, frame, cycles in domains[:6]:
            cases.append(run_bidirectional_exchange(kernel, seed, n, distance, mode, *frame, cycles)); seed += 1
    grouped = {m: [r for r in cases if r["mode"] == m] for m in ["AB"] + controls}
    rates = {m: {"A": float(np.mean([r["functional"]["A_received_B_policy"] for r in rows])), "B": float(np.mean([r["functional"]["B_received_A_policy"] for r in rows])), "both": float(np.mean([r["functional"]["A_received_B_policy"] and r["functional"]["B_received_A_policy"] for r in rows]))} for m, rows in grouped.items()}
    arrival_law = all(r["arrival_tick"] == 1 + r["distance"] and r["query_tick"] == r["arrival_tick"] + r["query_cycles"] * r["n"] for r in cases)
    gates = {
        "AB": rates["AB"]["both"] == 1,
        "offpath": rates["offpath_cut"]["both"] == 1,
        "empty": rates["empty"]["both"] == 0,
        "no_connection": rates["no_connection"]["both"] == 0,
        "block_A": rates["block_A_path"]["B"] == 0 and rates["block_A_path"]["A"] == 1,
        "block_B": rates["block_B_path"]["A"] == 0 and rates["block_B_path"]["B"] == 1,
        "A_only": rates["A_only"]["A"] == 0 and rates["A_only"]["B"] == 1,
        "B_only": rates["B_only"]["A"] == 1 and rates["B_only"]["B"] == 0,
        "arrival_scale_law": arrival_law,
    }
    verdict = "PASS" if all(gates.values()) else "FAIL"
    result = {"schema": "dee.v27.core10.c10h01.v1", "module_id": claim, "status": "COMPLETE", "role": "FROZEN_CONFIRMATION", "lock_sha256": lock_sha, "kernel_environment": environment, "verdict": verdict, "rates": rates, "gates": gates, "law": {"arrival_tick": "1+d", "query_tick": "1+d+qN", "destination_state": "sgn(policy_source + output_relay + receiver_converter)", "scope": "collision-free parallel lanes in the locked domain"}, "cases": cases, "wall_clock_seconds": time.perf_counter() - started, "nonclaims": ["nonlinear mutual adaptation", "synchronization", "teleportation", "external physical communication"]}
    store(result, out.name)
    question({"question_id": "C10H01", "parent_question_id": "C10Q01", "front": "coupling", "why_this_question": "confirm the discovery candidate on new N/seeds/frames/lags", "kernel_response_that_triggered_it": "C10D01 exact directional separation", "hypotheses_being_separated": ["bidirectional causal exchange", "background/receiver artifact"], "experiment": claim, "controls": controls, "measurement": "two endpoint actions and lane timing", "result": {"verdict": verdict, "rates": rates, "gates": gates}, "next_questions": ["trace mediation and minimal observer"] if verdict == "PASS" else [], "status": "CONFIRMED" if verdict == "PASS" else "FAILED"})
    dialogue("Does two-way policy exchange generalize without tuning?", claim, {"verdict": verdict, "gates": gates}, "Both causal directions are adjudicated independently; this is two one-way mediated influences, not synchronization.", ["receiver background", "lane-independent recurrence", "common mode"], "Cross-feed the exact lane law into multiscale mediation.", "HIGH", "FROZEN_HOLDOUT")
    update_state(last_completed_experiment=claim, pending_holdout=["C10H02_LEARNED_POLICY_FUNCTIONAL_REINSTANTIATION", "C10H03_JOINT_INTERFACE_HOMEOSTASIS"])
    return result


def h02(kernel, environment):
    claim = "C10H02_LEARNED_POLICY_FUNCTIONAL_REINSTANTIATION"
    out = ROOT / "RESULTS" / "C10H02_learned_policy_reinstantiation.json"
    if out.exists(): return json.loads(out.read_text(encoding="utf-8"))
    started = time.perf_counter(); lock, lock_sha = locked(claim)
    domains = [(27 + 2 * (i % 3), (4, 6, 8)[(i // 3) % 3], FRAMES[i % 4]) for i in range(12)]
    modes = ["trained", "sreg_nuisance", "offpath_cut", "untrained", "memory_ablation", "history_reset", "direction_ablation", "corridor_cut", "receiver_none", "wrong_receiver", "no_relay"]
    cases = []; seed = 112000
    for mode in modes:
        subset = domains if mode == "trained" else domains[:6]
        for n, distance, frame in subset:
            cases.append(run_learned_policy_transfer(kernel, seed, n, distance, mode, *frame)); seed += 1
    grouped = {m: [r for r in cases if r["mode"] == m] for m in modes}
    rates = {m: float(np.mean([r["functional_policy_reinstantiated"] for r in rows])) for m, rows in grouped.items()}
    depletion = float(np.mean([r["source_depleted_after_launch"] for r in grouped["trained"]]))
    mediation = float(np.mean([r["corridor_all_intermediate_ticks_observed"] for r in grouped["trained"]]))
    positives = ["trained", "sreg_nuisance", "offpath_cut"]
    negatives = ["untrained", "memory_ablation", "history_reset", "direction_ablation", "corridor_cut", "receiver_none", "wrong_receiver", "no_relay"]
    gates = {"positive_modes": all(rates[m] == 1 for m in positives), "causal_negative_modes": all(rates[m] == 0 for m in negatives), "source_depletion": depletion == 1, "sequential_corridor_mediation": mediation == 1}
    verdict = "PASS" if all(gates.values()) else "FAIL"
    identity = {"microidentity": "NOT_PRESERVED", "organizational_identity": "DIRECTION_CLASS_PRESERVED", "functional_identity": "UNSEEN_CONTEXT_RESPONSE_PRESERVED" if verdict == "PASS" else "NOT_CONFIRMED"}
    result = {"schema": "dee.v27.core10.c10h02.v1", "module_id": claim, "status": "COMPLETE", "role": "FROZEN_CONFIRMATION", "lock_sha256": lock_sha, "kernel_environment": environment, "verdict": verdict, "rates": rates, "gates": gates, "trained_source_depletion_rate": depletion, "trained_corridor_mediation_rate": mediation, "identity_adjudication": identity, "transfer_class": "DESTRUCTIVE_FUNCTIONAL_REINSTANTIATION" if verdict == "PASS" else "FAILED_IN_TESTED_APPARATUS", "receiver_role": "inverse interface is necessary but insufficient; its null response is not ACTION1", "cases": cases, "wall_clock_seconds": time.perf_counter() - started, "nonclaims": ["same object", "same raw state", "discontinuous effect", "teleportation", "arbitrary policy transfer"]}
    store(result, out.name)
    question({"question_id": "C10H02", "parent_question_id": "C10Q05", "front": "reinstantiation", "why_this_question": "confirm revised non-leaking transfer on new worlds", "kernel_response_that_triggered_it": "C10D02 exact causal separation", "hypotheses_being_separated": ["functional reinstantiation", "receiver/routing/s_reg artifact", "remote discontinuity"], "experiment": claim, "controls": negatives + positives[1:], "measurement": "learned memory, source depletion, corridor sequence, unseen receiver query", "result": {"verdict": verdict, "rates": rates, "gates": gates, "identity": identity}, "next_questions": ["receiver dependence, multicast gate, unified operator"] if verdict == "PASS" else [], "status": "CONFIRMED" if verdict == "PASS" else "FAILED"})
    dialogue("Can an experience-acquired response repertoire be reinstantiated rather than merely copied by setup?", claim, {"verdict": verdict, "gates": gates, "identity": identity}, "The acquired direction class and function, not raw/hash identity, are conserved through a fully observed causal corridor.", ["converter answer leakage", "untrained route", "s_reg code", "reader artifact"], "Test only transfer modes enabled by an actual branching/reinstantiation mechanism; do not fabricate multicast.", "HIGH", "FROZEN_HOLDOUT")
    update_state(last_completed_experiment=claim, pending_holdout=["C10H03_JOINT_INTERFACE_HOMEOSTASIS"])
    return result


def h03(kernel, environment):
    claim = "C10H03_JOINT_INTERFACE_HOMEOSTASIS"
    out = ROOT / "RESULTS" / "C10H03_joint_interface_homeostasis.json"
    if out.exists(): return json.loads(out.read_text(encoding="utf-8"))
    started = time.perf_counter(); lock, lock_sha = locked(claim)
    primary_domains = [(n, axis) for n in (25, 27, 29, 31) for axis in (0, 1, 2)]
    modes = ["AB", "offpath_cut", "A_only", "B_only", "empty", "missing_shared_one", "shuffled_same_inventory", "full_A_only", "full_B_only"]
    cases = []; seed = 113000
    for mode in modes:
        subset = primary_domains if mode in {"AB", "offpath_cut"} else primary_domains[:6]
        for n, axis in subset:
            cases.append(run_joint_scaffold(kernel, seed, n, mode, 5, axis)); seed += 1
    grouped = {m: [r for r in cases if r["mode"] == m] for m in modes}
    rates = {m: {"A": float(np.mean([r["A_recovery_rate"] for r in rows])), "B": float(np.mean([r["B_recovery_rate"] for r in rows])), "joint": float(np.mean([r["joint_recovery_rate"] for r in rows])), "invariant": float(np.mean([r["scaffold_unchanged"] for r in rows]))} for m, rows in grouped.items()}
    negative = ["A_only", "B_only", "empty", "missing_shared_one", "shuffled_same_inventory"]
    gates = {"AB": rates["AB"]["joint"] == 1 and rates["AB"]["invariant"] == 1, "offpath": rates["offpath_cut"]["joint"] == 1, "negative_controls": all(rates[m]["joint"] == 0 for m in negative), "individual_positive_controls": rates["full_A_only"]["A"] == 1 and rates["full_A_only"]["B"] == 0 and rates["full_B_only"]["A"] == 0 and rates["full_B_only"]["B"] == 1}
    verdict = "PASS" if all(gates.values()) else "FAIL"
    result = {"schema": "dee.v27.core10.c10h03.v1", "module_id": claim, "status": "COMPLETE", "role": "FROZEN_CONFIRMATION", "lock_sha256": lock_sha, "kernel_environment": environment, "verdict": verdict, "rates": rates, "gates": gates, "cycles_per_case": 5, "mechanism": "each center's semantic-4 eight-corner guard requires the same four-cell interface; the pair is the smallest tested unit containing both complete guards", "joint_state": {"variables": ["center_A_occupied", "center_B_occupied", "four-bit shared-interface completeness"], "transition": "if interface and both outer half-scaffolds complete, both vacancies restore in one tick", "task_relative_closure": verdict == "PASS"}, "cases": cases, "wall_clock_seconds": time.perf_counter() - started, "nonclaims": ["adaptive reciprocal learning", "resource creation", "general cooperation", "living system"]}
    store(result, out.name)
    question({"question_id": "C10H03", "parent_question_id": "C10Q03", "front": "coupling", "why_this_question": "confirm whether shared interface, not count, makes the pair regenerative", "kernel_response_that_triggered_it": "C10D01 exact joint-only recovery", "hypotheses_being_separated": ["joint interface homeostasis", "inventory/redundancy", "independent centers"], "experiment": claim, "controls": modes[1:], "measurement": "five damage/recovery cycles per world", "result": {"verdict": verdict, "rates": rates, "gates": gates}, "next_questions": ["multiscale causal trace and observer quotient"] if verdict == "PASS" else [], "status": "CONFIRMED" if verdict == "PASS" else "FAILED"})
    dialogue("Is A+B+interface a bounded joint homeostatic unit?", claim, {"verdict": verdict, "gates": gates}, "The claim is structural and repeated, not adaptive: exact interface geometry supplies two simultaneous guards.", ["double resources", "support count", "random geometry", "single-center repair"], "Trace the shared micro guard to the joint macrostate and test observer sufficiency.", "HIGH", "FROZEN_HOLDOUT")
    update_state(last_completed_experiment=claim, pending_holdout=None)
    return result


def main() -> int:
    kernel, environment = verify_and_load_kernel(1)
    results = [h01(kernel, environment), h02(kernel, environment), h03(kernel, environment)]
    passed = [r["module_id"] for r in results if r["verdict"] == "PASS"]
    failed = [r["module_id"] for r in results if r["verdict"] == "FAIL"]
    update_state(complete_modules=["C10A00", "C10D01", "C10D02"] + [r["module_id"] for r in results], confirmed=passed, failed=["C10D01 receiver-leaking transfer apparatus"] + failed, next_action="Derive multiscale causal trace, minimal task-relative observer, interface information budget, and unified operator from confirmed holdouts.")
    print(json.dumps({"passed": passed, "failed": failed}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
