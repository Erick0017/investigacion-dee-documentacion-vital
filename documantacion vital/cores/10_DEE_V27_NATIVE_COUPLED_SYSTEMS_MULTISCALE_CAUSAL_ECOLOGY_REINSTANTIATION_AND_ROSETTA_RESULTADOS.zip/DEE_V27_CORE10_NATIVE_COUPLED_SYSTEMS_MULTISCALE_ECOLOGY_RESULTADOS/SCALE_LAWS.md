# Leyes de escala

- Exchange: `1+d` y `1+d+qN`, residual máximo 0.
- Learned transfer: `2N`, `3N`, `3N+d`, `4N+d`, residual máximo 0.
- Joint repair: un tick, local e independiente de N en [25, 27, 29, 31].

No se ajustó criticality ni power law. El boundary history denso usa O(N²) celdas por O(N) ticks, por lo que su presupuesto es O(N³), no area law.
