# Trazado causal árbol→bosque

`experience → direction b → relay/fiber → route carrier → cada celda del corridor → receiver reducer → b receptor → unseen sensor → ACTION1`.

En reparación: `shared corner bit → complete eight-corner guards A/B → two center births → joint recovery record`. Un corte causal en cualquier eslabón necesario elimina el efecto; cortes fuera de ruta no.
