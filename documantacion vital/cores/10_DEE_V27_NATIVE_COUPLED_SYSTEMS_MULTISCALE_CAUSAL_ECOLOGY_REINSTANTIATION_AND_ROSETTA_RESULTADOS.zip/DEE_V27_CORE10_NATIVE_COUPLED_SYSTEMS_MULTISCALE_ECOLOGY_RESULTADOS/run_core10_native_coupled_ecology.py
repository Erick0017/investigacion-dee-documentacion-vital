#!/usr/bin/env python3
"""Single resumable CORE10 entrypoint."""
from __future__ import annotations
import argparse, hashlib, json, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent
PY=Path(sys.executable)


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for b in iter(lambda:f.read(1<<20),b""): h.update(b)
    return h.hexdigest()


def validate():
    required=["C10A00_initial_audit.json","C10D01_coupled_discovery.json","C10D02_refined_policy_transfer.json","C10H01_bidirectional_exchange.json","C10H02_learned_policy_reinstantiation.json","C10H03_joint_interface_homeostasis.json","C10H04_task_relative_observer.json","C10H05_functional_observer.json","C10A04_multiscale_unified_analysis.json","C10A05_external_rosetta_screen.json"]
    missing=[x for x in required if not (ROOT/"RESULTS"/x).exists()]
    for path in (ROOT/"RESULTS").glob("*.json"): json.loads(path.read_text(encoding="utf-8"))
    for name in ("QUESTION_TREE.ndjson","KERNEL_DIALOGUE.ndjson","SCIENCE_LOG.ndjson"):
        for line in (ROOT/name).read_text(encoding="utf-8").splitlines():
            if line.strip(): json.loads(line)
    for lock in (ROOT/"HOLDOUT_LOCKS").glob("*.json"):
        expected=lock.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]
        if sha(lock)!=expected: raise RuntimeError(f"lock mismatch: {lock.name}")
    parent=ROOT/"PARENTS"/"09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip"
    if sha(parent)!="70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96": raise RuntimeError("parent mismatch")
    if missing: raise RuntimeError(f"missing results: {missing}")
    return {"results":len(list((ROOT/"RESULTS").glob("*.json"))),"locks":len(list((ROOT/"HOLDOUT_LOCKS").glob("*.json"))),"parent":sha(parent)}


def run(script): subprocess.run([str(PY),"-I","-B",str(ROOT/"RUNNERS"/script)],cwd=ROOT,check=True)


def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--validate-only",action="store_true"); args=ap.parse_args()
    if args.validate_only:
        print(json.dumps({"status":"PASS","validation":validate()},indent=2)); return 0
    stages=[
        ("RESULTS/C10A00_initial_audit.json","initialize_core10.py"),
        ("RESULTS/C10D01_coupled_discovery.json","run_c10d01_coupled_discovery.py"),
        ("RESULTS/C10D02_refined_policy_transfer.json","run_c10d02_refined_policy_transfer.py"),
        ("RESULTS/C10H01_bidirectional_exchange.json","run_core10_holdouts.py"),
        ("RESULTS/C10H04_task_relative_observer.json","freeze_c10h04_observer_lock.py"),
        ("RESULTS/C10H04_task_relative_observer.json","run_c10h04_observer_holdout.py"),
        ("RESULTS/C10H05_functional_observer.json","freeze_c10h05_functional_observer_lock.py"),
        ("RESULTS/C10H05_functional_observer.json","run_c10h05_functional_observer.py"),
        ("RESULTS/C10A04_multiscale_unified_analysis.json","analyze_core10_multiscale.py"),
        ("RESULTS/C10A05_external_rosetta_screen.json","record_external_protocol_screen.py"),
    ]
    # Discovery locks are a special dependency of the combined holdout stage.
    for marker,script in stages:
        if not (ROOT/marker).exists():
            if script=="run_core10_holdouts.py" and not (ROOT/"HOLDOUT_LOCKS/C10H01_BIDIRECTIONAL_CAUSAL_POLICY_EXCHANGE.json").exists(): run("freeze_core10_holdouts.py")
            if script.startswith("run_c10h04") and not (ROOT/"HOLDOUT_LOCKS/C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS.json").exists(): run("freeze_c10h04_observer_lock.py")
            if script.startswith("run_c10h05") and not (ROOT/"HOLDOUT_LOCKS/C10H05_FUNCTIONAL_OBSERVER_AND_INTERIOR_BOUNDARY_COUNTEREXAMPLE.json").exists(): run("freeze_c10h05_functional_observer_lock.py")
            run(script)
    if not (ROOT/"output/10_DEE_V27_NATIVE_COUPLED_SYSTEMS_MULTISCALE_CAUSAL_ECOLOGY_REINSTANTIATION_AND_ROSETTA_RESULTADOS.zip").exists(): run("finalize_core10.py")
    print(json.dumps({"status":"COMPLETE","validation":validate()},indent=2)); return 0


if __name__=="__main__": raise SystemExit(main())
