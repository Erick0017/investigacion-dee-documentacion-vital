# Revisión adversarial

- **¿Se eligió el observer mirando holdout?** No. `M_rel` se derivó de discovery y se congeló en C11H05; C11H06 congeló subobservadores antes de los pares nuevos.
- **¿Se reparó un FAIL?** No hubo FAIL holdout. Se corrigieron dos bugs discovery antes de locks y se conservaron los resultados v0.
- **¿El detector contenía labels?** No. La corrección explícita eliminó el filtro por `state` inicial.
- **¿Una imagen bonita se llamó interferencia?** No. Se usó contraste bin-a-bin y resultó cero.
- **¿La convergencia no aditiva prueba onda?** No. El reductor predice occupancy y `s_reg` exactamente.
- **¿`s_reg` fue llamado temperatura/energía?** No. El contacto no cumple el protocolo de igualación.
- **¿Se confundió identidad con raw?** No. La normalización matched demuestra que raw distingue microestados funcionalmente equivalentes.
- **¿Se sobrepromovió dimensionalidad?** No. Sólo se afirman observadores menores relativos a tarea.
- **¿La Rosetta se escogió por nombre?** No se abrió búsqueda externa porque el fingerprint no cruzó el gate identificador.
- **¿Ticks fueron pseudorreplicados?** No. Las leyes deterministas se evaluaron por mundo/preparación y dominio; los ticks son trayectoria, no réplicas estadísticas.

Conclusión: los positivos internos sobreviven; las interpretaciones físicas permanecen deliberadamente por debajo de validación.
