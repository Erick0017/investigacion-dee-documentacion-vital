# Nuevos descubrimientos CORE11

1. `state` arbitrario no pertenece a la identidad libre persistente: converge a 1 en el primer tick mientras ruta, `s_reg`, semántica y soporte se conservan.
2. La recuperación estable del centro no depende de la dirección de los ocho corners. Requiere en este motif el vecindario completo semantic-4. semantic-0/1 produce sólo un centro transitorio y después colapsa; una esquina ausente bloquea la respuesta.
3. Dos aperturas paralelas son exactamente aditivas en cinco geometrías. Una configuración convergente es no aditiva en occupancy, pero la no aditividad se localiza en la fibra compartida y conserva la suma saturada de `s_reg`.
4. El contacto de portadores estudiado no es intercambio: es coalescencia. Esto falsifica el aparato como termómetro antes de invocar nombres termodinámicos.
5. `M_rel` unifica cuatro familias y supera cinco subobservadores estrictos en holdout. Es un cierre relativo a tarea y el principal hallazgo integrador de CORE11.
