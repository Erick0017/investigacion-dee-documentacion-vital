# Observador dimensional

| Fenómeno | Sustrato | Estado/observador suficiente en la tarea | Límite |
|---|---:|---|---|
| Carrier | 3D | orbit dirigido 1D + payload funcional | sólo sector libre |
| Scaffold | 3D | grafo local semantic-4 de ocho corners + centro | dimensión relacional, no coordenada |
| Propagación | 3D | ruta, first-passage y payload | no predice interacción no declarada |
| Aperturas | 3D | línea transversal del detector + geometría source/aperturas | el detector solo no cierra la dinámica |
| Contacto | 3D | tupla de fibra compartida e inputs | probado para k=2 semantic-1 |

`M_rel` es menor que el bulk `N³` porque descarta celdas inactivas y `state` pre-normalización. Cinco witnesses muestran que support-only, position-only, fibra sin dirección o geometría sin semántica no bastan. Aun así, no se ha probado una representación lower-dimensional global. Veredicto: `LOWER_DIMENSIONAL_TASK_RELATIVE_OBSERVERS_FOUND`.
