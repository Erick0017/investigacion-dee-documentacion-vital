# Equilibrio y candidata de temperatura

Dos carriers con distintos `s_reg` se prepararon con destino común o destinos separados. En contacto común el resultado fue siempre un solo registro estacionario con suma saturada. Separados permanecieron dos registros.

El modelo `min(a+b,19664)` tuvo MAE 0. El promedio `(a+b)/2`, una caricatura de igualación, tuvo MAE 6422.75. Como el contacto elimina la distinción A/B, no existe un estado final de dos sistemas sobre el que evaluar una variable intensiva común.

Veredicto: `NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS`. No se construyó `Theta_DEE`; por ello el principio cero, fluctuaciones térmicas y Landauer quedaron `NOT_JUSTIFIED_TO_TEST`. Este negativo no cubre ensembles source-supported o sectores colectivos no probados.
