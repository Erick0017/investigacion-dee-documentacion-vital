# CORE11 — veredicto ejecutivo

CORE11 alcanzó cierre científico con seis contratos congelados aprobados. Un `PASS` confirma exactamente la relación preregistrada; en `C11H03` esa relación es un negativo de interferencia, no evidencia cuántica.

- **Materia operacional:** `MATTER_LIKE_OPERATIONAL_CLASS_FOUND`, acotado. Un carrier conserva soporte, ruta, `s_reg` y semántica aunque su `state` arbitrario normaliza a 1 tras el primer tick. Un scaffold semantic-4 completo reinstancia su centro tras 4/4 daños en dos nuevos tamaños; controles semantic-1 o con esquina ausente no sostienen esa recuperación.
- **Propagación:** ley exacta `r(t)=r0+t·d mod N`, con velocidad `L_inf=1`, sin spread ni atenuación de `s_reg` en el sector libre probado. Una fibra compartida de dos entradas móviles produce un solo registro con `s_reg_out=min(sum s_reg,19664)` y dirección `sign(sum d)`.
- **Dos aperturas:** `NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APERTURE_APPARATUS`. En cinco geometrías totales, incluyendo tres holdouts, `AB=A+B-closed` exactamente. El control convergente sí fue no aditivo en occupancy, pero quedó explicado por el reductor de destino y su contabilidad exacta de `s_reg`.
- **Equilibrio:** `NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS`. El contacto fusiona dos registros; no deja dos sistemas que igualen una variable intensiva. El modelo de suma saturada tuvo MAE 0; un promedio tuvo MAE 6422.75. No se abrió principio cero ni Landauer.
- **Observador:** `M_rel` —soporte activo, propuestas, multiplicidad de destino, dirección/`s_reg`/semántica y guarda local— predijo las cuatro familias en holdout. Fue el observador suficiente más pequeño entre los subobservadores ensayados, no un cierre global de DEE.
- **Dimensionalidad:** existen representaciones menores relativas a tarea (ruta 1D, detector transversal, fibra local), pero no una reducción dimensional global.
- **Rosetta:** máximo `NEUTRAL_STRUCTURAL_MATCH`. Hay similitud formal con transporte balístico, caminos geométricos independientes y coalescencia, pero no un mapa físico identificador ni predicción externa reservada.

La ley unificadora nativa es una gramática de propuesta dirigida → fibra de destino → reductor/guarda → lectura. Explica persistencia, transporte, aperturas, colisión y reinstanciación local sin convertir ninguna analogía en física externa.
