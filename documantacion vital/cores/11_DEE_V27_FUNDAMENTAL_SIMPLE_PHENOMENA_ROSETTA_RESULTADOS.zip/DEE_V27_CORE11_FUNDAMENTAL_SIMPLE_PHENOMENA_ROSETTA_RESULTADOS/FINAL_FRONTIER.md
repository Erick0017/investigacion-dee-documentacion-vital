# Frontera final CORE11

## Cerrado en el dominio probado

- identidad funcional de carrier y scaffold;
- transporte libre y reductor de dos propuestas móviles;
- aditividad de aperturas paralelas;
- coalescencia de contacto;
- suficiencia/minimalidad relativa de `M_rel` entre candidatos ensayados.

## Requiere mecanismo nuevo

- un modo colectivo con fase y patrón interferente;
- contacto entre ensembles que preserve dos subsistemas y permita igualdad intensiva;
- observador reducido global, no sólo relativo a tarea;
- preparación física para `s_reg`, semántica o fibra.

## Requiere datos externos después de una huella identificadora

- validación física de transporte/interface;
- una Rosetta material multiobservable;
- predicción externa no usada en calibración.

CORE11 no reserva artificialmente CORE12. Estas fronteras no se resuelven repitiendo el aparato ni cambiando umbrales; requieren una clase nativa nueva o un protocolo externo que mida la huella completa.
