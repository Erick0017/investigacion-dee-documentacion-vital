# CORE11 — informe final

## Pregunta y método

CORE11 preguntó si fenómenos simples aparecen en DEE antes de recibir nombres físicos. Se verificaron byte por byte CORE01–10 y el kernel v27. Discovery usó aparatos pequeños; cada promoción creó un lock SHA-256 antes de abrir mundos nuevos. La unidad independiente fue el mundo/preparación, no cada tick.

Un primer screen contenía dos errores de lectura: exigía conservar un `state` que el kernel normaliza y filtraba llegadas por el valor inicial de ese `state`. Los artefactos `*_v0_*` conservan el error. La corrección fue label-blind y se efectuó antes de cualquier lock; ningún holdout fue reparado.

## Resultados confirmados

`C11H01` confirmó dos clases de identidad operacional: carrier localizado con trayectoria exacta y scaffold distribuido con recuperación repetida. Identidad funcional no equivale a igualdad de `raw`.

`C11H02` confirmó el sector libre y el evento de interfaz de dos propuestas móviles. El movimiento usa una métrica operacional `L_inf`; las diagonales no autorizan una identificación con velocidad física.

`C11H03` confirmó aditividad exacta de dos canales paralelos. Los conteos de discovery fueron 1+1=2 y 3+3=6. En tres geometrías holdout el contraste espacial completo fue cero. Una convergencia a destino común redujo dos registros a uno, demostrando que no aditividad de occupancy no implica interferencia.

`C11H04` confirmó coalescencia saturada en contacto y dos registros en el control separado. Al desaparecer la pareja no existe el protocolo mínimo para una temperatura intensiva.

`C11H05` confirmó que `M_rel` predice las cuatro familias en nuevos tamaños, orientación y traslación. `C11H06` falsó cinco simplificaciones: support-only, position-only, necesidad del `raw` inicial, fibra sin dirección y geometría sin semántica.

## Mecanismo

La explicación mínima común no es una etiqueta clásica. Los registros activos proponen destinos; propuestas coincidentes forman fibras; multiplicidad, dirección, `s_reg` y semántica alimentan el reductor; guardas locales pueden crear un registro; un observador lee sólo la respuesta requerida. Esta gramática explica simultáneamente cinco fenómenos, pero no demuestra un estado reducido Markoviano global.

## Rosetta

La comparación se abrió sólo después del freeze interno. El transporte es formalmente balístico, la pantalla de aperturas coincide con caminos independientes y el contacto recuerda una agregación inelástica. Ninguna correspondencia fija una preparación física, unidades y dos observables externos independientes. No se buscaron datasets por nombre. El estado final es `NEUTRAL_STRUCTURAL_MATCH`, sin `EXTERNAL_PREDICTION`.

## Cierre

Todos los frentes recibieron screen, mecanismo y adjudicación. Los negativos quedan acotados al aparato: no se afirma que DEE carezca universalmente de modos colectivos interferentes o de termodinámica; se afirma que no aparecieron en las clases razonables y congeladas de CORE11.
