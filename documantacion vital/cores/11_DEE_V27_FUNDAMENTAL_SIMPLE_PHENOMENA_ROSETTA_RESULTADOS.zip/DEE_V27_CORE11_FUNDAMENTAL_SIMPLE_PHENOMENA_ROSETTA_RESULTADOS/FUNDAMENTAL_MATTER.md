# Materia operacional

## Definición y clases

Una clase merece tratamiento `matter-like` interno si mantiene identidad operacional, es localizable/detectable, interactúa y ofrece respuesta reproducible. CORE11 confirma dos realizaciones diferentes:

- carrier localizado: una instancia persistente que se traslada por un orbit dirigido;
- scaffold distribuido: una relación de ocho soportes semantic-4 capaz de reinstanciar repetidamente un centro.

## Identidad

La microidentidad falla: cambiar el `state` inicial deja registros distintos en `t0`, pero ambos son idénticos tras una actualización si los demás campos coinciden. La identidad funcional del carrier requiere posición, dirección, `s_reg`, semántica y clase de estado post-normalización. Para el scaffold requiere la relación completa semantic-4 y el readout central.

## Causalidad y límites

El inventario por sí solo no explica recuperación sostenida. semantic-0/1 colapsa tras una génesis transitoria, y eliminar una esquina bloquea el centro. No se derivaron masa, inercia, exclusión universal ni equivalencia con materia externa. Veredicto: `MATTER_LIKE_OPERATIONAL_CLASS_FOUND`, no `MATTER = DEE_RECORD`.
