# Rosetta fundamental

## Procedimiento

Las huellas se congelaron antes de cualquier nombre externo. Se evaluaron relaciones, no vocabulario.

## Ranking

1. Carrier persistente y transporte balístico: `FORMAL_SIMILARITY`. La ecuación discreta es exacta, pero calibrar voxel/tick no predice una constante física.
2. Dos aperturas: `NEUTRAL_STRUCTURAL_MATCH` con caminos geométricos independientes. Es una correspondencia negativa respecto de interferencia ondulatoria/cuántica.
3. Fibra compartida: `FORMAL_SIMILARITY` con coalescencia. `s_reg` y dirección carecen de interpretación física congelada.
4. Scaffold: `FORMAL_SIMILARITY` con reinstanciación local; sin preparación material externa.
5. Equilibrio: `NOT_READY`; no apareció variable intensiva.

## Gate

La gramática `proposal → fiber → reducer/guard` usa el mismo mapa interno para varias familias, pero ningún protocolo físico externo conocido queda identificado por todas sus relaciones con pocos parámetros. No existe observable externo reservado. Abrir un dataset por nombres habría violado el cortafuegos de pareidolia.

Estado máximo: `NEUTRAL_STRUCTURAL_MATCH`. `EXTERNAL_PREDICTION=false`, `ROSETTA_VALIDATED=false`.
