# Scaling de interferencia

No se promovió una ley de franjas porque no apareció señal de interferencia. El contraste no lineal fue exactamente cero al variar prospectivamente:

- N: 29–41 en holdout cruzado;
- orientación de los ejes;
- separación y ancho de apertura;
- distancia source–barrier y barrier–detector.

Por tanto no existen datos válidos para ajustar espaciado de nodos, fase, longitud de onda o envelope. Ajustarlos habría sido pareidolia. La única ley de escala disponible es geométrica: el número de llegadas `AB` es la suma de los anchos efectivos de A y B dentro del rango probado.
