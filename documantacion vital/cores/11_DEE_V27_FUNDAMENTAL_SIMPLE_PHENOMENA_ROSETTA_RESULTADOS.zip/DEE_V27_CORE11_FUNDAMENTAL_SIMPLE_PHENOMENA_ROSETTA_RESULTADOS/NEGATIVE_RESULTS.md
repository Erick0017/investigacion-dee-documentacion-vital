# Resultados negativos y límites

- No apareció contraste no aditivo en la pantalla paralela de dos aperturas. Esto no excluye modos colectivos no usados.
- La no aditividad convergente fue reducción de multiplicidad, no evidencia de fase u onda.
- No apareció variable intensiva que se iguale; el contacto fusionó los participantes.
- No se justificaron principio cero ni Landauer.
- No se obtuvo masa, energía, temperatura, fotón ni identidad cuántica.
- No se demostró una reducción dimensional global.
- Ninguna correspondencia produjo predicción externa.
- El `state` inicial no es carga transportada estable en el sector libre: se normaliza a 1.
- La dirección no causa la génesis del centro del scaffold; sólo cambia la dinámica global. La primera explicación quedó falsada.
- Un detector que filtraba el `state` inicial perdió todas las llegadas; fue un error de readout conservado como artefacto supersedido antes de locks.
