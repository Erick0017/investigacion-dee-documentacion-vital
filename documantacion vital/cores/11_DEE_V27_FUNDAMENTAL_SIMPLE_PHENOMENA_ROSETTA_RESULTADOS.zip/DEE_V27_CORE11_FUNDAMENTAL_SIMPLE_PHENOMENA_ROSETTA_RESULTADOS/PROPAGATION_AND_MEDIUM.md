# Propagación y medio

En la región operacional sin otra organización activa, el carrier cumple

`r(t) = r0 + t d (mod N)`

para componentes de `d` en `{-1,0,1}` probadas. Su desplazamiento por tick es uno en `L_inf`; el primer arribo a distancia dirigida `L` ocurre en `L` ticks. Soporte, `s_reg`, dirección y semántica no se atenúan ni se dispersan. El `state` inicial normaliza a 1 tras el primer tick.

Una interfaz no es un medio pasivo: cuando dos propuestas móviles comparten destino, emerge un registro con

`s_reg_out = min(s_reg_A + s_reg_B, 19664)`

`d_out = sign(d_A + d_B)`

en el sector semantic-1 de dos entradas probado. Oposición captura (`d_out=0`); una dirección transversal deflecta. Un ocupante estacionario en el destino mostró aniquilación en discovery y queda como límite de dominio, no absorbido en la ley de entradas móviles.

No se identifican estas unidades con metros/segundos ni con luz física.
