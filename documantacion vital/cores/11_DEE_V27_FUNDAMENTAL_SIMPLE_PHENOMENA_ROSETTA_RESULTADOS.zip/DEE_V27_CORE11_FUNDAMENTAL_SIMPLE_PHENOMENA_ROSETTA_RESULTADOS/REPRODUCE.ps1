param([int]$Threads = 1)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = "D:\Descargas\ANACONDA MINICONDA\python.exe"
if (-not (Test-Path -LiteralPath $Python)) { $Python = "python" }
& $Python -I -B (Join-Path $Root "RUNNERS\verify_parent_chain.py")
& $Python -I -B (Join-Path $Root "RUNNERS\run_core11_fundamental.py") --threads $Threads --no-finalize
if ($LASTEXITCODE -ne 0) { throw "CORE11 reproduction/audit failed" }
Write-Host "CORE11 verified; completed modules were not repeated."
