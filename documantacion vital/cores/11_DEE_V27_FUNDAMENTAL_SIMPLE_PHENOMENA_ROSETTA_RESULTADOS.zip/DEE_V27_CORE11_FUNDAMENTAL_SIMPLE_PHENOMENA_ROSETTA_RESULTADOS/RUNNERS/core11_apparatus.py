"""Neutral apparatus used by CORE11 discovery and frozen holdouts."""
from __future__ import annotations
import math
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core11_common import NativeWorld, fields, pack, unpack_scalar


def occupied(raw):
    return np.argwhere(raw != 0)


def snapshot(world):
    coords = occupied(world.raw)
    return [{"coordinate": [int(v) for v in c], **unpack_scalar(world.raw[tuple(c)]), "clock": int(world.clock[tuple(c)])} for c in coords]


def singleton_trial(kernel, n, start, direction, ticks, state=0x13579BDF, sreg=37, semantic=1, threads=1):
    raw = np.zeros((n, n, n), dtype=np.uint64); raw[start] = pack(state, sreg, direction, semantic)
    world = NativeWorld(kernel, raw, threads=threads); track = []
    for t in range(ticks + 1):
        snap = snapshot(world); track.append({"tick": t, "records": snap})
        if t < ticks: world.tick()
    expected = [[(start[i] + t * direction[i]) % n for i in range(3)] for t in range(ticks + 1)]
    observed = [row["records"][0]["coordinate"] if len(row["records"]) == 1 else None for row in track]
    invariant_fields = all(len(row["records"]) == 1 and row["records"][0]["sreg"] == sreg and row["records"][0]["direction"] == list(direction) and row["records"][0]["semantic"] == semantic for row in track)
    normalized_state = all(len(row["records"]) == 1 and row["records"][0]["state"] == 1 for row in track[1:])
    return {"n": n, "start": list(start), "direction": list(direction), "ticks": ticks, "initial_state": state, "track": track, "expected_track": expected, "trajectory_exact": observed == expected, "transport_invariants_preserved": invariant_fields, "state_normalizes_to_one_after_first_tick": normalized_state, "support_persistent": all(len(row["records"]) == 1 for row in track)}


def morph_scaffold_trial(kernel, n=15, cycles=3, threads=1, direction_mode="inward", corner_semantic=4, omit_corner_indices=(), center=None):
    center = tuple(center) if center is not None else (n // 2, n // 2, n // 2); raw = np.zeros((n, n, n), dtype=np.uint64)
    raw[center] = pack(0x10203040, 19, (0, 0, 0), 1)
    corners = []
    for dx in (-1, 1):
        for dy in (-1, 1):
            for dz in (-1, 1):
                c = (center[0] + dx, center[1] + dy, center[2] + dz); corners.append(c)
                if (len(corners) - 1) in set(omit_corner_indices): continue
                if direction_mode == "inward": direction = (-dx, -dy, -dz)
                elif direction_mode == "outward": direction = (dx, dy, dz)
                elif direction_mode == "zero": direction = (0, 0, 0)
                else: raise ValueError(direction_mode)
                raw[c] = pack(0xA0000000 | (len(corners) << 8), 7 + len(corners), direction, corner_semantic)
    world = NativeWorld(kernel, raw, threads=threads); rows = []
    for cycle in range(cycles):
        pre_support = int(np.count_nonzero(world.raw)); world.raw_a[center] = 0; world.raw_b[center] = 0
        damaged_support = int(np.count_nonzero(world.raw)); stats = world.tick(); center_after = int(world.raw[center])
        rows.append({"cycle": cycle, "pre_support": pre_support, "damaged_support": damaged_support, "center_recovered": center_after != 0, "center_after": unpack_scalar(center_after) if center_after else None, "post_support": int(np.count_nonzero(world.raw)), "tick_stats": stats})
    return {"n": n, "cycles": cycles, "direction_mode": direction_mode, "corner_semantic": corner_semantic, "omitted_corner_indices": list(omit_corner_indices), "center": list(center), "corner_count": len(corners)-len(omit_corner_indices), "cycle_rows": rows, "functional_recovery_rate": sum(r["center_recovered"] for r in rows) / cycles}


def collision_trial(kernel, n, target, incoming, ticks_after=1, threads=1):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    for item in incoming:
        d = tuple(item["direction"]); start = tuple((target[i] - d[i]) % n for i in range(3))
        if raw[start] != 0: raise ValueError("nonunique starts")
        raw[start] = pack(item["state"], item["sreg"], d, item.get("semantic", 1))
    world = NativeWorld(kernel, raw, threads=threads); pre = snapshot(world); stats = []
    for _ in range(ticks_after): stats.append(world.tick())
    return {"n": n, "target": list(target), "incoming": incoming, "pre": pre, "post": snapshot(world), "target_record": unpack_scalar(world.raw[target]) if int(world.raw[target]) else None, "stats": stats}


def _axes(frame):
    # frame is permutation of x/y/z: longitudinal, transverse, depth
    e = []
    for axis in frame:
        v = [0, 0, 0]; v[axis] = 1; e.append(tuple(v))
    return e


def aperture_world(kernel, n=31, frame=(0,1,2), barrier_distance=6, detector_distance=6, slit_centers=(-3,3), slit_width=1, mode="AB", threads=1):
    el, et, ed = _axes(frame); origin = [n // 4, n // 2, n // 2]
    barrier_l = origin[frame[0]] + barrier_distance; detector_l = barrier_l + detector_distance
    ys = list(range(-(n // 4), n // 4 + 1)); slit_a = set(range(slit_centers[0] - slit_width // 2, slit_centers[0] + (slit_width + 1) // 2)); slit_b = set(range(slit_centers[1] - slit_width // 2, slit_centers[1] + (slit_width + 1) // 2))
    open_offsets = set()
    if mode in ("A", "AB"): open_offsets |= slit_a
    if mode in ("B", "AB"): open_offsets |= slit_b
    if mode == "NO_BARRIER": open_offsets = set(ys)
    raw = np.zeros((n,n,n), dtype=np.uint64); source_state = 0x11001100; blocker_state = 0x00CC00CC
    def coord(l, t):
        c = origin.copy(); c[frame[0]] = l % n; c[frame[1]] = (origin[frame[1]] + t) % n; return tuple(c)
    for offset in ys:
        raw[coord(origin[frame[0]], offset)] = pack(source_state, 11, el, 1)
        if mode != "NO_BARRIER" and offset not in open_offsets:
            blocker_start = detector_l
            raw[coord(blocker_start, offset)] = pack(blocker_state, 13, tuple(-v for v in el), 1)
    world = NativeWorld(kernel, raw, threads=threads); arrivals = []
    total_ticks = barrier_distance + detector_distance
    for tick in range(1, total_ticks + 1):
        world.tick()
        if tick == total_ticks:
            for offset in ys:
                c = coord(detector_l, offset); val = int(world.raw[c])
                if val:
                    rec = unpack_scalar(val)
                    # Blockers have left this plane before arrival. The transported
                    # source state is normalized by F_DEE on the first tick, so the
                    # detector is intentionally state-label blind.
                    arrivals.append({"offset": offset, **rec})
    vector = [1 if any(a["offset"] == y for a in arrivals) else 0 for y in ys]
    return {"n": n, "frame": list(frame), "barrier_distance": barrier_distance, "detector_distance": detector_distance, "slit_centers": list(slit_centers), "slit_width": slit_width, "mode": mode, "offsets": ys, "arrival_vector": vector, "arrival_count": sum(vector), "arrivals": arrivals, "total_ticks": total_ticks}


def convergent_two_path(kernel, n=17, mode="AB", threads=1):
    target = (n//2,n//2,n//2); incoming=[]
    if mode in ("A","AB"): incoming.append({"state":0xAAAA0001,"sreg":17,"direction":[1,1,0],"semantic":1})
    if mode in ("B","AB"): incoming.append({"state":0x55550002,"sreg":23,"direction":[1,-1,0],"semantic":1})
    if not incoming: return {"mode":mode,"support":0,"target_record":None}
    trial=collision_trial(kernel,n,target,incoming,1,threads)
    return {"mode":mode,"support":len(trial["post"]),"target_record":trial["target_record"],"post":trial["post"]}


def contact_trial(kernel, a, b, n=17, shared=True, frame=(0,1,2), threads=1):
    el, et, ed = _axes(frame); center=[n//2,n//2,n//2]; target_a=tuple(center)
    target_b=tuple(center if shared else [center[i] + et[i] for i in range(3)])
    raw=np.zeros((n,n,n),dtype=np.uint64)
    start_a=tuple((target_a[i]-el[i])%n for i in range(3)); start_b=tuple((target_b[i]+el[i])%n for i in range(3))
    raw[start_a]=pack(0xF0F00001,a,el,1); raw[start_b]=pack(0x0F0F0002,b,tuple(-v for v in el),1)
    world=NativeWorld(kernel,raw,threads=threads); before=snapshot(world); stats=world.tick(); after=snapshot(world)
    return {"a":a,"b":b,"sum_capped":min(a+b,19664),"shared_destination":shared,"frame":list(frame),"before":before,"after":after,"target_a":unpack_scalar(world.raw[target_a]) if int(world.raw[target_a]) else None,"target_b":unpack_scalar(world.raw[target_b]) if int(world.raw[target_b]) else None,"support_after":len(after),"stats":stats}
