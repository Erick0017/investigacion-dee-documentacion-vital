from __future__ import annotations
import hashlib,json,os,shutil,sys,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT,TESTS,append_log,atomic_json,atomic_text,sha256_file,update_state,utc_now,verify_and_load_kernel

ZIP_NAME="11_DEE_V27_FUNDAMENTAL_SIMPLE_PHENOMENA_ROSETTA_RESULTADOS.zip"
PACKAGE_ROOT="DEE_V27_CORE11_FUNDAMENTAL_SIMPLE_PHENOMENA_ROSETTA_RESULTADOS"
DOCS=["EXECUTIVE_VERDICT.md","FINAL_REPORT.md","TRANSVERSAL_CORE01_TO_11.md","CORE11_NEW_DISCOVERIES.md","FUNDAMENTAL_MATTER.md","PROPAGATION_AND_MEDIUM.md","TWO_APERTURE_EXPERIMENT.md","INTERFERENCE_SCALING.md","EQUILIBRIUM_AND_TEMPERATURE_CANDIDATE.md","DIMENSIONAL_OBSERVER.md","FUNDAMENTAL_ROSETTA.md","COMPOSITE_FINGERPRINT.json","NEGATIVE_RESULTS.md","ADVERSARIAL_REVIEW.md","FINAL_FRONTIER.md","QUESTION_TREE.ndjson","KERNEL_DIALOGUE.ndjson","STATE.json","SCIENCE_LOG.ndjson","PARENT_CHAIN.json"]
PARENT_HASHES={"01":"06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4","02":"4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058","03":"553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640","04":"48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2","05":"aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b","06":"3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e","07":"707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f","08":"275d3e665c0d0c97c3da80ee487819078fc55dbca24bd4e40c7dafa5b5e7a5fc","09":"70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96","10":"2fedd8aa7a488584ed15ab8e8e86a4bd892c97914e7153945cc7fe019a87b515"}


def package_files():
    keep_dirs={"RESULTS","HOLDOUT_LOCKS","RUNNERS","KERNEL"}; files=[]
    for name in DOCS+["REPRODUCE.ps1"]:
        p=ROOT/name
        if p.exists():files.append(p)
    for d in keep_dirs:
        for p in (ROOT/d).rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts and p.suffix.lower() not in {".pyc"}:files.append(p)
    return sorted(set(files),key=lambda p:p.relative_to(ROOT).as_posix())


def verify_holds():
    expected=["C11H01_matter_identity_holdout.json","C11H02_propagation_interface_holdout.json","C11H03_two_aperture_holdout.json","C11H04_contact_equilibrium_holdout.json","C11H05_relational_observer_holdout.json","C11H06_minimal_observer_holdout.json"]
    rows={}
    for name in expected:
        data=json.loads((ROOT/"RESULTS"/name).read_text(encoding="utf-8"));rows[data["claim_id"]]=data["status"]
        lp=ROOT/"HOLDOUT_LOCKS"/f"{data['claim_id']}.json";side=lp.with_suffix(".sha256").read_text().split()[0]
        if sha256_file(lp)!=side or data["lock_sha256"]!=side:raise RuntimeError(f"holdout lock mismatch {name}")
    if not all(v=="PASS" for v in rows.values()):raise RuntimeError(rows)
    return rows


def make_zip(files,out):
    out.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for p in files+[ROOT/"MANIFEST.json",ROOT/"HASHES.sha256"]:
            z.write(p,f"{PACKAGE_ROOT}/{p.relative_to(ROOT).as_posix()}")


def validate_zip(path):
    with zipfile.ZipFile(path,"r") as z:
        if z.testzip() is not None:raise RuntimeError("zip CRC failure")
        prefix=PACKAGE_ROOT+"/";hashes=z.read(prefix+"HASHES.sha256").decode("utf-8").splitlines()
        for row in hashes:
            digest,rel=row.split("  ",1);actual=hashlib.sha256(z.read(prefix+rel)).hexdigest()
            if actual!=digest:raise RuntimeError(f"internal hash mismatch {rel}")
        names=set(z.namelist())
        for name in DOCS:
            if prefix+name not in names:raise RuntimeError(f"missing {name}")
        return {"entries":len(names),"uncompressed_bytes":sum(i.file_size for i in z.infolist()),"compressed_bytes":path.stat().st_size}


def update_expediente(official,official_hash):
    expediente=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE";core=expediente/"CORE";destination=core/ZIP_NAME
    shutil.copyfile(official,destination)
    if sha256_file(destination)!=official_hash:raise RuntimeError("official copy mismatch")
    index_path=expediente/"INDICE_EXPEDIENTE.md";index=index_path.read_text(encoding="utf-8")
    if "### Experimento 11" not in index:
        section="""### Experimento 11 — fenómenos fundamentales simples y Rosetta\n\n`11_DEE_V27_FUNDAMENTAL_SIMPLE_PHENOMENA_ROSETTA_RESULTADOS.zip`\n\nConfirma clases matter-like internas, transporte libre exacto, reductor de fibras y un observador relacional común; falsifica interferencia en el aparato paralelo de dos aperturas y equilibrio intensivo en contacto de portadores; limita la Rosetta a similitud estructural neutral sin predicción externa.\n\n"""
        index=index.replace("## EXTRA",section+"## EXTRA")
    index=index.replace("las diez campañas científicas principales","las once campañas científicas principales").replace("CORE 01–10","CORE 01–11")
    atomic_text(index_path,index)
    names=sorted(core.glob("*.zip"),key=lambda p:int(p.name[:2]))
    if [int(p.name[:2]) for p in names]!=list(range(1,12)):raise RuntimeError(f"CORE not exact 01-11: {[p.name for p in names]}")
    extra=expediente/"EXTRA"/"EXTRA_01_DEE_ORGANIC_TRANSDUCTION_RESULTADOS.zip"
    lines=[f"{sha256_file(p)}  CORE/{p.name}" for p in names]
    if extra.exists():lines.append(f"{sha256_file(extra)}  EXTRA/{extra.name}")
    lines.append(f"{sha256_file(index_path)}  INDICE_EXPEDIENTE.md");atomic_text(expediente/"HASHES.sha256","\n".join(lines)+"\n")
    portable=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE_COMPLETO.zip"
    with zipfile.ZipFile(portable,"w",zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as z:
        for p in sorted((x for x in expediente.rglob("*") if x.is_file()),key=lambda x:x.relative_to(expediente).as_posix()):z.write(p,f"EXPEDIENTE_EXPERIMENTOS_DEE/{p.relative_to(expediente).as_posix()}")
    return {"destination":str(destination),"core_files":[p.name for p in names],"portable":str(portable),"portable_sha256":sha256_file(portable)}


def main():
    _,identity=verify_and_load_kernel(1);holds=verify_holds()
    for name in DOCS:
        if not (ROOT/name).exists():raise RuntimeError(f"missing required {name}")
    reproduce=r'''param([int]$Threads = 1)
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Python = "D:\Descargas\ANACONDA MINICONDA\python.exe"
if (-not (Test-Path -LiteralPath $Python)) { $Python = "python" }
& $Python -I -B (Join-Path $Root "RUNNERS\verify_parent_chain.py")
& $Python -I -B (Join-Path $Root "RUNNERS\run_core11_fundamental.py") --threads $Threads --no-finalize
if ($LASTEXITCODE -ne 0) { throw "CORE11 reproduction/audit failed" }
Write-Host "CORE11 verified; completed modules were not repeated."
'''
    atomic_text(ROOT/"REPRODUCE.ps1",reproduce)
    append_log({"module_id":"C11F01_FINALIZATION","event":"SCIENTIFIC_CLOSE","holdouts":holds,"rosetta":"NEUTRAL_STRUCTURAL_MATCH"})
    state=json.loads((ROOT/"STATE.json").read_text());update_state(status="COMPLETE",completed_modules=state.get("completed_modules",[])+["C11F01_FINALIZATION"],holdout_results={**state.get("holdout_results",{}),**holds},final_states={"matter":"BOUNDED_CONFIRMED","propagation":"CONFIRMED","two_aperture":"NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_APPARATUS","equilibrium":"FAILED_TO_PRODUCE_INTENSIVE_EQUALIZATION","observer":"BOUNDED_CONFIRMED","rosetta":"NEUTRAL_STRUCTURAL_MATCH"},next_action="NONE_CORE11_COMPLETE")
    files=package_files();manifest={"schema":"DEE_CORE11_MANIFEST_V1","created_utc":utc_now(),"package_root":PACKAGE_ROOT,"official_zip":ZIP_NAME,"parent_embedding":False,"parents":PARENT_HASHES,"kernel_identity":identity["observed_hashes"],"holdout_results":holds,"science_verdicts":{"matter":"MATTER_LIKE_OPERATIONAL_CLASS_FOUND","propagation":"EXACT_FREE_TRANSPORT_AND_INTERFACE_REDUCER","two_aperture":"NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APPARATUS","equilibrium":"NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS","observer":"M_REL_SMALLEST_SUFFICIENT_AMONG_TESTED_FAMILY","rosetta":"NEUTRAL_STRUCTURAL_MATCH"},"files":[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha256_file(p)} for p in files]};atomic_json(ROOT/"MANIFEST.json",manifest)
    hashes=[]
    for p in files+[ROOT/"MANIFEST.json"]:hashes.append(f"{sha256_file(p)}  {p.relative_to(ROOT).as_posix()}")
    atomic_text(ROOT/"HASHES.sha256","\n".join(hashes)+"\n")
    out=ROOT/"output"/ZIP_NAME;make_zip(files,out);validation=validate_zip(out)
    if out.stat().st_size>5_000_000:raise RuntimeError(f"compact target exceeded {out.stat().st_size}")
    official_hash=sha256_file(out);exp=update_expediente(out,official_hash)
    print(json.dumps({"official_zip":exp["destination"],"sha256":official_hash,"validation":validation,"core_count":len(exp["core_files"]),"portable_sha256":exp["portable_sha256"]},indent=2))

if __name__=="__main__":main()
