from __future__ import annotations
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, atomic_text, sha256_file, update_state, utc_now, verify_and_load_kernel


LOCKS={
"C11H01_MATTER_IDENTITY":{
 "question":"Do a translating singleton and a complete semantic-4 scaffold instantiate reproducible task-relative operational identity?",
 "apparatus":"core11_apparatus.singleton_trial + morph_scaffold_trial","observer":{"singleton":["support","position","direction","s_reg","semantic","post-t0 state class"],"scaffold":["relative eight-corner support","center response","support stability"]},
 "parameters":{"carrier_trials":[{"n":27,"start":[9,13,17],"direction":[-1,0,1],"ticks":11,"state":286331153,"sreg":91},{"n":31,"start":[15,8,19],"direction":[1,-1,0],"ticks":13,"state":3735928559,"sreg":777},{"n":37,"start":[12,21,7],"direction":[0,1,1],"ticks":15,"state":42,"sreg":19664}],"scaffolds":[{"n":21,"center":[7,10,13]},{"n":25,"center":[12,8,15]}],"cycles":4},
 "predicted_relation":"singleton r(t)=r0+t*d mod N with one support, invariant d/s_reg/semantic and state=1 after t>=1; complete semantic-4 scaffold restores center on every cycle without net support growth; semantic1 and missing-corner controls do not sustain repeated restoration",
 "controls":["semantic1 same geometry/inventory","semantic4 one-corner-missing","translations","new N","new initial state/s_reg"],"nulls":["mere inventory","raw-hash identity","direction-only identity"],
 "PASS":"all singleton relations exact; both full scaffolds recover 4/4 with post_support=pre_support; semantic1 recovery<1 and missing-corner recovery=0","FAIL":"any main relation fails or a negative control matches sustained stable recovery","INCONCLUSIVE":"technical/kernel identity error","minimum_effect":"exact deterministic relation in all declared trials","seeds":[1101,1102,1103],"N":[21,25,27,31,37],"falsifier":"same observer state yields different declared task future in-domain"},
"C11H02_PROPAGATION_INTERFACE":{
 "question":"Does the free carrier obey a prospective transport law and do moving shared-destination interfaces obey the guarded reducer?","apparatus":"singleton_trial + collision_trial","observer":["first arrival","L_inf displacement","support","s_reg","direction","semantic","shared destination"],
 "parameters":{"free":[{"n":29,"start":[6,11,17],"direction":[1,1,-1],"ticks":10,"state":123,"sreg":55},{"n":34,"start":[20,9,12],"direction":[-1,0,-1],"ticks":12,"state":456,"sreg":900}],"collisions":[{"n":21,"incoming":[[1,0,0],[-1,1,0]],"sreg":[80,140]},{"n":25,"incoming":[[0,1,1],[0,-1,-1]],"sreg":[9000,15000]},{"n":27,"incoming":[[1,-1,0],[0,1,1]],"sreg":[3,7]}]},
 "predicted_relation":"free L_inf speed=1 and first arrival=distance with post-first-tick state normalization; moving co-destination pair gives one record, componentwise sign of summed directions, and capped s_reg sum","controls":["new directions","new N","opposed and non-opposed moving inputs","cap case"],"nulls":["diffusive spread","distance-dependent attenuation","unresolved two-body passage"],
 "PASS":"all free trajectories/invariants exact and all collision outputs match predicted multiplicity/direction/s_reg","FAIL":"any prospective relation fails","INCONCLUSIVE":"technical/kernel identity error","minimum_effect":"exact deterministic relation","seeds":[1201,1202],"N":[21,25,27,29,34],"falsifier":"arrival or reducer output differs from frozen equation"},
"C11H03_TWO_APERTURE":{
 "question":"Does a parallel two-aperture detector show any nonadditive spatial or arrival response beyond independent geometry?","apparatus":"state-label-blind aperture_world plus convergent shared-destination positive control","observer":["detector-plane arrival vector","arrival count","arrival tick","s_reg","shared-destination multiplicity"],
 "parameters":{"cases":[{"n":29,"frame":[2,0,1],"barrier_distance":5,"detector_distance":6,"slit_centers":[-4,3],"slit_width":1},{"n":37,"frame":[0,2,1],"barrier_distance":8,"detector_distance":7,"slit_centers":[-6,5],"slit_width":2},{"n":39,"frame":[1,0,2],"barrier_distance":7,"detector_distance":9,"slit_centers":[-5,6],"slit_width":3}]},
 "predicted_relation":"closed=0; A and B populate only their apertures; AB vector=A+B-closed exactly and arrival tick=barrier_distance+detector_distance; convergent shared-destination control is nonadditive in occupancy but conserves capped s_reg via the reducer","controls":["no barrier","closed barrier","A only","B only","convergent shared destination"],"nulls":["visual pattern","geometry-only independent paths","state-label readout artifact"],
 "PASS":"all parallel nonlinear contrast entries exactly zero and positive collision control behaves as predicted","FAIL":"any reproducible nonzero parallel contrast or control failure","INCONCLUSIVE":"detector/readout failure","minimum_effect":"exact zero contrast across all frozen geometries","seeds":[1301,1302,1303],"N":[29,37,39],"falsifier":"AB detector measure not equal to prospective single-path sum"},
"C11H04_CONTACT_EQUILIBRIUM":{
 "question":"In the tested two-carrier contact class, is contact intensive equalization or capped additive coalescence?","apparatus":"contact_trial shared versus separate destination","observer":["body multiplicity","output s_reg","direction","persistence of two subsystems"],
 "parameters":{"trials":[{"n":22,"frame":[1,0,2],"a":2,"b":5},{"n":26,"frame":[2,1,0],"a":8191,"b":8192},{"n":30,"frame":[0,2,1],"a":12000,"b":12000},{"n":32,"frame":[1,2,0],"a":0,"b":19664}]},
 "predicted_relation":"shared destination produces one zero-direction record with s_reg=min(a+b,19664); separated control preserves two records; therefore no two-body final state exists on which an intensive Theta equalizes","controls":["same inventory separated destinations","cap and non-cap pairs","new orientations/N"],"nulls":["averaging","bidirectional exchange","intensive equalization"],
 "PASS":"all shared cases follow capped coalescence and all separated cases retain two bodies","FAIL":"two persistent contact bodies equalize or reducer equation fails","INCONCLUSIVE":"technical/kernel identity error","minimum_effect":"exact deterministic relation","seeds":[1401,1402,1403,1404],"N":[22,26,30,32],"falsifier":"prospective output multiplicity or s_reg relation fails"}}


def main():
    verify_and_load_kernel(1); rows=[]
    for claim_id,body in LOCKS.items():
        data={"claim_id":claim_id,"schema":"DEE_CORE11_HOLDOUT_LOCK_V1","frozen_utc":utc_now(),"status":"LOCKED_UNOPENED",**body}
        path=ROOT/"HOLDOUT_LOCKS"/f"{claim_id}.json"; atomic_json(path,data); digest=sha256_file(path); atomic_text(path.with_suffix(".sha256"),f"{digest}  {path.name}\n"); rows.append({"claim_id":claim_id,"lock_sha256":digest})
    atomic_json(ROOT/"RESULTS"/"C11L01_holdout_locks.json",{"module_id":"C11L01_HOLDOUT_LOCKS","status":"COMPLETE","locks":rows})
    append_log({"module_id":"C11L01_HOLDOUT_LOCKS","event":"COMPLETE","locks":rows})
    update_state(completed_modules=["C11A00_INITIAL_AUDIT","C11D01_PHENOMENON_SCREENS","C11D02_MECHANISM_REFINEMENT","C11D03_SCAFFOLD_MECHANISM","C11L01_HOLDOUT_LOCKS"],pending_holdout=[r["claim_id"] for r in rows],next_action="Open each frozen holdout once")
    print(rows)

if __name__=="__main__":main()
