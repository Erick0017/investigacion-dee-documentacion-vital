from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core11_common import ROOT, TESTS, atomic_json, atomic_text, append_log, sha256_file, update_state, utc_now, verify_and_load_kernel

PARENTS = [
    ("CORE01", "01_DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_RESULTADOS.zip", "06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4"),
    ("CORE02", "02_DEE_V27_ROSETTA_CONSTRUCTION_FINAL_RESULTADOS.zip", "4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058"),
    ("CORE03", "03_DEE_V27_MULTISCALE_EMERGENCE_AND_ROSETTA_RESULTADOS.zip", "553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640"),
    ("CORE04", "04_DEE_V27_NATIVE_SCALE_AND_ROSETTA_HUNT_RESULTADOS.zip", "48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2"),
    ("CORE05", "05_DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS.zip", "aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b"),
    ("CORE06", "06_DEE_V27_NATIVE_LEARNING_C_RELATIVITY_AND_ROSETTA_CLOSURE_RESULTADOS.zip", "3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e"),
    ("CORE07", "07_DEE_V27_UNIVERSAL_EXPERIMENTAL_ATLAS_AND_FINAL_SYNTHESIS_RESULTADOS.zip", "707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f"),
    ("CORE08", "08_DEE_V27_NEUTRAL_OBSERVER_CONVERGENCE_AUTONOMY_AND_DIMENSIONALITY_RESULTADOS.zip", "275d3e665c0d0c97c3da80ee487819078fc55dbca24bd4e40c7dafa5b5e7a5fc"),
    ("CORE09", "09_DEE_V27_EXTERNAL_ROSETTA_ADAPTIVE_AUTONOMY_RESILIENT_MEMORY_AND_EMERGENT_SUBSYSTEMS_RESULTADOS.zip", "70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96"),
    ("CORE10", "10_DEE_V27_NATIVE_COUPLED_SYSTEMS_MULTISCALE_CAUSAL_ECOLOGY_REINSTANTIATION_AND_ROSETTA_RESULTADOS.zip", "2fedd8aa7a488584ed15ab8e8e86a4bd892c97914e7153945cc7fe019a87b515"),
]


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--threads", type=int, default=1); args = parser.parse_args()
    kernel, identity = verify_and_load_kernel(args.threads)
    core = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
    rows = []
    for core_id, name, expected in PARENTS:
        path = core / name; observed = sha256_file(path) if path.exists() else None
        rows.append({"core_id": core_id, "filename": name, "expected_sha256": expected, "observed_sha256": observed, "verified": observed == expected, "path": str(path)})
    if not all(row["verified"] for row in rows): raise RuntimeError(f"parent mismatch: {rows}")
    atomic_json(ROOT / "PARENT_CHAIN.json", {"schema": "DEE_CORE11_PARENT_CHAIN_V1", "verified_utc": utc_now(), "parents": rows, "embedded": False, "policy": "parents referenced and hash-verified; no parent ZIP embedded"})
    for name in ("QUESTION_TREE.ndjson", "KERNEL_DIALOGUE.ndjson", "SCIENCE_LOG.ndjson"):
        if not (ROOT / name).exists(): atomic_text(ROOT / name, "")
    atomic_json(ROOT / "STATE.json", {
        "campaign": "CORE11", "status": "RUNNING", "current_question": "Do simple native phenomena exist and obey frozen laws?",
        "completed_modules": ["C11A00_INITIAL_AUDIT"], "active_fronts": ["MATTER", "PROPAGATION", "TWO_APERTURE", "EQUILIBRIUM", "DIMENSIONAL_OBSERVER", "ROSETTA"],
        "proven": ["PARENT_CHAIN_VERIFIED", "KERNEL_V27_IDENTITY_VERIFIED"], "refuted": [], "provisional": [],
        "next_action": "Run cheap phenomenon screens against the real kernel", "timestamp_utc": utc_now(),
    })
    result = {"module_id": "C11A00_INITIAL_AUDIT", "status": "COMPLETE", "parent_chain": rows, "kernel_identity": identity, "p_kernel": 19665, "s_reg_cap": 19664}
    atomic_json(ROOT / "RESULTS" / "C11A00_initial_audit.json", result)
    append_log({"module_id": "C11A00_INITIAL_AUDIT", "event": "COMPLETE", "result": {"parents_verified": len(rows), "kernel_verified": True}})
    print("CORE11 initialization COMPLETE; 10 parents and kernel v27 verified")


if __name__ == "__main__": main()
