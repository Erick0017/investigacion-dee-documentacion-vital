from __future__ import annotations
import argparse, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, dialogue, question, update_state, verify_and_load_kernel
from core11_apparatus import aperture_world, collision_trial, contact_trial, convergent_two_path, morph_scaffold_trial, singleton_trial


def main():
    p=argparse.ArgumentParser(); p.add_argument("--threads",type=int,default=1); args=p.parse_args(); started=time.perf_counter()
    kernel, identity=verify_and_load_kernel(args.threads)
    singleton=[]
    for n,d in [(13,(1,0,0)),(17,(0,-1,0)),(19,(1,1,0)),(23,(1,-1,1))]:
        singleton.append(singleton_trial(kernel,n,(n//3,n//2,n//2),d,min(8,n-2),threads=args.threads))
    scaffold=morph_scaffold_trial(kernel,15,4,args.threads)
    matter={"singleton_trials":singleton,"homeostatic_scaffold":scaffold,"screen_pass":all(t["trajectory_exact"] and t["transport_invariants_preserved"] and t["state_normalizes_to_one_after_first_tick"] and t["support_persistent"] for t in singleton) and scaffold["functional_recovery_rate"]==1.0,"identity_note":"functional identity preserves route/s_reg/semantic/support while arbitrary initial state normalizes to 1 after the first free update"}
    atomic_json(ROOT/"RESULTS"/"C11D01_matter_screen.json",matter)

    interfaces=[]
    for converter in [
        {"name":"opposed_capture","direction":[-1,0,0]},
        {"name":"orthogonal_deflection","direction":[0,1,0]},
        {"name":"passive_load","direction":[0,0,0]},
    ]:
        incoming=[{"state":0x11110001,"sreg":17,"direction":[1,0,0],"semantic":1},{"state":0x22220002,"sreg":23,"direction":converter["direction"],"semantic":1}]
        row=collision_trial(kernel,17,(8,8,8),incoming,1,args.threads); row["interface_name"]=converter["name"]; interfaces.append(row)
    propagation={"free_trials":singleton,"interface_trials":interfaces,"free_l_inf_speed":1,"screen_pass":all(t["trajectory_exact"] and t["transport_invariants_preserved"] and t["state_normalizes_to_one_after_first_tick"] for t in singleton),"payload_correction":"initial state is not conserved; it deterministically normalizes to 1 while s_reg/direction/semantic persist"}
    atomic_json(ROOT/"RESULTS"/"C11D02_propagation_screen.json",propagation)

    aperture_cases=[]
    for spec in [
        {"n":31,"frame":(0,1,2),"barrier_distance":6,"detector_distance":6,"slit_centers":(-3,3),"slit_width":1},
        {"n":35,"frame":(1,2,0),"barrier_distance":7,"detector_distance":5,"slit_centers":(-4,4),"slit_width":3},
    ]:
        worlds={m:aperture_world(kernel,mode=m,threads=args.threads,**spec) for m in ("NO_BARRIER","CLOSED","A","B","AB")}
        contrast=[ab-a-b+c for ab,a,b,c in zip(worlds["AB"]["arrival_vector"],worlds["A"]["arrival_vector"],worlds["B"]["arrival_vector"],worlds["CLOSED"]["arrival_vector"])]
        aperture_cases.append({"spec":{k:list(v) if isinstance(v,tuple) else v for k,v in spec.items()},"worlds":worlds,"nonlinear_contrast":contrast,"contrast_l1":sum(abs(v) for v in contrast),"exact_additivity":all(v==0 for v in contrast)})
    convergence={m:convergent_two_path(kernel,17,m,args.threads) for m in ("CLOSED","A","B","AB")}
    conv_occ=convergence["AB"]["support"]-convergence["A"]["support"]-convergence["B"]["support"]
    aperture={"parallel_aperture_cases":aperture_cases,"convergent_control":convergence,"convergent_occupancy_contrast":conv_occ,"screen_status":"NO_INTERFERENCE_LIKE_SIGNAL" if all(c["exact_additivity"] for c in aperture_cases) else "INTERFERENCE_LIKE_CANDIDATE"}
    atomic_json(ROOT/"RESULTS"/"C11D03_two_aperture_screen.json",aperture)

    contacts=[]
    for n,frame,a,b in [(17,(0,1,2),11,31),(19,(1,2,0),101,509),(23,(2,0,1),9000,15000)]:
        contacts.append({"contact":contact_trial(kernel,a,b,n,True,frame,args.threads),"separated":contact_trial(kernel,a,b,n,False,frame,args.threads)})
    contact_merge_all=all(r["contact"]["support_after"]==1 and r["contact"]["target_a"] and r["contact"]["target_a"]["sreg"]==r["contact"]["sum_capped"] for r in contacts)
    separate_all=all(r["separated"]["support_after"]==2 for r in contacts)
    equilibrium={"trials":contacts,"contact_merge_relation_exact":contact_merge_all,"separated_support_preserved":separate_all,"two_persistent_bodies_after_contact":False,"theta_candidate_found":False,"screen_status":"NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS"}
    atomic_json(ROOT/"RESULTS"/"C11D04_equilibrium_screen.json",equilibrium)

    summary={"module_id":"C11D01_PHENOMENON_SCREENS","status":"COMPLETE","matter":matter["screen_pass"],"propagation":propagation["screen_pass"],"two_aperture":aperture["screen_status"],"equilibrium":equilibrium["screen_status"],"kernel_identity":identity,"wall_clock_seconds":time.perf_counter()-started}
    atomic_json(ROOT/"RESULTS"/"C11D01_phenomenon_screens_summary.json",summary)
    entries=[
        ("C11Q_MATTER_A",None,"MATTER","Which native organizations earn operational identity?","Singleton transport and guarded scaffold damage recovery","CONFIRMED" if matter["screen_pass"] else "FAILED"),
        ("C11Q_PROP_A",None,"PROPAGATION","Does an empty operational region support a reproducible transport law?","Exact singleton trajectories across four directions/N","CONFIRMED" if propagation["screen_pass"] else "FAILED"),
        ("C11Q_APER_A",None,"TWO_APERTURE","Is the AB detector distribution non-additive?",f"Parallel contrasts L1={[c['contrast_l1'] for c in aperture_cases]}; convergent occupancy contrast={conv_occ}","FAILED" if aperture["screen_status"].startswith("NO_") else "MECHANISM_CANDIDATE"),
        ("C11Q_EQ_A",None,"EQUILIBRIUM","Does contact preserve two systems while equalizing an intensive coordinate?",f"merge_exact={contact_merge_all}; separated_support={separate_all}; no two-body final","FAILED"),
    ]
    for qid,parent,front,q,response,status in entries:
        question({"question_id":qid,"parent_question_id":parent,"front":front,"why_this_question":"CORE11 level-A phenomenon screen","hypotheses_being_separated":["native law","simple null"],"experiment":"C11D01 real-kernel screen","controls":["matched geometry","separated/no barrier/single path as applicable"],"measurement":"trial-level state, arrival, support and response","kernel_response_that_triggered_it":response,"result":response,"next_questions":["freeze prospective law screen" if status=="CONFIRMED" else "bound negative and test cheapest mechanism control"],"status":status})
    dialogue({"question":"Which simple phenomena survive neutral level-A screens?","experiment":"C11D01 matter/propagation/aperture/contact real-kernel battery; corrected state-label-blind aperture readout","kernel_response":summary,"interpretation":"Persistent functional classes and exact transport survive with first-tick state normalization; parallel apertures are additive; contact coalesces rather than equalizes.","alternatives":["geometry-only transport","destination-reducer collision","observer artifact"],"next_question":"Freeze independent holdouts for each relation and adjudicate task-relative observers.","confidence":"HIGH for tested apparatus","evidence_level":"DISCOVERY_REAL_KERNEL"})
    append_log({"module_id":"C11D01_PHENOMENON_SCREENS","event":"COMPLETE","result":summary})
    update_state(completed_modules=["C11A00_INITIAL_AUDIT","C11D01_PHENOMENON_SCREENS"],last_completed_experiment="C11D01_PHENOMENON_SCREENS",provisional=["MATTER_LIKE_OPERATIONAL_CLASS_CANDIDATE","EXACT_BALLISTIC_TRANSPORT_CANDIDATE","APERTURE_ADDITIVITY_CANDIDATE","CONTACT_COALESCENCE_CANDIDATE"],refuted=["INTERFERENCE_LIKE_SIGNAL_IN_PARALLEL_APERTURE_SCREEN","INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS"],next_action="Inspect discovery, freeze H01-H04 locks, then open independent holdouts")
    print(summary)


if __name__=="__main__": main()
