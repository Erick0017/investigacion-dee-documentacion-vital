from __future__ import annotations
import argparse, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, dialogue, question, update_state, verify_and_load_kernel
from core11_apparatus import aperture_world, contact_trial, convergent_two_path, morph_scaffold_trial, singleton_trial


def main():
    p=argparse.ArgumentParser(); p.add_argument("--threads",type=int,default=1); args=p.parse_args(); t0=time.perf_counter(); kernel,identity=verify_and_load_kernel(args.threads)
    scaffold={mode:morph_scaffold_trial(kernel,17,3,args.threads,mode) for mode in ("inward","zero","outward")}
    scaffold_mechanism=scaffold["inward"]["functional_recovery_rate"]==1.0 and scaffold["zero"]["functional_recovery_rate"]==0.0 and scaffold["outward"]["functional_recovery_rate"]==0.0
    carriers=[]
    for state,sreg,d in [(0,0,(1,0,0)),(0xFFFFFFFF,19664,(0,1,-1)),(17,1,(-1,-1,-1)),(999,400,(1,0,1))]:
        carriers.append(singleton_trial(kernel,29,(9,14,14),d,6,state,sreg,1,args.threads))
    normalization=all(r["state_normalizes_to_one_after_first_tick"] and r["transport_invariants_preserved"] and r["trajectory_exact"] for r in carriers)
    # Geometry-only prediction: independent channels remain additive, shared destination reduces two paths to one record.
    parallel={m:aperture_world(kernel,33,(2,0,1),5,7,(-5,4),2,m,args.threads) for m in ("CLOSED","A","B","AB")}
    contrast=[ab-a-b+c for ab,a,b,c in zip(parallel["AB"]["arrival_vector"],parallel["A"]["arrival_vector"],parallel["B"]["arrival_vector"],parallel["CLOSED"]["arrival_vector"])]
    convergent={m:convergent_two_path(kernel,19,m,args.threads) for m in ("CLOSED","A","B","AB")}
    collision_accounting=(convergent["AB"]["support"]==1 and convergent["A"]["support"]==1 and convergent["B"]["support"]==1 and convergent["AB"]["target_record"]["sreg"]==convergent["A"]["target_record"]["sreg"]+convergent["B"]["target_record"]["sreg"])
    contacts=[]
    for a,b in [(0,0),(1,19664),(19664,19664),(73,991)]:
        contacts.append({"shared":contact_trial(kernel,a,b,25,True,(0,2,1),args.threads),"separated":contact_trial(kernel,a,b,25,False,(0,2,1),args.threads)})
    reducer=all(x["shared"]["support_after"]==1 and x["shared"]["target_a"]["sreg"]==min(x["shared"]["a"]+x["shared"]["b"],19664) and x["separated"]["support_after"]==2 for x in contacts)
    result={"module_id":"C11D02_MECHANISM_REFINEMENT","status":"COMPLETE","scaffold_direction_control":scaffold,"scaffold_direction_causal":scaffold_mechanism,"state_normalization_trials":carriers,"state_normalization_relation":normalization,"parallel_aperture":parallel,"parallel_contrast":contrast,"parallel_additive":all(v==0 for v in contrast),"convergent_two_path":convergent,"convergent_collision_accounting":collision_accounting,"contact_trials":contacts,"contact_reducer_relation":reducer,"kernel_identity":identity,"wall_clock_seconds":time.perf_counter()-t0}
    atomic_json(ROOT/"RESULTS"/"C11D02_mechanism_refinement.json",result)
    question({"question_id":"C11Q_MATTER_MECH","parent_question_id":"C11Q_MATTER_A","front":"MATTER","why_this_question":"Separate geometric inventory from inward semantic-4 causal proposals","kernel_response_that_triggered_it":f"recovery rates inward/zero/outward={[scaffold[m]['functional_recovery_rate'] for m in ('inward','zero','outward')]}","hypotheses_being_separated":["inward destination-fiber genesis","mere eight-cell inventory"],"experiment":"matched scaffold direction intervention","controls":["zero direction","outward direction","same support/inventory"],"measurement":"center recovery across repeated damage","result":"inward-only recovery" if scaffold_mechanism else "control not decisive","next_questions":["freeze new-N scaffold holdout"],"status":"MECHANISM_CANDIDATE" if scaffold_mechanism else "INCONCLUSIVE"})
    question({"question_id":"C11Q_APER_MECH","parent_question_id":"C11Q_APER_A","front":"TWO_APERTURE","why_this_question":"Determine whether nonadditivity requires shared destination rather than two-path geometry","kernel_response_that_triggered_it":f"parallel L1={sum(abs(v) for v in contrast)}; convergent support AB/A/B={convergent['AB']['support']}/{convergent['A']['support']}/{convergent['B']['support']}","hypotheses_being_separated":["path interference","destination-fiber reduction"],"experiment":"parallel disjoint channels versus convergent shared destination","controls":["A only","B only","closed"],"measurement":"occupancy contrast and s_reg accounting","result":"shared-destination reducer explains observed nonadditivity" if collision_accounting else "unexplained","next_questions":["freeze geometry-diverse additivity holdout"],"status":"MECHANISM_CANDIDATE"})
    question({"question_id":"C11Q_EQ_MECH","parent_question_id":"C11Q_EQ_A","front":"EQUILIBRIUM","why_this_question":"Separate equalization from collision reduction","kernel_response_that_triggered_it":f"all reducer trials exact={reducer}","hypotheses_being_separated":["intensive equalization","capped additive coalescence"],"experiment":"s_reg endpoints including cap with matched separated controls","controls":["separate destination same inventory"],"measurement":"output multiplicity and s_reg","result":"one-body capped additive reducer" if reducer else "inconsistent","next_questions":["freeze new orientation/N holdout"],"status":"MECHANISM_CANDIDATE"})
    dialogue({"question":"Which minimal mechanisms explain the level-A phenomena?","experiment":"C11D02 direction, shared-destination, and cap interventions","kernel_response":{"scaffold_direction_causal":scaffold_mechanism,"state_normalization":normalization,"parallel_additive":all(v==0 for v in contrast),"convergent_collision_accounting":collision_accounting,"contact_reducer":reducer},"interpretation":"Inward proposal geometry causes scaffold refill; free state normalizes while transport coordinates persist; path nonadditivity occurs only at a shared destination and is explained by the reducer; contact is capped additive coalescence.","alternatives":["same inventory alone","visual interference","intensive exchange"],"next_question":"Freeze laws and test new sizes, orientations, states and geometries.","confidence":"HIGH in tested domains","evidence_level":"CAUSAL_DISCOVERY_REAL_KERNEL"})
    append_log({"module_id":"C11D02_MECHANISM_REFINEMENT","event":"COMPLETE","result":{"scaffold_direction_causal":scaffold_mechanism,"normalization":normalization,"parallel_additive":all(v==0 for v in contrast),"collision_accounting":collision_accounting,"reducer":reducer}})
    update_state(completed_modules=["C11A00_INITIAL_AUDIT","C11D01_PHENOMENON_SCREENS","C11D02_MECHANISM_REFINEMENT"],last_completed_experiment="C11D02_MECHANISM_REFINEMENT",provisional=["TASK_RELATIVE_MATTER_IDENTITY","EXACT_FREE_TRANSPORT_WITH_STATE_NORMALIZATION","DESTINATION_FIBER_REDUCER","APERTURE_ADDITIVITY","CONTACT_COALESCENCE"],next_action="Freeze C11H01-C11H04 claim contracts")
    print({k:result[k] for k in ("module_id","status","scaffold_direction_causal","state_normalization_relation","parallel_additive","convergent_collision_accounting","contact_reducer_relation","wall_clock_seconds")})


if __name__=="__main__": main()
