from __future__ import annotations
import argparse, sys, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, dialogue, question, update_state, verify_and_load_kernel
from core11_apparatus import morph_scaffold_trial


def main():
    p=argparse.ArgumentParser(); p.add_argument("--threads",type=int,default=1); args=p.parse_args(); t=time.perf_counter(); kernel,ident=verify_and_load_kernel(args.threads)
    trials={
        "semantic4_full":morph_scaffold_trial(kernel,19,2,args.threads,"zero",4,()),
        "semantic1_full":morph_scaffold_trial(kernel,19,2,args.threads,"zero",1,()),
        "semantic4_missing1":morph_scaffold_trial(kernel,19,2,args.threads,"zero",4,(0,)),
        "semantic4_missing2":morph_scaffold_trial(kernel,19,2,args.threads,"zero",4,(0,7)),
        "semantic0_full":morph_scaffold_trial(kernel,19,2,args.threads,"zero",0,()),
    }
    rates={k:v["functional_recovery_rate"] for k,v in trials.items()}
    result={"module_id":"C11D03_SCAFFOLD_MECHANISM","status":"COMPLETE","trials":trials,"recovery_rates":rates,"full_semantic4_sufficient":rates["semantic4_full"]==1.0,"semantic_ablation_blocks_repeated_recovery":rates["semantic1_full"]<1.0 and rates["semantic0_full"]<1.0,"missing_corner_blocks":rates["semantic4_missing1"]==0.0 and rates["semantic4_missing2"]==0.0,"missing_corner_effect":{"one":rates["semantic4_missing1"],"two":rates["semantic4_missing2"]},"adjudication":"repeated stable center reinstantiation requires the complete semantic-4 neighborhood in this scaffold; a full semantic-0/1 inventory gives one transient center record then collapses; direction is irrelevant to center genesis but changes global support dynamics","kernel_identity":ident,"wall_clock_seconds":time.perf_counter()-t}
    atomic_json(ROOT/"RESULTS"/"C11D03_scaffold_mechanism.json",result)
    question({"question_id":"C11Q_MATTER_MECH2","parent_question_id":"C11Q_MATTER_MECH","front":"MATTER","why_this_question":"Direction intervention failed to block center genesis; locate the causal guard","kernel_response_that_triggered_it":f"rates={rates}","hypotheses_being_separated":["semantic-4 neighborhood guard","inventory-only genesis","direction-mediated genesis"],"experiment":"semantic ablation and incomplete-neighborhood controls","controls":["semantic1","semantic0","one/two missing corners","same geometry where applicable"],"measurement":"recovery rate and support","result":result["adjudication"],"next_questions":["freeze exact domain, including negative controls"],"status":"MECHANISM_CANDIDATE"})
    dialogue({"question":"What causes repeated center reinstantiation?","experiment":"C11D03 semantic and neighbor-completeness intervention","kernel_response":rates,"interpretation":result["adjudication"],"alternatives":["direction","raw inventory without semantic guard"],"next_question":"Test the frozen guard/scaffold relation at unseen N and translations.","confidence":"HIGH in tested scaffold family","evidence_level":"CAUSAL_DISCOVERY_REAL_KERNEL"})
    append_log({"module_id":"C11D03_SCAFFOLD_MECHANISM","event":"COMPLETE","result":{"rates":rates,"adjudication":result["adjudication"]}})
    update_state(completed_modules=["C11A00_INITIAL_AUDIT","C11D01_PHENOMENON_SCREENS","C11D02_MECHANISM_REFINEMENT","C11D03_SCAFFOLD_MECHANISM"],last_completed_experiment="C11D03_SCAFFOLD_MECHANISM",next_action="Freeze C11H01-C11H04 claim contracts")
    print({"rates":rates,"adjudication":result["adjudication"]})


if __name__=="__main__":main()
