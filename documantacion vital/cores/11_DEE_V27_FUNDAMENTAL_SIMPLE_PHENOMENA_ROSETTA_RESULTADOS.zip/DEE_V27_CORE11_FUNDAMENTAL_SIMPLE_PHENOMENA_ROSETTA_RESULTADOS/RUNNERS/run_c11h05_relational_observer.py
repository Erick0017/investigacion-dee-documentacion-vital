from __future__ import annotations
import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, dialogue, question, sha256_file, update_state, verify_and_load_kernel
from core11_apparatus import aperture_world, collision_trial, morph_scaffold_trial, singleton_trial


def main():
    p=argparse.ArgumentParser();p.add_argument("--threads",type=int,default=1);a=p.parse_args();kernel,ident=verify_and_load_kernel(a.threads);t=time.perf_counter()
    lp=ROOT/"HOLDOUT_LOCKS"/"C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER.json";h=sha256_file(lp);expected=lp.with_suffix(".sha256").read_text().split()[0]
    if h!=expected:raise RuntimeError("lock changed")
    lock=json.loads(lp.read_text(encoding="utf-8")); prm=lock["parameters"]
    s=prm["singleton"]; singleton=singleton_trial(kernel,s["n"],tuple(s["start"]),tuple(s["direction"]),s["ticks"],s["state"],s["sreg"],1,a.threads); single_ok=singleton["trajectory_exact"] and singleton["transport_invariants_preserved"] and singleton["state_normalizes_to_one_after_first_tick"]
    c=prm["collision"]; collision=collision_trial(kernel,c["n"],tuple(c["target"]),c["incoming"],1,a.threads); expected_dir=[0,1,0]; collision_ok=len(collision["post"])==1 and collision["target_record"]["direction"]==expected_dir and collision["target_record"]["sreg"]==143
    ap={**prm["aperture"],"frame":tuple(prm["aperture"]["frame"]),"slit_centers":tuple(prm["aperture"]["slit_centers"])}; worlds={m:aperture_world(kernel,mode=m,threads=a.threads,**ap) for m in ("CLOSED","A","B","AB")};contrast=[ab-aa-bb+cc for ab,aa,bb,cc in zip(worlds["AB"]["arrival_vector"],worlds["A"]["arrival_vector"],worlds["B"]["arrival_vector"],worlds["CLOSED"]["arrival_vector"])]; aperture_ok=all(v==0 for v in contrast) and worlds["AB"]["arrival_count"]==worlds["A"]["arrival_count"]+worlds["B"]["arrival_count"]
    sc=prm["scaffold"]; full=morph_scaffold_trial(kernel,sc["n"],sc["cycles"],a.threads,"zero",4,(),sc["center"]); missing=morph_scaffold_trial(kernel,sc["n"],sc["cycles"],a.threads,"zero",4,(5,),sc["center"]); scaffold_ok=full["functional_recovery_rate"]==1 and missing["functional_recovery_rate"]==0
    passed=single_ok and collision_ok and aperture_ok and scaffold_ok
    result={"claim_id":lock["claim_id"],"status":"PASS" if passed else "FAIL","lock_sha256":h,"observer":lock["observer"],"singleton":{"result":singleton,"relation_exact":single_ok},"collision":{"result":collision,"expected_direction":expected_dir,"relation_exact":collision_ok},"aperture":{"worlds":worlds,"contrast":contrast,"relation_exact":aperture_ok},"scaffold":{"full":full,"missing_corner":missing,"relation_exact":scaffold_ok},"adjudication":"BOUNDED_CROSS_PHENOMENON_RELATIONAL_OBSERVER_CONFIRMED" if passed else "RELATIONAL_OBSERVER_FAILED","scope":"event outcomes in four declared apparatus families; not global Markov closure","kernel_identity":ident,"wall_clock_seconds":time.perf_counter()-t}
    atomic_json(ROOT/"RESULTS"/"C11H05_relational_observer_holdout.json",result)
    question({"question_id":"C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER","parent_question_id":None,"front":"DIMENSIONAL_OBSERVER","why_this_question":"A common destination-fiber/guard mechanism survived four earlier holdouts","kernel_response_that_triggered_it":result["status"],"hypotheses_being_separated":["bounded cross-domain sufficiency","full-Q0 required for every task"],"experiment":"new four-family holdout","controls":["missing corner","closed/single apertures","unique/shared fibers"],"measurement":"exact task outcomes","result":result["adjudication"],"next_questions":["quantify task-relative dimension and Rosetta readiness"],"status":"CONFIRMED" if passed else "FAILED"})
    dialogue({"question":"Does one neutral relational grammar predict multiple simple phenomena?","experiment":"C11H05 frozen cross-phenomenon holdout","kernel_response":{"status":result["status"],"components":{"singleton":single_ok,"collision":collision_ok,"aperture":aperture_ok,"scaffold":scaffold_ok}},"interpretation":result["adjudication"],"alternatives":["support count only","full raw state identity","geometry-only without multiplicity/guard"],"next_question":"Assess minimum observers and whether the fingerprint identifies any external physics.","confidence":"HIGH within bounded tasks","evidence_level":"FROZEN_CROSS_DOMAIN_INTERNAL_HOLDOUT"})
    append_log({"module_id":"C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER","event":"COMPLETE","result":{"status":result["status"],"adjudication":result["adjudication"]}})
    state=json.loads((ROOT/"STATE.json").read_text(encoding="utf-8")); completed=state.get("completed_modules",[])+["C11L02_H05_LOCK","C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER"]
    update_state(completed_modules=completed,pending_holdout=[],last_completed_experiment="C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER",proven=state.get("proven",[])+(["BOUNDED_CROSS_PHENOMENON_RELATIONAL_OBSERVER"] if passed else []),next_action="Synthesize observers, dimension, fingerprint, Rosetta gate and final package")
    print({"status":result["status"],"components":{"singleton":single_ok,"collision":collision_ok,"aperture":aperture_ok,"scaffold":scaffold_ok}})

if __name__=="__main__":main()
