from __future__ import annotations
import argparse,json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT,append_log,atomic_json,dialogue,question,sha256_file,update_state,verify_and_load_kernel
from core11_apparatus import collision_trial,morph_scaffold_trial,singleton_trial


def rec_at(track,t): return track[t]["records"][0]


def main():
    pa=argparse.ArgumentParser();pa.add_argument("--threads",type=int,default=1);a=pa.parse_args();kernel,ident=verify_and_load_kernel(a.threads);t=time.perf_counter();lp=ROOT/"HOLDOUT_LOCKS"/"C11H06_MINIMAL_OBSERVER_WITHIN_TESTED_FAMILY.json";h=sha256_file(lp)
    if h!=lp.with_suffix(".sha256").read_text().split()[0]:raise RuntimeError("lock changed")
    lock=json.loads(lp.read_text(encoding="utf-8"));p=lock["parameters"];start=tuple(p["start"])
    dx=singleton_trial(kernel,p["n_singleton"],start,tuple(p["directions"][0]),p["ticks"],p["states"][0],61,1,a.threads);dy=singleton_trial(kernel,p["n_singleton"],start,tuple(p["directions"][1]),p["ticks"],p["states"][0],61,1,a.threads)
    support_pair={"same_subobserver_at_t0":len(dx["track"][0]["records"])==len(dy["track"][0]["records"]),"future_positions_differ":rec_at(dx["track"],1)["coordinate"]!=rec_at(dy["track"],1)["coordinate"]}
    position_pair={"same_position_at_t0":rec_at(dx["track"],0)["coordinate"]==rec_at(dy["track"],0)["coordinate"],"future_positions_differ":rec_at(dx["track"],1)["coordinate"]!=rec_at(dy["track"],1)["coordinate"]}
    s1=singleton_trial(kernel,p["n_singleton"],start,(1,0,1),1,p["states"][0],211,1,a.threads);s2=singleton_trial(kernel,p["n_singleton"],start,(1,0,1),1,p["states"][1],211,1,a.threads);state_pair={"initial_raw_differs":rec_at(s1["track"],0)["raw"]!=rec_at(s2["track"],0)["raw"],"post_tick_raw_equal":rec_at(s1["track"],1)["raw"]==rec_at(s2["track"],1)["raw"],"post_tick_clock_equal":rec_at(s1["track"],1)["clock"]==rec_at(s2["track"],1)["clock"]}
    cols=[]
    for dirs in p["collision_pairs"]:
        incoming=[{"state":1,"sreg":p["sreg"][0],"direction":dirs[0],"semantic":1},{"state":1,"sreg":p["sreg"][1],"direction":dirs[1],"semantic":1}];cols.append(collision_trial(kernel,p["n_collision"],tuple(p["target"]),incoming,1,a.threads))
    direction_pair={"same_destination_multiplicity_and_sreg":len(cols[0]["incoming"])==len(cols[1]["incoming"]) and sum(x["sreg"] for x in cols[0]["incoming"])==sum(x["sreg"] for x in cols[1]["incoming"]),"output_direction_differs":cols[0]["target_record"]["direction"]!=cols[1]["target_record"]["direction"]}
    sc4=morph_scaffold_trial(kernel,p["n_scaffold"],p["cycles"],a.threads,"zero",4,(),p["center"]);sc1=morph_scaffold_trial(kernel,p["n_scaffold"],p["cycles"],a.threads,"zero",1,(),p["center"]);semantic_pair={"same_geometry_direction_inventory_count":sc4["corner_count"]==sc1["corner_count"],"different_repeated_future":sc4["functional_recovery_rate"]!=sc1["functional_recovery_rate"],"rates":[sc4["functional_recovery_rate"],sc1["functional_recovery_rate"]]}
    checks=[support_pair["same_subobserver_at_t0"] and support_pair["future_positions_differ"],position_pair["same_position_at_t0"] and position_pair["future_positions_differ"],state_pair["initial_raw_differs"] and state_pair["post_tick_raw_equal"] and state_pair["post_tick_clock_equal"],direction_pair["same_destination_multiplicity_and_sreg"] and direction_pair["output_direction_differs"],semantic_pair["same_geometry_direction_inventory_count"] and semantic_pair["different_repeated_future"]];passed=all(checks)
    result={"claim_id":lock["claim_id"],"status":"PASS" if passed else "FAIL","lock_sha256":h,"support_only_witness":support_pair,"position_only_witness":position_pair,"raw_state_redundancy_witness":state_pair,"incoming_direction_necessity_witness":direction_pair,"semantic_necessity_witness":semantic_pair,"adjudication":"M_REL_SMALLEST_SUFFICIENT_AMONG_TESTED_SUBOBSERVER_FAMILY" if passed else "MINIMALITY_NOT_ESTABLISHED","limit":"not an exhaustive proof over all possible encodings; task-relative to CORE11 simple phenomena","kernel_identity":ident,"wall_clock_seconds":time.perf_counter()-t};atomic_json(ROOT/"RESULTS"/"C11H06_minimal_observer_holdout.json",result)
    question({"question_id":lock["claim_id"],"parent_question_id":"C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER","front":"DIMENSIONAL_OBSERVER","why_this_question":"Cross-domain sufficiency passed but minimality required decisive nulls","kernel_response_that_triggered_it":result["status"],"hypotheses_being_separated":["strict subobserver sufficiency","M_rel tested-family minimality"],"experiment":"five frozen matched equivalence witnesses","controls":["all other fields matched"],"measurement":"observer equivalence and next outcome","result":result["adjudication"],"next_questions":["synthesize D_substrate/D_effective/D_observer/D_information"],"status":"CONFIRMED" if passed else "FAILED"})
    dialogue({"question":"Can M_rel be simplified further within the tested observer family?","experiment":"C11H06 matched future-divergence holdout","kernel_response":{"status":result["status"],"checks":checks},"interpretation":result["adjudication"],"alternatives":["support only","position only","raw state necessary","direction-free fibers","semantic-free geometry"],"next_question":"Determine external identifiability of the composite fingerprint.","confidence":"HIGH for tested subobservers","evidence_level":"FROZEN_INTERNAL_HOLDOUT"})
    append_log({"module_id":"C11H06_MINIMAL_OBSERVER","event":"COMPLETE","result":{"status":result["status"],"checks":checks}});state=json.loads((ROOT/"STATE.json").read_text());update_state(completed_modules=state.get("completed_modules",[])+["C11L03_H06_LOCK","C11H06_MINIMAL_OBSERVER"],pending_holdout=[],last_completed_experiment="C11H06_MINIMAL_OBSERVER",next_action="Synthesize laws, dimensional observer, Rosetta gate and final package");print({"status":result["status"],"checks":checks})
if __name__=="__main__":main()
