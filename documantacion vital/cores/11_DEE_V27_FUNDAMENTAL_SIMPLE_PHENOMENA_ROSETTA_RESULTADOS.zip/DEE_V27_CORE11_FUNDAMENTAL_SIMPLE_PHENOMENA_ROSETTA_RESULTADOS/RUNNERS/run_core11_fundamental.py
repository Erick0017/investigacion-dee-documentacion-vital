"""Single idempotent/resumable CORE11 entrypoint."""
from __future__ import annotations
import argparse,subprocess,sys
from pathlib import Path

HERE=Path(__file__).resolve().parent;ROOT=HERE.parent
PY=sys.executable
STAGES=[
 ("RESULTS/C11A00_initial_audit.json","initialize_core11.py"),
 ("RESULTS/C11D01_phenomenon_screens_summary.json","run_c11d01_screens.py"),
 ("RESULTS/C11D02_mechanism_refinement.json","run_c11d02_mechanism_refinement.py"),
 ("RESULTS/C11D03_scaffold_mechanism.json","run_c11d03_scaffold_mechanism.py"),
 ("RESULTS/C11L01_holdout_locks.json","freeze_core11_holdouts.py"),
 ("RESULTS/C11H00_holdout_summary.json","run_core11_holdouts.py"),
 ("RESULTS/C11L02_h05_lock.json","freeze_c11h05_relational_observer.py"),
 ("RESULTS/C11H05_relational_observer_holdout.json","run_c11h05_relational_observer.py"),
 ("RESULTS/C11L03_h06_lock.json","freeze_c11h06_minimal_observer.py"),
 ("RESULTS/C11H06_minimal_observer_holdout.json","run_c11h06_minimal_observer.py"),
 ("RESULTS/C11A03_rosetta_gate.json","analyze_core11.py"),
 ("FINAL_FRONTIER.md","write_core11_reports.py"),
]

def main():
    p=argparse.ArgumentParser();p.add_argument("--threads",type=int,default=1);p.add_argument("--no-finalize",action="store_true");a=p.parse_args()
    for marker,script in STAGES:
        path=ROOT/marker
        if path.exists(): print(f"SKIP COMPLETE {script}");continue
        cmd=[PY,"-I","-B",str(HERE/script)]
        if script.startswith(("initialize_","run_c11","run_core11_holdouts")):cmd += ["--threads",str(a.threads)]
        print("RUN",script);subprocess.run(cmd,cwd=ROOT,check=True)
    if not a.no_finalize:
        final=HERE/"finalize_core11.py"
        if final.exists():subprocess.run([PY,"-I","-B",str(final)],cwd=ROOT,check=True)
    print("CORE11 master COMPLETE")
if __name__=="__main__":main()
