from __future__ import annotations
import argparse, json, math, sys, time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT, append_log, atomic_json, dialogue, question, sha256_file, update_state, verify_and_load_kernel
from core11_apparatus import aperture_world, collision_trial, contact_trial, convergent_two_path, morph_scaffold_trial, singleton_trial


def load_lock(claim):
    p=ROOT/"HOLDOUT_LOCKS"/f"{claim}.json"; expected=(p.with_suffix(".sha256").read_text(encoding="utf-8").split()[0]); observed=sha256_file(p)
    if expected!=observed: raise RuntimeError(f"lock mutation {claim}")
    return json.loads(p.read_text(encoding="utf-8")),observed


def sign_sum(a,b): return [0 if a[i]+b[i]==0 else (1 if a[i]+b[i]>0 else -1) for i in range(3)]


def main():
    p=argparse.ArgumentParser(); p.add_argument("--threads",type=int,default=1); args=p.parse_args(); kernel,ident=verify_and_load_kernel(args.threads); all_results={}
    # H01
    lock,h=load_lock("C11H01_MATTER_IDENTITY"); t=time.perf_counter(); carriers=[]
    for s in lock["parameters"]["carrier_trials"]: carriers.append(singleton_trial(kernel,s["n"],tuple(s["start"]),tuple(s["direction"]),s["ticks"],s["state"],s["sreg"],1,args.threads))
    scaffolds=[]
    for s in lock["parameters"]["scaffolds"]:
        full=morph_scaffold_trial(kernel,s["n"],4,args.threads,"zero",4,(),s["center"]); sem1=morph_scaffold_trial(kernel,s["n"],4,args.threads,"zero",1,(),s["center"]); missing=morph_scaffold_trial(kernel,s["n"],4,args.threads,"zero",4,(0,),s["center"]); scaffolds.append({"spec":s,"full":full,"semantic1":sem1,"missing_corner":missing})
    h01_pass=all(x["trajectory_exact"] and x["transport_invariants_preserved"] and x["state_normalizes_to_one_after_first_tick"] and x["support_persistent"] for x in carriers) and all(x["full"]["functional_recovery_rate"]==1 and all(r["pre_support"]==r["post_support"] for r in x["full"]["cycle_rows"]) and x["semantic1"]["functional_recovery_rate"]<1 and x["missing_corner"]["functional_recovery_rate"]==0 for x in scaffolds)
    r={"claim_id":"C11H01_MATTER_IDENTITY","status":"PASS" if h01_pass else "FAIL","lock_sha256":h,"carrier_trials":carriers,"scaffolds":scaffolds,"wall_clock_seconds":time.perf_counter()-t}; atomic_json(ROOT/"RESULTS"/"C11H01_matter_identity_holdout.json",r); all_results[r["claim_id"]]=r["status"]
    # H02
    lock,h=load_lock("C11H02_PROPAGATION_INTERFACE"); t=time.perf_counter(); free=[]
    for s in lock["parameters"]["free"]: free.append(singleton_trial(kernel,s["n"],tuple(s["start"]),tuple(s["direction"]),s["ticks"],s["state"],s["sreg"],1,args.threads))
    collisions=[]
    for i,s in enumerate(lock["parameters"]["collisions"]):
        target=(s["n"]//2,)*3; inc=[{"state":0x100+i,"sreg":s["sreg"][0],"direction":s["incoming"][0],"semantic":1},{"state":0x200+i,"sreg":s["sreg"][1],"direction":s["incoming"][1],"semantic":1}]
        trial=collision_trial(kernel,s["n"],target,inc,1,args.threads); pred_dir=sign_sum(*s["incoming"]); ok=len(trial["post"])==1 and trial["target_record"] is not None and trial["target_record"]["direction"]==pred_dir and trial["target_record"]["sreg"]==min(sum(s["sreg"]),19664); collisions.append({"spec":s,"trial":trial,"predicted_direction":pred_dir,"relation_exact":ok})
    h02_pass=all(x["trajectory_exact"] and x["transport_invariants_preserved"] and x["state_normalizes_to_one_after_first_tick"] for x in free) and all(x["relation_exact"] for x in collisions)
    r={"claim_id":"C11H02_PROPAGATION_INTERFACE","status":"PASS" if h02_pass else "FAIL","lock_sha256":h,"free_trials":free,"collision_trials":collisions,"wall_clock_seconds":time.perf_counter()-t}; atomic_json(ROOT/"RESULTS"/"C11H02_propagation_interface_holdout.json",r); all_results[r["claim_id"]]=r["status"]
    # H03
    lock,h=load_lock("C11H03_TWO_APERTURE"); t=time.perf_counter(); cases=[]
    for s in lock["parameters"]["cases"]:
        kw={**s,"frame":tuple(s["frame"]),"slit_centers":tuple(s["slit_centers"])}; worlds={m:aperture_world(kernel,mode=m,threads=args.threads,**kw) for m in ("NO_BARRIER","CLOSED","A","B","AB")}; contrast=[ab-a-b+c for ab,a,b,c in zip(worlds["AB"]["arrival_vector"],worlds["A"]["arrival_vector"],worlds["B"]["arrival_vector"],worlds["CLOSED"]["arrival_vector"])]; ok=worlds["CLOSED"]["arrival_count"]==0 and all(v==0 for v in contrast) and worlds["AB"]["arrival_count"]==worlds["A"]["arrival_count"]+worlds["B"]["arrival_count"]
        cases.append({"spec":s,"worlds":worlds,"contrast":contrast,"contrast_l1":sum(abs(v) for v in contrast),"relation_exact":ok})
    cv={m:convergent_two_path(kernel,23,m,args.threads) for m in ("CLOSED","A","B","AB")}; cv_ok=cv["AB"]["support"]==1 and cv["A"]["support"]==1 and cv["B"]["support"]==1 and cv["AB"]["target_record"]["sreg"]==cv["A"]["target_record"]["sreg"]+cv["B"]["target_record"]["sreg"]
    h03_pass=all(x["relation_exact"] for x in cases) and cv_ok
    r={"claim_id":"C11H03_TWO_APERTURE","status":"PASS" if h03_pass else "FAIL","adjudication":"NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APERTURE_APPARATUS" if h03_pass else "FROZEN_ADDITIVITY_HYPOTHESIS_FAILED","lock_sha256":h,"parallel_cases":cases,"convergent_control":cv,"convergent_control_exact":cv_ok,"wall_clock_seconds":time.perf_counter()-t}; atomic_json(ROOT/"RESULTS"/"C11H03_two_aperture_holdout.json",r); all_results[r["claim_id"]]=r["status"]
    # H04
    lock,h=load_lock("C11H04_CONTACT_EQUILIBRIUM"); t=time.perf_counter(); trials=[]
    for s in lock["parameters"]["trials"]:
        shared=contact_trial(kernel,s["a"],s["b"],s["n"],True,tuple(s["frame"]),args.threads); separate=contact_trial(kernel,s["a"],s["b"],s["n"],False,tuple(s["frame"]),args.threads); ok=shared["support_after"]==1 and shared["target_a"] is not None and shared["target_a"]["sreg"]==min(s["a"]+s["b"],19664) and shared["target_a"]["direction"]==[0,0,0] and separate["support_after"]==2; trials.append({"spec":s,"shared":shared,"separated":separate,"relation_exact":ok})
    h04_pass=all(x["relation_exact"] for x in trials)
    r={"claim_id":"C11H04_CONTACT_EQUILIBRIUM","status":"PASS" if h04_pass else "FAIL","adjudication":"CAPPED_ADDITIVE_COALESCENCE; NO_INTENSIVE_EQUALIZATION_IN_TESTED_CLASS" if h04_pass else "FROZEN_COALESCENCE_HYPOTHESIS_FAILED","lock_sha256":h,"trials":trials,"theta_candidate":False,"zeroth_law_opened":False,"landauer_opened":False,"wall_clock_seconds":time.perf_counter()-t}; atomic_json(ROOT/"RESULTS"/"C11H04_contact_equilibrium_holdout.json",r); all_results[r["claim_id"]]=r["status"]
    summary={"module_id":"C11H00_CORE11_HOLDOUTS","status":"COMPLETE","claims":all_results,"all_pass":all(v=="PASS" for v in all_results.values()),"kernel_identity":ident}; atomic_json(ROOT/"RESULTS"/"C11H00_holdout_summary.json",summary)
    for claim,status in all_results.items():
        question({"question_id":claim,"parent_question_id":None,"front":"HOLDOUT","why_this_question":"Prospective promotion test","kernel_response_that_triggered_it":status,"hypotheses_being_separated":["frozen relation","declared nulls"],"experiment":claim,"controls":["as frozen in lock"],"measurement":"as frozen in lock","result":status,"next_questions":["promote bounded claim and synthesize observer/fingerprint" if status=="PASS" else "preserve fail"],"status":"CONFIRMED" if status=="PASS" else "FAILED"})
    dialogue({"question":"Do the four frozen simple-phenomenon relations generalize to unused worlds?","experiment":"C11H01-H04 one-shot holdouts","kernel_response":all_results,"interpretation":"Promote only PASS relations within the preregistered apparatus domains.","alternatives":["post-hoc tuning","visual analogy","uncontrolled geometry"],"next_question":"Derive minimal observers and test composite Rosetta readiness.","confidence":"HIGH","evidence_level":"FROZEN_INTERNAL_HOLDOUT"})
    append_log({"module_id":"C11H00_CORE11_HOLDOUTS","event":"COMPLETE","result":summary})
    update_state(completed_modules=["C11A00_INITIAL_AUDIT","C11D01_PHENOMENON_SCREENS","C11D02_MECHANISM_REFINEMENT","C11D03_SCAFFOLD_MECHANISM","C11L01_HOLDOUT_LOCKS","C11H00_CORE11_HOLDOUTS"],last_completed_experiment="C11H00_CORE11_HOLDOUTS",pending_holdout=[],holdout_results=all_results,next_action="Observer sufficiency, dimensional analysis, composite fingerprint and Rosetta gate")
    print(summary)

if __name__=="__main__":main()
