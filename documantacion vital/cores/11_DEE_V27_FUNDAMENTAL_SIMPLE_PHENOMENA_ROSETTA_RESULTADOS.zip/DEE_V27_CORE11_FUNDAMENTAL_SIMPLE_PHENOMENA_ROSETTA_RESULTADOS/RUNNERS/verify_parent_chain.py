from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core11_common import ROOT, sha256_file

chain = json.loads((ROOT / "PARENT_CHAIN.json").read_text(encoding="utf-8"))
for row in chain["parents"]:
    observed = sha256_file(Path(row["path"]))
    if observed != row["expected_sha256"]: raise SystemExit(f"FAIL {row['core_id']} {observed}")
    print(f"PASS {row['core_id']} {observed}")
