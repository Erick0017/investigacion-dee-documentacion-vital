from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core11_common import ROOT,append_log,atomic_text,update_state,utc_now


def write(name,text): atomic_text(ROOT/name,text.strip()+"\n")


def main():
    write("EXECUTIVE_VERDICT.md",r'''# CORE11 — veredicto ejecutivo

CORE11 alcanzó cierre científico con seis contratos congelados aprobados. Un `PASS` confirma exactamente la relación preregistrada; en `C11H03` esa relación es un negativo de interferencia, no evidencia cuántica.

- **Materia operacional:** `MATTER_LIKE_OPERATIONAL_CLASS_FOUND`, acotado. Un carrier conserva soporte, ruta, `s_reg` y semántica aunque su `state` arbitrario normaliza a 1 tras el primer tick. Un scaffold semantic-4 completo reinstancia su centro tras 4/4 daños en dos nuevos tamaños; controles semantic-1 o con esquina ausente no sostienen esa recuperación.
- **Propagación:** ley exacta `r(t)=r0+t·d mod N`, con velocidad `L_inf=1`, sin spread ni atenuación de `s_reg` en el sector libre probado. Una fibra compartida de dos entradas móviles produce un solo registro con `s_reg_out=min(sum s_reg,19664)` y dirección `sign(sum d)`.
- **Dos aperturas:** `NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APERTURE_APPARATUS`. En cinco geometrías totales, incluyendo tres holdouts, `AB=A+B-closed` exactamente. El control convergente sí fue no aditivo en occupancy, pero quedó explicado por el reductor de destino y su contabilidad exacta de `s_reg`.
- **Equilibrio:** `NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS`. El contacto fusiona dos registros; no deja dos sistemas que igualen una variable intensiva. El modelo de suma saturada tuvo MAE 0; un promedio tuvo MAE 6422.75. No se abrió principio cero ni Landauer.
- **Observador:** `M_rel` —soporte activo, propuestas, multiplicidad de destino, dirección/`s_reg`/semántica y guarda local— predijo las cuatro familias en holdout. Fue el observador suficiente más pequeño entre los subobservadores ensayados, no un cierre global de DEE.
- **Dimensionalidad:** existen representaciones menores relativas a tarea (ruta 1D, detector transversal, fibra local), pero no una reducción dimensional global.
- **Rosetta:** máximo `NEUTRAL_STRUCTURAL_MATCH`. Hay similitud formal con transporte balístico, caminos geométricos independientes y coalescencia, pero no un mapa físico identificador ni predicción externa reservada.

La ley unificadora nativa es una gramática de propuesta dirigida → fibra de destino → reductor/guarda → lectura. Explica persistencia, transporte, aperturas, colisión y reinstanciación local sin convertir ninguna analogía en física externa.''')

    write("FINAL_REPORT.md",r'''# CORE11 — informe final

## Pregunta y método

CORE11 preguntó si fenómenos simples aparecen en DEE antes de recibir nombres físicos. Se verificaron byte por byte CORE01–10 y el kernel v27. Discovery usó aparatos pequeños; cada promoción creó un lock SHA-256 antes de abrir mundos nuevos. La unidad independiente fue el mundo/preparación, no cada tick.

Un primer screen contenía dos errores de lectura: exigía conservar un `state` que el kernel normaliza y filtraba llegadas por el valor inicial de ese `state`. Los artefactos `*_v0_*` conservan el error. La corrección fue label-blind y se efectuó antes de cualquier lock; ningún holdout fue reparado.

## Resultados confirmados

`C11H01` confirmó dos clases de identidad operacional: carrier localizado con trayectoria exacta y scaffold distribuido con recuperación repetida. Identidad funcional no equivale a igualdad de `raw`.

`C11H02` confirmó el sector libre y el evento de interfaz de dos propuestas móviles. El movimiento usa una métrica operacional `L_inf`; las diagonales no autorizan una identificación con velocidad física.

`C11H03` confirmó aditividad exacta de dos canales paralelos. Los conteos de discovery fueron 1+1=2 y 3+3=6. En tres geometrías holdout el contraste espacial completo fue cero. Una convergencia a destino común redujo dos registros a uno, demostrando que no aditividad de occupancy no implica interferencia.

`C11H04` confirmó coalescencia saturada en contacto y dos registros en el control separado. Al desaparecer la pareja no existe el protocolo mínimo para una temperatura intensiva.

`C11H05` confirmó que `M_rel` predice las cuatro familias en nuevos tamaños, orientación y traslación. `C11H06` falsó cinco simplificaciones: support-only, position-only, necesidad del `raw` inicial, fibra sin dirección y geometría sin semántica.

## Mecanismo

La explicación mínima común no es una etiqueta clásica. Los registros activos proponen destinos; propuestas coincidentes forman fibras; multiplicidad, dirección, `s_reg` y semántica alimentan el reductor; guardas locales pueden crear un registro; un observador lee sólo la respuesta requerida. Esta gramática explica simultáneamente cinco fenómenos, pero no demuestra un estado reducido Markoviano global.

## Rosetta

La comparación se abrió sólo después del freeze interno. El transporte es formalmente balístico, la pantalla de aperturas coincide con caminos independientes y el contacto recuerda una agregación inelástica. Ninguna correspondencia fija una preparación física, unidades y dos observables externos independientes. No se buscaron datasets por nombre. El estado final es `NEUTRAL_STRUCTURAL_MATCH`, sin `EXTERNAL_PREDICTION`.

## Cierre

Todos los frentes recibieron screen, mecanismo y adjudicación. Los negativos quedan acotados al aparato: no se afirma que DEE carezca universalmente de modos colectivos interferentes o de termodinámica; se afirma que no aparecieron en las clases razonables y congeladas de CORE11.''')

    write("TRANSVERSAL_CORE01_TO_11.md",r'''# Síntesis transversal CORE01–11

| Core | Avance heredado, en su dominio |
|---|---|
| 01 | Estado exacto `raw+clock`, transporte singleton, fuentes, colisiones y cotas causales. |
| 02 | Separación estado/evento, roles causales y fibras predictivas. |
| 03 | Organización de basin Q2 y predictor multiescala acotado. |
| 04 | Histories productivas Q3, sectores múltiples y ausencia de Q4 global. |
| 05 | Grafo de propuestas, fibras, observador interno, medición y retardo-a-lugar. |
| 06 | Plasticidad/asociación, generalización acotada, materia operacional, cinemática; Bell local en aparato probado. |
| 07 | Atlas ejecutable, cross-feeding y cierre causal relativo a tareas. |
| 08 | Observadores neutrales; reparación/autonomía clasificadas; ninguna reducción global de frontera. |
| 09 | A6 acotado, memoria resiliente y búsqueda Rosetta externa con fail preservado. |
| 10 | Coupling bidireccional, reinstanciación funcional causal, homeostasis conjunta fija y observador funcional acotado. |
| 11 | Gramática relacional única confirmada sobre materia-like, transporte, aperturas, colisión y refill; Rosetta simple permanece no identificada. |

CORE11 no introduce Q4. Convierte varias leyes sectoriales heredadas en una compresión transversal: `proposal → destination fiber → guarded reducer → response`. El nuevo resultado es su validación cruzada prospectiva y la delimitación de lo que esa gramática no genera en los aparatos simples.''')

    write("CORE11_NEW_DISCOVERIES.md",r'''# Nuevos descubrimientos CORE11

1. `state` arbitrario no pertenece a la identidad libre persistente: converge a 1 en el primer tick mientras ruta, `s_reg`, semántica y soporte se conservan.
2. La recuperación estable del centro no depende de la dirección de los ocho corners. Requiere en este motif el vecindario completo semantic-4. semantic-0/1 produce sólo un centro transitorio y después colapsa; una esquina ausente bloquea la respuesta.
3. Dos aperturas paralelas son exactamente aditivas en cinco geometrías. Una configuración convergente es no aditiva en occupancy, pero la no aditividad se localiza en la fibra compartida y conserva la suma saturada de `s_reg`.
4. El contacto de portadores estudiado no es intercambio: es coalescencia. Esto falsifica el aparato como termómetro antes de invocar nombres termodinámicos.
5. `M_rel` unifica cuatro familias y supera cinco subobservadores estrictos en holdout. Es un cierre relativo a tarea y el principal hallazgo integrador de CORE11.''')

    write("FUNDAMENTAL_MATTER.md",r'''# Materia operacional

## Definición y clases

Una clase merece tratamiento `matter-like` interno si mantiene identidad operacional, es localizable/detectable, interactúa y ofrece respuesta reproducible. CORE11 confirma dos realizaciones diferentes:

- carrier localizado: una instancia persistente que se traslada por un orbit dirigido;
- scaffold distribuido: una relación de ocho soportes semantic-4 capaz de reinstanciar repetidamente un centro.

## Identidad

La microidentidad falla: cambiar el `state` inicial deja registros distintos en `t0`, pero ambos son idénticos tras una actualización si los demás campos coinciden. La identidad funcional del carrier requiere posición, dirección, `s_reg`, semántica y clase de estado post-normalización. Para el scaffold requiere la relación completa semantic-4 y el readout central.

## Causalidad y límites

El inventario por sí solo no explica recuperación sostenida. semantic-0/1 colapsa tras una génesis transitoria, y eliminar una esquina bloquea el centro. No se derivaron masa, inercia, exclusión universal ni equivalencia con materia externa. Veredicto: `MATTER_LIKE_OPERATIONAL_CLASS_FOUND`, no `MATTER = DEE_RECORD`.''')

    write("PROPAGATION_AND_MEDIUM.md",r'''# Propagación y medio

En la región operacional sin otra organización activa, el carrier cumple

`r(t) = r0 + t d (mod N)`

para componentes de `d` en `{-1,0,1}` probadas. Su desplazamiento por tick es uno en `L_inf`; el primer arribo a distancia dirigida `L` ocurre en `L` ticks. Soporte, `s_reg`, dirección y semántica no se atenúan ni se dispersan. El `state` inicial normaliza a 1 tras el primer tick.

Una interfaz no es un medio pasivo: cuando dos propuestas móviles comparten destino, emerge un registro con

`s_reg_out = min(s_reg_A + s_reg_B, 19664)`

`d_out = sign(d_A + d_B)`

en el sector semantic-1 de dos entradas probado. Oposición captura (`d_out=0`); una dirección transversal deflecta. Un ocupante estacionario en el destino mostró aniquilación en discovery y queda como límite de dominio, no absorbido en la ley de entradas móviles.

No se identifican estas unidades con metros/segundos ni con luz física.''')

    write("TWO_APERTURE_EXPERIMENT.md",r'''# Experimento de dos aperturas

## Aparato

Una familia de carriers viajó hacia una barrera. Carriers opuestos ocuparon las posiciones cerradas y cancelaron el paso; los offsets omitidos constituyeron aperturas A y B. El detector fue label-blind respecto del `state` inicial y leyó presencia, tiempo, dirección y `s_reg`.

## Mundos comparados

`NO_BARRIER`, `CLOSED`, `A`, `B`, `AB` se ejecutaron con el mismo source. En discovery: `A=1, B=1, AB=2` y `A=3, B=3, AB=6`. Tres geometrías nuevas cambiaron N, orientación, distancias, separación y ancho.

## Resultado congelado

En todos los bins y mundos holdout:

`D_AB - D_A - D_B + D_CLOSED = 0`.

No hubo máximos, mínimos ni redistribución entre canales. Un control de dos rutas convergentes dio un solo record en lugar de dos, pero `s_reg_AB=s_reg_A+s_reg_B`; es el reductor de fibra, no un patrón espacial.

Veredicto: `TWO_PATH_GEOMETRIC_PATTERN` y `NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APERTURE_APPARATUS`. No se afirma ausencia universal de otro modo colectivo.''')

    write("INTERFERENCE_SCALING.md",r'''# Scaling de interferencia

No se promovió una ley de franjas porque no apareció señal de interferencia. El contraste no lineal fue exactamente cero al variar prospectivamente:

- N: 29–41 en holdout cruzado;
- orientación de los ejes;
- separación y ancho de apertura;
- distancia source–barrier y barrier–detector.

Por tanto no existen datos válidos para ajustar espaciado de nodos, fase, longitud de onda o envelope. Ajustarlos habría sido pareidolia. La única ley de escala disponible es geométrica: el número de llegadas `AB` es la suma de los anchos efectivos de A y B dentro del rango probado.''')

    write("EQUILIBRIUM_AND_TEMPERATURE_CANDIDATE.md",r'''# Equilibrio y candidata de temperatura

Dos carriers con distintos `s_reg` se prepararon con destino común o destinos separados. En contacto común el resultado fue siempre un solo registro estacionario con suma saturada. Separados permanecieron dos registros.

El modelo `min(a+b,19664)` tuvo MAE 0. El promedio `(a+b)/2`, una caricatura de igualación, tuvo MAE 6422.75. Como el contacto elimina la distinción A/B, no existe un estado final de dos sistemas sobre el que evaluar una variable intensiva común.

Veredicto: `NO_INTENSIVE_EQUALIZATION_IN_TESTED_COLLISION_CLASS`. No se construyó `Theta_DEE`; por ello el principio cero, fluctuaciones térmicas y Landauer quedaron `NOT_JUSTIFIED_TO_TEST`. Este negativo no cubre ensembles source-supported o sectores colectivos no probados.''')

    write("DIMENSIONAL_OBSERVER.md",r'''# Observador dimensional

| Fenómeno | Sustrato | Estado/observador suficiente en la tarea | Límite |
|---|---:|---|---|
| Carrier | 3D | orbit dirigido 1D + payload funcional | sólo sector libre |
| Scaffold | 3D | grafo local semantic-4 de ocho corners + centro | dimensión relacional, no coordenada |
| Propagación | 3D | ruta, first-passage y payload | no predice interacción no declarada |
| Aperturas | 3D | línea transversal del detector + geometría source/aperturas | el detector solo no cierra la dinámica |
| Contacto | 3D | tupla de fibra compartida e inputs | probado para k=2 semantic-1 |

`M_rel` es menor que el bulk `N³` porque descarta celdas inactivas y `state` pre-normalización. Cinco witnesses muestran que support-only, position-only, fibra sin dirección o geometría sin semántica no bastan. Aun así, no se ha probado una representación lower-dimensional global. Veredicto: `LOWER_DIMENSIONAL_TASK_RELATIVE_OBSERVERS_FOUND`.''')

    write("FUNDAMENTAL_ROSETTA.md",r'''# Rosetta fundamental

## Procedimiento

Las huellas se congelaron antes de cualquier nombre externo. Se evaluaron relaciones, no vocabulario.

## Ranking

1. Carrier persistente y transporte balístico: `FORMAL_SIMILARITY`. La ecuación discreta es exacta, pero calibrar voxel/tick no predice una constante física.
2. Dos aperturas: `NEUTRAL_STRUCTURAL_MATCH` con caminos geométricos independientes. Es una correspondencia negativa respecto de interferencia ondulatoria/cuántica.
3. Fibra compartida: `FORMAL_SIMILARITY` con coalescencia. `s_reg` y dirección carecen de interpretación física congelada.
4. Scaffold: `FORMAL_SIMILARITY` con reinstanciación local; sin preparación material externa.
5. Equilibrio: `NOT_READY`; no apareció variable intensiva.

## Gate

La gramática `proposal → fiber → reducer/guard` usa el mismo mapa interno para varias familias, pero ningún protocolo físico externo conocido queda identificado por todas sus relaciones con pocos parámetros. No existe observable externo reservado. Abrir un dataset por nombres habría violado el cortafuegos de pareidolia.

Estado máximo: `NEUTRAL_STRUCTURAL_MATCH`. `EXTERNAL_PREDICTION=false`, `ROSETTA_VALIDATED=false`.''')

    write("NEGATIVE_RESULTS.md",r'''# Resultados negativos y límites

- No apareció contraste no aditivo en la pantalla paralela de dos aperturas. Esto no excluye modos colectivos no usados.
- La no aditividad convergente fue reducción de multiplicidad, no evidencia de fase u onda.
- No apareció variable intensiva que se iguale; el contacto fusionó los participantes.
- No se justificaron principio cero ni Landauer.
- No se obtuvo masa, energía, temperatura, fotón ni identidad cuántica.
- No se demostró una reducción dimensional global.
- Ninguna correspondencia produjo predicción externa.
- El `state` inicial no es carga transportada estable en el sector libre: se normaliza a 1.
- La dirección no causa la génesis del centro del scaffold; sólo cambia la dinámica global. La primera explicación quedó falsada.
- Un detector que filtraba el `state` inicial perdió todas las llegadas; fue un error de readout conservado como artefacto supersedido antes de locks.''')

    write("ADVERSARIAL_REVIEW.md",r'''# Revisión adversarial

- **¿Se eligió el observer mirando holdout?** No. `M_rel` se derivó de discovery y se congeló en C11H05; C11H06 congeló subobservadores antes de los pares nuevos.
- **¿Se reparó un FAIL?** No hubo FAIL holdout. Se corrigieron dos bugs discovery antes de locks y se conservaron los resultados v0.
- **¿El detector contenía labels?** No. La corrección explícita eliminó el filtro por `state` inicial.
- **¿Una imagen bonita se llamó interferencia?** No. Se usó contraste bin-a-bin y resultó cero.
- **¿La convergencia no aditiva prueba onda?** No. El reductor predice occupancy y `s_reg` exactamente.
- **¿`s_reg` fue llamado temperatura/energía?** No. El contacto no cumple el protocolo de igualación.
- **¿Se confundió identidad con raw?** No. La normalización matched demuestra que raw distingue microestados funcionalmente equivalentes.
- **¿Se sobrepromovió dimensionalidad?** No. Sólo se afirman observadores menores relativos a tarea.
- **¿La Rosetta se escogió por nombre?** No se abrió búsqueda externa porque el fingerprint no cruzó el gate identificador.
- **¿Ticks fueron pseudorreplicados?** No. Las leyes deterministas se evaluaron por mundo/preparación y dominio; los ticks son trayectoria, no réplicas estadísticas.

Conclusión: los positivos internos sobreviven; las interpretaciones físicas permanecen deliberadamente por debajo de validación.''')

    write("FINAL_FRONTIER.md",r'''# Frontera final CORE11

## Cerrado en el dominio probado

- identidad funcional de carrier y scaffold;
- transporte libre y reductor de dos propuestas móviles;
- aditividad de aperturas paralelas;
- coalescencia de contacto;
- suficiencia/minimalidad relativa de `M_rel` entre candidatos ensayados.

## Requiere mecanismo nuevo

- un modo colectivo con fase y patrón interferente;
- contacto entre ensembles que preserve dos subsistemas y permita igualdad intensiva;
- observador reducido global, no sólo relativo a tarea;
- preparación física para `s_reg`, semántica o fibra.

## Requiere datos externos después de una huella identificadora

- validación física de transporte/interface;
- una Rosetta material multiobservable;
- predicción externa no usada en calibración.

CORE11 no reserva artificialmente CORE12. Estas fronteras no se resuelven repitiendo el aparato ni cambiando umbrales; requieren una clase nativa nueva o un protocolo externo que mida la huella completa.''')
    append_log({"module_id":"C11R01_REPORTS","event":"COMPLETE","documents":15})
    state=json.loads((ROOT/"STATE.json").read_text());update_state(completed_modules=state.get("completed_modules",[])+["C11R01_REPORTS"],next_action="Build manifest, hashes, compact official ZIP and update expediente")
    print("CORE11 reports COMPLETE")

if __name__=="__main__":main()
