# Síntesis transversal CORE01–11

| Core | Avance heredado, en su dominio |
|---|---|
| 01 | Estado exacto `raw+clock`, transporte singleton, fuentes, colisiones y cotas causales. |
| 02 | Separación estado/evento, roles causales y fibras predictivas. |
| 03 | Organización de basin Q2 y predictor multiescala acotado. |
| 04 | Histories productivas Q3, sectores múltiples y ausencia de Q4 global. |
| 05 | Grafo de propuestas, fibras, observador interno, medición y retardo-a-lugar. |
| 06 | Plasticidad/asociación, generalización acotada, materia operacional, cinemática; Bell local en aparato probado. |
| 07 | Atlas ejecutable, cross-feeding y cierre causal relativo a tareas. |
| 08 | Observadores neutrales; reparación/autonomía clasificadas; ninguna reducción global de frontera. |
| 09 | A6 acotado, memoria resiliente y búsqueda Rosetta externa con fail preservado. |
| 10 | Coupling bidireccional, reinstanciación funcional causal, homeostasis conjunta fija y observador funcional acotado. |
| 11 | Gramática relacional única confirmada sobre materia-like, transporte, aperturas, colisión y refill; Rosetta simple permanece no identificada. |

CORE11 no introduce Q4. Convierte varias leyes sectoriales heredadas en una compresión transversal: `proposal → destination fiber → guarded reducer → response`. El nuevo resultado es su validación cruzada prospectiva y la delimitación de lo que esa gramática no genera en los aparatos simples.
