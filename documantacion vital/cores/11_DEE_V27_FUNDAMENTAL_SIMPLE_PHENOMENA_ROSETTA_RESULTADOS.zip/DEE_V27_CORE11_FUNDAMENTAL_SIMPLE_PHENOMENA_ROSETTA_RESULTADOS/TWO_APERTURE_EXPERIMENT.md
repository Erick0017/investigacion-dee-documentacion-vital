# Experimento de dos aperturas

## Aparato

Una familia de carriers viajó hacia una barrera. Carriers opuestos ocuparon las posiciones cerradas y cancelaron el paso; los offsets omitidos constituyeron aperturas A y B. El detector fue label-blind respecto del `state` inicial y leyó presencia, tiempo, dirección y `s_reg`.

## Mundos comparados

`NO_BARRIER`, `CLOSED`, `A`, `B`, `AB` se ejecutaron con el mismo source. En discovery: `A=1, B=1, AB=2` y `A=3, B=3, AB=6`. Tres geometrías nuevas cambiaron N, orientación, distancias, separación y ancho.

## Resultado congelado

En todos los bins y mundos holdout:

`D_AB - D_A - D_B + D_CLOSED = 0`.

No hubo máximos, mínimos ni redistribución entre canales. Un control de dos rutas convergentes dio un solo record en lugar de dos, pero `s_reg_AB=s_reg_A+s_reg_B`; es el reductor de fibra, no un patrón espacial.

Veredicto: `TWO_PATH_GEOMETRIC_PATTERN` y `NO_INTERFERENCE_LIKE_SIGNAL_IN_TESTED_PARALLEL_APERTURE_APPARATUS`. No se afirma ausencia universal de otro modo colectivo.
