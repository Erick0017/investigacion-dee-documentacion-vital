# Adversarial review

- **Kernel drift:** none in all completed audits.
- **Post-hoc holdout tuning:** none; four locks were hashed before execution.
- **Readout artifact:** binary occupancy did hide phase sensitivity. The interpretation was invalidated; the frozen neutral record includes time, s_reg and direction.
- **Interference pareidolia:** rejected. Occupancy exclusion and destination reduction explain the full signal.
- **Interface as mere inventory:** rejected by semantic-1 equal-inventory and spatially shuffled semantic-4 controls.
- **Full scaffold narrative:** corrected. Seven corners already worked; exhaustive masks yielded the exact threshold.
- **Clock mechanism:** falsified causally (0/3 restoration); target occupancy passed (3/3).
- **Equilibrium overclaim:** avoided. Driven sources were not labeled closed equilibrium and guard restoration was not called equalization.
- **External match by name:** no external matching was attempted because the gate failed.
- **Scope inflation:** all claims are sector- and task-relative.

All final textual claims have true machine predicates in `CLAIM_LEDGER.json`.
