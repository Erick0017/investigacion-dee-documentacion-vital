# CORE12 new discoveries

1. **Transported native phase:** a one-bit arrival parity survives direction, translation, N, distance and s_reg nuisance in 4/4 locked worlds.
2. **Phase-sensitive recombination without fringes:** coherent arrivals reduce together; one-tick offset invokes target-occupancy exclusion. The neutral detector record changes even when binary occupancy does not.
3. **Exact semantic-4 local threshold:** retain iff at least six of eight corner relations exist; create iff all eight exist. Holdout: 1,536/1,536.
4. **Guarded sustained capture:** the thresholded organization removes every tested downstream train event; k=5 and equal-inventory controls transmit. Holdout: 4/4.

These are new internal laws. None is an external Rosetta validation.
