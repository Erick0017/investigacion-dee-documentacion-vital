# Dimensional observer

| Task | Sufficient observer in tested sector | Insufficient observer |
|---|---|---|
| phase transport | source class, route distance and parity bit; detector history | snapshot occupancy without time |
| two paths | `(tick,s_reg,direction)` at destination plus current target occupancy | binary detector occupancy |
| guard | initial-center bit plus semantic-4 corner count k | global inventory |
| interface | guard state plus downstream detector history | same-size shuffled support |

`D_substrate=3`. Effective transport is one-dimensional along a route; guard dynamics is a finite local relation. Information needed by these frozen predictors is O(1) per local update. No area law, boundary code or holographic conclusion follows.
