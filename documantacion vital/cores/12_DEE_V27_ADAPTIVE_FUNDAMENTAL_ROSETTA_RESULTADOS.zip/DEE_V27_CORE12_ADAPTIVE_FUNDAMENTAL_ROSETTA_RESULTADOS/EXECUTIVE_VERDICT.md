# CORE12 — Executive verdict

## Primary decision

`ROSETTA_INTERNAL_LAW_FOUND`

CORE12 found and froze four reproducible laws under the unchanged v27 kernel. All four holdouts passed: phase transport 4/4, two-path phase/history response 4/4, the local guard predicate 1,536/1,536 outcomes, and the guarded interface 4/4.

The principal discovery is not physical interference. A persistent semantic-4 source emits a source-supported period-two train. A preparation-time obstruction shifts its arrival parity by one tick. When two equal paths meet, phase decides whether arrivals are simultaneous and reduced (`s_reg=a+b`) or sequential, in which case current target occupancy excludes the delayed path. Removing that occupant at the preregistered tick restores the delayed record in 3/3 causal diagnostics; resetting only its clock restores 0/3.

The second discovery is an exact local organization law: among eight semantic-4 corner relations, an existing center is retained iff `k≥6`; an absent center is created iff `k=8`. Coupling this guard to the period-two train yields sustained capture. A `k=5` arrangement, semantic-1 equal inventory, shifted semantic-4 inventory and empty controls transmit.

No `Theta_DEE`, bounded zeroth law, fringe scaling, wave-law match, low-parameter external Rosetta, unused external prediction or external validation was obtained. The two-path signal is fully explained by DEE's reducer/exclusion rules. External search therefore did not pass its gate.

No CORE13 is created or automatically recommended. A further internal experiment would require a concretely new mechanism: a distributed phase-bearing mode that can split and recombine without target exclusion, or a closed persistent ensemble with an exchangeable macro coordinate.
