# External validation protocol status

`NOT_ACTIVATED`.

No CORE12 fingerprint reached R2, so choosing an external phenomenon or dataset would be name-driven. Before external validation can begin, a future internal fingerprint must add at least one independent observable—such as prospective fringe-spacing scaling, a transmission/reflection pair under angle, or closed relaxation with a transitive intensive coordinate. Only then freeze preparation map, dimensionless translation, calibration, standard-model/null competition and unused external holdout.
