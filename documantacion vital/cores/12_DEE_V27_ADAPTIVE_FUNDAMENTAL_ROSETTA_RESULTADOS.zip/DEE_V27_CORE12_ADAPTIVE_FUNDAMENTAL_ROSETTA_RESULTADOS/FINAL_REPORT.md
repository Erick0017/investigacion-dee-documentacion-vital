# CORE12 final report

## Scope and integrity

CORE12 used CORE01–11 as a scientific corpus and did not repeat CORE11's singleton transport, singleton aperture additivity, carrier coalescence or M_rel results. CORE11 was verified at `c8b591c5eb4e90a5de947da992337434be98802c024c860991ba8d967d9fb885`. Wheel, package and `.pyd` identities were checked before science, after discovery and before/after holdouts; the final check is part of packaging. F_DEE was never modified.

## Adaptive interrogation

The direct v27 candidate outranked historical T2/T3/T4 labels: semantic-4 sources had an existing period-two propagation witness, and an initial mouth obstruction had an existing phase-memory witness. Three new geometries established that the phase reaches a detector. That prerequisite opened a two-path test.

Binary detector occupancy initially hid the effect and produced an invalid provisional interpretation. The preserved structured records showed that coherent worlds delivered `s_reg=312`, whereas phase-shifted worlds delivered only the `s_reg=101` A record. Isolated shifted B still arrived one tick later. Sparse traces localized the loss at the occupied target. A selective clock reset failed (0/3); selective occupant removal restored B (3/3). The final interpretation is therefore phase-conditioned destination reduction/exclusion, not a spatial fringe.

An interface discovery likewise began with an overbroad “full scaffold” label. The seven-corner arm behaved identically, so CORE12 preserved that interpretation as invalid and exhaustively tested all `2^8` masks. Exactly 37 masks retain a center: all 28 six-corner masks, all eight seven-corner masks and the full mask. Only the full eight-corner mask creates a missing center.

## Frozen results

| Claim | Lock | Result |
|---|---|---|
| Period-two phase transport | `d6597657f14f2b28d9912564d841bdb90531766e7a96a1230e171cb127271655` | PASS 4/4 |
| Phase/history two-path detector law | `9ccdbe2e0b624f8e463d6a23ad56c414058df9c8f33447328bca2eb5e92b34ba` | PASS 4/4 |
| Semantic-4 guard threshold | `a6dba46827c19bfdd120bc093b4a0d9546dc08d45f8990b7eccecbb83b21fafa` | PASS 1536/1536 |
| Guarded sustained-capture interface | `c6fb5f786532dde01c65dec6ad889aa91a4d8a86332d3cd5b83dc66d78b893d3` | PASS 4/4 |

## Ensemble branch

Three causally distinct classes used the full budget. Static semantic-1 arrays did not satisfy persistence; joint semantic-4 scaffolds exhibited guard restoration rather than macro exchange; facing source trains retained distinct sources but were driven steady states. No primary scalar both predicted flux and tended to equality while A/B survived. `Theta_DEE`, zeroth-law and Landauer gates remained closed.

## Observer and dimensional result

The phase route needs only source class, direction, distance and one parity bit plus detector history. The two-path law needs the destination record `(time,s_reg,direction)` and one-step target occupancy; occupancy alone is insufficient. The interface law needs center occupancy and the scalar count `k` over eight specific relations. These are task-relative finite observers embedded in a 3D substrate—not evidence for lower-dimensional ontology.

## Rosetta gate

All promoted laws reached R1 internally. None reached R2: the aperture response has no spatial maxima/minima/envelope law and is exactly explained by the native reducer; the interface response is a discrete semantic threshold with no independently predicted external observable. No internet search or dataset fitting was scientifically justified.

## Decision

`ROSETTA_INTERNAL_LAW_FOUND`. The result is meaningful internal progress, not an external physical identification.
