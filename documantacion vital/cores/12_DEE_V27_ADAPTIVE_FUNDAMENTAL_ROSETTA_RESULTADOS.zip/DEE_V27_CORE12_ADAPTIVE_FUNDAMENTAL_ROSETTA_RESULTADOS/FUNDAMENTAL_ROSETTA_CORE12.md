# Fundamental Rosetta CORE12

CORE12 earned internal laws but not an external Rosetta. The richest neutral fingerprint is:

`persistent source → parity-bearing train → path geometry → target occupancy/destination fiber → reduction or exclusion → detector record`, composed with `semantic-4 neighbor count → retained interface → sustained capture`.

This fingerprint has multiple internal relations and falsifiers, but its observed outputs are already fixed by the native discrete mechanism. It offers no unused external observable with which to distinguish a physical law from generic pulsed transport plus exclusion. Accordingly no external dataset was opened and no units were calibrated.

Primary state: `ROSETTA_INTERNAL_LAW_FOUND`. External maximum: R1 only.
