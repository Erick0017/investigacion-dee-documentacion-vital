# Matter + propagation + interface

An existing center surrounded by at least six of eight zero-direction semantic-4 corner records is retained at every update in this sector. Against a period-two incident train, the center remains present and no event reaches the detector seven cells downstream. With five corners, with eight semantic-4 records shifted out of the guard geometry, with semantic-1 equal inventory, or with no interface, the train reaches downstream at its original cadence.

The result is organization-specific rather than inventory-specific. The exact local guard provides mechanism; the sustained absence downstream supplies the interface response. Frozen holdout: 4/4.

Observed functions: capture/occlusion. Not observed: reflected record, angular deflection, refraction-like law, phase shift through the interface or conversion mode.
