# Negative results

- `C12N01` — **SIMPLER_MECHANISM_EXPLAINS_SIGNAL**: nonadditive and phase-sensitive detector record is fully explained by destination reduction plus target occupancy exclusion; no spatial fringe/scaling law Scope: semantic-4 period-two source trains in tested convergent apparatus.
- `C12N02` — **APPARATUS_PREREQUISITE_MISMATCH**: nominal static semantic-1 arrays did not persist as two ensembles Scope: closed static preparation.
- `C12N03` — **SIMPLER_MECHANISM_EXPLAINS_SIGNAL**: joint center restoration follows semantic/topological guard, not exchange/equalization of a macro coordinate Scope: joint scaffold.
- `C12N04` — **APPARATUS_PREREQUISITE_MISMATCH**: facing source trains remain driven; source coordinates do not relax Scope: driven steady state.
- `C12N05` — **MECHANISM_CLASS_NULL**: no candidate after three causally distinct classes; zeroth law and Landauer gates not opened Scope: CORE12 mechanism budget, not global.
- `C12N06` — **MECHANISM_CLASS_NULL**: selective clock reset did not restore B; clock alone is not sufficient Scope: tested path geometry.
- `C12N07` — **INSUFFICIENT_INFORMATION**: confirmed internal laws lack a nontrivial second external observable and are explained by discrete reducer/guard rules Scope: CORE12 fingerprints.

The two pre-lock technical incidents and two invalid provisional interpretations are preserved in `INCIDENTS/`; none changes a holdout.
