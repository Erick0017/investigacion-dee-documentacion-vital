# Persistent ensemble search

Three mechanism classes exhausted the preregistered budget:

1. Closed static semantic-1 arrays: failed persistence prerequisite (`APPARATUS_PREREQUISITE_MISMATCH`).
2. Closed joint semantic-4 scaffold: persisted and restored centers, but the response was an exact local guard effect, not exchange/equalization (`SIMPLER_MECHANISM_EXPLAINS_SIGNAL`).
3. Facing semantic-4 source trains: sources persisted and produced interface events, but were driven steady states and retained source coordinates (`APPARATUS_PREREQUISITE_MISMATCH` for equilibrium).

Closure: `NOT_FOUND_WITHIN_CORE12_MECHANISM_BUDGET`.
