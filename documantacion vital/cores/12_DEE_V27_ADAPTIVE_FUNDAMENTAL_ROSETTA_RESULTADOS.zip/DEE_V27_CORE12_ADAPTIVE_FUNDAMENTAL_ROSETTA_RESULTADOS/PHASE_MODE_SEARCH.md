# Phase mode search

Mechanism class 1 was the v27 semantic-4 period-two source train. It passed the prerequisite immediately, so the conditional historical attractor class was not opened. The mode is `SOURCE_SUPPORTED` and evolves `NATIVE_AFTER_T0`; it is not a closed autonomous oscillator. Rigid translated packets remain the inherited mechanism-class null: their Fourier phase is translation bookkeeping and had shown no new path interaction.

Witness discovery: 3/3. Frozen holdout: 4/4.
