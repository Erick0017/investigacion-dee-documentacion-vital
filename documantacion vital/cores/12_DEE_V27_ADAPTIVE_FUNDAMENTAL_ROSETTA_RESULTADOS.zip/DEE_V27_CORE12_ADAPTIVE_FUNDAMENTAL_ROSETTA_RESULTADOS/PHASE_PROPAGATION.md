# Phase propagation

For detector distance `L`, baseline and off-path-sham events occur at `t=L+2j`. A stationary obstruction placed at the mouth only at preparation changes them to `t=L+1+2j`. The source remains semantic-4 and persistent, and all interarrival gaps remain two.

Operational phase is the parity class `phi=(t-L) mod 2`. It is a history coordinate of source emission, not a fitted sine or externally synthesized waveform. Scope is the pre-toroidal-return source-train sector.
