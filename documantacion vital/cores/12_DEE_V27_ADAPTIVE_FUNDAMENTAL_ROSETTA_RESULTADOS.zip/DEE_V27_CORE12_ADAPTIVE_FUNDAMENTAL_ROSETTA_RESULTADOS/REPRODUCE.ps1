$ErrorActionPreference = 'Stop'
$Python = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
& $Python -I -B '.\RUNNERS\run_core12_adaptive_fundamental_rosetta.py'
