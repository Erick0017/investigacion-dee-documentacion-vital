# Rosetta ladder

| Fingerprint | Highest level | Why it stops |
|---|---|---|
| parity transport | R1 internal scaling law | cadence comes from source rule; no independent external observable |
| phase-conditioned paths | R1 internal law | reducer/exclusion fully explains signal; no fringes |
| 6/8–8/8 guard | R1 exact sector law | semantic discrete threshold lacks external measurement map |
| guarded capture | R1 internal interface law | no transmission/reflection angular family or second external relation |

R2 formal external match, R3 low-parameter candidate, R4 shared map, R5 unused prediction and R6 external holdout were not reached.
