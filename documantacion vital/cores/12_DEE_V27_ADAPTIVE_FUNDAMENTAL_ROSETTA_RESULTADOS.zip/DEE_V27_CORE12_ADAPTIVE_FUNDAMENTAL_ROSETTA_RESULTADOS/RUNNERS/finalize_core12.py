"""Final adversarial validation, compact packaging, and expediente publication."""
from __future__ import annotations
import json,os,shutil,sys,time,zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import EXPECTED,PARENT_HASHES,ROOT,TESTS,append_log,atomic_json,atomic_text,kernel_hashes,sha256_file,update_budget,update_kernel_audit,update_state,utc_now

ZIP_NAME="12_DEE_V27_ADAPTIVE_FUNDAMENTAL_ROSETTA_RESULTADOS.zip"
PACKAGE_ROOT="DEE_V27_CORE12_ADAPTIVE_FUNDAMENTAL_ROSETTA_RESULTADOS"
REQUIRED_DOCS=["EXECUTIVE_VERDICT.md","FINAL_REPORT.md","TRANSVERSAL_CORE01_TO_12.md","CORE12_NEW_DISCOVERIES.md","PHASE_MODE_SEARCH.md","PHASE_PROPAGATION.md","TWO_APERTURE_PHASE_TEST.md","INTERFERENCE_LAW.md","PERSISTENT_ENSEMBLE_SEARCH.md","ENSEMBLE_CONTACT.md","THETA_DEE.md","ZEROTH_LAW_SCREEN.md","MATTER_PROPAGATION_INTERFACE.md","DIMENSIONAL_OBSERVER.md","ROSETTA_LADDER.md","FUNDAMENTAL_ROSETTA_CORE12.md","NEGATIVE_RESULTS.md","ADVERSARIAL_REVIEW.md","FINAL_FRONTIER.md","EXTERNAL_VALIDATION_PROTOCOL.md"]

def package_files():
    roots=REQUIRED_DOCS+["STATE.json","TIME_BUDGET.json","PARENT_CHAIN.json","KERNEL_IMMUTABILITY_AUDIT.json","PRIOR_MECHANISM_MAP.json","QUESTION_TREE.ndjson","KERNEL_DIALOGUE.ndjson","CLAIM_LEDGER.json","NEGATIVE_CLASSIFICATION.json","SCIENCE_LOG.ndjson","REPRODUCE.ps1"]
    files=[ROOT/x for x in roots]
    for directory in ("RESULTS","HOLDOUT_LOCKS","RUNNERS","INCIDENTS","KERNEL"):
        files.extend(p for p in (ROOT/directory).rglob("*") if p.is_file() and not p.name.endswith(".tmp") and "__pycache__" not in p.parts)
    return sorted(set(files),key=lambda p:p.relative_to(ROOT).as_posix())

def update_expediente(official,zip_hash):
    exp=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE"; core=exp/"CORE"; target=core/ZIP_NAME
    tmp=target.with_suffix(target.suffix+".tmp"); shutil.copyfile(official,tmp); os.replace(tmp,target)
    if sha256_file(target)!=zip_hash: raise RuntimeError("official copy is not byte-identical")
    index=exp/"INDICE_EXPEDIENTE.md"; text=index.read_text(encoding="utf-8")
    section=f"""\n### Experimento 12 — búsqueda Rosetta fundamental adaptativa\n\n`{ZIP_NAME}`\n\nConfirma transporte de fase/paridad source-supported, una respuesta de dos caminos sensible a fase pero explicada por reducción/exclusión, el umbral local semantic-4 6/8–8/8 y una interfaz de captura sostenida; cierra sin Theta_DEE, franjas, ajuste externo ni Rosetta física validada.\n\n"""
    if ZIP_NAME not in text:
        marker="\n## EXTRA\n"
        text=text.replace(marker,section+marker) if marker in text else text+section
        atomic_text(index,text)
    lines=[]
    for p in sorted(core.glob("*.zip"),key=lambda x:x.name): lines.append(f"{sha256_file(p)}  CORE/{p.name}")
    extra=exp/"EXTRA"
    if extra.exists():
        for p in sorted(extra.glob("*.zip"),key=lambda x:x.name): lines.append(f"{sha256_file(p)}  EXTRA/{p.name}")
    lines.append(f"{sha256_file(index)}  INDICE_EXPEDIENTE.md")
    atomic_text(exp/"HASHES.sha256","\n".join(lines)+"\n")
    expected_names={f"{i:02d}_" for i in range(1,13)}
    zips=sorted(core.glob("*.zip"))
    if len(zips)!=12 or {p.name[:3] for p in zips}!=expected_names: raise RuntimeError(f"CORE folder not exact 01-12: {[p.name for p in zips]}")
    portable=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE_COMPLETO.zip"
    if portable.exists():
        temp=portable.with_suffix(".zip.tmp")
        with zipfile.ZipFile(temp,"w",allowZip64=True) as z:
            for p in sorted(q for q in exp.rglob("*") if q.is_file()):
                arc=Path(exp.name)/p.relative_to(exp)
                compression=zipfile.ZIP_STORED if p.suffix.lower()==".zip" else zipfile.ZIP_DEFLATED
                z.write(p,arc.as_posix(),compress_type=compression,compresslevel=9 if compression==zipfile.ZIP_DEFLATED else None)
        with zipfile.ZipFile(temp,"r") as z:
            if z.testzip() is not None: raise RuntimeError("portable archive CRC failure")
        os.replace(temp,portable)
    return target,portable if portable.exists() else None,zips

def main():
    started=time.perf_counter(); update_budget("finalize_package",180,"RUN")
    for name in REQUIRED_DOCS:
        if not (ROOT/name).is_file(): raise RuntimeError(f"missing required report: {name}")
    claims=json.loads((ROOT/"CLAIM_LEDGER.json").read_text(encoding="utf-8"))
    if not claims["contradiction_check"]["all_final_claim_predicates_true"]: raise RuntimeError("final claim predicate failure")
    locks=json.loads((ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json").read_text(encoding="utf-8"))["hashes"]
    for cid,h in locks.items():
        if sha256_file(ROOT/"HOLDOUT_LOCKS"/f"{cid}.json")!=h: raise RuntimeError(f"lock mutated: {cid}")
    holdouts={}
    for p in sorted((ROOT/"RESULTS").glob("C12H*.json")):
        data=json.loads(p.read_text(encoding="utf-8")); holdouts[data["claim_id"]]=data["verdict"]
    if set(holdouts.values())!={"PASS"}: raise RuntimeError(f"holdout failure: {holdouts}")
    update_kernel_audit("final")
    audit=json.loads((ROOT/"KERNEL_IMMUTABILITY_AUDIT.json").read_text(encoding="utf-8"))
    if not audit["all_pass"]: raise RuntimeError("kernel audit failed")
    update_budget("complete",0,"COMPLETE")
    budget=json.loads((ROOT/"TIME_BUDGET.json").read_text(encoding="utf-8"))
    if budget["elapsed_seconds"]>budget["hard_wall_seconds"]: raise RuntimeError("hard wall exceeded")
    append_log({"module":"final_adversarial_validation","status":"COMPLETE","holdouts":holdouts,"kernel_immutable":True,"elapsed_seconds":budget["elapsed_seconds"]})
    update_state(status="COMPLETE",primary_decision="ROSETTA_INTERNAL_LAW_FOUND",holdout_verdicts=holdouts,kernel_immutable=True,elapsed_seconds=budget["elapsed_seconds"],next_action="none; bring only official CORE12 ZIP")
    files=package_files(); rows=[{"path":p.relative_to(ROOT).as_posix(),"bytes":p.stat().st_size,"sha256":sha256_file(p)} for p in files]
    manifest={"schema":"DEE_CORE12_MANIFEST_V1","created_utc":utc_now(),"package_root":PACKAGE_ROOT,"official_zip":ZIP_NAME,"parent_embedding":False,"parents":PARENT_HASHES,"kernel_identity":EXPECTED,"primary_decision":"ROSETTA_INTERNAL_LAW_FOUND","holdout_results":holdouts,"negative_scope":"bounded mechanism-class adjudications only","external_rosetta":"NOT_READY_R1_MAXIMUM","files":rows}
    atomic_json(ROOT/"MANIFEST.json",manifest)
    hash_lines=[f"{r['sha256']}  {r['path']}" for r in rows]+[f"{sha256_file(ROOT/'MANIFEST.json')}  MANIFEST.json"]
    atomic_text(ROOT/"HASHES.sha256","\n".join(hash_lines)+"\n")
    archive_files=files+[ROOT/"MANIFEST.json",ROOT/"HASHES.sha256"]
    out=ROOT/"output"/ZIP_NAME; out.parent.mkdir(exist_ok=True); tmp=out.with_suffix(".zip.tmp")
    with zipfile.ZipFile(tmp,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
        for p in archive_files: z.write(p,(Path(PACKAGE_ROOT)/p.relative_to(ROOT)).as_posix())
    with zipfile.ZipFile(tmp,"r") as z:
        if z.testzip() is not None: raise RuntimeError("CORE12 archive CRC failure")
        names=z.namelist()
        if len(names)!=len(archive_files): raise RuntimeError("archive entry count mismatch")
    os.replace(tmp,out); zip_hash=sha256_file(out)
    target,portable,zips=update_expediente(out,zip_hash)
    final={"status":"COMPLETE","zip":str(out),"official_copy":str(target),"sha256":zip_hash,"size_bytes":out.stat().st_size,"byte_identical":sha256_file(target)==zip_hash,"core_zip_count":len(zips),"portable_updated":str(portable) if portable else None,"package_entries":len(archive_files),"elapsed_wall_seconds":time.perf_counter()-started}
    atomic_json(ROOT/"output"/"FINAL_VALIDATION.json",final)
    print(json.dumps(final,indent=2))

if __name__=="__main__":main()
