"""Freeze and hash every promoted CORE12 claim before opening new worlds."""
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,append_log,atomic_json,sha256_file,update_budget,update_kernel_audit,update_state,utc_now

LOCKS={
"C12H01_PHASE_TRANSPORT":{
 "question":"Does a semantic-4 source-supported train carry a parity phase to a distant detector?",
 "domain":"axis-aligned source trains before toroidal return; new N, translation, direction, distance, s_reg",
 "preparation":"one semantic-4 state-zero source; optional one-tick mouth obstruction fixed at t0",
 "observer":"detector semantic-1 event tick sequence plus source persistence",
 "features":["arrival parity","interarrival gap","source semantic"],
 "rule":"baseline and offpath sham arrive at ticks L+2k; mouth block at L+1+2k; all gaps=2; source persists",
 "parameters":{"period":2,"phase_shift_ticks":1},
 "null":"block has no selective phase effect or cadence is not period two",
 "controls":["baseline","mouth_block","offpath_sham"],
 "PASS":"all 4 new cases satisfy the exact rule","FAIL":"any valid case violates it","INCONCLUSIVE":"technical invalidity only","minimum_effect":"4/4 exact","seeds_N":[[61,10],[67,11],[71,12],[73,13]],"falsifier":"one valid offpath-preserving case lacking exact phase shift"
},
"C12H02_PHASE_HISTORY_PATH_RESPONSE":{
 "question":"Does relative emission phase alter the neutral record of two convergent paths by destination reduction/exclusion?",
 "domain":"equal diagonal paths; two period-two sources; pre-return horizon; new N/frame/translation/s_reg",
 "preparation":"A and B coherent or B mouth-blocked at t0; no intervention after t0",
 "observer":"detector event ticks, s_reg and direction; isolated B control",
 "features":["event cadence","s_reg","direction","path contribution"],
 "rule":"coherent detector record has sreg=a+b and sign-summed direction at L+2k; shifted AB has A-only record at L+2k while isolated shifted B reaches at L+1+2k; offpath sham equals coherent",
 "parameters":{"period":2,"phase_offset":1},
 "null":"signature is phase-invariant or isolated B also fails",
 "controls":["A_only","B_only","isolated_B_shifted","closed","offpath_sham"],
 "PASS":"all 4 cases exact","FAIL":"any valid case violates frozen record law","INCONCLUSIVE":"technical invalidity only","minimum_effect":"4/4 exact","seeds_N":[[61,10],[67,11],[71,12],[73,13]],"falsifier":"shifted and coherent detector signatures equal in a valid case"
},
"C12H03_SEMANTIC4_GUARD_THRESHOLD":{
 "question":"What exact local corner predicate retains or creates the center?",
 "domain":"eight Chebyshev corners, zero-direction semantic-4 cells; new N, translations, s_reg/state nuisance",
 "preparation":"all 256 corner masks crossed with center absent/present",
 "observer":"center occupancy one tick later",
 "features":["initial center","semantic-4 corner count"],
 "rule":"present center retained iff k>=6; absent center created iff k=8",
 "parameters":{"retention_threshold":6,"birth_threshold":8},
 "null":"arrangement or nuisance fields change predicate",
 "controls":["all masks","center absent/present","new nuisance values"],
 "PASS":"1536/1536 mask/world outcomes exact","FAIL":"any outcome violates predicate","INCONCLUSIVE":"technical invalidity only","minimum_effect":"100% exact","seeds_N":[17,19,21],"falsifier":"one valid counterexample"
},
"C12H04_GUARDED_INTERFACE_CAPTURE":{
 "question":"Does the semantic-4 local guard create an organization-specific sustained capture interface for a period-two train?",
 "domain":"axis-aligned trains; center initially present; k=5,6,8 corner masks; new N/orientation/translation/s_reg",
 "preparation":"period-two source aimed at center; corner masks fixed before t0",
 "observer":"center persistence and events seven cells downstream",
 "features":["guard count","downstream event ticks","center occupancy"],
 "rule":"k>=6 retains center and yields zero downstream train events; k=5, shuffled semantic-4 and semantic-1 equal-inventory controls transmit like empty",
 "parameters":{"guard_threshold":6,"probe_distance":7},
 "null":"inventory/static blocking alone explains suppression",
 "controls":["k5","semantic4_shuffled","semantic1_same_inventory","empty"],
 "PASS":"all 4 new cases exact","FAIL":"any valid case violates threshold/transmission rule","INCONCLUSIVE":"technical invalidity only","minimum_effect":"4/4 exact","seeds_N":[61,67,71,73],"falsifier":"a k5 control blocks or a k6 interface transmits"
}}

def main():
    update_budget("freeze_holdouts",20,"RUN"); update_kernel_audit("before_holdouts")
    hashes={}
    for claim,payload in LOCKS.items():
        path=ROOT/"HOLDOUT_LOCKS"/f"{claim}.json"
        atomic_json(path,{"claim_id":claim,"frozen_utc":utc_now(),"status":"LOCKED_UNOPENED",**payload})
        hashes[claim]=sha256_file(path)
    atomic_json(ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json",{"created_utc":utc_now(),"hashes":hashes})
    append_log({"module":"holdout_freeze","status":"COMPLETE","lock_hashes":hashes})
    update_state(status="HOLDOUTS_LOCKED",holdout_lock_hashes=hashes,next_action="run untouched holdout worlds once")
    update_budget("run_holdouts",90,"RUN"); print(json.dumps(hashes,indent=2))

if __name__=="__main__":main()
