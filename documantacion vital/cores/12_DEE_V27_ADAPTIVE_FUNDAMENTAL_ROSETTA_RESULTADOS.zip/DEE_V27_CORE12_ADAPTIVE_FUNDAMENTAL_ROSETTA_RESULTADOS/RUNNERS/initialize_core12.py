"""Initialize CORE12 once, verify genealogy and freeze the initial scientific map."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core12_common import (
    EXPECTED, PARENT_HASHES, ROOT, TESTS, append_log, atomic_json, atomic_text,
    sha256_file, update_kernel_audit, utc_now,
)


def find_parents():
    core_dir = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
    rows = []
    files = list(core_dir.glob("*.zip"))
    for core_id, expected in PARENT_HASHES.items():
        matches = [p for p in files if sha256_file(p) == expected]
        if len(matches) != 1:
            raise RuntimeError(f"{core_id}: expected exactly one parent by hash, found {len(matches)}")
        path = matches[0]
        rows.append({"core": core_id, "name": path.name, "path": str(path), "sha256": expected, "size_bytes": path.stat().st_size, "verified": True})
    return rows


def main():
    for name in ("RESULTS", "HOLDOUT_LOCKS", "RUNNERS", "INCIDENTS", "phase", "ensembles", "interfaces", "rosetta", "output"):
        (ROOT / name).mkdir(parents=True, exist_ok=True)
    parents = find_parents()
    atomic_json(ROOT / "PARENT_CHAIN.json", {"created_utc": utc_now(), "authority": "byte-level SHA-256", "parents": parents})
    update_kernel_audit("before_core12")
    now = time.time()
    atomic_json(ROOT / "TIME_BUDGET.json", {
        "start_utc": utc_now(), "start_epoch_utc": now, "hard_wall_seconds": 3600,
        "science_soft_deadline_seconds": 3000, "finalization_reserve_seconds": 600,
        "elapsed_seconds": 0, "remaining_seconds": 3600,
        "estimated_next_module_seconds": 25, "next_module": "phase_discovery", "decision_to_run_or_skip": "RUN",
    })
    atomic_json(ROOT / "PRIOR_MECHANISM_MAP.json", {
        "created_utc": utc_now(),
        "frozen_core11_results_not_repeated": [
            {"claim": "singleton free transport r(t)=r0+t*d mod N; v_Linf=1", "relevance": "ballistic control, not phase mechanism"},
            {"claim": "destination reducer sums capped s_reg and signs summed direction", "relevance": "mandatory simpler alternative for convergent paths"},
            {"claim": "parallel singleton two-aperture apparatus exactly additive", "relevance": "bounded null, not global interference null"},
            {"claim": "two semantic1 carriers at common destination coalesce", "relevance": "apparatus mismatch for intensive equalization"},
            {"claim": "M_rel is bounded task-relative observer", "relevance": "neutral baseline observer"},
        ],
        "ranked_phase_candidates": [
            {"mechanism_class_id": "P12_PHASE_MC1", "family": "semantic4_period2_source_train", "source": "CORE06 C6D09 plus CORE05 NRD02B", "kernel_version": "v27", "shown": "persistent period-two non-dispersive train; one-tick mouth obstruction flips parity", "negative_controls": "free packets and source ablation/matched histories", "current_relevance": "highest; phase-bearing and propagating", "needs_v27_witness": True, "estimated_seconds": 20},
            {"mechanism_class_id": "P12_PHASE_MC2", "family": "rigid_translating_packet", "source": "CORE06 C6D09", "kernel_version": "v27", "shown": "Fourier magnitude invariant; translation phase only", "negative_controls": "9/9 exact translation", "current_relevance": "prior mechanism-class null for path interaction", "needs_v27_witness": False, "estimated_seconds": 0},
            {"mechanism_class_id": "P12_PHASE_MC3", "family": "toroidal_or_historical_periodic_attractor", "source": "historical T2/T3/T4/phase corpus", "kernel_version": "pre-v27 prior", "shown": "periodicity reported, exact phase-propagation suitability not consolidated", "negative_controls": "historical", "current_relevance": "conditional only if MC1 cannot carry phase to detector", "needs_v27_witness": True, "estimated_seconds": 90},
        ],
        "ranked_ensemble_candidates": [
            {"mechanism_class_id": "P12_ENSEMBLE_MC1", "family": "closed_static_persistent_ensembles", "relevance": "survival prerequisite with no exchange"},
            {"mechanism_class_id": "P12_ENSEMBLE_MC2", "family": "closed_semantic4_joint_scaffolds", "relevance": "persistent active guard response across shared interface"},
            {"mechanism_class_id": "P12_ENSEMBLE_MC3", "family": "source_supported_facing_trains", "relevance": "persistent distinct sources with driven interface flux"},
        ],
        "historical_candidates_not_promoted": ["T2", "T3", "T4", "NOISESYNC17X", "PHASESHIFT17X", "OSCILLATORMOD17X", "ATTRACTORROBUST17X", "ANTENNA17X"],
        "reason": "Direct v27 witnesses outrank historical names; historical classes reopen only if a new causal prerequisite demands it.",
    })
    atomic_json(ROOT / "CLAIM_LEDGER.json", {"created_utc": utc_now(), "claims": []})
    atomic_json(ROOT / "NEGATIVE_CLASSIFICATION.json", {"created_utc": utc_now(), "allowed_categories": ["PHENOMENON_NEGATIVE_VALID_APPARATUS", "APPARATUS_PREREQUISITE_MISMATCH", "READOUT_INVALID", "TECHNICAL_INVALID", "SIMPLER_MECHANISM_EXPLAINS_SIGNAL", "MECHANISM_CLASS_NULL", "INSUFFICIENT_INFORMATION", "TIME_BUDGET_LIMITED"], "negatives": []})
    atomic_json(ROOT / "STATE.json", {"core": 12, "status": "INITIALIZED", "current_question": "Can the v27 period-two semantic-4 train transport an operational phase?", "completed_modules": ["initialization", "directed_prior_audit"], "next_action": "run phase prerequisite discovery", "hard_wall_seconds": 3600, "kernel_immutable": True})
    atomic_text(ROOT / "QUESTION_TREE.ndjson", "")
    atomic_text(ROOT / "KERNEL_DIALOGUE.ndjson", "")
    atomic_text(ROOT / "SCIENCE_LOG.ndjson", "")
    append_log({"module": "initialization", "status": "COMPLETE", "parent_count": len(parents), "kernel_hashes": EXPECTED})
    print(json.dumps({"status": "COMPLETE", "parents": len(parents), "kernel": EXPECTED}, indent=2))


if __name__ == "__main__":
    main()
