"""Single resumable CORE12 entrypoint."""
from __future__ import annotations
import subprocess,sys,time
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]; HERE=Path(__file__).resolve().parent
MODULES=[
 ("initialize_core12.py",ROOT/"PARENT_CHAIN.json"),
 ("run_core12_discovery.py",ROOT/"RESULTS"/"C12D04_matter_propagation_interface.json"),
 ("run_core12_mechanism_diagnostics.py",ROOT/"RESULTS"/"C12D06_interface_guard_diagnostic.json"),
 ("run_core12_path_mediation.py",ROOT/"RESULTS"/"C12D07_path_mediation.json"),
 ("run_core12_clock_mediation.py",ROOT/"RESULTS"/"C12D08_clock_mediation.json"),
 ("run_core12_occupancy_mediation.py",ROOT/"RESULTS"/"C12D09_occupancy_mediation.json"),
 ("freeze_core12_holdouts.py",ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json"),
 ("run_core12_holdouts.py",ROOT/"RESULTS"/"C12H04_guarded_interface_holdout.json"),
 ("analyze_core12.py",ROOT/"RESULTS"/"C12A01_machine_synthesis.json"),
 ("write_core12_reports.py",ROOT/"FINAL_REPORT.md"),
 ("finalize_core12.py",ROOT/"output"/"12_DEE_V27_ADAPTIVE_FUNDAMENTAL_ROSETTA_RESULTADOS.zip"),
]

def main():
    for script,marker in MODULES:
        if marker.exists():
            print(f"SKIP COMPLETE {script}")
            continue
        print(f"RUN {script}")
        subprocess.run([sys.executable,"-I","-B",str(HERE/script)],cwd=ROOT,check=True)
    print("CORE12 COMPLETE")

if __name__=="__main__":main()
