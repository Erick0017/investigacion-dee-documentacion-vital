"""Test whether detector clock/history mediates the antiphase path exclusion."""
from __future__ import annotations
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,append_log,atomic_json,dialogue,question,update_budget,update_state,verify_and_load_kernel
from core12_apparatus import convergent_phase_trace

def detector_at(run,tick):
    return next(r["detector"] for r in run["rows"] if r["tick"]==tick)

def main():
    started=time.perf_counter(); update_budget("clock_mediation",30,"RUN"); kernel,env=verify_and_load_kernel(1); cases=[]
    for n,l,frame in [(43,7,(0,1,2)),(47,8,(1,2,0)),(53,9,(2,0,1))]:
        natural=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3)
        reset=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3,reset_center_clock_tick=l)
        sham=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3,reset_offpath_clock_tick=l)
        target=l+1
        cases.append({"n":n,"path_length":l,"frame":list(frame),"target_tick":target,"natural_clock_at_A_arrival":natural["rows"][l]["detector_clock"],"natural_B_record":detector_at(natural,target),"center_clock_reset_B_record":detector_at(reset,target),"offpath_clock_reset_B_record":detector_at(sham,target),"center_reset_restores_B":detector_at(natural,target) is None and detector_at(reset,target) is not None and detector_at(reset,target)["sreg"]==211,"offpath_reset_preserves_exclusion":detector_at(sham,target) is None,"runs":[natural,reset,sham]})
    passed=all(x["center_reset_restores_B"] and x["offpath_reset_preserves_exclusion"] for x in cases)
    result={"schema":"dee.v27.core12.clock_mediation.v1","module":"C12D08_CLOCK_MEDIATION","role":"DISCOVERY_CAUSAL_INTERVENTION","post_t0_python":"FIXED_EXTERNAL_INTERVENTION used only to identify mechanism","environment":env,"question":"Does the detector's clock/history left by A exclude antiphase B one tick later?","machine_predicate":"scheduled center-clock reset after A arrival restores s_reg211 B at next tick; equal-time offpath reset does not","predicate_result":passed,"summary":{"cases":len(cases),"center_reset_restores_cases":sum(x["center_reset_restores_B"] for x in cases),"offpath_sham_preserves_cases":sum(x["offpath_reset_preserves_exclusion"] for x in cases),"mechanism":"DETECTOR_CLOCK_HISTORY_EXCLUSION" if passed else "CLOCK_NOT_SUFFICIENT"},"cases":cases,"wall_seconds":time.perf_counter()-started}
    atomic_json(ROOT/"RESULTS"/"C12D08_clock_mediation.json",result)
    question({"question_id":"C12Q08","parent_question_id":"C12Q07","front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"B diverged exactly one tick after A occupied the detector, suggesting clock/history mediation.","prerequisites":"C12D07 localized divergence at L+1","experiment":"predeclared center-clock reset at tick L versus offpath reset","controls":["natural","offpath reset"],"response":result["summary"],"classification":result["summary"]["mechanism"],"next_question":"freeze natural unedited phase-history exclusion law" if passed else None,"information_gain":"HIGH","time_cost":result["wall_seconds"],"status":"MECHANISM_CANDIDATE" if passed else "CLOSED"})
    dialogue({"question":"What mediates antiphase exclusion?","why":"Divergence occurs at detector one tick after the other path's event.","apparatus":"fixed-time selective reset of detector clock, matched offpath reset","kernel_response":result["summary"],"negative_positive_class":"POSITIVE_CAUSAL" if passed else "MECHANISM_CLASS_NULL","simpler_explanation":"history/clock exclusion rather than amplitude cancellation","next_discriminating_question":"natural holdout without intervention","evidence_level":"DISCOVERY_CAUSAL"})
    append_log({"module":"clock_mediation","status":"COMPLETE","summary":result["summary"],"wall_seconds":result["wall_seconds"]}); update_state(status="READY_TO_FREEZE",last_completed_experiment="C12D08_CLOCK_MEDIATION",next_action="freeze four bounded laws and run untouched worlds"); update_budget("freeze_holdouts",30,"RUN")
    print(json.dumps(result["summary"],indent=2))

if __name__=="__main__": main()
