"""Adaptive discovery: phase prerequisite, path interaction, ensembles, and interface."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core12_common import ROOT, append_log, atomic_json, dialogue, question, update_budget, update_kernel_audit, update_state, utc_now, verify_and_load_kernel
from core12_apparatus import convergent_phase_paths, facing_source_ensembles, joint_scaffold_contact, regenerative_interface_trial, source_train_trial, static_ensemble_contact


def save(name, payload):
    payload["completed_utc"] = utc_now()
    atomic_json(ROOT / "RESULTS" / f"{name}.json", payload)


def main():
    started=time.perf_counter(); update_budget("adaptive_discovery", 120, "RUN")
    kernel,env=verify_and_load_kernel(1)
    # Q1: does the v27 source train expose transported phase?
    phase_trials=[]
    cases=[
        (43,(13,21,21),(1,0,0),7),
        (47,(16,22,24),(0,1,0),8),
        (53,(20,24,27),(0,0,-1),9),
    ]
    for n,source,distance_vec,l in []: pass
    # The tuple naming above is intentional but source directions are declared explicitly below.
    for n,source,d,l in [
        (43,(13,21,21),(1,0,0),7),
        (47,(16,22,24),(0,1,0),8),
        (53,(20,24,27),(0,0,-1),9),
    ]:
        for mode in ("baseline","mouth_block","offpath_sham"):
            phase_trials.append(source_train_trial(kernel,n,source,d,137+n,l+14,l,mode))
    grouped=[]
    for index in range(0,len(phase_trials),3):
        base,block,sham=phase_trials[index:index+3]
        grouped.append({
            "case":index//3,"baseline_ticks":base["arrival_ticks"],"blocked_ticks":block["arrival_ticks"],"sham_ticks":sham["arrival_ticks"],
            "baseline_period2":base["period_two_at_detector"],"blocked_period2":block["period_two_at_detector"],"sham_period2":sham["period_two_at_detector"],
            "block_changes_arrival_parity":bool(base["arrival_ticks"] and block["arrival_ticks"] and base["arrival_ticks"][0]%2 != block["arrival_ticks"][0]%2),
            "sham_preserves_arrival_parity":bool(base["arrival_ticks"] and sham["arrival_ticks"] and base["arrival_ticks"][0]%2 == sham["arrival_ticks"][0]%2),
        })
    phase_pass=all(r["baseline_period2"] and r["blocked_period2"] and r["sham_period2"] and r["block_changes_arrival_parity"] and r["sham_preserves_arrival_parity"] for r in grouped)
    phase_result={"schema":"dee.v27.core12.phase_discovery.v1","module":"C12D01_PHASE_PREREQUISITE","role":"DISCOVERY","environment":env,"mechanism_class_id":"P12_PHASE_MC1","question":"Does the source-supported semantic-4 train transport an operational parity phase to a distant detector?","machine_predicate":"all three translated/oriented cases retain period two; mouth-only obstruction flips detector parity; matched off-path obstruction does not","predicate_result":phase_pass,"summary":{"cases":len(grouped),"passing_cases":sum(r["baseline_period2"] and r["blocked_period2"] and r["sham_period2"] and r["block_changes_arrival_parity"] and r["sham_preserves_arrival_parity"] for r in grouped),"gate_to_two_paths":phase_pass},"case_comparisons":grouped,"trials":phase_trials,"wall_seconds":time.perf_counter()-started}
    save("C12D01_phase_prerequisite",phase_result)
    question({"question_id":"C12Q01","parent_question_id":None,"front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"Direct v27 source train has period two and prior mouth-block phase memory.","prerequisites":"source persists and phase reaches detector","experiment":"three N/orientation/translation cases with baseline, mouth block, off-path sham","controls":["offpath_sham"],"response":phase_result["summary"],"classification":"INTERNAL_PHASE_MODE" if phase_pass else "NOT_SUITABLE_FOR_APERTURE_TEST","next_question":"C12Q02" if phase_pass else "audit mechanism class 3","information_gain":"HIGH","time_cost":phase_result["wall_seconds"],"status":"MECHANISM_CANDIDATE" if phase_pass else "CLOSED"})
    dialogue({"question":"Can a native v27 process carry phase?","why":"Two-path interaction requires a causal coordinate beyond occupancy.","apparatus":"semantic-4 period-two source train; t0 mouth block; matched off-path block","kernel_response":grouped,"negative_positive_class":"POSITIVE" if phase_pass else "APPARATUS_PREREQUISITE_MISMATCH","simpler_explanation":"external clock cue excluded because post-t0 evolution is native and off-path sham preserves parity","next_discriminating_question":"Do equal convergent paths depend on relative phase?" if phase_pass else "test a causally distinct periodic attractor","evidence_level":"DISCOVERY"})

    # Q2: phase-sensitive path interaction. Only open after Q1.
    path_result={"schema":"dee.v27.core12.two_path_discovery.v1","module":"C12D02_PHASE_TWO_PATH","role":"DISCOVERY","environment":env,"executed":phase_pass}
    if phase_pass:
        paths=[]
        for n,length,frame in [(43,7,(0,1,2)),(47,8,(1,2,0)),(53,9,(2,0,1))]:
            family=[convergent_phase_paths(kernel,n,length,mode,frame=frame,horizon=length+14) for mode in ("closed","A_only","B_only","AB_coherent","AB_phase_shifted","AB_offpath_sham")]
            by={x["mode"]:x for x in family}
            coherent=by["AB_coherent"]; shifted=by["AB_phase_shifted"]; sham=by["AB_offpath_sham"]
            # At every tick, nonlinear contrast is occupancy_AB-A-B+CLOSED.
            def occupancy(run): return {r["tick"]:int(r["detector"] is not None) for r in run["trace"]}
            oa,ob,oc,oab=[occupancy(by[x]) for x in ("A_only","B_only","closed","AB_coherent")]
            contrast={str(t):oab[t]-oa[t]-ob[t]+oc[t] for t in oa}
            comparison={"n":n,"path_length":length,"frame":list(frame),"coherent_ticks":coherent["detector_event_ticks"],"shifted_ticks":shifted["detector_event_ticks"],"sham_ticks":sham["detector_event_ticks"],"coherent_sregs":coherent["detector_event_sregs"],"shifted_sregs":shifted["detector_event_sregs"],"nonzero_nonlinear_contrast_ticks":[int(t) for t,v in contrast.items() if v!=0],"phase_changes_detector_record":coherent["detector_event_ticks"]!=shifted["detector_event_ticks"],"sham_matches_coherent":coherent["detector_event_ticks"]==sham["detector_event_ticks"],"contrast":contrast}
            paths.append({"comparison":comparison,"worlds":family})
        phase_sensitive=all(x["comparison"]["phase_changes_detector_record"] and x["comparison"]["sham_matches_coherent"] and x["comparison"]["nonzero_nonlinear_contrast_ticks"] for x in paths)
        reducer_explains=all(all(v==312 for v in x["worlds"][3]["detector_event_sregs"]) for x in paths)
        path_result.update({"question":"Do two equal propagating paths produce a nonadditive, phase-sensitive detector record?","machine_predicate":"relative phase changes event timing in all cases, offpath sham does not, and coherent collision s_reg is exact reducer sum","predicate_result":phase_sensitive and reducer_explains,"summary":{"cases":len(paths),"phase_sensitive_cases":sum(x["comparison"]["phase_changes_detector_record"] for x in paths),"nonadditive_cases":sum(bool(x["comparison"]["nonzero_nonlinear_contrast_ticks"]) for x in paths),"reducer_exact_cases":sum(all(v==312 for v in x["worlds"][3]["detector_event_sregs"]) for x in paths),"classification":"PHASE_SENSITIVE_TWO_PATH_REDUCER_PATTERN" if phase_sensitive else "INDEPENDENT_PATH_ADDITIVITY"},"mechanism_adjudication":"The detector response is phase-sensitive because coincident arrivals enter one destination fiber and the guarded reducer merges them. Phase shift time-multiplexes the arrivals. This is a native phase-sensitive two-path pattern, but no spatial fringes or specifically wave-like interference law is present.","negative_classification":"SIMPLER_MECHANISM_EXPLAINS_SIGNAL" if phase_sensitive else "MECHANISM_CLASS_NULL","cases":paths})
    save("C12D02_phase_two_path",path_result)
    question({"question_id":"C12Q02","parent_question_id":"C12Q01","front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"Phase reached the detector under native dynamics.","prerequisites":"C12Q01 passed","experiment":"convergent equal paths, coherent/shifted/offpath/A/B/closed worlds across N and axes","controls":["A_only","B_only","closed","offpath_sham"],"response":path_result.get("summary"),"classification":path_result.get("summary",{}).get("classification","NOT_EXECUTED"),"next_question":"freeze bounded reducer law" if path_result.get("predicate_result") else None,"information_gain":"HIGH","time_cost":time.perf_counter()-started,"status":"MECHANISM_CANDIDATE" if path_result.get("predicate_result") else "CLOSED"})

    # Q3: up to three causally distinct ensemble-contact classes.
    ensemble_started=time.perf_counter()
    static=[static_ensemble_contact(kernel,contact=c) for c in (False,True)]
    scaffolds=[joint_scaffold_contact(kernel,mode=m) for m in ("AB","A_only","B_only","empty")]
    driven=[facing_source_ensembles(kernel,mode=m) for m in ("contact","isolated")]
    static_survival=all(all(r["A_support"]==9 and r["B_support"]==9 for r in trial["rows"]) for trial in static)
    static_exchange=static[0]["rows"][-1]["global"]!=static[1]["rows"][-1]["global"]
    joint_restores=all(r["A_restored"] is not None and r["B_restored"] is not None for r in scaffolds[0]["cycles"])
    driven_sources=all(x["source_A_persistent"] and x["source_B_persistent"] for x in driven)
    ensemble_result={"schema":"dee.v27.core12.ensemble_discovery.v1","module":"C12D03_PERSISTENT_ENSEMBLE_CONTACT","role":"DISCOVERY","environment":env,"question":"Can two persistent ensembles exchange a macro coordinate and tend to equality without losing identity?","mechanism_budget_used":3,"classes":[{"id":"P12_ENSEMBLE_MC1","result":"persistent but inert/no exchange","negative_classification":"MECHANISM_CLASS_NULL","prerequisite_survival":static_survival,"trials":static},{"id":"P12_ENSEMBLE_MC2","result":"joint guard restoration; response fixed by semantic/topological guard, not macro equalization","negative_classification":"SIMPLER_MECHANISM_EXPLAINS_SIGNAL","joint_restoration":joint_restores,"trials":scaffolds},{"id":"P12_ENSEMBLE_MC3","result":"distinct persistent sources drive collision flux; source coordinates do not relax","negative_classification":"APPARATUS_PREREQUISITE_MISMATCH","persistent_sources":driven_sources,"trials":driven}],"machine_predicate":"some class preserves A/B and shows exchange plus convergence of a pre-contact scalar","predicate_result":False,"summary":{"classes_tested":3,"static_identity_survives":static_survival,"static_exchange_detected":static_exchange,"joint_scaffold_response":joint_restores,"driven_sources_persist":driven_sources,"Theta_DEE_found":False,"zeroth_law_screen":"NOT_JUSTIFIED","Landauer":"NOT_JUSTIFIED","closure":"NOT_FOUND_WITHIN_CORE12_MECHANISM_BUDGET"},"wall_seconds":time.perf_counter()-ensemble_started}
    save("C12D03_persistent_ensemble_contact",ensemble_result)
    question({"question_id":"C12Q03","parent_question_id":None,"front":"P0-B","mechanism_class":"THREE_CLASS_BUDGET","why_question":"CORE11 carrier collision was an apparatus mismatch; ensembles must survive contact.","prerequisites":"two persistent distinguishable subsystems","experiment":"closed static, closed guard scaffold, source-supported facing trains","controls":["no contact","A/B only","blocked interface"],"response":ensemble_result["summary"],"classification":"NOT_FOUND_WITHIN_CORE12_MECHANISM_BUDGET","next_question":None,"information_gain":"HIGH","time_cost":ensemble_result["wall_seconds"],"status":"CLOSED"})

    # Q4: a confirmed matter-like guard scaffold as interface for confirmed phase train.
    interface_started=time.perf_counter()
    interface_trials=[]
    for n,dist,d in [(47,11,(1,0,0)),(53,13,(0,1,0)),(59,15,(0,0,1))]:
        for mode in ("empty","static_center_only","semantic1_same_inventory","semantic4_missing_corner","semantic4_full"):
            interface_trials.append(regenerative_interface_trial(kernel,n,dist,7,dist+18,mode,d))
    cases=[]
    for i in range(0,len(interface_trials),5):
        by={x["mode"]:x for x in interface_trials[i:i+5]}
        last="7"
        cases.append({"n":by["empty"]["n"],"direction":by["empty"]["direction"],"empty_downstream_ticks":by["empty"]["downstream_event_ticks"][last],"center_only_downstream_ticks":by["static_center_only"]["downstream_event_ticks"][last],"semantic1_downstream_ticks":by["semantic1_same_inventory"]["downstream_event_ticks"][last],"missing_corner_downstream_ticks":by["semantic4_missing_corner"]["downstream_event_ticks"][last],"semantic4_full_downstream_ticks":by["semantic4_full"]["downstream_event_ticks"][last],"full_suppresses_more_than_controls":len(by["semantic4_full"]["downstream_event_ticks"][last]) < len(by["semantic1_same_inventory"]["downstream_event_ticks"][last])})
    interface_signal=all(c["full_suppresses_more_than_controls"] for c in cases)
    interface_result={"schema":"dee.v27.core12.interface_discovery.v1","module":"C12D04_MATTER_PROPAGATION_INTERFACE","role":"DISCOVERY","environment":env,"question":"Does organization, beyond inventory, change transmission of a period-two propagating mode?","machine_predicate":"semantic-4 full scaffold suppresses more downstream events than equal-support semantic-1 and missing-corner controls in every orientation","predicate_result":interface_signal,"summary":{"cases":len(cases),"organization_specific_cases":sum(c["full_suppresses_more_than_controls"] for c in cases),"candidate":"REGENERATIVE_PERIODIC_CAPTURE_INTERFACE" if interface_signal else "NO_ORGANIZATION_SPECIFIC_INTERFACE_LAW"},"cases":cases,"trials":interface_trials,"wall_seconds":time.perf_counter()-interface_started}
    save("C12D04_matter_propagation_interface",interface_result)
    question({"question_id":"C12Q04","parent_question_id":"C12Q01","front":"P1","mechanism_class":"PERIOD2_TRAIN_X_SEMANTIC4_SCAFFOLD","why_question":"Both mode and matter-like regenerative scaffold are independently established v27 families.","prerequisites":"phase train and scaffold persistence","experiment":"five matched interface organizations across three axes/N","controls":["empty","center_only","same inventory semantic1","missing corner"],"response":interface_result["summary"],"classification":interface_result["summary"]["candidate"],"next_question":"freeze interface relation" if interface_signal else None,"information_gain":"HIGH","time_cost":interface_result["wall_seconds"],"status":"MECHANISM_CANDIDATE" if interface_signal else "CLOSED"})
    update_kernel_audit("after_discovery")
    update_state(status="DISCOVERY_COMPLETE",completed_modules=["initialization","directed_prior_audit","phase_prerequisite","phase_two_path","persistent_ensemble_contact","matter_propagation_interface"],last_completed_experiment="C12D04_MATTER_PROPAGATION_INTERFACE",next_action="analyze discovery and freeze only predicates supported by telemetry")
    append_log({"module":"adaptive_discovery","status":"COMPLETE","phase_gate":phase_pass,"two_path":path_result.get("summary"),"ensemble":ensemble_result["summary"],"interface":interface_result["summary"],"wall_seconds":time.perf_counter()-started})
    update_budget("freeze_supported_holdouts", 20, "RUN")
    print(json.dumps({"phase":phase_result["summary"],"two_path":path_result.get("summary"),"ensemble":ensemble_result["summary"],"interface":interface_result["summary"],"wall_seconds":time.perf_counter()-started},indent=2))


if __name__=="__main__": main()
