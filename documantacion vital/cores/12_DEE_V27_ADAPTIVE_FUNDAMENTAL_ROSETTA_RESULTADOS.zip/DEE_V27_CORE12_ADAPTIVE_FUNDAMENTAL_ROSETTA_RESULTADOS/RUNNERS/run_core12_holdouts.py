"""Run the frozen CORE12 holdouts exactly once on new worlds."""
from __future__ import annotations
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,append_log,atomic_json,dialogue,question,sha256_file,update_budget,update_kernel_audit,update_state,verify_and_load_kernel
from core12_apparatus import convergent_phase_paths,guard_truth_table,regenerative_interface_trial,source_train_trial

def validate_locks():
    registry=json.loads((ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json").read_text(encoding="utf-8"))
    for claim,expected in registry["hashes"].items():
        observed=sha256_file(ROOT/"HOLDOUT_LOCKS"/f"{claim}.json")
        if observed!=expected: raise RuntimeError(f"lock changed: {claim}")
    return registry["hashes"]

def expected_ticks(first,horizon): return list(range(first,horizon+1,2))

def main():
    started=time.perf_counter(); update_budget("run_holdouts",90,"RUN"); locks=validate_locks(); kernel,env=verify_and_load_kernel(1)
    # H01
    configs=[(61,(17,29,31),(1,0,0),10,401),(67,(23,35,19),(0,-1,0),11,733),(71,(37,22,41),(0,0,1),12,1201),(73,(31,40,27),(-1,0,0),13,19001)]
    h1=[]
    for n,src,d,L,sreg in configs:
        arms={m:source_train_trial(kernel,n,src,d,sreg,L+14,L,m,clock_value=987650+n) for m in ("baseline","mouth_block","offpath_sham")}
        passed=arms["baseline"]["arrival_ticks"]==expected_ticks(L,L+14) and arms["mouth_block"]["arrival_ticks"]==expected_ticks(L+1,L+14) and arms["offpath_sham"]["arrival_ticks"]==expected_ticks(L,L+14) and all(a["source_persistent"] for a in arms.values())
        h1.append({"n":n,"source":list(src),"direction":list(d),"L":L,"sreg":sreg,"pass":passed,"arms":arms})
    h1pass=all(x["pass"] for x in h1)
    out1={"schema":"dee.v27.core12.holdout.v1","claim_id":"C12H01_PHASE_TRANSPORT","lock_sha256":locks["C12H01_PHASE_TRANSPORT"],"environment":env,"verdict":"PASS" if h1pass else "FAIL","machine_predicate_result":h1pass,"summary":{"passed":sum(x["pass"] for x in h1),"total":len(h1)},"trials":h1}
    atomic_json(ROOT/"RESULTS"/"C12H01_phase_transport_holdout.json",out1)
    # H02
    h2=[]
    frames=[(0,2,1),(1,0,2),(2,1,0),(0,1,2)]
    for (n,_,_,L,_),frame,sregs in zip(configs,frames,[(331,509),(701,1103),(1701,2203),(4001,8009)],strict=True):
        horizon=L+12
        worlds={m:convergent_phase_paths(kernel,n,L,m,center=(n//2+1,n//2-2,n//2+2),sregs=sregs,horizon=horizon,frame=frame) for m in ("closed","A_only","B_only","AB_coherent","AB_phase_shifted","AB_offpath_sham","B_phase_shifted")}
        coherent=worlds["AB_coherent"]; shifted=worlds["AB_phase_shifted"]; sham=worlds["AB_offpath_sham"]; bshift=worlds["B_phase_shifted"]
        coherent_expected=expected_ticks(L,horizon); shifted_b_expected=expected_ticks(L+1,horizon)
        passed=(coherent["detector_event_ticks"]==coherent_expected and all(v==sum(sregs) for v in coherent["detector_event_sregs"]) and shifted["detector_event_ticks"]==coherent_expected and all(v==sregs[0] for v in shifted["detector_event_sregs"]) and sham["detector_event_sregs"]==coherent["detector_event_sregs"] and bshift["detector_event_ticks"]==shifted_b_expected and all(v==sregs[1] for v in bshift["detector_event_sregs"]))
        h2.append({"n":n,"L":L,"frame":list(frame),"sregs":list(sregs),"pass":passed,"worlds":worlds})
    h2pass=all(x["pass"] for x in h2)
    out2={"schema":"dee.v27.core12.holdout.v1","claim_id":"C12H02_PHASE_HISTORY_PATH_RESPONSE","lock_sha256":locks["C12H02_PHASE_HISTORY_PATH_RESPONSE"],"environment":env,"verdict":"PASS" if h2pass else "FAIL","machine_predicate_result":h2pass,"summary":{"passed":sum(x["pass"] for x in h2),"total":len(h2),"interpretation":"bounded phase-sensitive two-path response explained by target occupancy and destination reduction; not a fringe law"},"trials":h2}
    atomic_json(ROOT/"RESULTS"/"C12H02_phase_history_path_holdout.json",out2)
    # H03
    h3=[]
    for n,center,sbase,statebase in [(17,(5,8,9),701,0x11000),(19,(11,7,13),5001,0x22000),(21,(14,12,6),16001,0x33000)]:
        table=guard_truth_table(kernel,n,center,sreg_base=sbase,state_base=statebase)
        errors=[]
        for row in table["rows"]:
            expected=(row["count"]>=6) if row["initial_center"] else (row["count"]==8)
            if row["center_present"]!=expected: errors.append({"mask":row["mask"],"initial_center":row["initial_center"],"observed":row["center_present"],"expected":expected})
        h3.append({"n":n,"center":list(center),"sreg_base":sbase,"state_base":statebase,"pass":not errors,"errors":errors,"table":table})
    h3pass=all(x["pass"] for x in h3)
    out3={"schema":"dee.v27.core12.holdout.v1","claim_id":"C12H03_SEMANTIC4_GUARD_THRESHOLD","lock_sha256":locks["C12H03_SEMANTIC4_GUARD_THRESHOLD"],"environment":env,"verdict":"PASS" if h3pass else "FAIL","machine_predicate_result":h3pass,"summary":{"passed_outcomes":sum(512-len(x["errors"]) for x in h3),"total_outcomes":1536,"worlds_passed":sum(x["pass"] for x in h3)},"trials":h3}
    atomic_json(ROOT/"RESULTS"/"C12H03_guard_threshold_holdout.json",out3)
    # H04
    h4=[]
    masks6=[[0,1,2,3,4,5],[0,1,2,4,6,7],[1,2,3,5,6,7],[0,2,3,4,5,7]]; masks5=[[0,1,2,3,4],[0,1,4,6,7],[1,2,3,5,7],[0,2,4,5,7]]
    dirs=[(1,0,0),(0,-1,0),(0,0,1),(-1,0,0)]
    for ix,((n,_,_,L,sreg),d,k6,k5) in enumerate(zip(configs,dirs,masks6,masks5,strict=True)):
        center=(n//2+2,n//2-1,n//2+1); horizon=L+18
        pass6=regenerative_interface_trial(kernel,n,L,7,horizon,"semantic4_custom",d,center,sreg,semantic4_indices=k6)
        fail5=regenerative_interface_trial(kernel,n,L,7,horizon,"semantic4_custom",d,center,sreg,semantic4_indices=k5)
        shuffled=regenerative_interface_trial(kernel,n,L,7,horizon,"semantic4_shuffled",d,center,sreg)
        sem1=regenerative_interface_trial(kernel,n,L,7,horizon,"semantic1_same_inventory",d,center,sreg)
        empty=regenerative_interface_trial(kernel,n,L,7,horizon,"empty",d,center,sreg)
        key="7"; expected=empty["downstream_event_ticks"][key]
        passed=(pass6["downstream_event_ticks"][key]==[] and all(r["center"] is not None for r in pass6["rows"]) and fail5["downstream_event_ticks"][key]==expected and shuffled["downstream_event_ticks"][key]==expected and sem1["downstream_event_ticks"][key]==expected)
        h4.append({"n":n,"L":L,"direction":list(d),"center":list(center),"k6":k6,"k5":k5,"pass":passed,"expected_transmission":expected,"worlds":[pass6,fail5,shuffled,sem1,empty]})
    h4pass=all(x["pass"] for x in h4)
    out4={"schema":"dee.v27.core12.holdout.v1","claim_id":"C12H04_GUARDED_INTERFACE_CAPTURE","lock_sha256":locks["C12H04_GUARDED_INTERFACE_CAPTURE"],"environment":env,"verdict":"PASS" if h4pass else "FAIL","machine_predicate_result":h4pass,"summary":{"passed":sum(x["pass"] for x in h4),"total":len(h4),"classification":"ORGANIZATION_SPECIFIC_SUSTAINED_CAPTURE_INTERFACE" if h4pass else "CLAIM_FAILED"},"trials":h4}
    atomic_json(ROOT/"RESULTS"/"C12H04_guarded_interface_holdout.json",out4)
    verdicts={x["claim_id"]:x["verdict"] for x in (out1,out2,out3,out4)}; update_kernel_audit("after_holdouts")
    append_log({"module":"frozen_holdouts","status":"COMPLETE","verdicts":verdicts,"wall_seconds":time.perf_counter()-started})
    for cid,verdict in verdicts.items(): question({"question_id":cid,"parent_question_id":cid.replace("H","Q",1),"front":"CONFIRMATION","mechanism_class":"FROZEN","why_question":"promotion test","prerequisites":"immutable lock","experiment":"new worlds","controls":"as locked","response":verdict,"classification":verdict,"next_question":None,"information_gain":"DECISIVE","time_cost":time.perf_counter()-started,"status":"CONFIRMED" if verdict=="PASS" else "FAILED"})
    dialogue({"question":"Which discovery laws survive untouched worlds?","why":"Promotion requires frozen confirmation.","apparatus":"four SHA-256 locked protocols","kernel_response":verdicts,"negative_positive_class":"HOLDOUT_RESULTS","simpler_explanation":"retained in each lock","next_discriminating_question":"Rosetta ladder only for passed multirelational fingerprint","evidence_level":"HOLDOUT"})
    update_state(status="HOLDOUTS_COMPLETE",last_completed_experiment="C12H04_GUARDED_INTERFACE_CAPTURE",holdout_verdicts=verdicts,next_action="adversarial synthesis and Rosetta readiness gate")
    update_budget("analysis_and_reports",300,"RUN"); print(json.dumps({"verdicts":verdicts,"wall_seconds":time.perf_counter()-started},indent=2))

if __name__=="__main__":main()
