"""Cheap discriminating tests for phase interaction and the interface guard."""
from __future__ import annotations

import json
import shutil
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT, append_log, atomic_json, dialogue, question, update_budget, update_state, utc_now, verify_and_load_kernel
from core12_apparatus import convergent_phase_paths, guard_truth_table, regenerative_interface_trial, source_train_trial


def main():
    started=time.perf_counter(); update_budget("mechanism_diagnostics",90,"RUN"); kernel,env=verify_and_load_kernel(1)
    # Preserve the provisional interpretation before correcting it.
    prior=ROOT/"RESULTS"/"C12D04_matter_propagation_interface.json"
    incident=ROOT/"INCIDENTS"/"C12I01_provisional_interface_interpretation.json"
    if prior.exists() and not incident.exists():
        shutil.copyfile(prior,incident)
    diagonal=[]
    for n,source,d,l in [(43,(11,20,20),(1,1,0),7),(47,(14,25,22),(1,-1,0),8),(53,(21,18,27),(-1,1,1),9)]:
        arms=[source_train_trial(kernel,n,source,d,173,l+14,l,m) for m in ("baseline","mouth_block","offpath_sham")]
        diagonal.append({"n":n,"d":list(d),"baseline":arms[0]["arrival_ticks"],"blocked":arms[1]["arrival_ticks"],"sham":arms[2]["arrival_ticks"],"block_flips":bool(arms[0]["arrival_ticks"] and arms[1]["arrival_ticks"] and arms[0]["arrival_ticks"][0]%2!=arms[1]["arrival_ticks"][0]%2),"arms":arms})
    isolated=[]
    for n,l,frame in [(43,7,(0,1,2)),(47,8,(1,2,0)),(53,9,(2,0,1))]:
        base=convergent_phase_paths(kernel,n,l,"B_only",frame=frame,horizon=l+14)
        shifted=convergent_phase_paths(kernel,n,l,"B_phase_shifted",frame=frame,horizon=l+14)
        isolated.append({"n":n,"frame":list(frame),"baseline":base["detector_event_ticks"],"shifted":shifted["detector_event_ticks"],"phase_flip":bool(base["detector_event_ticks"] and shifted["detector_event_ticks"] and base["detector_event_ticks"][0]%2!=shifted["detector_event_ticks"][0]%2),"worlds":[base,shifted]})
    path_diagnostic={"schema":"dee.v27.core12.phase_path_diagnostic.v1","module":"C12D05_PHASE_PATH_DIAGNOSTIC","role":"DISCOVERY_MECHANISM_DIAGNOSTIC","environment":env,"question":"Why did relative phase not alter the AB detector tick set?","diagonal_single_train":diagonal,"isolated_B_paths":isolated,"summary":{"diagonal_phase_flip_cases":sum(x["block_flips"] for x in diagonal),"isolated_B_phase_flip_cases":sum(x["phase_flip"] for x in isolated),"interpretation":"If isolated B flips but AB does not, a detector-level occupancy union can hide which path arrived; the s_reg/direction record remains phase-sensitive. If isolated B does not flip, mouth phase control is route-class dependent."}}
    atomic_json(ROOT/"RESULTS"/"C12D05_phase_path_diagnostic.json",path_diagnostic)

    truth=guard_truth_table(kernel)
    born=[r for r in truth["rows"] if not r["initial_center"] and r["center_present"]]
    retained=[r for r in truth["rows"] if r["initial_center"] and r["center_present"]]
    min_born=min((r["count"] for r in born),default=None); min_retained=min((r["count"] for r in retained),default=None)
    minimal_born=[r["indices"] for r in born if r["count"]==min_born]
    minimal_retained=[r["indices"] for r in retained if r["count"]==min_retained]
    # Prospective representatives are still discovery; holdout will use new N/orientation/sreg.
    pass_indices=minimal_retained[0] if minimal_retained else []
    fail_indices=next((r["indices"] for r in truth["rows"] if r["initial_center"] and not r["center_present"] and r["count"]==min_retained),[]) if min_retained is not None else []
    interface_trials=[]
    for mode,indices in [("semantic4_custom",pass_indices),("semantic4_custom",fail_indices),("semantic4_shuffled",None),("semantic1_same_inventory",None),("empty",None)]:
        trial=regenerative_interface_trial(kernel,n=47,source_distance=11,downstream_distance=7,horizon=29,mode=mode,direction=(1,0,0),semantic4_indices=indices)
        trial["custom_indices"]=indices
        interface_trials.append(trial)
    through=[{"mode":x["mode"],"indices":x.get("custom_indices"),"downstream7":x["downstream_event_ticks"]["7"],"center_present_ticks":sum(r["center"] is not None for r in x["rows"])} for x in interface_trials]
    interface_diag={"schema":"dee.v27.core12.interface_guard_diagnostic.v1","module":"C12D06_INTERFACE_GUARD_DIAGNOSTIC","role":"DISCOVERY_MECHANISM_DIAGNOSTIC","environment":env,"question":"Is suppression caused by inventory, static blocking, or the semantic/topological local guard?","truth_table":truth,"summary":{"masks_with_birth":len(born),"masks_with_retention":len(retained),"minimum_corner_count_for_birth":min_born,"minimum_corner_count_for_retention":min_retained,"minimal_birth_masks":minimal_born,"minimal_retention_masks":minimal_retained,"retention_counts":dict(Counter(r["count"] for r in retained))},"representative_interface_trials":through,"trials":interface_trials,"provisional_interpretation_status":"INTERPRETATION_INVALIDATED","why":"The first predicate omitted that a seven-corner control also suppressed transmission. The exhaustive guard table replaces the broad regenerative label with an exact topology/semantic mechanism."}
    atomic_json(ROOT/"RESULTS"/"C12D06_interface_guard_diagnostic.json",interface_diag)
    question({"question_id":"C12Q05","parent_question_id":"C12Q02","front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"AB occupancy ticks did not change although the isolated phase witness did.","prerequisites":"phase witness passed, AB occupancy null","experiment":"diagonal isolated trains and isolated B geometry","controls":["baseline","mouth block","offpath"],"response":path_diagnostic["summary"],"classification":"MECHANISM_LOCALIZATION","next_question":"define detector record sensitive to path identity/sreg, not occupancy only","information_gain":"HIGH","time_cost":time.perf_counter()-started,"status":"CLOSED"})
    question({"question_id":"C12Q06","parent_question_id":"C12Q04","front":"P1","mechanism_class":"SEMANTIC4_LOCAL_GUARD","why_question":"Seven corners suppressed transmission as strongly as eight; topology threshold was unknown.","prerequisites":"organization-specific suppression discovery","experiment":"exhaustive 2^8 one-tick local truth table plus representative propagating controls","controls":["center absent/present","semantic1","shuffled semantic4","pass/fail masks"],"response":interface_diag["summary"],"classification":"EXACT_LOCAL_GUARD_CANDIDATE","next_question":"freeze exact mask predicate and interface consequence on new worlds","information_gain":"HIGH","time_cost":time.perf_counter()-started,"status":"MECHANISM_CANDIDATE"})
    dialogue({"question":"What actually blocks the phase train at the scaffold?","why":"A seven-corner structure equaled the full structure, invalidating the provisional full-scaffold story.","apparatus":"exhaustive local corner mask truth table and equal-inventory spatial controls","kernel_response":interface_diag["summary"],"negative_positive_class":"INTERPRETATION_INVALIDATED then MECHANISM_CANDIDATE","simpler_explanation":"semantic/topological guard rather than bulk inventory or passive center","next_discriminating_question":"Can the exact predicate predict suppression at new N/orientations?","evidence_level":"DISCOVERY"})
    append_log({"module":"mechanism_diagnostics","status":"COMPLETE","phase":path_diagnostic["summary"],"interface":interface_diag["summary"],"incident":str(incident.name),"wall_seconds":time.perf_counter()-started})
    update_state(status="MECHANISM_DIAGNOSTICS_COMPLETE",completed_modules=["initialization","directed_prior_audit","phase_prerequisite","phase_two_path","persistent_ensemble_contact","matter_propagation_interface","phase_path_diagnostic","interface_guard_diagnostic"],last_completed_experiment="C12D06_INTERFACE_GUARD_DIAGNOSTIC",next_action="freeze supported phase and interface laws; do not promote interference or Theta")
    update_budget("freeze_holdouts",30,"RUN")
    print(json.dumps({"phase":path_diagnostic["summary"],"guard":interface_diag["summary"],"representatives":through,"wall_seconds":time.perf_counter()-started},indent=2))


if __name__=="__main__": main()
