"""Decisive intervention for target-occupancy mediation in antiphase paths."""
from __future__ import annotations
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,append_log,atomic_json,dialogue,question,update_budget,update_state,verify_and_load_kernel
from core12_apparatus import convergent_phase_trace

def detector(run,tick): return next(r["detector"] for r in run["rows"] if r["tick"]==tick)

def main():
    started=time.perf_counter(); update_budget("occupancy_mediation",30,"RUN"); kernel,env=verify_and_load_kernel(1); cases=[]
    for n,l,frame in [(43,7,(0,1,2)),(47,8,(1,2,0)),(53,9,(2,0,1))]:
        natural=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3)
        remove=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3,remove_center_record_tick=l)
        sham=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+3,remove_offpath_record_tick=l)
        t=l+1; nr,rr,sr=detector(natural,t),detector(remove,t),detector(sham,t)
        cases.append({"n":n,"path_length":l,"frame":list(frame),"target_tick":t,"natural":nr,"center_record_removed":rr,"offpath_record_removed":sr,"center_removal_restores_B":nr is None and rr is not None and rr["sreg"]==211,"offpath_preserves_exclusion":sr is None,"runs":[natural,remove,sham]})
    passed=all(x["center_removal_restores_B"] and x["offpath_preserves_exclusion"] for x in cases)
    result={"schema":"dee.v27.core12.occupancy_mediation.v1","module":"C12D09_OCCUPANCY_MEDIATION","role":"DISCOVERY_CAUSAL_INTERVENTION","post_t0_python":"FIXED_EXTERNAL_INTERVENTION used only to identify mechanism","environment":env,"question":"Does current target occupancy by A, rather than clock history, exclude antiphase B?","machine_predicate":"predeclared removal of A's detector record at tick L restores B(s_reg=211) at L+1; offpath removal does not","predicate_result":passed,"summary":{"cases":len(cases),"restored_cases":sum(x["center_removal_restores_B"] for x in cases),"sham_cases":sum(x["offpath_preserves_exclusion"] for x in cases),"mechanism":"TARGET_OCCUPANCY_EXCLUSION" if passed else "OCCUPANCY_NOT_SUFFICIENT"},"cases":cases,"wall_seconds":time.perf_counter()-started}
    atomic_json(ROOT/"RESULTS"/"C12D09_occupancy_mediation.json",result)
    question({"question_id":"C12Q09","parent_question_id":"C12Q08","front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"Clock reset failed; B attempts entry while A occupies target.","prerequisites":"clock mechanism rejected","experiment":"fixed removal of target occupant at tick L versus offpath removal","controls":["natural","offpath removal"],"response":result["summary"],"classification":result["summary"]["mechanism"],"next_question":"freeze natural reducer/exclusion law" if passed else None,"information_gain":"HIGH","time_cost":result["wall_seconds"],"status":"MECHANISM_CANDIDATE" if passed else "CLOSED"})
    dialogue({"question":"Is target occupancy the decisive mediator?","why":"The clock was causally insufficient.","apparatus":"fixed-time record removal at target and matched offpath","kernel_response":result["summary"],"negative_positive_class":"POSITIVE_CAUSAL" if passed else "MECHANISM_CLASS_NULL","simpler_explanation":"target exclusion/destination rule; not wave cancellation","next_discriminating_question":"new-domain untouched holdout","evidence_level":"DISCOVERY_CAUSAL"})
    append_log({"module":"occupancy_mediation","status":"COMPLETE","summary":result["summary"],"wall_seconds":result["wall_seconds"]}); update_state(status="READY_TO_FREEZE",last_completed_experiment="C12D09_OCCUPANCY_MEDIATION",next_action="freeze and hash supported holdout contracts"); update_budget("freeze_holdouts",30,"RUN"); print(json.dumps(result["summary"],indent=2))

if __name__=="__main__": main()
