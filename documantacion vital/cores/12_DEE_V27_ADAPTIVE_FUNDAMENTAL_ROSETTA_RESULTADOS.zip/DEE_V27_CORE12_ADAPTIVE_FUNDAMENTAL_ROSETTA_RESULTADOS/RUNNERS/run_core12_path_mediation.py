"""Locate the causal loss of the phase-shifted B train in the two-path world."""
from __future__ import annotations

import json
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT, append_log, atomic_json, dialogue, question, update_budget, update_state, verify_and_load_kernel
from core12_apparatus import convergent_phase_trace


def signatures(row, wanted):
    return sorted((tuple(r["coordinate"]),r["sreg"],tuple(r["direction"]),r["semantic"]) for r in row["records"] if r["sreg"]==wanted)


def main():
    started=time.perf_counter(); update_budget("path_mediation",30,"RUN"); kernel,env=verify_and_load_kernel(1)
    prior=ROOT/"RESULTS"/"C12D02_phase_two_path.json"; incident=ROOT/"INCIDENTS"/"C12I03_binary_readout_interpretation.json"
    if prior.exists() and not incident.exists(): shutil.copyfile(prior,incident)
    cases=[]
    for n,l,frame in [(43,7,(0,1,2)),(47,8,(1,2,0)),(53,9,(2,0,1))]:
        ab=convergent_phase_trace(kernel,n,l,"AB_phase_shifted",frame=frame,horizon=l+4)
        b=convergent_phase_trace(kernel,n,l,"B_phase_shifted",frame=frame,horizon=l+4)
        comparisons=[]; first=None
        for ra,rb in zip(ab["rows"],b["rows"],strict=True):
            sa=signatures(ra,211); sb=signatures(rb,211); same=sa==sb
            if not same and first is None: first=ra["tick"]
            comparisons.append({"tick":ra["tick"],"AB_B_sreg211":sa,"isolated_B_sreg211":sb,"same":same,"AB_detector":ra["detector"],"B_detector":rb["detector"]})
        first_row=next((r for r in comparisons if r["tick"]==first),None)
        cases.append({"n":n,"path_length":l,"frame":list(frame),"first_B_lineage_divergence_tick":first,"first_divergence":first_row,"comparison":comparisons,"AB_trace":ab,"isolated_B_trace":b})
    localized=all(c["first_B_lineage_divergence_tick"] is not None and c["first_B_lineage_divergence_tick"]<=c["path_length"] for c in cases)
    result={"schema":"dee.v27.core12.path_mediation.v1","module":"C12D07_PATH_MEDIATION","role":"DISCOVERY_MECHANISM","environment":env,"question":"Where does the isolated phase-shifted B lineage cease to match B inside the AB world?","machine_predicate":"a reproducible pre/detector divergence of B lineage occurs across orientations, while the coherent detector record is exact destination reduction","predicate_result":localized,"summary":{"cases":len(cases),"localized_cases":sum(c["first_B_lineage_divergence_tick"] is not None for c in cases),"first_divergence_ticks":[c["first_B_lineage_divergence_tick"] for c in cases],"classification":"PHASE_SENSITIVE_PATH_INTERACTION" if localized else "MEDIATION_NOT_LOCALIZED"},"interpretation_correction":{"previous":"INDEPENDENT_PATH_ADDITIVITY based on occupancy ticks only","current":"phase changes the detector record (s_reg/direction/path contribution) even though A preserves the same occupancy cadence","status":"INTERPRETATION_INVALIDATED"},"cases":cases,"wall_seconds":time.perf_counter()-started}
    atomic_json(ROOT/"RESULTS"/"C12D07_path_mediation.json",result)
    question({"question_id":"C12Q07","parent_question_id":"C12Q05","front":"P0-A","mechanism_class":"P12_PHASE_MC1","why_question":"The detector signature changed while occupancy did not; locate the missing B lineage.","prerequisites":"isolated B phase flip and AB signature difference","experiment":"sparse lineage/path trace AB-shifted versus isolated-B-shifted","controls":["isolated B with identical source, mouth block, route and clock"],"response":result["summary"],"classification":result["summary"]["classification"],"next_question":"freeze detector-signature law, not an occupancy-fringe claim" if localized else None,"information_gain":"HIGH","time_cost":result["wall_seconds"],"status":"MECHANISM_CANDIDATE" if localized else "CLOSED"})
    dialogue({"question":"Did relative phase truly alter a physical detector record, or only a chosen readout?","why":"Occupancy was invariant but s_reg and direction differed.","apparatus":"matched AB and isolated B sparse path/lineage traces","kernel_response":result["summary"],"negative_positive_class":"POSITIVE_BOUNDED" if localized else "INSUFFICIENT_INFORMATION","simpler_explanation":"destination-fiber/near-path interaction, not wave-amplitude cancellation","next_discriminating_question":"frozen prediction across new geometries","evidence_level":"DISCOVERY_MECHANISM"})
    append_log({"module":"path_mediation","status":"COMPLETE","summary":result["summary"],"wall_seconds":result["wall_seconds"]})
    update_state(status="READY_TO_FREEZE",last_completed_experiment="C12D07_PATH_MEDIATION",next_action="create immutable holdout contracts for phase transport, phase-sensitive path signature, local guard, and guarded interface")
    update_budget("freeze_holdouts",30,"RUN")
    print(json.dumps(result["summary"],indent=2))


if __name__=="__main__": main()
