from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,sha256_file
data=json.loads((ROOT/"PARENT_CHAIN.json").read_text(encoding="utf-8"))
for row in data["parents"]:
    observed=sha256_file(Path(row["path"]))
    if observed!=row["sha256"]: raise SystemExit(f"FAIL {row['core']} {observed}")
print(f"PASS {len(data['parents'])} parents")
