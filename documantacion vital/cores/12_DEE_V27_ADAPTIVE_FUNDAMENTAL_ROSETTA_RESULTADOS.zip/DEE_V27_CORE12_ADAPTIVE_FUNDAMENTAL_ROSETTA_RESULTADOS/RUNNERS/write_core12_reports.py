"""Write concise, evidence-linked CORE12 scientific reports."""
from __future__ import annotations
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core12_common import ROOT,append_log,atomic_text,update_budget,update_state,utc_now

def load(path): return json.loads((ROOT/path).read_text(encoding="utf-8"))
def write(name,text): atomic_text(ROOT/name,text.strip()+"\n")

def main():
    started=time.perf_counter(); update_budget("write_reports",180,"RUN")
    syn=load(Path("RESULTS/C12A01_machine_synthesis.json")); claims=load(Path("CLAIM_LEDGER.json")); neg=load(Path("NEGATIVE_CLASSIFICATION.json")); tb=load(Path("TIME_BUDGET.json"))
    h1=load(Path("RESULTS/C12H01_phase_transport_holdout.json")); h2=load(Path("RESULTS/C12H02_phase_history_path_holdout.json")); h3=load(Path("RESULTS/C12H03_guard_threshold_holdout.json")); h4=load(Path("RESULTS/C12H04_guarded_interface_holdout.json")); ens=load(Path("RESULTS/C12D03_persistent_ensemble_contact.json")); occ=load(Path("RESULTS/C12D09_occupancy_mediation.json")); clk=load(Path("RESULTS/C12D08_clock_mediation.json"))
    executive=f"""# CORE12 — Executive verdict

## Primary decision

`ROSETTA_INTERNAL_LAW_FOUND`

CORE12 found and froze four reproducible laws under the unchanged v27 kernel. All four holdouts passed: phase transport 4/4, two-path phase/history response 4/4, the local guard predicate 1,536/1,536 outcomes, and the guarded interface 4/4.

The principal discovery is not physical interference. A persistent semantic-4 source emits a source-supported period-two train. A preparation-time obstruction shifts its arrival parity by one tick. When two equal paths meet, phase decides whether arrivals are simultaneous and reduced (`s_reg=a+b`) or sequential, in which case current target occupancy excludes the delayed path. Removing that occupant at the preregistered tick restores the delayed record in 3/3 causal diagnostics; resetting only its clock restores 0/3.

The second discovery is an exact local organization law: among eight semantic-4 corner relations, an existing center is retained iff `k≥6`; an absent center is created iff `k=8`. Coupling this guard to the period-two train yields sustained capture. A `k=5` arrangement, semantic-1 equal inventory, shifted semantic-4 inventory and empty controls transmit.

No `Theta_DEE`, bounded zeroth law, fringe scaling, wave-law match, low-parameter external Rosetta, unused external prediction or external validation was obtained. The two-path signal is fully explained by DEE's reducer/exclusion rules. External search therefore did not pass its gate.

No CORE13 is created or automatically recommended. A further internal experiment would require a concretely new mechanism: a distributed phase-bearing mode that can split and recombine without target exclusion, or a closed persistent ensemble with an exchangeable macro coordinate.
"""
    write("EXECUTIVE_VERDICT.md",executive)
    final=f"""# CORE12 final report

## Scope and integrity

CORE12 used CORE01–11 as a scientific corpus and did not repeat CORE11's singleton transport, singleton aperture additivity, carrier coalescence or M_rel results. CORE11 was verified at `c8b591c5eb4e90a5de947da992337434be98802c024c860991ba8d967d9fb885`. Wheel, package and `.pyd` identities were checked before science, after discovery and before/after holdouts; the final check is part of packaging. F_DEE was never modified.

## Adaptive interrogation

The direct v27 candidate outranked historical T2/T3/T4 labels: semantic-4 sources had an existing period-two propagation witness, and an initial mouth obstruction had an existing phase-memory witness. Three new geometries established that the phase reaches a detector. That prerequisite opened a two-path test.

Binary detector occupancy initially hid the effect and produced an invalid provisional interpretation. The preserved structured records showed that coherent worlds delivered `s_reg=312`, whereas phase-shifted worlds delivered only the `s_reg=101` A record. Isolated shifted B still arrived one tick later. Sparse traces localized the loss at the occupied target. A selective clock reset failed (0/3); selective occupant removal restored B (3/3). The final interpretation is therefore phase-conditioned destination reduction/exclusion, not a spatial fringe.

An interface discovery likewise began with an overbroad “full scaffold” label. The seven-corner arm behaved identically, so CORE12 preserved that interpretation as invalid and exhaustively tested all `2^8` masks. Exactly 37 masks retain a center: all 28 six-corner masks, all eight seven-corner masks and the full mask. Only the full eight-corner mask creates a missing center.

## Frozen results

| Claim | Lock | Result |
|---|---|---|
| Period-two phase transport | `{h1['lock_sha256']}` | PASS 4/4 |
| Phase/history two-path detector law | `{h2['lock_sha256']}` | PASS 4/4 |
| Semantic-4 guard threshold | `{h3['lock_sha256']}` | PASS 1536/1536 |
| Guarded sustained-capture interface | `{h4['lock_sha256']}` | PASS 4/4 |

## Ensemble branch

Three causally distinct classes used the full budget. Static semantic-1 arrays did not satisfy persistence; joint semantic-4 scaffolds exhibited guard restoration rather than macro exchange; facing source trains retained distinct sources but were driven steady states. No primary scalar both predicted flux and tended to equality while A/B survived. `Theta_DEE`, zeroth-law and Landauer gates remained closed.

## Observer and dimensional result

The phase route needs only source class, direction, distance and one parity bit plus detector history. The two-path law needs the destination record `(time,s_reg,direction)` and one-step target occupancy; occupancy alone is insufficient. The interface law needs center occupancy and the scalar count `k` over eight specific relations. These are task-relative finite observers embedded in a 3D substrate—not evidence for lower-dimensional ontology.

## Rosetta gate

All promoted laws reached R1 internally. None reached R2: the aperture response has no spatial maxima/minima/envelope law and is exactly explained by the native reducer; the interface response is a discrete semantic threshold with no independently predicted external observable. No internet search or dataset fitting was scientifically justified.

## Decision

`{syn['primary_decision']}`. The result is meaningful internal progress, not an external physical identification.
"""
    write("FINAL_REPORT.md",final)
    write("TRANSVERSAL_CORE01_TO_12.md",f"""# Transversal CORE01–12

CORE12 preserves the established chain: Q0 raw+clock; directed proposals and destination fibers; guarded reduction; histories/lineages; bounded collective organizations; task-relative observers; internal measurement and learning. It adds a controlled cross-phenomenon composition:

`semantic-4 persistent source → period-two history/phase → directed transport → destination occupancy/fiber → reducer or exclusion → detector record`.

The same semantic/topological guard that supported earlier matter-like persistence now supplies an exact `6/8` retention and `8/8` birth rule and, when composed with transport, an organization-specific capture interface. This connects phase, propagation, matter-like organization, interface response and observer sufficiency without asserting an external physical identity.

Historical claims remain subordinate to bytes/runners/results. T2/T3/T4 were not promoted because a stronger direct v27 witness answered the phase prerequisite. CORE11's additivity and coalescence negatives remain valid in their original apparatuses.
""")
    write("CORE12_NEW_DISCOVERIES.md",f"""# CORE12 new discoveries

1. **Transported native phase:** a one-bit arrival parity survives direction, translation, N, distance and s_reg nuisance in 4/4 locked worlds.
2. **Phase-sensitive recombination without fringes:** coherent arrivals reduce together; one-tick offset invokes target-occupancy exclusion. The neutral detector record changes even when binary occupancy does not.
3. **Exact semantic-4 local threshold:** retain iff at least six of eight corner relations exist; create iff all eight exist. Holdout: 1,536/1,536.
4. **Guarded sustained capture:** the thresholded organization removes every tested downstream train event; k=5 and equal-inventory controls transmit. Holdout: 4/4.

These are new internal laws. None is an external Rosetta validation.
""")
    write("PHASE_MODE_SEARCH.md",f"""# Phase mode search

Mechanism class 1 was the v27 semantic-4 period-two source train. It passed the prerequisite immediately, so the conditional historical attractor class was not opened. The mode is `SOURCE_SUPPORTED` and evolves `NATIVE_AFTER_T0`; it is not a closed autonomous oscillator. Rigid translated packets remain the inherited mechanism-class null: their Fourier phase is translation bookkeeping and had shown no new path interaction.

Witness discovery: 3/3. Frozen holdout: {h1['summary']['passed']}/{h1['summary']['total']}.
""")
    write("PHASE_PROPAGATION.md",f"""# Phase propagation

For detector distance `L`, baseline and off-path-sham events occur at `t=L+2j`. A stationary obstruction placed at the mouth only at preparation changes them to `t=L+1+2j`. The source remains semantic-4 and persistent, and all interarrival gaps remain two.

Operational phase is the parity class `phi=(t-L) mod 2`. It is a history coordinate of source emission, not a fitted sine or externally synthesized waveform. Scope is the pre-toroidal-return source-train sector.
""")
    write("TWO_APERTURE_PHASE_TEST.md",f"""# Two-aperture / two-path phase test

The apparatus uses two equal diagonal paths beginning at matched source mouths and converging on a common detector. It is a recombination proxy, not a full diffraction screen, because the native source train does not branch from one source into a spatial continuum.

Worlds: closed, A-only, B-only, coherent AB, B phase-shifted by a t0 mouth obstruction, off-path sham, and isolated shifted B. Coherent AB produces `s_reg=a+b` at `L+2j`. Shifted AB produces only A at those ticks, while isolated B reaches at `L+1+2j`. The law passed 4/4 frozen worlds.

There are no detector-plane peaks, nodes or fringe-spacing scaling. Status: `PHASE_SENSITIVE_TWO_PATH_REDUCER_EXCLUSION_PATTERN`, not quantum or classical-wave interference.
""")
    write("INTERFERENCE_LAW.md",f"""# Interference law adjudication

`NONADDITIVE_PATTERN`: PASS for the relational record.

`PHASE_SENSITIVE_PATTERN`: PASS.

`INTERFERENCE_SCALING_LAW`: FAIL / not present.

`WAVE_LIKE_LAW_MATCH`: NOT JUSTIFIED.

Best model: simultaneous proposals enter one destination fiber and the reducer sums s_reg/signs direction. With a one-tick offset, B proposes to a destination occupied by A at the start of the update and is excluded. A fixed center-record removal restores B in 3/3 cases; clock-only reset restores 0/3. Thus a simpler DEE mechanism explains the signal.

This is not a global claim that DEE cannot support interference. Only one prerequisite-valid phase-bearing mechanism class reached recombination; a causally distinct distributed mode would be required for a broader test.
""")
    write("PERSISTENT_ENSEMBLE_SEARCH.md",f"""# Persistent ensemble search

Three mechanism classes exhausted the preregistered budget:

1. Closed static semantic-1 arrays: failed persistence prerequisite (`APPARATUS_PREREQUISITE_MISMATCH`).
2. Closed joint semantic-4 scaffold: persisted and restored centers, but the response was an exact local guard effect, not exchange/equalization (`SIMPLER_MECHANISM_EXPLAINS_SIGNAL`).
3. Facing semantic-4 source trains: sources persisted and produced interface events, but were driven steady states and retained source coordinates (`APPARATUS_PREREQUISITE_MISMATCH` for equilibrium).

Closure: `{ens['summary']['closure']}`.
""")
    write("ENSEMBLE_CONTACT.md",f"""# Ensemble contact

The search required two systems to remain distinguishable before, during and after contact. No tested class simultaneously provided persistence, genuine exchange and relaxation of a macro coordinate. Coalescence from CORE11 was not repeated or misused as a universal negative.

The joint-scaffold response remains scientifically positive as guard-mediated organization, but it does not adjudicate intensive equalization. Facing trains provide flux but not closed relaxation.
""")
    write("THETA_DEE.md",f"""# Theta_DEE

No variable earned candidacy. Activity, support, interface events, s_reg and guard restoration did not yield a scalar that both predicted exchange direction and tended to equality while A and B survived as distinct ensembles.

Verdict: `NOT_FOUND_WITHIN_CORE12_MECHANISM_BUDGET`, not `DEE_HAS_NO_TEMPERATURE`.
""")
    write("ZEROTH_LAW_SCREEN.md",f"""# Zeroth-law screen

`NOT_JUSTIFIED`.

The prerequisite Theta_DEE did not exist, so no A–B, B–C, prospective A–C transitivity test was opened. Landauer was likewise not opened because neither an operational intensive coordinate nor a compatible cost/exchange observable was established.
""")
    write("MATTER_PROPAGATION_INTERFACE.md",f"""# Matter + propagation + interface

An existing center surrounded by at least six of eight zero-direction semantic-4 corner records is retained at every update in this sector. Against a period-two incident train, the center remains present and no event reaches the detector seven cells downstream. With five corners, with eight semantic-4 records shifted out of the guard geometry, with semantic-1 equal inventory, or with no interface, the train reaches downstream at its original cadence.

The result is organization-specific rather than inventory-specific. The exact local guard provides mechanism; the sustained absence downstream supplies the interface response. Frozen holdout: {h4['summary']['passed']}/{h4['summary']['total']}.

Observed functions: capture/occlusion. Not observed: reflected record, angular deflection, refraction-like law, phase shift through the interface or conversion mode.
""")
    write("DIMENSIONAL_OBSERVER.md",f"""# Dimensional observer

| Task | Sufficient observer in tested sector | Insufficient observer |
|---|---|---|
| phase transport | source class, route distance and parity bit; detector history | snapshot occupancy without time |
| two paths | `(tick,s_reg,direction)` at destination plus current target occupancy | binary detector occupancy |
| guard | initial-center bit plus semantic-4 corner count k | global inventory |
| interface | guard state plus downstream detector history | same-size shuffled support |

`D_substrate=3`. Effective transport is one-dimensional along a route; guard dynamics is a finite local relation. Information needed by these frozen predictors is O(1) per local update. No area law, boundary code or holographic conclusion follows.
""")
    write("ROSETTA_LADDER.md",f"""# Rosetta ladder

| Fingerprint | Highest level | Why it stops |
|---|---|---|
| parity transport | R1 internal scaling law | cadence comes from source rule; no independent external observable |
| phase-conditioned paths | R1 internal law | reducer/exclusion fully explains signal; no fringes |
| 6/8–8/8 guard | R1 exact sector law | semantic discrete threshold lacks external measurement map |
| guarded capture | R1 internal interface law | no transmission/reflection angular family or second external relation |

R2 formal external match, R3 low-parameter candidate, R4 shared map, R5 unused prediction and R6 external holdout were not reached.
""")
    write("FUNDAMENTAL_ROSETTA_CORE12.md",f"""# Fundamental Rosetta CORE12

CORE12 earned internal laws but not an external Rosetta. The richest neutral fingerprint is:

`persistent source → parity-bearing train → path geometry → target occupancy/destination fiber → reduction or exclusion → detector record`, composed with `semantic-4 neighbor count → retained interface → sustained capture`.

This fingerprint has multiple internal relations and falsifiers, but its observed outputs are already fixed by the native discrete mechanism. It offers no unused external observable with which to distinguish a physical law from generic pulsed transport plus exclusion. Accordingly no external dataset was opened and no units were calibrated.

Primary state: `{syn['primary_decision']}`. External maximum: R1 only.
""")
    negative_lines="\n".join(f"- `{n['negative_id']}` — **{n['classification']}**: {n['result']} Scope: {n['scope']}." for n in neg["negatives"])
    write("NEGATIVE_RESULTS.md",f"""# Negative results

{negative_lines}

The two pre-lock technical incidents and two invalid provisional interpretations are preserved in `INCIDENTS/`; none changes a holdout.
""")
    write("ADVERSARIAL_REVIEW.md",f"""# Adversarial review

- **Kernel drift:** none in all completed audits.
- **Post-hoc holdout tuning:** none; four locks were hashed before execution.
- **Readout artifact:** binary occupancy did hide phase sensitivity. The interpretation was invalidated; the frozen neutral record includes time, s_reg and direction.
- **Interference pareidolia:** rejected. Occupancy exclusion and destination reduction explain the full signal.
- **Interface as mere inventory:** rejected by semantic-1 equal-inventory and spatially shuffled semantic-4 controls.
- **Full scaffold narrative:** corrected. Seven corners already worked; exhaustive masks yielded the exact threshold.
- **Clock mechanism:** falsified causally (0/3 restoration); target occupancy passed (3/3).
- **Equilibrium overclaim:** avoided. Driven sources were not labeled closed equilibrium and guard restoration was not called equalization.
- **External match by name:** no external matching was attempted because the gate failed.
- **Scope inflation:** all claims are sector- and task-relative.

All final textual claims have true machine predicates in `CLAIM_LEDGER.json`.
""")
    write("FINAL_FRONTIER.md",f"""# Final frontier

## Closed here

- Source-supported period-two phase transport: confirmed.
- Phase-sensitive convergent-path record: confirmed and mechanistically reduced to occupancy/reducer.
- Spatial fringe or wave scaling for this class: not found.
- Semantic-4 local threshold and capture interface: confirmed.
- Theta_DEE within three ensemble classes: not found; zeroth/Landauer not justified.

## Single Rosetta obstacle

No confirmed internal fingerprint yet supplies an independent external observable beyond relations already fixed by the discrete shift/reducer/guard mechanism.

## What would change the model

Only a concrete new mechanism earns further internal work: (a) a distributed phase-bearing mode that can branch and recombine without target occupancy, or (b) a closed persistent ensemble with a transferable macro coordinate. This is not an automatic CORE13 recommendation.
""")
    write("EXTERNAL_VALIDATION_PROTOCOL.md",f"""# External validation protocol status

`NOT_ACTIVATED`.

No CORE12 fingerprint reached R2, so choosing an external phenomenon or dataset would be name-driven. Before external validation can begin, a future internal fingerprint must add at least one independent observable—such as prospective fringe-spacing scaling, a transmission/reflection pair under angle, or closed relaxation with a transitive intensive coordinate. Only then freeze preparation map, dimensionless translation, calibration, standard-model/null competition and unused external holdout.
""")
    append_log({"module":"report_generation","status":"COMPLETE","documents":19,"wall_seconds":time.perf_counter()-started})
    update_state(status="DOCUMENTATION_COMPLETE",last_completed_experiment="REPORT_GENERATION",next_action="final audit, manifest, compact ZIP, expediente copy")
    update_budget("finalize_package",180,"RUN"); print(json.dumps({"status":"COMPLETE","documents":19,"wall_seconds":time.perf_counter()-started},indent=2))

if __name__=="__main__":main()
