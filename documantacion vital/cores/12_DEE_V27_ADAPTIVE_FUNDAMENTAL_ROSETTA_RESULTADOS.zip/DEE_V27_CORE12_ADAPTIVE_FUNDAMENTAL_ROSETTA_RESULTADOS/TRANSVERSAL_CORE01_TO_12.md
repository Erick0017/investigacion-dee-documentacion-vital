# Transversal CORE01–12

CORE12 preserves the established chain: Q0 raw+clock; directed proposals and destination fibers; guarded reduction; histories/lineages; bounded collective organizations; task-relative observers; internal measurement and learning. It adds a controlled cross-phenomenon composition:

`semantic-4 persistent source → period-two history/phase → directed transport → destination occupancy/fiber → reducer or exclusion → detector record`.

The same semantic/topological guard that supported earlier matter-like persistence now supplies an exact `6/8` retention and `8/8` birth rule and, when composed with transport, an organization-specific capture interface. This connects phase, propagation, matter-like organization, interface response and observer sufficiency without asserting an external physical identity.

Historical claims remain subordinate to bytes/runners/results. T2/T3/T4 were not promoted because a stronger direct v27 witness answered the phase prerequisite. CORE11's additivity and coalescence negatives remain valid in their original apparatuses.
