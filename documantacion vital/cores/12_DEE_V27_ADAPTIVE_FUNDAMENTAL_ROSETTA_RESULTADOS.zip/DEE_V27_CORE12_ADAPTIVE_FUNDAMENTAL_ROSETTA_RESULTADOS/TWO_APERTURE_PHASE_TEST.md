# Two-aperture / two-path phase test

The apparatus uses two equal diagonal paths beginning at matched source mouths and converging on a common detector. It is a recombination proxy, not a full diffraction screen, because the native source train does not branch from one source into a spatial continuum.

Worlds: closed, A-only, B-only, coherent AB, B phase-shifted by a t0 mouth obstruction, off-path sham, and isolated shifted B. Coherent AB produces `s_reg=a+b` at `L+2j`. Shifted AB produces only A at those ticks, while isolated B reaches at `L+1+2j`. The law passed 4/4 frozen worlds.

There are no detector-plane peaks, nodes or fringe-spacing scaling. Status: `PHASE_SENSITIVE_TWO_PATH_REDUCER_EXCLUSION_PATTERN`, not quantum or classical-wave interference.
