# Zeroth-law screen

`NOT_JUSTIFIED`.

The prerequisite Theta_DEE did not exist, so no A–B, B–C, prospective A–C transitivity test was opened. Landauer was likewise not opened because neither an operational intensive coordinate nor a compatible cost/exchange observable was established.
