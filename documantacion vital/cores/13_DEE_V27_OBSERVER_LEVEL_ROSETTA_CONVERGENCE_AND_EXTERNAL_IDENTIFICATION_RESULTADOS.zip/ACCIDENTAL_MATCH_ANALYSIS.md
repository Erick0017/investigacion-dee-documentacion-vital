# Análisis de coincidencia accidental

Discovery comparó 8 observers, 3 clusters neutrales y hasta 4 familias externas. El producto 8×3×4=96 es sólo un inventario de flexibilidad, no 96 pruebas independientes ni un p-value.

Contra el ajuste accidental interno: el observador se congeló antes de mundos nuevos; H01 pasó 10/10, H02 6/6 y dos nulls numéricos quedaron lejos de cero. Contra la identificación accidental externa: la huella de detector con recuperación finita es común a varias tecnologías, y no hubo dataset reservado. Por ello el riesgo residual de escoger la *clase física exacta* es moderado-alto.

No se afirma “imposible por azar”. La forma de reducir el riesgo es una tercera relación externa preregistrada bajo el mismo `tau`, idealmente una curva de dos pulsos con amplitud y eficiencia temporal, más réplica independiente.
