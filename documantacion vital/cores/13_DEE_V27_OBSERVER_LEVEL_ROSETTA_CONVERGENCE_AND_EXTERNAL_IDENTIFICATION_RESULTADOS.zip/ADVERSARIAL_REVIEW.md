# Revisión adversarial

1. **Selección post-hoc:** ocho observers y tres fingerprints fueron discovery; el costo está registrado. H01/H02 usaron mundos nuevos.
2. **Cambio de observer:** ninguno después de H01. H02 reutilizó las mismas coordenadas.
3. **Leakage:** las predicciones exactas se escribieron en locks antes de ejecutar los mundos correspondientes.
4. **Null simple:** caminos independientes, paridad permutada, evento binario e inventario fallan aspectos distintos.
5. **Calibración:** una escala `tau`; no se ajustó por geometría. La equivalencia `voxel/tick → c` no cuenta por sí sola como evidencia.
6. **Pile-up universal:** falso; depende del detector/procesador. La candidata se restringe a detectores integradores/energy-resolving compatibles.
7. **Identidad física:** no demostrada. El mismo fingerprint aparece en aparatos no ópticos.
8. **Unused external:** ausente y declarado, no reconstruido retrospectivamente.
9. **Incidentes técnicos:** dos errores de bootstrap/schema ocurrieron antes de locks/datos relevantes, están preservados y no alteran resultados.

Conclusión adversarial: R3 es defendible como mapa de aparato; R4–R6 no lo son.
