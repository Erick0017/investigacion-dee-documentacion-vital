# Veredicto ejecutivo — CORE13

Estado máximo: **STRONG_ROSETTA_CANDIDATE** (`R3_SHARED_LOW_PARAMETER_MAP`).

La matriz CORE01–12 reunió 23 fenómenos y comparó ocho familias de observador. El observador acotado mínimo mejor puntuado fue `M_EVENT_CAUSAL`: siete coordenadas relacionales/locales explican 11 fenómenos sin leer el estado 3D completo. Su ley congelada pasó 10/10 mundos de ruta/fase/interfaz y una predicción posterior pasó 6/6 mundos singleton. El modelo causal obtuvo RMSE 0; los nulls de camino independiente y paridad permutada obtuvieron 1220.411 y 1618.840.

La identificación externa más cercana es una **cadena de medición pulsada por tiempo de vuelo con detector de resolución finita**. El mismo mapa de una escala temporal cubre retardo de trayectoria, pérdida del segundo evento dentro de la ventana de respuesta y pile-up coincidente. Esto es una correspondencia operacional de aparato, no prueba de que un portador DEE sea un fotón ni validación de física fundamental.

No se abrió un dato externo reservado. Por ello no se promueve `MULTI_RELATION_ROSETTA` ni `EXTERNAL_ROSETTA_VALIDATED`. El obstáculo actual es la no-identificabilidad externa: varios sistemas de eventos con recuperación finita comparten la misma huella.
