# Correspondencia externa

La búsqueda comenzó sólo después del lock neutral `C13E00`. La clase más cercana fue la cadena pulso–ruta–detector de resolución finita.

- [NISTIR 7117](https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir7117.pdf) da el protocolo pulsado TOF y `t=2d/c`.
- [Pommé et al., *Uncertainty of nuclear counting*](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=917522) distingue pile-up, pérdida del segundo pulso y registro compuesto.
- [Taguchi et al., modelo analítico de pulse pile-up](https://pmc.ncbi.nlm.nih.gov/articles/PMC2917451/) modela detector no paralizable con tiempo de resolución finito.
- [Ware et al., NIST](https://www.nist.gov/publications/calibrating-photon-counting-detectors-high-accuracy-background-and-deadtime-issues-0) documenta que calibrar APD exige tratar timing y deadtime.

Nivel: `OBSERVER_LEVEL_FORMAL_EXTERNAL_MATCH`, integrado en un candidato R3 por compartir mapa con dos relaciones independientes. No hubo descarga de dataset, error externo fila a fila ni réplica de laboratorio. El resultado no identifica “luz” como ontología DEE.
