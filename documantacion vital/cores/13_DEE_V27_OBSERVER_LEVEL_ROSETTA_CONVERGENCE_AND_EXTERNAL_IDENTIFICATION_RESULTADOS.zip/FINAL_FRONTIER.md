# Frontera final

La búsqueda amplia se cierra. La única siguiente investigación justificada es una validación profunda del candidato `MAP_EVENT_TO_PULSED_DETECTOR_V1`:

1. elegir antes de datos un detector físico y protocolo de dos pulsos;
2. calibrar `tau` una vez;
3. predecir curvas de eficiencia del segundo pulso y amplitud compuesta en delays reservados;
4. comparar contra modelo estándar del detector y null refractario genérico;
5. replicar en segundo detector/laboratorio.

Hasta entonces, el obstáculo es `OBSERVER_UNDERDETERMINED / INSUFFICIENT_EXTERNAL_OBSERVABLE`, no ausencia de ley interna. No se propone CORE14 automático.
