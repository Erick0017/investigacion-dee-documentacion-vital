# Informe final — CORE13

## Respuestas obligatorias

1. **Convergencia:** 11 de 23 fenómenos indexados caen dentro del dominio explicativo declarado de `M_EVENT_CAUSAL`.
2. **Observador mínimo:** `M_EVENT_CAUSAL`, mínimo sólo dentro de las ocho familias comparadas; no es un teorema global de minimalidad.
3. **Información descartable:** el volumen 3D completo, inventario remoto, clocks fuera de ruta y microestado no incidente. Se conservan ruta, orden de eventos y estado local del detector/interfaz.
4. **Clase externa más cercana:** medición pulsada de tiempo de vuelo con detector de recuperación/resolución finita.
5. **Tipo de match:** ley operacional y orden causal; no identidad de nombre ni microdinámica.
6. **Parámetros libres:** una escala temporal `tau`; las amplitudes se comparan como razones normalizadas y la velocidad externa pertenece al protocolo elegido.
7. **Reutilización:** sí; el mismo mapa cubre retardo, exclusión temporal y registro compuesto.
8. **Competidores:** supera los nulls internos congelados; externamente permanece no único frente a otros sistemas refractarios o procesadores de pulsos.
9. **Nuevo mundo DEE:** sí, H01 pasó 10/10 y H02 pasó 6/6.
10. **Observable externo no usado:** no probado.
11. **Tercera pieza:** la relación singleton de resolución fue predicha internamente sin recalibración; no cuenta como tercera pieza externa.
12. **Riesgo accidental:** moderado-alto para identificación física, pese a riesgo bajo para la ley interna; no se asigna probabilidad espuria.
13. **ROSETTA_CANDIDATE_FOUND:** sí, como candidato de aparato.
14. **STRONG_ROSETTA_CANDIDATE:** sí, por dos relaciones independientes con un mapa de baja dimensión.
15. **MULTI_RELATION_ROSETTA:** no; falta una tercera predicción externa reservada.
16. **EXTERNAL_ROSETTA_VALIDATED:** no.

## Cadena causal confirmada

`fuente → ruta → propuesta al destino → ocupación/fibra → reductor o guarda → registro`.

La proyección binaria falla: no distingue suma, exclusión ni captura. La variable decisiva no es “presencia”, sino evento + historia local del destino.

## Cierre

CORE13 detiene la búsqueda amplia. La única continuación justificada es validar profundamente `MAP_EVENT_TO_PULSED_DETECTOR_V1` con un protocolo físico preregistrado y datos de dos pulsos reservados.
