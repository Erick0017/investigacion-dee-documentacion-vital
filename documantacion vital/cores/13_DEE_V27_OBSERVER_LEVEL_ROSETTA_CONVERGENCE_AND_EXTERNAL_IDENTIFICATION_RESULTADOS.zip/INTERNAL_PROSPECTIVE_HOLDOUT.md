# Holdouts internos prospectivos

## H01 — observer compartido

Lock SHA-256: `4e78472b42989f1f7c36f84eed6fe85ba3db9cac77c9d63f3b88fae419f16bf3`. Seis mundos de delay variaron N, traslación, ejes firmados, `s_reg` y delta 4–9; cuatro mundos de interfaz variaron k=5/6/7 y organización barajada. Resultado: 10/10 exactos, RMSE causal 0.

## H02 — intervalo resolutivo singleton

Lock SHA-256: `a215c86323c01f2a8cee227034773e67e20b8254eaeb86e9065f443c8b0c804a`. Fue congelado después de identificar la familia externa, antes de ejecutar los mundos. Predicción: delta 0 suma; delta 1 pierde el segundo evento; delta ≥2 resuelve ambos. Resultado: 6/6 exactos.

H02 elimina la recurrencia periodo‑2 como explicación necesaria, pero es evidencia DEE interna; no sustituye un holdout externo.
