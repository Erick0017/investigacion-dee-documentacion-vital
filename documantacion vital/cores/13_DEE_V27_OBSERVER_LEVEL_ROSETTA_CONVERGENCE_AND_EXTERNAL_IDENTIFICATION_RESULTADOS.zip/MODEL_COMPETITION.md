# Competencia de modelos

| Modelo | Evidencia interna | Resultado |
|---|---:|---|
| `M_EVENT_CAUSAL` | RMSE 0.0; 16/16 mundos | ganador |
| caminos independientes | RMSE 1220.411 | falla reducción/exclusión |
| paridad permutada | RMSE 1618.840 | falla la clase temporal |
| evento binario | sin amplitud/dirección/historia | insuficiente |
| inventario | k=6 organizado y k=6 barajado divergen | insuficiente |

Externamente, el detector pulsado TOF cubre ruta y respuesta finita. Un procesador genérico cubre sólo la respuesta; un sistema refractario sólo la exclusión; una interfaz absorbente sólo la captura. La victoria externa es por cobertura, no por unicidad.
