# Resultados negativos y límites

- La ocupación binaria no es observador suficiente.
- Caminos independientes no explican el reductor/exclusión.
- Inventario no explica captura: la organización local importa.
- No se encontró un observador reducido global de toda `F_DEE`.
- El umbral guardado/captura no obtuvo correspondencia externa compartida.
- La candidata externa no es única.
- No existe tercera predicción externa reservada.
- No hay validación por dataset ni réplica independiente.
- No se deriva fotón, luz fundamental, teoría cuántica ni ontología material.
