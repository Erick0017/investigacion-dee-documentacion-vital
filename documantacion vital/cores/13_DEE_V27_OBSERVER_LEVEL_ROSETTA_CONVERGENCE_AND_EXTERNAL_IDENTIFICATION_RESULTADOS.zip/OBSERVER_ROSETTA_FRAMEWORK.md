# CORE13 — marco de evidencia

Kernel v27 inmutable. `M_EVENT_CAUSAL` observa longitud de ruta, tick y registro local (`s_reg`, dirección), relación temporal, ocupación previa del destino y cuenta de guardas. No identifica ontologías microscópicas externas.

## Definición

Para la tarea, dos mundos son equivalentes si producen la misma secuencia de registros bajo las mismas rutas e intervenciones. `M_EVENT_CAUSAL` no intenta cerrar toda `F_DEE`; cierra las respuestas probadas.

## Selección

Se puntuaron ocho observadores como `2 × relaciones - 0.35 × costo - fallos explícitos`. `M_EVENT_CAUSAL` obtuvo 18.55; `M_REL`, 13.85; Q0, 11.0 pero fue retenido como baseline trivial no reducido. La selección fue discovery y quedó congelada antes de H01.

## Traducción

La unidad comparada es preparación → propagación → interacción con detector → registro. El mapa nunca afirma equivalencia de microestados.
