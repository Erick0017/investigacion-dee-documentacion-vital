# Candidato Rosetta primario

## `MAP_EVENT_TO_PULSED_DETECTOR_V1`

Estado: `STRONG_ROSETTA_CANDIDATE` / R3.

Mapa congelado:

- `t_externo / tau = tick_DEE`;
- `d_externo / (v_externo tau) = L_DEE`;
- amplitud mediante razones normalizadas de suma;
- evento registrado/no registrado ↔ propuesta aceptada/excluida en el destino.

Relaciones compartidas:

1. retardo proporcional a longitud de ruta;
2. evento posterior dentro de una ventana finita no produce segundo registro;
3. eventos coincidentes producen un registro compuesto en el régimen no saturado.

`tau` es el único parámetro libre. `v_externo` pertenece al protocolo físico y no se ajusta por caso. El umbral guardado 6/8 y la captura sostenida no tienen todavía una segunda ley externa bajo el mismo mapa.

La candidata identifica una arquitectura de medición, no una partícula ni una ontología. Su familia externa sigue siendo no única.
