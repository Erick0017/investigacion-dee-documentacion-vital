$ErrorActionPreference = "Stop"
$Python = "D:\Descargas\ANACONDA MINICONDA\python.exe"
if (-not (Test-Path -LiteralPath $Python)) { throw "CPython 3.13 not found at $Python" }
& $Python -I -B ".\RUNNERS\run_core13_observer_rosetta.py"
if ($LASTEXITCODE -ne 0) { throw "CORE13 reproduction failed with exit code $LASTEXITCODE" }
