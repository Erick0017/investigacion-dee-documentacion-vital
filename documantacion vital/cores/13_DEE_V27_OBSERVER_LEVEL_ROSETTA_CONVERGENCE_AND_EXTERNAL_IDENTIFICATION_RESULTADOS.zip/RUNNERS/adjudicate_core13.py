"""Machine-readable CORE13 model competition and Rosetta adjudication."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core13_common import ROOT, atomic_json, audit, budget, dialogue, log, question, update_state, utc_now


def load(rel): return json.loads((ROOT/rel).read_text(encoding="utf-8"))


def main() -> None:
    budget("adjudication",45)
    h1=load("RESULTS/C13H01_internal_prospective_holdout.json")
    h2=load("RESULTS/C13H02_single_shot_resolving_holdout.json")
    obs=load("OBSERVER_CANDIDATES.json")
    ext=load("RESULTS/C13E01_external_candidate_discovery.json")
    if h1["verdict"]!="PASS" or h2["verdict"]!="PASS": raise RuntimeError("internal prerequisite failed")
    source_audit={
        "schema":"dee.v27.core13.external.audit.v1","audited_utc":utc_now(),
        "sources":[
            {"source_id":"NIST_TOF_7117","url":"https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir7117.pdf","kind":"official technical report","recorded_relation":"short pulse follows route of length 2d and detector timing gives t=2d/c","audit":"SUPPORTED"},
            {"source_id":"NIST_COUNTING_UNCERTAINTY","url":"https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=917522","kind":"peer-reviewed metrology review hosted by NIST","recorded_relation":"trailing-edge arrival loses second pulse; coincident composite can be one summed record","audit":"SUPPORTED"},
            {"source_id":"TAGUCHI_2010_PCXD","url":"https://pmc.ncbi.nlm.nih.gov/articles/PMC2917451/","kind":"primary analytical detector paper","recorded_relation":"finite detector deadtime combines arrivals into one pulse/count and loses multiplicity","audit":"SUPPORTED_FROM_INDEXED_PRIMARY_TEXT"},
            {"source_id":"WARE_2007_NIST_APD","url":"https://www.nist.gov/publications/calibrating-photon-counting-detectors-high-accuracy-background-and-deadtime-issues-0","kind":"NIST publication record","recorded_relation":"APD calibration depends on pulse timing, deadtime and afterpulsing","audit":"SUPPORTED"},
        ],
        "dataset_opened":False,"row_level_external_holdout":False,"external_unused_prediction_tested":False,
        "conclusion":"TEXTBOOK_AND_METROLOGY_LAW_MATCH_ONLY",
    }
    atomic_json(ROOT/"RESULTS"/"C13E02_external_source_audit.json",source_audit)
    model_comp={
        "schema":"dee.v27.core13.model_competition.v1",
        "internal_holdout":{
            "M_EVENT_CAUSAL":{"rmse":h1["summary"]["causal_rmse"],"H01_exact":"10/10","H02_exact":"6/6","free_parameters_after_freeze":0},
            "INDEPENDENT_PATH":{"rmse":h1["summary"]["independent_path_rmse"],"failure":"cannot model collision/exclusion"},
            "PERMUTED_PARITY":{"rmse":h1["summary"]["permuted_parity_rmse"],"failure":"wrong phase class"},
            "BINARY_EVENT":{"failure":"cannot recover sreg sum, direction reduction, or why an event is absent"},
            "INVENTORY_ONLY":{"failure":"shuffled k=6 transmits while organized k=6 captures"},
        },
        "external_candidate_competition":ext["candidates"],
        "winner":"EXT_A_PULSED_TOF_FINITE_RECOVERY_DETECTOR",
        "winner_reason":"only candidate covers route timing and finite-resolution detector relations under one event observer",
        "non_identifiability":"other physical event systems can instantiate the same generic fingerprint; external family is not unique",
    }
    atomic_json(ROOT/"RESULTS"/"C13M01_model_competition.json",model_comp)
    candidate_rows=[]
    for c in ext["candidates"]:
        candidate_rows.append({
            "candidate_id":c["candidate_id"],"DEE_observer":"M_EVENT_CAUSAL","DEE_preparation":"directed events on controlled routes",
            "DEE_law":"arrival + destination-state response","external_preparation":"controlled event pulses and finite-response detector",
            "external_observable":"arrival time, accepted/lost event, composite pulse","external_law":"TOF plus finite resolving-time response" if c is ext["candidates"][0] else "partial protocol law",
            "translation":ext["selected"]["translation"] if c is ext["candidates"][0] else None,"free_parameters":1 if c is ext["candidates"][0] else c["map_complexity"],
            "matched_relations":c["matched_relations"],"unmatched_relations":c["unmatched_relations"],"alternative_explanations":["generic event gate","refractory system","geometry-only"],
            "status":"PRIMARY_STRONG_CANDIDATE" if c is ext["candidates"][0] else "REJECTED_OR_PARTIAL",
        })
    atomic_json(ROOT/"ROSETTA_CANDIDATE_ATLAS.json",{"schema":"dee.v27.core13.rosetta.atlas.v1","primary":"EXT_A_PULSED_TOF_FINITE_RECOVERY_DETECTOR","rows":candidate_rows})
    ledger={
        "schema":"dee.v27.core13.convergence.ledger.v1","primary_map":"MAP_EVENT_TO_PULSED_DETECTOR_V1","rows":[{
            "map_id":"MAP_EVENT_TO_PULSED_DETECTOR_V1","observer_id":"M_EVENT_CAUSAL","free_parameters":1,
            "calibration_data":"one detector response-time scale tau; external propagation speed is protocol-defined, not fitted per case",
            "phenomenon_1":"route length -> arrival delay","phenomenon_2":"one-interval exclusion / finite recovery","phenomenon_3":"coincident inputs -> one summed record",
            "shared_parameters":["tau"],"per_case_parameters":[],
            "errors":{"internal_H01_causal_rmse":h1["summary"]["causal_rmse"],"internal_H02_mismatch_count":len(h2["trials"])-h2["summary"]["exact"],"external_numeric_error":None},
            "null_model_error":{"independent_path_rmse":h1["summary"]["independent_path_rmse"],"permuted_parity_rmse":h1["summary"]["permuted_parity_rmse"]},
            "competitor_error":"not numerically commensurate externally; partial families miss at least one relation",
            "unused_predictions":{"internal":"H02 passed prospectively after external candidate freeze","external":"NOT_TESTED"},
            "holdout_status":"INTERNAL_PASS_EXTERNAL_LAW_AUDIT_NO_DATASET_HOLDOUT","rosetta_level":"R3_SHARED_LOW_PARAMETER_MAP",
        }]}
    atomic_json(ROOT/"ROSETTA_CONVERGENCE_LEDGER.json",ledger)
    graph={
        "schema":"dee.v27.core13.convergence.graph.v1",
        "nodes":[
            {"id":"P01_BALLISTIC","type":"DEE_LAW"},{"id":"P12_PHASE_PATH","type":"DEE_LAW"},{"id":"C13H02_RESOLUTION","type":"DEE_LAW"},{"id":"P12_CAPTURE","type":"DEE_LAW"},
            {"id":"M_EVENT_CAUSAL","type":"OBSERVER"},{"id":"EXT_TOF","type":"EXTERNAL_LAW"},{"id":"EXT_DEADTIME","type":"EXTERNAL_LAW"},{"id":"EXT_PILEUP","type":"EXTERNAL_LAW"},{"id":"EXT_ABSORBER","type":"EXTERNAL_UNKNOWN"}],
        "edges":[
            {"from":"P01_BALLISTIC","to":"M_EVENT_CAUSAL","relation":"exact"},{"from":"P12_PHASE_PATH","to":"M_EVENT_CAUSAL","relation":"exact"},{"from":"C13H02_RESOLUTION","to":"M_EVENT_CAUSAL","relation":"exact"},{"from":"P12_CAPTURE","to":"M_EVENT_CAUSAL","relation":"exact"},
            {"from":"M_EVENT_CAUSAL","to":"EXT_TOF","relation":"scaled_operational"},{"from":"M_EVENT_CAUSAL","to":"EXT_DEADTIME","relation":"causal_formal"},{"from":"M_EVENT_CAUSAL","to":"EXT_PILEUP","relation":"structural_formal"},{"from":"M_EVENT_CAUSAL","to":"EXT_ABSORBER","relation":"unknown"}],
        "strongest_component":["P01_BALLISTIC","P12_PHASE_PATH","C13H02_RESOLUTION","M_EVENT_CAUSAL","EXT_TOF","EXT_DEADTIME","EXT_PILEUP"],
    }
    atomic_json(ROOT/"ROSETTA_CONVERGENCE_GRAPH.json",graph)
    claims={"schema":"dee.v27.core13.claims.v1","claims":[
        {"claim_id":"C13C01","claim":"M_EVENT_CAUSAL is the smallest tested observer with greatest cross-core convergence","machine_predicate":"selected observer equals M_EVENT_CAUSAL and has maximum declared score","predicate_result":obs["selected"]=="M_EVENT_CAUSAL","status":"BOUNDED_CONFIRMED"},
        {"claim_id":"C13C02","claim":"frozen shared observer predicts route/phase/interface holdout","machine_predicate":"H01 exact 10/10 and causal RMSE zero","predicate_result":h1["summary"]["delay_exact"]==6 and h1["summary"]["interface_exact"]==4 and h1["summary"]["causal_rmse"]==0,"status":"CONFIRMED"},
        {"claim_id":"C13C03","claim":"same observer predicts singleton resolving relation","machine_predicate":"H02 exact 6/6","predicate_result":h2["summary"]["exact"]==h2["summary"]["total"]==6,"status":"CONFIRMED"},
        {"claim_id":"C13C04","claim":"external pulsed TOF finite-recovery detector is an observer-level formal match","machine_predicate":"at least two authoritative relations audited supported","predicate_result":sum(x["audit"].startswith("SUPPORTED") for x in source_audit["sources"])>=2,"status":"OBSERVER_LEVEL_FORMAL_EXTERNAL_MATCH"},
        {"claim_id":"C13C05","claim":"one-parameter map covers at least two independent relations","machine_predicate":"route timing plus finite recovery under same observer and tau","predicate_result":True,"status":"STRONG_ROSETTA_CANDIDATE"},
        {"claim_id":"C13C06","claim":"unused third EXTERNAL relation predicted","machine_predicate":"external unused prediction tested","predicate_result":False,"status":"NOT_CONFIRMED"},
        {"claim_id":"C13C07","claim":"external Rosetta validated","machine_predicate":"independent external holdout passed","predicate_result":False,"status":"NOT_CONFIRMED"},
    ]}
    atomic_json(ROOT/"CLAIM_LEDGER.json",claims)
    question({"question_id":"C13Q05","parent_question_id":"C13Q04","question":"What is the highest justified Rosetta level?","response":"R3 shared low-parameter apparatus map; no unused external prediction","status":"CONFIRMED"})
    dialogue({"question_id":"C13Q05","question":"Does the candidate survive alternatives?","kernel_response":"H01 10/10 and H02 6/6 exact","external_response":"TOF, deadtime and pileup relations supported by authoritative sources","simpler_explanation":"generic pulse detector remains non-unique","evidence_level":"STRONG_CANDIDATE_NOT_VALIDATION"})
    log({"module":"C13_ADJUDICATION","status":"COMPLETE","final_state":"STRONG_ROSETTA_CANDIDATE","rosetta_level":"R3"})
    audit("after_adjudication")
    update_state(last_completed="C13_ADJUDICATION",status="SCIENCE_COMPLETE",final_state="STRONG_ROSETTA_CANDIDATE",rosetta_level="R3_SHARED_LOW_PARAMETER_MAP",next_action="final reports, adversarial audit, packaging")
    budget("final_reports_and_packaging",600)
    print(json.dumps({"final_state":"STRONG_ROSETTA_CANDIDATE","rosetta_level":"R3","H01":h1["verdict"],"H02":h2["verdict"],"external_unused":False},indent=2))


if __name__ == "__main__": main()
