"""Generate reports, validate, package, and register CORE13 without altering CORE01-12."""
from __future__ import annotations
import hashlib, json, os, shutil, sys, time, zipfile
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core13_common import ROOT, TESTS, PARENTS, atomic_json, atomic_text, audit, budget, log, sha256_file, update_state, utc_now

ZIP_NAME="13_DEE_V27_OBSERVER_LEVEL_ROSETTA_CONVERGENCE_AND_EXTERNAL_IDENTIFICATION_RESULTADOS.zip"
EXP=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE"; CORE=EXP/"CORE"; EXTRA=EXP/"EXTRA"

def load(rel): return json.loads((ROOT/rel).read_text(encoding="utf-8"))
def write_docs():
 h1=load("RESULTS/C13H01_internal_prospective_holdout.json"); h2=load("RESULTS/C13H02_single_shot_resolving_holdout.json")
 indep=h1["summary"]["independent_path_rmse"]; perm=h1["summary"]["permuted_parity_rmse"]
 common="""# CORE13 — marco de evidencia

Kernel v27 inmutable. `M_EVENT_CAUSAL` observa longitud de ruta, tick y registro local (`s_reg`, dirección), relación temporal, ocupación previa del destino y cuenta de guardas. No identifica ontologías microscópicas externas.
"""
 docs={
 "EXECUTIVE_VERDICT.md":f"""# Veredicto ejecutivo — CORE13

Estado máximo: **STRONG_ROSETTA_CANDIDATE** (`R3_SHARED_LOW_PARAMETER_MAP`).

La matriz CORE01–12 reunió 23 fenómenos y comparó ocho familias de observador. El observador acotado mínimo mejor puntuado fue `M_EVENT_CAUSAL`: siete coordenadas relacionales/locales explican 11 fenómenos sin leer el estado 3D completo. Su ley congelada pasó 10/10 mundos de ruta/fase/interfaz y una predicción posterior pasó 6/6 mundos singleton. El modelo causal obtuvo RMSE 0; los nulls de camino independiente y paridad permutada obtuvieron {indep:.3f} y {perm:.3f}.

La identificación externa más cercana es una **cadena de medición pulsada por tiempo de vuelo con detector de resolución finita**. El mismo mapa de una escala temporal cubre retardo de trayectoria, pérdida del segundo evento dentro de la ventana de respuesta y pile-up coincidente. Esto es una correspondencia operacional de aparato, no prueba de que un portador DEE sea un fotón ni validación de física fundamental.

No se abrió un dato externo reservado. Por ello no se promueve `MULTI_RELATION_ROSETTA` ni `EXTERNAL_ROSETTA_VALIDATED`. El obstáculo actual es la no-identificabilidad externa: varios sistemas de eventos con recuperación finita comparten la misma huella.
""",
 "FINAL_REPORT.md":f"""# Informe final — CORE13

## Respuestas obligatorias

1. **Convergencia:** 11 de 23 fenómenos indexados caen dentro del dominio explicativo declarado de `M_EVENT_CAUSAL`.
2. **Observador mínimo:** `M_EVENT_CAUSAL`, mínimo sólo dentro de las ocho familias comparadas; no es un teorema global de minimalidad.
3. **Información descartable:** el volumen 3D completo, inventario remoto, clocks fuera de ruta y microestado no incidente. Se conservan ruta, orden de eventos y estado local del detector/interfaz.
4. **Clase externa más cercana:** medición pulsada de tiempo de vuelo con detector de recuperación/resolución finita.
5. **Tipo de match:** ley operacional y orden causal; no identidad de nombre ni microdinámica.
6. **Parámetros libres:** una escala temporal `tau`; las amplitudes se comparan como razones normalizadas y la velocidad externa pertenece al protocolo elegido.
7. **Reutilización:** sí; el mismo mapa cubre retardo, exclusión temporal y registro compuesto.
8. **Competidores:** supera los nulls internos congelados; externamente permanece no único frente a otros sistemas refractarios o procesadores de pulsos.
9. **Nuevo mundo DEE:** sí, H01 pasó 10/10 y H02 pasó 6/6.
10. **Observable externo no usado:** no probado.
11. **Tercera pieza:** la relación singleton de resolución fue predicha internamente sin recalibración; no cuenta como tercera pieza externa.
12. **Riesgo accidental:** moderado-alto para identificación física, pese a riesgo bajo para la ley interna; no se asigna probabilidad espuria.
13. **ROSETTA_CANDIDATE_FOUND:** sí, como candidato de aparato.
14. **STRONG_ROSETTA_CANDIDATE:** sí, por dos relaciones independientes con un mapa de baja dimensión.
15. **MULTI_RELATION_ROSETTA:** no; falta una tercera predicción externa reservada.
16. **EXTERNAL_ROSETTA_VALIDATED:** no.

## Cadena causal confirmada

`fuente → ruta → propuesta al destino → ocupación/fibra → reductor o guarda → registro`.

La proyección binaria falla: no distingue suma, exclusión ni captura. La variable decisiva no es “presencia”, sino evento + historia local del destino.

## Cierre

CORE13 detiene la búsqueda amplia. La única continuación justificada es validar profundamente `MAP_EVENT_TO_PULSED_DETECTOR_V1` con un protocolo físico preregistrado y datos de dos pulsos reservados.
""",
 "TRANSVERSAL_CORE01_TO_13.md":"""# Transversal CORE01–13

CORE01 fijó transporte y reductor; CORE03–04 añadieron organización e historia; CORE05 hizo operacionales observador y medición; CORE06–10 mostraron memoria, materia, transferencia y acoplamiento; CORE11 separó aditividad geométrica de interferencia; CORE12 encontró fase transportada, exclusión/reducción condicionada por ruta y captura guardada. CORE13 no añade una ontología: demuestra que once de esos resultados se comprimen en un observador de eventos de ruta y destino.

La convergencia no es global. Basins, aprendizaje completo, termodinámica y cierre Q0 quedan fuera del observador seleccionado. La ganancia es sectorial: transporte + fase temporal + fibras + interfaz + detector.

El nuevo resultado de CORE13 es metodológico y experimental: una proyección local-relacional predice nuevos mundos sin reconstruir Q0 y se compara operacionalmente con una clase real de instrumentos.
""",
 "OBSERVER_ROSETTA_FRAMEWORK.md":common+"""
## Definición

Para la tarea, dos mundos son equivalentes si producen la misma secuencia de registros bajo las mismas rutas e intervenciones. `M_EVENT_CAUSAL` no intenta cerrar toda `F_DEE`; cierra las respuestas probadas.

## Selección

Se puntuaron ocho observadores como `2 × relaciones - 0.35 × costo - fallos explícitos`. `M_EVENT_CAUSAL` obtuvo 18.55; `M_REL`, 13.85; Q0, 11.0 pero fue retenido como baseline trivial no reducido. La selección fue discovery y quedó congelada antes de H01.

## Traducción

La unidad comparada es preparación → propagación → interacción con detector → registro. El mapa nunca afirma equivalencia de microestados.
""",
 "PRIMARY_ROSETTA_CANDIDATE.md":"""# Candidato Rosetta primario

## `MAP_EVENT_TO_PULSED_DETECTOR_V1`

Estado: `STRONG_ROSETTA_CANDIDATE` / R3.

Mapa congelado:

- `t_externo / tau = tick_DEE`;
- `d_externo / (v_externo tau) = L_DEE`;
- amplitud mediante razones normalizadas de suma;
- evento registrado/no registrado ↔ propuesta aceptada/excluida en el destino.

Relaciones compartidas:

1. retardo proporcional a longitud de ruta;
2. evento posterior dentro de una ventana finita no produce segundo registro;
3. eventos coincidentes producen un registro compuesto en el régimen no saturado.

`tau` es el único parámetro libre. `v_externo` pertenece al protocolo físico y no se ajusta por caso. El umbral guardado 6/8 y la captura sostenida no tienen todavía una segunda ley externa bajo el mismo mapa.

La candidata identifica una arquitectura de medición, no una partícula ni una ontología. Su familia externa sigue siendo no única.
""",
 "ACCIDENTAL_MATCH_ANALYSIS.md":"""# Análisis de coincidencia accidental

Discovery comparó 8 observers, 3 clusters neutrales y hasta 4 familias externas. El producto 8×3×4=96 es sólo un inventario de flexibilidad, no 96 pruebas independientes ni un p-value.

Contra el ajuste accidental interno: el observador se congeló antes de mundos nuevos; H01 pasó 10/10, H02 6/6 y dos nulls numéricos quedaron lejos de cero. Contra la identificación accidental externa: la huella de detector con recuperación finita es común a varias tecnologías, y no hubo dataset reservado. Por ello el riesgo residual de escoger la *clase física exacta* es moderado-alto.

No se afirma “imposible por azar”. La forma de reducir el riesgo es una tercera relación externa preregistrada bajo el mismo `tau`, idealmente una curva de dos pulsos con amplitud y eficiencia temporal, más réplica independiente.
""",
 "MODEL_COMPETITION.md":f"""# Competencia de modelos

| Modelo | Evidencia interna | Resultado |
|---|---:|---|
| `M_EVENT_CAUSAL` | RMSE {h1['summary']['causal_rmse']:.1f}; 16/16 mundos | ganador |
| caminos independientes | RMSE {indep:.3f} | falla reducción/exclusión |
| paridad permutada | RMSE {perm:.3f} | falla la clase temporal |
| evento binario | sin amplitud/dirección/historia | insuficiente |
| inventario | k=6 organizado y k=6 barajado divergen | insuficiente |

Externamente, el detector pulsado TOF cubre ruta y respuesta finita. Un procesador genérico cubre sólo la respuesta; un sistema refractario sólo la exclusión; una interfaz absorbente sólo la captura. La victoria externa es por cobertura, no por unicidad.
""",
 "INTERNAL_PROSPECTIVE_HOLDOUT.md":f"""# Holdouts internos prospectivos

## H01 — observer compartido

Lock SHA-256: `{h1['lock_sha256']}`. Seis mundos de delay variaron N, traslación, ejes firmados, `s_reg` y delta 4–9; cuatro mundos de interfaz variaron k=5/6/7 y organización barajada. Resultado: 10/10 exactos, RMSE causal 0.

## H02 — intervalo resolutivo singleton

Lock SHA-256: `{h2['lock_sha256']}`. Fue congelado después de identificar la familia externa, antes de ejecutar los mundos. Predicción: delta 0 suma; delta 1 pierde el segundo evento; delta ≥2 resuelve ambos. Resultado: 6/6 exactos.

H02 elimina la recurrencia periodo‑2 como explicación necesaria, pero es evidencia DEE interna; no sustituye un holdout externo.
""",
 "EXTERNAL_MATCH.md":"""# Correspondencia externa

La búsqueda comenzó sólo después del lock neutral `C13E00`. La clase más cercana fue la cadena pulso–ruta–detector de resolución finita.

- [NISTIR 7117](https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir7117.pdf) da el protocolo pulsado TOF y `t=2d/c`.
- [Pommé et al., *Uncertainty of nuclear counting*](https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=917522) distingue pile-up, pérdida del segundo pulso y registro compuesto.
- [Taguchi et al., modelo analítico de pulse pile-up](https://pmc.ncbi.nlm.nih.gov/articles/PMC2917451/) modela detector no paralizable con tiempo de resolución finito.
- [Ware et al., NIST](https://www.nist.gov/publications/calibrating-photon-counting-detectors-high-accuracy-background-and-deadtime-issues-0) documenta que calibrar APD exige tratar timing y deadtime.

Nivel: `OBSERVER_LEVEL_FORMAL_EXTERNAL_MATCH`, integrado en un candidato R3 por compartir mapa con dos relaciones independientes. No hubo descarga de dataset, error externo fila a fila ni réplica de laboratorio. El resultado no identifica “luz” como ontología DEE.
""",
 "UNUSED_PREDICTION.md":"""# Predicción no usada

## Interna

Después de congelar la candidata externa se predijo prospectivamente la respuesta de dos eventos singleton: suma a delay 0, exclusión a delay 1 y resolución separada desde delay 2. Pasó 6/6 mundos sin ajuste.

## Externa

`NOT_TESTED`. Las relaciones TOF, deadtime y pile-up estaban visibles durante la identificación de la familia. No se reclasifican como holdout. La predicción externa necesaria es una respuesta cuantitativa de dos pulsos reservada, usando `tau` calibrado una vez y sin cambiar detector, observable o normalización.
""",
 "NEGATIVE_RESULTS.md":"""# Resultados negativos y límites

- La ocupación binaria no es observador suficiente.
- Caminos independientes no explican el reductor/exclusión.
- Inventario no explica captura: la organización local importa.
- No se encontró un observador reducido global de toda `F_DEE`.
- El umbral guardado/captura no obtuvo correspondencia externa compartida.
- La candidata externa no es única.
- No existe tercera predicción externa reservada.
- No hay validación por dataset ni réplica independiente.
- No se deriva fotón, luz fundamental, teoría cuántica ni ontología material.
""",
 "ADVERSARIAL_REVIEW.md":"""# Revisión adversarial

1. **Selección post-hoc:** ocho observers y tres fingerprints fueron discovery; el costo está registrado. H01/H02 usaron mundos nuevos.
2. **Cambio de observer:** ninguno después de H01. H02 reutilizó las mismas coordenadas.
3. **Leakage:** las predicciones exactas se escribieron en locks antes de ejecutar los mundos correspondientes.
4. **Null simple:** caminos independientes, paridad permutada, evento binario e inventario fallan aspectos distintos.
5. **Calibración:** una escala `tau`; no se ajustó por geometría. La equivalencia `voxel/tick → c` no cuenta por sí sola como evidencia.
6. **Pile-up universal:** falso; depende del detector/procesador. La candidata se restringe a detectores integradores/energy-resolving compatibles.
7. **Identidad física:** no demostrada. El mismo fingerprint aparece en aparatos no ópticos.
8. **Unused external:** ausente y declarado, no reconstruido retrospectivamente.
9. **Incidentes técnicos:** dos errores de bootstrap/schema ocurrieron antes de locks/datos relevantes, están preservados y no alteran resultados.

Conclusión adversarial: R3 es defendible como mapa de aparato; R4–R6 no lo son.
""",
 "FINAL_FRONTIER.md":"""# Frontera final

La búsqueda amplia se cierra. La única siguiente investigación justificada es una validación profunda del candidato `MAP_EVENT_TO_PULSED_DETECTOR_V1`:

1. elegir antes de datos un detector físico y protocolo de dos pulsos;
2. calibrar `tau` una vez;
3. predecir curvas de eficiencia del segundo pulso y amplitud compuesta en delays reservados;
4. comparar contra modelo estándar del detector y null refractario genérico;
5. replicar en segundo detector/laboratorio.

Hasta entonces, el obstáculo es `OBSERVER_UNDERDETERMINED / INSUFFICIENT_EXTERNAL_OBSERVABLE`, no ausencia de ley interna. No se propone CORE14 automático.
""",
 }
 for name,text in docs.items(): atomic_text(ROOT/name,text)

def parent_integrity():
 p=load("PARENT_CHAIN.json"); bad=[]
 for row in p["parents"]:
  path=Path(row["path"]); observed=sha256_file(path) if path.exists() else None
  if observed!=row["sha256"]: bad.append({"core":row["core"],"expected":row["sha256"],"observed":observed})
 if bad: raise RuntimeError(f"parent drift: {bad}")
 return len(p["parents"])

def update_expediente(zip_hash):
 index=EXP/"INDICE_EXPEDIENTE.md"; text=index.read_text(encoding="utf-8")
 text=text.replace("once campañas científicas principales","trece campañas científicas principales")
 text=text.replace("Los ZIP CORE 01–11 están sellados","Los ZIP CORE 01–13 están sellados")
 if "### Experimento 13" not in text:
  section="""### Experimento 13 — convergencia Rosetta a nivel de observador

`13_DEE_V27_OBSERVER_LEVEL_ROSETTA_CONVERGENCE_AND_EXTERNAL_IDENTIFICATION_RESULTADOS.zip`

Comprime once fenómenos de transporte, fase, destino e interfaz mediante `M_EVENT_CAUSAL`; confirma prospectivamente 16 mundos nuevos; y establece un candidato Rosetta R3 para medición pulsada por tiempo de vuelo con detector de resolución finita. Conserva explícitamente la no-identificabilidad de la familia física, la ausencia de predicción externa reservada y la no-validación externa.


"""
  text=text.replace("## EXTRA",section+"## EXTRA")
 atomic_text(index,text)
 lines=[]
 for p in sorted(CORE.glob("*.zip"),key=lambda x:x.name): lines.append(f"{sha256_file(p)}  CORE/{p.name}")
 for p in sorted(EXTRA.glob("*.zip"),key=lambda x:x.name): lines.append(f"{sha256_file(p)}  EXTRA/{p.name}")
 lines.append(f"{sha256_file(index)}  INDICE_EXPEDIENTE.md")
 atomic_text(EXP/"HASHES.sha256","\n".join(lines)+"\n")

def package():
 include_files=[
  "EXECUTIVE_VERDICT.md","FINAL_REPORT.md","TRANSVERSAL_CORE01_TO_13.md","OBSERVER_ROSETTA_FRAMEWORK.md","CROSS_CORE_OBSERVABLE_MATRIX.json","OBSERVER_CANDIDATES.json","ROSETTA_CANDIDATE_ATLAS.json","ROSETTA_CONVERGENCE_LEDGER.json","ROSETTA_CONVERGENCE_GRAPH.json","PRIMARY_ROSETTA_CANDIDATE.md","ACCIDENTAL_MATCH_ANALYSIS.md","MODEL_COMPETITION.md","INTERNAL_PROSPECTIVE_HOLDOUT.md","EXTERNAL_MATCH.md","UNUSED_PREDICTION.md","NEGATIVE_RESULTS.md","ADVERSARIAL_REVIEW.md","FINAL_FRONTIER.md","QUESTION_TREE.ndjson","KERNEL_DIALOGUE.ndjson","CLAIM_LEDGER.json","STATE.json","TIME_BUDGET.json","PARENT_CHAIN.json","KERNEL_IMMUTABILITY_AUDIT.json","REPRODUCE.ps1"
 ]
 dirs=["NEUTRAL_FINGERPRINTS","HOLDOUT_LOCKS","RESULTS","RUNNERS"]
 staging=(ROOT/"output"/"package_root").resolve(); outroot=(ROOT/"output").resolve()
 if not staging.is_relative_to(outroot): raise RuntimeError("unsafe staging")
 if staging.exists(): shutil.rmtree(staging)
 staging.mkdir(parents=True)
 for name in include_files: shutil.copy2(ROOT/name,staging/name)
 for d in dirs: shutil.copytree(ROOT/d,staging/d,ignore=shutil.ignore_patterns("__pycache__","*.pyc"))
 manifest_rows=[]
 for p in sorted(x for x in staging.rglob("*") if x.is_file()):
  rel=p.relative_to(staging).as_posix(); manifest_rows.append({"path":rel,"bytes":p.stat().st_size,"sha256":sha256_file(p)})
 required=include_files+dirs
 manifest={"schema":"dee.v27.core13.manifest.v1","created_utc":utc_now(),"final_state":"STRONG_ROSETTA_CANDIDATE","rosetta_level":"R3_SHARED_LOW_PARAMETER_MAP","required":required,"file_count_before_manifest":len(manifest_rows),"files":manifest_rows}
 atomic_json(staging/"MANIFEST.json",manifest)
 hash_lines=[]
 for p in sorted(x for x in staging.rglob("*") if x.is_file() and x.name!="HASHES.sha256"):
  hash_lines.append(f"{sha256_file(p)}  {p.relative_to(staging).as_posix()}")
 atomic_text(staging/"HASHES.sha256","\n".join(hash_lines)+"\n")
 out=ROOT/"output"/ZIP_NAME; temp=out.with_suffix(".zip.tmp")
 if temp.exists(): temp.unlink()
 with zipfile.ZipFile(temp,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(x for x in staging.rglob("*") if x.is_file()): z.write(p,p.relative_to(staging).as_posix())
 os.replace(temp,out)
 # Validate archive names and every packaged hash.
 with zipfile.ZipFile(out,"r") as z:
  names=set(z.namelist()); expected=set(p.relative_to(staging).as_posix() for p in staging.rglob("*") if p.is_file())
  if names!=expected: raise RuntimeError("zip inventory mismatch")
  for line in z.read("HASHES.sha256").decode("utf-8").splitlines():
   digest,name=line.split("  ",1)
   if hashlib.sha256(z.read(name)).hexdigest()!=digest: raise RuntimeError(f"zip hash mismatch {name}")
 if out.stat().st_size>=5_000_000: raise RuntimeError("package exceeds hard preference")
 official=CORE/ZIP_NAME; shutil.copyfile(out,official)
 if sha256_file(out)!=sha256_file(official): raise RuntimeError("official copy mismatch")
 return out,official,sha256_file(out)

def rebuild_portable():
 portable=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE_COMPLETO.zip"
 if not portable.exists(): return None
 tmp=portable.with_suffix(".zip.tmp")
 if tmp.exists(): tmp.unlink()
 with zipfile.ZipFile(tmp,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(x for x in EXP.rglob("*") if x.is_file()): z.write(p,(Path(EXP.name)/p.relative_to(EXP)).as_posix())
 os.replace(tmp,portable); return {"path":str(portable),"bytes":portable.stat().st_size,"sha256":sha256_file(portable)}

def main():
 start=time.perf_counter(); budget("finalization",600); parents=parent_integrity(); audit("final_prepackage")
 write_docs()
 update_state(last_completed="C13_FINALIZATION",status="PACKAGE_READY",final_state="STRONG_ROSETTA_CANDIDATE",package_name=ZIP_NAME,next_action="none; deep external validation only")
 b=budget("complete",0,"COMPLETE"); b["finished_utc"]=utc_now(); atomic_json(ROOT/"TIME_BUDGET.json",b)
 out,official,digest=package(); update_expediente(digest); portable=rebuild_portable(); parents_after=parent_integrity()
 validation={"schema":"dee.v27.core13.final.validation.v1","timestamp_utc":utc_now(),"zip_name":ZIP_NAME,"source":str(out),"official":str(official),"sha256":digest,"bytes":out.stat().st_size,"byte_for_byte_copy":True,"parent_count_before":parents,"parent_count_after":parents_after,"parents_unchanged":True,"kernel_all_pass":load("KERNEL_IMMUTABILITY_AUDIT.json")["all_pass"],"zip_under_2MB":out.stat().st_size<2_000_000,"zip_under_5MB":out.stat().st_size<5_000_000,"portable":portable,"final_state":"STRONG_ROSETTA_CANDIDATE"}
 atomic_json(ROOT/"RESULTS"/"C13F01_final_validation.json",validation)
 log({"module":"C13_FINAL_PACKAGE","status":"COMPLETE","sha256":digest,"bytes":out.stat().st_size,"official":str(official)})
 print(json.dumps(validation,indent=2,ensure_ascii=False))

if __name__=="__main__": main()
