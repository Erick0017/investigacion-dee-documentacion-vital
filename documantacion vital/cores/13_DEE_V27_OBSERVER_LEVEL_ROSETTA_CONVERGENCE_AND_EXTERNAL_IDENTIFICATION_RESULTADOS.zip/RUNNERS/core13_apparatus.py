"""Prospective observer-level apparatus for route-delay and guarded interfaces."""
from __future__ import annotations
import itertools,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core13_common import World,pack,unpack
def add(q,d,k,n): return tuple((q[i]+k*d[i])%n for i in range(3))
def read(raw,q): return None if int(raw[q])==0 else unpack(raw[q])
def axes(frame,sign=1):
 dl=[0,0,0]; dt=[0,0,0]; dl[frame[0]]=sign; dt[frame[1]]=1; return tuple(dl[i]+dt[i] for i in range(3)),tuple(dl[i]-dt[i] for i in range(3))
def delayed_paths(kernel,n=47,L=8,delta=0,frame=(0,1,2),sign=1,center=None,sregs=(101,211),mode="AB",horizon=None):
 center=tuple(center or (n//2,n//2,n//2)); da,db=axes(frame,sign); La=L; Lb=L+delta; sa=add(center,da,-La,n); sb=add(center,db,-Lb,n); horizon=horizon or Lb+10
 raw=np.zeros((n,n,n),dtype=np.uint64); clock=np.zeros_like(raw)
 if mode in ("AB","A"): raw[sa]=pack(0,sregs[0],da,4); clock[sa]=np.uint64(111111+n)
 if mode in ("AB","B"): raw[sb]=pack(0,sregs[1],db,4); clock[sb]=np.uint64(222222+n)
 w=World(kernel,raw,clock); rows=[]
 for t in range(horizon+1):
  rows.append({"tick":t,"detector":read(w.raw,center),"target_occupied":int(w.raw[center])!=0,"target_clock":int(w.clock[center]),"source_A":read(w.raw,sa),"source_B":read(w.raw,sb),"support":int(np.count_nonzero(w.raw))})
  if t<horizon: w.tick()
 events=[r for r in rows if r["detector"] is not None and r["detector"]["semantic"]==1]
 return {"n":n,"L_A":La,"L_B":Lb,"delta":delta,"frame":list(frame),"sign":sign,"center":list(center),"sources":[list(sa),list(sb)],"directions":[list(da),list(db)],"sregs":list(sregs),"mode":mode,"horizon":horizon,"post_t0":"NATIVE_AFTER_T0","events":[{"tick":r["tick"],"sreg":r["detector"]["sreg"],"direction":r["detector"]["direction"]} for r in events],"rows":rows}
def predicted_delay_events(L,delta,horizon,sregs,dirs):
 out=[]
 if delta%2==0:
  for t in range(L,horizon+1,2):
   if t<L+delta: out.append({"tick":t,"sreg":sregs[0],"direction":list(dirs[0])})
   else: out.append({"tick":t,"sreg":sum(sregs),"direction":[int(np.sign(dirs[0][i]+dirs[1][i])) for i in range(3)]})
 else:
  out=[{"tick":t,"sreg":sregs[0],"direction":list(dirs[0])} for t in range(L,horizon+1,2)]
 return out
def single_shot_paths(kernel,n=59,L=9,delta=0,frame=(0,1,2),sign=1,center=None,sregs=(307,401),horizon=None):
 center=tuple(center or (n//2,n//2,n//2)); da,db=axes(frame,sign); sa=add(center,da,-L,n); sb=add(center,db,-(L+delta),n); horizon=horizon or L+delta+4
 raw=np.zeros((n,n,n),dtype=np.uint64); clock=np.zeros_like(raw)
 raw[sa]=pack(1,sregs[0],da,1); raw[sb]=pack(1,sregs[1],db,1)
 w=World(kernel,raw,clock); rows=[]
 for t in range(horizon+1):
  rows.append({"tick":t,"detector":read(w.raw,center),"target_occupied":int(w.raw[center])!=0,"target_clock":int(w.clock[center]),"support":int(np.count_nonzero(w.raw))})
  if t<horizon: w.tick()
 events=[{"tick":r["tick"],"sreg":r["detector"]["sreg"],"direction":r["detector"]["direction"]} for r in rows if r["detector"] is not None]
 return {"n":n,"L":L,"delta":delta,"frame":list(frame),"sign":sign,"center":list(center),"sregs":list(sregs),"horizon":horizon,"post_t0":"NATIVE_AFTER_T0","events":events,"rows":rows}
def predicted_single_shot_events(L,delta,sregs,dirs):
 if delta==0:
  return [{"tick":L,"sreg":sum(sregs),"direction":[int(np.sign(dirs[0][i]+dirs[1][i])) for i in range(3)]}]
 if delta==1:
  return [{"tick":L,"sreg":sregs[0],"direction":list(dirs[0])}]
 return [{"tick":L,"sreg":sregs[0],"direction":list(dirs[0])},{"tick":L+delta,"sreg":sregs[1],"direction":list(dirs[1])}]
def guarded_route(kernel,n=53,L=12,k=6,frame=(0,1,2),sign=1,center=None,sreg=503,horizon=None,shuffled=False,semantic=4):
 center=tuple(center or (n//2,n//2,n//2)); d=[0,0,0]; d[frame[0]]=sign; d=tuple(d); source=add(center,d,-L,n); horizon=horizon or L+16
 raw=np.zeros((n,n,n),dtype=np.uint64); raw[source]=pack(0,sreg,d,4); raw[center]=pack(0x1234,19,(0,0,0),1)
 corners=[((center[0]+x)%n,(center[1]+y)%n,(center[2]+z)%n) for x,y,z in itertools.product((-1,1),repeat=3)]
 selected=corners[:k]
 if shuffled: selected=[tuple((center[i]+2*s[i])%n for i in range(3)) for s in itertools.product((-1,1),repeat=3)][:k]
 for i,q in enumerate(selected): raw[q]=pack(0xA000+i,31+i,(0,0,0),semantic)
 w=World(kernel,raw); probe=add(center,d,5,n); rows=[]
 for t in range(horizon+1):
  rows.append({"tick":t,"center":read(w.raw,center),"probe":read(w.raw,probe),"guard_support":sum(int(w.raw[q]!=0) for q in selected)})
  if t<horizon:w.tick()
 events=[{"tick":r["tick"],"record":r["probe"]} for r in rows if r["probe"] is not None and r["probe"]["direction"]==list(d)]
 return {"n":n,"L":L,"k":k,"frame":list(frame),"sign":sign,"center":list(center),"sreg":sreg,"shuffled":shuffled,"semantic":semantic,"horizon":horizon,"post_t0":"NATIVE_AFTER_T0","probe_events":events,"center_all_ticks":all(r["center"] is not None for r in rows),"rows":rows}
