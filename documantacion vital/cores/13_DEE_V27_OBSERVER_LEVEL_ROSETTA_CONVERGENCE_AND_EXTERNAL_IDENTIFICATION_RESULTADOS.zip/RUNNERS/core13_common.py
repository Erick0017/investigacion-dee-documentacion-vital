"""Atomic persistence and sealed DEE v27 helpers for CORE13."""
from __future__ import annotations
import hashlib,importlib,json,os,platform,sys,time
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]; TESTS=ROOT.parent
EXTRACTED=ROOT/"KERNEL"/"wheel_extracted"; WHEEL_FILE=ROOT/"KERNEL"/"dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"; PACKAGE_FILE=EXTRACTED/"dee_universe_v27"/"__init__.py"; KERNEL_FILE=EXTRACTED/"dee_universe_v27"/"dee_kernel_v27.cp313-win_amd64.pyd"
EXPECTED={"wheel":"69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939","package":"7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4","kernel":"0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"}
PARENTS={"CORE01":"06c9721e11efbb8907d0283633ae7a08b5f58c424c7342ed0465a3fe266de1e4","CORE02":"4c29c9530c80f21c5e3af03ff5b3ff79d36367ba8480bb137ae7a3ec84b76058","CORE03":"553bba71dc21929443e6032801607d90a7b3d7ced5c45f1078295338efb16640","CORE04":"48dc7452e72c6372b526bf271112d5826386e5fe9bfde9218258fd9e297fd3d2","CORE05":"aeb4c45ddba43a3bfefe54da5177823ced28e4fc233363a3b0f4f8411a7bcd8b","CORE06":"3f81b016b0f1d5a1bb0b9a7e43807ba68e81eb0120fab0a2a32b4d1081ecef6e","CORE07":"707a83c9c23d891152e2ecbe92673a72aec58ab2242d152537d35ba62fcfad4f","CORE08":"275d3e665c0d0c97c3da80ee487819078fc55dbca24bd4e40c7dafa5b5e7a5fc","CORE09":"70ef26424a11ae907e39a4a25f9dfe4864ed0d11a7ae33cfc22f395238091d96","CORE10":"2fedd8aa7a488584ed15ab8e8e86a4bd892c97914e7153945cc7fe019a87b515","CORE11":"c8b591c5eb4e90a5de947da992337434be98802c024c860991ba8d967d9fb885","CORE12":"909833980f9b676f1c8fba40a68838a23fd759f8f99c1492d1133f5609889345"}
STATE_MASK=np.uint64((1<<32)-1); SREG_MASK=np.uint64(0xFFFF); SEM_MASK=np.uint64(0xF)
def utc_now(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")
def sha256_file(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""): h.update(b)
 return h.hexdigest()
def native(v):
 if isinstance(v,dict): return {str(k):native(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)): return [native(x) for x in v]
 if isinstance(v,np.generic): return v.item()
 return v
def atomic_json(p,v):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+".tmp")
 with t.open("w",encoding="utf-8",newline="\n") as f: json.dump(native(v),f,indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False); f.write("\n"); f.flush(); os.fsync(f.fileno())
 os.replace(t,p)
def atomic_text(p,v):
 p=Path(p); p.parent.mkdir(parents=True,exist_ok=True); t=p.with_suffix(p.suffix+".tmp")
 with t.open("w",encoding="utf-8",newline="\n") as f: f.write(v); f.flush(); os.fsync(f.fileno())
 os.replace(t,p)
def append_ndjson(p,row): atomic_text(p,(Path(p).read_text(encoding="utf-8") if Path(p).exists() else "")+json.dumps(native(row),separators=(",",":"),ensure_ascii=False)+"\n")
def log(row): append_ndjson(ROOT/"SCIENCE_LOG.ndjson",{"timestamp_utc":utc_now(),**row})
def question(row): append_ndjson(ROOT/"QUESTION_TREE.ndjson",{"timestamp_utc":utc_now(),**row})
def dialogue(row): append_ndjson(ROOT/"KERNEL_DIALOGUE.ndjson",{"timestamp_utc":utc_now(),**row})
def update_state(**u):
 p=ROOT/"STATE.json"; s=json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}; s.update(native(u)); s["timestamp_utc"]=utc_now(); atomic_json(p,s)
def kernel_hashes(): return {"wheel":sha256_file(WHEEL_FILE),"package":sha256_file(PACKAGE_FILE),"kernel":sha256_file(KERNEL_FILE)}
def audit(stage):
 p=ROOT/"KERNEL_IMMUTABILITY_AUDIT.json"; a=json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"expected":EXPECTED,"checks":[]}; o=kernel_hashes(); ok=o==EXPECTED; a["checks"].append({"stage":stage,"timestamp_utc":utc_now(),"observed":o,"pass":ok}); a["all_pass"]=all(x["pass"] for x in a["checks"]); atomic_json(p,a)
 if not ok: raise RuntimeError("kernel drift")
def budget(module,estimate,decision="RUN"):
 p=ROOT/"TIME_BUDGET.json"; b=json.loads(p.read_text(encoding="utf-8")); e=time.time()-b["start_epoch_utc"]; b.update({"last_update_utc":utc_now(),"elapsed_seconds":round(e,3),"remaining_seconds":round(max(0,3600-e),3),"next_module":module,"estimated_next_module_seconds":estimate,"decision_to_run_or_skip":decision}); atomic_json(p,b); return b
def verify_kernel(threads=1):
 if sys.version_info[:2]!=(3,13): raise RuntimeError("CPython 3.13 required")
 if kernel_hashes()!=EXPECTED: raise RuntimeError("sealed identity mismatch")
 sys.path.insert(0,str(EXTRACTED)); importlib.invalidate_caches(); import dee_universe_v27 as pkg; from dee_universe_v27 import dee_kernel_v27 as kernel
 if Path(pkg.__file__).resolve()!=PACKAGE_FILE.resolve() or Path(kernel.__file__).resolve()!=KERNEL_FILE.resolve(): raise RuntimeError("wrong import")
 return kernel,{"hashes":EXPECTED,"python":sys.version,"numpy":np.__version__,"platform":platform.platform(),"threads":threads}
def pack(state,sreg,d,semantic=1): return np.uint64((state&0xffffffff)|((sreg&0xffff)<<32)|((d[0]&0xf)<<48)|((d[1]&0xf)<<52)|((d[2]&0xf)<<56)|((semantic&0xf)<<60))
def signed(v,shift):
 x=(np.asarray(v,dtype=np.uint64)>>np.uint64(shift))&np.uint64(15); x=x.astype(np.int16); return np.where(x>=8,x-16,x)
def unpack(v):
 v=np.uint64(v); return {"raw":int(v),"state":int(v&STATE_MASK),"sreg":int((v>>np.uint64(32))&SREG_MASK),"direction":[int(signed(v,s)) for s in (48,52,56)],"semantic":int((v>>np.uint64(60))&SEM_MASK)}
class World:
 def __init__(self,kernel,raw,clock=None,threads=1):
  self.k=kernel; self.n=raw.shape[0]; self.t=threads; self.raw_a=np.ascontiguousarray(raw,dtype=np.uint64).copy(); self.raw_b=self.raw_a.copy(); base=np.zeros_like(raw,dtype=np.uint64) if clock is None else clock; self.clock_a=np.ascontiguousarray(base,dtype=np.uint64).copy(); self.clock_b=self.clock_a.copy()
 @property
 def raw(self): return self.raw_a
 @property
 def clock(self): return self.clock_a
 def tick(self): return native(dict(self.k.tick_universo_lazy(self.raw_a,self.raw_b,self.clock_a,self.clock_b,self.n,self.t)))
