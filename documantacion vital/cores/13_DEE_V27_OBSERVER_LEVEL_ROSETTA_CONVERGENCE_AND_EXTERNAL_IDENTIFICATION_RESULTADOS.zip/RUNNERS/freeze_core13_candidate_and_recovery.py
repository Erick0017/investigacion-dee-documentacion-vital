"""Record the externally identified candidate and freeze an unused internal relation."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core13_common import ROOT, atomic_json, audit, budget, dialogue, log, question, sha256_file, update_state, utc_now


def main() -> None:
    budget("freeze_candidate_and_unused_relation", 20)
    search_lock = ROOT / "HOLDOUT_LOCKS" / "C13E00_BLIND_EXTERNAL_IDENTIFICATION.json"
    if not search_lock.exists():
        raise RuntimeError("pre-search lock missing")
    sources = [
        {
            "source_id": "NIST_TOF_7117",
            "url": "https://nvlpubs.nist.gov/nistpubs/Legacy/IR/nistir7117.pdf",
            "authority": "NIST",
            "relation": "a pulse traversing round-trip distance 2d reaches a photonic detector at t=2d/c",
            "role": "external candidate discovery",
        },
        {
            "source_id": "NIST_COUNTING_UNCERTAINTY",
            "url": "https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=917522",
            "authority": "NIST",
            "relation": "overlapping pulses can form one summed pulse; a later pulse in the trailing response can be lost",
            "role": "external candidate discovery",
        },
        {
            "source_id": "TAGUCHI_2010_PCXD",
            "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC2917451/",
            "authority": "primary peer-reviewed analytical detector paper",
            "relation": "finite resolving time; arrivals during it contribute to one recorded pulse/count and cause count loss",
            "role": "external candidate discovery",
        },
        {
            "source_id": "WARE_2007_NIST_APD",
            "url": "https://www.nist.gov/publications/calibrating-photon-counting-detectors-high-accuracy-background-and-deadtime-issues-0",
            "authority": "NIST publication record",
            "relation": "APD calibration requires explicit pulse timing and dead-time treatment",
            "role": "external candidate discovery",
        },
    ]
    candidates = [
        {"candidate_id":"EXT_A_PULSED_TOF_FINITE_RECOVERY_DETECTOR","matched_relations":["route delay","finite resolving interval","coincident-event pile-up"],"unmatched_relations":["guard-count threshold","exact period two"],"map_complexity":1,"identification_specificity":"NON_UNIQUE","score":5.0},
        {"candidate_id":"EXT_B_GENERIC_PULSE_PROCESSOR","matched_relations":["finite resolving interval","coincident-event pile-up"],"unmatched_relations":["route delay","guard-count threshold"],"map_complexity":1,"identification_specificity":"GENERIC","score":3.0},
        {"candidate_id":"EXT_C_REFRACTORY_EVENT_SYSTEM","matched_relations":["finite resolving interval"],"unmatched_relations":["uncapped amplitude sum","route delay","guard-count threshold"],"map_complexity":1,"identification_specificity":"GENERIC","score":1.0},
        {"candidate_id":"EXT_D_ABSORBING_THRESHOLD_INTERFACE","matched_relations":["transmission/capture switch"],"unmatched_relations":["route delay","coincident-event pile-up","one-interval exclusion"],"map_complexity":2,"identification_specificity":"GENERIC","score":0.0},
    ]
    selected = candidates[0]
    candidate = {
        "candidate_id": selected["candidate_id"],
        "observer_id": "M_EVENT_CAUSAL",
        "status_before_prospective_test": "EXTERNAL_DISCOVERY_CANDIDATE_FROZEN",
        "external_protocol_class": "pulsed time-of-flight measurement with a finite-resolving event detector",
        "translation": {
            "time": "t_external/tau = tick_DEE",
            "route": "d_external/(v_external*tau) = L_DEE; v_external belongs to the external protocol and is not fitted case-by-case",
            "amplitude": "E_record/(E1+E2) = sreg_record/(sreg1+sreg2), using normalized sums",
            "acceptance": "recorded/not-recorded maps to accepted/excluded destination event",
        },
        "free_parameters": [{"name":"tau","role":"single detector response-time scale"}],
        "matched_relations": selected["matched_relations"],
        "unmatched_relations": selected["unmatched_relations"],
        "nulls": ["independent events with no detector state", "binary occupancy alone", "generic threshold without route timing", "permuted timing map"],
        "external_identification": "NON_UNIQUE_APPARATUS_LEVEL",
        "physical_identity_claimed": False,
        "external_unused_prediction_available": False,
        "sources_exposed_during_candidate_discovery": [x["source_id"] for x in sources],
        "frozen_utc": utc_now(),
    }
    atomic_json(ROOT / "RESULTS" / "C13E01_external_candidate_discovery.json", {"sources":sources,"candidates":candidates,"selected":candidate})
    map_lock = {
        "claim_id":"C13E01_PULSED_TOF_FINITE_RECOVERY_MAP",
        "frozen_utc":utc_now(),
        "candidate":candidate,
        "PASS":"authoritative external sources support at least two operational relations with the same one-scale map",
        "FAIL":"one map cannot cover route timing and finite-resolution response",
        "INCONCLUSIVE":"law match is real but does not identify a unique physical sector",
        "promotion_ceiling_without_unused_external_data":"R3_SHARED_LOW_PARAMETER_MAP",
        "falsifier":"requires per-geometry remapping or external detector response contradicts the frozen event ordering",
    }
    map_path = ROOT / "HOLDOUT_LOCKS" / "C13E01_PULSED_TOF_FINITE_RECOVERY_MAP.json"
    atomic_json(map_path,map_lock)
    recovery_lock = {
        "claim_id":"C13H02_SINGLE_SHOT_RESOLVING_INTERVAL",
        "frozen_utc":utc_now(),
        "observer_id":"M_EVENT_CAUSAL",
        "apparatus":"two singleton semantic-1 events on convergent routes",
        "new_worlds":"new N, axes, translations, amplitudes; delays 0,1,2,3",
        "prediction":{
            "delta_0":"one record at L with uncapped summed sreg",
            "delta_1":"only first event recorded; second excluded by occupied target in prior input state",
            "delta_ge_2":"two separately resolved records at L and L+delta",
        },
        "parameters":{"resolving_interval_ticks":1,"time_scale":1},
        "controls":["delta zero","delta one","delta two or more","signed-axis and translation diversity"],
        "PASS":"all frozen event lists exact and no parameter changes",
        "FAIL":"any valid event list differs",
        "INCONCLUSIVE":"technical invalidity only",
        "falsifier":"one new world violates the frozen resolution relation",
        "role":"prospective unused INTERNAL relation; not an unused external validation",
    }
    rec_path=ROOT/"HOLDOUT_LOCKS"/"C13H02_SINGLE_SHOT_RESOLVING_INTERVAL.json"
    atomic_json(rec_path,recovery_lock)
    hashes={"C13E01":sha256_file(map_path),"C13H02":sha256_file(rec_path)}
    atomic_json(ROOT/"RESULTS"/"C13E01_candidate_map_freeze.json",{"hashes":hashes,"status":"LOCKED_BEFORE_H02"})
    question({"question_id":"C13Q04","parent_question_id":"C13Q03","question":"Does the same observer predict the unused singleton resolving relation?","candidate_map_falsified_if":"any event list differs","status":"HOLDOUT_LOCKED","lock_sha256":hashes["C13H02"]})
    dialogue({"question_id":"C13Q04","question":"Can the one-interval exclusion be separated from period-two source recurrence?","why":"distinguishes detector-state mechanism from phase-train artifact","apparatus":"new singleton convergent routes","kernel_response":"not opened","evidence_level":"FROZEN_PREDICTION"})
    log({"module":"C13E01_FREEZE","status":"COMPLETE","hashes":hashes})
    update_state(last_completed="C13E01_FREEZE",status="H02_LOCKED",next_action="run singleton resolving holdout once",external_candidate=selected["candidate_id"],external_map_lock_sha256=hashes["C13E01"],h02_lock_sha256=hashes["C13H02"])
    audit("before_H02")
    budget("C13H02_single_shot_holdout",90)
    print(json.dumps(hashes,indent=2))


if __name__ == "__main__": main()
