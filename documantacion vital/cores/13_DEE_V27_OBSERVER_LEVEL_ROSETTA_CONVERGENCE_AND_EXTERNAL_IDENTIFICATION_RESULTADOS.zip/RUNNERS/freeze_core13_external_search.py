"""Freeze the neutral fingerprint and external-identification rules before search."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core13_common import ROOT, atomic_json, audit, budget, dialogue, log, question, sha256_file, update_state, utc_now


def main() -> None:
    budget("freeze_external_identification", 15)
    audit("before_external_identification_freeze")
    internal = json.loads((ROOT / "RESULTS" / "C13H01_internal_prospective_holdout.json").read_text(encoding="utf-8"))
    if internal.get("verdict") != "PASS":
        raise RuntimeError("C13H01 did not pass; external identification is not earned")
    fingerprint = json.loads((ROOT / "NEUTRAL_FINGERPRINTS" / "NEUTRAL_FINGERPRINT_A.json").read_text(encoding="utf-8"))
    lock = {
        "claim_id": "C13E00_BLIND_EXTERNAL_IDENTIFICATION",
        "frozen_utc": utc_now(),
        "phase": "PRE_SEARCH_NEUTRAL_FREEZE",
        "observer_id": "M_EVENT_CAUSAL",
        "observer_variables": fingerprint["observable_outputs"] + ["route length", "relative delay", "target occupancy", "guard count"],
        "neutral_fingerprint_sha256": sha256_file(ROOT / "NEUTRAL_FINGERPRINTS" / "NEUTRAL_FINGERPRINT_A.json"),
        "internal_holdout_sha256": sha256_file(ROOT / "RESULTS" / "C13H01_internal_prospective_holdout.json"),
        "relations_to_match": [
            "arrival delay is proportional to route length",
            "simultaneous destination events produce one summed uncapped record",
            "an event arriving one response interval after an accepted event is excluded",
            "an organization-specific local guard can switch transmission to sustained capture",
        ],
        "search_without_physical_names": True,
        "selection_rule": "prefer the simplest preparation-interaction-detector-readout protocol matching at least two frozen relations",
        "external_source_policy": "authoritative primary or standards source; analytic law allowed; dataset validation must be labelled separately",
        "maximum_external_candidate_families": 4,
        "free_parameter_limit": "one time scale for event timing; amplitude scale must cancel in normalized comparisons",
        "required_competitors": ["independent-path", "binary-event", "generic-threshold", "permuted-map"],
        "promotion": {
            "R2": "one operational external law family matches without changing the DEE observer",
            "R3": "shared low-parameter map covers at least two independent external relations",
            "R4": "same map predicts an unused third external relation",
        },
        "FAIL": "no external protocol matches even one multi-coordinate relation",
        "INCONCLUSIVE": "matches are non-identifying or authoritative observables are unavailable",
        "falsifier": "a simpler observer or generic null explains all matched records equally well",
        "discovery_flexibility_cost": {
            "cross_core_rows": 23,
            "observer_families_compared": 8,
            "neutral_clusters_compared": 3,
            "internal_candidate_holdouts_opened": 1,
        },
    }
    path = ROOT / "HOLDOUT_LOCKS" / "C13E00_BLIND_EXTERNAL_IDENTIFICATION.json"
    atomic_json(path, lock)
    digest = sha256_file(path)
    atomic_json(ROOT / "RESULTS" / "C13E00_external_search_freeze.json", {
        "claim_id": lock["claim_id"], "lock_sha256": digest, "status": "LOCKED_BEFORE_EXTERNAL_SEARCH"
    })
    question({"question_id": "C13Q03", "parent_question_id": "C13Q02", "question": "What external preparation-interaction-detector-readout protocol matches the frozen neutral fingerprint?", "status": "HOLDOUT_LOCKED", "lock_sha256": digest})
    dialogue({"question_id": "C13Q03", "question": "Can the frozen observer law be identified externally without names?", "why": "internal holdout passed", "apparatus": "literature/protocol identification under frozen criteria", "kernel_response": "not applicable; internal response already frozen", "evidence_level": "PRE_SEARCH_LOCK"})
    log({"module": "C13E00", "status": "COMPLETE", "lock_sha256": digest})
    update_state(last_completed="C13E00", status="EXTERNAL_SEARCH_FROZEN", next_action="blind external protocol search", external_search_lock_sha256=digest)
    budget("blind_external_protocol_search", 240)
    print(digest)


if __name__ == "__main__":
    main()
