from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core13_common import ROOT,atomic_json,sha256_file,audit,budget,log,update_state,utc_now
def main():
 d=json.loads((ROOT/"RESULTS"/"C13D01_observer_convergence_discovery.json").read_text(encoding="utf-8"))
 if not d["predicate_result"]: raise RuntimeError("discovery gate failed")
 lock={"claim_id":"C13H01_EVENT_CAUSAL_SHARED_OBSERVER","frozen_utc":utc_now(),"observer":{"id":"M_EVENT_CAUSAL","variables":["route length","event tick","event sreg","event direction","relative delay parity","target occupancy","guard count"]},"map":{"time":"t_arrival=L+2j","even_delay":"A-only before B; then simultaneous destination reduction sreg=a+b","odd_delay":"A occupies destination on alternating ticks and B is excluded; A signature remains","interface":"k>=6 retains center and captures; k=5/shuffled transmits"},"parameters":{"period":2,"guard_threshold":6,"time_scale":1},"domain":"new N, translations, signed axes, sreg, delays 4..9; guard k5/6/7 and shuffled","nulls":["independent paths","binary event","inventory-only","permuted parity"],"PASS":"all six delay worlds and four interface worlds exact; causal model zero signature error and beats all declared nulls","FAIL":"any valid frozen relation fails","INCONCLUSIVE":"technical invalidity only","falsifier":"one valid new world requires remapping"}
 p=ROOT/"HOLDOUT_LOCKS"/"C13H01_EVENT_CAUSAL_SHARED_OBSERVER.json"; atomic_json(p,lock); h=sha256_file(p); atomic_json(ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json",{"C13H01_EVENT_CAUSAL_SHARED_OBSERVER":h}); audit("before_holdout"); log({"module":"freeze_internal_holdout","status":"COMPLETE","lock_sha256":h}); update_state(status="HOLDOUT_LOCKED",lock_sha256=h,next_action="open new DEE worlds once"); budget("internal_holdout",90); print(h)
if __name__=="__main__":main()
