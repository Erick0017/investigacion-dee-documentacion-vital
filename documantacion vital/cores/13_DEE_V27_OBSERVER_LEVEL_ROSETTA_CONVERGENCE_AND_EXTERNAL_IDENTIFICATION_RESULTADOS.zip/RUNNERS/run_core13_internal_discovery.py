"""Discover only the prospective relation needed to discriminate observer maps."""
from __future__ import annotations
import json,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core13_common import ROOT,budget,verify_kernel,atomic_json,question,dialogue,log,update_state,audit
from core13_apparatus import delayed_paths,predicted_delay_events,guarded_route
def main():
 started=time.perf_counter(); budget("internal_discovery",60); kernel,env=verify_kernel(); cases=[]
 for delta in range(4):
  run=delayed_paths(kernel,47,8,delta,(0,1,2),1,(22,25,20),(101,211),"AB",21)
  pred=predicted_delay_events(8,delta,21,(101,211),run["directions"]); cases.append({"delta":delta,"observed":run["events"],"predicted":pred,"exact":run["events"]==pred,"run":run})
 guard=[guarded_route(kernel,53,12,k,(1,2,0),1,(28,25,30),503,28,shuffled=False,semantic=4) for k in (5,6)]
 exact=all(x["exact"] for x in cases) and bool(guard[0]["probe_events"]) and not guard[1]["probe_events"]
 result={"schema":"dee.v27.core13.discovery.v1","module":"C13D01_OBSERVER_CONVERGENCE_DISCOVERY","environment":env,"question":"Can M_EVENT_CAUSAL predict a new route-delay family and reuse the same guard coordinate?","machine_predicate":"delay parity exactly selects merged/eclipsed signatures for delta0..3 and k5/k6 select transmit/capture","predicate_result":exact,"cases":cases,"guard_crosscheck":guard,"summary":{"delay_cases_exact":sum(x["exact"] for x in cases),"delay_cases":4,"k5_transmits":bool(guard[0]["probe_events"]),"k6_captures":not guard[1]["probe_events"],"selected_observer":"M_EVENT_CAUSAL","gate_to_holdout":exact},"wall_seconds":time.perf_counter()-started}
 atomic_json(ROOT/"RESULTS"/"C13D01_observer_convergence_discovery.json",result); audit("after_discovery")
 question({"question_id":"C13Q01","candidate_map":"NF_A_EVENT_CAUSAL","distinguishes":"independent-path, binary-event, and destination-history maps","prediction":"delay parity selects sum versus exclusion; guard count selects transmission","response":result["summary"],"status":"MECHANISM_CANDIDATE" if exact else "FAILED"})
 dialogue({"question":"Can one reduced observer predict a relation not used in selection?","apparatus":"route delays delta0..3 plus k5/k6 interface","kernel_response":result["summary"],"interpretation":"same event/occupancy/guard coordinates predict both path and interface families","alternatives":["independent paths","binary event only","inventory only"],"evidence":"DISCOVERY_ONLY"})
 log({"module":"internal_discovery","status":"COMPLETE","summary":result["summary"],"wall_seconds":result["wall_seconds"]}); update_state(status="DISCOVERY_COMPLETE",last_completed="C13D01",next_action="freeze M_EVENT_CAUSAL and unused delta/interface worlds"); budget("freeze_internal_holdout",20); print(json.dumps(result["summary"],indent=2))
if __name__=="__main__":main()
