"""Frozen prospective test and head-to-head observer/model competition."""
from __future__ import annotations
import json,math,sys,time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from core13_common import ROOT,atomic_json,sha256_file,verify_kernel,audit,budget,log,question,dialogue,update_state
from core13_apparatus import delayed_paths,predicted_delay_events,guarded_route
def vector(events,horizon):
 d={e["tick"]:e["sreg"] for e in events}; return [d.get(t,0) for t in range(horizon+1)]
def rmse(a,b): return math.sqrt(sum((x-y)**2 for x,y in zip(a,b,strict=True))/len(a))
def independent(L,delta,horizon,a,b):
 out={}
 for t in range(L,horizon+1,2):out[t]=out.get(t,0)+a
 for t in range(L+delta,horizon+1,2):out[t]=out.get(t,0)+b
 return [out.get(t,0) for t in range(horizon+1)]
def main():
 started=time.perf_counter(); budget("internal_holdout",90); locks=json.loads((ROOT/"HOLDOUT_LOCKS"/"LOCK_HASHES.json").read_text()); lp=ROOT/"HOLDOUT_LOCKS"/"C13H01_EVENT_CAUSAL_SHARED_OBSERVER.json"; lh=sha256_file(lp)
 if lh!=locks["C13H01_EVENT_CAUSAL_SHARED_OBSERVER"]: raise RuntimeError("lock changed")
 kernel,env=verify_kernel(); configs=[(61,10,4,(0,2,1),1,(331,509)),(67,11,5,(1,0,2),-1,(701,1103)),(71,12,6,(2,1,0),1,(1701,2203)),(73,13,7,(0,1,2),-1,(4001,8009)),(79,14,8,(1,2,0),1,(1201,3001)),(83,15,9,(2,0,1),-1,(503,9001))]; cases=[]
 for n,L,delta,frame,sign,sregs in configs:
  horizon=L+delta+8; center=(n//2+2,n//2-3,n//2+1); run=delayed_paths(kernel,n,L,delta,frame,sign,center,sregs,"AB",horizon); pred=predicted_delay_events(L,delta,horizon,sregs,run["directions"]); obs=vector(run["events"],horizon); causal=vector(pred,horizon); indep=independent(L,delta,horizon,*sregs); perm_delta=delta+1 if delta%2==0 else delta-1; perm=vector(predicted_delay_events(L,perm_delta,horizon,sregs,run["directions"]),horizon)
  cases.append({"n":n,"L":L,"delta":delta,"frame":list(frame),"sign":sign,"sregs":list(sregs),"exact":run["events"]==pred,"errors":{"M_EVENT_CAUSAL":rmse(obs,causal),"INDEPENDENT_PATH":rmse(obs,indep),"PERMUTED_PARITY":rmse(obs,perm)},"run":run,"prediction":pred})
 gconfigs=[(61,10,5,(0,2,1),1,401,False,4),(67,11,6,(1,0,2),-1,733,False,4),(71,12,7,(2,1,0),1,1201,False,4),(73,13,6,(0,1,2),-1,19001,True,4)]
 guards=[]
 for cfg in gconfigs:
  n,L,k,frame,sign,sreg,shuffled,semantic=cfg; center=(n//2+1,n//2-2,n//2+3); run=guarded_route(kernel,n,L,k,frame,sign,center,sreg,L+16,shuffled,semantic); expected_capture=k>=6 and not shuffled and semantic==4; exact=(not run["probe_events"] and run["center_all_ticks"]) if expected_capture else bool(run["probe_events"]); guards.append({"config":{"n":n,"L":L,"k":k,"frame":list(frame),"sign":sign,"sreg":sreg,"shuffled":shuffled,"semantic":semantic},"expected_capture":expected_capture,"exact":exact,"run":run})
 all_exact=all(x["exact"] for x in cases+guards); causal_errors=[x["errors"]["M_EVENT_CAUSAL"] for x in cases]; null_min=min(sum(x["errors"][k] for x in cases) for k in ("INDEPENDENT_PATH","PERMUTED_PARITY")); pass_=all_exact and max(causal_errors)==0 and null_min>0
 result={"schema":"dee.v27.core13.holdout.v1","claim_id":"C13H01_EVENT_CAUSAL_SHARED_OBSERVER","lock_sha256":lh,"environment":env,"verdict":"PASS" if pass_ else "FAIL","machine_predicate_result":pass_,"summary":{"delay_exact":sum(x["exact"] for x in cases),"delay_total":len(cases),"interface_exact":sum(x["exact"] for x in guards),"interface_total":len(guards),"causal_rmse":sum(causal_errors)/len(causal_errors),"independent_path_rmse":sum(x["errors"]["INDEPENDENT_PATH"] for x in cases)/len(cases),"permuted_parity_rmse":sum(x["errors"]["PERMUTED_PARITY"] for x in cases)/len(cases)},"delay_trials":cases,"interface_trials":guards,"wall_seconds":time.perf_counter()-started}
 atomic_json(ROOT/"RESULTS"/"C13H01_internal_prospective_holdout.json",result); audit("after_holdout"); question({"question_id":"C13Q02","candidate_map":"NF_A_EVENT_CAUSAL","distinguishes":"same-map causal observer vs null maps","prediction":"unused delays4..9 and interfaces exact","response":result["summary"],"status":"CONFIRMED" if pass_ else "FAILED"}); dialogue({"question":"Does the selected observer generalize prospectively?","apparatus":"six new delay worlds and four interface worlds","kernel_response":result["summary"],"interpretation":"internal multiphenomenon convergence" if pass_ else "candidate falsified","alternatives":["independent path","permuted parity","inventory-only"],"evidence":"FROZEN_HOLDOUT"}); log({"module":"internal_holdout","status":"COMPLETE","verdict":result["verdict"],"summary":result["summary"],"wall_seconds":result["wall_seconds"]}); update_state(status="INTERNAL_HOLDOUT_COMPLETE",holdout=result["verdict"],next_action="freeze neutral external fingerprint then blind external identification" if pass_ else "close candidate"); budget("external_matching",300); print(json.dumps(result["summary"]|{"verdict":result["verdict"]},indent=2))
if __name__=="__main__":main()
