"""Idempotent CORE13 master entrypoint for the internal executable modules."""
from __future__ import annotations
import subprocess, sys
from pathlib import Path

HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
STEPS=[
 ("initialize_core13.py",ROOT/"CROSS_CORE_OBSERVABLE_MATRIX.json"),
 ("run_core13_internal_discovery.py",ROOT/"RESULTS"/"C13D01_observer_convergence_discovery.json"),
 ("freeze_core13_holdout.py",ROOT/"HOLDOUT_LOCKS"/"C13H01_EVENT_CAUSAL_SHARED_OBSERVER.json"),
 ("run_core13_internal_holdout.py",ROOT/"RESULTS"/"C13H01_internal_prospective_holdout.json"),
 ("freeze_core13_external_search.py",ROOT/"HOLDOUT_LOCKS"/"C13E00_BLIND_EXTERNAL_IDENTIFICATION.json"),
 ("freeze_core13_candidate_and_recovery.py",ROOT/"HOLDOUT_LOCKS"/"C13H02_SINGLE_SHOT_RESOLVING_INTERVAL.json"),
 ("run_core13_single_shot_holdout.py",ROOT/"RESULTS"/"C13H02_single_shot_resolving_holdout.json"),
 ("adjudicate_core13.py",ROOT/"ROSETTA_CANDIDATE_ATLAS.json"),
]
def main():
 for script,output in STEPS:
  if output.exists(): print(f"SKIP COMPLETE {script}"); continue
  subprocess.run([sys.executable,"-I","-B",str(HERE/script)],check=True,cwd=ROOT)
 print("CORE13 executable science modules COMPLETE")
if __name__=="__main__": main()
