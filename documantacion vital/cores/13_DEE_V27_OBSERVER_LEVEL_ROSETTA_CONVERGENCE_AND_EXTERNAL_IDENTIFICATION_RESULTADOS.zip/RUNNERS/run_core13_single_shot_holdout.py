"""Open the frozen singleton resolving-time holdout exactly once."""
from __future__ import annotations
import json, math, sys, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from core13_common import ROOT, atomic_json, audit, budget, dialogue, log, question, sha256_file, update_state, verify_kernel
from core13_apparatus import axes, predicted_single_shot_events, single_shot_paths


def main() -> None:
    start=time.perf_counter(); budget("C13H02_single_shot_holdout",90)
    lock_path=ROOT/"HOLDOUT_LOCKS"/"C13H02_SINGLE_SHOT_RESOLVING_INTERVAL.json"
    lock_sha=sha256_file(lock_path); kernel,identity=verify_kernel()
    configs=[
        {"n":59,"L":9,"delta":0,"frame":(0,2,1),"sign":1,"center":(31,27,30),"sregs":(307,401)},
        {"n":61,"L":10,"delta":1,"frame":(1,0,2),"sign":-1,"center":(29,33,30),"sregs":(503,809)},
        {"n":67,"L":11,"delta":2,"frame":(2,1,0),"sign":1,"center":(36,31,35),"sregs":(1201,1601)},
        {"n":71,"L":12,"delta":3,"frame":(0,1,2),"sign":-1,"center":(34,38,33),"sregs":(2011,3001)},
        {"n":73,"L":13,"delta":1,"frame":(2,0,1),"sign":-1,"center":(39,35,37),"sregs":(4093,5003)},
        {"n":79,"L":14,"delta":2,"frame":(1,2,0),"sign":1,"center":(38,41,36),"sregs":(6007,7001)},
    ]
    trials=[]
    for cfg in configs:
        run=single_shot_paths(kernel,**cfg)
        da,db=axes(cfg["frame"],cfg["sign"])
        pred=predicted_single_shot_events(cfg["L"],cfg["delta"],cfg["sregs"],(da,db))
        trials.append({"config":{**cfg,"frame":list(cfg["frame"]),"center":list(cfg["center"]),"sregs":list(cfg["sregs"])},"observed":run["events"],"predicted":pred,"exact":run["events"]==pred,"run":run})
    exact=sum(x["exact"] for x in trials); verdict="PASS" if exact==len(trials) else "FAIL"
    out={"schema":"dee.v27.core13.holdout.v1","claim_id":"C13H02_SINGLE_SHOT_RESOLVING_INTERVAL","lock_sha256":lock_sha,"identity":identity,"trials":trials,"summary":{"exact":exact,"total":len(trials),"resolving_interval_ticks":1},"verdict":verdict,"machine_predicate_result":verdict=="PASS","wall_seconds":time.perf_counter()-start}
    atomic_json(ROOT/"RESULTS"/"C13H02_single_shot_resolving_holdout.json",out)
    question({"question_id":"C13Q04","response":{"exact":exact,"total":len(trials)},"status":"CONFIRMED" if verdict=="PASS" else "FAILED"})
    dialogue({"question_id":"C13Q04","kernel_response":{"exact":exact,"total":len(trials),"verdict":verdict},"simpler_explanation":"local destination occupancy/reducer; no period-two source needed","evidence_level":"FROZEN_INTERNAL_HOLDOUT"})
    log({"module":"C13H02","status":"COMPLETE","verdict":verdict,"exact":exact,"total":len(trials),"wall_seconds":out["wall_seconds"]})
    update_state(last_completed="C13H02",status="INTERNAL_PROSPECTIVE_COMPLETE",h02_verdict=verdict,next_action="audit frozen external sources and adjudicate Rosetta level")
    audit("after_H02")
    budget("external_source_audit_and_adjudication",180)
    print(json.dumps(out["summary"]|{"verdict":verdict},indent=2))


if __name__ == "__main__": main()
