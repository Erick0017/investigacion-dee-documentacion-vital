# Predicción no usada

## Interna

Después de congelar la candidata externa se predijo prospectivamente la respuesta de dos eventos singleton: suma a delay 0, exclusión a delay 1 y resolución separada desde delay 2. Pasó 6/6 mundos sin ajuste.

## Externa

`NOT_TESTED`. Las relaciones TOF, deadtime y pile-up estaban visibles durante la identificación de la familia. No se reclasifican como holdout. La predicción externa necesaria es una respuesta cuantitativa de dos pulsos reservada, usando `tau` calibrado una vez y sin cambiar detector, observable o normalización.
