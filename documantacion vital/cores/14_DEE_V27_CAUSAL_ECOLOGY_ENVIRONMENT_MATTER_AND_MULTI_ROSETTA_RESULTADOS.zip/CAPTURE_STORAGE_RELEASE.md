# Capture Storage Release

Associative collision yields operational storage and query-triggered transformed output. k6 capture alone does not store/release, and spontaneous later release was not found.
