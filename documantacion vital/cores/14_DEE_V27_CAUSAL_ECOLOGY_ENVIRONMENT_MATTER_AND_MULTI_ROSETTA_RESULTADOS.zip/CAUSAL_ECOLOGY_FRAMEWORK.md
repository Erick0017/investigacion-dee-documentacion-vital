# Causal ecology framework

Minimal confirmed graph: `event -> routed history lineage -> response`; `learned state -> corridor -> receiver -> functional response`; `A <-> B` via two necessary lanes; `shared interface -> joint restoration`. A hidden clock trace remains outside this functional graph under the two probes tested.
