# Causal Ecology Loop

Several arrows connect, but no autonomous NATIVE_AFTER_T0 closed loop was demonstrated.
