# Environmental Footprint

A persistent clock-array trace exists after full marked-lineage removal although both raw buffers match controls. The original full-state-identity lock failed. Two frozen probes found no functional raw effect in 18 ticks.
