# Exchange And Zeroth Law

Bidirectional causal state exchange passed lane cuts. No equalization relation exists, so zeroth-law testing was not justified.
