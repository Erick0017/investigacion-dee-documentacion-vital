# Final Frontier

The strongest new question is whether any independently motivated physical probe accesses the clock trace. Probe chasing is prohibited; next priority is complete MASTER revalidation and then independent external testing, not CORE15.
