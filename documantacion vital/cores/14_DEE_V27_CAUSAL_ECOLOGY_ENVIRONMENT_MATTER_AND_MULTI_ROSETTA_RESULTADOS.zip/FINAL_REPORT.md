# Executive verdict — rebuilt CORE14

**COMPLETE · R2_CROSS_PHENOMENON_INTERNAL_LAW.** The rebuild adjudicated 13 evidence-based mechanism classes across 6 unique experiment families. Five scoped positive claims and one bounded negative passed fresh locks; one earlier full-state-identity lock failed and remains failed.

The failed lock exposed a new exact fact: after complete marked-lineage removal, EMPTY and k6-GUARD raw buffers return to matched controls but the two clock buffers retain a persistent trace. Fresh singleton and phase probes did not convert that trace into a raw/readout difference within 18 ticks, so it is a computational environmental trace, not yet a functional environmental state.

Confirmed connected arrows are: paired events -> history-bearing lineage -> later response; learned state -> causal corridor -> prepared receiver -> functional response; two intervenable lanes -> bidirectional endpoint change; shared interface -> joint recovery. A distinct mixed-ensemble sector follows monotone dissipative contraction to a finite plateau.

No Theta, zeroth-law relation, field-like distance law, spontaneous release, autonomous native ecology loop, external unused prediction or external Rosetta validation was established.

## Scope

`PERSISTENT_CLOCK_STATE_TRACE` is L0 exact state evidence. `HISTORY_BEARING_LINEAGE_STATE`, scaffold recovery and the multi-arrow ecology are bounded L2 mechanisms. Rosetta remains internal R2; CORE13's observer candidate is preserved but not externally upgraded.
