# Legacy Theory Reassessment

temperature/s_reg STILL_HYPOTHESIS; absolute-zero/locking NOT_TESTED; matter/trapped propagation REFORMULATED as functional state transfer; mass/refresh NOT_TESTED; vacuum forgetting REFORMULATED as raw forgetting plus clock trace; active vacuum PARTIALLY_SUPPORTED only as hidden computational trace; reservoir/gravity STILL_HYPOTHESIS; radiation/material conversion REFORMULATED without external identity.
