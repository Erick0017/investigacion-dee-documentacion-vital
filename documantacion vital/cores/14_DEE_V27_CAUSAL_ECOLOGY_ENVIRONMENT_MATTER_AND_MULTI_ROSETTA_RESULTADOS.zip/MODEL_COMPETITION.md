# Model Competition

Residual raw carrier, inventory-only, aligned ballistic, missing scaffold, broken route, receiver-only and raw-only-state models were tested. Raw-only state identity lost to the clock trace.
