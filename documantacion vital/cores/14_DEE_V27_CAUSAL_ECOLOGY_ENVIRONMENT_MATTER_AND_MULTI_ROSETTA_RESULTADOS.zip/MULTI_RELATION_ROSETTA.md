# Multi Relation Rosetta

R2 internal convergence only. The new pieces do not reuse CORE13's same external map and provide no unused external prediction.
