# Negative Results

Preserved FAIL: C14H05 full-state identity. Bounded null: no clock-trace effect under two frozen probes/18 ticks. Also no Theta, zeroth law, field distance law, spontaneous release, autonomous loop or external validation.
