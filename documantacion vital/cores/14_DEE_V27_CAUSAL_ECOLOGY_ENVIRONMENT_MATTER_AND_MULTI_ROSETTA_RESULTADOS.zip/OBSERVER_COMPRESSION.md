# Observer Compression

M_HISTORY, M_MATTER and M_COUPLING are separately sufficient in their tasks. M_FULL was necessary to see the clock trace. No universal M_ECOLOGY was justified.
