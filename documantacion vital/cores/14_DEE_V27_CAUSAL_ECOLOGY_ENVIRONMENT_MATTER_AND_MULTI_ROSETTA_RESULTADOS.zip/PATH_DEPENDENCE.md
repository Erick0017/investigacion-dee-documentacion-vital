# Path Dependence

Paired simultaneous history changes later response; order/history shuffle and reset do not. This is a bounded constitutive-history result.
