# Relaxation

Mixed ensembles show monotone support/s_reg contraction to a finite plateau; aligned controls translate exactly. Collision-driven contraction beats exponential/equilibration narratives in this domain.
