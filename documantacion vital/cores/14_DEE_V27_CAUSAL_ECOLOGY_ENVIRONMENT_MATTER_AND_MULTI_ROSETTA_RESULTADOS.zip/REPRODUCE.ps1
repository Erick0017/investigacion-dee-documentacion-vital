$ErrorActionPreference = 'Stop'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\run_core14_causal_ecology.py'
