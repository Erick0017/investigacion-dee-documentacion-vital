from __future__ import annotations
import hashlib,itertools,json,sys,time
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
import run_core14_causal_ecology_rebuild as c
from native_core import NativeWorld,fields,pack,verify_and_load_kernel

def prepare(kernel,n,center,kind,exposed,sreg=8888):
 raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);d=(1,0,0);src=tuple((center[i]-8*d[i])%n for i in range(3))
 if kind=="GUARD":
  raw[center]=pack(0x1234,19,(0,0,0),1);corners=[tuple((center[i]+x[i])%n for i in range(3)) for x in itertools.product((-1,1),repeat=3)]
  for i,q in enumerate(corners[:6]):raw[q]=pack(0xA000+i,31+i,(0,0,0),4)
 if exposed:raw[src]=pack(0,sreg,d,4 if kind=="GUARD" else 1);clock[src]=123456+n
 w=NativeWorld(kernel,raw,clock)
 for _ in range(16):w.tick()
 fa,fb=fields(w.raw_a),fields(w.raw_b);mask=(fa["sreg"]==sreg)|(fb["sreg"]==sreg)
 w.raw_a[mask]=0;w.raw_b[mask]=0;w.clock_a[mask]=0;w.clock_b[mask]=0
 for _ in range(4):w.tick()
 return {"a":w.raw_a.copy(),"b":w.raw_b.copy(),"ca":w.clock_a.copy(),"cb":w.clock_b.copy()}
def fingerprint(s):return {k:hashlib.sha256(v.tobytes()).hexdigest() for k,v in s.items()}
def probe(kernel,state,n,center,kind):
 d=(1,0,0);src=tuple((center[i]-7*d[i])%n for i in range(3));a=state["a"].copy();b=state["b"].copy();ca=state["ca"].copy();cb=state["cb"].copy();sem=1 if kind=="P_SINGLETON_EVENT" else 4;a[src]=pack(1 if sem==1 else 0,3991,d,sem);b[src]=a[src];ca[src]=99001;cb[src]=99001;w=NativeWorld(kernel,a,ca);w.raw_b[:]=b;w.clock_b[:]=cb;trace=[]
 for t in range(18):
  trace.append({"tick":t,"raw":hashlib.sha256(w.raw_a.tobytes()).hexdigest(),"clock":hashlib.sha256(w.clock_a.tobytes()).hexdigest(),"center_raw":int(w.raw_a[center])})
  w.tick()
 return trace
def run_set(kernel,configs):
 rows=[]
 for n,center in configs:
  for cls in ("EMPTY","GUARD"):
   e=prepare(kernel,n,center,cls,True);z=prepare(kernel,n,center,cls,False);base={"raw_equal":np.array_equal(e["a"],z["a"]) and np.array_equal(e["b"],z["b"]),"clock_equal":np.array_equal(e["ca"],z["ca"]) and np.array_equal(e["cb"],z["cb"]),"exposed_fingerprint":fingerprint(e),"control_fingerprint":fingerprint(z)};probes=[]
   for p in ("P_SINGLETON_EVENT","P_PHASE_EVENT"):
    te,tz=probe(kernel,e,n,center,p),probe(kernel,z,n,center,p);probes.append({"probe":p,"raw_future_equal":all(a["raw"]==b["raw"] for a,b in zip(te,tz)),"clock_future_equal":all(a["clock"]==b["clock"] for a,b in zip(te,tz)),"center_readout_equal":all(a["center_raw"]==b["center_raw"] for a,b in zip(te,tz)),"exposed_trace":te,"control_trace":tz})
   rows.append({"n":n,"center":list(center),"class":cls,"baseline":base,"probes":probes})
 trace_present=all(x["baseline"]["raw_equal"] and not x["baseline"]["clock_equal"] for x in rows);functional=any(not p["raw_future_equal"] or not p["center_readout_equal"] for x in rows for p in x["probes"])
 return {"rows":rows,"clock_trace_present":trace_present,"functional_effect_detected":functional,"probe_raw_equivalence":all(p["raw_future_equal"] and p["center_readout_equal"] for x in rows for p in x["probes"])}
def main():
 kernel,env=verify_and_load_kernel(1)
 c.write(c.ROOT/"NEW_MECHANISM_JUSTIFICATION.json",{"entries":[{"mechanism_id":"MC_CLOCK_TRACE","observed_anomaly":"C14H05 raw arrays equal but clock arrays differ after complete marked-lineage removal","why_existing_classes_cannot_explain":"prior baseline treated raw equality as full causal identity","new_hypotheses":["clock trace is functional","clock trace is observationally inert for frozen probes"],"decisive_experiment":"same raw/different clock worlds challenged by predeclared singleton and phase probes","stop_condition":"fresh holdout classifies effect"}]})
 c.question("C14D06","environment","MC_CLOCK_TRACE","Does the persistent clock trace alter future frozen-probe response?","functional environmental state","computational trace without tested functional effect","freeze class-conditional holdout")
 discovery=run_set(kernel,[(35,(17,17,17)),(41,(13,24,19))]);c.write(c.ROOT/"RAW_OR_SPARSE_TELEMETRY"/"C14D06.json",discovery)
 prediction="FUNCTIONAL_EFFECT_REPLICATES" if discovery["functional_effect_detected"] else "CLOCK_TRACE_REPLICATES_BUT_FROZEN_PROBE_RAW_RESPONSE_REMAINS_EQUAL"
 lock={"claim_id":"C14H06_CLOCK_TRACE_CLASSIFICATION","source":"C14D06","question":"Does full causal state retain a clock trace after marked-lineage removal, and is it functional under the two frozen probe families?","apparatus":"matched-age EMPTY/GUARD; complete marked-lineage removal","probes":["P_SINGLETON_EVENT","P_PHASE_EVENT"],"observer":"all four canonical arrays plus center readout","prediction":prediction,"fresh_domain":[[47,[21,13,29]],[49,[31,17,11]],[55,[19,37,23]]],"PASS":"clock trace in every class/world and functional classification matches frozen prediction","FAIL":"trace absent or functional classification reverses","falsifier":"any fresh world violates prediction","created_before_holdout":True};c.write(c.ROOT/"HOLDOUT_LOCKS"/"C14H06_CLOCK_TRACE_CLASSIFICATION.json",lock);c.text(c.ROOT/"HOLDOUT_LOCKS"/"C14H06_CLOCK_TRACE_CLASSIFICATION.sha256",c.sha(c.ROOT/"HOLDOUT_LOCKS"/"C14H06_CLOCK_TRACE_CLASSIFICATION.json")+"  C14H06_CLOCK_TRACE_CLASSIFICATION.json\n")
 hold=run_set(kernel,[(47,(21,13,29)),(49,(31,17,11)),(55,(19,37,23))]);hold["prediction"]=prediction;hold["predicate"]=hold["clock_trace_present"] and (hold["functional_effect_detected"] if prediction=="FUNCTIONAL_EFFECT_REPLICATES" else hold["probe_raw_equivalence"]);hold["verdict"]="PASS" if hold["predicate"] else "FAIL";hold["lock_sha256"]=c.sha(c.ROOT/"HOLDOUT_LOCKS"/"C14H06_CLOCK_TRACE_CLASSIFICATION.json");c.write(c.ROOT/"RAW_OR_SPARSE_TELEMETRY"/"C14H06_CLOCK_TRACE_CLASSIFICATION.json",hold)
 reg=json.loads((c.ROOT/"EXPERIMENT_REGISTRY.json").read_text());key=c.expkey("C14D06","MC_CLOCK_TRACE","matched raw/different clock","fresh frozen probes","M_FULL+center","N35-55");reg["experiments"].append({"experiment_key":key,"question_id":"C14D06","front":"environment","mechanism_class":"MC_CLOCK_TRACE","preparation_family":"matched raw/different clock","intervention_class":"fresh frozen probes","readout_family":"M_FULL+center","parameter_region":"N35-55","predicate":hold["predicate"]});reg["unique_keys"]=len({x["experiment_key"] for x in reg["experiments"]})==len(reg["experiments"]);c.write(c.ROOT/"EXPERIMENT_REGISTRY.json",reg)
 c.append(c.ROOT/"KERNEL_DIALOGUE.ndjson",{"question_id":"C14D06","raw_outcome":{"discovery":discovery["functional_effect_detected"],"holdout":hold["verdict"],"prediction":prediction},"mechanism_update":"persistent clock trace classified prospectively","remaining_alternatives":"other probes may access clock state","next_high_information_question":"finalize bounded claim; no probe chasing"})
 print(json.dumps({"discovery":prediction,"holdout":hold["verdict"],"clock_trace":hold["clock_trace_present"],"functional_effect":hold["functional_effect_detected"]},indent=2))
if __name__=="__main__":main()
