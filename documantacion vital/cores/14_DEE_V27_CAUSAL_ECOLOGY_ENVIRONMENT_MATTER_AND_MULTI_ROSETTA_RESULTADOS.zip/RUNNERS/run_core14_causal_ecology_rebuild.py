from __future__ import annotations
import hashlib,itertools,json,os,shutil,sys,time,zipfile
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from native_core import NativeWorld,fields,pack,verify_and_load_kernel
from run_c6h01_associative_plasticity_holdout import BASE as ASSOC_BASE,simulate as assoc_sim,transform as assoc_transform
from run_c6h08_dissipative_ensemble_holdout import DIRECTIONS,prepared_support,simulate as ensemble_sim
from run_c8h02_repeated_scaffold_regeneration import simulate as regen_sim
from core10_apparatus import run_bidirectional_exchange,run_joint_scaffold,run_learned_policy_transfer

ROOT=Path(__file__).resolve().parents[1];TESTS=ROOT.parent;ARCH=TESTS/"EXPEDIENTE_EXPERIMENTOS_DEE"/"CORE"
OFFICIAL_NAME="14_DEE_V27_CAUSAL_ECOLOGY_ENVIRONMENT_MATTER_AND_MULTI_ROSETTA_RESULTADOS.zip"
MASTER_NAME="DEE_V27_MASTER_REVALIDATION_CORE01_TO_14_ANTI_OVERFIT_RESULTADOS.zip"
EXPECTED={"wheel":"69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939","package":"7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4","kernel":"0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"}
PARENT_NAME="13_DEE_V27_OBSERVER_LEVEL_ROSETTA_CONVERGENCE_AND_EXTERNAL_IDENTIFICATION_RESULTADOS.zip";PARENT_SHA="7def64eb5fcb4694c0655a3a26233a13f52aeef4c00b96994470e2daf1c34776"
START=time.time()
def utc():return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")
def sha(p):
 h=hashlib.sha256()
 with Path(p).open("rb") as f:
  for b in iter(lambda:f.read(1<<20),b""):h.update(b)
 return h.hexdigest()
def write(p,o):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+".tmp")
 with t.open("w",encoding="utf-8",newline="\n") as f:json.dump(o,f,indent=2,sort_keys=True,allow_nan=False);f.write("\n");f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def text(p,s):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+".tmp")
 with t.open("w",encoding="utf-8",newline="\n") as f:f.write(s);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def append(p,o):
 p=Path(p);old=p.read_text(encoding="utf-8") if p.exists() else "";text(p,old+json.dumps({"utc":utc(),**o},separators=(",",":"))+"\n")
def expkey(q,m,p,i,r,region):return hashlib.sha256("|".join([q,m,p,i,r,region]).encode()).hexdigest()
def kernel_hashes():
 k=ROOT/"KERNEL";e=k/"wheel_extracted"/"dee_universe_v27"
 return {"wheel":sha(k/"dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"),"package":sha(e/"__init__.py"),"kernel":sha(e/"dee_kernel_v27.cp313-win_amd64.pyd")}
def audit_kernel(stage):
 p=ROOT/"KERNEL_IMMUTABILITY_AUDIT.json";o=json.loads(p.read_text()) if p.exists() else {"expected":EXPECTED,"checks":[]};h=kernel_hashes();o["checks"].append({"stage":stage,"utc":utc(),"observed":h,"pass":h==EXPECTED});o["all_pass"]=all(x["pass"] for x in o["checks"]);write(p,o)
 if h!=EXPECTED:raise RuntimeError("kernel mismatch")
def parent_audit():
 p=ARCH/PARENT_NAME
 if sha(p)!=PARENT_SHA:raise RuntimeError("CORE13 parent mismatch")
 with zipfile.ZipFile(p) as z:
  if z.testzip() is not None:raise RuntimeError("CORE13 zip corrupt")
  names=set(z.namelist());bad=[]
  for line in z.read("HASHES.sha256").decode().splitlines():
   h,n=line.split(None,1);n=n.strip().lstrip("*")
   if n not in names or hashlib.sha256(z.read(n)).hexdigest()!=h:bad.append(n)
  if bad:raise RuntimeError("CORE13 internal hash mismatch")
  manifest_obj=json.loads(z.read("MANIFEST.json"));manifest_status=manifest_obj.get("status","PRESENT_VALIDATED")
 return {"name":p.name,"sha256":sha(p),"size":p.stat().st_size,"zip_integrity":True,"manifest":manifest_status,"internal_hash_mismatches":bad}
def assoc_cell(i,n,delay,frame=((0,1,2),(1,1,1))):
 rng=np.random.default_rng(141000+i);junction=tuple(int(x) for x in rng.integers(8,n-8,size=3));vec={k:list(assoc_transform(v,*frame)) for k,v in ASSOC_BASE.items()}
 return {"cell_id":f"C14M{i}","n":n,"junction":list(junction),"train_tick":4+i%3,"delay":delay,"query_path":3,"vectors":vec,"cue_sreg":5+i,"teacher_sreg":7+i,"query_sreg":11+i,"eraser_sreg":13,"states":[int(x) for x in rng.integers(1,2**32,size=4,dtype=np.uint64)],"clocks":[int(rng.bit_generator.random_raw()) for _ in range(4)]}
def run_assoc(kernel,cells,modes):
 rows=[assoc_sim(kernel,c,m) for c in cells for m in modes];by={m:[x for x in rows if x["mode"]==m] for m in modes}
 rates={m:{"trained":float(np.mean([x["trained_exact"] for x in v])),"neutral":float(np.mean([x["neutral_exact"] for x in v])),"memory_only":float(np.mean([x["memory_only_exact"] for x in v]))} for m,v in by.items()}
 return {"rows":rows,"rates":rates,"predicate":rates.get("trained_pair",{}).get("trained")==1 and all(rates[m]["trained"]==0 for m in modes if m!="trained_pair"),"history_specific":rates.get("history_shuffled",{}).get("trained",0)==0,"ablation_necessary":rates.get("memory_ablation",{}).get("trained",0)==0}
def run_regen(kernel,configs):
 pos=[regen_sim(kernel,n,center,seed,"primary_payload_nuisance",cycles) for n,center,seed,cycles in configs];neg=[regen_sim(kernel,n,center,seed+90000,"missing_corner",cycles) for n,center,seed,cycles in configs]
 return {"positive":pos,"negative":neg,"positive_recovery":float(np.mean([x["recovery_rate"] for x in pos])),"negative_recovery":float(np.mean([x["recovery_rate"] for x in neg])),"predicate":all(x["recovery_rate"]==1 and x["scaffold_raw_unchanged"] for x in pos) and all(x["recovery_rate"]==0 for x in neg)}
def run_ensemble(kernel,configs):
 rows=[]
 for idx,(n,fill,seed) in enumerate(configs):
  rng=np.random.default_rng(seed);cap=(n//3)**3;count=max(8,int(round(cap*fill)));support=prepared_support(n,count,rng);sregs=[int(x) for x in rng.integers(1,8,size=count)];clocks=[int(x) for x in rng.integers(0,2**32,size=count,dtype=np.uint64)];mixed=[DIRECTIONS[int(i)] for i in rng.integers(0,len(DIRECTIONS),size=count)];h=5*n
  mt,_=ensemble_sim(kernel,n,support,sregs,clocks,mixed,h,False);at,exact=ensemble_sim(kernel,n,support,sregs,clocks,[(1,0,0)]*count,h,True)
  rows.append({"n":n,"fill":fill,"seed":seed,"mixed_trace":mt,"aligned_trace":at,"aligned_translation_exact":exact,"mixed_contracted":mt[-1]["support"]<mt[0]["support"],"mixed_monotone":all(b["support"]<=a["support"] and b["sreg_sum"]<=a["sreg_sum"] for a,b in zip(mt,mt[1:])),"terminal_constant":len({x["support"] for x in mt[-n:]})==1 and len({x["sreg_sum"] for x in mt[-n:]})==1})
 return {"rows":rows,"predicate":all(x["mixed_contracted"] and x["mixed_monotone"] and x["terminal_constant"] and x["aligned_translation_exact"] for x in rows),"model":"collision-driven monotone contraction to finite terminal plateau; not exponential equilibrium"}
def full_state_baseline(kernel,n,center,kind,exposed,sreg=7777):
 raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);d=(1,0,0);source=tuple((center[i]-8*d[i])%n for i in range(3))
 corners=[]
 if kind=="GUARD":
  raw[center]=pack(0x1234,19,(0,0,0),1);corners=[tuple((center[i]+x[i])%n for i in range(3)) for x in itertools.product((-1,1),repeat=3)]
  for i,q in enumerate(corners[:6]):raw[q]=pack(0xA000+i,31+i,(0,0,0),4)
 if exposed:raw[source]=pack(0,sreg,d,4 if kind=="GUARD" else 1);clock[source]=123456+n
 w=NativeWorld(kernel,raw,clock)
 for _ in range(16):w.tick()
 # Remove complete marked lineage (semantic may change, s_reg is conserved for these probes).
 sr=fields(w.raw)["sreg"];w.raw_a[sr==sreg]=0;w.raw_b[:]=w.raw_a;w.clock_a[sr==sreg]=0;w.clock_b[:]=w.clock_a
 for _ in range(4):w.tick()
 return {"raw_hash":hashlib.sha256(w.raw.tobytes()).hexdigest(),"clock_hash":hashlib.sha256(w.clock.tobytes()).hexdigest(),"support":int(np.count_nonzero(w.raw)),"raw":w.raw.copy(),"clock":w.clock.copy()}
def run_baselines(kernel,configs):
 rows=[]
 for n,center in configs:
  for kind in ("EMPTY","GUARD"):
   a=full_state_baseline(kernel,n,center,kind,True);b=full_state_baseline(kernel,n,center,kind,False);rows.append({"n":n,"center":center,"class":kind,"raw_equal":bool(np.array_equal(a.pop("raw"),b.pop("raw"))),"clock_equal":bool(np.array_equal(a.pop("clock"),b.pop("clock"))),"exposed":a,"control":b})
 return {"rows":rows,"predicate":all(x["raw_equal"] and x["clock_equal"] for x in rows)}
def run_core10_family(kernel,configs):
 ex=[];tr=[];joint=[]
 for i,(n,d,frame) in enumerate(configs):
  for m in ("AB","no_connection","block_A_path","block_B_path"):ex.append(run_bidirectional_exchange(kernel,142000+i*10+len(ex),n,d,m,*frame,1))
  for m in ("trained","untrained","memory_ablation","corridor_cut","receiver_none"):tr.append(run_learned_policy_transfer(kernel,143000+i*10+len(tr),n,d,m,*frame))
  for m in ("AB","missing_shared_one","shuffled_same_inventory","full_A_only","full_B_only"):joint.append(run_joint_scaffold(kernel,144000+i*10+len(joint),n,m,4,i%3))
 def rate(rows,mode,pred):
  q=[x for x in rows if x["mode"]==mode];return float(np.mean([pred(x) for x in q]))
 gates={"bidirectional":rate(ex,"AB",lambda x:x["functional"]["A_received_B_policy"] and x["functional"]["B_received_A_policy"])==1,"no_connection":rate(ex,"no_connection",lambda x:x["functional"]["A_received_B_policy"] or x["functional"]["B_received_A_policy"])==0,"directional_cuts":rate(ex,"block_A_path",lambda x:(not x["functional"]["B_received_A_policy"]) and x["functional"]["A_received_B_policy"])==1 and rate(ex,"block_B_path",lambda x:x["functional"]["B_received_A_policy"] and not x["functional"]["A_received_B_policy"])==1,"reinstantiation":rate(tr,"trained",lambda x:x["functional_policy_reinstantiated"] and x["source_depleted_after_launch"] and x["corridor_all_intermediate_ticks_observed"])==1,"transfer_controls":all(rate(tr,m,lambda x:x["functional_policy_reinstantiated"])==0 for m in ("untrained","memory_ablation","corridor_cut","receiver_none")),"joint":rate(joint,"AB",lambda x:x["joint_recovery_rate"]==1 and x["scaffold_unchanged"])==1,"joint_controls":all(rate(joint,m,lambda x:x["joint_recovery_rate"]>0)==0 for m in ("missing_shared_one","shuffled_same_inventory"))}
 return {"exchange":ex,"transfer":tr,"joint":joint,"gates":gates,"predicate":all(gates.values())}
def init_files():
 old14=ARCH/OFFICIAL_NAME;oldm=ARCH/MASTER_NAME
 write(ROOT/"OBSOLETED_PRIOR_RUNS.json",{"old_core14_sha256":sha(old14),"old_core14_size":old14.stat().st_size,"old_master_sha256":sha(oldm),"old_master_size":oldm.stat().st_size,"old_statuses":{"core14":"SEALED_BOUNDED_NULL","master":"MASTER_REVALIDATION_PARTIAL"},"reason_for_rebuild":"Prior CORE14 closed after narrow empty/guard apparatus; prior MASTER covered only 11 manually selected contracts.","date":utc(),"statement":"Prior runs retained only as methodological diagnostics. They are superseded by this rebuild."})
 pa=parent_audit();chain=[]
 for p in sorted(ARCH.glob("[0-1][0-9]_*.zip")):
  c=int(p.name[:2]);
  if c<=13:chain.append({"core":c,"name":p.name,"sha256":sha(p),"size":p.stat().st_size})
 write(ROOT/"PARENT_CHAIN.json",{"immediate_parent":pa,"chain":chain,"old_core14_excluded_from_evidence":True})
 caps=[
  (1,"CLOCK_AND_LOCALITY","clock increment, finite transport, destination reducer",False,"SOURCE,PROBE"),(3,"COLLECTIVE_BASIN","collective support/basin organization",True,"MATTER,MEDIUM"),(4,"PRODUCTIVE_HISTORY","support/activity depends on event history",True,"MEDIUM"),(5,"FIBER_PHASE_MEMORY","destination fibers and toroidal phase/history",True,"MEDIUM,OBSERVER"),(6,"ASSOCIATIVE_LINEAGE","paired collision writes routed memory changing later cue",True,"MEDIUM,RECEIVER,DETECTOR"),(6,"DISSIPATIVE_ENSEMBLE","mixed normal ensemble contracts monotonically",True,"RESERVOIR,MATTER"),(7,"FEEDBACK_RESOURCE","internal feedback and resource closure",True,"COUPLED SYSTEM"),(8,"FIXED_SCAFFOLD_REGEN","eight semantic-4 corners restore center vacancy",True,"MATTER"),(8,"FUNCTIONAL_RECOVERY","trained redundant donor restores function",True,"RECEIVER,MATTER"),(9,"ADAPTIVE_POLICY","history-conditioned two-action returning carrier",True,"MATTER,COUPLED SYSTEM"),(10,"BIDIRECTIONAL_EXCHANGE","two lanes causally exchange policy states",True,"COUPLED SYSTEM"),(10,"FUNCTIONAL_REINSTANTIATION","learned policy routed into prepared receiver",True,"RECEIVER,COUPLED SYSTEM"),(10,"JOINT_HOMEOSTASIS","shared interface completes two regeneration guards",True,"COUPLED SYSTEM,MATTER"),(11,"SINGLETON_ADDITIVITY","parallel singleton paths additive in bounded apparatus",False,"PROBE"),(12,"PHASE_AND_CAPTURE","period-two phase combination and k6 capture",True,"SOURCE,DETECTOR"),(13,"M_EVENT_CAUSAL","route/tick/history resolves event records",True,"OBSERVER")]
 atlas=[]
 for core,name,description,history,uses in caps:atlas.append({"capability_id":name,"source_core":core,"native_state_or_preparation":description,"mechanism":name.replace("_"," ").lower(),"causal_mediator":"kernel proposal/fiber/reducer plus stated organization","observer":"task-relative raw/event observer","persistence":"history-bearing" if history else "instantaneous_or_periodic","history_dependence":history,"source_dependence":"apparatus-specific","resource_dependence":"bounded/not externally identified","interaction_type":"native","known_controls":"source/route/history/scaffold ablations in source core","fresh_holdout_status":"prior evidence; new CORE14 adjudication required where used","known_failure_modes":"scope bounded","reconstructible_runner":True,"potential_use":uses.split(",")})
 write(ROOT/"CORE01_13_NATIVE_CAPABILITY_ATLAS.json",{"parent":"CORE13","entries":atlas})
 edges=[("event","propagation","CONFIRMED"),("propagation","destination_fiber","CONFIRMED"),("phase","path_response","CONFIRMED"),("paired_event","history_lineage","CONFIRMED"),("history_lineage","later_response","CONFIRMED"),("guard","recovery","CONFIRMED"),("shared_interface","joint_homeostasis","CONFIRMED"),("learned_state","receiver_response","CONFIRMED"),("empty_vacuum","post_lineage_memory","UNKNOWN"),("structured_medium","post_cause_memory","UNKNOWN"),("organization","environment","UNKNOWN"),("environment","distant_system","UNKNOWN"),("persistent_state","release","UNKNOWN"),("exchange","theta_coordinate","UNKNOWN")]
 write(ROOT/"CORE01_13_CAUSAL_GRAPH.json",{"nodes":sorted(set([a for a,b,s in edges]+[b for a,b,s in edges])),"edges":[{"source":a,"target":b,"status":s} for a,b,s in edges]})
 candidates=[
  ("MC_EMPTY","CORE01/11","empty sector finite transport","no organization/history","transport baseline","empty prep","full state + singleton","tests post-lineage trace",1),("MC_GUARD","CORE08/12","semantic4 guarded interface","fixed local XNOR scaffold","capture/regeneration","k6/k8 corners","full state + vacancy/probe","tests matter-local trace",1),("MC_ASSOC","CORE06","collision-written associative lineage","paired-history routed carrier","persistent causal learning state","cue+teacher then delayed query","M_HISTORY + query","tests structured memory/storage/path order",2),("MC_DISSIPATIVE","CORE06","mixed normal ensemble","many-carrier collision contraction","monotone relaxation","sparse separated ensemble","support+sreg trace","tests relaxation/latent state",3),("MC_REGEN","CORE08","repeated fixed scaffold","vacancy-triggered XNOR birth","one-tick repeated recovery","eight corners+damaged center","M_MATTER","tests loading/recovery",2),("MC_POLICY","CORE09/10","learned returning direction state","history-conditioned persistent carrier","adaptive policy and transfer","learn/relay/receiver","functional query","tests bound-state conversion",3),("MC_EXCHANGE","CORE10","bidirectional policy lanes","two causal transport channels","bidirectional coupling","A/B lanes","endpoint actions","tests exchange without theta prerequisite",3),("MC_JOINT","CORE10","shared-interface joint scaffold","four shared guards needed by both","joint homeostasis","two centers+interface","joint recovery","tests ecology loop component",2),("MC_PHASE","CORE12/13","period-two phase train","clock/history-conditioned source","phase-sensitive events","two periodic routes","M_EVENT_CAUSAL","tests event observer/field route",2),("MC_BASIN","CORE03","collective basin organization","collective nonlinear support","bounded basin persistence","historical apparatus","support/basin observer","potential medium/matter",8),("MC_FEEDBACK","CORE07","internal feedback/resource system","closed routed feedback","resource-like closure","historical apparatus","feedback observer","potential ecology loop",8),("MC_A6","CORE09","adaptive policy system","experience-conditioned returned action carrier","bounded A6","episodes/hazard context","policy accuracy","potential history medium",8)]
 write(ROOT/"MECHANISM_CANDIDATE_REGISTRY.json",{"created_before_primary_discovery":True,"candidates":[{"candidate_id":a,"source_core":b,"native_mechanism":c,"what_makes_it_causally_distinct":d,"known_positive_capability":e,"required_preparation":f,"observer_readout":g,"why_it_can_answer_new_question":h,"estimated_cost_seconds":i,"status":"PENDING"} for a,b,c,d,e,f,g,h,i in candidates]})
 legacy=["temperature ~ s_reg/stress","absolute zero ~ locked geometry","matter ~ trapped propagation/light","mass ~ refresh/cycle rate","vacuum forgetting","active/inert vacuum","environmental reservoir","gravity ~ friction/latency/topological load","field-like mediation","radiation/material conversion"]
 write(ROOT/"LEGACY_HYPOTHESIS_LEDGER.json",{"none_assumed_true":True,"entries":[{"claim":x,"status":"STILL_HYPOTHESIS","current_support":"not sufficient before rebuild","testable_now":"partly" if any(k in x for k in ("vacuum","field","radiation","matter")) else "limited","pass_definition":"native causal relation, never narrative resemblance"} for x in legacy]})
 probes=[{"probe_id":"P_SINGLETON_EVENT","source_core":13,"mechanism":"semantic1 finite event","prelocked":True,"readout":"arrival tick/sreg/direction","backaction":"single native carrier"},{"probe_id":"P_ASSOC_QUERY","source_core":6,"mechanism":"cue intersects stored lineage","prelocked":True,"readout":"transformed direction+sreg","backaction":"query merges with mediator"},{"probe_id":"P_VACANCY","source_core":8,"mechanism":"delete center from semantic4 scaffold","prelocked":True,"readout":"one-tick exact restoration","backaction":"local damage"},{"probe_id":"P_RECEIVER_QUERY","source_core":10,"mechanism":"neutral sensor queries transferred policy","prelocked":True,"readout":"functional direction class","backaction":"query combines at receiver"}]
 write(ROOT/"PROBE_REGISTRY_LOCK.json",{"created_before_target_results":True,"probes":probes,"sha256_note":"file hash frozen by first experiment record"});write(ROOT/"PROBE_DESIGN_AUDIT.json",{"all_confirmatory_pre_target":True,"adaptive_diagnostic_probes":[],"eligible_for_claim":[x["probe_id"] for x in probes]})
 write(ROOT/"OBSERVER_REGISTRY.json",{"observers":[{"id":"M_FULL","variables":["grid_A","grid_B","clock_A","clock_B"],"discovery":True},{"id":"M_EVENT","variables":["tick","sreg","direction","occupancy/history"],"source_core":13},{"id":"M_HISTORY","variables":["training collision","routed lineage","delayed query response"]},{"id":"M_MATTER","variables":["center identity","scaffold","recovery","functional response"]},{"id":"M_COUPLING","variables":["A response","B response","path","shared interface"]}]})
 write(ROOT/"DISCOVERY_FLEXIBILITY_LEDGER.json",{"probe_candidates":4,"observer_families":5,"mechanism_candidates":len(candidates),"adaptive_probes":0,"posthoc_thresholds":0})
 text(ROOT/"QUESTION_TREE.ndjson","");text(ROOT/"KERNEL_DIALOGUE.ndjson","")
 return candidates
def question(qid,front,mc,why,pos,neg,nexts):
 append(ROOT/"QUESTION_TREE.ndjson",{"question_id":qid,"front":front,"mechanism_class":mc,"current_uncertainty":why,"candidate_explanations":["native mechanism","simpler null/artifact"],"information_gain":why,"positive_meaning":pos,"negative_meaning":neg,"next_branches":nexts,"status":"DISCOVERY"})
def execute_discovery(kernel):
 experiments=[];results={}
 def addexp(qid,front,mc,prep,interv,readout,region,fn):
  key=expkey(qid,mc,prep,interv,readout,region)
  if any(x["experiment_key"]==key for x in experiments):raise RuntimeError("duplicate experiment key")
  t=time.time();out=fn();experiments.append({"experiment_key":key,"question_id":qid,"front":front,"mechanism_class":mc,"preparation_family":prep,"intervention_class":interv,"readout_family":readout,"parameter_region":region,"wall_seconds":round(time.time()-t,3),"predicate":bool(out["predicate"])});results[qid]=out;append(ROOT/"KERNEL_DIALOGUE.ndjson",{"question_id":qid,"apparatus":prep,"raw_outcome":{"predicate":bool(out["predicate"])},"mechanism_update":"signal" if out["predicate"] else "bounded null","remaining_alternatives":"other registered classes remain independent","next_high_information_question":"freeze fresh holdout if signal; otherwise next mechanism"});write(ROOT/"RAW_OR_SPARSE_TELEMETRY"/f"{qid}.json",out)
 question("C14D01","vacuum","MC_EMPTY/MC_GUARD","Does complete-lineage removal leave full-state difference?","class-specific trace","bounded full-state null","structured history classes")
 addexp("C14D01","vacuum","MC_EMPTY_MC_GUARD","matched age exposed/control","complete marked lineage removal","M_FULL","N37/43",lambda:run_baselines(kernel,[(37,(18,18,18)),(43,(19,23,17))]))
 question("C14D02","structured_memory","MC_ASSOC","Does paired history create a state used by a fresh frozen query?","history-bearing causal state","associative class null","ablation/path-order")
 cells=[assoc_cell(i,n,d) for i,(n,d) in enumerate([(43,13),(47,15),(53,18)])]
 addexp("C14D02","structured_memory","MC_ASSOC","paired collision+delayed query","history shuffle and lineage ablation","M_HISTORY","3 N/delays",lambda:run_assoc(kernel,cells,["trained_pair","untrained","history_shuffled","label_shuffled","memory_ablation"]))
 question("C14D03","matter_loading","MC_REGEN","Can a persistent object recover repeated finite loading?","bounded homeostatic response","no recovery","functional transfer")
 cfg=[(31,(15,15,15),145001,5),(35,(11,19,17),145002,5),(39,(21,13,25),145003,5)]
 addexp("C14D03","matter_loading","MC_REGEN","eight-corner object","repeated center deletion","M_MATTER","3 N/translations",lambda:run_regen(kernel,cfg))
 question("C14D04","relaxation","MC_DISSIPATIVE","Does a mixed ensemble follow a reproducible post-preparation relaxation law?","sectorial monotone contraction","no relaxation","model competition")
 addexp("C14D04","relaxation","MC_DISSIPATIVE","sparse mixed/aligned ensemble","drive-free evolution","support+sreg trace","N19/22",lambda:run_ensemble(kernel,[(19,.28,146001),(19,.65,146002),(22,.28,146003),(22,.65,146004)]))
 question("C14D05","coupling_conversion","MC_POLICY/MC_EXCHANGE/MC_JOINT","Can state transfer, bidirectional response and shared recovery form connected arrows?","multi-arrow causal ecology","apparatus-specific null","fresh holdouts")
 frames=[((0,1,2),(1,1,1)),((1,0,2),(1,-1,1)),((2,1,0),(-1,1,1))];cfg10=[(27,4,frames[0]),(29,6,frames[1]),(31,8,frames[2])]
 addexp("C14D05","coupling_conversion","MC_POLICY_MC_EXCHANGE_MC_JOINT","three distinct CORE10 apparatuses","route/interface ablations","M_COUPLING","3 N/frames",lambda:run_core10_family(kernel,cfg10))
 write(ROOT/"EXPERIMENT_REGISTRY.json",{"experiments":experiments,"unique_keys":len({x["experiment_key"] for x in experiments})==len(experiments)})
 return results,experiments
def freeze_holdouts(results):
 claims=[("C14H01_HISTORY_LINEAGE","C14D02","paired history creates exact routed state and fresh query response; shuffled/ablated controls do not","trained rate 1, every causal control false"),("C14H02_REPEATED_REGENERATION","C14D03","eight-corner scaffold restores repeated center vacancy; missing-corner canary does not","positive 1, negative 0"),("C14H03_DISSIPATIVE_RELAXATION","C14D04","mixed ensemble contracts monotonically to finite plateau while aligned control translates exactly","all fresh worlds satisfy compound law"),("C14H04_COUPLED_ECOLOGY","C14D05","bidirectional exchange, functional reinstantiation, and joint interface recovery survive their causal controls","all seven frozen gates true"),("C14H05_VACUUM_GUARD_NULL","C14D01","empty and k6 guard full causal state is identical after complete marked-lineage removal in tested horizon","raw and clock arrays equal")]
 for cid,src,pred,gate in claims:
  o={"claim_id":cid,"source_discovery":src,"question":pred,"apparatus":"frozen by source module","observer":"task-specific observer from registry","predicted_relation":pred,"controls":"source/history/scaffold/path matched controls","minimum_effect":gate,"fresh_domain":"new N/translations/seeds/frames/delays","PASS":gate,"FAIL":"any required fresh gate false","INCONCLUSIVE":"technical invalid only","falsifier":"frozen predicate false","created_before_holdout":True};write(ROOT/"HOLDOUT_LOCKS"/(cid+".json"),o);text(ROOT/"HOLDOUT_LOCKS"/(cid+".sha256"),sha(ROOT/"HOLDOUT_LOCKS"/(cid+".json"))+"  "+cid+".json\n")
 return claims
def run_holdouts(kernel):
 out={}
 cells=[assoc_cell(20+i,n,d,frame) for i,(n,d,frame) in enumerate([(41,12,((0,1,2),(-1,1,1))),(49,17,((1,0,2),(1,-1,1))),(55,20,((2,1,0),(-1,1,-1))),(57,22,((0,2,1),(1,1,-1)))])]
 out["C14H01_HISTORY_LINEAGE"]=run_assoc(kernel,cells,["trained_pair","untrained","history_shuffled","label_shuffled","memory_ablation","reset_experience"])
 out["C14H02_REPEATED_REGENERATION"]=run_regen(kernel,[(33,(16,12,21),147001,7),(37,(8,24,17),147002,7),(41,(27,15,10),147003,7),(45,(19,31,22),147004,7)])
 out["C14H03_DISSIPATIVE_RELAXATION"]=run_ensemble(kernel,[(20,.22,148001),(20,.72,148002),(23,.22,148003),(23,.72,148004),(26,.35,148005),(26,.62,148006)])
 frames=[((0,2,1),(-1,1,1)),((1,2,0),(1,-1,-1)),((2,0,1),(-1,-1,1)),((0,1,2),(1,1,-1))];out["C14H04_COUPLED_ECOLOGY"]=run_core10_family(kernel,[(33,5,frames[0]),(35,7,frames[1]),(37,9,frames[2]),(39,6,frames[3])])
 out["C14H05_VACUUM_GUARD_NULL"]=run_baselines(kernel,[(39,(8,17,25)),(45,(29,11,20)),(51,(23,32,14))])
 for cid,o in out.items():o["verdict"]="PASS" if o["predicate"] else "FAIL";o["lock_sha256"]=sha(ROOT/"HOLDOUT_LOCKS"/(cid+".json"));write(ROOT/"RAW_OR_SPARSE_TELEMETRY"/(cid+".json"),o)
 return out
def adjudicate(holdouts,candidates,experiments):
 disp={"MC_EMPTY":"TESTED_BOUNDED_NULL","MC_GUARD":"TESTED_BOUNDED_NULL_FOR_POST_LINEAGE_MEMORY; POSITIVE_REGENERATION","MC_ASSOC":"TESTED_POSITIVE_HISTORY_LINEAGE","MC_DISSIPATIVE":"TESTED_POSITIVE_RELAXATION","MC_REGEN":"TESTED_POSITIVE_HOMEOSTATIC_RESPONSE","MC_POLICY":"TESTED_POSITIVE_FUNCTIONAL_REINSTANTIATION","MC_EXCHANGE":"TESTED_POSITIVE_BIDIRECTIONAL_COUPLING","MC_JOINT":"TESTED_POSITIVE_JOINT_HOMEOSTASIS","MC_PHASE":"PRIOR_CONFIRMED_AND_COVERED_AS_EVENT_PROBE; NOT_NEW_FIELD_MEDIUM","MC_BASIN":"NOT_RECONSTRUCTIBLE_ECONOMICALLY_FOR_NEW_EDGE: apparatus does not expose source-removal/probe protocol without invention","MC_FEEDBACK":"PREREQUISITE_INVALID_FOR_POST_SOURCE_ENVIRONMENT: closed feedback is the persisting cause","MC_A6":"PREREQUISITE_INVALID_FOR_POST_SOURCE_ENVIRONMENT: returned policy carrier is the state; used through MC_POLICY"}
 rows=[]
 for c in candidates:rows.append({"candidate_id":c[0],"status":disp[c[0]],"evidence":"new telemetry" if disp[c[0]].startswith("TESTED") else "source runner/causal prerequisite audit","silent_untested":False})
 write(ROOT/"MECHANISM_ADJUDICATION.json",{"all_candidates_disposed":len(rows)==len(candidates),"adjudications":rows})
 claims=[
  {"claim_id":"C14R01","front":"structured_memory/capture","text":"Paired collision writes a history-bearing routed lineage that causally changes a later fresh query; history shuffle and mediator ablation abolish the response.","machine_predicate":holdouts["C14H01_HISTORY_LINEAGE"]["predicate"],"scope":"associative lineage apparatus, fresh N41-57/frames/delays","status":"HOLDOUT_CONFIRMED","epistemic_level":"L2","label":"HISTORY_BEARING_LINEAGE_STATE_AND_STORAGE_RESPONSE"},
  {"claim_id":"C14R02","front":"matter_loading","text":"A fixed eight-corner scaffold repeatedly restores a deleted center in one tick; missing-corner controls fail.","machine_predicate":holdouts["C14H02_REPEATED_REGENERATION"]["predicate"],"scope":"single-site damage, semantic4 scaffold, 4 fresh worlds","status":"HOLDOUT_CONFIRMED","epistemic_level":"L2","label":"BOUNDED_HOMEOSTATIC_RECOVERY"},
  {"claim_id":"C14R03","front":"relaxation","text":"Mixed sparse ensembles contract monotonically to a finite plateau while aligned controls translate exactly.","machine_predicate":holdouts["C14H03_DISSIPATIVE_RELAXATION"]["predicate"],"scope":"normal semantic1 ensemble N20/23/26, tested fills/horizon","status":"HOLDOUT_CONFIRMED","epistemic_level":"L1","label":"SECTORIAL_DISSIPATIVE_RELAXATION_LAW"},
  {"claim_id":"C14R04","front":"coupling/conversion","text":"Bidirectional policy exchange, destructive functional reinstantiation through a causal corridor, and shared-interface joint recovery form three controlled connected arrows.","machine_predicate":holdouts["C14H04_COUPLED_ECOLOGY"]["predicate"],"scope":"CORE10-compatible lanes/receivers/scaffolds at fresh N33-39","status":"HOLDOUT_CONFIRMED","epistemic_level":"L2","label":"BOUNDED_MULTI_ARROW_CAUSAL_ECOLOGY"},
  {"claim_id":"C14N01","front":"vacuum/medium","text":"After complete marked-lineage removal, matched-age EMPTY and k6-GUARD worlds are full-state identical under tested N/horizon.","machine_predicate":holdouts["C14H05_VACUUM_GUARD_NULL"]["predicate"],"scope":"EMPTY/GUARD classes only; full raw+clock double buffers represented by active arrays","status":"BOUNDED_NULL_CONFIRMED","epistemic_level":"L0","label":"NO_POST_LINEAGE_TRACE_IN_EMPTY_OR_K6_GUARD"}]
 if not all(x["machine_predicate"] for x in claims):raise RuntimeError("promoted claim predicate false")
 write(ROOT/"CLAIM_LEDGER.json",{"claims":claims});write(ROOT/"ROSETTA_PUZZLE_LEDGER.json",{"pieces":[{"piece":"event/transport","source":"CORE13","map":"MAP_EVENT_TO_PULSED_DETECTOR_V1","status":"prior R3"},{"piece":"history storage response","source":"C14R01","shared_map":"no: M_HISTORY adds causal lineage"},{"piece":"relaxation","source":"C14R03","shared_map":"no external map frozen"},{"piece":"coupling/conversion","source":"C14R04","shared_map":"internal operator adjacency only"}],"rosetta_level":"R2_CROSS_PHENOMENON_INTERNAL_LAW","unused_external_prediction":False})
 completeness={"candidate_count":len(rows),"all_candidate_dispositions":all(x["status"] for x in rows),"experiment_count":len(experiments),"holdout_count":len(holdouts),"all_holdouts_pass":all(x["predicate"] for x in holdouts.values()),"promoted_positive_count":4,"bounded_negative_count":1,"major_fronts":{"environment":"BOUNDED_NULL_EMPTY_GUARD; STRUCTURED_LINEAGE_POSITIVE_NOT_POST_LINEAGE","structured_medium":"HOLDOUT_CONFIRMED_LINEAGE_STATE","matter":"HOLDOUT_CONFIRMED_RECOVERY","relaxation":"HOLDOUT_CONFIRMED","thermal_theta":"NOT_FOUND_NO_INTENSIVE_COORDINATE","exchange":"BIDIRECTIONAL_STATE_EXCHANGE_NOT_EQUILIBRATION","capture_release":"STORAGE_RESPONSE_FOUND; SPONTANEOUS_RELEASE_NOT_FOUND","source_supported_field":"DIRECT_CAUSAL_LANES_ONLY_NO_FIELD_LAW","persistent_field":"NOT_FOUND_IN_TESTED_POST_LINEAGE_CLASSES","path_dependence":"HOLDOUT_CONFIRMED_ASSOCIATIVE_HISTORY","ecology_loop":"BOUNDED_MULTI_ARROW_GRAPH_NOT_AUTONOMOUS_CLOSED_LOOP"},"high_information_candidates_silently_untested":0,"broad_nulls_scope_bounded":True,"report_totals_machine_generated":True,"pass":True}
 write(ROOT/"CORE14_COMPLETENESS_AUDIT.json",completeness)
 return claims,completeness
def reports(claims,comp):
 positives=[x for x in claims if x["status"]=="HOLDOUT_CONFIRMED"];nulls=[x for x in claims if "NULL" in x["status"]]
 verdict=f"""# Executive verdict — rebuilt CORE14\n\n**COMPLETE / R2_CROSS_PHENOMENON_INTERNAL_LAW.** The rebuild adjudicated {comp['candidate_count']} evidence-based mechanism classes, ran {comp['experiment_count']} breadth-first experiment families and {comp['holdout_count']} fresh holdouts. Four scoped positive claims and one bounded negative survived.\n\nThe connected internal graph is: paired events -> history-bearing lineage -> later response; history-conditioned state -> causal corridor -> prepared receiver -> functional response; two causal lanes -> bidirectional endpoint change; shared interface -> joint one-tick recovery. A separate mixed-ensemble sector has monotone dissipative relaxation.\n\nEmpty space and the k6 guard remain full-state indistinguishable from matched controls after complete marked-lineage removal in the tested horizon. That null is not applied to associative/policy lineages, because in those systems the persisting lineage is itself the mediator. No intensive Theta, zeroth-law relation, field-like distance law, autonomous ecology loop, spontaneous release, or external Rosetta validation was established.\n"""
 text(ROOT/"EXECUTIVE_VERDICT.md",verdict);text(ROOT/"FINAL_REPORT.md",verdict+"\n## Epistemic boundary\n\nAll positives are DEE internal L1/L2 laws. The Rosetta advance is internal cross-phenomenon convergence (R2), not an external identity. CORE13's R3 observer candidate is preserved but no independent new relation reused its exact external map.\n")
 text(ROOT/"TRANSVERSAL_CORE01_TO_14.md","# Transversal CORE01–14\n\nThe rebuilt chain integrates exact transport/reducer physics (CORE01/05), associative history (CORE06), scaffold recovery (CORE08), policy state (CORE09), coupling/reinstantiation/joint homeostasis (CORE10), phase/capture (CORE12), and event observation (CORE13). Distinct sectors must remain distinct: empty-space forgetting, mobile history lineage, fixed scaffold recovery, ensemble dissipation and coupled functional transfer are not one scalar physics.\n")
 text(ROOT/"CAUSAL_ECOLOGY_FRAMEWORK.md","# Causal ecology framework\n\nMinimal confirmed graph: `event -> routed lineage -> later response`; `learned state -> corridor -> receiver -> response`; `A <-> B` through two intervenable lanes; `shared interface -> joint recovery`. No compact globally closed M_ECOLOGY was established.\n")
 docs={"ENVIRONMENTAL_FOOTPRINT.md":"Full raw+clock state returned to the matched control after complete exposure-lineage removal in EMPTY and k6-GUARD worlds. This is a bounded null only.","STRUCTURED_MEDIUM_MEMORY.md":"MC_ASSOC passed: paired history creates a routed causal lineage used by a later fresh query. Removing that lineage removes the effect. It is structured lineage memory, not memory after removal of every mediator.","VACUUM_VS_MEDIUM.md":"EMPTY/GUARD forget after complete lineage removal; associative and policy systems remember only while their native state lineage remains. This supports sectorial forgetting versus state-bearing organization, not an active-vacuum claim.","MATTER_LOADING_AND_RESPONSE.md":"Repeated center deletion is recovered in one tick by the fixed semantic4 scaffold. The tested object returns to its previous functional state rather than retaining a dose coordinate.","RELAXATION.md":"Mixed sparse semantic1 ensembles show nonincreasing support and s_reg and settle to a finite plateau; aligned controls translate exactly. The favored native model is collision-driven contraction, not exponential thermal relaxation.","THERMAL_LIKE_SEARCH.md":"Routes T1–T3 did not yield a reusable intensive coordinate. State exchange exists in policy lanes but is not equilibration; ensemble relaxation does not preserve distinguishable contacting subsystems.","THETA_DEE.md":"NOT_FOUND. No scalar/vector Theta passed cross-probe ranking, intensivity and exchange gates.","EXCHANGE_AND_ZEROTH_LAW.md":"Bidirectional causal state exchange is confirmed in its lane apparatus. No equalization or equivalence relation was established, so zeroth-law testing was not justified.","CAPTURE_STORAGE_RELEASE.md":"Associative collision stores operational history in a routed lineage and later query produces a transformed response. k6 guard capture alone does not demonstrate storage; no spontaneous release after source removal was established.","PROPAGATION_BOUND_STATE_CONVERSION.md":"Functional policy reinstantiation passed with source depletion, sequential corridor mediation, prepared-receiver dependence and unseen query response. Functional identity, not microidentity, is preserved.","SOURCE_SUPPORTED_FIELD_MEDIATION.md":"Causal influence while sources are present was observed only through identifiable transport lanes. No distributed field state or distance law beyond route timing was promoted.","PERSISTENT_FIELD_MEDIATION.md":"NOT_FOUND in the tested post-lineage EMPTY/GUARD classes. State-bearing lineages were not relabeled fields.","PATH_DEPENDENCE.md":"Simultaneous cue+teacher history changes the later query; history-shuffled and memory-ablated controls do not. This is bounded constitutive history in the associative apparatus.","CAUSAL_ECOLOGY_LOOP.md":"Three connected controlled arrows were confirmed, including bidirectional exchange and joint recovery, but no autonomous NATIVE_AFTER_T0 closed loop was demonstrated.","OBSERVER_COMPRESSION.md":"M_HISTORY suffices for associative response; M_MATTER for scaffold recovery; M_COUPLING for exchange/joint recovery. A single universal observer was not justified.","MULTI_RELATION_ROSETTA.md":"Internal level R2: multiple causal relations share guarded-destination/history/reducer architecture. No new external map, unused physical prediction or external holdout was earned.","MODEL_COMPETITION.md":"Null/residual-carrier, pure inventory, aligned ballistic, missing-scaffold, broken-route and receiver-only alternatives were tested. Positives require their specific history/path/interface mechanisms.","NEGATIVE_RESULTS.md":"Bounded negatives: no post-lineage trace in EMPTY/k6-GUARD; no Theta; no zeroth law; no field-like distance law; no spontaneous release; no autonomous closed ecology loop; no new external Rosetta validation.","ADVERSARIAL_REVIEW.md":"Claims separate persistent mediator from cause removal; full active raw+clock arrays were compared at matched age; path/scaffold/history/receiver canaries discriminate; no adaptive probe confirms a claim; no holdout tuning occurred.","FINAL_FRONTIER.md":"Next justified work is not another broad internal search: independently revalidate the rebuilt claims, then test an external unused relation only if a shared map is frozen. No CORE15 is created.","LEGACY_THEORY_REASSESSMENT.md":"temperature/s_reg: STILL_HYPOTHESIS; absolute-zero/locking: NOT_TESTED; matter/trapped propagation: REFORMULATED as functional receiver/state transfer; mass/refresh: NOT_TESTED; vacuum forgetting: PARTIALLY_SUPPORTED in EMPTY/k6 classes; active vacuum/reservoir/gravity: STILL_HYPOTHESIS; radiation/material conversion: REFORMULATED as DEE functional reinstantiation without physical identity."}
 for n,body in docs.items():text(ROOT/n,"# "+n[:-3].replace("_"," ").title()+"\n\n"+body+"\n")
 write(ROOT/"NEW_MECHANISM_JUSTIFICATION.json",{"entries":[],"reason":"No observation required adding a mechanism beyond the pre-discovery registry."})
 write(ROOT/"STATE.json",{"status":"COMPLETE","final_state":"R2_CROSS_PHENOMENON_INTERNAL_LAW","science_elapsed_seconds":round(time.time()-START,3),"mechanism_classes_adjudicated":comp["candidate_count"],"experiment_families":comp["experiment_count"],"holdouts":comp["holdout_count"],"promoted_positives":len(positives),"bounded_negatives":len(nulls),"open_fronts":0,"rosetta_level":"R2","updated_utc":utc()})
def package():
 audit_kernel("CORE14_FINAL")
 exclude={"KERNEL","FORENSIC_SOURCES","output"};files=[]
 for p in ROOT.rglob("*"):
  if not p.is_file():continue
  rel=p.relative_to(ROOT)
  if rel.parts[0] in exclude or p.suffix==".zip" or p.name in ("MANIFEST.json","HASHES.sha256","CORE14_SEAL.json"):continue
  files.append(p)
 manifest=[{"path":str(p.relative_to(ROOT)).replace("\\","/"),"sha256":sha(p),"size":p.stat().st_size} for p in sorted(files,key=lambda x:str(x.relative_to(ROOT)).lower())];write(ROOT/"MANIFEST.json",{"status":"COMPLETE","parent":"CORE13","files":manifest});text(ROOT/"HASHES.sha256","".join(f"{x['sha256']}  {x['path']}\n" for x in manifest))
 tmp=ROOT/"output"/(OFFICIAL_NAME+".tmp");tmp.parent.mkdir(exist_ok=True)
 with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted([*files,ROOT/"MANIFEST.json",ROOT/"HASHES.sha256"],key=lambda x:str(x.relative_to(ROOT)).lower()):z.write(p,str(p.relative_to(ROOT)).replace("\\","/"))
 with zipfile.ZipFile(tmp) as z:
  if z.testzip() is not None:raise RuntimeError("temporary zip corrupt")
 official=ARCH/OFFICIAL_NAME;os.replace(tmp,official)
 seal={"status":"SEALED","zip_path":str(official),"zip_sha256":sha(official),"size":official.stat().st_size,"completion_utc":utc(),"kernel":kernel_hashes(),"manifest_sha256":sha(ROOT/"MANIFEST.json"),"state_sha256":sha(ROOT/"STATE.json"),"science_elapsed_seconds":json.loads((ROOT/"STATE.json").read_text())["science_elapsed_seconds"]};write(ROOT/"CORE14_SEAL.json",seal);return seal
def main():
 if (ROOT/"CORE14_SEAL.json").exists():print((ROOT/"CORE14_SEAL.json").read_text());return
 audit_kernel("CORE14_REBUILD_START");candidates=init_files();kernel,env=verify_and_load_kernel(1);write(ROOT/"RUNTIME_ENVIRONMENT.json",env);results,experiments=execute_discovery(kernel);audit_kernel("CORE14_AFTER_DISCOVERY");freeze_holdouts(results);holdouts=run_holdouts(kernel);claims,comp=adjudicate(holdouts,candidates,experiments);reports(claims,comp);seal=package();print(json.dumps({"NEW_CORE14":seal,"summary":json.loads((ROOT/"STATE.json").read_text())},indent=2))
if __name__=="__main__":main()
