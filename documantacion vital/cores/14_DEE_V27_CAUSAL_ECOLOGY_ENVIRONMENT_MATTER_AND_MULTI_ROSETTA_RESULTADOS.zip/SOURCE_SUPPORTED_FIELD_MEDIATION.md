# Source Supported Field Mediation

Influence while sources persist was restricted to identifiable lanes with causal cuts. No distributed field or native distance law was promoted.
