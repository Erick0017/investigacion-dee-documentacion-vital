# Structured Medium Memory

Associative paired history creates a routed causal lineage used by later fresh queries. History shuffle, reset and mediator ablation remove the response. The lineage is the persisting mediator; this is not memory after deleting the mediator.
