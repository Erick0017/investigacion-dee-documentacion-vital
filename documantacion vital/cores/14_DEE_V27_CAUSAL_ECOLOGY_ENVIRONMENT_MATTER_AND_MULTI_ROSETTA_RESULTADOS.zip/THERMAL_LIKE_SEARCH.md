# Thermal Like Search

T1–T3 yielded no reusable intensive coordinate. Bidirectional state exchange is not equilibration; relaxation did not preserve contacting A/B systems.
