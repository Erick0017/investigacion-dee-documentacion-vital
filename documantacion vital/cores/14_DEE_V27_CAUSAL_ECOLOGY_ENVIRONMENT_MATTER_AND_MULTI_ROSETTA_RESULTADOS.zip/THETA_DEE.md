# Theta Dee

NOT_FOUND: no ordinal/scalar/vector coordinate passed cross-probe, intensivity and exchange requirements.
