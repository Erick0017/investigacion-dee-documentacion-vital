# Vacuum Vs Medium

EMPTY and k6-GUARD share raw forgetting plus a clock trace. Associative and policy sectors retain functional state lineages. The distinction is sectorial, not a universal active-vacuum law.
