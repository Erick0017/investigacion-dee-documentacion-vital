from pathlib import Path
import subprocess,sys
p=Path(__file__).resolve().parent/"RUNNERS"/"run_core14_causal_ecology_rebuild.py"
raise SystemExit(subprocess.run([sys.executable,"-I","-B",str(p)],cwd=str(p.parent.parent)).returncode)
