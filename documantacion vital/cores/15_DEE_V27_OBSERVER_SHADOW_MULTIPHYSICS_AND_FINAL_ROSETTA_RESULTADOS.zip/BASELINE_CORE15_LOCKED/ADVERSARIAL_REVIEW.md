# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

All new claims used frozen source, OS-entropy worlds, exact metrics and paired canaries. No tolerance, observer, metric or sign changed after challenge generation. The coupled panel risks being a generic detector description; model competition therefore blocks external promotion. Clock invisibility is bounded to the singleton panel. Ensemble contraction is not temperature or friction.
