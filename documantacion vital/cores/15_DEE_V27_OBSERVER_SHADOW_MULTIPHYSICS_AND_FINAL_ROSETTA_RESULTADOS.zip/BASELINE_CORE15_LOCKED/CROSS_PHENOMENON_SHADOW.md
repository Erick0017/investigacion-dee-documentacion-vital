# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

No single scalar shadow survived. A small coupled family did: kinematic, payload/semantic, interface topology, phase/history and ordered-lineage components. It predicts motion, reduction, source persistence, capture, dissipative ensemble response and learned query response in frozen domains.
