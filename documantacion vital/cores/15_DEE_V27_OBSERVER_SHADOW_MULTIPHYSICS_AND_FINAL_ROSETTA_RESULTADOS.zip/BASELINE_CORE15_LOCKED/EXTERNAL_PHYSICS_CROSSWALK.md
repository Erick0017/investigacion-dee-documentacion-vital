# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

The event sector remains structurally comparable to finite-resolution pulsed detection. Directional ensemble contraction is only qualitatively dissipative; guard capture is only an absorbing-interface analogue; associative history is a memory response. No shared calibration, units or external numerical law joins these sectors.
