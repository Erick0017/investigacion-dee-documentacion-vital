# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Future test: first identify one physical apparatus where the same preparation/measurement map jointly predicts (1) path delay, (2) phase/history-conditioned pile-up or exclusion, and (3) organization-dependent capture using one frozen calibration. Units, uncertainty and detector dead-time must be preregistered; a held-out geometry must be predicted without refit. Failure of any relation falsifies the proposed shared map while leaving internal DEE laws intact.
