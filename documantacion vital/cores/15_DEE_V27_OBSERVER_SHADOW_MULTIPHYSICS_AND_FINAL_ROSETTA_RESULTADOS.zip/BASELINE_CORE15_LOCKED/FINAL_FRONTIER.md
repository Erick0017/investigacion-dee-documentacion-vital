# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

The robust frontier is intervention-relative operational equivalence: different full states may share a shadow until a specific interaction exposes the hidden residual. The next justified step is the external falsification protocol for the existing event-sector map or a specifically motivated mobile-object/field prerequisite test. CORE16 is not created.
