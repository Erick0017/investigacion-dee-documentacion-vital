# Executive verdict — CORE15

**COMPLETE — MULTI_RELATION_INTERNAL_CONVERGENCE.** CORE15 ran 56 executions across eight mechanism classes. The frozen confirmation passed 24/24 fresh positives and 24/24 causal canaries.

The central result is a small coupled family of observer shadows, not one scalar or one universal quotient. Occupancy alone is insufficient. Direction, payload, semantic/source class, relative topology, phase/target history and ordered lineage become necessary under different interactions. Full clock state can differ while singleton raw trajectories remain identical in the tested horizon.

No mass, weight, temperature, pressure, light ontology, field law, quantum law or unified external Rosetta is claimed. The final synthesis attempt stopped at internal convergence because no shared external numerical map or unused external prediction was identifiable.

## Claims

- `C15R01` — Operational equivalence is intervention-relative: six hidden coordinate classes are necessary for their corresponding future response while identical-coordinate canaries remain equivalent. (FRESH_REVALIDATED)
- `C15R02` — At fixed support, s_reg, semantic and clock, direction distribution distinguishes exact translation from collision-driven ensemble contraction. (FRESH_REVALIDATED)
- `C15R03` — Clock-only differences persist yet are behaviorally invisible to singleton raw trajectories in the frozen horizon; raw-direction canaries remain detectable. (BOUNDED_CONFIRMED)
- `C15R04` — A small coupled family of causal shadows predicts eight distinct interaction families without reading full Q0, but no one flat universal scalar was found. (FRESH_REVALIDATED)

## Boundary

The result is exact within frozen DEE apparatuses and does not establish DEE as our universe.
