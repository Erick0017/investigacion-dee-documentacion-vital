# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Exactly one final synthesis attempt was made after the native graph and fingerprints were frozen. Calibration subset: transport timing, interface response and ensemble contraction. Candidate: a zero-label causal-record map. Competitors: generic detector, ballistic transport, independent interface threshold and independent relaxation models. The independent models fit with equal or greater specificity; the shared map made no unused quantitative external prediction. Outcome: `MULTI_RELATION_INTERNAL_CONVERGENCE`, not a shared external map.
