# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

Destination reduction is many-to-one; organized history can remain recoverable; mixed ensembles contract. No bridge to thermodynamic entropy was established.

Native mechanisms considered: reducer, history lineage, ensemble contraction.

Observer: task-relative information ledger.
