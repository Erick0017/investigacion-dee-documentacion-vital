# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: BOUNDED_RESULT

Prior period-two source-supported propagation, phase/path response and fresh semantic-source distinction survive; reflection/refraction/dispersion/emission sector not established.

Native mechanisms considered: semantic4 source train, destination reducer/exclusion.

Observer: M_EVENT_CAUSAL.
