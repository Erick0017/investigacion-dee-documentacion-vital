# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

Fresh organized-versus-shuffled equal-inventory interfaces gave capture versus transmission in 3/3 worlds with 3/3 identical-organization canaries.

Native mechanisms considered: period-two event x semantic-topological guard.

Observer: M_INTERFACE.
