# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

M_EVENT_CAUSAL remains the event-sector observer; S_CAUSAL_PANEL_V1 passed all 24 fresh positives and 24 canaries across eight families.

Native mechanisms considered: system-interaction-detector records.

Observer: S_CAUSAL_PANEL_V1.
