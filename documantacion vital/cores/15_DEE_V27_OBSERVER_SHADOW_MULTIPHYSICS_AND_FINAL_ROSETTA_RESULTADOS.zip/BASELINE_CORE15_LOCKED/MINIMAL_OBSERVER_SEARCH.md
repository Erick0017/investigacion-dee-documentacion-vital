# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

`M_OCCUPANCY` failed broadly. `M_EVENT_CAUSAL` remains minimal in the event sector. `M_HISTORY` and `M_MATTER_REL` add information only where future response or organized interfaces require it. Backward ablation and fresh canaries selected `S_CAUSAL_PANEL_V1`; Q0 is sufficient but needlessly expensive.
