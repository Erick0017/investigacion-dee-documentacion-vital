# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

Direction-hidden state pairs diverged in discovery and 3/3 fresh worlds; identical-direction canaries remained equal.

Native mechanisms considered: directed singleton.

Observer: route + direction.
