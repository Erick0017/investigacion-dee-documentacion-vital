# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Native cross-links: direction controls both motion and ensemble collisions; semantic plus geometry controls source/interface behavior; phase plus target history controls event records; ordered lineage controls later function. Clock state is computationally real yet conditionally invisible.
