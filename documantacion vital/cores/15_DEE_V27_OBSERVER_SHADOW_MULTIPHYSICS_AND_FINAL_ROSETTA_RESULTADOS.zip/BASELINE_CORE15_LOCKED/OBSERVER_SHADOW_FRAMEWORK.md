# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

The empirical quotient test used state pairs equal under a candidate projection and the same controlled future interaction. Eight hidden-coordinate classes were tested. `S_CAUSAL_PANEL_V1` is not a flat vector imposed on every task: it is a coupled family whose components are activated only when their causal ablation matters.
