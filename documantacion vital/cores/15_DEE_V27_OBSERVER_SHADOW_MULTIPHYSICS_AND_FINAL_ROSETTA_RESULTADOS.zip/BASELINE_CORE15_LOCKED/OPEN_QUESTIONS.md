# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Open: whether a mobile persistent organization exists; whether any remote mediator survives causal cuts; whether a closed ensemble admits exchange and an intensive coordinate; whether a medium-supported collective mode exists; and whether the CORE13 event map predicts an external held-out apparatus relation.
