# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: BOUNDED_RESULT

The local guard has exact k=5/6 and k=7/8 changes, but these are local regime thresholds, not a collective thermodynamic phase transition.

Native mechanisms considered: semantic4 neighbor-count guard.

Observer: guard count + center state.
