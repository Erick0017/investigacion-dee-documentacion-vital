# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: BOUNDED_RESULT

Exact local guard thresholds and recovery supply load/failure response, but no stress-strain scaling or deformation field was measured.

Native mechanisms considered: k>=6 retention; k=8 birth.

Observer: local topology + response.
