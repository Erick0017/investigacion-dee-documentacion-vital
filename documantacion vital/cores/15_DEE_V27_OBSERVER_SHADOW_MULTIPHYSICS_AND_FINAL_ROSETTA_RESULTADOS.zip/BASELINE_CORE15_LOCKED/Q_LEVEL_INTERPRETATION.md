# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Q0 is retained as the full-state baseline. Historical Q1-Q3 are source-specific coarse, relational and history-aware representations. Q4 is not supported as a universal operational layer. None is treated as a literal spatial dimension.
