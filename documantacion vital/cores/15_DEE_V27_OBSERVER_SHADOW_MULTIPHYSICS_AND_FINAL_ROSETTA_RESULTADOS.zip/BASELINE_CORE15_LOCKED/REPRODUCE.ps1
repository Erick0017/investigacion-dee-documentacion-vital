$ErrorActionPreference = "Stop"
$Python = "D:\Descargas\ANACONDA MINICONDA\python.exe"
& $Python -I -B ".\RUNNERS\run_core15_observer_shadow_multiphysics.py"
