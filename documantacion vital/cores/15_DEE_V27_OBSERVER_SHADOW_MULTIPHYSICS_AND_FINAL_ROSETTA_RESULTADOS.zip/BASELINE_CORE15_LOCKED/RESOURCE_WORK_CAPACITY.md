# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: BOUNDED_RESULT

s_reg contributes causally to reducer output in 3/3 fresh payload pairs, but transfer/depletion/recharge accounting needed for an energy/work map is absent.

Native mechanisms considered: capped destination reduction.

Observer: s_reg flow at destination.
