# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

One final synthesis candidate mapped `S_CAUSAL_PANEL_V1` to a generic physical apparatus record: geometry, event payload, material response and history. It was rejected as a shared external Rosetta because a generic detector architecture explains the same structure, no cross-sector unit conversion is identifiable, and no unused numerical external relation follows.
