# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

Direction, path and relative guard geometry changed fresh outcomes under matched inventory; topology is a causal observer component.

Native mechanisms considered: route, direction, guard adjacency.

Observer: relational geometry.
