# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

At fixed support/payload/clock, mixed direction ensembles contracted and aligned controls translated in 3/3 fresh worlds; no Theta or equilibrium claim.

Native mechanisms considered: collision-driven ensemble contraction.

Observer: support + s_reg + direction distribution.
