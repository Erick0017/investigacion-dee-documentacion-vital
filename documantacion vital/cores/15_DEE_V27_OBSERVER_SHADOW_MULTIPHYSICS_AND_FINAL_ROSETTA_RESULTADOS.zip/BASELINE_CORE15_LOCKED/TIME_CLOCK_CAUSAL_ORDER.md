# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: TESTED_POSITIVE

Route/event order and phase history are predictive; absolute source-clock differences were behaviorally invisible to singleton raw motion within the frozen horizon.

Native mechanisms considered: clock skew product, relative event timing, history.

Observer: relative timing + phase; absolute clock residual only when queried.
