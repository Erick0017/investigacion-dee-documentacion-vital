# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

CORE15 does not append a new ontology. It reweights the CORE01–14 graph by the MASTER audit and adds a fresh law: operational equivalence is intervention-relative. Several earlier mechanisms become one causal architecture only through a coupled observer family; they do not collapse to one universal scalar.
