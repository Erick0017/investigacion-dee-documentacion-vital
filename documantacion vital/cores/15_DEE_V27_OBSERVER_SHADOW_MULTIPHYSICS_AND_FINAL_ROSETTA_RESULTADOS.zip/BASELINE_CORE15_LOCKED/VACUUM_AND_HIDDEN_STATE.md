# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

## Status: BOUNDED_RESULT

CORE14 clock trace persists after raw reset but is functionally null under frozen probes; CORE15 found clock-only singleton pairs raw-equivalent in 3/3 fresh worlds.

Native mechanisms considered: autonomous clock skew product.

Observer: M_CLOCK_RESIDUAL.
