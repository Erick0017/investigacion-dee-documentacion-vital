# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

Occupancy hides direction, payload, semantic, topology, phase and history. These residuals become visible under their corresponding interventions. A clock residual remained raw-invisible for singleton transport within the frozen horizon, demonstrating that full-state difference need not imply operational difference in every domain.
