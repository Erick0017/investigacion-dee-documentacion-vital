# CORE15 — Observer-shadow multiphysics

Canonical source: `CORE15_CANONICAL_SUMMARY.json`. All external labels below are interpretations after native fingerprints; none identifies DEE with the physical universe.

The detector sees interaction records, not the whole substrate. Hidden coordinates matter conditionally: direction at motion, payload at reduction, semantic at source recurrence, topology at interfaces, phase at convergent paths, and lineage at learned response. Absolute clock detail can remain hidden in a task where relative causal order is unchanged.
