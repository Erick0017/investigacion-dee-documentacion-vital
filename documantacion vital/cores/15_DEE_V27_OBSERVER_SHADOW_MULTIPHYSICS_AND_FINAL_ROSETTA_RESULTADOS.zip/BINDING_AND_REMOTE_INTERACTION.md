# Binding and remote interaction

No remote trajectory change exists to test attraction, repulsion or binding. Contact reduction must not be renamed binding.
