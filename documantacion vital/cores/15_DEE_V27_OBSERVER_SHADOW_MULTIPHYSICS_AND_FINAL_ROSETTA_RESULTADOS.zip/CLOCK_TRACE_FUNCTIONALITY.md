# Clock trace functionality

Fresh C15XC04 passed 8/8 clock-only equalities and 8/8 raw-direction canaries. The associative extension also remained functionally equal. Other untested native mechanisms could still read clock.
