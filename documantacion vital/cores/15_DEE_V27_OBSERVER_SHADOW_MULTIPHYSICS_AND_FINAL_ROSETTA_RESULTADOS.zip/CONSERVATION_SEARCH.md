# Conservation search

Local capped accounting is exact below and at saturation. Overflow explicitly destroys payload, and many-to-one reduction destroys distinctions. No global conservation law follows.
