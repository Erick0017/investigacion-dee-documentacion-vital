# Continuum and coarse closure

Equal bulk support, payload and direction sums did not close the next state. Adding destination-fiber multiplicity produced exact one-step support prediction in a sparse empty-destination sector and passed 8/8 fresh worlds plus 8/8 occupied-destination canaries. This is not Navier–Stokes or continuum closure.
