# Cross-phenomenon shadow

The same route/destination representation links motion, detector aggregation and one-step support. Guard topology and ordered history remain separate coupled shadows. This is cross-phenomenon reuse without a universal scalar.
