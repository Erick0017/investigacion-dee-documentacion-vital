# External physics crosswalk

Structural candidates are limited: event timing resembles detector/transport architecture; guard blocking resembles opacity at the response level; mobile identity resembles kinematics without inertia; reducer accounting resembles saturating detector response. None is an external identity or shared physical map.
