# Field mediation

Distributed clock traces, source trains and joint prepared interfaces were tested. Clock traces did not alter raw response; trains acted through direct carriers; joint systems used prepared contact. No serious remote mediator was found.
