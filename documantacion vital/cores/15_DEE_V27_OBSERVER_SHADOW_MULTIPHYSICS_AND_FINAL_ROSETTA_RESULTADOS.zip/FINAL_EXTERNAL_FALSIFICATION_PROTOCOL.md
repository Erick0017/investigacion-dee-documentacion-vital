# Future external falsification protocol

Freeze one physical detector family before values are opened. Calibrate only route distance to arrival delay and simultaneous multiplicity to response saturation. Then predict an unused interface response curve with the same units/scales and no new parameters. Reject the map if timing, saturation or interface prediction exceeds a preregistered measurement/finite-size error budget. No external pass is claimed here.
