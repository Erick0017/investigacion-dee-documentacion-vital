# Friction and internal state

Head-on constellations coalesced and lost identity; offset counter-moving layers did not interact. Therefore no identity-preserving friction apparatus was constructed.
