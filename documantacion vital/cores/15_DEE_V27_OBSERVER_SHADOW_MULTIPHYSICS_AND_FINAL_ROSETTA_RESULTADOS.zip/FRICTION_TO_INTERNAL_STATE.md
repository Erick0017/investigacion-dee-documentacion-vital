# Friction to internal state

Contact loss could be locally accounted by reducer payload, but no persistent distributed internal state, relaxation law or later probe response linked it to heat. The proposed bridge stops at reduction.
