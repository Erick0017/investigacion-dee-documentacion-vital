# Hardness and rigidity response

A persistent guard blocked incident trains without measured deformation. Disorganized equal-inventory controls transmitted. This is an opacity/interface response; it does not supply stress–strain, hardness or elastic coefficients.
