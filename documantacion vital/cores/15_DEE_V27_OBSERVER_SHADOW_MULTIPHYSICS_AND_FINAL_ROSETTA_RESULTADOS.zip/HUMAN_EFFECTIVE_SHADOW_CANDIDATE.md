# Human-effective shadow candidate

A macroscopic apparatus would operationally access relational geometry/direction, event timing/payload, destination multiplicity, organization/topology, history/phase and coupling context. Full clock can remain hidden. This is an instrument-effective candidate, not literal perception.
