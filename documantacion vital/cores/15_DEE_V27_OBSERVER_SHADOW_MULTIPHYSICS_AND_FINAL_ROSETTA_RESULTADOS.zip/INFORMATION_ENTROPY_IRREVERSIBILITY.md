# Information, entropy and irreversibility

Destination reduction is many-to-one; overflow loses s_reg; observer compression hides clock and state tokens. These are computational information-loss results, not thermodynamic entropy.
