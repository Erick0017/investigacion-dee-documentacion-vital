# Radiation-like sector

The native sector now has finite pulses, source-supported period-two emission, unit-step payload-independent delay, active collision redirection, detector aggregation and organization-specific blocking. Passive reflection/refraction, post-capture release and external light identity remain absent.
