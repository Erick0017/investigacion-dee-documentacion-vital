# Mass and inertia

The required mobile candidate was built, then subjected to standardized counter-collision at several sizes. Response was local component loss; no reusable body-level inertia coefficient survived. Voxel count predicts only the trivial fractional loss of one independent component.
