# Matter and existence

The expansion constructed mobile relational identity but not a collision-robust body. Fixed semantic4 guards and inherited regenerative/coupled structures remain matter-like in bounded functional senses. No single ontology unifies them.
