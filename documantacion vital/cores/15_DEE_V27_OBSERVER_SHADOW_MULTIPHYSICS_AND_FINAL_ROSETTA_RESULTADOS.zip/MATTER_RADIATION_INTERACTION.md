# Matter–radiation interaction

Incident trains distinguish organized semantic4 guard topology from equal-inventory shuffled controls on fresh worlds. This supports a bounded material-response classifier, not photon absorption or energy conversion.
