# Measurement and observer

Fresh detector, closure, opacity and clock panels extend S_CAUSAL_PANEL_V1. Geometry, destination fibers, payload aggregation and guard topology enter only where causally necessary. Clock stays excluded from tested raw-effective predictions.
