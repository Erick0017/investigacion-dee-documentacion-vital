# Medium-supported waves

No collective medium mode, attenuation law, dispersion curve or standing pattern was isolated. Source trains are periodic carriers, not sound.
