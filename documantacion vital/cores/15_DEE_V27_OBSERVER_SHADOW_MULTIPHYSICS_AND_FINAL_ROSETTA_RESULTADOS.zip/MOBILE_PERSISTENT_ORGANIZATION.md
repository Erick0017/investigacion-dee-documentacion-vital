# Mobile persistent organization

A sparse semantic1 constellation preserved relative geometry and payload-defined functional identity under fresh translations (C15XC01: 8/8 positives, 8/8 broken-direction canaries). Counter-collision removed a component rather than producing a body-level response. This is bounded mobile functional organization, not robust matter or mass.
