# Motion and kinematics

Relative geometry translated exactly across three new sizes and axis/diagonal directions, and fresh holdouts passed. Collision changes support through reduction. No acceleration law or moving frame transformation was established.
