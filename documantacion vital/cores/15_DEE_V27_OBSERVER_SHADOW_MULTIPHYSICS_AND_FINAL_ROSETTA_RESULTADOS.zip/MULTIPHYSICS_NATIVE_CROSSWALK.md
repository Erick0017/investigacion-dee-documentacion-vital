# Multiphysics native crosswalk

Native response classes now include translation-covariant identity, capped event aggregation, relational coarse closure, organization-specific blocking and conditional hidden clock. Each has its own scope; no classical name defines success.
