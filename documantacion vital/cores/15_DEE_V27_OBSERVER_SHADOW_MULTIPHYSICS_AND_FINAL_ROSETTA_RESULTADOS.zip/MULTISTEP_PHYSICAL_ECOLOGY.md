# Multistep physical ecology

Four tested chains connect motion/contact/reduction, radiation/guard/blocking, ensemble/fibers/support and clock/history/observer. The ecology is connected through routing and reduction but breaks before frictional heating, exchange, remote fields and sound.
