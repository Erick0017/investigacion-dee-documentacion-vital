# Bounded negative results

No body-level inertia, identity-preserving friction, graded hardness, thermal exchange/Theta, passive reflection/refraction, storage/release, non-collisional field, weight, binding, medium-supported wave, sound, viscosity or sharp phase transition was found in the declared apparatuses. None is a universal impossibility claim.
