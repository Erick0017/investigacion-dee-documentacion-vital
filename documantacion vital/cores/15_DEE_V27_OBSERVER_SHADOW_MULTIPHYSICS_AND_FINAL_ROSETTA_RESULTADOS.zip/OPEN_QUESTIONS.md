# Open questions

The decisive frontier is a robust identity-preserving mobile organization. Without it, mass, friction, pressure and moving-observer questions remain shallow. Independent alternatives are a genuine medium collective mode and a source-generated non-collisional mediator. Future work must not reopen bounded nulls by nearby parameter tuning.
