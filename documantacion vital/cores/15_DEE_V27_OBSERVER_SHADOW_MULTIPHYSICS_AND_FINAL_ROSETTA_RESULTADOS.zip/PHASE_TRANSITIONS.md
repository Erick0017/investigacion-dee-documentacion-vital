# Phase transitions

A 45-case size/fill/alignment survey found an exact fully aligned translating endpoint and a finite crossover among mixed preparations. It did not establish a sharp/scaling transition or metastable order parameter.
