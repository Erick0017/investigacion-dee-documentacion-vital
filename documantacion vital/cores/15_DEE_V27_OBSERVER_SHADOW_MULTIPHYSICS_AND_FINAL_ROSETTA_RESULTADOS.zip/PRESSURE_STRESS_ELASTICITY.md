# Pressure, stress and elasticity

Standard train loading of the guard yielded all-or-none organization-specific blocking, not deformation, reversible strain, plastic change or a flux–boundary response law.
