# Property as interaction

Properties were tested as response laws, not stored labels. Mobility was an exact response of relational geometry to translation; guard opacity was an organizational response to incident trains; detector intensity was capped incident aggregation; mass, hardness, temperature and weight failed their stronger operational gates.
