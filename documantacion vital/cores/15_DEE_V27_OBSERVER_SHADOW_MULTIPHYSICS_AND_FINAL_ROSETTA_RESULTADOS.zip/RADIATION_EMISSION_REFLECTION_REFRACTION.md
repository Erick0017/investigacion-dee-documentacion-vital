# Emission, reflection and refraction

Emission and propagation were direct positives. Direction change required an active convergent carrier and therefore is not passive reflection/refraction. The guard suppressed downstream events but released none after source removal and intervention.
