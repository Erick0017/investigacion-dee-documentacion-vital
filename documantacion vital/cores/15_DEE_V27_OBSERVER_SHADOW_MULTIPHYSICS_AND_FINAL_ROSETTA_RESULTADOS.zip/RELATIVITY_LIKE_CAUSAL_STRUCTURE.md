# Relativity-like causal structure

Unit-step transport and causal cones remain internal exact laws, but no interacting persistent moving observer or transformation group exists. Relativity comparison is not licensed.
