# Resource, work and capacity

s_reg obeys exact capped local aggregation and composes over two reductions, with explicit overflow loss. No storage–depletion–recharge cycle was found, so energy/work language is not earned.
