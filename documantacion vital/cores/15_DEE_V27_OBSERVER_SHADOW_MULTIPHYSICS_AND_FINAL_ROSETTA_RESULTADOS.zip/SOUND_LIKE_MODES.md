# Sound-like modes

The organized-medium prerequisite construction failed in the tested routes; frequency and resonance tests were therefore not licensed.
