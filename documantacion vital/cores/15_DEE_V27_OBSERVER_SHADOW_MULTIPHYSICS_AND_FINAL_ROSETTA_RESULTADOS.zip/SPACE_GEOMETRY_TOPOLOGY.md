# Space, geometry and topology

Microscopic Moore routes, relational constellation geometry, destination equivalence classes and semantic guard topology all affect outcomes. No single coarse geometry was shown to govern every sector.
