# Thermal and dissipative

Mixed ensembles contract and aligned ensembles translate, but new collision, joint-scaffold and policy-coupling routes did not produce identity-preserving exchange. Contraction is not temperature.
