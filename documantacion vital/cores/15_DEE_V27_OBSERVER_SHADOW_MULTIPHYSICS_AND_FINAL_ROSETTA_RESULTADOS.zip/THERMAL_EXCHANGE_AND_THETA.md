# Thermal exchange and Theta

No reproducible exchange with persistent distinct A/B identities was found. Consequently no common coordinate, intensivity test, equilibration or zeroth-like transitivity test was licensed.
