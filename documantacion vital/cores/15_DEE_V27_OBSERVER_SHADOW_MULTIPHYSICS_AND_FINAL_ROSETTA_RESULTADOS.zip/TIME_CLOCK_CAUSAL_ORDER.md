# Time, clock and causal order

Route distance predicts arrival timing; phase/history can change event combination; full-state clock can remain hidden. These are distinct coordinates and are not automatically physical time.
