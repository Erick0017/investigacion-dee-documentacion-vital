# Vacuum and hidden state

Pure clock differences persist in full state while remaining raw-invisible across transport, source, reducer, guard, ensemble and associative panels. This strengthens conditional hidden-state equivalence, not universal irrelevance.
