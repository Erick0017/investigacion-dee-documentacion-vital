# Waves and collective modes

Stationary lattices, aligned ensembles and guard media did not yield a disturbance requiring the medium. Independent carrier and local guard explanations remained sufficient.
