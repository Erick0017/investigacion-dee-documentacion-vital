# Weight prerequisites

Weight remains formally inapplicable: no source-generated non-collisional mediator survived construction. A mobile functional candidate alone is insufficient.
