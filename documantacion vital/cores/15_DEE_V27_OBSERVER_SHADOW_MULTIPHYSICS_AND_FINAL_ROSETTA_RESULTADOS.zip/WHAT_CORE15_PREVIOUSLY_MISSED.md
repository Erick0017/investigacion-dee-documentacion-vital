# What baseline CORE15 previously missed

Baseline CORE15 rigorously solved an observer-shadow problem but did not experimentally construct the prerequisites for most physical sectors. This expansion added mobile-identity construction, contact/load routes, exchange routes, radiation completion, field and medium-wave construction, coarse closure, resource accounting, a multi-mechanism clock panel and a regime survey. Baseline results were never reused as new confirmation.
