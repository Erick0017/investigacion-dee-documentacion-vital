# Revisión adversarial

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Los resultados fuertes sobreviven contra modelos más simples; cuando el modelo simple gana, la interpretación compleja se rechaza. Fase, no conmutatividad y probabilidad no se promovieron como cuánticas.

## Evidencia

- Naive overwrite perdió ante el operador incumbente.
- Fiber-only perdió ante branch-union.
- Modelo clásico de semigrupo explicó AB!=BA.
- Cortes y shams aislaron portadores y backaction.

## Límites y falsadores

- El cociente de reloj excluye dominios de wrap uint64.
- La regeneración es acotada al daño/preparación ensayados.

## Datos canónicos

- `CLAIM_LEDGER.json`
- `CANARY_REGISTRY.json`
- `HOLDOUT_REGISTRY.json`
