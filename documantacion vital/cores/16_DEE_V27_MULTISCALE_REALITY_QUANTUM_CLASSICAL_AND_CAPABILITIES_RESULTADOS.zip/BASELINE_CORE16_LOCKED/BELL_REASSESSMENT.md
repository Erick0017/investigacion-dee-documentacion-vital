# Bell Reassessment

The only valid Bell outcome level is the local collision record. Population correlations are summaries, not newly separated physical subsystems. In the final balanced holdout, externally supplied settings and locally generated DEE setting carriers each retained 512/512 trials, produced CHSH=-2.0, and had zero measured signaling. The local generator still begins from externally initialized independent bits. A lambda-dependent schedule was correctly flagged as violating measurement independence.

This is evidence about the tested multilevel apparatus, not a theorem that every possible DEE effective apparatus has been exhausted.
