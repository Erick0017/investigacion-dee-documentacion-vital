# DEE Capabilities Beyond Current Physical Labels

Fresh-confirmed internal capabilities include functional policy reconstruction through an explicit carrier, topology-bounded joint regeneration inherited from the parent, hidden-relation readout, and one-cell-to-train macro amplification. They remain **EXTERNAL_ROSETTA_UNKNOWN**. Internal confirmation is not downgraded because an external implementation is absent, and external feasibility is not inferred from internal success.
