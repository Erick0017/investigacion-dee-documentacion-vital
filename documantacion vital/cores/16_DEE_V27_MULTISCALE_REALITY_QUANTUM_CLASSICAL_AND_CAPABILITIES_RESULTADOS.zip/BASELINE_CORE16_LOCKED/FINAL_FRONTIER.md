# Final Frontier

The next scientifically justified work is not CORE17 by default. The sharpest internal frontier is the occupancy-aware multistep causal quotient: derive and freeze the local incumbent/proposal operator, then test whether it produces a broader closed level. Quantum work requires a genuinely new mechanism with nonadditive alternatives or compatible contextual measurements. External work requires a same-map multirelation calibration and an unused physical prediction. Without one of those prerequisites, continuation would add volume rather than evidence.
