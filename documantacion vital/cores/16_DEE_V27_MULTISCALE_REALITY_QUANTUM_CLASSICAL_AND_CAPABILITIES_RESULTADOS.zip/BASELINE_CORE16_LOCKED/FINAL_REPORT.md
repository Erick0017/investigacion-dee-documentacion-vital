# CORE16 Final Report

CORE16 completed a result-derived tree of 15 questions at depth 3, 16 adaptive discovery/selection experiment modules, and 9 final untouched holdouts. The canonical outcome is a three-level partially ordered ladder, not a universal scalar hierarchy.

## Explicit final answers

1. Three effective levels, plus the full-state reference.
2. E1 destinations/directions/fibers; E2 relational topology/function/history; E3 ensemble distributions and scale parameters.
3. Clock/state tokens can become nuisance; labels, fibers and phase/path data disappear under specific quotients.
4. Payload-position and phase/path information can reappear under selective readout.
5. No promoted quantum law emerges at any level; only bounded analogues occur at E1/E2.
6. No quantum-like property was validated in larger organized systems.
7. Classical repeatability appears at E2/E3 through response equivalence and statistical concentration.
8. The demonstrated classicality is observer inaccessibility plus concentration, not required destruction.
9. At the valid local-collision level CHSH=-2 in both final regimes; E3 is only a statistical summary.
10. Measurement independence, locality/no signaling and complete retention hold in the frozen positives; explicit lambda is a common cause; the dependent-setting canary fails independence.
11. Classical/statistical physics fits E2/E3 partially; quantum, thermodynamic and relativistic theories fit no validated level.
12. No unclassified native phenomenon was promoted.
13. Functional reconstruction, topology-bounded regeneration, relational readout and macro amplification are native.
14. No promoted capability is an observer-only artifact; broad external labels and universal extrapolations would be artifacts.
15. All confirmed extraordinary capabilities remain externally unmapped.
16. Destination/relational causal information connects exact, functional and statistical levels.
17. No external multilevel Rosetta emerged; internal multirelation convergence did.
18. No unused external prediction is justified.

## Epistemic boundary

All promoted results are DEE-internal laws or mechanisms. None identifies DEE with external reality. The conditional H_DEE hypothesis remains open and substantially underdetermined.
