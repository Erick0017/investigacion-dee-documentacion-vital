# How Classical Reality Emerges

Two bounded routes were observed: stable relational/functional equivalence at E2, and statistical concentration at E3. At fixed preparation density, the final untouched scaling exponent was -0.506543, with largest-to-smallest CV ratio 0.305. Thus larger compatible ensembles give more repeatable coarse responses even though their exact fibers remain different.

The demonstrated classicality is observer-limited plus statistical; information destruction was not required.
