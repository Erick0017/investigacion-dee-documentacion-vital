# Information to Effective Physics

DEE effective properties are best described by a mixture of state, relation and response law. Destination topology controls exact local evolution; labeled relations control selective interaction; ordered history controls composition; and hidden fiber volume induces macro probability. The same deterministic substrate therefore supports both exact task-relative dynamics and probabilistic coarse prediction without contradiction.
