param([string]$Python='D:\Descargas\ANACONDA MINICONDA\python.exe')
& $Python -I -B '.\RUNNERS\run_final_holdouts.py'
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
