# Science-Fiction-Like Effects Mechanistically Decomposed

The most dramatic transfer is not teleportation. Training writes a functional direction state; a relay launches an explicit local carrier; every intermediate corridor tick is observed; the source record depletes; a prepared receiver converts the arrival; and only the functional policy is reconstructed. Removing memory, relay, corridor or receiver destroys the effect. Macro amplification likewise comes from a local k5/k6 guard threshold, not action at a distance.
