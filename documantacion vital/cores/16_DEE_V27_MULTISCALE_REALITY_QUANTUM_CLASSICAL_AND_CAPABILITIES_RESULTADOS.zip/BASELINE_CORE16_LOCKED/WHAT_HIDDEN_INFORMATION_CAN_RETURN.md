# What Hidden Information Can Return

Payload-to-relative-position assignment returned under lane-selective collision in 64/64 fresh cases. Count-only phase/path equivalence was broken by the payload/direction readout in 6/6 cases. These are demonstrations of later revealability, not resurrection after physical destruction.

No tested mechanism made the clock-only residual functionally visible, so clock reappearance remains open rather than refuted universally.
