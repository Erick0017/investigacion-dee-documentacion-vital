# What Information an Observer Loses

Bulk support, total payload and direction sum discard destination fibers and therefore cannot close even one step. An unlabeled object shadow discards which payload occupies which relative site. Event count discards phase/path availability visible in payload and direction. The tested clock residual remains a nuisance coordinate in the challenged panels.

Loss must be classified: some is observer loss and recoverable under another interaction; many-to-one reducer output also erases incident identity from the reduced record and is genuine kernel-level compression unless separately stored in history.
