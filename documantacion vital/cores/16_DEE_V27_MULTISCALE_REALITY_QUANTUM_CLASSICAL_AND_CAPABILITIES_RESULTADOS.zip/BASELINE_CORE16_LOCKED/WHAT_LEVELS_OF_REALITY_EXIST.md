# What Levels of Reality Exist

The full raw+clock state is the reference, not counted as an effective level. Three reduced levels survived:

1. **E1 routed causal state**: destinations, directions, incident fibers and task-relevant event payload. It exactly predicts one sparse semantic1 step in 128/128 fresh worlds. It is not a universal dynamics: the simple multistep operator passed 122/128 selection worlds and failed 0/702 occupied-destination cases.
2. **E2 relational response state**: relative organization, labeled relations, topology, function and ordered interaction history. It predicts selective hidden-state readout, reducer order, functional reconstruction and guard amplification.
3. **E3 statistical ensemble state**: density/count/distribution summaries. It predicts an outcome distribution and scale-dependent concentration, not an individual microstate outcome.

These levels are partially ordered and task-relative; E2 and E3 are not one universal scalar chain.
