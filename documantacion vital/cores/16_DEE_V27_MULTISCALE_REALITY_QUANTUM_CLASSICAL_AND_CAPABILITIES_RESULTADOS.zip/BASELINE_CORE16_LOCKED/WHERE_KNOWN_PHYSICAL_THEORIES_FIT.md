# Where Known Physical Theories Fit

- Classical/statistical descriptions map most naturally to E2/E3 through response equivalence and concentration.
- A limited transport/continuum precursor exists at E1, but no PDE closure was derived.
- Quantum theory maps to no validated level: there is no Born law, nonclassical interference, contextuality proof or Bell violation.
- Thermodynamics maps to no validated level because no intensive coordinate/exchange bridge was established.
- Relativity maps to no validated level beyond bounded causal transport; no transformation structure emerged.

These placements are structural comparisons, not external identifications.
