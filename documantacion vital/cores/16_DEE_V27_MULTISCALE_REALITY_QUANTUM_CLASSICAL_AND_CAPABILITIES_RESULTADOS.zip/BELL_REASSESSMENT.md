# Reevaluación de Bell

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

El único aparato Bell físicamente válido construido dio CHSH=-2 con settings externos y generados localmente. Las representaciones superiores no aportaron todavía pares, settings y separación que permitan otro test válido.

## Evidencia

- 512 ensayos completos por régimen, sin postselección y sin señalización marginal.
- El canario detectó dependencia de medición deliberada.

## Límites y falsadores

- El resultado acota el aparato, no todos los niveles futuros.

## Datos canónicos

- `MULTILEVEL_BELL_AUDIT.json`
- `BELL_ASSUMPTION_AUDIT.json`
