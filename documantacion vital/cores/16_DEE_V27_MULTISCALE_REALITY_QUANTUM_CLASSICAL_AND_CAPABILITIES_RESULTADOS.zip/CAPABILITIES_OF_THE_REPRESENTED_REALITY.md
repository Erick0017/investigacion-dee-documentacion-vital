# Capacidades de la realidad representada

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La realidad DEE soporta regeneración acotada, reconstrucción funcional destructiva, direccionamiento por ruta/distancia, recuperación de fase y amplificación micro-macro.

## Evidencia

- Las capacidades pasaron holdouts y canarios causales.

## Límites y falsadores

- Existencia interna, mapa observable externo y control tecnológico humano son estados distintos.

## Datos canónicos

- `CAPABILITY_ATLAS.json`
- `REALITY_ENGINEERING_ACCESS.json`
