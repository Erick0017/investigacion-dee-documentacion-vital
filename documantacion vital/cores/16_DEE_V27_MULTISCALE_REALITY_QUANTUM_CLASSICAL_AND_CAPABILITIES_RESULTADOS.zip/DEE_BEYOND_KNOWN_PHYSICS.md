# DEE más allá de la física conocida

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Residuo de reloj tardíamente visible, reconstrucción funcional destructiva y gating macroscópico por una celda son regularidades nativas aún sin teoría externa identificada.

## Evidencia

- Todas poseen mecanismo causal y controles internos.

## Límites y falsadores

- Sin predicción externa no usada, se mantienen como realidad nativa no clasificada.

## Datos canónicos

- `UNCLASSIFIED_NATIVE_REALITY.json`
