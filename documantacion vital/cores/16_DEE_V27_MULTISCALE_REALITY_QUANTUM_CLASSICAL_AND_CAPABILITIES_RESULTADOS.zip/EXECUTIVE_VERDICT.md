# CORE16 corregido — veredicto ejecutivo

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La realidad DEE requiere cuatro representaciones reducidas útiles además del estado completo. La más profunda es un cociente causal exacto con dinámica multistep; las restantes describen eventos/fase, organización funcional y ensembles estadísticos. La información oculta puede reaparecer, pero otras distinciones sí son destruidas. No se aisló una ley específicamente cuántica ni un mapa externo congelado.

## Evidencia

- 24 mundos y 118 ticks confirmaron el operador exacto sin discrepancias.
- 576/576 ensayos confirmaron la ley probabilística condicionada por la medida de microestados.
- La fase se recuperó en bancos de hasta 30 componentes.
- Las ocho afirmaciones nuevas superaron holdouts y canarios congelados.

## Límites y falsadores

- Sin ley de inercia, nivel térmico, campo no colisional o continuo cerrado.
- CHSH=-2 pertenece al aparato válido probado, no a todos los niveles posibles.
- La Rosetta externa sigue sin mapa ni predicción no usada.

## Datos canónicos

- `REALITY_LEVEL_GRAPH.json`
- `CLAIM_LEDGER.json`
- `CORE16_COMPLETENESS_AUDIT.json`
