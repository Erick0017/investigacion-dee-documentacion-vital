# Campos y ondas en niveles efectivos

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

R1 soporta portadores finitos y trenes periódicos, pero las rutas probadas no produjeron un campo remoto no colisional ni un modo colectivo dependiente del medio.

## Evidencia

- Seis cortes de mediador alteraron la señal; seis shams fuera de ruta no la alteraron.
- Tres medios candidatos no mostraron onda colectiva.

## Límites y falsadores

- No hay ley de distancia, reflexión, refracción o dispersión validada.

## Datos canónicos

- `FIELD_LEVEL_SEARCH.json`
- `WAVE_LEVEL_SEARCH.json`
