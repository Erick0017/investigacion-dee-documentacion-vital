# Cómo emerge la física clásica

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La apariencia clásica parcial surge de dinámica determinista exacta, identidad operacional, compresión del observador y concentración estadística. La destrucción de información contribuye en algunos canales, pero no explica por sí sola la classicalización.

## Evidencia

- R0 es determinista y multistep.
- La identidad funcional tolera reemplazo microscópico.
- Las fluctuaciones decrecen al crecer el ensemble.

## Límites y falsadores

- Faltan inercia colectiva, fuerza y mecánica general de colisión.

## Datos canónicos

- `CLASSICAL_EMERGENCE.json`
