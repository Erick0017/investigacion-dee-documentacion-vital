# Cómo emerge la física estadística

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La probabilidad efectiva nace al agrupar microestados deterministas compatibles y declarar una medida de preparación. El operador exacto empuja esa medida a una distribución de resultados.

## Evidencia

- 576/576 predicciones binarias fueron exactas.
- Cambiar medida uniforme/agrupada cambió 7/8 pares.

## Límites y falsadores

- La distribución no es estocasticidad intrínseca ni ley de Born.

## Datos canónicos

- `EFFECTIVE_PROBABILITY_ATLAS.json`
- `EFFECTIVE_PROBABILITY_MEASURE_SEARCH.json`
