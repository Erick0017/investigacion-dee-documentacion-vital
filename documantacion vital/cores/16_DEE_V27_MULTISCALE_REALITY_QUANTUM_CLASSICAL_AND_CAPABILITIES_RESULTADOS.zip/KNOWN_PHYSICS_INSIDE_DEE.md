# Física conocida dentro de DEE

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La correspondencia interna más fuerte es con física causal/informacional. Hay sectores parciales para mecánica clásica, estadística y propagación, pero ninguna teoría externa completa está identificada.

## Evidencia

- Cada teoría fue ubicada sólo después del grafo nativo.

## Límites y falsadores

- Partículas, QFT, química, termodinámica, campos, relatividad y cosmología permanecen sin mapa suficiente.

## Datos canónicos

- `PHYSICS_PLACEMENT_ATLAS.json`
