# Estado de la Rosetta multinivel

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Existe una Rosetta informacional interna multinivel: estado completo, cociente causal, sombras de evento/organización/ensemble e instrumento. No existe todavía una Rosetta externa congelada.

## Evidencia

- Ocho relaciones internas nuevas comparten suficiencia causal, accesibilidad del observador y equivalencia de respuesta.

## Límites y falsadores

- Faltan múltiples relaciones físicas humanas bajo un mismo mapa y una predicción externa no usada.

## Datos canónicos

- `MULTILEVEL_ROSETTA.json`
- `EXTERNAL_UNUSED_PREDICTIONS.json`
