# Física efectiva multistep

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

El operador ocupado consciente del incumbente cierra exactamente R0 a múltiples ticks. La simple ocupación por bloques no cierra: necesita fibras de destino y estado de rama incumbente.

## Evidencia

- 24 mundos, 118 ticks, cero discrepancias raw/reloj.
- El cociente exacto conserva semantic4 y residuos de reloj necesarios.

## Límites y falsadores

- No se derivó límite continuo ni PDE.

## Datos canónicos

- `OCCUPANCY_AWARE_DESTINATION_OPERATOR.json`
- `MULTISTEP_EFFECTIVE_DYNAMICS.json`
