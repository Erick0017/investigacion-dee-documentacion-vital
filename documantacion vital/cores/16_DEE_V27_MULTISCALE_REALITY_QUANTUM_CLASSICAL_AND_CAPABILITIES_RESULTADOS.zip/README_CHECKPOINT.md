# CORE16 corrected and expanded campaign

This work directory continues the sealed CORE16 baseline under the fixed campaign premise P0: DEE is the representation of the reality being studied.

The directory `BASELINE_CORE16_LOCKED` is imported from the previously sealed official CORE16 ZIP and must not be reinterpreted or modified as new evidence. New experiments, locks, challenges, telemetry, claims, and reports are stored separately.

Official packaging is forbidden until all corrected CORE16 completeness gates pass.
