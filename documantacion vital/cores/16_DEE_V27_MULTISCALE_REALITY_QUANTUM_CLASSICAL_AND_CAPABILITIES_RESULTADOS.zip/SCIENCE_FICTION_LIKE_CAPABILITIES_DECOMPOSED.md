# Capacidades extraordinarias descompuestas

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La reinstanciación no es teletransporte: consume la fuente, usa un portador local observable y reconstruye función en un receptor preparado. La regeneración depende de organización entrenada; el control macro depende de un umbral local k5/k6.

## Evidencia

- Cortes de corredor, receptores no preparados y controles no entrenados fallan como predice el mecanismo.

## Límites y falsadores

- No se demostró copia, mediación remota sin portador ni transformación arbitraria.

## Datos canónicos

- `TRANSFER_REINSTANTIATION_TAXONOMY.json`
- `PROGRAMMABILITY_SEARCH.json`
