# Los niveles descubiertos de realidad

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Se requieren cuatro niveles reducidos: R0 causal exacto, R1 de eventos/fase, R2 de organización/respuesta y R3 estadístico. R2 contiene ramas relacional y funcional superpuestas; por ello la estructura es un grafo, no una escalera única.

## Evidencia

- R0 generalizó exactamente.
- R1 conserva ruta, payload, tiempo y fase.
- R2 conserva identidad funcional y respuesta.
- R3 conserva distribuciones, no resultados individuales.

## Límites y falsadores

- No se justificó un quinto nivel continuo, térmico, de campo o cosmológico.

## Datos canónicos

- `REALITY_LEVEL_GRAPH.json`
- `REALITY_LADDER.json`
- `LEVEL_DISCOVERY_REGISTRY.json`
