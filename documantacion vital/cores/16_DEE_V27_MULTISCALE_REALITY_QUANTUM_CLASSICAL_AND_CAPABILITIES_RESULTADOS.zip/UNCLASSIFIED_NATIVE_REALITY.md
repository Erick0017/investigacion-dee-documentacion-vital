# Realidad nativa no clasificada

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Tres fenómenos fuertes permanecen sin categoría física externa: reloj residual tardío, reconstrucción funcional mediante portador y control de tren por umbral local.

## Evidencia

- Son reproducibles y causalmente aislables.

## Límites y falsadores

- Ninguno produjo aún un efecto externo predicho sin usar en su descubrimiento.

## Datos canónicos

- `UNCLASSIFIED_NATIVE_REALITY.json`
