# Correspondencias externas no resueltas

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Las correspondencias con quantum, masa/inercia, termodinámica, campos, ondas de medio, continuo, relatividad y cosmología permanecen abiertas o acotadas negativamente.

## Evidencia

- Cada ausencia se atribuye al mecanismo/aparato probado, no a P0.

## Límites y falsadores

- No se usa observador distinto como excusa para salvar un mapa contradicho.

## Datos canónicos

- `PHYSICS_PLACEMENT_ATLAS.json`
- `EXTERNAL_ACCESS_PROTOCOLS.json`
