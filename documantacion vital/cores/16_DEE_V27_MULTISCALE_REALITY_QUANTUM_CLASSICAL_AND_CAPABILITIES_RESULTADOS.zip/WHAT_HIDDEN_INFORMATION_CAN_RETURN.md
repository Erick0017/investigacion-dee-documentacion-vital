# Qué información oculta puede regresar

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

El residuo de reloj reapareció tras 11 ticks y la fase de bancos organizados reapareció mediante lectura tiempo/carril. Dirección, semántica y destino reaparecen bajo evolución o interacción adecuadas.

## Evidencia

- No se introdujo una copia nueva del reloj antes de su lectura tardía.
- La misma regla de fase funcionó de 1 a 30 componentes.

## Límites y falsadores

- El linaje externo no codificado y payloads ya convergidos no regresaron.

## Datos canónicos

- `HIDDEN_STATE_RESURRECTION.json`
- `DELAYED_OBSERVABILITY.json`
- `CROSS_SCALE_MEMORY.json`
