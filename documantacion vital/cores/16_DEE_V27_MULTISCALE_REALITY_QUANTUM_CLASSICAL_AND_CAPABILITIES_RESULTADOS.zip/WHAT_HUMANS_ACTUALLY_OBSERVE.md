# Qué observan realmente los humanos

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

En esta campaña, un instrumento observa una sombra de interacción: eventos, tiempos, posiciones, payloads o respuestas. No se ha identificado todavía qué canal físico humano implementa esos observadores DEE.

## Evidencia

- El conteo integrado pierde fase que un detector tiempo/carril recupera.
- Una sonda funcional revela historia que la ocupación no contiene.

## Límites y falsadores

- Ningún readout interno se declara idéntico a una medida humana sin mapa externo.

## Datos canónicos

- `OBSERVER_ACCESSIBILITY_MATRIX.json`
- `EXTERNAL_ACCESS_PROTOCOLS.json`
