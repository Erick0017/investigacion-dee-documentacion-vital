# Qué información queda oculta

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

Dirección, semántica, fase, residuo de reloj, ruta, topología local e historia funcional pueden quedar ocultas bajo observadores comprimidos aun cuando sigan siendo causales.

## Evidencia

- Las parejas igualadas bajo sombras gruesas divergieron con intervenciones predeclaradas.
- R3 oculta cuál microestado compatible ocurrió.

## Límites y falsadores

- Oculto no significa siempre recuperable; el payload reducido por many-to-one puede perderse de verdad.

## Datos canónicos

- `CROSS_SCALE_INFORMATION_FLOW.json`
- `OBSERVER_ACCESSIBILITY_MATRIX.json`
