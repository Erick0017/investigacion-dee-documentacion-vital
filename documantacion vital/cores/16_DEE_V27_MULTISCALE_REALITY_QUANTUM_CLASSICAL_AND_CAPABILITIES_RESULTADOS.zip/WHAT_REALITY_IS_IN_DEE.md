# Qué es la realidad en DEE

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

La realidad completa es el grid raw empaquetado, los relojes locales y la topología toroidal, evolucionados por la regla v27. Fase, historia, linaje, cuencas y función son relaciones o resúmenes causales de esa realidad, no arreglos secretos adicionales.

## Evidencia

- El auditor de estado distinguió almacenamiento persistente, transitorios del tick y descripciones derivadas.
- El cociente R0 elimina información que no modifica futuros dentro del dominio validado.

## Límites y falsadores

- No se asignan nombres como masa, energía o carga a campos del kernel sin una ley operacional.

## Datos canónicos

- `DEE_FULL_STATE_SCHEMA.json`
- `DEE_INFORMATION_CAUSAL_ATLAS.json`
