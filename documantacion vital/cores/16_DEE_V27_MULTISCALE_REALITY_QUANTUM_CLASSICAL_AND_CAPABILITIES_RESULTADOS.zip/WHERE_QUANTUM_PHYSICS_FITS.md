# Dónde encaja la física cuántica

CORE16 corregido adopta P0 como premisa fija: DEE es la representación de la realidad estudiada. Esto no convierte ninguna correspondencia con la física humana en verdadera por decreto; esas correspondencias siguen requiriendo mapas y pruebas independientes.

## Veredicto

No se identificó un nivel que satisfaga conjuntamente interferencia no clásica, contextualidad, ley de Born y correlaciones de Bell. Fase, backaction y no conmutatividad existen, pero modelos clásicos deterministas más simples los explican exactamente.

## Evidencia

- La composición multipath fue aditiva/capada.
- T_d(s)=sign(s+d) explica la no conmutatividad.
- La probabilidad fue ignorancia clásica condicionada por medida.

## Límites y falsadores

- La ausencia en estos aparatos no es exclusión universal de futuros aparatos válidos.

## Datos canónicos

- `QUANTUM_LIKE_LEVEL_ATLAS.json`
- `CONTEXTUALITY_TESTS.json`
- `MULTILEVEL_BELL_AUDIT.json`
