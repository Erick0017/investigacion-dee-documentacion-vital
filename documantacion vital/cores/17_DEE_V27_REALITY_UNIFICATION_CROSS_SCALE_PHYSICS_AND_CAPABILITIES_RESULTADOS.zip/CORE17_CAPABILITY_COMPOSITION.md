# Composición de capacidades


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


La transferencia aprendida pasó sus positivos y controles: fuente agotada, carrier continuo, receptor preparado y query funcional. Al borrar después el receptor, el control damage-only perdió la función. El scaffold XNOR reconstruyó `semantic=7, state=1, s_reg=1, direction=(0,0,0)`, pero la query no recuperó ACTION1.

Conclusión causal: memoria+transferencia componen; transferencia+regeneración fija no. La historia/política es una coordenada ausente del scaffold canónico. La siguiente construcción debe codificar explícitamente esa coordenada en una organización regenerativa.

La amplificación sí compone: el guard local selecciona transmisión repetida. No hay acción remota; el efecto recorre source, route, interface y detector.

## Composición nueva confirmada

Aprendizaje direccional + redundancia + transporte + conversión de receptor componen una reparación funcional fresca después del daño. Requiere copia fuente y ruta; no equivale a regeneración autónoma.
