# Emergencia clásica


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


La apariencia clásica proviene de cuatro mecanismos distintos: cierre exacto de R0, identidad relacional de constelaciones móviles, pérdida de acceso del observer a coordenadas inferiores y concentración estadística en R3. No todo ocultamiento es destrucción: el reloj puede volver. No toda estabilidad es inercial: una constelación mantiene forma en traslación, pero una perturbación afecta componentes localmente y no define un coeficiente colectivo estable.

Por tanto, el objeto clásico acotado es una clase de respuesta/relación, no un conjunto fijo de voxels. La classicalización observada combina cociente causal, organización persistente y compresión del observer; no se justificó llamarla decoherencia cuántica.
