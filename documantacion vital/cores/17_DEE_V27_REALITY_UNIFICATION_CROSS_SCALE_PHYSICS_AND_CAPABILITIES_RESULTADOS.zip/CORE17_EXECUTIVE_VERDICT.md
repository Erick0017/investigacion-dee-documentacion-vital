# CORE17 — Veredicto ejecutivo


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


## Resultado central

La realidad DEE mejor sustentada no forma una escalera lineal única. X_FULL se reduce exactamente a R0; sobre R0 aparecen proyecciones solapadas R1 (eventos y fase), R2-relacional, R2-funcional y R3 (distribuciones condicionadas por medida). La búsqueda de R* no halló una compresión nueva: fase, contexto del receptor y medida de preparación son coordenadas causalmente independientes en las tareas probadas.

CORE17 descubrió y confirmó una ley nueva: una diferencia exclusivamente de reloj puede permanecer ausente del raw durante hasta 584 ticks en los mundos finales y reaparecer, sin introducir otra copia, cuando se abre la rama local sensible al período. En m módulos independientes, exactamente m respuestas cambian. Sobre k clases binarias, la distribución macroscópica es el pushforward binomial exacto.

También convirtió el control k5/k6 en una ley temporal: `E5(h)=max(0,floor((h-10)/2))` y `E6(h)=0` dentro del aparato sellado. Una sola celda guard selecciona una secuencia cuya diferencia acumulada crece con el horizonte.

## Lo que no se promovió

No se encontró estructura específicamente cuántica, campo remoto no portador, modo colectivo de onda, variable térmica intensiva, inercia colectiva ni continuo comprimido multietapa. Estos son nulos acotados, no imposibilidades universales. La transferencia aprendida y la regeneración fija no componen automáticamente: la regeneración recupera un estado canónico, no la historia aprendida.

## Rosetta

No existe Rosetta externa promovible. Hay protocolos funcionales de acceso, pero ninguna calibración externa congelada ni predicción humana unused. El resultado fuerte es interno: un modelo causal multiescala, exacto en R0 y con leyes de acceso parcial en los niveles superiores.

---

# CORE17 — Clausura definitiva

CORE17 se reabrió exclusivamente sobre las ramas vivas de su propia frontera. No se repitieron los 46 mundos finales anteriores, el panel de reloj oculto, el pushforward probabilístico, la ley k5/k6 ni el holdout R0 anterior.

## Nuevos resultados promovidos

1. **Coordenada de política y reparación redundante.** En 8 geometrías de localización, alterar `s_reg` conservó la función mientras resetear dirección la destruyó. El aparato de reparación entrenó una segunda copia, dañó la primera y reinstanció la política por un portador explícito. El holdout posterior al freeze pasó: tratamiento 12/12, corte fuera de ruta 12/12; copia no entrenada, dirección reseteada, copia ausente, corte de ruta y receptor incorrecto 0/12 cada uno.

2. **Compresión causal real de R0.** `R0_FACTOR_52` conserva para celdas ordinarias sólo existencia (1 bit), `s_reg` (16), dirección (12), semántica (4) y fase de reloj (19): 52 bits en lugar de 128. Semántica-4 necesita sus 64 bits raw pero no el reloj. El holdout fresco probó 10 mundos durante 406 pasos con cero discrepancias raw o reloj reducidas. `304980=lcm(195,260,391,782)` es el módulo fijo global mínimo para los periodos locales alcanzables de esa familia.

## Cierre de prerrequisitos

Las políticas aprendidas opuestas mantuvieron dos identidades en el control separado y se redujeron a un único estado en contacto (`s_reg=336`, dirección nula). La perturbación de una pareja redundante actuó localmente, no colectivamente. El híbrido semántica-4/móvil rompió su geometría relativa en un paso. No se construyeron cuerpos que sobrevivan contacto, intercambio con identidad, mediador distribuido no portador, contextos compatibles, subsistemas Bell válidos ni Rosetta externa.

La reparación demostrada es **reconstrucción soportada por una copia aprendida redundante**. No es autorregeneración local, acción remota ni teleportación.

`CORE17_DEFINITIVELY_CLOSED = TRUE`.
