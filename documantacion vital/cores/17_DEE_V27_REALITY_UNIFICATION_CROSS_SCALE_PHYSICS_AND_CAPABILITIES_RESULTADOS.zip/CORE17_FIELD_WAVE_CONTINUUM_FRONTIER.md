# Campos, ondas y continuo


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


Los source trains propagan portadores explícitos a velocidad finita; cortar la boca cambia el receptor y un sham off-path no. Esto no es mediación de campo no colisional. La traza distribuida de reloj sólo actúa cuando una interacción local compatible la lee; no se halló fuente que escriba remotamente ese fondo.

Ninguno de los medios probados produjo shell propagante o modo colectivo periódico independiente de carriers/guards. Los bloques coarse con igual ocupación/s_reg/dirección divergen al tick siguiente cuando cambian las fibras de destino; por ello no cierran.

La física efectiva multietapa confirmada es discreta: el operador R0. CORE17 añadió 9 mundos/54 ticks de descubrimiento y 12 mundos/86 ticks de holdout, todos con cero mismatch. Sumados a CORE16, el corpus del operador alcanza 45 mundos y 258 ticks exactos. Un continuo futuro debe comprimir fibras e incumbencia sin perder esta igualdad.
