# Acceso humano y Rosetta


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


No se promovió equivalencia externa. Los mecanismos nativos existen en la realidad representada; su canal de acceso humano permanece desconocido.

Protocolos funcionales propuestos:

1. Preparaciones externamente indistinguibles con distinta fase/edad interna, espera silenciosa y posterior interacción phase-sensitive; buscar divergencia retardada.
2. Inventarios iguales con distinta geometría de convergencia hacia un destino ocupado; medir timing y estado del receptor.
3. Dos interfaces que difieran en un único elemento guard bajo el mismo tren incidente; medir conteo acumulado versus horizonte.
4. Fuente entrenable, canal portador y receptor preparado; exigir source depletion, trayectoria y función fresca en destino.

Estos puntos definen requisitos experimentales, no aparatos actualmente disponibles. Falta una calibración compartida, independiente y de pocos parámetros. No existe predicción externa unused válida.
