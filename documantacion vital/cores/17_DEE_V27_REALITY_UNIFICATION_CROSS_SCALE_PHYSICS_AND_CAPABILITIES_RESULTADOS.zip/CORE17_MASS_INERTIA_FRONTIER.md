# Frontera masa/inercia


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


La organización móvil conserva exactamente geometría normalizada y el conjunto funcional de payloads. Bajo el impulso estandarizado, la respuesta fue local: el collision impulse reduce el soporte en un componente en cada tamaño estudiado. No emergió un coeficiente de cuerpo que relacione intervención con cambio colectivo.

Estado: `MOBILE_RELATIONAL_OBJECT_CONFIRMED`; `COLLECTIVE_INERTIA_NOT_FOUND`. Esto no demuestra ausencia universal de masa-like; demuestra que la constelación balística probada no es un cuerpo inercial acoplado.
