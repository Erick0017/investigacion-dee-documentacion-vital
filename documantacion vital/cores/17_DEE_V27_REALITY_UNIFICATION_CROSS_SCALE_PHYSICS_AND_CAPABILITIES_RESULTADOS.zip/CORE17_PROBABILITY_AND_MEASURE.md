# Probabilidad y selección de medida


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


Se agotaron las 64 configuraciones binarias de seis módulos en descubrimiento y k=2,4,6,8 en holdout. Para cada microestado determinista, el número de respuestas R coincide exactamente con el número de clases de reloj activas. Con preparación Bernoulli p:

`P(R=r | k,p) = C(k,r) p^r (1-p)^(k-r)`.

La igualdad fue exacta en conteos uniformes y el error ponderado máximo quedó por debajo de `1e-12`. Cambiar p altera la distribución sin modificar el mapa kernel micro->macro. Esto es probabilidad efectiva por acceso parcial y medida de preparación, no evidencia de amplitudes, regla de Born ni indeterminismo fundamental.
