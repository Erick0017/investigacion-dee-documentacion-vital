# Programabilidad


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


Gramática demostrada:

`PREPARATION(source train) -> ROUTE -> INTERFACE(k5 or k6) -> RESPONSE(transmit or block) -> DETECTOR COUNT`.

En los horizontes 22,42,82,162 la diferencia fue 6,16,36,76 eventos. El holdout extendió direcciones, N, s_reg y horizontes sin fallo. La programabilidad es binaria, local y dependiente de aparato. No se demostró computación general, edición arbitraria de organizaciones ni acceso tecnológico externo.
