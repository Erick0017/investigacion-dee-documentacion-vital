# Modelo causal de la realidad DEE después de CORE17


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


## Arquitectura

`X_FULL -> R0 -> {R1, R2-relacional, R2-funcional, R3}`.

R0 es el único cierre causal general demostrado: su operador conserva ocupación, semantic, dirección, s_reg, excepciones semantic4, reloj/ramas, incumbencia, incoming reducer y destino de fusión. R1/R2/R3 no son capas cronológicas universales; son cocientes para familias de preguntas. R1 añade lectura temporal y de fibras; R2 conserva organización, historia y función; R3 añade una medida sobre microestados compatibles.

## Resultado R*

Un R* no trivial no apareció. Dos historias con el mismo evento antes del receptor divergen si el receptor no está preparado; dos flujos con el mismo conteo integrado divergen en fase; una misma macroclase produce distribuciones distintas si cambia la medida. Reunir fase + receptor + medida es una unión descriptiva, no una compresión.

## Causalidad, identidad y escala

Una entidad efectiva es una clase de organización cuya respuesta y relaciones persisten aunque cambie la microidentidad. Una propiedad es una ley de respuesta a una intervención declarada. La escala es un cambio de representación y observer, no sólo un aumento de N. La causalidad se conserva en R0; los niveles superiores la retienen sólo para sus tareas.

## R0_FACTOR_52

R0 posee un cociente causal exacto más pequeño en el dominio declarado: 52 bits para celdas ordinarias y 64 para semántica-4. El reloj absoluto se reduce a fase módulo 304980; su cociente es invisible a esta dinámica.
