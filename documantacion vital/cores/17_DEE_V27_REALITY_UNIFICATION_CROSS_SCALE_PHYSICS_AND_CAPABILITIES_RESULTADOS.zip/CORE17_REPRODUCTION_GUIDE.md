# CORE17 — guía compacta de reproducción

Este paquete conserva sin modificación los resultados, telemetría, challenges, locks, canarios y runners científicos propios de CORE17. No contiene copias de CORE01–16.

## Prerrequisitos

- Kernel DEE v27 PYD SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Wheel SHA-256 `69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939`.
- Package SHA-256 `7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4`.
- Python CPython 3.13 x64 y NumPy compatible.
- Los ZIP oficiales CORE01–16 juntos en la carpeta canónica.

## Materializar dependencias padre exactas

Después de extraer este ZIP en una carpeta de trabajo:

```powershell
python RUNNERS/prepare_parent_dependencies.py --core-dir <carpeta-canónica-CORE01-16>
```

El script verifica los SHA de los dieciséis paquetes y de cada miembro antes de escribir las rutas requeridas por los runners congelados. Las fuentes exactas están en `PARENT_CORE_REFERENCES.json`.

## Orden científico reproducible

1. `RUNNERS/run_d01_hidden_scale.py`
2. `RUNNERS/run_d02_level_unification.py`
3. `RUNNERS/run_d03_probability_quantum.py`
4. `RUNNERS/run_d04_capability_composition.py`
5. `RUNNERS/run_d05_emergent_physics.py`
6. `RUNNERS/run_s01_model_selection.py`
7. `RUNNERS/freeze_core17.py` sólo en una copia sin challenges preexistentes.
8. `RUNNERS/generate_core17_challenges.py` para una nueva replicación post-freeze; los challenges históricos exactos ya están preservados.
9. `RUNNERS/run_final_holdouts.py`.

Para verificar la ejecución histórica sin regenerar challenges, conserve `HOLDOUT_LOCKS/CORE17_FINAL_LOCK.json` y `FRESH_CHALLENGES/CORE17_FINAL_CHALLENGES.json`; el resultado esperado completo está en `FINAL_HOLDOUTS/CORE17_FINAL_RESULTS.json`.

## Contratos esperados

- 46 mundos frescos; cinco paneles PASS y dos canarios PASS.
- Operador R0: 86 ticks de holdout, cero mismatches.
- Clock: cambio exacto de un centro por módulo positivo y cero en controles equal/off-gate.
- Probabilidad: pushforward binomial exacto; error máximo menor de `1e-12`.
- Macro-control: `E5(h)=max(0,floor((h-10)/2))`; `E6(h)=0`.
- Separación de niveles: todos los separadores causales congelados verdaderos.

`README_TELEMETRY.md` describe los archivos probatorios. Todos los hashes internos se verifican con `HASHES.sha256`.

---

# Reproducción de la extensión definitiva de CORE17

Use Python 3.13, NumPy 2.2.6, un hilo y el kernel v27 cuyo PYD tiene SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

Orden exacto: `run_e01_policy_coordinate.py`; `run_e02_redundant_policy_repair.py`; `freeze_e03_policy_repair.py`; `generate_e03_challenge.py`; `run_e03_policy_repair_holdout.py`; `run_e04_r0_compression_discovery.py`; `freeze_e05_r0_factor.py`; `generate_e05_challenge.py`; `run_e05_r0_factor_holdout.py`; `run_e06_prerequisite_constructions.py`; `synthesize_core17_extension.py`.

Los archivos `CHALLENGES` preservan la entropía y cada seed, de modo que los holdouts son reproducibles bit a bit con el binario fijado. Los JSON de `HOLDOUT` contienen todos los registros por caso y por tick usados para adjudicar las claims.
