# Retrospectiva científica CORE01–16


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


Esta retrospectiva no reaudita el Word ni reescribe la historia. Parte de los 16 ZIP oficiales (2753 registros tipo-claim ingeridos) y abre experimentos nuevos sólo cuando una lectura posterior genera una predicción discriminante.

| Etapa | Hecho histórico dominante | Lectura después de CORE17 |
|---|---|---|
| CORE01 | primitivas del kernel, transporte, reducer, reloj y causalidad local | base de X_FULL/R0 |
| CORE02 | construcción Rosetta y aparatos de ruta/destino | antecedente de R1; no equivalencia externa |
| CORE03 | multiescala, envolvente causal y sensibilidad a organización | precursor de información distribuida |
| CORE04 | leyes de escala/reproducción y búsquedas nativas | relaciones sectoriales, no teoría física total |
| CORE05 | redes fuente y proceso de coincidencia | observer/eventos como física de acceso |
| CORE06 | aprendizaje nativo y causalidad finita | precursor de R2-funcional |
| CORE07 | atlas experimental y límites | negativos que restringen interpretaciones |
| CORE08 | observers, autonomía y dimensionalidad | equivalencias dependientes del readout |
| CORE09 | memoria resiliente y política aprendida | historia como coordenada causal |
| CORE10 | sistemas acoplados y reinstanciación | carrier + receptor preparado, no teleportación |
| CORE11 | fenómenos simples fundamentales | controles para mecanismos locales |
| CORE12 | trenes fuente, fase e interfaces | precursor directo de R1 y k5/k6 |
| CORE13 | mapa causal de eventos | Rosetta interna acotada |
| CORE14 | traza de reloj persistente sin efecto en probes congelados | reinterpretada como latencia de acceso |
| CORE15 | shadow causal, identidad móvil y multiphysics | R2 y propiedades como respuesta |
| CORE16 | R0 exacto, niveles, probabilidad y operador ocupado | padre científico inmediato de CORE17 |

## Reinterpretación decisiva

CORE14 demostró una traza de reloj persistente; CORE15 mostró que varias interacciones congeladas no la leían. La conclusión correcta nunca fue «el reloj no causa nada». CORE17 preparó mundos raw-idénticos, conservó la diferencia de reloj durante un intervalo elegido y abrió después una rama period-sensitive. La diferencia volvió de manera exacta y escalable. No contradice los nulls anteriores: identifica el observer/interacción que faltaba.

## Genealogía adicional

- Las rutas de CORE02/05/12/13 se consolidan como R1, pero no contienen por sí solas estado del receptor.
- La memoria CORE06/09 y la reinstanciación CORE10 forman R2-funcional; CORE17 muestra que esa historia no es regenerada por cualquier scaffold.
- La identidad móvil de CORE15 es relacional y clásica sólo en un sentido acotado: trayectoria y forma se conservan, pero el contacto destruye componentes y no produce inercia colectiva.
- La estadística de CORE16 es ahora conectada a una familia causal concreta: clases de reloj deterministas cuya medida produce exactamente una distribución binomial.
- El operador de destino ocupado de CORE16 es el cierre efectivo real; los bloques de continuo siguen omitiendo fibras e incumbencia.

Los detalles machine-readable están en `RETROSPECTIVE/CORE17_RETROSPECTIVE_FINDINGS.json`.
