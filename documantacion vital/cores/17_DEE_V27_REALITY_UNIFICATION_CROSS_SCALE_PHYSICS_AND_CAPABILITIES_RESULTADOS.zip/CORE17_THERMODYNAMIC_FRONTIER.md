# Frontera termodinámica


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


El contacto reducer conserva contabilidad local `s_out=min(19664,sum s_in)` pero destruye identidad/proveniencia. Los scaffolds conjuntos regeneran por regla local, no intercambian una variable intensiva. Los ensembles muestran relajación/concentración, pero no equilibrio entre subsistemas ni Theta común.

No se promueve temperatura, calor ni entropía termodinámica. Deben seguir separados: conteo de microestados, incertidumbre del observer, pérdida many-to-one del kernel y función de estado termodinámica. Sólo las dos primeras y una pérdida local acotada están establecidas.
