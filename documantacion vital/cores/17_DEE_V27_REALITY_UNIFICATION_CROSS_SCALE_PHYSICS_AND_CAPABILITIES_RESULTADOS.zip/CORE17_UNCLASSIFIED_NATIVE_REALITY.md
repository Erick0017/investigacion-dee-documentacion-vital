# Realidad nativa no clasificada


P0_FIXED es la premisa ontológica: DEE representa la realidad estudiada. Esta premisa no identifica por sí sola ninguna variable DEE con una categoría de la física humana. El kernel permaneció inmutable (PYD `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`). El holdout final se creó después del freeze `e82774b50f53626ed86c84dc7bd6a2cf65db66fb553ac2c60d67aff342b8441b` y pasó 46 casos, incluidos 86 ticks del operador con 0 discrepancias.


`UN17-01`: dos estados raw-idénticos permanecen iguales durante un intervalo elegido; una diferencia de reloj no visible reaparece después como una diferencia raw sincronizada y escalable cuando se abre una rama local específica. Puede describirse sin etiqueta humana como «retorno causal retardado de una coordenada de fase oculta».

Se mantiene sin nombre de física humana. No es no-local, no es probabilístico en el estado completo y no prueba comportamiento cuántico. Sí demuestra que un observer coarse puede declarar equivalencia durante cientos de ticks y aun así fallar prospectivamente frente a otra interacción.
