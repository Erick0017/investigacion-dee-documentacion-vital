# CORE17 — Clausura definitiva

CORE17 se reabrió exclusivamente sobre las ramas vivas de su propia frontera. No se repitieron los 46 mundos finales anteriores, el panel de reloj oculto, el pushforward probabilístico, la ley k5/k6 ni el holdout R0 anterior.

## Nuevos resultados promovidos

1. **Coordenada de política y reparación redundante.** En 8 geometrías de localización, alterar `s_reg` conservó la función mientras resetear dirección la destruyó. El aparato de reparación entrenó una segunda copia, dañó la primera y reinstanció la política por un portador explícito. El holdout posterior al freeze pasó: tratamiento 12/12, corte fuera de ruta 12/12; copia no entrenada, dirección reseteada, copia ausente, corte de ruta y receptor incorrecto 0/12 cada uno.

2. **Compresión causal real de R0.** `R0_FACTOR_52` conserva para celdas ordinarias sólo existencia (1 bit), `s_reg` (16), dirección (12), semántica (4) y fase de reloj (19): 52 bits en lugar de 128. Semántica-4 necesita sus 64 bits raw pero no el reloj. El holdout fresco probó 10 mundos durante 406 pasos con cero discrepancias raw o reloj reducidas. `304980=lcm(195,260,391,782)` es el módulo fijo global mínimo para los periodos locales alcanzables de esa familia.

## Cierre de prerrequisitos

Las políticas aprendidas opuestas mantuvieron dos identidades en el control separado y se redujeron a un único estado en contacto (`s_reg=336`, dirección nula). La perturbación de una pareja redundante actuó localmente, no colectivamente. El híbrido semántica-4/móvil rompió su geometría relativa en un paso. No se construyeron cuerpos que sobrevivan contacto, intercambio con identidad, mediador distribuido no portador, contextos compatibles, subsistemas Bell válidos ni Rosetta externa.

La reparación demostrada es **reconstrucción soportada por una copia aprendida redundante**. No es autorregeneración local, acción remota ni teleportación.

`CORE17_DEFINITIVELY_CLOSED = TRUE`.
