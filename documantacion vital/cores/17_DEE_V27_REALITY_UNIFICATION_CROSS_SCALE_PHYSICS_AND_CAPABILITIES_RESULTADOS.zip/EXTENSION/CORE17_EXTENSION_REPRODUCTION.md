# Reproducción de la extensión definitiva de CORE17

Use Python 3.13, NumPy 2.2.6, un hilo y el kernel v27 cuyo PYD tiene SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

Orden exacto: `run_e01_policy_coordinate.py`; `run_e02_redundant_policy_repair.py`; `freeze_e03_policy_repair.py`; `generate_e03_challenge.py`; `run_e03_policy_repair_holdout.py`; `run_e04_r0_compression_discovery.py`; `freeze_e05_r0_factor.py`; `generate_e05_challenge.py`; `run_e05_r0_factor_holdout.py`; `run_e06_prerequisite_constructions.py`; `synthesize_core17_extension.py`.

Los archivos `CHALLENGES` preservan la entropía y cada seed, de modo que los holdouts son reproducibles bit a bit con el binario fijado. Los JSON de `HOLDOUT` contienen todos los registros por caso y por tick usados para adjudicar las claims.
