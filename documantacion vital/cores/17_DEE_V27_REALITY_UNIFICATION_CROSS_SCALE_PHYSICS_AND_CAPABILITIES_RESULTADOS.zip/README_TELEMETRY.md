# Telemetría CORE17 conservada sin pérdida

Los artefactos listados son copias byte por byte del paquete CORE17 original. No hubo redondeo, muestreo, downsampling, eliminación de filas ni sustitución por estadísticas.

Cada JSON se lee como UTF-8 y conserva su esquema original. `HASHES.sha256` permite validar los bytes exactos.

| Artefacto | Bytes | SHA-256 |
|---|---:|---|
| `CANARIES/CORE17_CANARY_RESULTS.json` | 228 | `4d0ccb27204dedda7ecf05d825b773b0736c1cb553abc40e215776850a7f7174` |
| `DISCOVERY/C17D01_HIDDEN_SCALE.json` | 58225 | `23a154c3ad6323183a6bf64e1ea99f9cd2da2cfb743246c7e4e8fcd74da216ab` |
| `DISCOVERY/C17D02_LEVEL_UNIFICATION.json` | 13076 | `c9c982b0669e49c5444ffdab7797207b1b363cdacabf4d686f3cf61931ca2b13` |
| `DISCOVERY/C17D03_PROBABILITY_QUANTUM.json` | 21083 | `305677567b259a068520cad5b07e17b42445bbe8ca261808d26ac1101e178b4e` |
| `DISCOVERY/C17D04_CAPABILITY_COMPOSITION.json` | 13608 | `643d0f3ff2a38f55c737895519391aacb6266737aae6cf9e891024d08b370ab1` |
| `DISCOVERY/C17D05_EMERGENT_PHYSICS.json` | 157493 | `5c7dd602c272b5c9132de266aa8a551fc20d6b0b27af20ffa95d808f4ec1513c` |
| `FINAL_HOLDOUTS/CORE17_FINAL_RESULTS.json` | 52981 | `31c743eb93ca49607efe6ab18499be9904e4c056f64bd710abbce2db93cf3dcf` |
| `FRESH_CHALLENGES/CORE17_FINAL_CHALLENGES.json` | 9019 | `4cc5c0f036739e5702f2dbe7c31018fe5c83e8bbe517d71248d864e3ba7e9208` |
| `HOLDOUT_LOCKS/CORE17_FINAL_LOCK.json` | 4270 | `dc972802e6cebcfa5efccbdaf08e7da610a6201e2e0bb2dcf29bae083ede7379` |
| `MODEL_SELECTION/C17S01_MODEL_SELECTION.json` | 6473 | `04dd6d32a172d60aa3366e0c38913326909e7148e6980322e66e8f02cded3ab3` |

Los JSON de discovery contienen estados, secuencias/ticks, controles y valores esperados; model-selection conserva la competencia de modelos; challenges/locks preservan seeds y contratos; final holdouts y canarios conservan todos los casos emitidos.
