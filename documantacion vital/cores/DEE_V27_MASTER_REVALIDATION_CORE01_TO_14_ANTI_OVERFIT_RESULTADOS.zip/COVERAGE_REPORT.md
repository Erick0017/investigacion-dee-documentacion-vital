# Coverage report

- GOLD disposition coverage: 100% (118/118).
- Executable fresh-claim pass coverage: 88.5% (23/26).
- Exact derived: 48.
- Replay-only with explicit scope/generator justification: 44.
- Silent omissions: 0.
