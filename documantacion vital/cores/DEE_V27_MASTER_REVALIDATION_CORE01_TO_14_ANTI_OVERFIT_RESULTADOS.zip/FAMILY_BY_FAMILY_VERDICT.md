# Family-by-family verdict

| family | present | GOLD | fresh | derived | replay-only | status |
|---|---|---|---|---|---|---|
| kernel/timing | True | 14 | 1 | 9 | 4 | ADJUDICATED |
| transport | True | 2 | 2 | 0 | 0 | ADJUDICATED |
| reducer/fiber | True | 3 | 2 | 1 | 0 | ADJUDICATED |
| guard | True | 2 | 2 | 0 | 0 | ADJUDICATED |
| phase | True | 17 | 2 | 9 | 6 | ADJUDICATED |
| history | True | 2 | 0 | 2 | 0 | ADJUDICATED |
| matter | True | 11 | 0 | 3 | 8 | ADJUDICATED |
| regeneration | False | 2 | 2 | 0 | 0 | NO_PROMOTED_GOLD_FOUND |
| memory | True | 3 | 2 | 0 | 1 | ADJUDICATED |
| learning | True | 15 | 1 | 5 | 9 | ADJUDICATED |
| coupling | True | 0 | 0 | 0 | 0 | ADJUDICATED |
| homeostasis | True | 3 | 2 | 0 | 1 | ADJUDICATED |
| observer | True | 16 | 2 | 6 | 8 | ADJUDICATED |
| interface | True | 1 | 1 | 0 | 0 | ADJUDICATED |
| simple phenomena | False | 0 | 0 | 0 | 0 | NO_PROMOTED_GOLD_FOUND |
| Rosetta | True | 1 | 0 | 0 | 1 | ADJUDICATED |
| causal ecology | True | 1 | 1 | 0 | 0 | ADJUDICATED |
