# Independent replication kit

Place the canonical v27 `KERNEL/` directory beside this file. Generate a new post-freeze wave with `RUNNERS/generate_fresh_challenges.py --wave A --challenge-seed <64 hex>`, then execute `RUNNERS/frozen_master_evaluator.py`. Do not edit frozen source or contracts. Observations come from the new kernel run; expected values are frozen laws.
