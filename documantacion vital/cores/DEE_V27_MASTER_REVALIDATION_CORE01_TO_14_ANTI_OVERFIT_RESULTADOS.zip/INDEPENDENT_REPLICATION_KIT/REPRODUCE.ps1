$ErrorActionPreference = 'Stop'
$py = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
& $py -I -B .\RUNNERS\generate_fresh_challenges.py --wave A --challenge-seed $args[0]
& $py -I -B .\RUNNERS\frozen_master_evaluator.py --manifest .\CHALLENGE_WAVE_A.json --contracts .\FROZEN_CLAIM_CONTRACTS.json --output .\OUTPUT_A
