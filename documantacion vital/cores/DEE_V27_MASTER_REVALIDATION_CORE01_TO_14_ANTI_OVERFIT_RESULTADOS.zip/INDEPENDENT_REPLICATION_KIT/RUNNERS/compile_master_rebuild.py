from __future__ import annotations

import json
import re
import sys
import zipfile
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from master_common import *


GOLD_STATUSES = {"EXACT_THEOREM", "EXACT_SECTOR_LAW", "HOLDOUT_CONFIRMED_INTERNAL"}
NEGATIVE_STATUSES = {
    "NEGATIVE_IN_TESTED_APPARATUS", "FAILED", "FAIL", "REFUTED_IN_TESTED_DOMAIN",
    "BOUNDED_NULL_CONFIRMED", "SUPERSEDED",
}


def core_zip(core: int) -> Path:
    rows = sorted(CORE_ARCHIVE.glob(f"{core:02d}_*.zip"))
    if len(rows) != 1:
        raise RuntimeError(f"expected one CORE{core:02d} ZIP, found {len(rows)}")
    return rows[0]


def read_json(z: zipfile.ZipFile, name: str):
    return json.loads(z.read(name).decode("utf-8", errors="replace"))


def first_member(z: zipfile.ZipFile, suffix: str) -> str:
    rows = [n for n in z.namelist() if n.endswith(suffix)]
    if len(rows) != 1:
        raise RuntimeError(f"{suffix}: expected one member, found {len(rows)}")
    return rows[0]


def compact(row: dict) -> dict:
    keys = (
        "claim_id", "name", "claim", "claim_text", "text", "label", "status", "current_adjudication",
        "family", "domain", "scope", "known_limits", "scope_and_caveat", "evidence_type", "evidence_source",
        "result_file", "source_result", "runner", "runner_path", "machine_predicate", "predicate_result",
        "epistemic_level", "epistemic_class", "category", "controls", "counterevidence", "holdout_status",
    )
    return {k: row.get(k) for k in keys if k in row}


def claim_text(row: dict) -> str:
    return str(row.get("name") or row.get("claim") or row.get("claim_text") or row.get("text") or row.get("label") or "")


def add_row(rows: list[dict], core: int, row: dict, source_file: str, tier: str | None = None) -> None:
    status = str(row.get("status") or row.get("current_adjudication") or row.get("verdict") or "UNKNOWN")
    cid = str(row.get("claim_id") or row.get("module_id") or row.get("experiment_id") or f"CORE{core:02d}:{len(rows)+1}")
    predicate = row.get("predicate_result", row.get("machine_predicate"))
    if tier is None:
        if status in GOLD_STATUSES and predicate is not False:
            tier = "GOLD"
        elif status in NEGATIVE_STATUSES or predicate is False:
            tier = "NEGATIVE_ANCHOR"
        else:
            tier = "SILVER"
    rows.append({
        "registry_id": f"RAW_{len(rows)+1:04d}",
        "claim_id": cid,
        "source_core": core,
        "source_files": [source_file],
        "original_text": claim_text(row),
        "original_status": status,
        "tier": tier,
        "epistemic_level": row.get("epistemic_level") or row.get("epistemic_class") or row.get("category") or row.get("exact_or_empirical") or "UNSPECIFIED",
        "family": row.get("family") or row.get("domain") or row.get("front") or "unclassified",
        "scope": row.get("scope") or row.get("known_limits") or row.get("scope_and_caveat") or "bounded to archived claim",
        "machine_predicate": row.get("machine_predicate"),
        "predicate_result": predicate,
        "evidence": compact(row),
    })


def extract_registry() -> tuple[list[dict], list[dict]]:
    rows: list[dict] = []
    chain: list[dict] = []
    # CORE08's ledger is the latest machine-readable transversal adjudication of CORE01-08.
    for core in range(1, 15):
        zp = core_zip(core)
        integrity = verify_zip_hashes(zp)
        chain.append({"core": core, "name": zp.name, "sha256": sha(zp), "size": zp.stat().st_size, "integrity": integrity})
    z8p = core_zip(8)
    with zipfile.ZipFile(z8p) as z:
        name = first_member(z, "CLAIM_LEDGER_CORE08.ndjson")
        for line in z.read(name).decode("utf-8", errors="replace").splitlines():
            if not line.strip():
                continue
            row = json.loads(line)
            m = re.search(r"CORE(\d{2})", str(row.get("core_or_history", row.get("claim_id", ""))).upper())
            core = int(m.group(1)) if m else 8
            if 1 <= core <= 8:
                add_row(rows, core, row, f"CORE08::{name}")

    # CORE09-11: frozen result modules, with failed frozen modules retained as negative anchors.
    selected = {
        9: {"C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA", "C9H02_ADAPTIVE_POLICY_A6", "C9H03_RESILIENT_SYMBOLIC_MEMORY_AND_SUBSYSTEM"},
        10: {"C10H01_BIDIRECTIONAL_CAUSAL_POLICY_EXCHANGE", "C10H02_LEARNED_POLICY_FUNCTIONAL_REINSTANTIATION", "C10H03_JOINT_INTERFACE_HOMEOSTASIS", "C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS", "C10H05_FUNCTIONAL_OBSERVER_AND_INTERIOR_BOUNDARY_COUNTEREXAMPLE"},
        11: {"C11H01_MATTER_IDENTITY", "C11H02_PROPAGATION_INTERFACE", "C11H03_TWO_APERTURE", "C11H04_CONTACT_EQUILIBRIUM", "C11H05_CROSS_PHENOMENON_RELATIONAL_OBSERVER", "C11H06_MINIMAL_OBSERVER_WITHIN_TESTED_FAMILY"},
    }
    negative_modules = {"C9H01_EXTERNAL_TRAVEL_TIME_ROSETTA", "C10H04_TASK_RELATIVE_OBSERVER_AND_MEMORY_LOCUS", "C11H03_TWO_APERTURE", "C11H04_CONTACT_EQUILIBRIUM"}
    for core in (9, 10, 11):
        with zipfile.ZipFile(core_zip(core)) as z:
            for name in z.namelist():
                if not name.lower().endswith(".json") or "RESULTS/" not in name.upper():
                    continue
                try:
                    obj = read_json(z, name)
                except Exception:
                    continue
                if not isinstance(obj, dict) or str(obj.get("module_id", "")) not in selected[core]:
                    continue
                mid = str(obj["module_id"])
                verdict = str(obj.get("verdict", obj.get("status", "UNKNOWN")))
                row = {
                    "claim_id": mid,
                    "claim": obj.get("question") or obj.get("conclusion") or obj.get("epistemic_scope") or mid.replace("_", " "),
                    "status": verdict,
                    "family": mid.split("_")[1].lower() if "_" in mid else "holdout",
                    "scope": obj.get("epistemic_scope", "frozen archived apparatus"),
                    "machine_predicate": obj.get("machine_predicate_result", obj.get("machine_predicate")),
                    "role": obj.get("role"),
                }
                if mid in negative_modules or verdict.upper() == "FAIL":
                    tier = "NEGATIVE_ANCHOR"
                elif verdict.upper() == "PASS":
                    tier = "GOLD"
                else:
                    tier = "SILVER"
                add_row(rows, core, row, name, tier)

    # CORE12-14 have explicit claim ledgers.
    for core in (12, 13, 14):
        with zipfile.ZipFile(core_zip(core)) as z:
            name = first_member(z, "CLAIM_LEDGER.json")
            obj = read_json(z, name)
            for row in obj.get("claims", []):
                status = str(row.get("status", "UNKNOWN"))
                pred = row.get("predicate_result", row.get("machine_predicate"))
                if core == 12 and pred is True:
                    tier = "GOLD"
                elif core == 13 and row.get("claim_id") in {"C13C01", "C13C02", "C13C03"} and pred is True:
                    tier = "GOLD"
                elif core == 14 and row.get("claim_id") in {"C14R01", "C14R02", "C14R03", "C14R04", "C14R05"} and pred is True:
                    tier = "GOLD"
                elif pred is False or "NULL" in status or status == "FAILED":
                    tier = "NEGATIVE_ANCHOR"
                else:
                    tier = "SILVER"
                add_row(rows, core, row, name, tier)
    return rows, chain


def evaluator_family(row: dict) -> str | None:
    key = (row["claim_id"] + " " + row["original_text"]).upper()
    patterns = [
        (("C14R01", "C06_ASSOCIATIVE_LEARNING"), "ASSOC_MEMORY"),
        (("C14R02", "C8_REPEATED_SCAFFOLD_REGENERATION", "C11H01_MATTER_IDENTITY"), "REGENERATION"),
        (("C14R03", "C06_DISSIPATIVE_ENSEMBLE_RELAXATION"), "ENSEMBLE_RELAXATION"),
        (("C14R04",), "C10_ECOLOGY_BUNDLE"),
        (("C14R05",), "CLOCK_TRACE"),
        (("C9H02_ADAPTIVE_POLICY_A6",), "ADAPTIVE_POLICY"),
        (("C10H01_BIDIRECTIONAL",), "BIDIRECTIONAL"),
        (("C10H02_LEARNED_POLICY",), "REINSTANTIATION"),
        (("C10H03_JOINT",), "JOINT_HOMEOSTASIS"),
        (("C10H05_FUNCTIONAL_OBSERVER",), "BIDIRECTIONAL_OBSERVER"),
        (("C8_BOUNDARY_FINITE_LAW",), "BOUNDARY_TIME"),
        (("C8_TRAINED_REDUNDANCY_RECOVERY_H06",), "FUNCTIONAL_RECOVERY"),
        (("C8_GUARDED_DESTINATION_OBSERVER", "C12C03", "C12H03_SEMANTIC4_GUARD_THRESHOLD"), "GUARD"),
        (("C12C01", "C12H01_PHASE_TRANSPORT"), "PHASE_TRAIN"),
        (("C12C02", "C12H02_PHASE_HISTORY_PATH_RESPONSE"), "PHASE_CONVERGENCE"),
        (("C12C04", "C12H04_GUARDED_INTERFACE_CAPTURE"), "CAPTURE"),
        (("C13C02", "C13H01_EVENT_CAUSAL_SHARED_OBSERVER"), "EVENT_COMPOSITE"),
        (("C13C03", "C13H02_SINGLE_SHOT_RESOLVING_INTERVAL"), "RESOLVING"),
        (("C11H02_PROPAGATION_INTERFACE", "C06_FREE_CARRIER_IDENTITY_QUOTIENT", "C06_INTERNAL_KINEMATICS"), "TRANSPORT"),
        (("INH_COLLISION_REDUCER", "NRH03_DESTINATION_FIBER_CLOSURE"), "REDUCER"),
    ]
    for needles, family in patterns:
        if any(n in key for n in needles):
            return family
    return None


def canonicalize(raw: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    gold = [r for r in raw if r["tier"] == "GOLD"]
    negatives = [r for r in raw if r["tier"] == "NEGATIVE_ANCHOR"]
    # The CORE08 transversal ledger is already de-duplicated. Only exact repeated text is merged here.
    groups: dict[str, list[dict]] = {}
    for row in gold:
        norm = re.sub(r"[^a-z0-9]+", " ", row["original_text"].lower()).strip()
        mechanism = evaluator_family(row) or row["family"]
        key = sha_bytes((norm + "|" + str(mechanism) + "|" + str(row["scope"])).encode("utf-8"))
        groups.setdefault(key, []).append(row)
    canon: list[dict] = []
    eq: list[dict] = []
    for i, (fingerprint, members) in enumerate(sorted(groups.items()), 1):
        c = members[0]
        cid = f"GOLD_{i:03d}"
        fam = evaluator_family(c)
        if fam:
            destination = "EXECUTABLE_FRESH_CONTRACT"
            reason = "A frozen evaluator and scope-preserving challenge transform can be reconstructed from archived source."
        elif c["original_status"] in {"EXACT_THEOREM", "EXACT_SECTOR_LAW"}:
            destination = "EXACT_DERIVABLE_LAW"
            reason = "The claim is an exact source-level/finite-sector relation; it is re-derived and covered by kernel identity plus static provenance."
        else:
            destination = "REPLAY_ONLY_WITH_JUSTIFICATION"
            reason = "Original machine evidence and runner/lock were found, but no archived frozen admissible fresh-world generator exists; inventing one would broaden or redefine the bounded preparation class."
        canon.append({
            "canonical_claim_id": cid,
            "source_claim_ids": [m["claim_id"] for m in members],
            "source_cores": sorted({m["source_core"] for m in members}),
            "claim_text": c["original_text"],
            "scope": c["scope"],
            "epistemic_level": c["epistemic_level"],
            "family": c["family"],
            "original_status": c["original_status"],
            "destination": destination,
            "destination_reason": reason,
            "evaluator_family": fam,
            "source_files": sorted({f for m in members for f in m["source_files"]}),
        })
        eq.append({
            "equivalence_class_id": f"EQ_{i:03d}",
            "canonical_claim_id": cid,
            "members": [m["claim_id"] for m in members],
            "merge_rule": "same normalized predicate text, mechanism family and declared scope",
            "fingerprint": fingerprint,
        })
    return canon, eq, negatives


def build_contracts(canon: list[dict]) -> list[dict]:
    contracts = []
    for c in canon:
        if c["destination"] != "EXECUTABLE_FRESH_CONTRACT":
            continue
        contracts.append({
            "contract_id": "CTR_" + c["canonical_claim_id"],
            "canonical_claim_id": c["canonical_claim_id"],
            "source_claim_ids": c["source_claim_ids"],
            "source_cores": c["source_cores"],
            "family": c["evaluator_family"],
            "claim_text": c["claim_text"],
            "scope": c["scope"],
            "metric": "family-specific frozen machine predicate",
            "threshold": "exact/compound boolean predicate declared in frozen evaluator",
            "observer": "family-specific raw-state/event observer",
            "probe": "fixed preparation generated from opaque challenge parameters",
            "fresh_transforms": ["new OS-derived seed", "new compatible N/translation/orientation/distance where defined"],
            "canary_rule": "break source/history/route/guard/interface when causally meaningful",
            "high_impact": c["evaluator_family"] in {"ASSOC_MEMORY", "REGENERATION", "ENSEMBLE_RELAXATION", "C10_ECOLOGY_BUNDLE", "CLOCK_TRACE", "ADAPTIVE_POLICY", "EVENT_COMPOSITE"},
        })
    contracts.extend([
        {
            "contract_id": "NEG_C11_SINGLETON_ADDITIVITY", "canonical_claim_id": "NEG_C11H03", "source_claim_ids": ["C11H03_TWO_APERTURE"],
            "source_cores": [11], "family": "NEGATIVE_ADDITIVITY", "claim_text": "The bounded singleton parallel-path apparatus is additive.",
            "scope": "CORE11 singleton two-path class", "metric": "AB detector trace equals capped A+B trace", "threshold": "exact equality",
            "observer": "detector event/s_reg trace", "probe": "two fresh singleton paths", "fresh_transforms": ["new N/translation/orientation/path length"],
            "canary_rule": "not applicable; this is a negative anchor", "high_impact": True, "negative_anchor": True,
        },
        {
            "contract_id": "NEG_C11_CARRIER_CONTACT", "canonical_claim_id": "NEG_C11H04", "source_claim_ids": ["C11H04_CONTACT_EQUILIBRIUM"],
            "source_cores": [11], "family": "NEGATIVE_COALESCENCE", "claim_text": "Two singleton carriers sharing a destination coalesce rather than remain distinguishable ensembles.",
            "scope": "CORE11 carrier-contact class", "metric": "one reduced destination record", "threshold": "exact reducer output",
            "observer": "destination record", "probe": "two fresh carriers", "fresh_transforms": ["new N/translation/orientation/s_reg"],
            "canary_rule": "separate destinations must not coalesce", "high_impact": True, "negative_anchor": True,
        },
    ])
    return contracts


def replay_manifest(contracts: list[dict]) -> dict:
    cases = []
    for i, c in enumerate(contracts):
        common = {"n": 41 + 2 * (i % 4), "center": [18 + i % 5, 19 + (2*i) % 5, 20 + (3*i) % 5], "axis": i % 3, "sign": -1 if i % 2 else 1, "distance": 5 + i % 4, "delay": 52 + i % 7, "sreg": 307 + 11*i}
        cases.append({"trial_id": f"R_{i+1:03d}", "contract_id": c["contract_id"], "canonical_claim_id": c["canonical_claim_id"], "family": c["family"], "lane": "REPLAY", "seed": 170000 + i * 97, "ordinal": i, "canary": False, **common})
        if c["family"] not in {"ENSEMBLE_RELAXATION", "BOUNDARY_TIME", "CLOCK_TRACE"}:
            cases.append({"trial_id": f"RC_{i+1:03d}", "contract_id": c["contract_id"], "canonical_claim_id": c["canonical_claim_id"], "family": c["family"], "lane": "REPLAY_CANARY", "seed": 270000 + i * 101, "ordinal": i, "canary": True, **common})
    return {"schema": "dee.v27.master.replay_manifest.v2", "cases": cases}


def static_audit(source_paths: list[Path]) -> dict:
    rows = []
    warnings = []
    for path in source_paths:
        text = path.read_text(encoding="utf-8")
        item = {
            "file": str(path.relative_to(ROOT)).replace("\\", "/"),
            "sha256": sha(path),
            "concrete_fresh_id_literal": bool(re.search(r"T_[0-9A-F]{8,}", text)),
            "observed_assigned_from_expected": bool(re.search(r"\bobserved\s*=\s*expected\b", text)),
            "historical_archive_read_in_fresh_evaluator": "CORE_ARCHIVE" in text if path.name == "frozen_master_evaluator.py" else False,
            "direct_pass_literal": bool(re.search(r"status\s*=\s*['\"]PASS['\"]", text)),
        }
        if item["concrete_fresh_id_literal"] or item["observed_assigned_from_expected"] or item["historical_archive_read_in_fresh_evaluator"]:
            warnings.append(item["file"])
        rows.append(item)
    return {"files": rows, "hardcode_warnings": len(warnings), "warning_files": warnings, "pass": not warnings, "note": "Analytic expected laws are allowed; observed values must be kernel-derived."}


def main() -> int:
    for stale in ("CHALLENGE_WAVE_A.json", "CHALLENGE_WAVE_B.json", "MASTER_CHALLENGE_SEED.json", "SOURCE_FREEZE.json"):
        if (ROOT / stale).exists():
            raise RuntimeError(f"unexpected pre-freeze artifact: {stale}")
    audit_kernel("MASTER_REBUILD_COMPILATION_START")
    raw, chain = extract_registry()
    canon, eq, negatives = canonicalize(raw)
    contracts = build_contracts(canon)
    destination_counts = Counter(c["destination"] for c in canon)
    if sum(destination_counts.values()) != len(canon):
        raise RuntimeError("coverage invariant failed")
    coverage = {
        "GOLD_TOTAL": len(canon),
        "GOLD_EXECUTABLE": destination_counts["EXECUTABLE_FRESH_CONTRACT"],
        "GOLD_DERIVABLE": destination_counts["EXACT_DERIVABLE_LAW"],
        "GOLD_REPLAY_ONLY": destination_counts["REPLAY_ONLY_WITH_JUSTIFICATION"],
        "GOLD_NOT_RECONSTRUCTIBLE": destination_counts["NOT_RECONSTRUCTIBLE_AFTER_EXHAUSTIVE_SEARCH"],
        "GOLD_DEGRADED": destination_counts["DEGRADED_BY_NEW_EVIDENCE"],
    }
    coverage["sum_matches_total"] = sum(coverage[k] for k in coverage if k.startswith("GOLD_") and k != "GOLD_TOTAL") == coverage["GOLD_TOTAL"]
    if not coverage["sum_matches_total"]:
        raise RuntimeError("GOLD destination sum does not match total")
    atomic_json(ROOT / "PARENT_CHAIN_AUDIT.json", {"cores": chain, "all_integrity_pass": all(x["integrity"]["pass"] for x in chain), "new_core14_sha256": CORE14_SHA, "new_core14_match": chain[-1]["sha256"] == CORE14_SHA})
    atomic_json(ROOT / "MASTER_CLAIM_REGISTRY.json", {"schema": "dee.v27.master.claim_registry.v2", "raw_ledger_entries": len(raw), "tier_counts": dict(Counter(r["tier"] for r in raw)), "claims": raw})
    atomic_json(ROOT / "CLAIM_EQUIVALENCE_CLASSES.json", {"classes": eq, "class_count": len(eq)})
    atomic_json(ROOT / "CANONICAL_GOLD_CLAIMS.json", {"claims": canon, "counts": coverage})
    atomic_json(ROOT / "CONTRACT_COVERAGE_MAP.json", {"coverage": coverage, "contracts": [{"canonical_claim_id": c["canonical_claim_id"], "destination": c["destination"], "contract_id": ("CTR_" + c["canonical_claim_id"]) if c["destination"] == "EXECUTABLE_FRESH_CONTRACT" else None, "reason": c["destination_reason"]} for c in canon], "invariant_pass": coverage["sum_matches_total"]})
    atomic_json(ROOT / "FROZEN_CLAIM_CONTRACTS.json", {"schema": "dee.v27.master.contracts.v2", "created_utc": utc(), "status": "FROZEN_BEFORE_FRESH_WORLDS", "contracts": contracts, "fresh_admissibility": {"challenge_worlds_exist_at_freeze": False, "scope_broadening_forbidden": True, "observer_metric_threshold_frozen": True}})
    atomic_json(ROOT / "REPLAY_MANIFEST.json", replay_manifest(contracts))
    atomic_json(ROOT / "NEGATIVE_ANCHOR_REGISTRY.json", {"anchors": negatives, "count": len(negatives)})
    atomic_json(ROOT / "OBSOLETED_PRIOR_RUNS.json", {"old_core14_sha256": "c5fcf877047262bc594193d168cf5e916915c19d892dc4404fe4837b0dd4e2e3", "old_master_sha256": "738cd737725094258b5dcd92a0f27da51aef54957fcae57a8dabfbcf0903c6eb", "reason_for_rebuild": "narrow CORE14 search and 11-contract MASTER subset", "statement": "Prior runs retained only as methodological diagnostics. They are superseded by this rebuild.", "date": utc()})

    source_names = [
        "master_common.py", "compile_master_rebuild.py", "generate_fresh_challenges.py", "frozen_master_evaluator.py",
        "run_dee_v27_master_revalidation_rebuild.py", "native_core.py", "core08_common.py", "core09_common.py",
        "core10_common.py", "core10_apparatus.py", "run_c6h01_associative_plasticity_holdout.py",
        "run_c6h08_dissipative_ensemble_holdout.py", "run_c8h02_repeated_scaffold_regeneration.py",
        "run_c8h03_trained_redundancy_recovery.py", "run_c8h04_boundary_time_code.py",
        "run_c9d02_adaptive_loop_discovery.py",
    ]
    sources = [ROOT / "RUNNERS" / name for name in source_names]
    missing = [str(p) for p in sources if not p.is_file()]
    if missing:
        raise RuntimeError(f"missing frozen sources: {missing}")
    static = static_audit(sources)
    atomic_json(ROOT / "STATIC_HARDCODE_AUDIT.json", static)
    atomic_json(ROOT / "SOURCE_PROVENANCE_AUDIT.json", {"sources": [{"path": str(p.relative_to(ROOT)).replace("\\", "/"), "sha256": sha(p)} for p in sources], "kernel_import_path": str(PYD), "runtime_mutations": "none", "post_t0_interventions": "native dynamics or frozen fixed interventions", "expected_value_policy": "analytic frozen law only; never copied into observed telemetry"})
    atomic_text(ROOT / "RUNTIME_ESTIMATE.md", f"# Runtime estimate\n\n- Raw ledger entries: {len(raw)}\n- Canonical GOLD claims: {len(canon)}\n- Executable fresh contracts: {len(contracts)}\n- Exact derivations: {coverage['GOLD_DERIVABLE']}\n- Replay-only justified claims: {coverage['GOLD_REPLAY_ONLY']}\n- Planned waves: A for all executable contracts; B for high-impact contracts.\n- Expected runtime: minutes to tens of minutes on this host.\n- Disk: compact telemetry; canonical runtime excluded from final ZIP.\n")
    atomic_json(ROOT / "TIME_BUDGET.json", {"policy": "scientific sufficiency; 30-hour combined safety ceiling", "stage": "MASTER_SOURCE_FREEZE", "created_utc": utc()})
    frozen = {str(p.relative_to(ROOT)).replace("\\", "/"): sha(p) for p in sources}
    for name in ("FROZEN_CLAIM_CONTRACTS.json", "REPLAY_MANIFEST.json", "CONTRACT_COVERAGE_MAP.json"):
        frozen[name] = sha(ROOT / name)
    atomic_json(ROOT / "SOURCE_FREEZE.json", {"status": "FROZEN", "created_utc": utc(), "fresh_worlds_existed": False, "frozen_files": frozen, "contracts_sha256": sha(ROOT / "FROZEN_CLAIM_CONTRACTS.json"), "coverage_invariant_pass": True, "rule": "No frozen source, contract, evaluator, observer, metric, threshold, transform or canary rule may change after this point."})
    print(json.dumps({"status": "SOURCE_FROZEN", "raw": len(raw), "gold": len(canon), "contracts": len(contracts), "coverage": coverage, "freeze_sha256": sha(ROOT / "SOURCE_FREEZE.json")}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
