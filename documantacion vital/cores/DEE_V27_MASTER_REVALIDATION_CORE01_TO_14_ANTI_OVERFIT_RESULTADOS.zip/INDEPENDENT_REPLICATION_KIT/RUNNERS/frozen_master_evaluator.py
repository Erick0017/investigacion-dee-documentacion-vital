"""Frozen MASTER evaluator.

Every observation is computed from a fresh v27 execution. Analytic expectations are
kept separate from raw observations, and no historical result package is accessible.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
RUNNERS = Path(__file__).resolve().parent
KROOT = ROOT / "KERNEL"
EXTRACTED = KROOT / "wheel_extracted"
WHEEL = KROOT / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
PACKAGE = EXTRACTED / "dee_universe_v27" / "__init__.py"
PYD = EXTRACTED / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}

OPENED: list[str] = []


def audit_hook(event, args):
    if event == "open" and args:
        try:
            OPENED.append(str(Path(args[0]).resolve()))
        except Exception:
            OPENED.append(str(args[0]))


sys.addaudithook(audit_hook)


def sha(path: Path | str) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def hashes() -> dict:
    return {"wheel": sha(WHEEL), "package": sha(PACKAGE), "pyd": sha(PYD)}


def write(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, path)


def pack(state: int, sreg: int, direction, semantic: int = 1) -> np.uint64:
    return np.uint64((state & 0xFFFFFFFF) | ((sreg & 0xFFFF) << 32) | ((direction[0] & 15) << 48) | ((direction[1] & 15) << 52) | ((direction[2] & 15) << 56) | ((semantic & 15) << 60))


def unpack(value) -> dict:
    v = int(value)
    direction = []
    for shift in (48, 52, 56):
        x = (v >> shift) & 15
        direction.append(x - 16 if x >= 8 else x)
    return {"raw": v, "state": v & 0xFFFFFFFF, "sreg": (v >> 32) & 0xFFFF, "direction": direction, "semantic": (v >> 60) & 15}


class World:
    def __init__(self, kernel, raw, clock=None):
        self.kernel = kernel
        self.n = raw.shape[0]
        self.a = np.ascontiguousarray(raw, dtype=np.uint64).copy()
        self.b = self.a.copy()
        c = np.zeros_like(raw) if clock is None else clock
        self.ca = np.ascontiguousarray(c, dtype=np.uint64).copy()
        self.cb = self.ca.copy()

    def tick(self):
        return self.kernel.tick_universo_lazy(self.a, self.b, self.ca, self.cb, self.n, 1)


def add(q, d, k, n):
    return tuple((int(q[i]) + k * int(d[i])) % n for i in range(3))


def record(raw, q):
    return None if int(raw[q]) == 0 else unpack(raw[q])


def direction_for(case, offset=0):
    axis = (int(case["axis"]) + offset) % 3
    d = [0, 0, 0]
    d[axis] = int(case["sign"])
    return tuple(d)


def base_transport(kernel, case, canary=False):
    n, center, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    d = direction_for(case)
    raw = np.zeros((n, n, n), np.uint64)
    if not canary:
        raw[add(center, d, -distance, n)] = pack(1, int(case["sreg"]), d, 1)
    world = World(kernel, raw)
    events = []
    for tick in range(distance + 4):
        obs = record(world.a, center)
        if obs:
            events.append((tick, obs["sreg"], obs["direction"], obs["semantic"]))
        world.tick()
    expected = [] if canary else [(distance, int(case["sreg"]), list(d), 1)]
    return events == expected, {"observed_events": events, "analytic_expected_events": expected}


def base_reducer(kernel, case, canary=False):
    n, q = int(case["n"]), tuple(case["center"])
    d1, d2 = direction_for(case), direction_for(case, 1)
    s1 = 101 + int(case["ordinal"])
    s2 = 211 + int(case["ordinal"])
    raw = np.zeros((n, n, n), np.uint64)
    raw[add(q, d1, -1, n)] = pack(1, s1, d1, 1)
    target = add(q, d1, 3, n) if canary else q
    raw[add(target, d2, -1, n)] = pack(1, s2, d2, 1)
    world = World(kernel, raw)
    world.tick()
    obs = record(world.a, q)
    expected_s = min(s1 + s2, 19664)
    expected_d = [int(np.sign(d1[i] + d2[i])) for i in range(3)]
    matches = obs is not None and obs["sreg"] == expected_s and obs["direction"] == expected_d
    return ((not matches) if canary else matches), {"observed": obs, "analytic_expected": {"sreg": expected_s, "direction": expected_d}, "common_destination_broken": canary}


def base_guard(kernel, case, canary=False):
    n, q = int(case["n"]), tuple(case["center"])
    raw = np.zeros((n, n, n), np.uint64)
    raw[q] = pack(0x1234, 19, (0, 0, 0), 1)
    corners = [tuple((q[i] + off[i]) % n for i in range(3)) for off in itertools.product((-1, 1), repeat=3)]
    kguards = 5 if canary else 6
    for i, pos in enumerate(corners[:kguards]):
        raw[pos] = pack(0xA000 + i, 31 + i, (0, 0, 0), 4)
    world = World(kernel, raw)
    world.tick()
    present = record(world.a, q) is not None
    return (present == (not canary)), {"k": kguards, "observed_center": record(world.a, q), "expected_present": not canary}


def base_phase_train(kernel, case, canary=False):
    n, q, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    d = direction_for(case)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    sem = 1 if canary else 4
    source = add(q, d, -distance, n)
    raw[source] = pack(0, int(case["sreg"]), d, sem)
    clock[source] = np.uint64(int(case["seed"]))
    world = World(kernel, raw, clock)
    ticks = []
    for tick in range(distance + 10):
        if record(world.a, q):
            ticks.append(tick)
        world.tick()
    periodic = len(ticks) >= 3 and all(b - a == 2 for a, b in zip(ticks, ticks[1:]))
    return ((len(ticks) <= 1) if canary else periodic), {"semantic": sem, "arrival_ticks": ticks, "period_two": periodic}


def convergent_dirs(case):
    axis = int(case["axis"])
    lateral = (axis + 1) % 3
    sign = int(case["sign"])
    a = [0, 0, 0]
    b = [0, 0, 0]
    a[axis] = sign
    b[axis] = sign
    a[lateral] = 1
    b[lateral] = -1
    return tuple(a), tuple(b)


def base_phase_convergence(kernel, case, canary=False):
    n, q, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    da, db = convergent_dirs(case)
    delta = 1 if canary else 0
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    s1, s2 = 101, 211
    raw[add(q, da, -distance, n)] = pack(0, s1, da, 4)
    raw[add(q, db, -(distance + delta), n)] = pack(0, s2, db, 4)
    clock[add(q, da, -distance, n)] = 101 + n
    clock[add(q, db, -(distance + delta), n)] = 202 + n
    world = World(kernel, raw, clock)
    events = []
    for tick in range(distance + delta + 8):
        obs = record(world.a, q)
        if obs:
            events.append((tick, obs["sreg"], obs["direction"]))
        world.tick()
    merged = any(x[1] == s1 + s2 for x in events)
    expected_merge = not canary
    return merged == expected_merge, {"events": events, "merged": merged, "analytic_expected_merge": expected_merge, "relative_delay": delta}


def guard_world(kernel, case, kguards, loaded=True):
    n, q, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    d = direction_for(case)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(0x1234, 19, (0, 0, 0), 1)
    corners = [tuple((q[i] + off[i]) % n for i in range(3)) for off in itertools.product((-1, 1), repeat=3)]
    for i, pos in enumerate(corners[:kguards]):
        raw[pos] = pack(0xA000 + i, 31 + i, (0, 0, 0), 4)
    if loaded:
        source = add(q, d, -distance, n)
        raw[source] = pack(0, int(case["sreg"]), d, 4)
        clock[source] = int(case["seed"])
    world = World(kernel, raw, clock)
    for _ in range(distance + 8):
        world.tick()
    return world, corners


def base_capture(kernel, case, canary=False):
    world, _ = guard_world(kernel, case, 5 if canary else 6, True)
    obs = record(world.a, tuple(case["center"]))
    return ((obs is None) if canary else (obs is not None)), {"center_record": obs, "guard_count": 5 if canary else 6}


def base_resolving(kernel, case, canary=False):
    n, q, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    da, db = convergent_dirs(case)
    delta = 2 if canary else (int(case["ordinal"]) % 2)
    raw = np.zeros((n, n, n), np.uint64)
    s1, s2 = 307, 401
    raw[add(q, da, -distance, n)] = pack(1, s1, da, 1)
    raw[add(q, db, -(distance + delta), n)] = pack(1, s2, db, 1)
    world = World(kernel, raw)
    events = []
    for tick in range(distance + delta + 4):
        obs = record(world.a, q)
        if obs:
            events.append((tick, obs["sreg"]))
        world.tick()
    if delta == 0:
        expected = [(distance, s1 + s2)]
    elif delta == 1:
        expected = [(distance, s1)]
    else:
        expected = [(distance, s1), (distance + delta, s2)]
    return events == expected, {"events": events, "analytic_expected": expected, "delta": delta}


def negative_additivity(kernel, case, canary=False):
    n, q, distance = int(case["n"]), tuple(case["center"]), int(case["distance"])
    da, db = convergent_dirs(case)
    s1, s2 = 307, 401
    def trace(mode):
        raw = np.zeros((n, n, n), np.uint64)
        if mode in {"A", "AB"}:
            raw[add(q, da, -distance, n)] = pack(1, s1, da, 1)
        if mode in {"B", "AB"}:
            raw[add(q, db, -distance, n)] = pack(1, s2, db, 1)
        world = World(kernel, raw)
        out = []
        for _ in range(distance + 3):
            obs = record(world.a, q)
            out.append(0 if obs is None else obs["sreg"])
            world.tick()
        return out
    a, b, ab = trace("A"), trace("B"), trace("AB")
    expected = [min(x + y, 19664) for x, y in zip(a, b)]
    return ab == expected, {"A": a, "B": b, "AB": ab, "additive_expected": expected}


def negative_coalescence(kernel, case, canary=False):
    if canary:
        return base_reducer(kernel, case, True)
    ok, tel = base_reducer(kernel, case, False)
    tel["interpretation"] = "one reduced destination record; not two persistent ensembles"
    return ok, tel


def assoc_memory(kernel, case, canary=False):
    from run_c6h01_associative_plasticity_holdout import BASE, simulate, transform
    rng = np.random.default_rng(int(case["seed"]))
    n = max(35, int(case["n"]))
    perm = tuple(np.roll(np.arange(3), int(case["axis"])).tolist())
    signs = [1, 1, 1]
    signs[int(case["axis"])] = int(case["sign"])
    vectors = {k: list(transform(v, perm, tuple(signs))) for k, v in BASE.items()}
    center = [int(x) for x in case["center"]]
    center = [min(max(8, x), n - 9) for x in center]
    cell = {
        "cell_id": case["trial_id"], "n": n, "junction": center, "train_tick": 4 + int(case["ordinal"]),
        "delay": int(case["delay"]), "query_path": 3, "vectors": vectors,
        "cue_sreg": 5 + int(case["ordinal"]), "teacher_sreg": 9 + int(case["ordinal"]), "query_sreg": 13 + int(case["ordinal"]), "eraser_sreg": 17,
        "states": [int(x) for x in rng.integers(1, 2**32, size=4, dtype=np.uint64)],
        "clocks": [int(rng.bit_generator.random_raw()) for _ in range(4)],
    }
    mode = "memory_ablation" if canary else "trained_pair"
    row = simulate(kernel, cell, mode)
    return ((not row["trained_exact"]) if canary else bool(row["training_exact"] and row["trained_exact"])), {"mode": mode, "training_exact": row["training_exact"], "trained_exact": row["trained_exact"], "neutral_exact": row["neutral_exact"], "ablation_present": row["ablation_present"], "readout_record": row["readout_record"]}


def regeneration(kernel, case, canary=False):
    from run_c8h02_repeated_scaffold_regeneration import simulate
    mode = "missing_corner" if canary else "primary_payload_nuisance"
    row = simulate(kernel, int(case["n"]), tuple(case["center"]), int(case["seed"]), mode, 5)
    expected = 0.0 if canary else 1.0
    ok = row["recovery_rate"] == expected and (canary or row["scaffold_raw_unchanged"])
    return ok, {"mode": mode, "recovery_rate": row["recovery_rate"], "stability_rate": row["stability_rate"], "scaffold_raw_unchanged": row["scaffold_raw_unchanged"], "records": row["records"]}


def ensemble_relaxation(kernel, case, canary=False):
    from run_c6h08_dissipative_ensemble_holdout import DIRECTIONS, prepared_support, simulate
    rng = np.random.default_rng(int(case["seed"]))
    n = int(case["n"])
    capacity = (n // 3) ** 3
    fill = 0.35 if int(case["ordinal"]) == 0 else 0.60
    count = max(8, int(round(capacity * fill)))
    support = prepared_support(n, count, rng)
    sregs = [int(x) for x in rng.integers(1, 8, size=count)]
    clocks = [int(x) for x in rng.integers(0, 2**32, size=count, dtype=np.uint64)]
    mixed = [DIRECTIONS[int(x)] for x in rng.integers(0, len(DIRECTIONS), size=count)]
    horizon = 5 * n
    mixed_trace, _ = simulate(kernel, n, support, sregs, clocks, mixed, horizon, False)
    aligned_trace, translated = simulate(kernel, n, support, sregs, clocks, [(1, 0, 0)] * count, horizon, True)
    monotone = all(b["support"] <= a["support"] and b["sreg_sum"] <= a["sreg_sum"] for a, b in zip(mixed_trace, mixed_trace[1:]))
    contracted = mixed_trace[-1]["support"] < mixed_trace[0]["support"]
    tail = mixed_trace[-n:]
    terminal = len({r["support"] for r in tail}) == 1 and len({r["sreg_sum"] for r in tail}) == 1
    ok = monotone and contracted and terminal and translated and all(x["support"] == aligned_trace[0]["support"] for x in aligned_trace)
    return ok, {"n": n, "fill": fill, "count": count, "monotone": monotone, "contracted": contracted, "terminal_constant": terminal, "aligned_translation_exact": translated, "initial": mixed_trace[0], "final": mixed_trace[-1], "tail": tail}


def boundary_time(kernel, case, canary=False):
    from run_c8h04_boundary_time_code import run_world
    row = run_world(kernel, int(case["n"]), int(case["seed"]), int(case["axis"]), int(case["sign"]))
    ok = row["reconstruction_rate"] == 1.0 and row["trajectory_prediction_rate"] == 1.0 and row["compression_ratio"] > 1.0
    return ok, row


def functional_recovery(kernel, case, canary=False):
    from run_c8h03_trained_redundancy_recovery import FRAMES, simulate
    rng = np.random.default_rng(int(case["seed"]))
    n = max(31, int(case["n"]))
    target = [int(x) for x in rng.integers(n // 2 - 3, n // 2 + 4, size=3)]
    cell = {"index": int(case["ordinal"]), "seed": int(case["seed"]), "delta": 3 + int(case["ordinal"]), "queries": [97], "n": n, "frame": FRAMES[int(case["axis"]) % len(FRAMES)], "target": target}
    mode = "no_donor" if canary else "trained_redundancy"
    row = simulate(kernel, cell, 97, mode)
    success = row["memory_restored"] and row["exact_unseen_response"]
    return ((not success) if canary else success), row


def adaptive_policy(kernel, case, canary=False):
    from run_c9d02_adaptive_loop_discovery import run_world
    axis = int(case["axis"])
    perm = tuple(np.roll(np.arange(3), axis).tolist())
    signs = [1, 1, 1]
    signs[axis] = int(case["sign"])
    mode = "memory_ablation" if canary else "contingent"
    row = run_world(kernel, int(case["seed"]), 17 + 2 * (int(case["ordinal"]) % 2), mode, 12, perm, tuple(signs))
    signal = row["post_first_acquisition_accuracy"] == 1 and row["post_first_reversal_accuracy"] == 1 and row["unseen_context_accuracy"] == 1 and row["damage_count"] == 2 and row["recovery_rate"] == 1 and row["scaffold_unchanged"]
    return ((not signal) if canary else signal), {k: row[k] for k in ("mode", "accuracy", "post_first_acquisition_accuracy", "post_first_reversal_accuracy", "unseen_context_accuracy", "damage_count", "recovery_rate", "scaffold_unchanged")}


def c10_frame(case):
    axis = int(case["axis"])
    return tuple(np.roll(np.arange(3), axis).tolist()), tuple(-1 if i == axis and int(case["sign"]) < 0 else 1 for i in range(3))


def bidirectional(kernel, case, canary=False):
    from core10_apparatus import run_bidirectional_exchange
    mode = "block_A_path" if canary else "AB"
    row = run_bidirectional_exchange(kernel, int(case["seed"]), int(case["n"]), int(case["distance"]), mode, *c10_frame(case), 1)
    both = row["functional"]["A_received_B_policy"] and row["functional"]["B_received_A_policy"]
    expected = (not row["functional"]["B_received_A_policy"]) and row["functional"]["A_received_B_policy"] if canary else both
    return bool(expected), {"mode": mode, "functional": row["functional"], "arrival_tick": row["arrival_tick"], "source_depleted": row["source_depleted"], "endpoint_at_arrival": row["endpoint_at_arrival"]}


def reinstantiation(kernel, case, canary=False):
    from core10_apparatus import run_learned_policy_transfer
    mode = "corridor_cut" if canary else "trained"
    row = run_learned_policy_transfer(kernel, int(case["seed"]), int(case["n"]), int(case["distance"]), mode, *c10_frame(case))
    signal = row["functional_policy_reinstantiated"] and row["source_depleted_after_launch"] and row["corridor_all_intermediate_ticks_observed"]
    return ((not row["functional_policy_reinstantiated"]) if canary else signal), {"mode": mode, "functional_policy_reinstantiated": row["functional_policy_reinstantiated"], "source_depleted_after_launch": row["source_depleted_after_launch"], "corridor_all_intermediate_ticks_observed": row["corridor_all_intermediate_ticks_observed"], "ticks": row["ticks"]}


def joint_homeostasis(kernel, case, canary=False):
    from core10_apparatus import run_joint_scaffold
    mode = "missing_shared_one" if canary else "AB"
    row = run_joint_scaffold(kernel, int(case["seed"]), int(case["n"]), mode, 4, int(case["axis"]))
    expected = row["joint_recovery_rate"] == (0.0 if canary else 1.0)
    return expected, {"mode": mode, "joint_recovery_rate": row["joint_recovery_rate"], "A_recovery_rate": row["A_recovery_rate"], "B_recovery_rate": row["B_recovery_rate"], "scaffold_unchanged": row["scaffold_unchanged"]}


def c10_bundle(kernel, case, canary=False):
    a, ta = bidirectional(kernel, case, canary)
    b, tb = reinstantiation(kernel, case, canary)
    d, td = joint_homeostasis(kernel, case, canary)
    return a and b and d, {"bidirectional": ta, "reinstantiation": tb, "joint_homeostasis": td, "component_predicates": [a, b, d]}


def event_composite(kernel, case, canary=False):
    a, ta = base_transport(kernel, case, canary)
    b, tb = base_phase_convergence(kernel, case, canary)
    d, td = base_capture(kernel, case, canary)
    return a and b and d, {"transport": ta, "phase_path": tb, "interface": td, "component_predicates": [a, b, d]}


def clock_prepare(kernel, n, center, guard, exposed, sreg):
    from native_core import NativeWorld, fields, pack as native_pack
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    d = (1, 0, 0)
    source = add(center, d, -8, n)
    if guard:
        raw[center] = native_pack(0x1234, 19, (0, 0, 0), 1)
        corners = [tuple((center[i] + x[i]) % n for i in range(3)) for x in itertools.product((-1, 1), repeat=3)]
        for i, q in enumerate(corners[:6]):
            raw[q] = native_pack(0xA000 + i, 31 + i, (0, 0, 0), 4)
    if exposed:
        raw[source] = native_pack(0, sreg, d, 4 if guard else 1)
        clock[source] = 123456 + n
    world = NativeWorld(kernel, raw, clock)
    for _ in range(16):
        world.tick()
    fa, fb = fields(world.raw_a), fields(world.raw_b)
    mask = (fa["sreg"] == sreg) | (fb["sreg"] == sreg)
    world.raw_a[mask] = 0
    world.raw_b[mask] = 0
    world.clock_a[mask] = 0
    world.clock_b[mask] = 0
    for _ in range(4):
        world.tick()
    return {"a": world.raw_a.copy(), "b": world.raw_b.copy(), "ca": world.clock_a.copy(), "cb": world.clock_b.copy()}


def clock_probe(kernel, state, n, center, semantic):
    from native_core import NativeWorld, pack as native_pack
    d = (1, 0, 0)
    source = add(center, d, -7, n)
    a, b, ca, cb = (state[x].copy() for x in ("a", "b", "ca", "cb"))
    a[source] = native_pack(1 if semantic == 1 else 0, 3991, d, semantic)
    b[source] = a[source]
    ca[source] = 99001
    cb[source] = 99001
    world = NativeWorld(kernel, a, ca)
    world.raw_b[:] = b
    world.clock_b[:] = cb
    rows = []
    for _ in range(18):
        rows.append((hashlib.sha256(world.raw_a.tobytes()).hexdigest(), int(world.raw_a[center])))
        world.tick()
    return rows


def clock_trace(kernel, case, canary=False):
    n, center = int(case["n"]), tuple(case["center"])
    results = []
    for guard in (False, True):
        exposed = clock_prepare(kernel, n, center, guard, True, 8888)
        control = clock_prepare(kernel, n, center, guard, False, 8888)
        raw_equal = np.array_equal(exposed["a"], control["a"]) and np.array_equal(exposed["b"], control["b"])
        clock_equal = np.array_equal(exposed["ca"], control["ca"]) and np.array_equal(exposed["cb"], control["cb"])
        probe_equal = all(clock_probe(kernel, exposed, n, center, sem) == clock_probe(kernel, control, n, center, sem) for sem in (1, 4))
        results.append({"class": "GUARD" if guard else "EMPTY", "raw_equal": raw_equal, "clock_equal": clock_equal, "probe_raw_readout_equal": probe_equal, "exposed_hashes": {k: hashlib.sha256(v.tobytes()).hexdigest() for k, v in exposed.items()}, "control_hashes": {k: hashlib.sha256(v.tobytes()).hexdigest() for k, v in control.items()}})
    ok = all(x["raw_equal"] and not x["clock_equal"] and x["probe_raw_readout_equal"] for x in results)
    return ok, {"classes": results, "classification": "persistent clock trace; no tested functional effect"}


FAMILIES = {
    "TRANSPORT": base_transport,
    "REDUCER": base_reducer,
    "GUARD": base_guard,
    "PHASE_TRAIN": base_phase_train,
    "PHASE_CONVERGENCE": base_phase_convergence,
    "CAPTURE": base_capture,
    "RESOLVING": base_resolving,
    "EVENT_COMPOSITE": event_composite,
    "ASSOC_MEMORY": assoc_memory,
    "REGENERATION": regeneration,
    "ENSEMBLE_RELAXATION": ensemble_relaxation,
    "BOUNDARY_TIME": boundary_time,
    "FUNCTIONAL_RECOVERY": functional_recovery,
    "ADAPTIVE_POLICY": adaptive_policy,
    "BIDIRECTIONAL": bidirectional,
    "BIDIRECTIONAL_OBSERVER": bidirectional,
    "REINSTANTIATION": reinstantiation,
    "JOINT_HOMEOSTASIS": joint_homeostasis,
    "C10_ECOLOGY_BUNDLE": c10_bundle,
    "CLOCK_TRACE": clock_trace,
    "NEGATIVE_ADDITIVITY": negative_additivity,
    "NEGATIVE_COALESCENCE": negative_coalescence,
}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--manifest", required=True)
    parser.add_argument("--contracts", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    if hashes() != EXPECTED:
        raise SystemExit("KERNEL_MISMATCH")
    sys.path.insert(0, str(RUNNERS))
    sys.path.insert(0, str(EXTRACTED))
    from dee_universe_v27 import dee_kernel_v27 as kernel
    manifest = json.loads(Path(args.manifest).read_text(encoding="utf-8"))
    contract_obj = json.loads(Path(args.contracts).read_text(encoding="utf-8"))
    contract_map = {c["contract_id"]: c for c in contract_obj["contracts"]}
    results = []
    for case in manifest["cases"]:
        contract = contract_map.get(case["contract_id"])
        if contract is None or contract["family"] != case["family"]:
            raise RuntimeError(f"unknown/mismatched contract {case['contract_id']}")
        family = case["family"]
        if family not in FAMILIES:
            raise RuntimeError(f"no frozen evaluator for {family}")
        ok, telemetry = FAMILIES[family](kernel, case, bool(case.get("canary", False)))
        results.append({
            "trial_id": case["trial_id"], "contract_id": case["contract_id"], "canonical_claim_id": case.get("canonical_claim_id"),
            "family": family, "lane": case["lane"], "wave": case.get("wave"), "canary": bool(case.get("canary", False)),
            "machine_predicate": bool(ok), "status": "PASS" if ok else "FAIL", "telemetry": telemetry,
            "dataflow": ["kernel state", "raw telemetry", "frozen readout", "frozen metric", "machine predicate", "status"],
        })
    out = Path(args.output)
    write(out / "EXECUTION_RESULTS.json", {
        "kernel": hashes(), "manifest_sha256": sha(args.manifest), "contracts_sha256": sha(args.contracts), "results": results,
        "summary": {"trials": len(results), "passed": sum(r["machine_predicate"] for r in results), "failed": sum(not r["machine_predicate"] for r in results), "canaries": sum(r["canary"] for r in results), "canaries_correct": sum(r["canary"] and r["machine_predicate"] for r in results)},
    })
    resolved = sorted(set(OPENED))
    forbidden_tokens = ("EXPEDIENTE_EXPERIMENTOS_DEE", "CORE14_CAUSAL_ECOLOGY_REBUILD_WORK", "MASTER_REVALIDATION_CORE01_TO_14_WORK")
    forbidden = [p for p in resolved if any(token in p.upper() for token in forbidden_tokens)]
    write(out / "FILE_ACCESS_AUDIT.json", {"files_opened": resolved, "forbidden_historical_access": forbidden, "result_leakage_attempts": len(forbidden), "pass": not forbidden})
    print(json.dumps({"trials": len(results), "passed": sum(r["machine_predicate"] for r in results), "failed": sum(not r["machine_predicate"] for r in results), "file_access_pass": not forbidden}, indent=2))
    return 0 if all(r["machine_predicate"] for r in results) and not forbidden else 2


if __name__ == "__main__":
    raise SystemExit(main())
