from __future__ import annotations

import argparse
import hashlib
import json
import secrets
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write(path: Path, value: object) -> None:
    import os
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(tmp, path)


def verify_freeze() -> dict:
    freeze = json.loads((ROOT / "SOURCE_FREEZE.json").read_text(encoding="utf-8"))
    if freeze.get("status") != "FROZEN" or freeze.get("fresh_worlds_existed") is not False:
        raise RuntimeError("invalid source freeze")
    bad = []
    for rel, expected in freeze["frozen_files"].items():
        path = ROOT / rel
        if not path.is_file() or sha(path) != expected:
            bad.append(rel)
    if bad:
        raise RuntimeError(f"source freeze invalidated: {bad}")
    return freeze


def opaque(seed: bytes, contract_id: str, wave: str, ordinal: int, canary: bool) -> str:
    payload = seed + contract_id.encode() + wave.encode() + ordinal.to_bytes(4, "little") + bytes([canary])
    return "T_" + hashlib.sha256(payload).hexdigest()[:12].upper()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wave", choices=("A", "B"), required=True)
    parser.add_argument("--challenge-seed", help="64 hexadecimal characters; OS entropy when absent")
    args = parser.parse_args()
    verify_freeze()
    target = ROOT / f"CHALLENGE_WAVE_{args.wave}.json"
    if target.exists():
        raise RuntimeError(f"wave already exists: {target.name}")
    seed_bytes = bytes.fromhex(args.challenge_seed) if args.challenge_seed else secrets.token_bytes(32)
    if len(seed_bytes) != 32:
        raise ValueError("challenge seed must be exactly 32 bytes")
    seed_int = int.from_bytes(hashlib.sha256(seed_bytes).digest()[:8], "little")
    rng = np.random.default_rng(seed_int)
    contracts = json.loads((ROOT / "FROZEN_CLAIM_CONTRACTS.json").read_text(encoding="utf-8"))["contracts"]
    if args.wave == "B":
        contracts = [c for c in contracts if c["high_impact"]]
    n_values = [31, 33, 35, 37, 39, 41, 43, 45, 47, 49, 51, 53, 55, 57]
    cases = []
    for contract in contracts:
        family = contract["family"]
        for ordinal in range(2):
            n = int(rng.choice(n_values))
            center = [int(x) for x in rng.integers(8, n - 8, size=3)]
            axis = int(rng.integers(0, 3))
            sign = int(rng.choice([-1, 1]))
            case_seed = int(rng.integers(1_000_000, 2_000_000_000))
            base = {
                "trial_id": opaque(seed_bytes, contract["contract_id"], args.wave, ordinal, False),
                "contract_id": contract["contract_id"],
                "canonical_claim_id": contract["canonical_claim_id"],
                "family": family,
                "lane": f"FRESH_WAVE_{args.wave}",
                "wave": args.wave,
                "ordinal": ordinal,
                "seed": case_seed,
                "n": n,
                "center": center,
                "axis": axis,
                "sign": sign,
                "distance": int(rng.integers(5, min(10, n // 3))),
                "delay": int(rng.integers(n + 5, n + 15)),
                "sreg": int(rng.integers(101, 5000)),
                "canary": False,
            }
            cases.append(base)
            if family not in {"ENSEMBLE_RELAXATION", "BOUNDARY_TIME", "CLOCK_TRACE"}:
                canary = dict(base)
                canary["trial_id"] = opaque(seed_bytes, contract["contract_id"], args.wave, ordinal, True)
                canary["lane"] = f"CANARY_WAVE_{args.wave}"
                canary["canary"] = True
                canary["seed"] = case_seed + 104729
                cases.append(canary)
    seed_record_path = ROOT / "MASTER_CHALLENGE_SEED.json"
    seed_record = json.loads(seed_record_path.read_text(encoding="utf-8")) if seed_record_path.exists() else {"waves": []}
    seed_record["waves"].append({
        "wave": args.wave,
        "source": "USER_SUPPLIED_HEX" if args.challenge_seed else "OS_ENTROPY",
        "seed_hex": seed_bytes.hex(),
        "seed_sha256": hashlib.sha256(seed_bytes).hexdigest(),
        "generator_sha256": sha(Path(__file__)),
    })
    write(seed_record_path, seed_record)
    manifest = {
        "schema": "dee.v27.master.challenge_wave.v2",
        "wave": args.wave,
        "seed_sha256": hashlib.sha256(seed_bytes).hexdigest(),
        "generator_sha256": sha(Path(__file__)),
        "source_freeze_sha256": sha(ROOT / "SOURCE_FREEZE.json"),
        "opaque_labels": True,
        "manual_case_selection": False,
        "cases": cases,
        "summary": {"contracts": len(contracts), "cases": len(cases), "positive": sum(not x["canary"] for x in cases), "canaries": sum(x["canary"] for x in cases)},
    }
    write(target, manifest)
    print(json.dumps({"wave": args.wave, "contracts": len(contracts), "cases": len(cases), "seed_sha256": manifest["seed_sha256"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
