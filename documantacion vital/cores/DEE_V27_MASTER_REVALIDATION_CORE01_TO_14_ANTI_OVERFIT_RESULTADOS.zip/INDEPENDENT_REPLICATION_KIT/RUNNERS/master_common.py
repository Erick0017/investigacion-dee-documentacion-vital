from __future__ import annotations
import hashlib, importlib, json, os, platform, sys, zipfile
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT.parent
CORE_ARCHIVE = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "CORE"
QUARANTINE = TESTS / "DEE_V27_MASTER_REVALIDATION_REBUILD_QUARANTINE"
KERNEL_ROOT = ROOT / "KERNEL"
EXTRACTED = KERNEL_ROOT / "wheel_extracted"
WHEEL = KERNEL_ROOT / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
PACKAGE = EXTRACTED / "dee_universe_v27" / "__init__.py"
PYD = EXTRACTED / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
EXPECTED = {
    "wheel": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
    "package": "7e2991b1fc8a053ee44ead6e177b129855ae9265dea68505a8e545f0c3fdf8b4",
    "pyd": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
}
CORE14_ZIP = "14_DEE_V27_CAUSAL_ECOLOGY_ENVIRONMENT_MATTER_AND_MULTI_ROSETTA_RESULTADOS.zip"
CORE14_SHA = "ad158c922da87e9696247f149c0302329981efb16050a1cbe020aa0260acb4c3"
STATE_MASK=np.uint64((1<<32)-1); SREG_MASK=np.uint64(0xffff); SEM_MASK=np.uint64(15)

def utc(): return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
def sha(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1<<20), b""): h.update(b)
    return h.hexdigest()
def sha_bytes(data): return hashlib.sha256(data).hexdigest()
def native(v):
    if isinstance(v, dict): return {str(k):native(x) for k,x in v.items()}
    if isinstance(v, (list,tuple)): return [native(x) for x in v]
    if isinstance(v, np.generic): return v.item()
    return v
def atomic_text(path, text):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True); tmp=path.with_suffix(path.suffix+".tmp")
    with tmp.open("w", encoding="utf-8", newline="\n") as f:
        f.write(text); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,path)
def atomic_json(path, obj): atomic_text(path,json.dumps(native(obj),indent=2,sort_keys=True,ensure_ascii=False,allow_nan=False)+"\n")
def append_ndjson(path,obj):
    path=Path(path); old=path.read_text(encoding="utf-8") if path.exists() else ""
    atomic_text(path,old+json.dumps(native({"utc":utc(),**obj}),separators=(",",":"),ensure_ascii=False)+"\n")
def kernel_hashes(): return {"wheel":sha(WHEEL),"package":sha(PACKAGE),"pyd":sha(PYD)}
def audit_kernel(stage):
    path=ROOT/"KERNEL_IMMUTABILITY_AUDIT.json"
    obj=json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"expected":EXPECTED,"checks":[]}
    observed=kernel_hashes(); passed=observed==EXPECTED
    obj["checks"].append({"stage":stage,"utc":utc(),"observed":observed,"pass":passed})
    obj["all_pass"]=all(x["pass"] for x in obj["checks"]); atomic_json(path,obj)
    if not passed: raise RuntimeError("canonical kernel mismatch")
def load_kernel():
    if sys.version_info[:2] != (3,13): raise RuntimeError("CPython 3.13 required")
    if kernel_hashes()!=EXPECTED: raise RuntimeError("canonical runtime mismatch")
    sys.path.insert(0,str(EXTRACTED)); importlib.invalidate_caches()
    import dee_universe_v27 as pkg
    from dee_universe_v27 import dee_kernel_v27 as kernel
    if Path(pkg.__file__).resolve()!=PACKAGE.resolve() or Path(kernel.__file__).resolve()!=PYD.resolve(): raise RuntimeError("wrong binary import")
    return kernel,{"python":sys.version,"numpy":np.__version__,"platform":platform.platform(),"hashes":EXPECTED}
def pack(state,sreg,direction,semantic=1):
    return np.uint64((state&0xffffffff)|((sreg&0xffff)<<32)|((direction[0]&15)<<48)|((direction[1]&15)<<52)|((direction[2]&15)<<56)|((semantic&15)<<60))
def signed(v,shift):
    x=(np.asarray(v,dtype=np.uint64)>>np.uint64(shift))&np.uint64(15); x=x.astype(np.int16)
    return np.where(x>=8,x-16,x)
def unpack(v):
    v=np.uint64(v)
    return {"raw":int(v),"state":int(v&STATE_MASK),"sreg":int((v>>np.uint64(32))&SREG_MASK),"direction":[int(signed(v,s)) for s in (48,52,56)],"semantic":int((v>>np.uint64(60))&SEM_MASK)}
class World:
    def __init__(self,kernel,raw,clock=None,t=1):
        self.k=kernel; self.n=raw.shape[0]; self.t=t
        self.a=np.ascontiguousarray(raw,dtype=np.uint64).copy(); self.b=self.a.copy()
        c=np.zeros_like(raw,dtype=np.uint64) if clock is None else clock
        self.ca=np.ascontiguousarray(c,dtype=np.uint64).copy(); self.cb=self.ca.copy()
    @property
    def raw(self): return self.a
    @property
    def clock(self): return self.ca
    def tick(self): return native(dict(self.k.tick_universo_lazy(self.a,self.b,self.ca,self.cb,self.n,self.t)))
def verify_zip_hashes(path):
    with zipfile.ZipFile(path) as z:
        names=set(z.namelist())
        state_ok=any(n.endswith("STATE.json") for n in names)
        manifest_ok=any(n.endswith("MANIFEST.json") for n in names)
        bad=[]; checked=0
        hash_names=[n for n in names if n.endswith("HASHES.sha256")]
        if hash_names:
            prefix=hash_names[0][:-len("HASHES.sha256")]
            for line in z.read(hash_names[0]).decode("utf-8",errors="replace").splitlines():
                if not line.strip(): continue
                bits=line.split(None,1)
                if len(bits)!=2: continue
                expected,rel=bits; rel=rel.lstrip("* ").replace("\\","/"); target=prefix+rel
                if target in names:
                    checked+=1
                    if sha_bytes(z.read(target))!=expected.lower(): bad.append(rel)
        return {"zip_test":z.testzip() is None,"state_present":state_ok,"manifest_present":manifest_ok,"internal_hashes_checked":checked,"internal_hash_mismatches":bad,"pass":z.testzip() is None and state_ok and manifest_ok and not bad}
