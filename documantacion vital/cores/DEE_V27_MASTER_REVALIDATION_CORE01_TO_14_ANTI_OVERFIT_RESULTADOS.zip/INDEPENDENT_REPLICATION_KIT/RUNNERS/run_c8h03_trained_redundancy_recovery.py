#!/usr/bin/env python3
"""Frozen C8H03: R5 learned-function recovery by finite trained redundancy."""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, canonical_hash, pack, unpack_scalar, update_state, verify_and_load_kernel

LOCK = ROOT / "HOLDOUT_LOCKS" / "C8H03_TRAINED_REDUNDANCY_FUNCTIONAL_RECOVERY.json"
EXPECTED_LOCK_SHA256 = "ea0703d2243642fea9f31acefbb7a9857547d71a11ac17d69ea44c13c3ce6e8e"
FRAMES = [
    ((0, 1, 2), (1, 1, 1)), ((0, 1, 2), (-1, 1, 1)),
    ((1, 0, 2), (1, 1, 1)), ((1, 0, 2), (1, -1, 1)),
    ((2, 1, 0), (1, 1, 1)), ((2, 1, 0), (-1, 1, -1)),
    ((0, 2, 1), (1, -1, 1)), ((1, 2, 0), (-1, -1, 1)),
]


def tr(v, frame):
    permutation, signs = frame
    return tuple(signs[i] * v[permutation[i]] for i in range(3))


def add(q, d, k, n):
    return tuple((q[i] + k * d[i]) % n for i in range(3))


def place(raw, clock, destination, tick, direction, sreg, state, n):
    q = add(destination, direction, -tick, n)
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, 1)
    clock[q] = np.uint64(7919 * state + tick)


def read(raw, q):
    return unpack_scalar(raw[q]) if int(raw[q]) else None


def simulate(kernel, cell, query, mode):
    n, delta, seed, frame = cell["n"], cell["delta"], cell["seed"], cell["frame"]
    B, t0, td = 4096, 4, 14
    M, D, R, Q = (tr(v, frame) for v in ((0, 1, 0), (1, 1, 0), (-1, 0, 0), (1, 0, 0)))
    cue, mt, dt = (tr(v, frame) for v in ((1, 0, 0), (-1, 1, 0), (0, 1, 0)))
    target = tuple(cell["target"])
    gate = add(target, M, -2, n)
    jm = add(target, M, -(td - t0), n)
    jd = add(gate, D, -(td - t0), n)
    receiver = add(target, M, 9, n)
    tq = td + 9 if mode == "no_damage" else td + 11
    raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw)
    xm, xd = cell.get("training_x_main", 19 + cell["index"]), cell.get("training_x_donor", 31 + cell["index"])
    place(raw, clock, jm, t0, cue, B - xm, 100 + cell["index"], n)
    place(raw, clock, jm, t0, mt, xm + delta, 200 + cell["index"], n)
    donor_delta = delta + (19 if mode == "wrong_donor" else (-17 if mode == "label_shuffled_donor" else 0))
    if mode != "no_donor":
        place(raw, clock, jd, t0, cue, B - xd, 300 + cell["index"], n)
        place(raw, clock, jd, t0, dt, xd + donor_delta, 400 + cell["index"], n)
        off = tr((0, 0, 1), frame)
        redirect_target = add(gate, off, 4, n) if mode == "offpath_donor" else gate
        place(raw, clock, redirect_target, td, R, 0, 500 + cell["index"], n)
    place(raw, clock, receiver, tq, Q, query, 600 + cell["index"], n)
    world = NativeWorld(kernel, raw, clock)
    events = {}
    for tick in range(tq + 1):
        if tick == t0:
            events["main_trained"] = read(world.raw, jm); events["donor_trained"] = read(world.raw, jd)
        if tick == t0 + 3 and mode == "memory_ablation":
            q = add(jd, D, 3, n); prior = read(world.raw, q); events["ablated_memory"] = prior
            if prior:
                value = pack(prior["state"], 0, tuple(prior["direction"]), prior["semantic"])
                world.raw_a[q] = value; world.raw_b[q] = value
        if tick == td:
            events["main_at_damage"] = read(world.raw, target); events["donor_at_gate"] = read(world.raw, gate)
            if mode != "no_damage":
                world.raw_a[target] = np.uint64(0); world.raw_b[target] = np.uint64(0)
                world.clock_a[target] = np.uint64(0); world.clock_b[target] = np.uint64(0)
            if mode == "actuator_direction_ablation" and int(world.raw[gate]):
                prior = read(world.raw, gate)
                value = pack(prior["state"], prior["s_reg"], (0, 0, 0), prior["semantic"])
                world.raw_a[gate] = value; world.raw_b[gate] = value
        if tick == td + 2:
            events["restored"] = read(world.raw, target)
        if tick == tq:
            events["response"] = read(world.raw, receiver)
        if tick < tq:
            world.tick()
    response, restored = events.get("response"), events.get("restored")
    decoded = None if response is None else response["s_reg"] - B
    memory_ok = restored is not None and restored["s_reg"] == B + delta and restored["direction"] == list(M)
    response_ok = response is not None and response["direction"] == [int(np.sign(M[i] + Q[i])) for i in range(3)] and decoded == query + delta
    return {"cell": cell["index"], "n": n, "frame": {"permutation": frame[0], "signs": frame[1]}, "target": list(target), "mode": mode, "delta": delta, "donor_delta": donor_delta, "query": query, "decoded": decoded, "memory_restored": memory_ok, "exact_unseen_response": response_ok, "events": events}


def main() -> int:
    started = time.perf_counter()
    lock_sha = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if lock_sha != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock changed: {lock_sha}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    cells = []
    for i, (seed, delta, queries) in enumerate(zip(lock["parameters"]["seeds"], lock["parameters"]["deltas"], lock["parameters"]["queries"], strict=True)):
        n = lock["domain"]["N"][i % len(lock["domain"]["N"])]
        rng = np.random.default_rng(seed)
        target = [int(v) for v in rng.integers(n // 2 - 3, n // 2 + 4, size=3)]
        cells.append({"index": i, "seed": seed, "delta": delta, "queries": queries, "n": n, "frame": FRAMES[i], "target": target})
    positives = [simulate(kernel, cell, query, "trained_redundancy") for cell in cells for query in cell["queries"]]
    baselines = [simulate(kernel, cell, query, "no_damage") for cell in cells for query in cell["queries"]]
    negative_modes = ["no_donor", "wrong_donor", "label_shuffled_donor", "offpath_donor", "memory_ablation", "actuator_direction_ablation"]
    negatives = [simulate(kernel, cell, cell["queries"][0], mode) for cell in cells for mode in negative_modes]
    rates = {
        "positive_exact_rate": sum(row["exact_unseen_response"] for row in positives) / len(positives),
        "positive_memory_restore_rate": sum(row["memory_restored"] for row in positives) / len(positives),
        "no_damage_exact_rate": sum(row["exact_unseen_response"] for row in baselines) / len(baselines),
        "negative_exact_rate": sum(row["exact_unseen_response"] for row in negatives) / len(negatives),
    }
    threshold = lock["minimum_effect"]
    conditions = {
        "positive_response": rates["positive_exact_rate"] >= threshold["positive_exact_rate"],
        "positive_memory": rates["positive_memory_restore_rate"] >= threshold["positive_memory_restore_rate"],
        "no_damage": rates["no_damage_exact_rate"] >= threshold["no_damage_exact_rate"],
        "negative_controls": rates["negative_exact_rate"] <= threshold["negative_exact_rate_max"],
    }
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core08.c8h03.v1",
        "module_id": lock["claim_id"],
        "role": "FROZEN_CONFIRMATION",
        "status": "COMPLETE",
        "verdict": verdict,
        "lock_sha256": lock_sha,
        "kernel_environment": environment,
        "sample_sizes": {"cells": len(cells), "unseen_queries": sum(len(c["queries"]) for c in cells), "positive_worlds": len(positives), "no_damage_worlds": len(baselines), "negative_worlds": len(negatives)},
        "wall_clock_seconds": time.perf_counter() - started,
        "rates": rates,
        "conditions": conditions,
        "cells": cells,
        "positives": positives,
        "baselines": baselines,
        "negatives": negatives,
        "recovery_level": "R5_FUNCTIONAL_RECOVERY_BY_FINITE_TRAINED_REDUNDANCY",
        "explicit_nonclaims": ["R6 internally triggered learned repair", "R7 repeated learned-memory regeneration", "reconstruction from the damaged carrier", "general self-repair"],
        "scope": lock["claim_scope"],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C8H03_trained_redundancy_functional_recovery.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": "C8H03", "verdict": verdict, "lock_sha256": lock_sha, "rates": rates})
    update_state(last_completed_experiment=lock["claim_id"], complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04", "C8H02", "C8H03"], pending_holdout=None, next_action="Run observer alias and EXTRA03 dimensional projection discovery.")
    print(json.dumps({"verdict": verdict, "sample_sizes": result["sample_sizes"], "rates": rates, "conditions": conditions}, indent=2))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
