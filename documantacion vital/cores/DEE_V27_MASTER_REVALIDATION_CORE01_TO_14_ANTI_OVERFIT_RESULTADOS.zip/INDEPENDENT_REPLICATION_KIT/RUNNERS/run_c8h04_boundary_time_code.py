#!/usr/bin/env python3
"""Frozen EXTRA03 confirmation of a restricted boundary-history observer."""
from __future__ import annotations

import hashlib
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, canonical_hash, pack, update_state, verify_and_load_kernel

LOCK = ROOT / "HOLDOUT_LOCKS" / "C8H04_BOUNDARY_TIME_CODE.json"
EXPECTED_LOCK_SHA256 = "e148517ad733f3bbe65b9e3460202e6820f2225632ec31b85fe448b8c0d8874c"
ORIENTATIONS = [(0, 1), (0, -1), (1, 1), (1, -1), (2, 1), (2, -1)]


def surface_coordinate(position, axis):
    return tuple(position[i] for i in range(3) if i != axis)


def build_position(axis, normal_coordinate, lateral):
    values = list(lateral)
    values.insert(axis, normal_coordinate)
    return tuple(values)


def run_world(kernel, n, seed, axis, sign):
    rng = np.random.default_rng(seed)
    grid = list(range(2, n - 2, 3))
    shift = int(rng.integers(0, 3))
    grid = [((x - 2 + shift) % (n - 4)) + 2 for x in grid]
    grid = sorted(set(grid))
    rays = [(a, b) for a in grid for b in grid]
    raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw)
    direction = [0, 0, 0]; direction[axis] = sign; direction = tuple(direction)
    truth = {}
    for index, lateral in enumerate(rays):
        depth_coord = int(rng.integers(1, n - 1))
        sreg = 100 + index
        position = build_position(axis, depth_coord, lateral)
        raw[position] = pack(10000 + index, sreg, direction, 1)
        clock[position] = np.uint64(rng.bit_generator.random_raw())
        arrival = n - 1 - depth_coord if sign > 0 else depth_coord
        truth[sreg] = {"position": list(position), "normal_coordinate": depth_coord, "lateral": list(lateral), "arrival": arrival}
    world = NativeWorld(kernel, raw, clock)
    boundary_coordinate = n - 1 if sign > 0 else 0
    events = []
    for tick in range(n):
        plane = np.take(world.raw, boundary_coordinate, axis=axis)
        for lateral_index in np.argwhere(plane != 0):
            lateral = tuple(int(x) for x in lateral_index)
            position = build_position(axis, boundary_coordinate, lateral)
            value = int(world.raw[position])
            sreg = int((np.uint64(value) >> np.uint64(32)) & np.uint64(0xFFFF))
            events.append({"lateral": list(lateral), "arrival": tick, "s_reg": sreg})
        world.tick()
    reconstruction = {}
    for event in events:
        normal = n - 1 - event["arrival"] if sign > 0 else event["arrival"]
        position = build_position(axis, normal, tuple(event["lateral"]))
        reconstruction[event["s_reg"]] = {"position": list(position), "normal_coordinate": normal, "lateral": event["lateral"], "arrival": event["arrival"]}
    reconstruction_rate = sum(reconstruction.get(key) == value for key, value in truth.items()) / len(truth)
    future_checks = []
    for tick in range(n, n + 4):
        observed = {(tuple(int(x) for x in q), int((world.raw[tuple(q)] >> np.uint64(32)) & np.uint64(0xFFFF))) for q in np.argwhere(world.raw != 0)}
        predicted = set()
        for sreg, row in reconstruction.items():
            q = row["position"][:]
            q[axis] = (q[axis] + sign * tick) % n
            predicted.add((tuple(q), sreg))
        future_checks.append({"tick": tick, "exact": observed == predicted, "observed_count": len(observed), "predicted_count": len(predicted)})
        world.tick()
    local_rng = np.random.default_rng(seed + 991)
    perm_time = local_rng.permutation(len(events))
    perm_space = local_rng.permutation(len(events))
    shuffled_time_correct = 0
    shuffled_location_correct = 0
    for i, event in enumerate(events):
        true = truth[event["s_reg"]]
        shuffled_arrival = events[int(perm_time[i])]["arrival"]
        inferred_normal = n - 1 - shuffled_arrival if sign > 0 else shuffled_arrival
        shuffled_time_correct += int(inferred_normal == true["normal_coordinate"])
        shuffled_lateral = events[int(perm_space[i])]["lateral"]
        shuffled_location_correct += int(shuffled_lateral == true["lateral"])
    counts = {}
    for row in truth.values():
        counts[row["normal_coordinate"]] = counts.get(row["normal_coordinate"], 0) + 1
    projection_only_depth_accuracy = max(counts.values()) / len(truth)
    bits = len(events) * (3 * math.ceil(math.log2(n)) + 16)
    return {
        "n": n, "seed": seed, "axis": axis, "sign": sign, "rays": len(rays), "events": len(events),
        "reconstruction_rate": reconstruction_rate,
        "trajectory_prediction_rate": sum(r["exact"] for r in future_checks) / len(future_checks),
        "future_checks": future_checks,
        "time_shuffle_accuracy": shuffled_time_correct / len(events),
        "location_shuffle_accuracy": shuffled_location_correct / len(events),
        "instantaneous_projection_best_constant_depth_accuracy": projection_only_depth_accuracy,
        "event_code_bits": bits,
        "full_raw_bits": n**3 * 64,
        "compression_ratio": n**3 * 64 / bits,
    }


def main() -> int:
    started = time.perf_counter()
    lock_sha = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if lock_sha != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock changed: {lock_sha}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    rows = []
    for i in range(lock["domain"]["worlds"]):
        n = lock["domain"]["N"][i % 4]
        axis, sign = ORIENTATIONS[i % len(ORIENTATIONS)]
        seed = lock["parameters"]["seeds"][i % 4] + 1009 * i
        rows.append(run_world(kernel, n, seed, axis, sign))
    rates = {
        "reconstruction_rate": sum(row["reconstruction_rate"] * row["rays"] for row in rows) / sum(row["rays"] for row in rows),
        "trajectory_prediction_rate": sum(row["trajectory_prediction_rate"] for row in rows) / len(rows),
        "time_shuffle_accuracy": sum(row["time_shuffle_accuracy"] * row["rays"] for row in rows) / sum(row["rays"] for row in rows),
        "location_shuffle_accuracy": sum(row["location_shuffle_accuracy"] * row["rays"] for row in rows) / sum(row["rays"] for row in rows),
        "instantaneous_projection_depth_accuracy": sum(row["instantaneous_projection_best_constant_depth_accuracy"] * row["rays"] for row in rows) / sum(row["rays"] for row in rows),
    }
    by_n = {}
    for row in rows:
        by_n.setdefault(row["n"], []).append(row["rays"])
    ns = np.asarray(sorted(by_n), dtype=float)
    ks = np.asarray([np.mean(by_n[int(n)]) for n in ns], dtype=float)
    exponent = float(np.polyfit(np.log(ns), np.log(ks), 1)[0])
    m = lock["minimum_effect"]
    conditions = {
        "reconstruction": rates["reconstruction_rate"] >= m["reconstruction_rate"],
        "future": rates["trajectory_prediction_rate"] >= m["trajectory_prediction_rate"],
        "time_control": rates["time_shuffle_accuracy"] <= m["time_shuffle_accuracy_max"],
        "location_control": rates["location_shuffle_accuracy"] <= m["location_shuffle_accuracy_max"],
        "scaling": m["ray_count_scaling_exponent_min"] <= exponent <= m["ray_count_scaling_exponent_max"],
    }
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core08.c8h04.v1",
        "module_id": lock["claim_id"], "role": "FROZEN_CONFIRMATION", "status": "COMPLETE", "verdict": verdict,
        "lock_sha256": lock_sha, "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started,
        "sample_sizes": {"worlds": len(rows), "carriers": sum(r["rays"] for r in rows), "future_world_ticks_checked": 4 * len(rows)},
        "rates": rates, "ray_count_scaling_exponent": exponent, "conditions": conditions, "worlds": rows,
        "adjudication": ["BOUNDARY_HISTORY_SUFFICIENT", "LOWER_DIMENSIONAL_EFFECTIVE_STATE"],
        "holographic_like_status": "NOT_PROMOTED: the prepared family's independent degrees already scale with surface rays; arbitrary volume states remain aliased",
        "scope": lock["claim_scope"],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C8H04_boundary_time_code.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": "C8H04", "verdict": verdict, "lock_sha256": lock_sha, "rates": rates, "scaling_exponent": exponent})
    update_state(last_completed_experiment=lock["claim_id"], complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04", "C8H02", "C8H03", "C8D05", "C8H04"], pending_holdout=None, next_action="Construct neutral fingerprints and blind convergence comparison; finish historical repair re-audit.")
    print(json.dumps({"verdict": verdict, "sample_sizes": result["sample_sizes"], "rates": rates, "scaling_exponent": exponent, "conditions": conditions}, indent=2))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
