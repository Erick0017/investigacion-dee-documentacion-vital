#!/usr/bin/env python3
"""Discovery: recurrent policy carrier, valence consequence and fixed scaffold repair."""
from __future__ import annotations

import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core09_common import ROOT, NativeWorld, atomic_json, append_log, canonical_hash, fields, pack, unpack_scalar, update_state, verify_and_load_kernel

A = (1, 0, 0); B = (0, 1, 0); SENSOR = (-1, 0, 1); NORMALIZER = (1, 0, -1)
ACTION = {A: (0, 0, 1), B: (-1, 1, 1)}
PENALTY = {0: (-1, 1, 0), 1: (1, -1, 0)}


def add(q, d, k, n): return tuple((q[i] + k * d[i]) % n for i in range(3))


def tr(v, perm, signs): return tuple(signs[i] * v[perm[i]] for i in range(3))


def read(raw, q): return unpack_scalar(raw[q]) if int(raw[q]) else None


def inject_arrival(world, target, direction, sreg, state, clock):
    port = add(target, direction, -1, world.n)
    world.inject(port, pack(state, sreg, direction, 1), clock)


def scaffold(world, center, rng):
    positions = []
    for offset in itertools.product((-1, 1), repeat=3):
        q = add(center, offset, 1, world.n); positions.append(q)
        world.raw_a[q] = pack(int(rng.integers(1, 2**32)), int(rng.integers(0, 19665)), (0, 0, 0), 4)
        world.raw_b[q] = world.raw_a[q]; world.clock_a[q] = np.uint64(rng.bit_generator.random_raw()); world.clock_b[q] = world.clock_a[q]
    world.raw_a[center] = pack(1, 1, (0, 0, 0), 7); world.raw_b[center] = world.raw_a[center]
    return positions


def run_world(kernel, seed, n=17, mode="contingent", episodes=12, perm=(0, 1, 2), signs=(1, 1, 1), contexts=None):
    rng = np.random.default_rng(seed); raw = np.zeros((n, n, n), dtype=np.uint64); clock = np.zeros_like(raw)
    world = NativeWorld(kernel, raw, clock); D = (n // 2, n // 2, n // 2); C = (2, 4, 6)
    a, b, sensor, normalizer = (tr(v, perm, signs) for v in (A, B, SENSOR, NORMALIZER)); actions = {a: tr(ACTION[A], perm, signs), b: tr(ACTION[B], perm, signs)}
    penalties = {0: tr(PENALTY[0], perm, signs), 1: tr(PENALTY[1], perm, signs)}
    world.raw_a[D] = pack(1000 + seed, 7, a, 1); world.raw_b[D] = world.raw_a[D]
    scaffold_positions = scaffold(world, C, rng); scaffold_initial = [int(world.raw[q]) for q in scaffold_positions]
    decision_times = [(2 * e + 1) * n for e in range(episodes)]; feedback_times = [(2 * e + 2) * n for e in range(episodes)]
    contexts = ([11, 13, 17, 19, 101, 103, 23, 29, 31, 37, 107, 109] if contexts is None else list(contexts))[:episodes]
    if len(contexts) != episodes: raise ValueError("one context per episode required")
    initial_support = int(np.count_nonzero(world.raw)); initial_sreg = int(fields(world.raw)["sreg"].astype(np.uint64).sum())
    correct = [1] * (episodes // 2) + [0] * (episodes - episodes // 2)
    if mode == "random_contingency": correct = [int(x) for x in rng.integers(0, 2, size=episodes)]
    reference_penalty = [True] + [False] * (episodes // 2 - 1) + [True] + [False] * (episodes - episodes // 2 - 1)
    yoked = [False] + reference_penalty[:-1]
    decisions = []; pending = {}; total_genesis = 0; damage_count = 0; recovery_count = 0
    end = feedback_times[-1]
    for tick in range(end + 1):
        if tick in [t - 1 for t in decision_times]:
            e = decision_times.index(tick + 1); sdir = sensor
            if mode == "sensor_shuffle":
                sdir = tr(((0, -1, 1), (1, 0, 1), (-1, 0, 1))[e % 3], perm, signs)
            inject_arrival(world, D, sdir, contexts[e], 200000 + 100 * seed + e, 300000 + e)
        if tick in decision_times:
            e = decision_times.index(tick); record = read(world.raw, D); direction = None if record is None else tuple(record["direction"])
            physical = 0 if direction == actions[a] else (1 if direction == actions[b] else None)
            interpreted = None if physical is None else (1 - physical if mode == "action_channel_swap" else physical)
            wrong = interpreted is None or interpreted != correct[e]
            apply_penalty = wrong if mode in {"contingent", "action_channel_swap", "random_contingency", "memory_ablation"} else (mode == "noncontingent_punishment" or (mode == "yoked_damage" and yoked[e]))
            pending[e] = {"physical_action": physical, "interpreted_action": interpreted, "wrong": wrong, "penalty": apply_penalty}
            if wrong:
                damage_count += 1; world.raw_a[C] = np.uint64(0); world.raw_b[C] = np.uint64(0); world.clock_a[C] = np.uint64(0); world.clock_b[C] = np.uint64(0)
            decisions.append({"episode": e, "phase": "acquisition" if e < episodes // 2 else "reversal", "context_sreg": contexts[e], "unseen_context": contexts[e] >= 100, "correct_action": correct[e], "record": record, **pending[e]})
        if tick in [t - 1 for t in feedback_times]:
            e = feedback_times.index(tick + 1); inject_arrival(world, D, normalizer, 3, 400000 + e, 500000 + e)
            if pending[e]["penalty"] and pending[e]["physical_action"] is not None:
                inject_arrival(world, D, penalties[pending[e]["physical_action"]], 5, 600000 + e, 700000 + e)
        if tick in feedback_times:
            e = feedback_times.index(tick); memory = read(world.raw, D)
            if mode in {"memory_ablation", "reset"} and memory is not None:
                world.raw_a[D] = pack(memory["state"], memory["sreg"], a, memory["semantic"]); world.raw_b[D] = world.raw_a[D]; memory = read(world.raw, D)
            decisions[e]["post_feedback_memory"] = memory
            decisions[e]["repair_recovered"] = read(world.raw, C) is not None
            recovery_count += int(decisions[e]["repair_recovered"] and decisions[e]["wrong"])
        if tick < end:
            info = world.tick(); total_genesis += int(info.get("genesis_count", 0))
    correct_flags = [not r["wrong"] for r in decisions]; half = episodes // 2
    post_acq = correct_flags[1:half]; post_rev = correct_flags[half + 1:]
    unseen = [not r["wrong"] for r in decisions if r["unseen_context"]]
    return {"seed": seed, "n": n, "mode": mode, "frame": {"permutation": perm, "signs": signs}, "episodes": episodes, "accuracy": sum(correct_flags) / episodes, "post_first_acquisition_accuracy": sum(post_acq) / len(post_acq), "post_first_reversal_accuracy": sum(post_rev) / len(post_rev), "unseen_context_accuracy": sum(unseen) / len(unseen), "damage_count": damage_count, "recovery_count": recovery_count, "recovery_rate": recovery_count / damage_count if damage_count else 1.0, "scaffold_unchanged": [int(world.raw[q]) for q in scaffold_positions] == scaffold_initial, "total_genesis": total_genesis, "resource_accounting": {"initial_support": initial_support, "final_support": int(np.count_nonzero(world.raw)), "initial_sreg": initial_sreg, "final_sreg": int(fields(world.raw)["sreg"].astype(np.uint64).sum()), "external_sensor_load": int(sum(contexts)), "normalizer_load": 3 * episodes, "penalty_load": 5 * sum(r["penalty"] for r in decisions)}, "decisions": decisions}


def main() -> int:
    started = time.perf_counter(); kernel, environment = verify_and_load_kernel(1)
    frames = [((0, 1, 2), (1, 1, 1)), ((1, 0, 2), (1, -1, 1)), ((2, 1, 0), (-1, 1, 1))]
    primary = [run_world(kernel, 910000 + i, 17 + 2 * (i % 2), "contingent", 12, *frames[i % len(frames)]) for i in range(6)]
    control_modes = ["equal_exposure_no_consequence", "memory_ablation", "reset", "yoked_damage", "random_contingency", "noncontingent_punishment", "sensor_shuffle", "action_channel_swap", "fixed_reflex"]
    controls = [run_world(kernel, 920000 + 100 * j + i, 17 + 2 * (i % 2), mode, 12, *frames[i % len(frames)]) for j, mode in enumerate(control_modes) for i in range(2)]
    summary = {"primary": {k: float(np.mean([r[k] for r in primary])) for k in ("accuracy", "post_first_acquisition_accuracy", "post_first_reversal_accuracy", "unseen_context_accuracy", "damage_count", "recovery_rate")}, "controls": {mode: {k: float(np.mean([r[k] for r in controls if r["mode"] == mode])) for k in ("accuracy", "damage_count", "unseen_context_accuracy")} for mode in control_modes}}
    signal = summary["primary"]["post_first_acquisition_accuracy"] == 1 and summary["primary"]["post_first_reversal_accuracy"] == 1 and summary["primary"]["unseen_context_accuracy"] == 1 and summary["primary"]["damage_count"] == 2 and all(r["scaffold_unchanged"] and r["recovery_rate"] == 1 for r in primary)
    result = {"schema": "dee.v27.core09.c9d02.v1", "module_id": "C9D02_ADAPTIVE_SURVIVAL_DISCOVERY", "status": "COMPLETE", "role": "DISCOVERY_EVIDENCE_ONLY", "question": "Can a persistent DEE policy lineage use action-contingent valence to reduce future damage, reverse, generalize across nuisance contexts and coexist with fixed regeneration?", "apparatus": {"policy": "A/B carrier direction persists through a toroidal recurrence", "decision": "policy + sensor collision creates one of two action directions", "environment": "fixed Python rule reads only action port; wrong action causes center deletion plus action-trace penalty", "update": "penalty and fixed normalizer transform the returning action trace into the alternative policy", "body": "CORE08 eight-corner semantic-4 regenerative scaffold", "teacher_identity_sent": False}, "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started, "summary": summary, "promotion_signal": signal, "primary": primary, "controls": controls, "epistemic_scope": "The host implements a frozen environment and consequence timing. Policy choice and persistent update are F_DEE carrier/reducer dynamics; this is not consciousness or a general agent."}
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS/C9D02_adaptive_survival_discovery.json", result)
    retrospective = {"schema": "dee.v27.core09.retrospective_adaptation.v1", "status": "DISCOVERY_AUDIT_COMPLETE", "findings": [{"source": "CORE06", "finding": "ordinary-experience reversal and class transfer prove plastic response but not a closed consequence loop", "A6": False}, {"source": "CORE07", "finding": "one-pass internal feedback establishes A3-like chain but consumes memory/action carriers", "A6": False}, {"source": "CORE08", "finding": "fixed scaffold repeats repair and bounded A7 resource support but has no experience-dependent policy", "A6": False}], "retrospective_A6_promotion": False, "new_mechanism_hypothesis": "returning action trace + contingent valence + normalizer forms a two-state plastic policy carrier"}
    atomic_json(ROOT / "RESULTS/C9A02_retrospective_adaptation_audit.json", retrospective)
    append_log({"event": "DISCOVERY_COMPLETE", "module_id": result["module_id"], "promotion_signal": signal, "summary": summary})
    update_state(last_completed_experiment=result["module_id"], provisional=["C9D02 returning-action policy signal"] if signal else [], next_action="Freeze and run an independent A6 holdout with new sizes, frames, seeds and all causal controls." if signal else "Close A6 after diagnosing the missing causal link.")
    print(json.dumps({"promotion_signal": signal, "summary": summary}, indent=2))
    return 0


if __name__ == "__main__": raise SystemExit(main())
