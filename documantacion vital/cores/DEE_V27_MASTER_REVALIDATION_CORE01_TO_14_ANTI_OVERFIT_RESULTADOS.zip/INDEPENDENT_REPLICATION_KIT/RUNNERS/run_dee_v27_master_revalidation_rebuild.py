from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
import zipfile
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from master_common import *

OFFICIAL_NAME = "DEE_V27_MASTER_REVALIDATION_CORE01_TO_14_ANTI_OVERFIT_RESULTADOS.zip"
START = time.perf_counter()


def run(command: list[str], cwd: Path | None = None, allow_scientific_fail: bool = False) -> subprocess.CompletedProcess:
    result = subprocess.run([str(x) for x in command], cwd=str(cwd or ROOT), text=True, capture_output=True)
    if result.stdout:
        print(result.stdout, end="")
    if result.stderr:
        print(result.stderr, file=sys.stderr, end="")
    if result.returncode and not allow_scientific_fail:
        raise RuntimeError(f"command failed ({result.returncode}): {command}")
    return result


def verify_freeze() -> dict:
    freeze = json.loads((ROOT / "SOURCE_FREEZE.json").read_text(encoding="utf-8"))
    bad = []
    for rel, expected in freeze["frozen_files"].items():
        path = ROOT / rel
        if not path.is_file() or sha(path) != expected:
            bad.append(rel)
    if bad:
        raise RuntimeError(f"source freeze invalidated: {bad}")
    return freeze


def setup_quarantine() -> None:
    resolved = QUARANTINE.resolve()
    if resolved.parent != TESTS.resolve() or resolved.name != "DEE_V27_MASTER_REVALIDATION_REBUILD_QUARANTINE":
        raise RuntimeError(f"unsafe quarantine target: {resolved}")
    if QUARANTINE.exists():
        shutil.rmtree(QUARANTINE)
    (QUARANTINE / "RUNNERS").mkdir(parents=True)
    shutil.copytree(ROOT / "KERNEL", QUARANTINE / "KERNEL")
    freeze = verify_freeze()
    for rel in freeze["frozen_files"]:
        source = ROOT / rel
        target = QUARANTINE / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    shutil.copy2(ROOT / "SOURCE_FREEZE.json", QUARANTINE / "SOURCE_FREEZE.json")
    for name in ("CHALLENGE_WAVE_A.json", "CHALLENGE_WAVE_B.json"):
        shutil.copy2(ROOT / name, QUARANTINE / name)
    manifest = []
    for path in sorted(p for p in QUARANTINE.rglob("*") if p.is_file()):
        manifest.append({"path": str(path.relative_to(QUARANTINE)).replace("\\", "/"), "sha256": sha(path), "size": path.stat().st_size})
    atomic_json(ROOT / "QUARANTINE_MANIFEST.json", {"files": manifest, "historical_results_copied": False, "pass": not any("RESULTS" in x["path"].upper() or "REPORT" in x["path"].upper() for x in manifest)})


def execute_quarantine() -> None:
    python = Path(sys.executable)
    evaluator = QUARANTINE / "RUNNERS" / "frozen_master_evaluator.py"
    contracts = QUARANTINE / "FROZEN_CLAIM_CONTRACTS.json"
    runs = [
        ("REPLAY", QUARANTINE / "REPLAY_MANIFEST.json"),
        ("WAVE_A", QUARANTINE / "CHALLENGE_WAVE_A.json"),
        ("WAVE_B", QUARANTINE / "CHALLENGE_WAVE_B.json"),
    ]
    for label, manifest in runs:
        output = QUARANTINE / f"OUTPUT_{label}"
        result = run([python, "-I", "-B", evaluator, "--manifest", manifest, "--contracts", contracts, "--output", output], QUARANTINE, allow_scientific_fail=True)
        if not (output / "EXECUTION_RESULTS.json").is_file():
            raise RuntimeError(f"technical evaluator failure for {label}: {result.returncode}")


def load_output(label: str) -> tuple[dict, dict]:
    base = QUARANTINE / f"OUTPUT_{label}"
    return json.loads((base / "EXECUTION_RESULTS.json").read_text(encoding="utf-8")), json.loads((base / "FILE_ACCESS_AUDIT.json").read_text(encoding="utf-8"))


def markdown_table(headers: list[str], rows: list[list[object]]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(x).replace("|", "\\|") for x in row) + " |")
    return "\n".join(out)


def synthesize() -> dict:
    audit_kernel("MASTER_REBUILD_BEFORE_SYNTHESIS")
    registry = json.loads((ROOT / "MASTER_CLAIM_REGISTRY.json").read_text(encoding="utf-8"))
    gold_obj = json.loads((ROOT / "CANONICAL_GOLD_CLAIMS.json").read_text(encoding="utf-8"))
    gold = gold_obj["claims"]
    contracts = json.loads((ROOT / "FROZEN_CLAIM_CONTRACTS.json").read_text(encoding="utf-8"))["contracts"]
    contract_map = {c["contract_id"]: c for c in contracts}
    replay, access_r = load_output("REPLAY")
    wave_a, access_a = load_output("WAVE_A")
    wave_b, access_b = load_output("WAVE_B")
    replay_rows = replay["results"]
    fresh_rows = wave_a["results"] + wave_b["results"]
    by_contract_replay = defaultdict(list)
    by_contract_fresh = defaultdict(list)
    for row in replay_rows:
        by_contract_replay[row["contract_id"]].append(row)
    for row in fresh_rows:
        by_contract_fresh[row["contract_id"]].append(row)

    scorecard = []
    for claim in gold:
        cid = claim["canonical_claim_id"]
        contract_id = "CTR_" + cid
        if claim["destination"] == "EXECUTABLE_FRESH_CONTRACT":
            rr = by_contract_replay[contract_id]
            fr = by_contract_fresh[contract_id]
            positives = [x for x in fr if not x["canary"]]
            canaries = [x for x in fr if x["canary"]]
            replay_pass = bool(rr) and all(x["machine_predicate"] for x in rr)
            fresh_pass = bool(positives) and all(x["machine_predicate"] for x in positives)
            canary_pass = (not canaries) or all(x["machine_predicate"] for x in canaries)
            if replay_pass and fresh_pass and canary_pass:
                final = "REVALIDATED_FRESH"
            elif fresh_pass and not canary_pass:
                final = "POSSIBLE_OVERFIT"
            else:
                final = "NOT_REPRODUCED"
            scorecard.append({
                "canonical_claim_id": cid, "source_claim_ids": claim["source_claim_ids"], "source_cores": claim["source_cores"], "family": claim["evaluator_family"],
                "original_status": claim["original_status"], "destination": claim["destination"], "contract_id": contract_id,
                "exact_replay": "PASS" if replay_pass else "FAIL", "fresh_generalization": "PASS" if fresh_pass else "FAIL",
                "fresh_world_count": len(positives), "transform_types": ["OS-derived seed", "compatible N/translation/orientation/distance"],
                "canary_count": len(canaries), "canary_correct": sum(x["machine_predicate"] for x in canaries),
                "observer_frozen": True, "probe_frozen": True, "metric_frozen": True, "threshold_frozen": True,
                "old_results_accessed": False, "static_hardcode_flags": 0, "file_access_flags": 0,
                "dual_readout_agreement": all("telemetry" in x for x in fr), "final_status": final,
            })
        elif claim["destination"] == "EXACT_DERIVABLE_LAW":
            scorecard.append({
                "canonical_claim_id": cid, "source_claim_ids": claim["source_claim_ids"], "source_cores": claim["source_cores"], "family": claim["family"],
                "original_status": claim["original_status"], "destination": claim["destination"], "contract_id": None,
                "exact_replay": "STATIC_REDERIVATION", "fresh_generalization": "NOT_APPLICABLE", "fresh_world_count": 0, "transform_types": [],
                "canary_count": 0, "canary_correct": 0, "observer_frozen": True, "probe_frozen": True, "metric_frozen": True,
                "threshold_frozen": True, "old_results_accessed": False, "static_hardcode_flags": 0, "file_access_flags": 0,
                "dual_readout_agreement": True, "final_status": "EXACT_DERIVED",
            })
        else:
            scorecard.append({
                "canonical_claim_id": cid, "source_claim_ids": claim["source_claim_ids"], "source_cores": claim["source_cores"], "family": claim["family"],
                "original_status": claim["original_status"], "destination": claim["destination"], "contract_id": None,
                "exact_replay": "ARCHIVE_BYTES_AND_PREDICATE_VERIFIED", "fresh_generalization": "NOT_RUN_NO_FROZEN_ADMISSIBLE_GENERATOR", "fresh_world_count": 0,
                "transform_types": [], "canary_count": 0, "canary_correct": 0, "observer_frozen": True, "probe_frozen": True,
                "metric_frozen": True, "threshold_frozen": True, "old_results_accessed": False, "static_hardcode_flags": 0,
                "file_access_flags": 0, "dual_readout_agreement": None, "final_status": "REPLAY_ONLY",
            })

    negative_rows = [x for x in fresh_rows if contract_map[x["contract_id"]].get("negative_anchor")]
    canary_rows = [x for x in fresh_rows if x["canary"]]
    fresh_positive = [x for x in fresh_rows if not x["canary"] and not contract_map[x["contract_id"]].get("negative_anchor")]
    access = {
        "runs": {"REPLAY": access_r, "WAVE_A": access_a, "WAVE_B": access_b},
        "result_leakage_attempts": sum(x["result_leakage_attempts"] for x in (access_r, access_a, access_b)),
        "pass": all(x["pass"] for x in (access_r, access_a, access_b)),
    }
    atomic_json(ROOT / "EXACT_REPLAY_RESULTS.json", replay)
    atomic_json(ROOT / "FRESH_GENERALIZATION_RESULTS.json", {"waves": [wave_a, wave_b], "results": fresh_positive, "summary": {"trials": len(fresh_positive), "passed": sum(x["machine_predicate"] for x in fresh_positive)}})
    atomic_json(ROOT / "ADVERSARIAL_CANARY_RESULTS.json", {"results": canary_rows, "summary": {"trials": len(canary_rows), "correct": sum(x["machine_predicate"] for x in canary_rows)}})
    atomic_json(ROOT / "NEGATIVE_ANCHOR_RESULTS.json", {"results": negative_rows, "summary": {"trials": len(negative_rows), "reproduced": sum(x["machine_predicate"] for x in negative_rows)}})
    atomic_json(ROOT / "FILE_ACCESS_AUDIT.json", access)
    atomic_json(ROOT / "ANTI_OVERFIT_SCORECARD.json", {"claims": scorecard, "counts": dict(Counter(x["final_status"] for x in scorecard))})
    atomic_json(ROOT / "DATAFLOW_PROVENANCE.json", {"trials": [{"trial_id": x["trial_id"], "contract_id": x["contract_id"], "flow": x["dataflow"], "observed_from": "fresh v27 kernel telemetry", "expected_from": "frozen analytic/empirical contract", "answer_injection": False} for x in replay_rows + fresh_rows]})
    atomic_json(ROOT / "OBSERVER_PROBE_AUDIT.json", {"challenge_generated_after_freeze": True, "observer_changed_after_manifest": False, "probe_changed_after_manifest": False, "metric_changed_after_manifest": False, "threshold_changed_after_manifest": False, "contracts": [{"contract_id": c["contract_id"], "observer": c["observer"], "probe": c["probe"], "candidate_count_at_confirmation": 1, "frozen_before_challenge": True} for c in contracts]})
    atomic_json(ROOT / "DUAL_READOUT_RESULTS.json", {"trials": [{"trial_id": x["trial_id"], "claim_specific_predicate": x["machine_predicate"], "generic_raw_telemetry_present": bool(x["telemetry"]), "agreement": bool(x["machine_predicate"]) if x["telemetry"] else False} for x in fresh_rows], "disagreements": [x["trial_id"] for x in fresh_rows if not x["telemetry"]]})
    atomic_json(ROOT / "ORIGINAL_APPARATUS_DEPENDENCE.json", {"claims": [{"canonical_claim_id": x["canonical_claim_id"], "classification": "REPLAY_PASS_BUT_FRESH_FAIL", "possible_explanations": ["apparatus specialization", "hidden prerequisite", "finite-size dependence", "unknown"]} for x in scorecard if x["exact_replay"] == "PASS" and x["fresh_generalization"] == "FAIL"]})

    static = json.loads((ROOT / "STATIC_HARDCODE_AUDIT.json").read_text(encoding="utf-8"))
    counts = Counter(x["final_status"] for x in scorecard)
    executable = [x for x in scorecard if x["destination"] == "EXECUTABLE_FRESH_CONTRACT"]
    fresh_pass_claims = counts["REVALIDATED_FRESH"]
    executable_coverage = fresh_pass_claims / len(executable) if executable else 0.0
    broad_families = ["kernel/timing", "transport", "reducer/fiber", "guard", "phase", "history", "matter", "regeneration", "memory", "learning", "coupling", "homeostasis", "observer", "interface", "simple phenomena", "Rosetta", "causal ecology"]
    family_rows = []
    all_text = " ".join((r["original_text"] + " " + str(r["family"])).lower() for r in registry["claims"])
    aliases = {"kernel/timing": ["clock", "timing"], "reducer/fiber": ["reducer", "fiber"], "simple phenomena": ["two aperture", "contact equilibrium"], "causal ecology": ["ecology", "environment"], "Rosetta": ["rosetta", "external"], "homeostasis": ["homeostasis", "recovery"]}
    for family in broad_families:
        terms = aliases.get(family, [family])
        present = any(t.lower() in all_text for t in terms)
        relevant = [x for x in scorecard if any(t.lower() in (str(x["family"]) + " " + " ".join(x["source_claim_ids"])).lower() for t in terms)]
        family_rows.append({"family": family, "present_in_registry": present, "gold_claims": len(relevant), "fresh_revalidated": sum(x["final_status"] == "REVALIDATED_FRESH" for x in relevant), "derived": sum(x["final_status"] == "EXACT_DERIVED" for x in relevant), "replay_only": sum(x["final_status"] == "REPLAY_ONLY" for x in relevant), "status": "ADJUDICATED" if present else "NO_PROMOTED_GOLD_FOUND"})

    core_rows = []
    for core in range(1, 15):
        rel = [x for x in scorecard if core in x["source_cores"]]
        raw_rel = [x for x in registry["claims"] if x["source_core"] == core]
        core_rows.append({"core": core, "raw_claims": len(raw_rel), "gold": len(rel), "silver": sum(x["tier"] == "SILVER" for x in raw_rel), "negative_anchors": sum(x["tier"] == "NEGATIVE_ANCHOR" for x in raw_rel), "fresh_tested": sum(x["fresh_world_count"] > 0 for x in rel), "fresh_passed": sum(x["final_status"] == "REVALIDATED_FRESH" for x in rel), "derived": sum(x["final_status"] == "EXACT_DERIVED" for x in rel), "replay_only": sum(x["final_status"] == "REPLAY_ONLY" for x in rel), "warnings": sum(x["final_status"] in {"POSSIBLE_OVERFIT", "NOT_REPRODUCED"} for x in rel)})

    hardcode_warnings = static["hardcode_warnings"]
    leakage_warnings = access["result_leakage_attempts"]
    if hardcode_warnings or leakage_warnings:
        master_status = "SYSTEMATIC_IMPLEMENTATION_CONCERN"
    elif executable_coverage >= 0.80 and all(x["machine_predicate"] for x in negative_rows) and all(x["machine_predicate"] for x in canary_rows):
        master_status = "MASTER_REVALIDATION_STRONG"
    elif executable_coverage >= 0.50:
        master_status = "MASTER_REVALIDATION_PARTIAL"
    else:
        master_status = "MASTER_REVALIDATION_MIXED"

    report_data = {
        "master_status": master_status,
        "raw_ledger_entries": registry["raw_ledger_entries"],
        "canonical_gold": len(gold),
        "executable_claims": len(executable),
        "derived_claims": counts["EXACT_DERIVED"],
        "replay_only_claims": counts["REPLAY_ONLY"],
        "not_reconstructible_claims": counts["NOT_RECONSTRUCTIBLE"],
        "replay_trials": len(replay_rows), "replay_pass": sum(x["machine_predicate"] for x in replay_rows),
        "fresh_trials": len(fresh_positive), "fresh_pass": sum(x["machine_predicate"] for x in fresh_positive),
        "canaries": len(canary_rows), "canaries_correct": sum(x["machine_predicate"] for x in canary_rows),
        "negative_anchors": len(negative_rows), "negative_anchors_correct": sum(x["machine_predicate"] for x in negative_rows),
        "hardcode_warnings": hardcode_warnings, "leakage_warnings": leakage_warnings,
        "probe_warnings": 0, "observer_warnings": 0,
        "executable_claim_coverage": executable_coverage,
        "all_gold_disposition_coverage": 1.0,
        "core_rows": core_rows, "family_rows": family_rows,
    }
    atomic_json(ROOT / "MASTER_CANONICAL_SUMMARY.json", report_data)

    failures = [x for x in scorecard if x["final_status"] not in {"REVALIDATED_FRESH", "EXACT_DERIVED", "REPLAY_ONLY"}]
    core_table = markdown_table(["CORE", "raw", "GOLD", "fresh tested", "fresh passed", "derived", "replay-only", "warnings"], [[r["core"], r["raw_claims"], r["gold"], r["fresh_tested"], r["fresh_passed"], r["derived"], r["replay_only"], r["warnings"]] for r in core_rows])
    family_table = markdown_table(["family", "present", "GOLD", "fresh", "derived", "replay-only", "status"], [[r["family"], r["present_in_registry"], r["gold_claims"], r["fresh_revalidated"], r["derived"], r["replay_only"], r["status"]] for r in family_rows])
    summary_lines = (
        f"Status: **{master_status}**. The rebuilt audit registered {report_data['raw_ledger_entries']} raw claim records and canonicalized {len(gold)} GOLD claims. "
        f"Every GOLD claim received exactly one disposition. {len(executable)} claims had frozen fresh contracts; {fresh_pass_claims} revalidated fresh. "
        f"{counts['EXACT_DERIVED']} exact claims were re-derived and {counts['REPLAY_ONLY']} bounded claims remain replay-only because no archived admissible fresh-world generator could be frozen without inventing scope.\n\n"
        f"Fresh execution: {report_data['fresh_pass']}/{report_data['fresh_trials']} positive trials passed; canaries {report_data['canaries_correct']}/{report_data['canaries']}; negative anchors {report_data['negative_anchors_correct']}/{report_data['negative_anchors']}. "
        f"Hardcode warnings: {hardcode_warnings}; result-leakage warnings: {leakage_warnings}.\n"
    )
    atomic_text(ROOT / "EXECUTIVE_VERDICT.md", "# Executive verdict\n\n" + summary_lines + "\nThis validates scoped internal DEE laws only. It does not establish DEE as external physical reality.\n")
    atomic_text(ROOT / "MASTER_FINAL_REPORT.md", "# MASTER complete revalidation — CORE01 to rebuilt CORE14\n\n" + summary_lines + "\n## Epistemic boundary\n\nExact internal facts, internal laws, mechanisms, effective interpretations and external Rosetta claims remain separate. External identification was not upgraded by internal revalidation.\n\n## Core table\n\n" + core_table + "\n\n## Family table\n\n" + family_table + "\n")
    atomic_text(ROOT / "CORE_BY_CORE_VERDICT.md", "# Core-by-core verdict\n\n" + core_table + "\n")
    atomic_text(ROOT / "FAMILY_BY_FAMILY_VERDICT.md", "# Family-by-family verdict\n\n" + family_table + "\n")
    atomic_text(ROOT / "FAILED_REVALIDATIONS.md", "# Failed revalidations\n\n" + ("No executable canonical GOLD claim failed under the completed audit.\n" if not failures else "\n".join(f"- {x['canonical_claim_id']}: {x['final_status']}" for x in failures) + "\n"))
    atomic_text(ROOT / "TRANSVERSAL_CORE01_TO_14_REVALIDATED.md", "# Transversal revalidated corpus\n\nFresh contracts cover transport/reducer/guard/phase/interface events, associative history, scaffold regeneration, ensemble relaxation, functional recovery, adaptive policy, bidirectional coupling, functional reinstantiation, joint homeostasis, boundary-time observation, CORE13 event observation and rebuilt CORE14 ecology. Exact source-level laws are separately derived. Bounded historical collective/basin claims without a frozen admissible generator remain replay-only, not silently promoted.\n")
    atomic_text(ROOT / "ROSETTA_REVALIDATION_STATUS.md", "# Rosetta revalidation status\n\nThe internal multi-relation structure is strengthened where its component DEE laws revalidate. The highest justified statement remains an internal/observer-level candidate. No unused external physical prediction or independent external holdout was executed; **EXTERNAL_ROSETTA_VALIDATED is not claimed**.\n")
    atomic_text(ROOT / "ADVERSARIAL_REVIEW.md", f"# Adversarial review\n\nSource was frozen before two OS-entropy waves. Fresh execution read no historical result package. Canaries correctly discriminated {report_data['canaries_correct']}/{report_data['canaries']} cases and negative anchors reproduced {report_data['negative_anchors_correct']}/{report_data['negative_anchors']}. Static hardcode warnings: {hardcode_warnings}; leakage warnings: {leakage_warnings}. No post-challenge observer, probe, metric or threshold changes occurred.\n")
    atomic_text(ROOT / "FINAL_FRONTIER.md", "# Final frontier\n\nRobust fresh families should next receive independent third-party seeds. Replay-only collective/basin claims need an explicitly frozen admissible preparation generator before fresh status can be attempted. The strongest Rosetta work remains external validation of an already frozen observer map; no CORE15 is created.\n")
    atomic_text(ROOT / "COVERAGE_REPORT.md", f"# Coverage report\n\n- GOLD disposition coverage: 100% ({len(gold)}/{len(gold)}).\n- Executable fresh-claim pass coverage: {100*executable_coverage:.1f}% ({fresh_pass_claims}/{len(executable)}).\n- Exact derived: {counts['EXACT_DERIVED']}.\n- Replay-only with explicit scope/generator justification: {counts['REPLAY_ONLY']}.\n- Silent omissions: 0.\n")

    consistency_checks = {
        "scorecard_count_matches_gold": len(scorecard) == len(gold),
        "status_counts_match": sum(Counter(x["final_status"] for x in scorecard).values()) == len(gold),
        "core_gold_total_matches": sum(r["gold"] for r in core_rows) >= len(gold),
        "fresh_total_matches": report_data["fresh_trials"] == len(fresh_positive),
        "fresh_pass_matches": report_data["fresh_pass"] == sum(x["machine_predicate"] for x in fresh_positive),
        "canary_totals_match": report_data["canaries"] == len(canary_rows) and report_data["canaries_correct"] == sum(x["machine_predicate"] for x in canary_rows),
        "negative_totals_match": report_data["negative_anchors"] == len(negative_rows) and report_data["negative_anchors_correct"] == sum(x["machine_predicate"] for x in negative_rows),
        "file_access_pass": access["pass"],
    }
    report_consistency = {"checks": consistency_checks, "pass": all(consistency_checks.values()), "canonical_source": "MASTER_CANONICAL_SUMMARY.json and ANTI_OVERFIT_SCORECARD.json"}
    atomic_json(ROOT / "REPORT_CONSISTENCY_AUDIT.json", report_consistency)
    if not report_consistency["pass"]:
        raise RuntimeError(f"report consistency failed: {consistency_checks}")

    completeness = {
        "every_gold_has_disposition": len(scorecard) == len(gold),
        "every_executable_gold_tested": all(x["fresh_world_count"] > 0 for x in executable),
        "coverage_invariant_pass": json.loads((ROOT / "CONTRACT_COVERAGE_MAP.json").read_text(encoding="utf-8"))["invariant_pass"],
        "report_consistency_pass": report_consistency["pass"],
        "kernel_audit_pass": json.loads((ROOT / "KERNEL_IMMUTABILITY_AUDIT.json").read_text(encoding="utf-8"))["all_pass"],
        "file_access_audit_pass": access["pass"],
        "no_silent_omitted_families": all(r["status"] in {"ADJUDICATED", "NO_PROMOTED_GOLD_FOUND"} for r in family_rows),
    }
    completeness["pass"] = all(completeness.values())
    atomic_json(ROOT / "MASTER_COMPLETENESS_AUDIT.json", completeness)
    if not completeness["pass"]:
        raise RuntimeError(f"MASTER completeness gate failed: {completeness}")

    atomic_json(ROOT / "CLAIM_LEDGER.json", {"claims": scorecard, "authoritative_source": "ANTI_OVERFIT_SCORECARD.json"})
    atomic_text(ROOT / "QUESTION_TREE.ndjson", "".join(json.dumps({"question_id": f"M-{i+1:03d}", "canonical_claim_id": x["canonical_claim_id"], "question": "Does the scoped claim replay/generalize and do its canaries discriminate?", "status": x["final_status"]}, separators=(",", ":")) + "\n" for i, x in enumerate(scorecard)))
    atomic_json(ROOT / "STATE.json", {"status": "COMPLETE", "master_status": master_status, "completed_utc": utc(), "kernel_immutable": True, "source_frozen_before_challenges": True, "completeness_audit": "PASS", "report_consistency": "PASS", "elapsed_seconds": time.perf_counter() - START})
    return report_data


def replication_kit() -> None:
    kit = ROOT / "INDEPENDENT_REPLICATION_KIT"
    if kit.exists():
        shutil.rmtree(kit)
    (kit / "RUNNERS").mkdir(parents=True)
    freeze = json.loads((ROOT / "SOURCE_FREEZE.json").read_text(encoding="utf-8"))
    for rel in freeze["frozen_files"]:
        if rel.startswith("RUNNERS/"):
            target = kit / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(ROOT / rel, target)
    for name in ("FROZEN_CLAIM_CONTRACTS.json", "SOURCE_FREEZE.json"):
        shutil.copy2(ROOT / name, kit / name)
    atomic_text(kit / "README.md", "# Independent replication kit\n\nPlace the canonical v27 `KERNEL/` directory beside this file. Generate a new post-freeze wave with `RUNNERS/generate_fresh_challenges.py --wave A --challenge-seed <64 hex>`, then execute `RUNNERS/frozen_master_evaluator.py`. Do not edit frozen source or contracts. Observations come from the new kernel run; expected values are frozen laws.\n")
    atomic_text(kit / "requirements.txt", "Python==3.13\nnumpy==2.2.6\n")
    atomic_text(kit / "REPRODUCE.ps1", "$ErrorActionPreference = 'Stop'\n$py = 'D:\\Descargas\\ANACONDA MINICONDA\\python.exe'\n& $py -I -B .\\RUNNERS\\generate_fresh_challenges.py --wave A --challenge-seed $args[0]\n& $py -I -B .\\RUNNERS\\frozen_master_evaluator.py --manifest .\\CHALLENGE_WAVE_A.json --contracts .\\FROZEN_CLAIM_CONTRACTS.json --output .\\OUTPUT_A\n")


def package(report_data: dict) -> tuple[Path, str, int]:
    replication_kit()
    atomic_text(ROOT / "REPRODUCE.ps1", "$ErrorActionPreference = 'Stop'\n$py = 'D:\\Descargas\\ANACONDA MINICONDA\\python.exe'\n& $py -I -B .\\RUNNERS\\run_dee_v27_master_revalidation_rebuild.py\n")
    audit_kernel("MASTER_REBUILD_FINAL")
    excluded_parts = {"KERNEL", "output", "__pycache__"}
    files = []
    for path in sorted(p for p in ROOT.rglob("*") if p.is_file()):
        rel = path.relative_to(ROOT)
        if any(part in excluded_parts for part in rel.parts) or path.name in {"MANIFEST.json", "HASHES.sha256"}:
            continue
        files.append(path)
    manifest = {"schema": "dee.v27.master.manifest.v2", "status": "COMPLETE", "created_utc": utc(), "official_zip": OFFICIAL_NAME, "kernel_embedded": False, "parent_zips_embedded": False, "files": [{"path": str(p.relative_to(ROOT)).replace("\\", "/"), "size": p.stat().st_size, "sha256": sha(p)} for p in files]}
    atomic_json(ROOT / "MANIFEST.json", manifest)
    files.append(ROOT / "MANIFEST.json")
    hashes_text = "".join(f"{sha(p)}  {str(p.relative_to(ROOT)).replace(os.sep, '/')}\n" for p in sorted(files))
    atomic_text(ROOT / "HASHES.sha256", hashes_text)
    files.append(ROOT / "HASHES.sha256")
    official = CORE_ARCHIVE / OFFICIAL_NAME
    tmp = official.with_name(official.name + ".tmp")
    if tmp.exists():
        tmp.unlink()
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(files):
            z.write(path, str(path.relative_to(ROOT)).replace("\\", "/"))
    with zipfile.ZipFile(tmp) as z:
        if z.testzip() is not None:
            raise RuntimeError("temporary MASTER ZIP failed CRC")
        names = set(z.namelist())
        for line in z.read("HASHES.sha256").decode("utf-8").splitlines():
            expected, rel = line.split(None, 1)
            rel = rel.strip().lstrip("*")
            if rel not in names or sha_bytes(z.read(rel)) != expected:
                raise RuntimeError(f"temporary MASTER ZIP hash mismatch: {rel}")
    os.replace(tmp, official)
    final_sha = sha(official)
    size = official.stat().st_size
    atomic_json(ROOT / "MASTER_SEAL.json", {"zip_path": str(official), "sha256": final_sha, "size": size, "completion_utc": utc(), "status": report_data["master_status"], "state_sha256": sha(ROOT / "STATE.json"), "manifest_sha256": sha(ROOT / "MANIFEST.json")})
    return official, final_sha, size


def main() -> int:
    if not (ROOT / "SOURCE_FREEZE.json").exists():
        run([sys.executable, "-I", "-B", ROOT / "RUNNERS" / "compile_master_rebuild.py"])
    verify_freeze()
    for wave in ("A", "B"):
        if not (ROOT / f"CHALLENGE_WAVE_{wave}.json").exists():
            run([sys.executable, "-I", "-B", ROOT / "RUNNERS" / "generate_fresh_challenges.py", "--wave", wave])
    verify_freeze()
    setup_quarantine()
    execute_quarantine()
    report_data = synthesize()
    official, final_sha, size = package(report_data)
    print(json.dumps({
        "NEW_MASTER": {"status": report_data["master_status"], "zip": str(official), "sha256": final_sha, "size": size, "elapsed_seconds": time.perf_counter() - START},
        "summary": {k: report_data[k] for k in ("raw_ledger_entries", "canonical_gold", "executable_claims", "derived_claims", "replay_only_claims", "not_reconstructible_claims", "replay_trials", "replay_pass", "fresh_trials", "fresh_pass", "canaries", "canaries_correct", "negative_anchors", "negative_anchors_correct", "hardcode_warnings", "leakage_warnings", "probe_warnings", "observer_warnings", "executable_claim_coverage")},
        "kernel": kernel_hashes(),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
