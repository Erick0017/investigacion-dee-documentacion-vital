$ErrorActionPreference = 'Stop'
$py = 'D:\Descargas\ANACONDA MINICONDA\python.exe'
& $py -I -B .\RUNNERS\run_dee_v27_master_revalidation_rebuild.py
