#!/usr/bin/env python3
"""Frozen confirmation of the task-relative guarded destination observer."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import NativeWorld, ROOT, atomic_json, append_log, canonical_hash, pack, unpack_scalar, update_state, verify_and_load_kernel

LOCK = ROOT / "HOLDOUT_LOCKS" / "C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER.json"
EXPECTED_LOCK_SHA256 = "c76c2c419ad4ef2e46a7080a937fcbcc8864875ec6d52c27b241774560424ba4"
OFFSETS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]
HALF = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, -1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (0, 1, -1), (1, 1, 1), (1, 1, -1), (1, -1, 1), (1, -1, -1)]


def guard(directions):
    occupied = set(directions)
    return len(occupied) >= 8 and all((d in occupied) == (tuple(-x for x in d) in occupied) for d in HALF)


def sign(x):
    return int(x > 0) - int(x < 0)


def expected(directions, sregs):
    if guard(directions):
        return {"state": 1, "s_reg": 1, "direction": [0, 0, 0], "semantic": 7}
    return {"state": 1, "s_reg": min(sum(sregs), 19664), "direction": [sign(sum(d[i] for d in directions)) for i in range(3)], "semantic": 1}


def unguarded(directions, sregs):
    return {"state": 1, "s_reg": min(sum(sregs), 19664), "direction": [sign(sum(d[i] for d in directions)) for i in range(3)], "semantic": 1}


def projection(value):
    return {key: value[key] for key in ("state", "s_reg", "direction", "semantic")} if value else None


def trial(kernel, directions, sregs, states, n, target, clock_offset):
    raw = np.zeros((n, n, n), dtype=np.uint64)
    clock = np.zeros_like(raw)
    for d, s, state in zip(directions, sregs, states, strict=True):
        q = tuple((target[i] - d[i]) % n for i in range(3))
        raw[q] = pack(state, s, d, 1)
        clock[q] = np.uint64(clock_offset)
    world = NativeWorld(kernel, raw, clock)
    world.tick()
    observed = projection(unpack_scalar(world.raw[target])) if int(world.raw[target]) else None
    prediction = expected(directions, sregs)
    null_prediction = unguarded(directions, sregs)
    return {
        "n": n,
        "target": list(target),
        "clock_offset": int(clock_offset),
        "k": len(directions),
        "xnor_guard": guard(directions),
        "sum_s": sum(sregs),
        "sum_d": [sum(d[i] for d in directions) for i in range(3)],
        "source_state_digest": hashlib.sha256(np.asarray(states, dtype=np.uint32).tobytes()).hexdigest(),
        "observed": observed,
        "prediction": prediction,
        "guarded_exact": observed == prediction,
        "unguarded_exact": observed == null_prediction,
        "account_exact": len(directions) - 1 >= 0,
    }


def random_non_guard(rng, k):
    while True:
        directions = [OFFSETS[int(i)] for i in rng.choice(len(OFFSETS), size=k, replace=False)]
        if not guard(directions):
            return directions


def run_pair(kernel, left, right):
    rows = []
    for directions, sregs in (left, right):
        rows.append(trial(kernel, directions, sregs, list(range(700, 700 + len(directions))), 23, (11, 9, 13), 77))
    return {"rows": rows, "future_differs": rows[0]["observed"] != rows[1]["observed"]}


def main() -> int:
    started = time.perf_counter()
    lock_sha = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if lock_sha != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"holdout lock changed: {lock_sha}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    rows = []
    seed_cycle = itertools.cycle(lock["parameters"]["seeds"])
    for family, count in lock["domain"]["trial_families"].items():
        for index in range(count):
            rng = np.random.default_rng(next(seed_cycle) + index * 1009 + {"generic": 0, "xnor_symmetric": 1000000, "saturation": 2000000}[family])
            n = lock["domain"]["N"][index % len(lock["domain"]["N"])]
            target = tuple(int(rng.integers(0, n)) for _ in range(3))
            clock_offset = lock["domain"]["clock_offsets"][index % len(lock["domain"]["clock_offsets"])]
            if family == "generic":
                k = int(rng.integers(1, 26))
                directions = random_non_guard(rng, k)
                sregs = [int(rng.integers(1, 400)) for _ in directions]
            elif family == "xnor_symmetric":
                pairs = int(rng.integers(4, 14))
                chosen = [HALF[int(i)] for i in rng.choice(len(HALF), size=pairs, replace=False)]
                directions = [d for d in chosen for d in (d, tuple(-x for x in d))]
                sregs = [int(rng.integers(1, 1000)) for _ in directions]
            else:
                k = int(rng.integers(2, 26))
                directions = random_non_guard(rng, k)
                sregs = [int(rng.integers(9000, 19665)) for _ in directions]
            states = [int(rng.integers(1, 2**32)) for _ in directions]
            row = trial(kernel, directions, sregs, states, n, target, clock_offset)
            row.update({"family": family, "index": index})
            rows.append(row)

    tetra = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]
    counterexamples = {
        "xnor_guard": run_pair(kernel, (list(itertools.product((-1, 1), repeat=3)), [21] * 8), (tetra + [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0)], [21] * 8)),
        "sum_s": run_pair(kernel, ([(1, 0, 0)], [31]), ([(1, 0, 0)], [47])),
        "sign_x": run_pair(kernel, ([(1, 0, 0)], [37]), ([(-1, 0, 0)], [37])),
        "sign_y": run_pair(kernel, ([(0, 1, 0)], [41]), ([(0, -1, 0)], [41])),
        "sign_z": run_pair(kernel, ([(0, 0, 1)], [43]), ([(0, 0, -1)], [43])),
    }
    rates = {
        "Z_update_exact_rate": sum(r["guarded_exact"] for r in rows) / len(rows),
        "Z_account_exact_rate": sum(r["account_exact"] for r in rows) / len(rows),
        "unguarded_exact_rate": sum(r["unguarded_exact"] for r in rows) / len(rows),
    }
    null_errors = sum(not r["unguarded_exact"] for r in rows)
    conditions = {
        "guarded_all_exact": rates["Z_update_exact_rate"] == 1.0,
        "account_all_exact": rates["Z_account_exact_rate"] == 1.0,
        "unguarded_null_fails": null_errors >= lock["minimum_effect"]["unguarded_error_count_min"],
        "all_coordinates_necessary_within_family": all(row["future_differs"] for row in counterexamples.values()),
    }
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core08.c8h01.v1",
        "module_id": lock["claim_id"],
        "role": "FROZEN_CONFIRMATION",
        "lock_sha256": lock_sha,
        "status": "COMPLETE",
        "verdict": verdict,
        "kernel_environment": environment,
        "sample_sizes": {"holdout_worlds": len(rows), "counterexample_worlds": 2 * len(counterexamples), "kernel_ticks": len(rows) + 2 * len(counterexamples)},
        "wall_clock_seconds": time.perf_counter() - started,
        "rates": rates,
        "unguarded_error_count": null_errors,
        "conditions": conditions,
        "coordinate_deletion_counterexamples": counterexamples,
        "family_summary": {family: {"n": sum(r["family"] == family for r in rows), "exact": sum(r["family"] == family and r["guarded_exact"] for r in rows), "null_errors": sum(r["family"] == family and not r["unguarded_exact"] for r in rows)} for family in lock["domain"]["trial_families"]},
        "trials": rows,
        "adjudication": "HOLDOUT_CONFIRMED_INTERNAL" if verdict == "PASS" else "NEGATIVE_IN_TESTED_APPARATUS",
        "scope": lock["epistemic_scope"],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C8H01_minimal_guarded_destination_observer.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": "C8H01", "verdict": verdict, "lock_sha256": lock_sha, "null_errors": null_errors})
    update_state(
        last_completed_experiment="C8H01_MINIMAL_GUARDED_DESTINATION_OBSERVER",
        complete_modules=["C8A00", "C8D01", "C8D02", "C8H01"],
        proven=["sealed identities", "Z_update guarded observer exact in frozen destination-fiber domain", "Z_account retains local multiplicity contraction"],
        pending_holdout=None,
        next_action="Construct cross-family observer counterexamples and identify hidden phase/topology information.",
    )
    print(json.dumps({"verdict": verdict, "rates": rates, "null_errors": null_errors, "conditions": conditions, "family_summary": result["family_summary"]}, indent=2))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
