#!/usr/bin/env python3
"""Post-failure frozen test of the exact finite-size boundary-code law."""
from __future__ import annotations

import hashlib
import json
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, append_log, canonical_hash, update_state, verify_and_load_kernel
from run_c8h04_boundary_time_code import ORIENTATIONS, run_world

LOCK = ROOT / "HOLDOUT_LOCKS" / "C8H05_FINITE_SIZE_BOUNDARY_CODE_LAW.json"
EXPECTED_LOCK_SHA256 = "1ed2d9b2b5fac5d074f658f74a1014dd159196a56944b134ab9eb70987aa16b2"


def main() -> int:
    started = time.perf_counter()
    lock_sha = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if lock_sha != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock changed: {lock_sha}")
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    rows = []
    for i in range(lock["domain"]["worlds"]):
        n = lock["domain"]["N"][i % len(lock["domain"]["N"])]
        axis, sign = ORIENTATIONS[i % len(ORIENTATIONS)]
        seed = lock["parameters"]["seeds"][i % 2] + i * 2027
        row = run_world(kernel, n, seed, axis, sign)
        row["predicted_ray_count"] = math.ceil((n - 4) / 3) ** 2
        row["ray_count_exact"] = row["rays"] == row["predicted_ray_count"]
        rows.append(row)
    carriers = sum(row["rays"] for row in rows)
    rates = {
        "exact_ray_count_rate": sum(row["ray_count_exact"] for row in rows) / len(rows),
        "reconstruction_rate": sum(row["reconstruction_rate"] * row["rays"] for row in rows) / carriers,
        "trajectory_prediction_rate": sum(row["trajectory_prediction_rate"] for row in rows) / len(rows),
        "time_shuffle_accuracy": sum(row["time_shuffle_accuracy"] * row["rays"] for row in rows) / carriers,
        "location_shuffle_accuracy": sum(row["location_shuffle_accuracy"] * row["rays"] for row in rows) / carriers,
    }
    m = lock["minimum_effect"]
    conditions = {
        "ray_law": rates["exact_ray_count_rate"] >= m["exact_ray_count_rate"],
        "decoder": rates["reconstruction_rate"] >= m["reconstruction_rate"],
        "future": rates["trajectory_prediction_rate"] >= m["trajectory_prediction_rate"],
        "time_control": rates["time_shuffle_accuracy"] <= m["time_shuffle_accuracy_max"],
        "location_control": rates["location_shuffle_accuracy"] <= m["location_shuffle_accuracy_max"],
    }
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core08.c8h05.v1", "module_id": lock["claim_id"], "role": "POST_FAILURE_FROZEN_CONFIRMATION", "status": "COMPLETE", "verdict": verdict,
        "lock_sha256": lock_sha, "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started,
        "sample_sizes": {"worlds": len(rows), "carriers": carriers, "new_N": lock["domain"]["N"]}, "rates": rates, "conditions": conditions, "worlds": rows,
        "predecessor_preserved": lock["predecessor"],
        "adjudication": ["BOUNDARY_HISTORY_SUFFICIENT_IN_RESTRICTED_RAY_DOMAIN", "LOWER_DIMENSIONAL_EFFECTIVE_STATE", "FINITE_SIZE_AREA_INDEX_LAW_CONFIRMED"],
        "asymptotic_statement": "The number of independently prepared rays is exactly ceil((N-4)/3)^2=Theta(N^2). Because each event carries an O(log N) delay, this explicit code is Theta(N^2 log N) bits.",
        "holographic_like_status": "NO_HOLOGRAPHIC_LIKE_SIGNAL for arbitrary bulk: the positive domain itself has only area-indexed degrees and does not compress arbitrary O(N^3) state.",
        "scope": lock["claim_scope"],
    }
    result["content_sha256"] = canonical_hash(result)
    atomic_json(ROOT / "RESULTS" / "C8H05_finite_size_boundary_code_law.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": "C8H05", "verdict": verdict, "lock_sha256": lock_sha, "predecessor_verdict_preserved": "C8H04_FAIL", "rates": rates})
    update_state(last_completed_experiment=lock["claim_id"], complete_modules=["C8A00", "C8D01", "C8D02", "C8H01", "C8D03", "C8D04", "C8H02", "C8H03", "C8D05", "C8H04_FAIL", "C8H05"], pending_holdout=None, next_action="Build neutral fingerprints, convergence ranking and historical recovery/autonomy re-audit.")
    print(json.dumps({"verdict": verdict, "sample_sizes": result["sample_sizes"], "rates": rates, "conditions": conditions}, indent=2))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
