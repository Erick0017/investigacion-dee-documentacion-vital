#!/usr/bin/env python3
"""Leakage-free post-audit confirmation of trained redundant R5 recovery."""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from core08_common import ROOT, atomic_json, append_log, canonical_hash, update_state, verify_and_load_kernel
from run_c8h03_trained_redundancy_recovery import FRAMES, simulate

LOCK = ROOT / "HOLDOUT_LOCKS" / "C8H06_LEAKAGE_FREE_TRAINED_FUNCTION_RECOVERY.json"
EXPECTED_LOCK_SHA256 = "8663332a6c01f4ea6c5393e9f08e0ca7e001db3f812ab133aec7e3234684b695"


def main() -> int:
    started = time.perf_counter(); lock_sha = hashlib.sha256(LOCK.read_bytes()).hexdigest()
    if lock_sha != EXPECTED_LOCK_SHA256:
        raise RuntimeError(f"lock changed: {lock_sha}")
    lock = json.loads(LOCK.read_text(encoding="utf-8")); kernel, environment = verify_and_load_kernel(lock["parameters"]["threads"])
    p = lock["parameters"]; cells = []
    for i in range(lock["domain"]["cells"]):
        n = lock["domain"]["N"][i]; rng = np.random.default_rng(p["seeds"][i])
        target = [int(v) for v in rng.integers(n // 2 - 2, n // 2 + 3, size=3)]
        cells.append({"index": i, "seed": p["seeds"][i], "delta": p["deltas"][i], "queries": p["queries"][i], "n": n, "frame": FRAMES[i], "target": target, "training_x_main": p["training_x_main"][i], "training_x_donor": p["training_x_donor"][i]})
    disjoint = [q not in {cell["training_x_main"], cell["training_x_donor"]} for cell in cells for q in cell["queries"]]
    if not all(disjoint):
        raise RuntimeError("frozen query/training overlap")
    positives = [simulate(kernel, cell, q, "trained_redundancy") for cell in cells for q in cell["queries"]]
    baselines = [simulate(kernel, cell, cell["queries"][0], "no_damage") for cell in cells]
    modes = ["no_donor", "wrong_donor", "label_shuffled_donor", "offpath_donor", "memory_ablation", "actuator_direction_ablation"]
    negatives = [simulate(kernel, cell, cell["queries"][0], mode) for cell in cells for mode in modes]
    rates = {
        "disjoint_rate": sum(disjoint) / len(disjoint),
        "positive_exact_rate": sum(row["exact_unseen_response"] for row in positives) / len(positives),
        "memory_restore_rate": sum(row["memory_restored"] for row in positives) / len(positives),
        "no_damage_exact_rate": sum(row["exact_unseen_response"] for row in baselines) / len(baselines),
        "negative_exact_rate": sum(row["exact_unseen_response"] for row in negatives) / len(negatives),
    }
    m = lock["minimum_effect"]
    conditions = {"disjoint": rates["disjoint_rate"] >= m["disjoint_rate"], "positive": rates["positive_exact_rate"] >= m["positive_exact_rate"], "memory": rates["memory_restore_rate"] >= m["memory_restore_rate"], "baseline": rates["no_damage_exact_rate"] >= m["no_damage_exact_rate"], "controls": rates["negative_exact_rate"] <= m["negative_exact_rate_max"]}
    verdict = "PASS" if all(conditions.values()) else "FAIL"
    result = {
        "schema": "dee.v27.core08.c8h06.v1", "module_id": lock["claim_id"], "role": "POST_AUDIT_FROZEN_CONFIRMATION", "status": "COMPLETE", "verdict": verdict,
        "lock_sha256": lock_sha, "kernel_environment": environment, "wall_clock_seconds": time.perf_counter() - started,
        "sample_sizes": {"cells": len(cells), "disjoint_queries": len(disjoint), "positive_worlds": len(positives), "no_damage_worlds": len(baselines), "negative_worlds": len(negatives)},
        "rates": rates, "conditions": conditions, "cells": cells, "positives": positives, "baselines": baselines, "negatives": negatives,
        "predecessor_preserved": lock["predecessor"], "current_adjudication": "R5_FUNCTIONAL_RECOVERY_CONFIRMED" if verdict == "PASS" else "NEGATIVE_IN_TESTED_APPARATUS",
        "explicit_nonclaims": ["R6 learned damage detection", "R7 repeated learned-memory regeneration", "same-carrier identity", "general self-repair"], "scope": lock["claim_scope"],
    }
    result["content_sha256"] = canonical_hash(result); atomic_json(ROOT / "RESULTS" / "C8H06_leakage_free_trained_function_recovery.json", result)
    append_log({"event": "HOLDOUT_COMPLETE", "module_id": "C8H06", "verdict": verdict, "lock_sha256": lock_sha, "C8H03_preserved": "FAIL_PROTOCOL_LEAKAGE", "rates": rates})
    update_state(last_completed_experiment=lock["claim_id"], pending_holdout=None, next_action="Run final adversarial audit with C8H03 leakage explicitly superseded by C8H06.")
    print(json.dumps({"verdict": verdict, "sample_sizes": result["sample_sizes"], "rates": rates, "conditions": conditions}, indent=2))
    return 0 if verdict == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
