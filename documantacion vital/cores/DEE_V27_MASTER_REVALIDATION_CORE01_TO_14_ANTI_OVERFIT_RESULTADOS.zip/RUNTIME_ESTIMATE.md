# Runtime estimate

- Raw ledger entries: 321
- Canonical GOLD claims: 118
- Executable fresh contracts: 28
- Exact derivations: 48
- Replay-only justified claims: 44
- Planned waves: A for all executable contracts; B for high-impact contracts.
- Expected runtime: minutes to tens of minutes on this host.
- Disk: compact telemetry; canonical runtime excluded from final ZIP.
