# Adversarial review

## Strong claims that survived

- The two-tick reset law survived long-horizon model selection and a new frozen holdout.
- The 195-class decoder survived N, translation, signed frame, class-count and destroyed/equal/sham controls.
- The finite feedback chain survived no-action, no-penalty and wrong-consequence canaries.
- The distributed vector decoder survived missing-writer and missing-probe controls and fresh length 512.

## Claims weakened or rejected

- Full-state invariance of `semantic4` sources was rejected. Only raw is invariant; clock advances exactly.
- Old sequence-clock “history” is not an experience-written memory: Python injected clock stamps.
- A routed phase symbol is not learned decoding; detector biases are configured.
- Spatial vector order is not recurrent temporal inference.
- L2 recurrence and L3 finite feedback do not compose into L4. Fixed sources restore their own grammar.
- No self-repair of learned function without pre-trained expendable information was found.
- No DEE-vs-transformer superiority claim has adequate primary evidence.

## Simpler models

Finite-state transducers, lookup/addressed memory and configured one-hot decoding remain sufficient functional abstractions for the registered tasks. The DEE-specific scientific result is their implementation through exact local raw/clock/destination dynamics, not algorithmic superiority.
