# CORE01–17 mechanism retrospective for INGENIERIA 01

The decisive reconstruction came from connections that the first pass underused:

- CORE01 E8/E12 supplies an inexhaustible *raw* source train; E1 simultaneously proves that its clock is dynamic. Combined with the CORE01 reducer, this yields the new L2 reset law without inventing a new kernel primitive.
- CORE01 E1/E2 and CORE12 clock mediation explain exactly how a hidden phase can be read. CORE16 hidden-state return motivated the readout; the rewrite turns it into a 195-class routed decoder.
- CORE06 plasticity, CORE09 policy response and CORE17 direction-policy identification form the finite L3 chain. The rewrite adds missing causal canaries and removes answer-conditioned query selection.
- CORE08 regeneration and CORE17 trained-backup repair do not supply a learned replenishing state: one restores canonical structure; the other spends trained backups.
- CORE03/04/11/13/15 establish organization-, level- and observer-dependent descriptions, explaining why binary direction, clock phase and spatial distributed codes are overlapping engineering coordinates rather than one universal memory variable.

The retrospective produced experiments, not only narrative: R01–R04 (reset), R05–R10 (phase decoder), R11/R17/R18 (distributed sequence), R13/R14 (finite feedback), R15 (L4 prerequisite closure), and R16 (26-symbol policy).

The final graph is `ING01_CORE01_17_MECHANISM_GRAPH.json`; every node records origin, artifact, coordinates, writes, preservation, loss, routing, resource behavior and possible composition.
