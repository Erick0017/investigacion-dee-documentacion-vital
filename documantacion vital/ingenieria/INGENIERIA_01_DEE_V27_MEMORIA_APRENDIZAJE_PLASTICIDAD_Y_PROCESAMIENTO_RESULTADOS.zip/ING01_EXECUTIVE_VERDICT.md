# INGENIERIA 01 — Definitive executive verdict

## Outcome

The original package was a valid first map but not the final architecture. Its eight claims are preserved; two interpretations are explicitly revised. The rewrite establishes three major additions:

1. **L2 native recurrent execution.** Four immutable `semantic4` raw sources replenish writers that recycle one policy carrier through an exact two-tick law. R04 passed 32/32 fresh treatment worlds, 15424 fresh cycles, horizons through 1024 cycles, and 12/12 causal canaries. Model selection reached 4,096 exact cycles in one world.
2. **Native distributed decoding.** A period-195 tetra gate converts clock phase to `raw`; a configured bank decoded and routed one of 195 classes. R10 passed 40/40 fresh treatments and 12/12 destroyed/equal/sham controls. This is a configured phase decoder, not a learned decoder: v27 clocks are autonomous and cannot be written by experience.
3. **L3 finite consequence-mediated adaptation.** In one continuing preloaded world, a native action is required for an environmental collision that writes policy A/B and changes the later action. R14 passed 40/40 treatments and 12/12 causal canaries with no Python intervention after `t0`.

The binary policy-bank is only the first primitive. The exact reducer plus routing supports all 26 Moore direction symbols (1,248/1,248 frame-symbol cases). An answer-independent dual-probe spatial bank decoded every one of 510 binary vectors through length 8 and 3,924 fresh bits in 24 worlds through length 512. This is spatially addressed sequence memory, not recurrent temporal reasoning.

## Critical corrections

- R03 falsified a too-strong auxiliary prediction: `semantic4 raw` is invariant, but its clock advances. The corrected claim was re-frozen and confirmed on new R04 worlds.
- The old D04/D09 `raw+clock` sequence injectivity remains numerically true, but the runner wrote clock values from Python during symbol injection. It did not demonstrate experience-written clock memory.
- Old query ports were selected using the known bit in several capacity/sequence apparatuses. The new dual-probe construction initializes both possible probes and removes that answer leakage.

## Final autonomy boundary

- L1 finite prepared pipeline: confirmed.
- L2 repeated cycles without external restoration: confirmed.
- L3 environmental consequence changes later behavior in the same world: confirmed, finite.
- L4 persistent adaptive loop with resource maintenance: not constructed.
- L5 self-maintaining learned organization: not constructed.

Three distinct L4 construction attempts isolated the missing prerequisite: no known coordinate is simultaneously experience-writable, functionally reusable/non-destructive, and natively replenishing. `semantic4` replenishes but is immutable; `semantic1 direction` learns but is consumed by read; redundant trained backups deplete linearly.

## AI comparison

A recursive content audit inspected 16,609 loose files/containers, including ZIP/DOCX members, and found no primary fair DEE-vs-transformer benchmark. No global superiority claim is supported and no mismatched transformer benchmark was manufactured.
