# Reproduction

Use the pinned v27 kernel recorded in `RUNTIME_ENVIRONMENT.json`. From the package root, execute the frozen runners with Python 3.13 and one kernel thread.

Core confirmations:

```text
python RUNNERS/run_r04_reset_corrected_holdout.py
python RUNNERS/run_r10_decoder_holdout.py
python RUNNERS/run_r14_feedback_holdout.py
python RUNNERS/run_r18_sequence_holdout.py
```

The corresponding `FREEZE/` and `CHALLENGES/` files must remain unchanged. Expected summaries are preserved in `HOLDOUT/`. R03 is intentionally a failed composite prediction and must not be reported as a full pass.

Discovery/model-selection reproduction:

```text
python RUNNERS/run_r01_reset_oscillator.py
python RUNNERS/run_r02_reset_longevity.py
python RUNNERS/run_r05_clock_decoder_discovery.py
python RUNNERS/run_r06_phase_decoder_bank.py
python RUNNERS/run_r09_decoder_frames.py
python RUNNERS/run_r11_distributed_sequence_decoder.py
python RUNNERS/run_r13_feedback_discovery.py
python RUNNERS/run_r15_l4_prerequisite_search.py
python RUNNERS/run_r16_multisymbol_policy.py
python RUNNERS/run_r17_sequence_scaling.py
```

All result content hashes and file hashes are listed in `MANIFEST.json` and `HASHES.sha256` after packaging.
