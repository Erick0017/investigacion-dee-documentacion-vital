#!/usr/bin/env python3
"""Search loose and embedded ZIP/DOCX content for historical DEE/AI comparisons."""
from __future__ import annotations

import hashlib
import io
import json
import re
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
TESTS = WORK.parents[4]

TEXT_EXT = {".json", ".md", ".txt", ".py", ".csv", ".ndjson", ".xml", ".yaml", ".yml", ".toml"}
TERMS = [
    "transformer",
    "neural network",
    "red neuronal",
    "lstm",
    "gru",
    "rnn",
    "dee vs",
    "dee-vs",
    "outperform",
    "superior a",
    "benchmark",
]
PROTOCOL_FIELDS = [
    "training set",
    "test set",
    "train split",
    "parameter count",
    "optimizer",
    "learning rate",
    "latency",
    "accuracy",
    "transformer architecture",
    "baseline",
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def scan_text(label, data, hits):
    text = data.decode("utf-8", errors="ignore")
    low = text.lower()
    matched = [term for term in TERMS if term in low]
    if not matched:
        return
    snippets = []
    for term in matched:
        start = low.find(term)
        snippets.append(re.sub(r"\s+", " ", text[max(0, start - 220): start + len(term) + 420]).strip())
    fields = [field for field in PROTOCOL_FIELDS if field in low]
    dee_present = bool(re.search(r"\bdee\b", low))
    numeric_metric = bool(re.search(r"(?:accuracy|latency|f1|loss|error).{0,80}\d", low, flags=re.S))
    likely_directive = any(x in low for x in ("do not begin", "only if", "must disclose", "search the entire", "compare on matched"))
    hits.append(
        {
            "artifact": label,
            "sha256": sha(data),
            "bytes": len(data),
            "terms": matched,
            "protocol_fields": fields,
            "dee_present": dee_present,
            "numeric_metric_near_comparison_terms": numeric_metric,
            "likely_directive_or_plan": likely_directive,
            "snippets": snippets[:8],
        }
    )


def scan_zip(data, label, hits, depth=0):
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            for info in archive.infolist():
                if info.is_dir() or info.file_size > 30_000_000:
                    continue
                name = info.filename
                ext = Path(name).suffix.lower()
                member = archive.read(info)
                child = f"{label}!/{name}"
                if ext in TEXT_EXT:
                    scan_text(child, member, hits)
                elif ext in {".zip", ".docx"} and depth < 3:
                    scan_zip(member, child, hits, depth + 1)
    except (zipfile.BadZipFile, RuntimeError, OSError):
        return


def main():
    hits = []
    files = []
    for path in TESTS.rglob("*"):
        if not path.is_file():
            continue
        if "REWRITE_WORK\\BASELINE_LOCKED" in str(path):
            continue
        ext = path.suffix.lower()
        if ext not in TEXT_EXT | {".zip", ".docx"}:
            continue
        files.append(path)
    for path in files:
        try:
            data = path.read_bytes()
        except OSError:
            continue
        label = str(path.relative_to(TESTS))
        if path.suffix.lower() in {".zip", ".docx"}:
            scan_zip(data, label, hits)
        elif len(data) <= 30_000_000:
            scan_text(label, data, hits)
    dedup = {}
    for hit in hits:
        key = hit["sha256"]
        if key not in dedup:
            dedup[key] = {**hit, "all_artifact_references": [hit["artifact"]]}
        else:
            dedup[key]["all_artifact_references"].append(hit["artifact"])
    unique = list(dedup.values())
    primary_candidates = [
        hit for hit in unique
        if hit["dee_present"]
        and "transformer" in hit["terms"]
        and hit["numeric_metric_near_comparison_terms"]
        and len(hit["protocol_fields"]) >= 4
        and not hit["likely_directive_or_plan"]
    ]
    out = {
        "schema": "dee.v27.ing01.rewrite.ai_history_audit.v1",
        "search_scope": str(TESTS),
        "method": "Recursive loose-file plus ZIP/DOCX member content scan to depth 3; content-SHA deduplication; primary benchmark gate requires DEE, transformer, a numeric metric, at least four protocol fields, and non-directive prose.",
        "files_or_containers_scanned": len(files),
        "raw_hits": len(hits),
        "unique_content_hits": len(unique),
        "primary_benchmark_candidates": primary_candidates,
        "all_unique_hits": unique,
        "adjudication": "VERIFIED_FAIR" if primary_candidates else "INSUFFICIENT_EVIDENCE",
        "conclusion": "No historical DEE-vs-transformer superiority claim is promoted without a primary artifact containing the task, split, architectures, budgets and metrics." if not primary_candidates else "Primary candidates require manual protocol adjudication recorded above.",
        "new_benchmark_executed": False,
        "reason_no_new_transformer_benchmark": "The strongest new tasks are exact prepared routing/memory transductions. A transformer comparison would measure a mismatched software task unless a common temporal prediction or continual-adaptation protocol is first constructed.",
    }
    path = WORK / "DEE_VS_TRANSFORMER_AUDIT.json"
    path.write_text(json.dumps(out, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"files": len(files), "raw_hits": len(hits), "unique_hits": len(unique), "primary_candidates": len(primary_candidates), "adjudication": out["adjudication"]}, sort_keys=True))


if __name__ == "__main__":
    main()
