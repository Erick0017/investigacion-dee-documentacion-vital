#!/usr/bin/env python3
"""Frozen spatially addressed sequence memory with unbiased dual probes."""
from __future__ import annotations

import itertools

import numpy as np

from rewrite_common import A, ACTION0, ACTION1, B, PENALTY0, SENSOR, NativeWorld, add, pack, read


def _place(raw, clock, target, tick, direction, state, sreg):
    n = raw.shape[0]
    source = add(target, direction, -tick, n)
    if int(raw[source]):
        raise RuntimeError(f"preloaded overlap at {source}")
    raw[source] = pack(state, sreg, direction, 1)
    clock[source] = np.uint64(0)


def coordinates(n, count):
    axis = list(range(8, n - 4, 7))
    pts = list(itertools.product(axis, repeat=3))
    if len(pts) < count:
        raise ValueError(f"N={n} supports only {len(pts)} tested addresses")
    return pts[:count]


def run_sequence_memory_case(kernel, challenge):
    sequence = [int(x) for x in challenge["sequence"]]
    mode = challenge["mode"]
    n = int(challenge["n"])
    coords = coordinates(n, len(sequence))
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    meta = []
    for i, (q, bit) in enumerate(zip(coords, sequence)):
        raw[q] = pack(1000 + i, 7 + (i % 101), A, 1)
        wq = add(q, A, 1, n)
        if bit and mode != "missing_writer":
            _place(raw, clock, wq, 1, PENALTY0, 100000 + i, 31 + (i % 113))
        target0 = add(wq, A, 1, n)
        target1 = add(wq, B, 1, n)
        if mode != "missing_probes":
            _place(raw, clock, target0, 2, SENSOR, 200000 + 2 * i, 101 + (i % 127))
            _place(raw, clock, target1, 2, SENSOR, 200001 + 2 * i, 103 + (i % 127))
        meta.append((wq, target0, target1, bit))
    world = NativeWorld(kernel, raw, clock, threads=1)
    world.tick()
    written = []
    for wq, _, _, bit in meta:
        record = read(world.raw, wq)
        expected = B if bit and mode != "missing_writer" else A
        written.append(record is not None and tuple(record["direction"]) == expected)
    world.tick()
    decoded = []
    for _, target0, target1, _ in meta:
        rec0 = read(world.raw, target0)
        rec1 = read(world.raw, target1)
        hit0 = rec0 is not None and tuple(rec0["direction"]) == ACTION0
        hit1 = rec1 is not None and tuple(rec1["direction"]) == ACTION1
        decoded.append(0 if hit0 and not hit1 else 1 if hit1 and not hit0 else -1)
    return {
        "challenge_id": challenge["challenge_id"],
        "mode": mode,
        "n": n,
        "length": len(sequence),
        "sequence": sequence,
        "decoded": decoded,
        "writes_exact": all(written),
        "full_sequence_exact": decoded == sequence if mode == "treatment" else False,
        "python_interventions_after_t0": 0,
        "initial_voxel_resources": int(np.count_nonzero(raw)),
        "write_ticks": 1,
        "read_ticks": 1,
    }

