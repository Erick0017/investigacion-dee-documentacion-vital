#!/usr/bin/env python3
"""Freeze the R03 reset law before generating fresh challenges."""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, sha256_file, write_json


def main():
    files = [HERE / "reset_apparatus_v1.py", HERE / "run_r03_reset_holdout.py"]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.reset_holdout_lock.v1",
            "originating_branch": "native reset / replenishment / reusable execution",
            "apparatus": "One semantic-1 policy carrier; four invariant semantic-4 writer sources; exact two-tick direction cycle.",
            "prediction": "All treatment worlds complete every requested cycle exactly; every causal canary fails by tick 3.",
            "metric": "direction equality at the alternating target after every half-cycle; bit-exact persistence of semantic-4 sources",
            "falsifier": "Any treatment direction mismatch, any source mutation, or any canary remaining exact after tick 3.",
            "scope": "Prepared recurrent execution with native resource replenishment; excludes adaptive feedback and damage self-maintenance.",
            "frozen_files": [{"path": str(p.relative_to(WORK)), "sha256": sha256_file(p)} for p in files],
            "fresh_dimensions": ["N", "position", "signed-permuted frame", "horizon", "canary mode"],
            "canaries": {
                "missing_source": "removes a required writer",
                "finite_sources": "replaces invariant sources with consumable carriers",
                "wrong_writer": "breaks the vector reducer identity",
            },
        }
    )
    write_json(WORK / "FREEZE" / "R03_RESET_HOLDOUT_LOCK.json", out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()

