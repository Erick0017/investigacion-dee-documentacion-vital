#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, sha256_file, write_json


def main():
    files = [HERE / "clock_decoder_apparatus_v1.py", HERE / "run_r10_decoder_holdout.py"]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.decoder_holdout_lock.v1",
            "originating_branch": "native decoder of distributed clock information",
            "claim": "A configured bank converts one common clock-phase class into a one-hot raw s_reg symbol and routes that symbol as a causal carrier without post-initialization Python intervention.",
            "prediction": "All fresh treatment worlds have exactly one active gate and routed output at the encoded class; equal-clock, destroyed-phase, and sham-nonzero canaries do not reproduce that class output.",
            "metric": "active output indices defined by s_reg=11 against baseline s_reg=10",
            "falsifier": "wrong/multiple/missing treatment output or any canary equal to the encoded singleton class",
            "scope": "Configured clock-phase decoder. The input phase is prepared at t0; no claim that DEE writes clocks from experience or learns decoder biases.",
            "frozen_files": [{"path": str(p.relative_to(WORK)), "sha256": sha256_file(p)} for p in files],
            "fresh_dimensions": ["N", "translation", "signed-permuted frame", "class count", "input class", "canary mode"],
        }
    )
    write_json(WORK / "FREEZE" / "R10_DECODER_HOLDOUT_LOCK.json", out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()

