#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, sha256_file, write_json


def main():
    files = [HERE / "distributed_sequence_apparatus_v1.py", HERE / "run_r18_sequence_holdout.py"]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.sequence_holdout_lock.v1",
            "claim": "A spatially addressed distributed direction bank stores and natively decodes every bit of a sequence in parallel using answer-independent dual probes initialized at t0.",
            "prediction": "All fresh treatment vectors decode bit-exactly in two ticks; missing-writer and missing-probe canaries fail full-vector equality.",
            "metric": "zero Hamming error across the full output vector",
            "falsifier": "any treatment bit error or any canary reproducing the complete vector",
            "scope": "Spatial sequence code and simultaneous functional readout, not a recurrent temporal encoder, rule induction, or maximum capacity.",
            "frozen_files": [{"path": str(p.relative_to(WORK)), "sha256": sha256_file(p)} for p in files],
            "fresh_dimensions": ["sequence", "length", "N", "canary mode"],
        }
    )
    write_json(WORK / "FREEZE" / "R18_SEQUENCE_HOLDOUT_LOCK.json", out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()

