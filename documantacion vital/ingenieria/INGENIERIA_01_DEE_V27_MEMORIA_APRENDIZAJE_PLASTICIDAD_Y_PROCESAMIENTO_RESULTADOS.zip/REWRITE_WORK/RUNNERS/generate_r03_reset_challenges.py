#!/usr/bin/env python3
"""Generate post-freeze R03 worlds from OS entropy."""
from __future__ import annotations

import itertools
import secrets
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, write_json


def main():
    freeze = WORK / "FREEZE" / "R03_RESET_HOLDOUT_LOCK.json"
    output = WORK / "CHALLENGES" / "R03_RESET_HOLDOUT_CHALLENGES.json"
    if not freeze.exists():
        raise RuntimeError("freeze must exist before challenge generation")
    if output.exists():
        raise RuntimeError("challenge file already exists; refusing to replace fresh worlds")
    rng = secrets.SystemRandom()
    ns = [19, 25, 29, 35, 41]
    cycles = [128, 256, 512]
    permutations = list(itertools.permutations(range(3)))
    signs = list(itertools.product((-1, 1), repeat=3))
    challenges = []
    modes = ["treatment"] * 30 + ["missing_source"] * 4 + ["finite_sources"] * 4 + ["wrong_writer"] * 4
    rng.shuffle(modes)
    for i, mode in enumerate(modes):
        n = rng.choice(ns)
        challenges.append(
            {
                "challenge_id": f"R03-{i:03d}",
                "entropy_token": secrets.token_hex(16),
                "mode": mode,
                "n": n,
                "cycles": rng.choice(cycles) if mode == "treatment" else 16,
                "q": [rng.randrange(n) for _ in range(3)],
                "permutation": list(rng.choice(permutations)),
                "signs": list(rng.choice(signs)),
            }
        )
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.reset_holdout_challenges.v1",
            "generation": "Python secrets.SystemRandom after freeze; entropy tokens are identifiers, not kernel seeds because dynamics are deterministic.",
            "challenges": challenges,
        }
    )
    write_json(output, out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()
