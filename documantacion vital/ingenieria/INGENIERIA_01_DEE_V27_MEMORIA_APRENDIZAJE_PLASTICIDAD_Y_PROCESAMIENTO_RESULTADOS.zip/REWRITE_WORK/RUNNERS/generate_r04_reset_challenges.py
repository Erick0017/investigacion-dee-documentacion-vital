#!/usr/bin/env python3
from __future__ import annotations

import itertools
import secrets
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, write_json


def main():
    freeze = WORK / "FREEZE" / "R04_RESET_CORRECTED_LOCK.json"
    output = WORK / "CHALLENGES" / "R04_RESET_CORRECTED_CHALLENGES.json"
    if not freeze.exists() or output.exists():
        raise RuntimeError("freeze missing or challenges already exist")
    rng = secrets.SystemRandom()
    perms = list(itertools.permutations(range(3)))
    signs = list(itertools.product((-1, 1), repeat=3))
    modes = ["treatment"] * 32 + ["missing_source"] * 4 + ["finite_sources"] * 4 + ["wrong_writer"] * 4
    rng.shuffle(modes)
    challenges = []
    for i, mode in enumerate(modes):
        n = rng.choice([17, 21, 27, 33, 39, 47])
        challenges.append(
            {
                "challenge_id": f"R04-{i:03d}",
                "entropy_token": secrets.token_hex(16),
                "mode": mode,
                "n": n,
                "cycles": rng.choice([64, 128, 256, 512, 1024]) if mode == "treatment" else 16,
                "q": [rng.randrange(n) for _ in range(3)],
                "permutation": list(rng.choice(perms)),
                "signs": list(rng.choice(signs)),
            }
        )
    out = seal({"schema": "dee.v27.ing01.rewrite.reset_corrected_challenges.v1", "generation": "post-freeze OS entropy", "challenges": challenges})
    write_json(output, out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()
