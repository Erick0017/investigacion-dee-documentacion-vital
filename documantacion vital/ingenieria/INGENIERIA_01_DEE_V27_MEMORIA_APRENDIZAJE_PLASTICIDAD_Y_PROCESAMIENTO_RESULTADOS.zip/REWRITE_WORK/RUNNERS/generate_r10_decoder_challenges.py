#!/usr/bin/env python3
from __future__ import annotations

import itertools
import secrets
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, write_json


def main():
    freeze = WORK / "FREEZE" / "R10_DECODER_HOLDOUT_LOCK.json"
    output = WORK / "CHALLENGES" / "R10_DECODER_HOLDOUT_CHALLENGES.json"
    if not freeze.exists() or output.exists():
        raise RuntimeError("freeze missing or challenges already exist")
    rng = secrets.SystemRandom()
    frames = list(itertools.product(itertools.permutations(range(3)), itertools.product((-1, 1), repeat=3)))
    modes = ["treatment"] * 40 + ["clock_equal"] * 4 + ["destroyed"] * 4 + ["sham_nonzero"] * 4
    rng.shuffle(modes)
    challenges = []
    class_choices = [2, 3, 4, 5, 8, 12, 16, 24, 32, 64, 97, 195]
    for i, mode in enumerate(modes):
        classes = rng.choice(class_choices if mode == "treatment" else [4, 8, 16])
        n = rng.choice([31, 37, 43, 47])
        permutation, signs = rng.choice(frames)
        challenges.append(
            {
                "challenge_id": f"R10-{i:03d}",
                "entropy_token": secrets.token_hex(16),
                "mode": mode,
                "n": n,
                "classes": classes,
                "input_class": rng.randrange(classes),
                "origin": [rng.randrange(n) for _ in range(3)],
                "permutation": list(permutation),
                "signs": list(signs),
            }
        )
    out = seal({"schema": "dee.v27.ing01.rewrite.decoder_holdout_challenges.v1", "generation": "post-freeze OS entropy", "challenges": challenges})
    write_json(output, out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()
