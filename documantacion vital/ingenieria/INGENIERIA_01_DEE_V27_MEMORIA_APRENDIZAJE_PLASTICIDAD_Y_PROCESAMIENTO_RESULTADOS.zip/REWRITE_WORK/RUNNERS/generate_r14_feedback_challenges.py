#!/usr/bin/env python3
from __future__ import annotations

import itertools
import secrets
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, write_json


def main():
    freeze = WORK / "FREEZE" / "R14_FEEDBACK_HOLDOUT_LOCK.json"
    output = WORK / "CHALLENGES" / "R14_FEEDBACK_HOLDOUT_CHALLENGES.json"
    if not freeze.exists() or output.exists():
        raise RuntimeError("freeze missing or challenges already exist")
    rng = secrets.SystemRandom()
    frames = list(itertools.product(itertools.permutations(range(3)), itertools.product((-1, 1), repeat=3)))
    modes = ["treatment"] * 40 + ["no_action"] * 4 + ["no_penalty"] * 4 + ["wrong_consequence"] * 4
    rng.shuffle(modes)
    challenges = []
    for i, mode in enumerate(modes):
        n = rng.choice([23, 27, 31, 37, 43])
        permutation, signs = rng.choice(frames)
        challenges.append(
            {
                "challenge_id": f"R14-{i:03d}",
                "entropy_token": secrets.token_hex(16),
                "mode": mode,
                "bit": rng.randrange(2) if mode == "treatment" else 1,
                "n": n,
                "q": [rng.randrange(n) for _ in range(3)],
                "permutation": list(permutation),
                "signs": list(signs),
            }
        )
    out = seal({"schema": "dee.v27.ing01.rewrite.feedback_holdout_challenges.v1", "generation": "post-freeze OS entropy", "challenges": challenges})
    write_json(output, out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()
