#!/usr/bin/env python3
from __future__ import annotations

import secrets
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import WORK, seal, write_json


def bits(count):
    data = secrets.token_bytes((count + 7) // 8)
    result = [(data[i // 8] >> (i % 8)) & 1 for i in range(count)]
    if result and not any(result):
        result[-1] = 1
    return result


def main():
    freeze = WORK / "FREEZE" / "R18_SEQUENCE_HOLDOUT_LOCK.json"
    output = WORK / "CHALLENGES" / "R18_SEQUENCE_HOLDOUT_CHALLENGES.json"
    if not freeze.exists() or output.exists():
        raise RuntimeError("freeze missing or challenges already exist")
    rng = secrets.SystemRandom()
    challenges = []
    lengths = [9, 17, 33, 65, 129, 257, 512]
    for i in range(24):
        length = rng.choice(lengths)
        challenges.append({"challenge_id": f"R18-T-{i:03d}", "entropy_token": secrets.token_hex(16), "mode": "treatment", "n": rng.choice([71, 79]), "sequence": bits(length)})
    for i, mode in enumerate(["missing_writer"] * 4 + ["missing_probes"] * 4):
        length = rng.choice([17, 33, 65])
        challenges.append({"challenge_id": f"R18-C-{i:03d}", "entropy_token": secrets.token_hex(16), "mode": mode, "n": 71, "sequence": bits(length)})
    rng.shuffle(challenges)
    out = seal({"schema": "dee.v27.ing01.rewrite.sequence_holdout_challenges.v1", "generation": "post-freeze OS entropy", "challenges": challenges})
    write_json(output, out)
    print(out["content_sha256"])


if __name__ == "__main__":
    main()
