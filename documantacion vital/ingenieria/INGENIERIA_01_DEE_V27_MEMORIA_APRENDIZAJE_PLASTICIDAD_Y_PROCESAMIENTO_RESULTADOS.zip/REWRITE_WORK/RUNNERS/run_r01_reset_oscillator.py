#!/usr/bin/env python3
"""Discovery: phase-staggered semantic-4 writers recycle one policy carrier."""
from __future__ import annotations
import itertools,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from rewrite_common import *

P=(1,0,0);S1=(-1,1,0);S2=(-1,-1,0);N1=(1,0,1);N2=(1,0,-1)
FRAMES=[((0,1,2),(1,1,1)),((0,1,2),(-1,1,1)),((1,0,2),(1,1,1)),((2,1,0),(1,-1,1)),((1,2,0),(-1,1,-1)),((2,0,1),(1,1,-1))]

def source(raw,clock,pos,d,state,sreg,semantic=4):
    if int(raw[pos]):raise RuntimeError(f"source overlap {pos}")
    raw[pos]=pack(state,sreg,d,semantic);clock[pos]=np.uint64(100000+state)

def run_case(kernel,seed,frame,n=31,cycles=64,mode="treatment"):
    perm,signs=frame;p,s1,s2,n1,n2=(transform(v,perm,signs) for v in (P,S1,S2,N1,N2));q=(n//2,n//2,n//2);qp=add(q,p,1,n)
    raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);raw[q]=pack(1,7,p,1);clock[q]=11
    specs=[(add(qp,s1,-1,n),s1,11),(add(qp,s2,-1,n),s2,13),(add(q,n1,-2,n),n1,17),(add(q,n2,-2,n),n2,19)]
    for i,(pos,d,sreg) in enumerate(specs):
        if mode=="missing_source" and i==0:continue
        sem=1 if mode=="finite_sources" else 4
        dd=transform((0,1,1),perm,signs) if mode=="wrong_writer" and i==0 else d
        source(raw,clock,pos,dd,2000+i,sreg,sem)
    world=NativeWorld(kernel,raw,clock,threads=1);trace=[];successes=0;first_failure=None
    for tick in range(1,2*cycles+1):
        world.tick();target=qp if tick%2 else q;expected=tuple(-x for x in p) if tick%2 else p;rec=read(world.raw,target);ok=rec is not None and tuple(rec["direction"])==expected
        if ok:successes+=1
        elif first_failure is None:first_failure=tick
        if tick<=12 or tick in {16,32,64,96,128,2*cycles}:trace.append({"tick":tick,"target":target,"record":rec,"expected":expected,"ok":ok,"support":int(np.count_nonzero(world.raw))})
    fixed=[]
    for pos,d,_ in specs:
        r=read(world.raw,pos);fixed.append(r is not None and r["semantic"]==4 and tuple(r["direction"])==d)
    return {"seed":seed,"mode":mode,"n":n,"cycles_requested":cycles,"frame":{"permutation":list(perm),"signs":list(signs)},"policy_direction":p,"coordinates":{"q":q,"q_plus_p":qp,"sources":[x[0] for x in specs]},"successful_half_cycles":successes,"complete_cycles":successes//2 if first_failure is None else (first_failure-1)//2,"first_failure_tick":first_failure,"all_exact":first_failure is None,"sources_fixed":all(fixed) if mode=="treatment" else None,"terminal_support":int(np.count_nonzero(world.raw)),"trace":trace}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for i,f in enumerate(FRAMES):
        for n in (17,23,31):rows.append(run_case(kernel,2010000+i*101+n,f,n,64,"treatment"))
    for i,mode in enumerate(("missing_source","finite_sources","wrong_writer")):rows.append(run_case(kernel,2020000+i,FRAMES[0],31,32,mode))
    treat=[r for r in rows if r["mode"]=="treatment"];controls=[r for r in rows if r["mode"]!="treatment"]
    summary={"treatment_cases":len(treat),"all_treatment_exact":all(r["all_exact"] for r in treat),"maximum_exact_cycles":max(r["complete_cycles"] for r in treat),"all_sources_fixed":all(r["sources_fixed"] for r in treat),"controls":{r["mode"]:{"first_failure_tick":r["first_failure_tick"],"complete_cycles":r["complete_cycles"]} for r in controls}}
    out=seal({"schema":"dee.v27.ing01.rewrite.reset_oscillator.discovery.v1","mechanism":{"policy":"one semantic-1 carrier alternates P and -P","forward":"P+S1+S2=-P","reset":"-P+N1+N2=P","replenishment":"four invariant semantic-4 sources emit writer trains; reset writers are placed at distance two to phase arrivals","cycle_latency_ticks":2},"rows":rows,"summary":summary,"runtime":runtime,"interpretation_guard":"Persistent sources replenish writer carriers and the policy carrier is recycled. Source sites are preconfigured and immutable; this is recurrent execution, not learned feedback adaptation."})
    write_json(WORK/"DISCOVERY"/"R01_RESET_OSCILLATOR.json",out);print(json.dumps({"hash":out["content_sha256"],**summary},sort_keys=True))

if __name__=="__main__":main()
