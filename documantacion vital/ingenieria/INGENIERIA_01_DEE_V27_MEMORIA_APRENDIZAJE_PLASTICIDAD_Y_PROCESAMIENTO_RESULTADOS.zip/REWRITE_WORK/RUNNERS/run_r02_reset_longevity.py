#!/usr/bin/env python3
"""Model selection: challenge the R01 cycle beyond torus wrap periods."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

from rewrite_common import WORK, load_kernel, seal, write_json
from run_r01_reset_oscillator import FRAMES, run_case


def main() -> None:
    kernel, runtime = load_kernel(1)
    plan = [
        (17, FRAMES[0], 4096),
        (23, FRAMES[1], 2048),
        (31, FRAMES[2], 2048),
        (47, FRAMES[3], 1024),
    ]
    rows = [
        run_case(kernel, 2030000 + i * 101 + n, frame, n, cycles, "treatment")
        for i, (n, frame, cycles) in enumerate(plan)
    ]
    total_cycles = sum(row["complete_cycles"] for row in rows)
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.reset_oscillator.model_selection.v1",
            "source_discovery": "DISCOVERY/R01_RESET_OSCILLATOR.json",
            "question": "Does the two-tick cycle survive far beyond the torus wrap time without finite resource exhaustion?",
            "prediction_frozen_in_runner": "All treatment cases remain exact for their full requested horizon and semantic-4 sources remain fixed.",
            "rows": rows,
            "summary": {
                "all_exact": all(row["all_exact"] for row in rows),
                "all_sources_fixed": all(row["sources_fixed"] for row in rows),
                "total_exact_cycles": total_cycles,
                "maximum_exact_cycles_single_world": max(row["complete_cycles"] for row in rows),
                "minimum_horizon_to_N_ratio": min((2 * row["cycles_requested"]) / row["n"] for row in rows),
            },
            "runtime": runtime,
            "interpretation_guard": "Longevity beyond many torus wraps rejects a short preloaded-train explanation. It does not by itself establish consequence-mediated learning or self-maintenance under damage.",
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R02_RESET_LONGEVITY.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
