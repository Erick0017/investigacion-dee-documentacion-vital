#!/usr/bin/env python3
"""Discover the exact native period-195 clock-to-raw gate."""
from __future__ import annotations

import itertools
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import NativeWorld, WORK, add, load_kernel, pack, read, seal, transform, write_json

TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))
FRAMES = [
    ((0, 1, 2), (1, 1, 1)),
    ((0, 1, 2), (-1, 1, 1)),
    ((1, 0, 2), (1, -1, 1)),
    ((2, 1, 0), (-1, 1, -1)),
]


def gate_case(kernel, phase, frame, n, q):
    permutation, signs = frame
    offsets = [transform(v, permutation, signs) for v in TETRA]
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(1, 10, (0, 0, 0), 1)
    clock[q] = np.uint64(phase)
    for offset in offsets:
        pos = add(q, offset, 1, n)
        raw[pos] = pack(1, 3, (0, 0, 0), 1)
        clock[pos] = np.uint64(17)
    world = NativeWorld(kernel, raw, clock, threads=1)
    world.tick()
    return read(world.raw, q)


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for frame_index, frame in enumerate(FRAMES):
        n = (17, 23, 31, 37)[frame_index]
        q = ((3 + 5 * frame_index) % n, (7 + 3 * frame_index) % n, (11 + 7 * frame_index) % n)
        for phase in range(195):
            rows.append(
                {
                    "frame_index": frame_index,
                    "n": n,
                    "q": list(q),
                    "phase_mod195": phase,
                    "record": gate_case(kernel, phase, frame, n, q),
                }
            )
    signatures = defaultdict(list)
    for row in rows:
        record = row["record"]
        key = (record["state"], record["sreg"], tuple(record["direction"]), record["semantic"])
        signatures[str(key)].append((row["frame_index"], row["phase_mod195"]))
    per_frame_active = {}
    for frame_index in range(len(FRAMES)):
        frame_rows = [row for row in rows if row["frame_index"] == frame_index]
        baseline_sreg = min(row["record"]["sreg"] for row in frame_rows)
        per_frame_active[str(frame_index)] = [row["phase_mod195"] for row in frame_rows if row["record"]["sreg"] != baseline_sreg]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.clock_decoder.discovery.v1",
            "apparatus": "A semantic-1 center with four zero-direction semantic-1 tetra neighbors. No post-initialization Python intervention.",
            "rows": rows,
            "signature_classes": {key: {"count": len(values), "examples": values[:12]} for key, values in signatures.items()},
            "per_frame_nonbaseline_phases": per_frame_active,
            "summary": {
                "worlds": len(rows),
                "residues_per_frame": 195,
                "frames": len(FRAMES),
                "signature_class_count": len(signatures),
                "same_active_phase_every_frame": len({tuple(v) for v in per_frame_active.values()}) == 1,
            },
            "runtime": runtime,
            "interpretation_guard": "This is native clock-to-raw transduction. It is not yet sequence decoding, learned decoding, or an action policy.",
        }
    )
    write_json(WORK / "DISCOVERY" / "R05_CLOCK_DECODER_DISCOVERY.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"], "active": per_frame_active}, sort_keys=True))


if __name__ == "__main__":
    main()
