#!/usr/bin/env python3
"""Discovery/model selection: a spatial bank decodes a distributed clock phase."""
from __future__ import annotations

import hashlib
import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import NativeWorld, WORK, add, load_kernel, pack, read, seal, write_json

TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))


def positions(n, count):
    pts = list(itertools.product(range(2, n - 2, 4), repeat=3))
    if len(pts) < count:
        raise ValueError("decoder bank does not fit")
    return pts[:count]


def bank_case(kernel, classes, input_class, mode="treatment", n=41):
    centers = positions(n, classes)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    for bias, q in enumerate(centers):
        if mode == "treatment":
            phase = (input_class - bias) % 195
        elif mode == "clock_equal":
            phase = input_class % 195
        elif mode == "destroyed":
            phase = 1
        elif mode == "sham_nonzero":
            phase = ((input_class - bias) % 194) + 1
        else:
            raise ValueError(mode)
        raw[q] = pack(1, 10, (0, 0, 0), 1)
        clock[q] = np.uint64(phase)
        for offset in TETRA:
            p = add(q, offset, 1, n)
            raw[p] = pack(1, 3, (0, 0, 0), 1)
            clock[p] = np.uint64(17)
    world = NativeWorld(kernel, raw, clock, threads=1)
    world.tick()
    sregs = [read(world.raw, q)["sreg"] for q in centers]
    active = [i for i, sreg in enumerate(sregs) if sreg == 11]
    expected = [input_class] if mode == "treatment" else None
    return {
        "classes": classes,
        "input_class": input_class,
        "mode": mode,
        "active_indices": active,
        "expected_active_indices": expected,
        "one_hot_exact": active == expected if expected is not None else None,
        "sreg_vector": sregs,
        "sreg_vector_sha256": hashlib.sha256(np.asarray(sregs, dtype="<u2").tobytes()).hexdigest(),
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for classes in (2, 4, 8, 16, 32, 64, 195):
        for input_class in range(classes):
            rows.append(bank_case(kernel, classes, input_class, "treatment"))
    controls = []
    for mode in ("clock_equal", "destroyed", "sham_nonzero"):
        for input_class in (0, 1, 3, 7):
            controls.append(bank_case(kernel, 8, input_class, mode))
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.phase_decoder_bank.discovery.v1",
            "encoding": "For input class x and detector bias i, central clock phase is (x-i) mod 195. The fixed tetra gate writes s_reg=11 only where phase=0; all other outputs are s_reg=10.",
            "python_boundary": "Python prepares the distributed phase code before t0 and reads telemetry after t1. No clock signature, class decision, or answer is injected after initialization.",
            "treatment_rows": rows,
            "controls": controls,
            "summary": {
                "treatment_worlds": len(rows),
                "all_one_hot_exact": all(row["one_hot_exact"] for row in rows),
                "maximum_classes_exactly_enumerated": max(row["classes"] for row in rows),
                "usable_raw_symbol_bits_lower_bound": math.log2(195),
                "control_worlds": len(controls),
                "destroyed_state_retains_class": any(len(row["active_indices"]) == 1 and row["active_indices"][0] == row["input_class"] for row in controls if row["mode"] == "destroyed"),
                "sham_nonzero_produces_active": any(row["active_indices"] for row in controls if row["mode"] == "sham_nonzero"),
            },
            "runtime": runtime,
            "interpretation_guard": "The bank is a configured native phase decoder with a one-hot raw output. It does not learn the biases and does not yet decode sequence-generated distributed clocks.",
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R06_PHASE_DECODER_BANK.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
