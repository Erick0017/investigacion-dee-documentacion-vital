#!/usr/bin/env python3
"""Discovery: test whether a phase-decoded s_reg symbol affects later native dynamics."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import NativeWorld, WORK, add, load_kernel, pack, read, seal, write_json

TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))


def run(kernel, phase, incoming_sreg, horizon=6, n=23):
    q = (11, 11, 11)
    incoming_direction = (-1, 0, 0)
    source = add(q, incoming_direction, -2, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(1, 10, (0, 0, 0), 1)
    clock[q] = np.uint64(phase)
    for offset in TETRA:
        p = add(q, offset, 1, n)
        raw[p] = pack(1, 3, (0, 0, 0), 1)
        clock[p] = np.uint64(17)
    raw[source] = pack(0, incoming_sreg, incoming_direction, 4)
    clock[source] = np.uint64(31)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    for tick in range(1, horizon + 1):
        world.tick()
        nz = np.argwhere(world.raw != 0)
        trace.append(
            {
                "tick": tick,
                "center": read(world.raw, q),
                "support": int(len(nz)),
                "raw_sha256": hashlib.sha256(np.ascontiguousarray(world.raw).tobytes()).hexdigest(),
                "active": [
                    {"q": [int(x) for x in p], "record": read(world.raw, tuple(int(x) for x in p))}
                    for p in nz[:20]
                ],
            }
        )
    return {"phase": phase, "incoming_sreg": incoming_sreg, "trace": trace}


def main():
    kernel, runtime = load_kernel(1)
    pairs = []
    for incoming_sreg in (0, 1, 17, 101, 19653, 19654, 19664):
        active = run(kernel, 0, incoming_sreg)
        inactive = run(kernel, 1, incoming_sreg)
        first_diff = None
        for a, b in zip(active["trace"], inactive["trace"]):
            if a["raw_sha256"] != b["raw_sha256"]:
                first_diff = a["tick"]
                break
        pairs.append({"incoming_sreg": incoming_sreg, "phase0": active, "phase1": inactive, "first_raw_difference_tick": first_diff, "difference_survives_after_gate_tick": first_diff is not None and any(a["raw_sha256"] != b["raw_sha256"] for a, b in zip(active["trace"][1:], inactive["trace"][1:]))})
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.decoder_causal_output.discovery.v1",
            "pairs": pairs,
            "summary": {
                "payloads": len(pairs),
                "all_differ_at_gate": all(row["first_raw_difference_tick"] == 1 for row in pairs),
                "payloads_with_later_causal_difference": sum(row["difference_survives_after_gate_tick"] for row in pairs),
                "maximum_observed_difference_horizon": 6,
            },
            "runtime": runtime,
            "interpretation_guard": "Persistence of a raw difference is necessary but not sufficient for an action decoder; telemetry identifies whether the one-tick phase symbol enters later occupied-destination dynamics.",
        }
    )
    write_json(WORK / "DISCOVERY" / "R07_DECODER_CAUSAL_OUTPUT.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
