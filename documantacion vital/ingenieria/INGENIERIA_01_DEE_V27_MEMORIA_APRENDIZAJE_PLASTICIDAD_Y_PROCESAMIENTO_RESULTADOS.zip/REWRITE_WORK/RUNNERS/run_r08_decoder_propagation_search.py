#!/usr/bin/env python3
"""Search whether a directed phase gate transports its decoded s_reg difference."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import NativeWorld, WORK, add, load_kernel, pack, read, seal, write_json

TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))
DIRECTIONS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]


def trial(kernel, phase, direction, sreg, horizon=6, n=23):
    q = (11, 11, 11)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(1, sreg, direction, 1)
    clock[q] = np.uint64(phase)
    for offset in TETRA:
        p = add(q, offset, 1, n)
        raw[p] = pack(1, 3, (0, 0, 0), 1)
        clock[p] = np.uint64(17)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    for tick in range(1, horizon + 1):
        world.tick()
        raw_bytes = np.ascontiguousarray(world.raw).tobytes()
        trace.append(
            {
                "tick": tick,
                "raw_sha256": hashlib.sha256(raw_bytes).hexdigest(),
                "support": int(np.count_nonzero(world.raw)),
                "center": read(world.raw, q),
                "route": read(world.raw, add(q, direction, tick, n)),
            }
        )
    return trace


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for direction in DIRECTIONS:
        for sreg in (0, 1, 10, 101, 19663, 19664):
            a = trial(kernel, 0, direction, sreg)
            b = trial(kernel, 1, direction, sreg)
            different_ticks = [x["tick"] for x, y in zip(a, b) if x["raw_sha256"] != y["raw_sha256"]]
            rows.append(
                {
                    "direction": list(direction),
                    "initial_sreg": sreg,
                    "different_ticks": different_ticks,
                    "propagates_beyond_tick1": any(t > 1 for t in different_ticks),
                    "phase0": a,
                    "phase1": b,
                }
            )
    positives = [row for row in rows if row["propagates_beyond_tick1"]]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.decoder_propagation_search.v1",
            "rows": rows,
            "summary": {
                "cases": len(rows),
                "directions": len(DIRECTIONS),
                "propagating_cases": len(positives),
                "maximum_difference_tick": max((max(row["different_ticks"]) for row in rows if row["different_ticks"]), default=None),
            },
            "runtime": runtime,
            "interpretation_guard": "A propagating raw distinction is a causal carrier of the decoded phase; it is not automatically a learned action or general sequence decoder.",
        }
    )
    write_json(WORK / "DISCOVERY" / "R08_DECODER_PROPAGATION_SEARCH.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"], "examples": [{"direction": x["direction"], "sreg": x["initial_sreg"], "ticks": x["different_ticks"]} for x in positives[:8]]}, sort_keys=True))


if __name__ == "__main__":
    main()
