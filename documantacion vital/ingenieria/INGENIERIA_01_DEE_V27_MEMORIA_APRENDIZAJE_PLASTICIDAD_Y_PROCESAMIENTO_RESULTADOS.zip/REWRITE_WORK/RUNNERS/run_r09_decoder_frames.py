#!/usr/bin/env python3
"""Model selection across the 48 signed-permuted local frames."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from clock_decoder_apparatus_v1 import run_decoder_case
from rewrite_common import WORK, load_kernel, seal, write_json


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    frames = list(itertools.product(itertools.permutations(range(3)), itertools.product((-1, 1), repeat=3)))
    for i, (permutation, signs) in enumerate(frames):
        challenge = {
            "challenge_id": f"R09-{i:03d}",
            "mode": "treatment",
            "n": 31,
            "classes": 8,
            "input_class": i % 8,
            "origin": [(3 + 5 * i) % 31, (7 + 3 * i) % 31, (11 + 7 * i) % 31],
            "permutation": list(permutation),
            "signs": list(signs),
        }
        rows.append(run_decoder_case(kernel, challenge))
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.decoder_frames.model_selection.v1",
            "rows": rows,
            "summary": {
                "frames": len(rows),
                "gate_exact": sum(row["gate_one_hot_exact"] for row in rows),
                "routed_exact": sum(row["routed_one_hot_exact"] for row in rows),
                "directions_exact": sum(row["gate_directions_exact"] for row in rows),
            },
            "runtime": runtime,
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R09_DECODER_FRAMES.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
