#!/usr/bin/env python3
"""Discovery: answer-independent dual probes decode a distributed bit sequence."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import (
    A,
    ACTION0,
    ACTION1,
    B,
    PENALTY0,
    SENSOR,
    NativeWorld,
    WORK,
    add,
    load_kernel,
    pack,
    read,
    seal,
    write_json,
)


def place_arrival(raw, clock, target, tick, direction, state, sreg):
    n = raw.shape[0]
    source = add(target, direction, -tick, n)
    if int(raw[source]):
        raise RuntimeError(f"preloaded carrier overlap at {source}")
    raw[source] = pack(state, sreg, direction, 1)
    clock[source] = np.uint64(0)


def memory_coordinates(n, length):
    pts = [(8, 8 + 7 * j, 8) for j in range(length)]
    if any(max(q) >= n - 4 for q in pts):
        raise ValueError("N too small")
    return pts


def run_case(kernel, sequence, mode="treatment", n=71):
    coords = memory_coordinates(n, len(sequence))
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    metadata = []
    for i, (q, bit) in enumerate(zip(coords, sequence)):
        raw[q] = pack(1000 + i, 7 + i, A, 1)
        wq = add(q, A, 1, n)
        if bit and mode != "missing_writer":
            place_arrival(raw, clock, wq, 1, PENALTY0, 2000 + i, 31 + i)
        target_a = add(wq, A, 1, n)
        target_b = add(wq, B, 1, n)
        if mode != "missing_probes":
            place_arrival(raw, clock, target_a, 2, SENSOR, 3000 + 2 * i, 101 + i)
            place_arrival(raw, clock, target_b, 2, SENSOR, 3001 + 2 * i, 103 + i)
        metadata.append((wq, target_a, target_b, bit))
    world = NativeWorld(kernel, raw, clock, threads=1)
    world.tick()
    written = []
    for wq, _, _, bit in metadata:
        record = read(world.raw, wq)
        written.append(record is not None and tuple(record["direction"]) == (B if bit and mode != "missing_writer" else A))
    world.tick()
    decoded = []
    traces = []
    for wq, target_a, target_b, bit in metadata:
        rec_a = read(world.raw, target_a)
        rec_b = read(world.raw, target_b)
        hit0 = rec_a is not None and tuple(rec_a["direction"]) == ACTION0
        hit1 = rec_b is not None and tuple(rec_b["direction"]) == ACTION1
        symbol = 0 if hit0 and not hit1 else 1 if hit1 and not hit0 else -1
        decoded.append(symbol)
        traces.append({"write_site": list(wq), "target0": list(target_a), "target1": list(target_b), "record0": rec_a, "record1": rec_b, "decoded": symbol})
    exact = decoded == list(sequence) if mode == "treatment" else False
    return {
        "sequence": list(sequence),
        "length": len(sequence),
        "mode": mode,
        "written_exact": all(written),
        "decoded": decoded,
        "decoded_sha256": hashlib.sha256(bytes(max(0, x) for x in decoded)).hexdigest(),
        "exact": exact,
        "python_interventions_after_t0": 0,
        "traces": traces,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for length in range(1, 9):
        for sequence in itertools.product((0, 1), repeat=length):
            rows.append(run_case(kernel, sequence))
    controls = [
        run_case(kernel, (0, 1, 1, 0), "missing_probes"),
        run_case(kernel, (0, 1, 1, 0), "missing_writer"),
    ]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.distributed_sequence_decoder.discovery.v1",
            "apparatus": "Each ordinal position is an independent direction-coded memory. At t0 both possible sensor probes are preloaded, so Python does not choose a bit-conditioned read target. Kernel ticks write at t1 and produce the complete parallel action pattern at t2.",
            "rows": rows,
            "controls": controls,
            "summary": {
                "histories_enumerated": len(rows),
                "maximum_length_exhaustive": 8,
                "all_writes_exact": all(row["written_exact"] for row in rows),
                "all_full_sequences_decoded": all(row["exact"] for row in rows),
                "post_initialization_python_interventions": 0,
                "missing_probes_decodes": controls[0]["decoded"],
                "missing_writer_matches_original": controls[1]["decoded"] == controls[1]["sequence"],
            },
            "runtime": runtime,
            "interpretation_guard": "This is functional memory for an explicitly spatially addressed sequence, not temporal-order inference by one recurrent state and not a learned decoder.",
        }
    )
    write_json(WORK / "DISCOVERY" / "R11_DISTRIBUTED_SEQUENCE_DECODER.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
