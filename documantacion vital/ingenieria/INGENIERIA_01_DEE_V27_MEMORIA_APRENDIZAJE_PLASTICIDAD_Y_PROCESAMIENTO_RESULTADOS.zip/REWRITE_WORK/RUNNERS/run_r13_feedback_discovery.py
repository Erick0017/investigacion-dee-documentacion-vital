#!/usr/bin/env python3
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from feedback_apparatus_v1 import run_feedback_case
from rewrite_common import WORK, load_kernel, seal, write_json


def main():
    kernel, runtime = load_kernel(1)
    frames = list(itertools.product(itertools.permutations(range(3)), itertools.product((-1, 1), repeat=3)))
    treatments = []
    for i, (permutation, signs) in enumerate(frames):
        for bit in (0, 1):
            treatments.append(run_feedback_case(kernel, {"challenge_id": f"R13-T-{i}-{bit}", "mode": "treatment", "bit": bit, "n": (23, 29, 31)[i % 3], "q": [11, 12, 13], "permutation": list(permutation), "signs": list(signs)}))
    controls = []
    for i, mode in enumerate(("no_action", "no_penalty", "wrong_consequence")):
        controls.append(run_feedback_case(kernel, {"challenge_id": f"R13-C-{i}", "mode": mode, "bit": 1, "n": 31, "q": [15, 15, 15], "permutation": [0, 1, 2], "signs": [1, 1, 1]}))
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.feedback.discovery.v1",
            "treatments": treatments,
            "controls": controls,
            "summary": {
                "treatment_worlds": len(treatments),
                "all_end_to_end_exact": all(row["end_to_end_exact"] for row in treatments),
                "all_no_python_after_t0": all(row["python_interventions_after_t0"] == 0 for row in treatments),
                "controls_that_reproduce_bit1": sum(row["decoded"] == 1 for row in controls),
                "no_action_decoded": controls[0]["decoded"],
                "no_penalty_decoded": controls[1]["decoded"],
                "wrong_consequence_decoded": controls[2]["decoded"],
            },
            "runtime": runtime,
            "interpretation_guard": "This establishes a finite prepared L3 causal chain if controls exclude answer leakage. It is not reusable L4 adaptation: the policy and probes are consumed and the environmental rule is fixed at t0.",
        }
    )
    write_json(WORK / "DISCOVERY" / "R13_FEEDBACK_DISCOVERY.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
