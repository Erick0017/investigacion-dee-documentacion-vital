#!/usr/bin/env python3
"""Discriminating construction search for a persistent reusable adaptive loop."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import (
    A,
    ACTION1,
    B,
    PENALTY0,
    SENSOR,
    NativeWorld,
    WORK,
    add,
    inject_arrival,
    load_kernel,
    pack,
    read,
    seal,
    write_json,
)
from reset_apparatus_v1 import N1, N2, P, S1, S2


def semantic4_mutability(kernel, n=23):
    q = (11, 11, 11)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    initial = pack(1, 7, A, 4)
    raw[q] = initial
    world = NativeWorld(kernel, raw, clock, threads=1)
    inject_arrival(world, q, PENALTY0, 31, 2, 2)
    world.tick()
    record = read(world.raw, q)
    return {
        "attempt": "mutable persistent semantic4 policy",
        "initial_raw": int(initial),
        "after_training": record,
        "raw_invariant": int(world.raw[q]) == int(initial),
        "learned_B": record is not None and tuple(record["direction"]) == B,
        "mechanism": "CORE01 E8 fixes semantic4 raw pointwise; persistent emitters cannot acquire a direction policy by collision.",
    }


def ballistic_policy_query(kernel, n=29):
    q = (14, 14, 14)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(1, 7, A, 1)
    world = NativeWorld(kernel, raw, clock, threads=1)
    target = add(q, A, 1, n)
    inject_arrival(world, target, PENALTY0, 31, 10, 10)
    world.tick()
    learned_site = target
    learned = read(world.raw, learned_site)
    for _ in range(n):
        world.tick()
    returned = read(world.raw, learned_site)
    query_target = add(learned_site, B, 1, n)
    inject_arrival(world, query_target, SENSOR, 101, 20, 20)
    world.tick()
    action = read(world.raw, query_target)
    for _ in range(n):
        world.tick()
    b_count = 0
    for value in world.raw.ravel():
        if int(value):
            # direction bits are decoded only for the sparse surviving support.
            pass
    nz = np.argwhere(world.raw != 0)
    b_count = sum(1 for p in nz if tuple(read(world.raw, tuple(int(x) for x in p))["direction"]) == B)
    return {
        "attempt": "mutable ballistic carrier with torus return",
        "learned_B": learned is not None and tuple(learned["direction"]) == B,
        "returns_after_N": returned is not None and tuple(returned["direction"]) == B,
        "first_query_action1": action is not None and tuple(action["direction"]) == ACTION1,
        "B_carriers_after_query_plus_N": b_count,
        "policy_survives_functional_query": b_count > 0,
        "mechanism": "The mutable policy persists ballistically, but its functional sensor collision changes direction to ACTION1 and consumes the B policy.",
    }


def reset_feedback_overwrite(kernel, n=47, intervention_tick=10, horizon=18):
    q = (23, 23, 23)
    p, s1, s2, n1, n2 = P, S1, S2, N1, N2
    qp = add(q, p, 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(1, 7, p, 1)
    specs = [
        (add(qp, s1, -1, n), s1, 11),
        (add(qp, s2, -1, n), s2, 13),
        (add(q, n1, -2, n), n1, 17),
        (add(q, n2, -2, n), n2, 19),
    ]
    for i, (pos, direction, sreg) in enumerate(specs):
        raw[pos] = pack(2000 + i, sreg, direction, 4)
        clock[pos] = np.uint64(100000 + i)
    consequence = (-1, 1, 0)
    source = add(q, consequence, -intervention_tick, n)
    raw[source] = pack(3000, 23, consequence, 1)
    world = NativeWorld(kernel, raw, clock, threads=1)
    trace = []
    for tick in range(1, horizon + 1):
        world.tick()
        target = qp if tick % 2 else q
        record = read(world.raw, target)
        trace.append({"tick": tick, "nominal_target": list(target), "record": record, "support": int(np.count_nonzero(world.raw))})
    expected_at_intervention = B
    intervention_record = trace[intervention_tick - 1]["record"]
    restored = [row for row in trace[intervention_tick:] if row["record"] is not None and tuple(row["record"]["direction"]) == ((-1, 0, 0) if row["tick"] % 2 else p)]
    return {
        "attempt": "inject learned-state perturbation into source-replenished oscillator",
        "intervention_tick": intervention_tick,
        "intervention_record": intervention_record,
        "intervention_writes_B": intervention_record is not None and tuple(intervention_record["direction"]) == expected_at_intervention,
        "nominal_cycle_restored_later": bool(restored),
        "trace": trace,
        "mechanism": "Persistent writer sources reimpose the fixed oscillator grammar; a mutable perturbation does not become a persistent learned source policy.",
    }


def main():
    kernel, runtime = load_kernel(1)
    attempts = [semantic4_mutability(kernel), ballistic_policy_query(kernel), reset_feedback_overwrite(kernel)]
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.l4_prerequisite_search.v1",
            "attempts": attempts,
            "summary": {
                "causally_distinct_constructions": len(attempts),
                "semantic4_mutable": not attempts[0]["raw_invariant"],
                "mutable_policy_reusable_after_query": attempts[1]["policy_survives_functional_query"],
                "replenished_oscillator_retains_perturbation": attempts[2]["intervention_writes_B"] and not attempts[2]["nominal_cycle_restored_later"],
                "L4_constructed": False,
            },
            "cross_core_closure": {
                "persistent_replenishment": "semantic4 sources, but raw policy is immutable",
                "mutable_learning": "semantic1 direction, but functional read is destructive",
                "clock": "persistent phase differences, but E1 makes clocks autonomous and experience-unwritable",
                "regeneration": "canonical/local or trained-backup reconstruction; no endogenous learned-policy source",
                "identified_missing_coordinate": "a state that is simultaneously experience-writable, non-destructively readable or copyable, and natively replenishing",
            },
            "runtime": runtime,
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R15_L4_PREREQUISITE_SEARCH.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
