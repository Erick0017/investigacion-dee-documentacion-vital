#!/usr/bin/env python3
"""Exact/exhaustive construction of a 26-symbol direction policy alphabet."""
from __future__ import annotations

import itertools
import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from rewrite_common import NativeWorld, WORK, add, inject_arrival, load_kernel, read, seal, sign_sum, transform, write_json

DIRECTIONS = [d for d in itertools.product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]
FRAMES = list(itertools.product(itertools.permutations(range(3)), itertools.product((-1, 1), repeat=3)))


def pair_map():
    result = {}
    for target in DIRECTIONS:
        for d1, d2 in itertools.permutations(DIRECTIONS, 2):
            if sign_sum(d1, d2) == target:
                result[target] = (d1, d2)
                break
        if target not in result:
            raise RuntimeError(f"no pair for {target}")
    return result


def run_case(kernel, target, pair, frame, n, q):
    permutation, signs = frame
    target_f = transform(target, permutation, signs)
    d1, d2 = (transform(d, permutation, signs) for d in pair)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    world = NativeWorld(kernel, raw, clock, threads=1)
    inject_arrival(world, q, d1, 11, 1001, 2001)
    inject_arrival(world, q, d2, 17, 1002, 2002)
    world.tick()
    written = read(world.raw, q)
    world.tick()
    output = add(q, target_f, 1, n)
    routed = read(world.raw, output)
    return {
        "target_base": list(target),
        "target_frame": list(target_f),
        "writer_pair_base": [list(pair[0]), list(pair[1])],
        "write_record": written,
        "route_record": routed,
        "write_exact": written is not None and tuple(written["direction"]) == target_f,
        "route_exact": routed is not None and tuple(routed["direction"]) == target_f,
    }


def main():
    kernel, runtime = load_kernel(1)
    pairs = pair_map()
    rows = []
    for frame_index, frame in enumerate(FRAMES):
        n = (17, 23, 31)[frame_index % 3]
        q = ((3 + frame_index * 5) % n, (7 + frame_index * 3) % n, (11 + frame_index * 7) % n)
        for target in DIRECTIONS:
            row = run_case(kernel, target, pairs[target], frame, n, q)
            row["frame_index"] = frame_index
            rows.append(row)
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.multisymbol_policy.v1",
            "rows": rows,
            "summary": {
                "policy_symbols": 26,
                "functional_bits_log2": math.log2(26),
                "frames": len(FRAMES),
                "worlds": len(rows),
                "writes_exact": sum(row["write_exact"] for row in rows),
                "routes_exact": sum(row["route_exact"] for row in rows),
                "all_exact": all(row["write_exact"] and row["route_exact"] for row in rows),
            },
            "derivation": "CORE01 E10: direction'=sign(sum incoming directions) at an empty destination; CORE01 E9: an isolated nonzero direction routes one voxel per tick. The apparatus composes these exact sectors.",
            "scope": "Externally prepared supervised write with native reduction and native route readout; not a learned 26-way classifier.",
            "runtime": runtime,
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R16_MULTISYMBOL_POLICY.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
