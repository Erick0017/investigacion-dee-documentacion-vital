#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from distributed_sequence_apparatus_v1 import run_sequence_memory_case
from rewrite_common import WORK, load_kernel, seal, write_json


def main():
    kernel, runtime = load_kernel(1)
    rng = np.random.default_rng(2170001)
    rows = []
    for i, length in enumerate((8, 16, 32, 64, 128, 256, 512)):
        sequence = [int(x) for x in rng.integers(0, 2, size=length)]
        rows.append(run_sequence_memory_case(kernel, {"challenge_id": f"R17-{i}", "mode": "treatment", "n": 71, "sequence": sequence}))
    out = seal(
        {
            "schema": "dee.v27.ing01.rewrite.distributed_sequence_scaling.v1",
            "rows": rows,
            "summary": {
                "worlds": len(rows),
                "all_exact": all(row["full_sequence_exact"] for row in rows),
                "maximum_length_zero_error": max(row["length"] for row in rows if row["full_sequence_exact"]),
                "maximum_parallel_output_bits": max(row["length"] for row in rows),
                "latency_ticks": 2,
            },
            "runtime": runtime,
            "scope": "Spatially addressed parallel sequence code. This is a capacity lower bound, not a maximum and not recurrent temporal-order inference.",
        }
    )
    write_json(WORK / "MODEL_SELECTION" / "R17_SEQUENCE_SCALING.json", out)
    print(json.dumps({"hash": out["content_sha256"], **out["summary"]}, sort_keys=True))


if __name__ == "__main__":
    main()
