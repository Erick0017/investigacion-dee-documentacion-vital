#!/usr/bin/env python3
"""Independent final validation of the INGENIERIA 01 rewrite evidence."""
from __future__ import annotations

import ast
import hashlib
import json
import zipfile
from datetime import datetime, timezone
from pathlib import Path


HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = WORK.parent
BASELINE = WORK / "BASELINE_LOCKED" / "ING01_BASELINE_LOCKED.zip"
OFFICIAL = ROOT / "INGENIERIA_01_DEE_V27_MEMORIA_APRENDIZAJE_PLASTICIDAD_Y_PROCESAMIENTO_RESULTADOS.zip"
PARENT_REFS = ROOT / "PARENT_CORE_REFERENCES.json"
CORE_DIR = ROOT.parent.parent / "CORE"
EXPECTED_BASELINE_SHA = "2429bb1fb1895c8cf401f3bea82214e0732ef438156845a3f73c144f94b7f6e0"
EXPECTED_KERNEL_SHA = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"


def utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_content_hash(path: Path) -> dict:
    value = read_json(path)
    expected = value.get("content_sha256")
    if not expected:
        return {"path": path.relative_to(WORK).as_posix(), "status": "NO_CONTENT_HASH"}
    payload = dict(value)
    payload.pop("content_sha256", None)
    observed = canonical_hash(payload)
    return {
        "path": path.relative_to(WORK).as_posix(),
        "expected": expected,
        "observed": observed,
        "status": "PASS" if observed == expected else "FAIL",
    }


def validate_lock(lock_path: Path) -> dict:
    lock = read_json(lock_path)
    rows = []
    for frozen in lock.get("frozen_files", []):
        rel = Path(frozen["path"].replace("\\", "/"))
        candidate = WORK / rel
        observed = sha256_file(candidate) if candidate.exists() else None
        rows.append(
            {
                "path": rel.as_posix(),
                "expected": frozen["sha256"],
                "observed": observed,
                "status": "PASS" if observed == frozen["sha256"] else "FAIL",
            }
        )
    status = "PASS" if rows and all(row["status"] == "PASS" for row in rows) else "FAIL"
    if lock_path.name == "R03_RESET_HOLDOUT_LOCK.json" and status == "FAIL":
        amendment = read_json(WORK / "FREEZE" / "R03_FREEZE_AMENDMENT.json")
        amended = next((row for row in rows if row["path"] == "RUNNERS/reset_apparatus_v1.py"), None)
        other_rows = [row for row in rows if row is not amended]
        if (
            amended
            and amended["expected"] == amendment["pre_amendment_sha256"]
            and amended["observed"] == amendment["post_amendment_sha256"]
            and amendment["causal_apparatus_changed"] is False
            and all(row["status"] == "PASS" for row in other_rows)
        ):
            status = "PASS_WITH_DOCUMENTED_TELEMETRY_AMENDMENT"
    return {
        "lock": lock_path.relative_to(WORK).as_posix(),
        "content_sha256": lock.get("content_sha256"),
        "files": rows,
        "status": status,
    }


def main() -> None:
    failures: list[str] = []

    baseline_rows = []
    for path in (OFFICIAL, BASELINE):
        observed = sha256_file(path)
        status = "PASS" if observed == EXPECTED_BASELINE_SHA else "FAIL"
        baseline_rows.append({"path": str(path), "sha256": observed, "status": status})
        if status != "PASS":
            failures.append(f"baseline SHA mismatch: {path}")

    baseline_evidence_tokens: set[str] = set()
    with zipfile.ZipFile(BASELINE, "r") as archive:
        bad = archive.testzip()
        baseline_zip_integrity = "PASS" if bad is None else f"FAIL:{bad}"
        if bad is not None:
            failures.append(f"baseline ZIP CRC failure: {bad}")
        for name in archive.namelist():
            if name.endswith("/"):
                continue
            raw = archive.read(name)
            baseline_evidence_tokens.add(hashlib.sha256(raw).hexdigest())
            if name.lower().endswith(".json"):
                try:
                    value = json.loads(raw.decode("utf-8-sig"))
                except (UnicodeDecodeError, json.JSONDecodeError):
                    continue
                if isinstance(value, dict) and value.get("content_sha256"):
                    baseline_evidence_tokens.add(value["content_sha256"])

    hashed_json: list[dict] = []
    roots = [WORK]
    for folder in ("DISCOVERY", "MODEL_SELECTION", "FREEZE", "CHALLENGES", "HOLDOUT"):
        roots.append(WORK / folder)
    seen: set[Path] = set()
    for base in roots:
        candidates = base.glob("*.json") if base == WORK else base.rglob("*.json")
        for path in sorted(candidates):
            if path in seen:
                continue
            seen.add(path)
            row = validate_content_hash(path)
            hashed_json.append(row)
            if row["status"] == "FAIL":
                failures.append(f"canonical content hash mismatch: {path}")

    lock_rows = [validate_lock(path) for path in sorted((WORK / "FREEZE").glob("*LOCK.json"))]
    for row in lock_rows:
        if not row["status"].startswith("PASS"):
            failures.append(f"frozen runner mismatch: {row['lock']}")

    holdout_expectations = {
        "R03_RESET_HOLDOUT.json": False,
        "R04_RESET_CORRECTED_HOLDOUT.json": True,
        "R10_DECODER_HOLDOUT.json": True,
        "R14_FEEDBACK_HOLDOUT.json": True,
        "R18_SEQUENCE_HOLDOUT.json": True,
    }
    holdout_rows = []
    for name, expected_passed in holdout_expectations.items():
        result = read_json(WORK / "HOLDOUT" / name)
        observed = bool(result["summary"]["passed"])
        status = "PASS" if observed is expected_passed else "FAIL"
        holdout_rows.append(
            {"file": name, "expected_passed": expected_passed, "observed_passed": observed, "status": status}
        )
        if status != "PASS":
            failures.append(f"holdout adjudication mismatch: {name}")

    claims = read_json(WORK / "CLAIM_LEDGER.json")
    claim_rows = []
    for claim in claims.get("claims", []):
        evidence = claim.get("evidence", [])
        missing = []
        verified = []
        for item in evidence:
            if isinstance(item, str):
                if item in baseline_evidence_tokens:
                    verified.append({"baseline_evidence_token": item, "status": "PASS"})
                else:
                    missing.append(item)
                continue
            if not isinstance(item, dict) or "artifact" not in item:
                missing.append(repr(item))
                continue
            rel_path = Path(item["artifact"].replace("\\", "/"))
            candidate = ROOT / rel_path
            if not candidate.exists():
                missing.append(item["artifact"])
                continue
            observed_file = sha256_file(candidate)
            file_ok = observed_file == item.get("file_sha256")
            content_ok = True
            if item.get("content_sha256"):
                value = read_json(candidate)
                content_ok = value.get("content_sha256") == item["content_sha256"]
            verified.append(
                {
                    "artifact": item["artifact"],
                    "file_sha256": observed_file,
                    "file_hash_status": "PASS" if file_ok else "FAIL",
                    "content_hash_status": "PASS" if content_ok else "FAIL",
                }
            )
            if not file_ok or not content_ok:
                missing.append(item["artifact"] + "#HASH_MISMATCH")
        claim_rows.append(
            {"id": claim.get("id"), "evidence_count": len(evidence), "verified": verified, "missing": missing}
        )
        if missing:
            failures.append(f"claim evidence missing: {claim.get('id')}: {missing}")

    parent = read_json(PARENT_REFS)
    parent_rows = []
    for entry in parent.get("packages", []):
        candidate = CORE_DIR / entry["filename"]
        observed = sha256_file(candidate) if candidate.exists() else None
        status = "PASS" if observed == entry["sha256"] else "FAIL"
        parent_rows.append(
            {
                "filename": entry["filename"],
                "expected": entry["sha256"],
                "observed": observed,
                "status": status,
            }
        )
        if status != "PASS":
            failures.append(f"parent package mismatch: {entry['filename']}")

    python_rows = []
    scientific_patterns = ("run_*.py", "freeze_*.py", "generate_*.py", "*_apparatus_v1.py", "rewrite_common.py")
    python_files: set[Path] = set()
    for pattern in scientific_patterns:
        python_files.update(HERE.glob(pattern))
    for path in sorted(python_files):
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            status = "PASS"
            error = None
        except SyntaxError as exc:
            status = "FAIL"
            error = str(exc)
            failures.append(f"Python syntax failure: {path}: {exc}")
        python_rows.append({"path": path.relative_to(WORK).as_posix(), "status": status, "error": error})

    runtime_path = WORK / "HOLDOUT" / "R04_RESET_CORRECTED_HOLDOUT.json"
    runtime = read_json(runtime_path).get("runtime", {})
    observed_kernel = runtime.get("observed_hashes", {}).get("kernel")
    kernel_status = "PASS" if observed_kernel == EXPECTED_KERNEL_SHA else "FAIL"
    if kernel_status != "PASS":
        failures.append(f"kernel evidence mismatch in {runtime_path}: {observed_kernel}")

    validation = {
        "schema": "dee.v27.ing01.rewrite.science_validation.v1",
        "created_utc": utc(),
        "baseline": baseline_rows,
        "baseline_zip_integrity": baseline_zip_integrity,
        "canonical_json_hashes": hashed_json,
        "freeze_runner_hashes": lock_rows,
        "holdout_adjudications": holdout_rows,
        "claim_evidence": claim_rows,
        "parent_package_hashes": parent_rows,
        "python_syntax": python_rows,
        "kernel": {"expected": EXPECTED_KERNEL_SHA, "observed": observed_kernel, "status": kernel_status},
        "claim_count": len(claims.get("claims", [])),
        "failure_count": len(failures),
        "failures": failures,
        "overall": "PASS" if not failures else "FAIL",
    }
    payload = dict(validation)
    validation["content_sha256"] = canonical_hash(payload)
    output = WORK / "SCIENCE_VALIDATION.json"
    output.write_text(json.dumps(validation, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output), "overall": validation["overall"], "failures": failures}, indent=2))
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
