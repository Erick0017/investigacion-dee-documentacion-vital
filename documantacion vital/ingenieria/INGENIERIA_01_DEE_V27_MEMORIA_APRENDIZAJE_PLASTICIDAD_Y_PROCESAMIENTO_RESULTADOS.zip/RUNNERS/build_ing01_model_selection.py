#!/usr/bin/env python3
"""Select bounded engineering claims before freeze."""
from __future__ import annotations
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *

FILES=[
 "ING01_D01_NATIVE_CYCLE.json","ING01_D02_PLASTICITY_RETENTION.json","ING01_D03_CAPACITY_SCALING.json",
 "ING01_D04_SEQUENCE_HIDDEN.json","ING01_D05_CLOSED_PIPELINE.json","ING01_D06_POLICY_REPAIR_RESOURCE_SCALING.json",
 "ING01_D07_ROBUSTNESS_GENERALIZATION.json","ING01_D08_COMPOSITIONAL_PIPELINE.json",
 "ING01_D09_SEQUENCE_INFORMATION.json","ING01_D10_CLASSICAL_BASELINES.json",
]

def main():
    evidence={}
    for name in FILES:
        p=ROOT/"DISCOVERY"/name
        obj=json.loads(p.read_text(encoding="utf-8"));evidence[name]={"file_sha256":sha256_file(p),"content_sha256":obj["content_sha256"],"summary":obj.get("summary",obj.get("adjudication"))}
    selected=[
      {"id":"ING01-C01","claim":"A collision-written binary policy cycle is exact: two ticks for experience/consequence write and one tick for functional query; direction is the operational policy coordinate in this apparatus.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C02","claim":"Direct policy overwrite/reversal takes one tick, retains for at least 2048 isolated ticks, and same-site overwrite erases the previous direction unless copied elsewhere.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C03","claim":"Separated policy banks give zero-error lower bounds of 1000 stored bits and 343 simultaneous native reads at N=23; these are lower bounds, not maxima.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C04","claim":"A fully preloaded one-cycle sense-write-read-action pipeline runs without intermediate Python decisions, but destructive read and source depletion prevent a reusable closed loop.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C05","claim":"Source-supported learned-policy repair has the exact tested resource law: successful cycles equal intact trained backups with intact routes and correct converters; up to eight were demonstrated.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C06","claim":"Configured binary adapter stages compose natively through depth eight with two ticks per added stage.","status":"CANDIDATE_FOR_FRESH_CONFIRMATION"},
      {"id":"ING01-C07","claim":"The standard policy observer retains only the last symbol; full raw+clock retained every exhaustively tested sequence through length eight, but no general native decoder was constructed.","status":"EXACT_ENUMERATION_PLUS_BOUNDED_ACCESS_NULL"},
      {"id":"ING01-C08","claim":"On the matched one-bit association, DEE, lookup and a two-state FSM tie in accuracy/sample count; classical host execution is faster and no AI-transformer superiority claim is supported.","status":"NARROW_BENCHMARK"},
    ]
    rejected=[
      "general intelligence or reasoning", "autonomous indefinitely reusable learning loop", "autonomous full-sequence decoder",
      "unbounded capacity", "spontaneous regeneration", "transformer superiority", "arbitrary learned function composition",
    ]
    result=seal({"schema":"dee.v27.ing01.model_selection.v1","evidence":evidence,"selected_claims":selected,"rejected_promotions":rejected,"selection_rule":"simplest exact causal model; distinguish stored information from accessible function; distinguish lower bound from maximum; require post-freeze confirmation for promoted empirical claims"})
    write_json(ROOT/"MODEL_SELECTION"/"ING01_MODEL_SELECTION.json",result)
    append_ndjson(ROOT/"RESEARCH_DECISION_LOG.ndjson",{"decision_id":"INGD011","decision":"Freeze eight bounded claims and reject seven overclaims before generating fresh challenges.","result_hash":result["content_sha256"]})
    print({"hash":result["content_sha256"],"selected":len(selected),"rejected":len(rejected)})

if __name__=="__main__":main()
