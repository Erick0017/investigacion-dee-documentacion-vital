#!/usr/bin/env python3
"""Freeze apparatus, analysis, metrics and falsifiers before fresh worlds."""
from __future__ import annotations
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *

RUNNERS=[
 "ing01_common.py","ing01_apparatus.py","run_ing01_d01_native_cycle.py","run_ing01_d02_plasticity_retention.py",
 "run_ing01_d03_capacity_scaling.py","run_ing01_d04_sequence_hidden.py","run_ing01_d05_closed_pipeline.py",
 "run_ing01_d06_repair_resource_scaling.py","run_ing01_d07_robustness_generalization.py",
 "run_ing01_d08_compositional_pipeline.py","run_ing01_d09_sequence_information.py","run_ing01_d10_classical_baselines.py",
 "run_ing01_holdout.py",
]

def main():
    selection=ROOT/"MODEL_SELECTION"/"ING01_MODEL_SELECTION.json"
    if not selection.exists():raise RuntimeError("model selection missing")
    hashes={name:sha256_file(HERE/name) for name in RUNNERS}
    lock=seal({
      "schema":"dee.v27.ing01.freeze.v1","model_selection_file_sha256":sha256_file(selection),
      "kernel_sha256":EXPECTED_KERNEL_SHA,"wheel_sha256":EXPECTED_WHEEL_SHA,"runner_hashes":hashes,
      "fresh_protocol":{
        "challenge_generation":"OS entropy only after this lock exists",
        "native_cycle":"all treatment modes baseline/sreg_nuisance/payload_clock_nuisance exact; canaries missing_penalty(bit1), direction_reset, damage, wrong_query must fail",
        "plasticity":"all updates and fresh final queries exact; isolated retention exact at registered checks",
        "capacity":"step3 banks constructible with zero write/read errors; step2 storage zero write errors, read contention reported rather than excluded",
        "closed_pipeline":"fresh one-cycle pipelines exact and no Python after t0",
        "policy_repair":"successful cycles exactly equal registered expected intact backups",
        "composition":"all stages exact; terminal tick=3+2*depth",
        "sequence":"random fresh sequences length 9..16 answer last symbol exactly; no autonomous order claim",
      },
      "falsifier":"any treatment mismatch; any canary unexpectedly preserving target function; any mismatch of repair-resource count or composition latency",
      "analysis":"exact integer equality; no learned threshold and no excluded failed fresh world",
    })
    write_json(ROOT/"FREEZE"/"ING01_FINAL_LOCK.json",lock)
    write_json(ROOT/"HOLDOUT_REGISTRY.json",{"schema":"dee.v27.ing01.holdout_registry.v1","lock_content_sha256":lock["content_sha256"],"status":"LOCKED_AWAITING_OS_CHALLENGE","entries":[]})
    write_json(ROOT/"CANARY_REGISTRY.json",{"schema":"dee.v27.ing01.canary_registry.v1","lock_content_sha256":lock["content_sha256"],"canaries":[
      {"id":"CAN-DIRECTION-RESET","prerequisite":"learned direction coordinate","expected":"functional query fails"},
      {"id":"CAN-MISSING-WRITER","prerequisite":"penalty writer for bit1","expected":"bit1 query fails"},
      {"id":"CAN-DAMAGE","prerequisite":"stored carrier","expected":"query fails"},
      {"id":"CAN-WRONG-QUERY","prerequisite":"sensor interface","expected":"query fails"},
      {"id":"CAN-REPAIR-PATH","prerequisite":"intact carrier path","expected":"exactly one of four repairs lost"},
      {"id":"CAN-REPAIR-TRAINING","prerequisite":"trained backup","expected":"exactly one of four repairs lost"}
    ]})
    print({"lock_hash":lock["content_sha256"],"runners":len(hashes)})

if __name__=="__main__":main()
