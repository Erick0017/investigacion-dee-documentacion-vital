#!/usr/bin/env python3
"""Generate final challenge from OS entropy strictly after freeze."""
from __future__ import annotations
import json,random,secrets,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *

def main():
    lockp=ROOT/"FREEZE"/"ING01_FINAL_LOCK.json"
    if not lockp.exists():raise RuntimeError("freeze lock missing")
    lock=json.loads(lockp.read_text(encoding="utf-8"));seed=secrets.randbits(128);rng=random.Random(seed)
    frames=[{"permutation":list(p),"signs":list(s)} for p in __import__('itertools').permutations((0,1,2)) for s in __import__('itertools').product((-1,1),repeat=3)]
    pick=lambda:frames[rng.randrange(len(frames))]
    challenge=seal({
      "schema":"dee.v27.ing01.final_challenge.v1","lock_content_sha256":lock["content_sha256"],"os_entropy_seed_hex":f"{seed:032x}",
      "native_cycle":[{"seed":rng.randrange(2**31),"bit":rng.randrange(2),"n":rng.choice([12,14,16,18,21,25,27]),"frame":pick(),"mode":rng.choice(["baseline","sreg_nuisance","payload_clock_nuisance"])} for _ in range(24)],
      "native_canaries":[{"seed":rng.randrange(2**31),"bit":1,"n":rng.choice([14,18,25]),"frame":pick(),"mode":m} for m in ["missing_penalty","direction_reset","damage","wrong_query"] for _ in range(3)],
      "plasticity":[{"seed":rng.randrange(2**31),"n":rng.choice([12,14,16,18,21]),"frame":pick(),"cycles":rng.choice([17,33,65,97])} for _ in range(12)],
      "retention":[{"seed":rng.randrange(2**31),"n":rng.choice([12,14,18]),"frame":pick(),"horizon":rng.choice([1024,1536,3072])} for _ in range(6)],
      "capacity":[{"seed":rng.randrange(2**31),"n":n,"step":step} for n,step in [(13,3),(21,3),(25,3),(27,3),(13,2),(21,2),(25,2)]],
      "pipeline":[{"seed":rng.randrange(2**31),"bit":rng.randrange(2),"frame":pick(),"n":rng.choice([29,37,43])} for _ in range(16)],
      "repair":[{"seed":rng.randrange(2**31),"k":rng.choice([1,2,3,4,5,6,7,8]),"frame":pick(),"mode":rng.choice(["treatment","one_untrained","one_path_cut","one_wrong_converter","no_backups"])} for _ in range(16)],
      "composition":[{"seed":rng.randrange(2**31),"bit":rng.randrange(2),"depth":rng.choice([1,3,4,5,6,7]),"frame":pick(),"n":71} for _ in range(16)],
      "sequence":[{"sequence":[rng.randrange(2) for _ in range(length)]} for length in [rng.randrange(9,17) for _ in range(32)]],
    })
    write_json(ROOT/"CHALLENGES"/"ING01_FINAL_CHALLENGE.json",challenge)
    print({"challenge_hash":challenge["content_sha256"],"seed_hex":challenge["os_entropy_seed_hex"],"fresh_worlds":sum(len(challenge[k]) for k in ["native_cycle","native_canaries","plasticity","retention","capacity","pipeline","repair","composition","sequence"])})

if __name__=="__main__":main()
