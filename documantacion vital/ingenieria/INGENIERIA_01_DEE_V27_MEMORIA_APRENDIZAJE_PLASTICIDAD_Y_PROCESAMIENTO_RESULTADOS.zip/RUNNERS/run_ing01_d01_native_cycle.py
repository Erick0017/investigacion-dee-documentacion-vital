#!/usr/bin/env python3
"""Discover the exact minimal experience-change-persistence-query cycle."""
from __future__ import annotations
import itertools, math, sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from ing01_common import *
from ing01_apparatus import *


def all_frames():
    for p in itertools.permutations((0,1,2)):
        for s in itertools.product((-1,1),repeat=3): yield p,s


def reducer_pair(kernel,d1,d2,case):
    n=7; raw=np.zeros((n,n,n),np.uint64); clock=np.zeros_like(raw); world=NativeWorld(kernel,raw,clock,threads=1); target=(3,3,3)
    inject_arrival(world,target,d1,11,10000+case,20000+case); inject_arrival(world,target,d2,17,30000+case,40000+case); world.tick(); rec=read(world.raw,target); expected=sign_sum(d1,d2)
    return rec is not None and tuple(rec["direction"])==expected and rec["sreg"]==28 and rec["state"]==1 and rec["semantic"]==1


def main():
    kernel,runtime=load_kernel(1); rows=[]
    frames=list(all_frames())
    for i,(permutation,signs) in enumerate(frames):
        for bit in (0,1):
            rows.append(compact_learning_cycle(kernel,1800000+i*101+bit,bit,permutation=tuple(permutation),signs=tuple(signs),n=(11,13,17)[i%3]))
    dirs=[d for d in itertools.product((-1,0,1),repeat=3) if d!=(0,0,0)]
    constructible_pairs=[pair for pair in itertools.product(dirs,repeat=2) if pair[0]!=pair[1]]
    reducer_pass=0
    for i,(d1,d2) in enumerate(constructible_pairs): reducer_pass+=int(reducer_pair(kernel,d1,d2,i))
    summary={"frames":len(frames),"policy_cases":len(rows),"writes_correct":sum(r["write_correct"] for r in rows),"reads_correct":sum(r["read_correct"] for r in rows),"reducer_pairs":len(constructible_pairs),"reducer_pairs_exact":reducer_pass,"minimum_experience_consequence_write_ticks":2,"minimum_query_ticks":1,"one_consequence_update":True}
    result=seal({"schema":"dee.v27.ing01.native_learning_cycle.discovery.v1","rows":rows,"transition_grammar":{"empty_destination_multi_input":"state'=1; semantic'=1; s_reg'=min(sum s_reg,19664); direction'=sign(sum direction)","experience":"A + SENSOR -> ACTION0","consequence_bit1":"ACTION0 + NORMALIZER + PENALTY0 -> B","consequence_bit0":"ACTION0 + NORMALIZER -> A","query_bit1":"B + SENSOR -> ACTION1","query_bit0":"A + SENSOR -> ACTION0","external_orchestration":"Python schedules arrivals; all state transitions and readout collisions are native kernel events"},"summary":summary,"runtime":runtime})
    write_json(ROOT/"DISCOVERY"/"ING01_D01_NATIVE_CYCLE.json",result)
    append_ndjson(ROOT/"QUESTION_TREE.ndjson",{"question_id":"INGQ009","parent_question":"INGQ001","parent_result_hash":result["content_sha256"],"question":"Does the 2-tick write/1-tick read cycle survive post-freeze frames, N and nuisance payloads?","status":"OPEN","competing_hypotheses":["exact native grammar","discovery configuration artifact"]})
    append_ndjson(ROOT/"RESEARCH_DECISION_LOG.ndjson",{"decision_id":"INGD002","decision":"Promote to model selection then freeze if nuisance and timing tests isolate direction update","result_hash":result["content_sha256"],"summary":summary})
    print({"hash":result["content_sha256"],**summary})
    if summary["writes_correct"]!=len(rows) or summary["reads_correct"]!=len(rows) or reducer_pass!=len(constructible_pairs): raise SystemExit(2)


if __name__=="__main__": main()
