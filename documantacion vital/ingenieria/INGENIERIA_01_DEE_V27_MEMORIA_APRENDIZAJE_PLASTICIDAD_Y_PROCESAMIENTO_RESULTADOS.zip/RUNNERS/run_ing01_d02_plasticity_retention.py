#!/usr/bin/env python3
"""Direct write, reversal, reacquisition, retention and destruction boundaries."""
from __future__ import annotations
import itertools, sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent; sys.path.insert(0,str(HERE))
from ing01_common import *
from ing01_apparatus import *

REVERSE_A=(1,-1,0)


def all_frames():
    return list(itertools.product(list(itertools.permutations((0,1,2))),list(itertools.product((-1,1),repeat=3))))


def cycle_case(kernel,seed,frame,cycles=64,n=11):
    p,s=frame; rng=np.random.default_rng(seed); raw=np.zeros((n,n,n),np.uint64); clock=np.zeros_like(raw); world=NativeWorld(kernel,raw,clock,threads=1)
    a,b,penalty,reverse,sensor,action0,action1=(transform(v,p,s) for v in (A,B,PENALTY0,REVERSE_A,SENSOR,ACTION0,ACTION1))
    q=tuple(int(x) for x in rng.integers(2,n-2,size=3)); v=pack(4000+seed%10000,7,a,1); world.raw_a[q]=v;world.raw_b[q]=v
    trace=[]; current=q; direction=a
    for j in range(cycles):
        desired=b if j%2==0 else a; writer=penalty if desired==b else reverse
        current,rec=direct_overwrite_tick(world,current,direction,writer,31+j%7,100000+j,200000+j)
        ok=rec is not None and tuple(rec["direction"])==desired
        trace.append({"update":j+1,"desired":list(desired),"record":rec,"correct":ok}); direction=desired
    # A final one-tick query reads the last policy and consumes it into the action.
    query_target=add(current,direction,1,n); inject_arrival(world,query_target,sensor,101,300000+seed,400000+seed); world.tick(); query=read(world.raw,query_target); expected=action1 if direction==b else action0
    return {"seed":seed,"frame":{"permutation":list(p),"signs":list(s)},"cycles":cycles,"all_updates_correct":all(x["correct"] for x in trace),"trace":trace,"query":query,"query_correct":query is not None and tuple(query["direction"])==expected,"write_latency_ticks":1,"read_latency_ticks":1,"final_policy":list(direction)}


def retention_case(kernel,seed,frame,n,horizon):
    p,s=frame; rng=np.random.default_rng(seed); raw=np.zeros((n,n,n),np.uint64); world=NativeWorld(kernel,raw,np.zeros_like(raw),threads=1)
    a,b,penalty=(transform(v,p,s) for v in (A,B,PENALTY0)); q=tuple(int(x) for x in rng.integers(2,n-2,size=3)); v=pack(5000+seed%10000,17,a,1);world.raw_a[q]=v;world.raw_b[q]=v
    q,rec=direct_overwrite_tick(world,q,a,penalty,23,500000+seed,600000+seed); start_sreg=rec["sreg"]
    checks=[]; current=q
    for t in range(1,horizon+1):
        current=add(current,b,1,n); world.tick()
        if t in {1,2,7,31,127,511,horizon}:
            r=read(world.raw,current); checks.append({"delay":t,"coordinate":current,"record":r,"direction_ok":r is not None and tuple(r["direction"])==b,"sreg_ok":r is not None and r["sreg"]==start_sreg})
    return {"seed":seed,"n":n,"horizon":horizon,"checks":checks,"passed":all(c["direction_ok"] and c["sreg_ok"] for c in checks),"start_sreg":start_sreg}


def destruction_case(kernel,frame,n=11):
    p,s=frame; raw=np.zeros((n,n,n),np.uint64); world=NativeWorld(kernel,raw,np.zeros_like(raw),threads=1); a,b,penalty=(transform(v,p,s) for v in (A,B,PENALTY0)); q=(n//2,n//2,n//2);v=pack(1,19,a,1);world.raw_a[q]=v;world.raw_b[q]=v
    q,rec=direct_overwrite_tick(world,q,a,penalty,23,1,1); target=add(q,b,1,n); inject_arrival(world,target,tuple(-x for x in b),29,2,2);world.tick(); collision=read(world.raw,target);world.tick(); after=read(world.raw,target)
    return {"collision_record":collision,"direction_zero":collision is not None and tuple(collision["direction"])==(0,0,0),"raw_destroyed_next_tick":after is None,"interpretation":"policy raw destroyed after counter-collision plus zero-direction incumbent death; clock may remain as a separate hidden trace"}


def main():
    kernel,runtime=load_kernel(1); frames=all_frames(); cycles=[cycle_case(kernel,1810000+i*113,f,64,(11,13,17)[i%3]) for i,f in enumerate(frames)]
    ret=[]
    for i,f in enumerate(frames[::8]): ret.append(retention_case(kernel,1820000+i*173,f,(7,11,13)[i%3],2048))
    dest=[destruction_case(kernel,f,(11,13,17)[i%3]) for i,f in enumerate(frames[::8])]
    summary={"plasticity_frames":len(cycles),"total_overwrites":sum(x["cycles"] for x in cycles),"all_overwrites_correct":all(x["all_updates_correct"] for x in cycles),"all_final_queries_correct":all(x["query_correct"] for x in cycles),"direct_write_ticks":1,"experience_consequence_write_ticks":2,"retention_cases":len(ret),"retention_ticks_each":2048,"all_retained":all(x["passed"] for x in ret),"destruction_cases":len(dest),"all_destroyed":all(x["direction_zero"] and x["raw_destroyed_next_tick"] for x in dest)}
    result=seal({"schema":"dee.v27.ing01.plasticity_retention.discovery.v1","plasticity":cycles,"retention":ret,"destruction":dest,"summary":summary,"mechanism":{"acquisition":"A + PENALTY0 -> B in one collision","reversal":"B + (1,-1,0) -> A in one collision","reacquisition":"same as acquisition","forgetting":"overwrite is many-to-one and old direction is absent unless redundantly copied","retention":"isolated nonzero-direction semantic1 carrier preserves direction and s_reg while translating","destruction":"counter-direction collision yields zero direction; isolated zero-direction incumbent dies next tick"},"runtime":runtime})
    write_json(ROOT/"DISCOVERY"/"ING01_D02_PLASTICITY_RETENTION.json",result)
    append_ndjson(ROOT/"QUESTION_TREE.ndjson",{"question_id":"INGQ010","parent_question":"INGQ005","parent_result_hash":result["content_sha256"],"question":"Can separation/context prevent overwrite interference while capacity scales?","status":"OPEN"})
    append_ndjson(ROOT/"ENGINEERING_DECISION_LOG.ndjson",{"decision_id":"INGE002","decision":"Distinguish direct supervised write (1 tick) from experience-consequence write (2 ticks); classify same-site overwrite as catastrophic interference by design","result_hash":result["content_sha256"]})
    print({"hash":result["content_sha256"],**summary})
    if not all((summary["all_overwrites_correct"],summary["all_final_queries_correct"],summary["all_retained"],summary["all_destroyed"])): raise SystemExit(2)


if __name__=="__main__": main()
