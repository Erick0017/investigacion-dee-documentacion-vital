#!/usr/bin/env python3
"""Parallel binary policy bank, packing bound and contention boundary."""
from __future__ import annotations
import hashlib,itertools,math,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *
from ing01_apparatus import *


def bit_hash(bits): return hashlib.sha256(bytes(int(x) for x in bits)).hexdigest()


def coordinates(n,step):
    axis=list(range(1,n-3,step)); return [tuple(int(x) for x in q) for q in itertools.product(axis,repeat=3)]


def preflight(coords,n,bits):
    occupied=set(coords); writer_ports=[]; query_ports=[]; query_targets=[]
    for q,bit in zip(coords,bits):
        write_target=add(q,A,1,n)
        if bit: writer_ports.append(add(write_target,PENALTY0,-1,n))
        learned=B if bit else A; qt=add(write_target,learned,1,n); query_targets.append(qt); query_ports.append(add(qt,SENSOR,-1,n))
    def duplicate_count(xs): return len(xs)-len(set(xs))
    return {"writer_port_on_initial":sum(p in occupied for p in writer_ports),"writer_port_duplicates":duplicate_count(writer_ports),"query_port_duplicates":duplicate_count(query_ports),"query_target_duplicates":duplicate_count(query_targets),"query_port_on_written_state":"evaluated after write"}


def bank_case(kernel,seed,n,step):
    rng=np.random.default_rng(seed); coords=coordinates(n,step); bits=[int(x) for x in rng.integers(0,2,size=len(coords))]; pf=preflight(coords,n,bits)
    if pf["writer_port_on_initial"] or pf["writer_port_duplicates"] or pf["query_target_duplicates"]: return {"seed":seed,"n":n,"step":step,"memories":len(coords),"preflight":pf,"constructible":False}
    raw=np.zeros((n,n,n),np.uint64);world=NativeWorld(kernel,raw,np.zeros_like(raw),threads=1)
    for i,q in enumerate(coords): v=pack(100000+i,7+(i%17),A,1);world.raw_a[q]=v;world.raw_b[q]=v
    for i,(q,bit) in enumerate(zip(coords,bits)):
        if bit: inject_arrival(world,add(q,A,1,n),PENALTY0,31+(i%11),200000+i,300000+i)
    world.tick(); written=[]; states=[]
    for q,bit in zip(coords,bits):
        wq=add(q,A,1,n);r=read(world.raw,wq);states.append((wq,r));written.append(int(r is not None and tuple(r["direction"])==B))
    query_ports=set(); conflict_after=0
    for i,((wq,r),bit) in enumerate(zip(states,bits)):
        learned=B if bit else A; qt=add(wq,learned,1,n);port=add(qt,SENSOR,-1,n)
        if int(world.raw_a[port]) or port in query_ports: conflict_after+=1
        else: inject_arrival(world,qt,SENSOR,101+(i%13),400000+i,500000+i);query_ports.add(port)
    if conflict_after: return {"seed":seed,"n":n,"step":step,"memories":len(coords),"preflight":pf,"constructible":False,"storage_write_constructible":True,"write_errors":sum(a!=b for a,b in zip(bits,written)),"input_bits":bits,"written_bits":written,"input_sha256":bit_hash(bits),"written_sha256":bit_hash(written),"query_conflicts_after_write":conflict_after}
    world.tick(); observed=[]
    for (wq,_),bit in zip(states,bits):
        learned=B if bit else A;qt=add(wq,learned,1,n);r=read(world.raw,qt);observed.append(1 if r is not None and tuple(r["direction"])==ACTION1 else 0 if r is not None and tuple(r["direction"])==ACTION0 else -1)
    errors=sum(a!=b for a,b in zip(bits,observed))
    return {"seed":seed,"n":n,"step":step,"memories":len(coords),"constructible":True,"preflight":pf,"input_bits":bits,"observed_bits":observed,"input_sha256":bit_hash(bits),"observed_sha256":bit_hash([max(0,x) for x in observed]),"write_errors":sum(a!=b for a,b in zip(bits,written)),"read_errors":errors,"accuracy":1-errors/max(1,len(bits)),"ticks_write":1,"ticks_read":1,"auxiliary_arrivals":sum(bits)+len(bits)}


def main():
    kernel,runtime=load_kernel(1); rows=[bank_case(kernel,1830000+i*1009,n,3) for i,n in enumerate((9,11,15,19,23))]
    step2=[bank_case(kernel,1850000+i*1013,n,2) for i,n in enumerate((9,11,15,19,23))]
    dense=[]
    for i,n in enumerate((9,11,15)):
        rng=np.random.default_rng(1840000+i);coords=coordinates(n,1);bits=[int(x) for x in rng.integers(0,2,size=len(coords))];dense.append({"n":n,"step":1,"candidate_memories":len(coords),"preflight":preflight(coords,n,bits),"constructible":False,"reason":"writer ports overlap occupied memory sites in the tested full-density lattice"})
    summary={"scaling_cases":len(rows),"all_step3_constructible":all(r["constructible"] for r in rows),"all_zero_error":all(r.get("read_errors")==0 and r.get("write_errors")==0 for r in rows),"largest_n":rows[-1]["n"],"largest_simultaneous_native_read_bits":rows[-1]["memories"],"largest_simultaneous_accuracy":rows[-1]["accuracy"],"largest_written_bits_before_read_contention":step2[-1]["memories"],"largest_step2_write_errors":step2[-1]["write_errors"],"largest_step2_query_port_conflicts":step2[-1].get("query_conflicts_after_write",0),"tested_parallel_read_lower_bound":"coordinates range(1,N-3,3), approximately N^3/27 bits","tested_storage_lower_bound":"coordinates range(1,N-3,2), 1000 zero-error writes at N=23; simultaneous read has contention","single_carrier_direction_classes":26,"single_carrier_direction_capacity_bits":math.log2(26),"single_carrier_direction_sreg_classes":26*19665,"direct_observer_capacity_bits_direction_plus_sreg":math.log2(26*19665),"upper_bound_not_achieved":"N^3 binary cells before auxiliary routing constraints"}
    result=seal({"schema":"dee.v27.ing01.memory_capacity.discovery.v1","parallel_read_banks_step3":rows,"storage_and_read_contention_step2":step2,"dense_contention_step1":dense,"summary":summary,"interpretation":{"independent_context":"spatial address/fiber separation","catastrophic_interference":"same-site sequential writes are last-write-wins (ING01_D02)","native_mitigation":"separate spatial addresses; no learned anti-forgetting mechanism demonstrated","not_maximum":"1000 stored bits and 343 simultaneous native reads are tested lower bounds, not global maxima for N=23"},"runtime":runtime})
    write_json(ROOT/"DISCOVERY"/"ING01_D03_CAPACITY_SCALING.json",result)
    append_ndjson(ROOT/"QUESTION_TREE.ndjson",{"question_id":"INGQ011","parent_question":"INGQ004","parent_result_hash":result["content_sha256"],"question":"Does the step-2 bank and exact zero-error scaling survive fresh patterns/geometries after freeze?","status":"OPEN"})
    append_ndjson(ROOT/"ENGINEERING_DECISION_LOG.ndjson",{"decision_id":"INGE003","decision":"Separate storage lower bound (1000 bits) from collision-free simultaneous native read lower bound (343 bits) at N=23; do not call either maximum","result_hash":result["content_sha256"]})
    print({"hash":result["content_sha256"],**summary})
    if not summary["all_step3_constructible"] or not summary["all_zero_error"] or summary["largest_step2_write_errors"]!=0: raise SystemExit(2)


if __name__=="__main__":main()
