#!/usr/bin/env python3
"""Sequence processing: visible last-state memory and recoverable distributed clock trace."""
from __future__ import annotations
import hashlib,itertools,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *
from ing01_apparatus import *

TETRA=((1,0,0),(0,1,0),(0,0,1),(1,1,1))


def array_sha(a): return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def run_sequence(kernel,sequence,n=31,query=False):
    raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);world=NativeWorld(kernel,raw,clock,threads=1);q=(n//2,n//2,n//2);v=pack(1,7,A,1);world.raw_a[q]=v;world.raw_b[q]=v;current=A;pos=q;trace=[]
    for t,bit in enumerate(sequence,1):
        desired=B if bit else A;target=add(pos,current,1,n)
        if desired!=current:
            writer=PENALTY0 if desired==B else (1,-1,0);inject_arrival(world,target,writer,11,1000+t,100+t)
        world.tick();rec=read(world.raw,target);trace.append({"t":t,"input_bit":bit,"coordinate":target,"record":rec});pos=target;current=desired
    query_record=None
    if query:
        target=add(pos,current,1,n);inject_arrival(world,target,SENSOR,101,9999,9999);world.tick();query_record=read(world.raw,target)
    return {"sequence":list(sequence),"position":pos,"record":read(world.raw,pos) if not query else None,"raw":world.raw.copy(),"clock":world.clock_a.copy(),"trace":trace,"query":query_record,"last_bit":int(sequence[-1])}


def resurrect_order(kernel,a,b):
    diffs=np.argwhere((a["clock"]%np.uint64(195))!=(b["clock"]%np.uint64(195)))
    if len(diffs)==0:return {"eligible":False}
    q=tuple(int(x) for x in diffs[0]);ca=a["clock"].copy();cb=b["clock"].copy();n=ca.shape[0];raw=np.zeros_like(ca);raw[q]=pack(777,10,(0,0,0),4)
    wa=NativeWorld(kernel,raw,ca,threads=1);wb=NativeWorld(kernel,raw,cb,threads=1);delay=(-int(wa.clock_a[q]))%195
    for _ in range(delay):wa.tick();wb.tick()
    for w in (wa,wb):
        w.raw_a[q]=w.raw_b[q]=pack(1,10,(0,0,0),1)
        for d in TETRA:
            p=add(q,d,1,n);v=pack(1,3,(0,0,0),1);w.raw_a[p]=w.raw_b[p]=v
    pre_raw_equal=bool(np.array_equal(wa.raw,wb.raw));wa.tick();wb.tick();ra=read(wa.raw,q);rb=read(wb.raw,q)
    return {"eligible":True,"selected_coordinate":q,"pre_clock_phases":[int(a["clock"][q]%195),int(b["clock"][q]%195)],"coast_delay":delay,"pre_readout_raw_equal":pre_raw_equal,"a":ra,"b":rb,"raw_different_after_readout":int(wa.raw[q])!=int(wb.raw[q])}


def main():
    kernel,runtime=load_kernel(1);variable=[]
    rng=np.random.default_rng(1860000)
    for length in (1,2,4,8,16,32,64):
        for j in range(8):
            seq=[int(x) for x in rng.integers(0,2,size=length)];r=run_sequence(kernel,seq,n=71,query=True);expected=ACTION1 if seq[-1] else ACTION0;r["query_correct"]=r["query"] is not None and tuple(r["query"]["direction"])==expected;del r["raw"];del r["clock"];variable.append(r)
    candidates=[];groups={}
    for seq in itertools.product((0,1),repeat=6):
        r=run_sequence(kernel,seq,n=31,query=False);key=(r["position"],int(r["raw"][r["position"]]));groups.setdefault(key,[]).append(r)
    pair=None
    for rs in groups.values():
        if len(rs)>1:
            for a,b in itertools.combinations(rs,2):
                if a["sequence"]!=b["sequence"] and np.array_equal(a["raw"],b["raw"]) and np.any((a["clock"]%195)!=(b["clock"]%195)):
                    pair=(a,b);break
            if pair:break
    if pair is None:raise RuntimeError("no sequence collision with recoverable clock trace")
    a,b=pair;qa=run_sequence(kernel,a["sequence"],31,True);qb=run_sequence(kernel,b["sequence"],31,True);local_same=qa["query"]==qb["query"]
    resurrection=resurrect_order(kernel,a,b)
    pair_summary={"sequence_a":a["sequence"],"sequence_b":b["sequence"],"same_final_position":a["position"]==b["position"],"same_full_raw_world":bool(np.array_equal(a["raw"],b["raw"])),"clock_mismatches":int(np.count_nonzero(a["clock"]!=b["clock"])),"same_standard_query":local_same,"raw_sha256":array_sha(a["raw"]),"clock_a_sha256":array_sha(a["clock"]),"clock_b_sha256":array_sha(b["clock"]),"special_clock_readout":resurrection}
    summary={"variable_length_cases":len(variable),"max_sequence_length":64,"all_last_symbol_queries_correct":all(x["query_correct"] for x in variable),"same_raw_order_collision_found":True,"standard_observer_distinguishes_order":not local_same,"distributed_clock_trace_differs":pair_summary["clock_mismatches"]>0,"special_readout_recovers_difference":resurrection.get("raw_different_after_readout",False)}
    result=seal({"schema":"dee.v27.ing01.sequence_processing.discovery.v1","variable_length":variable,"order_collision":pair_summary,"summary":summary,"interpretation":{"native_visible_memory":"one-step policy; standard query returns last symbol","sequence_order":"not retained in the local raw policy for the collision pair","distributed_history":"different event order leaves a clock trace although raw world converges","recovery":"an externally selected period-sensitive readout can make the hidden trace causal again","autonomy_limit":"the special readout uses omniscient coordinate selection and is not an autonomous native sequence classifier"},"runtime":runtime})
    write_json(ROOT/"DISCOVERY"/"ING01_D04_SEQUENCE_HIDDEN.json",result)
    append_ndjson(ROOT/"QUESTION_TREE.ndjson",{"question_id":"INGQ012","parent_question":"INGQ006","parent_result_hash":result["content_sha256"],"question":"Can the clock-trace order readout be addressed without omniscient Python selection?","status":"OPEN","competing_hypotheses":["constructible native order detector","hidden trace accessible only to configured coordinate-specific gate"]})
    append_ndjson(ROOT/"ENGINEERING_DECISION_LOG.ndjson",{"decision_id":"INGE004","decision":"Classify sequence ability as last-symbol finite-state processing plus distributed recoverable clock trace; do not claim autonomous order learning","result_hash":result["content_sha256"]})
    print({"hash":result["content_sha256"],**summary,"pair":[a["sequence"],b["sequence"]]})
    if not all((summary["all_last_symbol_queries_correct"],summary["same_raw_order_collision_found"],summary["distributed_clock_trace_differs"],summary["special_readout_recovers_difference"])):raise SystemExit(2)


if __name__=="__main__":main()
