#!/usr/bin/env python3
"""Resource law for repeated learned-policy reconstruction.

Each native backup is learned in situ.  A distinct carrier route consumes one
backup to rebuild the policy at a receiver; a fresh functional query then
consumes the rebuilt policy.  The experiment measures whether usable cycles
are exactly limited by intact trained backups.
"""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing01_common import *
from ing01_apparatus import *
sys.path.insert(0, str(BASE_RUNNERS))
from core10_apparatus import inject_arrival, neg, summarize_world  # noqa:E402


ROUTE_BASES = [
    (-1, 0, -1), (-1, 0, 0), (-1, 0, 1), (0, 0, -1),
    (0, 0, 1), (1, 0, -1), (1, 0, 0), (1, 0, 1),
]
FRAMES = [
    ((0, 1, 2), (1, 1, 1)),
    ((1, 2, 0), (1, -1, 1)),
    ((2, 0, 1), (-1, 1, 1)),
    ((0, 2, 1), (-1, -1, 1)),
]


def run_case(kernel, seed, k, frame, mode="treatment", n=29):
    permutation, signs = frame
    a, b, sensor, normalizer, penalty, action1 = (
        transform(v, permutation, signs)
        for v in (A, B, SENSOR, NORMALIZER, PENALTY0, ACTION1)
    )
    receiver = (n // 2, n // 2, n // 2)
    routes = [transform(v, permutation, signs) for v in ROUTE_BASES[:k]]
    # relay + B = route (componentwise sign reducer); canonical relay y=-1.
    relays = [transform((r[0], -1, r[2]), permutation, signs) for r in ROUTE_BASES[:k]]
    distances = [3 + i for i in range(k)]
    sources = [add(receiver, routes[i], -distances[i], n) for i in range(k)]
    if len(set(sources)) != k:
        raise RuntimeError("source geometry collision")

    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    world = NativeWorld(kernel, raw, clock, threads=1)
    for i, source in enumerate(sources):
        rv = pack(100000 + seed + i, 7 + i, a, 1)
        world.raw_a[source] = rv; world.raw_b[source] = rv
        world.clock_a[source] = np.uint64(200000 + seed + i)
        world.clock_b[source] = world.clock_a[source]

    learn1, learn2 = n, 2 * n
    launch_ticks = [(3 + 3 * i) * n for i in range(k)]
    arrival_ticks = [launch_ticks[i] + distances[i] for i in range(k)]
    query_ticks = [arrival_ticks[i] + n for i in range(k)]
    final_tick = query_ticks[-1]
    queries = []
    arrivals = []
    source_after_learning = []

    damaged_index = 0
    for current in range(final_tick):
        tick = current + 1
        if tick == learn1:
            for i, source in enumerate(sources):
                inject_arrival(world, source, sensor, 47 + i, 300000 + seed + i, 400000 + seed + i)
        if tick == learn2:
            for i, source in enumerate(sources):
                inject_arrival(world, source, normalizer, 53 + i, 500000 + seed + i, 600000 + seed + i)
                if not (mode == "one_untrained" and i == damaged_index):
                    inject_arrival(world, source, penalty, 59 + i, 700000 + seed + i, 800000 + seed + i)
        for i in range(k):
            if tick == launch_ticks[i] and mode != "no_backups":
                inject_arrival(world, sources[i], relays[i], 67 + i, 900000 + seed + i, 1000000 + seed + i)
            if tick == launch_ticks[i] + max(2, distances[i] // 2) and mode == "one_path_cut" and i == damaged_index:
                cut = add(sources[i], routes[i], max(2, distances[i] // 2), n)
                inject_arrival(world, cut, neg(routes[i]), 73, 1100000 + seed, 1200000 + seed)
            if tick == arrival_ticks[i] and mode != "no_backups":
                converter = neg(relays[i])
                if mode == "one_wrong_converter" and i == damaged_index:
                    converter = neg(b)
                inject_arrival(world, receiver, converter, 79 + i, 1300000 + seed + i, 1400000 + seed + i)
            if tick == query_ticks[i]:
                inject_arrival(world, receiver, sensor, 101 + i, 1500000 + seed + i, 1600000 + seed + i)
        world.tick()
        if tick == learn2:
            source_after_learning = [read(world.raw, s) for s in sources]
        for i in range(k):
            if tick == arrival_ticks[i]:
                arrivals.append({"index": i, "tick": tick, "record": read(world.raw, receiver)})
            if tick == query_ticks[i]:
                rec = read(world.raw, receiver)
                queries.append({
                    "index": i, "tick": tick, "record": rec,
                    "functional": rec is not None and tuple(rec["direction"]) == action1,
                })
                # Standardized post-query damage.  The query creates an action
                # carrier at the receiver; removing it isolates the next repair
                # from cross-cycle carrier interference and explicitly models
                # loss of the just-used receiver function.
                world.raw_a[receiver] = np.uint64(0); world.raw_b[receiver] = np.uint64(0)
                world.clock_a[receiver] = np.uint64(0); world.clock_b[receiver] = np.uint64(0)

    successes = sum(int(q["functional"]) for q in queries)
    expected = 0 if mode == "no_backups" else k - (1 if mode != "treatment" else 0)
    return {
        "seed": seed, "k": k, "mode": mode, "n": n,
        "frame": {"permutation": list(permutation), "signs": list(signs)},
        "geometry": {"receiver": receiver, "sources": sources, "routes": routes, "relays": relays, "distances": distances},
        "ticks": {"learn1": learn1, "learn2": learn2, "launch": launch_ticks, "arrival": arrival_ticks, "query": query_ticks},
        "source_after_learning": source_after_learning,
        "arrivals": arrivals, "queries": queries,
        "successful_cycles": successes, "expected_successful_cycles": expected,
        "resource_law_exact": successes == expected,
        "all_sources_depleted": all(read(world.raw, s) is None for s in sources),
        "final": summarize_world(world),
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for fi, frame in enumerate(FRAMES):
        for k in (1, 2, 4, 8):
            rows.append(run_case(kernel, 1880000 + fi * 1009 + k * 31, k, frame, "treatment"))
    for fi, frame in enumerate(FRAMES):
        for mi, mode in enumerate(("one_untrained", "one_path_cut", "one_wrong_converter", "no_backups")):
            rows.append(run_case(kernel, 1890000 + fi * 1009 + mi * 37, 4, frame, mode))
    treatments = [r for r in rows if r["mode"] == "treatment"]
    controls = [r for r in rows if r["mode"] != "treatment"]
    summary = {
        "executions": len(rows),
        "treatment_executions": len(treatments),
        "control_executions": len(controls),
        "treatment_resource_law_all": all(r["resource_law_exact"] for r in treatments),
        "control_resource_law_all": all(r["resource_law_exact"] for r in controls),
        "maximum_demonstrated_sequential_repairs": max(r["successful_cycles"] for r in treatments),
        "maximum_tested_backups": max(r["k"] for r in treatments),
        "law": "fresh functional cycles = intact trained backups with intact route and correct receiver converter",
    }
    result = seal({
        "schema": "dee.v27.ing01.policy_repair_resource_scaling.discovery.v1",
        "rows": rows, "summary": summary, "runtime": runtime,
        "interpretation_guard": "Each repair consumes a trained backup and carrier path. This is finite source-supported functional restoration, not spontaneous local healing or an indefinitely reusable loop.",
    })
    write_json(ROOT / "DISCOVERY" / "ING01_D06_POLICY_REPAIR_RESOURCE_SCALING.json", result)
    append_ndjson(ROOT / "QUESTION_TREE.ndjson", {
        "question_id": "INGQ014", "parent_question": "INGQ013", "parent_result_hash": result["content_sha256"],
        "question": "Does the finite backup-count law survive a preregistered fresh holdout?", "status": "OPEN",
    })
    append_ndjson(ROOT / "RESEARCH_DECISION_LOG.ndjson", {
        "decision_id": "INGD006", "result_hash": result["content_sha256"],
        "decision": "Treat redundant learned copies as a consumable repair resource; do not call the process autonomous regeneration.",
    })
    print({"hash": result["content_sha256"], **summary})
    if not summary["treatment_resource_law_all"] or not summary["control_resource_law_all"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
