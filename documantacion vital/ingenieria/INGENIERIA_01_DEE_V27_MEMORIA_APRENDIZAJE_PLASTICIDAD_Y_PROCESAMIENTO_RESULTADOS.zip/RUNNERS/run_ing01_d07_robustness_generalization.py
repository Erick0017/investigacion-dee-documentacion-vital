#!/usr/bin/env python3
"""Structural generalization and causal robustness of the binary policy cycle."""
from __future__ import annotations

import itertools
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing01_common import *
from ing01_apparatus import *


def frames():
    return list(itertools.product(itertools.permutations((0, 1, 2)), itertools.product((-1, 1), repeat=3)))


def case(kernel, seed, bit, frame, n, mode):
    p, s = frame
    a, b, sensor, normalizer, penalty, action0, action1 = (
        transform(v, p, s) for v in (A, B, SENSOR, NORMALIZER, PENALTY0, ACTION0, ACTION1)
    )
    rng = np.random.default_rng(seed)
    q = tuple(int(x) for x in rng.integers(0, n, size=3))
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    initial_sreg = 19664 if mode == "sreg_nuisance" else 7
    initial_state = 0x5A5A0000 + seed % 65521 if mode == "payload_clock_nuisance" else 1000 + seed % 100000
    initial_clock = 0xABC00000 + seed if mode == "payload_clock_nuisance" else 2000 + seed
    rv = pack(initial_state, initial_sreg, a, 1)
    raw[q] = rv; clock[q] = np.uint64(initial_clock)
    world = NativeWorld(kernel, raw, clock, threads=1)

    t1 = add(q, a, 1, n)
    sensor_sreg = 19664 if mode == "sreg_nuisance" else 47
    sensor_state = 0x33330000 + seed if mode == "payload_clock_nuisance" else 3000 + seed
    sensor_clock = 0x77770000 + seed if mode == "payload_clock_nuisance" else 4000 + seed
    inject_arrival(world, t1, sensor, sensor_sreg, sensor_state, sensor_clock)
    world.tick(); r1 = read(world.raw, t1)
    t2 = add(t1, action0, 1, n)
    inject_arrival(world, t2, normalizer, 19664 if mode == "sreg_nuisance" else 53, 5000 + seed, 6000 + seed)
    if bit and mode != "missing_penalty":
        inject_arrival(world, t2, penalty, 19664 if mode == "sreg_nuisance" else 59, 7000 + seed, 8000 + seed)
    world.tick(); r2 = read(world.raw, t2)
    learned = b if bit else a
    if mode == "direction_reset" and r2 is not None:
        replacement = pack(r2["state"], r2["sreg"], a if bit else b, r2["semantic"])
        world.raw_a[t2] = replacement; world.raw_b[t2] = replacement
        learned_for_path = a if bit else b
    else:
        learned_for_path = learned
    if mode == "damage":
        world.raw_a[t2] = np.uint64(0); world.raw_b[t2] = np.uint64(0)
        world.clock_a[t2] = np.uint64(0); world.clock_b[t2] = np.uint64(0)
    t3 = add(t2, learned_for_path, 1, n)
    query_direction = sensor if mode != "wrong_query" else normalizer
    inject_arrival(world, t3, query_direction, 19664 if mode == "sreg_nuisance" else 101, 9000 + seed, 10000 + seed)
    world.tick(); rq = read(world.raw, t3)
    expected = action1 if bit else action0
    success = rq is not None and tuple(rq["direction"]) == expected
    return {
        "seed": seed, "bit": bit, "n": n, "mode": mode,
        "frame": {"permutation": list(p), "signs": list(s)}, "q": q,
        "after_experience": r1, "after_write": r2, "query": rq,
        "success": success,
    }


def main():
    kernel, runtime = load_kernel(1)
    modes = ["baseline", "sreg_nuisance", "payload_clock_nuisance", "missing_penalty", "direction_reset", "damage", "wrong_query"]
    rows = []
    fs = frames()
    for i, frame in enumerate(fs):
        n = (9, 10, 11, 17, 23, 29)[i % 6]
        for bit in (0, 1):
            for mi, mode in enumerate(modes):
                rows.append(case(kernel, 1900000 + i * 1009 + bit * 101 + mi, bit, frame, n, mode))
    by_mode = {m: [r for r in rows if r["mode"] == m] for m in modes}
    summary = {
        "executions": len(rows), "frames": len(fs), "world_sizes": [9, 10, 11, 17, 23, 29],
        "baseline_all": all(r["success"] for r in by_mode["baseline"]),
        "sreg_nuisance_all": all(r["success"] for r in by_mode["sreg_nuisance"]),
        "payload_clock_nuisance_all": all(r["success"] for r in by_mode["payload_clock_nuisance"]),
        "missing_penalty_bit1_none": not any(r["success"] for r in by_mode["missing_penalty"] if r["bit"] == 1),
        "missing_penalty_bit0_all": all(r["success"] for r in by_mode["missing_penalty"] if r["bit"] == 0),
        "direction_reset_none": not any(r["success"] for r in by_mode["direction_reset"]),
        "damage_none": not any(r["success"] for r in by_mode["damage"]),
        "wrong_query_none": not any(r["success"] for r in by_mode["wrong_query"]),
    }
    result = seal({
        "schema": "dee.v27.ing01.robustness_generalization.discovery.v1",
        "rows": rows, "summary": summary, "runtime": runtime,
        "interpretation": {
            "generalization": "Exact signed-permutation equivariance, tested N transfer and coordinate transfer; this is structural rule reuse, not induction of an unseen abstract rule.",
            "robust": ["s_reg nuisance including saturation", "payload/state nuisance", "clock nuisance"],
            "causally_required": ["penalty writer for bit 1", "learned direction", "stored carrier", "correct query interface"],
        },
    })
    write_json(ROOT / "DISCOVERY" / "ING01_D07_ROBUSTNESS_GENERALIZATION.json", result)
    append_ndjson(ROOT / "QUESTION_TREE.ndjson", {
        "question_id": "INGQ015", "parent_question": "INGQ009", "parent_result_hash": result["content_sha256"],
        "question": "Does the exact nuisance invariance and causal sensitivity survive fresh post-freeze worlds?", "status": "OPEN",
    })
    append_ndjson(ROOT / "ENGINEERING_DECISION_LOG.ndjson", {
        "decision_id": "INGE007", "result_hash": result["content_sha256"],
        "decision": "Classify direction as the functional policy coordinate in this apparatus; s_reg, payload and clock are nuisances for this readout but not universally irrelevant.",
    })
    print({"hash": result["content_sha256"], **summary})
    if not all(summary[k] for k in (
        "baseline_all", "sreg_nuisance_all", "payload_clock_nuisance_all",
        "missing_penalty_bit1_none", "missing_penalty_bit0_all", "direction_reset_none", "damage_none", "wrong_query_none",
    )):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
