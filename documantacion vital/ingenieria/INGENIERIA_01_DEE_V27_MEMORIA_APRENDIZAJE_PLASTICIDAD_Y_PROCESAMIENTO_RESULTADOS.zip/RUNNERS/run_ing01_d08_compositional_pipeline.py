#!/usr/bin/env python3
"""Preloaded composition of a learned policy with reusable native adapters."""
from __future__ import annotations

import itertools
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing01_common import *
from ing01_apparatus import *
sys.path.insert(0, str(BASE_RUNNERS))
from core10_apparatus import place_arrival  # noqa:E402


def frames():
    return list(itertools.product(itertools.permutations((0, 1, 2)), itertools.product((-1, 1), repeat=3)))


def run_case(kernel, seed, bit, frame, depth, n=47):
    p, s = frame
    a, b, sensor, normalizer, penalty, action0, action1 = (
        transform(v, p, s) for v in (A, B, SENSOR, NORMALIZER, PENALTY0, ACTION0, ACTION1)
    )
    q = (n // 2, n // 2, n // 2)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    raw[q] = pack(1, 7, a, 1)
    schedule = []
    pos = q
    # Experience, environmental consequence, first functional read.
    pos = add(pos, a, 1, n); schedule.append((pos, 1, sensor, 1001, 47))
    pos = add(pos, action0, 1, n); schedule.append((pos, 2, normalizer, 1002, 53))
    if bit: schedule.append((pos, 2, penalty, 1003, 59))
    policy = b if bit else a
    pos = add(pos, policy, 1, n); schedule.append((pos, 3, sensor, 1004, 61))
    action = action1 if bit else action0
    stage_targets = []
    tick = 3
    # ACTION0 + NORMALIZER = A; ACTION1 + NORMALIZER = B.  SENSOR
    # then reads A/B back to ACTION0/ACTION1.  Thus the two-event stage is
    # an exact native identity adapter over the binary functional alphabet.
    for stage in range(depth):
        tick += 1; pos = add(pos, action, 1, n)
        schedule.append((pos, tick, normalizer, 2000 + stage, 71 + stage)); adapter_target = pos
        tick += 1; pos = add(pos, policy, 1, n)
        schedule.append((pos, tick, sensor, 3000 + stage, 91 + stage)); read_target = pos
        stage_targets.append({"stage": stage + 1, "adapter_tick": tick - 1, "adapter_target": adapter_target, "read_tick": tick, "read_target": read_target})
    try:
        for target, at_tick, direction, state, sreg in schedule:
            place_arrival(raw, clock, target, at_tick, direction, state, sreg)
    except RuntimeError as exc:
        return {"seed": seed, "bit": bit, "depth": depth, "frame": {"permutation": list(p), "signs": list(s)}, "constructible": False, "error": str(exc)}
    world = NativeWorld(kernel, raw, clock, threads=1)
    observations = []
    stage_by_tick = {x["adapter_tick"]: ("adapter", x) for x in stage_targets}
    stage_by_tick.update({x["read_tick"]: ("read", x) for x in stage_targets})
    for t in range(1, tick + 1):
        world.tick()
        if t in stage_by_tick:
            kind, meta = stage_by_tick[t]
            target = meta["adapter_target"] if kind == "adapter" else meta["read_target"]
            observations.append({"tick": t, "kind": kind, "stage": meta["stage"], "record": read(world.raw, target)})
    expected_adapter = policy
    expected_action = action
    adapter_ok = all(tuple(x["record"]["direction"]) == expected_adapter for x in observations if x["kind"] == "adapter" and x["record"] is not None) and sum(x["kind"] == "adapter" and x["record"] is not None for x in observations) == depth
    read_ok = all(tuple(x["record"]["direction"]) == expected_action for x in observations if x["kind"] == "read" and x["record"] is not None) and sum(x["kind"] == "read" and x["record"] is not None for x in observations) == depth
    return {
        "seed": seed, "bit": bit, "depth": depth, "n": n,
        "frame": {"permutation": list(p), "signs": list(s)}, "constructible": True,
        "schedule_size": len(schedule), "python_interventions_after_t0": 0,
        "stage_targets": stage_targets, "observations": observations,
        "adapter_exact": adapter_ok, "read_exact": read_ok,
        "terminal_tick": tick, "ticks_per_composed_stage": 2,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    fs = frames()
    for i, frame in enumerate(fs):
        for bit in (0, 1):
            rows.append(run_case(kernel, 1910000 + i * 101 + bit, bit, frame, 2, n=47))
    # Deeper chains on an independent frame subset.
    for i, frame in enumerate(fs[::8]):
        for bit in (0, 1):
            rows.append(run_case(kernel, 1920000 + i * 101 + bit, bit, frame, 8, n=71))
    good = [r for r in rows if r["constructible"]]
    summary = {
        "executions": len(rows), "constructible": len(good),
        "all_constructible": len(good) == len(rows),
        "all_adapter_exact": all(r["adapter_exact"] for r in good),
        "all_read_exact": all(r["read_exact"] for r in good),
        "all_no_python_after_initialization": all(r["python_interventions_after_t0"] == 0 for r in good),
        "maximum_composed_depth": max(r["depth"] for r in good),
        "latency_law": "terminal tick = 3 + 2*depth",
    }
    result = seal({
        "schema": "dee.v27.ing01.compositional_processing.discovery.v1",
        "rows": rows, "summary": summary, "runtime": runtime,
        "exact_relations": [
            "sign(ACTION0 + NORMALIZER) = A",
            "sign(ACTION1 + NORMALIZER) = B",
            "sign(A + SENSOR) = ACTION0",
            "sign(B + SENSOR) = ACTION1",
        ],
        "interpretation_guard": "This demonstrates kernel-native composition of a learned binary response with a configured adapter/read stage. It is not learned arbitrary function composition and not Python composition of separate runs.",
    })
    write_json(ROOT / "DISCOVERY" / "ING01_D08_COMPOSITIONAL_PIPELINE.json", result)
    append_ndjson(ROOT / "ENGINEERING_DECISION_LOG.ndjson", {
        "decision_id": "INGE008", "result_hash": result["content_sha256"],
        "decision": "Promote exact binary adapter composition through depth 8; bound the claim to configured native stages and linear two-tick latency.",
    })
    append_ndjson(ROOT / "QUESTION_TREE.ndjson", {
        "question_id": "INGQ016", "parent_question": "INGQ007", "parent_result_hash": result["content_sha256"],
        "question": "Does exact depth-composition survive fresh frames and depths after freeze?", "status": "OPEN",
    })
    print({"hash": result["content_sha256"], **summary})
    if not all(summary[k] for k in ("all_constructible", "all_adapter_exact", "all_read_exact", "all_no_python_after_initialization")):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
