#!/usr/bin/env python3
"""Exact enumeration of sequence information in raw and clock observers."""
from __future__ import annotations

import hashlib
import itertools
import math
import sys
from collections import Counter
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing01_common import *
from run_ing01_d04_sequence_hidden import run_sequence


def digest_array(a):
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def entropy_of_classes(values):
    counts = Counter(values); total = len(values)
    return -sum((c / total) * math.log2(c / total) for c in counts.values())


def main():
    kernel, runtime = load_kernel(1)
    lengths = []
    collision_examples = []
    for length in range(1, 9):
        rows = []
        for sequence in itertools.product((0, 1), repeat=length):
            r = run_sequence(kernel, sequence, n=31, query=False)
            raw_sig = digest_array(r["raw"])
            clock_phase_sig = digest_array(r["clock"] % np.uint64(195))
            full_clock_sig = digest_array(r["clock"])
            rows.append({
                "sequence": list(sequence), "last_bit": int(sequence[-1]),
                "raw_sha256": raw_sig, "clock_mod195_sha256": clock_phase_sig,
                "clock_sha256": full_clock_sig,
                "raw_clock_key": raw_sig + ":" + full_clock_sig,
            })
        raw_values = [r["raw_sha256"] for r in rows]
        phase_values = [r["clock_mod195_sha256"] for r in rows]
        pair_values = [r["raw_clock_key"] for r in rows]
        raw_groups = {}
        for r in rows: raw_groups.setdefault(r["raw_sha256"], []).append(r)
        for rs in raw_groups.values():
            if len(rs) > 1 and len(collision_examples) < 8:
                collision_examples.append({"length": length, "sequences": [x["sequence"] for x in rs[:4]], "shared_raw_sha256": rs[0]["raw_sha256"], "clock_signatures_distinct": len({x["clock_sha256"] for x in rs})})
        lengths.append({
            "length": length, "sequences": len(rows),
            "visible_last_symbol_classes": 2,
            "unique_full_raw_worlds": len(set(raw_values)),
            "unique_clock_phase_worlds": len(set(phase_values)),
            "unique_raw_plus_clock_worlds": len(set(pair_values)),
            "raw_information_bits_uniform": entropy_of_classes(raw_values),
            "clock_phase_information_bits_uniform": entropy_of_classes(phase_values),
            "raw_plus_clock_information_bits_uniform": entropy_of_classes(pair_values),
            "sequence_entropy_bits_uniform": float(length),
            "raw_plus_clock_injective": len(set(pair_values)) == len(rows),
        })
    summary = {
        "total_sequences_enumerated": sum(x["sequences"] for x in lengths),
        "maximum_length_exactly_enumerated": 8,
        "raw_plus_clock_injective_all_lengths": all(x["raw_plus_clock_injective"] for x in lengths),
        "raw_collisions_exist": any(x["unique_full_raw_worlds"] < x["sequences"] for x in lengths),
        "maximum_uniform_sequence_bits_preserved_by_full_raw_plus_clock": lengths[-1]["raw_plus_clock_information_bits_uniform"],
        "autonomous_native_sequence_classifier": False,
    }
    result = seal({
        "schema": "dee.v27.ing01.sequence_information.enumeration.v1",
        "per_length": lengths, "raw_collision_examples": collision_examples,
        "summary": summary, "runtime": runtime,
        "interpretation": {
            "standard_functional_observer": "returns the last symbol only",
            "full_state_observer": "raw plus clock uniquely identifies every tested sequence through length 8 under this deterministic preparation",
            "access_limit": "injectivity is information retention, not a demonstrated native decoder; configured period-sensitive readout recovers a selected distinction but no general internal classifier was constructed",
            "long_range_claim": "last-symbol query tested through length 64 in D04; full-sequence injectivity was exhaustively established only through length 8",
        },
    })
    write_json(ROOT / "DISCOVERY" / "ING01_D09_SEQUENCE_INFORMATION.json", result)
    append_ndjson(ROOT / "PREREQUISITE_SEARCH.ndjson", {
        "search_id": "INGP003", "target": "autonomous order decoder",
        "attempts": ["standard local policy readout", "full raw equivalence", "full clock-phase observer", "configured period-sensitive selected-coordinate readout"],
        "result": "full state retains sequence information through length 8, but no general native decoder/addressing network constructed",
        "result_hash": result["content_sha256"], "missing": ["native address selection", "decoder mapping distributed clock signature to action"],
    })
    append_ndjson(ROOT / "ENGINEERING_DECISION_LOG.ndjson", {
        "decision_id": "INGE009", "result_hash": result["content_sha256"],
        "decision": "Separate information retention from usable native sequence processing; do not equate an injective omniscient state signature with an internally decoded memory.",
    })
    print({"hash": result["content_sha256"], **summary})
    if not summary["raw_plus_clock_injective_all_lengths"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
