#!/usr/bin/env python3
"""Matched narrow baselines for the demonstrated binary association task."""
from __future__ import annotations

import statistics
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing01_common import *
from ing01_apparatus import compact_learning_cycle


def percentile(values, q):
    a = sorted(values); return a[min(len(a) - 1, int(round((len(a) - 1) * q)))]


def main():
    kernel, runtime = load_kernel(1)
    rng = np.random.default_rng(1930000)
    bits = [int(x) for x in rng.integers(0, 2, size=512)]

    dee_times = []; dee_correct = 0
    for i, bit in enumerate(bits):
        t0 = time.perf_counter_ns()
        r = compact_learning_cycle(kernel, 1931000 + i, bit, n=11)
        dee_times.append(time.perf_counter_ns() - t0)
        dee_correct += int(r["write_correct"] and r["read_correct"])

    lookup_times = []; lookup_correct = 0
    for bit in bits:
        t0 = time.perf_counter_ns(); memory = {"context": bit}; output = memory["context"]
        lookup_times.append(time.perf_counter_ns() - t0); lookup_correct += int(output == bit)

    fsm_times = []; fsm_correct = 0
    for bit in bits:
        t0 = time.perf_counter_ns(); state = 0; state = bit; output = state
        fsm_times.append(time.perf_counter_ns() - t0); fsm_correct += int(output == bit)

    def timing(xs):
        return {"median_ns": statistics.median(xs), "p95_ns": percentile(xs, .95), "minimum_ns": min(xs), "maximum_ns": max(xs)}

    result = seal({
        "schema": "dee.v27.ing01.classical_baselines.v1",
        "task": "one-context binary association: observe consequence bit, store it, answer a fresh binary query",
        "split": {"cases": len(bits), "seed": 1930000, "bit_count_0": bits.count(0), "bit_count_1": bits.count(1), "same_cases_all_systems": True},
        "systems": {
            "DEE_native_collision_memory": {
                "correct": dee_correct, "accuracy": dee_correct / len(bits), "training_examples_per_case": 1,
                "native_kernel_ticks": 3, "write_ticks": 2, "read_ticks": 1,
                "host_timing_including_world_allocation_and_Python_boundary": timing(dee_times),
                "minimum_array_bytes_at_N11": 4 * 8 * (11 ** 3),
                "trainable_parameters": 0, "configured_geometry_and_carriers": True,
            },
            "Python_lookup": {"correct": lookup_correct, "accuracy": lookup_correct / len(bits), "training_examples_per_case": 1, "host_timing": timing(lookup_times), "logical_state_bits": 1},
            "two_state_FSM": {"correct": fsm_correct, "accuracy": fsm_correct / len(bits), "training_examples_per_case": 1, "host_timing": timing(fsm_times), "logical_state_bits": 1},
        },
        "adjudication": {
            "accuracy": "tie: all exact on this narrow task",
            "sample_efficiency": "tie: one consequence writes the bit",
            "host_latency": "classical lookup/FSM faster; DEE timing includes dense-grid kernel and Python orchestration and is not an energy comparison",
            "DEE_specific_value": "local native collision update, persistent moving state, exact equivariance, carrier transfer and source-supported repair; none implies general AI superiority",
            "transformer": "not executed: a transformer is scientifically mismatched to a one-bit association and no historical primary comparison was found",
            "pareto_claim": "No overall DEE advantage is established against classical computation on this benchmark.",
        },
        "runtime": runtime,
    })
    write_json(ROOT / "DISCOVERY" / "ING01_D10_CLASSICAL_BASELINES.json", result)
    append_ndjson(ROOT / "ENGINEERING_DECISION_LOG.ndjson", {
        "decision_id": "INGE010", "result_hash": result["content_sha256"],
        "decision": "Report exact tie in accuracy/sample count and classical host-latency advantage; decline an irrelevant transformer benchmark.",
    })
    print({"hash": result["content_sha256"], "dee_correct": dee_correct, "lookup_correct": lookup_correct, "fsm_correct": fsm_correct, "dee_median_ns": result["systems"]["DEE_native_collision_memory"]["host_timing_including_world_allocation_and_Python_boundary"]["median_ns"], "lookup_median_ns": result["systems"]["Python_lookup"]["host_timing"]["median_ns"]})
    if min(dee_correct, lookup_correct, fsm_correct) != len(bits):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
