#!/usr/bin/env python3
"""Final untouched holdout for selected INGENIERIA 01 claims."""
from __future__ import annotations
import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing01_common import *
from ing01_apparatus import ACTION0,ACTION1
from run_ing01_d02_plasticity_retention import cycle_case,retention_case
from run_ing01_d03_capacity_scaling import bank_case
from run_ing01_d04_sequence_hidden import run_sequence
from run_ing01_d05_closed_pipeline import preloaded_case
from run_ing01_d06_repair_resource_scaling import run_case as repair_case
from run_ing01_d07_robustness_generalization import case as native_case
from run_ing01_d08_compositional_pipeline import run_case as composition_case

def frame(x):return (tuple(x["permutation"]),tuple(x["signs"]))

def main():
    lockp=ROOT/"FREEZE"/"ING01_FINAL_LOCK.json";challengep=ROOT/"CHALLENGES"/"ING01_FINAL_CHALLENGE.json"
    lock=json.loads(lockp.read_text(encoding="utf-8"));challenge=json.loads(challengep.read_text(encoding="utf-8"))
    if challenge["lock_content_sha256"]!=lock["content_sha256"]:raise RuntimeError("challenge/lock mismatch")
    kernel,runtime=load_kernel(1)

    native=[native_case(kernel,x["seed"],x["bit"],frame(x["frame"]),x["n"],x["mode"]) for x in challenge["native_cycle"]]
    canaries=[native_case(kernel,x["seed"],x["bit"],frame(x["frame"]),x["n"],x["mode"]) for x in challenge["native_canaries"]]
    plasticity=[cycle_case(kernel,x["seed"],frame(x["frame"]),x["cycles"],x["n"]) for x in challenge["plasticity"]]
    retention=[retention_case(kernel,x["seed"],frame(x["frame"]),x["n"],x["horizon"]) for x in challenge["retention"]]
    capacity=[bank_case(kernel,x["seed"],x["n"],x["step"]) for x in challenge["capacity"]]
    pipeline=[preloaded_case(kernel,x["seed"],x["bit"],frame(x["frame"]),x["n"]) for x in challenge["pipeline"]]
    repair=[repair_case(kernel,x["seed"],x["k"],frame(x["frame"]),x["mode"]) for x in challenge["repair"]]
    composition=[composition_case(kernel,x["seed"],x["bit"],frame(x["frame"]),x["depth"],x["n"]) for x in challenge["composition"]]
    sequence=[]
    for x in challenge["sequence"]:
        r=run_sequence(kernel,x["sequence"],n=37,query=True);expected=ACTION1 if x["sequence"][-1] else ACTION0
        sequence.append({"sequence":x["sequence"],"length":len(x["sequence"]),"query":r["query"],"last_symbol_correct":r["query"] is not None and tuple(r["query"]["direction"])==expected,"trace":r["trace"]})

    capacity_step3=[r for r in capacity if r["step"]==3];capacity_step2=[r for r in capacity if r["step"]==2]
    checks={
      "native_treatments_all":all(r["success"] for r in native),
      "native_canaries_all_fail":not any(r["success"] for r in canaries),
      "plasticity_all":all(r["all_updates_correct"] and r["query_correct"] for r in plasticity),
      "retention_all":all(r["passed"] for r in retention),
      "capacity_step3_all_zero_error":all(r.get("constructible") and r.get("write_errors")==0 and r.get("read_errors")==0 for r in capacity_step3),
      "capacity_step2_all_zero_write_error":all(r.get("write_errors")==0 for r in capacity_step2),
      "pipeline_all":all(r["success"] and r["python_interventions_after_t0"]==0 for r in pipeline),
      "repair_resource_law_all":all(r["resource_law_exact"] for r in repair),
      "composition_all":all(r["constructible"] and r["adapter_exact"] and r["read_exact"] and r["terminal_tick"]==3+2*r["depth"] for r in composition),
      "sequence_last_symbol_all":all(r["last_symbol_correct"] for r in sequence),
    }
    result=seal({
      "schema":"dee.v27.ing01.final_holdout.v1","lock_content_sha256":lock["content_sha256"],"challenge_content_sha256":challenge["content_sha256"],
      "fresh_worlds":sum(len(x) for x in (native,canaries,plasticity,retention,capacity,pipeline,repair,composition,sequence)),
      "checks":checks,"pass":all(checks.values()),
      "native_cycle":native,"native_canaries":canaries,"plasticity":plasticity,"retention":retention,"capacity":capacity,
      "pipeline":pipeline,"repair":repair,"composition":composition,"sequence":sequence,"runtime":runtime,
    })
    write_json(ROOT/"HOLDOUT"/"ING01_FINAL_HOLDOUT.json",result)
    write_json(ROOT/"HOLDOUT_REGISTRY.json",{"schema":"dee.v27.ing01.holdout_registry.v1","lock_content_sha256":lock["content_sha256"],"status":"PASS" if result["pass"] else "FAIL","entries":[{"id":"ING01-FINAL","challenge_sha256":challenge["content_sha256"],"result_sha256":result["content_sha256"],"fresh_worlds":result["fresh_worlds"],"pass":result["pass"]}]})
    canary_reg=json.loads((ROOT/"CANARY_REGISTRY.json").read_text(encoding="utf-8"));canary_reg["executions"]=len(canaries)+sum(r["mode"]!="treatment" for r in repair);canary_reg["all_passed"]=checks["native_canaries_all_fail"] and checks["repair_resource_law_all"];canary_reg["result_content_sha256"]=result["content_sha256"]
    write_json(ROOT/"CANARY_REGISTRY.json",canary_reg)
    append_ndjson(ROOT/"RESEARCH_DECISION_LOG.ndjson",{"decision_id":"INGD012","decision":"Final untouched holdout passed; promote only frozen bounded claims.","result_hash":result["content_sha256"],"fresh_worlds":result["fresh_worlds"],"checks":checks})
    print({"hash":result["content_sha256"],"fresh_worlds":result["fresh_worlds"],"pass":result["pass"],**checks})
    if not result["pass"]:raise SystemExit(2)

if __name__=="__main__":main()
