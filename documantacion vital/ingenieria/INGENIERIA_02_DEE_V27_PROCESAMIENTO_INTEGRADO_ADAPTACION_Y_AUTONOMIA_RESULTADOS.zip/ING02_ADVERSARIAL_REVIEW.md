# INGENIERIA 02 — ADVERSARIAL REVIEW

## Review standard

Every promoted capability was challenged against simpler explanations: absolute drift, event-count coding, payload leakage, answer-specific clock state, hard-coded geometry, passive-observer assumptions, finite-source exhaustion, route coincidence, toroidal recurrence, collision rejection mistaken for repair, and Python orchestration mistaken for DEE processing.

## Could the memory be an absolute scalar threshold?

No. D04 shows that an untrained absolute control reaches the same threshold after 524 ticks. D06 replaces the invalid observer with a matched relational coordinate. Both absolute values drift, while their difference retains the experience. This supports a relational memory claim and rejects a lasting absolute-threshold claim.

## Could the result be support count rather than organization?

No. D07's four-site outward-plane construction fails. D08 finds only two qualifying patterns among eight valid tetrahedral orientations. The causal prerequisite is topology/geometry, not merely four neighboring supports.

## Could the order answer be encoded in event payload?

No for the promoted apparatus. D16 exposed payload-gradient contamination, so D17 set both event `s_reg` payloads to zero. AB and BA still produce opposite relative signs and routes.

## Could Python have encoded order into clock?

No for the promoted apparatus. AB and BA use the same center and event clocks. The only difference is the predeclared order of two external events. The kernel's native active-state transition determines which event is present during the writable update. Python performs no in-episode decode or rewrite.

## Could geometry or port selection encode the answer?

The same geometry and reader are used for AB, BA and controls. D23 covers all 48 signed/permuted frames. In the frozen holdout, fresh frame/origin/N combinations were generated only after apparatus freeze. The route follows the learned sign rather than a host-selected answer port.

## Could event count, rather than temporal order, explain the result?

No. Simultaneous-early and simultaneous-late controls contain the same number of events but write `delta=0`; no-event controls also write zero. AB and BA contain equal event counts and opposite order, producing opposite signs.

## Could the semantic4 source itself contain the answer?

No. The same raw-invariant source and direction are used across AB, BA and zero controls. It supplies reader traffic but does not select sign. Route-cut canaries preserve the written relative state and remove the output in all 16 fresh canary worlds.

## Could the apparent recurrence be finite preloading?

The semantic4 reader source is a persistent raw-invariant kernel mechanism, not a finite stock of preloaded semantic1 carriers. D14's finite semantic1-source control loses bit-exact source state and accumulates read errors. The promoted claim is nonetheless only a tested lower bound (`>=2000` ticks), never infinite autonomy.

## Could a single persistent comparator be enough?

No. D09–D12 show phase- and traffic-dependent errors, including a first failure at tick 763 and no exact phase ensemble. The persistent semantic4 source changes the maintenance mechanism; it does not merely repeat a threshold sweep.

## Is D13 evidence of L4 adaptation?

No. The `1 -> 0 -> 1` delta excursion at one offset establishes readout backaction. It does not produce repeated actions or a self-sustaining consequence/update cycle. D15's 41-offset persistent-source search also produces no L4 candidate.

## Is the learned regime an attractor?

Not under the operational standard. Persistence and perturbation rejection are necessary but insufficient. D20/D21 carrier families usually fail to damage the center, so no recovery is tested. D22 directly changes or deletes state: the learned relative coordinate is not reconstructed. The package therefore uses `persistent regime`, not `attractor`, for the learned state.

## Is continued function after component deletion self-repair?

No. A source or support can be deleted without immediate loss of every later output, but the component is not rebuilt. That is redundancy, degeneracy or residual trajectory, not restoration. Comparator corruption that returns the right sign once but later saturates the world is also not stable repair.

## Does eight-memory capacity imply native addressing?

No. D19 proves eight simultaneous functional memories under externally assigned disjoint placement. It does not show that DEE allocates the sites, constructs the routes or prevents interference endogenously. `>=8` is a usable-capacity lower bound only.

## Does 72/72 prove general learning?

No. The holdout proves the frozen two-event mechanism across fresh geometry/frame/N instances. It does not prove longer-sequence learning, rule induction, nonstationary adaptation or cognitive generalization.

## Does structural covariance imply external physical symmetry?

No external Rosetta was tested. Covariance across signed/permuted lattice frames is a native DEE result only.

## Python intervention audit

All 72 frozen worlds have zero Python interventions after `t0`. Python created the frozen apparatus, instantiated fresh challenges, called the kernel, logged state, and evaluated the result afterward. Discovery scripts did search architecture space; this is labeled `PYTHON ARCHITECTURE SEARCH`, not DEE learning. D22 host-side damage is an explicit perturbation experiment and not part of a native repair claim.

## Holdout integrity

The lock records hashes of the apparatus, challenge generator, holdout runner and challenge set. The final result is sealed separately. Model selection used D23; holdout instances were not used to tune the architecture. The package validator rechecks these hashes, the 72/72 result, and the registries.

## Residual threats and bounded claims

- Long-lived output interacts with toroidal route recurrence; no universal lifetime law is claimed.
- The relative memory is exact in the tested isolated apparatus but may not survive arbitrary coupled traffic.
- The source maintains reader interaction, not the learned state after deletion.
- L4 and L5 remain absence of a known construction, not proofs of kernel impossibility.
- No native allocator, route growth, longer-sequence decoder, nonstationary learner or external-AI comparison is claimed.
- No correspondence to biological memory, intelligence, life, quantum behavior or human physics is inferred.

## Adversarial conclusion

The simplest model surviving all controls is local and deterministic: native event timing writes one of two matched scaffolded sites; shared drift cancels in their difference; a persistent source repeatedly exposes this difference to a local reducer; and the reducer routes an output. This model predicts the fresh evidence without an exotic interpretation. It is scientifically stronger than the earlier modular apparatus but does not meet L4 or self-repair criteria.
