# INGENIERIA 02 — EXECUTIVE VERDICT

## Scope and epistemic status

INGENIERIA 02 treated CORE01–CORE17 and INGENIERIA 01 as frozen parent evidence and asked whether DEE v27 can support a persistent integrated organization in which stability, plasticity, memory, readout, maintenance and action are not separate host-controlled modules. The campaign did not modify or embed a parent package. Parent filenames and SHA-256 values are recorded in `ING02_PARENT_EVIDENCE_MAP.json`; exact artifact-level provenance is in `PROVENANCE/PARENT_ARTIFACT_INDEX.json` and `ING02_CORE01_17_ING01_AUTONOMY_MECHANISM_GRAPH.json`.

Under P0_FIXED, the promoted native mechanisms are properties of the represented DEE reality in their tested domains. No claim in this package establishes a correspondence to a human physical, biological, cognitive or AI category.

## Principal result

The component-by-component methodology of INGENIERIA 01 had hidden a stronger native organization. INGENIERIA 02 found that a persistent semantic4 scaffold can contain writable semantic1 degrees of freedom, that two matched scaffolded cells can store experience as a **relative causal coordinate**, and that a semantic4 persistent source can repeatedly recreate the interaction that reads this coordinate and routes an action.

The strongest demonstrated organization has this causal grammar:

1. two externally scheduled, zero-payload events arrive in different temporal orders;
2. the event present during the native writable phase changes one scaffolded center through the kernel's active-count/clock gate;
3. the resulting relative state `delta = s_reg(A) - s_reg(B)` is `+1`, `-1` or `0`;
4. common autonomous drift affects both centers but cancels in the relative coordinate;
5. a persistent semantic4 source recreates a native reader interaction;
6. the midpoint reducer converts the sign of `delta` into a signed local direction;
7. that direction routes a functional output without Python decoding or target selection during the episode.

This is not a classical CPU-plus-memory construction. Storage, maintenance, comparison and action are different relations inside the same local DEE dynamics. The organization itself is the functional state in the tested domain.

## Frozen fresh confirmation

The final apparatus, observer, metrics and thresholds were frozen before the final challenge set. The holdout used 72 fresh OS-entropy-derived worlds with unseen combinations of `N` (`19, 25, 37, 41, 43`), origins and signed/permuted frames:

- 40 treatment worlds (`AB` and `BA`);
- 16 simultaneous/no-event controls;
- 16 route-cut causal canaries.

All 72/72 matched their frozen exact predictions at the adjudicated ticks. Treatments wrote opposite relative signs and produced opposite axis projections. Equalized temporal controls wrote zero and produced zero projection. Route-cut canaries retained the learned relative state but removed the functional output, isolating the reader-source prerequisite. The sealed records are `FREEZE/ING02_FINAL_LOCK.json`, `CHALLENGES/ING02_FINAL_CHALLENGES.json`, and `HOLDOUT/ING02_FINAL_HOLDOUT.json`.

## Demonstrated capabilities

1. **Integrated stability plus plasticity.** Stable semantic4 support and writable semantic1 state coexist at different coordinates of one organization. In D01, all 54 treatment configurations wrote the expected `+1` change.

2. **Relative experience memory.** A matched pair stores one experience as `delta_s_reg = 1` for at least 5,000 ticks in `N=17,23,29`, while the absolute values drift together from approximately `100` to `125/126`. No-event and both-event controls remain at `delta=0`. This corrects the absolute-threshold apparatus, whose controls converged after 524 ticks.

3. **Native relational readout.** Two of eight symmetry-distinct valid tetrahedral midpoint organizations convert the relative sign into a signed direction. Support topology, not support count alone, is causal.

4. **Replenished learned output.** A raw-invariant semantic4 source maintains the reader/action interaction. Selected treatment worlds maintain learned routed output to the 2,000-tick cutoff; this is a lower bound, not infinity. A finite semantic1 source degrades, acting as a causal resource canary.

5. **Experience-written temporal order.** With both event payloads set to `s_reg=0`, `AB` writes `+1`, `BA` writes `-1`, and simultaneous/no-event controls write `0`. The AB and BA worlds have the same clock initialization; Python does not calculate or inject an answer after `t0`. Thus order is written by native evolution, not by an answer-coded clock or payload.

6. **Native three-way route selection.** The relative sign selects `+axis`, `-axis`, or no axis route. Storage sites and geometry are externally initialized, so this is causal route selection, not endogenous memory allocation.

7. **Structural covariance and fresh-instance transfer.** The mechanism was exact in 240/240 model-selection cases spanning all 48 signed/permuted frames and five modes, then exact in 72/72 fresh holdout worlds. This is structural invariance, not cognitive rule generalization.

8. **Parallel capacity lower bound.** Eight externally isolated temporal-order memories operated simultaneously in each of four worlds and were exact at ticks 16 and 32. This establishes usable functional capacity `>=8`; it is not a maximum and does not demonstrate native allocation or interference avoidance without assigned isolation.

## Autonomy verdict

The strongest new persistent capability is **learned L2**: one experience selects a relative state that repeatedly drives a natively replenished read/action interaction. The finite L3 action–consequence–policy effect remains valid as frozen parent evidence. INGENIERIA 02 did not construct a stronger persistent L3 or L4 loop.

L4 remains `NO_KNOWN_CONSTRUCTION`, not a fundamental impossibility claim. Three causally distinct routes were tested: active post-write locks, transient-reader feedback phase search, and a semantic4-replenished reader across 41 active-versus-route-cut phase offsets. The common obstruction is now precise: no tested path both rewrites the persistent relative learned coordinate from a consequence and preserves or recreates an unbiased reader for the next adaptive cycle.

## Attractor and repair verdict

The learned regimes are persistent, but they are not promoted as attractors. Many incoming carrier families fail to alter the learned center, which demonstrates collision rejection/robustness, not repair. Direct deletion or corruption of the learned relative state was not restored. Removing some source/support components sometimes preserved later function without rebuilding the missing component; that is functional degeneracy or persistence, not self-repair. No L5 claim is licensed.

## Temporal, addressing and capacity limits

- Temporal capability: exact two-event order discrimination and later functional use.
- Not demonstrated: longer sequence grammar, unseen-length generalization, prediction, or history-conditioned repeated learning.
- Addressing: the learned sign chooses among three local routing outcomes.
- Not demonstrated: endogenous site allocation, route construction or memory selection.
- Capacity: at least eight simultaneously usable, externally isolated memories.
- Not demonstrated: a maximum, native anti-interference, or autonomous capacity growth.

## Python intervention boundary

During discovery, Python enumerated architectures, ran worlds and analyzed telemetry. In the promoted final holdout, Python instantiated the frozen architecture and fresh environment, called the kernel, logged state and adjudicated afterward. It made zero interventions after `t0` in all 72 worlds. It did not decode order, select a route, write the learned delta, replenish the semantic4 source, reset policy, or repair state.

Python still provides initial geometry, input schedule, environment definition, execution/checkpointing and post-run interpretation. Therefore the system is not an independently embodied agent.

## Final scientific conclusion

The failure of L4 in INGENIERIA 01 was partly an apparatus limitation: stability and plasticity do coexist when assigned to different organizational coordinates, relative state defeats shared absolute drift, and persistent semantic4 replenishment supports reusable learned output. But the remaining L4 boundary is real for the mechanisms tested here. Integrated organization solved persistent experience storage and repeated use; it did not solve consequence-driven recurrent rewriting or learned-state self-reconstruction.

The strongest native processing architecture currently supported is a **scaffolded relative-state transducer with persistent native readout**. Its trajectory performs the computation: temporal experience selects a relational regime, common drift preserves that regime, and recurrent local interaction turns the regime into routed action. This is more than the binary policy-bank primitive, but less than a self-maintaining adaptive organization.

No transformer or external-AI benchmark was executed because no new capability reached a fair overlapping task requiring such a comparison. Manufacturing one would have violated the campaign's anti-pareidolia and fair-comparison rules.
