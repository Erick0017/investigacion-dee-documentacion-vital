# INGENIERIA 02 — FINAL FRONTIER AND REQUIRED QUESTIONS

The answers below distinguish demonstrated mechanisms, bounded nulls, apparatus limits and open construction problems. Evidence references resolve through `CLAIM_LEDGER.json`, the machine-readable atlases and the raw discovery/model-selection/holdout artifacts.

1. **Which parent mechanisms became newly useful?** Semantic4 persistence became a reader-resource mechanism; tetrahedral support became a stability scaffold; active-count/clock gating became a one-shot experience writer; matched drift became a relational memory invariant; destination-direction reduction became a native signed decoder; and zero-state activation delay became an order-writing mechanism.

2. **Was ING01's L4 failure only modular?** Partly. Modular construction hid stable-plastic coexistence and reusable learned readout. It did not hide a demonstrated consequence-driven recurrent rewrite: L4 still has no known construction.

3. **Can a persistent organization contain plastic degrees?** Yes. Semantic4 scaffolds remain stable while supported semantic1 `s_reg` is writable.

4. **Can stability and plasticity coexist at different levels?** Yes, within one local organization: stable scaffold, plastic centers, persistent relational difference, and maintained read/action interaction.

5. **Can experience persistently change the organization?** Yes. One event changes one center and thereby writes `delta=±1`, retained for at least 5,000 ticks in the isolated pair.

6. **Can the organization later use that change?** Yes. A midpoint reducer and semantic4 source convert its sign into repeated routed output.

7. **Can it distinguish temporal order without Python clock encoding?** Yes for two events. AB and BA have identical clock setup and zero payloads but produce opposite signs.

8. **Can native history become functional output?** Yes for the tested two-event history. Longer history is open.

9. **Can it allocate/select memory natively?** It can select among three route outcomes from stored sign; it cannot yet allocate a new memory site.

10. **Can it select routes natively?** Yes. `sign(delta)` selects `+axis`, `-axis` or no route.

11. **Can it maintain resources for repeated operation?** It maintains reader/action traffic through a persistent semantic4 source. It does not regenerate a deleted learned state.

12. **Can it repeat full sense–act–consequence–adapt cycles?** No demonstrated persistent repetition. It repeats learned read/action, but not consequence-driven policy rewrite.

13. **Was L4 demonstrated?** No.

14. **What prevents L4 in tested constructions?** No known path simultaneously writes a consequence into the persistent relative coordinate and preserves/recreates an unbiased reader for the next cycle.

15. **How long does the strongest autonomous operation persist?** Learned L2 output reaches at least 2,000 ticks in selected worlds; isolated relative memory reaches at least 5,000. These are lower bounds.

16. **What causes failure?** Route/reader traffic and toroidal recurrence cause phase/sign errors or relative-state collapse; direct learned-state damage is not reconstructed.

17. **How does lifetime scale with resources?** No monotonic law was earned. AB route lifetime was nonmonotonic over `N=17,23,29`; BA survived all three to cutoff.

18. **Can it recover from damage?** It rejects many carrier perturbations and tolerates some component removal functionally, but does not generally restore deleted/corrupted learned state.

19. **Can learned function recover, not merely occupancy?** No general recovery. One comparator corruption produced transient correct sign followed by saturation, which is not recovery.

20. **Can it maintain multiple memories?** Yes, at least eight simultaneously under external spatial isolation.

21. **Can it avoid destructive interference without assigned isolation?** Not demonstrated.

22. **Can it use context?** The native phase/timing context controls writing. A reusable learned context-selection system is not demonstrated.

23. **Can prior experience change later plasticity?** Not prospectively demonstrated; no meta-plasticity claim.

24. **Can it adapt to environmental change?** Only the frozen parent finite L3 effect. Persistent nonstationary adaptation was not licensed.

25. **Can it reacquire earlier behavior?** Not in a persistent integrated loop.

26. **Can it generalize beyond exact training histories?** It generalizes structurally to fresh N, origins and frames; not to unseen sequence grammar or learned relationships.

27. **Can learned transformations compose?** Parallel learned memories compose under external isolation. Sequential learned transformation composition is not demonstrated.

28. **Can organization-level attractors encode memory/policy?** Persistent regimes encode policy, but attractor status is withheld because recovery after real state perturbation failed.

29. **Can experience move between attractors?** It moves between persistent relative regimes; those regimes have not met the attractor recovery criterion.

30. **Can perturbation recovery restore the learned attractor?** No.

31. **Highest autonomy level?** L3 finite remains valid from frozen ING01. ING02's strongest new persistent result is learned L2. L4 and L5 are not achieved.

32. **What still requires Python?** Initial geometry, event/environment schedule, world instantiation, kernel execution/checkpointing, and post-run adjudication. Python does not act or decode during promoted episodes.

33. **Strongest architecture?** A scaffolded relative-state transducer with semantic4-maintained native readout and signed routing.

34. **Stored variables or organization dynamics?** Both exist, but the stronger description is organization-level dynamics: no single scalar is sufficient; topology, matched relation, timing and source trajectory jointly determine function.

35. **Which functions share one causal mechanism?** Write, storage, maintenance, readout and action are all local kernel updates over differently arranged state relations. Consequence-driven rewrite and self-repair remain absent.

36. **Capacity/scaling laws?** Eight usable simultaneous memories are demonstrated; construction cost is 13 initially nonzero voxels per memory and therefore `O(k)` for the externally isolated bank. Maximum and non-isolated scaling are open.

37. **Which limits are fundamental?** No new fundamental impossibility is proven. Absolute thresholds, outward-plane support, permanent-comparator reading and naive consolidation are apparatus limits. L4, native allocation and self-repair are `NO_KNOWN_CONSTRUCTION`.

38. **What was invisible under component-by-component methodology?** The persistent information is a relational coordinate protected by matched drift, while persistent semantic4 dynamics can maintain its read interface. Stability and plasticity need not belong to one cell or one scalar.

39. **Which ING01 claims need reinterpretation?** ING01's binary policy-bank and L2 recurrence remain valid primitives, but they are not the maximal architecture. Its L4 null becomes a narrower construction null: integrated organization adds persistent learned readout yet still lacks consequence-driven recurrent rewrite.

40. **What frontier remains?** The highest-value frontier is an endogenous consequence-to-relative-state writer compatible with persistent reader replenishment. Adjacent fronts are learned-state reconstruction, endogenous memory/route allocation, non-isolated interference control, longer native temporal grammar and scaling laws under coupled traffic.

## Scientifically justified next experiment families

These are proposals, not claims:

- Find a native consequence carrier that changes exactly one member of a matched pair without converting the persistent reader into a biased writer.
- Search for a two-timescale organization in which the reader source is persistent but write access is gated only by an environmental consequence.
- Test whether an organization can recreate a missing relative coordinate from redundant relational parity rather than from a unique trained backup.
- Replace externally isolated memory banks with a shared scaffold and determine whether phase, topology or lineage can select a bank without host addressing.
- Extend the zero-payload event grammar from two-event order to three events only after a native readout and anti-leakage controls are specified.

No branch should be reopened by cosmetic parameter sweeps. A new experiment must introduce a new causal writer, observer, recovery relation or allocation mechanism capable of changing the model.
