# INGENIERIA 02 — ORGANIZATION SEARCH REPORT

## Search strategy

The campaign changed the unit of search from isolated memory/decoder/reset modules to organizations whose state is relational and whose function emerges from a trajectory. Parent mechanisms were mined across all frozen CORE01–CORE17 and INGENIERIA 01 packages. The machine-readable mechanism graph contains 36 entries: 28 parent mechanisms and eight ING02 mechanisms, each linked to its source artifact and SHA-256.

The discovery sequence was adaptive. Each branch below either supplied a causal prerequisite, falsified an apparatus assumption, or bounded a major frontier. Seed/N/coordinate variation was not counted as a new construction unless it changed the causal mechanism.

## D01–D04: stable scaffold with a writable degree

`D01` established that a semantic4 tetrahedral scaffold can support a semantic1 center while a transient event changes the center's `s_reg` by exactly `+1` (54/54 treatment arrangements). This supplied a spatially stable scaffold and a plastic coordinate.

`D02` added a permanent comparator directly to the write apparatus. It contaminated the write through the same local reducer and was rejected. The result showed that readout cannot be assumed passive.

`D03` separated write and read in time and geometry. Across 48 frames and eight modes (384 cases), every treatment wrote at tick 1, the native reader responded at tick 2, and routed action appeared at tick 3.

`D04` then falsified the absolute-threshold interpretation. The treatment remained distinguishable to 20,000 ticks, but the no-experience control's autonomous drift crossed the same absolute threshold at tick 524. The underlying writable state remained useful; the observer was wrong.

## D05–D08: from absolute value to relational state

`D05` tested post-write locks as consolidation. Active locks propagated and saturated the system; apparent direction matches were coincidence inside a contaminated world. Those results are retained as a scientific failure and not promoted.

`D06` introduced a matched pair of scaffolded centers. One event changes A while B supplies a counterfactual reference. Common drift raises both absolute values, but `delta = A-B` remains exactly `1` for at least 5,000 ticks in all three treatment worlds (`N=17,23,29`). No-event and both-event controls remain at zero. Wrong-phase treatment loses the distinction at tick 130, identifying the native timing prerequisite.

`D07` showed that four supports placed in a simple outward plane do not reproduce the behavior. Support cardinality is insufficient.

`D08` enumerated eight symmetry-distinct valid tetrahedral configurations around the midpoint comparator. Two produce the exact relational reduction: `delta=1 -> +axis` and `delta=0 -> zero`. This established topology-dependent native relational readout.

## D09–D15: readout traffic, replenishment and the L4 obstruction

`D09` found that a single comparator reads correctly for hundreds of ticks but first fails at tick 763 even though the relative memory remains exact. This localized the error to the reader/traffic trajectory, not memory loss.

`D10` scanned reader phases. The best single phase reached approximately 0.945 accuracy, but none was exact through 2,000 ticks.

`D11` tested exact OR/majority ensembles of up to seven phases. No exact ensemble exists in the tested panel because errors are globally correlated rather than independent.

`D12` varied the memory phase in 260-tick classes. All classes wrote the same relative bit, while the reader still failed at tick 763. The failure is therefore not repaired by shifting memory phase.

`D13` searched transient reader feedback offsets. Offset `-1` produced `delta: 1 -> 0 -> 1`, proving readout backaction can alter the causal trajectory, but it emitted only one comparator event and did not form a reusable adaptive loop.

`D14` replaced the finite reader with a semantic4 source two cells upstream. In `N=17` and `N=29`, treatment memory and positive-axis output persist to the 2,000-tick cutoff while no-experience controls remain at zero; in `N=23`, memory collapses at tick 1305 due to toroidal interaction, while the output remains latched. A finite semantic1-source control degrades. This supplied native resource replenishment for read/action and exposed the topology-dependent lifetime boundary.

`D15` combined the replenished reader with 41 phase offsets and paired route-cut controls. Many offsets had causal activity, but none generated repeated memory/action transitions. This closed the L4 branch as `NO_KNOWN_CONSTRUCTION` for the tested mechanism family.

## D16–D19: experience-written temporal order and parallel capacity

`D16` first obtained AB/BA discrimination, but nonzero event payloads created a gradient and eventual saturation. It motivated a stronger anti-leakage design.

`D17` set both event payloads to zero. The early event is active during the writable phase; the late state-zero carrier becomes active only afterward. Consequently AB changes A and BA changes B. Across `N=17,23,29` and four read ticks, AB produces `delta=+1/+axis`, BA `delta=-1/-axis`, and simultaneous/no-event controls `delta=0/zero`. Clocks are equal across AB and BA.

`D18` extended the temporal-order worlds to 2,000 ticks. BA remains correct to the cutoff in all three N. AB survives to 2,000 ticks in `N=23`, while positive-route recurrence causes output failure at tick 393 in `N=17` and tick 792 in `N=29`. This forbids a monotonic N scaling claim.

`D19` placed eight disjoint order memories in one `N=73` world. Four different label patterns, all eight memories per world, were exact at ticks 16 and 32. The construction cost is 13 initially nonzero voxels per AB/BA memory. The result is a lower bound, because spatial isolation and addresses were externally assigned.

## D20–D22: damage, robustness and repair discrimination

`D20` and `D21` sent multiple carrier families toward learned centers. They did not reliably change the target. The correct interpretation is collision rejection/robustness; an experiment that fails to damage a state cannot demonstrate recovery.

`D22` therefore applied explicit, declared host-side damage after learning solely for perturbation science. Clearing or corrupting the learned memory did not restore it. Clearing the comparator produced a semantic7 zero-output state. Comparator corruption briefly returned the correct sign but then expanded to near-world saturation. Clearing a source or one support sometimes allowed later functional output without rebuilding the deleted component. None satisfies the self-repair standard.

## D23 and final holdout

`D23` validated all 48 signed/permuted frames over five modes (240/240 exact), after which the apparatus, runner, observer, metrics and predictions were frozen.

The final holdout was generated after freeze from fresh OS entropy. It produced 72/72 exact worlds. No architecture, threshold or observer was changed after freeze. The route-cut canary separated memory from action; temporal equalization controls separated order from event count.

## Resulting organization

The final organization is not merely a set of bolted modules. Its functional state is a relationship maintained by a common scaffold and read through a replenished interaction. Its key invariants and operations are:

- topology-stabilized writable sites;
- experience-gated local increment;
- matched-drift cancellation in `delta`;
- persistent-source maintenance of the read interaction;
- relational reduction into signed direction;
- route/action selected by the learned relational state;
- parallel composition under externally assigned separation.

The architecture is therefore best described as a **scaffolded relative-state transducer**, not as an attractor, neural network, CPU or autonomous agent.
