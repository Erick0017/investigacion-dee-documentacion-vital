# Reproduction guide

## Environment identity

Use the exact DEE v27 kernel and Python environment recorded in `ING02_PARENT_EVIDENCE_MAP.json` and the per-artifact metadata. Verify the kernel binary hash before execution. Parent packages are referenced by filename and SHA-256 and are not required to execute the new ING02 runners; they are required only to audit scientific ancestry.

## Final frozen result

1. Verify hashes listed in `HASHES.sha256` after extracting the official package.
2. Verify `FREEZE/ING02_FINAL_LOCK.json` against the recorded apparatus, challenge-generator, holdout-runner and challenge hashes.
3. Run `RUNNERS/run_ing02_holdout.py` with the exact runtime recorded by the package. The runner consumes `CHALLENGES/ING02_FINAL_CHALLENGES.json` and `RUNNERS/temporal_order_apparatus_v1.py`.
4. Do not modify the challenge set, apparatus, thresholds, observer or evaluation ticks.
5. Compare the regenerated result with `HOLDOUT/ING02_FINAL_HOLDOUT.json`. Expected summary: 72 worlds, 72 exact; 40/40 treatments, 16/16 controls and 16/16 canaries.

The apparatus initializes all events before `t0`; the holdout runner performs no Python intervention after `t0`. Expected values are specified per challenge and checked at the frozen adjudication ticks.

## Discovery and mechanism reproduction

Each evidence JSON contains its configuration, result rows, content seal and relevant environment metadata. Corresponding scripts are in `RUNNERS/`:

- D01–D05: scaffold, write/read, longevity and consolidation tests.
- D06–D12: relative memory, relational readout and phase/ensemble discrimination.
- D13–D15: backaction, semantic4 replenishment and recurrent-feedback prerequisite search.
- D16–D19: temporal order, longevity and parallel capacity.
- D20–D22: perturbation calibration and direct-damage recovery tests.
- D23: all-frame model selection.

`RUNNERS/ing02_common.py` supplies kernel loading, raw packing/unpacking, hashing and sealed JSON helpers. Apparatus modules preserve exact voxel creation, buffer dtype, clocks, support geometry and tick ordering.

## Evidence interpretation

Reproducing D20 or D21 without changing the target is evidence of collision rejection, not repair. D22 uses declared host-side damage to test restoration and must not be represented as an autonomous episode. D05 apparent direction matches are invalidated by propagation/saturation and are retained only as a scientific failure.

## Validation

Run `RUNNERS/validate_ing02_package.py` on the extracted package or official ZIP. It verifies internal hashes, manifest membership, parent-hash references, freeze hashes, registry consistency, 72/72 holdout status, intervention/leakage audits, absence of embedded parent ZIPs and ZIP integrity.
