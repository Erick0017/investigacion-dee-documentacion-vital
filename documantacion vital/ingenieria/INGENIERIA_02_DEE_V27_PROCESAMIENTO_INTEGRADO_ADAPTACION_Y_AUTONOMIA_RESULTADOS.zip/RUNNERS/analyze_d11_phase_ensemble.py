#!/usr/bin/env python3
"""Select small reader-phase ensembles that cover all discovery ticks."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, seal, write_json


def expand(rle, horizon):
    values = [None] * horizon
    for start, end, value in rle:
        values[int(start)-1:int(end)] = [bool(value)] * (int(end)-int(start)+1)
    return values


def main():
    source = ROOT / "MECHANISM_SELECTION" / "ING02_D10_READER_PHASE_PANEL.json"
    data = json.loads(source.read_text(encoding="utf-8"))
    rows = [row for row in data["rows"] if row["mode"] == "experience_a"]
    horizon = rows[0]["horizon"]
    correct = {row["phase"]: np.asarray(expand(row["correct_rle"], horizon), dtype=np.uint8)[1:] for row in rows}
    best_by_size = []
    candidate_count = 0
    best_or = None
    best_majority = None
    for size in range(1, 8):
        size_best_or = None
        size_best_majority = None
        for subset in itertools.combinations(sorted(correct), size):
            candidate_count += 1
            counts = np.sum(np.stack([correct[p] for p in subset]), axis=0)
            coverage = counts > 0
            majority = counts > size // 2
            row = {
                "phases": list(subset), "size": size,
                "or_exact": bool(np.all(coverage)), "or_accuracy": float(np.mean(coverage)),
                "majority_exact": bool(np.all(majority)), "majority_accuracy": float(np.mean(majority)),
                "first_or_failure": None if np.all(coverage) else int(np.flatnonzero(~coverage)[0]) + 2,
                "first_majority_failure": None if np.all(majority) else int(np.flatnonzero(~majority)[0]) + 2,
            }
            if size_best_or is None or (row["or_accuracy"], [-p for p in row["phases"]]) > (size_best_or["or_accuracy"], [-p for p in size_best_or["phases"]]):
                size_best_or = row
            if size_best_majority is None or (row["majority_accuracy"], [-p for p in row["phases"]]) > (size_best_majority["majority_accuracy"], [-p for p in size_best_majority["phases"]]):
                size_best_majority = row
            if best_or is None and row["or_exact"]:
                best_or = row
            if best_majority is None and row["majority_exact"]:
                best_majority = row
        best_by_size.append({"size": size, "best_or": size_best_or, "best_majority": size_best_majority})
        if best_or is not None and best_majority is not None:
            break
    result = seal({
        "schema": "dee.v27.ing02.model_selection.phase_ensemble.v1",
        "source_artifact": "MECHANISM_SELECTION/ING02_D10_READER_PHASE_PANEL.json",
        "source_content_sha256": data["content_sha256"],
        "evaluated_ticks": horizon - 1,
        "best_or_exact": best_or,
        "best_majority_exact": best_majority,
        "candidate_count": candidate_count,
        "best_by_size": best_by_size,
        "selection_note": "This is discovery/model selection only; physical aggregation and fresh validation remain required.",
    })
    output = ROOT / "MECHANISM_SELECTION" / "ING02_D11_PHASE_ENSEMBLE_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "best_or": best_or, "best_majority": best_majority, "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
