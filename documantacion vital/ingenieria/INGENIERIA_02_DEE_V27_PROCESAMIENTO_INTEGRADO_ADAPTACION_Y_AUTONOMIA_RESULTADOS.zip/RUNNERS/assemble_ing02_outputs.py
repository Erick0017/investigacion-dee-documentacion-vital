#!/usr/bin/env python3
"""Assemble final scientific atlases, ledgers and adaptive logs from sealed evidence."""
from __future__ import annotations

import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,seal,sha256_file,utc,write_json


def load(rel):return json.loads((ROOT/rel).read_text(encoding="utf-8"))
def ref(rel):
    data=load(rel);return {"artifact":rel,"file_sha256":sha256_file(ROOT/rel),"content_sha256":data.get("content_sha256")}
def save(name,schema,**body):write_json(ROOT/name,seal({"schema":schema,**body}))
def ndjson(path,rows):
    (ROOT/path).write_text("".join(json.dumps({"created_utc":utc(),**row},sort_keys=True,ensure_ascii=False)+"\n" for row in rows),encoding="utf-8")


E={
 "D01":ref("DISCOVERY/ING02_D01_SCAFFOLD_PLASTICITY.json"),"D03":ref("DISCOVERY/ING02_D03_INTEGRATED_WRITE_READ.json"),
 "D05":ref("DISCOVERY/ING02_D05_NATIVE_CONSOLIDATION.json"),"D06":ref("DISCOVERY/ING02_D06_RELATIVE_MEMORY.json"),
 "D07":ref("DISCOVERY/ING02_D07_RELATIVE_READOUT_SEARCH.json"),"D08":ref("DISCOVERY/ING02_D08_RELATIVE_TETRA_READOUT_SEARCH.json"),
 "D09":ref("DISCOVERY/ING02_D09_RELATIVE_READOUT_LONGEVITY.json"),"D10":ref("MECHANISM_SELECTION/ING02_D10_READER_PHASE_PANEL.json"),
 "D11":ref("MECHANISM_SELECTION/ING02_D11_PHASE_ENSEMBLE_SELECTION.json"),"D12":ref("MECHANISM_SELECTION/ING02_D12_MEMORY_PHASE_PANEL.json"),
 "D13":ref("DISCOVERY/ING02_D13_SELF_FEEDBACK_PHASE_SEARCH.json"),"D14":ref("DISCOVERY/ING02_D14_PERSISTENT_NATIVE_READER.json"),
 "D15":ref("DISCOVERY/ING02_D15_RECURRENT_FEEDBACK_PHASE_SEARCH.json"),"D17":ref("DISCOVERY/ING02_D17_TEMPORAL_ORDER_ZERO_PAYLOAD.json"),
 "D18":ref("MECHANISM_SELECTION/ING02_D18_TEMPORAL_ORDER_LONGEVITY.json"),"D19":ref("DISCOVERY/ING02_D19_PARALLEL_TEMPORAL_BANK.json"),
 "D20":ref("ADVERSARIAL_CHALLENGE/ING02_D20_PERTURBATION_RECOVERY.json"),"D21":ref("ADVERSARIAL_CHALLENGE/ING02_D21_DAMAGE_MECHANISM_SEARCH.json"),
 "D22":ref("ADVERSARIAL_CHALLENGE/ING02_D22_DIRECT_DAMAGE_RECOVERY.json"),"D23":ref("MECHANISM_SELECTION/ING02_D23_TEMPORAL_FRAME_PANEL.json"),
 "LOCK":ref("FREEZE/ING02_FINAL_LOCK.json"),"HOLDOUT":ref("HOLDOUT/ING02_FINAL_HOLDOUT.json"),
}


def main():
    holdout=load("HOLDOUT/ING02_FINAL_HOLDOUT.json");d14=load("DISCOVERY/ING02_D14_PERSISTENT_NATIVE_READER.json");d18=load("MECHANISM_SELECTION/ING02_D18_TEMPORAL_ORDER_LONGEVITY.json");d22=load("ADVERSARIAL_CHALLENGE/ING02_D22_DIRECT_DAMAGE_RECOVERY.json")
    assert holdout["summary"]["all_pass"] and holdout["summary"]["exact"]==72

    save("ING02_INTEGRATED_ORGANIZATION_ATLAS.json","dee.v27.ing02.integrated_organization_atlas.v1",
        architecture={"persistent_scaffold":"eight semantic4 support sites plus one semantic4 reader source","plastic_state":"two matched supported semantic1 centers; policy/history is delta_s_reg=A-B","readout":"midpoint reducer converts sign(delta_s_reg) into signed local axis","maintenance":"reader-source train recreates read interaction","action":"nonzero signed direction routes carriers"},
        causal_chain=["external event timing (frozen at t0)","native active-count/clock gate","relative s_reg write","persistent relative state","semantic4-replenished reader","native gradient reduction","signed route/action"],
        demonstrated={"stability_plus_plasticity":True,"experience_written":True,"later_native_use":True,"recurrent_learned_output":True,"repeated_consequence_adaptation":False},evidence=[E[k] for k in ("D06","D08","D14","D17","HOLDOUT")])

    save("ING02_ATTRACTOR_REGIME_ATLAS.json","dee.v27.ing02.attractor_regime_atlas.v1",
        regimes=[{"state":"delta=+1","meaning":"AB / early A","persistence":"5000 ticks for isolated pair; functional output bounded by route geometry"},{"state":"delta=-1","meaning":"BA / early B","persistence":">=2000 ticks in all three tested N"},{"state":"delta=0","meaning":"simultaneous/no event","persistence":"control output zero in frozen horizon"}],
        perturbation_verdict="PERSISTENT_REGIMES_NOT_PROMOTED_AS_ATTRACTORS",reason="No experiment restored a deleted or directly corrupted learned relative coordinate. Incoming carrier families were rejected rather than repaired; direct memory corruption persisted.",
        functional_component_results={"corrupt_comparator":"axis function returned in one tick but produced later support saturation; not stable repair","clear_comparator":"regenerated semantic7 zero-output state, not learned action","clear_source_or_one_support":"function could continue transiently without restoring the deleted component"},evidence=[E[k] for k in ("D20","D21","D22")])

    save("ING02_TEMPORAL_HISTORY_MEMORY.json","dee.v27.ing02.temporal_history_memory.v1",
        result="FRESH_CONFIRMED_EXACT_IN_FROZEN_DOMAIN",write_rule="At common memory phase 260, the event active during the first update increments its supported center; a state0 late carrier becomes active only after that gate. AB therefore writes delta=+1 and BA delta=-1.",
        anti_cheating={"clock_same_in_AB_BA":True,"event_payload_s_reg":0,"events_preloaded_before_t0":True,"python_history_decoder":False,"readout_answer_independent":True},
        fresh={"worlds":72,"treatments":40,"controls":16,"canaries":16,"exact":72,"frames_and_origins":"fresh randomized signed frames, origins and N=19/25/37/41/43"},
        scope="Two-event order only. No longer-sequence, unseen-length or temporal prediction claim.",evidence=[E[k] for k in ("D17","D23","LOCK","HOLDOUT")])

    save("ING02_NATIVE_ADDRESSING.json","dee.v27.ing02.native_addressing.v1",
        mechanism="The sign of the experience-written relative coordinate selects +axis, -axis, or no routed output without host target selection.",
        addressing_classes=3,classes=[{"delta":1,"route":"+local axis"},{"delta":-1,"route":"-local axis"},{"delta":0,"route":"no axis route"}],
        limits=["storage coordinates and scaffold are externally initialized","no endogenous allocation of a new memory site","route-cut canary preserves memory but removes output in 16/16 fresh worlds"],evidence=[E[k] for k in ("D17","D23","HOLDOUT")])

    save("ING02_RESOURCE_MAINTENANCE.json","dee.v27.ing02.resource_maintenance.v1",
        maintained="reader/action interaction supplied by raw-invariant semantic4 source",not_maintained="learned relative state is not regenerated after deletion",source_canary="semantic1 finite source lost bit-exact source state and accumulated read errors",
        lower_bounds={"learned_output_ticks":2000,"exact_isolated_relative_memory_ticks":5000},
        interpretation="Native replenishment and learned state coexist at different organizational coordinates. This removes the ING01 single-scalar obstruction but does not close adaptive feedback.",evidence=[E[k] for k in ("D06","D14","D18")])

    save("ING02_REUSABLE_ADAPTATION.json","dee.v27.ing02.reusable_adaptation.v1",
        achieved={"reusable_learned_read_action":"YES","repeated_environment_consequence_policy_update":"NO","nonstationary_adaptation":"NOT_LICENSED","L4":"NOT_CONSTRUCTED"},
        searches=[{"construction":"propagating post-write locks","result":"support expansion/saturation; invalid consolidation","evidence":E["D05"]},{"construction":"single transient reader with phase-offset relative memory","result":"one readout-backaction excursion; no repeated action","evidence":E["D13"]},{"construction":"semantic4-replenished reader over 41 phase offsets","result":"source stabilizes output; at most two delta-sign transitions, no repeated adaptive loop","evidence":E["D15"]}],
        obstruction="No tested causal path both (a) changes the persistent relative learned coordinate from a consequence and (b) preserves/recreates an unbiased reader for the next adaptive cycle.")

    save("ING02_AUTONOMY_LEVELS.json","dee.v27.ing02.autonomy_levels.v1",
        levels=[{"level":"L0","achieved":True,"basis":"parent"},{"level":"L1","achieved":True,"basis":"parent and ING02 finite order pipeline"},{"level":"L2","achieved":True,"basis":"ING02 strengthens L2: one experience selects a relative state that drives replenished repeated output; >=2000 ticks in selected worlds"},{"level":"L3","achieved":True,"basis":"frozen ING01 finite action-consequence update; ING02 adds bounded readout backaction but no stronger persistent L3"},{"level":"L4","achieved":False,"basis":"D15 paired prerequisite search"},{"level":"L5","achieved":False,"basis":"learned-state deletion/corruption not repaired"}],
        highest_supported="L3_FINITE inherited/frozen; strongest new persistent capability is learned L2",python_remaining=["initial organization geometry","event schedule/input","environment definition","run/checkpoint","post-run adjudication"],evidence=[E[k] for k in ("D14","D15","D22","HOLDOUT")])

    lifetime=[]
    for r in d14["rows"]:
        if r["mode"]=="treatment":lifetime.append({"apparatus":"replenished relative reader","n":r["n"],"tested_horizon":r["horizon"],"terminal_delta_segments":r["delta_rle"],"positive_axis_ticks":r["positive_x_ticks"]})
    for r in d18["rows"]:
        if r["mode"] in {"AB","BA"}:lifetime.append({"apparatus":"temporal order","n":r["n"],"mode":r["mode"],"tested_horizon":r["horizon"],"delta_failure":r["first_delta_failure"],"output_failure":r["first_output_failure"]})
    save("ING02_AUTONOMY_LIFETIME_SCALING.json","dee.v27.ing02.autonomy_lifetime.v1",observations=lifetime,
        law_status="NO_MONOTONIC_N_SCALING_EARNED",reason="Positive route recurrence interacted nonmonotonically with toroidal geometry: AB output failed at 393 for N17, survived N23 to 2000, and failed at 792 for N29; BA survived all to cutoff.",lower_bound="strongest tested learned recurrent output >=2000 ticks; not infinite",evidence=[E["D14"],E["D18"]])

    save("ING02_FEEDBACK_ATLAS.json","dee.v27.ing02.feedback_atlas.v1",
        entries=[{"type":"finite parent L3","status":"FRESH_CONFIRMED_PARENT","description":"action -> consequence -> later policy/action"},{"type":"relative readout backaction","status":"BOUNDED","description":"reader presence can change active-count/phase trajectory; offset -1 produced delta 1->0->1, but comparator did not reissue a new action"},{"type":"replenished feedback search","status":"BOUNDED_NULL","description":"41 phase offsets, active vs route-cut, no candidate with repeated memory/action transitions"}],
        L4=False,evidence=[E["D13"],E["D15"]])

    repair_rows=[]
    for r in d22["rows"]:repair_rows.append({"damage":r["mode"],"first_32_tick_functional_recovery":r["first_32_tick_functional_recovery"],"terminal_functional_exact":r["terminal_functional_exact"]})
    save("ING02_SELF_REPAIR.json","dee.v27.ing02.self_repair.v1",verdict="NO_GENERAL_LEARNED_STATE_SELF_REPAIR",tests=repair_rows,
        distinctions={"collision_rejection":"carrier perturbations failed to change the learned center; robustness, not repair","functional_persistence":"some deleted support/source components were not rebuilt although output later remained correct","unstable_correction":"corrupt comparator returned correct sign immediately but expanded to near-world saturation","learned_state_damage":"clear/corrupt memory did not recover"},evidence=[E[k] for k in ("D20","D21","D22")])

    save("ING02_DISTRIBUTED_MEMORY.json","dee.v27.ing02.distributed_memory.v1",
        mechanisms=[{"name":"relative pair","state":"delta_s_reg between two matched supported cells","hidden_from":"absolute-threshold observer can lose distinction as both drift","recoverable_by":"symmetric midpoint reducer"},{"name":"parallel order bank","state":"eight disjoint relative pairs","result":"4/4 worlds exact for all eight memories at ticks16 and32"}],
        capacity_lower_bound={"simultaneous_functional_memories":8,"native_classes_per_memory":3,"independent_binary_order_choices":8},
        limitation="Placement/isolation and addresses were externally configured; no endogenous allocator.",evidence=[E[k] for k in ("D06","D19")])

    save("ING02_PLASTICITY_STABILITY_MAP.json","dee.v27.ing02.plasticity_stability.v1",
        coordinates=[{"coordinate":"semantic4 scaffold","stable":True,"plastic":False,"role":"support and replenishment"},{"coordinate":"semantic1 center s_reg","stable":"under four-site support","plastic":"clock/active-count gated +1","role":"experience coordinate"},{"coordinate":"relative delta","stable":"matched drift cancels to >=5000 ticks","plastic":"which center receives gated event sets sign","role":"memory/policy"},{"coordinate":"comparator","stable":"maintained by source","plastic":"direction responds to relative sign","role":"read/action"}],
        principle="Stability and plasticity coexist at different coordinates of one organization; no single cell must be both immutable and writable.",evidence=[E[k] for k in ("D01","D06","D14")])

    save("ING02_GENERALIZATION_ATLAS.json","dee.v27.ing02.generalization.v1",
        demonstrated=[{"kind":"structural covariance","result":"240/240 across all 48 signed frames in model selection"},{"kind":"fresh structural holdout","result":"72/72 over fresh N, origins and frames"},{"kind":"parallel composition","result":"8 simultaneous memories, four label patterns"}],
        not_demonstrated=["rule learning beyond the frozen two-event gate","unseen sequence length","novel task relationship","endogenous relocation","nonstationary adaptation"],
        classification="STRUCTURAL_INVARIANCE_AND_FRESH_INSTANCE_GENERALIZATION; NOT COGNITIVE RULE GENERALIZATION",evidence=[E[k] for k in ("D19","D23","HOLDOUT")])

    save("ING02_CAPACITY_SCALING.json","dee.v27.ing02.capacity_scaling.v1",
        exact_construction_cost={"initial_nonzero_voxels_per_AB_or_BA_memory":13,"components":{"mutable_centers":2,"semantic4_supports":8,"scheduled_event_carriers":2,"semantic4_reader_source":1},"asymptotic":"O(k) initial voxels for k externally isolated memories"},
        tested={"single_memory":True,"simultaneous_memories":8,"world_n":73,"tick16_exact":"32/32 organization instances across four worlds","tick32_exact":"32/32"},
        bounds={"usable_functional_capacity_lower_bound":8,"maximum":"NOT_MEASURED","interference_free_without_external_isolation":"NOT_DEMONSTRATED"},evidence=[E["D19"]])

    save("ING02_RESOURCE_ACCOUNTING.json","dee.v27.ing02.resource_accounting.v1",
        final_apparatus={"initial_voxels_AB_BA":13,"write_latency_ticks":1,"conservative_frozen_readout_latency_ticks":16,"checked_recurrent_ticks":[16,32,64],"kernel_calls_per_frozen_world":64,"fresh_worlds":72,"fresh_kernel_calls":4608,"python_interventions_after_t0":0},
        bank={"memories":8,"initial_voxels":104,"tested_ticks":32,"world_size":73},
        caveat="Host wall time and energy are implementation measures, not intrinsic DEE resources.",evidence=[E[k] for k in ("D19","LOCK","HOLDOUT")])

    save("ING02_NATIVE_PROCESSING_GRAMMAR.json","dee.v27.ing02.processing_grammar.v1",
        operators=[{"op":"SUPPORT","rule":"semantic4 topology stabilizes a mutable semantic1 center"},{"op":"GATED_WRITE","rule":"clock phase and active support count condition s_reg increment"},{"op":"RELATIVE_STORE","rule":"matched autonomous drift preserves delta=A-B"},{"op":"REPLENISHED_READ","rule":"persistent source recreates reader interaction"},{"op":"RELATIONAL_REDUCE","rule":"midpoint gradient maps sign(delta) to signed direction"},{"op":"ROUTE","rule":"signed direction selects functional output path"},{"op":"PARALLEL_COMPOSE","rule":"disjoint organizations execute simultaneously"}],
        unification="Storage, readout, maintenance and action are all local kernel updates over different organizational relations; no CPU/memory ontology is required.",evidence=[E[k] for k in ("D06","D14","D17","D19")])

    save("ING02_NATIVE_LEARNING_GRAMMAR.json","dee.v27.ing02.learning_grammar.v1",
        demonstrated_rule="EVENT ORDER -> gated center increment -> relative sign -> later route",
        equations={"AB":"s_A'=s_A+1, s_B'=s_B, delta'=+1","BA":"s_A'=s_A, s_B'=s_B+1, delta'=-1","simultaneous":"both or neither increment, delta'=0","read":"action_axis=sign(delta) in validated window"},
        learning_status="one-shot experience-written temporal discrimination",not_learning=["Python architecture search","configured scaffold geometry","semantic4 source direction","spatial bank allocation"],
        limits=["two events","fixed writable phase","no repeated consequence-driven update","no meta-plasticity"],evidence=[E[k] for k in ("D17","D23","HOLDOUT")])

    save("ING02_FAILURE_OBSTRUCTION_MAP.json","dee.v27.ing02.failure_obstruction_map.v1",
        entries=[{"front":"naive consolidation","class":"APPARATUS_LIMIT","obstruction":"active locks propagate and saturate rather than consolidate"},{"front":"outward-plane support","class":"APPARATUS_LIMIT","obstruction":"support count alone is insufficient; valid topology required"},{"front":"single persistent comparator","class":"APPARATUS_LIMIT","obstruction":"self-emitted traffic causes phase/sign errors"},{"front":"phase ensembles","class":"NO_KNOWN_CONSTRUCTION","obstruction":"global traffic errors remain correlated; no exact OR/majority set through 2000"},{"front":"L4","class":"NO_KNOWN_CONSTRUCTION","obstruction":"no consequence path repeatedly rewrites relative state while preserving an unbiased replenished reader"},{"front":"learned-state self-repair","class":"NO_KNOWN_CONSTRUCTION","obstruction":"scaffold rejects collisions but does not reconstruct cleared/corrupted learned coordinate"}],
        no_fundamental_impossibility_claim=True,evidence=[E[k] for k in ("D05","D07","D10","D11","D15","D22")])

    save("ING02_PYTHON_INTERVENTION_AUDIT.json","dee.v27.ing02.python_audit.v1",
        promoted_holdout={"worlds":72,"worlds_with_python_after_t0":sum(r["result"]["python_interventions_after_t0"]!=0 for r in holdout["rows"]),"pass":True},
        python_did=["generate/freeze fresh challenges","instantiate frozen worlds","call kernel","record telemetry","adjudicate after execution","search architectures during discovery","apply declared external damage in D22"],
        python_did_not=["decode AB/BA during episode","select action route","write delta after t0","replenish reader source","repair holdout state","tune after freeze"],
        discovery_exception="D21 used Python snapshot/injection only to calibrate whether a damage was real; it was not a native capability or holdout.",evidence=[E[k] for k in ("D21","LOCK","HOLDOUT")])

    save("ING02_HARDCODE_LEAKAGE_AUDIT.json","dee.v27.ing02.leakage_audit.v1",
        tests=[{"risk":"answer encoded in payload","test":"event s_reg set to zero","result":"AB/BA exact"},{"risk":"answer-specific geometry","test":"same apparatus; only event order changes; all 48 frames","result":"240/240"},{"risk":"source encodes answer","test":"same semantic4 reader source in AB/BA/zero controls","result":"opposite/zero outputs follow delta"},{"risk":"reader existence creates answer","test":"route-cut canary","result":"memory writes but no output, 16/16 fresh"},{"risk":"order is merely event count","test":"simultaneous early/late and no-event controls","result":"delta=0/output=0, 16/16 fresh controls"},{"risk":"test-set leakage","test":"fresh N/origin/frame challenges generated after freeze","result":"72/72"}],
        audit_pass=True,evidence=[E[k] for k in ("D17","D23","LOCK","HOLDOUT")])

    claims=[
      {"id":"ING02-C01","status":"FRESH_CONFIRMED_EXACT_IN_DOMAIN","claim":"A persistent semantic4 organization can contain an experience-writable semantic1 degree and later use it natively.","evidence":[E["D03"],E["D06"],E["HOLDOUT"]]},
      {"id":"ING02-C02","status":"FRESH_CONFIRMED_BOUNDED","claim":"Matched organization preserves one experience as relative delta_s_reg=1 for at least 5000 ticks across N17/23/29 despite shared absolute drift.","evidence":[E["D06"]]},
      {"id":"ING02-C03","status":"FRESH_CONFIRMED_BOUNDED","claim":"Semantic4 replenishment converts learned relative state into reusable routed output; strongest tested learned recurrent output survives at least 2000 ticks, not infinitely.","evidence":[E["D14"],E["HOLDOUT"]]},
      {"id":"ING02-C04","status":"FRESH_CONFIRMED_EXACT_IN_FROZEN_DOMAIN","claim":"AB and BA are written by native timing into delta=+1/-1 and select opposite routes; 72/72 final fresh worlds including controls/canaries.","evidence":[E["D17"],E["D23"],E["LOCK"],E["HOLDOUT"]]},
      {"id":"ING02-C05","status":"CONFIRMED_LOWER_BOUND","claim":"At least eight independently addressed temporal-order memories coexist and act simultaneously in one world.","evidence":[E["D19"]]},
      {"id":"ING02-C06","status":"BOUNDED_NULL_NO_KNOWN_CONSTRUCTION","claim":"No L4 persistent consequence-driven adaptive loop was constructed after distinct lock, transient-reader and replenished-reader searches.","evidence":[E["D05"],E["D13"],E["D15"]]},
      {"id":"ING02-C07","status":"BOUNDED_NULL_NO_GENERAL_SELF_REPAIR","claim":"The organization rejects many carrier collisions and can preserve function after some component losses, but does not restore a deleted/corrupted learned relative coordinate.","evidence":[E["D20"],E["D21"],E["D22"]]},
      {"id":"ING02-C08","status":"MODEL_SELECTION_EXACT","claim":"The two-event mechanism is covariant across all 48 signed frames (240/240 pre-freeze worlds).","evidence":[E["D23"]]},
    ]
    write_json(ROOT/"CLAIM_LEDGER.json",seal({"schema":"dee.v27.ing02.claim_ledger.v1","status":"SCIENTIFICALLY_CLOSED","claims":claims,"promoted_claims":5,"bounds_and_nulls":3}))
    write_json(ROOT/"HOLDOUT_REGISTRY.json",seal({"schema":"dee.v27.ing02.holdout_registry.v1","status":"CLOSED","entries":[{"id":"ING02-H01","freeze":E["LOCK"],"result":E["HOLDOUT"],"worlds":72,"exact":72,"treatments":40,"controls":16,"canaries":16,"passed":True}]}))
    write_json(ROOT/"CANARY_REGISTRY.json",seal({"schema":"dee.v27.ing02.canary_registry.v1","status":"CLOSED","entries":[{"id":"ING02-K01_ROUTE_CUT","prerequisite":"semantic4 replenished reader source","prediction":"delta=+1 still writes but comparator output remains absent","fresh_worlds":16,"exact":16,"evidence":E["HOLDOUT"]},{"id":"ING02-K02_TEMPORAL_EQUALIZATION","prerequisite":"order-specific writable timing","prediction":"simultaneous/no events yield delta=0 and projection=0","fresh_worlds":16,"exact":16,"evidence":E["HOLDOUT"]}]}))

    ndjson("QUESTION_TREE.ndjson",[
      {"id":"ING02-Q00","parent":None,"question":"Can integrated organization overcome the modular L2/L3 obstruction?","result":"learned L2 yes; L4 no"},
      {"id":"ING02-Q01","parent":"ING02-Q00","question":"Can stable scaffold and plastic coordinate coexist?","result":"yes: D01/D03"},
      {"id":"ING02-Q02","parent":"ING02-Q01","question":"Can matched organization preserve experience against absolute drift?","result":"yes: relative delta, D06"},
      {"id":"ING02-Q03","parent":"ING02-Q02","question":"Can DEE read the relative coordinate natively and repeatedly?","result":"valid tetra + semantic4 source, D08/D14"},
      {"id":"ING02-Q04","parent":"ING02-Q03","question":"Can output/consequence cause repeated adaptive updates?","result":"no candidate across D13/D15"},
      {"id":"ING02-Q05","parent":"ING02-Q03","question":"Can experience write temporal order rather than Python clock labels?","result":"AB/BA exact with zero payload, D17"},
      {"id":"ING02-Q06","parent":"ING02-Q05","question":"Does order use generalize across frames and fresh worlds?","result":"240/240 selection; 72/72 frozen holdout"},
      {"id":"ING02-Q07","parent":"ING02-Q05","question":"Can multiple memories coexist?","result":"eight simultaneous lower bound"},
      {"id":"ING02-Q08","parent":"ING02-Q03","question":"Is learned regime an attractor/self-repairing?","result":"persistent but no learned-state reconstruction"},
    ])
    ndjson("PREREQUISITE_SEARCH.ndjson",[
      {"id":"P01","front":"stable plastic state","attempt":"semantic4 tetra scaffold","result":"success"},{"id":"P02","front":"consolidation","attempt":"post-write active locks","result":"failed by propagation/saturation"},{"id":"P03","front":"persistent memory","attempt":"matched relative pair","result":"success >=5000 ticks"},{"id":"P04","front":"reusable reader","attempt":"semantic4 source train","result":"success"},{"id":"P05","front":"L4","attempt":"41 active/cut phase-offset organizations","result":"no recurrent adaptive candidate"},{"id":"P06","front":"self-repair","attempt":"collision families and direct corruption/deletion","result":"learned state not reconstructed"},
    ])
    ndjson("ORGANIZATION_SEARCH.ndjson",[
      {"id":"O01","organization":"absolute scaffold memory","result":"write/read works; control converges at tick524"},{"id":"O02","organization":"matched relative pair","result":"shared drift cancels"},{"id":"O03","organization":"outward-plane support","result":"fails; topology not count alone"},{"id":"O04","organization":"symmetric tetra midpoint reader","result":"2 of 8 valid tetra orientations qualify"},{"id":"O05","organization":"semantic4-replenished reader","result":"learned recurrent output"},{"id":"O06","organization":"zero-payload temporal order","result":"AB/BA functional"},{"id":"O07","organization":"eight-memory bank","result":"parallel lower bound"},
    ])
    ndjson("AUTONOMY_RUN_LOG.ndjson",[
      {"id":"A01","apparatus":"relative memory","horizon":5000,"result":"delta exact in 3/3 treatment worlds"},{"id":"A02","apparatus":"replenished learned reader","horizon":2000,"result":"N17/N29 delta and output persist; N23 delta loses at1305"},{"id":"A03","apparatus":"temporal order","horizon":2000,"result":"BA 3/3; AB N23 only; route geometry bounds"},{"id":"A04","apparatus":"recurrent feedback phase search","horizon":2048,"result":"0 L4 candidates across 41 offsets"},{"id":"A05","apparatus":"frozen holdout","horizon":64,"result":"72/72 exact"},
    ])
    ndjson("RESEARCH_DECISION_LOG.ndjson",[
      {"decision":"Freeze all parents read-only","result":"18 hashes recorded; no parent embedded"},{"decision":"Reject D05 apparent successes","result":"world saturation made direction coincidence non-scientific"},{"decision":"Replace absolute threshold with relative causal coordinate","result":"D06 removes matched drift"},{"decision":"Reject scalar/module-only search","result":"paired scaffold+source+reducer treated as one organization"},{"decision":"Use zero-payload events","result":"eliminates payload-gradient explanation for order"},{"decision":"Do not promote L4","result":"multiple distinct constructions fail repeated adaptation"},{"decision":"Do not promote attractor/self-repair","result":"persistence and collision rejection are not restoration"},{"decision":"Freeze before fresh validation","result":"72/72; no post-freeze tuning"},
    ])
    print(json.dumps({"outputs":"assembled","claims":len(claims),"holdout":holdout["summary"]},indent=2))


if __name__=="__main__":main()
