#!/usr/bin/env python3
"""Build a direct-parent, autonomy-oriented mechanism graph without embedding parents."""
from __future__ import annotations

import json,re,sys,zipfile
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,CORE_DIR,ING01_DIR,seal,sha256_file,write_json


TERMS=("memory","learn","plastic","history","clock","phase","route","fiber","semantic","s_reg","regener","repair","feedback","policy","transfer","reconstruct","observer","hidden","causal","source","reducer","organization","lineage","attractor","recurrent","autonomy")


def read_member(z,name):
    with zipfile.ZipFile(z) as a:return json.loads(a.read(name).decode("utf-8"))


def collect_claims(obj,out):
    if isinstance(obj,dict):
        if ("claim" in obj or "statement" in obj) and ("id" in obj or "claim_id" in obj or "status" in obj):out.append(obj)
        for value in obj.values():collect_claims(value,out)
    elif isinstance(obj,list):
        for value in obj:collect_claims(value,out)


def evidence_ref(path):
    data=json.loads(path.read_text(encoding="utf-8"));return {"artifact":str(path.relative_to(ROOT)).replace('\\','/'),"file_sha256":sha256_file(path),"content_sha256":data.get("content_sha256")}


def main():
    parent_map=json.loads((ROOT/"ING02_PARENT_EVIDENCE_MAP.json").read_text(encoding="utf-8"));parents={p["parent_id"]:p for p in parent_map["packages"]}
    ingzip=ING01_DIR/parents["INGENIERIA_01"]["filename"]
    ancestor=read_member(ingzip,"ING01_CORE01_17_MECHANISM_GRAPH.json")
    mechanisms=[]
    for node in ancestor["mechanisms"]:
        origin=node["origin_core"]
        parent_id=origin if origin.startswith("CORE") else "INGENIERIA_01"
        mechanisms.append({**node,"parent_package":parents[parent_id]["filename"],"parent_package_sha256":parents[parent_id]["sha256"],"ing02_role":"candidate_parent_mechanism"})
    new_nodes=[
        ("I02_M01_SCAFFOLD_PLASTICITY","semantic4 scaffold with experience-writable semantic1 degree","CORE01 support/source + CORE04 support operator",["DISCOVERY/ING02_D01_SCAFFOLD_PLASTICITY.json","DISCOVERY/ING02_D03_INTEGRATED_WRITE_READ.json"]),
        ("I02_M02_RELATIVE_MEMORY","matched drift cancels in a persistent relative s_reg coordinate","I02_M01",["DISCOVERY/ING02_D06_RELATIVE_MEMORY.json"]),
        ("I02_M03_RELATIVE_READER","symmetric native gradient reads relative memory","CORE01 reducer + I02_M02",["DISCOVERY/ING02_D08_RELATIVE_TETRA_READOUT_SEARCH.json","DISCOVERY/ING02_D09_RELATIVE_READOUT_LONGEVITY.json"]),
        ("I02_M04_REPLENISHED_READER","semantic4 source repeatedly maintains learned-state read/action","ING01 N01 + I02_M03",["DISCOVERY/ING02_D14_PERSISTENT_NATIVE_READER.json"]),
        ("I02_M05_TEMPORAL_ORDER","native gate writes AB/BA into opposite relative states and routes opposite action","CORE01 clock gate + I02_M02 + I02_M04",["DISCOVERY/ING02_D17_TEMPORAL_ORDER_ZERO_PAYLOAD.json","MECHANISM_SELECTION/ING02_D18_TEMPORAL_ORDER_LONGEVITY.json","MECHANISM_SELECTION/ING02_D23_TEMPORAL_FRAME_PANEL.json","HOLDOUT/ING02_FINAL_HOLDOUT.json"]),
        ("I02_M06_PARALLEL_BANK","eight simultaneous independently addressed order memories","I02_M05",["DISCOVERY/ING02_D19_PARALLEL_TEMPORAL_BANK.json"]),
        ("I02_M07_DAMAGE_BOUND","collision rejection and functional persistence do not restore deleted learned state","I02_M01 + I02_M04",["ADVERSARIAL_CHALLENGE/ING02_D20_PERTURBATION_RECOVERY.json","ADVERSARIAL_CHALLENGE/ING02_D21_DAMAGE_MECHANISM_SEARCH.json","ADVERSARIAL_CHALLENGE/ING02_D22_DIRECT_DAMAGE_RECOVERY.json"]),
        ("I02_M08_L4_OBSTRUCTION","replenished readout stabilizes policy but no repeated consequence-driven policy cycle was constructed","ING01 N04/N05_L4 + I02_M02/I02_M04",["DISCOVERY/ING02_D13_SELF_FEEDBACK_PHASE_SEARCH.json","DISCOVERY/ING02_D15_RECURRENT_FEEDBACK_PHASE_SEARCH.json"]),
    ]
    for ident,name,ancestry,artifacts in new_nodes:
        refs=[evidence_ref(ROOT/a) for a in artifacts]
        mechanisms.append({"id":ident,"name":name,"origin_core":"INGENIERIA_02","status":"FRESH_CONFIRMED" if ident in {"I02_M05_TEMPORAL_ORDER"} else "DISCOVERY_OR_BOUND","causal_ancestry":ancestry,"evidence":refs})

    # Direct inventory of each immutable package: claim ledgers and autonomy-relevant primary members.
    inventories=[]
    for parent_id,parent in parents.items():
        z=(CORE_DIR/parent["filename"]) if parent_id.startswith("CORE") else (ING01_DIR/parent["filename"])
        with zipfile.ZipFile(z) as a:
            names=a.namelist();relevant=[n for n in names if any(term in n.lower() for term in TERMS) and not n.endswith('/')]
            ledgers=[n for n in names if n.upper().endswith("CLAIM_LEDGER.JSON")]
            claims=[]
            for ledger in ledgers:
                try:collect_claims(json.loads(a.read(ledger).decode("utf-8")),claims)
                except Exception:pass
            related=[]
            for claim in claims:
                text=json.dumps(claim,ensure_ascii=False).lower()
                if any(term in text for term in TERMS):related.append(claim)
            inventories.append({"parent_id":parent_id,"filename":parent["filename"],"sha256":parent["sha256"],"zip_integrity":"PARENT_FROZEN_NOT_RETESTED",
                "member_count":len(names),"claim_ledgers":ledgers,"claim_records_found":len(claims),"autonomy_related_claims":related,
                "autonomy_relevant_members":relevant})
    graph=seal({"schema":"dee.v27.ing02.autonomy_mechanism_graph.v1","parents_embedded":False,"parent_mechanisms_source":{"artifact":"INGENIERIA_01/ING01_CORE01_17_MECHANISM_GRAPH.json","package_sha256":parents["INGENIERIA_01"]["sha256"]},
        "mechanisms":mechanisms,"edges":[
            {"from":"M01_SOURCE","to":"I02_M04_REPLENISHED_READER","relation":"replenishes"},
            {"from":"M04_SUPPORT_OPERATOR","to":"I02_M01_SCAFFOLD_PLASTICITY","relation":"stabilizes_mutable_center"},
            {"from":"M01_CLOCK_SKEW","to":"I02_M05_TEMPORAL_ORDER","relation":"gates_early_vs_late_experience"},
            {"from":"M01_REDUCER","to":"I02_M03_RELATIVE_READER","relation":"converts_relative_gradient_to_route"},
            {"from":"N01_RESET","to":"I02_M04_REPLENISHED_READER","relation":"source_replenishment_grammar"},
            {"from":"I02_M02_RELATIVE_MEMORY","to":"I02_M05_TEMPORAL_ORDER","relation":"stores_order_sign"},
            {"from":"I02_M04_REPLENISHED_READER","to":"I02_M05_TEMPORAL_ORDER","relation":"reusable_functional_output"},
        ]})
    write_json(ROOT/"ING02_CORE01_17_ING01_AUTONOMY_MECHANISM_GRAPH.json",graph)
    index=seal({"schema":"dee.v27.ing02.parent_artifact_index.v1","inventories":inventories,"no_parent_content_copied":True})
    write_json(ROOT/"PROVENANCE"/"PARENT_ARTIFACT_INDEX.json",index)
    print(json.dumps({"graph":graph["content_sha256"],"mechanisms":len(mechanisms),"parents":len(inventories),"index":index["content_sha256"]},indent=2))


if __name__=="__main__":main()
