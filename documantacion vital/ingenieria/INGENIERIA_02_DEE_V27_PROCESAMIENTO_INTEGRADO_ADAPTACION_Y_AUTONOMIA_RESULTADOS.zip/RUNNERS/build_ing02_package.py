#!/usr/bin/env python3
"""Build the compact, deduplicated official INGENIERIA 02 package."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OFFICIAL_NAME = "INGENIERIA_02_DEE_V27_PROCESAMIENTO_INTEGRADO_ADAPTACION_Y_AUTONOMIA_RESULTADOS.zip"
OFFICIAL = ROOT / OFFICIAL_NAME
STAGE_PARENT = ROOT / "PACKAGE_STAGE"


def utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def source_candidates() -> list[Path]:
    excluded_roots = {"PACKAGE_STAGE", "DELIVERY_STAGE", "TELEMETRY", "__pycache__"}
    excluded_names = {OFFICIAL_NAME, "MANIFEST.json", "HASHES.sha256"}
    result = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if rel.parts[0] in excluded_roots or path.name in excluded_names:
            continue
        if path.suffix in {".pyc", ".pyo"}:
            continue
        result.append(path)
    return sorted(result, key=lambda p: p.relative_to(ROOT).as_posix())


def scientific_provenance() -> None:
    claims = json.loads((ROOT / "CLAIM_LEDGER.json").read_text(encoding="utf-8"))
    holdout = json.loads((ROOT / "HOLDOUT/ING02_FINAL_HOLDOUT.json").read_text(encoding="utf-8"))
    lock = json.loads((ROOT / "FREEZE/ING02_FINAL_LOCK.json").read_text(encoding="utf-8"))
    parent = json.loads((ROOT / "ING02_PARENT_EVIDENCE_MAP.json").read_text(encoding="utf-8"))
    value = {
        "schema": "dee.v27.ing02.final_provenance.v1",
        "created_utc": utc(),
        "campaign": "INGENIERIA_02",
        "status": "SCIENTIFICALLY_CLOSED",
        "official_filename": OFFICIAL_NAME,
        "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        "wheel_sha256": "69297e6f06761c8b2f65d24a3fd7a2f16a3f67595a7f9660739ab65f47abc939",
        "parent_reference_map_sha256": sha256(ROOT / "ING02_PARENT_EVIDENCE_MAP.json"),
        "parent_package_count": len(parent["packages"]),
        "parents_embedded": False,
        "freeze_content_sha256": lock["content_sha256"],
        "holdout_content_sha256": holdout["content_sha256"],
        "holdout_summary": holdout["summary"],
        "claim_counts": {
            "total": len(claims["claims"]),
            "promoted": claims["promoted_claims"],
            "bounds_and_nulls": claims["bounds_and_nulls"],
        },
        "highest_autonomy": "L3_FINITE_PARENT; strongest new persistent result learned L2",
        "l4": "NOT_CONSTRUCTED",
        "l5": "NOT_CONSTRUCTED",
    }
    value["content_sha256"] = canonical_hash(value)
    write_json(ROOT / "PROVENANCE/FINAL_PROVENANCE.json", value)


def build() -> dict:
    scientific_provenance()
    STAGE_PARENT.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix="ing02_final_", dir=STAGE_PARENT))
    seen: dict[str, str] = {}
    aliases: list[dict] = []
    inventory: list[dict] = []
    try:
        for source in source_candidates():
            rel = source.relative_to(ROOT).as_posix()
            digest = sha256(source)
            if digest in seen:
                aliases.append({"alias": rel, "physical_path": seen[digest], "sha256": digest})
                continue
            seen[digest] = rel
            target = stage / Path(rel)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            inventory.append({"path": rel, "bytes": source.stat().st_size, "sha256": digest})

        holdout = json.loads((ROOT / "HOLDOUT/ING02_FINAL_HOLDOUT.json").read_text(encoding="utf-8"))
        claims = json.loads((ROOT / "CLAIM_LEDGER.json").read_text(encoding="utf-8"))
        manifest = {
            "schema": "dee.v27.ing02.package_manifest.v1",
            "created_utc": utc(),
            "official_filename": OFFICIAL_NAME,
            "campaign_status": "SCIENTIFICALLY_CLOSED",
            "file_count": len(inventory) + 2,
            "payload_file_count": len(inventory),
            "payload_bytes": sum(row["bytes"] for row in inventory),
            "deduplication": {"duplicate_groups": len(aliases), "aliases": aliases},
            "scientific_counts": {
                "claims": len(claims["claims"]),
                "promoted_claims": claims["promoted_claims"],
                "bounds_and_nulls": claims["bounds_and_nulls"],
                "holdout_worlds": holdout["summary"]["worlds"],
                "holdout_exact": holdout["summary"]["exact"],
            },
            "parent_packages_embedded": False,
            "inventory": inventory,
        }
        manifest["content_sha256"] = canonical_hash(manifest)
        write_json(stage / "MANIFEST.json", manifest)

        hash_rows = []
        for path in sorted((p for p in stage.rglob("*") if p.is_file()), key=lambda p: p.relative_to(stage).as_posix()):
            hash_rows.append(f"{sha256(path)}  {path.relative_to(stage).as_posix()}")
        (stage / "HASHES.sha256").write_text("\n".join(hash_rows) + "\n", encoding="utf-8")

        temp_zip = ROOT / "DELIVERY_STAGE" / (OFFICIAL_NAME + ".tmp")
        temp_zip.parent.mkdir(parents=True, exist_ok=True)
        if temp_zip.exists():
            temp_zip.unlink()
        with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
            for path in sorted((p for p in stage.rglob("*") if p.is_file()), key=lambda p: p.relative_to(stage).as_posix()):
                archive.write(path, path.relative_to(stage).as_posix())
        with zipfile.ZipFile(temp_zip, "r") as archive:
            bad = archive.testzip()
            if bad is not None:
                raise RuntimeError(f"ZIP integrity failed at {bad}")
        os.replace(temp_zip, OFFICIAL)
        result = {
            "official": str(OFFICIAL),
            "bytes": OFFICIAL.stat().st_size,
            "sha256": sha256(OFFICIAL),
            "entries": len(inventory) + 2,
            "payload_entries": len(inventory),
            "duplicate_groups": len(aliases),
        }
        write_json(ROOT / "DELIVERY_STAGE/BUILD_RESULT.json", result)
        return result
    finally:
        if stage.exists():
            shutil.rmtree(stage)


if __name__ == "__main__":
    print(json.dumps(build(), indent=2, ensure_ascii=False))
