#!/usr/bin/env python3
"""Freeze the final INGENIERIA 02 temporal-order apparatus before holdout."""
from __future__ import annotations

import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,seal,sha256_file,write_json


def main():
    files=[HERE/"temporal_order_apparatus_v1.py",HERE/"run_ing02_holdout.py",HERE/"generate_ing02_holdout_challenges.py",ROOT/"CHALLENGES"/"ING02_FINAL_CHALLENGES.json"]
    out=seal({"schema":"dee.v27.ing02.freeze.v1","status":"FROZEN_BEFORE_HOLDOUT","apparatus":"temporal_order_apparatus_v1",
        "parameters":{"event_sreg":0,"reader_source_semantic":4,"memory_phase":260,"horizon":64,"adjudication_ticks":[1,16,32,64]},
        "predictions":{"AB":{"delta":1,"axis_projection":1},"BA":{"delta":-1,"axis_projection":-1},"simultaneous_or_none":{"delta":0,"axis_projection":0},"route_cut":{"delta":1,"axis_projection":None}},
        "success_rule":"Every treatment/control matches delta at tick1 and axis projection at ticks16,32,64; every route-cut canary writes delta=1 but has no comparator output.",
        "falsifier":"Any mismatch, Python intervention after t0, missing semantic4 source in treatment, or challenge/runner hash mismatch.",
        "files":{str(p.relative_to(ROOT)).replace('\\','/'):sha256_file(p) for p in files}})
    output=ROOT/"FREEZE"/"ING02_FINAL_LOCK.json";write_json(output,out)
    print(json.dumps({"output":str(output),"hash":out["content_sha256"],"files":out["files"]},indent=2))


if __name__=="__main__":main()
