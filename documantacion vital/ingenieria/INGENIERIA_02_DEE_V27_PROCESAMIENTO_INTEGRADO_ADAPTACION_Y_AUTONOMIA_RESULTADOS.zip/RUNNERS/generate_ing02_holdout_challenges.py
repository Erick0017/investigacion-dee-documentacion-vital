#!/usr/bin/env python3
"""Generate fresh post-selection temporal-order and canary challenges."""
from __future__ import annotations

import hashlib,itertools,json,os,random,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,seal,write_json


def main():
    entropy=os.urandom(32);rng=random.Random(int.from_bytes(entropy,"big"));frames=list(itertools.product(itertools.permutations(range(3)),itertools.product((-1,1),repeat=3)))
    specs=[]
    plan=[("AB",20),("BA",20),("simultaneous_early",6),("simultaneous_late",5),("no_events",5),("route_cut",16)]
    index=0
    for mode,count in plan:
        for _ in range(count):
            n=rng.choice((19,25,37,41,43));perm,signs=rng.choice(frames);origin=[rng.randrange(n) for _ in range(3)]
            expected=1 if mode=="AB" else -1 if mode=="BA" else 0
            specs.append({"challenge_id":f"ING02-H-{index:03d}","mode":mode,"n":n,"origin":origin,"permutation":list(perm),"signs":list(signs),
                "event_sreg":0,"horizon":64,"expected_delta":1 if mode=="route_cut" else expected,"expected_projection":None if mode=="route_cut" else expected,
                "role":"canary" if mode=="route_cut" else "control" if expected==0 else "treatment"})
            index+=1
    rng.shuffle(specs)
    out=seal({"schema":"dee.v27.ing02.holdout.challenges.v1","generation_entropy_sha256":hashlib.sha256(entropy).hexdigest(),
        "generated_after_model_selection":True,"world_count":len(specs),"challenges":specs})
    output=ROOT/"CHALLENGES"/"ING02_FINAL_CHALLENGES.json";write_json(output,out)
    print(json.dumps({"output":str(output),"worlds":len(specs),"hash":out["content_sha256"]},indent=2))


if __name__=="__main__":main()
