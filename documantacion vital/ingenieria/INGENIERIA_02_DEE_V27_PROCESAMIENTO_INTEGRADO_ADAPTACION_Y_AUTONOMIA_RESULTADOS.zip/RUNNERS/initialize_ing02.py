#!/usr/bin/env python3
"""Lock parent packages and initialize the adaptive INGENIERIA 02 campaign."""
from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import CORE_DIR, ING01_DIR, ROOT, append_ndjson, load_kernel, seal, sha256_file, write_json


def core_number(name: str) -> int | None:
    match = re.match(r"^(\d{2})_DEE_", name)
    if not match:
        return None
    value = int(match.group(1))
    return value if 1 <= value <= 17 else None


def zip_member_hash(path: Path, member: str) -> str | None:
    import hashlib

    with zipfile.ZipFile(path, "r") as archive:
        if member not in archive.namelist():
            return None
        return hashlib.sha256(archive.read(member)).hexdigest()


def main() -> None:
    packages = []
    cores = []
    for path in sorted(CORE_DIR.glob("*.zip")):
        number = core_number(path.name)
        if number is None:
            continue
        cores.append((number, path))
    if [number for number, _ in cores] != list(range(1, 18)):
        raise RuntimeError(f"CORE01-17 set incomplete: {[number for number, _ in cores]}")
    for number, path in cores:
        packages.append(
            {
                "parent_id": f"CORE{number:02d}",
                "filename": path.name,
                "bytes": path.stat().st_size,
                "sha256": sha256_file(path),
                "role": "frozen_parent_science",
            }
        )
    ing01 = ING01_DIR / "INGENIERIA_01_DEE_V27_MEMORIA_APRENDIZAJE_PLASTICIDAD_Y_PROCESAMIENTO_RESULTADOS.zip"
    packages.append(
        {
            "parent_id": "INGENIERIA_01",
            "filename": ing01.name,
            "bytes": ing01.stat().st_size,
            "sha256": sha256_file(ing01),
            "role": "frozen_parent_engineering",
            "primary_artifacts": [
                "CLAIM_LEDGER.json",
                "ING01_CORE01_17_MECHANISM_GRAPH.json",
                "DEE_NATIVE_LEARNING_ENGINE_SPEC.json",
                "DEE_AUTONOMY_BOUNDARY.json",
                "DEE_NATIVE_RESET_REPLENISHMENT.json",
                "DEE_REUSABLE_FEEDBACK_LOOP.json",
                "DEE_CLOCK_HISTORY_DECODING.json",
                "DEE_NATIVE_DISTRIBUTED_DECODER.json",
                "PROVENANCE_REWRITE.json",
            ],
        }
    )
    kernel, runtime = load_kernel(1)
    del kernel
    parent_map = seal(
        {
            "schema": "dee.v27.ing02.parent_evidence_map.v1",
            "packages": packages,
            "parent_packages_embedded": False,
            "frozen_policy": "Read-only parent evidence. CORE01-17 and INGENIERIA_01 are not modified.",
            "runtime": runtime,
            "purpose_specific_fronts": [
                "integrated organization",
                "attractor/regime",
                "experience-written temporal history",
                "native addressing",
                "resource maintenance",
                "L4 autonomy",
                "organization-level self-repair",
            ],
        }
    )
    write_json(ROOT / "ING02_PARENT_EVIDENCE_MAP.json", parent_map)
    empty_registry = {
        "schema": "dee.v27.ing02.registry.v1",
        "entries": [],
        "status": "DISCOVERY_OPEN",
    }
    for name in ("CLAIM_LEDGER.json", "HOLDOUT_REGISTRY.json", "CANARY_REGISTRY.json"):
        write_json(ROOT / name, seal({**empty_registry, "registry": name.removesuffix(".json")}))
    append_ndjson(
        ROOT / "QUESTION_TREE.ndjson",
        {
            "id": "ING02-Q00",
            "parent": None,
            "question": "Can integrated DEE organization overcome the modular L2/L3 obstruction and support reusable adaptation?",
            "competing_hypotheses": [
                "organization-level stability and plasticity coexist",
                "all mutable functional state remains consumable",
                "persistent sectors cannot be experience-written",
            ],
            "phase": "RETROSPECTIVE",
        },
    )
    append_ndjson(
        ROOT / "RESEARCH_DECISION_LOG.ndjson",
        {
            "decision": "Lock all parents before new experiments",
            "result": "18 parent packages hashed; no parent package copied or modified",
            "parent_map_content_sha256": parent_map["content_sha256"],
        },
    )
    for name in ("PREREQUISITE_SEARCH.ndjson", "ORGANIZATION_SEARCH.ndjson", "AUTONOMY_RUN_LOG.ndjson"):
        path = ROOT / name
        if not path.exists():
            path.write_text("", encoding="utf-8")
    print(json.dumps({"parent_count": len(packages), "parent_map": parent_map["content_sha256"], "kernel": runtime["observed_hashes"]}, indent=2))


if __name__ == "__main__":
    main()
