#!/usr/bin/env python3
"""Integrated semantic-4 scaffold with mutable s_reg memory and native gradient readout."""
from __future__ import annotations

import numpy as np

from ing02_common import NativeWorld, add, pack, read, summarize


M_TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))
C_TETRA = ((1, 0, 0), (0, -1, 0), (0, 0, 1), (1, -1, 1))
EVENT_OFFSET = (-1, 0, 0)
EVENT_DIRECTION = (-1, 0, 0)
CONTROL_DIRECTION = (0, 1, 0)
TREATMENT_DIRECTION = (1, 1, 0)


def _observer(raw, clock, q, state, sreg):
    if int(raw[q]):
        existing = read(raw, q)
        if existing["semantic"] != 4:
            raise RuntimeError(f"non-observer overlap at {q}: {existing}")
        return
    raw[q] = pack(state, sreg, (0, 0, 0), 4)
    clock[q] = np.uint64(1000 + state)


def construct_integrated_scaffold(kernel, n=23, origin=None, experience=True, mode="treatment"):
    m = tuple(origin or (n // 2,) * 3)
    c = add(m, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[m] = pack(100, 100, (0, 0, 0), 1)
    clock[m] = np.uint64(260)
    raw[c] = pack(200, 7, CONTROL_DIRECTION, 1)
    clock[c] = np.uint64(41)

    # Memory tetra: comparator itself is one of the four active supports.
    for index, offset in enumerate(M_TETRA[1:], start=1):
        _observer(raw, clock, add(m, offset, 1, n), 1000 + index, 0)

    # Comparator tetra. Reference and bias are also functional gradient anchors.
    for index, offset in enumerate(C_TETRA):
        sreg = 100 if offset == (1, 0, 0) else 10 if offset == (0, -1, 0) else 0
        _observer(raw, clock, add(c, offset, 1, n), 2000 + index, sreg)

    event_q = add(m, EVENT_OFFSET, 1, n)
    if experience and mode != "no_experience":
        direction = (0, -1, 0) if mode == "wrong_event_direction" else EVENT_DIRECTION
        raw[event_q] = pack(3000, 3, direction, 1)
        clock[event_q] = np.uint64(31)
    if mode == "no_memory_scaffold":
        raw[add(m, (0, 1, 0), 1, n)] = np.uint64(0)
    if mode == "no_reference":
        raw[add(c, (1, 0, 0), 1, n)] = np.uint64(0)
    if mode == "equalized_memory":
        clock[m] = np.uint64(261)
    world = NativeWorld(kernel, raw, clock)
    ports = {
        "memory": m,
        "comparator": c,
        "control_output": add(c, CONTROL_DIRECTION, 1, n),
        "treatment_output": add(c, TREATMENT_DIRECTION, 1, n),
        "event_start": event_q,
    }
    return world, ports


def run_integrated_case(kernel, challenge):
    world, ports = construct_integrated_scaffold(
        kernel,
        n=int(challenge.get("n", 23)),
        origin=tuple(challenge["origin"]) if "origin" in challenge else None,
        experience=bool(challenge.get("experience", True)),
        mode=challenge.get("mode", "treatment"),
    )
    horizon = int(challenge.get("horizon", 16))
    trace = []
    direction_divergence_tick = None
    for tick in range(1, horizon + 1):
        info = world.tick()
        memory = read(world.raw, ports["memory"])
        comparator = read(world.raw, ports["comparator"])
        record = {
            "tick": tick,
            "memory": memory,
            "comparator": comparator,
            "control_output": read(world.raw, ports["control_output"]),
            "treatment_output": read(world.raw, ports["treatment_output"]),
            "support": int(np.count_nonzero(world.raw)),
            "kernel": {str(k): int(v) if isinstance(v, (int, np.integer)) else v for k, v in info.items()},
        }
        if comparator is not None and tuple(comparator["direction"]) == TREATMENT_DIRECTION and direction_divergence_tick is None:
            direction_divergence_tick = tick
        if tick <= 8 or tick in {16, 32, 64, 128, 256, 512, 1024}:
            trace.append(record)
    terminal_memory = read(world.raw, ports["memory"])
    terminal_comparator = read(world.raw, ports["comparator"])
    observers_intact = True
    # Every semantic-4 coordinate is immutable; count is a compact integrity check.
    observers_intact = summarize(world.raw)["semantic_counts"].get("4", 0) == 7
    return {
        "challenge_id": challenge.get("challenge_id", "discovery"),
        "mode": challenge.get("mode", "treatment"),
        "experience": bool(challenge.get("experience", True)),
        "n": world.n,
        "origin": list(ports["memory"]),
        "horizon": horizon,
        "ports": {key: list(value) for key, value in ports.items()},
        "direction_divergence_tick": direction_divergence_tick,
        "terminal_memory": terminal_memory,
        "terminal_comparator": terminal_comparator,
        "observers_intact": observers_intact,
        "terminal": summarize(world.raw, world.clock_a),
        "trace": trace,
        "python_interventions_after_t0": 0,
    }
