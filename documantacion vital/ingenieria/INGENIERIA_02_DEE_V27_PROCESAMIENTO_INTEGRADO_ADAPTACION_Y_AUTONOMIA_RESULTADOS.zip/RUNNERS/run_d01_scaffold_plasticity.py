#!/usr/bin/env python3
"""Discovery: immutable semantic-4 scaffold supporting an experience-sensitive mutable center."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import NativeWorld, ROOT, add, fields, load_kernel, pack, read, seal, summarize, write_json


TETRA = ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1))
EVENT_OFFSETS = ((-1, 0, 0), (0, -1, 0), (0, 0, -1), (-1, -1, 0), (-1, 0, -1), (0, -1, -1))
DIRECTIONS = tuple(v for v in itertools.product((-1, 0, 1), repeat=3) if v != (0, 0, 0))


def make_world(kernel, n, q, event_offset=None, event_direction=None, center_clock=260, center_direction=(1, 0, 0)):
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    raw[q] = pack(100, 100, center_direction, 1)
    clock[q] = np.uint64(center_clock)
    for index, offset in enumerate(TETRA):
        p = add(q, offset, 1, n)
        raw[p] = pack(1000 + index, 10, (0, 0, 0), 4)
        clock[p] = np.uint64(17 + index)
    if event_offset is not None:
        p = add(q, event_offset, 1, n)
        if int(raw[p]):
            raise RuntimeError("event overlaps scaffold")
        raw[p] = pack(2000, 3, event_direction, 1)
        clock[p] = np.uint64(31)
    return NativeWorld(kernel, raw, clock), raw.copy(), clock.copy()


def trace_case(kernel, event_offset, event_direction, horizon=32, n=23):
    q = (n // 2,) * 3
    treatment, _, _ = make_world(kernel, n, q, event_offset, event_direction)
    control, _, _ = make_world(kernel, n, q)
    rows = []
    for tick in range(1, horizon + 1):
        treatment.tick()
        control.tick()
        tr = read(treatment.raw, q)
        cr = read(control.raw, q)
        event_pos = add(add(q, event_offset, 1, n), event_direction, tick, n)
        if tick <= 8 or tick in {16, 32}:
            rows.append(
                {
                    "tick": tick,
                    "treatment_center": tr,
                    "control_center": cr,
                    "center_sreg_delta": None if tr is None or cr is None else tr["sreg"] - cr["sreg"],
                    "treatment_support": int(np.count_nonzero(treatment.raw)),
                    "control_support": int(np.count_nonzero(control.raw)),
                    "expected_event_position": list(event_pos),
                    "event_record": read(treatment.raw, event_pos),
                }
            )
    tr = read(treatment.raw, q)
    cr = read(control.raw, q)
    scaffold_fixed = all(
        read(treatment.raw, add(q, offset, 1, n))["semantic"] == 4 for offset in TETRA
    )
    return {
        "event_offset": list(event_offset),
        "event_direction": list(event_direction),
        "center_survives": tr is not None and cr is not None,
        "terminal_sreg_delta": None if tr is None or cr is None else tr["sreg"] - cr["sreg"],
        "terminal_direction_equal": None if tr is None or cr is None else tr["direction"] == cr["direction"],
        "scaffold_fixed": scaffold_fixed,
        "treatment_terminal": summarize(treatment.raw, treatment.clock_a),
        "control_terminal": summarize(control.raw, control.clock_a),
        "trace": rows,
    }


def main() -> None:
    kernel, runtime = load_kernel(1)
    cases = []
    for offset in EVENT_OFFSETS:
        outward = [direction for direction in DIRECTIONS if sum(offset[i] * direction[i] for i in range(3)) > 0]
        for direction in outward:
            cases.append(trace_case(kernel, offset, direction))
    candidates = [
        row
        for row in cases
        if row["center_survives"] and row["scaffold_fixed"] and row["terminal_sreg_delta"] == 1
    ]
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.scaffold_plasticity.v1",
            "question": "Can a persistent semantic-4 organization support an experience-sensitive mutable semantic-1 degree of freedom?",
            "apparatus": {
                "center": "semantic1 state=100 s_reg=100 clock=260 nonzero direction",
                "scaffold": "four semantic4 cells in a tetra signature",
                "experience": "one transient ballistic neighbor present during the first update",
                "control": "same scaffold and center without transient neighbor",
                "horizon": 32,
            },
            "mechanism_prediction": "At center clock 260, n_active=5 increments s_reg (period 260), while n_active=4 control does not (period 195).",
            "case_count": len(cases),
            "candidate_count": len(candidates),
            "cases": cases,
            "candidate_indices": [cases.index(row) for row in candidates],
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D01_SCAFFOLD_PLASTICITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "cases": len(cases), "candidates": len(candidates), "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
