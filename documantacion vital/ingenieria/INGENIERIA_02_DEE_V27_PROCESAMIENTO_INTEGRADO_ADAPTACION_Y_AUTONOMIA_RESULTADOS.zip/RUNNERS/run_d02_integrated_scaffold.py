#!/usr/bin/env python3
"""Discovery panel for integrated stable scaffold, mutable memory, and native readout."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, seal, write_json
from integrated_scaffold_apparatus_v1 import run_integrated_case


def main() -> None:
    kernel, runtime = load_kernel(1)
    cases = []
    index = 0
    for n in (17, 23, 29):
        for mode, experience in (
            ("treatment", True),
            ("no_experience", False),
            ("wrong_event_direction", True),
            ("no_memory_scaffold", True),
            ("no_reference", True),
            ("equalized_memory", True),
        ):
            index += 1
            cases.append(
                run_integrated_case(
                    kernel,
                    {
                        "challenge_id": f"D02-{index:03d}",
                        "n": n,
                        "origin": [n // 2, n // 2, n // 2],
                        "horizon": 32,
                        "mode": mode,
                        "experience": experience,
                    },
                )
            )
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.integrated_scaffold.v1",
            "question": "Can organization-level stability, experience-written s_reg, and native gradient readout coexist?",
            "prediction": "Treatment experience increments memory s_reg at tick1; comparator changes from (0,1,0) to (1,1,0) after one causal delay while semantic4 scaffold remains fixed.",
            "cases": cases,
            "summary": {
                "treatment_worlds": sum(row["mode"] == "treatment" for row in cases),
                "treatment_direction_diverged": sum(row["mode"] == "treatment" and row["direction_divergence_tick"] is not None for row in cases),
                "scaffolds_intact": sum(row["observers_intact"] for row in cases),
            },
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D02_INTEGRATED_SCAFFOLD.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
