#!/usr/bin/env python3
"""Discovery of experience-written memory and later native functional readout."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, seal, write_json
from integrated_scaffold_apparatus_v2 import run_integrated_case_v2


def main() -> None:
    kernel, runtime = load_kernel(1)
    frames = []
    for permutation in itertools.permutations(range(3)):
        for signs in itertools.product((-1, 1), repeat=3):
            frames.append((permutation, signs))
    cases = []
    modes = (
        "treatment",
        "no_experience",
        "wrong_phase",
        "wrong_experience_route",
        "missing_memory_support",
        "missing_comparator_support",
        "unbalanced_reference",
        "no_reader",
    )
    for frame_index, (permutation, signs) in enumerate(frames):
        for mode in modes:
            cases.append(
                run_integrated_case_v2(
                    kernel,
                    {
                        "challenge_id": f"D03-{frame_index:02d}-{mode}",
                        "n": 29,
                        "origin": [14, 14, 14],
                        "permutation": permutation,
                        "signs": signs,
                        "mode": mode,
                        "horizon": 16,
                    },
                )
            )
    treatment = [row for row in cases if row["mode"] == "treatment"]
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.integrated_write_read.v1",
            "question": "Can a persistent organization retain an experience-written causal difference and later convert it to a native policy direction?",
            "apparatus_logic": [
                "memory semantic1 is supported by four immutable semantic4 sites",
                "experience transient changes n_active 4->5 at clock phase 260 and writes +1 s_reg",
                "reader arrives after the write and is stabilized by a separate semantic4 half-space scaffold",
                "balanced gradient converts s_reg 100 versus 101 into distinct nonzero policy directions",
            ],
            "cases": cases,
            "summary": {
                "frames": len(frames),
                "worlds": len(cases),
                "treatment_exact": sum(row["treatment_policy_exact_at_tick2"] is True for row in treatment),
                "treatment_worlds": len(treatment),
                "treatment_semantic4_intact": sum(row["semantic4_count"] == 10 for row in treatment),
                "treatment_functional_output_exact": sum(
                    row["functional_output_at_tick3"]["decoded_policy"] == "treatment" for row in treatment
                ),
            },
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D03_INTEGRATED_WRITE_READ.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
