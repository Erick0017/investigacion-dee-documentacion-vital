#!/usr/bin/env python3
"""Continue integrated organizations to natural functional failure or safety horizon."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, fields, load_kernel, read, seal, summarize, write_json
from integrated_scaffold_apparatus_v2 import construct


HORIZONS = {11: 20_000, 17: 20_000, 23: 20_000, 29: 20_000}


def run_world(kernel, n, mode):
    world, ports, vectors = construct(
        kernel,
        {"n": n, "origin": (n // 2,) * 3, "mode": mode, "permutation": (0, 1, 2), "signs": (1, 1, 1)},
    )
    expected_memory = 101 if mode == "treatment" else 100
    first_memory_delta_loss = None
    first_policy_failure = None
    first_center_loss = None
    mismatch_ticks = []
    telemetry = []
    sample_ticks = {1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 512, 1000, 2000, 5000, 10000, 20000}
    for tick in range(1, HORIZONS[n] + 1):
        info = world.tick()
        memory = read(world.raw, ports["memory"])
        comparator = read(world.raw, ports["comparator"])
        if memory is None or comparator is None:
            if first_center_loss is None:
                first_center_loss = tick
            functional = False
        else:
            dx = comparator["direction"][0]
            functional = (dx != 0) if mode == "treatment" else (dx == 0)
            expected_delta = 1 if mode == "treatment" else 0
            # Both regimes can accrue the same later autonomous increments; compare modulo the
            # initial one-count distinction through a separately paired analysis below.
            if tick <= 259 and memory["sreg"] != expected_memory and first_memory_delta_loss is None:
                first_memory_delta_loss = tick
        if tick >= 2 and not functional:
            mismatch_ticks.append(tick)
            if first_policy_failure is None:
                first_policy_failure = tick
        if tick in sample_ticks or (first_policy_failure is not None and tick == first_policy_failure):
            telemetry.append(
                {
                    "tick": tick,
                    "memory": memory,
                    "comparator": comparator,
                    "support": int(np.count_nonzero(world.raw)),
                    "semantic4": int(np.sum(fields(world.raw)["semantic"] == 4)),
                    "kernel": {str(k): int(v) if isinstance(v, (int, np.integer)) else v for k, v in info.items()},
                    "functional": functional,
                }
            )
        if first_policy_failure is not None and tick > first_policy_failure + 256:
            break
    return {
        "n": n,
        "mode": mode,
        "ticks_executed": tick,
        "safety_horizon": HORIZONS[n],
        "first_policy_failure": first_policy_failure,
        "first_center_loss": first_center_loss,
        "first_early_memory_failure": first_memory_delta_loss,
        "policy_lifetime_lower_bound": tick if first_policy_failure is None else first_policy_failure - 1,
        "mismatch_count_observed": len(mismatch_ticks),
        "mismatch_ticks_head": mismatch_ticks[:32],
        "terminal": summarize(world.raw, world.clock_a),
        "telemetry": telemetry,
        "python_interventions_after_t0": 0,
    }


def main() -> None:
    kernel, runtime = load_kernel(1)
    rows = []
    for n in HORIZONS:
        rows.append(run_world(kernel, n, "treatment"))
        rows.append(run_world(kernel, n, "no_experience"))
    paired = []
    for n in HORIZONS:
        treatment = next(row for row in rows if row["n"] == n and row["mode"] == "treatment")
        control = next(row for row in rows if row["n"] == n and row["mode"] == "no_experience")
        paired.append(
            {
                "n": n,
                "treatment_policy_lifetime": treatment["policy_lifetime_lower_bound"],
                "control_policy_lifetime": control["policy_lifetime_lower_bound"],
                "treatment_failure": treatment["first_policy_failure"],
                "control_failure": control["first_policy_failure"],
            }
        )
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.integrated_regime_longevity.v1",
            "question": "Does the experience-written integrated policy persist without Python maintenance?",
            "safety_rule": "Stop at 20,000 ticks or 256 ticks after first functional failure; no repair or replenishment by Python.",
            "rows": rows,
            "paired_summary": paired,
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D04_REGIME_LONGEVITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "paired": paired, "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
