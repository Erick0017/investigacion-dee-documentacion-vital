#!/usr/bin/env python3
"""Discovery of native transition from writable memory to consolidated support."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, fields, load_kernel, read, seal, summarize, write_json
from integrated_scaffold_apparatus_v2 import construct


def run_case(kernel, n, mode, horizon=5000):
    experience_mode = "treatment" if mode == "unconsolidated_treatment" else mode
    world, ports, vectors = construct(
        kernel,
        {
            "n": n,
            "origin": (n // 2,) * 3,
            "mode": experience_mode,
            "permutation": (0, 1, 2),
            "signs": (1, 1, 1),
            "consolidate": mode != "unconsolidated_treatment",
        },
    )
    expected_treatment = mode in {"treatment", "unconsolidated_treatment"}
    first_failure = None
    telemetry = []
    samples = {1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 512, 524, 1000, 2000, 5000}
    for tick in range(1, horizon + 1):
        info = world.tick()
        memory = read(world.raw, ports["memory"])
        comparator = read(world.raw, ports["comparator"])
        dx = None if comparator is None else comparator["direction"][0]
        functional = (dx != 0) if expected_treatment else (dx == 0)
        if tick >= 2 and not functional and first_failure is None:
            first_failure = tick
        if tick in samples:
            telemetry.append(
                {
                    "tick": tick,
                    "memory": memory,
                    "comparator": comparator,
                    "lock_support": [read(world.raw, q) for q in ports["lock_targets"]],
                    "functional": functional,
                    "support": int(np.count_nonzero(world.raw)),
                    "semantic4": int(np.sum(fields(world.raw)["semantic"] == 4)),
                    "kernel": {str(k): int(v) if isinstance(v, (int, np.integer)) else v for k, v in info.items()},
                }
            )
    return {
        "n": n,
        "mode": mode,
        "horizon": horizon,
        "first_functional_failure": first_failure,
        "lifetime_lower_bound": horizon if first_failure is None else first_failure - 1,
        "terminal_memory": read(world.raw, ports["memory"]),
        "terminal_comparator": read(world.raw, ports["comparator"]),
        "terminal_lock_support": [read(world.raw, q) for q in ports["lock_targets"]],
        "terminal": summarize(world.raw, world.clock_a),
        "telemetry": telemetry,
        "python_interventions_after_t0": 0,
    }


def main() -> None:
    kernel, runtime = load_kernel(1)
    rows = []
    for n in (11, 17, 23, 29):
        for mode in ("treatment", "no_experience", "unconsolidated_treatment", "no_consolidation"):
            rows.append(run_case(kernel, n, mode))
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.native_consolidation.v1",
            "question": "Can the same organization be plastic during experience and then natively increase support to prevent later autonomous overwrite?",
            "mechanism": "Three state-zero directional ghosts are inactive during the write and route three active support cells into the memory neighborhood one tick later.",
            "rows": rows,
            "summary": {
                "treatment_5000_exact": sum(row["mode"] == "treatment" and row["first_functional_failure"] is None for row in rows),
                "control_5000_exact": sum(row["mode"] == "no_experience" and row["first_functional_failure"] is None for row in rows),
                "unconsolidated_failures": [row["first_functional_failure"] for row in rows if row["mode"] == "unconsolidated_treatment"],
                "no_consolidation_failures": [row["first_functional_failure"] for row in rows if row["mode"] == "no_consolidation"],
            },
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D05_NATIVE_CONSOLIDATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
