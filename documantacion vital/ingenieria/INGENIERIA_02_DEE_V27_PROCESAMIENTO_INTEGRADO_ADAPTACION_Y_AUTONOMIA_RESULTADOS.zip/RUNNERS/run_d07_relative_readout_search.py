#!/usr/bin/env python3
"""Search support geometries for nondestructive native readout of relative memory."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, seal, write_json
from paired_relative_apparatus_v1 import OUTWARD_PLANE, run_case


def at(row, tick, key):
    return next(record[key] for record in row["trace"] if record["tick"] == tick)


def main():
    kernel, runtime = load_kernel(1)
    patterns = list(itertools.combinations(OUTWARD_PLANE, 4))
    rows = []
    for index, pattern in enumerate(patterns):
        compact = [list(q) for q in pattern]
        treatment = run_case(kernel, {"challenge_id": f"D07-{index:03d}-T", "n": 23, "mode": "experience_a", "support_pattern": compact})
        control = run_case(kernel, {"challenge_id": f"D07-{index:03d}-C", "n": 23, "mode": "no_experience", "support_pattern": compact})
        both = run_case(kernel, {"challenge_id": f"D07-{index:03d}-B", "n": 23, "mode": "experience_both", "support_pattern": compact})
        t2, c2, b2 = at(treatment, 2, "comparator_x"), at(control, 2, "comparator_x"), at(both, 2, "comparator_x")
        tdelta, cdelta, bdelta = at(treatment, 2, "sreg_delta_a_minus_b"), at(control, 2, "sreg_delta_a_minus_b"), at(both, 2, "sreg_delta_a_minus_b")
        qualifies = tdelta == 1 and cdelta == 0 and bdelta == 0 and t2 not in {None, 0} and c2 == 0 and b2 == 0
        rows.append(
            {
                "pattern_index": index,
                "support_pattern": compact,
                "qualifies": qualifies,
                "tick2": {"treatment_x": t2, "control_x": c2, "both_x": b2, "treatment_delta": tdelta, "control_delta": cdelta, "both_delta": bdelta},
                "treatment": treatment if qualifies else None,
                "control": control if qualifies else None,
                "both": both if qualifies else None,
                "diagnostic": {"treatment": treatment, "control": control, "both": both} if index == 0 else None,
            }
        )
    qualifying = [row for row in rows if row["qualifies"]]
    result = seal(
        {
            "schema": "dee.v27.ing02.discovery.relative_readout_search.v1",
            "question": "Can a later native comparator read a persistent relation without contaminating the experience write?",
            "search_space": "All 126 choices of four semantic4 supports from the outward 3x3 plane, mirrored for the two memories.",
            "qualifying_count": len(qualifying),
            "patterns_tested": len(patterns),
            "rows": rows,
            "runtime": runtime,
        }
    )
    output = ROOT / "DISCOVERY" / "ING02_D07_RELATIVE_READOUT_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "patterns": len(patterns), "qualifying": len(qualifying), "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
