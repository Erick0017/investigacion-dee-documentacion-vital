#!/usr/bin/env python3
"""Search symmetry-related valid tetra supports for direct relative-state readout."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, seal, transform, write_json
from paired_relative_apparatus_v2 import BASE_TETRA, run_case


def unique_tetra():
    seen = set()
    result = []
    for perm in itertools.permutations(range(3)):
        for signs in itertools.product((-1, 1), repeat=3):
            pattern = tuple(sorted(transform(q, perm, signs) for q in BASE_TETRA))
            if pattern not in seen:
                seen.add(pattern)
                result.append(pattern)
    return result


def val(row, tick, key):
    return next(record[key] for record in row["trace"] if record["tick"] == tick)


def main():
    kernel, runtime = load_kernel(1)
    patterns = unique_tetra()
    rows = []
    invalid = 0
    for index, pa in enumerate(patterns):
        # Inversion makes the full support organization symmetric around the midpoint.
        pb = tuple(sorted(tuple(-v for v in q) for q in pa))
        common = {"n": 17, "support_pattern_a": [list(q) for q in pa], "support_pattern_b": [list(q) for q in pb], "horizon": 8}
        try:
            t = run_case(kernel, {**common, "challenge_id": f"D08-{index:03d}-T", "mode": "experience_a"})
            c = run_case(kernel, {**common, "challenge_id": f"D08-{index:03d}-C", "mode": "no_experience"})
            b = run_case(kernel, {**common, "challenge_id": f"D08-{index:03d}-B", "mode": "experience_both"})
        except RuntimeError as error:
            invalid += 1
            rows.append({"index": index, "pattern_a": common["support_pattern_a"], "pattern_b": common["support_pattern_b"], "invalid": str(error)})
            continue
        tick1_ok = val(t, 1, "delta") == 1 and val(c, 1, "delta") == 0 and val(b, 1, "delta") == 0
        # Allow the first usable comparator state at either tick 2 or 3.
        candidates = []
        for tick in (2, 3):
            tx, cx, bx = val(t, tick, "x"), val(c, tick, "x"), val(b, tick, "x")
            if tx not in {None, 0} and cx == 0 and bx == 0:
                candidates.append(tick)
        qualifies = tick1_ok and bool(candidates)
        rows.append({
            "index": index, "pattern_a": common["support_pattern_a"], "pattern_b": common["support_pattern_b"],
            "qualifies": qualifies, "qualifying_ticks": candidates,
            "diagnostics": {"tick1_ok": tick1_ok, "t_x": [val(t, i, "x") for i in (1,2,3)], "c_x": [val(c, i, "x") for i in (1,2,3)], "b_x": [val(b, i, "x") for i in (1,2,3)]},
            "treatment": t if qualifies else None, "control": c if qualifies else None, "both": b if qualifies else None,
        })
    qualifying = [row for row in rows if row.get("qualifies")]
    result = seal({
        "schema": "dee.v27.ing02.discovery.relative_tetra_readout_search.v1",
        "question": "Can a topologically valid symmetric support organization expose relative s_reg to a midpoint native reader?",
        "patterns_tested": len(patterns), "invalid_geometries": invalid, "qualifying_count": len(qualifying),
        "rows": rows, "runtime": runtime,
    })
    output = ROOT / "DISCOVERY" / "ING02_D08_RELATIVE_TETRA_READOUT_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "patterns": len(patterns), "invalid": invalid, "qualifying": len(qualifying), "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
