#!/usr/bin/env python3
"""Map phase-conditioned correctness of the native relative-state reader."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, read, seal, write_json
from paired_relative_apparatus_v2 import construct
from run_d09_relative_readout_longevity import PATTERN_A, PATTERN_B


def rle(values):
    result = []
    start = 1
    previous = values[0]
    for index, value in enumerate(values[1:], start=2):
        if value != previous:
            result.append([start, index - 1, previous])
            start, previous = index, value
    result.append([start, len(values), previous])
    return result


def run_phase(kernel, phase, mode, horizon=2000):
    world, ports = construct(kernel, {
        "n": 17, "origin": (8,8,8), "mode": mode, "reader_phase": phase,
        "support_pattern_a": PATTERN_A, "support_pattern_b": PATTERN_B,
    })
    xs = []
    deltas = []
    for _ in range(horizon):
        world.tick()
        a, b, c = (read(world.raw, ports[k]) for k in ("a","b","comparator"))
        xs.append(None if c is None else c["direction"][0])
        deltas.append(None if a is None or b is None else a["sreg"] - b["sreg"])
    expected = (lambda x: x is not None and x > 0) if mode == "experience_a" else (lambda x: x == 0)
    correct = [bool(expected(x)) for x in xs]
    return {
        "phase": phase, "mode": mode, "horizon": horizon,
        "correct_ticks_after_latency": sum(correct[1:]), "evaluated_ticks_after_latency": horizon - 1,
        "accuracy_after_latency": sum(correct[1:]) / (horizon - 1),
        "first_failure_after_latency": next((i for i, ok in enumerate(correct, start=1) if i >= 2 and not ok), None),
        "x_rle": rle(xs), "correct_rle": rle(correct),
        "delta_unique": sorted(set(v for v in deltas if v is not None)),
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    phases = list(range(0, 195, 13))
    rows = [run_phase(kernel, phase, mode) for phase in phases for mode in ("experience_a","no_experience")]
    result = seal({
        "schema": "dee.v27.ing02.discovery.reader_phase_panel.v1",
        "question": "Are relative-reader sign errors phase-local and therefore suppressible by an internally redundant phase ensemble?",
        "phases": phases, "rows": rows,
        "summary": {
            "best_treatment": max((r for r in rows if r["mode"] == "experience_a"), key=lambda r: r["accuracy_after_latency"]),
            "control_exact": sum(r["mode"] == "no_experience" and r["first_failure_after_latency"] is None for r in rows),
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION" / "ING02_D10_READER_PHASE_PANEL.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "best": result["summary"]["best_treatment"]["phase"], "accuracy": result["summary"]["best_treatment"]["accuracy_after_latency"], "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
