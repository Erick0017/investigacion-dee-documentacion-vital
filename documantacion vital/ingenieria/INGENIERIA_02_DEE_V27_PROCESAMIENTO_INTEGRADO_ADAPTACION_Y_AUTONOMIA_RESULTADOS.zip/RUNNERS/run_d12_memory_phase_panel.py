#!/usr/bin/env python3
"""Test write-compatible memory phases as temporal redundancy coordinates."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, read, seal, write_json
from paired_relative_apparatus_v2 import construct
from run_d09_relative_readout_longevity import PATTERN_A, PATTERN_B


def rle(values):
    out=[]; start=1; prev=values[0]
    for i,v in enumerate(values[1:], start=2):
        if v != prev:
            out.append([start,i-1,prev]); start=i; prev=v
    out.append([start,len(values),prev]); return out


def run(kernel, memory_phase, mode, horizon=2000):
    world, ports = construct(kernel, {
        "n":17, "origin":(8,8,8), "mode":mode, "reader_phase":23, "memory_phase":memory_phase,
        "support_pattern_a":PATTERN_A, "support_pattern_b":PATTERN_B,
    })
    correct=[]; deltas=[]; xs=[]
    for _ in range(horizon):
        world.tick()
        a,b,c=(read(world.raw,ports[k]) for k in ("a","b","comparator"))
        delta=None if a is None or b is None else a["sreg"]-b["sreg"]
        x=None if c is None else c["direction"][0]
        deltas.append(delta); xs.append(x)
        correct.append(x is not None and x>0 if mode=="experience_a" else x==0)
    return {
        "memory_phase":memory_phase,"mode":mode,"horizon":horizon,
        "delta_at_tick1":deltas[0],"delta_unique":sorted(set(v for v in deltas if v is not None)),
        "accuracy_after_latency":sum(correct[1:])/(horizon-1),
        "first_failure_after_latency":next((i for i,v in enumerate(correct,start=1) if i>=2 and not v),None),
        "x_rle":rle(xs),"correct_rle":rle(correct),"python_interventions_after_t0":0,
    }


def main():
    kernel,runtime=load_kernel(1)
    phases=[260*k for k in (1,2,4,5,7,8,10,11)]
    rows=[run(kernel,p,m) for p in phases for m in ("experience_a","no_experience")]
    result=seal({
        "schema":"dee.v27.ing02.model_selection.memory_phase_panel.v1",
        "question":"Can write-compatible memory phase classes distribute reader failure times while preserving the same experience write?",
        "phases":phases,"rows":rows,
        "summary":{"best_treatment":max((r for r in rows if r["mode"]=="experience_a"),key=lambda r:r["accuracy_after_latency"]),"control_exact":sum(r["mode"]=="no_experience" and r["first_failure_after_latency"] is None for r in rows)},
        "runtime":runtime,
    })
    output=ROOT/"MECHANISM_SELECTION"/"ING02_D12_MEMORY_PHASE_PANEL.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
