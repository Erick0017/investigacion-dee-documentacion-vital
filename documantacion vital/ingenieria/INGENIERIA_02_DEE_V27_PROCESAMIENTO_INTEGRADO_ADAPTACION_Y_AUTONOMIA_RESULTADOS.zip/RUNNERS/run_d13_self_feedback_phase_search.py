#!/usr/bin/env python3
"""System-first search for action-induced regime transitions in relative memory."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing02_common import ROOT, load_kernel, read, seal, summarize, write_json
from paired_relative_apparatus_v2 import construct
from run_d09_relative_readout_longevity import PATTERN_A, PATTERN_B


def rle(values):
    out=[]; start=1; prev=values[0]
    for i,v in enumerate(values[1:],start=2):
        if v!=prev: out.append([start,i-1,prev]);start=i;prev=v
    out.append([start,len(values),prev]);return out


def sign(value):
    return None if value is None else (1 if value>0 else -1 if value<0 else 0)


def run(kernel, offset, reader_enabled, horizon=1024):
    world,ports=construct(kernel,{
        "n":17,"origin":(8,8,8),"mode":"experience_a","experience_a":True,
        "memory_phase_a":260,"memory_phase_b":260+offset,"reader_phase":23,
        "reader_enabled":reader_enabled,"support_pattern_a":PATTERN_A,"support_pattern_b":PATTERN_B,
    })
    deltas=[];xs=[];supports=[];centers=True
    for _ in range(horizon):
        world.tick();a,b,c=(read(world.raw,ports[k]) for k in ("a","b","comparator"))
        if a is None or b is None: centers=False
        delta=None if a is None or b is None else a["sreg"]-b["sreg"]
        deltas.append(delta);xs.append(None if c is None else c["direction"][0]);supports.append(int(np.count_nonzero(world.raw)))
    signs=[sign(v) for v in deltas]
    transitions=sum(signs[i]!=signs[i-1] for i in range(1,len(signs)))
    return {"offset":offset,"reader_enabled":reader_enabled,"horizon":horizon,"centers_survive":centers,
            "delta_rle":rle(deltas),"delta_sign_transitions":transitions,"x_rle":rle(xs),
            "support_max":max(supports),"terminal":summarize(world.raw,world.clock_a),"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1);rows=[]
    for offset in range(-20,21):
        rows.append(run(kernel,offset,True));rows.append(run(kernel,offset,False))
    paired=[]
    for offset in range(-20,21):
        active=next(r for r in rows if r["offset"]==offset and r["reader_enabled"])
        cut=next(r for r in rows if r["offset"]==offset and not r["reader_enabled"])
        action_changes_trajectory=active["delta_rle"]!=cut["delta_rle"]
        paired.append({"offset":offset,"action_changes_trajectory":action_changes_trajectory,
                       "active_transitions":active["delta_sign_transitions"],"cut_transitions":cut["delta_sign_transitions"],
                       "active_support_max":active["support_max"],"cut_support_max":cut["support_max"]})
    candidates=[p for p in paired if p["action_changes_trajectory"] and p["active_transitions"]>=2]
    result=seal({"schema":"dee.v27.ing02.discovery.self_feedback_phase_search.v1",
        "question":"Can the relative reader's own action collision move the memory organization between recurrent regimes?",
        "search":"B clock offset -20..20; paired reader-present and route-cut worlds; fixed experience writes A at tick1.",
        "rows":rows,"paired":paired,"candidate_offsets":[p["offset"] for p in candidates],"runtime":runtime})
    output=ROOT/"DISCOVERY"/"ING02_D13_SELF_FEEDBACK_PHASE_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"candidates":result["candidate_offsets"],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
