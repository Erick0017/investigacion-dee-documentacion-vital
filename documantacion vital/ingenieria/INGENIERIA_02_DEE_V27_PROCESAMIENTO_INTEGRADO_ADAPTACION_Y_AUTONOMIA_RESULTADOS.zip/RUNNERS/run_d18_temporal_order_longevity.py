#!/usr/bin/env python3
"""Continue zero-payload AB/BA order organizations to a safety horizon."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,load_kernel,read,seal,summarize,write_json
from temporal_order_apparatus_v1 import construct


def run(kernel,n,mode,horizon=2000):
    world,ports=construct(kernel,{"n":n,"origin":(n//2,)*3,"mode":mode,"event_sreg":0})
    expected=1 if mode=="AB" else -1 if mode=="BA" else 0
    first_delta_failure=None;first_output_failure=None;samples={1,2,3,4,8,16,32,64,128,256,512,1024,horizon};telemetry=[]
    for tick in range(1,horizon+1):
        info=world.tick();a,b,c=(read(world.raw,ports[k]) for k in ("a","b","comparator"));d=None if a is None or b is None else a["sreg"]-b["sreg"];x=None if c is None else c["direction"][0]
        if d!=expected and first_delta_failure is None:first_delta_failure=tick
        if tick>=16 and x!=expected and first_output_failure is None:first_output_failure=tick
        if tick in samples or tick in {first_delta_failure,first_output_failure}:
            telemetry.append({"tick":tick,"delta":d,"x":x,"a":a,"b":b,"comparator":c,"support":int(np.count_nonzero(world.raw)),"kernel":{str(k):int(v) if isinstance(v,(int,np.integer)) else v for k,v in info.items()}})
    return {"n":n,"mode":mode,"expected":expected,"horizon":horizon,"first_delta_failure":first_delta_failure,"first_output_failure":first_output_failure,
        "terminal":summarize(world.raw,world.clock_a),"telemetry":telemetry,"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,n,m) for n in (17,23,29) for m in ("AB","BA","simultaneous_early","no_events")]
    result=seal({"schema":"dee.v27.ing02.model_selection.temporal_order_longevity.v1","question":"Do experience-written order and native action persist after initial transients?",
        "safety_horizon":2000,"rows":rows,"summary":{"order_exact":sum(r["mode"] in {"AB","BA"} and r["first_delta_failure"] is None and r["first_output_failure"] is None for r in rows),"order_worlds":sum(r["mode"] in {"AB","BA"} for r in rows),"control_exact":sum(r["mode"] not in {"AB","BA"} and r["first_delta_failure"] is None and r["first_output_failure"] is None for r in rows)},"runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION"/"ING02_D18_TEMPORAL_ORDER_LONGEVITY.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
