#!/usr/bin/env python3
"""Precommitted damage/recovery challenge for the learned AB organization."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,add,load_kernel,pack,read,seal,summarize,write_json
from temporal_order_apparatus_v1 import construct


DAMAGE_TICK=64
DIRECTION=(0,0,1)


def install_carrier(world,target,sreg,semantic,state=1):
    source=add(target,DIRECTION,-DAMAGE_TICK,world.n)
    if int(world.raw[source]):raise RuntimeError(f"damage source overlap {source}")
    world.inject(source,pack(state,sreg,DIRECTION,semantic),0)
    return source


def run(kernel,mode,horizon=256):
    world,ports=construct(kernel,{"n":73,"origin":(36,36,36),"mode":"AB","event_sreg":0})
    source=None;target=ports["a"]
    if mode=="damage_sreg0":source=install_carrier(world,target,0,1)
    elif mode=="damage_sreg_max":source=install_carrier(world,target,65535,1)
    elif mode=="damage_semantic7":source=install_carrier(world,target,0,7)
    elif mode=="sham_miss":source=install_carrier(world,add(target,(0,-3,0),1,world.n),65535,1)
    elif mode=="missing_support":world.clear(add(target,(-1,0,0),1,world.n))
    elif mode!="no_damage":raise ValueError(mode)
    exact=[];trace=[];a_before=None
    sample=set(range(60,73))|{1,2,4,8,16,32,96,128,192,256}
    for tick in range(1,horizon+1):
        info=world.tick();a,b,c=(read(world.raw,ports[k]) for k in ("a","b","comparator"));delta=None if a is None or b is None else a["sreg"]-b["sreg"];x=None if c is None else c["direction"][0]
        ok=delta==1 and x==1 if tick>=16 else None;exact.append(ok)
        if tick==DAMAGE_TICK-1:a_before=a
        if tick in sample:trace.append({"tick":tick,"a":a,"b":b,"delta":delta,"x":x,"exact":ok,"support":int(np.count_nonzero(world.raw)),"kernel":{str(k):int(v) if isinstance(v,(int,np.integer)) else v for k,v in info.items()}})
    post=exact[DAMAGE_TICK-1:]
    first_recovery=None
    for i in range(0,len(post)-31):
        if all(post[i:i+32]):first_recovery=DAMAGE_TICK+i;break
    a_at=next(r["a"] for r in trace if r["tick"]==DAMAGE_TICK)
    perturbation_changed_target=a_before!=a_at if mode.startswith("damage_") else None
    return {"mode":mode,"damage_tick":DAMAGE_TICK,"damage_source":None if source is None else list(source),"target":list(target),
        "perturbation_changed_target":perturbation_changed_target,"first_32_tick_recovery":first_recovery,
        "exact_pre_damage":all(v for v in exact[15:DAMAGE_TICK-1]),"exact_terminal":exact[-1],
        "trace":trace,"terminal":summarize(world.raw,world.clock_a),"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1);modes=("no_damage","sham_miss","damage_sreg0","damage_sreg_max","damage_semantic7","missing_support");rows=[run(kernel,m) for m in modes]
    result=seal({"schema":"dee.v27.ing02.adversarial.perturbation_recovery.v1",
        "question":"Is the learned order regime an attractor that restores its functional state after a precommitted local collision?",
        "damage":"Carrier trajectory fixed at t0; direct collision at tick64. Recovery requires 32 consecutive exact ticks without host repair.",
        "rows":rows,"runtime":runtime})
    output=ROOT/"ADVERSARIAL_CHALLENGE"/"ING02_D20_PERTURBATION_RECOVERY.json";write_json(output,result)
    print(json.dumps({"output":str(output),"rows":[{"mode":r["mode"],"changed":r["perturbation_changed_target"],"recovery":r["first_32_tick_recovery"],"terminal":r["exact_terminal"]} for r in rows],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
