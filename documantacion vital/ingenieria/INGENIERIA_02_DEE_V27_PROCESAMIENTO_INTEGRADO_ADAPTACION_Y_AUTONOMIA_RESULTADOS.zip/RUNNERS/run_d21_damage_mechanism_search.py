#!/usr/bin/env python3
"""Discovery-only calibration of a genuine local perturbation to learned relative memory."""
from __future__ import annotations

import itertools,json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,summarize,write_json
from temporal_order_apparatus_v1 import construct


DIRECTIONS=tuple(v for v in itertools.product((-1,0,1),repeat=3) if v!=(0,0,0))


def family(name):
    if name=="all":return DIRECTIONS
    axis={"px":(0,1),"nx":(0,-1),"py":(1,1),"ny":(1,-1),"pz":(2,1),"nz":(2,-1)}[name]
    return tuple(d for d in DIRECTIONS if d[axis[0]]==axis[1])


def clone(kernel,raw,clock):return NativeWorld(kernel,raw,clock)


def main():
    kernel,runtime=load_kernel(1)
    base,ports=construct(kernel,{"n":29,"origin":(14,14,14),"mode":"AB","event_sreg":0})
    for _ in range(16):base.tick()
    base_raw=base.raw.copy();base_clock=base.clock_a.copy();target=ports["a"];before=read(base_raw,target)
    rows=[]
    for fname in ("px","nx","py","ny","pz","nz","all"):
        for semantic in (1,7):
            for sreg in (0,65535):
                world=clone(kernel,base_raw,base_clock);installed=[]
                for index,d in enumerate(family(fname)):
                    source=add(target,d,-1,world.n)
                    if int(world.raw[source]):continue
                    world.inject(source,pack(7000+index,sreg,d,semantic),0);installed.append({"source":list(source),"direction":list(d)})
                world.tick();after=read(world.raw,target);b=read(world.raw,ports["b"]);c=read(world.raw,ports["comparator"])
                rows.append({"family":fname,"semantic":semantic,"sreg":sreg,"installed":installed,"carrier_count":len(installed),
                    "before":before,"after":after,"target_changed":after!=before,"delta":None if after is None or b is None else after["sreg"]-b["sreg"],
                    "x":None if c is None else c["direction"][0],"terminal":summarize(world.raw,world.clock_a),
                    "discovery_python_intervention":"snapshot after tick16 then inject adjacent perturbation carriers before one diagnostic tick"})
    effective=[r for r in rows if r["target_changed"] and (r["after"] is None or r["delta"]!=1)]
    result=seal({"schema":"dee.v27.ing02.discovery.damage_mechanism_search.v1",
        "question":"What precommittable carrier collision genuinely changes the learned memory, so recovery can be tested without a sham perturbation?",
        "base":"AB learned organization after 16 native ticks; Python injection used only for adversarial mechanism calibration, not a native capability claim.",
        "rows":rows,"effective_count":len(effective),"effective_candidates":[{"family":r["family"],"semantic":r["semantic"],"sreg":r["sreg"],"carrier_count":r["carrier_count"],"delta":r["delta"],"after":r["after"]} for r in effective],"runtime":runtime})
    output=ROOT/"ADVERSARIAL_CHALLENGE"/"ING02_D21_DAMAGE_MECHANISM_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"effective":result["effective_candidates"],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
