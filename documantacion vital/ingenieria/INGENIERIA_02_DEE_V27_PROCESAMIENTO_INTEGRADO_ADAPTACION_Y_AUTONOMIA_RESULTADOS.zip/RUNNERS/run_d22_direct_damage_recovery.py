#!/usr/bin/env python3
"""Explicit external damage followed by unassisted organization-level recovery test."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,add,load_kernel,pack,read,seal,summarize,write_json
from temporal_order_apparatus_v1 import construct
from run_d09_relative_readout_longevity import PATTERN_A


DAMAGE_AFTER_TICK=16


def functional(world,ports):
    a,b,c=(read(world.raw,ports[k]) for k in ("a","b","comparator"));d=None if a is None or b is None else a["sreg"]-b["sreg"];x=None if c is None else c["direction"][0]
    return d,x,a,b,c,(d==1 and x==1)


def apply_damage(world,ports,mode):
    a=ports["a"];c=ports["comparator"]
    if mode=="sham":return None
    if mode=="clear_comparator":world.clear(c);return c
    if mode=="corrupt_comparator":world.inject(c,pack(9999,65535,(-1,-1,-1),1),0);return c
    if mode=="clear_memory":world.clear(a);return a
    if mode=="corrupt_memory_sreg":
        old=read(world.raw,a);world.inject(a,pack(old["state"],0,(0,0,0),1),int(world.clock_a[a]));return a
    if mode=="clear_reader_source":world.clear(ports["reader_source"]);return ports["reader_source"]
    if mode=="clear_support":
        q=add(a,PATTERN_A[0],1,world.n);world.clear(q);return q
    raise ValueError(mode)


def run(kernel,mode,horizon=256):
    world,ports=construct(kernel,{"n":29,"origin":(14,14,14),"mode":"AB","event_sreg":0})
    pre=[]
    for tick in range(1,DAMAGE_AFTER_TICK+1):
        world.tick();pre.append(functional(world,ports))
    before={"a":read(world.raw,ports["a"]),"b":read(world.raw,ports["b"]),"comparator":read(world.raw,ports["comparator"]),"terminal":summarize(world.raw,world.clock_a)}
    damaged_q=apply_damage(world,ports,mode)
    immediately={"a":read(world.raw,ports["a"]),"b":read(world.raw,ports["b"]),"comparator":read(world.raw,ports["comparator"])}
    exact=[];trace=[]
    for dt in range(1,horizon+1):
        world.tick();d,x,a,b,c,ok=functional(world,ports);exact.append(ok)
        if dt<=12 or dt in {16,32,64,128,256}:trace.append({"ticks_after_damage":dt,"delta":d,"x":x,"a":a,"b":b,"comparator":c,"functional_exact":ok,"support":int(np.count_nonzero(world.raw))})
    recovery=None
    for i in range(len(exact)-31):
        if all(exact[i:i+32]):recovery=i+1;break
    return {"mode":mode,"damage_after_tick":DAMAGE_AFTER_TICK,"damaged_coordinate":None if damaged_q is None else list(damaged_q),
        "pre_damage_functional_exact":all(row[-1] for row in pre[15:]),"before":before,"immediately_after_damage":immediately,
        "first_32_tick_functional_recovery":recovery,"terminal_functional_exact":exact[-1],"trace":trace,"terminal":summarize(world.raw,world.clock_a),
        "python_role":"applied one declared external damage after tick16; performed no repair, routing, decision or state rewrite afterward"}


def main():
    kernel,runtime=load_kernel(1);modes=("sham","clear_comparator","corrupt_comparator","clear_memory","corrupt_memory_sreg","clear_reader_source","clear_support");rows=[run(kernel,m) for m in modes]
    result=seal({"schema":"dee.v27.ing02.adversarial.direct_damage_recovery.v1","question":"Which organization components are natively restored after real external corruption?",
        "interpretation_guard":"Recovery of the renewable comparator is functional component repair. It does not by itself prove repair of the learned relative state.","rows":rows,"runtime":runtime})
    output=ROOT/"ADVERSARIAL_CHALLENGE"/"ING02_D22_DIRECT_DAMAGE_RECOVERY.json";write_json(output,result)
    print(json.dumps({"output":str(output),"rows":[{"mode":r["mode"],"recovery":r["first_32_tick_functional_recovery"],"terminal":r["terminal_functional_exact"]} for r in rows],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
