#!/usr/bin/env python3
"""Exhaust symmetry frames before freezing the temporal-order apparatus."""
from __future__ import annotations

import itertools,json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,load_kernel,seal,write_json
from temporal_order_apparatus_v1 import run_case


def at(row,t):return next(r for r in row["trace"] if r["tick"]==t)


def main():
    kernel,runtime=load_kernel(1);frames=list(itertools.product(itertools.permutations(range(3)),itertools.product((-1,1),repeat=3)));rows=[];adjud=[]
    for i,(perm,signs) in enumerate(frames):
        for mode in ("AB","BA","simultaneous_early","no_events","route_cut"):
            row=run_case(kernel,{"challenge_id":f"D23-{i}-{mode}","n":31,"origin":(15,15,15),"mode":mode,"event_sreg":0,"permutation":perm,"signs":signs,"horizon":32});rows.append(row)
            expected=1 if mode=="AB" else -1 if mode=="BA" else 0
            expected_delta=1 if mode=="route_cut" else expected
            d=at(row,1)["delta"];vals=[at(row,t)["axis_projection"] for t in (16,32)]
            exact=d==expected_delta and (all(v==expected for v in vals) if mode!="route_cut" else all(v is None for v in vals))
            adjud.append({"frame":i,"permutation":list(perm),"signs":list(signs),"mode":mode,"delta":d,"projections":vals,"expected":expected,"expected_delta":expected_delta,"exact":exact})
    result=seal({"schema":"dee.v27.ing02.model_selection.temporal_frame_panel.v1","question":"Is experience-written AB/BA memory and action covariant across all 48 signed axis frames?",
        "rows":rows,"adjudication":adjud,"summary":{"frames":len(frames),"worlds":len(rows),"exact":sum(a["exact"] for a in adjud),"failed":[a for a in adjud if not a["exact"]]},"runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION"/"ING02_D23_TEMPORAL_FRAME_PANEL.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
