#!/usr/bin/env python3
"""Execute the locked fresh holdout without tuning."""
from __future__ import annotations

import json,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing02_common import ROOT,load_kernel,seal,sha256_file,write_json
from temporal_order_apparatus_v1 import run_case


def at(row,t):return next(r for r in row["trace"] if r["tick"]==t)


def main():
    lock_path=ROOT/"FREEZE"/"ING02_FINAL_LOCK.json";challenge_path=ROOT/"CHALLENGES"/"ING02_FINAL_CHALLENGES.json"
    lock=json.loads(lock_path.read_text(encoding="utf-8"));challenges=json.loads(challenge_path.read_text(encoding="utf-8"))
    for rel,expected in lock["files"].items():
        if sha256_file(ROOT/rel)!=expected:raise RuntimeError(f"freeze hash mismatch: {rel}")
    kernel,runtime=load_kernel(1);rows=[]
    for spec in challenges["challenges"]:
        result=run_case(kernel,spec);delta=at(result,1)["delta"];projections=[at(result,t)["axis_projection"] for t in (16,32,64)]
        exact=delta==spec["expected_delta"] and all(v==spec["expected_projection"] for v in projections) and result["python_interventions_after_t0"]==0
        rows.append({"challenge":spec,"result":result,"observed":{"delta_tick1":delta,"axis_projection_ticks_16_32_64":projections},"exact":exact})
    by_role={role:{"worlds":sum(r["challenge"]["role"]==role for r in rows),"exact":sum(r["challenge"]["role"]==role and r["exact"] for r in rows)} for role in ("treatment","control","canary")}
    out=seal({"schema":"dee.v27.ing02.holdout.result.v1","freeze_content_sha256":lock["content_sha256"],"challenge_content_sha256":challenges["content_sha256"],
        "rows":rows,"summary":{"worlds":len(rows),"exact":sum(r["exact"] for r in rows),"all_pass":all(r["exact"] for r in rows),"by_role":by_role},"runtime":runtime})
    output=ROOT/"HOLDOUT"/"ING02_FINAL_HOLDOUT.json";write_json(output,out)
    print(json.dumps({"output":str(output),"summary":out["summary"],"hash":out["content_sha256"]},indent=2))


if __name__=="__main__":main()
