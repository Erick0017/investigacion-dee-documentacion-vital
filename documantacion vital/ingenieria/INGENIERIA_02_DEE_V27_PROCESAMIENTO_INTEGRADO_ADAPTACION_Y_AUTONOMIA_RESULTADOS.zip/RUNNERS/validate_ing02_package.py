#!/usr/bin/env python3
"""Strict validator for the official compact INGENIERIA 02 package."""
from __future__ import annotations

import argparse
import hashlib
import json
import tempfile
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DEFAULT_ZIP = ROOT / "INGENIERIA_02_DEE_V27_PROCESAMIENTO_INTEGRADO_ADAPTACION_Y_AUTONOMIA_RESULTADOS.zip"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def canonical_hash(value: object) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def verify_seal(value: dict, label: str) -> None:
    expected = value.get("content_sha256")
    if not expected:
        return
    body = dict(value)
    body.pop("content_sha256")
    observed = canonical_hash(body)
    if observed != expected:
        raise AssertionError(f"content seal mismatch: {label}")


def find_parent(filename: str) -> Path:
    candidates = [
        ROOT.parents[1] / "CORE" / filename,
        ROOT.parent / "INGENIERIA_01" / filename,
    ]
    for candidate in candidates:
        if candidate.exists():
            return candidate
    raise FileNotFoundError(f"parent package missing: {filename}")


def validate(package: Path) -> dict:
    checks: list[str] = []
    with zipfile.ZipFile(package, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise AssertionError(f"ZIP integrity failed at {bad}")
        checks.append("ZIP_INTEGRITY_PASS")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise AssertionError("duplicate ZIP entry names")
        if any(name.lower().endswith(".zip") for name in names):
            raise AssertionError("embedded ZIP/parent package detected")
        if any("__pycache__" in name or name.endswith((".pyc", ".pyo")) for name in names):
            raise AssertionError("cache artifact detected")
        checks.append("PACKAGE_HYGIENE_PASS")

        required = {
            "ING02_EXECUTIVE_VERDICT.md",
            "ING02_PARENT_EVIDENCE_MAP.json",
            "ING02_CORE01_17_ING01_AUTONOMY_MECHANISM_GRAPH.json",
            "ING02_ORGANIZATION_SEARCH_REPORT.md",
            "ING02_INTEGRATED_ORGANIZATION_ATLAS.json",
            "ING02_ATTRACTOR_REGIME_ATLAS.json",
            "ING02_TEMPORAL_HISTORY_MEMORY.json",
            "ING02_NATIVE_ADDRESSING.json",
            "ING02_RESOURCE_MAINTENANCE.json",
            "ING02_REUSABLE_ADAPTATION.json",
            "ING02_AUTONOMY_LEVELS.json",
            "ING02_AUTONOMY_LIFETIME_SCALING.json",
            "ING02_FEEDBACK_ATLAS.json",
            "ING02_SELF_REPAIR.json",
            "ING02_DISTRIBUTED_MEMORY.json",
            "ING02_PLASTICITY_STABILITY_MAP.json",
            "ING02_GENERALIZATION_ATLAS.json",
            "ING02_CAPACITY_SCALING.json",
            "ING02_RESOURCE_ACCOUNTING.json",
            "ING02_NATIVE_PROCESSING_GRAMMAR.json",
            "ING02_NATIVE_LEARNING_GRAMMAR.json",
            "ING02_FAILURE_OBSTRUCTION_MAP.json",
            "ING02_PYTHON_INTERVENTION_AUDIT.json",
            "ING02_HARDCODE_LEAKAGE_AUDIT.json",
            "ING02_ADVERSARIAL_REVIEW.md",
            "ING02_FINAL_FRONTIER.md",
            "QUESTION_TREE.ndjson",
            "RESEARCH_DECISION_LOG.ndjson",
            "PREREQUISITE_SEARCH.ndjson",
            "ORGANIZATION_SEARCH.ndjson",
            "AUTONOMY_RUN_LOG.ndjson",
            "CLAIM_LEDGER.json",
            "HOLDOUT_REGISTRY.json",
            "CANARY_REGISTRY.json",
            "MANIFEST.json",
            "HASHES.sha256",
        }
        missing = required - set(names)
        if missing:
            raise AssertionError(f"required outputs missing: {sorted(missing)}")
        for name in required:
            if name.endswith(".ndjson") and not archive.read(name).strip():
                raise AssertionError(f"empty adaptive log: {name}")
        checks.append("REQUIRED_OUTPUTS_AND_LOGS_PASS")

        manifest = json.loads(archive.read("MANIFEST.json"))
        verify_seal(manifest, "MANIFEST.json")
        if manifest["file_count"] != len(names):
            raise AssertionError("manifest file_count mismatch")
        inv = {row["path"]: row for row in manifest["inventory"]}
        for name, row in inv.items():
            data = archive.read(name)
            if len(data) != row["bytes"] or sha256_bytes(data) != row["sha256"]:
                raise AssertionError(f"manifest mismatch: {name}")
        checks.append("MANIFEST_PASS")

        hashes = archive.read("HASHES.sha256").decode("utf-8").splitlines()
        listed = {}
        for line in hashes:
            digest, name = line.split("  ", 1)
            listed[name] = digest
        expected_hash_names = set(names) - {"HASHES.sha256"}
        if set(listed) != expected_hash_names:
            raise AssertionError("HASHES membership mismatch")
        for name, expected in listed.items():
            if sha256_bytes(archive.read(name)) != expected:
                raise AssertionError(f"HASHES mismatch: {name}")
        checks.append("ALL_INTERNAL_HASHES_PASS")

        for name in names:
            if name.endswith(".json"):
                value = json.loads(archive.read(name))
                if isinstance(value, dict):
                    verify_seal(value, name)
        checks.append("CONTENT_SEALS_PASS")

        lock = json.loads(archive.read("FREEZE/ING02_FINAL_LOCK.json"))
        for name, expected in lock["files"].items():
            if sha256_bytes(archive.read(name)) != expected:
                raise AssertionError(f"freeze mismatch: {name}")
        checks.append("FREEZE_HASHES_PASS")

        holdout = json.loads(archive.read("HOLDOUT/ING02_FINAL_HOLDOUT.json"))
        summary = holdout["summary"]
        if not summary["all_pass"] or summary["worlds"] != 72 or summary["exact"] != 72:
            raise AssertionError("holdout summary mismatch")
        if any(row["result"]["python_interventions_after_t0"] != 0 for row in holdout["rows"]):
            raise AssertionError("Python intervention found in holdout")
        checks.append("FRESH_HOLDOUT_72_OF_72_PASS")

        claims = json.loads(archive.read("CLAIM_LEDGER.json"))
        holdouts = json.loads(archive.read("HOLDOUT_REGISTRY.json"))
        canaries = json.loads(archive.read("CANARY_REGISTRY.json"))
        if len(claims["claims"]) != 8 or claims["promoted_claims"] != 5 or claims["bounds_and_nulls"] != 3:
            raise AssertionError("claim registry mismatch")
        if not holdouts["entries"][0]["passed"] or canaries["entries"][0]["exact"] != 16 or canaries["entries"][1]["exact"] != 16:
            raise AssertionError("holdout/canary registry mismatch")
        for claim in claims["claims"]:
            for evidence in claim["evidence"]:
                if evidence["artifact"] not in names:
                    raise AssertionError(f"claim evidence missing: {claim['id']} -> {evidence['artifact']}")
        checks.append("CLAIM_HOLDOUT_CANARY_CONSISTENCY_PASS")

        py_audit = json.loads(archive.read("ING02_PYTHON_INTERVENTION_AUDIT.json"))
        leakage = json.loads(archive.read("ING02_HARDCODE_LEAKAGE_AUDIT.json"))
        if not py_audit["promoted_holdout"]["pass"] or not leakage["audit_pass"]:
            raise AssertionError("intervention/leakage audit failed")
        checks.append("PYTHON_AND_LEAKAGE_AUDITS_PASS")

        parent_map = json.loads(archive.read("ING02_PARENT_EVIDENCE_MAP.json"))
        parent_status = []
        for row in parent_map["packages"]:
            parent = find_parent(row["filename"])
            observed = sha256_file(parent)
            if observed != row["sha256"]:
                raise AssertionError(f"parent hash mismatch: {row['parent_id']}")
            parent_status.append({"parent_id": row["parent_id"], "sha256": observed})
        checks.append("ALL_18_PARENT_HASHES_PASS")

    return {
        "package": str(package),
        "bytes": package.stat().st_size,
        "sha256": sha256_file(package),
        "checks": checks,
        "parents": parent_status,
        "status": "PASS",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("package", nargs="?", type=Path, default=DEFAULT_ZIP)
    args = parser.parse_args()
    print(json.dumps(validate(args.package.resolve()), indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
