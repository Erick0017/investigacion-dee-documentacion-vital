# Telemetry and evidence schema

All decisive scientific telemetry is stored losslessly as UTF-8 JSON. ZIP DEFLATE compression changes no values, rows or numeric precision. No decisive dataset is represented only by a plot, mean or sample.

## Common evidence fields

- `schema`: versioned artifact type.
- `created_utc`: creation timestamp.
- `content_sha256`: SHA-256 of canonical JSON before adding the seal.
- `runtime`: exact Python/platform/kernel identity when the runner invoked the kernel.
- `configuration`, `apparatus`, or `parameters`: frozen or discovery construction inputs.
- `rows`: complete world/configuration results for that experiment.
- `summary`: adjudication counts and bounded conclusion.

## State fields

Depending on the runner, traces preserve tick, raw voxel value, unpacked `state`, `s_reg`, `semantic`, directions, clock, support count, relative `delta`, comparator direction/projection, source state and world-level counts. Apparatus modules define coordinate transforms and raw packing exactly.

## Run phases

- `DISCOVERY/`: D01–D09 and D13–D17/D19/D20; complete tested panels.
- `MECHANISM_SELECTION/`: D10–D12, D18 and D23; phase/ensemble/lifetime/frame selection panels.
- `ADVERSARIAL_CHALLENGE/`: D21–D22 and related perturbation evidence.
- `CHALLENGES/`: the complete 72-world post-freeze challenge registry.
- `FREEZE/`: pre-holdout apparatus and file-hash lock.
- `HOLDOUT/`: all 72 full result rows and their traces.

## Interpretation safeguards

`D05` is retained because it falsifies naive consolidation; apparent successes in a saturated world are not claims. `D20` and `D21` calibrate whether proposed perturbations actually damage learned state; rejection is robustness, not repair. `D22` is explicit host-applied damage science and not a native-autonomy episode.

All artifact paths used by promoted claims are enumerated in `CLAIM_LEDGER.json`. `HASHES.sha256` and `MANIFEST.json` verify every physical package entry.
