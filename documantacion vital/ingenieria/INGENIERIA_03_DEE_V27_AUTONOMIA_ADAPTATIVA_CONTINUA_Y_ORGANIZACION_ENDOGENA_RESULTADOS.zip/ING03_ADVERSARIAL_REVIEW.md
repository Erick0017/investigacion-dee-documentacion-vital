# Revisión adversarial — competencia renovable

- No se promueve el cambio funcional D12/D18: los destinos están preasignados y la causalidad funcional escapa del estado local antes de tick128.
- Distancia6 se excluye porque modifica las regiones en tick9, antes de Function A.
- El daño r2 de RCA01 no cuenta como reapertura: produce el mismo delta6 sin el desafío.
- La recurrencia muestreada no se denomina ciclo límite ni competencia continua.
- Periodo1 no se denomina atractor sin cuenca/convergencia.
- El frente común no cuenta como aprendizaje porque el control sin periferia también cambia la función.
- Robustez sin pérdida/restauración no se denomina auto-mantenimiento; dinámica sin vacío/reemplazo no se denomina turnover.

Conclusión: las promociones permanecen conservadoras y las hipótesis no probadas continúan abiertas fuera de los dominios acotados.
