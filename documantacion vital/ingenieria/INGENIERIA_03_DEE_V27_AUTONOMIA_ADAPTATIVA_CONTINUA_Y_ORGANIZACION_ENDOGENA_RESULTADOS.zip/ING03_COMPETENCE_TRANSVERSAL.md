# Competencia causal transversal — actualización CCE

`C(X,t;E,F,T)` requiere que una experiencia produzca una distinción retenida y que ésta cambie una respuesta causal posterior. S0 reactividad y S1 retención no bastan.

CCE01 encuentra ventanas recurrentes; CCE02 demuestra que el reloj local transfiere apertura/cierre S1 en 6/6 pares, mientras RAW solo no. CCE03 eleva el panel a C2 diagnóstico: SEM1 finito produce cambio retenido y respuesta posterior distinta en 4/4 casos abiertos y 0/4 cerrados. CCE05 corta todos los portadores originales desde latencia 1 sin perder C2 y ubica soporte causal colectivo en 22 diferencias RAW.

La competencia no es sólo fase. Después de B, la segunda experiencia D12 funciona en el control naive pero no sobre la organización B, aun en t320. CCE09 revela el acoplamiento: preservar B impide C; reabrir C borra B. CCE10 evita el conflicto usando otra región y logra dos historias estratificadas, pero consume capacidad espacial finita y la tercera región falla.

CCE11–CCE17 completan la disección local: los 16 subconjuntos posibles de cuatro diferencias RAW, tres tiempos de renovación temprana, 24 transformaciones producidas por interacción, 18 factorizaciones de componentes y 20 relocalizaciones válidas convergen. La relación ocupada en `(1,-1,-1)` es necesaria para la función B en este aparato y su ocupación bloquea C2; variar su contenido no basta, mientras liberarla o moverla reabre C2 sólo después de perder B. Por ello la siguiente hipótesis no es “resetear un valor”, sino regenerar nativamente una trayectoria/topología competente que pueda coexistir con la historia distribuida.

CCE20 corrige esa frontera: liberar sólo RAW y conservar el reloj no preserva la huella B exacta, pero sí preserva información causal de B y permite formar un régimen BC nuevo. CCE21 repite la operación y obtiene B→C→B diagnóstico en dos marcos; sin la segunda vacancia, la tercera experiencia falla. Por tanto, la capacidad recurrente existe como mecanismo intervenido.

CCE22–CCE25 separan turnover de competencia. El soporte tetraédrico fijo es necesario para C2; romperlo vacía el sitio pero elimina competencia. El soporte repuesto genera turnover estructural abundante, pero no función adaptativa en las fases probadas. Falta turnover del ocupante con conservación de la organización competente, no mera repoblación.

CCE26–CCE33 muestran que la competencia también puede reorganizarse no localmente: una captura B funcional en una región fresca induce una oportunidad C2 distante y permite C diagnóstica. Sin embargo, el generador B all-t0 probado no reproduce esa inducción, y una historia A temprana sólo añade ventanas C2 de B. La diferencia causal relevante queda localizada entre “B presente/capturable desde temprano” y “B formada tras maduración”.

Corrección metodológica preservada: `raw_b` y `clock_b` son buffers scratch del kernel. Los clones causales reproducibles de CCE05 usan el estado público actual `raw + clock_a`; no se atribuye memoria independiente a los buffers de trabajo.

Frontera: falta renovación endógena de C2 o una organización colectiva donde la historia funcional no cierre la misma interfaz requerida por la siguiente experiencia.
