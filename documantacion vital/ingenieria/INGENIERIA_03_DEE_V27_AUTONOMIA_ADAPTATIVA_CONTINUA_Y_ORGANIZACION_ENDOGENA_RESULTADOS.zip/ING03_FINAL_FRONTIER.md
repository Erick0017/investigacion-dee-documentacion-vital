# Frontera científica actual

**Demostrado/promovido:** RW2 y L3 finito heredado.

**Demostrado causalmente en diagnóstico:** fase/reloj local controla S1 en el aparato probado; experiencia finita alineada crea una historia RAW distribuida independiente de su portador; la historia cambia una respuesta posterior; dos regiones preasignadas pueden coexistir con historias diagnósticas distintas.

**Nulos acotados nuevos:** plano amplio CCE04; superficies nativas CCE06; recurrencia sin renovación; tercera región de CCE10; presión finita, relajación, colisiones y relocalización CCE11–17; soporte tetraédrico destruido, las 15 sustituciones no vacías, soporte repuesto y sus fases representativas CCE22–25; reapertura local por fase madura CCE26; composición all-t0 de inducción remota CCE32.

**Demostrado sólo en diagnóstico:** vacancia RAW conservando reloj separa historia distribuida de interfaz; B→C→B se completa en un mundo continuo y dos marcos; una captura B fresca induce competencia C2 distante bajo controles causales CCE29–30; CCE31 completa A→B→C en un mundo diagnóstico preservando respuestas anteriores.

**No demostrado:** episodio B genuinamente tardío, nativo y ciego con internalización; función DEE promovida; renovación/reutilización acotada; lazo ambiental cerrado; RW3/RW4/RW5/L4. CCE34 fue interrumpido antes de evidencia y se excluye del paquete oficial.

**Hipótesis aún abiertas:** turnover causalmente distinto, remaduración colectiva, morfología renovable, atractores con cuenca demostrada, propiedades ondulatorias/de campo definidas operacionalmente y coordenadas de `X_FULL` no accesibles desde RAW/reloj.

**Estado de cierre:** RW2 y L3 finito heredado siguen siendo el máximo. Ingeniería 03 permanece ABIERTA y no se promueve a L4. Este paquete sella el checkpoint ejecutado; no prescribe ni inicia una nueva exploración.
