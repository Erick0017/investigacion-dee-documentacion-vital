# ING03 — Second-experience transversal

Baseline locked at `fc1ada1c90d0ec8b6591122a97a1bed7fc78df87e2ad9579a9881858c46c34a8`. No Engineering 04 was created. RW2 and all parent evidence remain preserved.

The campaign tested the missing edge directly. A learned A landscape forms and transfers a retained P1 distinction, but neither t0 persistent pressures nor eight explicitly later pressures at tick 160 produce a new retained P0/P1 organization. Direct receiver pressures can change output without learning and are excluded from RW3.

| Hypothesis | Name | Status | Exact scope |
|---|---|---|---|
| H1 | smooth distributed regime conversion | BOUNDED_NULL | persistent t0 P1 pressures and eight diagnostic post-A pressures |
| H2 | catastrophic/critical regime transition | BOUNDED_NULL | point/distributed pressures and post-A insertions |
| H3 | stratified causal history | PARTIALLY_SUPPORTED | initial formation: direction/extent and duration yield terminal P1 -1/0/+1 |
| H4 | state-dependent boundary scattering | DIAGNOSTIC_ONLY | A is amplified by semantic sheets; PLASTIC is nearly unchanged; no reflection-like redistribution |
| H5 | native DR04 order-parameter transition | BOUNDED_NULL | no post-A P0/P1 transition in DRT01/DRT11 |
| H6 | collective attractor transition | PARTIALLY_SUPPORTED | basin-like functional robustness; no exact convergence or A→B switch |
| H7 | wave-like distributed dynamics | PARTIALLY_SUPPORTED | ordered arrival/apparent front only; no phase/interference/reflection/dispersion |
| H8 | field-like distributed coupling | UNRESOLVED | porous sheet does not exclude alternate local routes |
| H9 | holographic-like distributed encoding | PARTIALLY_SUPPORTED | multiple disjoint fragments carry A/B/SHAM diagnostic information |
| H10 | morphological causal adaptation | PARTIALLY_SUPPORTED | one-shot history-dependent morphology; no post-A remodeling |
| H11 | self-maintaining causal organization | OPEN_HYPOTHESIS | passive robustness is present but active restoration is absent |
| H12 | controlled destruction/rejuvenation | UNRESOLVED | D15 late gate lacks an age-matched competent control; prior remote destruction remains nonreceptive |
| H13 | interface turnover | BOUNDED_NULL | prior repopulation does not restore write competence; no new valid late gate |
| H14 | transient-vs-persistent integration | DIAGNOSTIC_ONLY | host-ended durations give nonmonotonic -1/0/+1 outcomes; finite native train synthesis is null |
| H15 | environment as effector | PARTIALLY_SUPPORTED | one-shot native effect and direct receiver modification; no feedback closure |
| H16 | unanticipated mechanism | DIAGNOSTIC_ONLY | state-dependent boundary amplification |

The strongest new positives are bounded: ordered spatial arrival without a wave claim; diagnostic information in multiple disjoint fragments without holographic reconstruction; nonmonotonic temporal-history dependence under diagnostic pulse removal; and state-dependent boundary amplification. The finite all-t0 carrier reconstruction did not reproduce the temporal distinction.

The precise missing edge remains **second independent experience → new retained organization → new native function**. Consequently RW3 is not achieved, RW4/RW5 are not applicable, and no L4 challenge was run. This is `NO_KNOWN_CONSTRUCTION`, not a claim of impossibility.
