# Reproduction

Run from the canonical `INGENIERIA_03` directory with CPython 3.13 and kernel SHA-256 `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

The corrected promoted mechanisms are reproduced in phase order:

1. Native one-shot buffer: `run_final_d32_native_consequence_buffer.py`, `run_final_d35_buffer_model_selection.py`, then frozen `run_final_native_buffer_holdout.py`.
2. Persistent generated writer: `run_final_d36_recurrent_generated_buffer.py`, `run_final_d37_persistent_buffer_model_selection.py`, then `run_final_persistent_buffer_holdout.py`.
3. One-cycle buffered delayed readout: `run_final_d39_buffered_offline_readout.py`, `run_final_d40_offline_readout_model_selection.py`, then `run_final_offline_readout_holdout.py`.
4. Temporal return law: `run_final_d45_temporal_slot_capacity.py`, `run_final_d50_temporal_size_boundary.py`, `run_final_d51_temporal_modular_frame_panel.py`, then `run_final_temporal_return_holdout.py`.

Every holdout runner verifies apparatus and lock hashes before execution. Challenge files were generated only after their lock. Python constructs t0, advances ticks and logs; it does not write memory, select outputs, release buffers or restore resources after t0.

Parent CORE/ING01/ING02 packages are not embedded. Their identities and artifact references are in `ING03_PARENT_EVIDENCE_MAP.json` and the mechanism graphs.
