#!/usr/bin/env python3
"""Phenomenological classification of D01-D03 distributed responses."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def load(rel): return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def sample(row, latency):
    return next(item for item in row["checkpoint_features"] if item["latency"] == latency)


def ref(rel):
    value = load(rel)
    return {"path": rel, "file_sha256": sha256_file(ROOT / rel),
            "content_sha256": value.get("content_sha256")}


def main():
    d01_rel = "MECHANISM_SELECTION/ING03_DR_D01_DISTRIBUTED_REGIME_CARTOGRAPHY.json"
    d02_rel = "MECHANISM_SELECTION/ING03_DR_D02_CLEAN_PORT_GENERALIZATION.json"
    d03_rel = "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json"
    d01, d02, d03 = load(d01_rel), load(d02_rel), load(d03_rel)
    by = {row["label"]: row for row in d01["rows"]}
    classifications = []
    definitions = {
        "A": "BRANCHING_PERCOLATIVE_LIKE_AVALANCHE_TO_STATIONARY_EXTENSIVE_REGIME",
        "B": "LOCAL_TRANSIENT_TO_SPARSE_STATIONARY_REGIME",
        "SHAM": "SPARSE_TRAJECTORY_THEN_DELAYED_PERCOLATIVE_LIKE_GLOBAL_REGIME",
        "PLASTIC": "SPARSE_BALLISTIC_LIKE_TOROIDAL_TRACE_TO_STATIONARY_REGIME",
    }
    for label, row in by.items():
        s1, s24, s64, s128, s192 = (sample(row, tick) for tick in (1, 24, 64, 128, 192))
        classifications.append({
            "label": label, "descriptive_class": definitions[label],
            "raw_changed": {"t1": s1["raw_changed"], "t24": s24["raw_changed"],
                            "t64": s64["raw_changed"], "t128": s128["raw_changed"],
                            "t192": s192["raw_changed"]},
            "terminal_components": s192["connected_components_6_torus"],
            "terminal_neighbor_edge_density": s192["changed_neighbor_edge_density"],
            "maximum_radius": max(item["maximum_chebyshev_radius"] for item in row["time_series"]),
            "terminal_count_period_candidate": row["terminal_count_period_candidate"],
            "ever_affected_positions": row["ever_affected_positions"],
            "criteria": {
                "extensive": s192["raw_changed"] > 1000,
                "giant_connected_component": s192["connected_components_6_torus"]["largest_fraction"] > 0.9,
                "delayed_amplification": s64["raw_changed"] < 100 and s128["raw_changed"] > 1000,
                "sparse_stationary": s192["raw_changed"] < 100 and row["terminal_count_period_candidate"] == 1,
            }})
    clean = d02["rows"][0] if d02["rows"] else None
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.classification.v1",
        "question": "What empirically descriptive propagation classes best fit the observed A/B/SHAM/PLASTIC responses?",
        "classification_rule": "Names summarize measured growth, connectivity and recurrence; wave, field, resonance and diffusion are not asserted.",
        "classifications": classifications,
        "clean_port_replication": None if clean is None else {
            "direction": clean["direction"], "distance": clean["distance"],
            "classes_pairwise_distinct": clean["a_b_sham_pairwise_distinct"],
            "maximum_changed": {label: value["maximum_changed"] for label, value in clean["responses"].items()},
            "remote_interface_effect": clean["any_remote_interface_effect"]},
        "causal_tomography": {
            "source_cuts_change_nearest_class": d03["summary"]["any_source_cut_changes_nearest_class"],
            "any_exact_donor_recreation": d03["summary"]["any_exact_donor_template_recreation"],
            "interpretation": "response class depends on mesoscopic domain plus host history; no tested local implant exactly recreates an intact regime"},
        "summary": {
            "a_b_sham_descriptively_distinct": True,
            "a_is_early_extensive": True, "b_is_sparse_stationary": True,
            "sham_has_delayed_global_transition": True, "plastic_is_sparse_trace": True,
            "wave_demonstrated": False, "field_demonstrated": False,
            "native_decoder_or_function_demonstrated": False,
            "fresh_validation_required": True, "rw3_demonstrated": False},
        "evidence": [ref(d01_rel), ref(d02_rel), ref(d03_rel)],
        "claim_guard": "This is an operational morphology of diagnostic paired differences. Descriptive labels are not literal physical media and do not establish native function."})
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D04_REGIME_CLASSIFICATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
