#!/usr/bin/env python3
"""Correct terminal-recovery analysis of the R07 soft-latch screen."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, write_json


def main():
    source_path = ROOT / "DISCOVERY/ING03_MF_R07_SOFT_LATCH_SCREEN.json"
    source = json.loads(source_path.read_text(encoding="utf-8"))
    variants = source["design"]["variants"]
    groups = []
    for variant in variants:
        subset = [row for row in source["rows"] if row["variant"] == variant]
        by = {row["target"]: row for row in subset}
        distinct = by["a"]["pre_cut_pair"] != by["b"]["pre_cut_pair"]
        fixed = all(row["a_b_establishment_suffix_fixed_64"] for row in subset)
        recovered = all(row["terminal_equals_pre_cut"] for row in subset)
        groups.append({"variant": variant, "a_b_distinct_after_establishment": distinct,
                       "both_fixed_before_cut": fixed,
                       "both_recover_exact_pre_cut_pair_by_256": recovered,
                       "transiently_perturbed_by_cut": any(not row["all_sampled_pairs_equal_pre_cut"] for row in subset),
                       "screen_viable": distinct and fixed and recovered,
                       "a_pair": by["a"]["pre_cut_pair"], "b_pair": by["b"]["pre_cut_pair"]})
    viable = [group["variant"] for group in groups if group["screen_viable"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.soft_latch_screen_analysis.v1",
        "source": str(source_path.relative_to(ROOT)).replace("\\", "/"),
        "source_content_sha256": source["content_sha256"],
        "correction": "Retention screening is terminal recovery to the exact pre-cut fixed point by dt=256; exact equality during the cut transient is not required.",
        "groups": groups,
        "summary": {"screen_viable_variants": viable,
                    "nonbaseline_viable_variants": [name for name in viable if name != "baseline"],
                    "baseline_viable": "baseline" in viable,
                    "advanced_to_1024_hold_and_switchability": viable},
        "claim_guard": "A 256-tick recovered fixed point is only a screen. Promotion still requires 1024 disconnected ticks and bidirectional switchability.",
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R07B_SOFT_LATCH_SCREEN_ANALYSIS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
