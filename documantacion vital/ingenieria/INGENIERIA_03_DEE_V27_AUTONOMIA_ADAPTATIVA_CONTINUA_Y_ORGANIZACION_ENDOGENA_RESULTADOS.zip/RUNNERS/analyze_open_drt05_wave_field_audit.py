#!/usr/bin/env python3
"""Operational wave/field/resonance audit of the lossless DR01 masks.

This is an offline diagnostic analysis.  It separates measurable propagation
properties from labels that require experiments absent from DR01 (barriers,
interference pairs, strict carrier exclusion, or driven resonance).
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


LABELS = ("A", "B", "SHAM", "PLASTIC")
SOURCE_JSON = ROOT / "MECHANISM_SELECTION/ING03_DR_D01_DISTRIBUTED_REGIME_CARTOGRAPHY.json"
SOURCE_NPZ = ROOT / "TELEMETRY/ING03_DR_D01_DISTRIBUTED_REGIME_RESPONSES.npz"
OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT05_WAVE_FIELD_AUDIT.json"


def unpack_masks(packed: np.ndarray, n: int) -> np.ndarray:
    bits = np.unpackbits(packed, axis=1, bitorder="little")[:, : n ** 3]
    return bits.reshape((packed.shape[0], n, n, n)).astype(bool, copy=False)


def torus_offsets(n: int, origin: list[int]) -> np.ndarray:
    indices = np.indices((n, n, n), dtype=np.int16).reshape(3, -1).T
    offsets = indices.astype(np.int32) - np.asarray(origin, dtype=np.int32)
    return ((offsets + n // 2) % n - n // 2).reshape(n, n, n, 3)


def quantile(values: np.ndarray, q: float) -> float | None:
    return None if not values.size else float(np.quantile(values, q))


def linear_fit(x: np.ndarray, y: np.ndarray) -> dict:
    if len(x) < 3 or np.all(x == x[0]):
        return {"slope": None, "intercept": None, "r_squared": None, "points": int(len(x))}
    slope, intercept = np.polyfit(x.astype(float), y.astype(float), 1)
    predicted = slope * x + intercept
    residual = float(np.sum((y - predicted) ** 2))
    total = float(np.sum((y - np.mean(y)) ** 2))
    return {
        "slope": float(slope),
        "intercept": float(intercept),
        "r_squared": 1.0 if total == 0.0 and residual == 0.0 else (1.0 - residual / total if total else None),
        "points": int(len(x)),
    }


def autocorrelation(values: np.ndarray, max_lag: int = 64) -> list[dict]:
    centered = values.astype(float) - float(np.mean(values))
    denom = float(np.dot(centered, centered))
    rows = []
    for lag in range(1, min(max_lag, len(values) - 2) + 1):
        corr = None if denom == 0.0 else float(np.dot(centered[:-lag], centered[lag:]) / denom)
        rows.append({"lag": lag, "correlation": corr})
    return rows


def spectrum(values: np.ndarray) -> dict:
    centered = values.astype(float) - float(np.mean(values))
    power = np.abs(np.fft.rfft(centered)) ** 2
    if len(power) <= 1 or float(power[1:].sum()) == 0.0:
        return {"dominant_nonzero_bin": None, "candidate_period_ticks": None,
                "dominant_power_fraction": 0.0, "oscillatory_peak_demonstrated": False}
    index = int(np.argmax(power[1:]) + 1)
    fraction = float(power[index] / power[1:].sum())
    return {"dominant_nonzero_bin": index, "candidate_period_ticks": float(len(values) / index),
            "dominant_power_fraction": fraction,
            "oscillatory_peak_demonstrated": bool(fraction >= 0.50 and index >= 2)}


def label_metrics(label: str, masks: np.ndarray, event: list[int], n: int) -> dict:
    horizon = masks.shape[0]
    ever = masks.any(axis=0)
    first = np.full((n, n, n), -1, dtype=np.int16)
    for tick in range(horizon):
        new = masks[tick] & (first < 0)
        first[new] = tick + 1

    offsets = torus_offsets(n, event)
    cheb = np.max(np.abs(offsets), axis=3)
    euclid = np.sqrt(np.sum(offsets.astype(float) ** 2, axis=3))
    arrival_ticks = first[ever].astype(float)
    arrival_radii = cheb[ever].astype(float)
    euclid_radii = euclid[ever].astype(float)

    shell_rows = []
    for radius in sorted(int(x) for x in np.unique(cheb[ever])) if ever.any() else []:
        values = first[ever & (cheb == radius)]
        shell_rows.append({
            "chebyshev_radius": radius,
            "arrived_positions": int(values.size),
            "first_tick": int(values.min()),
            "median_tick": float(np.median(values)),
            "q25_tick": quantile(values, 0.25),
            "q75_tick": quantile(values, 0.75),
            "last_tick": int(values.max()),
            "arrival_tick_std": float(np.std(values)),
        })

    max_new_radius = []
    coherent_fractions = []
    active_new_ticks = 0
    previous_ever = np.zeros((n, n, n), dtype=bool)
    for tick in range(horizon):
        new = masks[tick] & ~previous_ever
        previous_ever |= masks[tick]
        radii = cheb[new]
        max_new_radius.append(int(radii.max()) if radii.size else None)
        if radii.size:
            active_new_ticks += 1
            counts = np.bincount(radii.astype(int), minlength=n // 2 + 1)
            coherent_fractions.append(float(counts.max() / radii.size))

    # Fit first-arrival tick against radius only through the first toroidal edge.
    # This is a descriptive apparent radial rate, not a material propagation speed.
    valid_shells = [row for row in shell_rows if row["arrived_positions"] >= 1]
    sx = np.asarray([row["median_tick"] for row in valid_shells], dtype=float)
    sy = np.asarray([row["chebyshev_radius"] for row in valid_shells], dtype=float)
    fit = linear_fit(sx, sy)

    count_series = masks.reshape(horizon, -1).sum(axis=1).astype(np.int64)
    changed_between = np.count_nonzero(masks[1:] != masks[:-1], axis=(1, 2, 3)).astype(np.int64)
    ac = autocorrelation(count_series)
    best_ac = max((row for row in ac if row["correlation"] is not None),
                  key=lambda row: row["correlation"], default=None)
    spec = spectrum(count_series)
    terminal_equal = [bool(np.array_equal(masks[-1], masks[-1 - lag]))
                      for lag in range(1, min(64, horizon - 1) + 1)]

    radius_arrival_corr = None
    if arrival_ticks.size >= 3 and np.std(arrival_ticks) > 0 and np.std(arrival_radii) > 0:
        radius_arrival_corr = float(np.corrcoef(arrival_ticks, arrival_radii)[0, 1])

    ordered_shells = sum(
        1 for left, right in zip(valid_shells, valid_shells[1:])
        if right["median_tick"] >= left["median_tick"]
    )
    shell_pairs = max(0, len(valid_shells) - 1)
    ordered_fraction = float(ordered_shells / shell_pairs) if shell_pairs else None
    radial_order_present = bool(
        len(valid_shells) >= 5
        and ordered_fraction is not None and ordered_fraction >= 0.75
        and fit["slope"] is not None and fit["slope"] > 0
    )
    stationary_tail = bool(all(terminal_equal[:16])) if len(terminal_equal) >= 16 else False
    coherent_front = bool(radial_order_present and coherent_fractions and np.median(coherent_fractions) >= 0.50)
    wave_properties = {
        "spatially_ordered_propagation": radial_order_present,
        "apparent_radial_rate_measurable": bool(radial_order_present and fit["r_squared"] is not None),
        "narrow_coherent_front": coherent_front,
        "oscillatory_frequency": bool(spec["oscillatory_peak_demonstrated"] and not stationary_tail),
        "phase_propagation": False,
        "reflection": False,
        "refraction": False,
        "interference": False,
        "dispersion": False,
        "standing_structure": False,
    }
    if sum(bool(x) for x in wave_properties.values()) >= 3 and wave_properties["oscillatory_frequency"]:
        classification = "MULTIPLE_WAVE_LIKE_PROPERTIES_DIAGNOSTIC_ONLY"
    elif radial_order_present:
        classification = "ORDERED_PROPAGATION_OR_AVALANCHE_WITHOUT_WAVE_DEMONSTRATION"
    elif ever.sum() <= 64:
        classification = "SPARSE_LOCAL_OR_TRACE_RESPONSE_WITHOUT_WAVE_DEMONSTRATION"
    else:
        classification = "DISTRIBUTED_RESPONSE_WITHOUT_ORDERED_WAVE_DEMONSTRATION"

    return {
        "label": label,
        "ever_affected_positions": int(ever.sum()),
        "maximum_chebyshev_radius": int(cheb[ever].max()) if ever.any() else 0,
        "maximum_euclidean_radius": float(euclid_radii.max()) if euclid_radii.size else 0.0,
        "arrival_tick_vs_chebyshev_radius_pearson": radius_arrival_corr,
        "shell_ordered_fraction": ordered_fraction,
        "apparent_radius_per_tick_fit": fit,
        "active_new_arrival_ticks": active_new_ticks,
        "new_arrival_dominant_shell_fraction": {
            "median": float(np.median(coherent_fractions)) if coherent_fractions else None,
            "q25": quantile(np.asarray(coherent_fractions), 0.25),
            "q75": quantile(np.asarray(coherent_fractions), 0.75),
        },
        "count_series": {
            "first_24": [int(x) for x in count_series[:24]],
            "last_24": [int(x) for x in count_series[-24:]],
            "minimum": int(count_series.min()),
            "maximum": int(count_series.max()),
            "terminal": int(count_series[-1]),
        },
        "mask_turnover": {
            "median_consecutive_hamming": float(np.median(changed_between)) if changed_between.size else 0.0,
            "last_16_consecutive_hamming": [int(x) for x in changed_between[-16:]],
            "terminal_equal_at_lags_1_to_16": terminal_equal[:16],
            "stationary_last_16_lags": stationary_tail,
        },
        "frequency_diagnostic": spec,
        "best_positive_count_autocorrelation": best_ac,
        "shell_first_arrival_summary": shell_rows,
        "wave_property_audit": wave_properties,
        "operational_classification": classification,
    }


def main() -> None:
    source = json.loads(SOURCE_JSON.read_text(encoding="utf-8"))
    with np.load(SOURCE_NPZ, allow_pickle=False) as archive:
        n = int(archive["n"][0])
        horizon = int(archive["horizon"][0])
        rows = {row["label"]: row for row in source["rows"]}
        metrics = []
        for label in LABELS:
            masks = unpack_masks(archive[f"{label}_raw_change_masks"], n)
            metrics.append(label_metrics(label, masks, rows[label]["event"], n))

    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.wave_field_resonance_audit.v1",
        "question": "Which operational wave-, field-, or resonance-like properties are actually present in the DR01 distributed causal responses?",
        "analysis_class": "OFFLINE_DIAGNOSTIC_ANALYSIS_OF_FROZEN_LOSSLESS_MASKS",
        "design": {
            "n": n,
            "horizon_ticks": horizon,
            "conditions": list(LABELS),
            "origin": "per-condition DR01 event coordinate",
            "distance": "signed toroidal Chebyshev distance; Euclidean maximum also reported",
            "wave_properties_tested": [
                "ordered first arrival", "apparent radial rate", "front-shell concentration",
                "temporal mask turnover", "count periodicity", "mask recurrence",
            ],
            "properties_not_testable_from_dr01": [
                "controlled reflection", "controlled refraction", "two-source interference",
                "dispersion relation", "phase velocity", "strict no-carrier field coupling",
                "frequency-matched driven resonance",
            ],
        },
        "conditions": metrics,
        "hypothesis_status": {
            "H7_wave_like_distributed_dynamics": {
                "status": "PARTIALLY_SUPPORTED" if any(row["wave_property_audit"]["spatially_ordered_propagation"] for row in metrics) else "OPEN_HYPOTHESIS",
                "scope": "Some responses may have ordered propagation/front properties; DR01 does not demonstrate a wave because phase, interference, reflection/refraction and dispersion were not established.",
            },
            "H8_field_like_distributed_coupling": {
                "status": "UNRESOLVED",
                "scope": "DR01 did not implement a strict locality/carrier-exclusion or barrier control, so distributed reach cannot establish field-like coupling.",
            },
            "resonance": {
                "status": "UNRESOLVED",
                "scope": "No frequency-matched drive or phase-sweep coupling experiment is present in DR01.",
            },
        },
        "summary": {
            "wave_label_promoted": False,
            "field_label_promoted": False,
            "resonance_label_promoted": False,
            "operational_properties_reported_separately": True,
            "native_function_added": False,
            "second_independent_experience_added": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Ordered spatial arrival or an apparent front rate is not by itself a wave. Absence of a DR01 test is recorded as UNRESOLVED, not as a global negation.",
        "evidence": [
            {"path": SOURCE_JSON.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(SOURCE_JSON),
             "content_sha256": source.get("content_sha256")},
            {"path": SOURCE_NPZ.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(SOURCE_NPZ)},
        ],
    })
    write_json(OUTPUT, result)
    print(json.dumps({
        "output": OUTPUT.relative_to(ROOT).as_posix(),
        "content_sha256": result["content_sha256"],
        "statuses": result["hypothesis_status"],
        "classes": {row["label"]: row["operational_classification"] for row in metrics},
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
