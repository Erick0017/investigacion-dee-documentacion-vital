#!/usr/bin/env python3
"""Diagnostic fragment-level information audit for the DR01 response masks."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


LABELS = ("A", "B", "SHAM")
SOURCE_JSON = ROOT / "MECHANISM_SELECTION/ING03_DR_D01_DISTRIBUTED_REGIME_CARTOGRAPHY.json"
SOURCE_NPZ = ROOT / "TELEMETRY/ING03_DR_D01_DISTRIBUTED_REGIME_RESPONSES.npz"
TOMOGRAPHY = ROOT / "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json"
FRESH = ROOT / "HOLDOUT/ING03_DR_D05_REGIME_SEPARABILITY_HOLDOUT.json"
OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT06_DISTRIBUTED_REDUNDANCY.json"


def unpack(packed: np.ndarray, n: int) -> np.ndarray:
    return np.unpackbits(packed, axis=1, bitorder="little")[:, :n ** 3].reshape((-1, n, n, n)).astype(bool)


def signed_offsets(n: int, origin: list[int]) -> np.ndarray:
    index = np.indices((n, n, n), dtype=np.int16).reshape(3, -1).T
    delta = index.astype(np.int32) - np.asarray(origin, dtype=np.int32)
    return ((delta + n // 2) % n - n // 2).reshape(n, n, n, 3)


def digest_fragment(sequence: np.ndarray) -> str:
    return hashlib.sha256(np.packbits(sequence.reshape(-1), bitorder="little").tobytes()).hexdigest()


def partitions(n: int, event: list[int]) -> dict[str, list[tuple[str, np.ndarray]]]:
    delta = signed_offsets(n, event)
    cheb = np.max(np.abs(delta), axis=3)
    families: dict[str, list[tuple[str, np.ndarray]]] = {}

    octants = []
    for sx in (0, 1):
        for sy in (0, 1):
            for sz in (0, 1):
                mask = ((delta[..., 0] >= 0) == bool(sx))
                mask &= ((delta[..., 1] >= 0) == bool(sy))
                mask &= ((delta[..., 2] >= 0) == bool(sz))
                octants.append((f"octant_{sx}{sy}{sz}", mask))
    families["eight_signed_octants"] = octants

    # Seven disjoint toroidal Chebyshev shells covering the entire world.
    edges = ((0, 2), (3, 5), (6, 8), (9, 11), (12, 14), (15, 17), (18, n // 2))
    families["seven_radial_shells"] = [
        (f"shell_{lo}_{hi}", (cheb >= lo) & (cheb <= hi)) for lo, hi in edges
    ]

    # 3x3x3 disjoint relative-coordinate blocks.  The central band is kept
    # symmetric around the event and no block overlaps another.
    bins = ((-n // 2, -7), (-6, 6), (7, n // 2))
    blocks = []
    for ix, (x0, x1) in enumerate(bins):
        for iy, (y0, y1) in enumerate(bins):
            for iz, (z0, z1) in enumerate(bins):
                mask = (delta[..., 0] >= x0) & (delta[..., 0] <= x1)
                mask &= (delta[..., 1] >= y0) & (delta[..., 1] <= y1)
                mask &= (delta[..., 2] >= z0) & (delta[..., 2] <= z1)
                blocks.append((f"block_{ix}{iy}{iz}", mask))
    families["twenty_seven_blocks"] = blocks
    return families


def audit_family(name: str, fragments: list[tuple[str, np.ndarray]], masks: dict[str, np.ndarray]) -> dict:
    rows = []
    pairs = (("A", "B"), ("A", "SHAM"), ("B", "SHAM"))
    for fragment_id, spatial in fragments:
        sequences = {label: masks[label] & spatial[None, ...] for label in LABELS}
        hammings = {
            f"{left}_vs_{right}": int(np.count_nonzero(sequences[left] != sequences[right]))
            for left, right in pairs
        }
        signatures = {label: digest_fragment(sequences[label]) for label in LABELS}
        active = {label: int(np.count_nonzero(sequences[label])) for label in LABELS}
        rows.append({
            "fragment_id": fragment_id,
            "voxel_count": int(spatial.sum()),
            "response_voxel_ticks": active,
            "sequence_sha256": signatures,
            "pairwise_hamming_voxel_ticks": hammings,
            "all_A_B_SHAM_pairwise_distinguishable": bool(all(value > 0 for value in hammings.values())),
            "all_three_have_local_response": bool(all(value > 0 for value in active.values())),
            "all_three_distinguishable_and_active": bool(all(value > 0 for value in hammings.values()) and all(value > 0 for value in active.values())),
        })
    triple = [row for row in rows if row["all_A_B_SHAM_pairwise_distinguishable"]]
    active_triple = [row for row in rows if row["all_three_distinguishable_and_active"]]
    return {
        "partition": name,
        "disjoint_fragment_count": len(rows),
        "coverage_voxels": int(sum(row["voxel_count"] for row in rows)),
        "pairwise_distinguishing_fragments": len(triple),
        "active_pairwise_distinguishing_fragments": len(active_triple),
        "diagnostic_redundancy_present": bool(len(active_triple) >= 2),
        "fragments": rows,
    }


def main() -> None:
    source = json.loads(SOURCE_JSON.read_text(encoding="utf-8"))
    tomography = json.loads(TOMOGRAPHY.read_text(encoding="utf-8"))
    fresh = json.loads(FRESH.read_text(encoding="utf-8"))
    source_rows = {row["label"]: row for row in source["rows"]}
    event = source_rows["A"]["event"]
    if any(source_rows[label]["event"] != event for label in LABELS):
        raise RuntimeError("DR01 event coordinates differ across compared conditions")
    with np.load(SOURCE_NPZ, allow_pickle=False) as archive:
        n = int(archive["n"][0])
        masks = {label: unpack(archive[f"{label}_raw_change_masks"], n) for label in LABELS}

    family_rows = [audit_family(name, fragments, masks)
                   for name, fragments in partitions(n, event).items()]
    independent_fragment_evidence = any(row["diagnostic_redundancy_present"] for row in family_rows)
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.distributed_information_redundancy.v1",
        "question": "Do multiple disjoint spatial fragments carry diagnostic information about the global A/B/SHAM learned-history-conditioned response class?",
        "analysis_class": "OFFLINE_DIAGNOSTIC_INFORMATION_AUDIT",
        "design": {
            "conditions": list(LABELS),
            "same_event_coordinate": event,
            "partitions": [
                "8 disjoint signed octants", "7 disjoint toroidal Chebyshev shells",
                "27 disjoint relative-coordinate blocks",
            ],
            "fragment_information_criterion": "the fragment's full lossless response-mask sequence is pairwise unequal for A, B and SHAM and every class has a local response",
            "redundancy_criterion": "at least two disjoint fragments in one frozen partition independently satisfy the fragment-information criterion",
            "external_classifier_used": False,
        },
        "partition_audits": family_rows,
        "causal_lesion_context": {
            "source": TOMOGRAPHY.relative_to(ROOT).as_posix(),
            "existing_result": tomography["summary"],
            "interpretation": "Prior regional copies/cuts change response-template proximity but did not recreate a donor regime or demonstrate native function; therefore lesion-tolerant function is not inferred from fragment information.",
        },
        "fresh_global_context": {
            "source": FRESH.relative_to(ROOT).as_posix(),
            "fresh_frames": fresh["summary"].get("fresh_frames"),
            "global_regime_separability_fresh_confirmed": fresh["summary"].get("diagnostic_history_conditioned_regime_separability_validated"),
            "fragment_redundancy_fresh_tested": False,
        },
        "hypothesis_status": {
            "H9_holographic_like_distributed_encoding": {
                "status": "PARTIALLY_SUPPORTED" if independent_fragment_evidence else "OPEN_HYPOTHESIS",
                "demonstrated_property": "multiple disjoint fragments contain diagnostic A/B/SHAM response-class information" if independent_fragment_evidence else None,
                "not_demonstrated": [
                    "fragment sufficiency to recreate global state", "native DEE decoding from a fragment",
                    "functional retention after lesions", "fresh fragment-level generalization",
                    "holographic reconstruction",
                ],
            }
        },
        "summary": {
            "multiple_disjoint_informative_fragments": independent_fragment_evidence,
            "distributed_diagnostic_information_supported": independent_fragment_evidence,
            "holographic_label_promoted": False,
            "native_function_demonstrated": False,
            "functional_redundancy_demonstrated": False,
            "second_independent_experience_added": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Fragment-level separability is diagnostic distributed information only. It is not evidence that a fragment recreates the whole, that DEE decodes it, or that function survives lesion.",
        "evidence": [
            {"path": SOURCE_JSON.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(SOURCE_JSON), "content_sha256": source.get("content_sha256")},
            {"path": SOURCE_NPZ.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(SOURCE_NPZ)},
            {"path": TOMOGRAPHY.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(TOMOGRAPHY), "content_sha256": tomography.get("content_sha256")},
            {"path": FRESH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(FRESH), "content_sha256": fresh.get("content_sha256")},
        ],
    })
    write_json(OUTPUT, result)
    print(json.dumps({
        "output": OUTPUT.relative_to(ROOT).as_posix(),
        "content_sha256": result["content_sha256"],
        "status": result["hypothesis_status"]["H9_holographic_like_distributed_encoding"],
        "partition_summary": [{k: row[k] for k in ("partition", "disjoint_fragment_count", "active_pairwise_distinguishing_fragments", "diagnostic_redundancy_present")} for row in family_rows],
    }, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
