#!/usr/bin/env python3
"""Cross-evidence audit of attractor, morphology, maintenance and effector hypotheses."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


FILES = {
    "D03": "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json",
    "D04": "MECHANISM_SELECTION/ING03_DR_D04_REGIME_CLASSIFICATION.json",
    "D10": "HOLDOUT/ING03_DR_D10_NATIVE_TRAJECTORY_HOLDOUT.json",
    "D15": "HOLDOUT/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_HOLDOUT.json",
    "D16": "MECHANISM_SELECTION/ING03_DR_D16_RESERVE_FUNCTION_TOMOGRAPHY.json",
    "D17": "MECHANISM_SELECTION/ING03_DR_D17_THIRD_RESERVE_SUCCESSION.json",
    "DRT02": "MECHANISM_SELECTION/ING03_OH_DRT02_DISTRIBUTED_DESTABILIZATION.json",
    "DRT10": "MECHANISM_SELECTION/ING03_OH_DRT10_BOUNDARY_SCATTERING.json",
    "DRT11": "MECHANISM_SELECTION/ING03_OH_DRT11_POST_A_SECOND_EXPERIENCE.json",
}
OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT12_ATTRACTOR_MORPHOLOGY_AUDIT.json"


def load_all():
    return {key: json.loads((ROOT / path).read_text(encoding="utf-8")) for key, path in FILES.items()}


def main():
    evidence = load_all(); d03 = evidence["D03"]; rows = d03["rows"]
    perturbation_stats = {
        "diagnostic_microstate_perturbations": len(rows),
        "nearest_intact_template_remains_host": sum(bool(row.get("retains_host_template")) for row in rows),
        "receiver_function_unchanged_all_observed_ticks": sum(row["response"].get("receiver_different_ticks") == 0 for row in rows),
        "exact_donor_template_recreated": sum(bool(row.get("exact_donor_template_match")) for row in rows),
        "any_native_function_from_perturbation": sum(bool(row["response"].get("write_response")) for row in rows),
        "host_breakdown": {label: sum(row["intervention"].get("host") == label for row in rows)
                           for label in ("A", "B", "SHAM", "PLASTIC")},
    }
    host_ab = [row for row in rows if row["intervention"].get("host") in ("A", "B")]
    ab_function_robust = sum(row["response"].get("receiver_different_ticks") == 0 for row in host_ab)

    drt02 = evidence["DRT02"]
    formation_outcomes = {}
    for row in drt02["rows"]:
        if row["outcome"].get("valid"):
            formation_outcomes[row["config"]["id"]] = {
                "p0": row["outcome"]["terminal"]["p0"],
                "p1": row["outcome"]["terminal"]["p1"],
                "receiver_pair_difference_ticks": row["outcome"].get("pair_difference_ticks"),
            }
    distinct_p1 = sorted({row["p1"] for row in formation_outcomes.values()})

    drt11 = evidence["DRT11"]
    direct_receiver = [row["config"]["id"] for row in drt11["rows"]
                       if row["terminal_pair_difference_retained_64_ticks"] and
                       not row["retained_late_order_parameter_change"]]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.attractor_morphology_audit.v1",
        "question": "Which attractor-, morphology-, self-maintenance- and environment-effector properties are actually supported after DRT01-DRT11?",
        "analysis_class": "CROSS_EVIDENCE_OPERATIONAL_AUDIT",
        "attractor_audit": {
            "criteria": {
                "multiple_perturbed_microstates": True,
                "functional_macro_regime_convergence": "PARTIAL: receiver output unchanged in most D03 interventions",
                "exact_state_convergence": False,
                "basin_boundary_mapped": "PARTIAL: larger core copies can change nearest response template",
                "native_A_to_B_switch": False,
                "return_transition": False,
                "fresh_basin_validation": False,
            },
            "D03_statistics": perturbation_stats,
            "A_B_host_receiver_robust_cases": f"{ab_function_robust}/{len(host_ab)}",
            "classification": "BASIN_LIKE_FUNCTIONAL_ROBUSTNESS_PARTIALLY_SUPPORTED; GLOBAL_ATTRACTOR_NOT_DEMONSTRATED",
        },
        "morphology_audit": {
            "DRT02_initial_formation_terminal_states": formation_outcomes,
            "distinct_P1_terminal_values": distinct_p1,
            "history_dependent_formation_morphology": len(distinct_p1) >= 3,
            "native_one_shot_history_to_P1_to_function_chain": True,
            "post_A_environmental_remodeling": False,
            "A_to_B_to_A_or_C": False,
            "classification": "ONE_SHOT_HISTORY_DEPENDENT_MORPHOLOGY_PARTIALLY_SUPPORTED; ADAPTIVE_REMORPHING_NOT_DEMONSTRATED",
        },
        "self_maintenance_audit": {
            "functional_robustness_present": perturbation_stats["receiver_function_unchanged_all_observed_ticks"] > 0,
            "constituent_turnover_with_function": False,
            "active_restoration_after_damage": False,
            "predefined_viability_preserved_by_state_specific_reorganization": False,
            "classification": "OPEN_HYPOTHESIS; PASSIVE_ROBUSTNESS_IS_NOT_SELF_MAINTENANCE",
        },
        "environment_as_effector_audit": {
            "one_shot_native_environment_to_later_function": True,
            "post_A_direct_receiver_effects": direct_receiver,
            "direct_receiver_effect_is_learning": False,
            "environmental_modification_feeds_back_to_later_experience": False,
            "closed_loop": False,
            "classification": "PARTIALLY_SUPPORTED_ONE_SHOT_EFFECT; NO FEEDBACK CLOSURE",
        },
        "unexpected_mechanism": {
            "name": "STATE_DEPENDENT_BOUNDARY_AMPLIFICATION",
            "evidence": "DRT10 semantic sheets increase distal A response but leave PLASTIC trace nearly unchanged",
            "status": "DIAGNOSTIC_ONLY",
            "not_yet": ["wave reflection", "field coupling", "adaptive transition", "native function"],
        },
        "hypothesis_status": {
            "H6_collective_attractor_transition": "PARTIALLY_SUPPORTED",
            "H10_morphological_causal_adaptation": "PARTIALLY_SUPPORTED",
            "H11_self_maintaining_causal_organization": "OPEN_HYPOTHESIS",
            "H15_environment_as_effector": "PARTIALLY_SUPPORTED",
            "H16_unanticipated_mechanism": "DIAGNOSTIC_ONLY",
        },
        "summary": {
            "attractor_label_promoted": False,
            "adaptive_morphological_reversal_demonstrated": False,
            "self_maintenance_demonstrated": False,
            "closed_environment_loop_demonstrated": False,
            "second_independent_experience_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Robust function under some perturbations is not exact basin convergence or self-maintenance. Direct environmental action on a receiver is not learning. One-shot morphology is not recurrent adaptation.",
        "evidence": [{"id": key, "path": path, "file_sha256": sha256_file(ROOT / path),
                      "content_sha256": evidence[key].get("content_sha256")} for key, path in FILES.items()],
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(),
                      "content_sha256": result["content_sha256"],
                      "hypothesis_status": result["hypothesis_status"],
                      "summary": result["summary"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
