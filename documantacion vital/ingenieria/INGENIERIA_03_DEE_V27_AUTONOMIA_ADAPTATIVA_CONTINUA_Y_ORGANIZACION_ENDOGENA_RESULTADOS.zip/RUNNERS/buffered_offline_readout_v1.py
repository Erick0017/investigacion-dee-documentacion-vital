#!/usr/bin/env python3
"""Candidate one-cycle native consequence-buffer/write/delayed-query organization."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, add, pack, read, transform
from relative_magnitude_reader_v1 import PA, PB, inverse


def _put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def build_world(kernel, *, n, origin, target_name, permutation=(0, 1, 2), signs=(1, 1, 1), mode="treatment"):
    tf = lambda vector: transform(vector, permutation, signs)
    c = tuple(int(x) % int(n) for x in origin); a = add(c, tf((-1, 0, 0)), 1, n); b = add(c, tf((1, 0, 0)), 1, n)
    memory_phase, query_distance = (252, 12) if target_name == "a" else (240, 24)
    consequence_distance = 6
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    _put(raw, clock, a, 1000, 100, semantic=1, phase=memory_phase); _put(raw, clock, b, 2000, 100, semantic=1, phase=memory_phase)
    for i, offset in enumerate(PA): _put(raw, clock, add(a, tf(offset), 1, n), 3000 + i, 0, semantic=4, phase=31 + i)
    for i, offset in enumerate(PB): _put(raw, clock, add(b, tf(offset), 1, n), 4000 + i, 0, semantic=4, phase=41 + i)
    target = a if target_name == "a" else b
    event = add(target, tf((0, -1, 0)), 1, n); route = tf((0, 0, 1)); generator = add(event, route, -consequence_distance, n)
    d1, d2 = tf((1, 0, 1)), tf((-1, 0, 1))
    if mode not in ("no_consequence", "missing_d1"):
        _put(raw, clock, add(generator, d1, -1, n), 5001, 3, d1, 1, 0)
    if mode != "no_consequence":
        _put(raw, clock, add(generator, d2, -1, n), 5002, 3, d2, 1, 0)
    query_direction = tf((0, 1, 0)); query_start = add(c, query_direction, -query_distance, n)
    if mode != "no_query": _put(raw, clock, query_start, 6000, 7, query_direction, 1, 23)
    metadata = {
        "n": n, "origin": list(c), "a": list(a), "b": list(b), "c": list(c), "target_name": target_name,
        "memory_phase": memory_phase, "consequence_distance": consequence_distance, "query_distance": query_distance,
        "permutation": list(permutation), "signs": list(signs), "mode": mode,
        "expected_write_tick": 9 if target_name == "a" else 21,
        "expected_second_direction": [1, 0, 0] if target_name == "a" else [-1, 1, 1],
    }
    return NativeWorld(kernel, raw, clock), metadata


def execute(world, metadata, horizon=56):
    a, b, c = tuple(metadata["a"]), tuple(metadata["b"]), tuple(metadata["c"])
    permutation, signs = tuple(metadata["permutation"]), tuple(metadata["signs"])
    deltas, events = [], []
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb, rc = read(world.raw, a), read(world.raw, b), read(world.raw, c)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]); deltas.append(delta)
        if rc is not None:
            events.append({"tick": tick, "delta": delta, "state": rc["state"], "sreg": rc["sreg"], "direction": rc["direction"], "normalized_direction": inverse(rc["direction"], permutation, signs), "semantic": rc["semantic"]})
    first_write = next((index + 1 for index, value in enumerate(deltas) if value not in (0, None)), None)
    return {**metadata, "horizon": horizon, "first_write": first_write, "terminal_delta": deltas[-1], "comparator_events": events, "first_comparator_event": None if not events else events[0]["tick"], "second_comparator_direction": None if len(events) < 2 else events[1]["normalized_direction"], "python_interventions_after_t0": 0}


def run_case(kernel, *, horizon=56, **kwargs):
    world, metadata = build_world(kernel, **kwargs)
    return execute(world, metadata, horizon=horizon)
