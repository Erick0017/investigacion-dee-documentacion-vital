#!/usr/bin/env python3
"""Consolidate completed CCE01-33 evidence into the open ING03 checkpoint."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, utc, write_json


BASELINE_SHA = "c97d31075ddc238bf5c4aa8b6b03da1ee79a1a36459e0e922f08140ada298f60"
EVIDENCE = {
    f"CCE{i:02d}": ROOT / f"MECHANISM_SELECTION/ING03_CCE{i:02d}_{name}.json"
    for i, name in enumerate((
        "RECURRENT_COMPETENCE_ATLAS", "COMPETENCE_CAUSAL_TEST", "CAUSAL_RESPONSE_FINGERPRINT",
        "BLIND_ENVIRONMENTAL_EXPOSURE", "SECOND_EXPERIENCE_CAUSAL_TOMOGRAPHY",
        "NATIVE_BLIND_GENERATOR_SURFACES", "FINITE_EXPERIENCE_ALPHABET",
        "DIAGNOSTIC_RECURRENT_SEQUENCE", "INTERFACE_RENEWAL_DIAGNOSTIC",
        "SPATIAL_COMPETENCE_ECOLOGY", "MINIMAL_INTERFACE_SEPARATION",
        "PRECONSOLIDATION_INTERFACE_RENEWAL", "ENVIRONMENTAL_REMATURATION_SCREEN",
        "REMATURATION_RELAXATION", "INTERACTIVE_TURNOVER_SCREEN",
        "BOTTLENECK_COMPONENT_FACTORIZATION", "BOTTLENECK_RELOCATION",
        "TOPOLOGICAL_COMPETENCE_REGENERATION", "VACANCY_REORGANIZATION_WINDOW",
        "HISTORY_PRESERVING_VACANCY", "DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE",
        "TETRAHEDRAL_SUPPORT_VACANCY", "DEVELOPMENTAL_SUPPORT_SUBSTITUTION",
        "REGENERATED_DEVELOPMENTAL_SUPPORT", "REGENERATED_SUPPORT_PHASE_ATLAS",
        "MATURE_PHASE_REMATURATION", "PHASE_STRATIFIED_COMPETENCE",
        "PHASE_STRATIFIED_BROADCAST_SEQUENCE", "SILENT_EXPOSURE_INTERFERENCE",
        "REMOTE_COMPETENCE_INDUCTION_CONTROLS", "INDUCED_COMPETENCE_CHAIN",
        "NATIVE_B_INDUCED_COMPETENCE", "T0_A_NATIVE_B_FACTORIAL"), 1)
}
RUNNERS = {key: f"RUNNERS/run_{key.lower()}_{path.stem.split(key + '_', 1)[1].lower()}.py"
           for key, path in EVIDENCE.items()}


def load(path): return json.loads(Path(path).read_text(encoding="utf-8"))


def ref(key):
    path = EVIDENCE[key]; data = load(path)
    return {"evidence_id": key, "path": path.relative_to(ROOT).as_posix(),
            "file_sha256": sha256_file(path), "content_sha256": data.get("content_sha256")}


def write_report(name, body): write_json(ROOT / name, seal(body))


def update_claim_ledger():
    path = ROOT / "CLAIM_LEDGER.json"; ledger = load(path)
    new = [
        ("ING03-CCE01", "PARTIALLY_SUPPORTED", "Recurrent S0/S1 windows exist, but a clock-only predictor does not generalize across morphologies.", "CCE01"),
        ("ING03-CCE02", "DEMONSTRATED", "Within the tested morphology, transplanting clock state transfers S1-open/closed status in 6/6 pairs while RAW-only transplant does not.", "CCE02"),
        ("ING03-CCE03", "DIAGNOSTIC_ONLY", "Finite aligned SEM1 and D12 experiences can create retained response-class changes to a later identical probe in competence-open snapshots.", "CCE03"),
        ("ING03-CCE04", "BOUNDED_NULL", "The tested 121-carrier blind planes yield no replicated open-only capture with direct path excluded.", "CCE04"),
        ("ING03-CCE05", "DIAGNOSTIC_ONLY", "The SEM1 response class survives removal of original carriers from latency1 and requires equalization of all 22 terminal RAW differences, not either local/external subset alone.", "CCE05"),
        ("ING03-CCE06", "BOUNDED_NULL", "Tested all-t0 collision surfaces fail both the broken-parent and no-periphery direct-path controls.", "CCE06"),
        ("ING03-CCE07", "FRESH_CONFIRMED", "The same interface captures only the aligned direction at open windows; semantic1/2/3 collapse to one response class in an unseen time/frame holdout.", "CCE07"),
        ("ING03-CCE08", "CONTRADICTED_IN_TESTED_DOMAIN", "In the tested same-region B→C→B sequence, B is retained but C and the return B do not create new retained functional response classes.", "CCE08"),
        ("ING03-CCE09", "CONTRADICTED_IN_TESTED_DOMAIN", "Tested local renewal cannot preserve B function and restore C2 simultaneously; every C2-restoring equalization erases B function.", "CCE09"),
        ("ING03-CCE10", "PARTIALLY_SUPPORTED", "Two preassigned regions can layer B and C diagnostic response classes, but a third region fails and no region is renewed/reused.", "CCE10"),
        ("ING03-CCE11", "CONTRADICTED_IN_TESTED_DOMAIN", "No subset of the four local B-history RAW differences preserves B and restores C2 in either of two relational frames; one occupied offset is the shared bottleneck.", "CCE11"),
        ("ING03-CCE12", "CONTRADICTED_IN_TESTED_DOMAIN", "Renewal at t288 followed by 0/16/32 ticks of rematuration never preserves B and restores C2 in either frame.", "CCE12"),
        ("ING03-CCE13", "BOUNDED_NULL", "Finite incoming semantic1-3 pressures do not change the bottleneck; semantic4 produces a persistent state4 regime without C2.", "CCE13"),
        ("ING03-CCE14", "BOUNDED_NULL", "The semantic4 state4 regime and its marker persist through t512 and never relax into C2 competence in three arrival directions.", "CCE14"),
        ("ING03-CCE15", "BOUNDED_NULL", "Twenty-four finite RAW transformations from 54 regulated/two-parent interactions restore neither S1 nor C2.", "CCE15"),
        ("ING03-CCE16", "DIAGNOSTIC_ONLY", "Many state/s_reg/direction/semantic mutations preserve B, but no occupied variant restores C2; occupancy, not encoded content alone, gates competence.", "CCE16"),
        ("ING03-CCE17", "CONTRADICTED_IN_TESTED_DOMAIN", "Twenty valid neighboring relocations cannot preserve B; 17 reopen C2 only after losing the old functional response.", "CCE17"),
        ("ING03-CCE18", "DIAGNOSTIC_ONLY", "A RAW+clock vacancy initially appears to preserve a B distinction and reopen C2, but the matched naive canary is altered; the apparent renewal is not valid.", "CCE18"),
        ("ING03-CCE19", "CONTRADICTED_IN_TESTED_DOMAIN", "Across gaps 0-64, RAW+clock vacancy never preserves the exact B response and fails the naive no-effect canary at the only C2-positive gaps.", "CCE19"),
        ("ING03-CCE20", "DEMONSTRATED", "RAW-only vacancy with clock/history preserved yields a layered BC diagnostic response at gaps 0-1 in two frames while the naive RAW-clear control is a no-op; exact B response identity is not preserved.", "CCE20"),
        ("ING03-CCE21", "DEMONSTRATED", "Repeated host RAW-only vacancies enable a diagnostic B->C->B response sequence in one continuous world in two frames; the third experience fails without the second vacancy.", "CCE21"),
        ("ING03-CCE22", "DEMONSTRATED", "Removing any member of the four-anchor tetrahedral support vacates the bottleneck in one tick but also abolishes C2; the semantic4 supports remain byte-identical for 64 ticks.", "CCE22"),
        ("ING03-CCE23", "BOUNDED_NULL", "In the complete 2^4 t0 semantic4-to-semantic1 support substitution, every nonzero substitution loses initial C2 and none renews C2 at t320 or t704.", "CCE23"),
        ("ING03-CCE24", "BOUNDED_NULL", "Persistent-source replenished semantic1 anchors create near-tickwise structural turnover, but every tested nonzero support replacement loses initial functional competence and no recurrent C2 emerges.", "CCE24"),
        ("ING03-CCE25", "BOUNDED_NULL", "Phase-resolved assays across two structural alternations find no shifted C2 for representative one-anchor or four-anchor regenerated-support architectures in discovery or rotated holdout.", "CCE25"),
        ("ING03-CCE26", "CONTRADICTED_IN_TESTED_DOMAIN", "Seventeen local phase-only interventions on a mature B organization preserve the learned response control but never reopen C2 in the tested local domains.", "CCE26"),
        ("ING03-CCE27", "PARTIALLY_SUPPORTED", "Frozen t0 clock strata create replicated late C2 opportunities at offsets 16, 48 and 208, but no B-selector stratum or continuous competence coverage.", "CCE27"),
        ("ING03-CCE28", "PARTIALLY_SUPPORTED", "A non-addressed diagnostic B broadcast is captured only by the fresh early region, while the later phase stratum does not capture C in the same sequence.", "CCE28"),
        ("ING03-CCE29", "DIAGNOSTIC_ONLY", "B capture in a separated early region induces a later distant C2 opportunity; global RAW/R0 transfer is sufficient while local late-region transfer is not.", "CCE29"),
        ("ING03-CCE30", "DIAGNOSTIC_ONLY", "Fresh-region functional B capture, not broken traffic, saturated contact, late-local contact or missing periphery, causes remote competence induction; early radius2 RAW remains necessary at t480.", "CCE30"),
        ("ING03-CCE31", "DIAGNOSTIC_ONLY", "One uninterrupted diagnostic world completes retained A, retained B and a C2 C capture selected by remotely induced competence while preserving prior A/B response classes.", "CCE31"),
        ("ING03-CCE32", "BOUNDED_NULL", "The tested all-t0 RCA06 B generator reaches node2 at tick140 but produces neither retained C2 B capture nor remote late competence in the composed apparatus.", "CCE32"),
        ("ING03-CCE33", "PARTIALLY_SUPPORTED", "Two causally distinct early A histories add native-B C2 windows at ticks480 and704, but neither produces the remote induction seen when B is formed diagnostically after maturation.", "CCE33"),
    ]
    by_id = {claim.get("claim_id"): claim for claim in ledger.get("claims", [])}
    for claim_id, status, text, key in new:
        by_id[claim_id] = {"claim_id": claim_id, "status": status, "claim": text,
                           "scope": "continuous causal ecology CCE01-33",
                           "evidence": [ref(key)], "runner": RUNNERS[key],
                           "promoted_native_capability": False}
    old_order = [c.get("claim_id") for c in ledger.get("claims", [])]
    ledger["claims"] = [by_id[cid] for cid in old_order if cid in by_id] + [by_id[x[0]] for x in new if x[0] not in old_order]
    ledger["continuous_causal_ecology_completion"] = {
        "baseline_sha256": BASELINE_SHA, "evidence": [ref(k) for k in EVIDENCE],
        "new_claims": [x[0] for x in new], "checkpoint_new_claims": [x[0] for x in new if int(x[0].split("CCE")[-1]) >= 26],
        "new_promoted_native_claims": [],
        "highest_rw": "RW2", "rw3": False,
        "precise_obstruction": "diagnostic remote induction and A-B-C capture now exist, but the tested all-t0 B generator does not reproduce post-maturation induction and no tested native process renews a competent interface or produces promoted DEE-native function",
        "methodological_correction": "CCE05 clones only current raw plus clock_a; raw_b and clock_b are kernel scratch buffers and are never treated as independent causal state",
        "ingenieria_03_open": True,
    }
    ledger["highest_rw"] = "RW2"; ledger["l4_achieved"] = False
    ledger["new_claims"] = sorted(set(ledger.get("new_claims", [])) | {x[0] for x in new})
    ledger.pop("content_sha256", None); ledger.pop("created_utc", None)
    write_json(path, seal(ledger))


def update_registries():
    hpath = ROOT / "HOLDOUT_REGISTRY.json"; h = load(hpath)
    h["continuous_causal_ecology"] = {
        "status": "DIAGNOSTIC_HOLDOUT_ONLY_NO_PROMOTED_NATIVE_CLAIM",
        "fresh_diagnostic_result": "CCE20/21 replicate RAW-only layered recurrence in a rotated frame; CCE25 replicates the regenerated-support null; CCE30 causally controls remote induction, while CCE32/33 bound its all-t0 composition",
        "evidence": [ref("CCE07"), ref("CCE20"), ref("CCE21"), ref("CCE25"), ref("CCE30"), ref("CCE32"), ref("CCE33")], "architecture_freeze_for_native_claim": False,
        "promoted_native_holdouts": 0, "rw3_holdouts": 0,
    }
    h["all_passed"] = False
    h.pop("content_sha256", None); h.pop("created_utc", None); write_json(hpath, seal(h))

    cpath = ROOT / "CANARY_REGISTRY.json"; c = load(cpath)
    c["continuous_causal_ecology_canaries"] = [
        {"id": "CCE05_CLOSED_WINDOW", "status": "PASS", "finding": "t144 lacks C2 while open t128/t320 reproduce", "evidence": ref("CCE05")},
        {"id": "CCE04_NO_PERIPHERY", "status": "FAILS_PROMOTION", "finding": "broad plane retains direct pair paths", "evidence": ref("CCE04")},
        {"id": "CCE06_BROKEN_PARENT", "status": "FAILS_PROMOTION", "finding": "single-parent surface reproduces retained differences", "evidence": ref("CCE06")},
        {"id": "CCE06_NO_PERIPHERY", "status": "FAILS_PROMOTION", "finding": "surface functions persist after periphery removal", "evidence": ref("CCE06")},
        {"id": "CCE09_RESET_TRADEOFF", "status": "PASS_BOUNDARY", "finding": "reopening C2 always loses B function in tested interventions", "evidence": ref("CCE09")},
        {"id": "CCE19_NAIVE_CLOCK_CLEAR", "status": "PASS_CAUGHT_FALSE_POSITIVE", "finding": "clearing an empty site's clock changes the naive response class", "evidence": ref("CCE19")},
        {"id": "CCE20_NAIVE_RAW_CLEAR", "status": "PASS", "finding": "RAW-only clear is a no-op in naive controls at the positive gaps", "evidence": ref("CCE20")},
        {"id": "CCE21_NO_VACANCY", "status": "PASS_CAUSAL", "finding": "third diagnostic B fails without renewed RAW vacancy", "evidence": ref("CCE21")},
        {"id": "CCE25_PHASE_CONTROL", "status": "PASS", "finding": "fixed support retains C2 while regenerated support fails in matched phases", "evidence": ref("CCE25")},
        {"id": "CCE30_BROKEN_GENERATOR", "status": "PASS_CAUSAL", "finding": "broken B generator, saturated A, late-local contact and missing periphery do not induce distant C2", "evidence": ref("CCE30")},
        {"id": "CCE32_NATIVE_B_BOUNDARY", "status": "PASS_BOUNDARY", "finding": "native B arrives after Function A but does not become C2 or induce the late region", "evidence": ref("CCE32")},
        {"id": "CCE33_FACTORIAL", "status": "PASS_CAUSAL", "finding": "two distinct A histories add the same B C2 windows but neither creates remote induction", "evidence": ref("CCE33")},
    ]
    # Preserve the heterogeneous historical new_canaries records verbatim; the
    # CCE registry above is the authoritative typed extension.
    c.pop("content_sha256", None); c.pop("created_utc", None); write_json(cpath, seal(c))


def status_reports():
    common_evidence = [ref(k) for k in EVIDENCE]
    frontier = {
        "schema": "dee.v27.ing03.continuous_causal_ecology.frontier.v1", "baseline_sha256": BASELINE_SHA,
        "classification": "DIAGNOSTIC_THREE_EXPERIENCE_AND_REMOTE_COMPETENCE_INDUCTION_NOT_RW3",
        "highest_rw": "RW2", "highest_autonomy": "L3_FINITE_INHERITED", "rw3_achieved": False,
        "strongest_chain": ["retained diagnostic A", "fresh-region retained diagnostic B",
                            "capture-dependent remote competence induction", "late C2 capture of diagnostic C",
                            "prior A/B response classes preserved"],
        "new_causal_boundaries": ["clock state causes S1-open/closed within tested morphology",
                                  "same-region B blocks causally distinct C despite open temporal window",
                                  "local reset restores C2 only by losing B function",
                                  "two regions layer diagnostic histories once; third tested region fails",
                                  "blind plane/surface families fail direct-path or broken-generator canaries",
                                  "complete four-state subset decomposition identifies offset(1,-1,-1) as a shared function/competence bottleneck",
                                  "content mutation, finite collision and neighboring relocation do not regenerate C2 while retaining B",
                                  "RAW-only vacancy preserves distributed B information and enables diagnostic B-C-B recurrence in two frames",
                                  "tetrahedral anchor loss generates vacancy but destroys C2",
                                  "direct and replenished nonimmutable support substitutions fail functional competence despite structural turnover",
                                  "mature local phase edits do not reopen C2 in the tested domains",
                                  "t0 phase strata create late C2 opportunities but no continuous coverage",
                                  "fresh-region B capture causally induces a distant later C2 opportunity through early-region RAW organization",
                                  "the complete diagnostic A-B-C chain exists in one world but uses host experiences and external fingerprints",
                                  "the tested all-t0 native B generator does not reproduce capture-dependent remote induction",
                                  "early A history changes native-B C2 timing without producing remote induction"],
        "missing_operation": "a genuinely later, non-directed native environmental episode that is captured after maturation and drives DEE-native function, together with bounded renewal/reuse of functional competence",
        "open_domains": ["native occupant turnover without support loss", "lineage/topology regeneration beyond anchor substitution", "collective attractor rematuration", "larger-scale morphological renewal", "other blind environmental geometries", "X_FULL support beyond public raw/clock"],
        "methodological_correction": {"public_clonable_proxy": "raw + clock_a", "scratch_buffers": ["raw_b", "clock_b"],
                                      "scratch_buffers_are_not_independent_causal_state": True, "evidence": [ref("CCE05")]},
        "ingenieria_03_open": True, "campaign_complete": False,
        "evidence": common_evidence,
    }
    write_report("ING03_CURRENT_CAUSAL_FRONTIER.json", frontier)

    gap = {"schema": "dee.v27.ing03.continuous_causal_ecology.l4_gap.v1", "highest_rw": "RW2",
           "gaps": [
               {"edge": "independent native B", "required": True, "observed": "PARTIAL_ALL_T0_GENERATOR_WITHOUT_POST_MATURATION_INDUCTION", "evidence": [ref("CCE32"), ref("CCE33")]},
               {"edge": "retained C2 after B in same organization", "required": True, "observed": False, "evidence": [ref("CCE08")]},
               {"edge": "renewal preserving function", "required": True, "observed": False,
                "evidence": [ref("CCE09"), ref("CCE11"), ref("CCE12"), ref("CCE15"), ref("CCE16"), ref("CCE17")]},
               {"edge": "third transition", "required": True, "observed": "DIAGNOSTIC_HOST_VACANCY_ONLY", "evidence": [ref("CCE21")]},
               {"edge": "bounded reuse 8+ cycles", "required": True, "observed": False, "evidence": [ref("CCE10")]},
               {"edge": "closed environment feedback", "required": True, "observed": False, "evidence": []},
               {"edge": "48 fresh worlds / 1024 cycles", "required": True, "observed": False, "evidence": []},
           ], "l4_candidate": False, "l4_achieved": False, "ingenieria_03_open": True, "evidence": common_evidence}
    write_report("ING03_CURRENT_L4_GAP_MATRIX.json", gap)

    rw3 = {"schema": "dee.v27.ing03.continuous_causal_ecology.rw3.v1", "question": "Has one promoted world completed A→Function A→B→Function B→A/C→Function?",
           "status": "NOT_DEMONSTRATED", "qualifying_worlds": 0, "highest_rw": "RW2",
           "diagnostic_findings": ["CCE08: first B succeeds; same-region C and return B fail without renewal",
                                   "CCE10: two one-shot regions layer histories; third fails",
                                   "CCE11-17: the occupied relational bottleneck cannot be renewed, transformed or relocated while preserving exact B",
                                   "CCE20-21: clock-preserving RAW vacancy enables layered B-C-B diagnostic recurrence in two frames",
                                   "CCE29-31: fresh-region B capture induces distant C2 and completes diagnostic A-B-C in one uninterrupted world",
                                   "CCE32: the tested native B generator reaches the region but does not become C2 or induce remote competence",
                                   "CCE33: early A adds native-B C2 windows but still does not induce remote competence"],
           "blocking_conditions": ["events/probes diagnostic in positive C2 runs", "blind native runs fail causal canaries",
                                   "no tested native generation of the required RAW vacancy", "no non-directed native environment", "no native DEE function"],
           "rw3_demonstrated": False, "rw4_demonstrated": False, "rw5_demonstrated": False, "l4_demonstrated": False,
           "evidence": [ref("CCE08"), ref("CCE10"), ref("CCE04"), ref("CCE06"), ref("CCE11"), ref("CCE17"), ref("CCE20"), ref("CCE21"), ref("CCE25"), ref("CCE29"), ref("CCE30"), ref("CCE31"), ref("CCE32"), ref("CCE33")]}
    write_report("ING03_RW3_RECURRENT_EXPRESSION.json", rw3)
    write_report("ING03_RW3_CONTINUOUS_WORLD.json", rw3 | {"schema": "dee.v27.ing03.continuous_causal_ecology.rw3_world.v1"})
    write_report("ING03_RW4_RESOURCE_REUSE.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.rw4.v1", "status": "NOT_ELIGIBLE_RW3_ABSENT",
                 "resource_audit": {"bounded_world": True, "diagnostic_regions_consumed": 2, "third_region_capture": False,
                                    "native_renewal": False, "cycles_completed": 0},
                 "finding": "CCE21 and CCE31 reach three diagnostic experiences through host interventions or one-shot preconditioned regions; no tested mechanism renews them natively", "rw4_demonstrated": False,
                 "evidence": [ref("CCE10"), ref("CCE20"), ref("CCE21"), ref("CCE22"), ref("CCE23"), ref("CCE24"), ref("CCE25"), ref("CCE31")]})
    write_report("ING03_RW5_CLOSED_ADAPTIVE_LOOP.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.rw5.v1", "status": "NOT_ELIGIBLE_RW3_RW4_ABSENT",
                 "closed_environment_feedback": False, "organization_modifies_future_contingencies": False,
                 "rw5_demonstrated": False, "evidence": [ref("CCE06"), ref("CCE10")]})
    write_report("ING03_L4_CAUSAL_OBSTRUCTION.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.l4_obstruction.v1", "status": "NOT_ELIGIBLE",
                 "precise_missing_operation": frontier["missing_operation"], "not_global_impossibility": True,
                 "rw3": False, "rw4": False, "rw5": False, "l4": False, "ingenieria_03_open": True,
                 "tested_obstructions": frontier["new_causal_boundaries"], "untested_domains": frontier["open_domains"], "evidence": common_evidence})
    write_report("ING03_AUTONOMY_LEVELS.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.autonomy.v1", "status": "L3_FINITE_INHERITED_PRESERVED",
                 "highest_rw": "RW2", "rw3": False, "rw4": False, "rw5": False, "l4": False,
                 "diagnostic_C2": True, "native_continuous_adaptation": False, "evidence": [ref("CCE03"), ref("CCE05")]})
    write_report("ING03_AUTONOMY_LIFETIME.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.lifetime.v1", "status": "FINITE_NOT_RENEWED",
                 "complete_promoted_adaptive_cycles": 0, "diagnostic_layered_experiences": 2, "third_diagnostic_capture": False,
                 "bounded_reuse": False, "evidence": [ref("CCE10")]})


def audits():
    anti_rows = [
        ("CCE01", False, False, True, "diagnostic time-indexed writer"),
        ("CCE02", False, False, True, "diagnostic state transplants"),
        ("CCE03", True, True, True, "host-installed same-port challenge/probe"),
        ("CCE04", False, False, True, "blind plane but host-inserted snapshot"),
        ("CCE05", True, True, True, "tomography of targeted diagnostic candidate"),
        ("CCE06", False, False, False, "all-t0 blind surfaces; fails canaries"),
        ("CCE07", True, True, True, "same-port diagnostic alphabet"),
        ("CCE08", True, True, True, "host-timed B/C/B sequence"),
        ("CCE09", True, True, True, "host equalization renewal"),
        ("CCE10", True, True, True, "preassigned one-use regions"),
        ("CCE11", True, True, True, "host subset equalization"),
        ("CCE12", True, True, True, "host preconsolidation renewal and timed C"),
        ("CCE13", True, True, True, "aimed incoming pressure"),
        ("CCE14", True, True, True, "aimed pressure and timed C probes"),
        ("CCE15", True, True, True, "aimed collision screen"),
        ("CCE16", True, True, True, "direct RAW component mutation"),
        ("CCE17", True, True, True, "host topological relocation"),
        ("CCE18", True, True, True, "host vacancy/scaffold installation"),
        ("CCE19", True, True, True, "host RAW+clock vacancy"),
        ("CCE20", True, True, True, "host RAW-only vacancy and diagnostic factorial"),
        ("CCE21", True, True, True, "two host RAW vacancies and three diagnostic experiences"),
        ("CCE22", True, True, True, "host tetrahedral-support ablation"),
        ("CCE23", True, True, True, "t0 support architecture; host experiences/probes"),
        ("CCE24", True, True, True, "t0 replenished-support architecture; host experiences/probes"),
        ("CCE25", True, True, True, "t0 architecture; host phase-resolved competence panel"),
        ("CCE26", True, True, True, "host local phase interventions on mature B histories"),
        ("CCE27", True, True, True, "t0 phase strata; host diagnostic competence challenges"),
        ("CCE28", False, True, True, "non-addressed diagnostic broadcasts; host timing and external fingerprints"),
        ("CCE29", True, True, True, "host exposure factorial and RAW/CLOCK/R0 transplants"),
        ("CCE30", True, True, True, "host B experiences, diagnostic C2 probes and causal equalizations"),
        ("CCE31", False, True, True, "one uninterrupted world but host A/B/C events and external response fingerprints"),
        ("CCE32", True, True, True, "all-t0 recipient-referencing B generator; diagnostic B/C2 probes"),
        ("CCE33", True, True, True, "all-t0 factorial main worlds; diagnostic clone assays and recipient-referencing B"),
    ]
    write_report("ING03_ANTI_CLASSICAL_BIAS_AUDIT.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.anti_classical.v1",
        "rows": [{"experiment": k, "preassigned_recipient": pr, "central_external_readout": cr,
                  "python_decision_after_t0": py, "classification": "DIAGNOSTIC_ONLY" if py or pr else "NATIVE_T0_TEST",
                  "reason": reason, "evidence": ref(k)} for k, pr, cr, py, reason in anti_rows],
        "promoted_mechanisms_with_classical_leakage": 0, "audit_pass": True,
        "finding": "positive C2/renewal/layering results remain diagnostic; the only all-t0 blind family failed canaries"})
    write_report("ING03_PYTHON_INTERVENTION_AUDIT.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.python_audit.v1", "audit_pass": True,
        "diagnostic_after_t0": [k for k, _, _, py, _ in anti_rows if py], "native_tick_log_stop_only": ["CCE06", "CCE32_MAIN", "CCE33_MAIN"],
        "promoted_rw3_runs": [], "rw3_promoted": False,
        "finding": "No host-intervened result is promoted to native autonomy", "evidence": [ref(k) for k in EVIDENCE]})
    families = {
        "recurrent_competence": "PARTIALLY_SUPPORTED", "multi_challenge_C2": "DIAGNOSTIC_ONLY",
        "blind_environment_direct_plane": "BOUNDED_NULL", "blind_environment_native_surfaces": "BOUNDED_NULL",
        "history_tomography": "DIAGNOSTIC_ONLY", "same_region_recurrence": "CONTRADICTED_IN_TESTED_DOMAIN",
        "interface_renewal": "CONTRADICTED_IN_TESTED_DOMAIN", "spatial_layering": "PARTIALLY_SUPPORTED",
        "minimal_interface_separation": "CONTRADICTED_IN_TESTED_DOMAIN",
        "preconsolidation_renewal": "CONTRADICTED_IN_TESTED_DOMAIN",
        "interactive_turnover": "BOUNDED_NULL", "local_morphological_relocation": "CONTRADICTED_IN_TESTED_DOMAIN",
        "history_preserving_RAW_vacancy": "DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE",
        "tetrahedral_support_turnover": "CONTRADICTED_IN_TESTED_DOMAIN",
        "developmental_support_substitution": "BOUNDED_NULL",
        "replenished_support_turnover": "STRUCTURAL_ONLY_NO_C2",
        "replenished_support_phase_atlas": "BOUNDED_NULL_NEAR_T128",
        "mature_local_phase_reopening": "CONTRADICTED_IN_TESTED_DOMAIN",
        "phase_stratified_competence": "PARTIALLY_SUPPORTED",
        "capture_dependent_remote_competence_induction": "DIAGNOSTIC_ONLY_CAUSALLY_CONTROLLED",
        "diagnostic_induced_competence_chain": "DIAGNOSTIC_ONLY_THREE_EXPERIENCES",
        "all_t0_native_B_induction": "BOUNDED_NULL_IN_TESTED_COMPOSITION",
        "early_A_native_B_temporal_conditioning": "PARTIALLY_SUPPORTED_NO_REMOTE_INDUCTION",
        "endogenous_turnover": "UNRESOLVED", "collective_attractor": "UNRESOLVED",
        "wave_field_resonance": "OPEN_HYPOTHESIS", "morphological_adaptation": "OPEN_HYPOTHESIS",
        "self_maintenance": "OPEN_HYPOTHESIS",
    }
    write_report("ING03_EXPERIMENT_COMPLETENESS_AUDIT.json", {"schema": "dee.v27.ing03.continuous_causal_ecology.completeness.v1",
        "status": "PASS", "families": families, "no_cross_family_abort": True,
        "causally_distinct_new_experiments": list(EVIDENCE), "bounded_nulls_not_globalized": True,
        "rw4_rw5_l4_not_run_for_prerequisite_reason": True,
        "interrupted_without_evidence": ["CCE34_NATIVE_B_PHASE_DELAY_ATLAS"],
        "interrupted_runner_excluded_from_official_package": True,
        "scratch_buffer_correction": {"raw_b_clock_b_are_kernel_scratch": True,
                                      "causal_clone_proxy": "raw + clock_a", "evidence": [ref("CCE05")]},
        "evidence": [ref(k) for k in EVIDENCE]})


def dependency_map():
    ledger = load(ROOT / "CLAIM_LEDGER.json"); rows = []
    for claim in ledger.get("claims", []):
        evidence = claim.get("evidence", []) or claim.get("discovery_evidence", []) or []
        paths = [item.get("path") for item in evidence if isinstance(item, dict) and item.get("path")]
        runner = claim.get("runner")
        rows.append({"claim_id": claim.get("claim_id"), "status": claim.get("status"),
                     "decisive_evidence": paths, "runner": runner,
                     "all_evidence_present": all((ROOT / p).exists() for p in paths),
                     "runner_present": runner is None or (ROOT / runner).exists()})
    write_report("ING03_CLAIM_EVIDENCE_DEPENDENCY_MAP.json", {"schema": "dee.v27.ing03.claim_evidence_map.v2",
        "claim_count": len(rows), "claims": rows,
        "all_referenced_evidence_present": all(x["all_evidence_present"] for x in rows),
        "all_required_runners_present": all(x["runner_present"] for x in rows),
        "current_campaign_evidence": [ref(k) for k in EVIDENCE]})


def markdown_reports():
    executive = """# Veredicto ejecutivo — ecología causal continua

RW2 permanece como máximo promovido; RW3, RW4, RW5 y L4 no están demostrados. La campaña sí resolvió una parte importante del mecanismo: en ventanas abiertas, una experiencia SEM1 finita deja una distinción C2 diagnóstica que sobrevive al portador original, se distribuye en 22 diferencias RAW y cambia la interacción con un desafío posterior. El reloj local controla causalmente S1 en la morfología no aprendida, pero no basta para reabrir una organización que ya incorporó B.

La segunda experiencia causalmente distinta C funciona en el control no expuesto y falla sobre B. Renovar de 4 a 22 estados RAW locales/globales restaura C2, pero sólo borrando la función B; las intervenciones que conservan B no reabren C. Dos regiones preasignadas pueden estratificar B y C una vez, pero una tercera región no captura y no existe renovación.

Los ambientes amplios tampoco cierran la cadena: el plano diagnóstico no excluye camino directo y las superficies nativas desde t0 responden con un solo padre y conservan función sin periferia. Son nulos acotados de esas geometrías, no una prohibición general.

CCE11–CCE17 resuelven la ambigüedad local con controles exhaustivos dentro del dominio público accesible. La tabla completa de 16 subconjuntos identifica una relación ocupada en el desplazamiento canónico `(1,-1,-1)`: mantenerla conserva B pero bloquea C2; liberarla reabre C2 pero elimina B. Adelantar la intervención, cambiar estado, `s_reg`, dirección o semántica, provocar 24 transformaciones por interacción y trasladar el estado a 20 vecinos válidos no produce separación. Esto demuestra un cuello de botella de ocupación/organización en el aparato probado, no un registro cuyo contenido deba reescribirse.

CCE18–CCE21 encuentran la separación que faltaba, pero sólo en diagnóstico. Vaciar RAW conservando el reloj del sitio mantiene información distribuida de B, permite una C retenida y, tras una segunda vacancia, permite otra B en el mismo mundo. La secuencia B→C→B replica en dos marcos y falla sin la segunda vacancia. No conserva idénticamente la vieja huella B: produce regímenes estratificados nuevos. Borrar también el reloj fue correctamente rechazado por el canario naive.

CCE22–CCE25 explican por qué la vacancia no aparece nativamente en este aparato. Cuatro anclas `semantic4` forman el soporte tetraédrico: quitar cualquiera vacía el sitio, pero destruye C2. Sustituirlas por soporte ordinario elimina competencia inicial. Reponerlas desde fuentes persistentes produce turnover estructural casi tick-a-tick, pero tampoco C2, incluso al resolver dos fases consecutivas. La operación ausente es ahora concreta: una vacancia RAW nativa —o renovación desarrollativa equivalente— que preserve reloj/historia y topología competente, seguida de captura ambiental no dirigida y función DEE nativa. Ingeniería 03 permanece abierta; no se crea Ingeniería 04.

CCE26–CCE33 añaden una operación organizacional distinta sin cambiar el nivel promovido. La fase local de una organización B madura no reabre C2; en cambio, estratos de fase t0 sí conservan oportunidades C2 tardías. Una captura B funcional en una región fresca induce causalmente competencia C2 en una región distante: el efecto desaparece con generador roto, contacto saturado, contacto tardío local o ausencia de periferia, y depende todavía del RAW de radio2 de la región B en t480. Esa inducción permite una cadena diagnóstica A→B→C en un solo mundo, pero A/B/C y la función siguen siendo diagnósticos y las regiones son preacondicionadas de un solo uso.

La reconstrucción all-t0 acota el borde faltante. El generador nativo B llega en t140 pero no reproduce C2/inducción; dos historias A tempranas causalmente distintas añaden ventanas C2 de B en t480/t704, pero tampoco inducen la competencia remota. Por tanto el requisito no es sólo “B se vuelve C2”: falta que un episodio ambiental genuinamente tardío y no dirigido se forme tras maduración, sea capturado y cambie una función DEE nativa, seguido de renovación acotada. `raw_b/clock_b` se conservan metodológicamente como buffers scratch del kernel; CCE05 clonó únicamente `raw + clock_a` como proxy causal público.
"""
    frontier = """# Frontera científica actual

**Demostrado/promovido:** RW2 y L3 finito heredado.

**Demostrado causalmente en diagnóstico:** fase/reloj local controla S1 en el aparato probado; experiencia finita alineada crea una historia RAW distribuida independiente de su portador; la historia cambia una respuesta posterior; dos regiones preasignadas pueden coexistir con historias diagnósticas distintas.

**Nulos acotados nuevos:** plano amplio CCE04; superficies nativas CCE06; recurrencia sin renovación; tercera región de CCE10; presión finita, relajación, colisiones y relocalización CCE11–17; soporte tetraédrico destruido, las 15 sustituciones no vacías, soporte repuesto y sus fases representativas CCE22–25; reapertura local por fase madura CCE26; composición all-t0 de inducción remota CCE32.

**Demostrado sólo en diagnóstico:** vacancia RAW conservando reloj separa historia distribuida de interfaz; B→C→B se completa en un mundo continuo y dos marcos; una captura B fresca induce competencia C2 distante bajo controles causales CCE29–30; CCE31 completa A→B→C en un mundo diagnóstico preservando respuestas anteriores.

**No demostrado:** episodio B genuinamente tardío, nativo y ciego con internalización; función DEE promovida; renovación/reutilización acotada; lazo ambiental cerrado; RW3/RW4/RW5/L4. CCE34 fue interrumpido antes de evidencia y se excluye del paquete oficial.

**Hipótesis aún abiertas:** turnover causalmente distinto, remaduración colectiva, morfología renovable, atractores con cuenca demostrada, propiedades ondulatorias/de campo definidas operacionalmente y coordenadas de `X_FULL` no accesibles desde RAW/reloj.

**Estado de cierre:** RW2 y L3 finito heredado siguen siendo el máximo. Ingeniería 03 permanece ABIERTA y no se promueve a L4. Este paquete sella el checkpoint ejecutado; no prescribe ni inicia una nueva exploración.
"""
    (ROOT / "ING03_EXECUTIVE_VERDICT.md").write_text(executive, encoding="utf-8")
    (ROOT / "ING03_FINAL_FRONTIER.md").write_text(frontier, encoding="utf-8")
    competence = """# Competencia causal transversal — actualización CCE

`C(X,t;E,F,T)` requiere que una experiencia produzca una distinción retenida y que ésta cambie una respuesta causal posterior. S0 reactividad y S1 retención no bastan.

CCE01 encuentra ventanas recurrentes; CCE02 demuestra que el reloj local transfiere apertura/cierre S1 en 6/6 pares, mientras RAW solo no. CCE03 eleva el panel a C2 diagnóstico: SEM1 finito produce cambio retenido y respuesta posterior distinta en 4/4 casos abiertos y 0/4 cerrados. CCE05 corta todos los portadores originales desde latencia 1 sin perder C2 y ubica soporte causal colectivo en 22 diferencias RAW.

La competencia no es sólo fase. Después de B, la segunda experiencia D12 funciona en el control naive pero no sobre la organización B, aun en t320. CCE09 revela el acoplamiento: preservar B impide C; reabrir C borra B. CCE10 evita el conflicto usando otra región y logra dos historias estratificadas, pero consume capacidad espacial finita y la tercera región falla.

CCE11–CCE17 completan la disección local: los 16 subconjuntos posibles de cuatro diferencias RAW, tres tiempos de renovación temprana, 24 transformaciones producidas por interacción, 18 factorizaciones de componentes y 20 relocalizaciones válidas convergen. La relación ocupada en `(1,-1,-1)` es necesaria para la función B en este aparato y su ocupación bloquea C2; variar su contenido no basta, mientras liberarla o moverla reabre C2 sólo después de perder B. Por ello la siguiente hipótesis no es “resetear un valor”, sino regenerar nativamente una trayectoria/topología competente que pueda coexistir con la historia distribuida.

CCE20 corrige esa frontera: liberar sólo RAW y conservar el reloj no preserva la huella B exacta, pero sí preserva información causal de B y permite formar un régimen BC nuevo. CCE21 repite la operación y obtiene B→C→B diagnóstico en dos marcos; sin la segunda vacancia, la tercera experiencia falla. Por tanto, la capacidad recurrente existe como mecanismo intervenido.

CCE22–CCE25 separan turnover de competencia. El soporte tetraédrico fijo es necesario para C2; romperlo vacía el sitio pero elimina competencia. El soporte repuesto genera turnover estructural abundante, pero no función adaptativa en las fases probadas. Falta turnover del ocupante con conservación de la organización competente, no mera repoblación.

CCE26–CCE33 muestran que la competencia también puede reorganizarse no localmente: una captura B funcional en una región fresca induce una oportunidad C2 distante y permite C diagnóstica. Sin embargo, el generador B all-t0 probado no reproduce esa inducción, y una historia A temprana sólo añade ventanas C2 de B. La diferencia causal relevante queda localizada entre “B presente/capturable desde temprano” y “B formada tras maduración”.

Corrección metodológica preservada: `raw_b` y `clock_b` son buffers scratch del kernel. Los clones causales reproducibles de CCE05 usan el estado público actual `raw + clock_a`; no se atribuye memoria independiente a los buffers de trabajo.

Frontera: falta renovación endógena de C2 o una organización colectiva donde la historia funcional no cierre la misma interfaz requerida por la siguiente experiencia.
"""
    (ROOT / "ING03_COMPETENCE_TRANSVERSAL.md").write_text(competence, encoding="utf-8")


def append_log(name, entry):
    path = ROOT / name; marker = entry["campaign_id"]
    lines = path.read_text(encoding="utf-8").splitlines() if path.exists() else []
    if any(marker in line for line in lines): return
    with path.open("a", encoding="utf-8", newline="\n") as stream:
        stream.write(json.dumps(entry, sort_keys=True, ensure_ascii=False) + "\n")


def logs():
    base = {"campaign_id": "CCE26-33_REMOTE_COMPETENCE_INDUCTION_CHECKPOINT", "timestamp_utc": utc(), "highest_rw": "RW2", "rw3": False}
    append_log("QUESTION_TREE.ndjson", base | {"question": "Can a functionally captured B reorganize later competence, and can the operation be reconstructed natively from t0?", "answer": "remote induction and A-B-C are diagnostic; tested all-t0 B compositions do not reproduce the induction"})
    append_log("RESEARCH_DECISION_LOG.ndjson", base | {"decision": "stop new exploration by user directive; seal CCE26-33, exclude incomplete CCE34, leave ING03 open"})
    append_log("DISTRIBUTED_REGIME_LOG.ndjson", base | {"finding": "fresh-region B capture changes a distant future C2 opportunity without a field/wave promotion"})
    append_log("CAUSAL_TOMOGRAPHY_LOG.ndjson", base | {"finding": "early-region radius2 RAW remains necessary at t480 for remote competence induction"})
    append_log("ENVIRONMENT_LOOP_LOG.ndjson", base | {"finding": "native B generator reaches the organization but does not reproduce post-maturation induction; no closed loop"})
    append_log("RW3_RUN_LOG.ndjson", base | {"finding": "diagnostic A-B-C chain succeeds in one world; host events, external fingerprints and one-shot regions prevent RW3"})
    append_log("RW4_REUSE_LOG.ndjson", base | {"finding": "no renewed/reused competent interface demonstrated; RW4 not eligible"})
    append_log("FAILURE_CAUSAL_ANALYSIS.ndjson", base | {"failure": "native temporal formation of capture-dependent induction", "tested_domain": "local mature phase interventions, t0 phase strata, all-t0 addressed RCA06 B generator, two early-A factorials", "open": "genuinely late non-directed native B, native function and bounded renewal"})


def main():
    missing = [path for path in EVIDENCE.values() if not path.exists()]
    if missing: raise FileNotFoundError(missing)
    update_claim_ledger(); update_registries(); status_reports(); audits(); dependency_map(); markdown_reports(); logs()
    print(json.dumps({"status": "PASS", "evidence": list(EVIDENCE), "highest_rw": "RW2",
                      "rw3": False, "ingenieria_03_open": True, "reports_updated": 18}, indent=2))


if __name__ == "__main__": main()
