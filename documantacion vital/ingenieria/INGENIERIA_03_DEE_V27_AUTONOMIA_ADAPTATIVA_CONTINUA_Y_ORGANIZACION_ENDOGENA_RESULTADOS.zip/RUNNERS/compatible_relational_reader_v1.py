#!/usr/bin/env python3
"""Candidate recurrent relational reader that preserves the writer path."""
from __future__ import annotations

import numpy as np

from ing03_common import NativeWorld, add, pack, read

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
READER_SOURCES = (((2, 1, 0), (-1, -1, 0), 11), ((2, -1, 0), (-1, 1, 0), 13), ((-2, 0, 2), (1, 0, -1), 17), ((-2, 0, -2), (1, 0, 1), 19))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def construct(kernel, spec):
    n = int(spec.get("n", 23)); c = tuple(spec.get("origin", (n // 2,) * 3)); initial_delta = int(spec.get("initial_delta", 0))
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    put(raw, clock, a, 1000, 100 + initial_delta, semantic=1, phase=260)
    put(raw, clock, b, 2000, 100, semantic=1, phase=260)
    for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    writer_side = spec.get("writer_side", "b")
    if writer_side in {"a", "b"}:
        center = a if writer_side == "a" else b
        event = add(center, (0, -1, 0), 1, n); writer = add(event, (0, 0, 1), -3, n)
        put(raw, clock, writer, 5000 if writer_side == "b" else 5001, 0, (0, 0, 1), 4, 0)
    else:
        writer = None
    mode = spec.get("reader_mode", "full")
    if mode != "no_seed": put(raw, clock, c, 1, 7, (1, 0, 0), 1, 11)
    sources = []
    source_semantic = int(spec.get("reader_source_semantic", 4))
    selected_sources = set(spec.get("reader_source_indices", range(len(READER_SOURCES))))
    for index, (offset, direction, sreg) in enumerate(READER_SOURCES):
        if mode == "no_sources" or mode == f"missing_source_{index}" or index not in selected_sources: continue
        q = add(c, offset, 1, n); put(raw, clock, q, 7000 + index, sreg, direction, source_semantic, 100 + index); sources.append((q, int(raw[q])))
    return NativeWorld(kernel, raw, clock), {"a": a, "b": b, "c": c, "writer": writer, "sources": sources}


def relational_delta(world, ports):
    a, b = read(world.raw, ports["a"]), read(world.raw, ports["b"])
    return None if a is None or b is None else a["sreg"] - b["sreg"]


def projection(record):
    return None if record is None else int(record["direction"][0])
