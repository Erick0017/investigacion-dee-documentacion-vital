#!/usr/bin/env python3
"""Correct proximity labels in the completed D03 evidence without rerunning worlds."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, write_json


def main():
    path = ROOT / "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json"
    value = json.loads(path.read_text(encoding="utf-8"))
    templates = value["intact_templates"]
    for row in value["rows"]:
        donor = row["intervention"].get("donor")
        nearest = row["nearest_intact_template"]
        row["nearest_template_is_donor"] = donor is not None and nearest == donor
        row["exact_donor_template_match"] = (donor is not None and
            row["response"]["response_masks_sha256"] == templates[donor]["response_masks_sha256"])
        row.pop("follows_donor_template", None)
    swaps = [row for row in value["rows"] if row["intervention"]["mode"] in
             ("pair_copy", "core_copy", "receiver_copy") and row["intervention"]["host"] in ("A", "B")]
    sufficiency = [row for row in value["rows"] if row["intervention"]["host"] in ("SHAM", "PLASTIC")]
    summary = value["summary"]
    summary.pop("a_b_pair_copy_follows_donor", None)
    summary.pop("a_b_any_local_swap_follows_donor", None)
    summary.pop("sham_or_plastic_implant_recreates_donor", None)
    summary["a_b_pair_copy_nearest_to_donor"] = all(
        row["nearest_template_is_donor"] for row in swaps if row["intervention"]["mode"] == "pair_copy")
    summary["a_b_any_local_swap_nearest_to_donor"] = any(row["nearest_template_is_donor"] for row in swaps)
    summary["sham_or_plastic_implant_nearest_to_donor"] = any(row["nearest_template_is_donor"] for row in sufficiency)
    summary["any_exact_donor_template_recreation"] = any(row["exact_donor_template_match"] for row in value["rows"])
    summary["template_proximity_is_not_recreation"] = True
    value.pop("content_sha256", None); value.pop("created_utc", None)
    value["label_correction"] = "Nearest-template classification is descriptive proximity only; no implanted response exactly recreated an intact donor template."
    write_json(path, seal(value))
    print(json.dumps({"output": str(path), "summary": value["summary"]}, indent=2))


if __name__ == "__main__":
    main()
