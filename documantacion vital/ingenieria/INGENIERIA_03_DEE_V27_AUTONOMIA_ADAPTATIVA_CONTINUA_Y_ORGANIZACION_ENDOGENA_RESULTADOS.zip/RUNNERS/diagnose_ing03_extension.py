#!/usr/bin/env python3
"""Classify every baseline ING03 artifact before extension work."""
from __future__ import annotations

import json
import sys
import zipfile
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json

OFFICIAL = ROOT / "INGENIERIA_03_DEE_V27_AUTONOMIA_ADAPTATIVA_CONTINUA_Y_ORGANIZACION_ENDOGENA_RESULTADOS.zip"
EXPECTED = "f367e80abd73b985b2ad6b4f23ef3bc4818356711bb591c43b74a1f5ff95bb47"
CAUSAL_FAILURES = {f"DISCOVERY/ING03_D{i:02d}_{name}.json" for i, name in [
    (4,"WRITER_GATE_SEARCH"),(5,"DELAYED_WRITER_GATE"),(10,"RECURRENT_COUNTER_READOUT"),(11,"READER_CLEANUP_SEARCH"),(12,"SEEDED_RECURRENT_READ_WRITE")
]}
PROVENANCE = {"ING03_PARENT_EVIDENCE_MAP.json","ING03_PARENT_MECHANISM_GRAPH.json","RUNTIME_ENVIRONMENT.json","FREEZE/ING03_APPARATUS_LOCK.json","FREEZE/ING03_FINAL_LOCK.json","FREEZE/ING03_FROZEN_PREDICTIONS.json","CHALLENGES/ING03_FRESH_HOLDOUT_CHALLENGES.json"}
VALID_POSITIVES = {"ING03_EXECUTIVE_VERDICT.md","ING03_ATTRACTOR_ATLAS.json","ING03_CAPACITY_SCALING.json","ING03_SHARED_MEMORY_INTERFERENCE.json","ING03_ORGANIZATION_ATLAS.json"}
VALID_NULLS = {"ING03_L4_CAUSAL_OBSTRUCTION.json","ING03_FAILURE_OBSTRUCTION_MAP.json","ING03_CONTINUOUS_ADAPTATION.json"}
REGENERATE = {"CLAIM_LEDGER.json","HOLDOUT_REGISTRY.json","CANARY_REGISTRY.json","ING03_ADVERSARIAL_REVIEW.md","ING03_FINAL_FRONTIER.md","ING03_EXECUTIVE_VERDICT.md","MANIFEST.json","HASHES.sha256","DELIVERY_VALIDATION.json","FINALIZATION_STATE.json"}


def classify(path):
    if path in CAUSAL_FAILURES: return "KEEP_CAUSAL_FAILURE"
    if path in PROVENANCE: return "KEEP_PROVENANCE"
    if path.startswith(("DISCOVERY/","MECHANISM_SELECTION/","ADVERSARIAL_CHALLENGE/","HOLDOUT/")): return "KEEP_PRIMARY_EVIDENCE"
    if path.startswith("RUNNERS/"): return "KEEP_REPRODUCTION"
    if path in REGENERATE: return "REGENERATE_SUPERSEDED_REPORT"
    if path in VALID_NULLS: return "KEEP_VALID_NULL"
    if path in VALID_POSITIVES: return "KEEP_VALID_POSITIVE"
    if path.endswith((".ndjson",".json",".md")): return "KEEP_METHODOLOGICAL_LESSON"
    return "KEEP_PROVENANCE"


def main():
    observed=sha256_file(OFFICIAL)
    if observed!=EXPECTED: raise RuntimeError(f"baseline mismatch: {observed}")
    with zipfile.ZipFile(OFFICIAL,"r") as zf:
        if zf.testzip() is not None: raise RuntimeError("baseline ZIP CRC failure")
        names=[n for n in zf.namelist() if not n.endswith("/")]
        rows=[]
        for name in sorted(names):
            info=zf.getinfo(name); rows.append({"path":name,"bytes":info.file_size,"sha256":__import__('hashlib').sha256(zf.read(name)).hexdigest(),"classification":classify(name),"reason":{
                "KEEP_PRIMARY_EVIDENCE":"decisive discovery/model-selection/adversarial/holdout telemetry",
                "KEEP_VALID_POSITIVE":"valid baseline positive result; preserve unless falsified",
                "KEEP_VALID_NULL":"valid bounded null/obstruction",
                "KEEP_CAUSAL_FAILURE":"failed construction with information about the read/write obstruction",
                "KEEP_METHODOLOGICAL_LESSON":"scientific synthesis/log that constrains extension decisions",
                "KEEP_REPRODUCTION":"runner or reproduction specification",
                "KEEP_PROVENANCE":"identity, freeze, challenge, or parent traceability",
                "REGENERATE_SUPERSEDED_REPORT":"must be regenerated after new science; old copy retained through baseline hash",
            }[classify(name)]})
    counts=Counter(r["classification"] for r in rows)
    payload=seal({"schema":"dee.v27.ing03.extension_diagnosis.v1","pre_extension_sha256":observed,"baseline_zip_bytes":OFFICIAL.stat().st_size,"baseline_zip_integrity":"PASS","baseline_file_count":len(rows),"classification_counts":dict(sorted(counts.items())),"files":rows,"deletion_before_diagnosis":False,"planned_policy":{"preserve_decisive_old_evidence":True,"preserve_D04_D05_D10_D11_D12":True,"embed_old_baseline_zip":False,"regenerate_reports_only_after_new_evidence":True}})
    write_json(ROOT/"ING03_EXTENSION_DIAGNOSIS.json",payload)
    lines=["# ING03 definitive-extension diagnosis","",f"- PRE_EXTENSION_SHA256: `{observed}`",f"- Baseline integrity: PASS",f"- Files classified: {len(rows)}","","## Classification totals",""]
    lines += [f"- {k}: {v}" for k,v in sorted(counts.items())]
    lines += ["","## Scientific decision","","No baseline artifact was deleted or modified before classification. D04, D05, D10, D11 and D12 are retained as causal failures because they establish that static blocking, late gate carriers, maintained readers, cleanup sources and non-zero seeded relations all constrain the same read/write interface. Existing positives remain valid. Final synthesis files will be regenerated only after the extension experiments; the old versions remain recoverable through the locked baseline ZIP hash.","","## Removal policy","","No scientific evidence is scheduled for removal. Only exact duplicates, cache, temporary staging, and superseded administrative validation may be omitted from the replacement package after their role is recorded."]
    (ROOT/"ING03_EXTENSION_DIAGNOSIS.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({"pre_extension_sha256":observed,"files":len(rows),"counts":dict(counts)},indent=2))


if __name__=="__main__": main()
