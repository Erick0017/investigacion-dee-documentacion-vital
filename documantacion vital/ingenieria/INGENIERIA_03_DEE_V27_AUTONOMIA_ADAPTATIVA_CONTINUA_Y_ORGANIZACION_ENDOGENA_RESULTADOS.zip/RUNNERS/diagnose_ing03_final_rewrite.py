#!/usr/bin/env python3
"""Forensic inventory and completeness audit before the final ING03 rewrite."""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, canonical_hash, seal, sha256_file, write_json

OFFICIAL = "INGENIERIA_03_DEE_V27_AUTONOMIA_ADAPTATIVA_CONTINUA_Y_ORGANIZACION_ENDOGENA_RESULTADOS.zip"
EXPECTED = "593688182f1a0e46b89071e519b40eb2805f365112032bb4aa51a3eb8abadf9b"


def classify(name: str) -> tuple[str, str]:
    if name.startswith(("HOLDOUT/", "MECHANISM_SELECTION/", "ADVERSARIAL_CHALLENGE/")):
        return "KEEP_PRIMARY_EVIDENCE", "decisive validation/model-selection/adversarial telemetry"
    if name.startswith("DISCOVERY/"):
        if "D19_" in name:
            return "KEEP_METHODOLOGICAL_LESSON", "invalid distant-pair reader geometry constrained the corrected D21 design"
        if any(tag in name for tag in ("D04_", "D05_", "D10_", "D11_", "D12_", "EXT_D17_", "EXT_D18_", "EXT_D20_", "EXT_D22_", "EXT_D23_")):
            return "KEEP_CAUSAL_FAILURE", "meaningful negative evidence constraining read/write constructions"
        if "D21_" in name:
            return "KEEP_VALID_POSITIVE", "locality: reading one organ does not globally suppress a separate plastic organ"
        return "KEEP_PRIMARY_EVIDENCE", "scientific discovery telemetry"
    if name.startswith(("FREEZE/", "CHALLENGES/", "PROVENANCE/")) or name in {"RUNTIME_ENVIRONMENT.json", "ING03_PARENT_EVIDENCE_MAP.json"}:
        return "KEEP_PROVENANCE", "identity/freeze/fresh-world/provenance record"
    if name.startswith("RUNNERS/"):
        if any(token in name for token in ("build_ing03_package.py", "build_ing03_extension_package.py", "validate_ing03_package.py", "validate_ing03_extension_package.py", "build_ing03_scientific_outputs.py", "build_ing03_extension_outputs.py", "diagnose_ing03_extension.py")):
            return "DROP_ADMINISTRATIVE", "superseded package/report administration; not needed to reproduce scientific experiments"
        return "KEEP_REPRODUCTION", "scientific runner or frozen apparatus required for reproduction"
    if name in {"MANIFEST.json", "HASHES.sha256", "DELIVERY_VALIDATION.json", "FINALIZATION_STATE.json"}:
        return "REGENERATE_SUPERSEDED", "must describe the completed superseding edition"
    if name.endswith((".md", ".json", ".ndjson")):
        return "REGENERATE_SUPERSEDED", "scientific synthesis/registry/log will be updated while preserving prior claims and references"
    return "KEEP_PROVENANCE", "unclassified payload retained conservatively"


def main():
    package = ROOT / OFFICIAL
    observed = sha256_file(package)
    if observed != EXPECTED:
        raise RuntimeError(f"baseline SHA mismatch: {observed}")
    files = []
    with zipfile.ZipFile(package, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"baseline CRC failure: {bad}")
        for info in sorted(archive.infolist(), key=lambda item: item.filename):
            data = archive.read(info.filename)
            category, reason = classify(info.filename)
            files.append({
                "path": info.filename,
                "bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
                "classification": category,
                "reason": reason,
            })
    counts = Counter(item["classification"] for item in files)
    diagnosis = seal({
        "schema": "dee.v27.ing03.final_rewrite_diagnosis.v1",
        "pre_rewrite_sha256": observed,
        "baseline_zip_bytes": package.stat().st_size,
        "baseline_zip_integrity": "PASS",
        "baseline_file_count": len(files),
        "deletion_before_diagnosis": False,
        "classification_counts": dict(sorted(counts.items())),
        "classification_policy": "No artifact was removed before this inventory. Informative failures and all decisive raw evidence are retained.",
        "files": files,
        "initial_scientific_diagnosis": {
            "valid_science_preserved": [
                "recurrent relational writer and multilevel delta",
                "persistent source behavior",
                "bounded functional sign attractor/recovery",
                "five-class answer-independent reader",
                "configured fan-out and shared-source interference",
                "fresh-confirmed finite-probe information/plasticity trade-off",
                "locality of blocking and separate-organ plasticity",
            ],
            "central_incompleteness": "The extension bounded local finite probes but did not construct the intended recurrent bridge, native buffer, true dynamic phase switch, consequence-triggered release, or full high-s_reg response map.",
            "deletion_plan": "Only superseded administrative builders/reports, exact duplicates, cache, and zero-information artifacts may be omitted after final classification.",
        },
        "post_rewrite_sha256": "recorded after atomic publication; embedding an archive's own hash is self-referential",
    })
    write_json(ROOT / "ING03_FINAL_REWRITE_DIAGNOSIS.json", diagnosis)

    counts_md = "\n".join(f"- `{key}`: {value}" for key, value in sorted(counts.items()))
    (ROOT / "ING03_FINAL_REWRITE_DIAGNOSIS.md").write_text(
        "# ING03 final rewrite diagnosis\n\n"
        f"The current official archive was verified before any deletion: `{observed}`; {len(files)} files; CRC PASS.\n\n"
        "## Classification\n\n" + counts_md + "\n\n"
        "All decisive evidence, meaningful nulls, D04/D05/D10/D11/D12, the extension finite-probe result, and D21 locality evidence are retained. "
        "The prior campaign did not exhaust the intended mechanisms merely by naming them: dynamic interface release, a recurrent plastic-master→executor bridge, native consequence buffering, true offline consolidation, and the high-s_reg regime were incomplete. "
        "No file was removed before this diagnosis.\n",
        encoding="utf-8",
    )

    completeness = seal({
        "schema": "dee.v27.ing03.experiment_completeness_audit.v1",
        "pre_rewrite_sha256": observed,
        "allowed_status": ["TESTED_AS_INTENDED", "PARTIALLY_TESTED", "PREREQUISITE_NOT_CONSTRUCTED", "TESTED_DIFFERENT_MECHANISM", "NOT_TESTED"],
        "fronts": [
            {"front": "local finite trajectory probes", "status": "TESTED_AS_INTENDED", "evidence": ["D17", "D24", "H02"], "gap": "claim is deliberately bounded; different trajectory organizations remain open"},
            {"front": "true phase-multiplexed reader", "status": "PARTIALLY_TESTED", "evidence": ["D20"], "gap": "static phase sweep did not construct reader present→absent→present dynamics"},
            {"front": "consequence-triggered refractory release", "status": "TESTED_DIFFERENT_MECHANISM", "evidence": ["D23"], "gap": "finite collision cleanup was tested; consequence branching and native reader return were not constructed"},
            {"front": "separated plastic master and executor", "status": "PARTIALLY_TESTED", "evidence": ["D21"], "gap": "locality was established but the native recurrent update bridge was absent"},
            {"front": "high-s_reg modulation", "status": "PARTIALLY_TESTED", "evidence": ["D20"], "gap": "only s_reg 0..32 was mapped; legal 16-bit high/saturation regimes were not tested"},
            {"front": "native consequence buffer", "status": "NOT_TESTED", "evidence": [], "gap": "D22 delayed an injected writer but did not store and later release a consequence"},
            {"front": "offline consolidation", "status": "PREREQUISITE_NOT_CONSTRUCTED", "evidence": ["D22"], "gap": "no native buffer and no endogenous mode switch"},
            {"front": "copy-before-consume", "status": "PARTIALLY_TESTED", "evidence": ["D17", "D18"], "gap": "finite probes and writer emissions were tested; no parent transfer/reinstantiation bridge was implemented"},
            {"front": "first-passage/latency/route nonoccupying readout", "status": "NOT_TESTED", "evidence": [], "gap": "D17 recorded finite probe trajectories but did not build a distinct remote first-passage organization"},
        ],
        "conclusion": "The latest bounded null is valid additional knowledge, not completion of every named family.",
    })
    write_json(ROOT / "ING03_EXPERIMENT_COMPLETENESS_AUDIT.json", completeness)
    print(json.dumps({"baseline_sha256": observed, "files": len(files), "classification_counts": dict(counts), "diagnosis_written": True}, indent=2))


if __name__ == "__main__":
    main()
