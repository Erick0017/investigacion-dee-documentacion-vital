#!/usr/bin/env python3
"""Reseal validated delivery/finalization status inside the official archive."""
from __future__ import annotations

import json
import os
import shutil
import sys
import uuid
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, canonical_hash, sha256_file, utc, write_json
from validate_cce_package import OFFICIAL, validate_archive


def main():
    official = ROOT / OFFICIAL
    before = validate_archive(official)
    if not before["overall_pass"]: raise RuntimeError(json.dumps(before, indent=2))
    stage_root = (ROOT / "PACKAGE_STAGE").resolve(); delivery_root = (ROOT / "DELIVERY_STAGE").resolve()
    stage_root.mkdir(exist_ok=True); delivery_root.mkdir(exist_ok=True)
    stage = stage_root / f"ing03_cce_final_{uuid.uuid4().hex}"; stage.mkdir()
    with zipfile.ZipFile(official) as archive: archive.extractall(stage)
    internal = {"zip_crc": "PASS", "internal_hashes": "PASS", "manifest": "PASS",
                "kernel_identity": "PASS", "parent_provenance": "PASS",
                "claim_evidence": "PASS", "compaction": "PASS", "no_ing04": "PASS"}
    write_json(stage / "DELIVERY_VALIDATION.json", {
        "schema": "dee.v27.ing03.cce.delivery.v1", "validated_utc": utc(),
        "status": "SEALED_PAYLOAD_VALIDATED", "external_sha256": "reported outside archive to avoid self-reference",
        "archive_members": before["member_count"], "checks": internal, "overall_pass": True,
    })
    write_json(stage / "FINALIZATION_STATE.json", {
        "schema": "dee.v27.ing03.cce.finalization.v1", "created_utc": utc(),
        "status": "CCE26_33_CHECKPOINT_VALIDATED_ING03_OPEN", "highest_rw": "RW2",
        "rw3": False, "rw4": False, "rw5": False, "l4": False,
        "ingenieria_03_open": True, "campaign_complete": False,
        "incomplete_experiment_excluded": "CCE34_NATIVE_B_PHASE_DELAY_ATLAS",
        "official_filename": OFFICIAL,
    })
    manifest = json.loads((stage / "MANIFEST.json").read_text(encoding="utf-8"))
    entries = []
    old_roles = {row["path"]: row.get("role", "scientific_report_or_registry") for row in manifest.get("files", [])}
    for path in sorted(stage.rglob("*")):
        if path.is_file() and path.name not in {"MANIFEST.json", "HASHES.sha256"}:
            rel = path.relative_to(stage).as_posix()
            entries.append({"path": rel, "sha256": sha256_file(path), "bytes": path.stat().st_size,
                            "role": old_roles.get(rel, "scientific_report_or_registry")})
    manifest["created_utc"] = utc(); manifest["files"] = entries; manifest["payload_file_count"] = len(entries)
    manifest["archive_member_count"] = len(entries) + 2
    manifest.pop("content_sha256", None); manifest["content_sha256"] = canonical_hash(manifest)
    write_json(stage / "MANIFEST.json", manifest)
    hashes = entries + [{"path": "MANIFEST.json", "sha256": sha256_file(stage / "MANIFEST.json")}]
    (stage / "HASHES.sha256").write_text("".join(f"{row['sha256']}  {row['path']}\n" for row in sorted(hashes, key=lambda x: x["path"])), encoding="utf-8")
    candidate = delivery_root / f"{OFFICIAL}.{uuid.uuid4().hex}.tmp"
    with zipfile.ZipFile(candidate, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True) as archive:
        for path in sorted(stage.rglob("*")):
            if path.is_file(): archive.write(path, path.relative_to(stage).as_posix())
    after = validate_archive(candidate)
    if not after["overall_pass"]: raise RuntimeError(json.dumps(after, indent=2))
    os.replace(candidate, official)
    final = validate_archive(official)
    if not final["overall_pass"]: raise RuntimeError(json.dumps(final, indent=2))
    for name in ("MANIFEST.json", "HASHES.sha256", "DELIVERY_VALIDATION.json", "FINALIZATION_STATE.json"):
        shutil.copy2(stage / name, ROOT / name)
    if stage.parent != stage_root or not stage.name.startswith("ing03_cce_final_"): raise RuntimeError("unsafe cleanup")
    shutil.rmtree(stage)
    print(json.dumps({"official": str(official), "sha256": sha256_file(official), "bytes": official.stat().st_size,
                      "members": final["member_count"], "validation": final}, indent=2, ensure_ascii=False))


if __name__ == "__main__": main()
