#!/usr/bin/env python3
"""Freeze the configured recurrent messenger transducer before fresh tests."""
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,sha256_file,write_json

def main():
    apparatus=ROOT/"RUNNERS/run_deep_d57_reusable_spatial_executor.py"
    selection=ROOT/"MECHANISM_SELECTION/ING03_DEEP_D62_RECURRENT_TRANSDUCER_SELECTION.json"
    lock=seal({
        "schema":"dee.v27.ing03.deep.freeze.recurrent_transducer.v1",
        "status":"FROZEN_BEFORE_FRESH_GENERATION",
        "promoted_capability":"CONFIGURED_RECURRENT_MESSAGE_TRANSDUCTION_WITH_LATER_MASTER_WRITES",
        "explicit_nonclaims":["consequence-selected policy","master readout","RW2","L4"],
        "apparatus":{"path":"RUNNERS/run_deep_d57_reusable_spatial_executor.py","sha256":sha256_file(apparatus)},
        "selection":{"path":"MECHANISM_SELECTION/ING03_DEEP_D62_RECURRENT_TRANSDUCER_SELECTION.json","sha256":sha256_file(selection)},
        "fixed":{"horizon":1024,"master_phase":255,"generator_distance":3,"messenger_direction":[0,0,1],"transducer_direction":[0,1,-1],"action_direction":[0,1,0],"source_semantic":4,"source_sreg":6,"fresh_groups":8},
        "predictions":{"first_action_law":"1+3+port_offset+action_offset","action_period":2,"action_count_law":"floor((1024-first_action)/2)+1","post_action_master_transitions":6,"original_message_after_port":0,"sources_fixed":True,"no_sink":"no transverse action; original continues","missing_or_wrong_proposal":"no master transition and no transverse action"},
        "pass_criterion":"All 8 fresh groups pass both target lanes and three causal controls; no case discarded.",
        "python_interventions_after_t0":0,
    })
    out=ROOT/"FREEZE/ING03_DEEP_RECURRENT_TRANSDUCER_LOCK.json";write_json(out,lock)
    print(json.dumps({"output":str(out),"apparatus_sha256":lock["apparatus"]["sha256"],"content_sha256":lock["content_sha256"]},indent=2))
if __name__=="__main__":main()
