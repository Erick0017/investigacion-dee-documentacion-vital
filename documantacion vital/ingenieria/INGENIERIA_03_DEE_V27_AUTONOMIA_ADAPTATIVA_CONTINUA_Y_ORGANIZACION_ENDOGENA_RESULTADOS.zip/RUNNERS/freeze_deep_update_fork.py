#!/usr/bin/env python3
"""Freeze the promoted update-fork primitive before fresh challenge generation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    apparatus = ROOT / "RUNNERS/run_deep_d58_counterfactual_update_fork.py"
    model = ROOT / "MECHANISM_SELECTION/ING03_DEEP_D59_UPDATE_FORK_MODEL_SELECTION.json"
    adversarial = ROOT / "ADVERSARIAL_CHALLENGE/ING03_DEEP_D60_SPATIAL_ADVERSARIAL.json"
    lock = seal({
        "schema": "dee.v27.ing03.deep.freeze.update_fork.v1",
        "status": "FROZEN_BEFORE_FRESH_GENERATION",
        "promoted_capability": "UPDATE_EVENT_COMMON_CAUSE_FORK_WITH_REMOTE_REUSABLE_TRANSDUCTION",
        "explicit_nonclaims": ["master-mediated readout", "RW3", "RW4", "RW5", "L4", "continuous adaptation"],
        "apparatus": {"path": "RUNNERS/run_deep_d58_counterfactual_update_fork.py", "sha256": sha256_file(apparatus)},
        "selection_evidence": [
            {"path": "MECHANISM_SELECTION/ING03_DEEP_D59_UPDATE_FORK_MODEL_SELECTION.json", "sha256": sha256_file(model)},
            {"path": "ADVERSARIAL_CHALLENGE/ING03_DEEP_D60_SPATIAL_ADVERSARIAL.json", "sha256": sha256_file(adversarial)},
        ],
        "frozen_parameters": {
            "generator_to_event_distance": 3,
            "master_phase": 255,
            "master_support": [[-1, 0, 0], [0, 1, 0], [0, 0, 1], [-1, 1, 1]],
            "messenger_route_normalized": [0, 0, 1],
            "transducer_source_direction_normalized": [0, 1, -1],
            "action_direction_normalized": [0, 1, 0],
            "transducer_semantic": 4,
            "transducer_sreg": 6,
            "horizon": 64,
            "fresh_pair_count": 12,
        },
        "frozen_predictions": {
            "pair_learner_hashes_equal": True,
            "pair_environment_hashes_differ": True,
            "first_write_tick": 6,
            "target_a_terminal_delta": 1,
            "target_b_terminal_delta": -1,
            "first_action_law": "1 + 3 + port_offset + action_offset",
            "target_action_only": True,
            "no_consequence": "no write and no action",
            "no_transducer": "write remains, action absent",
            "no_master": "write absent, action unchanged",
            "shifted_transducer": "write remains, action absent",
        },
        "fresh_parameter_domain": {
            "n": [59, 61, 67, 71, 73, 79, 83],
            "port_offset": [4, 7, 10, 13, 16],
            "action_offset": [2, 4, 5, 7, 9],
            "permutations": "all six axis permutations",
            "signs": "all signed frames sampled by frozen seed generator",
            "origin": "uniform toroidal coordinates from frozen seed generator",
        },
        "pass_criterion": "All 12 pairs satisfy frozen treatment predictions and all four causal controls satisfy their frozen predictions; no case may be discarded.",
        "python_role": "construct t0 from frozen specs, tick, census both action ports, hash learner/environment, score frozen predictions",
        "python_forbidden": ["choose action", "rewrite master", "create messenger after t0", "route after t0", "repair", "replenish", "discard fresh failure"],
    })
    output = ROOT / "FREEZE/ING03_DEEP_UPDATE_FORK_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "apparatus_sha256": lock["apparatus"]["sha256"], "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
