#!/usr/bin/env python3
"""Freeze the clean-port distributed-regime claim before fresh frames exist."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_distributed_d05_regime_separability_holdout as d05


D02_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D02_CLEAN_PORT_GENERALIZATION.json"
D03_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json"
D04_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D04_REGIME_CLASSIFICATION.json"
OUTPUT = ROOT / "FREEZE/ING03_DR_D05_REGIME_SEPARABILITY_LOCK.json"


def main():
    if OUTPUT.exists():
        raise RuntimeError(f"refusing to overwrite existing lock: {OUTPUT}")
    d02 = json.loads(D02_PATH.read_text(encoding="utf-8"))
    selected = d02["rows"][0]
    architecture = {
        "n": 41, "memory_phase": 252, "consequence_distance": 6,
        "bridge_source_distance": 24, "receiver_relative_offset": [-6, 7, 8],
        "maturation_tick": 184, "followup_ticks": 64,
        "probe_event_offset": [0, -1, 0], "probe_direction": [-1, -1, 1],
        "probe_distance": 10, "probe_state": 42000, "probe_s_reg": 0,
        "probe_semantic": 4,
    }
    expected = selected["responses"]
    kernel, runtime = load_kernel(1)
    identity = ((0, 1, 2), (1, 1, 1))
    reproduction = {condition: d05.run_case(kernel, identity, condition, architecture)
                    for condition in d05.CONDITIONS}
    checks = {}
    for condition in d05.CONDITIONS:
        checks[condition] = {
            "valid_and_clean": reproduction[condition].get("valid") and reproduction[condition].get("port_raw") == 0,
            "counts_exact": reproduction[condition].get("counts") == expected[condition]["counts"],
            "mask_hash_exact": reproduction[condition].get("canonical_response_mask_sequence_sha256") ==
                               expected[condition]["response_mask_sequence_sha256"],
            "ever_exact": reproduction[condition].get("ever_affected_positions") == expected[condition]["ever_affected_positions"],
        }
    if not all(all(row.values()) for row in checks.values()):
        raise RuntimeError(f"identity reconstruction failed: {checks}")
    lock = seal({
        "schema": "dee.v27.ing03.distributed_regime.d05_lock.v1",
        "lock_id": "ING03-DR-D05-CLEAN-PORT-SEPARABILITY-V1",
        "claim_scope": "An identical diagnostic clean-port perturbation elicits history-conditioned A/B/SHAM distributed causal response regimes whose frozen lossless response sequences generalize across fresh signed/permuted frames. This is not a wave, field, native decoder, function, adaptation, or RW3.",
        "conditions": list(d05.CONDITIONS), "architecture": architecture,
        "expected_identity_response": {condition: {
            "counts": expected[condition]["counts"],
            "ever_affected_positions": expected[condition]["ever_affected_positions"],
            "maximum_changed": expected[condition]["maximum_changed"],
            "terminal_changed": expected[condition]["terminal_changed"],
            "response_mask_sequence_sha256": expected[condition]["response_mask_sequence_sha256"],
        } for condition in d05.CONDITIONS},
        "identity_reproduction_checks": checks,
        "success_criteria": {
            "fresh_frames": 8, "conditions_per_frame": 4, "probe_port_empty_in_every_world": True,
            "exact_frozen_count_sequence_every_condition": True,
            "exact_canonical_lossless_mask_hash_every_condition": True,
            "a_b_sham_pairwise_distinct_every_frame": True,
            "remote_pair_effect": False, "probe_specific_write": False,
            "post_t0_interventions_per_world": 1, "post_freeze_tuning": False,
        },
        "fresh_generation": {
            "algorithm": "sha256-sort unused nonidentity signed/permuted 3D frames after excluding every prior challenge registry",
            "fresh_frames": 8, "salt": "ING03-DR-D05-CLEAN-PORT-FRESH-2026-09-22",
            "outcomes_absent_at_lock": True,
        },
        "evidence": [{"path": path.relative_to(ROOT).as_posix(), "sha256": sha256_file(path)}
                     for path in (D02_PATH, D03_PATH, D04_PATH)],
        "planning": {"estimated_runtime_minutes": 4, "worlds": 32, "ticks_per_world": 248,
                     "estimated_storage_mb": 1,
                     "scientific_information_gain": "tests whether the clean-port A/B/SHAM distinction is a frame-invariant history-conditioned regime rather than an identity-frame artifact"},
        "runtime_at_lock": runtime,
    })
    write_json(OUTPUT, lock)
    print(json.dumps({"output": str(OUTPUT), "identity_reproduction_checks": checks,
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
