#!/usr/bin/env python3
"""Freeze the D07 sparse shell and treatment-control metrics before fresh use."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_distributed_d08_t0_shell_holdout as d08


D05_LOCK = ROOT / "FREEZE/ING03_DR_D05_REGIME_SEPARABILITY_LOCK.json"
D07_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D07_T0_EFFECTOR_GEOMETRIES.json"
OUTPUT = ROOT / "FREEZE/ING03_DR_D08_T0_SHELL_LOCK.json"


def main():
    if OUTPUT.exists():
        raise RuntimeError(f"refusing to overwrite existing lock: {OUTPUT}")
    parent = json.loads(D05_LOCK.read_text(encoding="utf-8"))
    discovery = json.loads(D07_PATH.read_text(encoding="utf-8"))
    shell = next(row for row in discovery["rows"] if row["family"] == "SPARSE_SHELL_6")
    c = parent["architecture"]["n"] // 2
    offsets = [[int((q[i] - c + parent["architecture"]["n"] // 2) % parent["architecture"]["n"] -
                    parent["architecture"]["n"] // 2) for i in range(3)] for q in shell["centers"]]
    architecture = dict(parent["architecture"])
    architecture["shell_center_offsets"] = offsets
    kernel, runtime = load_kernel(1)
    identity = ((0, 1, 2), (1, 1, 1))
    rows = {condition: d08.run_case(kernel, identity, condition, architecture) for condition in d08.CONDITIONS}
    if not all(row.get("valid") for row in rows.values()):
        raise RuntimeError(f"identity reconstruction invalid: {rows}")
    if not (rows["A"]["pairs_ever_probe_responsive"] == 2 and
            all(rows[name]["pairs_ever_probe_responsive"] == 0 for name in ("B", "SHAM", "PLASTIC")) and
            rows["A"]["maximum_exterior_interaction_residue"] == 1431 and
            rows["B"]["maximum_exterior_interaction_residue"] == 11 and
            rows["SHAM"]["maximum_exterior_interaction_residue"] == 0 and
            rows["PLASTIC"]["maximum_exterior_interaction_residue"] == 0):
        raise RuntimeError("corrected differential metrics do not reproduce D07 shell")
    fields = ("pairs_ever_probe_responsive", "responsive_pair_indices", "pair_differential_sequence_sha256",
              "response_count_sequence", "interaction_count_sequence", "exterior_interaction_count_sequence",
              "canonical_response_mask_sequence_sha256", "canonical_interaction_mask_sequence_sha256",
              "pre_probe_master_delta", "terminal_master_delta")
    expected = {condition: {field: rows[condition][field] for field in fields} for condition in d08.CONDITIONS}
    remaining = 48 - len(d08.prior_frames() | {identity})
    if remaining != 4:
        raise RuntimeError(f"fresh frame census changed before freeze: {remaining}")
    lock = seal({
        "schema": "dee.v27.ing03.distributed_regime.d08_lock.v1",
        "lock_id": "ING03-DR-D08-T0-SPARSE-SHELL-V1",
        "claim_scope": "A t0-complete six-transducer sparse shell physically distinguishes the diagnostic A-history distributed response from B/SHAM/PLASTIC through treatment-control pair changes and nonlocal interaction residue across all remaining never-used signed/permuted frames. The late probe is diagnostic; this is not an autonomous effector, RW3, or L4.",
        "conditions": list(d08.CONDITIONS), "architecture": architecture,
        "expected_identity_response": expected,
        "success_criteria": {"all_remaining_never_used_frames": 4, "all_conditions_valid": True,
                             "exact_frozen_differential_sequences": True,
                             "exact_canonical_response_and_interaction_masks": True,
                             "a_responsive_pairs": 2, "b_sham_plastic_responsive_pairs": 0,
                             "a_maximum_exterior_residue": 1431, "b_maximum_exterior_residue": 11,
                             "sham_plastic_maximum_exterior_residue": 0,
                             "post_t0_interventions_per_treatment_world": 1, "post_freeze_tuning": False},
        "fresh_generation": {"algorithm": "use every nonidentity signed/permuted frame absent from all earlier challenge registries",
                             "fresh_frames": 4, "salt": "ING03-DR-D08-T0-SHELL-2026-09-22",
                             "outcomes_absent_at_lock": True},
        "evidence": [{"path": path.relative_to(ROOT).as_posix(), "sha256": sha256_file(path)}
                     for path in (D05_LOCK, D07_PATH)],
        "planning": {"estimated_runtime_minutes": 5, "condition_groups": 16,
                     "kernel_worlds_per_group": 4, "ticks_per_world": 248, "estimated_storage_mb": 2,
                     "scientific_information_gain": "separates passive exposure from frame-invariant physical transduction by a t0-complete spatial organization"},
        "runtime_at_lock": runtime,
    })
    write_json(OUTPUT, lock)
    print(json.dumps({"output": str(OUTPUT), "fresh_frame_census": remaining,
                      "identity_summary": {name: {"responsive_pairs": rows[name]["pairs_ever_probe_responsive"],
                                                   "maximum_exterior_residue": rows[name]["maximum_exterior_interaction_residue"]}
                                           for name in d08.CONDITIONS},
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
