#!/usr/bin/env python3
"""Freeze the simplest phase-invariant native t0 trajectory architecture."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_distributed_d10_native_trajectory_holdout as d10


D08_LOCK = ROOT / "FREEZE/ING03_DR_D08_T0_SHELL_LOCK.json"
D09_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D09_NATIVE_T0_STIMULUS_SEARCH.json"
OUTPUT = ROOT / "FREEZE/ING03_DR_D10_NATIVE_TRAJECTORY_LOCK.json"


def main():
    if OUTPUT.exists():
        raise RuntimeError(f"refusing to overwrite existing lock: {OUTPUT}")
    parent = json.loads(D08_LOCK.read_text(encoding="utf-8"))
    discovery = json.loads(D09_PATH.read_text(encoding="utf-8"))
    architecture = dict(parent["architecture"])
    architecture.update({"native_source_distance": 10, "native_source_clock": 0, "horizon": 256})
    kernel, runtime = load_kernel(1)
    identity = ((0, 1, 2), (1, 1, 1)); zero_shift = (0, 0, 0)
    rows = {condition: d10.run_case(kernel, identity, zero_shift, condition, architecture)
            for condition in d10.CONDITIONS}
    if not all(row.get("valid") and row.get("source_persistent_raw") for row in rows.values()):
        raise RuntimeError("identity native trajectory reconstruction invalid")
    if not (rows["A"]["terminal_treatment_delta"] == 1 and rows["B"]["terminal_treatment_delta"] == -1 and
            rows["SHAM"]["terminal_treatment_delta"] == 0 and rows["PLASTIC"]["terminal_treatment_delta"] == 0 and
            rows["A"]["first_pair_response_tick"] == 138 and rows["B"]["first_pair_response_tick"] == 125 and
            rows["SHAM"]["first_pair_response_tick"] is None and rows["PLASTIC"]["first_pair_response_tick"] is None):
        raise RuntimeError("identity native trajectory does not reproduce selected D09 candidate")
    fields = ("terminal_treatment_delta", "terminal_control_delta", "first_pair_response_tick",
              "pairs_ever_source_responsive", "responsive_pair_indices", "pair_differential_sequence_sha256",
              "pair_response_count_sequence", "world_response_count_sequence",
              "canonical_world_response_mask_sequence_sha256")
    expected = {condition: {field: rows[condition][field] for field in fields} for condition in d10.CONDITIONS}
    lock = seal({
        "schema": "dee.v27.ing03.distributed_regime.d10_lock.v1",
        "lock_id": "ING03-DR-D10-NATIVE-HISTORY-CONDITIONED-TRAJECTORY-V1",
        "claim_scope": "A fixed answer-neutral t0 source and t0-complete sparse shell produce three native history-conditioned causal trajectories: B response from tick125, A from tick138, SHAM/PLASTIC absent through tick256, while native stored signs remain intact and Python performs only ticking/logging/stopping. This demonstrates one learned-history-to-function pathway, not recurrent learning or RW3.",
        "conditions": list(d10.CONDITIONS), "architecture": architecture,
        "expected_identity_response": expected,
        "success_criteria": {"fresh_frame_origin_pairs": 8, "all_conditions_valid": True,
                             "exact_frozen_pair_and_world_trajectories": True,
                             "a_first_response_tick": 138, "b_first_response_tick": 125,
                             "sham_plastic_no_response_through_tick": 256,
                             "a_terminal_delta": 1, "b_terminal_delta": -1,
                             "source_persistent": True, "python_interventions_after_t0": 0,
                             "post_freeze_tuning": False},
        "fresh_generation": {"algorithm": "sha256-sort signed/permuted frames crossed with nonzero toroidal translations",
                             "challenge_pairs": 8, "salt": "ING03-DR-D10-NATIVE-TRAJECTORY-2026-09-22",
                             "outcomes_absent_at_lock": True},
        "phase_independence_discovery": {"distance10_clocks_tested": [0, 64, 128, 184, 252],
                                         "identical_first_response_ticks": {"A": 138, "B": 125}},
        "evidence": [{"path": path.relative_to(ROOT).as_posix(), "sha256": sha256_file(path)}
                     for path in (D08_LOCK, D09_PATH)],
        "planning": {"estimated_runtime_minutes": 6, "challenge_pairs": 8, "conditions_per_pair": 4,
                     "kernel_worlds_per_condition": 2, "ticks_per_world": 256, "estimated_storage_mb": 3,
                     "scientific_information_gain": "tests whether a no-host learned-history-to-collective-trajectory function is invariant to frame and origin"},
        "runtime_at_lock": runtime,
    })
    write_json(OUTPUT, lock)
    print(json.dumps({"output": str(OUTPUT),
                      "identity_summary": {name: {"first_response": rows[name]["first_pair_response_tick"],
                                                   "responsive_pairs": rows[name]["pairs_ever_source_responsive"],
                                                   "terminal_delta": rows[name]["terminal_treatment_delta"]}
                                           for name in d10.CONDITIONS},
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
