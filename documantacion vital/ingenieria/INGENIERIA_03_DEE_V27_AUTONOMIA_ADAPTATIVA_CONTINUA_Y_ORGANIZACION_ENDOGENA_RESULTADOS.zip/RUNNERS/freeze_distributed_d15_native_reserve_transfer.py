#!/usr/bin/env python3
"""Freeze the minimal no-shell A-history-to-reserve transfer architecture."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15


D10_LOCK = ROOT / "FREEZE/ING03_DR_D10_NATIVE_TRAJECTORY_LOCK.json"
D14_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D14_NATIVE_STATE_TRANSFER_CONTROLS.json"
OUTPUT = ROOT / "FREEZE/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_LOCK.json"


def main():
    if OUTPUT.exists(): raise RuntimeError(f"refusing to overwrite {OUTPUT}")
    parent = json.loads(D10_LOCK.read_text(encoding="utf-8"))
    architecture = dict(parent["architecture"])
    architecture.update({"reserve_center_offset": [20, -20, -19], "horizon": 256})
    kernel, runtime = load_kernel(1); identity = ((0, 1, 2), (1, 1, 1)); zero = (0, 0, 0)
    rows = {condition: d15.run_case(kernel, identity, zero, condition, architecture) for condition in d15.CONDITIONS}
    if not all(row.get("valid") and row.get("source_persistent_raw") for row in rows.values()):
        raise RuntimeError("identity transfer reconstruction invalid")
    if not (rows["A"]["primary_terminal_treatment"] == 1 and rows["A"]["reserve_terminal_treatment"] == -1 and
            rows["A"]["reserve_treatment_transitions"] == [{"tick": 140, "before": 0, "after": -1}] and
            all(rows[name]["reserve_terminal_treatment"] == 0 and not rows[name]["reserve_treatment_transitions"]
                for name in ("B", "SHAM", "PLASTIC"))):
        raise RuntimeError("minimal transfer response does not reproduce discovery")
    fields = ("primary_treatment_transitions", "primary_control_transitions",
              "reserve_treatment_transitions", "reserve_control_transitions",
              "primary_terminal_treatment", "primary_terminal_control",
              "reserve_terminal_treatment", "reserve_terminal_control",
              "world_response_count_sequence", "canonical_world_response_mask_sequence_sha256")
    expected = {condition: {field: rows[condition][field] for field in fields} for condition in d15.CONDITIONS}
    lock = seal({"schema": "dee.v27.ing03.distributed_regime.d15_lock.v1",
                 "lock_id": "ING03-DR-D15-NATIVE-A-HISTORY-RESERVE-TRANSFER-V1",
                 "claim_scope": "In a t0-complete no-shell architecture, native A learning at tick9 plus an answer-neutral persistent source causes a spatially separate x-frame relational reserve to acquire retained state -1 at tick140; B/SHAM/PLASTIC controls remain reserve-neutral through tick256. This is learned-history-dependent native transfer, not a later independent experience, recurrent function, or RW3.",
                 "conditions": list(d15.CONDITIONS), "architecture": architecture,
                 "expected_identity_response": expected,
                 "success_criteria": {"fresh_frame_origin_pairs": 8, "exact_frozen_trajectories": True,
                                      "a_primary_transition": {"tick": 9, "after": 1},
                                      "a_reserve_transition": {"tick": 140, "after": -1},
                                      "b_sham_plastic_reserve_neutral": True,
                                      "python_interventions_after_t0": 0, "post_freeze_tuning": False},
                 "fresh_generation": {"algorithm": "sha256-sort signed/permuted frames crossed with nonzero toroidal translations",
                                      "challenge_pairs": 8, "salt": "ING03-DR-D15-NATIVE-RESERVE-TRANSFER-2026-09-22",
                                      "outcomes_absent_at_lock": True},
                 "evidence": [{"path": path.relative_to(ROOT).as_posix(), "sha256": sha256_file(path)}
                              for path in (D10_LOCK, D14_PATH)],
                 "planning": {"estimated_runtime_minutes": 6, "challenge_pairs": 8, "conditions_per_pair": 4,
                              "kernel_worlds_per_condition": 2, "ticks_per_world": 256, "estimated_storage_mb": 3,
                              "scientific_information_gain": "tests whether the first native cross-organization retained-state transfer is a frame/origin invariant rather than an identity-placement accident"},
                 "runtime_at_lock": runtime})
    write_json(OUTPUT, lock)
    print(json.dumps({"output": str(OUTPUT),
                      "identity_summary": {name: {"primary": rows[name]["primary_terminal_treatment"],
                                                   "reserve": rows[name]["reserve_terminal_treatment"],
                                                   "reserve_transitions": rows[name]["reserve_treatment_transitions"]}
                                           for name in d15.CONDITIONS},
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
