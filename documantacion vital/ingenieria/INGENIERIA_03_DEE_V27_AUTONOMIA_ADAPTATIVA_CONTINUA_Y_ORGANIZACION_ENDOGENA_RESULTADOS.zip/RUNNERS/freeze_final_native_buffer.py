#!/usr/bin/env python3
"""Freeze the selected D32/D35 native consequence-buffer family before fresh worlds."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json


def main():
    apparatus = ROOT / "RUNNERS/native_consequence_buffer_v1.py"
    discovery = ROOT / "DISCOVERY/ING03_FINAL_D32_NATIVE_CONSEQUENCE_BUFFER.json"
    selection = ROOT / "MECHANISM_SELECTION/ING03_FINAL_D35_NATIVE_BUFFER_MODEL_SELECTION.json"
    predictions = seal({
        "schema": "dee.v27.ing03.final.freeze.native_consequence_buffer.predictions.v1",
        "claim_scope": "one-shot native consequence generation, delay, and relational write; not recurrent learning, not RW2, not L4",
        "selected_family": {"memory_phase": 255, "distance": 3, "expected_write_tick": 6},
        "treatment_prediction": "two required proposals generate the frame-transformed route at tick 1 and change delta with target-dependent sign exactly at tick 6",
        "control_predictions": {
            "missing_d1": "no generated consequence and no relational write",
            "missing_d2": "no generated consequence and no relational write",
            "wrong_cancel": "no correct generated consequence and no relational write",
        },
        "fresh_dimensions": {"N": [37, 41, 43], "unseen_positions": True, "unseen_sign_combinations": True, "groups": 12, "worlds": 48},
        "pass_criterion": "all 12 treatment groups meet exact tick/sign/route predictions and all 36 prerequisite-breaking controls remain delta zero",
        "python_after_t0": "kernel ticks and logging only",
    })
    write_json(ROOT / "FREEZE/ING03_FINAL_NATIVE_BUFFER_PREDICTIONS.json", predictions)
    lock = seal({
        "schema": "dee.v27.ing03.final.freeze.native_consequence_buffer.lock.v1",
        "status": "FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION",
        "kernel_sha256": EXPECTED["kernel"],
        "apparatus": {"path": str(apparatus.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(apparatus)},
        "discovery": {"path": str(discovery.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(discovery)},
        "model_selection": {"path": str(selection.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(selection)},
        "predictions": {"path": "FREEZE/ING03_FINAL_NATIVE_BUFFER_PREDICTIONS.json", "sha256": sha256_file(ROOT / "FREEZE/ING03_FINAL_NATIVE_BUFFER_PREDICTIONS.json")},
        "selected_family": {"memory_phase": 255, "distance": 3, "expected_write_tick": 6},
    })
    output = ROOT / "FREEZE/ING03_FINAL_NATIVE_BUFFER_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "content_sha256": lock["content_sha256"], "apparatus_sha256": lock["apparatus"]["sha256"]}, indent=2))


if __name__ == "__main__":
    main()
