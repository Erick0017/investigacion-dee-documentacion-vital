#!/usr/bin/env python3
"""Freeze the one-cycle generated-consequence/buffer/write/delayed-query organization."""
from __future__ import annotations
import json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json

def main():
    paths={
        "apparatus":ROOT/"RUNNERS/buffered_offline_readout_v1.py",
        "discovery":ROOT/"DISCOVERY/ING03_FINAL_D39_BUFFERED_OFFLINE_READOUT.json",
        "model_selection":ROOT/"MECHANISM_SELECTION/ING03_FINAL_D40_OFFLINE_READOUT_MODEL_SELECTION.json",
    }
    prediction=seal({
        "schema":"dee.v27.ing03.final.freeze.buffered_offline_readout.predictions.v1",
        "claim_scope":"one complete prebuilt native sequence: consequence generation -> native delay -> master write -> later native query -> relation-specific output; one cycle only",
        "target_families":{"a":{"write_tick":9,"query_tick":12,"second_normalized_direction":[1,0,0]},"b":{"write_tick":21,"query_tick":24,"second_normalized_direction":[-1,1,1]}},
        "canaries":{"no_consequence":"no write; zero-class query","missing_d1":"no write; zero-class query","no_query":"write occurs; no comparator output"},
        "pass_criterion":"all 12 fresh groups and all 36 canary worlds meet exact preregistered tick/direction predictions",
        "not_claimed":["reusable mode switching","RW2","RW3","L4","consequence-selected policy reversal"],
        "python_after_t0":"kernel ticks and logging only",
    })
    pp=ROOT/"FREEZE/ING03_FINAL_OFFLINE_READOUT_PREDICTIONS.json";write_json(pp,prediction)
    lock=seal({"schema":"dee.v27.ing03.final.freeze.buffered_offline_readout.lock.v1","status":"FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION","kernel_sha256":EXPECTED["kernel"],**{k:{"path":str(v.relative_to(ROOT)).replace('\\','/'),"sha256":sha256_file(v)} for k,v in paths.items()},"predictions":{"path":str(pp.relative_to(ROOT)).replace('\\','/'),"sha256":sha256_file(pp)}})
    out=ROOT/"FREEZE/ING03_FINAL_OFFLINE_READOUT_LOCK.json";write_json(out,lock);print(json.dumps({"output":str(out),"content_sha256":lock["content_sha256"],"apparatus_sha256":lock["apparatus"]["sha256"]},indent=2))
if __name__=="__main__":main()
