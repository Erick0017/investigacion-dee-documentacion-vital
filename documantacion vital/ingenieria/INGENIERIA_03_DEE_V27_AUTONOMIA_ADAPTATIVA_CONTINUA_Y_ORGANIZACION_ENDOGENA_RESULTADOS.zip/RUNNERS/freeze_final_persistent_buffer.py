#!/usr/bin/env python3
"""Freeze the persistent generated-consequence writer after D37 model selection."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json


def main():
    paths = {
        "apparatus": ROOT / "RUNNERS/persistent_generated_buffer_v1.py",
        "dependency": ROOT / "RUNNERS/native_consequence_buffer_v1.py",
        "discovery": ROOT / "DISCOVERY/ING03_FINAL_D36_RECURRENT_GENERATED_BUFFER.json",
        "model_selection": ROOT / "MECHANISM_SELECTION/ING03_FINAL_D37_PERSISTENT_BUFFER_MODEL_SELECTION.json",
    }
    predictions = seal({
        "schema": "dee.v27.ing03.final.freeze.persistent_generated_buffer.predictions.v1",
        "claim_scope": "configured persistent two-source organization regenerates a delayed writer and changes relational state repeatedly without source depletion; not consequence-selected learning",
        "architecture": {"memory_phase": 255, "distance": 3, "proposal_semantic": 4, "horizon": 1024},
        "treatment_prediction": "at least four delta transitions and four distinct delta levels, target-dependent net sign, and unchanged persistent sources",
        "control_prediction": "removing either proposal or breaking vector cancellation leaves delta exactly zero",
        "pass_criterion": "all 12 fresh groups and all 36 prerequisite-breaking controls satisfy the preregistered predictions",
        "fresh_dimensions": {"N": [37, 41, 43], "groups": 12, "worlds": 48, "unseen_positions": True, "unseen_frame_signs": True},
        "python_after_t0": "kernel ticks and logging only",
    })
    prediction_path = ROOT / "FREEZE/ING03_FINAL_PERSISTENT_BUFFER_PREDICTIONS.json"
    write_json(prediction_path, predictions)
    lock = seal({
        "schema": "dee.v27.ing03.final.freeze.persistent_generated_buffer.lock.v1",
        "status": "FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION",
        "kernel_sha256": EXPECTED["kernel"],
        **{name: {"path": str(path.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(path)} for name, path in paths.items()},
        "predictions": {"path": str(prediction_path.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(prediction_path)},
    })
    output = ROOT / "FREEZE/ING03_FINAL_PERSISTENT_BUFFER_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "content_sha256": lock["content_sha256"], "apparatus_sha256": lock["apparatus"]["sha256"]}, indent=2))


if __name__ == "__main__":
    main()
