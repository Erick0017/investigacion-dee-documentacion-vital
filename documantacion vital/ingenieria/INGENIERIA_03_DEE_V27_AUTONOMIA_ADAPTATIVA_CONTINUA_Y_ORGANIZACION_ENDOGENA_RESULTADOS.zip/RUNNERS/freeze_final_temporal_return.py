#!/usr/bin/env python3
"""Freeze the N mod 6 temporal-return law before fresh N/frames."""
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED,ROOT,seal,sha256_file,write_json
def main():
    paths={"apparatus":ROOT/"RUNNERS/temporal_prefix_reader_v1.py","slot_enumeration":ROOT/"DISCOVERY/ING03_FINAL_D45_TEMPORAL_SLOT_CAPACITY.json","size_boundary":ROOT/"DISCOVERY/ING03_FINAL_D50_TEMPORAL_SIZE_BOUNDARY.json","model_selection":ROOT/"MECHANISM_SELECTION/ING03_FINAL_D51_TEMPORAL_MODULAR_FRAME_PANEL.json"}
    pred=seal({"schema":"dee.v27.ing03.final.freeze.temporal_return.predictions.v1","architecture":{"slots":[0,1,8],"query_tick":12,"horizon":"2N+20","zero_event_payload":True},"predictions":{"N_mod_6_1":{"classes":5,"partition":["Axx","BAA","BAB","BBA","BBB"],"second_tick":"N+3","third_tick":"N+10"},"N_mod_6_3":{"classes":3,"partition":["Axx","BxA","BxB"],"second_tick":None,"third_tick":"N+10"},"N_mod_6_5":{"classes":3,"partition":["Axx","BAx","BBx"],"second_tick":"2N+1","third_tick":None}},"fresh_N":[47,49,51,53,55,57],"pass_criterion":"all six fresh N/frame groups reproduce exact class partition and latency; no-events gives a distinct zero trace; no-query produces no comparator output","scope":"fixed length-three schedule family, not arbitrary sequence decoding or unseen-length generalization","python_after_t0":"ticks/logging only"})
    pp=ROOT/"FREEZE/ING03_FINAL_TEMPORAL_RETURN_PREDICTIONS.json";write_json(pp,pred)
    lock=seal({"schema":"dee.v27.ing03.final.freeze.temporal_return.lock.v1","status":"FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION","kernel_sha256":EXPECTED["kernel"],**{k:{"path":str(v.relative_to(ROOT)).replace('\\','/'),"sha256":sha256_file(v)} for k,v in paths.items()},"predictions":{"path":str(pp.relative_to(ROOT)).replace('\\','/'),"sha256":sha256_file(pp)}})
    out=ROOT/"FREEZE/ING03_FINAL_TEMPORAL_RETURN_LOCK.json";write_json(out,lock);print(json.dumps({"output":str(out),"content_sha256":lock["content_sha256"],"apparatus_sha256":lock["apparatus"]["sha256"]},indent=2))
if __name__=="__main__":main()
