#!/usr/bin/env python3
"""Freeze apparatus, predictions, challenge generator, and holdout analysis."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json


FILES = [
    "RUNNERS/ing03_common.py",
    "RUNNERS/recurrent_writer_apparatus_v1.py",
    "RUNNERS/relative_magnitude_reader_v1.py",
    "RUNNERS/generate_ing03_holdout_challenges.py",
    "RUNNERS/run_ing03_fresh_holdout.py",
    "FREEZE/ING03_FROZEN_PREDICTIONS.json",
]


def main():
    entries = []
    for rel in FILES:
        path = ROOT / rel
        if not path.exists():
            raise FileNotFoundError(path)
        entries.append({"path": rel, "sha256": sha256_file(path), "bytes": path.stat().st_size})
    lock = seal({
        "schema": "dee.v27.ing03.apparatus_lock.v1",
        "phase": "FREEZE_BEFORE_FRESH_WORLD_GENERATION",
        "kernel_expected_sha256": EXPECTED["kernel"],
        "locked_files": entries,
        "claims_under_test": [
            "exact recurrent relational writing under a persistent configured native source",
            "bounded functional-sign attractor recovery under an intact native source",
            "five exact relational-magnitude response classes",
        ],
        "non_claims": ["continuous L4 autonomy", "learned attractor", "microstate restoration", "endogenous allocation"],
    })
    out = ROOT / "FREEZE/ING03_APPARATUS_LOCK.json"
    write_json(out, lock)
    print(json.dumps({"output": str(out), "content_sha256": lock["content_sha256"], "files": len(entries)}, indent=2))


if __name__ == "__main__":
    main()
