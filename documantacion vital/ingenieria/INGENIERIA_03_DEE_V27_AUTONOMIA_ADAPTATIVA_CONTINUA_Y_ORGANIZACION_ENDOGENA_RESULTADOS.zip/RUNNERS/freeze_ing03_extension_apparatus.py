#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED,ROOT,seal,sha256_file,write_json
FILES=["RUNNERS/ing03_common.py","RUNNERS/read_write_extension_apparatus_v1.py","RUNNERS/generate_ing03_extension_holdout.py","RUNNERS/run_ing03_extension_holdout.py","FREEZE/ING03_EXTENSION_PREDICTIONS.json"]
def main():
    entries=[{"path":r,"sha256":sha256_file(ROOT/r),"bytes":(ROOT/r).stat().st_size} for r in FILES]
    d=seal({"schema":"dee.v27.ing03.extension.apparatus_lock.v1","phase":"FREEZE_BEFORE_FRESH_WORLD_GENERATION","kernel_sha256":EXPECTED["kernel"],"locked_files":entries,"claim_under_test":"selected finite-probe information/plasticity trade-off","nonclaims":["kernel-wide impossibility","L4","all trajectory readers"]})
    out=ROOT/"FREEZE/ING03_EXTENSION_APPARATUS_LOCK.json";write_json(out,d);print(json.dumps({"output":str(out),"files":len(entries),"content_sha256":d["content_sha256"]},indent=2))
if __name__=="__main__":main()
