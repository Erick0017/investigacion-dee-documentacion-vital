#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,sha256_file,write_json
def main():
    ap=ROOT/"FREEZE/ING03_EXTENSION_APPARATUS_LOCK.json";cp=ROOT/"CHALLENGES/ING03_EXTENSION_FRESH_CHALLENGES.json";a=json.loads(ap.read_text(encoding="utf-8"));c=json.loads(cp.read_text(encoding="utf-8"))
    if c["apparatus_lock_file_sha256"]!=sha256_file(ap):raise RuntimeError("challenge/lock mismatch")
    d=seal({"schema":"dee.v27.ing03.extension.final_lock.v1","apparatus_lock_file_sha256":sha256_file(ap),"apparatus_lock_content_sha256":a["content_sha256"],"challenge_file_sha256":sha256_file(cp),"challenge_content_sha256":c["content_sha256"],"group_count":c["group_count"],"native_world_count":c["native_world_count"],"post_challenge_tuning_permitted":False})
    out=ROOT/"FREEZE/ING03_EXTENSION_FINAL_LOCK.json";write_json(out,d);print(json.dumps({"output":str(out),"worlds":d["native_world_count"],"content_sha256":d["content_sha256"]},indent=2))
if __name__=="__main__":main()
