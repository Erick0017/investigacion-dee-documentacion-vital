#!/usr/bin/env python3
"""Bind the unseen challenge file to the already frozen apparatus."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    apparatus_path = ROOT / "FREEZE/ING03_APPARATUS_LOCK.json"
    challenge_path = ROOT / "CHALLENGES/ING03_FRESH_HOLDOUT_CHALLENGES.json"
    apparatus = json.loads(apparatus_path.read_text(encoding="utf-8"))
    challenge = json.loads(challenge_path.read_text(encoding="utf-8"))
    if challenge["apparatus_lock_file_sha256"] != sha256_file(apparatus_path):
        raise RuntimeError("challenge is not bound to current apparatus lock")
    lock = seal({
        "schema": "dee.v27.ing03.final_lock.v1",
        "phase": "FINAL_LOCK_BEFORE_EXECUTION",
        "apparatus_lock_file_sha256": sha256_file(apparatus_path),
        "apparatus_lock_content_sha256": apparatus["content_sha256"],
        "challenge_file_sha256": sha256_file(challenge_path),
        "challenge_content_sha256": challenge["content_sha256"],
        "world_count": challenge["world_count"],
        "post_challenge_tuning_permitted": False,
    })
    out = ROOT / "FREEZE/ING03_FINAL_LOCK.json"
    write_json(out, lock)
    print(json.dumps({"output": str(out), "content_sha256": lock["content_sha256"], "worlds": lock["world_count"]}, indent=2))


if __name__ == "__main__":
    main()
