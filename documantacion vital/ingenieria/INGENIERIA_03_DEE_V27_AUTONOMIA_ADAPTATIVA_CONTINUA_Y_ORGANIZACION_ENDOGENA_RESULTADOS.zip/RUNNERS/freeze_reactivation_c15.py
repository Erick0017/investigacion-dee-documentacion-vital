#!/usr/bin/env python3
"""Freeze the selected combined late-development mechanism before fresh worlds."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    evidence_paths = [
        "MECHANISM_SELECTION/ING03_REACT_R08_PHASE_COMPENSATED_LATE_COMMITMENT.json",
        "MECHANISM_SELECTION/ING03_REACT_R11_NATIVE_FORMATION_PROGRAM_GENERATOR.json",
        "MECHANISM_SELECTION/ING03_REACT_R12_LATE_COMMITMENT_CONTROLS.json",
        "MECHANISM_SELECTION/ING03_REACT_R13_COMBINED_LATE_DEVELOPMENT.json",
    ]
    evidence = [{"path": path, "sha256": sha256_file(ROOT / path)} for path in evidence_paths]
    lock = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.late_development_lock.v1",
        "lock_id": "ING03-REACT-C15-LATE-DEVELOPMENT-V1",
        "selected_after_discovery": True,
        "architecture": {"n": 41, "consequence_distance": 18, "memory_phase": 240,
                         "bridge_source_distances": [24, 24, 32, 24],
                         "receiver_relative_offset": [-6, 7, 8],
                         "horizon": 512, "stable_window_start": 384},
        "conditions": ["learn_a", "learn_b", "sham", "broken_generator"],
        "metrics": {"native_write_tick": 21, "first_remote_a_b_difference_tick": 38,
                    "minimum_stored_interval": 17,
                    "terminal_pair_observer": "raw pair at transformed receiver q/qp",
                    "master_observer": "relational s_reg delta"},
        "success_criteria": {"all_worlds_valid": True, "all_worlds_t0_complete": True,
                             "python_interventions_after_t0": 0,
                             "learner_t0_hash_identical_within_frame": True,
                             "learn_a_terminal_delta": 1, "learn_b_terminal_delta": -1,
                             "sham_terminal_delta": 0, "broken_generator_terminal_delta": 0,
                             "learn_a_b_sham_terminal_pairs_distinct": True,
                             "broken_generator_pair_equals_sham": True,
                             "a_b_first_write_tick": 21,
                             "a_b_first_remote_difference_tick": 38,
                             "terminal_window_constant": True,
                             "persistent_sources_raw_fixed": True},
        "claim_scope": "Native phase-compensated late first learning selects a delayed-formation remote state after a stored interval; not recurrent learning or RW3.",
        "fresh_generation": {"fresh_frames": 8,
                             "algorithm": "sha256-sort all nonidentity signed/permuted 3D frames",
                             "salt": "ING03-RW3-REACT-C15-FRESH-2026-09-21",
                             "outcomes_absent_at_lock": True},
        "evidence": evidence})
    output = ROOT / "FREEZE/ING03_REACT_C15_LATE_DEVELOPMENT_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "lock_id": lock["lock_id"],
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
