#!/usr/bin/env python3
"""Freeze the diagnostic susceptibility index before fresh frame generation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    source = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S01_SUSCEPTIBILITY.json"
    lock = seal({
        "schema": "dee.v27.ing03.native_succession.susceptibility_lock.v1",
        "lock_id": "ING03-SUCCESSION-S05-SUSCEPTIBILITY-V1",
        "discovery_evidence": {"path": str(source.relative_to(ROOT)).replace("\\", "/"),
                               "sha256": sha256_file(source)},
        "architecture": {"n": 41, "probe_tick": 184, "horizon": 360,
                         "frozen_architecture": "C15 learn_a with complete native formation apparatus",
                         "plastic_architecture": "virgin relational learner with identical local PA/PB scaffold",
                         "writer_relative_target": "b+(0,-1,0)-3*(0,0,1), transformed with frame",
                         "writer_state": 36000, "writer_s_reg": 0, "writer_semantic": 4,
                         "writer_clock": 184},
        "metric": {"name": "CAUSAL_ACCESSIBILITY_INDEX",
                   "definition": "1 iff a competent diagnostic writer causes any master-delta transition after tick184 by tick360; otherwise 0",
                   "frozen_prediction": 0, "plastic_prediction": 1},
        "pass_rule": "all fresh frames yield frozen index0, plastic index1, persistent writer source, and valid nonoverlapping apparatus",
        "claim_scope": "fresh-confirmed diagnostic state susceptibility differential; not native learner selection or RW3",
        "fresh_generation": {"algorithm": "sha256-sort unused nonidentity signed/permuted frames",
                             "salt": "ING03-NATIVE-SUCCESSION-S05-FRESH-2026-09-22",
                             "fresh_frames": 8, "exclude_c15_frames": True,
                             "outcomes_absent_at_lock": True},
    })
    output = ROOT / "FREEZE/ING03_SUCCESSION_S05_SUSCEPTIBILITY_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "lock_id": lock["lock_id"],
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
