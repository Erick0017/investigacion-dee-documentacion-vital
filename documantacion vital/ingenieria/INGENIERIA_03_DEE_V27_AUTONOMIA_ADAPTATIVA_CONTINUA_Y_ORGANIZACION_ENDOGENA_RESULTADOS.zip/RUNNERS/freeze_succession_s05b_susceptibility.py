#!/usr/bin/env python3
"""Freeze the S01/R10 susceptibility apparatus after S05's C15-port overlap."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    discovery = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S01_SUSCEPTIBILITY.json"
    invalid = ROOT / "HOLDOUT/ING03_SUCCESSION_S05_SUSCEPTIBILITY_HOLDOUT.json"
    lock = seal({
        "schema": "dee.v27.ing03.native_succession.susceptibility_lock.v2",
        "lock_id": "ING03-SUCCESSION-S05B-SUSCEPTIBILITY-V1",
        "predecessor_invalid_holdout": {"path": str(invalid.relative_to(ROOT)).replace("\\", "/"),
                                        "sha256": sha256_file(invalid),
                                        "reason": "C15 mature traffic occupied the diagnostic writer site in every frame"},
        "discovery_evidence": {"path": str(discovery.relative_to(ROOT)).replace("\\", "/"),
                               "sha256": sha256_file(discovery)},
        "architecture": {"n": 41, "probe_tick": 184, "horizon": 360,
                         "memory_phase": 252, "consequence_distance": 6,
                         "bridge_source_distances": [24, 24, 24, 24],
                         "receiver_relative_offset": [-6, 7, 8],
                         "writer_state": 36000, "writer_s_reg": 0,
                         "writer_semantic": 4, "writer_clock": 184},
        "metric": {"name": "CAUSAL_ACCESSIBILITY_INDEX",
                   "definition": "1 iff the diagnostic writer causes a master-delta transition after tick184; otherwise 0",
                   "frozen_prediction": 0, "plastic_prediction": 1},
        "pass_rule": "all fresh frames are valid, writer sites empty at insertion, frozen index0, plastic index1, and sources persist",
        "claim_scope": "fresh-confirmed diagnostic susceptibility differential; not native selection, RW3 or autonomy",
        "fresh_generation": {"algorithm": "sha256-sort frames unused by C15 and invalid S05",
                             "salt": "ING03-NATIVE-SUCCESSION-S05B-FRESH-2026-09-22",
                             "fresh_frames": 8, "outcomes_absent_at_lock": True},
    })
    output = ROOT / "FREEZE/ING03_SUCCESSION_S05B_SUSCEPTIBILITY_LOCK.json"
    write_json(output, lock)
    print(json.dumps({"output": str(output), "lock_id": lock["lock_id"],
                      "content_sha256": lock["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
