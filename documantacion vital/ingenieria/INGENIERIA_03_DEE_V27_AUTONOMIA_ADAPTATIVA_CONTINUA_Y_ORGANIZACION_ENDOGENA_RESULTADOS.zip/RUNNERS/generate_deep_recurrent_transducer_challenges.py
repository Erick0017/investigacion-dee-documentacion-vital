#!/usr/bin/env python3
"""Generate recurrent-transducer fresh challenges after its freeze."""
from __future__ import annotations
import itertools,json,random,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,sha256_file,write_json

def main():
    lock=ROOT/"FREEZE/ING03_DEEP_RECURRENT_TRANSDUCER_LOCK.json"
    if not lock.exists():raise RuntimeError("freeze first")
    rng=random.Random(35720260920);perms=list(itertools.permutations((0,1,2)));ns=(53,59,61,67,71,73,79,83);ports=(5,8,11,14,17);triples=((1,3,6),(2,5,8),(1,6,10),(3,7,11))
    rows=[]
    for i,n in enumerate(ns):
        rows.append({"group_id":f"DEEP-H02-{i:02d}","n":n,"origin":[rng.randrange(n) for _ in range(3)],"permutation":list(perms[(i+2)%6]),"signs":[rng.choice((-1,1)) for _ in range(3)],"port_offset":ports[i%len(ports)],"action_offsets":list(triples[i%len(triples)])})
    payload=seal({"schema":"dee.v27.ing03.deep.holdout.recurrent_transducer_challenges.v1","generated_after_freeze":True,"seed":35720260920,"freeze_lock":{"path":"FREEZE/ING03_DEEP_RECURRENT_TRANSDUCER_LOCK.json","sha256":sha256_file(lock)},"challenges":rows})
    out=ROOT/"HOLDOUT/ING03_DEEP_RECURRENT_TRANSDUCER_CHALLENGES.json";write_json(out,payload)
    print(json.dumps({"output":str(out),"groups":len(rows),"content_sha256":payload["content_sha256"]},indent=2))
if __name__=="__main__":main()
