#!/usr/bin/env python3
"""Generate fresh paired challenges only after the update-fork freeze exists."""
from __future__ import annotations

import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def main():
    lock_path = ROOT / "FREEZE/ING03_DEEP_UPDATE_FORK_LOCK.json"
    if not lock_path.exists():
        raise RuntimeError("freeze lock must exist before challenge generation")
    seed = 90320260920
    rng = random.Random(seed)
    permutations = list(itertools.permutations((0, 1, 2)))
    ns = [59, 61, 67, 71, 73, 79, 83]
    port_offsets = [4, 7, 10, 13, 16]
    action_offsets = [2, 4, 5, 7, 9]
    challenges = []
    for index in range(12):
        n = ns[index % len(ns)]
        permutation = permutations[index % len(permutations)]
        signs = tuple(rng.choice((-1, 1)) for _ in range(3))
        origin = tuple(rng.randrange(n) for _ in range(3))
        challenges.append({
            "group_id": f"DEEP-H01-{index:02d}",
            "n": n,
            "origin": list(origin),
            "permutation": list(permutation),
            "signs": list(signs),
            "port_offset": port_offsets[index % len(port_offsets)],
            "action_offset": action_offsets[(2 * index + 1) % len(action_offsets)],
        })
    payload = seal({
        "schema": "dee.v27.ing03.deep.holdout.update_fork_challenges.v1",
        "generated_after_freeze": True,
        "seed": seed,
        "freeze_lock": {"path": "FREEZE/ING03_DEEP_UPDATE_FORK_LOCK.json", "sha256": sha256_file(lock_path)},
        "challenge_count": len(challenges),
        "challenges": challenges,
    })
    output = ROOT / "HOLDOUT/ING03_DEEP_UPDATE_FORK_CHALLENGES.json"
    write_json(output, payload)
    print(json.dumps({"output": str(output), "challenge_count": len(challenges), "content_sha256": payload["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
