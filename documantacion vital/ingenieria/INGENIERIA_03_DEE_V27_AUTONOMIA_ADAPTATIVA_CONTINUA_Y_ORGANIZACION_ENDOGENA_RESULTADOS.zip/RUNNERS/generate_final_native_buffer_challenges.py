#!/usr/bin/env python3
"""Generate deterministic fresh native-buffer worlds only after the apparatus lock exists."""
from __future__ import annotations

import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json

SEED = 2026092003


def main():
    lock_path = ROOT / "FREEZE/ING03_FINAL_NATIVE_BUFFER_LOCK.json"
    if not lock_path.exists():
        raise RuntimeError("freeze lock must exist before challenge generation")
    lock_sha = sha256_file(lock_path)
    rng = random.Random(SEED)
    frames = list(itertools.product(itertools.permutations((0, 1, 2)), itertools.product((-1, 1), repeat=3)))
    discovery_frames = {
        ((0, 1, 2), (1, 1, 1)), ((1, 2, 0), (-1, 1, 1)), ((2, 0, 1), (1, -1, 1)),
        ((0, 2, 1), (-1, -1, 1)), ((2, 1, 0), (1, 1, -1)), ((1, 0, 2), (-1, 1, -1)),
    }
    unseen = [item for item in frames if item not in discovery_frames]
    rng.shuffle(unseen)
    groups = []
    for group_id in range(1, 13):
        n = [37, 41, 43][(group_id - 1) % 3]
        permutation, signs = unseen[group_id - 1]
        origin = tuple(rng.randrange(n) for _ in range(3))
        target = "a" if group_id % 2 else "b"
        groups.append({
            "group_id": group_id,
            "n": n,
            "origin": list(origin),
            "permutation": list(permutation),
            "signs": list(signs),
            "target_name": target,
            "memory_phase": 255,
            "distance": 3,
            "expected_write_tick": 6,
            "modes": ["treatment", "missing_d1", "missing_d2", "wrong_cancel"],
        })
    challenges = seal({
        "schema": "dee.v27.ing03.final.challenge.native_consequence_buffer.v1",
        "generated_after_freeze": True,
        "seed": SEED,
        "freeze_lock": {"path": "FREEZE/ING03_FINAL_NATIVE_BUFFER_LOCK.json", "sha256": lock_sha},
        "groups": groups,
    })
    output = ROOT / "CHALLENGES/ING03_FINAL_NATIVE_BUFFER_CHALLENGES.json"
    write_json(output, challenges)
    print(json.dumps({"output": str(output), "groups": len(groups), "worlds": 4 * len(groups), "content_sha256": challenges["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
