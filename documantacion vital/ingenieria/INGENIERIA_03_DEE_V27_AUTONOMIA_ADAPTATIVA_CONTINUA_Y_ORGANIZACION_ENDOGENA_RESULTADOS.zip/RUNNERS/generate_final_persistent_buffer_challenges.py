#!/usr/bin/env python3
"""Generate fresh persistent-buffer challenges after the freeze lock."""
from __future__ import annotations

import itertools
import json
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json

SEED = 2026092037


def main():
    lock_path = ROOT / "FREEZE/ING03_FINAL_PERSISTENT_BUFFER_LOCK.json"
    if not lock_path.exists():
        raise RuntimeError("persistent buffer must be frozen first")
    rng = random.Random(SEED)
    used = {
        ((0, 1, 2), (1, 1, 1)), ((1, 2, 0), (-1, 1, 1)), ((2, 0, 1), (1, -1, 1)),
        ((0, 2, 1), (-1, -1, 1)), ((2, 1, 0), (1, 1, -1)), ((1, 0, 2), (-1, 1, -1)),
    }
    frames = [item for item in itertools.product(itertools.permutations((0, 1, 2)), itertools.product((-1, 1), repeat=3)) if item not in used]
    rng.shuffle(frames)
    groups = []
    for group_id in range(1, 13):
        n = [37, 41, 43][(group_id - 1) % 3]
        permutation, signs = frames[group_id - 1]
        groups.append({
            "group_id": group_id, "n": n, "origin": [rng.randrange(n) for _ in range(3)],
            "target_name": "a" if group_id % 2 else "b", "memory_phase": 255, "distance": 3,
            "permutation": list(permutation), "signs": list(signs), "horizon": 1024,
            "modes": ["treatment", "missing_d1", "missing_d2", "wrong_cancel"],
        })
    value = seal({
        "schema": "dee.v27.ing03.final.challenge.persistent_generated_buffer.v1",
        "generated_after_freeze": True, "seed": SEED,
        "freeze_lock": {"path": str(lock_path.relative_to(ROOT)).replace('\\', '/'), "sha256": sha256_file(lock_path)},
        "groups": groups,
    })
    output = ROOT / "CHALLENGES/ING03_FINAL_PERSISTENT_BUFFER_CHALLENGES.json"
    write_json(output, value)
    print(json.dumps({"output": str(output), "groups": len(groups), "worlds": 4 * len(groups), "content_sha256": value["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
