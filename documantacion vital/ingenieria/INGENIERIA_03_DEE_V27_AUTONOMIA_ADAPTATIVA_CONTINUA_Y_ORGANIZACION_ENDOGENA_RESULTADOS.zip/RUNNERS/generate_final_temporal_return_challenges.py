#!/usr/bin/env python3
"""Create fresh temporal-return N/frame worlds after freeze."""
from __future__ import annotations
import itertools,json,random,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,sha256_file,write_json
SEED=2026092051
def main():
    lp=ROOT/"FREEZE/ING03_FINAL_TEMPORAL_RETURN_LOCK.json"
    if not lp.exists():raise RuntimeError("freeze required")
    rng=random.Random(SEED);used={((0,1,2),(1,1,1)),((1,2,0),(-1,1,1)),((2,0,1),(1,-1,1)),((0,2,1),(-1,-1,1)),((2,1,0),(1,1,-1)),((1,0,2),(-1,1,-1))};frames=[x for x in itertools.product(itertools.permutations((0,1,2)),itertools.product((-1,1),repeat=3)) if x not in used];rng.shuffle(frames);groups=[]
    for index,n in enumerate((47,49,51,53,55,57)):
        p,s=frames[index];groups.append({"group_id":index+1,"n":n,"origin":[rng.randrange(n) for _ in range(3)],"permutation":list(p),"signs":list(s),"horizon":2*n+20})
    value=seal({"schema":"dee.v27.ing03.final.challenge.temporal_return.v1","generated_after_freeze":True,"seed":SEED,"freeze_lock":{"path":str(lp.relative_to(ROOT)).replace('\\','/'),"sha256":sha256_file(lp)},"groups":groups})
    out=ROOT/"CHALLENGES/ING03_FINAL_TEMPORAL_RETURN_CHALLENGES.json";write_json(out,value);print(json.dumps({"output":str(out),"groups":len(groups),"worlds":10*len(groups),"content_sha256":value["content_sha256"]},indent=2))
if __name__=="__main__":main()
