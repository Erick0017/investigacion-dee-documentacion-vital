#!/usr/bin/env python3
from __future__ import annotations
import itertools,json,secrets,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,sha256_file,write_json

def main():
    lockp=ROOT/"FREEZE/ING03_EXTENSION_APPARATUS_LOCK.json"
    if not lockp.exists():raise RuntimeError("extension apparatus not frozen")
    seed=secrets.token_hex(32);rng=secrets.SystemRandom(int(seed,16));frames=[(list(p),list(s)) for p in itertools.permutations((0,1,2)) for s in itertools.product((-1,1),repeat=3)];groups=[]
    for i in range(16):
        n=rng.choice([19,25,29,31]);p,s=rng.choice(frames);kind=("INFORMATIVE_BLOCKING","WRITABLE_UNINFORMATIVE")[i%2]
        groups.append({"case_id":f"EXH{i:03d}","n":n,"origin":[rng.randrange(n) for _ in range(3)],"permutation":p,"signs":s,"probe_kind":kind})
    c=seal({"schema":"dee.v27.ing03.extension.holdout.challenge.v1","generated_after_freeze":True,"os_entropy_seed_hex":seed,"apparatus_lock_file_sha256":sha256_file(lockp),"groups":groups,"group_count":len(groups),"native_world_count":len(groups)*6})
    out=ROOT/"CHALLENGES/ING03_EXTENSION_FRESH_CHALLENGES.json";write_json(out,c);print(json.dumps({"output":str(out),"groups":len(groups),"worlds":len(groups)*6,"content_sha256":c["content_sha256"]},indent=2))
if __name__=="__main__":main()
