#!/usr/bin/env python3
"""Generate post-freeze fresh challenges using OS entropy."""
from __future__ import annotations

import itertools
import json
import secrets
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, sha256_file, write_json


def frames():
    return [(list(p), list(s)) for p in itertools.permutations((0, 1, 2)) for s in itertools.product((-1, 1), repeat=3)]


def main():
    lock_path = ROOT / "FREEZE/ING03_APPARATUS_LOCK.json"
    if not lock_path.exists():
        raise RuntimeError("apparatus must be frozen before challenge generation")
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    seed_hex = secrets.token_hex(32)
    rng = secrets.SystemRandom(int(seed_hex, 16))
    fs = frames()
    fresh_n = [19, 25, 31, 37, 41]
    writer = []
    for i in range(24):
        n = rng.choice(fresh_n); p, s = rng.choice(fs); mode = ("source_a", "source_b", "both", "none")[i % 4]
        writer.append({"case_id": f"HW{i:03d}", "n": n, "origin": [rng.randrange(n) for _ in range(3)], "permutation": p, "signs": s, "mode": mode, "horizon": 2048})
    recovery = []
    recovery_modes = ["source_a", "source_b", "none", "both", "source_a_cut"]
    for i in range(25):
        n = rng.choice([25, 31, 37, 41]); p, s = rng.choice(fs); mode = recovery_modes[i % len(recovery_modes)]
        recovery.append({"case_id": f"HR{i:03d}", "n": n, "origin": [rng.randrange(n) for _ in range(3)], "permutation": p, "signs": s, "mode": mode, "pre_ticks": 2048, "post_ticks": 3072, "damage_magnitude": 8})
    magnitude = []
    class_values = {"NEGATIVE": list(range(-16, 0)), "ZERO": [0], "POSITIVE_1_TO_6": list(range(1, 7)), "POSITIVE_7": [7], "POSITIVE_8_PLUS": list(range(8, 17))}
    classes = list(class_values)
    for i in range(30):
        n = rng.choice(fresh_n); p, s = rng.choice(fs); klass = classes[i % len(classes)]; delta = rng.choice(class_values[klass])
        magnitude.append({"case_id": f"HM{i:03d}", "n": n, "origin": [rng.randrange(n) for _ in range(3)], "permutation": p, "signs": s, "delta": delta, "expected_class": klass})
    challenge = seal({
        "schema": "dee.v27.ing03.holdout.challenge.v1",
        "generated_after_apparatus_freeze": True,
        "os_entropy_seed_hex": seed_hex,
        "apparatus_lock_file_sha256": sha256_file(lock_path),
        "apparatus_lock_content_sha256": lock["content_sha256"],
        "writer_worlds": writer,
        "recovery_worlds": recovery,
        "magnitude_worlds": magnitude,
        "world_count": len(writer) + len(recovery) + len(magnitude),
    })
    out = ROOT / "CHALLENGES/ING03_FRESH_HOLDOUT_CHALLENGES.json"
    write_json(out, challenge)
    print(json.dumps({"output": str(out), "worlds": challenge["world_count"], "content_sha256": challenge["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
