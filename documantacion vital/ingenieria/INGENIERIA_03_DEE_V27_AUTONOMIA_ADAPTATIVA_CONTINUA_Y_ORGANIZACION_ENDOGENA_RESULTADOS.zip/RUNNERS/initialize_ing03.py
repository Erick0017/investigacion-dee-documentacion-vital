#!/usr/bin/env python3
"""Lock frozen parent package identities and canonical DEE v27 runtime."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing03_common import CORE_DIR, ENGINEERING_DIR, ROOT, load_kernel, seal, sha256_file, write_json


def main():
    _, runtime = load_kernel(1)
    parents = []
    for index in range(1, 18):
        matches = sorted(CORE_DIR.glob(f"{index:02d}_*.zip"))
        if len(matches) != 1:
            raise RuntimeError(f"CORE{index:02d}: expected one parent, observed {matches}")
        p = matches[0]
        parents.append({"parent_id": f"CORE{index:02d}", "filename": p.name, "bytes": p.stat().st_size, "sha256": sha256_file(p), "role": "frozen_parent"})
    for index in (1, 2):
        folder = ENGINEERING_DIR / f"INGENIERIA_{index:02d}"
        matches = sorted(folder.glob(f"INGENIERIA_{index:02d}_*.zip"))
        if len(matches) != 1:
            raise RuntimeError(f"INGENIERIA_{index:02d}: expected one parent, observed {matches}")
        p = matches[0]
        parents.append({"parent_id": f"INGENIERIA_{index:02d}", "filename": p.name, "bytes": p.stat().st_size, "sha256": sha256_file(p), "role": "frozen_parent"})
    result = seal({"schema": "dee.v27.ing03.parent_evidence_map.v1", "frozen_policy": "CORE01-17 and INGENIERIA 01-02 are read-only parent evidence.", "packages": parents, "runtime": runtime})
    write_json(ROOT / "ING03_PARENT_EVIDENCE_MAP.json", result)
    print(json.dumps({"parents": len(parents), "kernel": runtime["observed_hashes"]["kernel"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
