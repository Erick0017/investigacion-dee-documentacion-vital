#!/usr/bin/env python3
"""Lock and inventory the authoritative pre-native-succession ING03 archive."""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json


OFFICIAL = ROOT / "INGENIERIA_03_DEE_V27_AUTONOMIA_ADAPTATIVA_CONTINUA_Y_ORGANIZACION_ENDOGENA_RESULTADOS.zip"
EXPECTED_SHA = "3a82594ab9d8027f17215a26086588f39f2ddc1686aaff148774bec89aae2884"


def main():
    observed = sha256_file(OFFICIAL)
    if observed != EXPECTED_SHA:
        raise RuntimeError(f"baseline SHA mismatch: {observed}")
    with zipfile.ZipFile(OFFICIAL) as archive:
        bad = archive.testzip()
        names = archive.namelist()
        manifest = json.loads(archive.read("MANIFEST.json"))
        claims = json.loads(archive.read("CLAIM_LEDGER.json"))
        holdouts = json.loads(archive.read("HOLDOUT_REGISTRY.json"))
        canaries = json.loads(archive.read("CANARY_REGISTRY.json"))
        runtime = json.loads(archive.read("RUNTIME_ENVIRONMENT.json"))
        parents = json.loads(archive.read("ING03_PARENT_EVIDENCE_MAP.json"))
        finalization = json.loads(archive.read("FINALIZATION_STATE.json"))
        hash_failures = []
        for line in archive.read("HASHES.sha256").decode("utf-8").splitlines():
            if not line.strip():
                continue
            digest, rel = line.split("  ", 1)
            if rel not in names or hashlib.sha256(archive.read(rel)).hexdigest() != digest:
                hash_failures.append(rel)
        manifest_failures = [item["path"] for item in manifest["files"]
                             if item["path"] not in names or
                             hashlib.sha256(archive.read(item["path"])).hexdigest() != item["sha256"]]
    result = seal({
        "schema": "dee.v27.ing03.native_succession.baseline.v1",
        "baseline_id": "ING03_PRE_NATIVE_SUCCESSION_BASELINE",
        "official_filename": OFFICIAL.name,
        "sha256": observed,
        "archive_bytes": OFFICIAL.stat().st_size,
        "member_count": len(names),
        "zip_crc_bad_member": bad,
        "manifest_hash_failures": manifest_failures,
        "hashes_file_failures": hash_failures,
        "kernel_sha256": manifest.get("kernel_sha256"),
        "kernel_identity_pass": manifest.get("kernel_sha256") == EXPECTED["kernel"] == runtime.get("kernel_observed_sha256"),
        "parent_package_count": len(parents.get("packages", [])),
        "parent_packages_embedded": manifest.get("parent_packages_embedded"),
        "highest_rw": claims.get("highest_rw"),
        "highest_rw_label": claims.get("highest_rw_label"),
        "highest_autonomy": manifest.get("highest_autonomy"),
        "rw3_achieved": manifest.get("rw3_achieved"),
        "l4_achieved": manifest.get("l4_achieved"),
        "claim_count": len(claims.get("claims", [])),
        "holdout_count": len(holdouts.get("holdouts", [])),
        "canary_registry_present": bool(canaries),
        "embedded_finalization_status": finalization.get("scientific_status"),
        "baseline_lock_pass": bad is None and not manifest_failures and not hash_failures and
                              manifest.get("kernel_sha256") == EXPECTED["kernel"] and
                              len(parents.get("packages", [])) == 19 and
                              manifest.get("parent_packages_embedded") is False and
                              claims.get("highest_rw") == "RW2" and
                              manifest.get("rw3_achieved") is False and
                              manifest.get("l4_achieved") is False,
    })
    write_json(ROOT / "ING03_PRE_NATIVE_SUCCESSION_BASELINE.json", result)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
