#!/usr/bin/env python3
"""Lock the authoritative pre-open-hypothesis ING03 archive."""
from __future__ import annotations

import hashlib
import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, write_json

OFFICIAL = ROOT / "INGENIERIA_03_DEE_V27_AUTONOMIA_ADAPTATIVA_CONTINUA_Y_ORGANIZACION_ENDOGENA_RESULTADOS.zip"
EXPECTED_SHA = "fc1ada1c90d0ec8b6591122a97a1bed7fc78df87e2ad9579a9881858c46c34a8"


def main():
    observed = sha256_file(OFFICIAL)
    if observed != EXPECTED_SHA: raise RuntimeError(f"baseline SHA mismatch: {observed}")
    with zipfile.ZipFile(OFFICIAL) as archive:
        bad = archive.testzip(); names = archive.namelist()
        get = lambda name: json.loads(archive.read(name))
        manifest = get("MANIFEST.json"); claims = get("CLAIM_LEDGER.json")
        holdouts = get("HOLDOUT_REGISTRY.json"); canaries = get("CANARY_REGISTRY.json")
        runtime = get("RUNTIME_ENVIRONMENT.json"); parents = get("ING03_PARENT_EVIDENCE_MAP.json")
        finalization = get("FINALIZATION_STATE.json")
        hash_failures = []
        for line in archive.read("HASHES.sha256").decode("utf-8").splitlines():
            if line.strip():
                digest, rel = line.split("  ", 1)
                if rel not in names or hashlib.sha256(archive.read(rel)).hexdigest() != digest: hash_failures.append(rel)
        manifest_failures = [row["path"] for row in manifest["files"] if row["path"] not in names or
                             hashlib.sha256(archive.read(row["path"])).hexdigest() != row["sha256"]]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.baseline.v1",
        "baseline_id": "ING03_PRE_OPEN_HYPOTHESIS_BASELINE", "official_filename": OFFICIAL.name,
        "sha256": observed, "archive_bytes": OFFICIAL.stat().st_size, "member_count": len(names),
        "zip_crc_bad_member": bad, "manifest_hash_failures": manifest_failures,
        "hashes_file_failures": hash_failures, "kernel_sha256": manifest.get("kernel_sha256"),
        "kernel_identity_pass": manifest.get("kernel_sha256") == EXPECTED["kernel"] == runtime.get("kernel_observed_sha256"),
        "parent_package_count": len(parents.get("packages", [])),
        "parent_packages_embedded": manifest.get("parent_packages_embedded"),
        "highest_rw": claims.get("highest_rw"), "highest_rw_label": claims.get("highest_rw_label"),
        "highest_autonomy": manifest.get("highest_autonomy"), "rw3_achieved": manifest.get("rw3_achieved"),
        "rw4_achieved": manifest.get("rw4_achieved"), "rw5_achieved": manifest.get("rw5_achieved"),
        "l4_achieved": manifest.get("l4_achieved"), "claim_count": len(claims.get("claims", [])),
        "holdout_count": len(holdouts.get("holdouts", [])),
        "canary_sections": sorted(k for k in canaries if k not in {"schema", "created_utc", "content_sha256"}),
        "embedded_finalization_status": finalization.get("scientific_status"),
        "baseline_lock_pass": bad is None and not manifest_failures and not hash_failures and
            manifest.get("kernel_sha256") == EXPECTED["kernel"] and len(parents.get("packages", [])) == 19 and
            manifest.get("parent_packages_embedded") is False and claims.get("highest_rw") == "RW2" and
            manifest.get("rw3_achieved") is False and manifest.get("l4_achieved") is False,
    })
    output = ROOT / "ING03_PRE_OPEN_HYPOTHESIS_BASELINE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), **result}, indent=2, ensure_ascii=False))


if __name__ == "__main__": main()

