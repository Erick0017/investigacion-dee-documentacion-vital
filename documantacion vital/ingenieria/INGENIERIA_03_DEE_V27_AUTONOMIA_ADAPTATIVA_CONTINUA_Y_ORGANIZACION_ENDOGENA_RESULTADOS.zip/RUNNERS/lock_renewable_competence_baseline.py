#!/usr/bin/env python3
"""Lock the validated open-hypothesis package for renewable-competence work."""
from __future__ import annotations

import json
import sys
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import EXPECTED, ROOT, seal, sha256_file, utc, write_json
from validate_open_hypothesis_package import OFFICIAL, validate_archive


EXPECTED_SHA256 = "f6257a1d002420fc85cd2df4c91dbc7836e03496050e80085154163732ea6497"
EXPECTED_MEMBERS = 917
OUTPUT = ROOT / "ING03_PRE_RENEWABLE_COMPETENCE_BASELINE.json"


def main():
    archive = ROOT / OFFICIAL
    validation = validate_archive(archive)
    current_sha = sha256_file(archive)
    with zipfile.ZipFile(archive) as payload:
        manifest = json.loads(payload.read("MANIFEST.json"))
        claims = json.loads(payload.read("CLAIM_LEDGER.json"))
        holdouts = json.loads(payload.read("HOLDOUT_REGISTRY.json"))
        canaries = json.loads(payload.read("CANARY_REGISTRY.json"))
        autonomy = json.loads(payload.read("ING03_AUTONOMY_LEVELS.json"))
        parent_map = json.loads(payload.read(manifest["parents_referenced_by"]))
        member_names = set(payload.namelist())
    checks = {
        "official_archive_exists": archive.exists(),
        "external_sha256_matches": current_sha == EXPECTED_SHA256,
        "zip_crc_pass": validation.get("crc_bad_member") is None,
        "internal_hashes_pass": not validation.get("hashes_file_failures"),
        "manifest_pass": not validation.get("manifest_hash_failures"),
        "kernel_identity_pass": validation.get("kernel_identity_pass") is True,
        "parent_provenance_pass": (
            manifest.get("parents_referenced_by") in member_names
            and manifest.get("parent_package_count") == len(parent_map.get("packages", []))
            and manifest.get("parent_package_count", 0) > 0
        ),
        "claim_ledger_pass": (
            validation.get("claims_pass") is True
            and claims.get("highest_rw") == "RW2"
            and claims.get("l4_achieved") is False
        ),
        "holdout_registry_pass": (
            holdouts.get("all_passed") is True
            and holdouts.get("freeze_before_fresh") is True
            and holdouts.get("no_post_freeze_tuning") is True
        ),
        "canary_registry_pass": (
            validation.get("canaries_pass") is True
            and bool(canaries.get("open_hypothesis_canaries"))
        ),
        "rw_classification_pass": (
            validation.get("rw_chain_pass") is True
            and validation.get("claim_ladder_pass") is True
            and manifest.get("highest_read_write_level") == "RW2_NATIVE_DELAYED_EXPRESSION"
            and all(manifest.get(name) is False for name in ("rw3_achieved", "rw4_achieved", "rw5_achieved", "l4_achieved"))
        ),
        "autonomy_classification_pass": (
            manifest.get("highest_autonomy") == "L3_FINITE_INHERITED_PRESERVED"
            and autonomy.get("status") == "L3_FINITE_INHERITED_PRESERVED"
            and all(autonomy.get(name) is False for name in ("rw3_demonstrated", "rw4_demonstrated", "rw5_demonstrated", "l4_demonstrated"))
        ),
        "member_count_matches": validation.get("member_count") == EXPECTED_MEMBERS,
        "no_engineering04": not validation.get("engineering04_members"),
        "prior_validator_pass": validation.get("overall_pass") is True,
    }
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.baseline.v1",
        "recorded_utc": utc(),
        "baseline_id": "ING03_PRE_RENEWABLE_COMPETENCE_BASELINE",
        "official_archive": OFFICIAL,
        "sha256": current_sha,
        "bytes": archive.stat().st_size,
        "member_count": validation.get("member_count"),
        "expected_sha256": EXPECTED_SHA256,
        "expected_members": EXPECTED_MEMBERS,
        "kernel_sha256": EXPECTED["kernel"],
        "checks": checks,
        "baseline_lock_pass": all(checks.values()),
        "highest_rw": "RW2_NATIVE_DELAYED_EXPRESSION",
        "highest_autonomy": "L3_FINITE_INHERITED_PRESERVED",
        "rw3_achieved": False,
        "rw4_achieved": False,
        "rw5_achieved": False,
        "l4_achieved": False,
        "missing_edge": "second independent experience -> retained transition of an established learned organization -> new native function",
        "continuity": {
            "engineering": "INGENIERIA_03",
            "engineering04_created": False,
            "kernel_modified": False,
            "frozen_parents_modified": False,
        },
        "validator_snapshot": validation,
    })
    write_json(OUTPUT, result)
    print(json.dumps({
        "output": OUTPUT.relative_to(ROOT).as_posix(),
        "sha256": current_sha,
        "member_count": validation.get("member_count"),
        "baseline_lock_pass": result["baseline_lock_pass"],
        "failed_checks": [name for name, passed in checks.items() if not passed],
        "content_sha256": result["content_sha256"],
    }, indent=2, ensure_ascii=False))
    raise SystemExit(0 if result["baseline_lock_pass"] else 1)


if __name__ == "__main__":
    main()
