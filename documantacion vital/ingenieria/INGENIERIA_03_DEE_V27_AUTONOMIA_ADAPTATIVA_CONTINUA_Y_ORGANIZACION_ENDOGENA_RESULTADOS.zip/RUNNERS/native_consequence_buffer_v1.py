#!/usr/bin/env python3
"""Frozen-candidate native consequence buffer distilled from ING03 D32."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, add, full_sha, pack, read, transform

SUPPORT = ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1))


def _put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap at {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def build_world(
    kernel,
    *,
    n=29,
    origin=(8, 13, 11),
    target_name="a",
    memory_phase=255,
    distance=3,
    permutation=(0, 1, 2),
    signs=(1, 1, 1),
    mode="treatment",
):
    """Create a complete t0 world; no later host intervention is required."""
    tv = lambda vector: transform(vector, permutation, signs)
    a = tuple(int(x) % int(n) for x in origin)
    b = add(a, tv((9, 0, 0)), 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    for center, base in ((a, 1000), (b, 2000)):
        _put(raw, clock, center, base, 100, semantic=1, phase=memory_phase)
        for index, offset in enumerate(SUPPORT):
            _put(raw, clock, add(center, tv(offset), 1, n), base + 100 + index, 0, semantic=4, phase=31 + index)

    target = a if target_name == "a" else b
    event = add(target, tv((0, -1, 0)), 1, n)
    route = tv((0, 0, 1))
    generator = add(event, route, -int(distance), n)
    d1, d2 = tv((1, 0, 1)), tv((-1, 0, 1))
    if mode != "missing_d1":
        _put(raw, clock, add(generator, d1, -1, n), 5001, 3, d1, 1, 0)
    if mode != "missing_d2":
        _put(raw, clock, add(generator, d2, -1, n), 5002, 3, d2, 1, 0)
    if mode == "wrong_cancel":
        q = add(generator, d2, -1, n)
        raw[q] = pack(5002, 3, d1, 1)

    metadata = {
        "n": int(n),
        "origin": list(a),
        "a": list(a),
        "b": list(b),
        "target": list(target),
        "target_name": target_name,
        "event": list(event),
        "generator": list(generator),
        "route": list(route),
        "memory_phase": int(memory_phase),
        "distance": int(distance),
        "permutation": list(permutation),
        "signs": list(signs),
        "mode": mode,
        "initial_full_sha256": full_sha(raw, clock),
    }
    return NativeWorld(kernel, raw, clock), metadata


def execute(world, metadata, horizon=32):
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    generator, event = tuple(metadata["generator"]), tuple(metadata["event"])
    route, distance = tuple(metadata["route"]), int(metadata["distance"])
    first_nonzero_delta = None
    delta_trace, corridor = [], []
    generated_tick1 = None
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        delta_trace.append(delta)
        if tick == 1:
            generated_tick1 = read(world.raw, generator)
        step = tick - 1
        if 0 <= step <= distance:
            q = add(generator, route, step, metadata["n"])
            record = read(world.raw, q)
            if record is not None:
                corridor.append({"tick": tick, "step": step, "q": list(q), "record": record})
        if delta not in (0, None) and first_nonzero_delta is None:
            first_nonzero_delta = tick
    expected_sign = 1 if metadata["target_name"] == "a" else -1
    return {
        **metadata,
        "horizon": int(horizon),
        "generated_tick1": generated_tick1,
        "generated_route_exact": generated_tick1 is not None and tuple(generated_tick1["direction"]) == route,
        "corridor": corridor,
        "delta_trace": delta_trace,
        "first_nonzero_delta": first_nonzero_delta,
        "terminal_delta": delta_trace[-1],
        "expected_sign": expected_sign,
        "sign_correct": delta_trace[-1] is not None and int(np.sign(delta_trace[-1])) == expected_sign,
        "python_interventions_after_t0": 0,
    }


def run_case(kernel, **kwargs):
    horizon = kwargs.pop("horizon", 32)
    world, metadata = build_world(kernel, **kwargs)
    return execute(world, metadata, horizon=horizon)
