#!/usr/bin/env python3
"""Candidate persistent generated-consequence writer derived from D36."""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import add, pack, read, transform
from native_consequence_buffer_v1 import build_world


def _rle(values):
    output = []
    for tick, value in enumerate(values, 1):
        if output and output[-1][2] == value:
            output[-1][1] = tick
        else:
            output.append([tick, tick, value])
    return output


def build_persistent_world(kernel, **kwargs):
    mode = kwargs.get("mode", "treatment")
    world, metadata = build_world(kernel, **kwargs)
    permutation, signs = tuple(metadata["permutation"]), tuple(metadata["signs"])
    d1 = transform((1, 0, 1), permutation, signs)
    d2 = transform((-1, 0, 1), permutation, signs)
    generator, n = tuple(metadata["generator"]), int(metadata["n"])
    positions = [add(generator, d1, -1, n), add(generator, d2, -1, n)]
    for index, (q, direction, state) in enumerate(zip(positions, (d1, d2), (5001, 5002))):
        if (mode == "missing_d1" and index == 0) or (mode == "missing_d2" and index == 1):
            continue
        actual_direction = d1 if mode == "wrong_cancel" and index == 1 else direction
        value = pack(state, 3, actual_direction, 4)
        world.raw_a[q] = value
        world.raw_b[q] = value
    metadata["persistent_source_positions"] = [list(q) for q in positions]
    metadata["persistent_source_initial_raw"] = [int(world.raw[q]) for q in positions]
    return world, metadata


def execute_persistent(world, metadata, horizon=1024):
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    positions = [tuple(q) for q in metadata["persistent_source_positions"]]
    deltas = []
    for _ in range(int(horizon)):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
    runs = _rle(deltas)
    expected_net_sign = -1 if metadata["target_name"] == "a" else 1
    nonnull = [value for value in deltas if value is not None]
    return {
        **metadata,
        "horizon": int(horizon),
        "delta_rle": runs,
        "delta_transitions": max(0, len(runs) - 1),
        "distinct_delta_values": sorted(set(nonnull)),
        "terminal_delta": deltas[-1],
        "expected_net_sign": expected_net_sign,
        "net_sign_correct": bool(nonnull) and (nonnull[-1] > 0) == (expected_net_sign > 0) and nonnull[-1] != 0,
        "source_raw_fixed": [int(world.raw[q]) for q in positions] == metadata["persistent_source_initial_raw"],
        "python_interventions_after_t0": 0,
    }


def run_case(kernel, *, horizon=1024, **kwargs):
    world, metadata = build_persistent_world(kernel, **kwargs)
    return execute_persistent(world, metadata, horizon=horizon)
