#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,seal,write_json

def main():
    d24=json.loads((ROOT/"MECHANISM_SELECTION/ING03_EXT_D24_PROBE_FRAME_PANEL.json").read_text(encoding="utf-8"))
    if d24["summary"]!={"world_groups":24,"pass":24}:raise RuntimeError("D24 not exact")
    p=seal({"schema":"dee.v27.ing03.extension.freeze.predictions.v1","phase":"FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION","predictions":{"INFORMATIVE_BLOCKING":{"distinct_signatures":3,"all_future_writable":False,"per_delta_post16_transitions":0},"WRITABLE_UNINFORMATIVE":{"distinct_signatures":1,"all_future_writable":True}},"scope":"Selected finite-probe classes only; no kernel-wide impossibility claim.","model_selection_content_sha256":d24["content_sha256"]})
    out=ROOT/"FREEZE/ING03_EXTENSION_PREDICTIONS.json";write_json(out,p);print(json.dumps({"output":str(out),"content_sha256":p["content_sha256"]},indent=2))
if __name__=="__main__":main()
