#!/usr/bin/env python3
"""Materialize pre-holdout predictions selected by D13/D14."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, seal, write_json


EXPECTED_WRITER = {
    "source_a": {"1": 0, "131": -1, "326": -2, "521": -3, "523": -2, "716": -3, "911": -4, "1024": -4, "1106": -5, "1301": -6, "1305": -5, "1496": -6, "1691": -7, "1886": -8, "2048": -8},
    "source_b": {"1": 0, "131": 1, "326": 2, "521": 3, "523": 2, "716": 3, "911": 4, "1024": 4, "1106": 5, "1301": 6, "1305": 5, "1496": 6, "1691": 7, "1886": 8, "2048": 8},
    "both": {str(t): 0 for t in (1, 131, 326, 521, 523, 716, 911, 1024, 1106, 1301, 1305, 1496, 1691, 1886, 2048)},
    "none": {str(t): 0 for t in (1, 131, 326, 521, 523, 716, 911, 1024, 1106, 1301, 1305, 1496, 1691, 1886, 2048)},
}


def main():
    d13 = json.loads((ROOT / "MECHANISM_SELECTION/ING03_D13_WRITER_FRAME_PANEL.json").read_text(encoding="utf-8"))
    d14 = json.loads((ROOT / "MECHANISM_SELECTION/ING03_D14_MAGNITUDE_FRAME_PANEL.json").read_text(encoding="utf-8"))
    if d13["summary"] != {"worlds": 192, "exact": 192}:
        raise RuntimeError("D13 model-selection panel is not exact")
    if d14["summary"] != {"worlds": 240, "exact": 240}:
        raise RuntimeError("D14 model-selection panel is not exact")
    payload = seal({
        "schema": "dee.v27.ing03.freeze.predictions.v1",
        "phase": "FROZEN_BEFORE_FRESH_CHALLENGE_GENERATION",
        "writer_expected_delta_by_tick": EXPECTED_WRITER,
        "magnitude_class_signatures": d14["representative_signatures"],
        "recovery_predictions": {
            "treatment_modes": ["source_a", "source_b"],
            "success_rule": "configured functional sign returns within 3072 post-perturbation ticks",
            "canary_modes": ["none", "both", "source_a_cut"],
            "canary_rule": "configured functional sign must not return within 3072 post-perturbation ticks",
            "scope": "functional sign class only; not exact value or microstate restoration",
        },
        "model_selection_sources": {
            "D13_content_sha256": d13["content_sha256"],
            "D14_content_sha256": d14["content_sha256"],
        },
    })
    out = ROOT / "FREEZE/ING03_FROZEN_PREDICTIONS.json"
    write_json(out, payload)
    print(json.dumps({"output": str(out), "content_sha256": payload["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
