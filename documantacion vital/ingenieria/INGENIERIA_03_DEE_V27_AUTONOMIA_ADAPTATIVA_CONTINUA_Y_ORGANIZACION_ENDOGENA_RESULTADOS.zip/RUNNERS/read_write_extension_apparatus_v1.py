#!/usr/bin/env python3
"""Selected read/write-compatibility apparatuses for extension validation."""
from __future__ import annotations

import hashlib
import json
import numpy as np

from ing03_common import NativeWorld,add,pack,read,transform,unpack_scalar

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))
PROBES={"INFORMATIVE_BLOCKING":{"target":"c","direction":(0,0,-1),"distance":3,"sreg":7,"phase":0},"WRITABLE_UNINFORMATIVE":{"target":"c","direction":(-1,0,0),"distance":3,"sreg":7,"phase":0}}

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def build_probe(kernel,spec,delta,with_probe):
    n=int(spec["n"]);c=tuple(spec["origin"]);p=tuple(spec.get("permutation",(0,1,2)));s=tuple(spec.get("signs",(1,1,1)));tf=lambda v:transform(v,p,s)
    a=add(c,tf((-1,0,0)),1,n);b=add(c,tf((1,0,0)),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);fixed={a,b}
    put(raw,clock,a,1000,100+delta,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):q=add(a,tf(o),1,n);put(raw,clock,q,3000+i,0,semantic=4,phase=31+i);fixed.add(q)
    for i,o in enumerate(PB):q=add(b,tf(o),1,n);put(raw,clock,q,4000+i,0,semantic=4,phase=41+i);fixed.add(q)
    event=add(b,tf((0,-1,0)),1,n);writer=add(event,tf((0,0,1)),-3,n);put(raw,clock,writer,5000,0,tf((0,0,1)),4,0);fixed.add(writer)
    probe_q=None
    if with_probe:
        pr=PROBES[spec["probe_kind"]];direction=tf(pr["direction"]);probe_q=add(c,direction,-pr["distance"],n);put(raw,clock,probe_q,7001,pr["sreg"],direction,1,pr["phase"])
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"probe":probe_q,"fixed":fixed}

def delta(world,ports):
    a,b=read(world.raw,ports["a"]),read(world.raw,ports["b"]);return None if a is None or b is None else a["sreg"]-b["sreg"]

def run_probe_class(kernel,spec):
    outputs=[]
    for initial_delta in (-8,0,8):
        base,pb=build_probe(kernel,spec,initial_delta,False);world,p=build_probe(kernel,spec,initial_delta,True);h=hashlib.sha256();ds=[];bds=[];external_count=0
        for tick in range(1,1025):
            base.tick();world.tick();ds.append(delta(world,p));bds.append(delta(base,pb))
            if tick<=16:
                diff=[]
                for row in np.argwhere(world.raw!=base.raw):
                    q=tuple(int(x) for x in row)
                    if q not in p["fixed"]:diff.append((q,int(world.raw[q]),int(base.raw[q])))
                external_count+=len(diff);h.update(json.dumps(diff,sort_keys=True,separators=(",",":")).encode())
        trans=sum(ds[i]!=ds[i-1] for i in range(16,len(ds)));btrans=sum(bds[i]!=bds[i-1] for i in range(16,len(bds)))
        outputs.append({"initial_delta":initial_delta,"signature_sha256":h.hexdigest(),"external_difference_events":external_count,"post16_delta_transitions":trans,"baseline_post16_delta_transitions":btrans,"future_writable":trans>=max(1,btrans-2),"terminal_delta":ds[-1],"baseline_terminal_delta":bds[-1]})
    unique=len(set(x["signature_sha256"] for x in outputs));kind=spec["probe_kind"]
    return {"spec":spec,"outputs":outputs,"distinct_signatures":unique,"all_future_writable":all(x["future_writable"] for x in outputs),"prediction_pass":(unique==3 and not any(x["future_writable"] for x in outputs)) if kind=="INFORMATIVE_BLOCKING" else (unique==1 and all(x["future_writable"] for x in outputs)),"python_interventions_after_t0":0}
