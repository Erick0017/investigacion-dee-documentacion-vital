#!/usr/bin/env python3
"""Frozen-candidate recurrent relational writer and functional-regime apparatus."""
from __future__ import annotations

import numpy as np

from ing03_common import NativeWorld, add, pack, read, transform

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))
CHECK_TICKS=(1,131,326,521,523,716,911,1024,1106,1301,1305,1496,1691,1886,2048)
EXPECTED_2048={"source_a":-8,"source_b":8,"both":0,"none":0}


def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)


def construct(kernel,spec):
    n=int(spec["n"]);origin=tuple(spec["origin"]);perm=tuple(spec.get("permutation",(0,1,2)));signs=tuple(spec.get("signs",(1,1,1)));tf=lambda v:transform(v,perm,signs)
    axis=tf((1,0,0));da=n//2-n//3;db=2*n//3-n//2;a=add(origin,axis,-da,n);b=add(origin,axis,db,n)
    raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    for center,base in ((a,1000),(b,2000)):
        put(raw,clock,center,base,100,semantic=1,phase=260)
        for i,o in enumerate(SUPPORT):put(raw,clock,add(center,tf(o),1,n),base+100+i,0,semantic=4,phase=31+i)
    mode=spec["mode"];sources=[]
    def source(center,state):
        event=add(center,tf((0,-1,0)),1,n);direction=tf((0,0,1));q=add(event,direction,-3,n);put(raw,clock,q,state,0,direction,4,0);sources.append(q)
    if mode in {"source_a","source_a_cut","both"}:source(a,5000)
    if mode in {"source_b","both"}:source(b,6000)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"sources":sources,"axis":axis}


def delta(world,ports):
    a,b=read(world.raw,ports["a"]),read(world.raw,ports["b"]);return None if a is None or b is None else a["sreg"]-b["sreg"]


def run_writer_case(kernel,spec):
    world,p=construct(kernel,spec);h=int(spec.get("horizon",2048));source0=[int(world.raw[q]) for q in p["sources"]];trace=[]
    for tick in range(1,h+1):
        world.tick()
        if tick in CHECK_TICKS or tick==h:trace.append({"tick":tick,"delta":delta(world,p),"a":read(world.raw,p["a"]),"b":read(world.raw,p["b"]),"support":int(np.count_nonzero(world.raw))})
    return {"spec":spec,"trace":trace,"source_raw_fixed":all(int(world.raw[q])==v for q,v in zip(p["sources"],source0)),"python_interventions_after_t0":0}


def run_recovery_case(kernel,spec):
    world,p=construct(kernel,spec);pre=int(spec.get("pre_ticks",2048));post=int(spec.get("post_ticks",3072));mode=spec["mode"]
    for _ in range(pre):world.tick()
    before=delta(world,p);ra,rb=read(world.raw,p["a"]),read(world.raw,p["b"]);target=-1 if mode.startswith("source_a") else 1
    magnitude=int(spec.get("damage_magnitude",8))
    if target<0:new_a,new_b=rb["sreg"]+magnitude,rb["sreg"]
    else:new_a,new_b=ra["sreg"],ra["sreg"]+magnitude
    for q,old,value in ((p["a"],ra,new_a),(p["b"],rb,new_b)):
        raw=pack(old["state"],value,tuple(old["direction"]),old["semantic"]);world.raw_a[q]=raw;world.raw_b[q]=raw
    if mode=="source_a_cut":
        for q in p["sources"]:world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
    immediately=delta(world,p);first_return=None;trace=[]
    for tick in range(1,post+1):
        world.tick();d=delta(world,p)
        if d is not None and ((target<0 and d<0) or (target>0 and d>0)) and first_return is None:first_return=tick
        if tick in (1,64,256,512,1024,2048,2178,3072) or tick==first_return:trace.append({"post_tick":tick,"delta":d,"a":read(world.raw,p["a"]),"b":read(world.raw,p["b"])})
    return {"spec":spec,"delta_before":before,"delta_after_damage":immediately,"target_sign":target,"first_functional_return":first_return,"trace":trace,"python_interventions":{"after_t0":1,"role":"predeclared direct perturbation only","after_damage":0}}
