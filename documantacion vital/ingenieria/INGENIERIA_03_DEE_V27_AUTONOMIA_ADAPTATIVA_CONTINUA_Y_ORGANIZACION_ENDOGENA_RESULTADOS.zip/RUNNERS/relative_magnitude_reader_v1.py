#!/usr/bin/env python3
"""Native five-class relational magnitude reader, normalized to a local frame."""
from __future__ import annotations

import numpy as np

from ing03_common import NativeWorld,add,pack,read,transform

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def inverse(direction,permutation,signs):
    original=[0,0,0]
    for i,j in enumerate(permutation):original[j]=int(signs[i])*int(direction[i])
    return original

def expected_class(delta):
    if delta<0:return "NEGATIVE"
    if delta==0:return "ZERO"
    if delta<=6:return "POSITIVE_1_TO_6"
    if delta==7:return "POSITIVE_7"
    return "POSITIVE_8_PLUS"

def run_case(kernel,spec):
    n=int(spec["n"]);c=tuple(spec["origin"]);p=tuple(spec.get("permutation",(0,1,2)));s=tuple(spec.get("signs",(1,1,1)));tf=lambda v:transform(v,p,s);d=int(spec["delta"])
    a=add(c,tf((-1,0,0)),1,n);b=add(c,tf((1,0,0)),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100+d,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,tf(o),1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,tf(o),1,n),4000+i,0,semantic=4,phase=41+i)
    source=add(c,tf((0,-2,0)),1,n);put(raw,clock,source,6000,7,tf((0,1,0)),4,23)
    world=NativeWorld(kernel,raw,clock);trace=[]
    for tick in range(1,17):
        world.tick();rc=read(world.raw,c)
        trace.append({"tick":tick,"comparator":rc,"normalized_direction":None if rc is None else inverse(rc["direction"],p,s)})
    signature=[None if r["comparator"] is None else [r["comparator"]["state"],r["comparator"]["sreg"],r["normalized_direction"],r["comparator"]["semantic"]] for r in trace]
    return {"spec":spec,"expected_class":expected_class(d),"signature":signature,"trace":trace,"python_interventions_after_t0":0}
