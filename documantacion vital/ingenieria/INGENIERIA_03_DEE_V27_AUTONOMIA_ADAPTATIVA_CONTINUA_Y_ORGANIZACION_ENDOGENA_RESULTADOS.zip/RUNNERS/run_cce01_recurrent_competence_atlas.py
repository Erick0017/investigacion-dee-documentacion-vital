#!/usr/bin/env python3
"""Dense adaptive cartography of recurrent susceptibility without assuming a clock."""
from __future__ import annotations

import hashlib
import json
import math
import sys
from collections import deque
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, read, seal, sha256_file, unpack_scalar, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE01_RECURRENT_COMPETENCE_ATLAS.json"
ATLAS = ROOT / "ING03_RECURRENT_COMPETENCE_ATLAS.json"
PREDICTOR = ROOT / "ING03_COMPETENCE_WINDOW_PREDICTOR.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA03_DEVELOPMENTAL_CYCLE_MAP.json"
DISCOVERY_TICKS = tuple(sorted(set(
    set(range(32, 417, 16))
    | set(range(576, 1089, 32))
    | set(range(1408, 1665, 32))
    | {1728, 1792, 1856, 1920, 1984, 2048}
)))
HOLDOUT_TICKS = (55, 71, 119, 135, 183, 199, 247, 263, 311, 327, 383, 399,
                 639, 767, 895, 1023, 1535, 1791)
S0_HORIZON = 128
S1_HORIZON = 128
S1_TAIL = 64
PERIODS = (195, 260, 391, 782)


def torus_offset_grid(n: int, center: tuple[int, int, int], radius: int):
    values = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                values.append(((center[0] + dx) % n, (center[1] + dy) % n, (center[2] + dz) % n))
    return values


def array_digest(values) -> str:
    return hashlib.sha256(np.ascontiguousarray(values).tobytes()).hexdigest()


def local_features(world: NativeWorld, meta: dict, node: dict, tick: int, history: deque) -> dict:
    n = meta["n"]
    center = node["center"]
    result = {"tick": tick, "node_id": node["id"], "frame": node["frame"],
              "node_delta": r09.delta(world, node), "writer_occupied": int(world.raw[node["writer_q"]] != 0)}
    for label, q in (("a", node["a"]), ("b", node["b"]), ("writer", node["writer_q"])):
        rec = read(world.raw, q)
        result[f"{label}_present"] = int(rec is not None)
        result[f"{label}_sreg"] = -1 if rec is None else rec["sreg"]
        result[f"{label}_semantic"] = -1 if rec is None else rec["semantic"]
        result[f"{label}_clock"] = int(world.clock_a[q])
        result[f"{label}_raw"] = int(world.raw_a[q])
        for period in PERIODS:
            result[f"{label}_clock_mod_{period}"] = int(world.clock_a[q] % period)
    for radius in (1, 2, 4, 6):
        positions = torus_offset_grid(n, center, radius)
        raw = np.asarray([world.raw[q] for q in positions], dtype=np.uint64)
        clocks = np.asarray([world.clock_a[q] for q in positions], dtype=np.uint64)
        occupied = raw != 0
        semantics = ((raw >> np.uint64(60)) & np.uint64(0xF)).astype(np.uint8)
        sregs = ((raw >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.uint64)
        result[f"r{radius}_support"] = int(np.count_nonzero(occupied))
        result[f"r{radius}_semantic1"] = int(np.count_nonzero(occupied & (semantics == 1)))
        result[f"r{radius}_semantic4"] = int(np.count_nonzero(occupied & (semantics == 4)))
        result[f"r{radius}_sreg_sum"] = int(sregs[occupied].sum(dtype=np.uint64))
        result[f"r{radius}_clock_sum_mod_304980"] = int(clocks[occupied].sum(dtype=np.uint64) % 304980)
        result[f"r{radius}_raw_sha256"] = array_digest(raw)
        result[f"r{radius}_r0_sha256"] = array_digest(np.stack((raw, clocks), axis=1))
    result["tick_mod_195"] = tick % 195
    result["tick_mod_260"] = tick % 260
    result["tick_mod_391"] = tick % 391
    result["tick_mod_782"] = tick % 782
    hist = list(history)
    for width in (8, 16, 32, 64):
        suffix = hist[-width:]
        result[f"history_delta_changes_{width}"] = sum(
            suffix[i] != suffix[i - 1] for i in range(1, len(suffix))
        )
        result[f"history_distinct_delta_{width}"] = len(set(suffix))
    return result


def set_writer(world: NativeWorld, node: dict, tick: int, treatment: bool) -> None:
    q = node["writer_q"]
    for raw in (world.raw_a, world.raw_b):
        raw[q] = np.uint64(node["writer_raw"] if treatment else 0)
    for clock in (world.clock_a, world.clock_b):
        clock[q] = np.uint64(tick)


def adaptive_assay(kernel, base: NativeWorld, meta: dict, node: dict, tick: int) -> dict:
    treatment = NativeWorld(kernel, base.raw_a, base.clock_a)
    control = NativeWorld(kernel, base.raw_a, base.clock_a)
    set_writer(treatment, node, tick, True); set_writer(control, node, tick, False)
    node_diff, pair_diff, core_diff, world_diff = [], [], [], []
    response = False
    latency = 0
    while latency < S0_HORIZON:
        latency += 1; treatment.tick(); control.tick()
        nd = r09.delta(treatment, node) != r09.delta(control, node)
        node_diff.append(nd)
        pair_diff.append(pair(treatment, meta) != pair(control, meta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, meta))
        world_diff.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if nd and not response:
            response = True
    retained = response and len(node_diff) >= S1_TAIL and all(node_diff[-S1_TAIL:])
    first = next((i + 1 for i, value in enumerate(node_diff) if value), None)
    return {
        "S0_reactivity": response, "S1_retained_change": retained,
        "C2_functional_competence": False,
        "followup_ticks": latency, "first_node_difference_latency": first,
        "node_difference_ticks": int(sum(node_diff)),
        "pair_difference_ticks": int(sum(pair_diff)),
        "core_difference_ticks": int(sum(core_diff)),
        "maximum_world_difference": max(world_diff),
        "terminal_world_difference": world_diff[-1],
        "writer_challenge_ended_at_t0": False,
        "diagnostic_intervention": True,
    }


def balanced_accuracy(y, prediction) -> float:
    pos = [p for a, p in zip(y, prediction) if a]
    neg = [p for a, p in zip(y, prediction) if not a]
    if not pos or not neg:
        return 0.0
    return 0.5 * (sum(pos) / len(pos) + sum(not p for p in neg) / len(neg))


def discover_threshold(rows: list[dict], outcome: str) -> dict:
    y = [bool(row[outcome]) for row in rows]
    excluded = {"tick", "node_id"}
    keys = sorted(k for k, v in rows[0]["features"].items()
                  if k not in excluded and isinstance(v, (int, float)) and not isinstance(v, bool))
    best = {"balanced_accuracy": 0.0}
    for key in keys:
        values = [float(row["features"][key]) for row in rows]
        unique = sorted(set(values))
        if len(unique) < 2 or len(unique) > 200:
            continue
        cuts = [(a + b) / 2.0 for a, b in zip(unique, unique[1:])]
        for cut in cuts:
            for polarity in ("le", "gt"):
                prediction = [(v <= cut) if polarity == "le" else (v > cut) for v in values]
                score = balanced_accuracy(y, prediction)
                if score > best["balanced_accuracy"]:
                    best = {"feature": key, "threshold": cut, "polarity": polarity,
                            "balanced_accuracy": score,
                            "positive_count": int(sum(y)), "negative_count": len(y) - int(sum(y))}
    return best


def predict(rule: dict, features: dict) -> bool:
    value = float(features[rule["feature"]])
    return value <= rule["threshold"] if rule["polarity"] == "le" else value > rule["threshold"]


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel)
    discovery_node, holdout_node, negative_node = nodes
    needed = set(DISCOVERY_TICKS) | set(HOLDOUT_TICKS)
    snapshots = {}
    histories = {node["id"]: deque(maxlen=64) for node in nodes}
    feature_snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        for node in nodes:
            histories[node["id"]].append(r09.delta(base, node))
        if tick in needed:
            snapshots[tick] = NativeWorld(kernel, base.raw_a, base.clock_a)
            for node in nodes:
                feature_snapshots[(tick, node["id"])] = local_features(base, meta, node, tick, histories[node["id"]])

    discovery = []
    for tick in DISCOVERY_TICKS:
        outcome = adaptive_assay(kernel, snapshots[tick], meta, discovery_node, tick)
        row = {"tick": tick, "node_id": discovery_node["id"], "frame": discovery_node["frame"],
               "features": feature_snapshots[(tick, discovery_node["id"])], **outcome}
        discovery.append(row)
        print(json.dumps({"set": "discovery", "tick": tick, "S0": row["S0_reactivity"],
                          "S1": row["S1_retained_change"], "followup": row["followup_ticks"]}), flush=True)

    s0_rule = discover_threshold(discovery, "S0_reactivity")
    s1_rule = discover_threshold(discovery, "S1_retained_change")
    holdout = []
    for tick in HOLDOUT_TICKS:
        for node in (holdout_node, negative_node):
            outcome = adaptive_assay(kernel, snapshots[tick], meta, node, tick)
            features = feature_snapshots[(tick, node["id"])]
            row = {"tick": tick, "node_id": node["id"], "frame": node["frame"],
                   "features": features, **outcome,
                   "predicted_S0": predict(s0_rule, features) if s0_rule.get("feature") else False,
                   "predicted_S1": predict(s1_rule, features) if s1_rule.get("feature") else False}
            holdout.append(row)
            print(json.dumps({"set": "holdout", "tick": tick, "node": node["id"],
                              "S0": row["S0_reactivity"], "S1": row["S1_retained_change"],
                              "p0": row["predicted_S0"], "p1": row["predicted_S1"]}), flush=True)

    node2 = [row for row in holdout if row["node_id"] == holdout_node["id"]]
    node3 = [row for row in holdout if row["node_id"] == negative_node["id"]]
    s0_holdout_ba = balanced_accuracy([r["S0_reactivity"] for r in node2], [r["predicted_S0"] for r in node2])
    s1_holdout_ba = balanced_accuracy([r["S1_retained_change"] for r in node2], [r["predicted_S1"] for r in node2])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.recurrent_competence_atlas.v1",
        "question": "Which accessible state/history conditions predict recurring S0/S1 susceptibility in the RCA03 organization?",
        "planning": {"mechanism": "adaptive exact-writer diagnostic around open/closed transitions",
                     "controls": ["matched no-writer", "unseen frame node2", "negative region node3", "short followup for S0 nulls"],
                     "predicted_outcomes": ["clock-only", "current-organization", "history-dependent", "no stable predictor"],
                     "estimated_runtime_minutes": 8, "stop_condition": "discovery grid plus 36 reserved node/time assays"},
        "definitions": {
            "S0": "writer-specific node response within the frozen 128-tick causal horizon",
            "S1": "writer-specific node distinction throughout the final 64 of 128 ticks",
            "C2": "retained experience alters later independent frozen function; not assayed here",
            "X_FULL_accessible": "not directly exposed by the binary API; trajectory is observed but cannot be cloned as hidden state",
            "R0_proxy": "current raw_a plus clock_a, the reproducibly clonable public state",
        },
        "design": {"discovery_ticks": list(DISCOVERY_TICKS), "holdout_ticks": list(HOLDOUT_TICKS),
                   "discovery_node": discovery_node["id"], "holdout_node": holdout_node["id"],
                   "negative_node": negative_node["id"], "s0_horizon": S0_HORIZON,
                   "s1_horizon": S1_HORIZON, "s1_tail": S1_TAIL,
                   "python_interventions_after_snapshot": "DIAGNOSTIC_INTERVENTION only"},
        "discovery_rows": discovery, "holdout_rows": holdout,
        "predictors": {"S0": s0_rule, "S1": s1_rule},
        "summary": {
            "discovery_assays": len(discovery), "holdout_assays": len(holdout),
            "discovery_S0_positive": sum(r["S0_reactivity"] for r in discovery),
            "discovery_S1_positive": sum(r["S1_retained_change"] for r in discovery),
            "node2_holdout_S0_balanced_accuracy": s0_holdout_ba,
            "node2_holdout_S1_balanced_accuracy": s1_holdout_ba,
            "node3_S0_positive": sum(r["S0_reactivity"] for r in node3),
            "node3_S1_positive": sum(r["S1_retained_change"] for r in node3),
            "predictor_fresh_confirmed": s0_holdout_ba == 1.0 and s1_holdout_ba == 1.0,
            "causal_predictor_demonstrated": False,
            "C2_competence_demonstrated": False,
            "periodicity_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "status": "DIAGNOSTIC_PREDICTOR_DISCOVERY",
        "claim_guard": "Threshold discovery is offline diagnosis. Fresh frame performance is not causal validation, origin/N generalization, C2 competence or a clock/limit-cycle claim.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    atlas = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "predictors")})
    atlas["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix()
    write_json(ATLAS, atlas)
    predictor = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.competence_predictor.v1",
        "status": "DIAGNOSTIC_ONLY", "predictors": result["predictors"],
        "fresh_frame_results": {"node2_S0_balanced_accuracy": s0_holdout_ba,
                                "node2_S1_balanced_accuracy": s1_holdout_ba,
                                "node3_S0_positive": sum(r["S0_reactivity"] for r in node3)},
        "causal_validation_required": True, "origin_generalization_tested": False,
        "N_generalization_tested": False, "C2_predictor": None,
        "source_evidence": OUTPUT.relative_to(ROOT).as_posix(),
        "source_file_sha256": sha256_file(OUTPUT),
    })
    write_json(PREDICTOR, predictor)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "S0_rule": s0_rule, "S1_rule": s1_rule,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
