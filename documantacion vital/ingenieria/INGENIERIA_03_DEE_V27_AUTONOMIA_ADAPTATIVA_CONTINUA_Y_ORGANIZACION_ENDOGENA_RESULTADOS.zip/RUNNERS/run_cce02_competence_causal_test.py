#!/usr/bin/env python3
"""Causal transplantation between competence-open and competence-closed windows."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce01_recurrent_competence_atlas as cce01
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE02_COMPETENCE_CAUSAL_TEST.json"
REPORT = ROOT / "ING03_COMPETENCE_CAUSAL_TEST.json"
PREDICTOR = ROOT / "ING03_COMPETENCE_WINDOW_PREDICTOR.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE01_RECURRENT_COMPETENCE_ATLAS.json"
PAIRS = ((128, 144), (320, 336), (704, 736), (896, 928), (1472, 1504), (1536, 1568))
RADII = (0, 2, 6)
COMPONENTS = ("CLOCK", "RAW", "R0")


def domain(node: dict, n: int, radius: int):
    if radius == 0:
        return rca05.node_positions(node, n)
    positions = set()
    for origin in (node["a"], node["b"], node["center"]):
        positions.update(cce01.torus_offset_grid(n, origin, radius))
    return sorted(positions)


def clone(kernel, source: NativeWorld) -> NativeWorld:
    return NativeWorld(kernel, source.raw, source.clock_a)


def transplant(kernel, target: NativeWorld, donor: NativeWorld, positions, component: str) -> NativeWorld:
    result = clone(kernel, target)
    for q in positions:
        if component in ("RAW", "R0"):
            result.raw_a[q] = donor.raw_a[q]; result.raw_b[q] = donor.raw_a[q]
        if component in ("CLOCK", "R0"):
            result.clock_a[q] = donor.clock_a[q]; result.clock_b[q] = donor.clock_a[q]
    return result


def assay(kernel, world, meta, node, tick):
    row = cce01.adaptive_assay(kernel, world, meta, node, tick)
    return {"S0": row["S0_reactivity"], "S1": row["S1_retained_change"],
            "first_latency": row["first_node_difference_latency"],
            "pair_difference_ticks": row["pair_difference_ticks"],
            "maximum_world_difference": row["maximum_world_difference"]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel); node = nodes[0]
    needed = {tick for pair in PAIRS for tick in pair}; snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        if tick in needed:
            snapshots[tick] = clone(kernel, base)
    rows = []
    for open_tick, closed_tick in PAIRS:
        open_base = assay(kernel, snapshots[open_tick], meta, node, open_tick)
        closed_base = assay(kernel, snapshots[closed_tick], meta, node, closed_tick)
        rows.append({"pair": [open_tick, closed_tick], "mode": "BASELINE_OPEN", "radius": None,
                     "component": None, "result": open_base})
        rows.append({"pair": [open_tick, closed_tick], "mode": "BASELINE_CLOSED", "radius": None,
                     "component": None, "result": closed_base})
        print(json.dumps({"pair": [open_tick, closed_tick], "baseline_open": open_base,
                          "baseline_closed": closed_base}, sort_keys=True), flush=True)
        for radius in RADII:
            positions = domain(node, meta["n"], radius)
            for component in COMPONENTS:
                open_from_closed = transplant(kernel, snapshots[open_tick], snapshots[closed_tick], positions, component)
                closed_from_open = transplant(kernel, snapshots[closed_tick], snapshots[open_tick], positions, component)
                out_open = assay(kernel, open_from_closed, meta, node, open_tick)
                out_closed = assay(kernel, closed_from_open, meta, node, closed_tick)
                rows.append({"pair": [open_tick, closed_tick], "mode": "OPEN_RECEIVES_CLOSED",
                             "radius": radius, "component": component,
                             "position_count": len(positions), "result": out_open})
                rows.append({"pair": [open_tick, closed_tick], "mode": "CLOSED_RECEIVES_OPEN",
                             "radius": radius, "component": component,
                             "position_count": len(positions), "result": out_closed})
                print(json.dumps({"pair": [open_tick, closed_tick], "r": radius,
                                  "component": component, "open_from_closed": out_open,
                                  "closed_from_open": out_closed}, sort_keys=True), flush=True)

    baseline_valid = 0
    for pair in PAIRS:
        op = next(r for r in rows if r["pair"] == list(pair) and r["mode"] == "BASELINE_OPEN")
        cl = next(r for r in rows if r["pair"] == list(pair) and r["mode"] == "BASELINE_CLOSED")
        baseline_valid += int(op["result"]["S1"] and not cl["result"]["S1"])
    adjudication = []
    for radius in RADII:
        for component in COMPONENTS:
            subset = [r for r in rows if r.get("radius") == radius and r.get("component") == component]
            loses = sum(r["mode"] == "OPEN_RECEIVES_CLOSED" and not r["result"]["S1"] for r in subset)
            gains = sum(r["mode"] == "CLOSED_RECEIVES_OPEN" and r["result"]["S1"] for r in subset)
            bidirectional = sum(
                not next(r for r in subset if r["pair"] == list(pair) and r["mode"] == "OPEN_RECEIVES_CLOSED")["result"]["S1"]
                and next(r for r in subset if r["pair"] == list(pair) and r["mode"] == "CLOSED_RECEIVES_OPEN")["result"]["S1"]
                for pair in PAIRS
            )
            adjudication.append({"radius": radius, "component": component,
                                 "open_loses_S1": loses, "closed_gains_S1": gains,
                                 "bidirectional_transfers": bidirectional,
                                 "full_transfer": bidirectional == len(PAIRS)})
    full = [r for r in adjudication if r["full_transfer"]]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.competence_causal_test.v1",
        "question": "Does raw organization, clock phase, or their R0 conjunction causally transfer S1 competence between matched open/closed windows?",
        "planning": {"mechanism": "diagnostic component transplantation in increasing local domains",
                     "controls": ["unmodified open/closed baselines", "clock-only", "raw-only", "joint R0", "six temporal pairs"],
                     "predicted_outcomes": ["clock causal", "raw causal", "joint organization causal", "history outside domain required"],
                     "estimated_runtime_minutes": 12, "stop_condition": "120 fixed 128-tick paired assays"},
        "design": {"pairs": [list(p) for p in PAIRS], "radii": list(RADII),
                   "components": list(COMPONENTS), "challenge": "same exact-writer assay",
                   "intervention_class": "DIAGNOSTIC_INTERVENTION", "X_FULL_transplantable": False,
                   "R0_transplantable": True},
        "rows": rows, "adjudication": adjudication,
        "summary": {"baseline_valid_pairs": baseline_valid, "pair_count": len(PAIRS),
                    "full_transfer_mechanisms": full,
                    "clock_alone_sufficient": any(r["full_transfer"] and r["component"] == "CLOCK" for r in adjudication),
                    "raw_alone_sufficient": any(r["full_transfer"] and r["component"] == "RAW" for r in adjudication),
                    "R0_local_sufficient": any(r["full_transfer"] and r["component"] == "R0" for r in adjudication),
                    "causal_predictor_demonstrated": bool(full) and baseline_valid == len(PAIRS),
                    "C2_competence_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_CAUSAL_TRANSFER" if full else "UNRESOLVED_CAUSAL_GENERATOR",
        "claim_guard": "Component transplantation tests accessible R0 causality only. It cannot transplant hidden history/X_FULL and does not establish C2 or native environmental capture.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix()
    report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    predictor = json.loads(PREDICTOR.read_text(encoding="utf-8"))
    predictor["causal_test"] = {"path": OUTPUT.relative_to(ROOT).as_posix(),
                                "file_sha256": sha256_file(OUTPUT),
                                "result": result["summary"]}
    predictor["status"] = "CAUSAL_COMPONENT_IDENTIFIED" if full else "DIAGNOSTIC_CORRELATE_NOT_CAUSALLY_RESOLVED"
    predictor.pop("content_sha256", None); predictor.pop("created_utc", None)
    write_json(PREDICTOR, seal(predictor))
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "adjudication": adjudication, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
