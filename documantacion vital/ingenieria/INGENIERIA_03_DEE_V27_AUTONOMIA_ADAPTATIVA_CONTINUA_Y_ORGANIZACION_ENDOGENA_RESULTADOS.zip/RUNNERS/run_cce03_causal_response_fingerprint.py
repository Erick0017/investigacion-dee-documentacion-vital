#!/usr/bin/env python3
"""Multi-challenge S0/S1/C2 response-fingerprint panel for recurrent windows."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n04_dynamic_temporal_expression import PA
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE03_CAUSAL_RESPONSE_FINGERPRINT.json"
REPORT = ROOT / "ING03_CAUSAL_RESPONSE_FINGERPRINT.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE02_COMPETENCE_CAUSAL_TEST.json"
WINDOWS = ((128, "OPEN"), (144, "CLOSED"), (320, "OPEN"), (336, "CLOSED"))
MODES = ("SEM4_WRITER", "SEM1_WRITER", "SEM1_REVERSE", "CLOCK_SHIFT_A",
         "SUPPORT_ABLATION", "TWO_PARENT_D12")
ENCODING_HORIZON = 160
RETENTION = 64
PROBE_HORIZON = 128
CHECKPOINTS = (1, 2, 4, 8, 16, 32, 64, 96, 128)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install(world, meta, node, mode, tick):
    markers = []
    if mode == "SEM4_WRITER":
        set_both(world, node["writer_q"], node["writer_raw"], tick)
        markers.append(25000 + node["id"])
    elif mode in ("SEM1_WRITER", "SEM1_REVERSE"):
        route = r09.transform((0, 0, 1), node["frame"])
        if mode == "SEM1_REVERSE": route = tuple(-value for value in route)
        state = 73001 if mode == "SEM1_WRITER" else 73002
        set_both(world, node["writer_q"], int(pack(state, 0, route, 1)), tick); markers.append(state)
    elif mode == "CLOCK_SHIFT_A":
        for clock in (world.clock_a, world.clock_b): clock[node["a"]] += np.uint64(37)
    elif mode == "SUPPORT_ABLATION":
        q = add(node["a"], r09.transform(PA[0], node["frame"]), 1, meta["n"])
        set_both(world, q, 0, 0)
    elif mode == "TWO_PARENT_D12":
        info = rca06.install_generator(world, meta, node, 12, False, 73100)
        markers.extend([73100, 73101]); return {"mode": mode, "generator": info, "marker_states": markers}
    return {"mode": mode, "marker_states": markers}


def marker_count(world, states):
    if not states: return 0
    state = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(state == value) for value in states))


def diff_digest(a: NativeWorld, b: NativeWorld) -> str:
    h = hashlib.sha256(); h.update(np.bitwise_xor(a.raw, b.raw).tobytes())
    h.update(np.bitwise_xor(a.clock_a, b.clock_a).tobytes()); return h.hexdigest()


def install_probe(world, node, tick, enabled):
    q = node["writer_q"]
    set_both(world, q, node["writer_raw"] if enabled else 0, tick)


def probe_fingerprint(kernel, experienced, control, meta, node, tick):
    ep, en = clone(kernel, experienced), clone(kernel, experienced)
    cp, cn = clone(kernel, control), clone(kernel, control)
    for world, enabled in ((ep, True), (en, False), (cp, True), (cn, False)):
        install_probe(world, node, tick, enabled)
    rows = []
    effect_exp = []; effect_control = []
    pair_effect_exp = []; pair_effect_control = []
    for latency in range(1, PROBE_HORIZON + 1):
        for world in (ep, en, cp, cn): world.tick()
        effect_exp.append(diff_digest(ep, en)); effect_control.append(diff_digest(cp, cn))
        pair_effect_exp.append(pair(ep, meta) != pair(en, meta))
        pair_effect_control.append(pair(cp, meta) != pair(cn, meta))
        if latency in CHECKPOINTS:
            rows.append({"latency": latency,
                         "experienced_probe_effect_sha256": effect_exp[-1],
                         "control_probe_effect_sha256": effect_control[-1],
                         "effects_equal": effect_exp[-1] == effect_control[-1],
                         "experienced_pair_effect": pair_effect_exp[-1],
                         "control_pair_effect": pair_effect_control[-1],
                         "experienced_node_probe": r09.delta(ep, node),
                         "experienced_node_no_probe": r09.delta(en, node),
                         "control_node_probe": r09.delta(cp, node),
                         "control_node_no_probe": r09.delta(cn, node)})
    different = any(a != b for a, b in zip(effect_exp, effect_control))
    functional_pair_interaction = any(a != b for a, b in zip(pair_effect_exp, pair_effect_control))
    return {"response_fingerprint_differs": different,
            "shared_pair_response_differs": functional_pair_interaction,
            "checkpoint_rows": rows}


def run(kernel, snapshot, meta, node, tick, label, mode):
    treatment, control = clone(kernel, snapshot), clone(kernel, snapshot)
    record = install(treatment, meta, node, mode, tick)
    node_diff = []; pair_diff = []; core_diff = []; markers = []
    for latency in range(1, ENCODING_HORIZON + 1):
        treatment.tick(); control.tick()
        node_diff.append(r09.delta(treatment, node) != r09.delta(control, node))
        pair_diff.append(pair(treatment, meta) != pair(control, meta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, meta))
        markers.append(marker_count(treatment, record["marker_states"]))
    S0 = any(node_diff)
    S1 = all(node_diff[-RETENTION:])
    episode_ended = not record["marker_states"] or all(value == 0 for value in markers[-RETENTION:])
    probe = probe_fingerprint(kernel, treatment, control, meta, node, tick + ENCODING_HORIZON)
    C2 = S1 and episode_ended and probe["response_fingerprint_differs"]
    return {"tick": tick, "window_label": label, "node_id": node["id"], "mode": mode,
            "challenge_record": record, "S0_reactivity": S0, "S1_retained_change": S1,
            "episode_ended_last64": episode_ended,
            "marker_count_terminal": markers[-1],
            "pair_difference_during_encoding": any(pair_diff),
            "core_difference_during_encoding": any(core_diff),
            "frozen_probe": probe, "C2_response_fingerprint": C2,
            "C2_shared_pair_function": C2 and probe["shared_pair_response_differs"],
            "intervention_class": "DIAGNOSTIC_INTERVENTION",
            "python_interventions_after_snapshot": 2}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel); needed = {tick for tick, _ in WINDOWS}; snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        if tick in needed: snapshots[tick] = clone(kernel, base)
    rows = []
    for tick, label in WINDOWS:
        for node in nodes[:2]:
            for mode in MODES:
                try: row = run(kernel, snapshots[tick], meta, node, tick, label, mode)
                except RuntimeError as exc:
                    row = {"tick": tick, "window_label": label, "node_id": node["id"],
                           "mode": mode, "valid": False, "reason": str(exc)}
                else: row["valid"] = True
                rows.append(row)
                print(json.dumps({"tick": tick, "node": node["id"], "mode": mode,
                                  "valid": row["valid"], "S0": row.get("S0_reactivity"),
                                  "S1": row.get("S1_retained_change"),
                                  "ended": row.get("episode_ended_last64"),
                                  "C2": row.get("C2_response_fingerprint")}, sort_keys=True), flush=True)
    valid = [r for r in rows if r.get("valid")]
    by_mode = []
    for mode in MODES:
        subset = [r for r in valid if r["mode"] == mode]
        by_mode.append({"mode": mode,
                        "open_S0": sum(r["S0_reactivity"] for r in subset if r["window_label"] == "OPEN"),
                        "closed_S0": sum(r["S0_reactivity"] for r in subset if r["window_label"] == "CLOSED"),
                        "open_S1": sum(r["S1_retained_change"] for r in subset if r["window_label"] == "OPEN"),
                        "closed_S1": sum(r["S1_retained_change"] for r in subset if r["window_label"] == "CLOSED"),
                        "C2_fingerprint": sum(r["C2_response_fingerprint"] for r in subset),
                        "C2_shared_pair": sum(r["C2_shared_pair_function"] for r in subset)})
    c2 = [r for r in valid if r["C2_response_fingerprint"]]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.causal_response_fingerprint.v1",
        "question": "Do recurrent windows generalize across challenges, and does retained change alter a later independent frozen-probe response?",
        "planning": {"mechanism": "six causally distinct diagnostic experiences plus four-arm frozen probe",
                     "controls": ["open/closed windows", "two frames", "finite marker extinction", "probe/no-probe within experienced/control states"],
                     "predicted_outcomes": ["writer-specific susceptibility", "multi-challenge susceptibility", "S1 only", "C2 response-class change"],
                     "estimated_runtime_minutes": 10, "stop_condition": "48 encoding panels and 192 probe branches"},
        "definitions": {"S0": "challenge-specific node response", "S1": "node distinction retained for final64/160",
                        "C2_fingerprint": "S1 plus ended marker episode plus changed causal response to identical later frozen probe",
                        "C2_shared_pair": "C2 fingerprint also changes the existing shared action pair response"},
        "design": {"windows": [list(x) for x in WINDOWS], "modes": list(MODES),
                   "encoding_horizon": ENCODING_HORIZON, "probe_horizon": PROBE_HORIZON,
                   "diagnostic_only": True},
        "rows": rows, "mode_summary": by_mode,
        "summary": {"valid_panels": len(valid), "S0_positive": sum(r["S0_reactivity"] for r in valid),
                    "S1_positive": sum(r["S1_retained_change"] for r in valid),
                    "C2_fingerprint_candidates": len(c2),
                    "C2_shared_pair_candidates": sum(r["C2_shared_pair_function"] for r in valid),
                    "multi_challenge_C2_demonstrated": len({r["mode"] for r in c2}) >= 2,
                    "native_C2_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_C2_RESPONSE_CLASS" if c2 else "S0_S1_ONLY_NO_C2",
        "claim_guard": "Host-installed challenges/probes establish diagnostic response classes only. External hashes are observers, not DEE effectors; native capture and promoted function remain unproven.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "mode_summary": by_mode, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
