#!/usr/bin/env python3
"""Blind finite environmental planes at competence-open and closed snapshots."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE04_BLIND_ENVIRONMENTAL_EXPOSURE.json"
REPORT_EXPOSURE = ROOT / "ING03_BLIND_ENVIRONMENTAL_EXPOSURE.json"
REPORT_CAPTURE = ROOT / "ING03_ENDOGENOUS_CAPTURE_TEST.json"
REPORT_DIRECT = ROOT / "ING03_DIRECT_PATH_EXCLUSION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE03_CAUSAL_RESPONSE_FINGERPRINT.json"
WINDOWS = ((128, "OPEN"), (144, "CLOSED"), (320, "OPEN"), (336, "CLOSED"))
MODES = (
    {"id": "Z_SEM1", "axis": 2, "sign": 1, "semantic": 1},
    {"id": "X_SEM1", "axis": 0, "sign": 1, "semantic": 1},
    {"id": "Z_REVERSE_SEM1", "axis": 2, "sign": -1, "semantic": 1},
    {"id": "Z_SEM4", "axis": 2, "sign": 1, "semantic": 4},
)
HORIZON = 256
RETENTION = 64
GRID = tuple(range(-20, 21, 4))


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install_plane(world, meta, mode, state_base=74000):
    n = meta["n"]; center = meta["c"]; axis = mode["axis"]
    direction = [0, 0, 0]; direction[axis] = mode["sign"]; direction = tuple(direction)
    fixed = list(center); fixed[axis] = (center[axis] - mode["sign"] * 8) % n
    transverse = [i for i in range(3) if i != axis]
    installed, skipped, states = [], [], []
    for serial, (u, v) in enumerate((u, v) for u in GRID for v in GRID):
        q = list(fixed); q[transverse[0]] = (center[transverse[0]] + u) % n
        q[transverse[1]] = (center[transverse[1]] + v) % n; q = tuple(q)
        if int(world.raw[q]): skipped.append(list(q)); continue
        state = state_base + serial
        raw = int(pack(state, 0, direction, mode["semantic"])); set_both(world, q, raw, 0)
        installed.append({"q": list(q), "state": state}); states.append(state)
    return {"mode": mode, "grid": list(GRID), "plane_offset": -mode["sign"] * 8,
            "installed": installed, "skipped": skipped, "states": states,
            "explicit_recipient": False, "covers_complete_transverse_grid": True}


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def clear_periphery(world, meta, nodes):
    positions = sorted({q for node in nodes for q in rca05.node_positions(node, meta["n"])})
    for q in positions: set_both(world, q, 0, 0)
    return len(positions)


def run(kernel, snapshot, meta, nodes, tick, label, mode, periphery=True):
    treatment, control = clone(kernel, snapshot), clone(kernel, snapshot)
    removed = 0
    if not periphery:
        removed = clear_periphery(treatment, meta, nodes); clear_periphery(control, meta, nodes)
    plane = install_plane(treatment, meta, mode)
    histories = {node["id"]: [] for node in nodes}; pair_diff = []; core_diff = []; markers = []
    world_counts = []
    for latency in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node in nodes:
            histories[node["id"]].append(r09.delta(treatment, node) != r09.delta(control, node))
        pair_diff.append(pair(treatment, meta) != pair(control, meta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, meta))
        markers.append(marker_count(treatment, plane["states"]))
        world_counts.append(int(np.count_nonzero(treatment.raw != control.raw)))
    node_results = []
    for node in nodes:
        values = histories[node["id"]]
        node_results.append({"node_id": node["id"], "S0": any(values),
                             "S1": all(values[-RETENTION:]),
                             "first_difference_latency": next((i + 1 for i, value in enumerate(values) if value), None)})
    episode_ended = all(value == 0 for value in markers[-RETENTION:])
    return {"tick": tick, "window_label": label, "mode": mode["id"], "periphery": periphery,
            "removed_peripheral_positions": removed, "plane": plane, "node_results": node_results,
            "episode_ended_last64": episode_ended, "terminal_marker_count": markers[-1],
            "pair_response": any(pair_diff), "pair_response_retained": all(pair_diff[-RETENTION:]),
            "core_response": any(core_diff), "core_response_retained": all(core_diff[-RETENTION:]),
            "maximum_world_difference": max(world_counts), "terminal_world_difference": world_counts[-1],
            "world_difference_sha256": hashlib.sha256(np.asarray(world_counts, np.int32).tobytes()).hexdigest(),
            "intervention_class": "DIAGNOSTIC_INTERVENTION", "python_interventions_after_snapshot": 1}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel); needed = {tick for tick, _ in WINDOWS}; snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        if tick in needed: snapshots[tick] = clone(kernel, base)
    rows = []
    for tick, label in WINDOWS:
        for mode in MODES:
            row = run(kernel, snapshots[tick], meta, nodes, tick, label, mode, True); rows.append(row)
            print(json.dumps({"tick": tick, "window": label, "mode": mode["id"],
                              "nodes": row["node_results"], "ended": row["episode_ended_last64"],
                              "pair": row["pair_response_retained"]}, sort_keys=True), flush=True)
    for tick, label in (WINDOWS[0], WINDOWS[1]):
        for mode in MODES[:2]:
            row = run(kernel, snapshots[tick], meta, nodes, tick, label, mode, False); rows.append(row)
            print(json.dumps({"tick": tick, "window": label, "mode": mode["id"],
                              "periphery": False, "pair": row["pair_response_retained"]}, sort_keys=True), flush=True)

    capture = []
    for mode in MODES:
        mode_rows = [r for r in rows if r["mode"] == mode["id"] and r["periphery"]]
        for node_id in (1, 2, 3):
            opens = [next(n for n in r["node_results"] if n["node_id"] == node_id)
                     for r in mode_rows if r["window_label"] == "OPEN"]
            closed = [next(n for n in r["node_results"] if n["node_id"] == node_id)
                      for r in mode_rows if r["window_label"] == "CLOSED"]
            capture.append({"mode": mode["id"], "node_id": node_id,
                            "open_S1": sum(n["S1"] for n in opens), "closed_S1": sum(n["S1"] for n in closed),
                            "open_only_replicated_capture": len(opens) == 2 and all(n["S1"] for n in opens)
                                and not any(n["S1"] for n in closed),
                            "episodes_ended": all(r["episode_ended_last64"] for r in mode_rows)})
    candidates = [r for r in capture if r["open_only_replicated_capture"] and r["episodes_ended"]]
    direct_controls = [r for r in rows if not r["periphery"]]
    direct_clean_by_mode = {mode["id"]: not any(r["pair_response_retained"] for r in direct_controls if r["mode"] == mode["id"])
                            for mode in MODES[:2]}
    controlled = [r for r in candidates if direct_clean_by_mode.get(r["mode"], False)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.blind_environmental_exposure.v1",
        "question": "Does the same broad non-addressed finite environment produce retained capture selectively in clock-causal competence windows?",
        "planning": {"mechanism": "121-carrier plane spanning the complete transverse lattice",
                     "controls": ["open/closed", "x/z/reverse", "semantic1/4", "no periphery", "matched no-plane"],
                     "predicted_outcomes": ["no capture", "direct function", "competence-selected S1", "persistent exposure"],
                     "estimated_runtime_minutes": 4, "stop_condition": "20 paired 256-tick panels"},
        "design": {"windows": [list(x) for x in WINDOWS], "modes": list(MODES), "grid": list(GRID),
                   "explicit_destination": False, "diagnostic_snapshot_insertion": True,
                   "native_t0_environment": False, "horizon": HORIZON},
        "rows": rows, "capture_adjudication": capture,
        "summary": {"blind_open_only_S1_candidates": candidates,
                    "direct_path_clean_by_mode": direct_clean_by_mode,
                    "controlled_blind_capture_candidates": controlled,
                    "endogenous_capture_diagnostic": bool(controlled),
                    "native_t0_blind_capture_demonstrated": False,
                    "direct_path_excluded": bool(controlled),
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_BLIND_CAPTURE" if controlled else "BOUNDED_NULL_OR_DIRECT_PATH",
        "claim_guard": "The plane is blind but inserted into diagnostic snapshots. Promotion requires native t0 parents, cessation of the causal episode, internalization tomography and a native functional handoff.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    common = {k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")}
    exposure = seal({**common, "report_focus": "exposure", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()})
    capture_report = seal({**common, "report_focus": "capture", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()})
    direct = seal({"schema": "dee.v27.ing03.continuous_causal_ecology.direct_path_exclusion.v1",
                   "status": "DIAGNOSTIC_ONLY", "direct_path_clean_by_mode": direct_clean_by_mode,
                   "controlled_candidates": controlled, "native_exclusion_demonstrated": False,
                   "source_evidence": OUTPUT.relative_to(ROOT).as_posix(), "source_file_sha256": sha256_file(OUTPUT)})
    write_json(REPORT_EXPOSURE, exposure); write_json(REPORT_CAPTURE, capture_report); write_json(REPORT_DIRECT, direct)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "capture_adjudication": capture, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
