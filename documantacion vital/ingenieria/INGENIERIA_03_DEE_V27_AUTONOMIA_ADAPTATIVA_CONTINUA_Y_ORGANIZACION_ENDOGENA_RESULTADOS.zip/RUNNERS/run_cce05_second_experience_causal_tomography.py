#!/usr/bin/env python3
"""Diagnostic time/domain tomography of the finite SEM1 C2 response class.

This deliberately starts from the strongest CCE03 diagnostic candidate.  It
does not promote native learning: both the finite experience and the later
probe are installed by the host in snapshot branches.  The objective is to
separate an expiring carrier path from a retained internal causal distinction
and to bound where that distinction is supported in public reproducible state.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_rca02_continuous_competence_core_periphery as rca02


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE05_SECOND_EXPERIENCE_CAUSAL_TOMOGRAPHY.json"
TOMOGRAPHY_REPORT = ROOT / "ING03_SECOND_EXPERIENCE_CAUSAL_TOMOGRAPHY.json"
HISTORY_REPORT = ROOT / "ING03_HISTORY_DISTRIBUTION_MAP.json"
COMMITMENT_REPORT = ROOT / "ING03_CAUSAL_COMMITMENT_TIME.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE03_CAUSAL_RESPONSE_FINGERPRINT.json"

CASES = ((128, 1), (320, 2))
NEGATIVE_CASE = (144, 1)
ENCODING_HORIZON = 160
CUT_LATENCIES = (1, 2, 4, 8, 16, 32, 64, 96, 128)
RADII = (0, 1, 2, 3, 6, 10)
MARKER_STATE = 73001


def clone(kernel, source):
    # Public reproducible state only. raw_b/clock_b are kernel scratch buffers.
    return NativeWorld(kernel, source.raw, source.clock_a)


def toroidal_chebyshev(n, center):
    axes = []
    for coordinate in center:
        axis = np.arange(n, dtype=np.int16)
        distance = np.abs(axis - int(coordinate))
        axes.append(np.minimum(distance, n - distance))
    return np.maximum.reduce(np.meshgrid(*axes, indexing="ij"))


def install_experience(world, node, tick):
    cce03.install(world, {}, node, "SEM1_WRITER", tick)


def marker_mask(world):
    return (world.raw & np.uint64(0xFFFFFFFF)) == np.uint64(MARKER_STATE)


def copy_mask(target, source, mask, component):
    if component in ("RAW", "R0"):
        target.raw_a[mask] = source.raw[mask]
        target.raw_b[mask] = source.raw[mask]
    if component in ("CLOCK", "R0"):
        target.clock_a[mask] = source.clock_a[mask]
        target.clock_b[mask] = source.clock_a[mask]


def advance_pair(treatment, control, ticks):
    for _ in range(ticks):
        treatment.tick(); control.tick()


def prepare(kernel, snapshot, node, tick, horizon=ENCODING_HORIZON):
    treatment, control = clone(kernel, snapshot), clone(kernel, snapshot)
    install_experience(treatment, node, tick)
    node_difference = []
    marker_counts = []
    for _ in range(horizon):
        treatment.tick(); control.tick()
        node_difference.append(cce03.r09.delta(treatment, node) != cce03.r09.delta(control, node))
        marker_counts.append(int(marker_mask(treatment).sum()))
    adjudication = {
        "S1_retained_change": all(node_difference[-cce03.RETENTION:]),
        "episode_ended_last64": all(value == 0 for value in marker_counts[-cce03.RETENTION:]),
        "marker_count_terminal": marker_counts[-1],
    }
    return treatment, control, adjudication


def fingerprint(kernel, treatment, control, meta, node, tick):
    result = cce03.probe_fingerprint(kernel, treatment, control, meta, node, tick)
    result["probe_interaction_differs"] = bool(result["response_fingerprint_differs"])
    return result


def fingerprint_fast(kernel, experienced, control, node, tick):
    """Exact CCE03 XOR-response comparison, stopping at first discrimination."""
    ep, en = clone(kernel, experienced), clone(kernel, experienced)
    cp, cn = clone(kernel, control), clone(kernel, control)
    for world, enabled in ((ep, True), (en, False), (cp, True), (cn, False)):
        cce03.install_probe(world, node, tick, enabled)
    for latency in range(1, cce03.PROBE_HORIZON + 1):
        for world in (ep, en, cp, cn):
            world.tick()
        raw_equal = np.array_equal(np.bitwise_xor(ep.raw, en.raw), np.bitwise_xor(cp.raw, cn.raw))
        clock_equal = np.array_equal(np.bitwise_xor(ep.clock_a, en.clock_a),
                                     np.bitwise_xor(cp.clock_a, cn.clock_a))
        if not (raw_equal and clock_equal):
            return {"probe_interaction_differs": True, "first_discriminating_latency": latency,
                    "exact_relation": "experienced XOR probe effect differs from control XOR probe effect"}
    return {"probe_interaction_differs": False, "first_discriminating_latency": None,
            "exact_relation": "experienced and control XOR probe effects equal through horizon"}


def cut_test(kernel, snapshot, meta, node, tick, latency):
    treatment, control = clone(kernel, snapshot), clone(kernel, snapshot)
    install_experience(treatment, node, tick)
    node_difference = []
    marker_counts = []
    for _ in range(latency):
        treatment.tick(); control.tick()
        node_difference.append(cce03.r09.delta(treatment, node) != cce03.r09.delta(control, node))
        marker_counts.append(int(marker_mask(treatment).sum()))
    mask = marker_mask(treatment)
    marker_before = int(mask.sum())
    copy_mask(treatment, control, mask, "R0")
    marker_after = int(marker_mask(treatment).sum())
    for _ in range(ENCODING_HORIZON - latency):
        treatment.tick(); control.tick()
        node_difference.append(cce03.r09.delta(treatment, node) != cce03.r09.delta(control, node))
        marker_counts.append(int(marker_mask(treatment).sum()))
    probe = fingerprint_fast(kernel, treatment, control, node, tick + ENCODING_HORIZON)
    S1 = len(node_difference) >= cce03.RETENTION and all(node_difference[-cce03.RETENTION:])
    ended = len(marker_counts) >= cce03.RETENTION and all(value == 0 for value in marker_counts[-cce03.RETENTION:])
    C2 = S1 and ended and probe["probe_interaction_differs"]
    return {
        "latency": latency,
        "marker_positions_cut": marker_before,
        "marker_positions_remaining_immediately": marker_after,
        "marker_positions_terminal": int(marker_mask(treatment).sum()),
        "terminal_public_raw_difference_count": int(np.count_nonzero(treatment.raw != control.raw)),
        "terminal_public_clock_difference_count": int(np.count_nonzero(treatment.clock_a != control.clock_a)),
        "S1_retained_change": S1,
        "episode_ended_last64": ended,
        "C2_response_class_after_carrier_cut": C2,
        "probe": probe,
    }


def domain_mask(n, node, radius):
    centers = (node["a"], node["b"], node["writer_q"], node["center"])
    return np.logical_or.reduce([toroidal_chebyshev(n, center) <= radius for center in centers])


def domain_test(kernel, treatment0, control0, meta, node, tick, radius, component):
    treatment, control = clone(kernel, treatment0), clone(kernel, control0)
    mask = domain_mask(meta["n"], node, radius)
    raw_before = int(np.count_nonzero((treatment.raw != control.raw) & mask))
    clock_before = int(np.count_nonzero((treatment.clock_a != control.clock_a) & mask))
    copy_mask(treatment, control, mask, component)
    probe = fingerprint_fast(kernel, treatment, control, node, tick)
    return {
        "domain": f"NODE_UNION_R{radius}", "radius": radius, "component": component,
        "positions": int(mask.sum()), "raw_differences_equalized": raw_before if component in ("RAW", "R0") else 0,
        "clock_differences_equalized": clock_before if component in ("CLOCK", "R0") else 0,
        "probe_interaction_after_equalization": probe["probe_interaction_differs"],
        "probe": probe,
    }


def difference_support_test(kernel, treatment0, control0, meta, node, tick, component, scope):
    treatment, control = clone(kernel, treatment0), clone(kernel, control0)
    if component == "RAW":
        mask = treatment.raw != control.raw
    elif component == "CLOCK":
        mask = treatment.clock_a != control.clock_a
    else:
        mask = (treatment.raw != control.raw) | (treatment.clock_a != control.clock_a)
    if scope == "LOCAL_R6":
        mask &= domain_mask(meta["n"], node, 6)
    elif scope == "OUTSIDE_R6":
        mask &= ~domain_mask(meta["n"], node, 6)
    count = int(mask.sum())
    copy_mask(treatment, control, mask, component)
    probe = fingerprint_fast(kernel, treatment, control, node, tick)
    return {
        "domain": f"ACTUAL_DIFFERENCE_{scope}", "component": component,
        "positions": count,
        "probe_interaction_after_equalization": probe["probe_interaction_differs"],
        "probe": probe,
    }


def run_case(kernel, snapshot, meta, node, tick, include_cut=True, include_domains=True):
    treatment, control, adjudication = prepare(kernel, snapshot, node, tick)
    baseline = fingerprint(kernel, treatment, control, meta, node, tick + ENCODING_HORIZON)
    baseline_C2 = (adjudication["S1_retained_change"] and adjudication["episode_ended_last64"]
                   and baseline["probe_interaction_differs"])
    terminal = {
        "marker_count": int(marker_mask(treatment).sum()),
        "raw_difference_count": int(np.count_nonzero(treatment.raw != control.raw)),
        "clock_difference_count": int(np.count_nonzero(treatment.clock_a != control.clock_a)),
    }
    cuts = [cut_test(kernel, snapshot, meta, node, tick, latency) for latency in CUT_LATENCIES] if include_cut else []
    domains = []
    if include_domains:
        for radius in RADII:
            for component in ("RAW", "CLOCK", "R0"):
                domains.append(domain_test(kernel, treatment, control, meta, node, tick + ENCODING_HORIZON,
                                           radius, component))
        for scope in ("LOCAL_R6", "OUTSIDE_R6", "GLOBAL"):
            for component in ("RAW", "CLOCK", "R0"):
                domains.append(difference_support_test(kernel, treatment, control, meta, node,
                                                       tick + ENCODING_HORIZON, component, scope))
    return {
        "tick": tick, "node_id": node["id"], "frame": node["frame"],
        "intervention_class": "DIAGNOSTIC_INTERVENTION", "terminal": terminal,
        "encoding_adjudication": adjudication, "baseline_probe": baseline,
        "baseline_C2_response_class": baseline_C2,
        "carrier_cut_series": cuts, "domain_equalization_series": domains,
    }


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel)
    needed = {tick for tick, _ in CASES} | {NEGATIVE_CASE[0]}
    snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        if tick in needed:
            snapshots[tick] = clone(kernel, base)

    cases = []
    for tick, node_id in CASES:
        print(json.dumps({"stage": "case_start", "tick": tick, "node": node_id}), flush=True)
        row = run_case(kernel, snapshots[tick], meta, nodes[node_id - 1], tick, include_cut=True)
        cases.append(row)
        print(json.dumps({"stage": "case_done", "tick": tick, "node": node_id,
                          "baseline": row["baseline_C2_response_class"],
                          "cuts_retaining": sum(x["C2_response_class_after_carrier_cut"] for x in row["carrier_cut_series"]),
                          "domains_abolishing": sum(not x["probe_interaction_after_equalization"] for x in row["domain_equalization_series"])}, sort_keys=True), flush=True)

    ntick, nnode_id = NEGATIVE_CASE
    negative = run_case(kernel, snapshots[ntick], meta, nodes[nnode_id - 1], ntick,
                        include_cut=False, include_domains=False)

    baseline_reproduced = all(row["baseline_C2_response_class"] for row in cases)
    negative_clean = not negative["baseline_C2_response_class"]
    earliest = []
    for row in cases:
        retained = [x["latency"] for x in row["carrier_cut_series"] if x["C2_response_class_after_carrier_cut"]]
        earliest.append({"tick": row["tick"], "node_id": row["node_id"],
                         "earliest_tested_carrier_independent_latency": min(retained) if retained else None})
    necessary = []
    for row in cases:
        for test in row["domain_equalization_series"]:
            if not test["probe_interaction_after_equalization"]:
                necessary.append({"tick": row["tick"], "node_id": row["node_id"],
                                  "domain": test["domain"], "component": test["component"],
                                  "positions": test["positions"]})

    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.second_experience_tomography.v1",
        "question": "When does the finite SEM1 experience cease depending on its carrier, and which public-state domains support its retained response class?",
        "planning": {
            "mechanism": "time-of-carrier-cut plus growing-domain RAW/CLOCK/R0 equalization in two independent open-window candidates",
            "controls": ["CCE03 replication", "closed-window negative", "raw-only", "clock-only", "combined public R0", "global equalization positive control"],
            "predicted_outcomes": ["direct carrier dependence", "local internalization", "distributed support", "history outside accessible public state"],
            "estimated_runtime_minutes": 15,
            "stop_condition": "two positive cases, one negative case, nine carrier cuts, and causal growing-domain panel",
        },
        "epistemic_scope": {
            "diagnostic_only": True,
            "experience_host_installed": True,
            "probe_host_installed": True,
            "x_full_accessible": False,
            "public_reproducible_state_proxy": "current raw plus clock_a; raw_b/clock_b are scratch and never cloned as causal state",
        },
        "design": {"cases": [list(x) for x in CASES], "negative_case": list(NEGATIVE_CASE),
                   "encoding_horizon": ENCODING_HORIZON, "cut_latencies": list(CUT_LATENCIES),
                   "domain_radii": list(RADII), "marker_state": MARKER_STATE},
        "cases": cases, "closed_window_negative": negative,
        "summary": {
            "baseline_C2_response_class_reproduced": baseline_reproduced,
            "closed_window_negative_clean": negative_clean,
            "earliest_tested_carrier_independent_commitment": earliest,
            "causally_necessary_equalizations": necessary,
            "native_second_experience_demonstrated": False,
            "native_function_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "status": "DIAGNOSTIC_INTERNALIZATION_TOMOGRAPHY" if baseline_reproduced and negative_clean else "DIAGNOSTIC_REPLICATION_FAILED",
        "claim_guard": "Abolition/preservation applies only to tested public raw/clock interventions. It neither localizes X_FULL exhaustively nor promotes host-installed experience/probe to native function.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)

    common = {"source_evidence": OUTPUT.relative_to(ROOT).as_posix(), "source_file_sha256": sha256_file(OUTPUT),
              "status": result["status"], "claim_guard": result["claim_guard"]}
    tomography = seal({"schema": "dee.v27.ing03.second_experience_causal_tomography.v1",
                       "question": result["question"], "design": result["design"],
                       "summary": result["summary"], "causally_necessary_equalizations": necessary, **common})
    history = seal({"schema": "dee.v27.ing03.history_distribution_map.v1",
                    "finding": "tested public-state support is reported by causal equalization, not inferred from raw difference counts",
                    "case_terminal_counts": [{"tick": x["tick"], "node_id": x["node_id"], **x["terminal"]} for x in cases],
                    "causally_necessary_equalizations": necessary,
                    "x_full_unresolved": True, **common})
    commitment = seal({"schema": "dee.v27.ing03.causal_commitment_time.v1",
                       "definition": "earliest tested latency at which deleting every extant original SEM1 marker-state carrier still preserves the later frozen-probe response-class difference",
                       "results": earliest,
                       "direct_path_fully_excluded": False,
                       "reason": "marker-state cutting bounds dependence on the original carrier class but cannot remove every transformed descendant or hidden X_FULL coordinate",
                       **common})
    write_json(TOMOGRAPHY_REPORT, tomography)
    write_json(HISTORY_REPORT, history)
    write_json(COMMITMENT_REPORT, commitment)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
