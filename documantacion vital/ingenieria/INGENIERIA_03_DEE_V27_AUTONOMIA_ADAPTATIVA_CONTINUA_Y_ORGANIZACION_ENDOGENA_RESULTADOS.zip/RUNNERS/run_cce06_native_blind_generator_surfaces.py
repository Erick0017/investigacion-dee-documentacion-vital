#!/usr/bin/env python3
"""All-t0 non-addressed environmental generator surfaces.

The surfaces are defined in world coordinates and span many unrelated paths;
they contain no learner identifier or recipient coordinate.  Two-parent local
collisions generate the later-moving environmental population natively.  This
is a causally distinct follow-up to CCE04's host-inserted direct carrier plane.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce04_blind_environmental_exposure as cce04
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE06_NATIVE_BLIND_GENERATOR_SURFACES.json"
REPORT_EXPOSURE = ROOT / "ING03_NATIVE_BLIND_ENVIRONMENT.json"
REPORT_CAPTURE = ROOT / "ING03_NATIVE_ENDOGENOUS_CAPTURE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE05_SECOND_EXPERIENCE_CAUSAL_TOMOGRAPHY.json"
HORIZON = 1024
RETENTION = 64
GRID0 = tuple(range(-20, 21, 4))
GRID2 = tuple(range(-18, 20, 4))

MODES = (
    {"id": "Z_SURFACE_PHASE0", "axes": (2,), "grid": GRID0, "semantic": 1, "broken": False},
    {"id": "Z_SURFACE_PHASE2", "axes": (2,), "grid": GRID2, "semantic": 1, "broken": False},
    {"id": "X_SURFACE_PHASE0", "axes": (0,), "grid": GRID0, "semantic": 1, "broken": False},
    {"id": "Y_SURFACE_PHASE0", "axes": (1,), "grid": GRID0, "semantic": 1, "broken": False},
    {"id": "TRIAXIAL_SURFACES", "axes": (0, 1, 2), "grid": GRID0, "semantic": 1, "broken": False},
    {"id": "Z_SURFACE_IRRELEVANT_SEM2", "axes": (2,), "grid": GRID0, "semantic": 2, "broken": False},
    {"id": "Z_SURFACE_BROKEN_PARENT", "axes": (2,), "grid": GRID0, "semantic": 1, "broken": True},
)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def set_both(world, q, raw, clock=0):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def vectors_for_axis(axis):
    route = [0, 0, 0]; route[axis] = 1
    transverse = next(i for i in range(3) if i != axis)
    d1 = route.copy(); d1[transverse] = 1
    d2 = route.copy(); d2[transverse] = -1
    return tuple(route), tuple(d1), tuple(d2)


def add_vec(q, v, scale, n):
    return tuple((int(q[i]) + scale * int(v[i])) % n for i in range(3))


def install_surface(world, meta, axis, grid, semantic, broken, serial_base):
    n = meta["n"]; center = meta["c"]
    route, d1, d2 = vectors_for_axis(axis)
    transverse = [i for i in range(3) if i != axis]
    fixed = list(center); fixed[axis] = (center[axis] - 12) % n
    installed = []; skipped = []; states = []
    serial = 0
    for u in grid:
        for v in grid:
            generator = list(fixed)
            generator[transverse[0]] = (center[transverse[0]] + u) % n
            generator[transverse[1]] = (center[transverse[1]] + v) % n
            generator = tuple(generator)
            parents = (d2,) if broken else (d1, d2)
            positions = [add_vec(generator, direction, -1, n) for direction in parents]
            if any(int(world.raw[q]) for q in positions):
                skipped.append({"generator": list(generator), "reason": "occupied_parent"})
                serial += 1
                continue
            entry = {"generator": list(generator), "route": list(route), "parents": []}
            for parent_index, (q, direction) in enumerate(zip(positions, parents)):
                state = serial_base + serial * 2 + parent_index
                raw = int(pack(state, 3, direction, semantic)); set_both(world, q, raw)
                entry["parents"].append({"q": list(q), "direction": list(direction), "state": state})
                states.append(state)
            installed.append(entry); serial += 1
    return {"axis": axis, "grid": list(grid), "semantic": semantic, "broken": broken,
            "surface_coordinate": fixed[axis], "installed_generators": installed,
            "skipped_generators": skipped, "parent_states": states}


def install_environment(world, meta, mode):
    surfaces = []
    for index, axis in enumerate(mode["axes"]):
        surfaces.append(install_surface(world, meta, axis, mode["grid"], mode["semantic"],
                                        mode["broken"], 76000 + index * 1000))
    return {"mode": mode["id"], "surfaces": surfaces,
            "explicit_recipient": False, "learner_coordinates_used": False,
            "answer_mapping_encoded": False,
            "parent_states": [state for surface in surfaces for state in surface["parent_states"]]}


def clear_periphery(world, meta, nodes):
    positions = sorted({q for node in nodes for q in rca05.node_positions(node, meta["n"])})
    for q in positions:
        set_both(world, q, 0, 0)
    return len(positions)


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def run_world(kernel, mode, periphery=True):
    treatment, meta, nodes = rca02.build(kernel)
    control, cmeta, cnodes = rca02.build(kernel)
    removed = 0
    if not periphery:
        removed = clear_periphery(treatment, meta, nodes)
        clear_periphery(control, cmeta, cnodes)
    environment = install_environment(treatment, meta, mode)
    histories = {node["id"]: [] for node in nodes}
    pair_diff = []; core_diff = []; world_diff = []; markers = []; checkpoints = []
    by_control = {node["id"]: node for node in cnodes}
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node in nodes:
            histories[node["id"]].append(r09.delta(treatment, node) != r09.delta(control, by_control[node["id"]]))
        pair_diff.append(pair(treatment, meta) != pair(control, cmeta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        world_diff.append(int(np.count_nonzero(treatment.raw != control.raw)))
        markers.append(marker_count(treatment, environment["parent_states"]))
        if tick in (1, 2, 4, 8, 16, 32, 38, 64, 96, 128, 160, 256, 320, 512, 768, 1024):
            checkpoints.append({"tick": tick, "node_difference": {str(k): v[-1] for k, v in histories.items()},
                                "pair_difference": pair_diff[-1], "core_difference": core_diff[-1],
                                "world_difference": world_diff[-1], "parent_marker_count": markers[-1]})
    node_results = []
    for node in nodes:
        series = histories[node["id"]]
        first = next((i + 1 for i, value in enumerate(series) if value), None)
        node_results.append({"node_id": node["id"], "first_difference_tick": first,
                             "no_change_through_function_A_tick38": first is None or first > 38,
                             "S1_retained_last64": all(series[-RETENTION:])})
    return {"mode": mode, "periphery": periphery, "removed_peripheral_positions": removed,
            "environment": environment, "node_results": node_results,
            "episode_parent_markers_ended_last64": all(value == 0 for value in markers[-RETENTION:]),
            "terminal_parent_marker_count": markers[-1],
            "pair_difference_any": any(pair_diff), "pair_difference_retained_last64": all(pair_diff[-RETENTION:]),
            "core_difference_any": any(core_diff), "core_difference_retained_last64": all(core_diff[-RETENTION:]),
            "maximum_world_difference": max(world_diff), "terminal_world_difference": world_diff[-1],
            "world_difference_sha256": hashlib.sha256(np.asarray(world_diff, np.int32).tobytes()).hexdigest(),
            "checkpoints": checkpoints,
            "terminal_treatment": treatment, "terminal_control": control,
            "meta": meta, "nodes": nodes}


def strip_runtime_world(row):
    return {k: v for k, v in row.items() if k not in ("terminal_treatment", "terminal_control", "meta", "nodes")}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    runtime_rows = []
    for mode in MODES:
        row = run_world(kernel, mode, True); runtime_rows.append(row)
        print(json.dumps({"mode": mode["id"], "nodes": row["node_results"],
                          "ended": row["episode_parent_markers_ended_last64"],
                          "pair_retained": row["pair_difference_retained_last64"]}, sort_keys=True), flush=True)
    prelim_modes = {row["mode"]["id"] for row in runtime_rows
                    if any(node["no_change_through_function_A_tick38"] and node["S1_retained_last64"]
                           for node in row["node_results"])}
    prelim_modes.add(MODES[0]["id"])
    direct_controls = []
    for mode in (mode for mode in MODES if mode["id"] in prelim_modes and not mode["broken"]):
        row = run_world(kernel, mode, False); direct_controls.append(row)
        print(json.dumps({"mode": mode["id"], "periphery": False,
                          "pair_retained": row["pair_difference_retained_last64"]}, sort_keys=True), flush=True)

    direct_clean = {row["mode"]["id"]: not row["pair_difference_retained_last64"] for row in direct_controls}
    candidates = []
    for row in runtime_rows:
        mode_id = row["mode"]["id"]
        retained = [node["node_id"] for node in row["node_results"]
                    if node["no_change_through_function_A_tick38"] and node["S1_retained_last64"]]
        if retained and row["episode_parent_markers_ended_last64"] and direct_clean.get(mode_id, False):
            candidates.append({"mode": mode_id, "retained_nodes": retained})

    # The identical later probe is diagnostic; the environmental episode itself is all-t0/native.
    probe_rows = []
    by_mode = {row["mode"]["id"]: row for row in runtime_rows}
    for candidate in candidates:
        row = by_mode[candidate["mode"]]
        for node_id in candidate["retained_nodes"]:
            node = row["nodes"][node_id - 1]
            probe = cce03.probe_fingerprint(kernel, row["terminal_treatment"], row["terminal_control"],
                                            row["meta"], node, HORIZON)
            probe_rows.append({"mode": candidate["mode"], "node_id": node_id,
                               "response_fingerprint_differs": probe["response_fingerprint_differs"],
                               "shared_pair_response_differs": probe["shared_pair_response_differs"],
                               "probe_intervention_class": "DIAGNOSTIC_INTERVENTION"})

    broken = next(row for row in runtime_rows if row["mode"]["broken"])
    broken_clean = not any(node["S1_retained_last64"] for node in broken["node_results"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.native_blind_generator_surfaces.v1",
        "question": "Can broad all-t0 two-parent environmental surfaces generate a non-addressed episode that is selectively internalized after Function A?",
        "planning": {
            "mechanism": "world-coordinate collision surfaces generating moving populations natively from t0",
            "controls": ["three axes", "spatial phase", "triaxial multiplicity", "irrelevant semantic", "broken parent", "periphery removed"],
            "predicted_outcomes": ["no capture", "direct-path core response", "late S1 capture", "retained changed challenge response"],
            "estimated_runtime_minutes": 8,
            "stop_condition": "seven all-t0 worlds and three no-periphery direct-path controls through tick1024",
        },
        "design": {"horizon": HORIZON, "retention": RETENTION, "function_A_tick": 38,
                   "modes": list(MODES), "python_after_t0": ["tick", "log", "stop"],
                   "environment_blind": True, "environmental_parents_present_at_t0": True,
                   "answer_carrier_present_at_t0": False, "explicit_recipient": False},
        "rows": [strip_runtime_world(row) for row in runtime_rows],
        "direct_path_controls": [strip_runtime_world(row) for row in direct_controls],
        "direct_path_clean_by_mode": direct_clean, "candidate_captures": candidates,
        "diagnostic_probe_rows": probe_rows,
        "summary": {"candidate_native_blind_captures": candidates,
                    "candidate_probe_response_classes": [row for row in probe_rows if row["response_fingerprint_differs"]],
                    "broken_generator_clean": broken_clean,
                    "native_blind_capture_demonstrated": bool(candidates) and broken_clean,
                    "native_functional_handoff_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "NATIVE_BLIND_CAPTURE_CANDIDATE" if candidates and broken_clean else "BOUNDED_NULL_OR_DIRECT_PATH",
        "claim_guard": "A retained node difference is not itself functional handoff. No-periphery controls exclude only tested direct pair paths. The later probe is diagnostic and host-installed; no RW3 promotion follows.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")},
                     {"path": cce04.OUTPUT.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(cce04.OUTPUT)}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    common = {k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows", "direct_path_controls")}
    write_json(REPORT_EXPOSURE, seal({**common, "report_focus": "native_blind_environment", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()}))
    write_json(REPORT_CAPTURE, seal({**common, "report_focus": "native_capture", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()}))
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
