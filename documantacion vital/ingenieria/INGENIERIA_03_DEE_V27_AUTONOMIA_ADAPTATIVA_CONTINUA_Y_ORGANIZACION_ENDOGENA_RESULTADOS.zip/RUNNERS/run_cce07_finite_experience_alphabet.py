#!/usr/bin/env python3
"""Discover distinct finite experiences captured by one competence region."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE07_FINITE_EXPERIENCE_ALPHABET.json"
REPORT = ROOT / "ING03_FINITE_EXPERIENCE_ALPHABET.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE05_SECOND_EXPERIENCE_CAUSAL_TOMOGRAPHY.json"
ENCODING = 160
RETENTION = 64

CANONICAL_DIRECTIONS = (
    (1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1),
    (1, 1, 0), (1, -1, 0), (-1, 1, 0), (-1, -1, 0),
    (1, 0, 1), (1, 0, -1), (-1, 0, 1), (-1, 0, -1),
    (0, 1, 1), (0, 1, -1), (0, -1, 1), (0, -1, -1),
)
MODES = tuple({"id": "D_%+d_%+d_%+d_S1" % direction, "direction": direction, "semantic": 1}
              for direction in CANONICAL_DIRECTIONS) + (
    {"id": "D_0_0_1_S2", "direction": (0, 0, 1), "semantic": 2},
    {"id": "D_0_0_1_S3", "direction": (0, 0, 1), "semantic": 3},
    {"id": "D_0_0_1_S4", "direction": (0, 0, 1), "semantic": 4},
)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install(world, node, mode, tick, state):
    direction = r09.transform(mode["direction"], node["frame"])
    set_both(world, node["writer_q"], int(pack(state, 0, direction, mode["semantic"])), tick)
    return direction


def marker_count(world, state):
    return int(np.count_nonzero((world.raw & np.uint64(0xFFFFFFFF)) == state))


def full_signature(probe):
    payload = []
    for row in probe["checkpoint_rows"]:
        payload.append((row["latency"], row["experienced_probe_effect_sha256"],
                        row["control_probe_effect_sha256"], row["effects_equal"],
                        row["experienced_pair_effect"], row["control_pair_effect"]))
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def assay(kernel, snapshot, meta, node, tick, label, mode, serial, full=False):
    treatment, control = clone(kernel, snapshot), clone(kernel, snapshot)
    state = 78000 + serial
    physical_direction = install(treatment, node, mode, tick, state)
    differences = []; markers = []
    for _ in range(ENCODING):
        treatment.tick(); control.tick()
        differences.append(r09.delta(treatment, node) != r09.delta(control, node))
        markers.append(marker_count(treatment, state))
    S0 = any(differences); S1 = all(differences[-RETENTION:]); ended = all(x == 0 for x in markers[-RETENTION:])
    fast = cce05.fingerprint_fast(kernel, treatment, control, node, tick + ENCODING)
    C2 = S1 and ended and fast["probe_interaction_differs"]
    detailed = cce03.probe_fingerprint(kernel, treatment, control, meta, node, tick + ENCODING) if full and C2 else None
    return {"tick": tick, "window": label, "node_id": node["id"], "mode": mode,
            "physical_direction": list(physical_direction), "marker_state": state,
            "S0": S0, "S1": S1, "episode_ended_last64": ended,
            "first_difference_latency": next((i + 1 for i, value in enumerate(differences) if value), None),
            "C2_response_class": C2, "fast_probe": fast,
            "full_probe": detailed, "response_signature_sha256": full_signature(detailed) if detailed else None,
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel)
    needed = {128, 144, 320, 336}; snapshots = {}
    for tick in range(1, max(needed) + 1):
        base.tick()
        if tick in needed:
            snapshots[tick] = clone(kernel, base)

    discovery = []
    for serial, mode in enumerate(MODES):
        for tick, label in ((128, "OPEN"), (144, "CLOSED")):
            row = assay(kernel, snapshots[tick], meta, nodes[0], tick, label, mode, serial, full=True)
            discovery.append(row)
        rows = discovery[-2:]
        print(json.dumps({"mode": mode["id"], "open_C2": rows[0]["C2_response_class"],
                          "closed_C2": rows[1]["C2_response_class"],
                          "signature": rows[0]["response_signature_sha256"]}, sort_keys=True), flush=True)

    selective = []
    for mode in MODES:
        subset = [row for row in discovery if row["mode"]["id"] == mode["id"]]
        open_row = next(row for row in subset if row["window"] == "OPEN")
        closed_row = next(row for row in subset if row["window"] == "CLOSED")
        if open_row["C2_response_class"] and not closed_row["C2_response_class"]:
            selective.append({"mode": mode, "discovery_signature": open_row["response_signature_sha256"]})

    # Validate at an unseen time/frame. Full probes are restricted to discovery and
    # candidates; this is exact validation, not a trained external classifier.
    holdout = []
    for index, candidate in enumerate(selective):
        mode = candidate["mode"]; serial = MODES.index(mode)
        for tick, label in ((320, "OPEN_HOLDOUT"), (336, "CLOSED_HOLDOUT")):
            holdout.append(assay(kernel, snapshots[tick], meta, nodes[1], tick, label, mode, serial, full=True))
        rows = holdout[-2:]
        print(json.dumps({"holdout": mode["id"], "open_C2": rows[0]["C2_response_class"],
                          "closed_C2": rows[1]["C2_response_class"],
                          "signature": rows[0]["response_signature_sha256"]}, sort_keys=True), flush=True)

    confirmed = []
    for candidate in selective:
        subset = [row for row in holdout if row["mode"]["id"] == candidate["mode"]["id"]]
        if len(subset) == 2 and subset[0]["C2_response_class"] and not subset[1]["C2_response_class"]:
            confirmed.append({"mode": candidate["mode"],
                              "discovery_signature": candidate["discovery_signature"],
                              "holdout_signature": subset[0]["response_signature_sha256"],
                              "signature_stable": candidate["discovery_signature"] == subset[0]["response_signature_sha256"]})
    distinct_discovery = sorted({x["discovery_signature"] for x in confirmed})
    distinct_holdout = sorted({x["holdout_signature"] for x in confirmed})
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.finite_experience_alphabet.v1",
        "question": "Can one competence organization retain causally distinguishable finite experience classes rather than a single writer response?",
        "planning": {"mechanism": "direction/semantic alphabet at the same experience interface",
                     "controls": ["open/closed", "same node and port", "finite marker extinction", "unseen time/frame holdout", "identical later probe"],
                     "predicted_outcomes": ["single generic susceptibility", "direction-selective capture", "multiple response classes", "persistent carrier"],
                     "estimated_runtime_minutes": 8, "stop_condition": "21 discovery modes and fresh validation of every open-only candidate"},
        "design": {"modes": list(MODES), "discovery": {"node": 1, "open": 128, "closed": 144},
                   "holdout": {"node": 2, "open": 320, "closed": 336},
                   "encoding_horizon": ENCODING, "diagnostic_only": True},
        "discovery_rows": discovery, "holdout_rows": holdout,
        "selective_discovery_candidates": selective, "fresh_confirmed_candidates": confirmed,
        "summary": {"modes_tested": len(MODES), "selective_discovery_count": len(selective),
                    "fresh_confirmed_count": len(confirmed),
                    "distinct_discovery_response_signatures": len(distinct_discovery),
                    "distinct_holdout_response_signatures": len(distinct_holdout),
                    "multi_experience_response_classes_demonstrated": len(distinct_holdout) >= 2,
                    "native_environment_demonstrated": False, "recurrent_sequence_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "FRESH_CONFIRMED_DIAGNOSTIC_ALPHABET" if confirmed else "BOUNDED_NULL",
        "claim_guard": "The same-port alphabet is diagnostic. Distinct external response hashes establish response classes, not a DEE reader or native environmental capture. Sequence-level recurrence remains untested here.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery_rows", "holdout_rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "confirmed": confirmed, "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
