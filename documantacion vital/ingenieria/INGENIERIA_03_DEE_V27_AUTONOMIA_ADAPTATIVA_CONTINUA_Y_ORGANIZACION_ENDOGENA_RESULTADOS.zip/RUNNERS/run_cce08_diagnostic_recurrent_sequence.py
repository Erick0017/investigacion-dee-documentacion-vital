#!/usr/bin/env python3
"""Factorial B -> C -> B diagnostic sequence in one uninterrupted world.

B is the finite aligned SEM1 experience; C is the causally distinct two-parent
D12 experience.  Both are installed diagnostically.  The runner asks whether
the same bounded organization retains each step and changes its response to an
identical later probe, then reacquires B without reconstructing the world.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE08_DIAGNOSTIC_RECURRENT_SEQUENCE.json"
REPORT_HANDOFF = ROOT / "ING03_DISTRIBUTED_HANDOFF.json"
REPORT_TRANSITION = ROOT / "ING03_REGIME_TRANSITION_MAP.json"
REPORT_WORLD = ROOT / "ING03_RW3_CONTINUOUS_WORLD.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE07_FINITE_EXPERIENCE_ALPHABET.json"
RETENTION = 64
CHECKPOINTS = (1, 2, 4, 8, 16, 32, 64, 96, 128)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds:
            world.tick()


def response_signature(kernel, state, node, tick):
    probe, no_probe = clone(kernel, state), clone(kernel, state)
    cce03.install_probe(probe, node, tick, True); cce03.install_probe(no_probe, node, tick, False)
    rows = []
    for latency in range(1, cce03.PROBE_HORIZON + 1):
        probe.tick(); no_probe.tick()
        if latency in CHECKPOINTS:
            h = hashlib.sha256()
            h.update(np.bitwise_xor(probe.raw, no_probe.raw).tobytes())
            h.update(np.bitwise_xor(probe.clock_a, no_probe.clock_a).tobytes())
            rows.append({"latency": latency, "effect_sha256": h.hexdigest()})
    signature = hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"signature_sha256": signature, "checkpoints": rows}


def run_interval(world_a, world_b, node, ticks, marker_states):
    differences = []; markers_a = []; markers_b = []
    for _ in range(ticks):
        world_a.tick(); world_b.tick()
        differences.append(r09.delta(world_a, node) != r09.delta(world_b, node))
        markers_a.append(marker_count(world_a, marker_states)); markers_b.append(marker_count(world_b, marker_states))
    return {"S0": any(differences), "S1_last64": all(differences[-RETENTION:]),
            "first_difference_latency": next((i + 1 for i, value in enumerate(differences) if value), None),
            "episode_A_ended_last64": all(value == 0 for value in markers_a[-RETENTION:]),
            "episode_B_ended_last64": all(value == 0 for value in markers_b[-RETENTION:]),
            "terminal_marker_A": markers_a[-1], "terminal_marker_B": markers_b[-1]}


def signatures(kernel, worlds, node, tick):
    return {name: response_signature(kernel, world, node, tick) for name, world in worlds.items()}


def distinct(a, b):
    return a["signature_sha256"] != b["signature_sha256"]


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel); node = nodes[0]

    # Native A organization develops identically until the first diagnostic experience.
    advance((base,), 128)
    world_B, world_N = clone(kernel, base), clone(kernel, base)
    cce03.install(world_B, meta, node, "SEM1_WRITER", 128)
    stage_B = run_interval(world_B, world_N, node, 192, (73001,))  # t128 -> t320
    sig_B_t320 = signatures(kernel, {"B": world_B, "N": world_N}, node, 320)
    stage_B["response_signatures_t320"] = sig_B_t320
    stage_B["functional_response_changed"] = distinct(sig_B_t320["B"], sig_B_t320["N"])

    # Factorial C at t320: BC/B and C/N isolate C on two histories.
    worlds = {"BC": clone(kernel, world_B), "B": clone(kernel, world_B),
              "C": clone(kernel, world_N), "N": clone(kernel, world_N)}
    rec_bc = cce03.install(worlds["BC"], meta, node, "TWO_PARENT_D12", 320)
    rec_c = cce03.install(worlds["C"], meta, node, "TWO_PARENT_D12", 320)
    differences = {"BC_vs_B": [], "C_vs_N": []}; marker_hist = {name: [] for name in worlds}
    states_C = tuple(rec_bc["marker_states"])
    for _ in range(160):
        for world in worlds.values(): world.tick()
        differences["BC_vs_B"].append(r09.delta(worlds["BC"], node) != r09.delta(worlds["B"], node))
        differences["C_vs_N"].append(r09.delta(worlds["C"], node) != r09.delta(worlds["N"], node))
        for name, world in worlds.items(): marker_hist[name].append(marker_count(world, states_C))
    sig_t480 = signatures(kernel, worlds, node, 480)
    stage_C = {
        "BC_vs_B_S1_last64": all(differences["BC_vs_B"][-RETENTION:]),
        "C_vs_N_S1_last64": all(differences["C_vs_N"][-RETENTION:]),
        "BC_episode_ended_last64": all(v == 0 for v in marker_hist["BC"][-RETENTION:]),
        "C_episode_ended_last64": all(v == 0 for v in marker_hist["C"][-RETENTION:]),
        "response_signatures_t480": sig_t480,
        "C_changes_B_conditioned_response": distinct(sig_t480["BC"], sig_t480["B"]),
        "C_changes_naive_response": distinct(sig_t480["C"], sig_t480["N"]),
        "BC_is_distinct_from_B_C_N": all(distinct(sig_t480["BC"], sig_t480[name]) for name in ("B", "C", "N")),
    }

    # Continue every factorial branch without reconstruction to t704.
    advance(tuple(worlds.values()), 224)
    world_BCB, world_BC = clone(kernel, worlds["BC"]), clone(kernel, worlds["BC"])
    cce03.install(world_BCB, meta, node, "SEM1_WRITER", 704)
    stage_return = run_interval(world_BCB, world_BC, node, 160, (73001,))
    sig_t864 = signatures(kernel, {"BCB": world_BCB, "BC": world_BC}, node, 864)
    stage_return["response_signatures_t864"] = sig_t864
    stage_return["return_B_changes_BC_response"] = distinct(sig_t864["BCB"], sig_t864["BC"])

    B_ok = stage_B["S1_last64"] and stage_B["episode_A_ended_last64"] and stage_B["functional_response_changed"]
    C_ok = (stage_C["BC_vs_B_S1_last64"] and stage_C["BC_episode_ended_last64"]
            and stage_C["C_changes_B_conditioned_response"])
    return_ok = (stage_return["S1_last64"] and stage_return["episode_A_ended_last64"]
                 and stage_return["return_B_changes_BC_response"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.diagnostic_recurrent_sequence.v1",
        "question": "Can the same uninterrupted bounded organization incorporate finite B, then causally distinct C, then B again with retained changes in later response?",
        "planning": {"mechanism": "same-node SEM1(t128) -> D12(t320) -> SEM1(t704) factorial sequence",
                     "controls": ["no experience", "B only", "C only", "B+C", "same-time identical probe", "marker extinction"],
                     "predicted_outcomes": ["first capture only", "C blocked by B", "layered BC", "recurrent B reacquisition"],
                     "estimated_runtime_minutes": 5, "stop_condition": "factorial transition plus third return experience through t864"},
        "design": {"continuous_world": True, "same_bounded_node": node["id"],
                   "events": [{"tick": 128, "type": "SEM1_WRITER_B"}, {"tick": 320, "type": "TWO_PARENT_D12_C"},
                              {"tick": 704, "type": "SEM1_WRITER_B_RETURN"}],
                   "intervention_class": "DIAGNOSTIC_INTERVENTION", "python_functional_interventions_after_t0": 3},
        "stage_B": stage_B, "stage_C": stage_C, "stage_return_B": stage_return,
        "summary": {"B_retained_functional_response": B_ok,
                    "C_after_B_retained_functional_response": C_ok,
                    "return_B_after_BC_retained_functional_response": return_ok,
                    "three_stage_diagnostic_recurrence": B_ok and C_ok and return_ok,
                    "BC_layered_response_class": stage_C["BC_is_distinct_from_B_C_N"],
                    "native_environmental_events": False, "promoted_RW3": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_THREE_STAGE_RECURRENCE" if B_ok and C_ok and return_ok else "BOUNDED_SEQUENCE_OBSTRUCTION",
        "claim_guard": "All three experience events and response probes are host-installed diagnostics. A positive sequence reveals recurrent causal capacity of one organization but cannot satisfy RW3 until blind events are generated physically from t0 and DEE function is native.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    common = {k: v for k, v in result.items() if k not in ("content_sha256", "created_utc")}
    write_json(REPORT_HANDOFF, seal({**common, "report_focus": "diagnostic_handoff", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()}))
    write_json(REPORT_TRANSITION, seal({**common, "report_focus": "regime_transition", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()}))
    world_report = seal({"schema": "dee.v27.ing03.rw3_continuous_world.v1", "status": "DIAGNOSTIC_ONLY",
                         "continuous_diagnostic_world": True, "summary": result["summary"],
                         "rw3_demonstrated": False, "blocking_conditions": ["host-installed B/C/B", "host-installed functional probes", "environment not blind/native"],
                         "source_evidence": OUTPUT.relative_to(ROOT).as_posix(), "source_file_sha256": sha256_file(OUTPUT)})
    write_json(REPORT_WORLD, world_report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
