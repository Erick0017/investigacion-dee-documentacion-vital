#!/usr/bin/env python3
"""Can local interface renewal restore competence while distributed B persists?"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE09_INTERFACE_RENEWAL_DIAGNOSTIC.json"
REPORT = ROOT / "ING03_FUNCTIONAL_COMPETENCE_RENEWAL.json"
TURNOVER_REPORT = ROOT / "ING03_ENDOGENOUS_INTERFACE_TURNOVER.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE08_DIAGNOSTIC_RECURRENT_SEQUENCE.json"
RETENTION = 64
MODES = (
    "NONE", "NODE_R0_RAW", "NODE_R1_RAW", "NODE_R2_RAW", "NODE_R3_RAW",
    "NODE_R6_RAW", "NODE_R10_RAW", "LOCAL_DIFF_R6_RAW", "OUTSIDE_DIFF_R6_RAW",
    "GLOBAL_DIFF_RAW", "LOCAL_DIFF_R6_R0", "NODE_POSITIONS_RAW", "CLOCK_SHIFT37",
)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def copy_mask(target, source, mask, component):
    if component in ("RAW", "R0"):
        target.raw_a[mask] = source.raw[mask]; target.raw_b[mask] = source.raw[mask]
    if component in ("CLOCK", "R0"):
        target.clock_a[mask] = source.clock_a[mask]; target.clock_b[mask] = source.clock_a[mask]


def apply_intervention(target, naive, meta, node, mode):
    raw_diff = target.raw != naive.raw
    clock_diff = target.clock_a != naive.clock_a
    r6 = cce05.domain_mask(meta["n"], node, 6)
    component = "RAW"; mask = np.zeros(target.raw.shape, dtype=bool)
    if mode.startswith("NODE_R"):
        radius = int(mode.split("_R", 1)[1].split("_", 1)[0])
        mask = cce05.domain_mask(meta["n"], node, radius)
    elif mode == "LOCAL_DIFF_R6_RAW": mask = raw_diff & r6
    elif mode == "OUTSIDE_DIFF_R6_RAW": mask = raw_diff & ~r6
    elif mode == "GLOBAL_DIFF_RAW": mask = raw_diff
    elif mode == "LOCAL_DIFF_R6_R0": mask = (raw_diff | clock_diff) & r6; component = "R0"
    elif mode == "NODE_POSITIONS_RAW":
        for q in rca05.node_positions(node, meta["n"]): mask[q] = True
    elif mode == "CLOCK_SHIFT37":
        local = cce05.domain_mask(meta["n"], node, 6)
        target.clock_a[local] += np.uint64(37); target.clock_b[local] += np.uint64(37)
        return {"mode": mode, "component": "CLOCK_SHIFT", "positions": int(local.sum()),
                "raw_differences_equalized": 0, "clock_differences_equalized": 0}
    elif mode == "NONE":
        return {"mode": mode, "component": "NONE", "positions": 0,
                "raw_differences_equalized": 0, "clock_differences_equalized": 0}
    else: raise ValueError(mode)
    record = {"mode": mode, "component": component, "positions": int(mask.sum()),
              "raw_differences_equalized": int(np.count_nonzero(raw_diff & mask)) if component in ("RAW", "R0") else 0,
              "clock_differences_equalized": int(np.count_nonzero(clock_diff & mask)) if component in ("CLOCK", "R0") else 0}
    copy_mask(target, naive, mask, component)
    return record


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel); node = nodes[0]
    for _ in range(128): base.tick()
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    for _ in range(192): learned.tick(); naive.tick()
    sig_learned = cce08.response_signature(kernel, learned, node, 320)
    sig_naive = cce08.response_signature(kernel, naive, node, 320)
    initial_B_function = sig_learned["signature_sha256"] != sig_naive["signature_sha256"]

    rows = []
    for mode in MODES:
        renewed = clone(kernel, learned); control = clone(kernel, learned)
        intervention = apply_intervention(renewed, naive, meta, node, mode)
        apply_intervention(control, naive, meta, node, mode)
        pre_sig = cce08.response_signature(kernel, renewed, node, 320)
        old_B_preserved = (pre_sig["signature_sha256"] == sig_learned["signature_sha256"]
                           and pre_sig["signature_sha256"] != sig_naive["signature_sha256"])
        record = cce03.install(renewed, meta, node, "TWO_PARENT_D12", 320)
        differences = []; markers = []
        for _ in range(160):
            renewed.tick(); control.tick()
            differences.append(r09.delta(renewed, node) != r09.delta(control, node))
            markers.append(marker_count(renewed, record["marker_states"]))
        S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
        probe = cce05.fingerprint_fast(kernel, renewed, control, node, 480)
        C2 = S1 and ended and probe["probe_interaction_differs"]
        renewal = old_B_preserved and C2
        row = {"mode": mode, "intervention": intervention,
               "pre_C_old_B_response_signature": pre_sig["signature_sha256"],
               "old_B_function_preserved": old_B_preserved,
               "C_S0": any(differences), "C_S1_last64": S1,
               "C_episode_ended_last64": ended, "C_probe": probe,
               "C2_after_intervention": C2,
               "functional_competence_renewal_with_old_history_preserved": renewal,
               "intervention_class": "DIAGNOSTIC_INTERVENTION"}
        rows.append(row)
        print(json.dumps({"mode": mode, "B_preserved": old_B_preserved, "C2": C2,
                          "renewal": renewal, "equalized": intervention["raw_differences_equalized"]}, sort_keys=True), flush=True)

    successes = [row["mode"] for row in rows if row["functional_competence_renewal_with_old_history_preserved"]]
    reset_controls = [row["mode"] for row in rows if row["C2_after_intervention"] and not row["old_B_function_preserved"]]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.interface_renewal_diagnostic.v1",
        "question": "Can partial public-state renewal restore C2 competence while the distributed B response remains functional?",
        "planning": {"mechanism": "equalize causally distinct local/global RAW or clock domains before D12 C",
                     "controls": ["no renewal", "growing local domains", "local/outside actual differences", "global reset", "clock shift"],
                     "predicted_outcomes": ["no reopening", "reset-only reopening", "local interface renewal", "outside-history dependence"],
                     "estimated_runtime_minutes": 6, "stop_condition": "13 diagnostic interventions with identical C/no-C comparison"},
        "design": {"B_tick": 128, "renewal_and_C_tick": 320, "same_node": node["id"],
                   "modes": list(MODES), "diagnostic_only": True},
        "initial_B_function_present": initial_B_function,
        "reference_signatures": {"B": sig_learned["signature_sha256"], "naive": sig_naive["signature_sha256"]},
        "rows": rows,
        "summary": {"old_B_preserving_competence_renewal_modes": successes,
                    "reset_only_C2_modes": reset_controls,
                    "diagnostic_functional_competence_renewal": bool(successes),
                    "endogenous_turnover_demonstrated": False,
                    "native_renewal_demonstrated": False, "rw4_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_RENEWAL_CANDIDATE" if successes else "BOUNDED_NULL_OR_RESET_ONLY",
        "claim_guard": "Host equalization is a causal diagnostic, not endogenous turnover. A success identifies a separable renewable interface but cannot satisfy RW4 until the same renewal occurs under unmodified DEE dynamics.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    turnover = seal({"schema": "dee.v27.ing03.endogenous_interface_turnover.v1",
                     "status": "NOT_DEMONSTRATED", "diagnostic_renewal_candidates": successes,
                     "endogenous_turnover_demonstrated": False,
                     "reason": "all tested renewal operations were host equalizations at t320",
                     "source_evidence": OUTPUT.relative_to(ROOT).as_posix(), "source_file_sha256": sha256_file(OUTPUT)})
    write_json(TURNOVER_REPORT, turnover)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
