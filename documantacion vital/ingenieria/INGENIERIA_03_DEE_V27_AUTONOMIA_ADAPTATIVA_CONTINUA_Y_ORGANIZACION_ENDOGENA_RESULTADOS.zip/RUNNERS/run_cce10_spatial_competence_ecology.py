#!/usr/bin/env python3
"""Diagnostic spatial competence ecology: node1 B -> node2 C -> node3 D."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE10_SPATIAL_COMPETENCE_ECOLOGY.json"
REPORT_ECOLOGY = ROOT / "ING03_CONTINUOUS_CAUSAL_ECOLOGY.json"
REPORT_DEVELOPMENT = ROOT / "ING03_DEVELOPMENTAL_STATE_MAP.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE09_INTERFACE_RENEWAL_DIAGNOSTIC.json"
RETENTION = 64


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def experience_pair(kernel, history, meta, node, tick, mode):
    yes, no = clone(kernel, history), clone(kernel, history)
    record = cce03.install(yes, meta, node, mode, tick)
    differences = []; markers = []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, record["marker_states"]))
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160)
    S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    return yes, no, {"node_id": node["id"], "tick": tick, "mode": mode,
                     "S0": any(differences), "S1_last64": S1, "episode_ended_last64": ended,
                     "first_difference_latency": next((i + 1 for i, v in enumerate(differences) if v), None),
                     "probe": probe, "C2_response_class": S1 and ended and probe["probe_interaction_differs"]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = rca02.build(kernel)
    advance((base,), 128)
    B, N, stage_B = experience_pair(kernel, base, meta, nodes[0], 128, "SEM1_WRITER")
    # experience_pair ends at t288; reach the known t320 opportunity without rebuilding.
    advance((B, N), 32)
    sig_B_before = cce08.response_signature(kernel, B, nodes[0], 320)
    sig_N_before = cce08.response_signature(kernel, N, nodes[0], 320)
    stage_B["node1_function_present_t320"] = sig_B_before["signature_sha256"] != sig_N_before["signature_sha256"]

    BC, B_control, stage_C = experience_pair(kernel, B, meta, nodes[1], 320, "TWO_PARENT_D12")
    sig_B_after_C = cce08.response_signature(kernel, BC, nodes[0], 480)
    sig_B_without_C = cce08.response_signature(kernel, B_control, nodes[0], 480)
    sig_C_after = cce08.response_signature(kernel, BC, nodes[1], 480)
    sig_C_control = cce08.response_signature(kernel, B_control, nodes[1], 480)
    stage_C["old_node1_response_preserved"] = sig_B_after_C["signature_sha256"] == sig_B_without_C["signature_sha256"]
    stage_C["node2_response_changed"] = sig_C_after["signature_sha256"] != sig_C_control["signature_sha256"]

    # Continue the two histories to a late opportunity and test the third morphology.
    advance((BC, B_control), 224)  # t480 -> t704
    BCD, BC_control, stage_D = experience_pair(kernel, BC, meta, nodes[2], 704, "TWO_PARENT_D12")
    sig_node1_D = cce08.response_signature(kernel, BCD, nodes[0], 864)
    sig_node1_noD = cce08.response_signature(kernel, BC_control, nodes[0], 864)
    sig_node2_D = cce08.response_signature(kernel, BCD, nodes[1], 864)
    sig_node2_noD = cce08.response_signature(kernel, BC_control, nodes[1], 864)
    stage_D["old_node1_response_preserved"] = sig_node1_D["signature_sha256"] == sig_node1_noD["signature_sha256"]
    stage_D["old_node2_response_preserved"] = sig_node2_D["signature_sha256"] == sig_node2_noD["signature_sha256"]

    two_region = (stage_B["C2_response_class"] and stage_B["node1_function_present_t320"]
                  and stage_C["C2_response_class"] and stage_C["node2_response_changed"]
                  and stage_C["old_node1_response_preserved"])
    three_region = two_region and stage_D["C2_response_class"]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.spatial_competence_ecology.v1",
        "question": "Can distinct regions of one bounded organization capture successive experiences while earlier regional response classes persist?",
        "planning": {"mechanism": "three causally rotated developmental regions sampled sequentially",
                     "controls": ["same-history no-event branch at each stage", "finite marker extinction", "identical later probe", "old-region response preservation"],
                     "predicted_outcomes": ["global saturation", "two-region layering", "three-region layering", "cross-region interference"],
                     "estimated_runtime_minutes": 3, "stop_condition": "node1 B, node2 C and node3 D through t864"},
        "design": {"events": [{"tick": 128, "node": 1, "mode": "SEM1_WRITER"},
                              {"tick": 320, "node": 2, "mode": "TWO_PARENT_D12"},
                              {"tick": 704, "node": 3, "mode": "TWO_PARENT_D12"}],
                   "bounded_regions": 3, "diagnostic_only": True, "preassigned_recipients": True},
        "stage_B": stage_B, "stage_C": stage_C, "stage_D": stage_D,
        "summary": {"two_region_layered_diagnostic_history": two_region,
                    "three_region_layered_diagnostic_history": three_region,
                    "third_region_C2": stage_D["C2_response_class"],
                    "renewal_or_reuse_demonstrated": False,
                    "one_shot_region_consumption": True,
                    "native_blind_environment": False, "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_BOUNDED_SPATIAL_LAYERING" if two_region else "BOUNDED_NULL",
        "claim_guard": "Recipients are explicitly selected and each region is used once. Even a positive result is finite spatial accumulation, not endogenous capture, renewal, RW3 or RW4.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    common = {k: v for k, v in result.items() if k not in ("content_sha256", "created_utc")}
    write_json(REPORT_ECOLOGY, seal({**common, "report_focus": "continuous_causal_ecology", "source_evidence": OUTPUT.relative_to(ROOT).as_posix()}))
    development = seal({"schema": "dee.v27.ing03.developmental_state_map.v1",
                        "sampled_events": result["design"]["events"],
                        "stage_results": {"node1": stage_B, "node2": stage_C, "node3": stage_D},
                        "interpretation": "spatial competence is history- and morphology-dependent; tested recipients remain preassigned diagnostics",
                        "continuous_renewal_demonstrated": False,
                        "source_evidence": OUTPUT.relative_to(ROOT).as_posix(), "source_file_sha256": sha256_file(OUTPUT)})
    write_json(REPORT_DEVELOPMENT, development)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
