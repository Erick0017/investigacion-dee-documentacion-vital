#!/usr/bin/env python3
"""Exact subset decomposition of the four local B-history RAW differences."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce09_interface_renewal_diagnostic as cce09
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE11_MINIMAL_INTERFACE_SEPARATION.json"
REPORT = ROOT / "ING03_MINIMAL_INTERFACE_SEPARATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE09_INTERFACE_RENEWAL_DIAGNOSTIC.json"
RETENTION = 64


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def toroidal_offset(q, center, n):
    out = []
    for value, origin in zip(q, center):
        d = (int(value) - int(origin)) % n
        if d > n // 2: d -= n
        out.append(d)
    return tuple(out)


def add_offset(center, offset, n): return tuple((int(c) + int(d)) % n for c, d in zip(center, offset))


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def build_history(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128)
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    advance((learned, naive), 192)
    return learned, naive, meta, node


def evaluate_frame(kernel, node_id, canonical_offsets=None):
    learned, naive, meta, node = build_history(kernel, node_id)
    local = cce05.domain_mask(meta["n"], node, 1)
    positions = [tuple(int(x) for x in row) for row in np.argwhere((learned.raw != naive.raw) & local)]
    offsets = sorted(r09.transform(toroidal_offset(q, node["center"], meta["n"]), node["frame"])
                     for q in positions)
    if canonical_offsets is not None and sorted(canonical_offsets) != offsets:
        raise RuntimeError(f"relational four-state morphology did not generalize: {offsets} != {canonical_offsets}")
    positions = [add_offset(node["center"], r09.transform(offset, node["frame"]), meta["n"])
                 for offset in offsets]
    state_map = [{"index": i, "offset_from_node_center": list(offset), "position": list(q),
                  "learned": unpack_scalar(learned.raw[q]), "naive": unpack_scalar(naive.raw[q]) if int(naive.raw[q]) else None}
                 for i, (offset, q) in enumerate(zip(offsets, positions))]
    if len(positions) != 4: raise RuntimeError(f"expected four local differences, observed {len(positions)}")
    sig_B = cce08.response_signature(kernel, learned, node, 320)["signature_sha256"]
    sig_N = cce08.response_signature(kernel, naive, node, 320)["signature_sha256"]
    rows = []
    for bits in range(16):
        selected = [i for i in range(4) if bits & (1 << i)]
        renewed, control = clone(kernel, learned), clone(kernel, learned)
        for index in selected:
            q = positions[index]
            for world in (renewed, control):
                world.raw_a[q] = naive.raw[q]; world.raw_b[q] = naive.raw[q]
        sig_pre = cce08.response_signature(kernel, renewed, node, 320)["signature_sha256"]
        B_preserved = sig_pre == sig_B and sig_pre != sig_N
        record = cce03.install(renewed, meta, node, "TWO_PARENT_D12", 320)
        differences = []; markers = []
        for _ in range(160):
            renewed.tick(); control.tick()
            differences.append(r09.delta(renewed, node) != r09.delta(control, node))
            markers.append(marker_count(renewed, record["marker_states"]))
        S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
        probe = cce05.fingerprint_fast(kernel, renewed, control, node, 480)
        C2 = S1 and ended and probe["probe_interaction_differs"]
        rows.append({"subset_bits": format(bits, "04b"), "selected_indices": selected,
                     "selected_offsets": [list(offsets[i]) for i in selected],
                     "B_function_preserved": B_preserved, "C_S1": S1, "C_episode_ended": ended,
                     "C2_restored": C2, "B_and_C2": B_preserved and C2,
                     "pre_C_signature": sig_pre, "probe": probe})
    return {"node_id": node_id, "frame": node["frame"], "local_state_map": state_map,
            "canonical_offsets": [list(x) for x in offsets], "reference_B_signature": sig_B,
            "reference_naive_signature": sig_N, "rows": rows,
            "separating_subsets": [row["subset_bits"] for row in rows if row["B_and_C2"]],
            "B_preserving_subsets": [row["subset_bits"] for row in rows if row["B_function_preserved"]],
            "C2_restoring_subsets": [row["subset_bits"] for row in rows if row["C2_restored"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_frame(kernel, 1)
    holdout = evaluate_frame(kernel, 2, [tuple(x) for x in discovery["canonical_offsets"]])
    replicated = sorted(set(discovery["separating_subsets"]) & set(holdout["separating_subsets"]))
    for frame in (discovery, holdout):
        print(json.dumps({"node": frame["node_id"], "frame": frame["frame"],
                          "B_preserving": frame["B_preserving_subsets"],
                          "C2_restoring": frame["C2_restoring_subsets"],
                          "separating": frame["separating_subsets"]}, sort_keys=True), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.minimal_interface_separation.v1",
        "question": "Can any exact subset of the four local B-history RAW differences be renewed to restore C2 while preserving B function?",
        "planning": {"mechanism": "complete 2^4 causal equalization truth table",
                     "controls": ["zero subset", "full subset", "B/naive response signatures", "D12/no-D12", "second relational frame"],
                     "predicted_outcomes": ["separable function/refractoriness", "inseparable tradeoff", "frame-specific split"],
                     "estimated_runtime_minutes": 4, "stop_condition": "all 16 subsets in discovery and holdout frames"},
        "design": {"discovery_node": 1, "holdout_node": 2, "B_tick": 128, "renewal_C_tick": 320,
                   "subset_count_per_frame": 16, "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_separating_subsets": replicated,
                    "minimal_public_RAW_separation_demonstrated": bool(replicated),
                    "complete_four_state_truth_table": True,
                    "native_renewal_demonstrated": False, "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_SEPARATION_CANDIDATE" if replicated else "CONTRADICTED_IN_TESTED_DOMAIN",
        "claim_guard": "The exact truth table is limited to four public RAW differences and host equalization. Absence of a separating subset does not exclude transformations of hidden X_FULL coordinates, topology, phase or larger collective organization.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
