#!/usr/bin/env python3
"""Renew the local interface at t288, before the t320 compact bottleneck."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE12_PRECONSOLIDATION_INTERFACE_RENEWAL.json"
REPORT = ROOT / "ING03_PRECONSOLIDATION_INTERFACE_RENEWAL.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE11_MINIMAL_INTERFACE_SEPARATION.json"
MODES = ("NONE", "CRITICAL_OFFSET_RAW", "NODE_R1_RAW", "LOCAL_DIFF_R6_RAW", "GLOBAL_DIFF_RAW")
C_TICKS = (288, 304, 320)
CRITICAL_CANONICAL_OFFSET = (1, -1, -1)
RETENTION = 64


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def apply(target, naive, meta, node, mode):
    raw_diff = target.raw != naive.raw
    if mode == "NONE": mask = np.zeros(target.raw.shape, dtype=bool)
    elif mode == "CRITICAL_OFFSET_RAW":
        mask = np.zeros(target.raw.shape, dtype=bool)
        physical = r09.transform(CRITICAL_CANONICAL_OFFSET, node["frame"])
        q = cce11.add_offset(node["center"], physical, meta["n"]); mask[q] = True
    elif mode == "NODE_R1_RAW": mask = cce05.domain_mask(meta["n"], node, 1)
    elif mode == "LOCAL_DIFF_R6_RAW": mask = raw_diff & cce05.domain_mask(meta["n"], node, 6)
    elif mode == "GLOBAL_DIFF_RAW": mask = raw_diff
    else: raise ValueError(mode)
    count = int(np.count_nonzero(raw_diff & mask))
    target.raw_a[mask] = naive.raw[mask]; target.raw_b[mask] = naive.raw[mask]
    return {"mode": mode, "positions": int(mask.sum()), "raw_differences_equalized": count}


def history(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128)
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    advance((learned, naive), 160)
    return learned, naive, meta, node


def assay(kernel, learned288, naive288, meta, node, mode, c_tick):
    renewed = clone(kernel, learned288); record = apply(renewed, naive288, meta, node, mode)
    reference_B, reference_N = clone(kernel, learned288), clone(kernel, naive288)
    delay = c_tick - 288; advance((renewed, reference_B, reference_N), delay)
    sig_R = cce08.response_signature(kernel, renewed, node, c_tick)["signature_sha256"]
    sig_B = cce08.response_signature(kernel, reference_B, node, c_tick)["signature_sha256"]
    sig_N = cce08.response_signature(kernel, reference_N, node, c_tick)["signature_sha256"]
    B_preserved = sig_R == sig_B and sig_R != sig_N
    yes, no = clone(kernel, renewed), clone(kernel, renewed)
    c_record = cce03.install(yes, meta, node, "TWO_PARENT_D12", c_tick)
    differences = []; markers = []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, c_record["marker_states"]))
    S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, c_tick + 160)
    C2 = S1 and ended and probe["probe_interaction_differs"]
    return {"mode": mode, "renewal_tick": 288, "C_tick": c_tick, "intervention": record,
            "B_function_preserved_at_C": B_preserved, "C_S1": S1, "C_episode_ended": ended,
            "C2_restored": C2, "B_and_C2": B_preserved and C2, "probe": probe,
            "signatures": {"renewed": sig_R, "B": sig_B, "naive": sig_N}}


def evaluate_node(kernel, node_id):
    learned, naive, meta, node = history(kernel, node_id)
    rows = [assay(kernel, learned, naive, meta, node, mode, tick) for mode in MODES for tick in C_TICKS]
    return {"node_id": node_id, "frame": node["frame"], "rows": rows,
            "candidates": [{"mode": row["mode"], "C_tick": row["C_tick"]} for row in rows if row["B_and_C2"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    print(json.dumps({"node": 1, "candidates": discovery["candidates"]}, sort_keys=True), flush=True)
    holdout = evaluate_node(kernel, 2)
    print(json.dumps({"node": 2, "candidates": holdout["candidates"]}, sort_keys=True), flush=True)
    d = {(x["mode"], x["C_tick"]) for x in discovery["candidates"]}
    h = {(x["mode"], x["C_tick"]) for x in holdout["candidates"]}
    replicated = [{"mode": mode, "C_tick": tick} for mode, tick in sorted(d & h)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.preconsolidation_renewal.v1",
        "question": "Can early local renewal preserve distributed B history and restore later C2 after rematuration?",
        "planning": {"mechanism": "renew at t288, then allow 0/16/32 ticks before C",
                     "controls": ["no renewal", "critical state", "r1 domain", "local r6 differences", "global reset", "second frame"],
                     "predicted_outcomes": ["immediate reset", "distributed B preservation plus renewed C2", "recompaction to refractory state"],
                     "estimated_runtime_minutes": 5, "stop_condition": "15 timing/mode panels in two frames"},
        "design": {"B_tick": 128, "renewal_tick": 288, "C_ticks": list(C_TICKS), "modes": list(MODES),
                   "critical_offset": list(CRITICAL_CANONICAL_OFFSET), "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_B_preserving_C2_candidates": replicated,
                    "preconsolidation_interface_renewal_demonstrated": bool(replicated),
                    "native_turnover_demonstrated": False, "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_PRECONSOLIDATION_RENEWAL" if replicated else "CONTRADICTED_IN_TESTED_DOMAIN",
        "claim_guard": "All renewals and C events are host diagnostics. A positive result would identify timing for native turnover design, not itself establish endogenous renewal or RW3/RW4.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
