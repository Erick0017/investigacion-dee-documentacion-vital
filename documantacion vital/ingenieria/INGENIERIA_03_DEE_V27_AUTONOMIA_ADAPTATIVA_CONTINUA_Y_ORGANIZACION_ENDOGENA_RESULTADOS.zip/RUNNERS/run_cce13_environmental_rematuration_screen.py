#!/usr/bin/env python3
"""Screen finite incoming pressures for B destabilization -> renewed C2."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE13_ENVIRONMENTAL_REMATURATION_SCREEN.json"
REPORT = ROOT / "ING03_MATURE_REGIME_REMATURATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE12_PRECONSOLIDATION_INTERFACE_RENEWAL.json"
DIRECTIONS = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))
SEMANTICS = (1, 2, 3, 4)
PRESSURE_TICK = 304
C_TICK = 320
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def marker_count(world, state): return int(np.count_nonzero((world.raw & np.uint64(0xFFFFFFFF)) == state))


def build_B(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128)
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    advance((learned, naive), PRESSURE_TICK - 128)
    physical = r09.transform(CRITICAL_OFFSET, node["frame"])
    critical = cce11.add_offset(node["center"], physical, meta["n"])
    return learned, naive, meta, node, critical


def assay(kernel, learned304, naive304, meta, node, critical, direction, semantic, serial):
    pressured, pressure_control = clone(kernel, learned304), clone(kernel, learned304)
    physical_direction = r09.transform(direction, node["frame"])
    source = tuple((critical[i] - physical_direction[i]) % meta["n"] for i in range(3))
    if int(pressured.raw[source]):
        return {"valid": False, "direction": list(direction), "semantic": semantic,
                "reason": "incoming source occupied", "source": list(source)}
    state = 79000 + serial
    set_both(pressured, source, int(pack(state, 0, physical_direction, semantic)), PRESSURE_TICK)
    critical_before = int(learned304.raw[critical]); markers = []
    for _ in range(C_TICK - PRESSURE_TICK):
        pressured.tick(); pressure_control.tick(); markers.append(marker_count(pressured, state))
    critical_after = int(pressured.raw[critical]); pressure_ended = markers[-1] == 0
    yes, no = clone(kernel, pressured), clone(kernel, pressured)
    c_record = cce03.install(yes, meta, node, "TWO_PARENT_D12", C_TICK)
    differences = []; cmarkers = []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        cmarkers.append(sum(marker_count(yes, state_id) for state_id in c_record["marker_states"]))
    S1 = all(differences[-RETENTION:]); C_ended = all(v == 0 for v in cmarkers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, C_TICK + 160)
    C2 = S1 and C_ended and probe["probe_interaction_differs"]
    row = {"valid": True, "direction": list(direction), "physical_direction": list(physical_direction),
           "semantic": semantic, "source": list(source), "critical": list(critical),
           "critical_before": unpack_scalar(critical_before),
           "critical_after_pressure": unpack_scalar(critical_after) if critical_after else None,
           "critical_changed": critical_after != critical_before,
           "pressure_marker_ended_by_C_tick": pressure_ended, "C_S1": S1, "C_episode_ended": C_ended,
           "C2_after_pressure": C2, "probe": probe, "intervention_class": "DIAGNOSTIC_INTERVENTION"}
    if C2:
        sig_pressure = cce08.response_signature(kernel, pressured, node, C_TICK)["signature_sha256"]
        sig_B = cce08.response_signature(kernel, pressure_control, node, C_TICK)["signature_sha256"]
        naive320 = clone(kernel, naive304); advance((naive320,), C_TICK - PRESSURE_TICK)
        sig_N = cce08.response_signature(kernel, naive320, node, C_TICK)["signature_sha256"]
        row["pre_C_regime"] = "B" if sig_pressure == sig_B else ("NAIVE" if sig_pressure == sig_N else "THIRD")
        row["pre_C_signatures"] = {"pressure": sig_pressure, "B": sig_B, "naive": sig_N}
    return row


def evaluate_node(kernel, node_id):
    learned, naive, meta, node, critical = build_B(kernel, node_id)
    rows = []; serial = 0
    for direction in DIRECTIONS:
        for semantic in SEMANTICS:
            rows.append(assay(kernel, learned, naive, meta, node, critical, direction, semantic, serial)); serial += 1
    candidates = [{"direction": row["direction"], "semantic": row["semantic"],
                   "critical_changed": row["critical_changed"], "pre_C_regime": row.get("pre_C_regime")}
                  for row in rows if row.get("valid") and row["pressure_marker_ended_by_C_tick"] and row["C2_after_pressure"]]
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows, "candidates": candidates}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    print(json.dumps({"node": 1, "valid": sum(r.get("valid", False) for r in discovery["rows"]),
                      "candidates": discovery["candidates"]}, sort_keys=True), flush=True)
    # Fresh frame is run only if discovery provides a discriminating mechanism.
    holdout = evaluate_node(kernel, 2) if discovery["candidates"] else None
    if holdout: print(json.dumps({"node": 2, "candidates": holdout["candidates"]}, sort_keys=True), flush=True)
    d = {(tuple(x["direction"]), x["semantic"]) for x in discovery["candidates"]}
    h = {(tuple(x["direction"]), x["semantic"]) for x in holdout["candidates"]} if holdout else set()
    replicated = [{"direction": list(direction), "semantic": semantic} for direction, semantic in sorted(d & h)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.environmental_rematuration_screen.v1",
        "question": "Can a finite incoming environmental interaction destabilize the mature B bottleneck and restore C2 competence?",
        "planning": {"mechanism": "24 direction/semantic incoming collisions with the critical interface state",
                     "controls": ["unpressured same-history C", "finite marker extinction", "critical-state telemetry", "fresh frame if positive"],
                     "predicted_outcomes": ["no interaction", "damage without C2", "reset-like reopening", "third-regime rematuration"],
                     "estimated_runtime_minutes": 4, "stop_condition": "six directions x four semantics; fresh relational frame for candidates"},
        "design": {"pressure_tick": PRESSURE_TICK, "C_tick": C_TICK, "directions": [list(x) for x in DIRECTIONS],
                   "semantics": list(SEMANTICS), "critical_offset": list(CRITICAL_OFFSET), "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"discovery_candidates": discovery["candidates"], "fresh_replicated_candidates": replicated,
                    "diagnostic_environmental_rematuration": bool(replicated),
                    "native_blind_rematuration": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_REMATURATION_CANDIDATE" if replicated else "BOUNDED_NULL",
        "claim_guard": "Incoming carriers are diagnostically aimed at the known causal bottleneck. Promotion requires a blind environment, direct-path exclusion and all-t0 generation.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
