#!/usr/bin/env python3
"""Follow the semantic4-induced critical-state transition through relaxation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE14_REMATURATION_RELAXATION.json"
REPORT = ROOT / "ING03_REMATURATION_RELAXATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE13_ENVIRONMENTAL_REMATURATION_SCREEN.json"
PRESSURE_TICK = 304
C_TICKS = (320, 336, 352, 384, 448, 512)
DIRECTIONS = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def marker_count(world, state): return int(np.count_nonzero((world.raw & np.uint64(0xFFFFFFFF)) == state))


def build_B(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128); learned = clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128); advance((learned,), PRESSURE_TICK - 128)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, meta, node, critical


def install_pressure(world, meta, node, critical, direction, state):
    physical = r09.transform(direction, node["frame"])
    source = tuple((critical[i] - physical[i]) % meta["n"] for i in range(3))
    if int(world.raw[source]): raise RuntimeError(f"occupied {source}")
    set_both(world, source, int(pack(state, 0, physical, 4)), PRESSURE_TICK)
    return source


def c_assay(kernel, state, meta, node, tick):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, "TWO_PARENT_D12", tick)
    differences = []; markers = []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        values = yes.raw & np.uint64(0xFFFFFFFF)
        markers.append(int(sum(np.count_nonzero(values == x) for x in record["marker_states"])))
    S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160)
    return {"C_S1": S1, "C_episode_ended": ended, "probe": probe,
            "C2": S1 and ended and probe["probe_interaction_differs"]}


def evaluate_node(kernel, node_id):
    rows = []
    for serial, direction in enumerate(DIRECTIONS):
        learned, meta, node, critical = build_B(kernel, node_id)
        state_id = 79500 + serial
        source = install_pressure(learned, meta, node, critical, direction, state_id)
        current = PRESSURE_TICK
        for tick in C_TICKS:
            advance((learned,), tick - current); current = tick
            critical_raw = int(learned.raw[critical]); pressure_markers = marker_count(learned, state_id)
            c = c_assay(kernel, learned, meta, node, tick)
            rows.append({"direction": list(direction), "source": list(source), "tick": tick,
                         "critical_state": unpack_scalar(critical_raw) if critical_raw else None,
                         "pressure_marker_count": pressure_markers,
                         "pressure_episode_ended": pressure_markers == 0, **c})
    candidates = [{"direction": row["direction"], "tick": row["tick"],
                   "critical_state": row["critical_state"]}
                  for row in rows if row["pressure_episode_ended"] and row["C2"]]
    return {"node_id": node_id, "rows": rows, "candidates": candidates}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    print(json.dumps({"node": 1, "candidates": discovery["candidates"],
                      "states": [{"d": r["direction"], "t": r["tick"], "s": None if r["critical_state"] is None else r["critical_state"]["state"], "m": r["pressure_marker_count"]} for r in discovery["rows"]]}, sort_keys=True), flush=True)
    holdout = evaluate_node(kernel, 2) if discovery["candidates"] else None
    if holdout: print(json.dumps({"node": 2, "candidates": holdout["candidates"]}, sort_keys=True), flush=True)
    d = {(tuple(x["direction"]), x["tick"]) for x in discovery["candidates"]}
    h = {(tuple(x["direction"]), x["tick"]) for x in holdout["candidates"]} if holdout else set()
    replicated = [{"direction": list(direction), "tick": tick} for direction, tick in sorted(d & h)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.rematuration_relaxation.v1",
        "question": "Does the semantic4-induced 3→4 bottleneck transition relax into renewed C2 competence after the pressure episode ends?",
        "planning": {"mechanism": "follow three causal arrival directions through six post-pressure times",
                     "controls": ["marker extinction", "critical-state trajectory", "identical C/no-C challenge", "fresh frame if positive"],
                     "predicted_outcomes": ["persistent damage", "return to B refractory state", "transient competence", "rematuration to new regime"],
                     "estimated_runtime_minutes": 4, "stop_condition": "three directions through t512 and C2 assays"},
        "design": {"pressure_tick": PRESSURE_TICK, "C_ticks": list(C_TICKS), "semantic": 4,
                   "directions": [list(x) for x in DIRECTIONS], "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"discovery_candidates": discovery["candidates"], "fresh_replicated_candidates": replicated,
                    "relaxed_rematuration_demonstrated": bool(replicated), "native_blind_rematuration": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_RELAXED_REMATURATION" if replicated else "BOUNDED_NULL",
        "claim_guard": "Pressure is aimed diagnostically at the known bottleneck and C is host-installed. A positive relaxation would still require blind all-t0 reconstruction and native function.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
