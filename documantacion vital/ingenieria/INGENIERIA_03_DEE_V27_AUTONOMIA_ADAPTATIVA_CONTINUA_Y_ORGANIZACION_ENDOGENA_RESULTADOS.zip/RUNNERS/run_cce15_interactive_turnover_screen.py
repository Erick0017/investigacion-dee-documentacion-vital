#!/usr/bin/env python3
"""Search finite single/two-parent interactions that transform the B bottleneck."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE15_INTERACTIVE_TURNOVER_SCREEN.json"
REPORT = ROOT / "ING03_INTERACTIVE_TURNOVER_SCREEN.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE14_REMATURATION_RELAXATION.json"
PRESSURE_TICK = 304
C_TICK = 320
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)
SREGS = (0, 3, 100, 101, 65535)
SEMANTICS = (1, 2, 3)
SINGLE_DIRECTIONS = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
PARENT_PAIRS = (((1, 0, 0), (0, 1, 0)), ((1, 0, 0), (0, 0, 1)), ((0, 1, 0), (0, 0, 1)))


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def build_B(kernel):
    base, meta, nodes = rca02.build(kernel); node = nodes[0]
    advance((base,), 128); learned = clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128); advance((learned,), PRESSURE_TICK - 128)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, meta, node, critical


def install_mode(world, meta, node, critical, mode, serial):
    states = []; sources = []
    directions = [mode["direction"]] if mode["family"] == "SINGLE" else list(mode["directions"])
    for index, canonical in enumerate(directions):
        direction = r09.transform(canonical, node["frame"])
        source = tuple((critical[i] - direction[i]) % meta["n"] for i in range(3))
        if int(world.raw[source]): return None
        state = 80000 + serial * 2 + index
        set_both(world, source, int(pack(state, mode["sreg"], direction, mode["semantic"])), PRESSURE_TICK)
        states.append(state); sources.append(list(source))
    return {"states": states, "sources": sources}


def c_assay(kernel, state, meta, node):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, "TWO_PARENT_D12", C_TICK)
    differences = []; markers = []
    for _ in range(160):
        yes.tick(); no.tick(); differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, record["marker_states"]))
    S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, C_TICK + 160)
    return {"C_S1": S1, "C_episode_ended": ended, "probe": probe,
            "C2": S1 and ended and probe["probe_interaction_differs"]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    learned, meta, node, critical = build_B(kernel); before = int(learned.raw[critical])
    modes = []
    for direction in SINGLE_DIRECTIONS:
        for semantic in SEMANTICS:
            for sreg in SREGS: modes.append({"family": "SINGLE", "direction": direction, "semantic": semantic, "sreg": sreg})
    for directions in PARENT_PAIRS:
        for semantic in SEMANTICS:
            modes.append({"family": "TWO_PARENT", "directions": directions, "semantic": semantic, "sreg": 3})
    rows = []
    for serial, mode in enumerate(modes):
        world = clone(kernel, learned); installed = install_mode(world, meta, node, critical, mode, serial)
        if installed is None:
            rows.append({"mode": mode, "valid": False, "reason": "occupied source"}); continue
        advance((world,), C_TICK - PRESSURE_TICK)
        after = int(world.raw[critical]); remaining = marker_count(world, installed["states"])
        row = {"mode": mode, "valid": True, "installed": installed,
               "critical_before": unpack_scalar(before), "critical_after": unpack_scalar(after) if after else None,
               "critical_changed": after != before, "pressure_marker_count": remaining,
               "finite_transition": after != before and remaining == 0}
        if row["finite_transition"]: row["competence"] = c_assay(kernel, world, meta, node)
        rows.append(row)
    finite = [row for row in rows if row.get("finite_transition")]
    candidates = [row for row in finite if row["competence"]["C2"]]
    print(json.dumps({"valid": sum(r.get("valid", False) for r in rows), "finite_transitions": len(finite),
                      "C2_candidates": len(candidates),
                      "candidate_modes": [r["mode"] for r in candidates]}, sort_keys=True), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.interactive_turnover_screen.v1",
        "question": "Can finite state-regulated or two-parent interactions transform the mature B bottleneck and restore C2?",
        "planning": {"mechanism": "45 single-parent s_reg/semantic interactions plus nine two-parent collisions",
                     "controls": ["marker extinction", "critical-state change", "C/no-C response", "unpressured C from CCE12"],
                     "predicted_outcomes": ["rejection", "persistent transformed state", "finite turnover without competence", "functional rematuration"],
                     "estimated_runtime_minutes": 3, "stop_condition": "54 causally distinct collision states; C2 only for finite transformations"},
        "design": {"pressure_tick": PRESSURE_TICK, "C_tick": C_TICK, "s_regs": list(SREGS),
                   "semantics": list(SEMANTICS), "single_directions": [list(x) for x in SINGLE_DIRECTIONS],
                   "two_parent_pairs": [[list(a), list(b)] for a, b in PARENT_PAIRS], "diagnostic_only": True},
        "rows": rows,
        "summary": {"valid_modes": sum(r.get("valid", False) for r in rows),
                    "finite_bottleneck_transitions": len(finite), "C2_rematuration_candidates": len(candidates),
                    "interactive_turnover_restores_competence": bool(candidates),
                    "native_turnover_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_TURNOVER_CANDIDATE" if candidates else "BOUNDED_NULL",
        "claim_guard": "This targeted screen is bounded to tested RAW collision classes. It does not exclude topology/phase/collective turnover and cannot establish endogenous blind renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
