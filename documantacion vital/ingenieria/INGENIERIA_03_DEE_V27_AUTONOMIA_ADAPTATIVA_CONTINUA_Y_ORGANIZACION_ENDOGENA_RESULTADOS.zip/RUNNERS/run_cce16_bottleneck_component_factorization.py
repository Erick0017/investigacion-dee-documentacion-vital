#!/usr/bin/env python3
"""Factor the critical RAW coordinate into state/s_reg/direction/semantic roles."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE16_BOTTLENECK_COMPONENT_FACTORIZATION.json"
REPORT = ROOT / "ING03_BOTTLENECK_COMPONENT_FACTORIZATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE15_INTERACTIVE_TURNOVER_SCREEN.json"
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)
MODES = (
    {"id": "BASE", "component": "NONE"},
    *({"id": f"SREG_{value}", "component": "SREG", "value": value} for value in (1, 2, 3, 100, 101, 65535)),
    *({"id": f"SEMANTIC_{value}", "component": "SEMANTIC", "value": value} for value in (2, 3, 4)),
    {"id": "DIRECTION_ZERO", "component": "DIRECTION", "value": (0, 0, 0)},
    {"id": "DIRECTION_REVERSE", "component": "DIRECTION", "value": (0, 1, 1)},
    {"id": "DIRECTION_ROUTE", "component": "DIRECTION", "value": (0, 0, 1)},
    {"id": "DIRECTION_X", "component": "DIRECTION", "value": (1, 0, 0)},
    {"id": "DIRECTION_Y", "component": "DIRECTION", "value": (0, 1, 0)},
    *({"id": f"STATE_{value}", "component": "STATE", "value": value} for value in (1, 2, 4)),
)


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_raw(world, q, raw): world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def build_B(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128); learned = clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128); advance((learned,), 192)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, meta, node, critical


def mutate(original, mode, frame):
    fields = unpack_scalar(original)
    state, sreg, direction, semantic = fields["state"], fields["sreg"], tuple(fields["direction"]), fields["semantic"]
    component = mode["component"]
    if component == "SREG": sreg = mode["value"]
    elif component == "SEMANTIC": semantic = mode["value"]
    elif component == "DIRECTION": direction = r09.transform(mode["value"], frame)
    elif component == "STATE": state = mode["value"]
    return int(pack(state, sreg, direction, semantic))


def evaluate_node(kernel, node_id):
    learned, meta, node, critical = build_B(kernel, node_id); original = int(learned.raw[critical])
    original_sig = cce08.response_signature(kernel, learned, node, 320)["signature_sha256"]
    rows = []
    for mode in MODES:
        changed, control = clone(kernel, learned), clone(kernel, learned)
        new_raw = mutate(original, mode, node["frame"]); set_raw(changed, critical, new_raw); set_raw(control, critical, new_raw)
        pre_sig = cce08.response_signature(kernel, changed, node, 320)["signature_sha256"]
        B_preserved = pre_sig == original_sig
        rec = cce03.install(changed, meta, node, "TWO_PARENT_D12", 320)
        differences = []; markers = []
        for _ in range(160):
            changed.tick(); control.tick(); differences.append(r09.delta(changed, node) != r09.delta(control, node))
            markers.append(marker_count(changed, rec["marker_states"]))
        S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
        probe = cce05.fingerprint_fast(kernel, changed, control, node, 480)
        C2 = S1 and ended and probe["probe_interaction_differs"]
        rows.append({"mode": mode, "critical_before": unpack_scalar(original), "critical_after": unpack_scalar(new_raw),
                     "B_function_preserved": B_preserved, "C_S1": S1, "C_episode_ended": ended,
                     "C2": C2, "B_and_C2": B_preserved and C2, "probe": probe})
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "separating_modes": [row["mode"]["id"] for row in rows if row["B_and_C2"]],
            "B_preserving_modes": [row["mode"]["id"] for row in rows if row["B_function_preserved"]],
            "C2_modes": [row["mode"]["id"] for row in rows if row["C2"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    print(json.dumps({"node": 1, "B_preserving": discovery["B_preserving_modes"], "C2": discovery["C2_modes"],
                      "separating": discovery["separating_modes"]}, sort_keys=True), flush=True)
    holdout = evaluate_node(kernel, 2) if discovery["separating_modes"] else None
    if holdout: print(json.dumps({"node": 2, "separating": holdout["separating_modes"]}, sort_keys=True), flush=True)
    replicated = sorted(set(discovery["separating_modes"]) & set(holdout["separating_modes"])) if holdout else []
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.bottleneck_component_factorization.v1",
        "question": "Can a component-level modulation of the critical RAW coordinate preserve B function while restoring C2?",
        "planning": {"mechanism": "single-component state/s_reg/direction/semantic mutations",
                     "controls": ["BASE", "exact B response signature", "C/no-C", "fresh frame if separating"],
                     "predicted_outcomes": ["function-only component", "competence-only component", "separable modulation", "inseparable raw coordinate"],
                     "estimated_runtime_minutes": 4, "stop_condition": "18 component variants; fresh frame for candidates"},
        "design": {"modes": list(MODES), "B_tick": 128, "mutation_C_tick": 320,
                   "critical_offset": list(CRITICAL_OFFSET), "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"discovery_separating_modes": discovery["separating_modes"], "fresh_replicated_modes": replicated,
                    "component_level_separation_demonstrated": bool(replicated),
                    "native_modulation_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_COMPONENT_SEPARATION" if replicated else "CONTRADICTED_IN_TESTED_DOMAIN",
        "claim_guard": "Direct RAW mutations are diagnostic. The tested one-component factorization does not exclude multi-coordinate, topological, trajectory or hidden-state modulation.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
