#!/usr/bin/env python3
"""Relocate the occupied functional bottleneck while freeing its interface site."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE17_BOTTLENECK_RELOCATION.json"
REPORT = ROOT / "ING03_BOTTLENECK_RELOCATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE16_BOTTLENECK_COMPONENT_FACTORIZATION.json"
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)
DISPLACEMENTS = tuple((x, y, z) for x in (-1, 0, 1) for y in (-1, 0, 1) for z in (-1, 0, 1)
                      if (x, y, z) != (0, 0, 0))


def clone(kernel, source): return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def build_B(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128); learned = clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128); advance((learned,), 192)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, meta, node, critical


def evaluate_node(kernel, node_id, restrict=None):
    learned, meta, node, critical = build_B(kernel, node_id)
    B_sig = cce08.response_signature(kernel, learned, node, 320)["signature_sha256"]
    rows = []
    displacements = DISPLACEMENTS if restrict is None else tuple(restrict)
    for canonical in displacements:
        physical = r09.transform(canonical, node["frame"])
        destination = tuple((critical[i] + physical[i]) % meta["n"] for i in range(3))
        if int(learned.raw[destination]):
            rows.append({"displacement": list(canonical), "destination": list(destination), "valid": False,
                         "reason": "destination occupied"}); continue
        moved, control = clone(kernel, learned), clone(kernel, learned)
        raw, clock = int(moved.raw[critical]), int(moved.clock_a[critical])
        set_both(moved, critical, 0, 0); set_both(control, critical, 0, 0)
        set_both(moved, destination, raw, clock); set_both(control, destination, raw, clock)
        pre_sig = cce08.response_signature(kernel, moved, node, 320)["signature_sha256"]
        B_preserved = pre_sig == B_sig
        rec = cce03.install(moved, meta, node, "TWO_PARENT_D12", 320)
        differences = []; markers = []
        for _ in range(160):
            moved.tick(); control.tick(); differences.append(r09.delta(moved, node) != r09.delta(control, node))
            markers.append(marker_count(moved, rec["marker_states"]))
        S1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
        probe = cce05.fingerprint_fast(kernel, moved, control, node, 480)
        C2 = S1 and ended and probe["probe_interaction_differs"]
        rows.append({"displacement": list(canonical), "destination": list(destination), "valid": True,
                     "B_function_preserved": B_preserved, "C_S1": S1, "C_episode_ended": ended,
                     "C2": C2, "B_and_C2": B_preserved and C2, "probe": probe})
    candidates = [row["displacement"] for row in rows if row.get("B_and_C2")]
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "candidates": candidates, "valid_relocations": sum(row.get("valid", False) for row in rows),
            "B_preserving": [row["displacement"] for row in rows if row.get("B_function_preserved")],
            "C2_reopening": [row["displacement"] for row in rows if row.get("C2")]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    print(json.dumps({"node": 1, "valid": discovery["valid_relocations"], "B_preserving": discovery["B_preserving"],
                      "C2": discovery["C2_reopening"], "candidates": discovery["candidates"]}, sort_keys=True), flush=True)
    holdout = evaluate_node(kernel, 2, [tuple(x) for x in discovery["candidates"]]) if discovery["candidates"] else None
    if holdout: print(json.dumps({"node": 2, "candidates": holdout["candidates"]}, sort_keys=True), flush=True)
    d = {tuple(x) for x in discovery["candidates"]}; h = {tuple(x) for x in holdout["candidates"]} if holdout else set()
    replicated = [list(x) for x in sorted(d & h)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.bottleneck_relocation.v1",
        "question": "Can topological relocation of the occupied B bottleneck preserve B function while freeing the original interface for C2?",
        "planning": {"mechanism": "move the exact RAW+clock state to each of 26 relational neighbors",
                     "controls": ["empty original site", "exact B response signature", "C/no-C", "fresh rotated frame for candidates"],
                     "predicted_outcomes": ["function lost", "competence-only reset", "relocatable functional support", "morphological renewal"],
                     "estimated_runtime_minutes": 4, "stop_condition": "all 26 neighboring relational displacements; fresh frame for candidates"},
        "design": {"B_tick": 128, "relocation_C_tick": 320, "displacements": [list(x) for x in DISPLACEMENTS],
                   "critical_offset": list(CRITICAL_OFFSET), "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"discovery_candidates": discovery["candidates"], "fresh_replicated_relocations": replicated,
                    "functional_support_relocation_demonstrated": bool(replicated),
                    "native_morphological_turnover": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_RELOCATION_CANDIDATE" if replicated else "CONTRADICTED_IN_TESTED_DOMAIN",
        "claim_guard": "Relocation is a host diagnostic. The tested local neighborhood does not exhaust larger distributed/topological remodelling and cannot establish endogenous renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__": main()
