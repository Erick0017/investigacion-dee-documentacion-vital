#!/usr/bin/env python3
"""Compose CORE08 fixed-scaffold regeneration with the CCE B/C2 bottleneck."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce11_minimal_interface_separation as cce11
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE18_TOPOLOGICAL_COMPETENCE_REGENERATION.json"
REPORT = ROOT / "ING03_TOPOLOGICAL_COMPETENCE_REGENERATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE17_BOTTLENECK_RELOCATION.json"
B_TICK = 128
INTERVENTION_TICK = 320
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)
CORNERS = tuple(itertools.product((-1, 1), repeat=3))
MISSING_CORNER = (-1, -1, -1)
SHUFFLED = ((-1, -1, -1), (-1, -1, 1), (-1, 1, -1), (1, -1, -1),
            (1, 1, -1), (-1, 0, 0), (0, -1, 0))
CASES = (("CLEAR_ONLY", 0), ("FULL_CLEAR", 0), ("FULL_CLEAR", 16), ("FULL_CLEAR", 64),
         ("MISSING_CLEAR", 0), ("MISSING_CLEAR", 16), ("SHUFFLED_CLEAR", 0),
         ("NONPERSISTENT_CLEAR", 0), ("FULL_NO_CLEAR", 0))


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds:
            world.tick()


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def add_offset(q, d, n):
    return tuple((int(q[i]) + int(d[i])) % int(n) for i in range(3))


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def build_histories(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), B_TICK)
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", B_TICK)
    advance((learned, naive), INTERVENTION_TICK - B_TICK)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, naive, meta, node, critical


def scaffold_offsets(mode):
    if mode in ("FULL_CLEAR", "FULL_NO_CLEAR", "NONPERSISTENT_CLEAR"):
        return CORNERS
    if mode == "MISSING_CLEAR":
        return tuple(d for d in CORNERS if d != MISSING_CORNER)
    if mode == "SHUFFLED_CLEAR":
        return SHUFFLED
    return ()


def apply_architecture(world, critical, n, mode):
    if mode != "FULL_NO_CLEAR":
        set_both(world, critical, 0, 0)
    semantic = 1 if mode == "NONPERSISTENT_CLEAR" else 4
    installed, retained, conflicts = [], [], []
    for index, offset in enumerate(scaffold_offsets(mode)):
        q = add_offset(critical, offset, n)
        if int(world.raw[q]):
            decoded = unpack_scalar(world.raw[q])
            if decoded["semantic"] == 4 and mode != "NONPERSISTENT_CLEAR":
                retained.append({"offset": list(offset), "position": list(q), "state": decoded})
                continue
            conflicts.append({"offset": list(offset), "position": list(q), "state": decoded})
            continue
        value = int(pack(92000 + index, 300 + index, (0, 0, 0), semantic))
        set_both(world, q, value, INTERVENTION_TICK)
        installed.append({"offset": list(offset), "position": list(q), "raw": value})
    return {"mode": mode, "semantic": semantic, "installed": installed,
            "retained_semantic4": retained, "conflicts": conflicts,
            "critical_cleared": mode != "FULL_NO_CLEAR"}


def regenerated_center(world, critical):
    if not int(world.raw[critical]):
        return False
    value = unpack_scalar(world.raw[critical])
    return (value["state"] == 1 and value["sreg"] == 1
            and value["direction"] == [0, 0, 0] and value["semantic"] == 7)


def c2_assay(kernel, state, meta, node, tick):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, "TWO_PARENT_D12", tick)
    differences, markers = [], []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, record["marker_states"]))
    s1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160)
    return {"S0": any(differences), "S1": s1, "episode_ended": ended,
            "probe": probe, "C2": s1 and ended and probe["probe_interaction_differs"]}


def evaluate_node(kernel, node_id):
    learned0, naive0, meta, node, critical = build_histories(kernel, node_id)
    rows = []
    for mode, delay in CASES:
        learned, naive = clone(kernel, learned0), clone(kernel, naive0)
        architecture_l = apply_architecture(learned, critical, meta["n"], mode)
        architecture_n = apply_architecture(naive, critical, meta["n"], mode)
        advance((learned, naive), 1 + delay)
        tick = INTERVENTION_TICK + 1 + delay
        critical_l = unpack_scalar(learned.raw[critical]) if int(learned.raw[critical]) else None
        critical_n = unpack_scalar(naive.raw[critical]) if int(naive.raw[critical]) else None
        sig_l = cce08.response_signature(kernel, learned, node, tick)["signature_sha256"]
        sig_n = cce08.response_signature(kernel, naive, node, tick)["signature_sha256"]
        b_distinction = sig_l != sig_n
        assay_l = c2_assay(kernel, learned, meta, node, tick)
        assay_n = c2_assay(kernel, naive, meta, node, tick)
        renewal = b_distinction and assay_l["C2"]
        row = {"mode": mode, "delay_after_regeneration": delay, "tick": tick,
               "learned_architecture": architecture_l, "naive_architecture": architecture_n,
               "learned_critical": critical_l, "naive_critical": critical_n,
               "learned_structural_regeneration": regenerated_center(learned, critical),
               "naive_structural_regeneration": regenerated_center(naive, critical),
               "B_response_distinction_retained": b_distinction,
               "learned_C2": assay_l, "naive_C2_control": assay_n,
               "functional_competence_renewal": renewal}
        rows.append(row)
        print(json.dumps({"node": node_id, "mode": mode, "delay": delay,
                          "regen": row["learned_structural_regeneration"],
                          "B": b_distinction, "C2": assay_l["C2"],
                          "renewal": renewal}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "renewal_candidates": [f'{r["mode"]}@{r["delay_after_regeneration"]}' for r in rows
                                   if r["functional_competence_renewal"]],
            "structural_regeneration_cases": [f'{r["mode"]}@{r["delay_after_regeneration"]}' for r in rows
                                               if r["learned_structural_regeneration"]],
            "C2_without_B_cases": [f'{r["mode"]}@{r["delay_after_regeneration"]}' for r in rows
                                   if r["learned_C2"]["C2"] and not r["B_response_distinction_retained"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1)
    holdout = evaluate_node(kernel, 2)
    replicated = sorted(set(discovery["renewal_candidates"]) & set(holdout["renewal_candidates"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.topological_competence_regeneration.v1",
        "question": "Can the CORE08 fixed-corner regeneration primitive rebuild C2 competence while the distributed B response remains causally distinct?",
        "planning": {"mechanism": "complete persistent semantic4 corner scaffold regenerating the cleared CCE bottleneck",
                     "controls": ["clear only", "missing corner", "shuffled inventory", "nonpersistent scaffold", "full scaffold without vacancy", "naive history", "second relational frame"],
                     "predicted_outcomes": ["structural recovery only", "reset-only C2", "B-preserving competence renewal", "no regeneration"],
                     "estimated_runtime_minutes": 8, "stop_condition": "nine mechanism/time cases in two relational frames"},
        "design": {"B_tick": B_TICK, "intervention_tick": INTERVENTION_TICK,
                   "cases": [[mode, delay] for mode, delay in CASES],
                   "critical_offset": list(CRITICAL_OFFSET), "diagnostic_only": True,
                   "parent_primitive": "CORE08 repeated fixed semantic4 corner scaffold regeneration"},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_functional_competence_renewal": replicated,
                    "structural_regeneration_validated_in_both_frames": bool(set(discovery["structural_regeneration_cases"]) & set(holdout["structural_regeneration_cases"])),
                    "diagnostic_competence_regeneration_with_B": bool(replicated),
                    "native_turnover_demonstrated": False, "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_REGENERATION_CANDIDATE" if replicated else "BOUNDED_NULL_OR_STRUCTURAL_ONLY",
        "claim_guard": "Host vacancy/scaffold installation is diagnostic. A structural birth is not functional competence regeneration; this test does not exhaust lineage, moving topology, collective rematuration or hidden X_FULL organization.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "discovery": {k: discovery[k] for k in ("renewal_candidates", "structural_regeneration_cases", "C2_without_B_cases")},
                      "holdout": {k: holdout[k] for k in ("renewal_candidates", "structural_regeneration_cases", "C2_without_B_cases")},
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
