#!/usr/bin/env python3
"""Map whether a one-site vacancy separates retained B response from later C2."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce11_minimal_interface_separation as cce11
import run_cce18_topological_competence_regeneration as cce18
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE19_VACANCY_REORGANIZATION_WINDOW.json"
REPORT = ROOT / "ING03_VACANCY_REORGANIZATION_WINDOW.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE18_TOPOLOGICAL_COMPETENCE_REGENERATION.json"
GAPS = (0, 1, 2, 4, 8, 16, 32, 64)
CHECKPOINTS = (1, 2, 4, 8, 16, 32, 64, 96, 128)
CRITICAL_OFFSET = (1, -1, -1)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds:
            world.tick()


def set_empty(world, q):
    for raw in (world.raw_a, world.raw_b): raw[q] = np.uint64(0)
    for clock in (world.clock_a, world.clock_b): clock[q] = np.uint64(0)


def response_signature(kernel, state, node, tick):
    probe, no_probe = clone(kernel, state), clone(kernel, state)
    cce03.install_probe(probe, node, tick, True); cce03.install_probe(no_probe, node, tick, False)
    rows = []
    for latency in range(1, cce03.PROBE_HORIZON + 1):
        probe.tick(); no_probe.tick()
        if latency in CHECKPOINTS:
            raw_xor = np.bitwise_xor(probe.raw, no_probe.raw)
            clock_xor = np.bitwise_xor(probe.clock_a, no_probe.clock_a)
            h = hashlib.sha256(); h.update(raw_xor.tobytes()); h.update(clock_xor.tobytes())
            rows.append({"latency": latency, "effect_sha256": h.hexdigest(),
                         "affected_positions": int(np.count_nonzero(raw_xor)),
                         "node_probe": r09.delta(probe, node), "node_no_probe": r09.delta(no_probe, node)})
    digest = hashlib.sha256(json.dumps(rows, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {"signature_sha256": digest, "checkpoints": rows}


def build(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128)
    learned, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    advance((learned, naive), 192)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    return learned, naive, meta, node, critical


def evaluate_node(kernel, node_id):
    learned0, naive0, meta, node, critical = build(kernel, node_id)
    rows = []
    for gap in GAPS:
        learned_clear, naive_clear = clone(kernel, learned0), clone(kernel, naive0)
        learned_ref, naive_ref = clone(kernel, learned0), clone(kernel, naive0)
        set_empty(learned_clear, critical); set_empty(naive_clear, critical)
        advance((learned_clear, naive_clear, learned_ref, naive_ref), gap)
        tick = 320 + gap
        signatures = {
            "learned_clear": response_signature(kernel, learned_clear, node, tick),
            "naive_clear": response_signature(kernel, naive_clear, node, tick),
            "learned_reference": response_signature(kernel, learned_ref, node, tick),
            "naive_reference": response_signature(kernel, naive_ref, node, tick),
        }
        hashes = {k: v["signature_sha256"] for k, v in signatures.items()}
        c2_lc = cce18.c2_assay(kernel, learned_clear, meta, node, tick)
        c2_lr = cce18.c2_assay(kernel, learned_ref, meta, node, tick)
        c2_nc = cce18.c2_assay(kernel, naive_clear, meta, node, tick)
        b_exact = hashes["learned_clear"] == hashes["learned_reference"]
        b_distinct = hashes["learned_clear"] != hashes["naive_clear"]
        no_false_history = hashes["naive_clear"] == hashes["naive_reference"]
        row = {"gap_ticks": gap, "tick": tick, "critical_empty_before_C": not int(learned_clear.raw[critical]),
               "signature_hashes": hashes, "B_exact_response_preserved": b_exact,
               "B_response_distinction_retained": b_distinct,
               "naive_clear_does_not_create_response_class": no_false_history,
               "learned_clear_C2": c2_lc, "learned_reference_C2": c2_lr, "naive_clear_C2": c2_nc,
               "exact_B_plus_C2": b_exact and c2_lc["C2"] and no_false_history,
               "B_distinction_plus_C2": b_distinct and c2_lc["C2"] and no_false_history,
               "signatures": signatures}
        rows.append(row)
        print(json.dumps({"node": node_id, "gap": gap, "empty": row["critical_empty_before_C"],
                          "B_exact": b_exact, "B_distinct": b_distinct,
                          "C2_clear": c2_lc["C2"], "C2_ref": c2_lr["C2"],
                          "naive_C2": c2_nc["C2"], "candidate": row["exact_B_plus_C2"]}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "exact_candidates": [r["gap_ticks"] for r in rows if r["exact_B_plus_C2"]],
            "response_class_candidates": [r["gap_ticks"] for r in rows if r["B_distinction_plus_C2"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1); holdout = evaluate_node(kernel, 2)
    exact = sorted(set(discovery["exact_candidates"]) & set(holdout["exact_candidates"]))
    response = sorted(set(discovery["response_class_candidates"]) & set(holdout["response_class_candidates"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.vacancy_reorganization_window.v1",
        "question": "Does a brief vacancy interval preserve the original B response while reopening C2, rather than merely creating another response class?",
        "planning": {"mechanism": "clear only the occupied critical relation and vary the autonomous reorganization gap",
                     "controls": ["learned no-clear", "naive clear", "naive no-clear", "C/no-C", "second relational frame"],
                     "predicted_outcomes": ["B erased", "changed residual class", "exact B plus C2", "transient reopening window"],
                     "estimated_runtime_minutes": 10, "stop_condition": "eight gaps from 0 to64 in two frames"},
        "design": {"B_tick": 128, "vacancy_tick": 320, "gaps": list(GAPS),
                   "critical_offset": list(CRITICAL_OFFSET), "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"fresh_replicated_exact_B_plus_C2_gaps": exact,
                    "replicated_B_distinction_plus_C2_gaps": response,
                    "exact_function_competence_separation": bool(exact),
                    "diagnostic_response_class_competence_separation": bool(response),
                    "native_vacancy_generation_demonstrated": False,
                    "native_function_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_EXACT_SEPARATION_CANDIDATE" if exact else ("DIAGNOSTIC_RESPONSE_CLASS_SEPARATION" if response else "BOUNDED_NULL"),
        "claim_guard": "The vacancy is host-created and the function is an external diagnostic response fingerprint. Exact hash preservation is stronger than mere learned-vs-naive separability, but neither establishes native turnover, DEE-native function or RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
