#!/usr/bin/env python3
"""Test RAW-only vacancy as a history-preserving diagnostic competence interface."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce18_topological_competence_regeneration as cce18
import run_cce19_vacancy_reorganization_window as cce19
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE20_HISTORY_PRESERVING_VACANCY.json"
REPORT = ROOT / "ING03_HISTORY_PRESERVING_VACANCY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE19_VACANCY_REORGANIZATION_WINDOW.json"
GAPS = (0, 1, 2, 4, 8, 16)
RETENTION = 64


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def clear_raw(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def factorial_sequence(kernel, learned, naive, meta, node, tick):
    worlds = {"BC": clone(kernel, learned), "B": clone(kernel, learned),
              "C": clone(kernel, naive), "N": clone(kernel, naive)}
    rec_bc = cce03.install(worlds["BC"], meta, node, "TWO_PARENT_D12", tick)
    rec_c = cce03.install(worlds["C"], meta, node, "TWO_PARENT_D12", tick)
    differences = {"BC_vs_B": [], "C_vs_N": []}; markers = {name: [] for name in worlds}
    states = tuple(rec_bc["marker_states"])
    for _ in range(160):
        for world in worlds.values(): world.tick()
        differences["BC_vs_B"].append(r09.delta(worlds["BC"], node) != r09.delta(worlds["B"], node))
        differences["C_vs_N"].append(r09.delta(worlds["C"], node) != r09.delta(worlds["N"], node))
        for name, world in worlds.items(): markers[name].append(marker_count(world, states))
    signatures = {name: cce19.response_signature(kernel, world, node, tick + 160)["signature_sha256"]
                  for name, world in worlds.items()}
    bc_unique = all(signatures["BC"] != signatures[name] for name in ("B", "C", "N"))
    c_changes_b = signatures["BC"] != signatures["B"]
    b_remains_in_bc = signatures["BC"] != signatures["C"]
    c_control = signatures["C"] != signatures["N"]
    return {"S1_BC_vs_B": all(differences["BC_vs_B"][-RETENTION:]),
            "S1_C_vs_N": all(differences["C_vs_N"][-RETENTION:]),
            "BC_episode_ended": all(v == 0 for v in markers["BC"][-RETENTION:]),
            "C_episode_ended": all(v == 0 for v in markers["C"][-RETENTION:]),
            "response_signatures": signatures, "C_changes_B_response": c_changes_b,
            "B_history_remains_in_BC_response": b_remains_in_bc,
            "C_changes_naive_response": c_control, "BC_unique_from_B_C_N": bc_unique,
            "layered_diagnostic_response": (all(differences["BC_vs_B"][-RETENTION:])
                                             and all(v == 0 for v in markers["BC"][-RETENTION:])
                                             and bc_unique and b_remains_in_bc and c_control)}


def evaluate_node(kernel, node_id):
    learned0, naive0, meta, node, critical = cce19.build(kernel, node_id)
    rows = []
    for gap in GAPS:
        learned_clear, naive_clear = clone(kernel, learned0), clone(kernel, naive0)
        learned_ref, naive_ref = clone(kernel, learned0), clone(kernel, naive0)
        learned_clock_before = int(learned_clear.clock_a[critical]); naive_clock_before = int(naive_clear.clock_a[critical])
        clear_raw(learned_clear, critical); clear_raw(naive_clear, critical)
        advance((learned_clear, naive_clear, learned_ref, naive_ref), gap)
        tick = 320 + gap
        hashes = {"learned_clear": cce19.response_signature(kernel, learned_clear, node, tick)["signature_sha256"],
                  "naive_clear": cce19.response_signature(kernel, naive_clear, node, tick)["signature_sha256"],
                  "learned_reference": cce19.response_signature(kernel, learned_ref, node, tick)["signature_sha256"],
                  "naive_reference": cce19.response_signature(kernel, naive_ref, node, tick)["signature_sha256"]}
        c2_lc = cce18.c2_assay(kernel, learned_clear, meta, node, tick)
        c2_lr = cce18.c2_assay(kernel, learned_ref, meta, node, tick)
        c2_nc = cce18.c2_assay(kernel, naive_clear, meta, node, tick)
        b_exact = hashes["learned_clear"] == hashes["learned_reference"]
        b_distinct = hashes["learned_clear"] != hashes["naive_clear"]
        no_false = hashes["naive_clear"] == hashes["naive_reference"]
        candidate = b_distinct and no_false and c2_lc["C2"] and not c2_lr["C2"] and c2_nc["C2"]
        factorial = factorial_sequence(kernel, learned_clear, naive_clear, meta, node, tick) if candidate else None
        row = {"gap_ticks": gap, "tick": tick, "critical_empty_before_C": not int(learned_clear.raw[critical]),
               "clock_preserved_at_intervention": learned_clock_before == int(learned0.clock_a[critical])
                                                  and naive_clock_before == int(naive0.clock_a[critical]),
               "signature_hashes": hashes, "B_exact_response_preserved": b_exact,
               "B_response_distinction_retained": b_distinct,
               "naive_RAW_clear_is_noop_for_response": no_false,
               "learned_clear_C2": c2_lc, "learned_reference_C2": c2_lr, "naive_clear_C2": c2_nc,
               "response_class_competence_candidate": candidate, "factorial": factorial,
               "layered_diagnostic_response": bool(factorial and factorial["layered_diagnostic_response"])}
        rows.append(row)
        print(json.dumps({"node": node_id, "gap": gap, "B_exact": b_exact, "B_distinct": b_distinct,
                          "naive_noop": no_false, "C2_clear": c2_lc["C2"], "C2_ref": c2_lr["C2"],
                          "candidate": candidate, "layered": row["layered_diagnostic_response"]}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "candidate_gaps": [r["gap_ticks"] for r in rows if r["response_class_competence_candidate"]],
            "layered_gaps": [r["gap_ticks"] for r in rows if r["layered_diagnostic_response"]],
            "exact_B_gaps": [r["gap_ticks"] for r in rows if r["B_exact_response_preserved"] and r["learned_clear_C2"]["C2"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1); holdout = evaluate_node(kernel, 2)
    candidates = sorted(set(discovery["candidate_gaps"]) & set(holdout["candidate_gaps"]))
    layered = sorted(set(discovery["layered_gaps"]) & set(holdout["layered_gaps"]))
    exact = sorted(set(discovery["exact_B_gaps"]) & set(holdout["exact_B_gaps"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.history_preserving_vacancy.v1",
        "question": "Can removing only occupied RAW while preserving site history reopen C2 without erasing all causal evidence of B?",
        "planning": {"mechanism": "RAW-only vacancy at the critical relational site, leaving its clock/history coordinate unchanged",
                     "controls": ["learned no-clear", "naive RAW-clear no-op", "naive competence", "B/C factorial", "second relational frame"],
                     "predicted_outcomes": ["false-positive intervention", "B erased", "residual B plus C2", "layered BC response"],
                     "estimated_runtime_minutes": 10, "stop_condition": "six gaps and factorial follow-up of every candidate in two frames"},
        "design": {"B_tick": 128, "RAW_vacancy_tick": 320, "gaps": list(GAPS),
                   "diagnostic_only": True, "clock_equalization": False},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_response_class_competence_gaps": candidates,
                    "replicated_layered_BC_response_gaps": layered,
                    "replicated_exact_B_plus_C2_gaps": exact,
                    "diagnostic_history_competence_separation": bool(candidates),
                    "diagnostic_layered_history": bool(layered),
                    "old_B_function_exactly_preserved": bool(exact),
                    "native_RAW_vacancy_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_LAYERED_HISTORY_CANDIDATE" if layered else ("DIAGNOSTIC_RESPONSE_CLASS_SEPARATION" if candidates else "BOUNDED_NULL"),
        "claim_guard": "RAW vacancy is host-created and response hashes are diagnostic observer classes. Residual B distinguishability is not identity of Function B; no native turnover, autonomous second experience or RW3 is claimed.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
