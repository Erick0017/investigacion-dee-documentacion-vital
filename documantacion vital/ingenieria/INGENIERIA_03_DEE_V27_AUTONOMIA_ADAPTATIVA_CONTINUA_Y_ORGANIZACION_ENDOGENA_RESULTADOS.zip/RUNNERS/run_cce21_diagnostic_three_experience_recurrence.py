#!/usr/bin/env python3
"""Test B -> RAW-vacancy -> C -> RAW-vacancy -> B in one diagnostic world."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce11_minimal_interface_separation as cce11
import run_cce19_vacancy_reorganization_window as cce19
import run_cce20_history_preserving_vacancy as cce20
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE21_DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE.json"
REPORT = ROOT / "ING03_DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE20_HISTORY_PRESERVING_VACANCY.json"
RETENTION = 64
CRITICAL_OFFSET = (1, -1, -1)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def clear_raw(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def experience_pair(kernel, experienced0, control0, meta, node, tick, mode, clear_site=None):
    experienced, control = clone(kernel, experienced0), clone(kernel, control0)
    if clear_site is not None:
        clear_raw(experienced, clear_site); clear_raw(control, clear_site)
    record = cce03.install(experienced, meta, node, mode, tick)
    differences, markers = [], []
    for _ in range(160):
        experienced.tick(); control.tick()
        differences.append(r09.delta(experienced, node) != r09.delta(control, node))
        markers.append(marker_count(experienced, record["marker_states"]))
    s1 = all(differences[-RETENTION:]); ended = all(v == 0 for v in markers[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, experienced, control, node, tick + 160)
    return {"experienced": experienced, "control": control,
            "assay": {"S0": any(differences), "S1": s1, "episode_ended": ended,
                      "probe": probe, "C2": s1 and ended and probe["probe_interaction_differs"]},
            "intervention": {"RAW_vacancy": clear_site is not None,
                             "vacancy_position": list(clear_site) if clear_site is not None else None}}


def evaluate_node(kernel, node_id):
    base, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    advance((base,), 128)
    learned_b, naive = clone(kernel, base), clone(kernel, base)
    cce03.install(learned_b, meta, node, "SEM1_WRITER", 128)
    advance((learned_b, naive), 192)
    critical = cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])

    # Second experience C at t320 after RAW-only vacancy; four-arm factorial.
    worlds = {"BC": clone(kernel, learned_b), "B": clone(kernel, learned_b),
              "C": clone(kernel, naive), "N": clone(kernel, naive)}
    for world in worlds.values(): clear_raw(world, critical)
    rec_bc = cce03.install(worlds["BC"], meta, node, "TWO_PARENT_D12", 320)
    rec_c = cce03.install(worlds["C"], meta, node, "TWO_PARENT_D12", 320)
    differences = {"BC_vs_B": [], "C_vs_N": []}; markers = {name: [] for name in worlds}
    states_c = tuple(rec_bc["marker_states"])
    for _ in range(160):
        for world in worlds.values(): world.tick()
        differences["BC_vs_B"].append(r09.delta(worlds["BC"], node) != r09.delta(worlds["B"], node))
        differences["C_vs_N"].append(r09.delta(worlds["C"], node) != r09.delta(worlds["N"], node))
        for name, world in worlds.items(): markers[name].append(marker_count(world, states_c))
    sig480 = {name: cce19.response_signature(kernel, world, node, 480)["signature_sha256"] for name, world in worlds.items()}
    stage_c = {"BC_vs_B_S1": all(differences["BC_vs_B"][-RETENTION:]),
               "C_vs_N_S1": all(differences["C_vs_N"][-RETENTION:]),
               "BC_episode_ended": all(v == 0 for v in markers["BC"][-RETENTION:]),
               "signatures_t480": sig480,
               "BC_unique_B_C_N": all(sig480["BC"] != sig480[name] for name in ("B", "C", "N"))}

    advance(tuple(worlds.values()), 224)  # t480 -> t704, a recurrent S1-open time in CCE01.
    sig704 = {name: cce19.response_signature(kernel, world, node, 704)["signature_sha256"] for name, world in worlds.items()}
    stage_c["signatures_t704"] = sig704
    stage_c["BC_still_unique_t704"] = all(sig704["BC"] != sig704[name] for name in ("B", "C", "N"))

    # Third B on BC with a renewed RAW-only vacancy, plus no-vacancy and naive controls.
    renewed = experience_pair(kernel, worlds["BC"], worlds["BC"], meta, node, 704, "SEM1_WRITER", critical)
    no_renewal = experience_pair(kernel, worlds["BC"], worlds["BC"], meta, node, 704, "SEM1_WRITER", None)
    naive_control = experience_pair(kernel, worlds["N"], worlds["N"], meta, node, 704, "SEM1_WRITER", critical)
    sig864 = {
        "BCB_renewed": cce19.response_signature(kernel, renewed["experienced"], node, 864)["signature_sha256"],
        "BC_renewed_control": cce19.response_signature(kernel, renewed["control"], node, 864)["signature_sha256"],
        "BCB_no_renewal": cce19.response_signature(kernel, no_renewal["experienced"], node, 864)["signature_sha256"],
        "BC_no_renewal_control": cce19.response_signature(kernel, no_renewal["control"], node, 864)["signature_sha256"],
        "NB": cce19.response_signature(kernel, naive_control["experienced"], node, 864)["signature_sha256"],
        "N": cce19.response_signature(kernel, naive_control["control"], node, 864)["signature_sha256"],
    }
    third = {"with_RAW_vacancy": renewed["assay"], "without_vacancy": no_renewal["assay"],
             "naive_with_RAW_vacancy": naive_control["assay"], "signatures_t864": sig864,
             "third_B_changes_BC_response": sig864["BCB_renewed"] != sig864["BC_renewed_control"],
             "third_B_requires_vacancy": renewed["assay"]["C2"] and not no_renewal["assay"]["C2"],
             "naive_positive_control": naive_control["assay"]["C2"],
             "diagnostic_three_experience_sequence": (stage_c["BC_unique_B_C_N"]
                                                      and stage_c["BC_still_unique_t704"]
                                                      and renewed["assay"]["C2"]
                                                      and not no_renewal["assay"]["C2"]
                                                      and naive_control["assay"]["C2"])}
    print(json.dumps({"node": node_id, "BC480": stage_c["BC_unique_B_C_N"],
                      "BC704": stage_c["BC_still_unique_t704"], "third_C2": renewed["assay"]["C2"],
                      "no_vacancy_C2": no_renewal["assay"]["C2"], "naive_C2": naive_control["assay"]["C2"],
                      "three": third["diagnostic_three_experience_sequence"]}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical),
            "stage_C": stage_c, "stage_return_B": third}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1); holdout = evaluate_node(kernel, 2)
    replicated = (discovery["stage_return_B"]["diagnostic_three_experience_sequence"]
                  and holdout["stage_return_B"]["diagnostic_three_experience_sequence"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.diagnostic_three_experience_recurrence.v1",
        "question": "Can repeated RAW-only vacancy enable B->C->B retained response transitions in one uninterrupted diagnostic world?",
        "planning": {"mechanism": "preserve distributed history while reopening the occupied relation before each later experience",
                     "controls": ["no vacancy before third B", "naive positive control", "B/C factorial", "second relational frame"],
                     "predicted_outcomes": ["single renewal only", "third capture", "history collapse", "temporal-window failure"],
                     "estimated_runtime_minutes": 8, "stop_condition": "complete sequence in two frames"},
        "design": {"B_tick": 128, "C_tick": 320, "return_B_tick": 704,
                   "RAW_vacancy_ticks": [320, 704], "clock_preserved": True,
                   "one_uninterrupted_world_per_branch": True, "diagnostic_only": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_diagnostic_three_experience_sequence": replicated,
                    "host_RAW_vacancy_required": (discovery["stage_return_B"]["third_B_requires_vacancy"]
                                                  and holdout["stage_return_B"]["third_B_requires_vacancy"]),
                    "native_vacancy_generation_demonstrated": False,
                    "native_environment_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE" if replicated else "BOUNDED_NULL",
        "claim_guard": "The two RAW vacancies and all experiences are host diagnostics, and function is a response fingerprint. This identifies a recurrent mechanism/prerequisite but cannot satisfy RW3 until DEE generates the vacancy and experiences natively and produces a DEE-native function.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
