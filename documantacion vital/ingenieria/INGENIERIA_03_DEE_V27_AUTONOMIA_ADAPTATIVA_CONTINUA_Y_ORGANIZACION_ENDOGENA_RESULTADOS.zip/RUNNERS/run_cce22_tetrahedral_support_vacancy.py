#!/usr/bin/env python3
"""Identify the neighbor support whose loss indirectly vacates the CCE bottleneck."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, unpack_scalar, write_json
import run_cce18_topological_competence_regeneration as cce18
import run_cce19_vacancy_reorganization_window as cce19


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE22_TETRAHEDRAL_SUPPORT_VACANCY.json"
REPORT = ROOT / "ING03_TETRAHEDRAL_SUPPORT_VACANCY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE21_DIAGNOSTIC_THREE_EXPERIENCE_RECURRENCE.json"
TETRA_PATTERNS = (
    ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 1)),
    ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1)),
    ((1, 0, 0), (0, -1, 0), (0, 0, 1), (1, -1, 1)),
    ((1, 0, 0), (0, 1, 0), (0, 0, -1), (1, 1, -1)),
    ((-1, 0, 0), (0, -1, 0), (0, 0, 1), (-1, -1, 1)),
    ((-1, 0, 0), (0, 1, 0), (0, 0, -1), (-1, 1, -1)),
    ((1, 0, 0), (0, -1, 0), (0, 0, -1), (1, -1, -1)),
    ((-1, 0, 0), (0, -1, 0), (0, 0, -1), (-1, -1, -1)),
)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def add(q, d, n):
    return tuple((int(q[i]) + int(d[i])) % int(n) for i in range(3))


def clear_raw(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)


def active_neighbor_map(world, critical, n):
    rows = []
    for d in itertools.product((-1, 0, 1), repeat=3):
        if d == (0, 0, 0): continue
        q = add(critical, d, n); raw = int(world.raw[q])
        if not raw: continue
        decoded = unpack_scalar(raw)
        if decoded["semantic"] == 5: continue
        rows.append({"offset": list(d), "position": list(q), "state": decoded})
    return rows


def evaluate_node(kernel, node_id):
    learned0, naive0, meta, node, critical = cce19.build(kernel, node_id)
    neighbors = active_neighbor_map(learned0, critical, meta["n"])
    active_offsets = {tuple(row["offset"]) for row in neighbors}
    complete_patterns = [pattern for pattern in TETRA_PATTERNS if set(pattern) <= active_offsets]
    tetra_offsets = set().union(*(set(p) for p in complete_patterns)) if complete_patterns else set()

    persistence = clone(kernel, learned0); before = {tuple(row["offset"]): int(persistence.raw[tuple(row["position"])]) for row in neighbors}
    for _ in range(64): persistence.tick()
    persistent = {str(offset): {"exact": int(persistence.raw[add(critical, offset, meta["n"])]) == raw,
                                "semantic": unpack_scalar(raw)["semantic"]}
                  for offset, raw in before.items()}

    modes = [("NONE", None)] + [("REMOVE_" + "_".join(map(str, row["offset"])), tuple(row["offset"])) for row in neighbors]
    rows = []
    for mode, offset in modes:
        learned, naive = clone(kernel, learned0), clone(kernel, naive0)
        if offset is not None:
            clear_raw(learned, add(critical, offset, meta["n"])); clear_raw(naive, add(critical, offset, meta["n"]))
        learned.tick(); naive.tick(); tick = 321
        sig_l = cce19.response_signature(kernel, learned, node, tick)["signature_sha256"]
        sig_n = cce19.response_signature(kernel, naive, node, tick)["signature_sha256"]
        assay_l = cce18.c2_assay(kernel, learned, meta, node, tick)
        assay_n = cce18.c2_assay(kernel, naive, meta, node, tick)
        critical_empty = not int(learned.raw[critical])
        candidate = offset is not None and critical_empty and sig_l != sig_n and assay_l["C2"] and assay_n["C2"]
        row = {"mode": mode, "removed_offset": list(offset) if offset is not None else None,
               "removed_state": next((x["state"] for x in neighbors if tuple(x["offset"]) == offset), None),
               "member_of_complete_tetrahedron": offset in tetra_offsets if offset is not None else False,
               "critical_after_one_tick": unpack_scalar(learned.raw[critical]) if int(learned.raw[critical]) else None,
               "critical_vacancy_generated": critical_empty, "B_response_distinction_retained": sig_l != sig_n,
               "learned_C2": assay_l, "naive_C2_control": assay_n,
               "support_mediated_competence_candidate": candidate}
        rows.append(row)
        print(json.dumps({"node": node_id, "mode": mode, "tetra": row["member_of_complete_tetrahedron"],
                          "vacancy": critical_empty, "B": row["B_response_distinction_retained"],
                          "C2": assay_l["C2"], "candidate": candidate}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical),
            "active_neighbors": neighbors, "complete_tetrahedral_patterns": [[list(x) for x in p] for p in complete_patterns],
            "neighbor_exact_persistence_64_ticks": persistent, "rows": rows,
            "candidate_offsets": [r["removed_offset"] for r in rows if r["support_mediated_competence_candidate"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1); holdout = evaluate_node(kernel, 2)
    d = {tuple(x) for x in discovery["candidate_offsets"]}; h = {tuple(x) for x in holdout["candidate_offsets"]}
    replicated = [list(x) for x in sorted(d & h)]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.tetrahedral_support_vacancy.v1",
        "question": "Which causal supports maintain the occupied bottleneck, and can their loss generate the competence-reopening vacancy indirectly?",
        "planning": {"mechanism": "single-neighbor support ablation followed by one native tick",
                     "controls": ["no removal", "non-tetra neighbors", "matched naive removal", "second relational frame", "64-tick persistence"],
                     "predicted_outcomes": ["no vacancy", "tetrahedron-dependent vacancy", "B loss", "support-mediated C2 reopening"],
                     "estimated_runtime_minutes": 6, "stop_condition": "every active neighbor in two frames"},
        "design": {"B_tick": 128, "support_ablation_tick": 320, "assay_tick": 321,
                   "diagnostic_only": True, "kernel_rule_reference": "tetrahedral signature + matter rule_value"},
        "discovery": discovery, "holdout": holdout,
        "summary": {"replicated_support_mediated_vacancy_offsets": replicated,
                    "support_mediated_diagnostic_competence_reopening": bool(replicated),
                    "semantic4_supports_exactly_persistent_64_ticks": all(
                        row["exact"] for frame in (discovery, holdout)
                        for row in frame["neighbor_exact_persistence_64_ticks"].values() if row["semantic"] == 4),
                    "native_support_removal_demonstrated": False, "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_SUPPORT_MEDIATED_VACANCY" if replicated else "BOUNDED_NULL",
        "claim_guard": "Neighbor removal is a host diagnostic. Semantic4 voxels are fixed by the frozen kernel, so a positive identifies why this apparatus cannot turn over natively; it does not prohibit architectures with nonimmutable developmental support.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
