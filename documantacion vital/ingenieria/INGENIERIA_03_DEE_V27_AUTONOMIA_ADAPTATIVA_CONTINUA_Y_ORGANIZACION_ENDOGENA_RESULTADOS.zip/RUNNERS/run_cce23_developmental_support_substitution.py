#!/usr/bin/env python3
"""Replace immutable tetrahedral supports at t0 with ordinary evolving support."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce18_topological_competence_regeneration as cce18
import run_cce19_vacancy_reorganization_window as cce19
import run_cce22_tetrahedral_support_vacancy as cce22
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE23_DEVELOPMENTAL_SUPPORT_SUBSTITUTION.json"
REPORT = ROOT / "ING03_DEVELOPMENTAL_SUPPORT_SUBSTITUTION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE22_TETRAHEDRAL_SUPPORT_VACANCY.json"
CRITICAL_OFFSET = (1, -1, -1)
DISCOVERY_BITS = tuple(format(i, "04b") for i in range(16))
HOLDOUT_CORE = ("0000", "0001", "0010", "0100", "1000", "1111")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds: world.tick()


def set_both(world, q, raw):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)


def tetra_supports(world, critical, n):
    active = cce22.active_neighbor_map(world, critical, n)
    offsets = {tuple(row["offset"]): row for row in active}
    patterns = [p for p in cce22.TETRA_PATTERNS if set(p) <= set(offsets)]
    if len(patterns) != 1:
        raise RuntimeError(f"expected one tetrahedral pattern, observed {patterns}")
    supports = [offsets[offset] for offset in patterns[0]]
    if any(row["state"]["semantic"] != 4 for row in supports):
        raise RuntimeError("t0 tetrahedral support is not semantic4")
    return supports


def configure(kernel, node_id, bits):
    world, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    critical = cce19.cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    supports = tetra_supports(world, critical, meta["n"])
    selected = []
    for index, row in enumerate(supports):
        if bits[index] != "1": continue
        old = row["state"]; q = tuple(row["position"])
        value = int(pack(old["state"], old["sreg"], tuple(old["direction"]), 1))
        set_both(world, q, value); selected.append({"index": index, "offset": row["offset"], "position": row["position"]})
    return world, meta, node, critical, supports, selected


def support_state(world, supports):
    return [{"offset": row["offset"], "value": unpack_scalar(world.raw[tuple(row["position"])]) if int(world.raw[tuple(row["position"])]) else None}
            for row in supports]


def marker_count(world, states):
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def c2_assay(kernel, state, meta, node, tick, mode):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, mode, tick)
    differences, markers = [], []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, record["marker_states"]))
    s1 = all(differences[-64:]); ended = all(v == 0 for v in markers[-64:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160)
    return {"mode": mode, "S0": any(differences), "S1": s1, "episode_ended": ended,
            "probe": probe, "C2": s1 and ended and probe["probe_interaction_differs"]}


def evaluate_bits(kernel, node_id, bits):
    base, meta, node, critical, supports, selected = configure(kernel, node_id, bits)
    advance((base,), 128)
    snapshot = clone(kernel, base)
    initial_competence = c2_assay(kernel, snapshot, meta, node, 128, "SEM1_WRITER")
    learned, naive = clone(kernel, snapshot), clone(kernel, snapshot)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    advance((learned, naive), 192)
    sig_b320 = cce19.response_signature(kernel, learned, node, 320)["signature_sha256"]
    sig_n320 = cce19.response_signature(kernel, naive, node, 320)["signature_sha256"]
    recurrent320 = c2_assay(kernel, learned, meta, node, 320, "TWO_PARENT_D12")
    row = {"bits": bits, "substituted_supports": selected,
           "support_t128": support_state(snapshot, supports), "support_t320": support_state(learned, supports),
           "critical_t128": unpack_scalar(snapshot.raw[critical]) if int(snapshot.raw[critical]) else None,
           "critical_t320": unpack_scalar(learned.raw[critical]) if int(learned.raw[critical]) else None,
           "initial_C2_t128": initial_competence, "B_response_distinction_t320": sig_b320 != sig_n320,
           "recurrent_C2_t320_without_host_vacancy": recurrent320,
           "developmental_recurrence_candidate": (initial_competence["C2"] and sig_b320 != sig_n320 and recurrent320["C2"])}
    advance((learned, naive), 384)
    sig_b704 = cce19.response_signature(kernel, learned, node, 704)["signature_sha256"]
    sig_n704 = cce19.response_signature(kernel, naive, node, 704)["signature_sha256"]
    recurrent704 = c2_assay(kernel, learned, meta, node, 704, "SEM1_WRITER")
    row.update({"support_t704": support_state(learned, supports),
                "critical_t704": unpack_scalar(learned.raw[critical]) if int(learned.raw[critical]) else None,
                "B_response_distinction_t704": sig_b704 != sig_n704,
                "recurrent_C2_t704_without_host_vacancy": recurrent704,
                "late_developmental_recurrence_candidate": (initial_competence["C2"] and sig_b704 != sig_n704 and recurrent704["C2"])})
    print(json.dumps({"node": node_id, "bits": bits, "initial": initial_competence["C2"],
                      "B320": row["B_response_distinction_t320"], "critical320": row["critical_t320"] is not None,
                      "C320": recurrent320["C2"], "B704": row["B_response_distinction_t704"],
                      "critical704": row["critical_t704"] is not None, "C704": recurrent704["C2"]}, sort_keys=True), flush=True)
    return row


def evaluate_node(kernel, node_id, bit_values):
    rows = [evaluate_bits(kernel, node_id, bits) for bits in bit_values]
    return {"node_id": node_id, "rows": rows,
            "initial_competent_bits": [r["bits"] for r in rows if r["initial_C2_t128"]["C2"]],
            "recurrent320_bits": [r["bits"] for r in rows if r["developmental_recurrence_candidate"]],
            "recurrent704_bits": [r["bits"] for r in rows if r["late_developmental_recurrence_candidate"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1, DISCOVERY_BITS)
    holdout_bits = tuple(dict.fromkeys(HOLDOUT_CORE + tuple(discovery["recurrent320_bits"]) + tuple(discovery["recurrent704_bits"])))
    holdout = evaluate_node(kernel, 2, holdout_bits)
    recurrent320 = sorted(set(discovery["recurrent320_bits"]) & set(holdout["recurrent320_bits"]))
    recurrent704 = sorted(set(discovery["recurrent704_bits"]) & set(holdout["recurrent704_bits"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.developmental_support_substitution.v1",
        "question": "Can nonimmutable support installed at t0 preserve initial C2 and later renew competence without a host vacancy?",
        "planning": {"mechanism": "complete 2^4 semantic4-to-semantic1 substitution of the tetrahedral developmental support",
                     "controls": ["unchanged support", "four single substitutions", "all substituted", "second relational frame for core/candidates"],
                     "predicted_outcomes": ["developmental failure", "initial competence only", "natural vacancy", "recurrent C2"],
                     "estimated_runtime_minutes": 12, "stop_condition": "all 16 subsets in discovery; core and candidates in holdout"},
        "design": {"substitution_at_t0": True, "discovery_subsets": list(DISCOVERY_BITS),
                   "holdout_subsets": list(holdout_bits), "assay_ticks": [128, 320, 704],
                   "diagnostic_experiences": True, "no_host_vacancy": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"fresh_replicated_recurrent_C2_t320": recurrent320,
                    "fresh_replicated_recurrent_C2_t704": recurrent704,
                    "developmental_support_substitution_renews_competence": bool(recurrent320 or recurrent704),
                    "native_second_environment_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_DEVELOPMENTAL_RENEWAL_CANDIDATE" if recurrent320 or recurrent704 else "BOUNDED_NULL",
        "claim_guard": "Support substitutions are frozen t0 architectures, but experiences/probes remain diagnostic. The exhaustive discovery applies only to semantic labels on the four original supports, not moving lineages, replacement topologies or collective renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
