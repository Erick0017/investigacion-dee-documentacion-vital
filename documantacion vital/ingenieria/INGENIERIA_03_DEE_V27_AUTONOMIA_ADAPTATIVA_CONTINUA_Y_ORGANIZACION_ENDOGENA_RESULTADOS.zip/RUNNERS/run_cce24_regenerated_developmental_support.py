#!/usr/bin/env python3
"""Replace fixed tetrahedral anchors with sem1 anchors replenished by persistent sources."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, sha256_file, unpack_scalar, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce19_vacancy_reorganization_window as cce19
import run_cce23_developmental_support_substitution as cce23
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE24_REGENERATED_DEVELOPMENTAL_SUPPORT.json"
REPORT = ROOT / "ING03_REGENERATED_DEVELOPMENTAL_SUPPORT.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE23_DEVELOPMENTAL_SUPPORT_SUBSTITUTION.json"
CRITICAL_OFFSET = (1, -1, -1)
DISCOVERY_BITS = tuple(format(i, "04b") for i in range(16))
HOLDOUT_CORE = ("0000", "0001", "0010", "0100", "1000", "1111")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def add(q, d, n):
    return tuple((int(q[i]) + int(d[i])) % int(n) for i in range(3))


def set_both(world, q, raw, clock=0):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def configure(kernel, node_id, bits):
    world, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    critical = cce19.cce11.add_offset(node["center"], r09.transform(CRITICAL_OFFSET, node["frame"]), meta["n"])
    supports = cce23.tetra_supports(world, critical, meta["n"])
    regenerated = []
    for index, row in enumerate(supports):
        if bits[index] != "1": continue
        offset = tuple(row["offset"]); anchor = tuple(row["position"]); source = add(anchor, offset, meta["n"])
        if int(world.raw[source]): raise RuntimeError(f"regenerator source overlap at {source}")
        set_both(world, anchor, 0, 0)
        direction = tuple(-v for v in offset)
        value = int(pack(94000 + index, 0, direction, 4))
        set_both(world, source, value, 0)
        regenerated.append({"index": index, "offset": list(offset), "anchor": list(anchor),
                            "source": list(source), "source_raw": value, "direction": list(direction)})
    return world, meta, node, critical, supports, regenerated


def snapshot_support(world, supports, regenerated):
    return {"anchors": [{"offset": row["offset"], "value": unpack_scalar(world.raw[tuple(row["position"])]) if int(world.raw[tuple(row["position"])]) else None}
                        for row in supports],
            "sources": [{"offset": row["offset"], "value": unpack_scalar(world.raw[tuple(row["source"])]) if int(world.raw[tuple(row["source"])]) else None}
                        for row in regenerated]}


def advance_trace(worlds, ticks, critical, supports):
    trace = []
    for latency in range(1, ticks + 1):
        for world in worlds: world.tick()
        primary = worlds[0]
        trace.append({"latency": latency, "critical_present": bool(int(primary.raw[critical])),
                      "anchor_occupancy": sum(bool(int(primary.raw[tuple(row["position"])])) for row in supports)})
    return trace


def evaluate_bits(kernel, node_id, bits):
    base, meta, node, critical, supports, regenerated = configure(kernel, node_id, bits)
    trace_dev = advance_trace((base,), 128, critical, supports)
    snapshot = clone(kernel, base)
    initial = cce23.c2_assay(kernel, snapshot, meta, node, 128, "SEM1_WRITER")
    row = {"bits": bits, "regenerated_supports": regenerated,
           "development_trace": {"critical_present_ticks": sum(x["critical_present"] for x in trace_dev),
                                 "critical_transitions": sum(trace_dev[i]["critical_present"] != trace_dev[i-1]["critical_present"] for i in range(1, len(trace_dev))),
                                 "minimum_anchor_occupancy": min(x["anchor_occupancy"] for x in trace_dev)},
           "support_t128": snapshot_support(snapshot, supports, regenerated),
           "critical_t128": unpack_scalar(snapshot.raw[critical]) if int(snapshot.raw[critical]) else None,
           "initial_C2_t128": initial}
    if not initial["C2"]:
        row.update({"B_response_distinction_t320": False, "recurrent_C2_t320": None,
                    "B_response_distinction_t704": False, "recurrent_B_C2_t704": None,
                    "candidate_t320": False, "candidate_t704": False})
        print(json.dumps({"node": node_id, "bits": bits, "initial": False,
                          "dev_transitions": row["development_trace"]["critical_transitions"]}, sort_keys=True), flush=True)
        return row

    learned, naive = clone(kernel, snapshot), clone(kernel, snapshot)
    cce03.install(learned, meta, node, "SEM1_WRITER", 128)
    trace_b = advance_trace((learned, naive), 192, critical, supports)
    sig_b320 = cce19.response_signature(kernel, learned, node, 320)["signature_sha256"]
    sig_n320 = cce19.response_signature(kernel, naive, node, 320)["signature_sha256"]
    recurrent320 = cce23.c2_assay(kernel, learned, meta, node, 320, "TWO_PARENT_D12")
    trace_late = advance_trace((learned, naive), 384, critical, supports)
    sig_b704 = cce19.response_signature(kernel, learned, node, 704)["signature_sha256"]
    sig_n704 = cce19.response_signature(kernel, naive, node, 704)["signature_sha256"]
    recurrent704 = cce23.c2_assay(kernel, learned, meta, node, 704, "SEM1_WRITER")
    row.update({"support_t320": snapshot_support(learned, supports, regenerated),
                "history_trace_128_320": {"critical_empty_ticks": sum(not x["critical_present"] for x in trace_b),
                                          "minimum_anchor_occupancy": min(x["anchor_occupancy"] for x in trace_b)},
                "B_response_distinction_t320": sig_b320 != sig_n320, "recurrent_C2_t320": recurrent320,
                "history_trace_320_704": {"critical_empty_ticks": sum(not x["critical_present"] for x in trace_late),
                                          "minimum_anchor_occupancy": min(x["anchor_occupancy"] for x in trace_late)},
                "support_t704": snapshot_support(learned, supports, regenerated),
                "B_response_distinction_t704": sig_b704 != sig_n704, "recurrent_B_C2_t704": recurrent704,
                "candidate_t320": sig_b320 != sig_n320 and recurrent320["C2"],
                "candidate_t704": sig_b704 != sig_n704 and recurrent704["C2"]})
    print(json.dumps({"node": node_id, "bits": bits, "initial": True, "B320": sig_b320 != sig_n320,
                      "C320": recurrent320["C2"], "B704": sig_b704 != sig_n704, "C704": recurrent704["C2"],
                      "empty_early": row["history_trace_128_320"]["critical_empty_ticks"],
                      "empty_late": row["history_trace_320_704"]["critical_empty_ticks"]}, sort_keys=True), flush=True)
    return row


def evaluate_node(kernel, node_id, bit_values):
    rows = [evaluate_bits(kernel, node_id, bits) for bits in bit_values]
    return {"node_id": node_id, "rows": rows,
            "initial_competent_bits": [r["bits"] for r in rows if r["initial_C2_t128"]["C2"]],
            "candidate_t320_bits": [r["bits"] for r in rows if r["candidate_t320"]],
            "candidate_t704_bits": [r["bits"] for r in rows if r["candidate_t704"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1, DISCOVERY_BITS)
    candidate_bits = tuple(discovery["candidate_t320_bits"] + discovery["candidate_t704_bits"])
    holdout_bits = tuple(dict.fromkeys(HOLDOUT_CORE + candidate_bits))
    holdout = evaluate_node(kernel, 2, holdout_bits)
    r320 = sorted(set(discovery["candidate_t320_bits"]) & set(holdout["candidate_t320_bits"]))
    r704 = sorted(set(discovery["candidate_t704_bits"]) & set(holdout["candidate_t704_bits"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.regenerated_developmental_support.v1",
        "question": "Can replenished ordinary anchors preserve competence while allowing native support turnover and later C2?",
        "planning": {"mechanism": "persistent semantic4 sources one step outside each selected anchor continuously supply semantic1 support",
                     "controls": ["fixed original", "single regenerated anchors", "all regenerated", "all 16 subsets", "rotated holdout"],
                     "predicted_outcomes": ["developmental loss", "stable replenishment only", "turnover window", "recurrent competence"],
                     "estimated_runtime_minutes": 8, "stop_condition": "all subsets discovery; core/candidates holdout"},
        "design": {"architecture_frozen_at_t0": True, "subsets": list(DISCOVERY_BITS),
                   "source_semantic": 4, "regenerated_anchor_semantic": 1,
                   "assay_ticks": [128, 320, 704], "no_host_vacancy": True,
                   "diagnostic_experiences": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"fresh_replicated_recurrent_C2_t320": r320,
                    "fresh_replicated_recurrent_C2_t704": r704,
                    "regenerated_support_renews_competence": bool(r320 or r704),
                    "native_second_environment_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_REGENERATED_SUPPORT_CANDIDATE" if r320 or r704 else "BOUNDED_NULL",
        "claim_guard": "Persistent sources and geometry are configured at t0, but experience/probe remain diagnostic. This exact replenished-anchor family does not exhaust traveling, oscillatory or collective developmental support.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
