#!/usr/bin/env python3
"""Dense competence mapping of the oscillatory regenerated-support architectures."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce23_developmental_support_substitution as cce23
import run_cce24_regenerated_developmental_support as cce24
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE25_REGENERATED_SUPPORT_PHASE_ATLAS.json"
REPORT = ROOT / "ING03_REGENERATED_SUPPORT_PHASE_ATLAS.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE24_REGENERATED_DEVELOPMENTAL_SUPPORT.json"
VARIANTS = ("0000", "0001", "1111")
TIMES = (124, 125, 126, 127)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def snapshots(kernel, node_id, bits, times):
    world, meta, node, critical, supports, regenerated = cce24.configure(kernel, node_id, bits)
    wanted = set(times); states = {}
    for tick in range(1, max(times) + 1):
        world.tick()
        if tick in wanted: states[tick] = clone(kernel, world)
    return states, meta, node, critical, supports, regenerated


def phase_assay(kernel, state, meta, node, tick):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, "SEM1_WRITER", tick)
    differences, markers = [], []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        values = yes.raw & np.uint64(0xFFFFFFFF)
        markers.append(int(sum(np.count_nonzero(values == marker) for marker in record["marker_states"])))
    s1 = all(differences[-64:]); ended = all(v == 0 for v in markers[-64:])
    if not (s1 and ended):
        return {"mode": "SEM1_WRITER", "S0": any(differences), "S1": s1,
                "episode_ended": ended, "probe": {"skipped": "C2 impossible because S1/episode criterion failed"}, "C2": False}
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160)
    return {"mode": "SEM1_WRITER", "S0": any(differences), "S1": s1,
            "episode_ended": ended, "probe": probe, "C2": probe["probe_interaction_differs"]}


def evaluate_variant(kernel, node_id, bits, times):
    states, meta, node, critical, supports, regenerated = snapshots(kernel, node_id, bits, times)
    rows = []
    for tick in times:
        state = states[tick]
        assay = phase_assay(kernel, state, meta, node, tick)
        row = {"tick": tick, "critical_present": bool(int(state.raw[critical])),
               "anchor_occupancy": sum(bool(int(state.raw[tuple(x["position"])])) for x in supports),
               "C2": assay}
        rows.append(row)
        print(json.dumps({"node": node_id, "bits": bits, "tick": tick,
                          "critical": row["critical_present"], "anchors": row["anchor_occupancy"],
                          "S1": assay["S1"], "C2": assay["C2"]}, sort_keys=True), flush=True)
    return {"bits": bits, "regenerated_support_count": len(regenerated), "rows": rows,
            "C2_open_ticks": [r["tick"] for r in rows if r["C2"]["C2"]]}


def evaluate_node(kernel, node_id, variants, times_by_variant):
    rows = [evaluate_variant(kernel, node_id, bits, times_by_variant[bits]) for bits in variants]
    return {"node_id": node_id, "variants": rows,
            "open_pairs": [[row["bits"], tick] for row in rows for tick in row["C2_open_ticks"]]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery = evaluate_node(kernel, 1, VARIANTS, {bits: TIMES for bits in VARIANTS})
    candidate_pairs = [(bits, tick) for bits, tick in discovery["open_pairs"] if bits != "0000"]
    if candidate_pairs:
        holdout_variants = tuple(dict.fromkeys(bits for bits, _ in candidate_pairs))
        times_by = {bits: tuple(sorted({tick for b, tick in candidate_pairs if b == bits})) for bits in holdout_variants}
    else:
        holdout_variants = ("0000", "0001", "1111")
        times_by = {bits: (124, 125) for bits in holdout_variants}
    holdout = evaluate_node(kernel, 2, holdout_variants, times_by)
    replicated = sorted([list(pair) for pair in set(map(tuple, discovery["open_pairs"])) & set(map(tuple, holdout["open_pairs"])) if pair[0] != "0000"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.regenerated_support_phase_atlas.v1",
        "question": "Did regenerated-support turnover destroy competence or shift it to another phase near t128?",
        "planning": {"mechanism": "phase-resolved SEM1 C2 assay across two complete structural alternations",
                     "controls": ["fixed 0000 architecture", "one regenerated support", "all four regenerated", "rotated holdout"],
                     "predicted_outcomes": ["no competence", "phase-shifted windows", "anchor-specific windows", "unchanged control only"],
                     "estimated_runtime_minutes": 8, "stop_condition": "12 discovery assays spanning two alternations; holdout only candidate or six core canaries"},
        "design": {"variants": list(VARIANTS), "discovery_times": list(TIMES),
                   "experience": "SEM1_WRITER", "diagnostic_only": True,
                   "architecture_frozen_at_t0": True, "no_host_vacancy": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"fresh_replicated_phase_shifted_C2": replicated,
                    "oscillatory_support_retains_functional_competence": bool(replicated),
                    "native_environment_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_PHASE_SHIFTED_COMPETENCE" if replicated else "BOUNDED_NULL_NEAR_T128",
        "claim_guard": "The atlas is limited to t124..127 and representative one/all-support topologies. A null does not exclude other developmental epochs, source topologies or collective competence; a positive remains a host-probed C2 diagnosis.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
