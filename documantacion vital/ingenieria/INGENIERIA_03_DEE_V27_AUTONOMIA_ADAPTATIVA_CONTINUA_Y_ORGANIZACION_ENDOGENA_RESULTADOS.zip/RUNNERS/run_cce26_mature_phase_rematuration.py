#!/usr/bin/env python3
"""Test clock/phase-only rematuration of an already learned CCE regime."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce02_competence_causal_test as cce02
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce19_vacancy_reorganization_window as cce19
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE26_MATURE_PHASE_REMATURATION.json"
REPORT = ROOT / "ING03_MATURE_PHASE_REMATURATION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE25_REGENERATED_SUPPORT_PHASE_ATLAS.json"
RETENTION = 64
ASSAY_HORIZON = 160
L_RAW = 304980
DONOR_TICKS = (128, 320, 336)
MODES = ("SEM1_WRITER", "TWO_PARENT_D12")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in states))


def virgin_snapshots(kernel):
    world, meta, nodes = rca02.build(kernel)
    snapshots = {}
    for tick in range(1, max(DONOR_TICKS) + 1):
        world.tick()
        if tick in DONOR_TICKS:
            snapshots[tick] = clone(kernel, world)
    return snapshots, meta, nodes


def positions_for(node, n, radius, critical):
    if radius == "CRITICAL":
        return [critical]
    return cce02.domain(node, n, int(radius))


def interventions(node, n, critical):
    rows = [{"id": "BASE", "domain": "NONE", "operation": "NONE"}]
    for domain in ("CRITICAL", 0, 2, 6):
        for donor_tick in DONOR_TICKS:
            rows.append({"id": f"{domain}_FROM_T{donor_tick}", "domain": domain,
                         "operation": "DONOR", "donor_tick": donor_tick})
    rows.extend((
        {"id": "CRITICAL_RESET_ZERO", "domain": "CRITICAL", "operation": "ZERO"},
        {"id": "NODE_PLUS_LRAW", "domain": 0, "operation": "SHIFT", "shift": L_RAW},
        {"id": "NODE_PLUS_16", "domain": 0, "operation": "SHIFT", "shift": 16},
        {"id": "NODE_MINUS_16", "domain": 0, "operation": "SHIFT", "shift": -16},
    ))
    for row in rows:
        row["position_count"] = 0 if row["domain"] == "NONE" else len(positions_for(node, n, row["domain"], critical))
    return rows


def apply_clock(world, positions, spec, donor):
    before_raw = np.asarray([world.raw[q] for q in positions], dtype=np.uint64)
    before_clock = np.asarray([world.clock_a[q] for q in positions], dtype=np.uint64)
    if spec["operation"] == "DONOR":
        for q in positions:
            value = donor.clock_a[q]
            world.clock_a[q] = value; world.clock_b[q] = value
    elif spec["operation"] == "ZERO":
        for q in positions:
            world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)
    elif spec["operation"] == "SHIFT":
        shift = int(spec["shift"])
        for q in positions:
            value = np.uint64((int(world.clock_a[q]) + shift) % (1 << 64))
            world.clock_a[q] = value; world.clock_b[q] = value
    after_raw = np.asarray([world.raw[q] for q in positions], dtype=np.uint64)
    after_clock = np.asarray([world.clock_a[q] for q in positions], dtype=np.uint64)
    return {"raw_unchanged": bool(np.array_equal(before_raw, after_raw)),
            "clock_positions_changed": int(np.count_nonzero(before_clock != after_clock))}


def c2_assay(kernel, state, meta, node, tick, mode):
    yes, no = clone(kernel, state), clone(kernel, state)
    record = cce03.install(yes, meta, node, mode, tick)
    differences, markers = [], []
    for _ in range(ASSAY_HORIZON):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, record["marker_states"]))
    s1 = all(differences[-RETENTION:])
    ended = not record["marker_states"] or all(value == 0 for value in markers[-RETENTION:])
    if not (s1 and ended):
        return {"mode": mode, "S0": any(differences), "S1": s1, "episode_ended": ended,
                "probe": {"skipped": "C2 impossible because S1/episode criterion failed"}, "C2": False}
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + ASSAY_HORIZON)
    return {"mode": mode, "S0": any(differences), "S1": s1, "episode_ended": ended,
            "probe": probe, "C2": bool(probe["probe_interaction_differs"])}


def evaluate_node(kernel, node_id, donors, donor_meta, donor_nodes):
    learned0, naive0, meta, node, critical = cce19.build(kernel, node_id)
    donor_node = donor_nodes[node_id - 1]
    if node["center"] != donor_node["center"] or meta["n"] != donor_meta["n"]:
        raise RuntimeError("donor architecture mismatch")
    original_b = cce19.response_signature(kernel, learned0, node, 320)["signature_sha256"]
    specs = interventions(node, meta["n"], critical)
    rows = []
    for spec in specs:
        learned, naive = clone(kernel, learned0), clone(kernel, naive0)
        change_l = change_n = {"raw_unchanged": True, "clock_positions_changed": 0}
        if spec["domain"] != "NONE":
            positions = positions_for(node, meta["n"], spec["domain"], critical)
            donor = donors.get(spec.get("donor_tick"))
            change_l = apply_clock(learned, positions, spec, donor)
            change_n = apply_clock(naive, positions, spec, donor)
        sig_l = cce19.response_signature(kernel, learned, node, 320)["signature_sha256"]
        sig_n = cce19.response_signature(kernel, naive, node, 320)["signature_sha256"]
        assays_l = [c2_assay(kernel, learned, meta, node, 320, mode) for mode in MODES]
        assays_n = [c2_assay(kernel, naive, meta, node, 320, mode) for mode in MODES]
        c2_modes = [row["mode"] for row in assays_l if row["C2"]]
        row = {"intervention": spec, "learned_change_audit": change_l, "naive_change_audit": change_n,
               "B_exact_response_preserved": sig_l == original_b,
               "B_response_distinction_retained": sig_l != sig_n,
               "learned_assays": assays_l, "naive_assays": assays_n,
               "learned_C2_modes": c2_modes,
               "B_distinction_plus_C2": bool(c2_modes) and sig_l != sig_n}
        rows.append(row)
        print(json.dumps({"node": node_id, "intervention": spec["id"],
                          "B_exact": row["B_exact_response_preserved"],
                          "B_distinct": row["B_response_distinction_retained"],
                          "C2": c2_modes}, sort_keys=True), flush=True)
    return {"node_id": node_id, "frame": node["frame"], "critical": list(critical), "rows": rows,
            "candidates": [{"intervention": row["intervention"]["id"], "C2_modes": row["learned_C2_modes"]}
                           for row in rows if row["B_distinction_plus_C2"]],
            "exact_candidates": [{"intervention": row["intervention"]["id"], "C2_modes": row["learned_C2_modes"]}
                                 for row in rows if row["B_distinction_plus_C2"] and row["B_exact_response_preserved"]]}


def candidate_pairs(frame):
    return {(row["intervention"], mode) for row in frame["candidates"] for mode in row["C2_modes"]}


def exact_pairs(frame):
    return {(row["intervention"], mode) for row in frame["exact_candidates"] for mode in row["C2_modes"]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    donors, donor_meta, donor_nodes = virgin_snapshots(kernel)
    discovery = evaluate_node(kernel, 1, donors, donor_meta, donor_nodes)
    holdout = evaluate_node(kernel, 2, donors, donor_meta, donor_nodes)
    replicated = sorted([{"intervention": a, "mode": b} for a, b in candidate_pairs(discovery) & candidate_pairs(holdout)],
                        key=lambda x: (x["intervention"], x["mode"]))
    exact = sorted([{"intervention": a, "mode": b} for a, b in exact_pairs(discovery) & exact_pairs(holdout)],
                   key=lambda x: (x["intervention"], x["mode"]))
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.mature_phase_rematuration.v1",
        "question": "Can clock/phase organization alone reopen C2 in a mature B regime while retaining its learned response class?",
        "planning": {"mechanism": "clock-only transplantation/reset/phase shifts with RAW and tetrahedral topology frozen",
                     "controls": ["BASE", "virgin open/closed clock donors", "critical/node/r2/r6 domains",
                                  "L_raw exact phase control", "+/-16 local shifts", "matched naive history", "rotated holdout"],
                     "predicted_outcomes": ["no reopening", "phase-only C2", "B loss", "B-preserving phase rematuration"],
                     "estimated_runtime_minutes": 10,
                     "stop_condition": "17 clock interventions x two challenge modes in two relational frames"},
        "design": {"B_tick": 128, "phase_intervention_tick": 320, "donor_ticks": list(DONOR_TICKS),
                   "domains": ["CRITICAL", 0, 2, 6], "challenge_modes": list(MODES),
                   "L_raw": L_RAW, "diagnostic_only": True, "RAW_modified": False,
                   "topology_modified": False, "python_intervention_after_t0": True},
        "discovery": discovery, "holdout": holdout,
        "summary": {"fresh_replicated_B_distinction_plus_C2": replicated,
                    "fresh_replicated_exact_B_plus_C2": exact,
                    "phase_only_competence_reopening": bool(replicated),
                    "phase_only_exact_function_preserving_reopening": bool(exact),
                    "native_phase_transition_demonstrated": False,
                    "native_environment_demonstrated": False, "native_function_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_PHASE_REMATURATION_CANDIDATE" if replicated else "CONTRADICTED_IN_TESTED_DOMAIN",
        "claim_guard": "Clock edits are host diagnostics. A bounded null applies only to the tested local phase donors/shifts and does not exclude collective phase, morphology, hidden X_FULL history or another competence mechanism.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
