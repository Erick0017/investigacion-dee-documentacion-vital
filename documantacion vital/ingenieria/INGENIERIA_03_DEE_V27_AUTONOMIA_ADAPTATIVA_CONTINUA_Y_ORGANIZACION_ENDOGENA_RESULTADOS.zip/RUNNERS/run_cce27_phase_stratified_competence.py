#!/usr/bin/env python3
"""Map complementary developmental competence schedules created by t0 phase diversity."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce01_recurrent_competence_atlas as cce01
import run_cce02_competence_causal_test as cce02
import run_cce23_developmental_support_substitution as cce23
import run_rca02_continuous_competence_core_periphery as rca02


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE27_PHASE_STRATIFIED_COMPETENCE.json"
REPORT = ROOT / "ING03_PHASE_STRATIFIED_COMPETENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE26_MATURE_PHASE_REMATURATION.json"
OFFSETS = tuple(range(0, 193, 16)) + (195, 208, 224, 240, 260, 304980)
EVENT_TICKS = (128, 320, 704)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def shift_node_clock(world, node, n, offset):
    positions = cce02.domain(node, n, 0)
    for q in positions:
        value = np.uint64((int(world.clock_a[q]) + int(offset)) % (1 << 64))
        world.clock_a[q] = value; world.clock_b[q] = value
    return len(positions)


def build_shifted(kernel, node_id, offset):
    world, meta, nodes = rca02.build(kernel); node = nodes[node_id - 1]
    count = shift_node_clock(world, node, meta["n"], offset)
    return world, meta, node, count


def snapshots(kernel, node_id, offset):
    world, meta, node, count = build_shifted(kernel, node_id, offset)
    states = {}
    for tick in range(1, max(EVENT_TICKS) + 1):
        world.tick()
        if tick in EVENT_TICKS:
            states[tick] = clone(kernel, world)
    return states, meta, node, count


def s1_schedule(kernel, node_id, offset):
    states, meta, node, count = snapshots(kernel, node_id, offset)
    rows = []
    for tick in EVENT_TICKS:
        assay = cce01.adaptive_assay(kernel, states[tick], meta, node, tick)
        rows.append({"tick": tick, "S0": assay["S0_reactivity"],
                     "S1": assay["S1_retained_change"],
                     "first_latency": assay["first_node_difference_latency"],
                     "terminal_world_difference": assay["terminal_world_difference"]})
    return {"node_id": node_id, "frame": node["frame"], "offset": offset,
            "shifted_position_count": count, "rows": rows,
            "schedule": [row["tick"] for row in rows if row["S1"]]}, states, meta, node


def row_at(result, tick):
    return next(row for row in result["rows"] if row["tick"] == tick)


def classify(result):
    a, b, c = (row_at(result, tick)["S1"] for tick in EVENT_TICKS)
    return {"A_only": a and not b and not c,
            "B_selector": (not a) and b,
            "C_selector": (not a) and (not b) and c,
            "all_open": a and b and c,
            "all_closed": not (a or b or c)}


def c2_validate(kernel, state, meta, node, tick):
    return cce23.c2_assay(kernel, state, meta, node, tick, "SEM1_WRITER")


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    discovery_rows = []; cached = {}
    for offset in OFFSETS:
        result, states, meta, node = s1_schedule(kernel, 1, offset)
        result["classification"] = classify(result); discovery_rows.append(result)
        cached[offset] = (states, meta, node)
        print(json.dumps({"node": 1, "offset": offset, "schedule": result["schedule"],
                          **result["classification"]}, sort_keys=True), flush=True)

    b_offsets = [row["offset"] for row in discovery_rows if row["classification"]["B_selector"]]
    c_offsets = [row["offset"] for row in discovery_rows if row["classification"]["C_selector"]]
    informative = list(dict.fromkeys((0, 16, 304980, *b_offsets, *c_offsets)))
    holdout_rows = []
    for offset in informative:
        result, states, meta, node = s1_schedule(kernel, 2, offset)
        result["classification"] = classify(result); holdout_rows.append(result)
        print(json.dumps({"node": 2, "offset": offset, "schedule": result["schedule"],
                          **result["classification"]}, sort_keys=True), flush=True)

    hb = {row["offset"] for row in holdout_rows if row["classification"]["B_selector"]}
    hc = {row["offset"] for row in holdout_rows if row["classification"]["C_selector"]}
    replicated_b = sorted(set(b_offsets) & hb); replicated_c = sorted(set(c_offsets) & hc)

    validation = []
    for offset, role, tick in ([(x, "B_SELECTOR", 320) for x in replicated_b]
                               + [(x, "C_SELECTOR", 704) for x in replicated_c]
                               + [(0, "BASE_CONTROL", 128), (304980, "LRAW_CONTROL", 128)]):
        states, meta, node = cached[offset]
        assay = c2_validate(kernel, states[tick], meta, node, tick)
        validation.append({"node_id": 1, "offset": offset, "role": role, "tick": tick, "assay": assay})
        print(json.dumps({"validation": role, "offset": offset, "tick": tick, "C2": assay["C2"]}, sort_keys=True), flush=True)

    c2_b = [row["offset"] for row in validation if row["role"] == "B_SELECTOR" and row["assay"]["C2"]]
    c2_c = [row["offset"] for row in validation if row["role"] == "C_SELECTOR" and row["assay"]["C2"]]
    lraw_same = (next(row for row in discovery_rows if row["offset"] == 0)["schedule"]
                 == next(row for row in discovery_rows if row["offset"] == 304980)["schedule"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.phase_stratified_competence.v1",
        "question": "Can t0 phase diversity create complementary late competence opportunities in otherwise matched bounded regions?",
        "planning": {"mechanism": "uniform local clock offsets installed before development",
                     "controls": ["offset0", "offset16", "L_raw=304980 exact raw-phase control", "rotated node2 holdout"],
                     "predicted_outcomes": ["identical schedules", "phase-shifted windows", "B-only opportunity", "C-only opportunity"],
                     "estimated_runtime_minutes": 12,
                     "stop_condition": "19 causal phases at ticks128/320/704; fresh frame for selector schedules"},
        "design": {"offsets": list(OFFSETS), "event_ticks": list(EVENT_TICKS),
                   "phase_installed_at_t0": True, "shift_domain": "node radius0 causal positions",
                   "diagnostic_challenges": True, "future_answer_encoded": False,
                   "recipient_selection_tested": False, "native_environment_tested": False},
        "discovery": {"node_id": 1, "rows": discovery_rows},
        "holdout": {"node_id": 2, "tested_offsets": informative, "rows": holdout_rows},
        "C2_validation": validation,
        "summary": {"fresh_replicated_B_selector_offsets": replicated_b,
                    "fresh_replicated_C_selector_offsets": replicated_c,
                    "B_selector_offsets_with_C2": c2_b,
                    "C_selector_offsets_with_C2": c2_c,
                    "complementary_C2_phase_strata": bool(c2_b and c2_c),
                    "L_raw_schedule_control_equal": lraw_same,
                    "continuous_time_coverage_demonstrated": False,
                    "nonaddressed_capture_demonstrated": False,
                    "renewal_or_reuse_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_COMPLEMENTARY_PHASE_STRATA" if c2_b and c2_c else "BOUNDED_NULL_OR_PARTIAL_PHASE_STRATIFICATION",
        "claim_guard": "Clock strata are frozen t0 developmental conditions and challenges remain host diagnostics. A positive schedule is not continuous coverage, blind environmental capture, renewable competence, RW3 or a biological clock.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "discovery", "holdout", "C2_validation")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
