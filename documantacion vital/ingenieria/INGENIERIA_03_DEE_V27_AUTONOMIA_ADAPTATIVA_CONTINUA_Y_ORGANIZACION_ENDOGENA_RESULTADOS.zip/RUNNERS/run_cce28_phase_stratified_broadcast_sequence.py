#!/usr/bin/env python3
"""Diagnostic A-local then B/C-broadcast sequence with a late phase stratum."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, sha256_file, write_json
import run_cce02_competence_causal_test as cce02
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce08_diagnostic_recurrent_sequence as cce08
import run_cce10_spatial_competence_ecology as cce10
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE28_PHASE_STRATIFIED_BROADCAST_SEQUENCE.json"
REPORT = ROOT / "ING03_PHASE_STRATIFIED_BROADCAST_SEQUENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE27_PHASE_STRATIFIED_COMPETENCE.json"
RETENTION = 64
PHASE_OFFSET = 16
LATE_OFFSET = (0, -14, 0)


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds:
            world.tick()


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    unique = set(states)
    return int(sum(np.count_nonzero(values == state) for state in unique))


def build(kernel):
    world, meta, nodes = rca02.build(kernel)
    late = r09.add_rotated_learner(world, meta, add(meta["c"], LATE_OFFSET, 1, meta["n"]), 4, "x")
    for q in cce02.domain(late, meta["n"], 0):
        value = np.uint64((int(world.clock_a[q]) + PHASE_OFFSET) % (1 << 64))
        world.clock_a[q] = value; world.clock_b[q] = value
    return world, meta, [nodes[0], nodes[1], late]


def broadcast_stage(kernel, history, meta, nodes, tick, mode):
    yes, no = clone(kernel, history), clone(kernel, history)
    records = [cce03.install(yes, meta, node, mode, tick) for node in nodes]
    marker_states = [state for record in records for state in record["marker_states"]]
    differences = {node["id"]: [] for node in nodes}; markers = []
    for _ in range(160):
        yes.tick(); no.tick()
        for node in nodes:
            differences[node["id"]].append(r09.delta(yes, node) != r09.delta(no, node))
        markers.append(marker_count(yes, marker_states))
    ended = not marker_states or all(value == 0 for value in markers[-RETENTION:])
    node_results = []
    for node in nodes:
        series = differences[node["id"]]
        s1 = all(series[-RETENTION:])
        probe = cce05.fingerprint_fast(kernel, yes, no, node, tick + 160) if s1 and ended else {
            "probe_interaction_differs": False,
            "skipped": "C2 impossible because S1/episode criterion failed",
        }
        node_results.append({"node_id": node["id"], "frame": node["frame"],
                             "S0": any(series), "S1": s1, "episode_ended": ended,
                             "first_difference_latency": next((i + 1 for i, value in enumerate(series) if value), None),
                             "probe": probe, "C2": bool(s1 and ended and probe["probe_interaction_differs"])})
    return yes, no, {"tick": tick, "mode": mode, "broadcast_to_node_ids": [node["id"] for node in nodes],
                     "same_mode_at_all_ports": True, "node_results": node_results,
                     "episode_ended_last64": ended, "terminal_marker_count": markers[-1]}


def result_for(stage, node_id):
    return next(row for row in stage["node_results"] if row["node_id"] == node_id)


def response_hash(kernel, world, node, tick):
    return cce08.response_signature(kernel, world, node, tick)["signature_sha256"]


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = build(kernel); node_a, node_b, node_c = nodes
    advance((base,), 128)

    A, N, stage_a = cce10.experience_pair(kernel, base, meta, node_a, 128, "SEM1_WRITER")
    stage_a["localized_first_experience"] = True
    advance((A, N), 32)
    stage_a["response_class_t320"] = response_hash(kernel, A, node_a, 320) != response_hash(kernel, N, node_a, 320)

    AB, A_no_b, stage_b = broadcast_stage(kernel, A, meta, nodes, 320, "TWO_PARENT_D12")
    stage_b["organization_selected_nodes"] = [row["node_id"] for row in stage_b["node_results"] if row["C2"]]
    stage_b["old_A_response_preserved"] = (response_hash(kernel, AB, node_a, 480)
                                                == response_hash(kernel, A_no_b, node_a, 480))

    advance((AB, A_no_b), 224)
    ABC, AB_no_c, stage_c = broadcast_stage(kernel, AB, meta, nodes, 704, "SEM1_WRITER")
    stage_c["organization_selected_nodes"] = [row["node_id"] for row in stage_c["node_results"] if row["C2"]]
    stage_c["old_A_response_preserved"] = (response_hash(kernel, ABC, node_a, 864)
                                                == response_hash(kernel, AB_no_c, node_a, 864))
    stage_c["old_B_response_preserved"] = (response_hash(kernel, ABC, node_b, 864)
                                                == response_hash(kernel, AB_no_c, node_b, 864))

    a_ok = bool(stage_a["C2_response_class"] and stage_a["response_class_t320"])
    b_selected = stage_b["organization_selected_nodes"] == [node_b["id"]]
    c_selected = stage_c["organization_selected_nodes"] == [node_c["id"]]
    sequence = a_ok and b_selected and c_selected
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.phase_stratified_broadcast_sequence.v1",
        "question": "Can saturation plus a late developmental phase stratum select successive recipients under non-addressed diagnostic broadcasts?",
        "planning": {"mechanism": "two ordinary early regions plus one phase16 late region; identical B/C challenge installed at every port",
                     "controls": ["same-history no-event branch at every stage", "finite marker extinction",
                                  "old-response preservation", "no B/C recipient choice by host"],
                     "predicted_outcomes": ["broadcast captures all", "no second capture", "B selects fresh early region",
                                            "C selects late phase stratum", "history interference closes late stratum"],
                     "estimated_runtime_minutes": 5,
                     "stop_condition": "A@128, broadcast B@320, broadcast C@704 through diagnostic response fingerprints"},
        "design": {"continuous_world": True,
                   "regions": [{"node_id": node_a["id"], "role": "initial_local_A", "phase_offset": 0},
                               {"node_id": node_b["id"], "role": "uncommitted_early", "phase_offset": 0},
                               {"node_id": node_c["id"], "role": "late_phase_stratum", "phase_offset": PHASE_OFFSET,
                                "offset": list(LATE_OFFSET), "frame": node_c["frame"]}],
                   "events": [{"tick": 128, "scope": "localized_diagnostic", "mode": "SEM1_WRITER"},
                              {"tick": 320, "scope": "all_three_ports_broadcast", "mode": "TWO_PARENT_D12"},
                              {"tick": 704, "scope": "all_three_ports_broadcast", "mode": "SEM1_WRITER"}],
                   "B_C_explicit_recipient": False, "host_diagnostic_events": True,
                   "native_blind_environment": False, "preconditioned_regions": 3},
        "stage_A": stage_a, "stage_B_broadcast": stage_b, "stage_C_broadcast": stage_c,
        "summary": {"A_retained_response": a_ok,
                    "B_selected_only_fresh_early_region": b_selected,
                    "C_selected_only_late_phase_stratum": c_selected,
                    "diagnostic_three_stage_organization_selection": sequence,
                    "one_shot_region_consumption": True, "bounded_regions": 3,
                    "native_environment_demonstrated": False, "native_function_demonstrated": False,
                    "renewal_or_reuse_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_THREE_STAGE_ORGANIZATION_SELECTION" if sequence else "BOUNDED_NULL_OR_PARTIAL_SELECTION",
        "claim_guard": "A is localized and all experiences are host diagnostics; fingerprints are external. Even a positive three-stage sequence consumes three preconditioned regions and is not native blind capture, RW3 or RW4.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "stage_A", "stage_B_broadcast", "stage_C_broadcast")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "B_selected": stage_b["organization_selected_nodes"],
                      "C_selected": stage_c["organization_selected_nodes"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
