#!/usr/bin/env python3
"""Factor the silent B exposure that closes a later phase-stratified C2 window."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce02_competence_causal_test as cce02
import run_cce03_causal_response_fingerprint as cce03
import run_cce23_developmental_support_substitution as cce23
import run_cce28_phase_stratified_broadcast_sequence as cce28


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE29_SILENT_EXPOSURE_INTERFERENCE.json"
REPORT = ROOT / "ING03_SILENT_EXPOSURE_INTERFERENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE28_PHASE_STRATIFIED_BROADCAST_SEQUENCE.json"
MODES = ("NO_B", "B_EARLY_REGION_ONLY", "B_LATE_REGION_ONLY", "B_BROADCAST")
RETENTION = 64


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def advance(worlds, ticks):
    for _ in range(ticks):
        for world in worlds:
            world.tick()


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in set(states)))


def install_mode(world, meta, nodes, mode, tick):
    early, late = nodes[1], nodes[2]
    targets = []
    if mode == "B_EARLY_REGION_ONLY": targets = [early]
    elif mode == "B_LATE_REGION_ONLY": targets = [late]
    elif mode == "B_BROADCAST": targets = list(nodes)
    records = [cce03.install(world, meta, node, "TWO_PARENT_D12", tick) for node in targets]
    return targets, [state for record in records for state in record["marker_states"]]


def build_a_history(kernel):
    base, meta, nodes = cce28.build(kernel)
    advance((base,), 128)
    A, N, stage_a = cce28.cce10.experience_pair(kernel, base, meta, nodes[0], 128, "SEM1_WRITER")
    advance((A, N), 32)
    return A, meta, nodes, stage_a


def exposure_world(kernel, base, meta, nodes, mode):
    world = clone(kernel, base)
    targets, markers = install_mode(world, meta, nodes, mode, 320)
    marker_trace = []
    for _ in range(384):
        world.tick(); marker_trace.append(marker_count(world, markers))
    return world, {"mode": mode, "target_node_ids": [node["id"] for node in targets],
                   "episode_ended_last64": not markers or all(value == 0 for value in marker_trace[-RETENTION:]),
                   "terminal_marker_count": marker_trace[-1] if marker_trace else 0}


def diff_in_positions(a, b, positions):
    return {"raw": int(sum(int(a.raw[q]) != int(b.raw[q]) for q in positions)),
            "clock": int(sum(int(a.clock_a[q]) != int(b.clock_a[q]) for q in positions))}


def c2(kernel, state, meta, node):
    return cce23.c2_assay(kernel, state, meta, node, 704, "SEM1_WRITER")


def global_transplant(kernel, target, donor, component):
    result = clone(kernel, target)
    if component in ("RAW", "R0"):
        result.raw_a[...] = donor.raw; result.raw_b[...] = donor.raw
    if component in ("CLOCK", "R0"):
        result.clock_a[...] = donor.clock_a; result.clock_b[...] = donor.clock_a
    return result


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes, stage_a = build_a_history(kernel); late = nodes[2]
    worlds = {}; exposure = {}
    for mode in MODES:
        worlds[mode], exposure[mode] = exposure_world(kernel, base, meta, nodes, mode)
        exposure[mode]["late_C2_t704"] = c2(kernel, worlds[mode], meta, late)
        print(json.dumps({"mode": mode, "targets": exposure[mode]["target_node_ids"],
                          "ended": exposure[mode]["episode_ended_last64"],
                          "late_C2": exposure[mode]["late_C2_t704"]["C2"]}, sort_keys=True), flush=True)

    control = worlds["NO_B"]
    induced = worlds["B_EARLY_REGION_ONLY"]
    failing = [mode for mode in MODES[1:] if not exposure[mode]["late_C2_t704"]["C2"]]
    remote_induction = (not exposure["NO_B"]["late_C2_t704"]["C2"]
                        and exposure["B_EARLY_REGION_ONLY"]["late_C2_t704"]["C2"]
                        and exposure["B_EARLY_REGION_ONLY"]["episode_ended_last64"])
    selected = "B_EARLY_REGION_ONLY" if remote_induction else None
    tomography = []
    if selected is not None:
        # Sufficiency test: move accessible state from the remotely induced
        # competent world into the otherwise matched NO_B late organization.
        target = control
        donor = induced
        for radius in (0, 2, 6):
            positions = cce02.domain(late, meta["n"], radius)
            for component in ("RAW", "CLOCK", "R0"):
                restored = cce02.transplant(kernel, target, donor, positions, component)
                assay = c2(kernel, restored, meta, late)
                tomography.append({"scope": f"R{radius}", "component": component,
                                   "position_count": len(positions),
                                   "pretransplant_differences": diff_in_positions(donor, target, positions),
                                   "C2_after_induced_component_transplant": assay})
                print(json.dumps({"selected": selected, "scope": f"R{radius}", "component": component,
                                  "C2": assay["C2"]}, sort_keys=True), flush=True)
        for component in ("RAW", "CLOCK", "R0"):
            restored = global_transplant(kernel, target, donor, component)
            assay = c2(kernel, restored, meta, late)
            tomography.append({"scope": "GLOBAL", "component": component,
                               "position_count": int(target.raw.size),
                               "pretransplant_differences": {"raw": int(np.count_nonzero(donor.raw != target.raw)),
                                                             "clock": int(np.count_nonzero(donor.clock_a != target.clock_a))},
                               "C2_after_induced_component_transplant": assay})
            print(json.dumps({"selected": selected, "scope": "GLOBAL", "component": component,
                              "C2": assay["C2"]}, sort_keys=True), flush=True)

    restoring = [{"scope": row["scope"], "component": row["component"]} for row in tomography
                 if row["C2_after_induced_component_transplant"]["C2"]]
    no_b_c2 = exposure["NO_B"]["late_C2_t704"]["C2"]
    local_silent = (no_b_c2 and not exposure["B_LATE_REGION_ONLY"]["late_C2_t704"]["C2"]
                    and exposure["B_LATE_REGION_ONLY"]["episode_ended_last64"])
    nonlocal_silent = (no_b_c2 and not exposure["B_EARLY_REGION_ONLY"]["late_C2_t704"]["C2"]
                       and exposure["B_EARLY_REGION_ONLY"]["episode_ended_last64"])
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.silent_exposure_interference.v1",
        "question": "Can B at another region induce a later C2 opportunity, and where is the accessible causal support of that induction?",
        "planning": {"mechanism": "factor B contact at early versus late region, then transplant RAW/CLOCK/R0 from the induced history into NO_B",
                     "controls": ["NO_B", "early-only B", "late-only B", "broadcast B", "global induced-R0 sufficiency control"],
                     "predicted_outcomes": ["no effect", "local silent interference", "remote competence induction",
                                            "RAW-mediated", "clock-mediated", "distributed/history-mediated"],
                     "estimated_runtime_minutes": 7,
                     "stop_condition": "four exposure histories plus r0/r2/r6/global component tomography at tick704"},
        "design": {"A_tick": 128, "B_tick": 320, "late_C_tick": 704,
                   "late_phase_offset": cce28.PHASE_OFFSET, "diagnostic_only": True,
                   "B_marker_extinction_required": True, "X_FULL_transplantable": False},
        "stage_A": stage_a, "exposure_factorial": exposure,
        "tomography_selected_mode": selected, "tomography": tomography,
        "summary": {"unexposed_late_C2": no_b_c2,
                    "local_silent_exposure_closes_late_C2": local_silent,
                    "nonlocal_early_capture_closes_late_C2": nonlocal_silent,
                    "remote_early_experience_induces_late_C2": remote_induction,
                    "failing_exposure_modes": failing,
                    "induction_sufficient_component_domains": restoring,
                    "accessible_R0_induction_state_identified": bool(restoring),
                    "hidden_history_resolved": False,
                    "native_filter_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_REMOTE_COMPETENCE_INDUCTION" if remote_induction else ("DIAGNOSTIC_SILENT_INTERFERENCE_FACTORIZED" if no_b_c2 and failing else "UNRESOLVED_OR_CONTROL_FAILURE"),
        "claim_guard": "All B/C insertions and transplants are diagnostic. Remote induction means a prior experience changes later C2 availability in this apparatus; it is not itself native capture, function, renewal, a global field, or RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "stage_A", "exposure_factorial", "tomography")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
