#!/usr/bin/env python3
"""Causal/direct-path controls for CCE29 remote late-competence induction."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce02_competence_causal_test as cce02
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce23_developmental_support_substitution as cce23
import run_cce28_phase_stratified_broadcast_sequence as cce28
import run_cce29_silent_exposure_interference as cce29
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE30_REMOTE_COMPETENCE_INDUCTION_CONTROLS.json"
REPORT = ROOT / "ING03_REMOTE_COMPETENCE_INDUCTION_CONTROLS.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE29_SILENT_EXPOSURE_INTERFERENCE.json"
RETENTION = 64
MODES = ("SATURATED_A", "FRESH_EARLY", "LATE_LOCAL", "BROKEN_EARLY", "FRESH_EARLY_NO_PERIPHERY")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def set_empty(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def clear_node(world, node, n):
    positions = rca05.node_positions(node, n)
    for q in positions:
        set_empty(world, q)
    return positions


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in set(states)))


def install(world, meta, nodes, mode):
    a, early, late = nodes
    if mode == "SATURATED_A": target = a
    elif mode in ("FRESH_EARLY", "BROKEN_EARLY", "FRESH_EARLY_NO_PERIPHERY"): target = early
    else: target = late
    if mode == "BROKEN_EARLY":
        record = rca06.install_generator(world, meta, target, 12, True, 98100)
        markers = [98100, 98101]
    else:
        record = cce03.install(world, meta, target, "TWO_PARENT_D12", 320)
        markers = record["marker_states"]
    return target, record, markers


def response_assay(kernel, yes, no, node, markers):
    differences = []; marker_trace = []
    for _ in range(160):
        yes.tick(); no.tick()
        differences.append(r09.delta(yes, node) != r09.delta(no, node))
        marker_trace.append(marker_count(yes, markers))
    s1 = all(differences[-RETENTION:]); ended = not markers or all(value == 0 for value in marker_trace[-RETENTION:])
    probe = cce05.fingerprint_fast(kernel, yes, no, node, 480) if s1 and ended else {
        "probe_interaction_differs": False, "skipped": "C2 impossible because S1/episode criterion failed"}
    return {"S0": any(differences), "S1": s1, "episode_ended": ended,
            "first_difference_latency": next((i + 1 for i, value in enumerate(differences) if value), None),
            "probe": probe, "C2": bool(s1 and ended and probe["probe_interaction_differs"])}, marker_trace


def run_mode(kernel, base, meta, nodes, mode):
    yes, no = clone(kernel, base), clone(kernel, base)
    removed = []
    if mode == "FRESH_EARLY_NO_PERIPHERY":
        removed = clear_node(yes, nodes[1], meta["n"]); clear_node(no, nodes[1], meta["n"])
    target, record, markers = install(yes, meta, nodes, mode)
    capture, marker_trace = response_assay(kernel, yes, no, target, markers)
    at480_yes, at480_no = clone(kernel, yes), clone(kernel, no)
    cce28.advance((yes, no), 224)
    late_yes = cce23.c2_assay(kernel, yes, meta, nodes[2], 704, "SEM1_WRITER")
    late_no = cce23.c2_assay(kernel, no, meta, nodes[2], 704, "SEM1_WRITER")
    return {"mode": mode, "target_node_id": target["id"], "generator": record,
            "removed_periphery_positions": len(removed), "capture_at_target": capture,
            "episode_ended_last64": not markers or all(value == 0 for value in marker_trace[-RETENTION:]),
            "late_C2_event_history": late_yes, "late_C2_matched_no_event": late_no,
            "remote_induction": late_yes["C2"] and not late_no["C2"]}, at480_yes, at480_no


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes, stage_a = cce29.build_a_history(kernel)
    rows = []; at480 = {}
    for mode in MODES:
        row, yes480, no480 = run_mode(kernel, base, meta, nodes, mode)
        rows.append(row); at480[mode] = (yes480, no480)
        print(json.dumps({"mode": mode, "capture_C2": row["capture_at_target"]["C2"],
                          "late_event_C2": row["late_C2_event_history"]["C2"],
                          "late_control_C2": row["late_C2_matched_no_event"]["C2"],
                          "remote_induction": row["remote_induction"]}, sort_keys=True), flush=True)

    # Is the captured early region still causally necessary after its B episode?
    positive_yes, positive_no = at480["FRESH_EARLY"]
    necessity = []
    for radius in (0, 2, 6):
        positions = cce02.domain(nodes[1], meta["n"], radius)
        for component in ("RAW", "CLOCK", "R0"):
            equalized = cce02.transplant(kernel, positive_yes, positive_no, positions, component)
            cce28.advance((equalized,), 224)
            assay = cce23.c2_assay(kernel, equalized, meta, nodes[2], 704, "SEM1_WRITER")
            necessity.append({"scope": f"EARLY_R{radius}", "component": component,
                              "position_count": len(positions), "late_C2_after_equalization": assay,
                              "blocks_induction": not assay["C2"]})
            print(json.dumps({"necessity": f"EARLY_R{radius}", "component": component,
                              "late_C2": assay["C2"]}, sort_keys=True), flush=True)

    by = {row["mode"]: row for row in rows}
    fresh = by["FRESH_EARLY"]
    controls = {
        "saturated_A_does_not_induce": not by["SATURATED_A"]["remote_induction"],
        "local_late_contact_does_not_induce": not by["LATE_LOCAL"]["remote_induction"],
        "broken_generator_does_not_induce": not by["BROKEN_EARLY"]["remote_induction"],
        "no_periphery_excludes_direct_generator_path": not by["FRESH_EARLY_NO_PERIPHERY"]["remote_induction"],
        "fresh_early_capture_is_C2": fresh["capture_at_target"]["C2"],
        "fresh_early_event_induces_late_C2": fresh["remote_induction"],
    }
    controlled = all(controls.values())
    necessary = [{"scope": row["scope"], "component": row["component"]} for row in necessity if row["blocks_induction"]]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.remote_competence_induction_controls.v1",
        "question": "Does retained B capture in a fresh region, rather than direct generator traffic, cause the later distant C2 opportunity?",
        "planning": {"mechanism": "factor target competence and generator integrity, then equalize the captured early region after B",
                     "controls": ["saturated A target", "fresh early target", "late local target", "broken generator",
                                  "fresh target removed", "matched no-event histories"],
                     "predicted_outcomes": ["direct generator effect", "target-independent effect", "capture-dependent induction",
                                            "persistent early-region necessity", "distributed migration by t480"],
                     "estimated_runtime_minutes": 10,
                     "stop_condition": "five target/generator controls and r0/r2/r6 early-region component equalization"},
        "design": {"A_tick": 128, "B_tick": 320, "post_B_equalization_tick": 480, "late_C_tick": 704,
                   "diagnostic_only": True, "host_events": True, "X_FULL_accessible": False},
        "stage_A": stage_a, "factorial_rows": rows, "early_region_necessity": necessity,
        "summary": {"controls": controls,
                    "controlled_capture_dependent_remote_competence_induction": controlled,
                    "early_region_necessary_component_domains_at_t480": necessary,
                    "induction_distributed_beyond_early_r6_by_t480": controlled and not necessary,
                    "native_blind_environment_demonstrated": False,
                    "native_function_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_CONTROLLED_REMOTE_COMPETENCE_INDUCTION" if controlled else "BOUNDED_NULL_OR_DIRECT_PATH_UNRESOLVED",
        "claim_guard": "The experience and equalizations are host diagnostics. A controlled remote C2 induction is a causal organizational operation, not a field/wave claim, native environmental capture, native function, renewal, RW3 or RW4.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "stage_A", "factorial_rows", "early_region_necessity")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
