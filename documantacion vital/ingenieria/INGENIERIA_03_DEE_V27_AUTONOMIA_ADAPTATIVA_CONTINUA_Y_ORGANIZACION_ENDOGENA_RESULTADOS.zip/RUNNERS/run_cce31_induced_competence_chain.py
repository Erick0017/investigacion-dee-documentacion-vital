#!/usr/bin/env python3
"""Complete diagnostic A->B->C using capture-dependent remote competence induction."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_cce10_spatial_competence_ecology as cce10
import run_cce28_phase_stratified_broadcast_sequence as cce28


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE31_INDUCED_COMPETENCE_CHAIN.json"
REPORT = ROOT / "ING03_INDUCED_COMPETENCE_CHAIN.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE30_REMOTE_COMPETENCE_INDUCTION_CONTROLS.json"


def response_hash(kernel, world, node, tick):
    return cce28.response_hash(kernel, world, node, tick)


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = cce28.build(kernel); node_a, node_b, node_c = nodes
    cce28.advance((base,), 128)

    A, N, stage_a = cce10.experience_pair(kernel, base, meta, node_a, 128, "SEM1_WRITER")
    cce28.advance((A, N), 32)
    stage_a["response_class_t320"] = response_hash(kernel, A, node_a, 320) != response_hash(kernel, N, node_a, 320)

    AB, A_no_b, stage_b = cce28.broadcast_stage(kernel, A, meta, [node_b], 320, "TWO_PARENT_D12")
    stage_b["scope"] = "single fresh early region diagnostic"
    stage_b["B_response_class_t480"] = response_hash(kernel, AB, node_b, 480) != response_hash(kernel, A_no_b, node_b, 480)
    stage_b["old_A_response_preserved"] = response_hash(kernel, AB, node_a, 480) == response_hash(kernel, A_no_b, node_a, 480)

    cce28.advance((AB, A_no_b), 224)
    ABC, AB_no_c, stage_c = cce28.broadcast_stage(kernel, AB, meta, nodes, 704, "SEM1_WRITER")
    stage_c["organization_selected_nodes"] = [row["node_id"] for row in stage_c["node_results"] if row["C2"]]
    stage_c["old_A_response_preserved"] = response_hash(kernel, ABC, node_a, 864) == response_hash(kernel, AB_no_c, node_a, 864)
    stage_c["old_B_response_preserved"] = response_hash(kernel, ABC, node_b, 864) == response_hash(kernel, AB_no_c, node_b, 864)
    stage_c["C_response_class_t864"] = response_hash(kernel, ABC, node_c, 864) != response_hash(kernel, AB_no_c, node_c, 864)

    a_ok = stage_a["C2_response_class"] and stage_a["response_class_t320"]
    b_row = stage_b["node_results"][0]
    b_ok = b_row["C2"] and stage_b["B_response_class_t480"] and stage_b["old_A_response_preserved"]
    c_ok = (stage_c["organization_selected_nodes"] == [node_c["id"]]
            and stage_c["C_response_class_t864"]
            and stage_c["old_A_response_preserved"] and stage_c["old_B_response_preserved"])
    sequence = bool(a_ok and b_ok and c_ok)
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.induced_competence_chain.v1",
        "question": "Can captured B induce a new distant competence opportunity that then selectively captures broadcast C in the same world?",
        "planning": {"mechanism": "A commits node1; B capture in node2 induces phase16 node4; broadcast C challenges all three",
                     "controls": ["same-history no-event branch each stage", "finite marker extinction",
                                  "old A/B response preservation", "C broadcast without recipient choice"],
                     "predicted_outcomes": ["B fails", "B retained but no induction", "C captures induced node only", "history interference"],
                     "estimated_runtime_minutes": 4,
                     "stop_condition": "three retained response stages through tick864"},
        "design": {"continuous_world": True,
                   "events": [{"tick": 128, "scope": "localized_A_diagnostic", "mode": "SEM1_WRITER", "node": node_a["id"]},
                              {"tick": 320, "scope": "localized_B_diagnostic", "mode": "TWO_PARENT_D12", "node": node_b["id"]},
                              {"tick": 704, "scope": "all_regions_broadcast", "mode": "SEM1_WRITER"}],
                   "late_region": {"node": node_c["id"], "phase_offset": cce28.PHASE_OFFSET,
                                   "competence_source": "capture-dependent remote induction from B"},
                   "host_diagnostic_events": True, "native_environment": False,
                   "external_response_fingerprints": True, "preconditioned_regions": 3},
        "stage_A": stage_a, "stage_B": stage_b, "stage_C_broadcast": stage_c,
        "summary": {"A_retained_response": bool(a_ok), "B_retained_response": bool(b_ok),
                    "C_broadcast_selected_only_induced_region": bool(c_ok),
                    "diagnostic_A_B_C_induced_competence_chain": sequence,
                    "capture_dependent_remote_competence_induction_used": True,
                    "one_shot_region_consumption": True, "bounded_regions": 3,
                    "native_blind_environment_demonstrated": False,
                    "native_function_demonstrated": False,
                    "renewal_or_reuse_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "DIAGNOSTIC_THREE_EXPERIENCE_INDUCED_COMPETENCE" if sequence else "BOUNDED_NULL_OR_PARTIAL_CHAIN",
        "claim_guard": "A and B are localized host diagnostics and functions are response fingerprints. A positive chain establishes a causal developmental organization-selection mechanism, not promoted RW3, blind capture, native function or renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "stage_A", "stage_B", "stage_C_broadcast")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "C_selected": stage_c["organization_selected_nodes"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
