#!/usr/bin/env python3
"""Compose RCA06 all-t0 native B generation with remote competence induction."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce05_second_experience_causal_tomography as cce05
import run_cce23_developmental_support_substitution as cce23
import run_cce28_phase_stratified_broadcast_sequence as cce28
import run_cce30_remote_competence_induction_controls as cce30
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE32_NATIVE_B_INDUCED_COMPETENCE.json"
REPORT = ROOT / "ING03_NATIVE_B_INDUCED_COMPETENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE31_INDUCED_COMPETENCE_CHAIN.json"
RETENTION = 64
HORIZON = 704
MODES = ("INTACT", "BROKEN", "NO_EARLY_PERIPHERY")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in set(states)))


def configure(kernel, mode):
    treatment, meta, nodes = cce28.build(kernel)
    control, cmeta, cnodes = cce28.build(kernel)
    if mode == "NO_EARLY_PERIPHERY":
        cce30.clear_node(treatment, nodes[1], meta["n"])
        cce30.clear_node(control, cnodes[1], cmeta["n"])
    broken = mode == "BROKEN"
    generator = rca06.install_generator(treatment, meta, nodes[1], 12, broken, 99100)
    marker_states = [99100 + parent["parent_index"] for parent in generator["parents"]]
    return treatment, control, meta, nodes, generator, marker_states


def run_mode(kernel, mode):
    treatment, control, meta, nodes, generator, markers = configure(kernel, mode)
    early, late = nodes[1], nodes[2]
    early_diff = []; late_diff = []; pair_diff = []; core_diff = []; marker_trace = []
    checkpoints = []; snapshot480 = None
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        early_diff.append(r09.delta(treatment, early) != r09.delta(control, early))
        late_diff.append(r09.delta(treatment, late) != r09.delta(control, late))
        pair_diff.append(pair(treatment, meta) != pair(control, meta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, meta))
        marker_trace.append(marker_count(treatment, markers))
        if tick == 480:
            snapshot480 = (clone(kernel, treatment), clone(kernel, control))
        if tick in (1, 12, 38, 64, 128, 139, 140, 160, 256, 320, 480, 640, 704):
            checkpoints.append({"tick": tick, "early_difference": early_diff[-1],
                                "late_difference": late_diff[-1], "pair_difference": pair_diff[-1],
                                "core_difference": core_diff[-1],
                                "pair_treatment": pair(treatment, meta), "pair_control": pair(control, meta),
                                "core_treatment": delta_value(treatment, meta), "core_control": delta_value(control, meta),
                                "parent_marker_count": marker_trace[-1]})
    if snapshot480 is None:
        raise RuntimeError("missing tick480 snapshot")
    t480, c480 = snapshot480
    b_s1 = all(early_diff[480 - RETENTION:480])
    ended480 = all(value == 0 for value in marker_trace[480 - RETENTION:480])
    b_probe = cce05.fingerprint_fast(kernel, t480, c480, early, 480) if b_s1 and ended480 else {
        "probe_interaction_differs": False, "skipped": "B C2 impossible because S1/episode criterion failed"}
    b_c2 = bool(b_s1 and ended480 and b_probe["probe_interaction_differs"])
    late_t = cce23.c2_assay(kernel, treatment, meta, late, 704, "SEM1_WRITER")
    late_c = cce23.c2_assay(kernel, control, meta, late, 704, "SEM1_WRITER")
    first_early = next((i + 1 for i, value in enumerate(early_diff) if value), None)
    return {"mode": mode, "generator": generator,
            "python_after_t0_prefix": ["tick", "log", "checkpoint", "stop"],
            "function_A": {"tick": 38, "treatment_pair": checkpoints[2]["pair_treatment"],
                           "control_pair": checkpoints[2]["pair_control"],
                           "treatment_core": checkpoints[2]["core_treatment"],
                           "treatment_and_control_equal_through_38": not any(pair_diff[:38]) and not any(core_diff[:38])},
            "native_B": {"first_early_difference_tick": first_early,
                         "arises_after_function_A": first_early is not None and first_early > 38,
                         "S1_at_t480": b_s1, "parent_episode_ended_at_t480": ended480,
                         "diagnostic_probe": b_probe, "C2_response_class": b_c2},
            "late_competence": {"treatment": late_t, "matched_no_generator": late_c,
                                "native_B_induces_late_C2": late_t["C2"] and not late_c["C2"]},
            "checkpoints": checkpoints,
            "direct_pair_difference_before_B": any(pair_diff[:(first_early or 1) - 1]),
            "terminal_parent_marker_count": marker_trace[-1]}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    rows = []
    for mode in MODES:
        row = run_mode(kernel, mode); rows.append(row)
        print(json.dumps({"mode": mode, "first_B": row["native_B"]["first_early_difference_tick"],
                          "B_C2": row["native_B"]["C2_response_class"],
                          "late_treatment_C2": row["late_competence"]["treatment"]["C2"],
                          "late_control_C2": row["late_competence"]["matched_no_generator"]["C2"],
                          "induction": row["late_competence"]["native_B_induces_late_C2"]}, sort_keys=True), flush=True)
    by = {row["mode"]: row for row in rows}; intact = by["INTACT"]
    controls = {
        "function_A_precedes_native_B": intact["function_A"]["treatment_and_control_equal_through_38"]
            and intact["native_B"]["arises_after_function_A"],
        "intact_native_B_is_C2": intact["native_B"]["C2_response_class"],
        "intact_native_B_induces_late_C2": intact["late_competence"]["native_B_induces_late_C2"],
        "broken_generator_blocks_B_C2": not by["BROKEN"]["native_B"]["C2_response_class"],
        "broken_generator_blocks_induction": not by["BROKEN"]["late_competence"]["native_B_induces_late_C2"],
        "periphery_absence_blocks_B_C2": not by["NO_EARLY_PERIPHERY"]["native_B"]["C2_response_class"],
        "periphery_absence_blocks_induction": not by["NO_EARLY_PERIPHERY"]["late_competence"]["native_B_induces_late_C2"],
    }
    controlled = all(controls.values())
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.native_b_induced_competence.v1",
        "question": "Can an all-t0 native late B event be functionally captured and induce a new distant competence opportunity after Function A?",
        "planning": {"mechanism": "RCA06 distance12 two-parent generator aimed by relational geometry at the fresh early region",
                     "controls": ["broken first parent", "early periphery absent", "matched no-generator branch",
                                  "Function A precedence", "finite parent extinction"],
                     "predicted_outcomes": ["direct path", "native B without induction", "capture-dependent induction", "broken canary failure"],
                     "estimated_runtime_minutes": 8,
                     "stop_condition": "three paired all-t0 worlds through tick704 plus diagnostic B/C2 probes"},
        "design": {"environmental_parents_at_t0": True, "answer_carrier_at_t0": False,
                   "B_generator_distance": 12, "B_first_effect_expected": 140,
                   "late_phase_offset": cce28.PHASE_OFFSET, "promoted_prefix_python_after_t0": ["tick", "log", "checkpoint", "stop"],
                   "late_C_challenge_diagnostic": True, "environment_blind": False,
                   "recipient_geometry_used": True},
        "rows": rows,
        "summary": {"controls": controls,
                    "controlled_native_B_capture_induces_remote_competence": controlled,
                    "second_native_experience_operation_demonstrated": controlled,
                    "third_native_experience_demonstrated": False,
                    "native_blind_environment_demonstrated": False,
                    "native_function_C_demonstrated": False,
                    "rw3_demonstrated": False, "rw4_demonstrated": False},
        "status": "NATIVE_SECOND_EXPERIENCE_INDUCES_DIAGNOSTIC_COMPETENCE" if controlled else "BOUNDED_NULL_OR_CANARY_FAILURE",
        "claim_guard": "B is generated natively from frozen t0 parents, but its geometry references the recipient and C/function remain diagnostic. This is not blind environmental capture, a third native experience, RW3 or renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}], "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items() if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix(); report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
