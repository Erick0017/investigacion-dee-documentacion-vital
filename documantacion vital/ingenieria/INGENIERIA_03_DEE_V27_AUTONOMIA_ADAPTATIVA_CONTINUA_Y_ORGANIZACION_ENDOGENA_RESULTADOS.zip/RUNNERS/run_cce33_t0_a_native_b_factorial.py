#!/usr/bin/env python3
"""Factor an early finite A history against an all-t0 native late B generator.

This is a mechanism-discovery experiment.  Every main-world cause is installed
at t0; the later C2 assays are explicitly diagnostic and operate on clones.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_cce03_causal_response_fingerprint as cce03
import run_cce05_second_experience_causal_tomography as cce05
import run_cce23_developmental_support_substitution as cce23
import run_cce28_phase_stratified_broadcast_sequence as cce28
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r09_distributed_rotated_array as r09


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_CCE33_T0_A_NATIVE_B_FACTORIAL.json"
REPORT = ROOT / "ING03_T0_A_NATIVE_B_FACTORIAL.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_CCE32_NATIVE_B_INDUCED_COMPETENCE.json"
HORIZON = 1024
RETENTION = 64
CHECKPOINTS = (160, 320, 480, 704, 896, 1024)
A_MODES = ("SEM1_FINITE", "TWO_PARENT_D6")
WORLD_MODES = ("NONE", "A_ONLY", "B_ONLY", "A_PLUS_B")


def clone(kernel, source):
    return NativeWorld(kernel, source.raw, source.clock_a)


def marker_count(world, states):
    if not states:
        return 0
    values = world.raw & np.uint64(0xFFFFFFFF)
    return int(sum(np.count_nonzero(values == state) for state in set(states)))


def install_a(world, meta, node, mode):
    if mode == "SEM1_FINITE":
        record = cce03.install(world, meta, node, "SEM1_WRITER", 0)
        return record, record["marker_states"]
    record = rca06.install_generator(world, meta, node, 6, False, 100100)
    return {"mode": mode, "generator": record}, [100100, 100101]


def install_b(world, meta, node):
    record = rca06.install_generator(world, meta, node, 12, False, 100200)
    return record, [100200, 100201]


def build_world(kernel, a_mode, world_mode):
    world, meta, nodes = cce28.build(kernel)
    records = {}; markers = []
    if world_mode in ("A_ONLY", "A_PLUS_B"):
        records["A"], states = install_a(world, meta, nodes[0], a_mode); markers.extend(states)
    if world_mode in ("B_ONLY", "A_PLUS_B"):
        records["B"], states = install_b(world, meta, nodes[1]); markers.extend(states)
    return world, meta, nodes, records, markers


def retained(series, tick):
    return tick >= RETENTION and all(series[tick - RETENTION:tick])


def first_true(series):
    return next((index + 1 for index, value in enumerate(series) if value), None)


def c2_between(kernel, yes, no, node, tick, series):
    s1 = retained(series, tick)
    probe = cce05.fingerprint_fast(kernel, yes, no, node, tick) if s1 else {
        "probe_interaction_differs": False,
        "skipped": "S1 criterion failed at this checkpoint",
    }
    return {"tick": tick, "S1": s1, "probe": probe,
            "C2": bool(s1 and probe["probe_interaction_differs"])}


def run_family(kernel, a_mode):
    built = {mode: build_world(kernel, a_mode, mode) for mode in WORLD_MODES}
    worlds = {mode: built[mode][0] for mode in WORLD_MODES}
    meta = built["NONE"][1]; nodes = built["NONE"][2]
    records = {mode: built[mode][3] for mode in WORLD_MODES}
    markers = {mode: built[mode][4] for mode in WORLD_MODES}
    series = {
        "A_ISOLATED": [],
        "B_ISOLATED": [],
        "B_AFTER_A": [],
        "A_WITH_B": [],
    }
    marker_trace = {mode: [] for mode in WORLD_MODES}
    snapshots = {}
    raw_checkpoints = []
    for tick in range(1, HORIZON + 1):
        for world in worlds.values():
            world.tick()
        series["A_ISOLATED"].append(r09.delta(worlds["A_ONLY"], nodes[0]) !=
                                     r09.delta(worlds["NONE"], nodes[0]))
        series["B_ISOLATED"].append(r09.delta(worlds["B_ONLY"], nodes[1]) !=
                                     r09.delta(worlds["NONE"], nodes[1]))
        series["B_AFTER_A"].append(r09.delta(worlds["A_PLUS_B"], nodes[1]) !=
                                    r09.delta(worlds["A_ONLY"], nodes[1]))
        series["A_WITH_B"].append(r09.delta(worlds["A_PLUS_B"], nodes[0]) !=
                                   r09.delta(worlds["B_ONLY"], nodes[0]))
        for mode in WORLD_MODES:
            marker_trace[mode].append(marker_count(worlds[mode], markers[mode]))
        if tick in CHECKPOINTS:
            snapshots[tick] = {mode: clone(kernel, world) for mode, world in worlds.items()}
            raw_checkpoints.append({
                "tick": tick,
                "A_isolated": series["A_ISOLATED"][-1],
                "B_isolated": series["B_ISOLATED"][-1],
                "B_after_A": series["B_AFTER_A"][-1],
                "A_with_B": series["A_WITH_B"][-1],
                "markers": {mode: marker_trace[mode][-1] for mode in WORLD_MODES},
            })

    assays = []
    late_competence = []
    for tick in CHECKPOINTS:
        snap = snapshots[tick]
        assays.append({
            "tick": tick,
            "A_isolated": c2_between(kernel, snap["A_ONLY"], snap["NONE"],
                                      nodes[0], tick, series["A_ISOLATED"]),
            "B_isolated": c2_between(kernel, snap["B_ONLY"], snap["NONE"],
                                      nodes[1], tick, series["B_ISOLATED"]),
            "B_after_A": c2_between(kernel, snap["A_PLUS_B"], snap["A_ONLY"],
                                     nodes[1], tick, series["B_AFTER_A"]),
        })
        ab_late = cce23.c2_assay(kernel, snap["A_PLUS_B"], meta, nodes[2], tick, "SEM1_WRITER")
        a_late = cce23.c2_assay(kernel, snap["A_ONLY"], meta, nodes[2], tick, "SEM1_WRITER")
        b_late = cce23.c2_assay(kernel, snap["B_ONLY"], meta, nodes[2], tick, "SEM1_WRITER")
        none_late = cce23.c2_assay(kernel, snap["NONE"], meta, nodes[2], tick, "SEM1_WRITER")
        late_competence.append({
            "tick": tick,
            "A_PLUS_B": ab_late,
            "A_ONLY": a_late,
            "B_ONLY": b_late,
            "NONE": none_late,
            "B_under_A_induces_late_C2": bool(ab_late["C2"] and not a_late["C2"]),
            "requires_A_B_interaction": bool(ab_late["C2"] and not a_late["C2"] and
                                             not b_late["C2"] and not none_late["C2"]),
        })

    a_c2 = [row["tick"] for row in assays if row["A_isolated"]["C2"]]
    b_after_a_c2 = [row["tick"] for row in assays if row["B_after_A"]["C2"]]
    b_alone_c2 = [row["tick"] for row in assays if row["B_isolated"]["C2"]]
    induced = [row["tick"] for row in late_competence if row["B_under_A_induces_late_C2"]]
    interaction = [row["tick"] for row in late_competence if row["requires_A_B_interaction"]]
    ended = {mode: all(value == 0 for value in marker_trace[mode][-RETENTION:])
             for mode in WORLD_MODES}
    return {
        "A_mode": a_mode,
        "t0_records": records,
        "first_difference_ticks": {key: first_true(value) for key, value in series.items()},
        "episodes_ended_last64": ended,
        "C2_checkpoint_ticks": {"A_isolated": a_c2, "B_isolated": b_alone_c2,
                                "B_after_A": b_after_a_c2},
        "late_C2_induction_ticks": induced,
        "A_B_interaction_specific_induction_ticks": interaction,
        "assays": assays,
        "late_competence": late_competence,
        "checkpoints": raw_checkpoints,
        "python_after_t0_main_worlds": ["tick", "log", "checkpoint", "stop"],
        "diagnostic_clone_assays": True,
    }


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    if "--reanalyze" in sys.argv and OUTPUT.exists():
        existing = json.loads(OUTPUT.read_text(encoding="utf-8"))
        rows = existing["rows"]; runtime = existing["runtime"]
    else:
        kernel, runtime = load_kernel(1); rows = []
        for mode in A_MODES:
            row = run_family(kernel, mode); rows.append(row)
            print(json.dumps({"A_mode": mode,
                              "first": row["first_difference_ticks"],
                              "C2": row["C2_checkpoint_ticks"],
                              "induction": row["late_C2_induction_ticks"],
                              "interaction_specific": row["A_B_interaction_specific_induction_ticks"]},
                             sort_keys=True), flush=True)

    history_added_windows = {}
    history_removed_windows = {}
    for row in rows:
        conditioned = set(row["C2_checkpoint_ticks"]["B_after_A"])
        isolated = set(row["C2_checkpoint_ticks"]["B_isolated"])
        history_added_windows[row["A_mode"]] = sorted(conditioned - isolated)
        history_removed_windows[row["A_mode"]] = sorted(isolated - conditioned)
    history_conditions_b = [mode for mode, ticks in history_added_windows.items() if ticks]
    history_conditions_induction = [row["A_mode"] for row in rows
                                    if row["A_B_interaction_specific_induction_ticks"]]
    result = seal({
        "schema": "dee.v27.ing03.continuous_causal_ecology.t0_a_native_b_factorial.v1",
        "question": "Does an early finite A history make an all-t0 native later B generator become C2 and induce a later competence opportunity?",
        "planning": {
            "mechanism": "factor finite local A and native two-parent B in four all-t0 worlds",
            "controls": ["NONE", "A_ONLY", "B_ONLY", "A_PLUS_B",
                         "finite one-carrier A", "two-parent short-route A"],
            "predicted_outcomes": ["B timing alone", "A-conditioned B capture",
                                   "A+B-specific remote induction", "no retained capture"],
            "estimated_runtime_minutes": 12,
            "stop_condition": "two causally distinct A histories x four all-t0 worlds through tick1024 with frozen checkpoint assays",
        },
        "design": {
            "horizon": HORIZON,
            "A_causes_installed_at_t0": True,
            "B_parents_installed_at_t0": True,
            "B_answer_carrier_at_t0": False,
            "B_recipient_geometry_used": True,
            "environment_blind": False,
            "main_world_python_after_t0": ["tick", "log", "checkpoint", "stop"],
            "C2_and_late_competence_assays": "DIAGNOSTIC_INTERVENTION_ON_CLONES",
        },
        "rows": rows,
        "summary": {
            "A_history_conditions_native_B_C2_modes": history_conditions_b,
            "A_history_added_native_B_C2_windows": history_added_windows,
            "A_history_removed_native_B_C2_windows": history_removed_windows,
            "A_B_interaction_specific_remote_induction_modes": history_conditions_induction,
            "early_A_history_is_sufficient_context_for_native_B_C2": bool(history_conditions_b),
            "early_A_plus_native_B_induces_remote_competence": bool(history_conditions_induction),
            "second_native_experience_demonstrated": False,
            "native_blind_environment_demonstrated": False,
            "native_function_demonstrated": False,
            "rw3_demonstrated": False,
            "rw4_demonstrated": False,
        },
        "status": ("DIAGNOSTIC_ALL_T0_A_CONDITIONS_NATIVE_B_AND_REMOTE_COMPETENCE"
                   if history_conditions_b and history_conditions_induction else
                   "BOUNDED_NULL_OR_PARTIAL_ALL_T0_HISTORY_COMPOSITION"),
        "claim_guard": "The main worlds are all-t0 and contain no post-t0 Python intervention, but A is an initial finite apparatus, B geometry references node2, and C2/function assays are diagnostic. A positive result is a composition mechanism, not blind capture, promoted RW3, or renewal.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(),
                      "file_sha256": sha256_file(PRIOR),
                      "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    report = seal({k: v for k, v in result.items()
                   if k not in ("content_sha256", "created_utc", "rows")})
    report["source_evidence"] = OUTPUT.relative_to(ROOT).as_posix()
    report["source_file_sha256"] = sha256_file(OUTPUT)
    write_json(REPORT, report)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(),
                      "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
