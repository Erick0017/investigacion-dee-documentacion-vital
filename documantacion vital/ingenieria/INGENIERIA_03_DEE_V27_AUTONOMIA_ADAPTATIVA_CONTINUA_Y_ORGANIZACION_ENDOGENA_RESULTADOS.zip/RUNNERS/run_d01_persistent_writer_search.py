#!/usr/bin/env python3
"""Discovery: can a semantic4 source repeatedly write a scaffolded relative memory?"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, summarize, write_json

SUPPORT = ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap at {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def install(raw, clock, center, base, n):
    put(raw, clock, center, base, 100, semantic=1, phase=260)
    for i, offset in enumerate(SUPPORT):
        put(raw, clock, add(center, offset, 1, n), base + 100 + i, 0, semantic=4, phase=31 + i)


def rle(values):
    out = []
    start, previous = 1, values[0]
    for index, value in enumerate(values[1:], 2):
        if value != previous:
            out.append([start, index - 1, previous])
            start, previous = index, value
    out.append([start, len(values), previous])
    return out


def run(kernel, phase, source_sreg, distance, source_semantic=4, horizon=1024):
    n = 17
    a, b = (5, 8, 8), (12, 8, 8)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    install(raw, clock, a, 1000, n)
    install(raw, clock, b, 2000, n)
    event_site = add(a, (0, -1, 0), 1, n)
    direction = (0, 0, 1)
    source = add(event_site, direction, -distance, n)
    put(raw, clock, source, 5000, source_sreg, direction, source_semantic, phase)
    world = NativeWorld(kernel, raw, clock)
    source_raw = int(world.raw[source])
    deltas, supports, samples = [], [], []
    source_fixed = True
    for tick in range(1, horizon + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else ra["sreg"] - rb["sreg"]
        deltas.append(delta)
        supports.append(int(np.count_nonzero(world.raw)))
        source_fixed &= int(world.raw[source]) == source_raw
        if tick <= 8 or tick in {16, 32, 64, 128, 256, 512, 1024}:
            samples.append({"tick": tick, "a": ra, "b": rb, "delta": delta, "source": read(world.raw, source), "support": supports[-1]})
    segments = rle(deltas)
    changes = sum(deltas[i] != deltas[i - 1] for i in range(1, len(deltas)))
    distinct = sorted({d for d in deltas if d is not None})
    return {"phase": phase, "source_sreg": source_sreg, "distance": distance, "source_semantic": source_semantic, "horizon": horizon,
            "source_fixed": source_fixed, "delta_changes": changes, "distinct_deltas": distinct, "delta_rle": segments,
            "support_min": min(supports), "support_max": max(supports), "samples": samples,
            "terminal": summarize(world.raw, world.clock_a), "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    phases = [0, 1, 7, 17, 23, 31, 63, 127, 195, 259]
    for distance in (2, 3, 4):
        for sreg in (0, 3, 7):
            for phase in phases:
                rows.append(run(kernel, phase, sreg, distance))
    for semantic in (1,):
        rows.append(run(kernel, 23, 7, 2, semantic))
    candidates = [r for r in rows if r["source_fixed"] and len(r["distinct_deltas"]) >= 3 and r["delta_changes"] >= 2]
    result = seal({"schema": "dee.v27.ing03.discovery.persistent_writer_search.v1",
        "question": "Can a raw-invariant native source repeatedly rewrite a scaffolded relative memory without host reset?",
        "construction": "semantic4 source emits toward the event-neighbor port of memory A; matched B is the common-mode reference.",
        "rows": rows, "candidate_count": len(candidates),
        "candidate_keys": [{k: r[k] for k in ("phase", "source_sreg", "distance", "distinct_deltas", "delta_changes")} for r in candidates],
        "runtime": runtime})
    output = ROOT / "DISCOVERY/ING03_D01_PERSISTENT_WRITER_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "candidate_count": len(candidates), "candidates": result["candidate_keys"][:20], "hash": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
