#!/usr/bin/env python3
"""Causal isolation of the persistent-source recurrent relative-state writer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, summarize, write_json

SUPPORT = ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def install(raw, clock, center, base, n):
    put(raw, clock, center, base, 100, semantic=1, phase=260)
    for i, o in enumerate(SUPPORT): put(raw, clock, add(center, o, 1, n), base + 100 + i, 0, semantic=4, phase=31 + i)


def rle(values):
    out=[]; start=1; prev=values[0]
    for i,v in enumerate(values[1:],2):
        if v!=prev: out.append([start,i-1,prev]); start=i; prev=v
    out.append([start,len(values),prev]); return out


def run(kernel,n,mode,horizon=2048):
    a=(n//3,n//2,n//2); b=(2*n//3,n//2,n//2)
    raw=np.zeros((n,n,n),np.uint64); clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n); install(raw,clock,b,2000,n)
    direction=(0,0,1); sources=[]
    def source_for(center,state,semantic=4,d=(0,0,1)):
        event=add(center,(0,-1,0),1,n); q=add(event,d,-3,n)
        put(raw,clock,q,state,0,d,semantic,0); sources.append(q)
    if mode=="source_a": source_for(a,5000)
    elif mode=="source_b": source_for(b,6000)
    elif mode=="sources_both": source_for(a,5000); source_for(b,6000)
    elif mode=="source_a_away": source_for(a,5000,4,(0,0,-1))
    elif mode=="finite_a": source_for(a,5000,1)
    elif mode!="none": raise ValueError(mode)
    world=NativeWorld(kernel,raw,clock); initial_source=[int(world.raw[q]) for q in sources]
    ds=[]; av=[]; bv=[]; transition_rows=[]; previous=None; source_fixed=True
    for tick in range(1,horizon+1):
        world.tick(); ra,rb=read(world.raw,a),read(world.raw,b)
        delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        ds.append(delta); av.append(None if ra is None else ra["sreg"]); bv.append(None if rb is None else rb["sreg"])
        source_fixed &= all(int(world.raw[q])==v for q,v in zip(sources,initial_source))
        if delta!=previous:
            transition_rows.append({"tick":tick,"a":ra,"b":rb,"delta":delta,"clock_a":int(world.clock_a[a]),"clock_b":int(world.clock_a[b]),"support":int(np.count_nonzero(world.raw))})
            previous=delta
    return {"n":n,"mode":mode,"horizon":horizon,"source_fixed":source_fixed if sources else None,"delta_rle":rle(ds),"transitions":transition_rows,
        "a_sreg_rle":rle(av),"b_sreg_rle":rle(bv),"distinct_deltas":sorted({d for d in ds if d is not None}),
        "terminal":summarize(world.raw,world.clock_a),"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1); rows=[]
    for n in (17,23,29):
        for mode in ("none","source_a","source_b","sources_both","source_a_away","finite_a"):
            rows.append(run(kernel,n,mode))
    result=seal({"schema":"dee.v27.ing03.discovery.recurrent_writer_isolation.v1",
        "question":"Does persistent-source traffic causally and repeatedly rewrite one member of a relational memory, and does source target identity control sign?",
        "rows":rows,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D02_RECURRENT_WRITER_ISOLATION.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":[{"n":r["n"],"mode":r["mode"],"fixed":r["source_fixed"],"deltas":r["distinct_deltas"],"changes":len(r["delta_rle"])-1} for r in rows],"hash":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
