#!/usr/bin/env python3
"""Long-horizon law and capacity bounds for the native recurrent writer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,summarize,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n):
    put(raw,clock,c,base,100,semantic=1,phase=260)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def run(kernel,mode,horizon=16384,n=23):
    a=(n//3,n//2,n//2);b=(2*n//3,n//2,n//2);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n);install(raw,clock,b,2000,n);sources=[]
    def source(c,state):
        event=add(c,(0,-1,0),1,n);q=add(event,(0,0,1),-3,n);put(raw,clock,q,state,0,(0,0,1),4,0);sources.append(q)
    if mode in {"source_a","both"}:source(a,5000)
    if mode in {"source_b","both"}:source(b,6000)
    world=NativeWorld(kernel,raw,clock);initial=[int(world.raw[q]) for q in sources];prev=None;trans=[];source_fixed=True
    samples={1,64,256,1024,4096,8192,16384};telemetry=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        source_fixed &= all(int(world.raw[q])==v for q,v in zip(sources,initial))
        if delta!=prev:
            trans.append({"tick":tick,"a_sreg":None if ra is None else ra["sreg"],"b_sreg":None if rb is None else rb["sreg"],"delta":delta,"clock":None if ra is None else int(world.clock_a[a])});prev=delta
        if tick in samples:telemetry.append({"tick":tick,"a":ra,"b":rb,"delta":delta,"support":int(np.count_nonzero(world.raw))})
    intervals=[trans[i]["tick"]-trans[i-1]["tick"] for i in range(1,len(trans))]
    return {"mode":mode,"n":n,"horizon":horizon,"source_fixed":source_fixed if sources else None,"transitions":trans,"transition_intervals":intervals,
        "delta_min":min(t["delta"] for t in trans if t["delta"] is not None),"delta_max":max(t["delta"] for t in trans if t["delta"] is not None),
        "telemetry":telemetry,"terminal":summarize(world.raw,world.clock_a),"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,m) for m in ("none","source_a","source_b","both")]
    result=seal({"schema":"dee.v27.ing03.mechanism.recurrent_writer_scaling.v1","question":"How many native rewrites and how much relational range persist under fixed native writer resources?","rows":rows,"runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION/ING03_D03_RECURRENT_WRITER_SCALING.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":[{"mode":r["mode"],"transitions":len(r["transitions"])-1,"range":[r["delta_min"],r["delta_max"]],"fixed":r["source_fixed"]} for r in rows],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
