#!/usr/bin/env python3
"""Search for a native gate that controls a persistent recurrent writer."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))
GATE_SPECS=[
    {"semantic":1,"state":0,"sreg":0,"direction":(0,0,0)},
    {"semantic":1,"state":1,"sreg":0,"direction":(0,0,0)},
    {"semantic":1,"state":0,"sreg":7,"direction":(0,0,1)},
    {"semantic":1,"state":1,"sreg":7,"direction":(0,0,-1)},
    {"semantic":4,"state":7000,"sreg":0,"direction":(0,0,0)},
    {"semantic":4,"state":7001,"sreg":0,"direction":(0,0,1)},
]

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n):
    put(raw,clock,c,base,100,semantic=1,phase=260)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def run(kernel,gate_offset=None,gate_spec=None,horizon=1024):
    n=17;a=(5,8,8);b=(12,8,8);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n);install(raw,clock,b,2000,n)
    event=add(a,(0,-1,0),1,n);source=add(event,(0,0,1),-3,n);put(raw,clock,source,5000,0,(0,0,1),4,0)
    gate=None;gate0=None
    if gate_offset is not None:
        gate=add(event,gate_offset,1,n);spec=gate_spec;put(raw,clock,gate,spec["state"],spec["sreg"],spec["direction"],spec["semantic"],0);gate0=int(raw[gate])
    world=NativeWorld(kernel,raw,clock);deltas=[];gate_lifetime=None
    for tick in range(1,horizon+1):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);deltas.append(None if ra is None or rb is None else ra["sreg"]-rb["sreg"])
        if gate is not None and gate_lifetime is None and int(world.raw[gate])!=gate0:gate_lifetime=tick
    first_nonzero=next((i+1 for i,v in enumerate(deltas) if v not in (0,None)),None)
    return {"gate_offset":None if gate_offset is None else list(gate_offset),"gate_spec":gate_spec,"horizon":horizon,"first_nonzero_delta":first_nonzero,
        "delta_tick_600":deltas[599],"delta_terminal":deltas[-1],"distinct_deltas":sorted({v for v in deltas if v is not None}),"gate_first_change":gate_lifetime,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel)]
    offsets=[]
    for z in (-2,-1,0):
        offsets.extend([(0,0,z),(1,0,z),(-1,0,z),(0,1,z),(0,-1,z)])
    offsets=list(dict.fromkeys(offsets))
    for offset in offsets:
        for spec in GATE_SPECS:
            try:
                rows.append(run(kernel,offset,spec))
            except RuntimeError as exc:
                if "overlap" not in str(exc): raise
    base=rows[0];candidates=[r for r in rows[1:] if r["first_nonzero_delta"]!=base["first_nonzero_delta"] or r["delta_terminal"]!=base["delta_terminal"]]
    result=seal({"schema":"dee.v27.ing03.discovery.writer_gate_search.v1","question":"Can a local native component gate or delay the persistent recurrent writer?",
        "baseline":base,"rows":rows,"candidate_count":len(candidates),"candidates":candidates,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D04_WRITER_GATE_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"baseline":base,"candidate_count":len(candidates),"top":candidates[:20],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
