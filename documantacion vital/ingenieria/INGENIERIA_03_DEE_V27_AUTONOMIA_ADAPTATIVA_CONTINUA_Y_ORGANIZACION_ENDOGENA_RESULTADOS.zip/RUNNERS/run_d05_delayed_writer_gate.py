#!/usr/bin/env python3
"""Can a later native carrier reconfigure an already active recurrent writer?"""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n):
    put(raw,clock,c,base,100,semantic=1,phase=260)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def run(kernel,distance=None,state=None,approach=(1,0,0),horizon=2048):
    n=23;a=(7,11,11);b=(15,11,11);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n);install(raw,clock,b,2000,n)
    event=add(a,(0,-1,0),1,n);source=add(event,(0,0,1),-3,n);gate=add(event,(0,0,-2),1,n)
    put(raw,clock,source,5000,0,(0,0,1),4,0)
    carrier=None
    if distance is not None:
        carrier=add(gate,approach,-distance,n);put(raw,clock,carrier,state,0,approach,1,0)
    world=NativeWorld(kernel,raw,clock);ds=[];gate_hits=[];carrier0=None if carrier is None else int(world.raw[carrier])
    for tick in range(1,horizon+1):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);ds.append(None if ra is None or rb is None else ra["sreg"]-rb["sreg"])
        if int(world.raw[gate]):gate_hits.append({"tick":tick,"gate":read(world.raw,gate)})
    return {"distance":distance,"state":state,"approach":list(approach),"horizon":horizon,"delta_series":ds,"gate_hits":gate_hits,
        "initial_carrier_raw":carrier0,"python_interventions_after_t0":0}

def compress(row,baseline):
    ds=row.pop("delta_series");base=baseline["delta_series"]
    row["first_delta_divergence"]=next((i+1 for i,(a,b) in enumerate(zip(ds,base)) if a!=b),None)
    row["delta_samples"]={str(t):ds[t-1] for t in (1,64,128,256,512,1024,2048)}
    row["delta_min"]=min(v for v in ds if v is not None);row["delta_max"]=max(v for v in ds if v is not None)
    row["gate_hit_count"]=len(row["gate_hits"]);row["first_gate_hit"]=None if not row["gate_hits"] else row["gate_hits"][0]["tick"]
    return row

def main():
    kernel,runtime=load_kernel(1);baseline=run(kernel);rows=[]
    for approach in ((1,0,0),(-1,0,0),(0,-1,0)):
        for state in (0,1):
            for distance in range(1,9):
                try: rows.append(compress(run(kernel,distance,state,approach),baseline))
                except RuntimeError: pass
    base_comp=compress({k:v for k,v in baseline.items()},baseline)
    candidates=[r for r in rows if r["first_delta_divergence"] is not None and r["first_delta_divergence"]>1]
    result=seal({"schema":"dee.v27.ing03.discovery.delayed_writer_gate.v1","question":"Can a pre-existing native carrier later reach the writer interface and causally reconfigure its continuing trajectory?",
        "baseline":base_comp,"rows":rows,"candidates":candidates,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D05_DELAYED_WRITER_GATE.json";write_json(output,result)
    print(json.dumps({"output":str(output),"candidate_count":len(candidates),"top":candidates[:20],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
