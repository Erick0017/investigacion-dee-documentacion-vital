#!/usr/bin/env python3
"""Calibrate whether native carrier travel creates usable event-delay classes."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n):
    put(raw,clock,c,base,100,semantic=1,phase=260)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def run(kernel,distance,state,horizon=64):
    n=37;a=(10,18,18);b=(27,18,18);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n);install(raw,clock,b,2000,n)
    event=add(a,(0,-1,0),1,n);direction=(0,0,1);source=add(event,direction,-distance,n)
    put(raw,clock,source,state,0,direction,1,19)
    world=NativeWorld(kernel,raw,clock);trace=[];first=None
    for tick in range(1,horizon+1):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        if delta not in (0,None) and first is None:first=tick
        if tick<=12 or tick in (16,32,64):trace.append({"tick":tick,"delta":delta,"a":ra,"b":rb,"event_site":read(world.raw,event)})
    return {"distance":distance,"initial_state":state,"first_nonzero_delta":first,"trace":trace,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for state in (0,1):
        for distance in range(0,13):
            try:rows.append(run(kernel,distance,state))
            except RuntimeError:pass
    result=seal({"schema":"dee.v27.ing03.discovery.event_delay_calibration.v1","question":"Can carrier distance/state create multiple native experience-arrival classes without writing clock answers?","rows":rows,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D06_EVENT_DELAY_CALIBRATION.json";write_json(output,result)
    print(json.dumps({"output":str(output),"classes":[{"state":r["initial_state"],"distance":r["distance"],"first_delta":r["first_nonzero_delta"]} for r in rows],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
