#!/usr/bin/env python3
"""Search fixed native detector phases for multiple event-arrival time slots."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n,phase):
    put(raw,clock,c,base,100,semantic=1,phase=phase)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def run(kernel,phase,distance,state,horizon=32):
    n=17;a=(5,8,8);b=(12,8,8);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    install(raw,clock,a,1000,n,phase);install(raw,clock,b,2000,n,phase)
    event=add(a,(0,-1,0),1,n);direction=(0,0,1);source=add(event,direction,-distance,n);put(raw,clock,source,state,0,direction,1,19)
    world=NativeWorld(kernel,raw,clock);ds=[]
    for _ in range(horizon):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);ds.append(None if ra is None or rb is None else ra["sreg"]-rb["sreg"])
    return {"memory_phase":phase,"distance":distance,"state":state,"first_nonzero":next((i+1 for i,v in enumerate(ds) if v not in (0,None)),None),"terminal_delta":ds[-1],"delta_series":ds,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for phase in range(240,281):
        for distance in range(0,5):
            for state in (0,1):
                try:rows.append(run(kernel,phase,distance,state))
                except RuntimeError:pass
    effective=[r for r in rows if r["first_nonzero"] is not None]
    result=seal({"schema":"dee.v27.ing03.discovery.temporal_slot_search.v1","question":"Can fixed answer-independent DEE detector phases convert different carrier arrival histories into distinct relative writes?","rows":rows,"effective":effective,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D07_TEMPORAL_SLOT_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"effective_count":len(effective),"effective":[{k:r[k] for k in ("memory_phase","distance","state","first_nonzero","terminal_delta")} for r in effective],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
