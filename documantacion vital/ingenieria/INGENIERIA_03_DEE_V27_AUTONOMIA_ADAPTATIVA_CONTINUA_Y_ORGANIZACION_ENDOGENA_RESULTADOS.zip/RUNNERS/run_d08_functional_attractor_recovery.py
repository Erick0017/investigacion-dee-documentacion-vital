#!/usr/bin/env python3
"""Test basin-like recovery of a functional policy sign after direct perturbation."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

SUPPORT=((-1,0,0),(0,1,0),(0,0,1),(-1,1,1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install(raw,clock,c,base,n):
    put(raw,clock,c,base,100,semantic=1,phase=260)
    for i,o in enumerate(SUPPORT):put(raw,clock,add(c,o,1,n),base+100+i,0,semantic=4,phase=31+i)

def construct(kernel,n,mode):
    a=(n//3,n//2,n//2);b=(2*n//3,n//2,n//2);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);install(raw,clock,a,1000,n);install(raw,clock,b,2000,n);sources=[]
    def source(c,state):
        event=add(c,(0,-1,0),1,n);q=add(event,(0,0,1),-3,n);put(raw,clock,q,state,0,(0,0,1),4,0);sources.append(q)
    if mode in {"source_a","source_a_cut","both"}:source(a,5000)
    if mode in {"source_b","both"}:source(b,6000)
    return NativeWorld(kernel,raw,clock),a,b,sources

def sign(x):return 1 if x>0 else -1 if x<0 else 0

def run(kernel,n,mode,pre=2048,post=4096):
    world,a,b,sources=construct(kernel,n,mode)
    for _ in range(pre):world.tick()
    ra,rb=read(world.raw,a),read(world.raw,b);before=ra["sreg"]-rb["sreg"]
    target_sign=-1 if mode.startswith("source_a") else 1 if mode=="source_b" else 0
    # Direct host perturbation is a scientific challenge, not a claimed native event.
    if target_sign<0:new_a=rb["sreg"]+8;new_b=rb["sreg"]
    elif target_sign>0:new_a=ra["sreg"];new_b=ra["sreg"]+8
    else:new_a=ra["sreg"]+8;new_b=rb["sreg"]
    for q,old,new_sreg in ((a,ra,new_a),(b,rb,new_b)):
        value=pack(old["state"],new_sreg,tuple(old["direction"]),old["semantic"]);world.raw_a[q]=value;world.raw_b[q]=value
    if mode=="source_a_cut":
        for q in sources:world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
    perturbed=read(world.raw,a)["sreg"]-read(world.raw,b)["sreg"];first_return=None;trace=[]
    for tick in range(1,post+1):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        if target_sign and delta is not None and sign(delta)==target_sign and first_return is None:first_return=tick
        if tick<=4 or tick in (64,256,512,1024,2048,4096) or tick==first_return:trace.append({"post_tick":tick,"a":ra,"b":rb,"delta":delta})
    return {"n":n,"mode":mode,"pre_ticks":pre,"post_ticks":post,"target_functional_sign":target_sign,"delta_before_perturbation":before,"delta_immediately_after":perturbed,
        "first_functional_return":first_return,"trace":trace,"python_interventions_after_perturbation":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for n in (17,23,29):
        for mode in ("source_a","source_b","source_a_cut","none","both"):rows.append(run(kernel,n,mode))
    result=seal({"schema":"dee.v27.ing03.adversarial.functional_attractor_recovery.v1","question":"Does the recurrent writer create a basin that restores its configured functional sign after the learned coordinate is forcibly flipped?",
        "damage_role":"Python applies one declared direct perturbation after pre-evolution; all recovery thereafter must be native.","rows":rows,"runtime":runtime})
    output=ROOT/"ADVERSARIAL_CHALLENGE/ING03_D08_FUNCTIONAL_ATTRACTOR_RECOVERY.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":[{"n":r["n"],"mode":r["mode"],"before":r["delta_before_perturbation"],"after":r["delta_immediately_after"],"return":r["first_functional_return"]} for r in rows],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
