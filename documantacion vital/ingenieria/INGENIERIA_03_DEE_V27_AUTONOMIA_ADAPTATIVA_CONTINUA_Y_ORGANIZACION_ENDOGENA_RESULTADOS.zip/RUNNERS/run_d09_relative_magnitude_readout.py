#!/usr/bin/env python3
"""Enumerate the native reader response to multi-level relative memory magnitude."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PATTERN_A=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0))
PATTERN_B=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def run(kernel,delta,horizon=16):
    n=23;c=(11,11,11);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100+delta,(0,0,0),1,260);put(raw,clock,b,2000,100,(0,0,0),1,260)
    for i,o in enumerate(PATTERN_A):put(raw,clock,add(a,o,1,n),3000+i,0,(0,0,0),4,31+i)
    for i,o in enumerate(PATTERN_B):put(raw,clock,add(b,o,1,n),4000+i,0,(0,0,0),4,41+i)
    source=add(c,(0,-2,0),1,n);put(raw,clock,source,6000,7,(0,1,0),4,23)
    world=NativeWorld(kernel,raw,clock);trace=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c)
        trace.append({"tick":tick,"delta":None if ra is None or rb is None else ra["sreg"]-rb["sreg"],"comparator":rc})
    signature=[None if r["comparator"] is None else (r["comparator"]["state"],r["comparator"]["sreg"],tuple(r["comparator"]["direction"]),r["comparator"]["semantic"]) for r in trace]
    return {"initial_delta":delta,"trace":trace,"signature":signature,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,d) for d in range(-16,17)];classes={}
    for r in rows:
        key=json.dumps(r["signature"]);classes.setdefault(key,[]).append(r["initial_delta"])
    result=seal({"schema":"dee.v27.ing03.discovery.relative_magnitude_readout.v1","question":"Does the native relational reader expose magnitude or only sign/zero?","rows":rows,
        "equivalence_classes":list(classes.values()),"class_count":len(classes),"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D09_RELATIVE_MAGNITUDE_READOUT.json";write_json(output,result)
    print(json.dumps({"output":str(output),"class_count":len(classes),"classes":list(classes.values()),"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
