#!/usr/bin/env python3
"""Integrate recurrent native writing with multi-class relational readout."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def construct(kernel,mode,n=23):
    c=(n//2,)*3;a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    event=add(b,(0,-1,0),1,n);writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,5000,0,(0,0,1),4,0)
    reader=add(c,(0,-2,0),1,n)
    if mode=="reader":put(raw,clock,reader,6000,7,(0,1,0),4,23)
    elif mode=="finite_reader":put(raw,clock,reader,6000,7,(0,1,0),1,23)
    elif mode!="no_reader":raise ValueError(mode)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"writer":writer,"reader":reader}

def classify(comp):
    if comp is None:return None
    return [comp["state"],comp["sreg"],comp["direction"],comp["semantic"]]

def run(kernel,mode,horizon=4096):
    world,p=construct(kernel,mode);trans=[];prev_delta=None;prev_sig=None;writer0=int(world.raw[p["writer"]]);reader0=int(world.raw[p["reader"]]);samples=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=(read(world.raw,p[k]) for k in ("a","b","c"));delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"];sig=classify(rc)
        if delta!=prev_delta or sig!=prev_sig:
            if len(trans)<500:trans.append({"tick":tick,"delta":delta,"comparator":rc})
            prev_delta,prev_sig=delta,sig
        if tick in (1,64,256,512,1024,2048,4096):samples.append({"tick":tick,"delta":delta,"comparator":rc,"support":int(np.count_nonzero(world.raw))})
    return {"mode":mode,"horizon":horizon,"writer_raw_fixed":int(world.raw[p["writer"]])==writer0,"reader_raw_fixed":None if mode=="no_reader" else int(world.raw[p["reader"]])==reader0,
        "transitions":trans,"samples":samples,"terminal_delta":samples[-1]["delta"],"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,m) for m in ("no_reader","reader","finite_reader")]
    result=seal({"schema":"dee.v27.ing03.discovery.recurrent_counter_readout.v1","question":"Can one organization repeatedly write a relational counter and natively expose magnitude classes while maintaining its reader?","rows":rows,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D10_RECURRENT_COUNTER_READOUT.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":[{"mode":r["mode"],"writer_fixed":r["writer_raw_fixed"],"reader_fixed":r["reader_raw_fixed"],"terminal_delta":r["terminal_delta"],"transitions":len(r["transitions"])} for r in rows],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
