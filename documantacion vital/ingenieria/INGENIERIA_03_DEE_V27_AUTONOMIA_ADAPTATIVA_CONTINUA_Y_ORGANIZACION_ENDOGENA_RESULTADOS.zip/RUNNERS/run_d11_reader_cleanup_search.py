#!/usr/bin/env python3
"""Search a native cleanup interaction that permits recurrent write/read cycles."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))
AXES=((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def construct(kernel,clean_dir,clean_distance,clean_sreg,reader=True,n=23):
    c=(n//2,)*3;a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    event=add(b,(0,-1,0),1,n);writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,5000,0,(0,0,1),4,0)
    reader_q=add(c,(0,-2,0),1,n)
    if reader:put(raw,clock,reader_q,6000,7,(0,1,0),4,23)
    cleaner=add(c,clean_dir,-clean_distance,n);put(raw,clock,cleaner,7000,clean_sreg,clean_dir,4,0)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"writer":writer,"reader":reader_q,"cleaner":cleaner}

def sgn(x):return None if x is None else 1 if x>0 else -1 if x<0 else 0

def run(kernel,direction,distance,sreg,reader=True,horizon=2048):
    try:world,p=construct(kernel,direction,distance,sreg,reader)
    except RuntimeError:return None
    fixed={k:int(world.raw[p[k]]) for k in ("writer","cleaner")};
    if reader:fixed["reader"]=int(world.raw[p["reader"]])
    ds=[];cs=[];support=[];samples=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=(read(world.raw,p[k]) for k in ("a","b","c"));delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        ds.append(delta);cs.append(None if rc is None else tuple(rc["direction"]));support.append(int(np.count_nonzero(world.raw)))
        if tick<=8 or tick in (16,32,64,128,256,512,1024,2048):samples.append({"tick":tick,"delta":delta,"comparator":rc,"support":support[-1]})
    delta_trans=sum(ds[i]!=ds[i-1] for i in range(1,len(ds)));comp_trans=sum(cs[i]!=cs[i-1] for i in range(1,len(cs)))
    nonzero=sum(v not in (None,(0,0,0)) for v in cs)
    return {"clean_direction":list(direction),"clean_distance":distance,"clean_sreg":sreg,"reader":reader,"horizon":horizon,
        "sources_fixed":all(int(world.raw[p[k]])==v for k,v in fixed.items()),"delta_transitions":delta_trans,"distinct_deltas":sorted({v for v in ds if v is not None}),
        "comparator_transitions":comp_trans,"nonzero_comparator_ticks":nonzero,"support_max":max(support),"samples":samples,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for d in AXES:
        for distance in (2,3):
            for sreg in (0,7):
                r=run(kernel,d,distance,sreg,True)
                if r:rows.append(r)
    candidates=[r for r in rows if r["sources_fixed"] and r["delta_transitions"]>=4 and r["comparator_transitions"]>=4 and r["nonzero_comparator_ticks"]>=4 and r["support_max"]<200]
    result=seal({"schema":"dee.v27.ing03.discovery.reader_cleanup_search.v1","question":"Can a second native persistent interaction remove/recycle the occupied comparator so recurrent writing and repeated readout coexist?","rows":rows,"candidates":candidates,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D11_READER_CLEANUP_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"candidate_count":len(candidates),"candidates":candidates,"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
