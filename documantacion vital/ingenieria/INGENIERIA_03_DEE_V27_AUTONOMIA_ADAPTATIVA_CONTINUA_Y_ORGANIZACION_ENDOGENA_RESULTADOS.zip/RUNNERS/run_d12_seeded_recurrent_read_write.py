#!/usr/bin/env python3
"""Test whether an experience-seeded nonzero regime permits recurrent write and read to coexist."""
from __future__ import annotations

import json,sys
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def construct(kernel,sign,reader,writer, n=23):
    c=(n//2,)*3;a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    # zero-payload experience writes sign at tick 1
    if sign>0:put(raw,clock,add(a,(0,-1,0),1,n),5001,0,(0,0,-1),1,17)
    elif sign<0:put(raw,clock,add(b,(0,1,0),1,n),5002,0,(0,0,1),1,17)
    if writer:
        target=b if writer>0 else a;event=add(target,(0,-1,0),1,n);q=add(event,(0,0,1),-3,n);put(raw,clock,q,6000+writer,0,(0,0,1),4,0)
    if reader:put(raw,clock,add(c,(0,-2,0),1,n),7000,7,(0,1,0),4,23)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c}

def run(kernel,sign,reader,writer,horizon=4096):
    world,p=construct(kernel,sign,reader,writer);ds=[];dirs=[];samples=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=(read(world.raw,p[k]) for k in ("a","b","c"));delta=None if ra is None or rb is None else ra["sreg"]-rb["sreg"];direction=None if rc is None else tuple(rc["direction"])
        ds.append(delta);dirs.append(direction)
        if tick<=8 or tick in (16,32,64,128,256,512,1024,2048,4096):samples.append({"tick":tick,"delta":delta,"comparator":rc,"support":int(np.count_nonzero(world.raw))})
    return {"experience_sign":sign,"reader":reader,"writer_sign":writer,"horizon":horizon,"delta_transitions":sum(ds[i]!=ds[i-1] for i in range(1,len(ds))),
        "distinct_deltas":sorted({v for v in ds if v is not None}),"direction_transitions":sum(dirs[i]!=dirs[i-1] for i in range(1,len(dirs))),
        "nonzero_direction_ticks":sum(v not in (None,(0,0,0)) for v in dirs),"samples":samples,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for sign in (-1,1):
        for reader in (False,True):
            for writer in (-1,0,1):rows.append(run(kernel,sign,reader,writer))
    result=seal({"schema":"dee.v27.ing03.discovery.seeded_recurrent_read_write.v1","question":"Does a natively experience-seeded nonzero relational regime allow persistent reader traffic and recurrent writer traffic to coexist?","rows":rows,"runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_D12_SEEDED_RECURRENT_READ_WRITE.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":[{k:r[k] for k in ("experience_sign","reader","writer_sign","delta_transitions","distinct_deltas","direction_transitions","nonzero_direction_ticks")} for r in rows],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
