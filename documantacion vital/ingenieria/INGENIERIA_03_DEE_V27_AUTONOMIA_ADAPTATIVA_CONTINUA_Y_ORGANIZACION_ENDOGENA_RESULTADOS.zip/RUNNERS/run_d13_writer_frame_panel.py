#!/usr/bin/env python3
"""Model-selection covariance panel for recurrent relational writer."""
from __future__ import annotations

import itertools,json,sys
from pathlib import Path

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import ROOT,load_kernel,seal,write_json
from recurrent_writer_apparatus_v1 import EXPECTED_2048,run_writer_case

def frames():
    for p in itertools.permutations((0,1,2)):
        for s in itertools.product((-1,1),repeat=3):yield p,s

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for i,(p,s) in enumerate(frames()):
        for mode in ("source_a","source_b","both","none"):
            spec={"case_id":f"F{i:02d}_{mode}","n":17,"origin":[8,8,8],"permutation":list(p),"signs":list(s),"mode":mode,"horizon":2048}
            out=run_writer_case(kernel,spec);terminal=out["trace"][-1]["delta"];out["expected_terminal"]=EXPECTED_2048[mode];out["exact"]=terminal==EXPECTED_2048[mode] and out["source_raw_fixed"] is not False;rows.append(out)
    result=seal({"schema":"dee.v27.ing03.model_selection.writer_frame_panel.v1","question":"Is the recurrent relational writer covariant across every signed/permuted local frame?","rows":rows,"summary":{"worlds":len(rows),"exact":sum(r["exact"] for r in rows)},"runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION/ING03_D13_WRITER_FRAME_PANEL.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
