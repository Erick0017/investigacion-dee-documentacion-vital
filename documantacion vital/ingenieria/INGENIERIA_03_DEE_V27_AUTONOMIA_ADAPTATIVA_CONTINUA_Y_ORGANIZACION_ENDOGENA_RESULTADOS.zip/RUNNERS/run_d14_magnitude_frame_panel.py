#!/usr/bin/env python3
"""All-frame model selection for five-class relational magnitude reader."""
from __future__ import annotations

import itertools,json,sys
from pathlib import Path

HERE=Path(__file__).resolve().parent;sys.path.insert(0,str(HERE))
from ing03_common import ROOT,load_kernel,seal,write_json
from relative_magnitude_reader_v1 import run_case

def frames():
    for p in itertools.permutations((0,1,2)):
        for s in itertools.product((-1,1),repeat=3):yield p,s

def main():
    kernel,runtime=load_kernel(1);rows=[];representatives={}
    for i,(p,s) in enumerate(frames()):
        for d in (-3,0,3,7,10):
            spec={"case_id":f"M{i:02d}_{d}","n":23,"origin":[11,11,11],"permutation":list(p),"signs":list(s),"delta":d}
            out=run_case(kernel,spec);key=out["expected_class"];representatives.setdefault(key,out["signature"]);out["exact"]=out["signature"]==representatives[key];rows.append(out)
    result=seal({"schema":"dee.v27.ing03.model_selection.magnitude_frame_panel.v1","question":"Are five relational-magnitude response classes invariant across all signed/permuted frames?","representative_signatures":representatives,"rows":rows,"summary":{"worlds":len(rows),"exact":sum(r["exact"] for r in rows)},"runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION/ING03_D14_MAGNITUDE_FRAME_PANEL.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"classes":list(representatives),"hash":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
