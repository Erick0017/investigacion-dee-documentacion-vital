#!/usr/bin/env python3
"""Test whether one recurrent writer stream can serve two relational memories."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json

SUPPORT = ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap at {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def pair(raw, clock, origin, base, n):
    da = n // 2 - n // 3; db = 2 * n // 3 - n // 2
    a = add(origin, (1, 0, 0), -da, n); b = add(origin, (1, 0, 0), db, n)
    for center, local in ((a, base), (b, base + 1000)):
        put(raw, clock, center, local, 100, semantic=1, phase=260)
        for i, off in enumerate(SUPPORT):
            put(raw, clock, add(center, off, 1, n), local + 100 + i, 0, semantic=4, phase=31 + i)
    return a, b


def delta(raw, ab):
    a, b = read(raw, ab[0]), read(raw, ab[1])
    return None if a is None or b is None else a["sreg"] - b["sreg"]


def run_case(kernel, separation, layout):
    n = 41; c1 = (20, 20, 8); c2 = (20, 20, 8 + separation)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    pairs = [pair(raw, clock, c1, 1000, n), pair(raw, clock, c2, 4000, n)]
    sources = []
    def source_for(center_a, state):
        event = add(center_a, (0, -1, 0), 1, n); q = add(event, (0, 0, 1), -3, n)
        put(raw, clock, q, state, 0, (0, 0, 1), 4, 0); sources.append(q)
    if layout == "shared_upstream_a":
        source_for(pairs[0][0], 8000)
    elif layout == "independent_a":
        source_for(pairs[0][0], 8000); source_for(pairs[1][0], 9000)
    elif layout == "shared_upstream_b":
        source_for(pairs[0][1], 8000)
    elif layout != "none":
        raise ValueError(layout)
    world = NativeWorld(kernel, raw, clock); trace = []
    for tick in range(1, 2049):
        world.tick()
        if tick in (1, 131, 326, 521, 716, 911, 1024, 1301, 1496, 1691, 1886, 2048):
            trace.append({"tick": tick, "deltas": [delta(world.raw, ab) for ab in pairs], "support": int(np.count_nonzero(world.raw))})
    return {"separation": separation, "layout": layout, "trace": trace, "terminal_deltas": [delta(world.raw, ab) for ab in pairs], "source_raw_fixed": all(int(world.raw[q]) == int(raw[q]) for q in sources), "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1); rows = []
    for separation in (4, 6, 8, 10, 12):
        for layout in ("none", "shared_upstream_a", "shared_upstream_b", "independent_a"):
            try:
                rows.append(run_case(kernel, separation, layout))
            except RuntimeError as exc:
                rows.append({"separation": separation, "layout": layout, "construction_valid": False, "reason": str(exc)})
    valid = [r for r in rows if "terminal_deltas" in r]
    result = seal({
        "schema": "dee.v27.ing03.discovery.shared_writer_interference.v1",
        "question": "Can shared recurrent streams write two memories, and how does configured sharing change interference?",
        "rows": rows,
        "summary": {
            "attempted": len(rows),
            "valid": len(valid),
            "shared_a_both_written": sum(r["layout"] == "shared_upstream_a" and all(d < 0 for d in r["terminal_deltas"]) for r in valid),
            "shared_b_both_written": sum(r["layout"] == "shared_upstream_b" and all(d > 0 for d in r["terminal_deltas"]) for r in valid),
            "independent_a_both_written": sum(r["layout"] == "independent_a" and all(d < 0 for d in r["terminal_deltas"]) for r in valid),
        },
        "interpretation_guard": "Configured shared routing is not endogenous allocation or interference avoidance.",
        "runtime": runtime,
    })
    out = ROOT / "DISCOVERY/ING03_D15_SHARED_WRITER_INTERFERENCE.json"
    write_json(out, result)
    print(json.dumps({"output": str(out), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
