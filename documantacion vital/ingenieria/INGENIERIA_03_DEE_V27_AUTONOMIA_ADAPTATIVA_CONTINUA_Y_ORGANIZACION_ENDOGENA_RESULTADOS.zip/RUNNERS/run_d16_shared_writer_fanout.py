#!/usr/bin/env python3
"""Bound the configured fan-out of one recurrent writer stream."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, read, seal, write_json
from run_d15_shared_writer_interference import delta, pair, put


def run_case(kernel, memory_count):
    n = 41; raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw); pairs = []
    for i in range(memory_count):
        pairs.append(pair(raw, clock, (20, 20, 4 + 4 * i), 1000 + 3000 * i, n))
    event = add(pairs[0][0], (0, -1, 0), 1, n); source = add(event, (0, 0, 1), -3, n)
    put(raw, clock, source, 900000, 0, (0, 0, 1), 4, 0)
    world = NativeWorld(kernel, raw, clock); source0 = int(raw[source]); trace = []
    for tick in range(1, 2049):
        world.tick()
        if tick in (1, 131, 326, 521, 716, 911, 1024, 1301, 1496, 1691, 1886, 2048):
            trace.append({"tick": tick, "deltas": [delta(world.raw, ab) for ab in pairs]})
    terminal = [delta(world.raw, ab) for ab in pairs]
    return {"memory_count": memory_count, "terminal_deltas": terminal, "all_exact_negative_eight": terminal == [-8] * memory_count, "source_raw_fixed": int(world.raw[source]) == source0, "trace": trace, "resource_accounting": {"persistent_sources": 1, "relational_memories": memory_count, "support_voxels_per_memory": 10}, "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1); rows = [run_case(kernel, k) for k in (1, 2, 4, 8)]
    result = seal({
        "schema": "dee.v27.ing03.model_selection.shared_writer_fanout.v1",
        "question": "How many configured relational memories can one persistent writer stream update exactly?",
        "rows": rows,
        "summary": {"tested_max_memories": 8, "exact_cases": sum(r["all_exact_negative_eight"] for r in rows), "cases": len(rows), "source_count": 1},
        "scope": "Lower bound for configured aligned fan-out; not endogenous allocation and not a maximum.",
        "runtime": runtime,
    })
    out = ROOT / "MECHANISM_SELECTION/ING03_D16_SHARED_WRITER_FANOUT.json"
    write_json(out, result)
    print(json.dumps({"output": str(out), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
