#!/usr/bin/env python3
"""Post-establishment dependency map for the C13 remote fixed point.

All removals are explicit DIAGNOSTIC_INTERVENTION branches.  They test whether
the already selected remote state needs continuing master/bridge/receiver drive;
they do not claim native decoupling.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value

ESTABLISH_TICK = 512
FOLLOWUP = 1024
CHECKPOINTS = (0, 1, 2, 4, 8, 16, 64, 256, 1024)


def clear(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def delayed_source_positions(meta):
    c, n = meta["c"], meta["n"]; qp = add(c, P, 1, n)
    return [add(qp, S1, -24, n), add(qp, S2, -24, n),
            add(c, N1, -24, n), add(c, N2, -24, n)]


def receiver_source_positions(meta):
    q, n = meta["q_receiver"], meta["n"]; qp = add(q, P, 1, n)
    return [add(qp, S1, -1, n), add(qp, S2, -1, n),
            add(q, N1, -2, n), add(q, N2, -2, n)]


def pair(world, meta):
    return [int(world.raw[meta["q_receiver"]]), int(world.raw[meta["qp_receiver"]])]


def pair_sha(value):
    h = hashlib.sha256()
    for raw in value: h.update(int(raw).to_bytes(8, "little"))
    return h.hexdigest()


def intervene(world, meta, mode):
    groups = {
        "master": [meta["a"], meta["b"]],
        "bridge_sources": delayed_source_positions(meta),
        "bridge_necessary_subset": [delayed_source_positions(meta)[i] for i in (0, 1, 3)],
        "master_interface": [meta["c"]],
        "receiver_drive_sources": receiver_source_positions(meta),
        "receiver_pair": [meta["q_receiver"], meta["qp_receiver"]],
        "generator": list(meta.get("generator_positions", [])),
    }
    if mode == "intact": positions = []
    elif mode == "master_and_bridge": positions = groups["master"] + groups["bridge_sources"]
    elif mode == "bridge_and_interface": positions = groups["bridge_sources"] + groups["master_interface"]
    else: positions = groups[mode]
    before = [{"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q])} for q in positions]
    for q in positions: clear(world, q)
    return {"type": "DIAGNOSTIC_INTERVENTION", "mode": mode, "positions": before}


def run(kernel, target, mode):
    world, meta = build(kernel, target)
    trajectory = []
    for tick in range(1, ESTABLISH_TICK + 1):
        world.tick()
    pre_pair = pair(world, meta); pre_delta = delta_value(world, meta)
    record = intervene(world, meta, mode)
    trajectory.append({"dt": 0, "tick": ESTABLISH_TICK, "pair": pair(world, meta),
                       "master_delta": delta_value(world, meta)})
    for dt in range(1, FOLLOWUP + 1):
        world.tick()
        if dt in CHECKPOINTS:
            trajectory.append({"dt": dt, "tick": ESTABLISH_TICK + dt,
                               "pair": pair(world, meta), "master_delta": delta_value(world, meta)})
    post_pairs = [row["pair"] for row in trajectory if row["dt"] > 0]
    exact_all = bool(post_pairs) and all(value == pre_pair for value in post_pairs)
    terminal = pair(world, meta)
    receiver_sources_fixed = [int(world.raw[q]) for q in receiver_source_positions(meta)]
    return {
        "target": target, "mode": mode, "establish_tick": ESTABLISH_TICK,
        "pre_intervention_pair": pre_pair, "pre_pair_sha256": pair_sha(pre_pair),
        "pre_intervention_delta": pre_delta, "intervention": record,
        "trajectory": trajectory, "terminal_pair": terminal,
        "terminal_pair_sha256": pair_sha(terminal),
        "sampled_pair_exactly_held": exact_all,
        "terminal_equals_pre": terminal == pre_pair,
        "receiver_drive_terminal_raw": receiver_sources_fixed,
        "python_interventions_after_t0": 0 if mode == "intact" else 1,
        "claim_guard": "Diagnostic post-establishment removal; not native decoupling."
    }


def main():
    kernel, runtime = load_kernel(1)
    modes = ("intact", "generator", "master", "bridge_sources", "bridge_necessary_subset",
             "master_interface", "master_and_bridge", "bridge_and_interface",
             "receiver_drive_sources", "receiver_pair")
    rows = [run(kernel, target, mode) for target in ("a", "b") for mode in modes]
    by = {(row["target"], row["mode"]): row for row in rows}
    persistence = {mode: all(by[(target, mode)]["terminal_equals_pre"] for target in ("a", "b"))
                   for mode in modes}
    result = seal({
        "schema": "dee.v27.ing03.delegation.remote_dependency_map.v1",
        "question": "After C13 has selected a remote fixed point, which ongoing components are necessary for its maintenance?",
        "design": {"native_establishment_through_tick": ESTABLISH_TICK,
                   "diagnostic_cut_after_establishment": True,
                   "followup_ticks": FOLLOWUP, "checkpoints_dt": list(CHECKPOINTS),
                   "targets": ["a", "b"], "modes": list(modes)},
        "rows": rows,
        "summary": {"both_targets_terminal_persistence_by_mode": persistence,
                    "master_cut_remote_persists": persistence["master"],
                    "bridge_cut_remote_persists": persistence["bridge_sources"],
                    "master_and_bridge_cut_remote_persists": persistence["master_and_bridge"],
                    "receiver_drive_cut_remote_persists": persistence["receiver_drive_sources"],
                    "receiver_pair_cut_recovers_pre_state": persistence["receiver_pair"]},
        "classification_rule": {
            "SELF_MAINTAINED": "persists after master, bridge, and receiver drive removal",
            "RECEIVER_DRIVE_MAINTAINED": "persists after master/bridge removal but not receiver drive removal",
            "BRIDGE_DEPENDENT": "fails after bridge removal",
            "MASTER_DEPENDENT": "fails after master removal"
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R01_REMOTE_DEPENDENCY_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
