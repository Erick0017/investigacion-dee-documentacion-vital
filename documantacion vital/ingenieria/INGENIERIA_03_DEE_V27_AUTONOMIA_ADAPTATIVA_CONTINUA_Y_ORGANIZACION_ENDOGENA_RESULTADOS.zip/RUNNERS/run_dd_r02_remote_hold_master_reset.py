#!/usr/bin/env python3
"""Does diagnostic decoupling reopen the master while the C13 latch holds?"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_rw3_r03_recurrent_writer_blocker_control import persistent_writer_spec
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import delayed_source_positions, pair

CUT_TICK = 512
HORIZON = 1024


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def clear(world, q): set_both(world, q, 0, 0)


def local_positions(meta):
    c, n = meta["c"], meta["n"]
    return sorted({add(c, (dx, dy, dz), 1, n)
                   for dx, dy, dz in product((-1, 0, 1), repeat=3)})


def install_writer(world, meta):
    q, raw = persistent_writer_spec(meta, "b")
    overlap = int(world.raw[q])
    set_both(world, q, raw, CUT_TICK)
    return {"installed": True, "q": list(q), "raw": raw, "clock": CUT_TICK,
            "replaced_raw": overlap,
            "diagnostic_guard": "Identical writer-coordinate replacement in every branch; not a native reset."}


def restore_nonlearning_fields(world, reference, meta, positions):
    changed = 0
    for q in positions:
        raw = int(reference.raw[q]); clock = int(reference.clock_a[q])
        if q in (meta["a"], meta["b"]):
            current = read(world.raw, q); source = None if not raw else unpack_scalar(raw)
            if current is None or source is None: continue
            raw = int(pack(source["state"], current["sreg"], source["direction"], source["semantic"]))
        set_both(world, q, raw, clock); changed += 1
    return changed


def run(kernel, mode):
    expression = mode != "no_expression_control"
    world, meta = build(kernel, "a", expression=expression)
    reference = None; reference_meta = None
    if mode == "diagnostic_regime_restoration":
        reference, reference_meta = build(kernel, "a", expression=False)
    transitions = []; previous = 0; remote_before = None; intervention = []
    positions = local_positions(meta)
    writer = None; sampled = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if reference is not None: reference.tick()
        if tick == CUT_TICK:
            remote_before = pair(world, meta)
            if mode in ("bridge_cut", "bridge_interface_cut", "diagnostic_regime_restoration"):
                for q in delayed_source_positions(meta):
                    intervention.append({"op": "cut_bridge_source", "q": list(q), "raw": int(world.raw[q])}); clear(world, q)
            if mode == "bridge_interface_cut":
                intervention.append({"op": "clear_master_interface", "q": list(meta["c"]), "raw": int(world.raw[meta["c"]])}); clear(world, meta["c"])
            if mode == "diagnostic_regime_restoration":
                count = restore_nonlearning_fields(world, reference, meta, positions)
                intervention.append({"op": "restore_noexpression_local_regime", "count": count})
            writer = install_writer(world, meta)
            if reference is not None:
                reference_writer = install_writer(reference, reference_meta)
                intervention.append({"op": "reference_writer", **reference_writer})
        elif tick > CUT_TICK and mode == "diagnostic_regime_restoration":
            restore_nonlearning_fields(world, reference, meta, positions)
        delta = delta_value(world, meta)
        if delta != previous: transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick in (9, 24, 511, 512, 513, 576, 611, 640, 768, 806, 896, 1001, 1024):
            sampled.append({"tick": tick, "delta": delta, "remote_pair": pair(world, meta),
                            "interface": read(world.raw, meta["c"])})
        previous = delta
    later = [event for event in transitions if event["tick"] > CUT_TICK]
    return {"mode": mode, "target": "a", "cut_tick": CUT_TICK, "writer": writer,
            "intervention": intervention, "transitions": transitions,
            "post_cut_transitions": later, "write_reopened": bool(later),
            "remote_pair_before_cut": remote_before, "remote_pair_terminal": pair(world, meta),
            "remote_function_held": pair(world, meta) == remote_before,
            "samples": sampled,
            "python_interventions_after_t0": 0 if mode in ("coupled", "no_expression_control") else 1,
            "claim_guard": "Route cuts and regime restoration are diagnostic. No intervention branch establishes native reset or RW3."}


def main():
    kernel, runtime = load_kernel(1)
    modes = ("no_expression_control", "coupled", "bridge_cut", "bridge_interface_cut",
             "diagnostic_regime_restoration")
    rows = [run(kernel, mode) for mode in modes]
    by = {row["mode"]: row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.remote_hold_master_reset.v1",
        "question": "Can the C13 remote latch hold function while decoupling or an explicit regime reset restores a competent second write?",
        "design": {"native_latch_establishment_to_tick": CUT_TICK,
                   "diagnostic_decoupling_and_writer_tick": CUT_TICK,
                   "horizon": HORIZON, "writer": "validated persistent competent writer targeting b",
                   "local_reset_scope": "Moore-27 nonlearning fields; master s_reg preserved"},
        "rows": rows,
        "summary": {
            "positive_control_writes": by["no_expression_control"]["write_reopened"],
            "coupled_blocks": not by["coupled"]["write_reopened"],
            "bridge_cut_reopens": by["bridge_cut"]["write_reopened"],
            "bridge_interface_cut_reopens": by["bridge_interface_cut"]["write_reopened"],
            "diagnostic_regime_restoration_reopens": by["diagnostic_regime_restoration"]["write_reopened"],
            "remote_held_during_diagnostic_reset": by["diagnostic_regime_restoration"]["remote_function_held"]
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R02_REMOTE_HOLD_MASTER_RESET.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
