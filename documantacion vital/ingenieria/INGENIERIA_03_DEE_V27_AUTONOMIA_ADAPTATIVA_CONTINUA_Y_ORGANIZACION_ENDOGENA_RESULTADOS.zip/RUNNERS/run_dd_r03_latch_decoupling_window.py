#!/usr/bin/env python3
"""Find the earliest post-selection cut at which the C13 fixed point is autonomous."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair

CUT_TICKS = (176, 184, 188, 191, 192, 196, 224, 256, 512)
FOLLOWUP = 256
CANONICAL = {
    "a": [1229764615630487555, 1233704926002020355],
    "b": [2238570747477884931, 2238570850557100035],
}


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def run_branch(world, meta, target, cut_tick):
    pre = pair(world, meta)
    removed = []
    for q in (meta["a"], meta["b"], *delayed_source_positions(meta)):
        removed.append({"q": list(q), "raw": int(world.raw[q])}); clear(world, q)
    samples = [{"dt": 0, "pair": pair(world, meta)}]
    for dt in range(1, FOLLOWUP + 1):
        world.tick()
        if dt in (1, 2, 4, 8, 16, 64, 128, 256): samples.append({"dt": dt, "pair": pair(world, meta)})
    terminal = pair(world, meta); canonical = CANONICAL[target]
    return {"target": target, "cut_tick": cut_tick, "pre_cut_pair": pre,
            "pre_cut_is_canonical": pre == canonical, "removed": removed,
            "samples": samples, "terminal_pair": terminal,
            "terminal_is_canonical": terminal == canonical,
            "terminal_equals_pre": terminal == pre,
            "native_ticks_before_cut": cut_tick, "diagnostic_followup_ticks": FOLLOWUP,
            "python_interventions_after_t0": 1,
            "claim_guard": "Diagnostic master+bridge cut; establishes maintenance dependency only."}


def run_target(kernel, target):
    base, meta = build(kernel, target)
    branches = []
    for tick in range(1, max(CUT_TICKS) + 1):
        base.tick()
        if tick in CUT_TICKS: branches.append(run_branch(clone_world(base), dict(meta), target, tick))
    return branches


def main():
    kernel, runtime = load_kernel(1)
    rows = run_target(kernel, "a") + run_target(kernel, "b")
    common = [tick for tick in CUT_TICKS if all(next(row for row in rows if row["target"] == target and row["cut_tick"] == tick)["terminal_is_canonical"] for target in ("a", "b"))]
    result = seal({
        "schema": "dee.v27.ing03.delegation.latch_decoupling_window.v1",
        "question": "At what earliest causally meaningful time can master and bridge be removed while both learned C13 fixed points remain correct?",
        "design": {"cut_ticks": list(CUT_TICKS), "followup_ticks": FOLLOWUP,
                   "cut_components": ["master_pair", "four delayed bridge sources"],
                   "cut_type": "DIAGNOSTIC_INTERVENTION",
                   "canonical_pairs_source": "ING03_RW3_R12_REMOTE_FIXED_POINT_CHARACTERIZATION.json"},
        "rows": rows,
        "summary": {"common_successful_cut_ticks": common,
                    "earliest_common_autonomous_latch_tick": min(common) if common else None,
                    "a_native_fixed_tick_reference": 188,
                    "b_native_fixed_tick_reference": 191},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R03_LATCH_DECOUPLING_WINDOW.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
