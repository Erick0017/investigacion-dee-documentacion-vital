#!/usr/bin/env python3
"""Repeat the reset test at the earliest common autonomous-latch cut (t=184)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import run_dd_r02_remote_hold_master_reset as reset
from ing03_common import ROOT, load_kernel, seal, write_json

CUT_TICK = 184
HORIZON = 768


def main():
    reset.CUT_TICK = CUT_TICK; reset.HORIZON = HORIZON
    kernel, runtime = load_kernel(1)
    modes = ("no_expression_control", "coupled", "bridge_cut", "bridge_interface_cut",
             "diagnostic_regime_restoration")
    rows = [reset.run(kernel, mode) for mode in modes]
    by = {row["mode"]: row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.early_decoupling_reset.v1",
        "question": "Does decoupling at the earliest common autonomous-latch time reopen master plasticity before the expression regime matures further?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON,
                   "cut_tick_source": "ING03_DD_R03_LATCH_DECOUPLING_WINDOW",
                   "writer": "validated persistent competent writer targeting b",
                   "reset": "diagnostic Moore-27 nonlearning-field restoration preserving master s_reg"},
        "rows": rows,
        "summary": {
            "positive_control_writes": by["no_expression_control"]["write_reopened"],
            "coupled_blocks": not by["coupled"]["write_reopened"],
            "bridge_cut_reopens": by["bridge_cut"]["write_reopened"],
            "bridge_interface_cut_reopens": by["bridge_interface_cut"]["write_reopened"],
            "diagnostic_regime_restoration_reopens": by["diagnostic_regime_restoration"]["write_reopened"],
            "remote_held_during_diagnostic_reset": by["diagnostic_regime_restoration"]["remote_function_held"]
        },
        "claim_guard": "All cut/reset branches are diagnostic and cannot establish native decoupling or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R04_EARLY_DECOUPLING_RESET.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
