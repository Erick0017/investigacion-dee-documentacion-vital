#!/usr/bin/env python3
"""Organization-level counterfactual map of the maintained expression regime."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair, receiver_source_positions
from run_dd_r02_remote_hold_master_reset import install_writer, restore_nonlearning_fields

CUT_TICK = 184
HORIZON = 768
RADII = (1, 2, 3, 4, 6)
CANONICAL_A = [1229764615630487555, 1233704926002020355]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(meta, radius):
    c, n = meta["c"], meta["n"]
    protected = {meta["q_receiver"], meta["qp_receiver"], *receiver_source_positions(meta)}
    return sorted({add(c, offset, 1, n)
                   for offset in product(range(-radius, radius + 1), repeat=3)} - protected)


def main():
    import run_dd_r02_remote_hold_master_reset as reset
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, reference_meta = build(kernel, "a", expression=False)
    for _ in range(CUT_TICK): expression.tick(); reference.tick()
    branches = []
    for radius in RADII:
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        positions = region(meta, radius)
        restore_nonlearning_fields(world, reference, meta, positions)
        writer = install_writer(world, meta)
        branches.append({"radius": radius, "world": world, "positions": positions,
                         "writer": writer, "previous": delta_value(world, meta), "transitions": []})
    reference_writer = install_writer(reference, reference_meta)
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick()
        for branch in branches:
            branch["world"].tick()
            restore_nonlearning_fields(branch["world"], reference, meta, branch["positions"])
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]:
                branch["transitions"].append({"tick": tick, "before": branch["previous"], "after": delta})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        remote = pair(branch["world"], meta)
        rows.append({"radius": branch["radius"], "restored_voxel_count": len(branch["positions"]),
                     "writer": branch["writer"], "post_cut_transitions": branch["transitions"],
                     "write_reopened": bool(branch["transitions"]), "terminal_delta": branch["previous"],
                     "remote_terminal_pair": remote, "remote_terminal_is_canonical_a": remote == CANONICAL_A,
                     "remote_apparatus_excluded_from_restoration": True,
                     "python_interventions_after_t0": HORIZON - CUT_TICK + 1,
                     "claim_guard": "Sustained counterfactual restoration is diagnostic only."})
    successful = [row["radius"] for row in rows if row["write_reopened"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.regime_spatial_extent.v1",
        "question": "How large a master-centered counterfactual restoration is sufficient to recover competent writing while the remote latch is protected?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON, "radii": list(RADII),
                   "restoration": "sustained no-expression nonlearning fields; master s_reg preserved",
                   "remote_protection": "receiver pair and its four original drive sources excluded",
                   "reference_writer": reference_writer},
        "rows": rows,
        "summary": {"successful_radii": successful,
                    "minimum_sufficient_radius": min(successful) if successful else None,
                    "largest_tested_radius": max(RADII),
                    "remote_canonical_for_all": all(row["remote_terminal_is_canonical_a"] for row in rows)},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R05_REGIME_SPATIAL_EXTENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
