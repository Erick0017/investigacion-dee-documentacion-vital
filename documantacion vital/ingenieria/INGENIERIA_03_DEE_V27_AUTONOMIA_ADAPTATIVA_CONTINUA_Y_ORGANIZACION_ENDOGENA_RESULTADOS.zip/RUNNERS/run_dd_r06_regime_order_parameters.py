#!/usr/bin/env python3
"""Reduce the radius-2 reset into causal 3D strata and changed-field sets."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, read, seal, unpack_scalar, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

CUT_TICK = 184
HORIZON = 400
CANONICAL_A = [1229764615630487555, 1233704926002020355]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def offset(q, c, n):
    out = []
    for value, center in zip(q, c):
        d = (value - center) % n
        if d > n // 2: d -= n
        out.append(int(d))
    return tuple(out)


def positions(meta, predicate):
    c, n = meta["c"], meta["n"]
    return sorted({add(c, d, 1, n) for d in product(range(-2, 3), repeat=3) if predicate(d)})


def main():
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, reference_meta = build(kernel, "a", expression=False)
    for _ in range(CUT_TICK): expression.tick(); reference.tick()
    r2 = positions(meta, lambda d: max(map(abs, d)) <= 2)
    changed = [q for q in r2 if int(expression.raw[q]) != int(reference.raw[q]) or int(expression.clock_a[q]) != int(reference.clock_a[q])]
    static_diff = []
    for q in changed:
        eraw, rraw = int(expression.raw[q]), int(reference.raw[q])
        static_diff.append({"q": list(q), "offset": list(offset(q, meta["c"], meta["n"])),
                            "expression": None if not eraw else unpack_scalar(eraw),
                            "no_expression": None if not rraw else unpack_scalar(rraw),
                            "expression_clock": int(expression.clock_a[q]),
                            "no_expression_clock": int(reference.clock_a[q])})
    variants = {
        "core_r1": positions(meta, lambda d: max(map(abs, d)) <= 1),
        "shell2_only": positions(meta, lambda d: max(map(abs, d)) == 2),
        "full_r2": r2,
        "core_plus_x_faces": positions(meta, lambda d: max(map(abs, d)) <= 1 or abs(d[0]) == 2),
        "core_plus_yz_faces": positions(meta, lambda d: max(map(abs, d)) <= 1 or abs(d[1]) == 2 or abs(d[2]) == 2),
        "changed_only_at_cut": changed,
        "changed_shell_only_at_cut": [q for q in changed if max(map(abs, offset(q, meta["c"], meta["n"]))) == 2],
    }
    branches = []
    for name, selected in variants.items():
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        reset.restore_nonlearning_fields(world, reference, meta, selected)
        writer = reset.install_writer(world, meta)
        branches.append({"name": name, "positions": selected, "world": world, "writer": writer,
                         "previous": delta_value(world, meta), "transitions": []})
    reference_writer = reset.install_writer(reference, reference_meta)
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick()
        for branch in branches:
            branch["world"].tick()
            reset.restore_nonlearning_fields(branch["world"], reference, meta, branch["positions"])
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]:
                branch["transitions"].append({"tick": tick, "before": branch["previous"], "after": delta})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        remote = pair(branch["world"], meta)
        rows.append({"variant": branch["name"], "restored_voxel_count": len(branch["positions"]),
                     "writer": branch["writer"], "post_cut_transitions": branch["transitions"],
                     "write_reopened": bool(branch["transitions"]), "terminal_delta": branch["previous"],
                     "remote_terminal_pair": remote, "remote_terminal_is_canonical_a": remote == CANONICAL_A,
                     "python_interventions_after_t0": HORIZON - CUT_TICK + 1})
    passing = [row["variant"] for row in rows if row["write_reopened"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.regime_order_parameters.v1",
        "question": "Which 3D stratum or cut-time differential subset carries the minimum sufficient radius-2 reset?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON,
                   "variants": {key: len(value) for key, value in variants.items()},
                   "restoration": "sustained no-expression nonlearning fields; master s_reg preserved",
                   "reference_writer": reference_writer},
        "cut_time_static_difference": {"count": len(static_diff), "records": static_diff,
                                       "raw_difference_count": sum(item["expression"] != item["no_expression"] for item in static_diff),
                                       "clock_difference_count": sum(item["expression_clock"] != item["no_expression_clock"] for item in static_diff)},
        "rows": rows,
        "summary": {"passing_variants": passing,
                    "shell2_only_sufficient": "shell2_only" in passing,
                    "changed_only_sufficient": "changed_only_at_cut" in passing,
                    "x_face_biased_sufficient": "core_plus_x_faces" in passing,
                    "yz_face_biased_sufficient": "core_plus_yz_faces" in passing,
                    "remote_canonical_for_passing": all(row["remote_terminal_is_canonical_a"] for row in rows if row["write_reopened"])},
        "claim_guard": "All restorations are sustained host diagnostics, not native replasticization.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R06_REGIME_ORDER_PARAMETERS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "static_difference_count": len(static_diff),
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
