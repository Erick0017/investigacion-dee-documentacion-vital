#!/usr/bin/env python3
"""Resolve the signed x-face contribution to the sufficient regime reset."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

CUT_TICK = 184
HORIZON = 400
CANONICAL_A = [1229764615630487555, 1233704926002020355]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def qset(meta, offsets): return {add(meta["c"], d, 1, meta["n"]) for d in offsets}


def main():
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, reference_meta = build(kernel, "a", expression=False)
    for _ in range(CUT_TICK): expression.tick(); reference.tick()
    core = qset(meta, product((-1, 0, 1), repeat=3))
    neg = qset(meta, ((-2, y, z) for y in range(-2, 3) for z in range(-2, 3)))
    pos = qset(meta, ((2, y, z) for y in range(-2, 3) for z in range(-2, 3)))
    changed = {q for q in core | neg | pos
               if int(expression.raw[q]) != int(reference.raw[q]) or int(expression.clock_a[q]) != int(reference.clock_a[q])}
    variants = {
        "core_plus_negative_x_face": core | neg,
        "core_plus_positive_x_face": core | pos,
        "core_plus_changed_negative_x": core | (neg & changed),
        "core_plus_changed_positive_x": core | (pos & changed),
        "core_plus_changed_both_x": core | ((neg | pos) & changed),
        "core_plus_both_x_faces": core | neg | pos,
    }
    branches = []
    for name, selected in variants.items():
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        reset.restore_nonlearning_fields(world, reference, meta, sorted(selected))
        writer = reset.install_writer(world, meta)
        branches.append({"name": name, "positions": sorted(selected), "world": world,
                         "writer": writer, "previous": delta_value(world, meta), "transitions": []})
    reset.install_writer(reference, reference_meta)
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick()
        for branch in branches:
            branch["world"].tick()
            reset.restore_nonlearning_fields(branch["world"], reference, meta, branch["positions"])
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]: branch["transitions"].append({"tick": tick, "before": branch["previous"], "after": delta})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        remote = pair(branch["world"], meta)
        rows.append({"variant": branch["name"], "restored_voxel_count": len(branch["positions"]),
                     "changed_negative_face_count": len(neg & changed), "changed_positive_face_count": len(pos & changed),
                     "post_cut_transitions": branch["transitions"], "write_reopened": bool(branch["transitions"]),
                     "remote_terminal_is_canonical_a": remote == CANONICAL_A,
                     "python_interventions_after_t0": HORIZON - CUT_TICK + 1})
    passing = [row["variant"] for row in rows if row["write_reopened"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.axial_regime_ports.v1",
        "question": "Which signed x-oriented causal face is needed with the local core to restore writing?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON,
                   "core_count": len(core), "negative_face_count": len(neg), "positive_face_count": len(pos),
                   "changed_negative_face_count": len(neg & changed), "changed_positive_face_count": len(pos & changed)},
        "rows": rows,
        "summary": {"passing_variants": passing,
                    "negative_face_sufficient": "core_plus_negative_x_face" in passing,
                    "positive_face_sufficient": "core_plus_positive_x_face" in passing,
                    "changed_negative_sufficient": "core_plus_changed_negative_x" in passing,
                    "changed_positive_sufficient": "core_plus_changed_positive_x" in passing,
                    "remote_canonical_for_passing": all(row["remote_terminal_is_canonical_a"] for row in rows if row["write_reopened"])},
        "claim_guard": "Sustained host restoration identifies a causal port but is not a native transition.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R07_AXIAL_REGIME_PORTS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
