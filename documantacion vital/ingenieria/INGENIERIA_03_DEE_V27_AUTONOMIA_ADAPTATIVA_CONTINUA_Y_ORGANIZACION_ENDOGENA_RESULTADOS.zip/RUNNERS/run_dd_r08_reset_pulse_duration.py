#!/usr/bin/env python3
"""Pulse-width law for the sufficient negative-x causal reset surface."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

CUT_TICK = 184
HORIZON = 400
DURATIONS = (1, 2, 4, 8, 16, 32, 64, 96, 128, 150, 195, 216)
CANONICAL_A = [1229764615630487555, 1233704926002020355]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def main():
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, reference_meta = build(kernel, "a", expression=False)
    for _ in range(CUT_TICK): expression.tick(); reference.tick()
    core_offsets = list(product((-1, 0, 1), repeat=3))
    neg_offsets = [(-2, y, z) for y in range(-2, 3) for z in range(-2, 3)]
    candidates = {add(meta["c"], d, 1, meta["n"]) for d in core_offsets + neg_offsets}
    changed_neg = {q for q in candidates if int(expression.raw[q]) != int(reference.raw[q]) or int(expression.clock_a[q]) != int(reference.clock_a[q])}
    core = {add(meta["c"], d, 1, meta["n"]) for d in core_offsets}
    selected = sorted(core | changed_neg)
    branches = []
    for duration in DURATIONS:
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        reset.restore_nonlearning_fields(world, reference, meta, selected)
        writer = reset.install_writer(world, meta)
        branches.append({"duration": duration, "world": world, "writer": writer,
                         "previous": delta_value(world, meta), "transitions": []})
    reset.install_writer(reference, reference_meta)
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick()
        dt = tick - CUT_TICK
        for branch in branches:
            branch["world"].tick()
            if dt < branch["duration"]:
                reset.restore_nonlearning_fields(branch["world"], reference, meta, selected)
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]: branch["transitions"].append({"tick": tick, "dt": dt, "before": branch["previous"], "after": delta})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        remote = pair(branch["world"], meta)
        rows.append({"pulse_duration_ticks": branch["duration"], "restored_voxel_count": len(selected),
                     "post_cut_transitions": branch["transitions"], "write_reopened": bool(branch["transitions"]),
                     "first_write_dt": None if not branch["transitions"] else branch["transitions"][0]["dt"],
                     "remote_terminal_is_canonical_a": remote == CANONICAL_A,
                     "python_interventions_after_t0": branch["duration"]})
    successful = [row["pulse_duration_ticks"] for row in rows if row["write_reopened"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.reset_pulse_duration.v1",
        "question": "Does a transient reset pulse trigger a durable plastic regime, or must the axial surface be held through a writer opportunity?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON, "durations": list(DURATIONS),
                   "surface": "core radius1 plus cut-time-divergent negative-x face sites",
                   "restored_voxel_count": len(selected),
                   "known_first_writer_opportunity_tick": 334},
        "rows": rows,
        "summary": {"successful_durations": successful,
                    "minimum_successful_duration": min(successful) if successful else None,
                    "one_tick_pulse_sufficient": 1 in successful,
                    "success_requires_spanning_first_writer_opportunity": bool(successful) and min(successful) >= 150,
                    "remote_canonical_for_all": all(row["remote_terminal_is_canonical_a"] for row in rows)},
        "claim_guard": "Host-applied pulse-width diagnostics do not establish a native gate.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R08_RESET_PULSE_DURATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
