#!/usr/bin/env python3
"""Diagnostic switchability of an established C13 A latch under later B coupling."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_dd_r01_remote_dependency_map import pair

SWITCH_TICK = 512
DRIVE_DURATION = 256
HORIZON = 1024
CANONICAL_A = [1229764615630487555, 1233704926002020355]
CANONICAL_B = [2238570747477884931, 2238570850557100035]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def set_from(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def region(meta, predicate):
    return sorted({add(meta["c"], d, 1, meta["n"])
                   for d in product(range(-2, 3), repeat=3) if predicate(d)})


def main():
    kernel, runtime = load_kernel(1)
    wa, meta = build(kernel, "a", expression=True)
    wb, _ = build(kernel, "b", expression=True)
    for _ in range(SWITCH_TICK): wa.tick(); wb.tick()
    core = region(meta, lambda d: max(map(abs, d)) <= 1)
    axial = region(meta, lambda d: max(map(abs, d)) <= 1 or d[0] == -2)
    full_r2 = region(meta, lambda d: max(map(abs, d)) <= 2)
    receiver = [meta["q_receiver"], meta["qp_receiver"]]
    specs = {
        "intact_a": ([], 0),
        "master_pair_b_once": ([meta["a"], meta["b"]], 1),
        "axial_b_once": (axial, 1),
        "axial_b_sustained": (axial, DRIVE_DURATION),
        "full_r2_b_sustained": (full_r2, DRIVE_DURATION),
        "receiver_pair_b_positive_control": (receiver, 1),
    }
    branches = []
    for name, (selected, duration) in specs.items():
        world = clone_world(wa)
        if selected: set_from(world, wb, selected)
        branches.append({"name": name, "positions": selected, "duration": duration, "world": world,
                         "samples": [{"tick": SWITCH_TICK, "pair": pair(world, meta)}]})
    for tick in range(SWITCH_TICK + 1, HORIZON + 1):
        wb.tick()
        dt = tick - SWITCH_TICK
        for branch in branches:
            branch["world"].tick()
            if branch["positions"] and dt < branch["duration"]:
                set_from(branch["world"], wb, branch["positions"])
            if dt in (1, 2, 4, 8, 16, 64, 128, 256, 257, 320, 512):
                branch["samples"].append({"tick": tick, "dt": dt, "pair": pair(branch["world"], meta)})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        rows.append({"variant": branch["name"], "copied_voxel_count": len(branch["positions"]),
                     "drive_duration_ticks": branch["duration"], "samples": branch["samples"],
                     "terminal_pair": terminal, "terminal_is_a": terminal == CANONICAL_A,
                     "terminal_is_b": terminal == CANONICAL_B,
                     "python_interventions_after_t0": 0 if branch["name"] == "intact_a" else max(1, branch["duration"]),
                     "claim_guard": "Host-installed B-regime diagnostic; not native state switching."})
    by = {row["variant"]: row for row in rows}
    switched = [row["variant"] for row in rows if row["terminal_is_b"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.remote_state_switching.v1",
        "question": "Can an already self-maintained remote A fixed point be switched into canonical B by a later B master-centered causal regime?",
        "design": {"switch_tick": SWITCH_TICK, "drive_duration_ticks": DRIVE_DURATION,
                   "horizon": HORIZON, "initial_remote": "canonical A"},
        "rows": rows,
        "summary": {"intact_remains_a": by["intact_a"]["terminal_is_a"],
                    "switching_variants": switched,
                    "master_pair_once_switches": by["master_pair_b_once"]["terminal_is_b"],
                    "axial_sustained_switches": by["axial_b_sustained"]["terminal_is_b"],
                    "full_r2_sustained_switches": by["full_r2_b_sustained"]["terminal_is_b"],
                    "direct_pair_b_holds": by["receiver_pair_b_positive_control"]["terminal_is_b"]},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R09_REMOTE_STATE_SWITCHING.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
