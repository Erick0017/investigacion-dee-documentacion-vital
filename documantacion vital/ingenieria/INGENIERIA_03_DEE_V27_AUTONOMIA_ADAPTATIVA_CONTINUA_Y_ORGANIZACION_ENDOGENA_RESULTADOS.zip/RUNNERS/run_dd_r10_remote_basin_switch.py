#!/usr/bin/env python3
"""Counterfactual basin-size map for switching the C13 remote latch A to B."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

from numpy import uint64

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_dd_r01_remote_dependency_map import pair, receiver_source_positions

SWITCH_TICK = 512
DRIVE_DURATION = 256
HORIZON = 1024
CANONICAL_A = [1229764615630487555, 1233704926002020355]
CANONICAL_B = [2238570747477884931, 2238570850557100035]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(meta, radius):
    q, n = meta["q_receiver"], meta["n"]
    return sorted({add(q, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def set_from(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def main():
    kernel, runtime = load_kernel(1)
    wa, meta = build(kernel, "a", expression=True)
    wb, _ = build(kernel, "b", expression=True)
    for _ in range(SWITCH_TICK): wa.tick(); wb.tick()
    apparatus = sorted({meta["q_receiver"], meta["qp_receiver"], *receiver_source_positions(meta)})
    specs = {
        "intact_a": ([], 0),
        "apparatus_b_sustained": (apparatus, DRIVE_DURATION),
        "receiver_r1_b_sustained": (region(meta, 1), DRIVE_DURATION),
        "receiver_r2_b_once": (region(meta, 2), 1),
        "receiver_r2_b_sustained": (region(meta, 2), DRIVE_DURATION),
        "receiver_r3_b_sustained": (region(meta, 3), DRIVE_DURATION),
    }
    branches = []
    for name, (selected, duration) in specs.items():
        world = clone_world(wa)
        if selected: set_from(world, wb, selected)
        branches.append({"name": name, "positions": selected, "duration": duration, "world": world,
                         "samples": [{"tick": SWITCH_TICK, "pair": pair(world, meta)}]})
    for tick in range(SWITCH_TICK + 1, HORIZON + 1):
        wb.tick(); dt = tick - SWITCH_TICK
        for branch in branches:
            branch["world"].tick()
            if branch["positions"] and dt < branch["duration"]: set_from(branch["world"], wb, branch["positions"])
            if dt in (1, 2, 4, 8, 16, 64, 128, 255, 256, 257, 320, 512):
                branch["samples"].append({"tick": tick, "dt": dt, "pair": pair(branch["world"], meta)})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        after_release = [sample["pair"] for sample in branch["samples"] if sample.get("dt", 0) > DRIVE_DURATION]
        rows.append({"variant": branch["name"], "copied_voxel_count": len(branch["positions"]),
                     "drive_duration_ticks": branch["duration"], "samples": branch["samples"],
                     "terminal_pair": terminal, "terminal_is_a": terminal == CANONICAL_A,
                     "terminal_is_b": terminal == CANONICAL_B,
                     "post_release_samples_all_b": bool(after_release) and all(value == CANONICAL_B for value in after_release),
                     "python_interventions_after_t0": 0 if branch["name"] == "intact_a" else max(1, branch["duration"])})
    by = {row["variant"]: row for row in rows}; switched = [row["variant"] for row in rows if row["terminal_is_b"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.remote_basin_switch.v1",
        "question": "What receiver-centered organizational radius must be driven into B before the A latch switches and remains B after release?",
        "design": {"switch_tick": SWITCH_TICK, "drive_duration_ticks": DRIVE_DURATION,
                   "release_followup_ticks": HORIZON - SWITCH_TICK - DRIVE_DURATION,
                   "horizon": HORIZON},
        "rows": rows,
        "summary": {"intact_remains_a": by["intact_a"]["terminal_is_a"],
                    "switching_variants": switched,
                    "r1_sustained_switches": by["receiver_r1_b_sustained"]["terminal_is_b"],
                    "r2_once_switches": by["receiver_r2_b_once"]["terminal_is_b"],
                    "r2_sustained_switches": by["receiver_r2_b_sustained"]["terminal_is_b"],
                    "r3_sustained_switches": by["receiver_r3_b_sustained"]["terminal_is_b"],
                    "r2_sustained_holds_after_release": by["receiver_r2_b_sustained"]["post_release_samples_all_b"]},
        "claim_guard": "Host-driven receiver-basin replacement maps switchability; it is not native latch update.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R10_REMOTE_BASIN_SWITCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
