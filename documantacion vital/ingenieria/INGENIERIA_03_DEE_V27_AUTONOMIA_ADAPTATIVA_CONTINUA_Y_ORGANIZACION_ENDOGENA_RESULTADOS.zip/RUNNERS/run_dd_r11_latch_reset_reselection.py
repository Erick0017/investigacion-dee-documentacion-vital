#!/usr/bin/env python3
"""Can a neutralized remote basin be reselected by a later B master regime?"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_dd_r01_remote_dependency_map import pair, receiver_source_positions

SWITCH_TICK = 512
DRIVE_DURATION = 256
HORIZON = 1024
CANONICAL_A = [1229764615630487555, 1233704926002020355]
CANONICAL_B = [2238570747477884931, 2238570850557100035]


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(center, n, radius):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def set_from(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def zero(world, positions):
    for q in positions:
        world.raw_a[q] = 0; world.raw_b[q] = 0; world.clock_a[q] = 0; world.clock_b[q] = 0


def main():
    kernel, runtime = load_kernel(1)
    wa, meta = build(kernel, "a", expression=True); wb, _ = build(kernel, "b", expression=True)
    for _ in range(SWITCH_TICK): wa.tick(); wb.tick()
    master_axial = sorted({add(meta["c"], d, 1, meta["n"])
                           for d in product(range(-2, 3), repeat=3)
                           if max(map(abs, d)) <= 1 or d[0] == -2})
    remote_r1 = region(meta["q_receiver"], meta["n"], 1)
    remote_r2 = region(meta["q_receiver"], meta["n"], 2)
    apparatus = sorted({meta["q_receiver"], meta["qp_receiver"], *receiver_source_positions(meta)})
    specs = {
        "intact_a": ([], False),
        "b_master_drive_only": ([], True),
        "clear_apparatus_plus_b_drive": (apparatus, True),
        "clear_remote_r1_plus_b_drive": (remote_r1, True),
        "clear_remote_r2_only": (remote_r2, False),
        "clear_remote_r2_plus_b_drive": (remote_r2, True),
    }
    branches = []
    for name, (clear_positions, drive_b) in specs.items():
        world = clone_world(wa)
        if clear_positions: zero(world, clear_positions)
        if drive_b: set_from(world, wb, master_axial)
        branches.append({"name": name, "world": world, "clear": clear_positions, "drive_b": drive_b,
                         "samples": [{"tick": SWITCH_TICK, "pair": pair(world, meta)}]})
    for tick in range(SWITCH_TICK + 1, HORIZON + 1):
        wb.tick(); dt = tick - SWITCH_TICK
        for branch in branches:
            branch["world"].tick()
            if branch["drive_b"] and dt < DRIVE_DURATION: set_from(branch["world"], wb, master_axial)
            if dt in (1, 2, 4, 8, 16, 64, 128, 255, 256, 257, 320, 512):
                branch["samples"].append({"tick": tick, "dt": dt, "pair": pair(branch["world"], meta)})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        rows.append({"variant": branch["name"], "cleared_voxel_count": len(branch["clear"]),
                     "b_master_drive_duration": DRIVE_DURATION if branch["drive_b"] else 0,
                     "samples": branch["samples"], "terminal_pair": terminal,
                     "terminal_is_a": terminal == CANONICAL_A, "terminal_is_b": terminal == CANONICAL_B,
                     "python_interventions_after_t0": (1 if branch["clear"] else 0) + (DRIVE_DURATION if branch["drive_b"] else 0)})
    by = {row["variant"]: row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.latch_reset_reselection.v1",
        "question": "Does a one-time neutralization of the remote basin let a later B master-centered regime reselect canonical B?",
        "design": {"switch_tick": SWITCH_TICK, "b_drive_duration": DRIVE_DURATION,
                   "b_drive_surface": "master core radius1 plus negative-x face", "horizon": HORIZON},
        "rows": rows,
        "summary": {"intact_remains_a": by["intact_a"]["terminal_is_a"],
                    "b_drive_only_fails": not by["b_master_drive_only"]["terminal_is_b"],
                    "apparatus_clear_plus_b_switches": by["clear_apparatus_plus_b_drive"]["terminal_is_b"],
                    "r1_clear_plus_b_switches": by["clear_remote_r1_plus_b_drive"]["terminal_is_b"],
                    "r2_clear_only_returns_a": by["clear_remote_r2_only"]["terminal_is_a"],
                    "r2_clear_plus_b_switches": by["clear_remote_r2_plus_b_drive"]["terminal_is_b"]},
        "claim_guard": "Host neutralization and B-regime drive establish causal prerequisites, not native reselection.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R11_LATCH_RESET_RESELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
