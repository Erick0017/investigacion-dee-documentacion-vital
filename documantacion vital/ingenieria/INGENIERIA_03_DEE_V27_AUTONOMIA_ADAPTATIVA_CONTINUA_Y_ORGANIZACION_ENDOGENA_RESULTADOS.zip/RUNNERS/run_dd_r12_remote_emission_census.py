#!/usr/bin/env python3
"""Emission census for isolated, already established C13 remote basins."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_dd_r01_remote_dependency_map import pair, receiver_source_positions

EXTRACT_TICK = 512
FOLLOWUP = 256
RADIUS = 2
CANONICAL = {"a": [1229764615630487555, 1233704926002020355],
             "b": [2238570747477884931, 2238570850557100035]}


def cheb(q, center, n):
    values = []
    for x, c in zip(q, center):
        d = (x - c) % n
        d = min(d, n - d); values.append(d)
    return max(values)


def region(meta):
    return sorted({add(meta["q_receiver"], d, 1, meta["n"])
                   for d in product(range(-RADIUS, RADIUS + 1), repeat=3)})


def isolated_world(kernel, source_world, meta, cut_sources):
    n = meta["n"]; raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    for q in region(meta): raw[q] = source_world.raw[q]; clock[q] = source_world.clock_a[q]
    if cut_sources:
        for q in receiver_source_positions(meta): raw[q] = 0; clock[q] = 0
    return NativeWorld(kernel, raw, clock)


def run(kernel, target, cut_sources):
    source, meta = build(kernel, target, expression=True)
    for _ in range(EXTRACT_TICK): source.tick()
    world = isolated_world(kernel, source, meta, cut_sources)
    initial_region = set(region(meta)); samples = []
    first_outside = None; maximum_distance = RADIUS; outside_union = set()
    for tick in range(0, FOLLOWUP + 1):
        if tick:
            world.tick()
        coords = np.argwhere(world.raw != 0)
        outside = []
        for row in coords:
            q = tuple(int(v) for v in row)
            if q not in initial_region:
                outside.append(q); outside_union.add(q); maximum_distance = max(maximum_distance, cheb(q, meta["q_receiver"], meta["n"]))
        if outside and first_outside is None: first_outside = tick
        if tick in (0, 1, 2, 4, 8, 16, 32, 64, 128, 256):
            samples.append({"tick": tick, "remote_pair": pair(world, meta),
                            "support": int(np.count_nonzero(world.raw)),
                            "outside_r2_support": len(outside),
                            "outside_r2_max_distance": max([RADIUS] + [cheb(q, meta["q_receiver"], meta["n"]) for q in outside])})
    terminal = pair(world, meta)
    return {"target": target, "receiver_sources_cut_on_isolation": cut_sources,
            "initial_remote_pair": samples[0]["remote_pair"], "terminal_remote_pair": terminal,
            "terminal_is_canonical": terminal == CANONICAL[target],
            "first_outside_r2_emission_tick": first_outside,
            "outside_r2_union_count": len(outside_union), "maximum_reached_chebyshev_distance": maximum_distance,
            "samples": samples, "python_interventions_after_t0": 1,
            "claim_guard": "Host isolation diagnoses remote emission; it is not native decoupling."}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target, cut_sources) for target in ("a", "b") for cut_sources in (False, True)]
    cut = [row for row in rows if row["receiver_sources_cut_on_isolation"]]
    result = seal({
        "schema": "dee.v27.ing03.delegation.remote_emission_census.v1",
        "question": "Does an isolated established remote basin emit causal traffic beyond radius2, including after its configured sources are removed?",
        "design": {"extract_tick": EXTRACT_TICK, "copied_radius": RADIUS, "followup_ticks": FOLLOWUP,
                   "background": "zero outside copied receiver basin"},
        "rows": rows,
        "summary": {"source_cut_basins_hold": all(row["terminal_is_canonical"] for row in cut),
                    "source_cut_any_emission": any(row["outside_r2_union_count"] > 0 for row in cut),
                    "source_cut_maximum_distance": max(row["maximum_reached_chebyshev_distance"] for row in cut),
                    "source_cut_first_emission_ticks": {row["target"]: row["first_outside_r2_emission_tick"] for row in cut}},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R12_REMOTE_EMISSION_CENSUS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
