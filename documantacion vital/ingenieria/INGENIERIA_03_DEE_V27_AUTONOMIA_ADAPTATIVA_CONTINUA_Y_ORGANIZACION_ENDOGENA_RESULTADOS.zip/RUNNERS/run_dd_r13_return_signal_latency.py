#!/usr/bin/env python3
"""First-passage and signature of source-free remote-basin emissions at master ports."""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_rw3_r03_recurrent_writer_blocker_control import persistent_writer_spec
from run_dd_r12_remote_emission_census import EXTRACT_TICK, FOLLOWUP, isolated_world


def token(world, positions): return tuple(int(world.raw[q]) for q in positions)


def signature(sequence):
    h = hashlib.sha256()
    for values in sequence:
        for value in values: h.update(int(value).to_bytes(8, "little"))
    return h.hexdigest()


def main():
    kernel, runtime = load_kernel(1)
    sources = {}; metas = {}
    for target in ("a", "b"):
        source, meta = build(kernel, target, expression=True)
        for _ in range(EXTRACT_TICK): source.tick()
        sources[target] = isolated_world(kernel, source, meta, True); metas[target] = meta
    meta = metas["a"]; c, n = meta["c"], meta["n"]
    groups = {
        "master_core_r1": sorted({add(c, d, 1, n) for d in product((-1, 0, 1), repeat=3)}),
        "negative_x_face": sorted({add(c, (-2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)}),
        "positive_x_face": sorted({add(c, (2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)}),
        "master_pair": [meta["a"], meta["b"]],
        "writer_origin": [persistent_writer_spec(meta, "b")[0]],
    }
    traces = {target: {name: [] for name in groups} for target in ("a", "b")}
    first = {target: {name: None for name in groups} for target in ("a", "b")}
    samples = []
    for tick in range(0, FOLLOWUP + 1):
        if tick:
            for world in sources.values(): world.tick()
        for target, world in sources.items():
            for name, positions in groups.items():
                values = token(world, positions); traces[target][name].append(values)
                if any(values) and first[target][name] is None: first[target][name] = tick
        if tick in (0, 1, 2, 4, 8, 16, 32, 64, 128, 256):
            samples.append({"tick": tick, "groups": {target: {name: sum(value != 0 for value in traces[target][name][-1]) for name in groups} for target in ("a", "b")}})
    rows = []
    for target in ("a", "b"):
        rows.append({"target": target, "first_nonzero_tick": first[target],
                     "signatures": {name: signature(traces[target][name]) for name in groups},
                     "terminal_nonzero_counts": {name: sum(value != 0 for value in traces[target][name][-1]) for name in groups}})
    by = {row["target"]: row for row in rows}
    distinct = {name: by["a"]["signatures"][name] != by["b"]["signatures"][name] for name in groups}
    result = seal({
        "schema": "dee.v27.ing03.delegation.return_signal_latency.v1",
        "question": "Do source-free A/B remote basins emit signals that reach master reset/write ports, and are the received temporal signatures state dependent?",
        "design": {"extract_tick": EXTRACT_TICK, "remote_sources_cut": True,
                   "background": "zero outside receiver radius2", "followup_ticks": FOLLOWUP,
                   "target_groups": {name: [list(q) for q in positions] for name, positions in groups.items()}},
        "rows": rows, "samples": samples,
        "summary": {"first_arrival_ticks": first,
                    "a_b_signature_distinct_by_group": distinct,
                    "reaches_negative_x_face_both": all(first[target]["negative_x_face"] is not None for target in ("a", "b")),
                    "reaches_master_pair_both": all(first[target]["master_pair"] is not None for target in ("a", "b")),
                    "reaches_writer_origin_both": all(first[target]["writer_origin"] is not None for target in ("a", "b"))},
        "claim_guard": "First passage in an isolated diagnostic background does not establish feedback shutdown in the coupled apparatus.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R13_RETURN_SIGNAL_LATENCY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
