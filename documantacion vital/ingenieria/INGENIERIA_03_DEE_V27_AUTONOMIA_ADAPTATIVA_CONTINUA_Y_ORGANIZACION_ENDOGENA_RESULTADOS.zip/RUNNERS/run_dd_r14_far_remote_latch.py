#!/usr/bin/env python3
"""Native consequence-selected remote latch at a non-overlapping far offset."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair, receiver_source_positions

OFFSET = (-6, 7, 8)
CUT_TICK = 512
HORIZON = 1024


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def run(kernel, target):
    r10.OFFSET = OFFSET
    world, meta = r10.build(kernel, target)
    prefix = []
    for _ in range(CUT_TICK):
        world.tick(); prefix.append(tuple(pair(world, meta)))
    cut = clone_world(world); removed = []
    for q in (meta["a"], meta["b"], *delayed_source_positions(meta), *receiver_source_positions(meta)):
        removed.append({"q": list(q), "raw": int(cut.raw[q])}); clear(cut, q)
    intact_pairs = list(prefix); cut_pairs = list(prefix)
    for _ in range(CUT_TICK + 1, HORIZON + 1):
        world.tick(); cut.tick()
        intact_pairs.append(tuple(pair(world, meta))); cut_pairs.append(tuple(pair(cut, meta)))
    intact_start = constant_suffix_start(intact_pairs); cut_start = constant_suffix_start(cut_pairs)
    return {"target": target, "offset": list(OFFSET), "cut_tick": CUT_TICK,
            "intact_terminal_pair": list(intact_pairs[-1]), "cut_terminal_pair": list(cut_pairs[-1]),
            "cut_matches_intact_terminal": cut_pairs[-1] == intact_pairs[-1],
            "intact_constant_suffix_start": intact_start, "cut_constant_suffix_start": cut_start,
            "intact_terminal_constant_duration": HORIZON - intact_start + 1,
            "cut_terminal_constant_duration": HORIZON - cut_start + 1,
            "removed": removed, "python_interventions_after_t0": 1,
            "claim_guard": "Post-establishment removal is diagnostic; native selection before cut is host-free."}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target) for target in ("a", "b", None)]
    by = {str(row["target"]): row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.far_remote_latch.v1",
        "question": "Does native learning select a spatially non-overlapping far remote fixed point that then survives removal of master, bridge, and receiver sources?",
        "design": {"receiver_offset": list(OFFSET), "cut_tick": CUT_TICK, "horizon": HORIZON,
                   "master_reset_radius": 2, "receiver_basin_radius": 2,
                   "chebyshev_center_distance": max(map(abs, OFFSET)),
                   "minimum_gap_between_radius2_regions": max(map(abs, OFFSET)) - 4},
        "rows": rows,
        "summary": {"a_b_intact_terminal_distinct": by["a"]["intact_terminal_pair"] != by["b"]["intact_terminal_pair"],
                    "a_b_cut_terminal_distinct": by["a"]["cut_terminal_pair"] != by["b"]["cut_terminal_pair"],
                    "a_cut_matches_intact": by["a"]["cut_matches_intact_terminal"],
                    "b_cut_matches_intact": by["b"]["cut_matches_intact_terminal"],
                    "a_cut_fixed_128_plus": by["a"]["cut_terminal_constant_duration"] >= 128,
                    "b_cut_fixed_128_plus": by["b"]["cut_terminal_constant_duration"] >= 128,
                    "spatial_basin_overlap": False},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R14_FAR_REMOTE_LATCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
