#!/usr/bin/env python3
"""Master writability with the non-overlapping far latch, with and without reset."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair, receiver_source_positions
import run_dd_r02_remote_hold_master_reset as reset

OFFSET = (-6, 7, 8)
CUT_TICK = 512
HORIZON = 800


def run(kernel, mode, canonical):
    r10.OFFSET = OFFSET; reset.CUT_TICK = CUT_TICK
    expression = mode != "no_expression_control"
    world, meta = r10.build(kernel, "a", expression=expression)
    reference = None; reference_meta = None; selected = []
    if mode == "diagnostic_r2_reset":
        reference, reference_meta = r10.build(kernel, "a", expression=False)
        selected = sorted({add(meta["c"], d, 1, meta["n"]) for d in product(range(-2, 3), repeat=3)})
    previous = 0; transitions = []; writer = None; remote_at_cut = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if reference is not None: reference.tick()
        if tick == CUT_TICK:
            remote_at_cut = pair(world, meta)
            if mode == "diagnostic_r2_reset":
                for q in (*delayed_source_positions(meta), *receiver_source_positions(meta)): clear(world, q)
                reset.restore_nonlearning_fields(world, reference, meta, selected)
            writer = reset.install_writer(world, meta)
            if reference is not None: reset.install_writer(reference, reference_meta)
        elif tick > CUT_TICK and mode == "diagnostic_r2_reset":
            reset.restore_nonlearning_fields(world, reference, meta, selected)
        delta = delta_value(world, meta)
        if delta != previous: transitions.append({"tick": tick, "before": previous, "after": delta})
        previous = delta
    later = [event for event in transitions if event["tick"] > CUT_TICK]
    terminal = pair(world, meta)
    return {"mode": mode, "writer": writer, "transitions": transitions, "post_cut_transitions": later,
            "write_reopened": bool(later), "remote_pair_at_cut": remote_at_cut,
            "remote_terminal_pair": terminal, "remote_terminal_is_far_a": terminal == canonical,
            "python_interventions_after_t0": 1 if mode != "diagnostic_r2_reset" else HORIZON - CUT_TICK + 1,
            "claim_guard": "Writer insertion and reset are diagnostic; no branch establishes native RW3."}


def main():
    kernel, runtime = load_kernel(1)
    prior = json.loads((ROOT / "MECHANISM_SELECTION/ING03_DD_R14_FAR_REMOTE_LATCH.json").read_text(encoding="utf-8"))
    canonical = next(row["intact_terminal_pair"] for row in prior["rows"] if row["target"] == "a")
    modes = ("no_expression_control", "far_coupled", "diagnostic_r2_reset")
    rows = [run(kernel, mode, canonical) for mode in modes]
    by = {row["mode"]: row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.far_latch_master_reset.v1",
        "question": "Does spatially separating the latch remove write blocking, and can the known r2 reset restore writing without disturbing the far latch?",
        "design": {"receiver_offset": list(OFFSET), "cut_tick": CUT_TICK, "horizon": HORIZON,
                   "writer": "validated competent persistent writer", "reset_radius": 2},
        "rows": rows,
        "summary": {"positive_control_writes": by["no_expression_control"]["write_reopened"],
                    "far_coupled_writes_without_reset": by["far_coupled"]["write_reopened"],
                    "diagnostic_r2_reset_reopens": by["diagnostic_r2_reset"]["write_reopened"],
                    "far_latch_survives_reset": by["diagnostic_r2_reset"]["remote_terminal_is_far_a"]},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R15_FAR_LATCH_MASTER_RESET.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
