#!/usr/bin/env python3
"""Necessity of far-latch return traffic for maintained master nonwritability."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

OFFSET = (-6, 7, 8)
CUT_TICK = 512
HORIZON = 800


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def shell(center, n, radius):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)
                   if max(map(abs, d)) == radius})


def main():
    r10.OFFSET = OFFSET; reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    base, meta = r10.build(kernel, "a", expression=True)
    for _ in range(CUT_TICK): base.tick()
    prior = json.loads((ROOT / "MECHANISM_SELECTION/ING03_DD_R14_FAR_REMOTE_LATCH.json").read_text(encoding="utf-8"))
    canonical = next(row["intact_terminal_pair"] for row in prior["rows"] if row["target"] == "a")
    remote_shell = shell(meta["q_receiver"], meta["n"], 3)
    sham_center = add(meta["c"], (6, -7, -8), 1, meta["n"]); sham_shell = shell(sham_center, meta["n"], 3)
    specs = {
        "bridge_cut_only": ([], False),
        "bridge_cut_remote_pair_removed": ([meta["q_receiver"], meta["qp_receiver"]], False),
        "bridge_cut_remote_shell_barrier": (remote_shell, True),
        "bridge_cut_sham_shell_barrier": (sham_shell, True),
    }
    branches = []
    for name, (positions, held) in specs.items():
        world = clone_world(base)
        for q in delayed_source_positions(meta): clear(world, q)
        for q in positions: clear(world, q)
        writer = reset.install_writer(world, meta)
        branches.append({"name": name, "world": world, "positions": positions, "held": held,
                         "writer": writer, "previous": delta_value(world, meta), "transitions": [],
                         "samples": [{"tick": CUT_TICK, "pair": pair(world, meta)}]})
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        for branch in branches:
            branch["world"].tick()
            if branch["held"]:
                for q in branch["positions"]: clear(branch["world"], q)
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]: branch["transitions"].append({"tick": tick, "before": branch["previous"], "after": delta})
            branch["previous"] = delta
            if tick in (513, 514, 516, 520, 528, 576, 640, 724, 800): branch["samples"].append({"tick": tick, "pair": pair(branch["world"], meta)})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        rows.append({"variant": branch["name"], "cut_voxel_count": len(branch["positions"]),
                     "barrier_held": branch["held"], "post_cut_transitions": branch["transitions"],
                     "write_reopened": bool(branch["transitions"]), "remote_terminal_pair": terminal,
                     "remote_terminal_is_far_a": terminal == canonical, "samples": branch["samples"],
                     "python_interventions_after_t0": 1 + (HORIZON - CUT_TICK if branch["held"] else 0)})
    by = {row["variant"]: row for row in rows}
    result = seal({
        "schema": "dee.v27.ing03.delegation.feedback_route_cut.v1",
        "question": "Is continuing return traffic from the far self-maintained latch necessary for the master to remain nonwritable?",
        "design": {"receiver_offset": list(OFFSET), "cut_tick": CUT_TICK, "horizon": HORIZON,
                   "remote_barrier": "held-empty Chebyshev shell radius3", "sham_barrier": "same shell at reflected remote"},
        "rows": rows,
        "summary": {"bridge_cut_only_blocks": not by["bridge_cut_only"]["write_reopened"],
                    "remote_shell_reopens": by["bridge_cut_remote_shell_barrier"]["write_reopened"],
                    "remote_shell_preserves_latch": by["bridge_cut_remote_shell_barrier"]["remote_terminal_is_far_a"],
                    "sham_shell_reopens": by["bridge_cut_sham_shell_barrier"]["write_reopened"],
                    "pair_removal_reopens": by["bridge_cut_remote_pair_removed"]["write_reopened"]},
        "claim_guard": "Held shell barriers and pair removal are diagnostic interventions, not native decoupling.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DD_R16_FEEDBACK_ROUTE_CUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
