#!/usr/bin/env python3
"""Replace the persistent delayed bridge sources with finite semantic1 carriers."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, pack, seal, unpack_scalar, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start
from run_dd_r01_remote_dependency_map import delayed_source_positions, pair
from run_nature_n07_native_consequence_expression import delta_value

OFFSET = (-6, 7, 8)
HORIZON = 512


def make_finite(world, meta):
    records = []
    for q in delayed_source_positions(meta):
        old = unpack_scalar(world.raw[q])
        raw = pack(old["state"], old["sreg"], old["direction"], 1)
        world.raw_a[q] = raw; world.raw_b[q] = raw
        records.append({"q": list(q), "before_raw": old["raw"], "after_raw": int(raw), "direction": old["direction"]})
    return records


def run(kernel, target, finite):
    r10.OFFSET = OFFSET
    world, meta = r10.build(kernel, target, expression=True)
    modifications = make_finite(world, meta) if finite else []
    pairs = []; deltas = []
    for _ in range(HORIZON):
        world.tick(); pairs.append(tuple(pair(world, meta))); deltas.append(delta_value(world, meta))
    start = constant_suffix_start(pairs)
    source_terminal = [int(world.raw[q]) for q in delayed_source_positions(meta)]
    return {"target": target, "bridge": "finite_semantic1" if finite else "persistent_semantic4",
            "t0_modifications": modifications, "master_delta_terminal": deltas[-1],
            "terminal_pair": list(pairs[-1]), "terminal_constant_suffix_start": start,
            "terminal_constant_duration": HORIZON - start + 1,
            "bridge_source_terminal_raw": source_terminal,
            "all_original_bridge_sites_vacated": all(raw == 0 for raw in source_terminal),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target, finite) for finite in (False, True) for target in ("a", "b", None)]
    by = {(row["bridge"], str(row["target"])): row for row in rows}
    finite_a, finite_b = by[("finite_semantic1", "a")], by[("finite_semantic1", "b")]
    result = seal({
        "schema": "dee.v27.ing03.delegation.transient_handoff.v1",
        "question": "Can finite bridge carriers select distinct far remote fixed points without persistent bridge sources?",
        "design": {"receiver_offset": list(OFFSET), "horizon": HORIZON,
                   "change": "same t0 positions/states/s_reg/directions; semantic4 persistent sources replaced by semantic1 carriers"},
        "rows": rows,
        "summary": {"finite_a_b_terminal_distinct": finite_a["terminal_pair"] != finite_b["terminal_pair"],
                    "finite_a_fixed_128_plus": finite_a["terminal_constant_duration"] >= 128,
                    "finite_b_fixed_128_plus": finite_b["terminal_constant_duration"] >= 128,
                    "finite_original_sites_vacated_both": finite_a["all_original_bridge_sites_vacated"] and finite_b["all_original_bridge_sites_vacated"],
                    "finite_matches_persistent_a": finite_a["terminal_pair"] == by[("persistent_semantic4", "a")]["terminal_pair"],
                    "finite_matches_persistent_b": finite_b["terminal_pair"] == by[("persistent_semantic4", "b")]["terminal_pair"]},
        "claim_guard": "A one-shot finite handoff does not establish regeneration, recurrent handoff, or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DD_R17_TRANSIENT_HANDOFF.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
