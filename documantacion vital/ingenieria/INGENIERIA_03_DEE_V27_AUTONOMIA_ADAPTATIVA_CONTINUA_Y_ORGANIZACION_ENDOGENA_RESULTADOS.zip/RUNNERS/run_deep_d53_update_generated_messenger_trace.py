#!/usr/bin/env python3
"""Trace whether the native D32 update carrier survives beyond the master write.

This is a discovery microscope, not a learning claim.  The complete world is
constructed at t0 and Python only advances ticks and records every transient
voxel outside the fixed relational scaffold.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, read, seal, write_json
from native_consequence_buffer_v1 import SUPPORT, build_world


def _snapshot(world, excluded):
    records = []
    for row in np.argwhere(world.raw != 0):
        q = tuple(int(value) for value in row)
        if q in excluded:
            continue
        records.append({"q": list(q), "record": read(world.raw, q)})
    return records


def run_case(kernel, *, target_name, mode, horizon=48):
    world, metadata = build_world(
        kernel,
        n=29,
        origin=(8, 13, 11),
        target_name=target_name,
        memory_phase=255,
        distance=3,
        permutation=(0, 1, 2),
        signs=(1, 1, 1),
        mode=mode,
    )
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    fixed_master = {a, b}
    for center in (a, b):
        for offset in SUPPORT:
            fixed_master.add(add(center, offset, 1, metadata["n"]))
    previous_positions = set()
    trace = []
    first_write = None
    post_write_external = []
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if delta not in (None, 0) and first_write is None:
            first_write = tick
        snapshot = _snapshot(world, fixed_master)
        positions = {tuple(item["q"]) for item in snapshot}
        entries = {
            "tick": tick,
            "delta": delta,
            "external": snapshot,
            "born": [list(q) for q in sorted(positions - previous_positions)],
            "gone": [list(q) for q in sorted(previous_positions - positions)],
        }
        if tick <= 12 or tick in (16, 24, 32, 40, 48):
            trace.append(entries)
        if first_write is not None and tick >= first_write:
            post_write_external.extend(
                {"tick": tick, **item} for item in snapshot
            )
        previous_positions = positions
    return {
        "target_name": target_name,
        "mode": mode,
        "first_write": first_write,
        "post_write_external_event_count": len(post_write_external),
        "post_write_external_unique_states": sorted(
            {item["record"]["state"] for item in post_write_external}
        ),
        "post_write_external": post_write_external,
        "trace": trace,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [
        run_case(kernel, target_name=target, mode=mode)
        for target in ("a", "b")
        for mode in ("treatment", "missing_d1", "missing_d2", "wrong_cancel")
    ]
    treatments = [row for row in rows if row["mode"] == "treatment"]
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.update_generated_messenger_trace.v1",
        "question": "Does the generated consequence carrier persist outside the relational master after causing its write?",
        "apparatus": "Frozen D32 geometry; complete t0 world; exhaustive external-voxel census through tick 48.",
        "rows": rows,
        "summary": {
            "treatment_first_writes": {row["target_name"]: row["first_write"] for row in treatments},
            "treatment_post_write_external_events": {row["target_name"]: row["post_write_external_event_count"] for row in treatments},
            "treatment_post_write_external_states": {row["target_name"]: row["post_write_external_unique_states"] for row in treatments},
        },
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D53_UPDATE_GENERATED_MESSENGER_TRACE.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
