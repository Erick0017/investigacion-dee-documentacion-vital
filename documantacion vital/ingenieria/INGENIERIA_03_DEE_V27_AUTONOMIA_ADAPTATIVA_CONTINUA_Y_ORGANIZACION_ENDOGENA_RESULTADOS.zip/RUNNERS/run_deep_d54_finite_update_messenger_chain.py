#!/usr/bin/env python3
"""Test a finite three-update master -> messenger/action chain in one world.

Three proposal pairs are present at t0.  Each pair reduces after t0 into one
carrier, which approaches either side of the relational master, causes a write,
and continues to a fixed all-port action census.  No master probe is installed.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, transform, write_json
from native_consequence_buffer_v1 import SUPPORT


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap at {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def build(kernel, *, schedule, omitted=None, permutation=(0, 1, 2), signs=(1, 1, 1), n=67):
    tf = lambda v: transform(v, permutation, signs)
    a = (20, 30, 30)
    b = add(a, tf((9, 0, 0)), 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    for center, base in ((a, 1000), (b, 2000)):
        put(raw, clock, center, base, 100, semantic=1, phase=255)
        for index, offset in enumerate(SUPPORT):
            put(raw, clock, add(center, tf(offset), 1, n), base + 100 + index, 0, semantic=4, phase=31 + index)
    route = tf((0, 0, 1))
    d1, d2 = tf((1, 0, 1)), tf((-1, 0, 1))
    events = {name: add(center, tf((0, -1, 0)), 1, n) for name, center in (("a", a), ("b", b))}
    generators = []
    for index, (target_name, distance) in enumerate(schedule):
        event = events[target_name]
        generator = add(event, route, -int(distance), n)
        generators.append({"index": index, "target": target_name, "distance": int(distance), "q": list(generator)})
        if omitted == index:
            continue
        put(raw, clock, add(generator, d1, -1, n), 5000 + 10 * index + 1, 3, d1, 1, 0)
        put(raw, clock, add(generator, d2, -1, n), 5000 + 10 * index + 2, 3, d2, 1, 0)
    action_ports = {name: add(event, route, 10, n) for name, event in events.items()}
    return NativeWorld(kernel, raw, clock), {
        "n": n,
        "a": list(a),
        "b": list(b),
        "events": {key: list(value) for key, value in events.items()},
        "action_ports": {key: list(value) for key, value in action_ports.items()},
        "generators": generators,
        "schedule": [[name, int(distance)] for name, distance in schedule],
        "omitted": omitted,
        "permutation": list(permutation),
        "signs": list(signs),
    }


def execute(world, metadata, horizon=52):
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    ports = {key: tuple(value) for key, value in metadata["action_ports"].items()}
    deltas, arrivals = [], []
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        deltas.append(delta)
        for name, q in ports.items():
            record = read(world.raw, q)
            if record is not None and record["state"] == 1 and record["semantic"] == 1:
                arrivals.append({"tick": tick, "port": name, "q": list(q), "record": record, "delta": delta})
    transitions = []
    previous = deltas[0]
    for tick, value in enumerate(deltas[1:], 2):
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    return {
        **metadata,
        "horizon": int(horizon),
        "delta_trace": deltas,
        "delta_transitions": transitions,
        "action_arrivals": arrivals,
        "action_sequence": [item["port"] for item in arrivals],
        "master_write_count": len(transitions),
        "python_interventions_after_t0": 0,
    }


def run_case(kernel, **kwargs):
    world, metadata = build(kernel, **kwargs)
    return execute(world, metadata)


def main():
    kernel, runtime = load_kernel(1)
    schedules = [
        (("a", 3), ("b", 15), ("a", 27)),
        (("b", 3), ("a", 15), ("b", 27)),
    ]
    rows = []
    for schedule in schedules:
        rows.append(run_case(kernel, schedule=schedule))
        for omitted in range(3):
            rows.append(run_case(kernel, schedule=schedule, omitted=omitted))
    treatments = [row for row in rows if row["omitted"] is None]
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.finite_update_messenger_chain.v1",
        "question": "Can three t0-prebuilt native consequences successively write a hidden relational master and continue as spatially distinct functional messengers without probing that master?",
        "claim_guard": "Finite-stock discovery only; not RW4, RW5, learning, or autonomy.",
        "rows": rows,
        "summary": {
            "treatments": [{"schedule": row["schedule"], "write_count": row["master_write_count"], "action_sequence": row["action_sequence"], "transitions": row["delta_transitions"]} for row in treatments],
            "omission_controls": [{"schedule": row["schedule"], "omitted": row["omitted"], "write_count": row["master_write_count"], "action_sequence": row["action_sequence"]} for row in rows if row["omitted"] is not None],
        },
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D54_FINITE_UPDATE_MESSENGER_CHAIN.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
