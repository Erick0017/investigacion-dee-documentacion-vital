#!/usr/bin/env python3
"""Test RW1 with a persistent generated carrier and a hidden plastic master."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, read, seal, write_json
from persistent_generated_buffer_v1 import build_persistent_world


FRAMES = (
    ((0, 1, 2), (1, 1, 1)),
    ((2, 1, 0), (1, 1, 1)),
    ((1, 2, 0), (-1, 1, 1)),
    ((0, 2, 1), (1, -1, 1)),
)


def run_case(kernel, *, target_name, mode, permutation, signs, horizon=1024):
    world, metadata = build_persistent_world(
        kernel,
        n=41,
        origin=(13, 20, 17),
        target_name=target_name,
        memory_phase=255,
        distance=3,
        permutation=permutation,
        signs=signs,
        mode=mode,
    )
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    event, route = tuple(metadata["event"]), tuple(metadata["route"])
    offsets = (1, 5, 10, 17)
    ports = {str(offset): add(event, route, offset, metadata["n"]) for offset in offsets}
    arrivals = {str(offset): [] for offset in offsets}
    deltas = []
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        for key, q in ports.items():
            record = read(world.raw, q)
            if record is not None and record["state"] == 1 and record["semantic"] == 1 and tuple(record["direction"]) == route:
                arrivals[key].append(tick)
    transitions = []
    previous = deltas[0]
    for tick, value in enumerate(deltas[1:], 2):
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    first_arrivals = {key: (None if not ticks else ticks[0]) for key, ticks in arrivals.items()}
    post_output_transitions = sum(item["tick"] > min(value for value in first_arrivals.values() if value is not None) for item in transitions) if any(value is not None for value in first_arrivals.values()) else 0
    return {
        "target_name": target_name,
        "mode": mode,
        "permutation": list(permutation),
        "signs": list(signs),
        "route": list(route),
        "ports": {key: list(value) for key, value in ports.items()},
        "first_arrivals": first_arrivals,
        "arrival_counts": {key: len(value) for key, value in arrivals.items()},
        "delta_transitions": transitions,
        "post_output_master_transitions": post_output_transitions,
        "terminal_delta": deltas[-1],
        "source_raw_fixed": [int(world.raw[tuple(q)]) for q in metadata["persistent_source_positions"]] == metadata["persistent_source_initial_raw"],
        "rw1": all(value is not None for value in first_arrivals.values()) and post_output_transitions >= 1,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for permutation, signs in FRAMES:
        for target in ("a", "b"):
            rows.append(run_case(kernel, target_name=target, mode="treatment", permutation=permutation, signs=signs))
    for mode in ("missing_d1", "missing_d2", "wrong_cancel"):
        rows.append(run_case(kernel, target_name="a", mode=mode, permutation=FRAMES[0][0], signs=FRAMES[0][1]))
    treatments = [row for row in rows if row["mode"] == "treatment"]
    controls = [row for row in rows if row["mode"] != "treatment"]
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.recurrent_messenger_rw1.v1",
        "question": "Can recurrent native output carriers cross fixed spatial ports while the separate hidden relational master continues accepting writes?",
        "claim_guard": "RW1 primitive with configured persistent sources; not consequence-selected learning, RW2, or L4.",
        "rows": rows,
        "summary": {
            "treatments_passing_rw1": sum(row["rw1"] for row in treatments),
            "treatments": len(treatments),
            "frames": len(FRAMES),
            "control_arrival_counts": [{"mode": row["mode"], "arrival_counts": row["arrival_counts"], "transitions": len(row["delta_transitions"])} for row in controls],
            "distance_law": "first arrival = 1 + generator_to_event_distance(3) + event_to_port_offset",
        },
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D55_RECURRENT_MESSENGER_RW1.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
