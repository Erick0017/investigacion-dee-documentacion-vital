#!/usr/bin/env python3
"""Measure toroidal messenger lifetime and test causally distinct native sinks."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
from native_consequence_buffer_v1 import build_world


def install_sink(world, metadata, kind, port_offset=10):
    route, event, n = tuple(metadata["route"]), tuple(metadata["event"]), int(metadata["n"])
    port = add(event, route, port_offset, n)
    first_arrival = 1 + int(metadata["distance"]) + int(port_offset)
    positions = []
    if kind == "none":
        return port, positions
    if kind == "stationary_semantic1":
        q, value = port, pack(9001, 0, (0, 0, 0), 1)
    elif kind == "stationary_semantic4":
        q, value = port, pack(9002, 0, (0, 0, 0), 4)
    elif kind in {"finite_counter", "persistent_counter"}:
        # Initial carrier advances on tick 1, so distance=first_arrival places
        # it on the port at the same tick as the update-generated messenger.
        q = add(port, route, first_arrival, n)
        value = pack(9003, 6, tuple(-x for x in route), 4 if kind == "persistent_counter" else 1)
    else:
        raise ValueError(kind)
    if int(world.raw[q]):
        raise RuntimeError(f"sink overlap at {q}")
    world.raw_a[q] = value
    world.raw_b[q] = value
    positions.append(q)
    return port, positions


def run_case(kernel, *, target_name, sink_kind, horizon=256):
    world, metadata = build_world(
        kernel,
        n=41,
        origin=(13, 20, 17),
        target_name=target_name,
        memory_phase=255,
        distance=3,
        permutation=(0, 1, 2),
        signs=(1, 1, 1),
        mode="treatment",
    )
    port, sink_positions = install_sink(world, metadata, sink_kind)
    route, event, n = tuple(metadata["route"]), tuple(metadata["event"]), int(metadata["n"])
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    crossings, delta_transitions, port_trace = [], [], []
    previous_delta = 0
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if delta != previous_delta:
            delta_transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        previous_delta = delta
        record = read(world.raw, port)
        if record is not None:
            port_trace.append({"tick": tick, "record": record, "delta": delta})
            if record["state"] == 1 and record["semantic"] == 1 and tuple(record["direction"]) == route:
                crossings.append(tick)
    expected_first = 1 + int(metadata["distance"]) + 10
    expected_unsunk = list(range(expected_first, int(horizon) + 1, n))
    return {
        "target_name": target_name,
        "sink_kind": sink_kind,
        "port": list(port),
        "sink_positions": [list(q) for q in sink_positions],
        "horizon": int(horizon),
        "messenger_crossings": crossings,
        "expected_unsunk_crossings": expected_unsunk,
        "toroidal_return_count": max(0, len(crossings) - 1),
        "port_trace": port_trace,
        "delta_transitions": delta_transitions,
        "terminal_delta": previous_delta,
        "sink_raw_terminal": [int(world.raw[q]) for q in sink_positions],
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    kinds = ("none", "stationary_semantic1", "stationary_semantic4", "finite_counter", "persistent_counter")
    rows = [run_case(kernel, target_name=target, sink_kind=kind) for target in ("a", "b") for kind in kinds]
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.messenger_lifetime_sink.v1",
        "question": "Does a finite update-generated messenger recur on the torus, and can a native local interaction terminate it before stale return?",
        "rows": rows,
        "summary": [{"target": row["target_name"], "sink": row["sink_kind"], "crossings": row["messenger_crossings"], "returns": row["toroidal_return_count"], "terminal_delta": row["terminal_delta"]} for row in rows],
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D56_MESSENGER_LIFETIME_SINK.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
