#!/usr/bin/env python3
"""Build a reusable spatial transducer for update-generated messengers.

A persistent diagonal source intersects the +z messenger train at a remote
port.  Vector reduction should emit a transverse +y carrier.  This consumes
the incoming message trajectory without sending a counter-carrier back toward
the hidden master.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, transform, write_json
from persistent_generated_buffer_v1 import build_persistent_world


def install_transducer(world, metadata, *, mode, port_offset=10, action_offsets=(1, 5, 9)):
    tf = lambda v: transform(v, tuple(metadata["permutation"]), tuple(metadata["signs"]))
    event, route, n = tuple(metadata["event"]), tuple(metadata["route"]), int(metadata["n"])
    port = add(event, route, port_offset, n)
    sink_direction = tf((0, 1, -1)) if mode != "sham_sink" else tf((0, -1, -1))
    action_direction = tf((0, 1, 0)) if mode != "sham_sink" else tf((0, -1, 0))
    first_arrival = 1 + int(metadata["distance"]) + int(port_offset)
    source = add(port, sink_direction, -first_arrival, n)
    source_raw = None
    if mode != "no_sink":
        if int(world.raw[source]):
            raise RuntimeError(f"transducer overlap at {source}")
        source_raw = pack(9100, 6, sink_direction, 4)
        world.raw_a[source] = source_raw
        world.raw_b[source] = source_raw
    action_ports = {str(offset): add(port, action_direction, offset, n) for offset in action_offsets}
    reverse_port = add(port, tuple(-x for x in action_direction), 5, n)
    return {
        "port": port,
        "source": source,
        "source_initial_raw": None if source_raw is None else int(source_raw),
        "sink_direction": sink_direction,
        "action_direction": action_direction,
        "action_ports": action_ports,
        "reverse_port": reverse_port,
        "first_message_arrival": first_arrival,
    }


def run_case(
    kernel,
    *,
    target_name,
    mode="treatment",
    permutation=(0, 1, 2),
    signs=(1, 1, 1),
    n=41,
    origin=(13, 20, 17),
    port_offset=10,
    action_offsets=(1, 5, 9),
    horizon=1024,
):
    writer_mode = mode if mode in {"missing_d1", "missing_d2", "wrong_cancel"} else "treatment"
    world, metadata = build_persistent_world(
        kernel,
        n=n,
        origin=origin,
        target_name=target_name,
        memory_phase=255,
        distance=3,
        permutation=permutation,
        signs=signs,
        mode=writer_mode,
    )
    transducer = install_transducer(world, metadata, mode=mode, port_offset=port_offset, action_offsets=action_offsets)
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    action_direction = tuple(transducer["action_direction"])
    action_arrivals = {key: [] for key in transducer["action_ports"]}
    reverse_arrivals, original_message_after_port = [], []
    deltas = []
    after_original = add(transducer["port"], tuple(metadata["route"]), 1, metadata["n"])
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        for key, q in transducer["action_ports"].items():
            record = read(world.raw, q)
            if record is not None and record["state"] == 1 and tuple(record["direction"]) == action_direction:
                action_arrivals[key].append(tick)
        record = read(world.raw, transducer["reverse_port"])
        if record is not None and record["state"] == 1:
            reverse_arrivals.append({"tick": tick, "record": record})
        record = read(world.raw, after_original)
        if record is not None and record["state"] == 1 and tuple(record["direction"]) == tuple(metadata["route"]):
            original_message_after_port.append(tick)
    transitions = []
    previous = deltas[0]
    for tick, value in enumerate(deltas[1:], 2):
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    first_action = min((ticks[0] for ticks in action_arrivals.values() if ticks), default=None)
    return {
        "target_name": target_name,
        "mode": mode,
        "permutation": list(permutation),
        "signs": list(signs),
        "n": int(n),
        "origin": list(origin),
        "port_offset": int(port_offset),
        "action_offsets": list(action_offsets),
        "messenger_route": metadata["route"],
        "transducer_port": list(transducer["port"]),
        "transducer_source": list(transducer["source"]),
        "sink_direction": list(transducer["sink_direction"]),
        "action_direction": list(action_direction),
        "action_ports": {key: list(value) for key, value in transducer["action_ports"].items()},
        "action_arrival_counts": {key: len(value) for key, value in action_arrivals.items()},
        "first_action": first_action,
        "original_message_after_port_count": len(original_message_after_port),
        "reverse_arrival_count": len(reverse_arrivals),
        "master_transitions": transitions,
        "post_action_master_transitions": sum(item["tick"] > first_action for item in transitions) if first_action is not None else 0,
        "terminal_delta": deltas[-1],
        "writer_sources_fixed": [int(world.raw[tuple(q)]) for q in metadata["persistent_source_positions"]] == metadata["persistent_source_initial_raw"],
        "transducer_source_fixed": transducer["source_initial_raw"] is None or int(world.raw[transducer["source"]]) == transducer["source_initial_raw"],
        "rw1_transduced": first_action is not None and len(original_message_after_port) == 0 and sum(item["tick"] > first_action for item in transitions) >= 1,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run_case(kernel, target_name=target, mode="treatment") for target in ("a", "b")]
    rows.extend(run_case(kernel, target_name="a", mode=mode) for mode in ("no_sink", "sham_sink", "missing_d1", "missing_d2", "wrong_cancel"))
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.reusable_spatial_executor.v1",
        "question": "Can a persistent remote transducer repeatedly convert master-writing messengers into transverse action carriers, suppress stale return, and leave the master writable?",
        "claim_guard": "Configured-source reusable transduction; not consequence-selected learning or L4.",
        "rows": rows,
        "summary": [{"target": row["target_name"], "mode": row["mode"], "first_action": row["first_action"], "actions": row["action_arrival_counts"], "passed": row["rw1_transduced"], "post_action_master_transitions": row["post_action_master_transitions"], "original_after_port": row["original_message_after_port_count"]} for row in rows],
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D57_REUSABLE_SPATIAL_EXECUTOR.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
