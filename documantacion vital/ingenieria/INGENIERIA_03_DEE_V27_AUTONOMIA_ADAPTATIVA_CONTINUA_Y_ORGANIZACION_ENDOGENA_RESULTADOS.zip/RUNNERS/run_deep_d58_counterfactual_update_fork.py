#!/usr/bin/env python3
"""Paired one-shot update-fork worlds with byte-identical learner substates."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, canonical_hash, full_sha, load_kernel, pack, read, seal, transform, write_json
from native_consequence_buffer_v1 import SUPPORT


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap at {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def construct(
    kernel,
    *,
    target_name,
    mode="treatment",
    n=41,
    origin=(13, 20, 17),
    permutation=(0, 1, 2),
    signs=(1, 1, 1),
    port_offset=10,
    action_offset=5,
    transducer_shift=(0, 0, 0),
):
    tf = lambda v: transform(v, permutation, signs)
    a = tuple(int(value) % n for value in origin)
    b = add(a, tf((9, 0, 0)), 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    master_positions = []
    if mode != "no_master":
        for center, base in ((a, 1000), (b, 2000)):
            put(raw, clock, center, base, 100, semantic=1, phase=255); master_positions.append(center)
            for index, offset in enumerate(SUPPORT):
                q = add(center, tf(offset), 1, n)
                put(raw, clock, q, base + 100 + index, 0, semantic=4, phase=31 + index); master_positions.append(q)
    route = tf((0, 0, 1))
    d1, d2 = tf((1, 0, 1)), tf((-1, 0, 1))
    action_direction = tf((0, 1, 0))
    sink_direction = tf((0, 1, -1))
    events = {name: add(center, tf((0, -1, 0)), 1, n) for name, center in (("a", a), ("b", b))}
    transducer_sources, transducer_ports, action_ports = {}, {}, {}
    for name, event in events.items():
        port = add(event, route, int(port_offset), n)
        source_distance = 1 + 3 + int(port_offset) + (1 if mode == "phase_miss" else 0)
        source = add(add(port, sink_direction, -source_distance, n), tf(transducer_shift), 1, n)
        transducer_ports[name] = port
        transducer_sources[name] = source
        action_ports[name] = add(port, action_direction, int(action_offset), n)
        if mode != "no_transducer":
            put(raw, clock, source, 9100 + (name == "b"), 6, sink_direction, 4, 0)
    # Everything built so far is the learner/action machinery.  It is exactly
    # identical for paired A/B treatment worlds.
    learner_hash = full_sha(raw, clock)
    learner_raw_hash = hashlib.sha256(np.ascontiguousarray(raw).tobytes()).hexdigest()
    learner_clock_hash = hashlib.sha256(np.ascontiguousarray(clock).tobytes()).hexdigest()
    environment_positions = []
    if mode not in {"no_consequence"}:
        event = events[target_name]
        generator = add(event, route, -3, n)
        specs = ((add(generator, d1, -1, n), 5001, d1), (add(generator, d2, -1, n), 5002, d2))
        for index, (q, state, direction) in enumerate(specs):
            if mode == "missing_d1" and index == 0:
                continue
            if mode == "missing_d2" and index == 1:
                continue
            actual = d1 if mode == "wrong_cancel" and index == 1 else direction
            put(raw, clock, q, state, 3, actual, 1, 0)
            environment_positions.append(q)
    environment_record = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in environment_positions]
    return NativeWorld(kernel, raw, clock), {
        "n": n,
        "a": a,
        "b": b,
        "target_name": target_name,
        "mode": mode,
        "permutation": list(permutation),
        "signs": list(signs),
        "port_offset": int(port_offset),
        "action_offset": int(action_offset),
        "transducer_shift": list(transducer_shift),
        "route": route,
        "action_direction": action_direction,
        "events": events,
        "transducer_sources": transducer_sources,
        "transducer_ports": transducer_ports,
        "action_ports": action_ports,
        "learner_full_sha256": learner_hash,
        "learner_raw_sha256": learner_raw_hash,
        "learner_clock_sha256": learner_clock_hash,
        "environment_sha256": canonical_hash(environment_record),
        "environment_positions": environment_positions,
        "master_positions": master_positions,
        "initial_world_sha256": full_sha(raw, clock),
    }


def execute(world, metadata, horizon=64):
    a, b = metadata["a"], metadata["b"]
    action_direction = tuple(metadata["action_direction"])
    arrivals = {name: [] for name in metadata["action_ports"]}
    deltas = []
    for tick in range(1, int(horizon) + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        for name, q in metadata["action_ports"].items():
            record = read(world.raw, q)
            if record is not None and record["state"] == 1 and tuple(record["direction"]) == action_direction:
                arrivals[name].append({"tick": tick, "record": record})
    first_write = next((tick for tick, value in enumerate(deltas, 1) if value not in (None, 0)), None)
    action_sequence = [name for tick in range(1, int(horizon) + 1) for name in sorted(arrivals) if any(item["tick"] == tick for item in arrivals[name])]
    first_action = min((item["tick"] for items in arrivals.values() for item in items), default=None)
    return {
        "target_name": metadata["target_name"],
        "mode": metadata["mode"],
        "n": metadata["n"],
        "permutation": metadata["permutation"],
        "signs": metadata["signs"],
        "port_offset": metadata["port_offset"],
        "action_offset": metadata["action_offset"],
        "transducer_shift": metadata["transducer_shift"],
        "learner_full_sha256": metadata["learner_full_sha256"],
        "learner_raw_sha256": metadata["learner_raw_sha256"],
        "learner_clock_sha256": metadata["learner_clock_sha256"],
        "environment_sha256": metadata["environment_sha256"],
        "initial_world_sha256": metadata["initial_world_sha256"],
        "first_write": first_write,
        "first_action": first_action,
        "action_sequence": action_sequence,
        "action_counts": {name: len(items) for name, items in arrivals.items()},
        "terminal_delta": deltas[-1],
        "write_precedes_action": first_write is not None and first_action is not None and first_write < first_action,
        "target_action_only": action_sequence == [metadata["target_name"]],
        "python_interventions_after_t0": 0,
    }


def run_case(kernel, **kwargs):
    world, metadata = construct(kernel, **kwargs)
    return execute(world, metadata)


def main():
    kernel, runtime = load_kernel(1)
    treatments = [run_case(kernel, target_name=target) for target in ("a", "b")]
    controls = [run_case(kernel, target_name="a", mode=mode) for mode in ("no_master", "no_transducer", "phase_miss", "no_consequence", "missing_d1", "missing_d2", "wrong_cancel")]
    learner_equal = len({row["learner_full_sha256"] for row in treatments}) == 1
    environment_differs = len({row["environment_sha256"] for row in treatments}) == 2
    no_master = next(row for row in controls if row["mode"] == "no_master")
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.counterfactual_update_fork.v1",
        "question": "With byte-identical learner/action machinery, can opposite environmental consequences write opposite master states and emit opposite spatial actions after the write?",
        "causal_question": "Does output depend on the stored master, or is it a parallel branch of the same update event?",
        "treatments": treatments,
        "controls": controls,
        "summary": {
            "paired_learner_hash_equal": learner_equal,
            "paired_environment_hashes_differ": environment_differs,
            "treatments_write_before_target_action": all(row["write_precedes_action"] and row["target_action_only"] for row in treatments),
            "treatment_results": [{"target": row["target_name"], "write": row["first_write"], "action": row["first_action"], "sequence": row["action_sequence"], "delta": row["terminal_delta"]} for row in treatments],
            "master_ablation_preserves_action": no_master["action_sequence"] == treatments[0]["action_sequence"] and no_master["first_action"] == treatments[0]["first_action"],
            "interpretation": "The consequence has a native common-cause fork: one branch writes the master and another becomes a remote action messenger. The output is not read from the stored master; master ablation leaves it intact.",
        },
        "claim_guard": "Consequence-conditioned update fork, not master-mediated policy readout, RW3, or L4.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D58_COUNTERFACTUAL_UPDATE_FORK.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
