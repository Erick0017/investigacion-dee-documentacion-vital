#!/usr/bin/env python3
"""Model-selection panel for the one-shot counterfactual update fork."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_deep_d58_counterfactual_update_fork import run_case


SPECS = (
    {"n": 31, "origin": (9, 15, 13), "permutation": (0, 1, 2), "signs": (1, 1, 1)},
    {"n": 37, "origin": (11, 18, 15), "permutation": (2, 1, 0), "signs": (1, 1, 1)},
    {"n": 41, "origin": (13, 20, 17), "permutation": (1, 2, 0), "signs": (-1, 1, 1)},
    {"n": 43, "origin": (15, 19, 21), "permutation": (0, 2, 1), "signs": (1, -1, 1)},
    {"n": 47, "origin": (17, 23, 19), "permutation": (2, 0, 1), "signs": (1, 1, -1)},
    {"n": 53, "origin": (19, 25, 23), "permutation": (1, 0, 2), "signs": (-1, -1, 1)},
)


def main():
    kernel, runtime = load_kernel(1)
    groups = []
    for index, spec in enumerate(SPECS):
        pair = [run_case(kernel, target_name=target, **spec) for target in ("a", "b")]
        controls = {mode: run_case(kernel, target_name="a", mode=mode, **spec) for mode in ("no_consequence", "no_transducer", "no_master", "missing_d1")}
        passed = (
            len({row["learner_full_sha256"] for row in pair}) == 1
            and len({row["environment_sha256"] for row in pair}) == 2
            and all(row["write_precedes_action"] and row["target_action_only"] for row in pair)
            and controls["no_consequence"]["first_write"] is None
            and controls["no_consequence"]["first_action"] is None
            and controls["no_transducer"]["first_write"] is not None
            and controls["no_transducer"]["first_action"] is None
            and controls["missing_d1"]["first_write"] is None
            and controls["missing_d1"]["first_action"] is None
            and controls["no_master"]["first_write"] is None
            and controls["no_master"]["action_sequence"] == pair[0]["action_sequence"]
        )
        groups.append({"group": index, "spec": spec, "pair": pair, "controls": controls, "passed": passed})
    result = seal({
        "schema": "dee.v27.ing03.deep.model_selection.update_fork.v1",
        "question": "Does the update-fork mechanism and its master-independence survive fresh geometry classes before freeze?",
        "groups": groups,
        "summary": {
            "groups_passed": sum(group["passed"] for group in groups),
            "groups": len(groups),
            "n_values": [spec["n"] for spec in SPECS],
            "permutations": [list(spec["permutation"]) for spec in SPECS],
            "signed_frames": [list(spec["signs"]) for spec in SPECS],
            "causal_class": "UPDATE_EVENT_COMMON_CAUSE_FORK_NOT_MASTER_READOUT",
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DEEP_D59_UPDATE_FORK_MODEL_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
