#!/usr/bin/env python3
"""Adversarial spatial controls for the update-fork transducer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_deep_d58_counterfactual_update_fork import run_case


def main():
    kernel, runtime = load_kernel(1)
    distances = []
    for port_offset, action_offset in ((4, 2), (7, 4), (10, 5), (13, 7), (16, 9)):
        row = run_case(kernel, target_name="a", n=47, origin=(15, 23, 19), port_offset=port_offset, action_offset=action_offset)
        expected = 1 + 3 + port_offset + action_offset
        distances.append({"port_offset": port_offset, "action_offset": action_offset, "expected_first_action": expected, "row": row, "passed": row["first_action"] == expected and row["first_write"] == 6})
    shifted = []
    for shift in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, 0, 1)):
        row = run_case(kernel, target_name="a", n=47, origin=(15, 23, 19), transducer_shift=shift)
        shifted.append({"shift": list(shift), "row": row, "passed": row["first_write"] == 6 and row["first_action"] is None})
    frames = []
    for permutation, signs in (((0, 1, 2), (1, 1, 1)), ((2, 0, 1), (-1, 1, 1)), ((1, 2, 0), (1, -1, -1))):
        pair = [run_case(kernel, target_name=target, n=47, origin=(15, 23, 19), permutation=permutation, signs=signs) for target in ("a", "b")]
        frames.append({"permutation": list(permutation), "signs": list(signs), "pair": pair, "passed": len({row["learner_full_sha256"] for row in pair}) == 1 and all(row["target_action_only"] for row in pair)})
    result = seal({
        "schema": "dee.v27.ing03.deep.adversarial.spatial_update_fork.v1",
        "question": "Does action latency follow route length, and does breaking the 3D collision geometry abolish transfer without abolishing the master write?",
        "distance_panel": distances,
        "shifted_transducer_canaries": shifted,
        "frame_panel": frames,
        "summary": {
            "distance_cases_passed": sum(row["passed"] for row in distances),
            "distance_cases": len(distances),
            "shift_canaries_passed": sum(row["passed"] for row in shifted),
            "shift_canaries": len(shifted),
            "frame_groups_passed": sum(row["passed"] for row in frames),
            "frame_groups": len(frames),
            "latency_law": "first_action = 1 + generator_to_event(3) + port_offset + action_offset",
        },
        "runtime": runtime,
    })
    output = ROOT / "ADVERSARIAL_CHALLENGE/ING03_DEEP_D60_SPATIAL_ADVERSARIAL.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
