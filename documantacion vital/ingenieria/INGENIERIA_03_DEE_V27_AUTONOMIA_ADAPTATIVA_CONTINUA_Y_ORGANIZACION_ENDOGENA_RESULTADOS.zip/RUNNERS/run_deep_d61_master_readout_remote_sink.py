#!/usr/bin/env python3
"""Test whether remote absorption of delta-dependent trajectories restores writing."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
from run_ext_d17_trajectory_probe_search import build, dval


PROBE = {"target": "c", "direction": [0, 1, 0], "distance": 3, "sreg": 7, "phase": 0}
RAYS = ((-1, -1, 0), (0, -1, 0), (1, -1, 0), (0, 1, 0))


def install_sinks(world, ports, distance=5):
    positions = []
    for index, direction in enumerate(RAYS):
        q = add(ports["c"], direction, distance, world.n)
        if int(world.raw[q]):
            raise RuntimeError(f"sink overlap at {q}")
        value = pack(9200 + index, 0, (0, 0, 0), 4)
        world.raw_a[q] = value
        world.raw_b[q] = value
        positions.append(q)
    return positions


def run_case(kernel, *, delta, with_probe, with_sinks, horizon=1024):
    world, ports = build(kernel, delta, PROBE if with_probe else None, n=23)
    sinks = install_sinks(world, ports) if with_sinks else []
    deltas, sink_initial = [], [int(world.raw[q]) for q in sinks]
    beyond_events = 0
    for _ in range(int(horizon)):
        world.tick()
        deltas.append(dval(world, ports))
        for direction in RAYS:
            q = add(ports["c"], direction, 6, world.n)
            record = read(world.raw, q)
            if record is not None and record["state"] == 1:
                beyond_events += 1
    transitions = sum(deltas[index] != deltas[index - 1] for index in range(16, len(deltas)))
    return {
        "delta_initial": delta,
        "with_probe": with_probe,
        "with_sinks": with_sinks,
        "post16_delta_transitions": transitions,
        "terminal_delta": deltas[-1],
        "sink_positions": [list(q) for q in sinks],
        "sinks_fixed": [int(world.raw[q]) for q in sinks] == sink_initial,
        "downstream_beyond_sink_events": beyond_events,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for delta in (-8, 0, 8):
        rows.append(run_case(kernel, delta=delta, with_probe=True, with_sinks=True))
        rows.append(run_case(kernel, delta=delta, with_probe=True, with_sinks=False))
        rows.append(run_case(kernel, delta=delta, with_probe=False, with_sinks=True))
    treatments = [row for row in rows if row["with_probe"] and row["with_sinks"]]
    baselines = [row for row in rows if not row["with_probe"] and row["with_sinks"]]
    result = seal({
        "schema": "dee.v27.ing03.deep.discovery.master_readout_remote_sink.v1",
        "question": "If all three known delta-class trajectories are absorbed remotely before toroidal return, does the hidden master regain future writability?",
        "rows": rows,
        "summary": {
            "absorbed_readout_transition_counts": [row["post16_delta_transitions"] for row in treatments],
            "sink_only_baseline_transition_counts": [row["post16_delta_transitions"] for row in baselines],
            "remote_absorption_restored_writing": all(row["post16_delta_transitions"] >= 1 for row in treatments),
            "interpretation": "A negative result locates persistent backaction at/near the read interface rather than in later toroidal return of the classified trajectory.",
        },
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_DEEP_D61_MASTER_READOUT_REMOTE_SINK.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
