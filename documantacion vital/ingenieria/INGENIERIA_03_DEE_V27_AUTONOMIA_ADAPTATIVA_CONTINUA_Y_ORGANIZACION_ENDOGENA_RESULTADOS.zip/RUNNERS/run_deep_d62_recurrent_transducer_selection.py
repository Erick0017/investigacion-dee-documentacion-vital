#!/usr/bin/env python3
"""Model-selection panel for the configured recurrent messenger transducer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_deep_d57_reusable_spatial_executor import run_case


SPECS = (
    {"n": 31, "origin": (9, 15, 13), "port_offset": 7, "action_offsets": (1, 3, 6), "permutation": (0, 1, 2), "signs": (1, 1, 1)},
    {"n": 37, "origin": (11, 18, 15), "port_offset": 9, "action_offsets": (1, 4, 7), "permutation": (2, 1, 0), "signs": (-1, 1, 1)},
    {"n": 43, "origin": (15, 19, 21), "port_offset": 12, "action_offsets": (2, 5, 9), "permutation": (1, 2, 0), "signs": (1, -1, 1)},
    {"n": 47, "origin": (17, 23, 19), "port_offset": 15, "action_offsets": (1, 6, 10), "permutation": (0, 2, 1), "signs": (1, 1, -1)},
)


def expected_counts(spec, horizon=1024):
    first_collision = 1 + 3 + spec["port_offset"]
    return {str(offset): (horizon - (first_collision + offset)) // 2 + 1 for offset in spec["action_offsets"]}


def main():
    kernel, runtime = load_kernel(1)
    groups = []
    for index, spec in enumerate(SPECS):
        pair = [run_case(kernel, target_name=target, **spec) for target in ("a", "b")]
        controls = {mode: run_case(kernel, target_name="a", mode=mode, **spec) for mode in ("no_sink", "missing_d1", "wrong_cancel")}
        expected = expected_counts(spec)
        passed = (
            all(row["rw1_transduced"] and row["action_arrival_counts"] == expected and row["post_action_master_transitions"] == 6 and row["original_message_after_port_count"] == 0 for row in pair)
            and controls["no_sink"]["first_action"] is None
            and controls["no_sink"]["original_message_after_port_count"] > 0
            and controls["missing_d1"]["first_action"] is None
            and not controls["missing_d1"]["master_transitions"]
            and controls["wrong_cancel"]["first_action"] is None
            and not controls["wrong_cancel"]["master_transitions"]
        )
        groups.append({"group": index, "spec": spec, "expected_action_counts": expected, "pair": pair, "controls": controls, "passed": passed})
    result = seal({
        "schema": "dee.v27.ing03.deep.model_selection.recurrent_transducer.v1",
        "question": "Does reusable messenger transduction preserve exact cadence and later master plasticity across geometry classes?",
        "groups": groups,
        "summary": {"groups_passed": sum(group["passed"] for group in groups), "groups": len(groups), "horizon": 1024, "configured_not_learned": True},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DEEP_D62_RECURRENT_TRANSDUCER_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
