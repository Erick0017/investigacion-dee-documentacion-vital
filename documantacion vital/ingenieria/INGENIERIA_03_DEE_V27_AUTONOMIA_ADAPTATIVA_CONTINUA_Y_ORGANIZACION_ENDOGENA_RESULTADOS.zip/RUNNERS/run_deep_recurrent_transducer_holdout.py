#!/usr/bin/env python3
"""Run the frozen configured recurrent transducer holdout."""
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,sha256_file,write_json
from run_deep_d57_reusable_spatial_executor import run_case

def expected(spec):
    collision=1+3+int(spec["port_offset"])
    return {str(x):(1024-(collision+int(x)))//2+1 for x in spec["action_offsets"]}

def main():
    lp=ROOT/"FREEZE/ING03_DEEP_RECURRENT_TRANSDUCER_LOCK.json";cp=ROOT/"HOLDOUT/ING03_DEEP_RECURRENT_TRANSDUCER_CHALLENGES.json"
    lock=json.loads(lp.read_text(encoding="utf-8"));ch=json.loads(cp.read_text(encoding="utf-8"))
    if sha256_file(ROOT/lock["apparatus"]["path"])!=lock["apparatus"]["sha256"]:raise RuntimeError("apparatus changed")
    if ch["freeze_lock"]["sha256"]!=sha256_file(lp):raise RuntimeError("freeze mismatch")
    kernel,runtime=load_kernel(1);groups=[]
    for spec0 in ch["challenges"]:
        spec={k:spec0[k] for k in ("n","origin","permutation","signs","port_offset","action_offsets")};want=expected(spec)
        pair=[run_case(kernel,target_name=t,**spec) for t in ("a","b")]
        no_sink=run_case(kernel,target_name="a",mode="no_sink",**spec);missing=run_case(kernel,target_name="a",mode="missing_d1",**spec);wrong=run_case(kernel,target_name="a",mode="wrong_cancel",**spec)
        checks={
            "treatments":all(r["rw1_transduced"] and r["action_arrival_counts"]==want and r["post_action_master_transitions"]==6 and r["original_message_after_port_count"]==0 and r["writer_sources_fixed"] and r["transducer_source_fixed"] for r in pair),
            "target_signs":pair[0]["terminal_delta"]==-4 and pair[1]["terminal_delta"]==4,
            "no_sink":no_sink["first_action"] is None and no_sink["original_message_after_port_count"]>0 and len(no_sink["master_transitions"])==6,
            "missing":missing["first_action"] is None and not missing["master_transitions"],
            "wrong":wrong["first_action"] is None and not wrong["master_transitions"],
        }
        groups.append({"challenge":spec0,"expected_action_counts":want,"pair":pair,"controls":{"no_sink":no_sink,"missing_d1":missing,"wrong_cancel":wrong},"checks":checks,"passed":all(checks.values())})
    result=seal({"schema":"dee.v27.ing03.deep.holdout.recurrent_transducer_results.v1","phase":"FRESH_HOLDOUT","freeze_lock_sha256":sha256_file(lp),"challenge_file_sha256":sha256_file(cp),"groups":groups,"summary":{"groups_passed":sum(g["passed"] for g in groups),"groups":len(groups),"worlds_executed":len(groups)*5,"all_passed":all(g["passed"] for g in groups),"no_post_freeze_tuning":True},"python_interventions_after_t0":0,"runtime":runtime})
    out=ROOT/"HOLDOUT/ING03_DEEP_RECURRENT_TRANSDUCER_HOLDOUT.json";write_json(out,result)
    print(json.dumps({"output":str(out),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
