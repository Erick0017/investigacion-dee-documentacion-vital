#!/usr/bin/env python3
"""Execute the frozen update-fork fresh holdout without tuning."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
from run_deep_d58_counterfactual_update_fork import run_case


def main():
    lock_path = ROOT / "FREEZE/ING03_DEEP_UPDATE_FORK_LOCK.json"
    challenge_path = ROOT / "HOLDOUT/ING03_DEEP_UPDATE_FORK_CHALLENGES.json"
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    challenges = json.loads(challenge_path.read_text(encoding="utf-8"))
    if sha256_file(ROOT / lock["apparatus"]["path"]) != lock["apparatus"]["sha256"]:
        raise RuntimeError("frozen apparatus changed")
    if challenges["freeze_lock"]["sha256"] != sha256_file(lock_path):
        raise RuntimeError("challenge/freeze mismatch")
    kernel, runtime = load_kernel(1)
    groups = []
    for challenge in challenges["challenges"]:
        spec = {key: challenge[key] for key in ("n", "origin", "permutation", "signs", "port_offset", "action_offset")}
        pair = [run_case(kernel, target_name=target, **spec) for target in ("a", "b")]
        no_consequence = run_case(kernel, target_name="a", mode="no_consequence", **spec)
        no_transducer = run_case(kernel, target_name="a", mode="no_transducer", **spec)
        no_master = run_case(kernel, target_name="a", mode="no_master", **spec)
        shifted = run_case(kernel, target_name="a", transducer_shift=(1, 0, 0), **spec)
        expected_action = 1 + 3 + int(spec["port_offset"]) + int(spec["action_offset"])
        checks = {
            "learner_equal": len({row["learner_full_sha256"] for row in pair}) == 1,
            "environment_differs": len({row["environment_sha256"] for row in pair}) == 2,
            "a_treatment": pair[0]["first_write"] == 6 and pair[0]["terminal_delta"] == 1 and pair[0]["first_action"] == expected_action and pair[0]["action_sequence"] == ["a"],
            "b_treatment": pair[1]["first_write"] == 6 and pair[1]["terminal_delta"] == -1 and pair[1]["first_action"] == expected_action and pair[1]["action_sequence"] == ["b"],
            "no_consequence": no_consequence["first_write"] is None and no_consequence["first_action"] is None,
            "no_transducer": no_transducer["first_write"] == 6 and no_transducer["first_action"] is None,
            "no_master": no_master["first_write"] is None and no_master["first_action"] == expected_action and no_master["action_sequence"] == ["a"],
            "shifted_transducer": shifted["first_write"] == 6 and shifted["first_action"] is None,
        }
        groups.append({"challenge": challenge, "pair": pair, "controls": {"no_consequence": no_consequence, "no_transducer": no_transducer, "no_master": no_master, "shifted_transducer": shifted}, "checks": checks, "passed": all(checks.values())})
    result = seal({
        "schema": "dee.v27.ing03.deep.holdout.update_fork_results.v1",
        "phase": "FRESH_HOLDOUT",
        "freeze_lock_sha256": sha256_file(lock_path),
        "challenge_file_sha256": sha256_file(challenge_path),
        "groups": groups,
        "summary": {
            "groups_passed": sum(group["passed"] for group in groups),
            "groups": len(groups),
            "worlds_executed": len(groups) * 6,
            "all_passed": all(group["passed"] for group in groups),
            "no_post_freeze_tuning": True,
            "causal_verdict": "fresh-confirmed update-event fork; fresh-confirmed absence of master-to-output dependence",
        },
        "python_interventions_after_t0": 0,
        "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_DEEP_UPDATE_FORK_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
