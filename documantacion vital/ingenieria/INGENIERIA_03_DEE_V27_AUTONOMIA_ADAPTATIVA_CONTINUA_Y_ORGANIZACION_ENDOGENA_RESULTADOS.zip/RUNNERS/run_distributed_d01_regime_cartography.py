#!/usr/bin/env python3
"""Lossless-mask cartography of matched A/B/SHAM/PLASTIC late responses."""
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter, deque
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 192
OFFSET = (-6, 7, 8)
CHECKPOINTS = set(range(1, 13)) | {16, 24, 32, 48, 64, 96, 128, 160, 192}
REGIMES = {
    "A": {"target": "a", "expression": True},
    "B": {"target": "b", "expression": True},
    "SHAM": {"target": None, "expression": True},
    "PLASTIC": {"target": None, "expression": False},
}


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def build_mature(kernel, label):
    r10.OFFSET = OFFSET
    cfg = REGIMES[label]
    world, meta = r10.build(kernel, cfg["target"], expression=cfg["expression"], receiver_mode="candidate")
    for _ in range(MATURATION): world.tick()
    return world, meta


def signed_offsets(indices, origin, n):
    offsets = indices.astype(np.int64) - np.asarray(origin, dtype=np.int64)
    return (offsets + n // 2) % n - n // 2


def signed_nibble_array(values, shift):
    result = ((values >> np.uint64(shift)) & np.uint64(15)).astype(np.int16)
    result[result >= 8] -= 16
    return result


def hist(values, limit=32):
    unique, counts = np.unique(values, return_counts=True)
    order = np.argsort(counts)[::-1][:limit]
    return {str(int(unique[index])): int(counts[index]) for index in order}


def direction_hist(values, limit=32):
    if len(values) == 0: return {}
    directions = np.column_stack([signed_nibble_array(values, shift) for shift in (48, 52, 56)])
    unique, counts = np.unique(directions, axis=0, return_counts=True)
    order = np.argsort(counts)[::-1][:limit]
    return {",".join(str(int(x)) for x in unique[index]): int(counts[index]) for index in order}


def components_torus(mask):
    coordinates = {tuple(int(x) for x in row) for row in np.argwhere(mask)}
    sizes = []
    n = mask.shape[0]
    while coordinates:
        start = coordinates.pop(); queue = deque([start]); size = 0
        while queue:
            q = queue.popleft(); size += 1
            for axis in range(3):
                for sign in (-1, 1):
                    neighbor = list(q); neighbor[axis] = (neighbor[axis] + sign) % n
                    neighbor = tuple(neighbor)
                    if neighbor in coordinates:
                        coordinates.remove(neighbor); queue.append(neighbor)
        sizes.append(size)
    sizes.sort(reverse=True)
    return {"count": len(sizes), "largest": sizes[0] if sizes else 0,
            "largest_fraction": (sizes[0] / int(mask.sum())) if sizes else 0.0,
            "top_sizes": sizes[:16]}


def mask_digest(mask):
    return hashlib.sha256(np.packbits(mask.reshape(-1), bitorder="little").tobytes()).hexdigest()


def measurement(treatment, control, event, arrival_raw, arrival_clock, latency):
    raw_mask = treatment.raw != control.raw
    clock_mask = treatment.clock_a != control.clock_a
    union = raw_mask | clock_mask
    raw_new = raw_mask & (arrival_raw < 0); clock_new = clock_mask & (arrival_clock < 0)
    arrival_raw[raw_new] = latency; arrival_clock[clock_new] = latency
    indices = np.argwhere(union)
    offsets = signed_offsets(indices, event, treatment.n) if len(indices) else np.empty((0, 3), dtype=np.int64)
    cheb = np.max(np.abs(offsets), axis=1) if len(indices) else np.empty(0, dtype=np.int64)
    raw_indices = np.argwhere(raw_mask)
    tv = treatment.raw[raw_mask]; cv = control.raw[raw_mask]
    tsem = ((tv >> np.uint64(60)) & np.uint64(15)).astype(np.uint8)
    csem = ((cv >> np.uint64(60)) & np.uint64(15)).astype(np.uint8)
    tsreg = ((tv >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.int64)
    csreg = ((cv >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.int64)
    occupied_both = (tv != 0) & (cv != 0)
    occupancy_gain = (tv != 0) & (cv == 0)
    occupancy_loss = (tv == 0) & (cv != 0)
    shell_counts = Counter(int(x) for x in cheb)
    mean_offset = np.mean(offsets, axis=0).tolist() if len(offsets) else [0.0, 0.0, 0.0]
    second = np.mean(offsets.astype(float) ** 2, axis=0).tolist() if len(offsets) else [0.0, 0.0, 0.0]
    adjacent_edges = sum(int(np.count_nonzero(union & np.roll(union, 1, axis=axis))) for axis in range(3))
    phase = treatment.clock_a[union] & np.uint64(255)
    semantic_transitions = Counter(f"{int(a)}->{int(b)}" for a, b in zip(csem, tsem))
    return {
        "raw_changed": int(raw_mask.sum()), "clock_changed": int(clock_mask.sum()),
        "union_changed": int(union.sum()), "new_raw_arrivals": int(raw_new.sum()),
        "new_clock_arrivals": int(clock_new.sum()),
        "maximum_chebyshev_radius": int(cheb.max()) if len(cheb) else 0,
        "radial_shell_counts": {str(k): v for k, v in sorted(shell_counts.items())},
        "mean_signed_offset": mean_offset, "axis_second_moments": second,
        "axis_positive_counts": [int(np.sum(offsets[:, axis] > 0)) for axis in range(3)] if len(offsets) else [0, 0, 0],
        "axis_negative_counts": [int(np.sum(offsets[:, axis] < 0)) for axis in range(3)] if len(offsets) else [0, 0, 0],
        "connected_components_6_torus": components_torus(union),
        "changed_neighbor_edges": adjacent_edges,
        "changed_neighbor_edge_density": adjacent_edges / max(1, 3 * int(union.sum())),
        "occupancy_gain": int(occupancy_gain.sum()), "occupancy_loss": int(occupancy_loss.sum()),
        "occupied_raw_transformations": int(occupied_both.sum()),
        "treatment_semantic_counts": hist(tsem), "control_semantic_counts": hist(csem),
        "semantic_transition_counts": dict(semantic_transitions),
        "treatment_direction_counts": direction_hist(tv), "control_direction_counts": direction_hist(cv),
        "sreg_delta_sign_counts": {"negative": int(np.sum(tsreg < csreg)),
                                   "zero": int(np.sum(tsreg == csreg)),
                                   "positive": int(np.sum(tsreg > csreg))},
        "treatment_sreg": {"min": int(tsreg.min()) if len(tsreg) else None,
                            "max": int(tsreg.max()) if len(tsreg) else None,
                            "mean": float(tsreg.mean()) if len(tsreg) else None},
        "changed_phase_mod256_counts": hist(phase),
        "raw_mask_sha256": mask_digest(raw_mask), "clock_mask_sha256": mask_digest(clock_mask),
        "union_mask_sha256": mask_digest(union),
    }, raw_mask, clock_mask


def sequence_period(values, max_period=64):
    for period in range(1, min(max_period, len(values) // 2) + 1):
        if values[-period:] == values[-2 * period:-period]: return period
    return None


def run_regime(kernel, label, base, meta, source):
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    source_raw = int(pack(41000, 0, (0, 0, 1), 4))
    replaced_raw = int(base.raw[source]); replaced_clock = int(base.clock_a[source])
    # Equalize the local diagnostic port in both branches before applying the
    # identical source only to treatment.  Some learned histories occupy this
    # route at maturation; unequal add-versus-replace operations would confound
    # the cross-regime comparison.
    set_both(treatment, source, 0, 0); set_both(control, source, 0, 0)
    set_both(treatment, source, source_raw, MATURATION)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    packed_width = (meta["n"] ** 3 + 7) // 8
    raw_masks = np.zeros((FOLLOWUP, packed_width), dtype=np.uint8)
    clock_masks = np.zeros_like(raw_masks)
    arrival_raw = np.full((meta["n"],) * 3, -1, dtype=np.int16)
    arrival_clock = np.full_like(arrival_raw, -1)
    time_series = []; samples = []; raw_digests = []
    previous_t, previous_c = delta_value(treatment, meta), delta_value(control, meta)
    transitions_t, transitions_c = [], []
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        features, raw_mask, clock_mask = measurement(treatment, control, event,
                                                     arrival_raw, arrival_clock, latency)
        raw_masks[latency - 1] = np.packbits(raw_mask.reshape(-1), bitorder="little")
        clock_masks[latency - 1] = np.packbits(clock_mask.reshape(-1), bitorder="little")
        raw_digests.append(features["raw_mask_sha256"])
        time_series.append({"latency": latency, "raw_changed": features["raw_changed"],
                            "clock_changed": features["clock_changed"],
                            "union_changed": features["union_changed"],
                            "new_raw_arrivals": features["new_raw_arrivals"],
                            "new_clock_arrivals": features["new_clock_arrivals"],
                            "maximum_chebyshev_radius": features["maximum_chebyshev_radius"],
                            "union_mask_sha256": features["union_mask_sha256"]})
        if latency in CHECKPOINTS: samples.append({"latency": latency, **features})
        dt, dc = delta_value(treatment, meta), delta_value(control, meta)
        if dt != previous_t: transitions_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c: transitions_c.append({"latency": latency, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
    ever = (arrival_raw >= 0) | (arrival_clock >= 0)
    sparse_arrival = [{"q": [int(x) for x in q], "raw": int(arrival_raw[tuple(q)]),
                       "clock": int(arrival_clock[tuple(q)])} for q in np.argwhere(ever)]
    counts = [row["union_changed"] for row in time_series]
    repeated_masks = len(raw_digests) - len(set(raw_digests))
    return {
        "label": label, "target": REGIMES[label]["target"], "expression": REGIMES[label]["expression"],
        "event": list(event), "diagnostic_source": list(source),
        "source_installation_clean": replaced_raw == 0,
        "diagnostic_port_equalization": True,
        "replaced_baseline_raw": replaced_raw, "replaced_baseline_clock": replaced_clock,
        "treatment_master_transitions": transitions_t, "control_master_transitions": transitions_c,
        "probe_specific_write_response": bool([row for row in transitions_t if row not in transitions_c]),
        "time_series": time_series, "checkpoint_features": samples,
        "sparse_first_arrival_map": sparse_arrival,
        "ever_affected_positions": len(sparse_arrival), "maximum_union_changed": max(counts),
        "terminal_count_period_candidate": sequence_period(counts),
        "repeated_raw_mask_count": repeated_masks,
        "python_interventions_after_t0": 2, "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }, raw_masks, clock_masks


def pairwise(rows, masks):
    labels = list(rows)
    result = []
    for i, left in enumerate(labels):
        for right in labels[i + 1:]:
            xor = np.bitwise_xor(masks[left], masks[right])
            result.append({"left": left, "right": right,
                           "raw_response_exact_equal": bool(np.array_equal(masks[left], masks[right])),
                           "raw_mask_hamming_voxel_ticks": int(np.unpackbits(xor, bitorder="little").sum()),
                           "ever_affected_position_difference": abs(rows[left]["ever_affected_positions"] - rows[right]["ever_affected_positions"]),
                           "maximum_response_difference": abs(rows[left]["maximum_union_changed"] - rows[right]["maximum_union_changed"])})
    return result


def main():
    kernel, runtime = load_kernel(1)
    bases = {label: build_mature(kernel, label) for label in REGIMES}
    sample_meta = next(iter(bases.values()))[1]
    event = add(sample_meta["b"], (0, -1, 0), 1, sample_meta["n"])
    source = add(event, (0, 0, 1), -3, sample_meta["n"])
    rows, raw_masks, clock_masks = {}, {}, {}
    for label, (base, meta) in bases.items():
        row, raw_mask, clock_mask = run_regime(kernel, label, base, meta, source)
        rows[label] = row; raw_masks[label] = raw_mask; clock_masks[label] = clock_mask
    telemetry = ROOT / "TELEMETRY/ING03_DR_D01_DISTRIBUTED_REGIME_RESPONSES.npz"
    telemetry.parent.mkdir(parents=True, exist_ok=True)
    arrays = {f"{label}_raw_change_masks": raw_masks[label] for label in REGIMES}
    arrays.update({f"{label}_clock_change_masks": clock_masks[label] for label in REGIMES})
    arrays.update({"n": np.asarray([sample_meta["n"]], dtype=np.int16),
                   "horizon": np.asarray([FOLLOWUP], dtype=np.int16),
                   "bitorder_little": np.asarray([1], dtype=np.int8)})
    np.savez_compressed(telemetry, **arrays)
    comparisons = pairwise(rows, raw_masks)
    ab = next(row for row in comparisons if {row["left"], row["right"]} == {"A", "B"})
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.cartography.v1",
        "question": "Does the same late perturbation reveal learned-state-specific A/B/SHAM distributed causal regimes?",
        "planning": {"mechanism": "within-regime treatment/control causal difference",
                     "controls": ["A", "B", "SHAM", "PLASTIC", "paired no-probe branch"],
                     "predicted_outcomes": ["A/B equal: expression status only", "A/B distinct: learned-history candidate", "sham distinct: at least three regimes"],
                     "estimated_runtime_minutes": 3, "estimated_storage_mb": 20,
                     "stop_condition": "192 ticks or stable/recurrent terminal response"},
        "design": {"maturation_tick": MATURATION, "followup_ticks": FOLLOWUP,
                   "same_probe_source": list(source), "receiver_offset": list(OFFSET),
                   "diagnostic_port_equalized_in_all_treatment_and_control_branches": True,
                   "lossless_mask_telemetry": telemetry.relative_to(ROOT).as_posix(),
                   "telemetry_sha256": sha256_file(telemetry)},
        "rows": [rows[label] for label in REGIMES], "pairwise_response_comparisons": comparisons,
        "summary": {"a_b_raw_response_distinct_in_discovery": not ab["raw_response_exact_equal"],
                    "a_b_hamming_voxel_ticks": ab["raw_mask_hamming_voxel_ticks"],
                    "three_expressive_regimes_pairwise_distinct": all(not row["raw_response_exact_equal"] for row in comparisons if row["left"] != "PLASTIC" and row["right"] != "PLASTIC"),
                    "plastic_write_response": rows["PLASTIC"]["probe_specific_write_response"],
                    "expressive_write_responses": {label: rows[label]["probe_specific_write_response"] for label in ("A", "B", "SHAM")},
                    "external_decoding_only": True, "fresh_generalization_required_before_claim": True,
                    "native_distributed_function_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "Discovery equalizes one occupied-or-empty local port in both paired branches, then installs one diagnostic source only in treatment. Pattern separability is not a native decoder, function, or promoted claim.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D01_DISTRIBUTED_REGIME_CARTOGRAPHY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "telemetry": str(telemetry),
                      "telemetry_bytes": telemetry.stat().st_size, "summary": result["summary"],
                      "regimes": {label: {"ever": rows[label]["ever_affected_positions"],
                                          "max": rows[label]["maximum_union_changed"],
                                          "period": rows[label]["terminal_count_period_candidate"]}
                                  for label in REGIMES},
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
