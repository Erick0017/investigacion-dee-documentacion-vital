#!/usr/bin/env python3
"""Search causally distinct clean probe orientations for A/B/SHAM response separation."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 64
DISTANCES = (3, 4, 5, 6, 8, 10, 12, 16)
OFFSET = (-6, 7, 8)
REGIMES = {"A": ("a", True), "B": ("b", True),
           "SHAM": (None, True), "PLASTIC": (None, False)}


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def mature(kernel, label):
    r10.OFFSET = OFFSET
    target, expression = REGIMES[label]
    world, meta = r10.build(kernel, target, expression=expression, receiver_mode="candidate")
    for _ in range(MATURATION): world.tick()
    return world, meta


def family(direction):
    nonzero = sum(value != 0 for value in direction)
    return {1: "AXIS", 2: "FACE_DIAGONAL", 3: "CORNER_DIAGONAL"}[nonzero]


def run_one(kernel, base, meta, source, direction):
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    set_both(treatment, source, int(pack(42000, 0, direction, 4)), MATURATION)
    h = hashlib.sha256(); ever = np.zeros_like(base.raw, dtype=bool)
    maximum = 0; counts = []
    previous_t, previous_c = delta_value(treatment, meta), delta_value(control, meta)
    transitions_t, transitions_c = [], []
    receiver_different_ticks = 0
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        mask = treatment.raw != control.raw
        packed = np.packbits(mask.reshape(-1), bitorder="little")
        h.update(packed.tobytes()); ever |= mask
        count = int(mask.sum()); counts.append(count); maximum = max(maximum, count)
        if ((int(treatment.raw[meta["q_receiver"]]), int(treatment.raw[meta["qp_receiver"]])) !=
            (int(control.raw[meta["q_receiver"]]), int(control.raw[meta["qp_receiver"]]))):
            receiver_different_ticks += 1
        dt, dc = delta_value(treatment, meta), delta_value(control, meta)
        if dt != previous_t: transitions_t.append((latency, previous_t, dt))
        if dc != previous_c: transitions_c.append((latency, previous_c, dc))
        previous_t, previous_c = dt, dc
    return {"response_mask_sequence_sha256": h.hexdigest(),
            "ever_affected_positions": int(ever.sum()), "maximum_changed": maximum,
            "terminal_changed": counts[-1], "counts": counts,
            "write_response": bool([row for row in transitions_t if row not in transitions_c]),
            "receiver_different_ticks": receiver_different_ticks}


def main():
    kernel, runtime = load_kernel(1)
    bases = {label: mature(kernel, label) for label in REGIMES}
    meta0 = next(iter(bases.values()))[1]
    event = add(meta0["b"], (0, -1, 0), 1, meta0["n"])
    directions = [tuple(values) for values in itertools.product((-1, 0, 1), repeat=3)
                  if values != (0, 0, 0)]
    candidates = []; port_search = []
    for direction in directions:
        selected = None
        for distance in DISTANCES:
            source = add(event, direction, -distance, meta0["n"])
            occupied = {label: int(base.raw[source]) for label, (base, _) in bases.items()}
            attempt = {"direction": list(direction), "family": family(direction),
                       "distance": distance, "source": list(source),
                       "clean_all": all(value == 0 for value in occupied.values()),
                       "occupied_raw": occupied}
            port_search.append(attempt)
            if attempt["clean_all"]:
                selected = attempt; break
        if selected is not None: candidates.append(selected)
    clean = candidates
    rows = []
    for index, candidate in enumerate(clean, 1):
        direction = tuple(candidate["direction"]); source = tuple(candidate["source"])
        responses = {label: run_one(kernel, base, meta, source, direction)
                     for label, (base, meta) in bases.items()}
        expressive_hashes = [responses[label]["response_mask_sequence_sha256"] for label in ("A", "B", "SHAM")]
        row = {**candidate, "responses": responses,
               "a_b_distinct": responses["A"]["response_mask_sequence_sha256"] != responses["B"]["response_mask_sequence_sha256"],
               "a_b_sham_pairwise_distinct": len(set(expressive_hashes)) == 3,
               "any_remote_interface_effect": any(value["receiver_different_ticks"] > 0 for value in responses.values())}
        rows.append(row)
        print(json.dumps({"candidate": index, "of": len(clean), "direction": candidate["direction"],
                          "family": candidate["family"], "a_b_distinct": row["a_b_distinct"]}), flush=True)
    families = sorted(set(row["family"] for row in rows))
    family_summary = {name: {"clean_candidates": sum(row["family"] == name for row in rows),
                             "a_b_distinct": sum(row["family"] == name and row["a_b_distinct"] for row in rows),
                             "three_way_distinct": sum(row["family"] == name and row["a_b_sham_pairwise_distinct"] for row in rows)}
                      for name in families}
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.clean_port_generalization.v1",
        "question": "Does A/B/SHAM response separation persist across clean axial, face-diagonal and corner-diagonal probe ports?",
        "planning": {"mechanism": "semantic4 sources aimed at the same event surface from 26 causal orientations; first shared-clean route length per orientation",
                     "controls": ["port empty in all four mature worlds", "paired no-probe branch", "plastic write control", "remote pair monitor"],
                     "predicted_outcomes": ["multi-family separation", "single-port artifact", "expression-only equivalence"],
                     "estimated_runtime_minutes": 8, "estimated_storage_mb": 2,
                     "stop_condition": "all 26 causally distinct directions receive one shared-clean route or exhaust distances3..16"},
        "design": {"maturation_tick": MATURATION, "followup_ticks": FOLLOWUP,
                   "candidate_distances": list(DISTANCES), "event": list(event), "directions_screened": len(directions),
                   "clean_candidates_tested": len(clean), "post_t0_interventions_per_world": 1},
        "candidate_port_census": port_search, "selected_clean_ports": candidates,
        "rows": rows, "family_summary": family_summary,
        "summary": {"clean_candidates": len(clean),
                    "families_with_clean_candidate": families,
                    "a_b_distinct_clean_candidates": sum(row["a_b_distinct"] for row in rows),
                    "three_way_distinct_clean_candidates": sum(row["a_b_sham_pairwise_distinct"] for row in rows),
                    "separation_in_every_available_geometry_family": bool(families) and all(any(row["family"] == name and row["a_b_distinct"] for row in rows) for name in families),
                    "any_remote_interface_effect": any(row["any_remote_interface_effect"] for row in rows),
                    "fresh_generalization_required": True, "native_function_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "All sources are diagnostic post-maturation insertions. Multi-port separation would establish a robust discovery pattern, not native decoding or function.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D02_CLEAN_PORT_GENERALIZATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "family_summary": family_summary, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
