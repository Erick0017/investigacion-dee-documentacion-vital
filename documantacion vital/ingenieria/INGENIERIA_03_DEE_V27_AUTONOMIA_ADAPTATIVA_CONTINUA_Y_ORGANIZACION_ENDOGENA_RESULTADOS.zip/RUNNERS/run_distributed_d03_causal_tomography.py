#!/usr/bin/env python3
"""Diagnostic necessity/sufficiency tomography of the clean-port distributed regimes."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_landscape_l05_delayed_native_expression import P, S1, S2, N1, N2
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 64
OFFSET = (-6, 7, 8)
DIRECTION = (-1, -1, 1)
DISTANCE = 10
REGIMES = {"A": ("a", True), "B": ("b", True),
           "SHAM": (None, True), "PLASTIC": (None, False)}


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def mature(kernel, label):
    r10.OFFSET = OFFSET
    target, expression = REGIMES[label]
    world, meta = r10.build(kernel, target, expression=expression, receiver_mode="candidate")
    for _ in range(MATURATION): world.tick()
    return world, meta


def cube(center, radius, n):
    return sorted({add(center, offset, 1, n)
                   for offset in itertools.product(range(-radius, radius + 1), repeat=3)})


def expression_sources(meta):
    c, n = meta["c"], meta["n"]; qp = add(c, P, 1, n); distance = 24
    return [add(qp, S1, -distance, n), add(qp, S2, -distance, n),
            add(c, N1, -distance, n), add(c, N2, -distance, n)]


def clone(kernel, world):
    return NativeWorld(kernel, world.raw, world.clock_a)


def copy_positions(target, donor, positions):
    changed = 0
    for q in positions:
        if int(target.raw_a[q]) != int(donor.raw[q]) or int(target.clock_a[q]) != int(donor.clock_a[q]):
            changed += 1
        set_both(target, q, int(donor.raw[q]), int(donor.clock_a[q]))
    return changed


def clear_positions(world, positions):
    occupied = 0
    for q in positions:
        occupied += int(int(world.raw_a[q]) != 0)
        set_both(world, q, 0, 0)
    return occupied


def response(kernel, prepared, meta, source):
    treatment = clone(kernel, prepared); control = clone(kernel, prepared)
    if int(prepared.raw[source]) != 0:
        raise RuntimeError(f"tomography source not clean: {source}")
    set_both(treatment, source, int(pack(42000, 0, DIRECTION, 4)), MATURATION)
    width = (meta["n"] ** 3 + 7) // 8
    masks = np.zeros((FOLLOWUP, width), dtype=np.uint8)
    ever = np.zeros_like(prepared.raw, dtype=bool); counts = []
    previous_t, previous_c = delta_value(treatment, meta), delta_value(control, meta)
    transitions_t, transitions_c = [], []
    receiver_different = 0
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        mask = treatment.raw != control.raw
        masks[latency - 1] = np.packbits(mask.reshape(-1), bitorder="little")
        ever |= mask; counts.append(int(mask.sum()))
        if ((int(treatment.raw[meta["q_receiver"]]), int(treatment.raw[meta["qp_receiver"]])) !=
            (int(control.raw[meta["q_receiver"]]), int(control.raw[meta["qp_receiver"]]))):
            receiver_different += 1
        dt, dc = delta_value(treatment, meta), delta_value(control, meta)
        if dt != previous_t: transitions_t.append((latency, previous_t, dt))
        if dc != previous_c: transitions_c.append((latency, previous_c, dc))
        previous_t, previous_c = dt, dc
    h = hashlib.sha256(masks.tobytes()).hexdigest()
    return masks, {"response_masks_sha256": h, "ever_affected": int(ever.sum()),
                   "maximum_changed": max(counts), "terminal_changed": counts[-1],
                   "counts": counts, "receiver_different_ticks": receiver_different,
                   "write_response": bool([row for row in transitions_t if row not in transitions_c])}


def distance(left, right):
    return int(np.unpackbits(np.bitwise_xor(left, right), bitorder="little").sum())


def intervention_world(kernel, bases, metas, host, mode, donor=None, radius=None):
    world = clone(kernel, bases[host]); meta = metas[host]
    positions = []; detail = {}
    if mode == "pair_copy": positions = [meta["a"], meta["b"]]
    elif mode == "core_copy": positions = cube(meta["c"], radius, meta["n"])
    elif mode == "receiver_copy": positions = cube(meta["q_receiver"], radius, meta["n"])
    elif mode == "pair_ablate": positions = [meta["a"], meta["b"]]
    elif mode == "core_ablate": positions = cube(meta["c"], radius, meta["n"])
    elif mode == "generator_cut": positions = list(meta.get("generator_positions", []))
    elif mode == "expression_cut": positions = expression_sources(meta)
    elif mode == "generator_expression_cut": positions = sorted(set(meta.get("generator_positions", [])) | set(expression_sources(meta)))
    else: raise ValueError(mode)
    if mode.endswith("copy"):
        detail["changed_positions"] = copy_positions(world, bases[donor], positions)
    else:
        detail["occupied_positions_removed"] = clear_positions(world, positions)
    detail.update({"position_count": len(positions), "mode": mode, "host": host,
                   "donor": donor, "radius": radius})
    return world, detail


def main():
    kernel, runtime = load_kernel(1)
    built = {label: mature(kernel, label) for label in REGIMES}
    bases = {label: item[0] for label, item in built.items()}
    metas = {label: item[1] for label, item in built.items()}
    meta0 = metas["A"]
    event = add(meta0["b"], (0, -1, 0), 1, meta0["n"])
    source = add(event, DIRECTION, -DISTANCE, meta0["n"])
    if any(int(world.raw[source]) != 0 for world in bases.values()):
        raise RuntimeError("D02 clean port no longer clean")

    template_masks, template_rows = {}, {}
    for label in REGIMES:
        template_masks[label], template_rows[label] = response(kernel, bases[label], metas[label], source)

    specifications = []
    for host, donor in (("A", "B"), ("B", "A")):
        specifications += [(host, "pair_copy", donor, None)]
        specifications += [(host, "core_copy", donor, radius) for radius in (1, 2, 3)]
        specifications += [(host, "receiver_copy", donor, 3)]
        specifications += [(host, mode, None, None) for mode in
                           ("generator_cut", "expression_cut", "generator_expression_cut", "pair_ablate")]
        specifications += [(host, "core_ablate", None, 1)]
    for host in ("SHAM", "PLASTIC"):
        for donor in ("A", "B"):
            specifications += [(host, "pair_copy", donor, None)]
            specifications += [(host, "core_copy", donor, radius) for radius in (1, 2, 3)]

    rows = []
    for index, (host, mode, donor, radius) in enumerate(specifications, 1):
        prepared, intervention = intervention_world(kernel, bases, metas, host, mode, donor, radius)
        masks, metrics = response(kernel, prepared, metas[host], source)
        distances = {label: distance(masks, template_masks[label]) for label in REGIMES}
        nearest = min(distances, key=distances.get)
        rows.append({"id": f"T{index:02d}", "intervention": intervention,
                     "response": metrics, "hamming_to_intact_templates": distances,
                     "nearest_intact_template": nearest,
                     "nearest_template_is_donor": donor is not None and nearest == donor,
                     "exact_donor_template_match": donor is not None and
                                                   metrics["response_masks_sha256"] == template_rows[donor]["response_masks_sha256"],
                     "retains_host_template": nearest == host,
                     "python_interventions_after_t0": 2})
        print(json.dumps({"row": index, "of": len(specifications), "host": host,
                          "mode": mode, "donor": donor, "radius": radius,
                          "nearest": nearest}), flush=True)

    swap_rows = [row for row in rows if row["intervention"]["mode"] in
                 ("pair_copy", "core_copy", "receiver_copy") and row["intervention"]["host"] in ("A", "B")]
    sufficiency_rows = [row for row in rows if row["intervention"]["host"] in ("SHAM", "PLASTIC")]
    cut_rows = [row for row in rows if "cut" in row["intervention"]["mode"]]
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.causal_tomography.v1",
        "question": "Which local, support, receiver or distributed-history domains causally determine the clean-port A/B response class?",
        "planning": {"mechanism": "paired diagnostic regional copy/ablation followed by identical clean-port probe",
                     "controls": ["four intact templates", "bidirectional A/B swaps", "SHAM and PLASTIC sufficiency hosts", "source cuts"],
                     "predicted_outcomes": ["response follows local donor", "response remains host-history-specific", "support cuts collapse class"],
                     "estimated_runtime_minutes": 8, "estimated_storage_mb": 3,
                     "stop_condition": "pair, core radii1..3, receiver-r3 and causal-source families classified bidirectionally"},
        "design": {"maturation_tick": MATURATION, "followup_ticks": FOLLOWUP,
                   "clean_source": list(source), "direction": list(DIRECTION), "distance": DISTANCE,
                   "template_labels": list(REGIMES)},
        "intact_templates": template_rows, "rows": rows,
        "summary": {
            "intact_templates_pairwise_distinct": len({row["response_masks_sha256"] for row in template_rows.values()}) == 4,
            "a_b_pair_copy_nearest_to_donor": all(row["nearest_template_is_donor"] for row in swap_rows if row["intervention"]["mode"] == "pair_copy"),
            "a_b_any_local_swap_nearest_to_donor": any(row["nearest_template_is_donor"] for row in swap_rows),
            "a_b_all_local_swaps_retain_host": all(row["retains_host_template"] for row in swap_rows),
            "sham_or_plastic_implant_nearest_to_donor": any(row["nearest_template_is_donor"] for row in sufficiency_rows),
            "any_exact_donor_template_recreation": any(row["exact_donor_template_match"] for row in rows),
            "template_proximity_is_not_recreation": True,
            "any_source_cut_changes_nearest_class": any(not row["retains_host_template"] for row in cut_rows),
            "remote_interface_effect_in_any_row": any(row["response"]["receiver_different_ticks"] > 0 for row in rows),
            "distributed_learned_state_causality_demonstrated": False,
            "native_function_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "All regional copies, cuts, ablations and late sources are diagnostic. Template proximity is causal localization, not native function or a promoted distributed-code claim.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D03_DISTRIBUTED_CAUSAL_TOMOGRAPHY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
