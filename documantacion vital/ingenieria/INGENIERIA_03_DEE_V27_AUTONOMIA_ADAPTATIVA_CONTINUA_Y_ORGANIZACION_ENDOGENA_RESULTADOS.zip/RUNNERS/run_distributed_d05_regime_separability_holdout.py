#!/usr/bin/env python3
"""Fresh signed/permuted validation of the clean-port distributed regimes."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, sha256_file, transform, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_nature_n07_native_consequence_expression import delta_value


LOCK_PATH = ROOT / "FREEZE/ING03_DR_D05_REGIME_SEPARABILITY_LOCK.json"
P = (1, 0, 0)
S1 = (-1, -1, 0)
S2 = (-1, 1, 0)
N1 = (1, 0, -1)
N2 = (1, 0, 1)
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def put_transducer(raw, clock, c, n, tf, base):
    p = tf(P)
    qp = add(c, p, 1, n)
    put(raw, clock, c, base, 7, p, 1, 11)
    specs = (
        (add(qp, tf(S1), -1, n), tf(S1), 11),
        (add(qp, tf(S2), -1, n), tf(S2), 13),
        (add(c, tf(N1), -2, n), tf(N1), 17),
        (add(c, tf(N2), -2, n), tf(N2), 19),
    )
    for index, (q, direction, sreg) in enumerate(specs):
        put(raw, clock, q, base + 100 + index, sreg, direction, 4, 100 + index)
    return c, qp


def build(kernel, frame, condition, architecture):
    permutation, signs = frame
    tf = lambda vector: transform(vector, permutation, signs)
    n = architecture["n"]
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    c = (n // 2,) * 3
    p = tf(P)
    a = add(c, p, -1, n)
    b = add(c, p, 1, n)
    put(raw, clock, a, 1000, 100, semantic=1, phase=architecture["memory_phase"])
    put(raw, clock, b, 2000, 100, semantic=1, phase=architecture["memory_phase"])
    for index, offset in enumerate(PA):
        put(raw, clock, add(a, tf(offset), 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB):
        put(raw, clock, add(b, tf(offset), 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    if condition in ("A", "B"):
        target = a if condition == "A" else b
        event = add(target, tf((0, -1, 0)), 1, n)
        route = tf((0, 0, 1))
        generator = add(event, route, -architecture["consequence_distance"], n)
        for index, direction in enumerate((tf((1, 0, 1)), tf((-1, 0, 1)))):
            put(raw, clock, add(generator, direction, -1, n), 5001 + index, 3, direction, 1, 0)
    if condition != "PLASTIC":
        qp = add(c, p, 1, n)
        specs = ((qp, tf(S1), 11), (qp, tf(S2), 13), (c, tf(N1), 17), (c, tf(N2), 19))
        for index, (anchor, direction, sreg) in enumerate(specs):
            q = add(anchor, direction, -architecture["bridge_source_distance"], n)
            put(raw, clock, q, 7000 + index, sreg, direction, 4, 100 + index)
    receiver = add(c, tf(tuple(architecture["receiver_relative_offset"])), 1, n)
    q_receiver, qp_receiver = put_transducer(raw, clock, receiver, n, tf, 9000)
    return NativeWorld(kernel, raw, clock), {
        "n": n, "c": c, "a": a, "b": b, "q_receiver": q_receiver,
        "qp_receiver": qp_receiver, "tf": tf,
    }


def canonical_mask_digest(mask_sequence, frame, n):
    """Hash each response after mapping the frame back to canonical coordinates."""
    permutation, signs = frame
    center = n // 2
    h = hashlib.sha256()
    for mask in mask_sequence:
        canonical = np.zeros_like(mask, dtype=bool)
        indices = np.argwhere(mask)
        if len(indices):
            w = (indices.astype(np.int64) - center + n // 2) % n - n // 2
            v = np.zeros_like(w)
            for axis in range(3):
                v[:, permutation[axis]] = signs[axis] * w[:, axis]
            q = (v + center) % n
            canonical[q[:, 0], q[:, 1], q[:, 2]] = True
        h.update(np.packbits(canonical.reshape(-1), bitorder="little").tobytes())
    return h.hexdigest()


def run_case(kernel, frame, condition, architecture):
    try:
        base, meta = build(kernel, frame, condition, architecture)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    for _ in range(architecture["maturation_tick"]):
        base.tick()
    tf = meta["tf"]
    event = add(meta["b"], tf(tuple(architecture["probe_event_offset"])), 1, meta["n"])
    direction = tf(tuple(architecture["probe_direction"]))
    source = add(event, direction, -architecture["probe_distance"], meta["n"])
    port_raw = int(base.raw[source])
    port_clock = int(base.clock_a[source])
    if port_raw:
        return {"condition": condition, "valid": False, "reason": "diagnostic probe port occupied",
                "source": list(source), "port_raw": port_raw, "port_clock": port_clock}
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    source_raw = int(pack(architecture["probe_state"], architecture["probe_s_reg"], direction,
                          architecture["probe_semantic"]))
    treatment.raw_a[source] = np.uint64(source_raw)
    treatment.raw_b[source] = np.uint64(source_raw)
    treatment.clock_a[source] = np.uint64(architecture["maturation_tick"])
    treatment.clock_b[source] = np.uint64(architecture["maturation_tick"])
    masks = []
    counts = []
    ever = np.zeros_like(base.raw, dtype=bool)
    receiver_different_ticks = 0
    previous_t = delta_value(treatment, meta)
    previous_c = delta_value(control, meta)
    transitions_t, transitions_c = [], []
    for latency in range(1, architecture["followup_ticks"] + 1):
        treatment.tick()
        control.tick()
        mask = treatment.raw != control.raw
        masks.append(mask)
        ever |= mask
        counts.append(int(mask.sum()))
        if ((int(treatment.raw[meta["q_receiver"]]), int(treatment.raw[meta["qp_receiver"]])) !=
                (int(control.raw[meta["q_receiver"]]), int(control.raw[meta["qp_receiver"]]))):
            receiver_different_ticks += 1
        dt = delta_value(treatment, meta)
        dc = delta_value(control, meta)
        if dt != previous_t:
            transitions_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c:
            transitions_c.append({"latency": latency, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
    probe_specific = [row for row in transitions_t if row not in transitions_c]
    return {
        "condition": condition, "valid": True, "source": list(source), "port_raw": port_raw,
        "port_clock": port_clock, "counts": counts, "ever_affected_positions": int(ever.sum()),
        "maximum_changed": max(counts), "terminal_changed": counts[-1],
        "canonical_response_mask_sequence_sha256": canonical_mask_digest(masks, frame, meta["n"]),
        "receiver_different_ticks": receiver_different_ticks,
        "probe_specific_write_response": bool(probe_specific),
        "treatment_master_transitions": transitions_t, "control_master_transitions": transitions_c,
        "python_interventions_after_t0": 1,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def excluded_frames():
    excluded = set()
    for path in (ROOT / "HOLDOUT").glob("*CHALLENGES.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            continue
        for row in data.get("challenges", []):
            frame = row.get("frame")
            if frame and "permutation" in frame and "signs" in frame:
                excluded.add((tuple(frame["permutation"]), tuple(frame["signs"])))
    return excluded


def select_frames(lock):
    identity = ((0, 1, 2), (1, 1, 1))
    excluded = excluded_frames() | {identity}
    frames = [(p, s) for p in itertools.permutations((0, 1, 2))
              for s in itertools.product((-1, 1), repeat=3) if (p, s) not in excluded]
    salt = lock["fresh_generation"]["salt"]
    frames.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True,
                     separators=(",", ":")) + salt).encode()).hexdigest())
    count = lock["fresh_generation"]["fresh_frames"]
    if len(frames) < count:
        raise RuntimeError(f"only {len(frames)} unused signed/permuted frames remain")
    return frames[:count]


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    frames = select_frames(lock)
    challenges = seal({
        "schema": "dee.v27.ing03.distributed_regime.d05_challenges.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "algorithm": lock["fresh_generation"]["algorithm"],
        "salt": lock["fresh_generation"]["salt"],
        "excluded_prior_frame_count": len(excluded_frames()),
        "challenges": [{"id": f"DRD05-{index:02d}", "frame": frame_json(frame)}
                       for index, frame in enumerate(frames, 1)],
        "outcomes_absent_at_generation": True,
    })
    challenge_path = ROOT / "HOLDOUT/ING03_DR_D05_REGIME_SEPARABILITY_CHALLENGES.json"
    write_json(challenge_path, challenges)
    kernel, runtime = load_kernel(1)
    rows = []
    for index, frame in enumerate(frames, 1):
        cid = f"DRD05-{index:02d}"
        for condition in lock["conditions"]:
            row = run_case(kernel, frame, condition, lock["architecture"])
            row.update({"challenge_id": cid, "frame": frame_json(frame)})
            rows.append(row)
        print(json.dumps({"challenge": cid, "completed_worlds": len(lock["conditions"])}, sort_keys=True), flush=True)
    groups = []
    expected = lock["expected_identity_response"]
    for index, frame in enumerate(frames, 1):
        cid = f"DRD05-{index:02d}"
        by = {row["condition"]: row for row in rows if row["challenge_id"] == cid}
        exact = {condition: (by[condition].get("counts") == expected[condition]["counts"] and
                             by[condition].get("canonical_response_mask_sequence_sha256") ==
                             expected[condition]["response_mask_sequence_sha256"])
                 for condition in lock["conditions"]}
        hashes = [by[name].get("canonical_response_mask_sequence_sha256") for name in ("A", "B", "SHAM")]
        passed = (
            len(by) == len(lock["conditions"]) and
            all(row.get("valid") and row.get("port_raw") == 0 and row.get("python_interventions_after_t0") == 1
                for row in by.values()) and
            all(exact.values()) and len(set(hashes)) == 3 and
            all(by[name].get("receiver_different_ticks") == 0 for name in lock["conditions"]) and
            all(not by[name].get("probe_specific_write_response") for name in lock["conditions"])
        )
        groups.append({"challenge_id": cid, "frame": frame_json(frame),
                       "exact_frozen_response": exact, "a_b_sham_pairwise_distinct": len(set(hashes)) == 3,
                       "passed": passed})
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.d05_holdout.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "challenge_content_sha256": challenges["content_sha256"],
        "rows": rows, "groups": groups,
        "summary": {"fresh_frames": len(groups), "fresh_worlds": len(rows),
                    "passed_groups": sum(group["passed"] for group in groups),
                    "all_passed": all(group["passed"] for group in groups),
                    "diagnostic_history_conditioned_regime_separability_validated": all(group["passed"] for group in groups),
                    "native_decoder_or_function_demonstrated": False, "rw3_demonstrated": False},
        "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_DR_D05_REGIME_SEPARABILITY_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
