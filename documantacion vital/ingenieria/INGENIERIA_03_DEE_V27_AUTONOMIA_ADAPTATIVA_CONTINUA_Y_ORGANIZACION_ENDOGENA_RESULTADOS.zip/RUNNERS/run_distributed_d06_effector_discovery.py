#!/usr/bin/env python3
"""Diagnostic interaction screen for distributed regimes and non-point effectors."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_distributed_d05_regime_separability_holdout as d05


IDENTITY = ((0, 1, 2), (1, 1, 1))
REGIMES = ("A", "B", "SHAM")
FAMILIES = {
    "POINT_BOUNDARY": [(0, 0, 0)],
    "LINE_BOUNDARY": [(-1, 0, 0), (0, 0, 0), (1, 0, 0)],
    "SHEET_BOUNDARY": [(0, y, z) for y in (-1, 0, 1) for z in (-1, 0, 1)],
    "AXIAL_SHELL": [(-1, 0, 0), (1, 0, 0), (0, -1, 0), (0, 1, 0), (0, 0, -1), (0, 0, 1)],
    "SPARSE_VOLUME": [(0, 0, 0), (-2, 0, 0), (2, 0, 0), (0, -2, 0), (0, 2, 0), (0, 0, -2), (0, 0, 2)],
}


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw)
    world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock)
    world.clock_b[q] = np.uint64(clock)


def torus_offset(q, origin, n):
    return tuple(int((q[i] - origin[i] + n // 2) % n - n // 2) for i in range(3))


def shifted(anchor, offsets, n):
    return [tuple((anchor[i] + offset[i]) % n for i in range(3)) for offset in offsets]


def digest_counts(values):
    return hashlib.sha256(json.dumps(values, separators=(",", ":")).encode()).hexdigest()


def mature_bases(kernel, architecture):
    bases = {}
    for regime in REGIMES:
        world, meta = d05.build(kernel, IDENTITY, regime, architecture)
        for _ in range(architecture["maturation_tick"]):
            world.tick()
        bases[regime] = (world, meta)
    return bases


def install_probe(world, meta, architecture):
    event = add(meta["b"], tuple(architecture["probe_event_offset"]), 1, meta["n"])
    direction = tuple(architecture["probe_direction"])
    source = add(event, direction, -architecture["probe_distance"], meta["n"])
    if int(world.raw[source]):
        raise RuntimeError(f"probe overlap {source}")
    set_both(world, source, int(pack(architecture["probe_state"], architecture["probe_s_reg"],
                                          direction, architecture["probe_semantic"])),
             architecture["maturation_tick"])
    return source, event


def reference_response(kernel, base, meta, architecture):
    probe = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    source, event = install_probe(probe, meta, architecture)
    masks = []
    arrival = np.full(base.raw.shape, -1, dtype=np.int16)
    for latency in range(1, architecture["followup_ticks"] + 1):
        probe.tick(); control.tick()
        mask = probe.raw != control.raw
        masks.append(mask.copy())
        arrival[(arrival < 0) & mask] = latency
    return {"masks": masks, "ever": arrival >= 0, "arrival": arrival,
            "source": source, "event": event}


def select_anchors(bases, references, family, offsets):
    n = next(iter(bases.values()))[1]["n"]
    a_ever = references["A"]["ever"]
    b_ever = references["B"]["ever"]
    sham_ever = references["SHAM"]["ever"]
    category = a_ever & ~b_ever & ~sham_ever
    event = references["A"]["event"]
    source = references["A"]["source"]
    receiver = bases["A"][1]["q_receiver"]
    candidates = []
    for row in np.argwhere(category):
        anchor = tuple(int(x) for x in row)
        positions = shifted(anchor, offsets, n)
        if any(int(world.raw[q]) for world, _ in bases.values() for q in positions):
            continue
        if not any(category[q] for q in positions):
            continue
        if any(max(abs(x) for x in torus_offset(anchor, protected, n)) < 3
               for protected in (event, source, receiver)):
            continue
        arrival_values = [int(references["A"]["arrival"][q]) for q in positions
                          if references["A"]["arrival"][q] >= 0]
        if not arrival_values:
            continue
        candidates.append((min(arrival_values), anchor))
    candidates.sort(key=lambda item: (item[0], item[1]))
    if not candidates:
        return []
    picks = []
    for index, tag in ((0, "EARLY"), (len(candidates) // 2, "MIDDLE"), (-1, "LATE")):
        latency, anchor = candidates[index]
        if anchor not in [row["anchor"] for row in picks]:
            picks.append({"phase": tag, "first_a_arrival": latency, "anchor": anchor,
                          "candidate_count": len(candidates)})
    return picks


def install_effector(world, positions, family, phase):
    moving = family == "TRAJECTORY_CROSSING"
    direction = (0, 0, 1) if moving else (0, 0, 0)
    for index, q in enumerate(positions):
        if int(world.raw[q]):
            raise RuntimeError(f"effector overlap {q}")
        set_both(world, q, int(pack(61000 + index, 7, direction, 1)), phase)


def run_effector(kernel, base, meta, reference, architecture, family, anchor, offsets):
    n = meta["n"]
    positions = shifted(anchor, offsets, n)
    effector_only = NativeWorld(kernel, base.raw, base.clock_a)
    both = NativeWorld(kernel, base.raw, base.clock_a)
    install_effector(effector_only, positions, family, architecture["maturation_tick"])
    install_effector(both, positions, family, architecture["maturation_tick"])
    install_probe(both, meta, architecture)
    readout_offsets = [(3, 0, 0), (-3, 0, 0), (0, 3, 0), (0, -3, 0), (0, 0, 3), (0, 0, -3)]
    readouts = shifted(anchor, readout_offsets, n)
    effector_response_counts = []
    interaction_residue_counts = []
    exterior_residue_counts = []
    readout_response_counts = []
    effector_ever = np.zeros(len(positions), dtype=bool)
    readout_ever = np.zeros(len(readouts), dtype=bool)
    position_mask = np.zeros(base.raw.shape, dtype=bool)
    for q in positions:
        position_mask[q] = True
    for latency in range(1, architecture["followup_ticks"] + 1):
        both.tick(); effector_only.tick()
        with_effector = both.raw != effector_only.raw
        reference_mask = reference["masks"][latency - 1]
        residue = with_effector ^ reference_mask
        local = np.asarray([with_effector[q] for q in positions], dtype=bool)
        output = np.asarray([with_effector[q] for q in readouts], dtype=bool)
        effector_ever |= local; readout_ever |= output
        effector_response_counts.append(int(local.sum()))
        readout_response_counts.append(int(output.sum()))
        interaction_residue_counts.append(int(residue.sum()))
        exterior_residue_counts.append(int((residue & ~position_mask).sum()))
    return {
        "effector_positions": [list(q) for q in positions], "readout_positions": [list(q) for q in readouts],
        "effector_response_counts": effector_response_counts,
        "readout_response_counts": readout_response_counts,
        "interaction_residue_counts": interaction_residue_counts,
        "exterior_residue_counts": exterior_residue_counts,
        "effector_positions_ever_responding": int(effector_ever.sum()),
        "readout_positions_ever_responding": int(readout_ever.sum()),
        "maximum_interaction_residue": max(interaction_residue_counts),
        "maximum_exterior_residue": max(exterior_residue_counts),
        "effector_response_sha256": digest_counts(effector_response_counts),
        "readout_response_sha256": digest_counts(readout_response_counts),
        "interaction_residue_sha256": digest_counts(interaction_residue_counts),
    }


def main():
    lock = json.loads(d05.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    bases = mature_bases(kernel, architecture)
    references = {regime: reference_response(kernel, *bases[regime], architecture) for regime in REGIMES}
    rows = []
    selection = {}
    for family, offsets in FAMILIES.items():
        anchors = select_anchors(bases, references, family, offsets)
        selection[family] = [{**row, "anchor": list(row["anchor"])} for row in anchors]
        for pick in anchors:
            outcomes = {regime: run_effector(kernel, *bases[regime], references[regime], architecture,
                                              family, pick["anchor"], offsets)
                        for regime in REGIMES}
            response_hashes = [outcomes[regime]["effector_response_sha256"] for regime in REGIMES]
            readout_hashes = [outcomes[regime]["readout_response_sha256"] for regime in REGIMES]
            rows.append({"family": family, "phase": pick["phase"], "anchor": list(pick["anchor"]),
                         "first_a_arrival": pick["first_a_arrival"], "positions": len(offsets),
                         "outcomes": outcomes,
                         "a_b_effector_readout_distinct": response_hashes[0] != response_hashes[1],
                         "a_b_sham_effector_pairwise_distinct": len(set(response_hashes)) == 3,
                         "a_b_downstream_readout_distinct": readout_hashes[0] != readout_hashes[1],
                         "all_regimes_have_nonlinear_interaction": all(outcomes[r]["maximum_interaction_residue"] > 0 for r in REGIMES)})
            print(json.dumps({"family": family, "phase": pick["phase"],
                              "a_b_effector_distinct": rows[-1]["a_b_effector_readout_distinct"],
                              "a_b_downstream_distinct": rows[-1]["a_b_downstream_readout_distinct"]}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.effector_discovery.v1",
        "question": "Can an identical physical DEE organization interact differently with the freshly validated A/B/SHAM distributed regimes?",
        "planning": {"mechanism": "four-branch causal interaction contrast: neither, probe-only, effector-only, probe+effector",
                     "controls": ["same effector across regimes", "same clean probe", "probe-only response", "effector-only response"],
                     "predicted_outcomes": ["no coupling", "local coupling only", "effector-dependent exterior modification", "history-specific readout"],
                     "estimated_runtime_minutes": 4, "estimated_storage_mb": 2,
                     "stop_condition": "five causally distinct spatial geometries at early/middle/late A-exclusive response sites"},
        "design": {"maturation_tick": architecture["maturation_tick"], "followup_ticks": architecture["followup_ticks"],
                   "families": {key: [list(v) for v in value] for key, value in FAMILIES.items()},
                   "diagnostic_insertions_after_t0": ["effector at maturation", "clean-port probe at maturation"],
                   "candidate_selection": "empty A-exclusive/non-B/non-SHAM response sites; early/middle/late deterministic ranks"},
        "anchor_selection": selection, "rows": rows,
        "summary": {"configurations": len(rows),
                    "families_tested": len({row["family"] for row in rows}),
                    "a_b_effector_distinct_configurations": sum(row["a_b_effector_readout_distinct"] for row in rows),
                    "a_b_downstream_distinct_configurations": sum(row["a_b_downstream_readout_distinct"] for row in rows),
                    "all_regime_nonlinear_configurations": sum(row["all_regimes_have_nonlinear_interaction"] for row in rows),
                    "native_distributed_effector_demonstrated": False,
                    "fresh_validation_required": True, "rw3_demonstrated": False},
        "claim_guard": "Candidate sites and effectors are diagnostic post-maturation insertions selected from discovery response maps. Any positive coupling is configured/diagnostic until a t0-complete frozen architecture passes fresh validation.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D06_DISTRIBUTED_EFFECTOR_DISCOVERY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
