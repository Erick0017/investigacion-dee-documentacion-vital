#!/usr/bin/env python3
"""Discovery of t0-complete transducing geometries for distributed regimes."""
from __future__ import annotations

import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, write_json
import run_distributed_d05_regime_separability_holdout as d05
import run_distributed_d06_effector_discovery as d06


IDENTITY = d06.IDENTITY
REGIMES = ("A", "B", "SHAM", "PLASTIC")
TRANSDUCER_OFFSETS = ((0, 0, 0), (1, 0, 0), (2, 1, 0), (2, -1, 0), (-2, 0, 2), (-2, 0, -2))


def torus_distance(a, b, n):
    values = [abs((a[i] - b[i] + n // 2) % n - n // 2) for i in range(3)]
    return max(values)


def farthest_sample(rows, count, n):
    if not rows:
        return []
    ordered = sorted(rows, key=lambda row: (row[0], row[1]))
    chosen = [ordered[0]]
    while len(chosen) < min(count, len(ordered)):
        remaining = [row for row in ordered if row not in chosen]
        next_row = max(remaining, key=lambda row: (min(torus_distance(row[1], old[1], n) for old in chosen),
                                                   -row[0], tuple(-x for x in row[1])))
        chosen.append(next_row)
    return chosen


def footprints_disjoint(rows, n):
    used = set()
    kept = []
    for row in rows:
        footprint = set(d06.shifted(row[1], TRANSDUCER_OFFSETS, n))
        if footprint & used:
            continue
        used |= footprint
        kept.append(row)
    return kept


def select_configurations(kernel, architecture, mature_bases, references):
    n = architecture["n"]
    t0 = {regime: d05.build(kernel, IDENTITY, regime, architecture)[0] for regime in REGIMES}
    category = references["A"]["ever"] & ~references["B"]["ever"] & ~references["SHAM"]["ever"]
    candidates = []
    for raw_row in np.argwhere(category):
        center = tuple(int(x) for x in raw_row)
        footprint = d06.shifted(center, TRANSDUCER_OFFSETS, n)
        if any(int(world.raw[q]) for world in t0.values() for q in footprint):
            continue
        arrivals = [int(references["A"]["arrival"][q]) for q in footprint
                    if references["A"]["arrival"][q] >= 0]
        if arrivals:
            candidates.append((min(arrivals), center))
    candidates.sort(key=lambda row: (row[0], row[1]))
    early, middle, late = candidates[0], candidates[len(candidates) // 2], candidates[-1]
    configurations = {
        "SINGLE_EARLY": [early], "SINGLE_MIDDLE": [middle], "SINGLE_LATE": [late],
        "SPARSE_VOLUME_3": footprints_disjoint(farthest_sample([early, middle, late], 3, n), n),
    }
    planes = defaultdict(list)
    shells = defaultdict(list)
    event = references["A"]["event"]
    for row in candidates:
        center = row[1]
        for axis in range(3):
            planes[(axis, center[axis])].append(row)
        shells[torus_distance(center, event, n)].append(row)
    plane_key = max(planes, key=lambda key: len(planes[key]))
    shell_key = max(shells, key=lambda key: len(shells[key]))
    configurations["SPARSE_SURFACE_4"] = footprints_disjoint(farthest_sample(planes[plane_key], 8, n), n)[:4]
    configurations["SPARSE_SHELL_6"] = footprints_disjoint(farthest_sample(shells[shell_key], 12, n), n)[:6]
    configurations["SPARSE_VOLUME_8"] = footprints_disjoint(farthest_sample(candidates, 16, n), n)[:8]
    if any(not rows for rows in configurations.values()):
        raise RuntimeError("failed to select every frozen discovery geometry")
    return configurations, {"candidate_centers": len(candidates),
                            "surface_plane": {"axis": plane_key[0], "coordinate": plane_key[1],
                                              "candidate_centers": len(planes[plane_key])},
                            "shell_radius": shell_key, "shell_candidate_centers": len(shells[shell_key])}


def install_array(world, meta, centers):
    tf = lambda vector: tuple(vector)
    pairs = []
    for center in centers:
        q, qp = d05.put_transducer(world.raw_a, world.clock_a, center, meta["n"], tf, 12000)
        pairs.append((q, qp))
    world.raw_b[:] = world.raw_a
    world.clock_b[:] = world.clock_a
    return pairs


def hash_pair_sequence(sequence):
    h = hashlib.sha256()
    for tick in sequence:
        for pair in tick:
            h.update(int(pair[0]).to_bytes(8, "little")); h.update(int(pair[1]).to_bytes(8, "little"))
    return h.hexdigest()


def run_case(kernel, regime, architecture, centers, reference_masks):
    try:
        base, meta = d05.build(kernel, IDENTITY, regime, architecture)
        pairs = install_array(base, meta, centers)
    except RuntimeError as exc:
        return {"regime": regime, "valid": False, "reason": str(exc)}
    for _ in range(architecture["maturation_tick"]):
        base.tick()
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    try:
        source, _ = d06.install_probe(treatment, meta, architecture)
    except RuntimeError as exc:
        return {"regime": regime, "valid": False, "reason": str(exc)}
    sequence = []
    changed_pairs = np.zeros(len(pairs), dtype=bool)
    interaction_counts = []
    exterior_interaction_counts = []
    footprint_mask = np.zeros(base.raw.shape, dtype=bool)
    for center in centers:
        for q in d06.shifted(center, TRANSDUCER_OFFSETS, meta["n"]):
            footprint_mask[q] = True
    for latency in range(1, architecture["followup_ticks"] + 1):
        treatment.tick(); control.tick()
        response = treatment.raw != control.raw
        residue = response ^ reference_masks[latency - 1]
        values = [((int(treatment.raw[q]), int(treatment.raw[qp])),
                   (int(control.raw[q]), int(control.raw[qp]))) for q, qp in pairs]
        changed_pairs |= np.asarray([left != right for left, right in values], dtype=bool)
        sequence.append([left for left, _ in values])
        interaction_counts.append(int(residue.sum()))
        exterior_interaction_counts.append(int((residue & ~footprint_mask).sum()))
    return {"regime": regime, "valid": True, "centers": [list(q) for q in centers],
            "mature_probe_port_clean": True, "diagnostic_source": list(source),
            "transducer_pairs": [[list(q), list(qp)] for q, qp in pairs],
            "pairs_ever_probe_responsive": int(changed_pairs.sum()),
            "pair_sequence_sha256": hash_pair_sequence(sequence),
            "maximum_interaction_residue": max(interaction_counts),
            "maximum_exterior_interaction_residue": max(exterior_interaction_counts),
            "interaction_count_sequence": interaction_counts,
            "python_interventions_after_t0": 1,
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    lock = json.loads(d05.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    mature_bases = d06.mature_bases(kernel, architecture)
    references = {regime: d06.reference_response(kernel, *mature_bases[regime], architecture)
                  for regime in d06.REGIMES}
    plastic_base = d05.build(kernel, IDENTITY, "PLASTIC", architecture)
    for _ in range(architecture["maturation_tick"]):
        plastic_base[0].tick()
    references["PLASTIC"] = d06.reference_response(kernel, *plastic_base, architecture)
    configurations, census = select_configurations(kernel, architecture, mature_bases, references)
    rows = []
    for family, selected in configurations.items():
        centers = [row[1] for row in selected]
        outcomes = {regime: run_case(kernel, regime, architecture, centers, references[regime]["masks"])
                    for regime in REGIMES}
        hashes = [outcomes[regime].get("pair_sequence_sha256") for regime in ("A", "B", "SHAM")]
        row = {"family": family, "centers": [list(q) for q in centers],
               "selection_arrival_ticks": [row[0] for row in selected], "outcomes": outcomes,
               "all_valid": all(outcomes[r].get("valid") for r in REGIMES),
               "a_b_pair_response_distinct": hashes[0] != hashes[1],
               "a_b_sham_pairwise_distinct": len(set(hashes)) == 3,
               "any_probe_responsive_pair": any(outcomes[r].get("pairs_ever_probe_responsive", 0) > 0 for r in REGIMES),
               "any_nonlinear_exterior_interaction": any(outcomes[r].get("maximum_exterior_interaction_residue", 0) > 0 for r in REGIMES)}
        rows.append(row)
        print(json.dumps({"family": family, "centers": len(centers), "all_valid": row["all_valid"],
                          "a_b_pair_distinct": row["a_b_pair_response_distinct"],
                          "nonlinear_exterior": row["any_nonlinear_exterior_interaction"]}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.t0_effector_geometries.v1",
        "question": "Can t0-complete point, surface, shell, and volume transducer organizations physically use the diagnostic distributed-regime distinction?",
        "planning": {"mechanism": "identical transducer organizations installed at t0; four-branch probe interaction contrasted with no-effector frozen response",
                     "controls": ["A", "B", "SHAM", "PLASTIC", "probe/no-probe", "no-effector reference masks"],
                     "predicted_outcomes": ["passive exposure", "local transduction", "nonlinear exterior modification", "A/B functional separation"],
                     "estimated_runtime_minutes": 5, "estimated_storage_mb": 2,
                     "stop_condition": "three point phases plus sparse volume, surface, shell and larger volume organizations"},
        "design": {"all_effectors_present_from_t0": True, "diagnostic_probe_at_maturation": True,
                   "transducer_footprint_offsets": [list(q) for q in TRANSDUCER_OFFSETS],
                   "configuration_census": census,
                   "selection_guard": "positions chosen from A-exclusive discovery response, therefore discovery only"},
        "configurations": {key: [{"arrival": row[0], "center": list(row[1])} for row in value]
                           for key, value in configurations.items()},
        "rows": rows,
        "summary": {"families_tested": len(rows), "all_valid_families": sum(row["all_valid"] for row in rows),
                    "families_with_probe_responsive_pairs": sum(row["any_probe_responsive_pair"] for row in rows),
                    "families_with_a_b_pair_separation": sum(row["a_b_pair_response_distinct"] for row in rows),
                    "families_with_nonlinear_exterior_interaction": sum(row["any_nonlinear_exterior_interaction"] for row in rows),
                    "native_distributed_function_demonstrated": False,
                    "fresh_validation_required": True, "rw3_demonstrated": False},
        "claim_guard": "The effector organization is t0-complete, but its placement was selected from discovery telemetry and the late probe remains a diagnostic host insertion. Positive families require freeze/fresh validation and a native consequence source before autonomy claims.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D07_T0_EFFECTOR_GEOMETRIES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
