#!/usr/bin/env python3
"""Fresh frame validation of the t0-complete sparse-shell interaction."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, sha256_file, transform, write_json
import run_distributed_d05_regime_separability_holdout as d05
from run_nature_n07_native_consequence_expression import delta_value


LOCK_PATH = ROOT / "FREEZE/ING03_DR_D08_T0_SHELL_LOCK.json"
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def build_shell(kernel, frame, condition, architecture, with_shell):
    world, meta = d05.build(kernel, frame, condition, architecture)
    permutation, signs = frame
    tf = lambda vector: transform(vector, permutation, signs)
    c = meta["c"]
    centers, pairs, footprint = [], [], []
    if with_shell:
        for raw_offset in architecture["shell_center_offsets"]:
            center = add(c, tf(tuple(raw_offset)), 1, meta["n"])
            q, qp = d05.put_transducer(world.raw_a, world.clock_a, center, meta["n"], tf, 12000)
            centers.append(center); pairs.append((q, qp))
            local_offsets = ((0, 0, 0), (1, 0, 0), (2, 1, 0), (2, -1, 0), (-2, 0, 2), (-2, 0, -2))
            footprint.extend(add(center, tf(offset), 1, meta["n"]) for offset in local_offsets)
        world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"shell_centers": centers, "shell_pairs": pairs,
                                    "shell_footprint": sorted(set(footprint)), "tf": tf})
    return world, meta


def install_probe(world, meta, architecture):
    tf = meta["tf"]
    event = add(meta["b"], tf(tuple(architecture["probe_event_offset"])), 1, meta["n"])
    direction = tf(tuple(architecture["probe_direction"]))
    source = add(event, direction, -architecture["probe_distance"], meta["n"])
    if int(world.raw[source]):
        raise RuntimeError(f"probe overlap {source}")
    set_both(world, source, int(pack(architecture["probe_state"], architecture["probe_s_reg"],
                                          direction, architecture["probe_semantic"])),
             architecture["maturation_tick"])
    return source


def bool_sequence_hash(sequence):
    return hashlib.sha256(np.packbits(np.asarray(sequence, dtype=np.uint8).reshape(-1),
                                      bitorder="little").tobytes()).hexdigest()


def run_case(kernel, frame, condition, architecture):
    try:
        shell_base, shell_meta = build_shell(kernel, frame, condition, architecture, True)
        reference_base, reference_meta = build_shell(kernel, frame, condition, architecture, False)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    for _ in range(architecture["maturation_tick"]):
        shell_base.tick(); reference_base.tick()
    shell_probe = NativeWorld(kernel, shell_base.raw, shell_base.clock_a)
    shell_control = NativeWorld(kernel, shell_base.raw, shell_base.clock_a)
    reference_probe = NativeWorld(kernel, reference_base.raw, reference_base.clock_a)
    reference_control = NativeWorld(kernel, reference_base.raw, reference_base.clock_a)
    try:
        shell_source = install_probe(shell_probe, shell_meta, architecture)
        reference_source = install_probe(reference_probe, reference_meta, architecture)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    pair_flags = []
    response_counts, interaction_counts, exterior_counts = [], [], []
    response_masks, residue_masks = [], []
    footprint_mask = np.zeros(shell_base.raw.shape, dtype=bool)
    for q in shell_meta["shell_footprint"]:
        footprint_mask[q] = True
    pre_delta = delta_value(shell_base, shell_meta)
    for _ in range(architecture["followup_ticks"]):
        shell_probe.tick(); shell_control.tick(); reference_probe.tick(); reference_control.tick()
        response = shell_probe.raw != shell_control.raw
        reference = reference_probe.raw != reference_control.raw
        residue = response ^ reference
        flags = [((int(shell_probe.raw[q]), int(shell_probe.raw[qp])) !=
                  (int(shell_control.raw[q]), int(shell_control.raw[qp])))
                 for q, qp in shell_meta["shell_pairs"]]
        pair_flags.append(flags)
        response_counts.append(int(response.sum()))
        interaction_counts.append(int(residue.sum()))
        exterior_counts.append(int((residue & ~footprint_mask).sum()))
        response_masks.append(response.copy()); residue_masks.append(residue.copy())
    ever_flags = np.any(np.asarray(pair_flags, dtype=bool), axis=0)
    return {
        "condition": condition, "valid": True, "shell_source": list(shell_source),
        "reference_source": list(reference_source), "probe_ports_match": shell_source == reference_source,
        "pre_probe_master_delta": pre_delta, "terminal_master_delta": delta_value(shell_probe, shell_meta),
        "shell_centers": [list(q) for q in shell_meta["shell_centers"]],
        "shell_pairs": [[list(q), list(qp)] for q, qp in shell_meta["shell_pairs"]],
        "pairs_ever_probe_responsive": int(ever_flags.sum()),
        "responsive_pair_indices": np.flatnonzero(ever_flags).astype(int).tolist(),
        "pair_differential_sequence_sha256": bool_sequence_hash(pair_flags),
        "response_count_sequence": response_counts,
        "interaction_count_sequence": interaction_counts,
        "exterior_interaction_count_sequence": exterior_counts,
        "maximum_interaction_residue": max(interaction_counts),
        "maximum_exterior_interaction_residue": max(exterior_counts),
        "canonical_response_mask_sequence_sha256": d05.canonical_mask_digest(response_masks, frame, architecture["n"]),
        "canonical_interaction_mask_sequence_sha256": d05.canonical_mask_digest(residue_masks, frame, architecture["n"]),
        "python_interventions_after_t0": 1,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def prior_frames():
    result = set()
    for path in (ROOT / "HOLDOUT").glob("*CHALLENGES.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        for row in data.get("challenges", []):
            frame = row.get("frame")
            if frame and "permutation" in frame and "signs" in frame:
                result.add((tuple(frame["permutation"]), tuple(frame["signs"])))
    return result


def select_frames(lock):
    identity = ((0, 1, 2), (1, 1, 1))
    excluded = prior_frames() | {identity}
    frames = [(p, s) for p in itertools.permutations((0, 1, 2))
              for s in itertools.product((-1, 1), repeat=3) if (p, s) not in excluded]
    salt = lock["fresh_generation"]["salt"]
    frames.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True,
                     separators=(",", ":")) + salt).encode()).hexdigest())
    expected = lock["fresh_generation"]["fresh_frames"]
    if len(frames) != expected:
        raise RuntimeError(f"frozen design expected exactly {expected} unused frames, observed {len(frames)}")
    return frames


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    frames = select_frames(lock)
    challenges = seal({
        "schema": "dee.v27.ing03.distributed_regime.d08_challenges.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "algorithm": lock["fresh_generation"]["algorithm"], "salt": lock["fresh_generation"]["salt"],
        "prior_frame_count": len(prior_frames()),
        "challenges": [{"id": f"DRD08-{index:02d}", "frame": frame_json(frame)}
                       for index, frame in enumerate(frames, 1)],
        "outcomes_absent_at_generation": True,
    })
    challenge_path = ROOT / "HOLDOUT/ING03_DR_D08_T0_SHELL_CHALLENGES.json"
    write_json(challenge_path, challenges)
    kernel, runtime = load_kernel(1)
    rows = []
    for index, frame in enumerate(frames, 1):
        cid = f"DRD08-{index:02d}"
        for condition in lock["conditions"]:
            row = run_case(kernel, frame, condition, lock["architecture"])
            row.update({"challenge_id": cid, "frame": frame_json(frame)})
            rows.append(row)
        print(json.dumps({"challenge": cid, "completed_conditions": len(lock["conditions"])}, sort_keys=True), flush=True)
    expected = lock["expected_identity_response"]
    exact_fields = ("pairs_ever_probe_responsive", "responsive_pair_indices", "pair_differential_sequence_sha256",
                    "response_count_sequence", "interaction_count_sequence", "exterior_interaction_count_sequence",
                    "canonical_response_mask_sequence_sha256", "canonical_interaction_mask_sequence_sha256",
                    "pre_probe_master_delta", "terminal_master_delta")
    groups = []
    for index, frame in enumerate(frames, 1):
        cid = f"DRD08-{index:02d}"
        by = {row["condition"]: row for row in rows if row["challenge_id"] == cid}
        exact = {condition: all(by[condition].get(field) == expected[condition][field] for field in exact_fields)
                 for condition in lock["conditions"]}
        passed = (len(by) == len(lock["conditions"]) and all(row.get("valid") and row.get("probe_ports_match")
                  and row.get("python_interventions_after_t0") == 1 for row in by.values()) and all(exact.values()))
        groups.append({"challenge_id": cid, "frame": frame_json(frame), "exact_frozen_response": exact,
                       "passed": passed})
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.d08_holdout.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "challenge_content_sha256": challenges["content_sha256"], "rows": rows, "groups": groups,
        "summary": {"fresh_never_previously_used_frames": len(groups), "fresh_world_groups": len(rows),
                    "kernel_worlds_per_group": 4, "passed_groups": sum(row["passed"] for row in groups),
                    "all_passed": all(row["passed"] for row in groups),
                    "t0_shell_diagnostic_transduction_validated": all(row["passed"] for row in groups),
                    "native_unprompted_function_demonstrated": False, "rw3_demonstrated": False},
        "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_DR_D08_T0_SHELL_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
