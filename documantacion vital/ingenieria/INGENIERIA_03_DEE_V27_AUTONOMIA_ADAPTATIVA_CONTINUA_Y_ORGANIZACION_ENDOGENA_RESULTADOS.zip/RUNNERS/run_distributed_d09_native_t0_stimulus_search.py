#!/usr/bin/env python3
"""Search for a t0-complete source that elicits learned-history shell function."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_distributed_d08_t0_shell_holdout as d08
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")
CONFIGURATIONS = (
    {"id": "D10_C000", "distance": 10, "clock": 0},
    {"id": "D10_C064", "distance": 10, "clock": 64},
    {"id": "D10_C128", "distance": 10, "clock": 128},
    {"id": "D10_C184", "distance": 10, "clock": 184},
    {"id": "D10_C252", "distance": 10, "clock": 252},
    {"id": "D16_C000", "distance": 16, "clock": 0},
    {"id": "D16_C184", "distance": 16, "clock": 184},
    {"id": "D20_C000", "distance": 20, "clock": 0},
    {"id": "D20_C184", "distance": 20, "clock": 184},
)
HORIZON = 256


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def sequence_hash(flags):
    return hashlib.sha256(np.packbits(np.asarray(flags, dtype=np.uint8).reshape(-1),
                                      bitorder="little").tobytes()).hexdigest()


def run_case(kernel, condition, architecture, config):
    try:
        treatment, meta = d08.build_shell(kernel, IDENTITY, condition, architecture, True)
        control, control_meta = d08.build_shell(kernel, IDENTITY, condition, architecture, True)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    event = add(meta["b"], tuple(architecture["probe_event_offset"]), 1, meta["n"])
    direction = tuple(architecture["probe_direction"])
    source = add(event, direction, -config["distance"], meta["n"])
    if int(treatment.raw[source]) or int(control.raw[source]):
        return {"condition": condition, "valid": False, "reason": "t0 source overlap", "source": list(source)}
    source_raw = int(pack(architecture["probe_state"], architecture["probe_s_reg"], direction,
                          architecture["probe_semantic"]))
    set_both(treatment, source, source_raw, config["clock"])
    previous_t = delta_value(treatment, meta)
    previous_c = delta_value(control, control_meta)
    transitions_t, transitions_c = [], []
    pair_flags = []
    pair_raw_t = []
    first_pair_response = None
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        dt = delta_value(treatment, meta); dc = delta_value(control, control_meta)
        if dt != previous_t: transitions_t.append({"tick": tick, "before": previous_t, "after": dt})
        if dc != previous_c: transitions_c.append({"tick": tick, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
        flags = [((int(treatment.raw[q]), int(treatment.raw[qp])) !=
                  (int(control.raw[q]), int(control.raw[qp]))) for q, qp in meta["shell_pairs"]]
        if first_pair_response is None and any(flags): first_pair_response = tick
        pair_flags.append(flags)
        pair_raw_t.append([(int(treatment.raw[q]), int(treatment.raw[qp])) for q, qp in meta["shell_pairs"]])
    ever = np.any(np.asarray(pair_flags, dtype=bool), axis=0)
    return {"condition": condition, "valid": True, "source": list(source), "source_raw": source_raw,
            "source_clock": config["clock"], "source_persistent_raw": int(treatment.raw[source]) == source_raw,
            "treatment_master_transitions": transitions_t, "control_master_transitions": transitions_c,
            "terminal_treatment_delta": previous_t, "terminal_control_delta": previous_c,
            "first_pair_response_tick": first_pair_response,
            "pairs_ever_source_responsive": int(ever.sum()),
            "responsive_pair_indices": np.flatnonzero(ever).astype(int).tolist(),
            "pair_differential_sequence_sha256": sequence_hash(pair_flags),
            "pair_treatment_sequence_sha256": hashlib.sha256(json.dumps(pair_raw_t, separators=(",", ":")).encode()).hexdigest(),
            "python_interventions_after_t0": 0}


def main():
    lock = json.loads(d08.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    rows = []
    configs = []
    for config in CONFIGURATIONS:
        outcomes = {condition: run_case(kernel, condition, architecture, config) for condition in CONDITIONS}
        valid = all(outcomes[name].get("valid") for name in CONDITIONS)
        differential_hashes = [outcomes[name].get("pair_differential_sequence_sha256") for name in ("A", "B", "SHAM")]
        first_ab_difference = None
        # Exact flag sequences are summarized by hashes in rows; a difference after native
        # learning is conservatively inferred only when both first responses occur after tick 9.
        first_responses = [outcomes[name].get("first_pair_response_tick") for name in ("A", "B")]
        nonnull = [tick for tick in first_responses if tick is not None]
        if differential_hashes[0] != differential_hashes[1] and nonnull:
            first_ab_difference = min(nonnull)
        candidate = (valid and outcomes["A"].get("terminal_treatment_delta") == 1 and
                     outcomes["B"].get("terminal_treatment_delta") == -1 and
                     outcomes["SHAM"].get("terminal_treatment_delta") == 0 and
                     differential_hashes[0] != differential_hashes[1] and
                     first_ab_difference is not None and first_ab_difference > 9 and
                     all(outcomes[name].get("source_persistent_raw") for name in CONDITIONS))
        row = {"configuration": config, "outcomes": outcomes, "all_valid": valid,
               "a_b_source_specific_pair_response_distinct": differential_hashes[0] != differential_hashes[1],
               "a_b_sham_pairwise_distinct": len(set(differential_hashes)) == 3,
               "first_a_b_response_difference_bound": first_ab_difference,
               "native_state_conditioned_function_candidate": candidate}
        configs.append(row)
        print(json.dumps({"configuration": config["id"], "valid": valid,
                          "first_responses": first_responses, "a_b_distinct": row["a_b_source_specific_pair_response_distinct"],
                          "candidate": candidate}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.native_t0_stimulus_search.v1",
        "question": "Can a fixed answer-neutral t0 source replace the diagnostic late insertion and elicit history-conditioned shell function with no host action?",
        "planning": {"mechanism": "persistent t0 semantic4 support at three causal distances and five phase/clock representatives",
                     "controls": ["paired no-source world", "A", "B", "SHAM", "PLASTIC", "master retention"],
                     "predicted_outcomes": ["early answer-independent response", "learning-disrupting source", "post-learning A/B-specific response", "no response"],
                     "estimated_runtime_minutes": 5, "estimated_storage_mb": 1,
                     "stop_condition": "nine causally distinct distance/phase configurations reach 256 ticks"},
        "design": {"horizon": HORIZON, "configurations": list(CONFIGURATIONS),
                   "shell_center_offsets": architecture["shell_center_offsets"],
                   "all_components_present_at_t0": True, "python_interventions_after_t0": 0,
                   "source_answer_neutral": True},
        "rows": configs,
        "summary": {"configurations": len(configs), "valid_configurations": sum(row["all_valid"] for row in configs),
                    "a_b_distinct_configurations": sum(row["a_b_source_specific_pair_response_distinct"] for row in configs),
                    "native_state_conditioned_function_candidates": sum(row["native_state_conditioned_function_candidate"] for row in configs),
                    "native_distributed_function_demonstrated": False,
                    "freeze_fresh_required_for_any_candidate": True, "rw3_demonstrated": False},
        "claim_guard": "This is mechanism selection. A candidate must be frozen and fresh-tested; a single learned transition would still not establish recurrent adaptation or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D09_NATIVE_T0_STIMULUS_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
