#!/usr/bin/env python3
"""Fresh frame-origin holdout for native t0 history-conditioned shell trajectories."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, transform, write_json
import run_distributed_d08_t0_shell_holdout as d08
from run_nature_n07_native_consequence_expression import delta_value


LOCK_PATH = ROOT / "FREEZE/ING03_DR_D10_NATIVE_TRAJECTORY_LOCK.json"
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def shifted(q, shift, n):
    return tuple((int(q[i]) + int(shift[i])) % n for i in range(3))


def translate_world(world, shift):
    axes = (0, 1, 2)
    world.raw_a = np.ascontiguousarray(np.roll(world.raw_a, shift, axis=axes))
    world.raw_b = np.ascontiguousarray(np.roll(world.raw_b, shift, axis=axes))
    world.clock_a = np.ascontiguousarray(np.roll(world.clock_a, shift, axis=axes))
    world.clock_b = np.ascontiguousarray(np.roll(world.clock_b, shift, axis=axes))


def translate_meta(meta, shift):
    n = meta["n"]
    result = dict(meta)
    for key in ("c", "a", "b", "q_receiver", "qp_receiver"):
        result[key] = shifted(meta[key], shift, n)
    for key in ("shell_centers", "shell_footprint"):
        result[key] = [shifted(q, shift, n) for q in meta[key]]
    result["shell_pairs"] = [(shifted(q, shift, n), shifted(qp, shift, n)) for q, qp in meta["shell_pairs"]]
    return result


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def bool_hash(values):
    return hashlib.sha256(np.packbits(np.asarray(values, dtype=np.uint8).reshape(-1),
                                      bitorder="little").tobytes()).hexdigest()


def canonical_mask_digest(masks, frame, origin, n):
    permutation, signs = frame
    h = hashlib.sha256()
    canonical_center = n // 2
    for mask in masks:
        canonical = np.zeros_like(mask, dtype=bool)
        indices = np.argwhere(mask)
        if len(indices):
            w = (indices.astype(np.int64) - np.asarray(origin) + n // 2) % n - n // 2
            v = np.zeros_like(w)
            for axis in range(3):
                v[:, permutation[axis]] = signs[axis] * w[:, axis]
            q = (v + canonical_center) % n
            canonical[q[:, 0], q[:, 1], q[:, 2]] = True
        h.update(np.packbits(canonical.reshape(-1), bitorder="little").tobytes())
    return h.hexdigest()


def run_case(kernel, frame, shift, condition, architecture):
    try:
        treatment, meta = d08.build_shell(kernel, frame, condition, architecture, True)
        translate_world(treatment, shift); meta = translate_meta(meta, shift)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    control = type(treatment)(kernel, treatment.raw, treatment.clock_a)
    tf = meta["tf"]
    event = add(meta["b"], tf(tuple(architecture["probe_event_offset"])), 1, meta["n"])
    direction = tf(tuple(architecture["probe_direction"]))
    source = add(event, direction, -architecture["native_source_distance"], meta["n"])
    if int(treatment.raw[source]):
        return {"condition": condition, "valid": False, "reason": "t0 source overlap", "source": list(source)}
    source_raw = int(pack(architecture["probe_state"], architecture["probe_s_reg"], direction,
                          architecture["probe_semantic"]))
    set_both(treatment, source, source_raw, architecture["native_source_clock"])
    previous_t = delta_value(treatment, meta); previous_c = delta_value(control, meta)
    transitions_t, transitions_c = [], []
    pair_flags, response_counts, response_masks = [], [], []
    first_pair_response = None
    for tick in range(1, architecture["horizon"] + 1):
        treatment.tick(); control.tick()
        dt = delta_value(treatment, meta); dc = delta_value(control, meta)
        if dt != previous_t: transitions_t.append({"tick": tick, "before": previous_t, "after": dt})
        if dc != previous_c: transitions_c.append({"tick": tick, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
        flags = [((int(treatment.raw[q]), int(treatment.raw[qp])) !=
                  (int(control.raw[q]), int(control.raw[qp]))) for q, qp in meta["shell_pairs"]]
        if first_pair_response is None and any(flags): first_pair_response = tick
        pair_flags.append(flags)
        mask = treatment.raw != control.raw
        response_counts.append(int(mask.sum())); response_masks.append(mask.copy())
    ever = np.any(np.asarray(pair_flags, dtype=bool), axis=0)
    origin = shifted((architecture["n"] // 2,) * 3, shift, architecture["n"])
    return {"condition": condition, "valid": True, "source": list(source), "source_raw": source_raw,
            "source_persistent_raw": int(treatment.raw[source]) == source_raw,
            "treatment_master_transitions": transitions_t, "control_master_transitions": transitions_c,
            "terminal_treatment_delta": previous_t, "terminal_control_delta": previous_c,
            "first_pair_response_tick": first_pair_response,
            "pairs_ever_source_responsive": int(ever.sum()),
            "responsive_pair_indices": np.flatnonzero(ever).astype(int).tolist(),
            "pair_differential_sequence_sha256": bool_hash(pair_flags),
            "pair_response_count_sequence": np.asarray(pair_flags, dtype=np.uint8).sum(axis=1).astype(int).tolist(),
            "world_response_count_sequence": response_counts,
            "canonical_world_response_mask_sequence_sha256": canonical_mask_digest(response_masks, frame, origin, architecture["n"]),
            "python_interventions_after_t0": 0}


def challenge_space(lock):
    identity = ((0, 1, 2), (1, 1, 1))
    frames = [(p, s) for p in itertools.permutations((0, 1, 2))
              for s in itertools.product((-1, 1), repeat=3)]
    shifts = [tuple(v) for v in itertools.product((-13, -7, 5, 11, 17), repeat=3) if v != (0, 0, 0)]
    candidates = [(frame, shift) for frame in frames for shift in shifts
                  if not (frame == identity and shift == (0, 0, 0))]
    salt = lock["fresh_generation"]["salt"]
    candidates.sort(key=lambda item: hashlib.sha256((json.dumps({"frame": frame_json(item[0]), "shift": item[1]},
                     sort_keys=True, separators=(",", ":")) + salt).encode()).hexdigest())
    return candidates[:lock["fresh_generation"]["challenge_pairs"]]


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    challenges_selected = challenge_space(lock)
    challenges = seal({
        "schema": "dee.v27.ing03.distributed_regime.d10_challenges.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "algorithm": lock["fresh_generation"]["algorithm"], "salt": lock["fresh_generation"]["salt"],
        "challenges": [{"id": f"DRD10-{index:02d}", "frame": frame_json(frame), "translation": list(shift)}
                       for index, (frame, shift) in enumerate(challenges_selected, 1)],
        "outcomes_absent_at_generation": True,
    })
    challenge_path = ROOT / "HOLDOUT/ING03_DR_D10_NATIVE_TRAJECTORY_CHALLENGES.json"
    write_json(challenge_path, challenges)
    kernel, runtime = load_kernel(1)
    rows = []
    for index, (frame, shift) in enumerate(challenges_selected, 1):
        cid = f"DRD10-{index:02d}"
        for condition in lock["conditions"]:
            row = run_case(kernel, frame, shift, condition, lock["architecture"])
            row.update({"challenge_id": cid, "frame": frame_json(frame), "translation": list(shift)})
            rows.append(row)
        print(json.dumps({"challenge": cid, "completed_conditions": len(lock["conditions"])}, sort_keys=True), flush=True)
    exact_fields = ("terminal_treatment_delta", "terminal_control_delta", "first_pair_response_tick",
                    "pairs_ever_source_responsive", "responsive_pair_indices", "pair_differential_sequence_sha256",
                    "pair_response_count_sequence", "world_response_count_sequence",
                    "canonical_world_response_mask_sequence_sha256")
    expected = lock["expected_identity_response"]
    groups = []
    for index, (frame, shift) in enumerate(challenges_selected, 1):
        cid = f"DRD10-{index:02d}"
        by = {row["condition"]: row for row in rows if row["challenge_id"] == cid}
        exact = {condition: all(by[condition].get(field) == expected[condition][field] for field in exact_fields)
                 for condition in lock["conditions"]}
        passed = (len(by) == len(lock["conditions"]) and all(row.get("valid") and row.get("source_persistent_raw")
                  and row.get("python_interventions_after_t0") == 0 for row in by.values()) and all(exact.values()))
        groups.append({"challenge_id": cid, "frame": frame_json(frame), "translation": list(shift),
                       "exact_frozen_response": exact, "passed": passed})
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.d10_holdout.v1",
        "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
        "challenge_content_sha256": challenges["content_sha256"], "rows": rows, "groups": groups,
        "summary": {"fresh_frame_origin_pairs": len(groups), "fresh_condition_world_pairs": len(rows),
                    "kernel_worlds": 2 * len(rows), "passed_groups": sum(group["passed"] for group in groups),
                    "all_passed": all(group["passed"] for group in groups),
                    "native_history_conditioned_trajectory_function_validated": all(group["passed"] for group in groups),
                    "rw3_demonstrated": False},
        "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_DR_D10_NATIVE_TRAJECTORY_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
