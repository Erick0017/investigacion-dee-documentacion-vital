#!/usr/bin/env python3
"""Test whether the native distributed trajectory can write a reserve learner."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_distributed_d08_t0_shell_holdout as d08
import run_distributed_d10_native_trajectory_holdout as d10
import run_reactivation_r09_distributed_rotated_array as r09
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
HORIZON = 400
FRAMES = ("x", "y", "z")


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install_native_source(world, meta, architecture):
    event = add(meta["b"], tuple(architecture["probe_event_offset"]), 1, meta["n"])
    direction = tuple(architecture["probe_direction"])
    source = add(event, direction, -architecture["native_source_distance"], meta["n"])
    if int(world.raw[source]): raise RuntimeError(f"source overlap {source}")
    raw = int(pack(architecture["probe_state"], architecture["probe_s_reg"], direction,
                   architecture["probe_semantic"]))
    set_both(world, source, raw, architecture["native_source_clock"])
    return source, raw


def reference_arrival(kernel, architecture):
    treatment, meta = d08.build_shell(kernel, IDENTITY, "A", architecture, True)
    control, _ = d08.build_shell(kernel, IDENTITY, "A", architecture, True)
    install_native_source(treatment, meta, architecture)
    arrival = np.full(treatment.raw.shape, -1, dtype=np.int16)
    for tick in range(1, 257):
        treatment.tick(); control.tick()
        mask = treatment.raw != control.raw
        arrival[(arrival < 0) & mask] = tick
    return arrival, meta


def center_for_writer(writer_q, frame, n):
    axis = r09.transform((1, 0, 0), frame)
    event_offset = r09.transform((0, -1, 0), frame)
    route = r09.transform((0, 0, 1), frame)
    center = add(writer_q, axis, -1, n)
    center = add(center, event_offset, -1, n)
    center = add(center, route, 3, n)
    return center


def learner_positions(center, frame, n):
    axis = r09.transform((1, 0, 0), frame)
    a = add(center, axis, -1, n); b = add(center, axis, 1, n)
    positions = [a, b]
    positions.extend(add(a, r09.transform(rel, frame), 1, n) for rel in PA)
    positions.extend(add(b, r09.transform(rel, frame), 1, n) for rel in PB)
    return positions


def select_candidates(kernel, architecture):
    arrival, meta = reference_arrival(kernel, architecture)
    base, base_meta = d08.build_shell(kernel, IDENTITY, "A", architecture, True)
    event = add(base_meta["b"], tuple(architecture["probe_event_offset"]), 1, base_meta["n"])
    source = add(event, tuple(architecture["probe_direction"]), -architecture["native_source_distance"], base_meta["n"])
    candidates = {frame: [] for frame in FRAMES}
    rows = np.argwhere(arrival >= 100)
    for raw_q in rows:
        writer_q = tuple(int(x) for x in raw_q)
        for frame in FRAMES:
            center = center_for_writer(writer_q, frame, meta["n"])
            positions = learner_positions(center, frame, meta["n"])
            if source == writer_q or len(set(positions)) != len(positions):
                continue
            if any(int(base.raw[q]) for q in positions):
                continue
            candidate = {"writer_q": writer_q, "center": center, "frame": frame,
                         "reference_arrival_tick": int(arrival[writer_q])}
            candidates[frame].append(candidate)
    selected = []
    for frame in FRAMES:
        rows = sorted(candidates[frame], key=lambda row: (row["reference_arrival_tick"], row["writer_q"]))
        if not rows: continue
        for index, phase in ((0, "EARLY"), (len(rows) // 2, "MIDDLE"), (-1, "LATE")):
            row = dict(rows[index]); row["phase"] = phase
            if row["writer_q"] not in [x["writer_q"] for x in selected if x["frame"] == frame]:
                selected.append(row)
    return selected, {frame: len(rows) for frame, rows in candidates.items()}


def build_world(kernel, condition, architecture, candidate, with_shell, with_source):
    if with_shell:
        world, meta = d08.build_shell(kernel, IDENTITY, condition, architecture, True)
    else:
        world, meta = d08.build_shell(kernel, IDENTITY, condition, architecture, False)
    node = r09.add_rotated_learner(world, meta, candidate["center"], 81, candidate["frame"])
    source = source_raw = None
    if with_source:
        source, source_raw = install_native_source(world, meta, architecture)
    return world, meta, node, source, source_raw


def run_pair(kernel, condition, architecture, candidate, with_shell=True):
    try:
        treatment, meta, node, source, source_raw = build_world(kernel, condition, architecture, candidate, with_shell, True)
        control, control_meta, control_node, _, _ = build_world(kernel, condition, architecture, candidate, with_shell, False)
    except RuntimeError as exc:
        return {"condition": condition, "with_shell": with_shell, "valid": False, "reason": str(exc)}
    previous_t = r09.delta(treatment, node); previous_c = r09.delta(control, control_node)
    p0_previous_t = delta_value(treatment, meta); p0_previous_c = delta_value(control, control_meta)
    transitions_t, transitions_c, p0_t, p0_c = [], [], [], []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        value_t = r09.delta(treatment, node); value_c = r09.delta(control, control_node)
        if value_t != previous_t: transitions_t.append({"tick": tick, "before": previous_t, "after": value_t})
        if value_c != previous_c: transitions_c.append({"tick": tick, "before": previous_c, "after": value_c})
        previous_t, previous_c = value_t, value_c
        now_t = delta_value(treatment, meta); now_c = delta_value(control, control_meta)
        if now_t != p0_previous_t: p0_t.append({"tick": tick, "before": p0_previous_t, "after": now_t})
        if now_c != p0_previous_c: p0_c.append({"tick": tick, "before": p0_previous_c, "after": now_c})
        p0_previous_t, p0_previous_c = now_t, now_c
    source_specific = [row for row in transitions_t if row not in transitions_c]
    return {"condition": condition, "with_shell": with_shell, "valid": True,
            "source": list(source), "source_persistent_raw": int(treatment.raw[source]) == source_raw,
            "reserve_treatment_transitions": transitions_t, "reserve_control_transitions": transitions_c,
            "reserve_source_specific_transitions": source_specific,
            "reserve_terminal_treatment": previous_t, "reserve_terminal_control": previous_c,
            "primary_treatment_transitions": p0_t, "primary_control_transitions": p0_c,
            "primary_terminal_treatment": p0_previous_t, "primary_terminal_control": p0_previous_c,
            "python_interventions_after_t0": 0}


def main():
    lock = json.loads(d10.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    candidates, census = select_candidates(kernel, architecture)
    screens = []
    for candidate in candidates:
        outcome = run_pair(kernel, "A", architecture, candidate, True)
        success = (outcome.get("valid") and bool(outcome.get("reserve_source_specific_transitions")) and
                   min(row["tick"] for row in outcome["reserve_source_specific_transitions"]) >=
                   candidate["reference_arrival_tick"])
        screens.append({"candidate": {key: list(value) if isinstance(value, tuple) else value
                                       for key, value in candidate.items()},
                        "a_outcome": outcome, "native_reserve_write_candidate": success})
        print(json.dumps({"frame": candidate["frame"], "phase": candidate["phase"],
                          "arrival": candidate["reference_arrival_tick"], "success": success}), flush=True)
    positives = [row for row in screens if row["native_reserve_write_candidate"]]
    controls = []
    for row in positives:
        raw = row["candidate"]
        candidate = {**raw, "writer_q": tuple(raw["writer_q"]), "center": tuple(raw["center"])}
        outcomes = {condition: run_pair(kernel, condition, architecture, candidate, True)
                    for condition in ("B", "SHAM", "PLASTIC")}
        outcomes["A_NO_SHELL"] = run_pair(kernel, "A", architecture, candidate, False)
        controls.append({"candidate": raw, "outcomes": outcomes,
                         "shell_necessary": (not outcomes["A_NO_SHELL"].get("reserve_source_specific_transitions")),
                         "state_specific": len({json.dumps(outcomes[name].get("reserve_source_specific_transitions"), sort_keys=True)
                                                for name in ("B", "SHAM", "PLASTIC")}) > 1})
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.native_reserve_coupling.v1",
        "question": "Can the validated native collective trajectory causally write a spatially separate still-plastic relational reserve?",
        "planning": {"mechanism": "backward-align reserve writer surfaces with A source-specific distributed response positions",
                     "controls": ["paired no-source", "B", "SHAM", "PLASTIC", "shell ablation"],
                     "predicted_outcomes": ["no reserve interaction", "source direct write independent of shell", "shell-mediated reserve write", "history-specific reserve write"],
                     "estimated_runtime_minutes": 5, "estimated_storage_mb": 2,
                     "stop_condition": "early/middle/late candidates in all three relational frames plus state and shell controls for positives"},
        "design": {"horizon": HORIZON, "reference_arrival_minimum": 100,
                   "candidate_census": census, "selected_candidates": len(candidates),
                   "all_components_present_at_t0": True, "python_interventions_after_t0": 0},
        "screens": screens, "positive_controls": controls,
        "summary": {"selected_candidates": len(candidates),
                    "native_reserve_write_candidates": len(positives),
                    "shell_necessary_candidates": sum(row["shell_necessary"] for row in controls),
                    "state_specific_candidates": sum(row["state_specific"] for row in controls),
                    "native_second_learning_demonstrated": False,
                    "functional_delegation_to_reserve_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "A reserve change would first establish native causal coupling from the trajectory to a second plastic organization. It would not count as RW3 unless it stores a genuinely later environmental consequence and produces corresponding later function.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D11_NATIVE_RESERVE_COUPLING.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
