#!/usr/bin/env python3
"""Direct competence controls and state taxonomy for the D11 coupling null."""
from __future__ import annotations

import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_distributed_d08_t0_shell_holdout as d08
import run_distributed_d11_native_reserve_coupling as d11
import run_reactivation_r09_distributed_rotated_array as r09


D11_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D11_NATIVE_RESERVE_COUPLING.json"
HORIZON = 400


def direct_control(kernel, architecture, candidate):
    try:
        world, meta = d08.build_shell(kernel, d11.IDENTITY, "A", architecture, True)
        node = r09.add_rotated_learner(world, meta, candidate["center"], 81, candidate["frame"])
    except RuntimeError as exc:
        return {"valid": False, "reason": str(exc)}
    previous = r09.delta(world, node); transitions = []; installed = None
    tick_install = candidate["reference_arrival_tick"]
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == tick_install:
            installed = {"q": list(node["writer_q"]), "replaced_raw": int(world.raw[node["writer_q"]]),
                         "writer_raw": node["writer_raw"]}
            d11.set_both(world, node["writer_q"], node["writer_raw"], tick)
        value = r09.delta(world, node)
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    post = [row for row in transitions if row["tick"] > tick_install]
    return {"valid": True, "install_tick": tick_install, "installed": installed,
            "transitions": transitions, "post_install_transitions": post,
            "direct_write_competent": bool(post), "terminal_delta": previous,
            "python_interventions_after_t0": 1, "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def signed_nibble(values, shift):
    result = ((values >> np.uint64(shift)) & np.uint64(15)).astype(np.int16)
    result[result >= 8] -= 16
    return result


def accumulate_classes(counter, values):
    if not len(values): return
    semantic = ((values >> np.uint64(60)) & np.uint64(15)).astype(np.int16)
    sreg = ((values >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.int32)
    matrix = np.column_stack((semantic, sreg, signed_nibble(values, 48),
                              signed_nibble(values, 52), signed_nibble(values, 56)))
    unique, counts = np.unique(matrix, axis=0, return_counts=True)
    for row, count in zip(unique.tolist(), counts.tolist()):
        counter[(row[0], row[1], (row[2], row[3], row[4]))] += int(count)


def state_taxonomy(kernel, architecture, condition):
    treatment, meta = d08.build_shell(kernel, d11.IDENTITY, condition, architecture, True)
    control, _ = d08.build_shell(kernel, d11.IDENTITY, condition, architecture, True)
    d11.install_native_source(treatment, meta, architecture)
    transition_counts = Counter(); treatment_classes = Counter(); control_classes = Counter()
    pair_samples = []
    first_difference = None
    for tick in range(1, 257):
        treatment.tick(); control.tick()
        mask = treatment.raw != control.raw
        if mask.any() and first_difference is None: first_difference = tick
        tv = treatment.raw[mask]; cv = control.raw[mask]
        left_semantic = ((cv >> np.uint64(60)) & np.uint64(15)).astype(np.int16)
        right_semantic = ((tv >> np.uint64(60)) & np.uint64(15)).astype(np.int16)
        encoded = left_semantic * 16 + right_semantic
        unique, counts = np.unique(encoded, return_counts=True)
        for value, count in zip(unique.tolist(), counts.tolist()):
            transition_counts[(int(value) // 16, int(value) % 16)] += int(count)
        accumulate_classes(treatment_classes, tv)
        accumulate_classes(control_classes, cv)
        flags = []
        for q, qp in meta["shell_pairs"]:
            flags.append({"q_t": int(treatment.raw[q]), "qp_t": int(treatment.raw[qp]),
                          "q_c": int(control.raw[q]), "qp_c": int(control.raw[qp])})
        if tick in (1, 9, 38, 100, 123, 125, 138, 142, 184, 208, 256):
            pair_samples.append({"tick": tick, "pairs": flags})
    writer_like = sum(count for (semantic, sreg, direction), count in treatment_classes.items()
                      if semantic == 4 and sreg == 0 and direction != (0, 0, 0))
    return {"condition": condition, "first_world_difference_tick": first_difference,
            "semantic_transition_counts": {f"{left}->{right}": count for (left, right), count in transition_counts.most_common()},
            "top_treatment_state_classes": [{"semantic": key[0], "sreg": key[1], "direction": list(key[2]), "count": count}
                                            for key, count in treatment_classes.most_common(64)],
            "top_control_state_classes": [{"semantic": key[0], "sreg": key[1], "direction": list(key[2]), "count": count}
                                          for key, count in control_classes.most_common(32)],
            "writer_like_semantic4_sreg0_directed_voxel_ticks": writer_like,
            "pair_samples": pair_samples}


def main():
    lock = json.loads(d11.d10.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    prior = json.loads(D11_PATH.read_text(encoding="utf-8"))
    candidates = []
    for row in prior["screens"]:
        raw = row["candidate"]
        candidates.append({**raw, "writer_q": tuple(raw["writer_q"]), "center": tuple(raw["center"])})
    kernel, runtime = load_kernel(1)
    controls = []
    for candidate in candidates:
        outcome = direct_control(kernel, architecture, candidate)
        controls.append({"candidate": {key: list(value) if isinstance(value, tuple) else value
                                       for key, value in candidate.items()}, "outcome": outcome})
        print(json.dumps({"frame": candidate["frame"], "phase": candidate["phase"],
                          "direct_competent": outcome.get("direct_write_competent")}), flush=True)
    taxonomy = [state_taxonomy(kernel, architecture, condition) for condition in ("A", "B", "SHAM")]
    competent = [row for row in controls if row["outcome"].get("direct_write_competent")]
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.reserve_competence_and_taxonomy.v1",
        "question": "Did D11 fail because reserves were noncompetent, or because the distributed trajectory lacked the required writer-class interaction?",
        "planning": {"mechanism": "exact competent-writer installation at each D11 arrival tick plus full raw transition taxonomy",
                     "controls": ["same reserve geometry", "same install tick", "known writer raw", "A/B/SHAM trajectory classes"],
                     "predicted_outcomes": ["reserve incompetence", "competent reserve but non-writer trajectory", "latent writer-class states without geometric collision"],
                     "estimated_runtime_minutes": 4, "estimated_storage_mb": 4,
                     "stop_condition": "all nine D11 candidates and three trajectory classes characterized"},
        "direct_competence_controls": controls, "trajectory_state_taxonomy": taxonomy,
        "summary": {"candidates": len(controls), "direct_write_competent_candidates": len(competent),
                    "d11_null_attributable_only_to_reserve_incompetence": len(competent) == 0,
                    "writer_like_state_counts": {row["condition"]: row["writer_like_semantic4_sreg0_directed_voxel_ticks"]
                                                 for row in taxonomy},
                    "native_state_conversion_still_required": len(competent) > 0,
                    "rw3_demonstrated": False},
        "claim_guard": "Writer installations are diagnostic interventions. Taxonomy is descriptive until candidate state classes are causally ablated/reconstructed.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D12_RESERVE_COMPETENCE_AND_STATE_TAXONOMY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
