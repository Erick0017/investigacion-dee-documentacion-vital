#!/usr/bin/env python3
"""Test distributed-regime contact throughout the demonstrated reserve competence window."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_distributed_d08_t0_shell_holdout as d08
import run_distributed_d11_native_reserve_coupling as d11
import run_distributed_d12_reserve_competence_and_state_taxonomy as d12


TARGET_TICKS = (12, 24, 48, 72, 96)
FRAME = "x"


def candidates(kernel, architecture):
    arrival, meta = d11.reference_arrival(kernel, architecture)
    base, _ = d08.build_shell(kernel, d11.IDENTITY, "A", architecture, True)
    event = add(meta["b"], tuple(architecture["probe_event_offset"]), 1, meta["n"])
    source = add(event, tuple(architecture["probe_direction"]), -architecture["native_source_distance"], meta["n"])
    rows = []
    for raw_q in np.argwhere((arrival >= 10) & (arrival <= 99)):
        writer_q = tuple(int(x) for x in raw_q)
        center = d11.center_for_writer(writer_q, FRAME, meta["n"])
        positions = d11.learner_positions(center, FRAME, meta["n"])
        if source == writer_q or len(set(positions)) != len(positions) or any(int(base.raw[q]) for q in positions):
            continue
        rows.append({"writer_q": writer_q, "center": center, "frame": FRAME,
                     "reference_arrival_tick": int(arrival[writer_q])})
    selected = []
    for target in TARGET_TICKS:
        available = [row for row in rows if row["writer_q"] not in [old["writer_q"] for old in selected]]
        selected.append(min(available, key=lambda row: (abs(row["reference_arrival_tick"] - target),
                                                        row["reference_arrival_tick"], row["writer_q"])))
    return selected, len(rows)


def main():
    lock = json.loads(d11.d10.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    selected, census = candidates(kernel, architecture)
    rows = []
    for target, candidate in zip(TARGET_TICKS, selected):
        native = d11.run_pair(kernel, "A", architecture, candidate, True)
        direct = d12.direct_control(kernel, architecture, candidate)
        native_specific = native.get("reserve_source_specific_transitions", [])
        row = {"target_tick": target,
               "candidate": {key: list(value) if isinstance(value, tuple) else value
                             for key, value in candidate.items()},
               "native_trajectory_outcome": native, "direct_writer_control": direct,
               "native_write": bool(native_specific), "direct_competent": direct.get("direct_write_competent", False)}
        rows.append(row)
        print(json.dumps({"target": target, "arrival": candidate["reference_arrival_tick"],
                          "native_write": row["native_write"], "direct_competent": row["direct_competent"]}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.early_competence_overlap.v1",
        "question": "Does native distributed-regime contact write a reserve anywhere inside its demonstrated competent window, when an exact writer at the same tick succeeds?",
        "planning": {"mechanism": "co-register source-specific response arrival with competent reserve writer surface at five temporal strata",
                     "controls": ["paired no-source world", "exact diagnostic writer at the same arrival tick"],
                     "predicted_outcomes": ["early native write", "timing-dependent boundary", "competent reserve but state-class mismatch"],
                     "estimated_runtime_minutes": 3, "estimated_storage_mb": 1,
                     "stop_condition": "five separated temporal strata from tick12 through tick96"},
        "design": {"frame": FRAME, "target_ticks": list(TARGET_TICKS), "candidate_census": census,
                   "native_worlds_t0_complete": True, "direct_controls_are_diagnostic_interventions": True},
        "rows": rows,
        "summary": {"temporal_strata": len(rows), "native_writes": sum(row["native_write"] for row in rows),
                    "direct_competent_controls": sum(row["direct_competent"] for row in rows),
                    "all_native_null_while_direct_competent": all(not row["native_write"] and row["direct_competent"] for row in rows),
                    "timing_only_explanation_rejected_in_tested_window": all(not row["native_write"] and row["direct_competent"] for row in rows),
                    "native_writer_conversion_or_gating_missing": all(not row["native_write"] and row["direct_competent"] for row in rows),
                    "rw3_demonstrated": False},
        "claim_guard": "The bounded conclusion applies to the tested x-frame placements and ticks12..96. Together with D11/D12 it motivates a conversion/gating mechanism; it does not prove that no other DEE organization can write a reserve.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D13_EARLY_COMPETENCE_OVERLAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
