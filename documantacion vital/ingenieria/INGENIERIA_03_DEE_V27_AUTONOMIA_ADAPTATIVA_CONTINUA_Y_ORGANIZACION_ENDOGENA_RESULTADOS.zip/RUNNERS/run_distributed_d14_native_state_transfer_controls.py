#!/usr/bin/env python3
"""Controls for the surprising D13 native write into a reserve organization."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_distributed_d11_native_reserve_coupling as d11
import run_distributed_d13_early_competence_overlap as d13


D13_PATH = ROOT / "MECHANISM_SELECTION/ING03_DR_D13_EARLY_COMPETENCE_OVERLAP.json"
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")
FRAMES = ("x", "y", "z")


def main():
    lock = json.loads(d11.d10.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    discovery = json.loads(D13_PATH.read_text(encoding="utf-8"))
    positive = next(row for row in discovery["rows"] if row["native_write"])
    writer_q = tuple(positive["candidate"]["writer_q"])
    kernel, runtime = load_kernel(1)
    rows = []
    for frame in FRAMES:
        candidate = {"writer_q": writer_q,
                     "center": d11.center_for_writer(writer_q, frame, architecture["n"]),
                     "frame": frame, "reference_arrival_tick": positive["candidate"]["reference_arrival_tick"],
                     "phase": "D13_T96"}
        outcomes = {condition: d11.run_pair(kernel, condition, architecture, candidate, True)
                    for condition in CONDITIONS}
        no_shell = {condition: d11.run_pair(kernel, condition, architecture, candidate, False)
                    for condition in ("A", "B")}
        terminals = {condition: outcomes[condition].get("reserve_terminal_treatment") for condition in CONDITIONS}
        source_specific = {condition: outcomes[condition].get("reserve_source_specific_transitions", [])
                           for condition in CONDITIONS}
        row = {"frame": frame, "candidate": {**candidate, "writer_q": list(writer_q),
                                                "center": list(candidate["center"])},
               "outcomes": outcomes, "no_shell_outcomes": no_shell,
               "all_valid": all(outcomes[name].get("valid") for name in CONDITIONS) and
                            all(no_shell[name].get("valid") for name in ("A", "B")),
               "terminal_reserve_states": terminals,
               "a_b_distinct_reserve_states": terminals["A"] != terminals["B"],
               "a_b_source_specific": bool(source_specific["A"]) and bool(source_specific["B"]),
               "sham_plastic_unchanged": not source_specific["SHAM"] and not source_specific["PLASTIC"],
               "shell_necessary_a": not no_shell["A"].get("reserve_source_specific_transitions"),
               "shell_necessary_b": not no_shell["B"].get("reserve_source_specific_transitions")}
        rows.append(row)
        print(json.dumps({"frame": frame, "valid": row["all_valid"], "terminals": terminals,
                          "shell_necessary": [row["shell_necessary_a"], row["shell_necessary_b"]]}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.native_state_transfer_controls.v1",
        "question": "Does the D13 native reserve write depend on learned A/B history and the sparse-shell organization rather than source presence alone?",
        "planning": {"mechanism": "same response-intersection writer surface in three relational frames",
                     "controls": ["A", "B", "SHAM", "PLASTIC", "paired no-source", "shell ablation"],
                     "predicted_outcomes": ["A-only geometry artifact", "source-only write", "shell-dependent history-specific transfer", "frame-general transfer"],
                     "estimated_runtime_minutes": 4, "estimated_storage_mb": 2,
                     "stop_condition": "all four histories plus A/B shell ablations in x/y/z"},
        "design": {"writer_q": list(writer_q), "reference_arrival_tick": positive["candidate"]["reference_arrival_tick"],
                   "frames": list(FRAMES), "horizon": d11.HORIZON,
                   "all_promising_worlds_t0_complete": True, "python_interventions_after_t0": 0},
        "rows": rows,
        "summary": {"frames": len(rows), "all_valid_frames": sum(row["all_valid"] for row in rows),
                    "frames_with_a_b_distinct_reserve_states": sum(row["a_b_distinct_reserve_states"] for row in rows),
                    "frames_with_a_b_source_specific_writes": sum(row["a_b_source_specific"] for row in rows),
                    "frames_with_sham_plastic_unchanged": sum(row["sham_plastic_unchanged"] for row in rows),
                    "frames_with_shell_necessary_for_both": sum(row["shell_necessary_a"] and row["shell_necessary_b"] for row in rows),
                    "native_history_to_reserve_state_transfer_candidate": any(row["a_b_distinct_reserve_states"] and
                        row["a_b_source_specific"] and row["sham_plastic_unchanged"] for row in rows),
                    "fresh_validation_required": True,
                    "later_independent_experience_demonstrated": False,
                    "reserve_to_function_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "A positive result is native transfer/delegation of the first learned history into a second retained organization. It is not yet a second independent environmental learning event, recurrent function, or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D14_NATIVE_STATE_TRANSFER_CONTROLS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
