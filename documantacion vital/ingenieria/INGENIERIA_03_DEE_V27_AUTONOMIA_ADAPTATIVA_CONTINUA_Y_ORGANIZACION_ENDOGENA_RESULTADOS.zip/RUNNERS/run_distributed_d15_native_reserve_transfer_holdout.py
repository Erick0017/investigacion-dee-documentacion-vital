#!/usr/bin/env python3
"""Fresh validation of native A-history transfer into a separate reserve."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, sha256_file, transform, write_json
import run_distributed_d08_t0_shell_holdout as d08
import run_distributed_d10_native_trajectory_holdout as d10
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_nature_n07_native_consequence_expression import delta_value


LOCK_PATH = ROOT / "FREEZE/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_LOCK.json"
CONDITIONS = ("A", "B", "SHAM", "PLASTIC")


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def put(world, q, raw, clock):
    if int(world.raw[q]): raise RuntimeError(f"reserve overlap {q}")
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def add_reserve(world, meta, frame, architecture):
    permutation, signs = frame
    tf = lambda vector: transform(vector, permutation, signs)
    n = meta["n"]
    center = add(meta["c"], tf(tuple(architecture["reserve_center_offset"])), 1, n)
    axis = tf((1, 0, 0)); a = add(center, axis, -1, n); b = add(center, axis, 1, n)
    put(world, a, int(pack(26000, 100, semantic=1)), 252)
    put(world, b, int(pack(26001, 100, semantic=1)), 252)
    for index, rel in enumerate(PA):
        put(world, add(a, tf(rel), 1, n), int(pack(26100 + index, 0, semantic=4)), 31 + index)
    for index, rel in enumerate(PB):
        put(world, add(b, tf(rel), 1, n), int(pack(26200 + index, 0, semantic=4)), 41 + index)
    event = add(b, tf((0, -1, 0)), 1, n); route = tf((0, 0, 1))
    writer_q = add(event, route, -3, n)
    return {"center": center, "a": a, "b": b, "writer_q": writer_q}


def reserve_delta(world, node):
    a, b = read(world.raw, node["a"]), read(world.raw, node["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def build(kernel, frame, shift, condition, architecture):
    world, meta = d08.build_shell(kernel, frame, condition, architecture, False)
    node = add_reserve(world, meta, frame, architecture)
    d10.translate_world(world, shift)
    meta = d10.translate_meta(meta, shift)
    node = {key: d10.shifted(value, shift, architecture["n"]) for key, value in node.items()}
    return world, meta, node


def install_source(world, meta, architecture):
    tf = meta["tf"]
    event = add(meta["b"], tf(tuple(architecture["probe_event_offset"])), 1, meta["n"])
    direction = tf(tuple(architecture["probe_direction"]))
    source = add(event, direction, -architecture["native_source_distance"], meta["n"])
    if int(world.raw[source]): raise RuntimeError(f"source overlap {source}")
    raw = int(pack(architecture["probe_state"], architecture["probe_s_reg"], direction,
                   architecture["probe_semantic"]))
    world.raw_a[source] = np.uint64(raw); world.raw_b[source] = np.uint64(raw)
    world.clock_a[source] = np.uint64(architecture["native_source_clock"])
    world.clock_b[source] = np.uint64(architecture["native_source_clock"])
    return source, raw


def run_case(kernel, frame, shift, condition, architecture):
    try:
        treatment, meta, node = build(kernel, frame, shift, condition, architecture)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    control = type(treatment)(kernel, treatment.raw, treatment.clock_a)
    try:
        source, source_raw = install_source(treatment, meta, architecture)
    except RuntimeError as exc:
        return {"condition": condition, "valid": False, "reason": str(exc)}
    p_prev_t = delta_value(treatment, meta); p_prev_c = delta_value(control, meta)
    r_prev_t = reserve_delta(treatment, node); r_prev_c = reserve_delta(control, node)
    pt, pc, rt, rc = [], [], [], []
    masks, counts = [], []
    for tick in range(1, architecture["horizon"] + 1):
        treatment.tick(); control.tick()
        p_t = delta_value(treatment, meta); p_c = delta_value(control, meta)
        r_t = reserve_delta(treatment, node); r_c = reserve_delta(control, node)
        if p_t != p_prev_t: pt.append({"tick": tick, "before": p_prev_t, "after": p_t})
        if p_c != p_prev_c: pc.append({"tick": tick, "before": p_prev_c, "after": p_c})
        if r_t != r_prev_t: rt.append({"tick": tick, "before": r_prev_t, "after": r_t})
        if r_c != r_prev_c: rc.append({"tick": tick, "before": r_prev_c, "after": r_c})
        p_prev_t, p_prev_c, r_prev_t, r_prev_c = p_t, p_c, r_t, r_c
        mask = treatment.raw != control.raw; masks.append(mask.copy()); counts.append(int(mask.sum()))
    origin = d10.shifted((architecture["n"] // 2,) * 3, shift, architecture["n"])
    return {"condition": condition, "valid": True, "source": list(source),
            "source_persistent_raw": int(treatment.raw[source]) == source_raw,
            "primary_treatment_transitions": pt, "primary_control_transitions": pc,
            "reserve_treatment_transitions": rt, "reserve_control_transitions": rc,
            "primary_terminal_treatment": p_prev_t, "primary_terminal_control": p_prev_c,
            "reserve_terminal_treatment": r_prev_t, "reserve_terminal_control": r_prev_c,
            "world_response_count_sequence": counts,
            "canonical_world_response_mask_sequence_sha256": d10.canonical_mask_digest(
                masks, frame, origin, architecture["n"]),
            "python_interventions_after_t0": 0}


def challenge_space(lock):
    frames = [(p, s) for p in itertools.permutations((0, 1, 2))
              for s in itertools.product((-1, 1), repeat=3)]
    shifts = [tuple(v) for v in itertools.product((-17, -11, -5, 7, 13), repeat=3)]
    candidates = [(frame, shift) for frame in frames for shift in shifts]
    salt = lock["fresh_generation"]["salt"]
    candidates.sort(key=lambda item: hashlib.sha256((json.dumps({"frame": frame_json(item[0]), "shift": item[1]},
                    sort_keys=True, separators=(",", ":")) + salt).encode()).hexdigest())
    return candidates[:lock["fresh_generation"]["challenge_pairs"]]


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    selected = challenge_space(lock)
    challenges = seal({"schema": "dee.v27.ing03.distributed_regime.d15_challenges.v1",
                       "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
                       "algorithm": lock["fresh_generation"]["algorithm"], "salt": lock["fresh_generation"]["salt"],
                       "challenges": [{"id": f"DRD15-{i:02d}", "frame": frame_json(frame), "translation": list(shift)}
                                      for i, (frame, shift) in enumerate(selected, 1)],
                       "outcomes_absent_at_generation": True})
    write_json(ROOT / "HOLDOUT/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_CHALLENGES.json", challenges)
    kernel, runtime = load_kernel(1); rows = []
    for i, (frame, shift) in enumerate(selected, 1):
        cid = f"DRD15-{i:02d}"
        for condition in lock["conditions"]:
            row = run_case(kernel, frame, shift, condition, lock["architecture"])
            row.update({"challenge_id": cid, "frame": frame_json(frame), "translation": list(shift)}); rows.append(row)
        print(json.dumps({"challenge": cid, "completed_conditions": len(lock["conditions"])}, sort_keys=True), flush=True)
    exact_fields = ("primary_treatment_transitions", "primary_control_transitions",
                    "reserve_treatment_transitions", "reserve_control_transitions",
                    "primary_terminal_treatment", "primary_terminal_control",
                    "reserve_terminal_treatment", "reserve_terminal_control",
                    "world_response_count_sequence", "canonical_world_response_mask_sequence_sha256")
    expected = lock["expected_identity_response"]; groups = []
    for i, (frame, shift) in enumerate(selected, 1):
        cid = f"DRD15-{i:02d}"; by = {row["condition"]: row for row in rows if row["challenge_id"] == cid}
        exact = {condition: all(by[condition].get(field) == expected[condition][field] for field in exact_fields)
                 for condition in lock["conditions"]}
        passed = (len(by) == len(lock["conditions"]) and all(row.get("valid") and row.get("source_persistent_raw")
                  and row.get("python_interventions_after_t0") == 0 for row in by.values()) and all(exact.values()))
        groups.append({"challenge_id": cid, "frame": frame_json(frame), "translation": list(shift),
                       "exact_frozen_response": exact, "passed": passed})
    result = seal({"schema": "dee.v27.ing03.distributed_regime.d15_holdout.v1",
                   "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
                   "challenge_content_sha256": challenges["content_sha256"], "rows": rows, "groups": groups,
                   "summary": {"fresh_frame_origin_pairs": len(groups), "condition_pairs": len(rows),
                               "kernel_worlds": 2 * len(rows), "passed_groups": sum(row["passed"] for row in groups),
                               "all_passed": all(row["passed"] for row in groups),
                               "native_a_history_to_reserve_transfer_validated": all(row["passed"] for row in groups),
                               "rw3_demonstrated": False},
                   "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime})
    output = ROOT / "HOLDOUT/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_HOLDOUT.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
