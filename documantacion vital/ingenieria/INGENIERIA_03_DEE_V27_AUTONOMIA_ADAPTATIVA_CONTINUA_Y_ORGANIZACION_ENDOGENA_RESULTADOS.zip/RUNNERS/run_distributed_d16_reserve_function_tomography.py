#!/usr/bin/env python3
"""Diagnostic causal tomography of the newly validated reserve state."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, read, seal, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
INTERVENTION_TICK = 141
FOLLOWUP = 256
SREG_CLEAR = np.uint64(~(0xFFFF << 32) & ((1 << 64) - 1))


def set_sreg(raw, sreg):
    return np.uint64((int(raw) & int(SREG_CLEAR)) | ((int(sreg) & 0xFFFF) << 32))


def set_both(world, q, raw, clock):
    world.raw_a[q] = raw; world.raw_b[q] = raw
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def signed_offset_grid(n, origins):
    indices = np.indices((n, n, n)).reshape(3, -1).T
    distance = np.full(len(indices), n, dtype=np.int16)
    for origin in origins:
        offset = (indices - np.asarray(origin) + n // 2) % n - n // 2
        distance = np.minimum(distance, np.max(np.abs(offset), axis=1))
    return distance.reshape((n, n, n))


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    base, meta, node = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    source, source_raw = d15.install_source(base, meta, architecture)
    reserve_history = []
    for tick in range(1, INTERVENTION_TICK + 1):
        base.tick(); reserve_history.append({"tick": tick, "delta": d15.reserve_delta(base, node)})
    if d15.reserve_delta(base, node) != -1:
        raise RuntimeError("reserve did not reach frozen -1 state before tomography")
    intact = NativeWorld(kernel, base.raw, base.clock_a)
    neutral = NativeWorld(kernel, base.raw, base.clock_a)
    opposite = NativeWorld(kernel, base.raw, base.clock_a)
    sham = NativeWorld(kernel, base.raw, base.clock_a)
    a_state = read(base.raw, node["a"]); b_state = read(base.raw, node["b"])
    a_raw = np.uint64(base.raw[node["a"]]); b_raw = np.uint64(base.raw[node["b"]])
    a_clock = int(base.clock_a[node["a"]]); b_clock = int(base.clock_a[node["b"]])
    neutral_a = set_sreg(a_raw, b_state["sreg"])
    opposite_a = set_sreg(a_raw, b_state["sreg"] + 1)
    set_both(neutral, node["a"], neutral_a, a_clock)
    set_both(opposite, node["a"], opposite_a, a_clock)
    set_both(sham, node["a"], a_raw, a_clock); set_both(sham, node["b"], b_raw, b_clock)
    distance = signed_offset_grid(architecture["n"], (node["a"], node["b"]))
    rows = {"neutralized": [], "opposite": [], "sham": []}
    branches = {"neutralized": neutral, "opposite": opposite, "sham": sham}
    receiver_difference_ticks = {key: 0 for key in branches}
    ever_nonlocal = {key: np.zeros_like(base.raw, dtype=bool) for key in branches}
    for latency in range(1, FOLLOWUP + 1):
        intact.tick()
        for key, world in branches.items():
            world.tick(); mask = intact.raw != world.raw
            nonlocal_mask = mask & (distance > 6); ever_nonlocal[key] |= nonlocal_mask
            receiver_different = ((int(intact.raw[meta["q_receiver"]]), int(intact.raw[meta["qp_receiver"]])) !=
                                  (int(world.raw[meta["q_receiver"]]), int(world.raw[meta["qp_receiver"]])))
            receiver_difference_ticks[key] += int(receiver_different)
            rows[key].append({"latency": latency, "changed": int(mask.sum()),
                              "outside_r3": int((mask & (distance > 3)).sum()),
                              "outside_r6": int(nonlocal_mask.sum()),
                              "maximum_radius": int(distance[mask].max()) if mask.any() else 0,
                              "reserve_delta": d15.reserve_delta(world, node),
                              "primary_delta": delta_value(world, meta),
                              "receiver_different": receiver_different})
    summary_by = {key: {"ever_outside_r6": int(ever_nonlocal[key].sum()),
                        "maximum_outside_r6": max(row["outside_r6"] for row in values),
                        "terminal_outside_r6": values[-1]["outside_r6"],
                        "maximum_radius": max(row["maximum_radius"] for row in values),
                        "receiver_difference_ticks": receiver_difference_ticks[key],
                        "terminal_reserve_delta": values[-1]["reserve_delta"],
                        "terminal_primary_delta": values[-1]["primary_delta"]}
                  for key, values in rows.items()}
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.reserve_function_tomography.v1",
        "question": "Does the retained reserve delta acquired at tick140 causally alter later dynamics outside its local organization?",
        "planning": {"mechanism": "s_reg-only neutralization/opposition with an identical-raw sham rewrite",
                     "controls": ["intact learned reserve", "same-value sham", "neutral delta0", "opposite delta+1"],
                     "predicted_outcomes": ["local-only memory", "nonlocal causal function", "sign-sensitive future dynamics"],
                     "estimated_runtime_minutes": 2, "estimated_storage_mb": 1,
                     "stop_condition": "256 post-intervention ticks with toroidal radius-stratified comparison"},
        "design": {"intervention_tick": INTERVENTION_TICK, "followup_ticks": FOLLOWUP,
                   "reserve_positions": {"a": list(node["a"]), "b": list(node["b"])},
                   "pre_intervention_delta": -1, "neutral_delta": 0, "opposite_delta": 1,
                   "intervention_class": "DIAGNOSTIC_INTERVENTION"},
        "reserve_history_to_intervention": reserve_history,
        "rows": rows, "branch_summary": summary_by,
        "summary": {"sham_world_identical": summary_by["sham"]["ever_outside_r6"] == 0 and
                                             summary_by["sham"]["maximum_radius"] == 0,
                    "neutralization_has_nonlocal_effect": summary_by["neutralized"]["ever_outside_r6"] > 0,
                    "opposite_has_nonlocal_effect": summary_by["opposite"]["ever_outside_r6"] > 0,
                    "sign_sensitive_future_dynamics": rows["neutralized"] != rows["opposite"],
                    "designated_receiver_effect": receiver_difference_ticks["neutralized"] > 0 or receiver_difference_ticks["opposite"] > 0,
                    "native_reserve_function_promoted": False, "fresh_native_readout_required": True,
                    "rw3_demonstrated": False},
        "claim_guard": "The causal intervention establishes necessity/sensitivity of the stored reserve state if positive. It does not itself count as native action, a later independent experience, or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D16_RESERVE_FUNCTION_TOMOGRAPHY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "branch_summary": summary_by, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
