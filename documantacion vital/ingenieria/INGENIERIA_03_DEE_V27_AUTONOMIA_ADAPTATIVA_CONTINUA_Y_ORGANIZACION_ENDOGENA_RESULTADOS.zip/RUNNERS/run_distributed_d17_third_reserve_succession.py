#!/usr/bin/env python3
"""Search whether the transferred reserve regime can recruit a third reserve."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15
import run_distributed_d16_reserve_function_tomography as d16
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
HORIZON = 480
FRAMES = ("x", "y", "z")


def frame_transform(vector, frame):
    x, y, z = vector
    if frame == "x": return (x, y, z)
    if frame == "y": return (y, x, z)
    if frame == "z": return (z, y, x)
    raise ValueError(frame)


def put(world, q, raw, clock):
    if int(world.raw[q]): raise RuntimeError(f"P2 overlap {q}")
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def add_p2(world, meta, center, frame):
    n = meta["n"]; axis = frame_transform((1, 0, 0), frame)
    a = add(center, axis, -1, n); b = add(center, axis, 1, n)
    put(world, a, int(pack(27000, 100, semantic=1)), 252)
    put(world, b, int(pack(27001, 100, semantic=1)), 252)
    for index, rel in enumerate(PA):
        put(world, add(a, frame_transform(rel, frame), 1, n), int(pack(27100 + index, 0, semantic=4)), 31 + index)
    for index, rel in enumerate(PB):
        put(world, add(b, frame_transform(rel, frame), 1, n), int(pack(27200 + index, 0, semantic=4)), 41 + index)
    event = add(b, frame_transform((0, -1, 0), frame), 1, n)
    route = frame_transform((0, 0, 1), frame); writer_q = add(event, route, -3, n)
    return {"center": center, "frame": frame, "a": a, "b": b, "writer_q": writer_q}


def p2_delta(world, node):
    a, b = read(world.raw, node["a"]), read(world.raw, node["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def center_for_writer(q, frame, n):
    axis = frame_transform((1, 0, 0), frame); event = frame_transform((0, -1, 0), frame)
    route = frame_transform((0, 0, 1), frame)
    center = add(q, axis, -1, n); center = add(center, event, -1, n); center = add(center, route, 3, n)
    return center


def p2_positions(center, frame, n):
    axis = frame_transform((1, 0, 0), frame); a = add(center, axis, -1, n); b = add(center, axis, 1, n)
    positions = [a, b]
    positions.extend(add(a, frame_transform(rel, frame), 1, n) for rel in PA)
    positions.extend(add(b, frame_transform(rel, frame), 1, n) for rel in PB)
    return positions


def p1_influence_map(kernel, architecture):
    base, meta, p1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    d15.install_source(base, meta, architecture)
    for _ in range(141): base.tick()
    intact = NativeWorld(kernel, base.raw, base.clock_a)
    neutral = NativeWorld(kernel, base.raw, base.clock_a)
    b_state = read(base.raw, p1["b"])
    neutral_a = d16.set_sreg(np.uint64(base.raw[p1["a"]]), b_state["sreg"])
    d16.set_both(neutral, p1["a"], neutral_a, int(base.clock_a[p1["a"]]))
    arrival = np.full(base.raw.shape, -1, dtype=np.int16)
    for latency in range(1, 257):
        intact.tick(); neutral.tick(); mask = intact.raw != neutral.raw
        arrival[(arrival < 0) & mask] = latency
    return arrival, meta, p1


def select_candidates(kernel, architecture):
    arrival, meta, p1 = p1_influence_map(kernel, architecture)
    base, _, _ = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    candidates = {frame: [] for frame in FRAMES}
    for raw_q in np.argwhere(arrival >= 1):
        q = tuple(int(x) for x in raw_q)
        for frame in FRAMES:
            center = center_for_writer(q, frame, meta["n"]); positions = p2_positions(center, frame, meta["n"])
            if len(set(positions)) != len(positions) or any(int(base.raw[pos]) for pos in positions): continue
            candidates[frame].append({"writer_q": q, "center": center, "frame": frame,
                                      "p1_influence_latency": int(arrival[q]),
                                      "absolute_reference_tick": 141 + int(arrival[q])})
    selected = []
    for frame in FRAMES:
        rows = sorted(candidates[frame], key=lambda row: (row["p1_influence_latency"], row["writer_q"]))
        for index, phase in ((0, "EARLY"), (len(rows) // 2, "MIDDLE"), (-1, "LATE")):
            row = dict(rows[index]); row["phase"] = phase
            if row["writer_q"] not in [old["writer_q"] for old in selected if old["frame"] == frame]: selected.append(row)
    return selected, {frame: len(rows) for frame, rows in candidates.items()}


def run_pair(kernel, architecture, candidate):
    try:
        treatment, meta, p1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
        control, control_meta, control_p1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
        p2 = add_p2(treatment, meta, candidate["center"], candidate["frame"])
        control_p2 = add_p2(control, control_meta, candidate["center"], candidate["frame"])
        source, source_raw = d15.install_source(treatment, meta, architecture)
    except RuntimeError as exc:
        return {"valid": False, "reason": str(exc)}
    prev = {"p1_t": d15.reserve_delta(treatment, p1), "p1_c": d15.reserve_delta(control, control_p1),
            "p2_t": p2_delta(treatment, p2), "p2_c": p2_delta(control, control_p2)}
    transitions = {key: [] for key in prev}
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        values = {"p1_t": d15.reserve_delta(treatment, p1), "p1_c": d15.reserve_delta(control, control_p1),
                  "p2_t": p2_delta(treatment, p2), "p2_c": p2_delta(control, control_p2)}
        for key, value in values.items():
            if value != prev[key]: transitions[key].append({"tick": tick, "before": prev[key], "after": value})
        prev = values
    p2_specific = [row for row in transitions["p2_t"] if row not in transitions["p2_c"]]
    return {"valid": True, "source_persistent_raw": int(treatment.raw[source]) == source_raw,
            "transitions": transitions, "terminal": prev, "p2_source_specific_transitions": p2_specific,
            "p1_transfer_preserved": transitions["p1_t"] == [{"tick": 140, "before": 0, "after": -1}],
            "python_interventions_after_t0": 0}


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8")); architecture = lock["architecture"]
    kernel, runtime = load_kernel(1); selected, census = select_candidates(kernel, architecture)
    rows = []
    for candidate in selected:
        outcome = run_pair(kernel, architecture, candidate)
        success = outcome.get("valid") and outcome.get("p1_transfer_preserved") and bool(outcome.get("p2_source_specific_transitions"))
        rows.append({"candidate": {key: list(value) if isinstance(value, tuple) else value for key, value in candidate.items()},
                     "outcome": outcome, "native_third_reserve_candidate": success})
        print(json.dumps({"frame": candidate["frame"], "phase": candidate["phase"],
                          "influence_latency": candidate["p1_influence_latency"], "success": success}), flush=True)
    result = seal({
        "schema": "dee.v27.ing03.distributed_regime.third_reserve_succession.v1",
        "question": "Can the new P1=-1 causal regime natively recruit a third relational reserve in the same uninterrupted world?",
        "planning": {"mechanism": "backward-align P2 writer surfaces with diagnostic P1-state causal-cone arrivals",
                     "controls": ["paired no-source world", "P1 transfer preservation", "three P2 relational frames"],
                     "predicted_outcomes": ["no third write", "P1-disrupting placement", "native P2 write after P1"],
                     "estimated_runtime_minutes": 5, "estimated_storage_mb": 2,
                     "stop_condition": "early/middle/late causal-cone intersections in x/y/z"},
        "design": {"horizon": HORIZON, "candidate_census": census, "selected_candidates": len(selected),
                   "candidate_map_intervention_class": "DIAGNOSTIC_INTERVENTION",
                   "candidate_execution_all_components_t0": True, "python_interventions_after_t0": 0},
        "rows": rows,
        "summary": {"selected_candidates": len(rows), "native_third_reserve_candidates": sum(row["native_third_reserve_candidate"] for row in rows),
                    "native_three_stage_succession_demonstrated": any(row["native_third_reserve_candidate"] for row in rows),
                    "independent_multiple_experiences_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "Even a positive P2 result would be endogenous causal succession from one initial experience, not yet three independent experiences required by RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_DR_D17_THIRD_RESERVE_SUCCESSION.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
