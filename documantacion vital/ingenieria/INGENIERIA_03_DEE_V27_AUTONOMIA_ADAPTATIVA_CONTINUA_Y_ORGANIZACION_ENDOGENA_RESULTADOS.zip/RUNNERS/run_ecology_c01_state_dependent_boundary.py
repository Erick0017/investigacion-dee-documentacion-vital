#!/usr/bin/env python3
"""Paired causal-cone atlas for the same perturbation at plastic and refractory organizations."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 192
RADIUS = 8


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def signed_offset(q, origin, n):
    values = []
    for value, base in zip(q, origin):
        d = (int(value) - int(base)) % n
        if d > n // 2:
            d -= n
        values.append(d)
    return tuple(values)


def local_positions(origin, n, radius):
    return [add(origin, offset, 1, n) for offset in product(range(-radius, radius + 1), repeat=3)]


def classify_difference(treatment, control, origin, n):
    positions = local_positions(origin, n, RADIUS)
    changed = [q for q in positions if int(treatment.raw[q]) != int(control.raw[q])]
    offsets = [signed_offset(q, origin, n) for q in changed]
    downstream = [d for d in offsets if d[2] > 0]
    upstream = [d for d in offsets if d[2] < 0]
    plane = [d for d in offsets if d[2] == 0]
    return {
        "changed_voxels": len(changed),
        "upstream_changed": len(upstream),
        "interaction_plane_changed": len(plane),
        "downstream_changed": len(downstream),
        "lateral_changed": sum(d[0] != 0 or d[1] != 0 for d in offsets),
        "maximum_forward_offset": max((d[2] for d in downstream), default=None),
        "minimum_backward_offset": min((d[2] for d in upstream), default=None),
        "changed_offsets": [list(d) for d in sorted(offsets)],
    }


def build_mature(kernel, regime):
    r10.OFFSET = (-6, 7, 8)
    if regime == "REFRACTORY_EXPRESSIVE":
        world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    elif regime == "RECEPTIVE_PLASTIC":
        world, meta = r10.build(kernel, None, expression=False, receiver_mode="absent")
    else:
        raise ValueError(regime)
    for _ in range(MATURATION):
        world.tick()
    return world, meta


def run(kernel, regime):
    base, meta = build_mature(kernel, regime)
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    source = add(event, (0, 0, 1), -3, meta["n"])
    source_raw = int(pack(41000, 0, (0, 0, 1), 4))
    replaced_raw = int(treatment.raw[source])
    set_both(treatment, source, source_raw, MATURATION)
    previous_t = delta_value(treatment, meta); previous_c = delta_value(control, meta)
    transitions_t = []; transitions_c = []; samples = []
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        dt = delta_value(treatment, meta); dc = delta_value(control, meta)
        if dt != previous_t:
            transitions_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c:
            transitions_c.append({"latency": latency, "before": previous_c, "after": dc})
        if latency <= 12 or latency in (16, 24, 32, 48, 64, 96, 128, 149, 150, 151, 160, 192):
            samples.append({"latency": latency, "causal_difference": classify_difference(treatment, control, event, meta["n"]),
                            "treatment_delta": dt, "control_delta": dc,
                            "source_raw": int(treatment.raw[source])})
        previous_t, previous_c = dt, dc
    probe_specific_transitions = [row for row in transitions_t if row not in transitions_c]
    max_forward = max((sample["causal_difference"]["maximum_forward_offset"] or 0 for sample in samples), default=0)
    max_downstream_count = max((sample["causal_difference"]["downstream_changed"] for sample in samples), default=0)
    max_changed = max((sample["causal_difference"]["changed_voxels"] for sample in samples), default=0)
    touches_observation_boundary = any(
        any(abs(axis) == RADIUS for axis in offset)
        for sample in samples
        for offset in sample["causal_difference"]["changed_offsets"]
    )
    return {
        "regime": regime,
        "maturation_ticks": MATURATION,
        "event": list(event),
        "source": list(source),
        "source_replaced_raw": replaced_raw,
        "source_installation_clean": replaced_raw == 0,
        "source_raw_fixed": int(treatment.raw[source]) == source_raw,
        "treatment_transitions": transitions_t,
        "paired_control_transitions": transitions_c,
        "probe_specific_transitions": probe_specific_transitions,
        "write_response": bool(probe_specific_transitions),
        "maximum_probe_specific_forward_offset": max_forward,
        "maximum_downstream_difference_voxels": max_downstream_count,
        "maximum_changed_voxels": max_changed,
        "causal_difference_touches_observation_boundary": touches_observation_boundary,
        "samples": samples,
        "python_interventions_after_t0": 1,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, regime) for regime in ("RECEPTIVE_PLASTIC", "REFRACTORY_EXPRESSIVE")]
    by = {row["regime"]: row for row in rows}
    plastic = by["RECEPTIVE_PLASTIC"]; refractory = by["REFRACTORY_EXPRESSIVE"]
    amplification_ratio = (refractory["maximum_changed_voxels"] /
                           max(1, plastic["maximum_changed_voxels"]))
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.state_boundary.v1",
        "question": "Does an identical perturbation generate a different paired causal cone at receptive and refractory organizations?",
        "cost_estimate": {"worlds": 4, "maturation_ticks": MATURATION, "followup_ticks": FOLLOWUP,
                          "observed_cube_voxels": (2 * RADIUS + 1) ** 3, "information_gain": "high"},
        "method": "Within-regime deterministic paired difference: treatment and no-perturbation control branch from the identical mature world.",
        "rows": rows,
        "summary": {
            "plastic_write_response": plastic["write_response"],
            "refractory_write_response": refractory["write_response"],
            "state_dependent_write_boundary": plastic["write_response"] and not refractory["write_response"],
            "plastic_max_forward_offset": plastic["maximum_probe_specific_forward_offset"],
            "refractory_max_forward_offset": refractory["maximum_probe_specific_forward_offset"],
            "plastic_max_changed_voxels": plastic["maximum_changed_voxels"],
            "refractory_max_changed_voxels": refractory["maximum_changed_voxels"],
            "refractory_to_plastic_amplification_ratio": amplification_ratio,
            "refractory_distributed_amplification": amplification_ratio >= 10.0,
            "boundary_differential_class": "SPARSE_WRITE_ASSOCIATED_VS_EXTENSIVE_NONWRITE_DIVERGENCE",
            "directed_pass_through_demonstrated": False,
            "deflection_demonstrated": False,
            "native_selection_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "The perturbation is installed diagnostically after maturation. A causal-cone differential is a boundary law, not native recurrence or selection.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C01_STATE_DEPENDENT_BOUNDARY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
