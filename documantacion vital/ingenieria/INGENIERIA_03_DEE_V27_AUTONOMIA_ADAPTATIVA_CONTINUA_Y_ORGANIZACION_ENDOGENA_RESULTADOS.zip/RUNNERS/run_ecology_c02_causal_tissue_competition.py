#!/usr/bin/env python3
"""Test capture topology, cross-talk and refractory exclusion in a compact learner tissue."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09


PROBE_TICK = 184
HORIZON = 400
ARRAY = (((0, 14, 0), "x"), ((14, 0, 0), "y"), ((0, 0, 14), "z"))


def add_native_one_shot(world, meta, node, mode="treatment", distance=6):
    frame = node["frame"]
    event = add(node["writer_q"], r09.transform((0, 0, 1), frame), 3, meta["n"])
    route = r09.transform((0, 0, 1), frame)
    generator = add(event, route, -distance, meta["n"])
    positions = []
    for index, base_direction in enumerate(((1, 0, 1), (-1, 0, 1))):
        if mode == "missing_branch" and index == 0:
            continue
        direction = r09.transform(base_direction, frame)
        q = add(generator, direction, -1, meta["n"])
        raw = int(pack(42000 + index, 3, direction, 1))
        r03.put(world, q, raw, 0)
        positions.append({"q": list(q), "raw": raw, "direction": list(direction)})
    return {"mode": mode, "event": list(event), "generator": list(generator), "positions": positions}


def build(kernel, early_mode):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    nodes = [r09.add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), index + 1, frame)
             for index, (offset, frame) in enumerate(ARRAY)]
    early = None
    if early_mode in ("node1", "broken"):
        early = add_native_one_shot(world, meta, nodes[0], "treatment" if early_mode == "node1" else "missing_branch")
    return world, meta, nodes, early


def run(kernel, label, early_mode, probe_nodes):
    try:
        world, meta, nodes, early = build(kernel, early_mode)
    except RuntimeError as exc:
        return {"label": label, "valid": False, "reason": str(exc)}
    previous = {node["id"]: r09.delta(world, node) for node in nodes}
    transitions = {node["id"]: [] for node in nodes}
    installed = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            for node in nodes:
                if node["id"] not in probe_nodes:
                    continue
                q = node["writer_q"]
                raw = int(pack(43000, 0, r09.transform((0, 0, 1), node["frame"]), 4))
                installed.append({"node": node["id"], "q": list(q), "replaced_raw": int(world.raw[q]), "raw": raw})
                r03.set_both(world, q, raw, PROBE_TICK)
        for node in nodes:
            value = r09.delta(world, node)
            if value != previous[node["id"]]:
                transitions[node["id"]].append({"tick": tick, "before": previous[node["id"]], "after": value})
            previous[node["id"]] = value
    return {
        "label": label,
        "valid": True,
        "early_mode": early_mode,
        "native_early_generator": early,
        "probe_nodes": list(probe_nodes),
        "probe_installations": installed,
        "probe_installations_clean": all(row["replaced_raw"] == 0 for row in installed),
        "node_transitions": {str(k): v for k, v in transitions.items()},
        "pre_probe_transitions": {str(k): [x for x in v if x["tick"] <= PROBE_TICK] for k, v in transitions.items()},
        "post_probe_transitions": {str(k): [x for x in v if x["tick"] > PROBE_TICK] for k, v in transitions.items()},
        "terminal_deltas": {str(k): value for k, value in previous.items()},
        "python_interventions_after_t0": len(installed),
        "intervention_class": "DIAGNOSTIC_INTERVENTION" if installed else "NONE",
    }


def signature(row, node):
    return [(x["tick"], x["before"], x["after"]) for x in row["post_probe_transitions"][str(node)]]


def main():
    kernel, runtime = load_kernel(1)
    plans = [
        ("noearly_none", "none", ()),
        ("noearly_front", "none", (1, 2, 3)),
        ("noearly_node1", "none", (1,)),
        ("noearly_node2", "none", (2,)),
        ("noearly_node3", "none", (3,)),
        ("early1_none", "node1", ()),
        ("early1_front", "node1", (1, 2, 3)),
        ("broken_none", "broken", ()),
        ("broken_front", "broken", (1, 2, 3)),
    ]
    rows = [run(kernel, *plan) for plan in plans]
    valid = {row["label"]: row for row in rows if row.get("valid")}
    def effects(treatment, control):
        return [node for node in (1, 2, 3) if signature(valid[treatment], node) != signature(valid[control], node)]
    direct_matrix = {str(node): effects(f"noearly_node{node}", "noearly_none") for node in (1, 2, 3)}
    front_effect = effects("noearly_front", "noearly_none")
    early_front_effect = effects("early1_front", "early1_none")
    broken_front_effect = effects("broken_front", "broken_none")
    early1_native_capture = bool(valid.get("early1_none", {}).get("pre_probe_transitions", {}).get("1"))
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.tissue_competition.v1",
        "question": "Does a compact three-frame plastic tissue produce single capture, lateral suppression, or state-dependent exclusion under a common perturbation?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "design": {"array": [{"offset": list(offset), "frame": frame} for offset, frame in ARRAY],
                   "probe_tick": PROBE_TICK, "early_native_generator_distance": 6},
        "rows": rows,
        "capture_matrix": direct_matrix,
        "summary": {
            "direct_effect_nodes": direct_matrix,
            "symmetric_front_effect_nodes": front_effect,
            "symmetric_front_single_winner": len(front_effect) == 1,
            "early_node1_native_capture": early1_native_capture,
            "front_effect_after_early_node1": early_front_effect,
            "front_effect_after_broken_canary": broken_front_effect,
            "refractory_exclusion_candidate": (early1_native_capture and 1 not in early_front_effect and
                                                any(node in early_front_effect for node in (2, 3))),
            "lateral_competition_demonstrated": len(front_effect) == 1,
            "native_repeated_selection_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "The early branch is t0-native. The later front is diagnostic; even a differential would require t0-native reconstruction and a later functional readout.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C02_CAUSAL_TISSUE_COMPETITION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
