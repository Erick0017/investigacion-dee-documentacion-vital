#!/usr/bin/env python3
"""Long-horizon paired probes for spontaneous recovery of write susceptibility."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value


PROBE_TICKS = (184, 512, 1024, 2048, 4096)
FOLLOWUP = 192


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def build(kernel, expressive):
    r10.OFFSET = (-6, 7, 8)
    if expressive:
        return r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    return r10.build(kernel, None, expression=False, receiver_mode="absent")


def probe_checkpoint(kernel, base, meta, expressive, probe_tick):
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    source = add(event, (0, 0, 1), -3, meta["n"])
    raw = int(pack(44000, 0, (0, 0, 1), 4))
    replaced = int(treatment.raw[source])
    set_both(treatment, source, raw, probe_tick)
    previous_t = delta_value(treatment, meta); previous_c = delta_value(control, meta)
    transitions_t = []; transitions_c = []
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        dt = delta_value(treatment, meta); dc = delta_value(control, meta)
        if dt != previous_t:
            transitions_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c:
            transitions_c.append({"latency": latency, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
    sig_t = [(x["latency"], x["before"], x["after"]) for x in transitions_t]
    sig_c = [(x["latency"], x["before"], x["after"]) for x in transitions_c]
    return {
        "regime": "REFRACTORY_EXPRESSIVE" if expressive else "RECEPTIVE_CONTROL",
        "probe_tick": probe_tick,
        "followup_ticks": FOLLOWUP,
        "source": list(source),
        "source_replaced_raw": replaced,
        "source_installation_clean": replaced == 0,
        "treatment_transitions": transitions_t,
        "paired_control_transitions": transitions_c,
        "probe_changes_trajectory": sig_t != sig_c,
        "terminal_treatment_delta": previous_t,
        "terminal_control_delta": previous_c,
        "source_raw_fixed": int(treatment.raw[source]) == raw,
        "python_interventions_after_t0": 1,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    base, meta = build(kernel, True)
    checkpoints = {}
    for tick in range(1, max(PROBE_TICKS) + 1):
        base.tick()
        if tick in PROBE_TICKS:
            checkpoints[tick] = NativeWorld(kernel, base.raw, base.clock_a)
    for tick in PROBE_TICKS:
        rows.append(probe_checkpoint(kernel, checkpoints[tick], meta, True, tick))
    plastic, plastic_meta = build(kernel, False)
    for _ in range(PROBE_TICKS[0]):
        plastic.tick()
    rows.append(probe_checkpoint(kernel, plastic, plastic_meta, False, PROBE_TICKS[0]))
    refractory = [row for row in rows if row["regime"] == "REFRACTORY_EXPRESSIVE"]
    controls = [row for row in rows if row["regime"] == "RECEPTIVE_CONTROL"]
    recovered = [row["probe_tick"] for row in refractory if row["probe_changes_trajectory"]]
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.susceptibility_recovery.v1",
        "question": "Does an expressive/refractory organization spontaneously recover competent write response over a 4096-tick horizon?",
        "cost_estimate": {"paired_branches": len(rows), "probe_ticks": list(PROBE_TICKS),
                          "followup_ticks": FOLLOWUP, "information_gain": "high"},
        "rows": rows,
        "summary": {
            "refractory_probe_ticks_with_recovery": recovered,
            "spontaneous_susceptibility_recovery_demonstrated": bool(recovered),
            "receptive_controls_respond": all(row["probe_changes_trajectory"] for row in controls),
            "maximum_refractory_horizon_tested": max(PROBE_TICKS),
            "bounded_reuse_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Each writer installation is a diagnostic competence assay in a separate paired branch. No host probe counts as native learning.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C03_SUSCEPTIBILITY_RECOVERY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
