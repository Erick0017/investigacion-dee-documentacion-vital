#!/usr/bin/env python3
"""Repeated destructive assay of an endogenous regenerative dynamic interface."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_landscape_l03_two_organ_coupling_search import build
from run_landscape_l04_coupling_mechanism_controls import periods


DAMAGE_TICKS = (256, 512, 768, 1024, 1280)
HORIZON = 1536


def clear(world, positions):
    for q in positions:
        world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
        world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def run(kernel, mode, cut_receiver_support=False):
    a_mode = "absent" if mode == "free_P2" else "delta_-8"
    world, meta = build(kernel, (-3, 4, 5), a_mode)
    cut = []
    if cut_receiver_support:
        for index, (q, _) in enumerate(meta["organ_b"]["sources"]):
            cut.append({"index": index, "q": list(q), "raw": int(world.raw[q])})
            clear(world, [q])
    sequence = []; episodes = []; active_episode = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick in DAMAGE_TICKS:
            before = (int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]]))
            clear(world, [meta["q_b"], meta["qp_b"]])
            active_episode = {"damage_tick": tick, "before_pair": list(before),
                              "first_nonempty_latency": None, "first_two_site_latency": None}
            episodes.append(active_episode)
        pair = (int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]]))
        sequence.append(pair)
        if active_episode is not None and tick > active_episode["damage_tick"]:
            latency = tick - active_episode["damage_tick"]
            if active_episode["first_nonempty_latency"] is None and any(pair):
                active_episode["first_nonempty_latency"] = latency
            if active_episode["first_two_site_latency"] is None and all(pair):
                active_episode["first_two_site_latency"] = latency
    windows = []
    for start in range(1, HORIZON + 1, 256):
        seq = sequence[start - 1:start + 255]
        windows.append({"start": start, "end": start + 255, "periods": periods(seq),
                        "nonempty_ticks": sum(any(pair) for pair in seq)})
    return {
        "mode": mode,
        "receiver_support_cut": cut_receiver_support,
        "support_cut": cut,
        "damage_ticks": list(DAMAGE_TICKS),
        "episodes": episodes,
        "windows": windows,
        "all_damage_episodes_repopulate": all(row["first_nonempty_latency"] is not None for row in episodes),
        "maximum_repopulation_latency": max((row["first_nonempty_latency"] or 0 for row in episodes), default=None),
        "python_interventions_after_t0": len(DAMAGE_TICKS),
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode, cut) for mode in ("free_P2", "coupled_P6") for cut in (False, True)]
    intact = [row for row in rows if not row["receiver_support_cut"]]
    cut = [row for row in rows if row["receiver_support_cut"]]
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.repeated_functional_homeostasis.v1",
        "question": "Can the same bounded dynamic organization regenerate its action-coupled interface after repeated perturbations, and is its support causally necessary?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "damage_episodes_per_world": len(DAMAGE_TICKS), "information_gain": "medium-high"},
        "rows": rows,
        "summary": {
            "intact_modes_repopulate_every_episode": all(row["all_damage_episodes_repopulate"] for row in intact),
            "intact_maximum_repopulation_latency": {row["mode"]: row["maximum_repopulation_latency"] for row in intact},
            "support_cut_modes_repopulate_every_episode": {row["mode"]: row["all_damage_episodes_repopulate"] for row in cut},
            "repeated_functional_interface_regeneration": all(row["all_damage_episodes_repopulate"] for row in intact),
            "write_compatibility_homeostasis_demonstrated": False,
            "native_damage_and_recovery_cycle_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Damage is diagnostic Python. Endogenous return after each damage establishes regenerative dynamics only; it is not autonomous damage generation, learning, or write-compatible recovery.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C04_REPEATED_FUNCTIONAL_HOMEOSTASIS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
