#!/usr/bin/env python3
"""Test t0-complete finite causal support as a native P2/P6 dynamic-attractor switch."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json
from run_landscape_l03_two_organ_coupling_search import build
from run_landscape_l04_coupling_mechanism_controls import periods


HORIZON = 2048
WINDOW = 256
OFFSET = (-3, 4, 5)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def configure(kernel, mode):
    if mode == "free":
        world, meta = build(kernel, OFFSET, "absent", n=41)
        return world, meta, []
    world, meta = build(kernel, OFFSET, "delta_-8", n=41)
    if mode == "persistent":
        return world, meta, [{"q": list(q), "raw": raw, "persistent": True} for q, raw in meta["organ_a"]["sources"]]
    spacings = (0,) if mode == "finite_one" else (0, 4, 8)
    installed = []
    originals = list(meta["organ_a"]["sources"])
    for source_index, (q, raw) in enumerate(originals):
        item = unpack_scalar(raw); direction = tuple(item["direction"])
        set_both(world, q, 0, 0)
        for pulse_index, spacing in enumerate(spacings):
            target = add(q, direction, -spacing, meta["n"])
            if int(world.raw[target]):
                raise RuntimeError(f"finite pulse overlap at {target} mode={mode}")
            pulse_raw = int(pack(45000 + source_index * 10 + pulse_index, item["sreg"], direction, 1))
            set_both(world, target, pulse_raw, 100 + source_index)
            installed.append({"q": list(target), "raw": pulse_raw, "source_index": source_index,
                              "pulse_index": pulse_index, "spacing": spacing,
                              "direction": list(direction), "persistent": False})
    return world, meta, installed


def run(kernel, mode):
    try:
        world, meta, installed = configure(kernel, mode)
    except RuntimeError as exc:
        return {"mode": mode, "valid": False, "reason": str(exc)}
    sequence = []; deltas = []; source_occupancy = []
    sites = [tuple(row["q"]) for row in installed]
    for tick in range(1, HORIZON + 1):
        world.tick()
        sequence.append((int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]])))
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        if tick in (1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048):
            source_occupancy.append({"tick": tick, "occupied_original_sites": sum(bool(int(world.raw[q])) for q in sites)})
    windows = []
    for start in range(1, HORIZON + 1, WINDOW):
        seq = sequence[start - 1:start + WINDOW - 1]
        windows.append({"start": start, "end": start + WINDOW - 1, "periods": periods(seq),
                        "nonempty_ticks": sum(any(pair) for pair in seq)})
    period_path = [row["periods"]["raw_pair"] for row in windows]
    return {
        "mode": mode, "valid": True, "t0_support": installed,
        "support_count": len(installed), "windows": windows,
        "raw_period_path": period_path,
        "terminal_period": period_path[-1],
        "master_delta_initial": deltas[0], "master_delta_terminal": deltas[-1],
        "source_occupancy_samples": source_occupancy,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode) for mode in ("free", "persistent", "finite_one", "finite_train3")]
    by = {row["mode"]: row for row in rows if row.get("valid")}
    free_period = by.get("free", {}).get("terminal_period")
    persistent_period = by.get("persistent", {}).get("terminal_period")
    transient = []
    for mode in ("finite_one", "finite_train3"):
        row = by.get(mode)
        if not row:
            continue
        path = row["raw_period_path"]
        transient.append({"mode": mode, "period_path": path,
                          "visits_persistent_period": persistent_period in path,
                          "returns_to_free_period": row["terminal_period"] == free_period})
    switches = [row["mode"] for row in transient if row["visits_persistent_period"] and row["returns_to_free_period"]]
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.dynamic_attractor_pulses.v1",
        "question": "Can finite t0-complete support drive a native transient P2/P6 functional-regime switch and endogenous return?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "design": {"offset": list(OFFSET), "window": WINDOW, "finite_train_spacings": [0, 4, 8],
                   "all_functional_runs_t0_complete": True},
        "rows": rows,
        "finite_classification": transient,
        "summary": {
            "free_terminal_period": free_period,
            "persistent_terminal_period": persistent_period,
            "finite_modes_with_P6_to_P2_switch": switches,
            "native_transient_dynamic_switch_demonstrated": bool(switches),
            "learned_state_selected_switch_demonstrated": False,
            "repeated_A_B_A_switching_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Finite support is fully configured at t0 and evolves natively, but it is not selected by later learned experience. Period identity must match the established exact raw P2/P6 controls.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C05_NATIVE_DYNAMIC_ATTRACTOR_PULSES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "finite_classification": transient, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
