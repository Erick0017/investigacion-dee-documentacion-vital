#!/usr/bin/env python3
"""Resolve the common receiver trajectory and the spatial advance of A/B commitment."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_reactivation_r13_combined_late_development as r13


HORIZON = 256


def region(center, n, radius):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def token(world, q):
    return int(world.raw[q]), int(world.clock_a[q])


def comparison(world_a, world_b, positions):
    changed = [q for q in positions if token(world_a, q) != token(world_b, q)]
    return {"site_count": len(positions), "different_sites": len(changed),
            "exact_equivalence": not changed, "different_positions": [list(q) for q in changed]}


def main():
    kernel, runtime = load_kernel(1)
    worlds = {}; metas = {}
    for label, target in (("A", "a"), ("B", "b"), ("SHAM", None)):
        worlds[label], metas[label], _ = r13.build(kernel, target)
    meta = metas["A"]; n = meta["n"]
    domains = {
        "master_r2": region(meta["c"], n, 2),
        "receiver_r1": region(meta["q_receiver"], n, 1),
        "receiver_r2": region(meta["q_receiver"], n, 2),
        "receiver_r3": region(meta["q_receiver"], n, 3),
    }
    rows = []; first = {name: None for name in domains}
    for tick in range(1, HORIZON + 1):
        for world in worlds.values():
            world.tick()
        domain_rows = {}
        for name, positions in domains.items():
            item = comparison(worlds["A"], worlds["B"], positions)
            if not item["exact_equivalence"] and first[name] is None:
                first[name] = tick
            if tick <= 48 or tick in (64, 96, 128, 182, 201, 256):
                domain_rows[name] = item
        if domain_rows:
            rows.append({"tick": tick, "domains": domain_rows})
    exact_prefix = {}
    for name in domains:
        exact_prefix[name] = (first[name] - 1) if first[name] is not None else HORIZON
    prior_splice = json.loads((ROOT / "MECHANISM_SELECTION/ING03_REACT_R01_HCOMMON_SPLICE.json").read_text(encoding="utf-8"))
    prior_lifetime = json.loads((ROOT / "MECHANISM_SELECTION/ING03_REACT_R06_HCOMMON_COMPETENCE_LIFETIME.json").read_text(encoding="utf-8"))
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.common_competence_trajectory.v1",
        "question": "What common receiver trajectory precedes A/B commitment, and does exact common-state competence persist when commitment is delayed?",
        "cost_estimate": {"worlds": 3, "ticks_per_world": HORIZON,
                          "tracked_domains": {key: len(value) for key, value in domains.items()},
                          "information_gain": "medium-high"},
        "design": {"apparatus": "C15 native late-development architecture",
                   "comparison": "tick-matched raw+clock A/B equality", "python_interventions_after_t0": 0},
        "trajectory_rows": rows,
        "first_A_B_divergence_tick": first,
        "exact_common_prefix_ticks": exact_prefix,
        "prior_diagnostic_splice": {
            "candidate_ticks": prior_splice["summary"].get("diagnostic_hcommon_candidate_ticks"),
            "latest_candidate": prior_splice["summary"].get("latest_diagnostic_hcommon_candidate_tick"),
            "python_cloning_only": True,
        },
        "prior_competence_lifetime": prior_lifetime["summary"],
        "summary": {
            "receiver_r3_common_trajectory_end": exact_prefix["receiver_r3"],
            "receiver_r1_first_commitment_divergence": first["receiver_r1"],
            "competence_is_time_extended_exact_receiver_trajectory": exact_prefix["receiver_r3"] > 1,
            "delayed_branching_from_static_snapshot_demonstrated": False,
            "renewing_competence_demonstrated": False,
            "developmental_conveyor_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Trajectory alignment is host observation only. Prior splice/lifetime experiments remain diagnostic interventions and do not establish a native renewable precursor.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C06_COMMON_COMPETENCE_TRAJECTORY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "first_A_B_divergence_tick": first, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
