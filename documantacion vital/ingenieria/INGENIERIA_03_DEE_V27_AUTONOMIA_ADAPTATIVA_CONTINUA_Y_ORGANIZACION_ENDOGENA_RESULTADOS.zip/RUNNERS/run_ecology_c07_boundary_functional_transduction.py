#!/usr/bin/env python3
"""Test whether the C01 state-dependent divergence reaches an existing remote interface.

The post-maturation source insertion is diagnostic.  Each treatment is compared with
an unperturbed deterministic branch of the same mature world; no result is promoted
as native recurrent learning.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_landscape_l04_coupling_mechanism_controls import periods
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 384
OFFSET = (-6, 7, 8)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw)
    world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock)
    world.clock_b[q] = np.uint64(clock)


def pair(world, meta):
    return (int(world.raw[meta["q_receiver"]]),
            int(world.raw[meta["qp_receiver"]]))


def digest(sequence):
    h = hashlib.sha256()
    for values in sequence:
        for value in values:
            h.update(int(value).to_bytes(8, "little"))
    return h.hexdigest()


def build_mature(kernel, regime):
    r10.OFFSET = OFFSET
    if regime == "REFRACTORY_EXPRESSIVE":
        world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    elif regime == "RECEPTIVE_PLASTIC":
        world, meta = r10.build(kernel, None, expression=False, receiver_mode="candidate")
    else:
        raise ValueError(regime)
    for _ in range(MATURATION):
        world.tick()
    return world, meta


def run(kernel, regime):
    base, meta = build_mature(kernel, regime)
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    source = add(event, (0, 0, 1), -3, meta["n"])
    source_raw = int(pack(41000, 0, (0, 0, 1), 4))
    replaced_raw = int(treatment.raw[source])
    set_both(treatment, source, source_raw, MATURATION)

    treatment_pairs = []
    control_pairs = []
    pair_differences = []
    master_t = []
    master_c = []
    previous_t = delta_value(treatment, meta)
    previous_c = delta_value(control, meta)
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick()
        control.tick()
        pt, pc = pair(treatment, meta), pair(control, meta)
        treatment_pairs.append(pt)
        control_pairs.append(pc)
        if pt != pc:
            pair_differences.append(latency)
        dt, dc = delta_value(treatment, meta), delta_value(control, meta)
        if dt != previous_t:
            master_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c:
            master_c.append({"latency": latency, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc

    suffix_t = treatment_pairs[-128:]
    suffix_c = control_pairs[-128:]
    return {
        "regime": regime,
        "event": list(event),
        "diagnostic_source": list(source),
        "source_installation_clean": replaced_raw == 0,
        "receiver": list(meta["q_receiver"]),
        "receiver_partner": list(meta["qp_receiver"]),
        "receiver_pair_first_difference_latency": (pair_differences[0]
                                                   if pair_differences else None),
        "receiver_pair_different_ticks": len(pair_differences),
        "receiver_pair_causally_changed": bool(pair_differences),
        "treatment_suffix_sha256": digest(suffix_t),
        "control_suffix_sha256": digest(suffix_c),
        "treatment_suffix_periods": periods(suffix_t),
        "control_suffix_periods": periods(suffix_c),
        "terminal_receiver_pair_equal": suffix_t[-1] == suffix_c[-1],
        "master_treatment_transitions": master_t,
        "master_control_transitions": master_c,
        "write_response": bool([row for row in master_t if row not in master_c]),
        "python_interventions_after_t0": 1,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, regime)
            for regime in ("RECEPTIVE_PLASTIC", "REFRACTORY_EXPRESSIVE")]
    by = {row["regime"]: row for row in rows}
    plastic = by["RECEPTIVE_PLASTIC"]
    refractory = by["REFRACTORY_EXPRESSIVE"]
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.boundary_functional_transduction.v1",
        "question": "Does the state-dependent C01 perturbation divergence causally alter a spatially separated remote interface?",
        "cost_estimate": {"worlds": 4, "maturation_ticks": MATURATION,
                          "followup_ticks": FOLLOWUP,
                          "information_gain": "high"},
        "design": {"receiver_offset": list(OFFSET),
                   "paired_within_regime_controls": True},
        "rows": rows,
        "summary": {
            "plastic_master_write_response": plastic["write_response"],
            "refractory_master_write_response": refractory["write_response"],
            "plastic_remote_interface_changed": plastic["receiver_pair_causally_changed"],
            "refractory_remote_interface_changed": refractory["receiver_pair_causally_changed"],
            "refractory_nonwrite_with_remote_effect": (not refractory["write_response"] and
                                                       refractory["receiver_pair_causally_changed"]),
            "native_functional_selection_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "The perturbation source is installed diagnostically after maturation. Remote-pair divergence, if present, is direct causal transduction and not stored new learning or autonomous functional succession.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C07_BOUNDARY_FUNCTIONAL_TRANSDUCTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "rows": [{"regime": row["regime"],
                                "first_remote_difference": row["receiver_pair_first_difference_latency"],
                                "different_ticks": row["receiver_pair_different_ticks"],
                                "treatment_periods": row["treatment_suffix_periods"],
                                "control_periods": row["control_suffix_periods"]}
                               for row in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
