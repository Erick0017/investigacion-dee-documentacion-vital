#!/usr/bin/env python3
"""Compact whole-world causal-front census for the C01 boundary differential."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value


MATURATION = 184
FOLLOWUP = 192
OFFSET = (-6, 7, 8)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def build_mature(kernel, regime):
    r10.OFFSET = OFFSET
    if regime == "REFRACTORY_EXPRESSIVE":
        world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    elif regime == "RECEPTIVE_PLASTIC":
        world, meta = r10.build(kernel, None, expression=False, receiver_mode="candidate")
    else:
        raise ValueError(regime)
    for _ in range(MATURATION):
        world.tick()
    return world, meta


def signed_offsets(indices, origin, n):
    offsets = indices.astype(np.int64) - np.asarray(origin, dtype=np.int64)
    offsets = (offsets + n // 2) % n - n // 2
    return offsets


def census(treatment, control, origin):
    indices = np.argwhere(treatment.raw != control.raw)
    if len(indices) == 0:
        return {"changed_voxels": 0, "maximum_chebyshev_radius": 0,
                "maximum_manhattan_radius": 0, "shell_counts": {}}
    offsets = signed_offsets(indices, origin, treatment.n)
    cheb = np.max(np.abs(offsets), axis=1)
    manhattan = np.sum(np.abs(offsets), axis=1)
    unique, counts = np.unique(cheb, return_counts=True)
    return {"changed_voxels": int(len(indices)),
            "maximum_chebyshev_radius": int(np.max(cheb)),
            "maximum_manhattan_radius": int(np.max(manhattan)),
            "shell_counts": {str(int(radius)): int(count)
                             for radius, count in zip(unique, counts)}}


def run(kernel, regime):
    base, meta = build_mature(kernel, regime)
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    source = add(event, (0, 0, 1), -3, meta["n"])
    source_raw = int(pack(41000, 0, (0, 0, 1), 4))
    replaced = int(treatment.raw[source])
    set_both(treatment, source, source_raw, MATURATION)

    checkpoints = set(range(1, 33)) | {40, 48, 64, 80, 96, 128, 160, 192}
    samples = []
    arrival = {str(radius): None for radius in range(1, meta["n"] // 2 + 1)}
    previous_t = delta_value(treatment, meta)
    previous_c = delta_value(control, meta)
    transitions_t, transitions_c = [], []
    maximum_changed = 0
    maximum_radius = 0
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        measurement = census(treatment, control, event)
        maximum_changed = max(maximum_changed, measurement["changed_voxels"])
        maximum_radius = max(maximum_radius, measurement["maximum_chebyshev_radius"])
        for radius in range(1, measurement["maximum_chebyshev_radius"] + 1):
            if arrival[str(radius)] is None:
                arrival[str(radius)] = latency
        if latency in checkpoints:
            samples.append({"latency": latency, **measurement})
        dt, dc = delta_value(treatment, meta), delta_value(control, meta)
        if dt != previous_t:
            transitions_t.append({"latency": latency, "before": previous_t, "after": dt})
        if dc != previous_c:
            transitions_c.append({"latency": latency, "before": previous_c, "after": dc})
        previous_t, previous_c = dt, dc
    probe_specific = [row for row in transitions_t if row not in transitions_c]
    return {"regime": regime, "event": list(event), "diagnostic_source": list(source),
            "source_installation_clean": replaced == 0,
            "maximum_changed_voxels": maximum_changed,
            "maximum_chebyshev_radius": maximum_radius,
            "front_arrival_by_radius": arrival,
            "samples": samples,
            "write_response": bool(probe_specific),
            "treatment_master_transitions": transitions_t,
            "control_master_transitions": transitions_c,
            "python_interventions_after_t0": 1,
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, regime)
            for regime in ("RECEPTIVE_PLASTIC", "REFRACTORY_EXPRESSIVE")]
    by = {row["regime"]: row for row in rows}
    plastic, refractory = by["RECEPTIVE_PLASTIC"], by["REFRACTORY_EXPRESSIVE"]
    result = seal({
        "schema": "dee.v27.ing03.native_causal_ecology.whole_world_front.v1",
        "question": "What is the full spatial extent and arrival law of the state-dependent paired causal divergence?",
        "cost_estimate": {"worlds": 4, "maturation_ticks": MATURATION,
                          "followup_ticks": FOLLOWUP,
                          "world_voxels": 41 ** 3, "information_gain": "high"},
        "rows": rows,
        "summary": {
            "plastic_write_response": plastic["write_response"],
            "refractory_write_response": refractory["write_response"],
            "plastic_maximum_changed_voxels": plastic["maximum_changed_voxels"],
            "refractory_maximum_changed_voxels": refractory["maximum_changed_voxels"],
            "plastic_maximum_chebyshev_radius": plastic["maximum_chebyshev_radius"],
            "refractory_maximum_chebyshev_radius": refractory["maximum_chebyshev_radius"],
            "refractory_world_scale_divergence": refractory["maximum_chebyshev_radius"] >= 20,
            "directed_propagation_demonstrated": False,
            "native_experience_selection_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Whole-world paired divergence follows one diagnostic source insertion. Spatial extent alone is not directed transport, learning, or autonomous selection.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECO_C08_WHOLE_WORLD_FRONT_PROPAGATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
