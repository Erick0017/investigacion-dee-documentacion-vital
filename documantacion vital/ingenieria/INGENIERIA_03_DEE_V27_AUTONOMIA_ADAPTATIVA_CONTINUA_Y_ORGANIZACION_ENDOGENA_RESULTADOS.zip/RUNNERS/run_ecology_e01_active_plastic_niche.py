#!/usr/bin/env python3
"""Search for a DEE-native persistent support geometry that preserves writability.

The semantic-4 structures are present at t0 and are part of the tested DEE
organization.  The later competent-writer insertion is a declared diagnostic
probe; it does not count as a native second consequence or as RW3.
"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_rw3_r03_recurrent_writer_blocker_control import persistent_writer_spec
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import pair


OFFSET = (-6, 7, 8)
PROBE_TICK = 184
HORIZON = 600
PLANE_RADIUS = 2
SUPPORT_DISTANCE = 12


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def source_specs(meta, variant):
    c, n = meta["c"], meta["n"]
    yz_full = list(product(range(-PLANE_RADIUS, PLANE_RADIUS + 1), repeat=2))
    yz_sparse = [(0, 0), (-2, -2), (-2, 2), (2, -2), (2, 2)]
    sides = []
    if variant in ("negative_face_plane25", "bilateral_planes50"):
        sides.append((-1, yz_full))
    if variant in ("positive_face_plane25", "bilateral_planes50"):
        sides.append((1, yz_full))
    if variant == "negative_face_sparse5":
        sides.append((-1, yz_sparse))
    specs = []
    for side, yz_values in sides:
        direction = (-side, 0, 0)
        for y, z in yz_values:
            q = add(c, (side * SUPPORT_DISTANCE, y, z), 1, n)
            specs.append((q, direction, y, z, side))
    return specs


def add_support(world, meta, variant):
    installed = []
    for index, (q, direction, y, z, side) in enumerate(source_specs(meta, variant)):
        if int(world.raw[q]):
            return {"valid": False, "reason": "t0_overlap", "q": list(q), "installed": installed}
        sreg = (11, 13, 17, 19)[index % 4]
        raw = int(pack(12000 + index + (0 if side < 0 else 100), sreg, direction, 4))
        set_both(world, q, raw, 211 + index)
        installed.append({"q": list(q), "raw": raw, "direction": list(direction),
                          "s_reg": sreg, "relative_yz": [y, z]})
    return {"valid": True, "installed": installed}


def local_signature(world, meta, radius=2):
    c, n = meta["c"], meta["n"]
    positions = sorted({add(c, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})
    occupied = sum(bool(int(world.raw[q])) for q in positions)
    sreg_sum = sum((int(world.raw[q]) >> 32) & 0xFFFF for q in positions if int(world.raw[q]))
    return {"radius": radius, "voxel_count": len(positions), "occupied": occupied,
            "s_reg_sum": int(sreg_sum)}


def install_probe(world, meta):
    q, raw = persistent_writer_spec(meta, "b")
    replaced = int(world.raw[q])
    set_both(world, q, raw, PROBE_TICK)
    return {"type": "DIAGNOSTIC_INTERVENTION", "q": list(q), "raw": raw,
            "clock": PROBE_TICK, "replaced_raw": replaced}


def run(kernel, variant, expression):
    r10.OFFSET = OFFSET
    try:
        world, meta = r10.build(kernel, "a", expression=expression)
        support = add_support(world, meta, variant)
    except RuntimeError as exc:
        return {"variant": variant, "expression": expression, "valid": False, "reason": str(exc)}
    if not support["valid"]:
        return {"variant": variant, "expression": expression, "valid": False, "reason": support}
    previous = 0; transitions = []; samples = []; probe = None; first_write = None
    support_initial = {tuple(item["q"]): item["raw"] for item in support["installed"]}
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            probe = install_probe(world, meta)
        delta = delta_value(world, meta)
        if delta not in (None, 0) and first_write is None:
            first_write = tick
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick in (1, 8, 9, 10, 24, 64, 128, 183, 184, 185, 256, 334, 400, 529, 531, 600):
            samples.append({"tick": tick, "master_delta": delta, "remote_pair": pair(world, meta),
                            "local": local_signature(world, meta)})
        previous = delta
    post_probe = [event for event in transitions if event["tick"] > PROBE_TICK]
    fixed = all(int(world.raw[q]) == raw for q, raw in support_initial.items())
    return {"variant": variant, "expression": expression, "valid": True,
            "native_support_at_t0": support, "native_support_count": len(support["installed"]),
            "initial_native_write_tick": first_write, "master_transitions": transitions,
            "diagnostic_probe": probe, "post_probe_transitions": post_probe,
            "write_compatible_at_probe": bool(post_probe), "terminal_delta": previous,
            "remote_pair_terminal": pair(world, meta), "support_raw_fixed_terminal": fixed,
            "samples": samples, "python_interventions_after_t0": 1,
            "claim_guard": "The t0 support is native; the writer at tick 184 is a diagnostic competence probe."}


def main():
    kernel, runtime = load_kernel(1)
    variants = ("none", "negative_face_sparse5", "negative_face_plane25",
                "positive_face_plane25", "bilateral_planes50")
    rows = [run(kernel, variant, expression) for variant in variants for expression in (True, False)]
    valid = [row for row in rows if row.get("valid")]
    expressive = [row for row in valid if row["expression"]]
    controls = [row for row in valid if not row["expression"]]
    candidates = [row["variant"] for row in expressive
                  if row["initial_native_write_tick"] is not None and row["write_compatible_at_probe"]]
    result = seal({
        "schema": "dee.v27.ing03.active_ecology.active_plastic_niche.v1",
        "question": "Can a t0-complete persistent causal-support geometry keep an expressed master write-compatible without a host-maintained reset?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "total_world_ticks": len(rows) * HORIZON,
                          "storage_class": "compact checkpoint telemetry", "information_gain": "high"},
        "design": {"remote_offset": list(OFFSET), "support_distance": SUPPORT_DISTANCE,
                   "plane_radius": PLANE_RADIUS, "probe_tick": PROBE_TICK, "horizon": HORIZON,
                   "variants": list(variants), "semantic4_term": "persistent causal support"},
        "rows": rows,
        "summary": {"valid_worlds": len(valid), "native_support_candidates": candidates,
                    "active_plastic_niche_demonstrated": bool(candidates),
                    "unsupported_expression_reopens": next((r["write_compatible_at_probe"] for r in expressive if r["variant"] == "none"), None),
                    "no_expression_controls_write": {r["variant"]: r["write_compatible_at_probe"] for r in controls}},
        "claim_guard": "A positive diagnostic probe would be a prerequisite only. Promotion requires three native consequences after t0 with no probe insertion or host maintenance.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECOLOGY_E01_ACTIVE_PLASTIC_NICHE.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
