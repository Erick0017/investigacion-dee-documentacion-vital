#!/usr/bin/env python3
"""Map late differentiation of a remote apparatus that is present from t0."""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import put_transducer
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair


OFFSET = (-6, 7, 8)
HORIZON = 512
COMMIT_TICKS = (9, 10, 16, 24, 30, 38, 64, 96, 128, 160, 182)
NATIVE_DISTANCES = (6, 10, 14, 18)


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(center, n, radius=3):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def region_sha(world, positions):
    h = hashlib.sha256()
    for q in positions:
        h.update(int(world.raw[q]).to_bytes(8, "little")); h.update(int(world.clock_a[q]).to_bytes(8, "little"))
    return h.hexdigest()


def build_niche(kernel, target, consequence_distance=6):
    world, meta = build_consequence(kernel, target, with_transducer=False, n=41,
                                    memory_phase=252, consequence_distance=consequence_distance)
    sources = add_delayed_sources(world, meta, 24)
    q = add(meta["c"], OFFSET, 1, meta["n"])
    put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, (1, 0, 0), 1, meta["n"]),
                                    "receiver_offset": OFFSET, "bridge_sources": [x[0] for x in sources]})
    return world, meta


def install_relational_state(branch, meta, reference, reference_meta, target, tick):
    changes = []
    for name in ("a", "b"):
        q = meta[name]; rq = reference_meta[name]
        current = read(branch.raw, q); desired = read(reference.raw, rq)
        if current is None or desired is None:
            return {"valid": False, "reason": "master_missing", "tick": tick, "target": target}
        raw = int(pack(current["state"], desired["sreg"], current["direction"], current["semantic"]))
        branch.raw_a[q] = np.uint64(raw); branch.raw_b[q] = np.uint64(raw)
        changes.append({"q": list(q), "before_s_reg": current["sreg"], "after_s_reg": desired["sreg"]})
    return {"valid": True, "type": "DIAGNOSTIC_INTERVENTION", "operation": "late_master_relation_install",
            "target": target, "tick": tick, "changes": changes}


def diagnostic_competence_map(kernel):
    worlds = {}; metas = {}
    for label, target in (("a", "a"), ("b", "b"), ("sham", None)):
        worlds[label], metas[label] = build_niche(kernel, target, 6)
    positions = region(metas["sham"]["q_receiver"], metas["sham"]["n"])
    initial_niche_hashes = {label: region_sha(world, positions) for label, world in worlds.items()}
    branches = []
    for tick in range(1, HORIZON + 1):
        for world in worlds.values(): world.tick()
        if tick in COMMIT_TICKS:
            for target in ("a", "b"):
                branch = clone_world(worlds["sham"])
                intervention = install_relational_state(branch, metas["sham"], worlds[target], metas[target], target, tick)
                branches.append({"target": target, "commit_tick": tick, "world": branch,
                                 "meta": metas["sham"], "intervention": intervention,
                                 "pre_pair": pair(worlds["sham"], metas["sham"]), "samples": []})
        for branch in branches:
            if branch["commit_tick"] < tick:
                branch["world"].tick()
                if tick in (24, 30, 38, 64, 96, 128, 160, 182, 201, 256, 320, 384, 512):
                    branch["samples"].append({"tick": tick, "pair": pair(branch["world"], branch["meta"]),
                                              "master_delta": delta_value(branch["world"], branch["meta"])})
    canonical = {label: pair(world, metas[label]) for label, world in worlds.items()}
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], branch["meta"])
        rows.append({"target": branch["target"], "commit_tick": branch["commit_tick"],
                     "common_precommit_pair": branch["pre_pair"], "intervention": branch["intervention"],
                     "samples": branch["samples"], "terminal_pair": terminal,
                     "terminal_matches_canonical_target": terminal == canonical[branch["target"]],
                     "terminal_matches_sham": terminal == canonical["sham"],
                     "python_interventions_after_t0": 1})
    latest = {}
    for target in ("a", "b"):
        successful = [row["commit_tick"] for row in rows if row["target"] == target and row["terminal_matches_canonical_target"]]
        latest[target] = max(successful) if successful else None
    return {"initial_niche_hashes": initial_niche_hashes,
            "initial_remote_niches_identical": len(set(initial_niche_hashes.values())) == 1,
            "canonical_terminal_pairs": canonical, "rows": rows,
            "latest_tested_diagnostic_commit_tick": latest}


def native_distance_row(kernel, target, distance):
    try:
        world, meta = build_niche(kernel, target, distance)
    except RuntimeError as exc:
        return {"target": target, "consequence_distance": distance, "valid": False, "reason": str(exc)}
    positions = region(meta["q_receiver"], meta["n"])
    initial_hash = region_sha(world, positions); transitions = []; previous = 0; first_write = None
    samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); delta = delta_value(world, meta)
        if delta != previous: transitions.append({"tick": tick, "before": previous, "after": delta})
        if delta not in (None, 0) and first_write is None: first_write = tick
        if tick in (8, 9, 12, 16, 20, 24, 30, 38, 64, 128, 182, 201, 256, 384, 512):
            samples.append({"tick": tick, "master_delta": delta, "pair": pair(world, meta)})
        previous = delta
    return {"target": target, "consequence_distance": distance, "valid": True,
            "initial_niche_sha256": initial_hash, "first_native_write_tick": first_write,
            "master_transitions": transitions, "terminal_master_delta": previous,
            "terminal_pair": pair(world, meta), "samples": samples,
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    diagnostic = diagnostic_competence_map(kernel)
    native_rows = [native_distance_row(kernel, target, distance)
                   for distance in NATIVE_DISTANCES for target in ("a", "b", None)]
    valid_native = [row for row in native_rows if row.get("valid")]
    groups = []
    for distance in NATIVE_DISTANCES:
        subset = [row for row in valid_native if row["consequence_distance"] == distance]
        by = {str(row["target"]): row for row in subset}
        if len(by) != 3:
            groups.append({"distance": distance, "valid": False}); continue
        groups.append({"distance": distance, "valid": True,
                       "initial_niches_identical": len({row["initial_niche_sha256"] for row in subset}) == 1,
                       "a_write_tick": by["a"]["first_native_write_tick"],
                       "b_write_tick": by["b"]["first_native_write_tick"],
                       "a_b_terminal_distinct": by["a"]["terminal_pair"] != by["b"]["terminal_pair"],
                       "a_sham_terminal_distinct": by["a"]["terminal_pair"] != by["None"]["terminal_pair"],
                       "b_sham_terminal_distinct": by["b"]["terminal_pair"] != by["None"]["terminal_pair"],
                       "terminal_pairs": {key: value["terminal_pair"] for key, value in by.items()}})
    late_native = [group["distance"] for group in groups if group.get("valid") and
                   group["a_write_tick"] is not None and group["b_write_tick"] is not None and
                   min(group["a_write_tick"], group["b_write_tick"]) > 9 and group["a_b_terminal_distinct"]]
    result = seal({
        "schema": "dee.v27.ing03.active_ecology.preconditioned_remote_niches.v1",
        "question": "Can a remote apparatus present from t0 remain uncommitted and accept a later A/B instruction?",
        "cost_estimate": {"diagnostic_branches": 2 * len(COMMIT_TICKS),
                          "native_worlds": len(native_rows), "horizon": HORIZON,
                          "storage_class": "checkpoint telemetry", "information_gain": "high"},
        "design": {"receiver_offset": list(OFFSET), "commit_ticks": list(COMMIT_TICKS),
                   "native_consequence_distances": list(NATIVE_DISTANCES),
                   "late_master_install_is_diagnostic": True,
                   "native_distance_worlds_t0_complete": True},
        "diagnostic_competence_map": diagnostic,
        "native_late_instruction_rows": native_rows, "native_distance_groups": groups,
        "summary": {"initial_diagnostic_niches_identical": diagnostic["initial_remote_niches_identical"],
                    "latest_tested_diagnostic_commit_tick": diagnostic["latest_tested_diagnostic_commit_tick"],
                    "native_late_differentiation_distances": late_native,
                    "preconditioned_late_differentiation_demonstrated": bool(late_native)},
        "claim_guard": "A/B commitment is a prerequisite only. No row contains recurrent niche reuse or RW3.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECOLOGY_E02_PRECONDITIONED_REMOTE_NICHES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "groups": groups, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
