#!/usr/bin/env python3
"""Causal decomposition of the far-remote formation history."""
from __future__ import annotations

import argparse
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair


OFFSET = (-6, 7, 8)
HORIZON = 384
SEGMENTS = ((0, 16), (16, 32), (32, 64), (64, 96), (96, 128), (128, 182), (182, 201))
EVENT_INTERVALS = ((0, 32), (32, 64), (64, 128))
CHECKPOINTS = (16, 24, 30, 32, 38, 64, 96, 128, 160, 182, 201, 224, 256, 320, 384)
PARTIAL_DIR = ROOT / "DISCOVERY/ECOLOGY_E03_CHECKPOINTS"


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def restore_source(world, reference, q):
    world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
    world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def run_window(kernel, target, start, end, source_indices):
    world, meta = r10.build(kernel, target); reference, rmeta = r10.build(kernel, target)
    sources = delayed_source_positions(meta); selected = [sources[index] for index in source_indices]
    if start == 0:
        for q in selected: clear(world, q)
    samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); reference.tick()
        if tick == start and start > 0:
            for q in selected: clear(world, q)
        if tick == end:
            for q in selected: restore_source(world, reference, q)
        if tick in CHECKPOINTS:
            samples.append({"tick": tick, "pair": pair(world, meta)})
    canonical = pair(reference, rmeta); terminal = pair(world, meta)
    return {"target": target, "window": [start, end], "source_indices": list(source_indices),
            "terminal_pair": terminal, "canonical_pair": canonical,
            "terminal_matches_canonical": terminal == canonical, "samples": samples,
            "python_interventions_after_t0": 2,
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def run_activation_schedule(kernel, target, name, activation_ticks):
    world, meta = r10.build(kernel, target); reference, rmeta = r10.build(kernel, target)
    sources = delayed_source_positions(meta)
    for index, tick in activation_ticks.items():
        if tick > 0: clear(world, sources[index])
    samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); reference.tick()
        for index, activation_tick in activation_ticks.items():
            if tick == activation_tick and activation_tick > 0:
                restore_source(world, reference, sources[index])
        if tick in CHECKPOINTS: samples.append({"tick": tick, "pair": pair(world, meta)})
    terminal = pair(world, meta); canonical = pair(reference, rmeta)
    return {"target": target, "schedule": name,
            "activation_ticks": {str(k): v for k, v in activation_ticks.items()},
            "terminal_pair": terminal, "canonical_pair": canonical,
            "terminal_matches_canonical": terminal == canonical, "samples": samples,
            "python_interventions_after_t0": sum(tick > 0 for tick in activation_ticks.values()),
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def event_graph(kernel):
    worlds = {}; metas = {}
    for label, target in (("a", "a"), ("b", "b"), ("sham", None)):
        worlds[label], metas[label] = r10.build(kernel, target)
    meta = metas["a"]; c, n = meta["c"], meta["n"]
    sources = delayed_source_positions(meta)
    directions = (S1, S2, N1, N2)
    roles = {}
    for name in ("a", "b", "c", "q_receiver", "qp_receiver"):
        roles.setdefault(meta[name], set()).add(name)
    edges = []
    for index, (source, direction) in enumerate(zip(sources, directions)):
        roles.setdefault(source, set()).add(f"bridge_source_{index}")
        previous = source
        for step in range(1, 25):
            q = add(source, direction, step, n)
            roles.setdefault(q, set()).add(f"bridge_path_{index}_step_{step}")
            edges.append({"from": list(previous), "to": list(q), "kind": "geometric_causal_route",
                          "source_index": index, "step": step})
            previous = q
    for d in product(range(-3, 4), repeat=3):
        roles.setdefault(add(meta["q_receiver"], d, 1, n), set()).add("remote_r3")
    positions = sorted(roles)
    first_ab = {}; first_a_sham = {}; first_b_sham = {}
    for tick in range(1, HORIZON + 1):
        for world in worlds.values(): world.tick()
        for q in positions:
            values = {label: (int(world.raw[q]), int(world.clock_a[q])) for label, world in worlds.items()}
            if q not in first_ab and values["a"] != values["b"]: first_ab[q] = tick
            if q not in first_a_sham and values["a"] != values["sham"]: first_a_sham[q] = tick
            if q not in first_b_sham and values["b"] != values["sham"]: first_b_sham[q] = tick
    nodes = []
    for q in positions:
        nodes.append({"q": list(q), "roles": sorted(roles[q]),
                      "first_difference": {"a_vs_b": first_ab.get(q),
                                           "a_vs_sham": first_a_sham.get(q),
                                           "b_vs_sham": first_b_sham.get(q)}})
    return {"nodes": nodes, "edges": edges,
            "summary": {"instrumented_nodes": len(nodes), "geometric_route_edges": len(edges),
                        "first_a_b_difference_tick": min(first_ab.values()) if first_ab else None,
                        "first_a_sham_difference_tick": min(first_a_sham.values()) if first_a_sham else None,
                        "first_b_sham_difference_tick": min(first_b_sham.values()) if first_b_sham else None}}


def schedules_spec():
    return {
        "all_native": {0: 0, 1: 0, 2: 0, 3: 0},
        "all_delayed_1": {0: 1, 1: 1, 2: 1, 3: 1},
        "all_delayed_2": {0: 2, 1: 2, 2: 2, 3: 2},
        "all_delayed_4": {0: 4, 1: 4, 2: 4, 3: 4},
        "all_delayed_8": {0: 8, 1: 8, 2: 8, 3: 8},
        "subset_013_then_2": {0: 0, 1: 0, 2: 16, 3: 0},
        "source_2_then_013": {0: 16, 1: 16, 2: 0, 3: 16},
        "stagger_0_1_3_2": {0: 0, 1: 2, 3: 4, 2: 8},
    }


def checkpoint_path(phase):
    return PARTIAL_DIR / f"{phase}.json"


def save_checkpoint(phase, payload, runtime):
    value = seal({"schema": f"dee.v27.ing03.active_ecology.formation_program.checkpoint.{phase}.v1",
                  "phase": phase, "payload": payload, "runtime": runtime})
    write_json(checkpoint_path(phase), value)
    print(json.dumps({"checkpoint": str(checkpoint_path(phase)), "phase": phase,
                      "content_sha256": value["content_sha256"]}, indent=2))


def load_checkpoint(phase):
    return json.loads(checkpoint_path(phase).read_text(encoding="utf-8"))["payload"]


def run_phase(kernel, runtime, phase):
    if phase == "temporal":
        rows = [run_window(kernel, target, start, end, range(4))
                for target in ("a", "b") for start, end in SEGMENTS]
        save_checkpoint(phase, rows, runtime)
    elif phase == "event":
        rows = [run_window(kernel, target, start, end, (source_index,))
                for target in ("a", "b") for start, end in EVENT_INTERVALS for source_index in range(4)]
        save_checkpoint(phase, rows, runtime)
    elif phase == "order":
        schedules = schedules_spec()
        rows = [run_activation_schedule(kernel, target, name, schedule)
                for target in ("a", "b") for name, schedule in schedules.items()]
        save_checkpoint(phase, rows, runtime)
    elif phase == "graph":
        save_checkpoint(phase, event_graph(kernel), runtime)
    else:
        raise ValueError(phase)


def assemble(runtime):
    temporal_rows = load_checkpoint("temporal")
    event_rows = load_checkpoint("event")
    order_rows = load_checkpoint("order")
    graph = load_checkpoint("graph")
    schedules = schedules_spec()
    necessary_segments = {}
    necessary_events = {}
    for target in ("a", "b"):
        necessary_segments[target] = [row["window"] for row in temporal_rows
                                      if row["target"] == target and not row["terminal_matches_canonical"]]
        necessary_events[target] = [{"window": row["window"], "source_index": row["source_indices"][0]}
                                    for row in event_rows if row["target"] == target and not row["terminal_matches_canonical"]]
    tolerated = {target: [row["schedule"] for row in order_rows
                          if row["target"] == target and row["terminal_matches_canonical"]]
                 for target in ("a", "b")}
    minimal_found = any(name != "all_native" for names in tolerated.values() for name in names)
    result = seal({
        "schema": "dee.v27.ing03.active_ecology.formation_program.v1",
        "question": "Which events, intervals, and order relations in the long bridge history are necessary or sufficient for canonical remote identity?",
        "cost_estimate": {"temporal_ablation_worlds": len(temporal_rows),
                          "event_ablation_worlds": len(event_rows), "order_worlds": len(order_rows),
                          "observational_worlds": 3, "horizon": HORIZON,
                          "information_gain": "high", "storage_class": "compact checkpoint telemetry plus event graph"},
        "design": {"receiver_offset": list(OFFSET), "segments": [list(x) for x in SEGMENTS],
                   "event_intervals": [list(x) for x in EVENT_INTERVALS], "source_count": 4,
                   "schedules": schedules, "all_interventions_diagnostic": True},
        "formation_event_graph": graph,
        "temporal_ablation_rows": temporal_rows, "event_ablation_rows": event_rows,
        "order_and_timing_rows": order_rows,
        "summary": {"necessary_tested_segments": necessary_segments,
                    "necessary_tested_source_events": necessary_events,
                    "canonical_schedules": tolerated,
                    "compressed_schedule_candidate_exists": minimal_found,
                    "minimal_sufficient_formation_program_demonstrated": False,
                    "native_formation_program_generator_demonstrated": False},
        "claim_guard": "Window removal/restoration and delayed activation are diagnostic interventions. Canonical completion under a shorter schedule is a candidate, not a native generator.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_ECOLOGY_E03_FORMATION_PROGRAM.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "graph": graph["summary"], "content_sha256": result["content_sha256"]}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=("temporal", "event", "order", "graph", "assemble", "all"), default="all")
    args = parser.parse_args()
    kernel, runtime = load_kernel(1); r10.OFFSET = OFFSET
    if args.phase in ("temporal", "event", "order", "graph"):
        run_phase(kernel, runtime, args.phase)
        return
    if args.phase == "all":
        for phase in ("temporal", "event", "order", "graph"):
            run_phase(kernel, runtime, phase)
    assemble(runtime)


if __name__ == "__main__":
    main()
