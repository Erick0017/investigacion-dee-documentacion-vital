#!/usr/bin/env python3
"""Search finite probes that read relational state without blocking future writes."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0)); PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))
AXES=((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1))


def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic); clock[q]=np.uint64(phase)


def build(kernel,delta,probe=None,n=17):
    c=(n//2,)*3; a=add(c,(-1,0,0),1,n); b=add(c,(1,0,0),1,n)
    raw=np.zeros((n,n,n),np.uint64); clock=np.zeros_like(raw); occupied={a,b}
    put(raw,clock,a,1000,100+delta,semantic=1,phase=260); put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA): q=add(a,o,1,n);put(raw,clock,q,3000+i,0,semantic=4,phase=31+i);occupied.add(q)
    for i,o in enumerate(PB): q=add(b,o,1,n);put(raw,clock,q,4000+i,0,semantic=4,phase=41+i);occupied.add(q)
    event=add(b,(0,-1,0),1,n); writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,5000,0,(0,0,1),4,0);occupied.add(writer)
    probe_q=None
    if probe:
        target={"a":a,"b":b,"c":c}[probe["target"]]; direction=tuple(probe["direction"]);probe_q=add(target,direction,-int(probe["distance"]),n)
        put(raw,clock,probe_q,7001,int(probe["sreg"]),direction,1,int(probe["phase"]));occupied.add(probe_q)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"probe":probe_q,"occupied":occupied}


def dval(world,p):
    a,b=read(world.raw,p["a"]),read(world.raw,p["b"]);return None if a is None or b is None else a["sreg"]-b["sreg"]


def run_pair(kernel,delta,probe,horizon=1024):
    base,pb=build(kernel,delta,None); world,p=build(kernel,delta,probe); h=hashlib.sha256(); external=[]; deltas=[]; base_deltas=[]; clear16=None
    excluded=set(p["occupied"]);excluded.discard(p["probe"])
    for tick in range(1,horizon+1):
        base.tick();world.tick();deltas.append(dval(world,p));base_deltas.append(dval(base,pb))
        if tick<=16:
            diff=np.argwhere(world.raw!=base.raw);outside=[]
            for row in diff:
                q=tuple(int(x) for x in row)
                if q not in excluded: outside.append((q,int(world.raw[q]),int(base.raw[q])))
            h.update(json.dumps(outside,sort_keys=True,separators=(",",":")).encode())
            if outside and len(external)<12: external.append({"tick":tick,"differences":[{"q":list(q),"probe_raw":x,"baseline_raw":y,"probe_decoded":None if x==0 else unpack_scalar(x)} for q,x,y in outside[:8]]})
        if tick==16: clear16=int(world.raw[p["probe"]])==0
    def transitions(v,start=16): return sum(v[i]!=v[i-1] for i in range(max(1,start),len(v)))
    return {"delta":delta,"signature_sha256":h.hexdigest(),"external_trace":external,"external_observed":bool(external),"probe_site_clear_tick16":clear16,"post16_delta_transitions":transitions(deltas),"baseline_post16_delta_transitions":transitions(base_deltas),"terminal_delta":deltas[-1],"baseline_terminal_delta":base_deltas[-1],"future_writable":transitions(deltas)>=max(1,transitions(base_deltas)-2),"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1);configs=[]
    for target,direction,distance in itertools.product(("a","b","c"),AXES,(1,2,3)):
        configs.append({"target":target,"direction":list(direction),"distance":distance,"sreg":7,"phase":0})
    rows=[];candidates=[]
    for i,cfg in enumerate(configs):
        try: sub=[run_pair(kernel,d,cfg) for d in (-8,0,8)]
        except RuntimeError: continue
        hashes=[r["signature_sha256"] for r in sub]; external=all(r["external_observed"] for r in sub); writable=all(r["future_writable"] for r in sub)
        row={"config_id":f"TP{i:03d}","probe":cfg,"classes":sub,"distinct_signatures":len(set(hashes)),"all_external":external,"all_future_writable":writable,"candidate":len(set(hashes))>=2 and external and writable}
        rows.append(row)
        if row["candidate"]:candidates.append(row)
    result=seal({"schema":"dee.v27.ing03.extension.discovery.trajectory_probe_search.v1","family":"E_NON_OCCUPYING_TRAJECTORY_READOUT","question":"Can a finite probe produce delta-dependent external trajectories while leaving the relation writable?","search":{"targets":["a","b","c"],"directions":AXES,"distances":[1,2,3],"sreg":7,"phase":0,"deltas":[-8,0,8],"horizon":1024},"rows":rows,"candidate_count":len(candidates),"candidates":candidates,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D17_TRAJECTORY_PROBE_SEARCH.json";write_json(out,result)
    print(json.dumps({"output":str(out),"valid_configs":len(rows),"candidate_count":len(candidates),"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
