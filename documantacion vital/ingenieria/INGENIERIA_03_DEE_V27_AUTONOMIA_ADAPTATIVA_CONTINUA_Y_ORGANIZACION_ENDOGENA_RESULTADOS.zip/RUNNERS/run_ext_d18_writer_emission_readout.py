#!/usr/bin/env python3
"""Search the recurrent writer's own emitted trajectory for relation-dependent output."""
from __future__ import annotations

import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,unpack_scalar,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))


def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(q)
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)


def build(kernel,delta,n=17):
    c=(n//2,)*3;a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);fixed={a,b}
    put(raw,clock,a,1000,100+delta,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):q=add(a,o,1,n);put(raw,clock,q,3000+i,0,semantic=4,phase=31+i);fixed.add(q)
    for i,o in enumerate(PB):q=add(b,o,1,n);put(raw,clock,q,4000+i,0,semantic=4,phase=41+i);fixed.add(q)
    event=add(b,(0,-1,0),1,n);source=add(event,(0,0,1),-3,n);put(raw,clock,source,5000,0,(0,0,1),4,0);fixed.add(source)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"fixed":fixed,"source":source}


def main():
    kernel,runtime=load_kernel(1);deltas=(-8,0,8);worlds=[];ports=[]
    for d in deltas:w,p=build(kernel,d);worlds.append(w);ports.append(p)
    observations=defaultdict(dict);delta_traces={str(d):[] for d in deltas}
    for tick in range(1,257):
        for d,w,p in zip(deltas,worlds,ports):
            w.tick();ra,rb=read(w.raw,p["a"]),read(w.raw,p["b"]);delta_traces[str(d)].append(None if ra is None or rb is None else ra["sreg"]-rb["sreg"])
            for row in np.argwhere(w.raw!=0):
                q=tuple(int(x) for x in row)
                if q not in p["fixed"]: observations[(tick,q)][d]=int(w.raw[q])
    candidates=[]
    for (tick,q),vals in observations.items():
        rawvals=[vals.get(d,0) for d in deltas]
        if len(set(rawvals))<2:continue
        decoded=[None if v==0 else unpack_scalar(v) for v in rawvals]
        direction_classes=len(set(None if x is None else tuple(x["direction"]) for x in decoded))
        sreg_classes=len(set(None if x is None else x["sreg"] for x in decoded))
        semantic_classes=len(set(None if x is None else x["semantic"] for x in decoded))
        candidates.append({"tick":tick,"q":list(q),"raw_by_initial_delta":dict(zip(map(str,deltas),rawvals)),"decoded_by_initial_delta":dict(zip(map(str,deltas),decoded)),"direction_classes":direction_classes,"sreg_classes":sreg_classes,"semantic_classes":semantic_classes})
    candidates.sort(key=lambda x:(max(x["direction_classes"],x["sreg_classes"],x["semantic_classes"]),-x["tick"]),reverse=True)
    exact_three=[c for c in candidates if max(c["direction_classes"],c["sreg_classes"],c["semantic_classes"])==3]
    # Fixed-port signatures: retain only ports with differences on >=2 ticks.
    by_q=defaultdict(list)
    for c in candidates:by_q[tuple(c["q"])].append(c)
    recurrent_ports=[{"q":list(q),"distinguishing_ticks":len(rows),"first_tick":min(r["tick"] for r in rows),"last_tick":max(r["tick"] for r in rows),"examples":rows[:12]} for q,rows in by_q.items() if len(rows)>=2]
    recurrent_ports.sort(key=lambda x:x["distinguishing_ticks"],reverse=True)
    result=seal({"schema":"dee.v27.ing03.extension.discovery.writer_emission_readout.v1","family":"E_NON_OCCUPYING_TRAJECTORY_READOUT","question":"Does the unprobed recurrent writer emit a relation-dependent external trajectory while remaining plastic?","deltas":deltas,"horizon":256,"candidate_events":len(candidates),"three_class_events":len(exact_three),"top_three_class_events":exact_three[:100],"recurrent_fixed_ports":recurrent_ports[:100],"delta_traces":delta_traces,"future_writable":all(len(set(v))>=2 for v in delta_traces.values()),"python_interventions_after_t0":0,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D18_WRITER_EMISSION_READOUT.json";write_json(out,result)
    print(json.dumps({"output":str(out),"candidate_events":len(candidates),"three_class_events":len(exact_three),"recurrent_ports":len(recurrent_ports),"future_writable":result["future_writable"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
