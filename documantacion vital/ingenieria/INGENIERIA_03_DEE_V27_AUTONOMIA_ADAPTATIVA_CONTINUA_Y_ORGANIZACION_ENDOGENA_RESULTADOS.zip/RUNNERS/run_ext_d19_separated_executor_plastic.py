#!/usr/bin/env python3
"""Test spatial separation of a writable relational organ and a maintained executor/readout."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,read,seal,write_json
from run_d15_shared_writer_interference import delta,pair,put


def run(kernel,reader_target,separation=6,horizon=4096):
    n=41;c1=(20,20,8);c2=(20,20,8+separation);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    pairs=[pair(raw,clock,c1,1000,n),pair(raw,clock,c2,4000,n)]
    event=add(pairs[0][0],(0,-1,0),1,n);writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,8000,0,(0,0,1),4,0)
    reader=None
    if reader_target in (0,1):
        center=(c1,c2)[reader_target];reader=add(center,(0,-2,0),1,n);put(raw,clock,reader,9000,7,(0,1,0),4,23)
    world=NativeWorld(kernel,raw,clock);prev=[None,None];trans=[0,0];out_ticks=0;samples=[]
    for tick in range(1,horizon+1):
        world.tick();ds=[delta(world.raw,ab) for ab in pairs];comp=read(world.raw,(c1,c2)[reader_target]) if reader_target in (0,1) else None
        for i,d in enumerate(ds):
            if prev[i] is not None and d!=prev[i]:trans[i]+=1
            prev[i]=d
        if comp is not None and comp["direction"] != [0,0,0]:out_ticks+=1
        if tick in (1,64,256,512,1024,2048,4096):samples.append({"tick":tick,"deltas":ds,"comparator":comp,"support":int(np.count_nonzero(world.raw))})
    return {"reader_target":reader_target,"separation":separation,"horizon":horizon,"delta_transitions":trans,"terminal_deltas":prev,"output_direction_ticks":out_ticks,"reader_raw_fixed":None if reader is None else int(world.raw[reader])==int(raw[reader]),"samples":samples,"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1);rows=[]
    for sep in (4,6,8,10,12):
        for reader in (None,0,1): rows.append(run(kernel,reader,sep))
    result=seal({"schema":"dee.v27.ing03.extension.discovery.separated_executor_plastic.v1","family":"B_SPATIAL_FUNCTIONAL_SEPARATION","question":"Can one aligned relational organ remain plastic while a different organ on the shared stream is continuously read?","rows":rows,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D19_SEPARATED_EXECUTOR_PLASTIC.json";write_json(out,result)
    print(json.dumps({"output":str(out),"rows":[{"sep":r["separation"],"reader":r["reader_target"],"trans":r["delta_transitions"],"terminal":r["terminal_deltas"],"output_ticks":r["output_direction_ticks"]} for r in rows],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
