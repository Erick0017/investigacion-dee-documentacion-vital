#!/usr/bin/env python3
"""Map phase and s_reg dependence of maintained reader/write compatibility."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(q)
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def run(kernel,phase,sreg,semantic=4,horizon=1024):
    n=17;c=(8,8,8);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    event=add(b,(0,-1,0),1,n);writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,5000,0,(0,0,1),4,0)
    reader=add(c,(0,-2,0),1,n);put(raw,clock,reader,6000,sreg,(0,1,0),semantic,phase)
    world=NativeWorld(kernel,raw,clock);prev=None;dtrans=0;directions=set();out_ticks=0;samples=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);d=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        if prev is not None and d!=prev:dtrans+=1
        prev=d
        if rc is not None:directions.add(tuple(rc["direction"]));out_ticks+=int(rc["direction"]!=[0,0,0])
        if tick in (1,2,4,16,64,256,512,1024):samples.append({"tick":tick,"delta":d,"comparator":rc})
    return {"phase":phase,"sreg":sreg,"semantic":semantic,"delta_transitions":dtrans,"terminal_delta":prev,"comparator_direction_classes":[list(x) for x in sorted(directions)],"output_direction_ticks":out_ticks,"reader_raw_fixed":int(world.raw[reader])==int(raw[reader]),"samples":samples,"rw_candidate":dtrans>=3 and len(directions)>=2,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for phase in range(195):rows.append(run(kernel,phase,7,4))
    for sreg in range(0,33):rows.append(run(kernel,23,sreg,4))
    for phase in (0,1,22,23,24,63,64,127,128,194):rows.append(run(kernel,phase,7,1))
    candidates=[r for r in rows if r["rw_candidate"]]
    result=seal({"schema":"dee.v27.ing03.extension.discovery.reader_phase_sreg_map.v1","families":["A_TEMPORAL_SEPARATION","C_STATE_DEPENDENT_MODULATION"],"question":"Can clock phase, source persistence, or s_reg create a native reader window that preserves recurrent writing?","rows":rows,"candidate_count":len(candidates),"candidates":candidates,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D20_READER_PHASE_SREG_MAP.json";write_json(out,result)
    print(json.dumps({"output":str(out),"rows":len(rows),"candidates":len(candidates),"content_sha256":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
