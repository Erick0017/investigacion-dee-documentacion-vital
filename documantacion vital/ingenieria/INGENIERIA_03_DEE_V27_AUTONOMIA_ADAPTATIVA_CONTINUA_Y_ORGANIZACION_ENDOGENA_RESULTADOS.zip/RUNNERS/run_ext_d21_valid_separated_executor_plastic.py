#!/usr/bin/env python3
"""Separated plastic/executor test using the validated adjacent relational-reader geometry."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def install_pair(raw,clock,c,base,n):
    a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n)
    put(raw,clock,a,base,100,semantic=1,phase=260);put(raw,clock,b,base+1000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),base+100+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),base+1100+i,0,semantic=4,phase=41+i)
    return a,b

def delta(raw,ab):
    a,b=read(raw,ab[0]),read(raw,ab[1]);return None if a is None or b is None else a["sreg"]-b["sreg"]

def run(kernel,sep,reader_target,horizon=4096):
    n=41;c1=(20,20,8);c2=(20,20,8+sep);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);pairs=[install_pair(raw,clock,c1,1000,n),install_pair(raw,clock,c2,5000,n)]
    event=add(pairs[0][1],(0,-1,0),1,n);source=add(event,(0,0,1),-3,n);put(raw,clock,source,9000,0,(0,0,1),4,0)
    reader=None
    if reader_target in (0,1):
        c=(c1,c2)[reader_target];reader=add(c,(0,-2,0),1,n);put(raw,clock,reader,10000,7,(0,1,0),4,23)
    world=NativeWorld(kernel,raw,clock);prev=[None,None];trans=[0,0];sign_matches=[0,0];nonzero=[0,0];reader_classes=set();samples=[]
    for tick in range(1,horizon+1):
        world.tick();ds=[delta(world.raw,x) for x in pairs]
        comp=read(world.raw,(c1,c2)[reader_target]) if reader_target in (0,1) else None
        for i,d in enumerate(ds):
            if prev[i] is not None and d!=prev[i]:trans[i]+=1
            prev[i]=d
        if comp is not None:
            reader_classes.add(tuple(comp["direction"]));nonzero[reader_target]+=int(comp["direction"]!=[0,0,0])
            if ds[reader_target] is not None and comp["direction"][0]!=0:sign_matches[reader_target]+=int((comp["direction"][0]>0)==(ds[reader_target]>0))
        if tick in (1,64,256,512,1024,2048,4096):samples.append({"tick":tick,"deltas":ds,"comparator":comp,"support":int(np.count_nonzero(world.raw))})
    return {"separation":sep,"reader_target":reader_target,"delta_transitions":trans,"terminal_deltas":prev,"reader_direction_classes":[list(x) for x in sorted(reader_classes)],"reader_nonzero_ticks":nonzero,"reader_sign_matches":sign_matches,"reader_raw_fixed":None if reader is None else int(world.raw[reader])==int(raw[reader]),"samples":samples,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for sep in (4,6,8,10,12):
        for reader in (None,0,1):
            try:rows.append(run(kernel,sep,reader))
            except RuntimeError as exc:rows.append({"separation":sep,"reader_target":reader,"construction_valid":False,"reason":str(exc)})
    result=seal({"schema":"dee.v27.ing03.extension.discovery.valid_separated_executor_plastic.v1","family":"B_SPATIAL_FUNCTIONAL_SEPARATION","question":"With the validated c±x reader geometry, can one organ be read while another on the shared stream remains plastic?","rows":rows,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D21_VALID_SEPARATED_EXECUTOR_PLASTIC.json";write_json(out,result)
    print(json.dumps({"output":str(out),"rows":[{"sep":r.get("separation"),"reader":r.get("reader_target"),"valid":r.get("construction_valid",True),"trans":r.get("delta_transitions"),"terminal":r.get("terminal_deltas"),"dirs":r.get("reader_direction_classes")} for r in rows],"content_sha256":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
