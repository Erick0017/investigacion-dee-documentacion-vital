#!/usr/bin/env python3
"""Minimal native READ -> delayed WRITE -> READ search with all machinery present at t0."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(q)
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def run(kernel,memory_phase,target,event_state,reader_mode,horizon=64):
    n=17;c=(8,8,8);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,101,semantic=1,phase=memory_phase);put(raw,clock,b,2000,100,semantic=1,phase=memory_phase)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    # One-shot experience carrier, prebuilt at t0.
    center=a if target=="a" else b;side=(0,-1,0) if target=="a" else (0,1,0);event=add(center,side,1,n);put(raw,clock,event,7000+event_state,0,side,1,19)
    reader=add(c,(0,-2,0),1,n)
    if reader_mode!="none":put(raw,clock,reader,6000,7,(0,1,0),4 if reader_mode=="persistent" else 1,23)
    world=NativeWorld(kernel,raw,clock);trace=[];first_change=None;initial=1
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);d=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        if first_change is None and d!=initial:first_change=tick
        trace.append({"tick":tick,"delta":d,"comparator":rc})
    before=[r for r in trace if first_change is None or r["tick"]<first_change];after=[r for r in trace if first_change is not None and r["tick"]>first_change]
    def sig(x):return None if x is None else [x["state"],x["sreg"],x["direction"],x["semantic"]]
    pre={json.dumps(sig(r["comparator"]),sort_keys=True) for r in before if r["comparator"] is not None};post={json.dumps(sig(r["comparator"]),sort_keys=True) for r in after if r["comparator"] is not None}
    return {"memory_phase":memory_phase,"target":target,"event_state":event_state,"reader_mode":reader_mode,"first_delta_change":first_change,"terminal_delta":trace[-1]["delta"],"pre_read_available":bool(pre),"post_read_available":bool(post),"readout_changed_after_write":bool(pre and post and pre!=post),"rw1_candidate":reader_mode!="none" and first_change is not None and first_change>1 and bool(pre) and bool(post),"rw2_candidate":reader_mode!="none" and first_change is not None and bool(pre) and bool(post) and pre!=post,"trace":trace,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for phase in range(240,261):
        for target in ("a","b"):
            for state in (0,1):
                for reader in ("none","finite","persistent"):
                    try:rows.append(run(kernel,phase,target,state,reader))
                    except RuntimeError:pass
    rw1=[r for r in rows if r["rw1_candidate"]];rw2=[r for r in rows if r["rw2_candidate"]]
    result=seal({"schema":"dee.v27.ing03.extension.discovery.delayed_write_after_read.v1","family":"A_TEMPORAL_SEPARATION","question":"Can a prebuilt phase-delayed experience update a relation after an earlier native read, with readout still available?","rows":rows,"rw1_candidates":rw1,"rw2_candidates":rw2,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D22_DELAYED_WRITE_AFTER_READ.json";write_json(out,result)
    print(json.dumps({"output":str(out),"rows":len(rows),"rw1":len(rw1),"rw2":len(rw2),"content_sha256":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
