#!/usr/bin/env python3
"""Search finite prebuilt cleanup carriers that release the reader-occupied interface."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json

PA=((-1,0,0),(-1,1,1),(0,0,1),(0,1,0));PB=((0,-1,0),(0,0,-1),(1,-1,-1),(1,0,0));AX=((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1))

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(q)
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def run(kernel,direction,distance,sreg,phase,horizon=1024):
    n=17;c=(8,8,8);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    event=add(b,(0,-1,0),1,n);writer=add(event,(0,0,1),-3,n);put(raw,clock,writer,5000,0,(0,0,1),4,0)
    reader=add(c,(0,-2,0),1,n);put(raw,clock,reader,6000,7,(0,1,0),1,23)
    cleaner=add(c,direction,-distance,n);put(raw,clock,cleaner,7000,sreg,direction,1,phase)
    world=NativeWorld(kernel,raw,clock);prev=None;dtrans=0;out_early=False;out_late=False;comp_clear=False;samples=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);d=None if ra is None or rb is None else ra["sreg"]-rb["sreg"]
        if prev is not None and d!=prev:dtrans+=1
        prev=d
        if tick<=16 and rc is not None:out_early=True
        if tick>=256 and rc is not None:out_late=True
        if tick>=4 and rc is None:comp_clear=True
        if tick in (1,2,4,8,16,64,256,512,1024):samples.append({"tick":tick,"delta":d,"comparator":rc})
    return {"direction":list(direction),"distance":distance,"sreg":sreg,"phase":phase,"delta_transitions":dtrans,"terminal_delta":prev,"output_early":out_early,"output_late":out_late,"comparator_ever_clear_after_read":comp_clear,"rw1_candidate":out_early and dtrans>=3,"samples":samples,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for direction,distance,sreg,phase in itertools.product(AX,(1,2,3,4,5,6),(0,7),(0,23,64,128,194,260)):
        try:rows.append(run(kernel,direction,distance,sreg,phase))
        except RuntimeError:pass
    candidates=[r for r in rows if r["rw1_candidate"]]
    result=seal({"schema":"dee.v27.ing03.extension.discovery.finite_reader_cleanup.v1","families":["A_REFRACTORY_WINDOW","C_REVERSIBLE_MODULATION"],"question":"Can a finite prebuilt carrier clear/release a prior readout and allow the recurrent writer to resume?","rows":rows,"candidate_count":len(candidates),"candidates":candidates,"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_EXT_D23_FINITE_READER_CLEANUP.json";write_json(out,result)
    print(json.dumps({"output":str(out),"rows":len(rows),"candidates":len(candidates),"content_sha256":result["content_sha256"]},indent=2))

if __name__=="__main__":main()
