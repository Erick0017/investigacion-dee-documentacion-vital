#!/usr/bin/env python3
"""Model-selection frame panel for the informative/blocking trade-off."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from read_write_extension_apparatus_v1 import run_probe_class

def main():
    kernel,runtime=load_kernel(1);rows=[]
    frames=[(p,s) for p in itertools.permutations((0,1,2)) for s in ((1,1,1),(-1,1,-1))]
    for i,(p,s) in enumerate(frames):
        for kind in ("INFORMATIVE_BLOCKING","WRITABLE_UNINFORMATIVE"):
            rows.append(run_probe_class(kernel,{"case_id":f"PF{i:02d}_{kind}","n":23,"origin":[11,11,11],"permutation":list(p),"signs":list(s),"probe_kind":kind}))
    result=seal({"schema":"dee.v27.ing03.extension.model_selection.probe_frame_panel.v1","question":"Is the information/plasticity trade-off invariant across signed/permuted frames?","rows":rows,"summary":{"world_groups":len(rows),"pass":sum(r["prediction_pass"] for r in rows)},"runtime":runtime})
    out=ROOT/"MECHANISM_SELECTION/ING03_EXT_D24_PROBE_FRAME_PANEL.json";write_json(out,result)
    print(json.dumps({"output":str(out),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
