#!/usr/bin/env python3
"""Microscopy of where informative finite probes alter the relational writer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, read, seal, unpack_scalar, write_json
from read_write_extension_apparatus_v1 import build_probe, delta


def compact(raw, q):
    return None if int(raw[q]) == 0 else unpack_scalar(raw[q])


def run(kernel, kind, initial_delta):
    spec = {"n": 23, "origin": [11, 11, 11], "permutation": [0, 1, 2], "signs": [1, 1, 1], "probe_kind": kind}
    base, pb = build_probe(kernel, spec, initial_delta, False)
    world, ports = build_probe(kernel, spec, initial_delta, True)
    key_sites = sorted(set(ports["fixed"]) | {ports["a"], ports["b"], ports["c"], ports["probe"]})
    trace = []
    previous_delta = delta(world, ports)
    transitions = 0
    for tick in range(1, 1025):
        base.tick(); world.tick()
        current_delta = delta(world, ports)
        if tick > 16 and current_delta != previous_delta:
            transitions += 1
        previous_delta = current_delta
        if tick <= 20 or tick in {32, 64, 128, 256, 512, 1024}:
            changed = []
            for row in np.argwhere(world.raw != base.raw):
                q = tuple(int(x) for x in row)
                changed.append({"q": list(q), "treatment": compact(world.raw, q), "control": compact(base.raw, q)})
            trace.append({
                "tick": tick,
                "delta": current_delta,
                "control_delta": delta(base, pb),
                "a": read(world.raw, ports["a"]),
                "b": read(world.raw, ports["b"]),
                "comparator": read(world.raw, ports["c"]),
                "probe_start": read(world.raw, ports["probe"]),
                "changed_cells": changed,
            })
    return {
        "probe_kind": kind,
        "initial_delta": initial_delta,
        "ports": {key: (None if value is None else list(value)) if key != "fixed" else [list(q) for q in sorted(value)] for key, value in ports.items()},
        "post16_delta_transitions": transitions,
        "trace": trace,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, kind, delta0) for kind in ("INFORMATIVE_BLOCKING", "WRITABLE_UNINFORMATIVE") for delta0 in (-8, 0, 8)]
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.interface_microscopy.v1",
        "question": "Which exact local records distinguish informative-blocking from writable-uninformative finite probes?",
        "rows": rows,
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D25_INTERFACE_MICROSCOPY.json"
    write_json(output, result)
    summary = [{"kind": r["probe_kind"], "delta": r["initial_delta"], "transitions": r["post16_delta_transitions"], "first_changed": len(r["trace"][0]["changed_cells"])} for r in rows]
    print(json.dumps({"output": str(output), "summary": summary, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
