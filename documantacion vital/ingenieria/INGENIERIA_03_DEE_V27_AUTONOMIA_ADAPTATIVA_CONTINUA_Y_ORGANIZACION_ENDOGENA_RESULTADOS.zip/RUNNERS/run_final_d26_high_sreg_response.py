#!/usr/bin/env python3
"""Adaptive high-s_reg map for the maintained relational reader."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
LEVELS = (0, 1, 7, 31, 32, 63, 127, 255, 511, 1023, 2047, 4095, 8191, 16383, 19662, 19663, 19664, 19665, 32767, 49151, 65534, 65535)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def cap_case(kernel, sreg):
    n = 11; target = (5, 5, 5)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    for state, direction in ((101, (1, 0, 0)), (102, (0, 1, 0))):
        put(raw, clock, add(target, direction, -1, n), state, sreg, direction, 1, 0)
    world = NativeWorld(kernel, raw, clock); world.tick()
    return {"input_sreg_each": sreg, "output": read(world.raw, target)}


def reader_case(kernel, sreg, semantic, phase, initial_delta=0, horizon=1024):
    n = 17; c = (8, 8, 8); a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100 + initial_delta, semantic=1, phase=260)
    put(raw, clock, b, 2000, 100, semantic=1, phase=260)
    for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    event = add(b, (0, -1, 0), 1, n); writer = add(event, (0, 0, 1), -3, n)
    put(raw, clock, writer, 5000, 0, (0, 0, 1), 4, 0)
    reader = add(c, (0, -2, 0), 1, n)
    put(raw, clock, reader, 6000, sreg, (0, 1, 0), semantic, phase)
    world = NativeWorld(kernel, raw, clock)
    previous = None; transitions = 0; direction_classes = set(); output_ticks = 0; comparator_absent = 0; memory_destroyed = False
    samples = []
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb, rc = read(world.raw, a), read(world.raw, b), read(world.raw, c)
        if ra is None or rb is None:
            memory_destroyed = True; current = None
        else:
            current = ra["sreg"] - rb["sreg"]
        if previous is not None and current != previous: transitions += 1
        previous = current
        if rc is None:
            comparator_absent += 1
        else:
            direction_classes.add(tuple(rc["direction"])); output_ticks += int(rc["direction"] != [0, 0, 0])
        if tick in {1, 2, 3, 4, 8, 16, 64, 256, 512, 1024}:
            samples.append({"tick": tick, "delta": current, "comparator": rc, "reader_source": read(world.raw, reader)})
    return {
        "sreg": sreg, "semantic": semantic, "phase": phase, "initial_delta": initial_delta,
        "delta_transitions": transitions, "terminal_delta": previous, "memory_destroyed": memory_destroyed,
        "comparator_absent_ticks": comparator_absent, "output_direction_ticks": output_ticks,
        "comparator_direction_classes": [list(value) for value in sorted(direction_classes)],
        "reader_raw_fixed": int(world.raw[reader]) == int(raw[reader]), "samples": samples,
        "rw_candidate": transitions >= 3 and output_ticks > 0, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    cap = [cap_case(kernel, value) for value in (0, 1, 8191, 9824, 16383, 19663, 19664, 19665, 32767, 65535)]
    coarse = [reader_case(kernel, level, semantic, phase) for semantic in (1, 4) for phase in (0, 23, 194) for level in LEVELS]
    transitions = []
    for left, right in zip(coarse, coarse[1:]):
        if (left["semantic"], left["phase"]) == (right["semantic"], right["phase"]) and (
            left["delta_transitions"], left["output_direction_ticks"], left["comparator_absent_ticks"], left["terminal_delta"]
        ) != (
            right["delta_transitions"], right["output_direction_ticks"], right["comparator_absent_ticks"], right["terminal_delta"]
        ):
            transitions.append({"left": left["sreg"], "right": right["sreg"], "semantic": left["semantic"], "phase": left["phase"]})
    candidates = [row for row in coarse if row["rw_candidate"]]
    refined = []
    for row in candidates:
        for initial_delta in (-8, 8):
            refined.append(reader_case(kernel, row["sreg"], row["semantic"], row["phase"], initial_delta))
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.high_sreg_response.v1",
        "question": "Does the full legal/high/saturation s_reg regime reversibly change read/write compatibility?",
        "legal_encoding_range": [0, 65535],
        "levels": list(LEVELS),
        "reducer_cap_calibration": cap,
        "coarse_rows": coarse,
        "response_transitions": transitions,
        "rw_candidate_count": len(candidates),
        "rw_candidates": candidates,
        "candidate_delta_refinement": refined,
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D26_HIGH_SREG_RESPONSE.json"
    write_json(output, result)
    print(json.dumps({
        "output": str(output), "coarse_rows": len(coarse), "response_transitions": transitions,
        "rw_candidates": len(candidates), "cap_outputs": [{"in": x["input_sreg_each"], "out": None if x["output"] is None else x["output"]["sreg"]} for x in cap],
        "content_sha256": result["content_sha256"],
    }, indent=2))


if __name__ == "__main__":
    main()
