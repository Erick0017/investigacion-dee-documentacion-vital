#!/usr/bin/env python3
"""Search a true DEE-native alternating reader using the validated two-site recycle law."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, transform, write_json

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
P = (1, 0, 0); S1 = (-1, 1, 0); S2 = (-1, -1, 0); N1 = (1, 0, 1); N2 = (1, 0, -1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def construct(kernel, frame, alignment, initial_delta, with_memory=True, horizon=1024):
    permutation, signs = frame
    n = 23; c = (11, 11, 11); tf = lambda v: transform(v, permutation, signs)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    if with_memory:
        put(raw, clock, a, 1000, 100 + initial_delta, semantic=1, phase=260)
        put(raw, clock, b, 2000, 100, semantic=1, phase=260)
        for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
        for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
        event = add(b, (0, -1, 0), 1, n); writer = add(event, (0, 0, 1), -3, n)
        put(raw, clock, writer, 5000, 0, (0, 0, 1), 4, 0)
    p, s1, s2, n1, n2 = (tf(v) for v in (P, S1, S2, N1, N2))
    if alignment == "q_is_comparator": q = c; qp = add(q, p, 1, n)
    else: qp = c; q = add(qp, p, -1, n)
    put(raw, clock, q, 1, 7, p, 1, 11)
    source_specs = ((add(qp, s1, -1, n), s1, 11), (add(qp, s2, -1, n), s2, 13), (add(q, n1, -2, n), n1, 17), (add(q, n2, -2, n), n2, 19))
    sources = []
    for index, (pos, direction, sreg) in enumerate(source_specs):
        put(raw, clock, pos, 7000 + index, sreg, direction, 4, 100 + index); sources.append((pos, int(raw[pos])))
    world = NativeWorld(kernel, raw, clock)
    trace = []; previous = None; transitions = 0; c_present = 0; c_absent = 0; exact_oscillator = 0; signature = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick()
        ra, rb, rc = read(world.raw, a), read(world.raw, b), read(world.raw, c)
        d = None if not with_memory or ra is None or rb is None else ra["sreg"] - rb["sreg"]
        if previous is not None and tick > 16 and d != previous: transitions += 1
        previous = d
        expected_site = qp if tick % 2 else q
        expected_direction = tuple(-value for value in p) if tick % 2 else tuple(p)
        record = read(world.raw, expected_site)
        exact_oscillator += int(record is not None and tuple(record["direction"]) == expected_direction)
        c_present += int(rc is not None); c_absent += int(rc is None)
        if tick <= 32:
            signature.update(json.dumps({"q": read(world.raw, q), "qp": read(world.raw, qp), "c": rc}, sort_keys=True, separators=(",", ":")).encode())
        if tick <= 12 or tick in {16, 32, 64, 128, 256, 512, 1024}:
            trace.append({"tick": tick, "delta": d, "q": read(world.raw, q), "qp": read(world.raw, qp), "comparator": rc})
    return {
        "frame": {"permutation": list(permutation), "signs": list(signs)}, "alignment": alignment,
        "initial_delta": initial_delta, "with_memory": with_memory, "q": list(q), "qp": list(qp), "p": list(p),
        "post16_delta_transitions": transitions, "terminal_delta": previous, "comparator_present_ticks": c_present,
        "comparator_absent_ticks": c_absent, "oscillator_exact_ticks": exact_oscillator,
        "source_raw_fixed": all(int(world.raw[pos]) == value for pos, value in sources),
        "signature_sha256": signature.hexdigest(), "trace": trace, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    all_frames = []
    for permutation in itertools.permutations((0, 1, 2)):
        for signs in itertools.product((-1, 1), repeat=3):
            all_frames.append((permutation, signs))
    # Twelve causally distinct signed/permuted orientations; additional frames would be symmetry repetition.
    frames = all_frames[::4]
    rows = []; groups = []
    for frame_index, frame in enumerate(frames):
        for alignment in ("q_is_comparator", "qp_is_comparator"):
            group_rows = []
            try:
                for delta0 in (-8, 0, 8):
                    row = construct(kernel, frame, alignment, delta0, True); rows.append(row); group_rows.append(row)
                distinct = len({row["signature_sha256"] for row in group_rows})
                groups.append({
                    "frame_index": frame_index, "frame": group_rows[0]["frame"], "alignment": alignment,
                    "valid": True, "distinct_signatures": distinct,
                    "all_temporally_release_comparator": all(row["comparator_present_ticks"] > 0 and row["comparator_absent_ticks"] > 0 for row in group_rows),
                    "all_future_writable": all(row["post16_delta_transitions"] >= 3 for row in group_rows),
                    "minimum_oscillator_exact_fraction": min(row["oscillator_exact_ticks"] / 1024 for row in group_rows),
                    "candidate": distinct >= 2 and all(row["post16_delta_transitions"] >= 3 for row in group_rows),
                })
            except RuntimeError as exc:
                groups.append({"frame_index": frame_index, "frame": {"permutation": list(frame[0]), "signs": list(frame[1])}, "alignment": alignment, "valid": False, "reason": str(exc), "candidate": False})
    candidates = [group for group in groups if group.get("candidate")]
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.true_phase_multiplexer.v1",
        "question": "Can the validated native two-site recycle law make the comparator alternate between present/read and absent/write states while preserving recurrent plasticity?",
        "construction": "ING01 two-site recycle oscillator placed with q or q+p at the relational comparator; all signed/permuted frames searched.",
        "groups": groups, "rows": rows, "candidate_count": len(candidates), "candidates": candidates,
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D27_TRUE_PHASE_MULTIPLEXER.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "groups": len(groups), "valid": sum(g["valid"] for g in groups), "candidates": len(candidates), "top": candidates[:10], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
