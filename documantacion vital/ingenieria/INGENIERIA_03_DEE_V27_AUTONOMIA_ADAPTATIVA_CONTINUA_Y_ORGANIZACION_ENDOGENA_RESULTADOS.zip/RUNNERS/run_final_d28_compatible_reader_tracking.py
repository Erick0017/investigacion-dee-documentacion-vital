#!/usr/bin/env python3
"""Mechanism selection: does the compatible reader track later recurrent writes?"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from compatible_relational_reader_v1 import construct, projection, relational_delta
from ing03_common import ROOT, load_kernel, read, seal, write_json


def classify_pair(pair):
    values = set(pair)
    if pair == (0, 0): return "ZERO"
    if -1 in values: return "NEGATIVE"
    if pair == (1, 1): return "POSITIVE"
    return "OTHER"


def sign_class(value):
    if value is None: return "DESTROYED"
    return "NEGATIVE" if value < 0 else "POSITIVE" if value > 0 else "ZERO"


def run(kernel, spec, horizon=4096):
    world, ports = construct(kernel, spec); ticks = []
    delta_changes = []; previous = relational_delta(world, ports); projections = []
    sources_fixed = True
    for tick in range(1, horizon + 1):
        world.tick(); current = relational_delta(world, ports); rc = read(world.raw, ports["c"]); x = projection(rc); projections.append(x)
        if current != previous:
            delta_changes.append({"tick": tick, "before": previous, "after": current})
        previous = current
        sources_fixed = sources_fixed and all(int(world.raw[q]) == raw0 for q, raw0 in ports["sources"])
        if tick <= 16 or tick in {32, 64, 128, 256, 512, 1024, 2048, 3072, 4096} or any(abs(tick - row["tick"]) <= 3 for row in delta_changes[-1:]):
            ticks.append({"tick": tick, "delta": current, "x": x, "comparator": rc})
    pairs = []
    for end in range(2, horizon + 1, 2):
        pair = (projections[end - 2], projections[end - 1]); delta_value = next((row["delta"] for row in reversed(ticks) if row["tick"] <= end), None)
        # ticks is sparse; the exact delta is reconstructed from ordered transitions.
        exact_delta = spec["initial_delta"]
        for change in delta_changes:
            if change["tick"] <= end: exact_delta = change["after"]
            else: break
        pairs.append({"end_tick": end, "projection_pair": list(pair), "decoded": classify_pair(pair), "delta": exact_delta, "expected": sign_class(exact_delta), "exact": classify_pair(pair) == sign_class(exact_delta)})
    stable_pairs = [row for row in pairs if row["end_tick"] >= 6]
    return {
        "spec": spec, "horizon": horizon, "delta_changes": delta_changes, "terminal_delta": previous,
        "source_raw_fixed": sources_fixed, "pair_exact_after_tick6": sum(row["exact"] for row in stable_pairs),
        "pair_total_after_tick6": len(stable_pairs), "all_pairs_exact_after_tick6": all(row["exact"] for row in stable_pairs),
        "pairs_around_sign_changes": [row for row in pairs if any(abs(row["end_tick"] - change["tick"]) <= 8 for change in delta_changes if sign_class(change["before"]) != sign_class(change["after"]))],
        "trace": ticks, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); rows = []
    # Full candidate in both writer directions and enough starting values to force sign crossings.
    for side, deltas in (("b", (-16, -8, 0, 8)), ("a", (-8, 0, 8, 16))):
        for delta0 in deltas:
            rows.append(run(kernel, {"n": 23, "origin": [11, 11, 11], "reader_mode": "full", "writer_side": side, "initial_delta": delta0}))
    # Causal ablations at a discriminating starting point, shorter but beyond three writer periods.
    controls = []
    for mode in ("no_sources", "no_seed", "missing_source_0", "missing_source_1", "missing_source_2", "missing_source_3"):
        controls.append(run(kernel, {"n": 23, "origin": [11, 11, 11], "reader_mode": mode, "writer_side": "b", "initial_delta": -8}, 1024))
    result = seal({
        "schema": "dee.v27.ing03.final.mechanism_selection.compatible_reader_tracking.v1",
        "question": "Does the new recurrent comparator remain functionally coupled to later relational writes rather than caching only the initial sign?",
        "decoder": "two-tick x-projection pair: contains -1 => NEGATIVE; (0,0)=>ZERO; (1,1)=>POSITIVE",
        "treatments": rows, "causal_ablations": controls,
        "summary": {
            "treatments_all_exact": sum(row["all_pairs_exact_after_tick6"] for row in rows), "treatments_total": len(rows),
            "sign_crossing_cases": sum(any(sign_class(change["before"]) != sign_class(change["after"]) for change in row["delta_changes"]) for row in rows),
            "source_fixed_cases": sum(row["source_raw_fixed"] for row in rows),
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_FINAL_D28_COMPATIBLE_READER_TRACKING.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "treatments": [{"side": r["spec"]["writer_side"], "d0": r["spec"]["initial_delta"], "terminal": r["terminal_delta"], "changes": len(r["delta_changes"]), "exact": [r["pair_exact_after_tick6"], r["pair_total_after_tick6"]], "all": r["all_pairs_exact_after_tick6"]} for r in rows], "controls": [{"mode": r["spec"]["reader_mode"], "exact": r["all_pairs_exact_after_tick6"], "changes": len(r["delta_changes"])} for r in controls], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
