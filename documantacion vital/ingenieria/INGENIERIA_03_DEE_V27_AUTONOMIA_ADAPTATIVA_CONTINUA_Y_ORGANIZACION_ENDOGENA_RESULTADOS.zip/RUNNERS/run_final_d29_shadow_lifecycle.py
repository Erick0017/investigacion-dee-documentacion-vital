#!/usr/bin/env python3
"""Test whether the compatible shadow can be temporary and release the comparator."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from compatible_relational_reader_v1 import construct, projection, relational_delta
from ing03_common import ROOT, load_kernel, read, seal, write_json


def run(kernel, semantic, initial_delta, horizon=4096):
    spec = {"n": 23, "origin": [11, 11, 11], "reader_mode": "full", "reader_source_semantic": semantic, "writer_side": "b", "initial_delta": initial_delta}
    world, ports = construct(kernel, spec); previous = relational_delta(world, ports); transitions = []; comparator_presence = []
    last_presence = read(world.raw, ports["c"]) is not None; runs = []; start = 0; trace = []
    for tick in range(1, horizon + 1):
        world.tick(); d = relational_delta(world, ports); rc = read(world.raw, ports["c"]); present = rc is not None
        if d != previous: transitions.append({"tick": tick, "before": previous, "after": d})
        previous = d
        if present != last_presence:
            runs.append({"start_tick": start, "end_tick": tick - 1, "present": last_presence}); start = tick; last_presence = present
        if tick <= 24 or tick in {32, 64, 128, 256, 512, 1024, 2048, 3072, 4096} or (transitions and abs(tick - transitions[-1]["tick"]) <= 2):
            trace.append({"tick": tick, "delta": d, "comparator": rc, "x": projection(rc), "sources": [read(world.raw, q) for q, _ in ports["sources"]]})
    runs.append({"start_tick": start, "end_tick": horizon, "present": last_presence})
    return {
        "spec": spec, "delta_transitions": transitions, "terminal_delta": previous,
        "comparator_presence_runs": runs, "comparator_ever_absent_after_read": any(not r["present"] and r["start_tick"] > 0 for r in runs),
        "source_survivors": sum(read(world.raw, q) is not None for q, _ in ports["sources"]),
        "trace": trace, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, semantic, delta0) for semantic in (1, 4) for delta0 in (-8, 0, 8)]
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.shadow_lifecycle.v1",
        "question": "Do finite versions of the compatible-reader support sources yield a temporary functional shadow followed by native interface release?",
        "rows": rows, "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D29_SHADOW_LIFECYCLE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "rows": [{"semantic": r["spec"]["reader_source_semantic"], "d0": r["spec"]["initial_delta"], "changes": len(r["delta_transitions"]), "terminal": r["terminal_delta"], "released": r["comparator_ever_absent_after_read"], "runs": r["comparator_presence_runs"][:8], "source_survivors": r["source_survivors"]} for r in rows], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
