#!/usr/bin/env python3
"""Search a one-shot native relay that exports the disposable shadow, not the plastic master."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from compatible_relational_reader_v1 import construct, relational_delta
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json

RELAY_DIRECTIONS = ((0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))


def add_relay(world, ports, direction, distance, state=9001, sreg=29):
    source = add(ports["c"], direction, -distance, world.n)
    if int(world.raw[source]): raise RuntimeError(f"relay overlap {source}")
    value = pack(state, sreg, direction, 1)
    world.raw_a[source] = value; world.raw_b[source] = value
    world.clock_a[source] = np.uint64(0); world.clock_b[source] = np.uint64(0)
    return source


def run(kernel, direction, distance, initial_delta, horizon=1024):
    spec = {"n": 23, "origin": [11, 11, 11], "reader_mode": "full", "writer_side": "b", "initial_delta": initial_delta}
    control, cp = construct(kernel, spec); world, ports = construct(kernel, spec)
    relay = add_relay(world, ports, direction, distance)
    digest = hashlib.sha256(); external_events = 0; first_difference = None; previous = relational_delta(world, ports); changes = 0; samples = []
    excluded = {ports["a"], ports["b"], ports["c"]} | {q for q, _ in ports["sources"]}
    for tick in range(1, horizon + 1):
        control.tick(); world.tick(); d = relational_delta(world, ports)
        if tick > 16 and d != previous: changes += 1
        previous = d
        if tick <= 64:
            diff = []
            for row in np.argwhere(world.raw != control.raw):
                q = tuple(int(x) for x in row)
                if q in excluded: continue
                tr = None if int(world.raw[q]) == 0 else unpack_scalar(world.raw[q])
                cr = None if int(control.raw[q]) == 0 else unpack_scalar(control.raw[q])
                diff.append((q, tr, cr))
            if diff and first_difference is None: first_difference = tick
            external_events += len(diff); digest.update(json.dumps(diff, sort_keys=True, separators=(",", ":")).encode())
        if tick <= 16 or tick in {32, 64, 128, 256, 512, 1024}:
            samples.append({"tick": tick, "delta": d, "control_delta": relational_delta(control, cp), "shadow": read(world.raw, ports["c"]), "relay_source": read(world.raw, relay)})
    return {
        "direction": list(direction), "distance": distance, "initial_delta": initial_delta,
        "signature_sha256": digest.hexdigest(), "external_difference_events": external_events,
        "first_external_difference": first_difference, "post16_delta_transitions": changes,
        "terminal_delta": previous, "control_terminal_delta": relational_delta(control, cp),
        "shadow_present_terminal": read(world.raw, ports["c"]) is not None,
        "samples": samples, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); groups = []; rows = []
    for direction in RELAY_DIRECTIONS:
        for distance in (3, 5, 7):
            group = []
            try:
                for delta0 in (-8, 0, 8):
                    row = run(kernel, direction, distance, delta0); rows.append(row); group.append(row)
                distinct = len({row["signature_sha256"] for row in group})
                record = {"direction": list(direction), "distance": distance, "valid": True, "distinct_signatures": distinct,
                          "all_future_writable": all(row["post16_delta_transitions"] >= 3 for row in group),
                          "all_shadow_present_terminal": all(row["shadow_present_terminal"] for row in group)}
                record["candidate"] = record["distinct_signatures"] == 3 and record["all_future_writable"]
                groups.append(record)
            except RuntimeError as exc:
                groups.append({"direction": list(direction), "distance": distance, "valid": False, "candidate": False, "reason": str(exc)})
    candidates = [group for group in groups if group["candidate"]]
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.shadow_transfer_bridge.v1",
        "question": "Can a finite relay export the disposable relational shadow while the separate master remains recurrently writable?",
        "groups": groups, "rows": rows, "candidate_count": len(candidates), "candidates": candidates,
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D30_SHADOW_TRANSFER_BRIDGE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "groups": groups, "candidates": candidates, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
