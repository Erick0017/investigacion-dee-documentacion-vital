#!/usr/bin/env python3
"""Search CORE01-E15 state-zero routing ghosts as nonoccupying relational readers."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, pack, seal, unpack_scalar, write_json
from run_ext_d17_trajectory_probe_search import AXES, build, dval


def run_pair(kernel, delta, probe, horizon=1024):
    base, pb = build(kernel, delta, None); world, ports = build(kernel, delta, probe)
    q = ports["probe"]; ghost = pack(0, int(probe["sreg"]), tuple(probe["direction"]), 1)
    world.raw_a[q] = ghost; world.raw_b[q] = ghost
    digest = hashlib.sha256(); external = []; deltas = []; controls = []
    excluded = set(ports["occupied"]); excluded.discard(q)
    for tick in range(1, horizon + 1):
        base.tick(); world.tick(); deltas.append(dval(world, ports)); controls.append(dval(base, pb))
        if tick <= 16:
            outside = []
            for row in np.argwhere(world.raw != base.raw):
                pos = tuple(int(x) for x in row)
                if pos in excluded: continue
                outside.append((pos, int(world.raw[pos]), int(base.raw[pos])))
            digest.update(json.dumps(outside, sort_keys=True, separators=(",", ":")).encode())
            if outside and len(external) < 8:
                external.append({"tick": tick, "differences": [{"q": list(pos), "treatment": None if tr == 0 else unpack_scalar(tr), "control": None if cr == 0 else unpack_scalar(cr)} for pos, tr, cr in outside[:12]]})
    trans = sum(deltas[i] != deltas[i - 1] for i in range(16, len(deltas)))
    base_trans = sum(controls[i] != controls[i - 1] for i in range(16, len(controls)))
    return {
        "delta": delta, "signature_sha256": digest.hexdigest(), "external_trace": external,
        "external_observed": bool(external), "post16_delta_transitions": trans,
        "baseline_post16_delta_transitions": base_trans, "future_writable": trans >= max(1, base_trans - 2),
        "terminal_delta": deltas[-1], "baseline_terminal_delta": controls[-1], "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); rows = []; candidates = []
    configs = [{"target": target, "direction": list(direction), "distance": distance, "sreg": 7, "phase": 0}
               for target, direction, distance in itertools.product(("a", "b", "c"), AXES, (1, 2, 3))]
    for index, config in enumerate(configs):
        try: classes = [run_pair(kernel, delta, config) for delta in (-8, 0, 8)]
        except RuntimeError: continue
        row = {
            "config_id": f"ZG{index:03d}", "probe": config, "classes": classes,
            "distinct_signatures": len({case["signature_sha256"] for case in classes}),
            "all_external": all(case["external_observed"] for case in classes),
            "all_future_writable": all(case["future_writable"] for case in classes),
        }
        row["candidate"] = row["distinct_signatures"] >= 2 and row["all_external"] and row["all_future_writable"]
        rows.append(row)
        if row["candidate"]: candidates.append(row)
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.statezero_ghost_reader.v1",
        "question": "Can a state-zero directional ghost route through the relational apparatus, externalize delta, and preserve future writing?",
        "parent_mechanism": "CORE01 E15 / ING02 integrated reader: state-zero directional raw routes without initial active-support contribution",
        "search": {"targets": ["a", "b", "c"], "directions": list(AXES), "distances": [1, 2, 3], "state": 0, "sreg": 7, "phase": 0},
        "rows": rows, "candidate_count": len(candidates), "candidates": candidates, "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D31_STATEZERO_GHOST_READER.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "valid_configs": len(rows), "candidates": len(candidates), "top": [{"id": r["config_id"], "probe": r["probe"], "signatures": r["distinct_signatures"]} for r in candidates[:20]], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
