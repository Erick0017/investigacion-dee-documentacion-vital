#!/usr/bin/env python3
"""Generate a consequence after t0, delay it natively, then release it into relational memory."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json

SUPPORT = ((-1, 0, 0), (0, 1, 0), (0, 0, 1), (-1, 1, 1))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def run(kernel, target_name, memory_phase, distance, mode="treatment", horizon=64):
    n = 23; a = (7, 11, 11); b = (16, 11, 11)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    for center, base in ((a, 1000), (b, 2000)):
        put(raw, clock, center, base, 100, semantic=1, phase=memory_phase)
        for index, offset in enumerate(SUPPORT): put(raw, clock, add(center, offset, 1, n), base + 100 + index, 0, semantic=4, phase=31 + index)
    target = a if target_name == "a" else b
    event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1); generator = add(event, route, -distance, n)
    d1 = (1, 0, 1); d2 = (-1, 0, 1)
    if mode != "missing_d1": put(raw, clock, add(generator, d1, -1, n), 5001, 3, d1, 1, 0)
    if mode != "missing_d2": put(raw, clock, add(generator, d2, -1, n), 5002, 3, d2, 1, 0)
    if mode == "wrong_cancel":
        q = add(generator, d2, -1, n); raw[q] = pack(5002, 3, (1, 0, 1), 1)
    world = NativeWorld(kernel, raw, clock); previous = 0; first_delta = None; generated = None; corridor = []; trace = []
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, a), read(world.raw, b); delta = None if ra is None or rb is None else ra["sreg"] - rb["sreg"]
        if tick == 1: generated = read(world.raw, generator)
        expected_step = tick - 1
        if 0 <= expected_step <= distance:
            pos = add(generator, route, expected_step, n); record = read(world.raw, pos)
            if record is not None: corridor.append({"tick": tick, "step": expected_step, "q": list(pos), "record": record})
        if delta not in (0, None) and first_delta is None: first_delta = tick
        if tick <= 24 or tick in {32, 48, 64}: trace.append({"tick": tick, "delta": delta, "event": read(world.raw, event), "generator": read(world.raw, generator)})
        previous = delta
    return {
        "target": target_name, "memory_phase": memory_phase, "distance": distance, "mode": mode,
        "generated_tick1": generated, "generated_route_exact": generated is not None and tuple(generated["direction"]) == route,
        "corridor": corridor, "first_nonzero_delta": first_delta, "terminal_delta": previous,
        "delayed_write": first_delta is not None and first_delta > 1,
        "trace": trace, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); treatments = []; candidates = []
    for target in ("a", "b"):
        for phase in range(240, 261):
            for distance in range(1, 7):
                try:
                    row = run(kernel, target, phase, distance); treatments.append(row)
                    if row["generated_route_exact"] and row["delayed_write"]: candidates.append(row)
                except RuntimeError:
                    pass
    # Select earliest, middle and longest successful delays for causal controls.
    selected = []
    if candidates:
        candidates_sorted = sorted(candidates, key=lambda row: (row["first_nonzero_delta"], row["target"], row["distance"]))
        for index in {0, len(candidates_sorted) // 2, len(candidates_sorted) - 1}:
            item = candidates_sorted[index]
            selected.append(item)
    controls = []
    for item in selected:
        for mode in ("missing_d1", "missing_d2", "wrong_cancel"):
            controls.append(run(kernel, item["target"], item["memory_phase"], item["distance"], mode))
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.native_consequence_buffer.v1",
        "question": "Can two environmental proposals generate a consequence after t0, preserve it in a native delay path, and release it later as a relational write?",
        "mechanism": "two proposals collide at tick1 into a +z consequence carrier; the carrier/path plus phase-sensitive memory delays the write",
        "treatments": treatments, "candidate_count": len(candidates), "candidates": candidates,
        "selected_for_controls": selected, "causal_controls": controls, "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D32_NATIVE_CONSEQUENCE_BUFFER.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "treatments": len(treatments), "candidates": len(candidates), "delay_range": None if not candidates else [min(r["first_nonzero_delta"] for r in candidates), max(r["first_nonzero_delta"] for r in candidates)], "selected": [{k: r[k] for k in ("target", "memory_phase", "distance", "first_nonzero_delta", "terminal_delta")} for r in selected], "controls": [{k: r[k] for k in ("target", "memory_phase", "distance", "mode", "first_nonzero_delta", "terminal_delta")} for r in controls], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
