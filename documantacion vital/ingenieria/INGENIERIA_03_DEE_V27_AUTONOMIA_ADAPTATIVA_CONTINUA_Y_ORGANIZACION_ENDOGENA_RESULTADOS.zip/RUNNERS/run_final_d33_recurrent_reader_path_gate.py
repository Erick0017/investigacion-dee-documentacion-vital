#!/usr/bin/env python3
"""Place the ING01 recycle oscillator on the maintained reader path as a native gate."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, transform, write_json

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0)); PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
P = (1, 0, 0); S1 = (-1, 1, 0); S2 = (-1, -1, 0); N1 = (1, 0, 1); N2 = (1, 0, -1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def run(kernel, frame, alignment, initial_delta, horizon=1024):
    permutation, signs = frame; tf = lambda v: transform(v, permutation, signs)
    n = 23; c = (11, 11, 11); a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100 + initial_delta, semantic=1, phase=260); put(raw, clock, b, 2000, 100, semantic=1, phase=260)
    for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    event = add(b, (0, -1, 0), 1, n); writer = add(event, (0, 0, 1), -3, n); put(raw, clock, writer, 5000, 0, (0, 0, 1), 4, 0)
    reader_source = add(c, (0, -2, 0), 1, n); mid = add(c, (0, -1, 0), 1, n)
    put(raw, clock, reader_source, 6000, 7, (0, 1, 0), 4, 23)
    p, s1, s2, n1, n2 = (tf(v) for v in (P, S1, S2, N1, N2))
    if alignment == "q_is_mid": q = mid; qp = add(q, p, 1, n)
    else: qp = mid; q = add(qp, p, -1, n)
    put(raw, clock, q, 1, 7, p, 1, 11)
    sources = []
    for index, (pos, direction, sreg) in enumerate(((add(qp, s1, -1, n), s1, 11), (add(qp, s2, -1, n), s2, 13), (add(q, n1, -2, n), n1, 17), (add(q, n2, -2, n), n2, 19))):
        put(raw, clock, pos, 7000 + index, sreg, direction, 4, 100 + index); sources.append((pos, int(raw[pos])))
    world = NativeWorld(kernel, raw, clock); digest = hashlib.sha256(); previous = None; changes = 0; present = 0; absent = 0; reader_mid_presence = 0; trace = []
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb, rc = read(world.raw, a), read(world.raw, b), read(world.raw, c); d = None if ra is None or rb is None else ra["sreg"] - rb["sreg"]
        if previous is not None and tick > 16 and d != previous: changes += 1
        previous = d; present += int(rc is not None); absent += int(rc is None); reader_mid_presence += int(read(world.raw, mid) is not None)
        if tick <= 32: digest.update(json.dumps({"c": rc, "mid": read(world.raw, mid)}, sort_keys=True, separators=(",", ":")).encode())
        if tick <= 16 or tick in {32, 64, 128, 256, 512, 1024}: trace.append({"tick": tick, "delta": d, "comparator": rc, "mid": read(world.raw, mid), "q": read(world.raw, q), "qp": read(world.raw, qp)})
    return {"frame": {"permutation": list(permutation), "signs": list(signs)}, "alignment": alignment, "initial_delta": initial_delta,
            "signature_sha256": digest.hexdigest(), "post16_delta_transitions": changes, "terminal_delta": previous,
            "comparator_present_ticks": present, "comparator_absent_ticks": absent, "mid_present_ticks": reader_mid_presence,
            "sources_fixed": all(int(world.raw[pos]) == raw0 for pos, raw0 in sources), "trace": trace, "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1); all_frames = [(p, s) for p in itertools.permutations((0, 1, 2)) for s in itertools.product((-1, 1), repeat=3)]; frames = all_frames[::4]
    groups = []; rows = []
    for index, frame in enumerate(frames):
        for alignment in ("q_is_mid", "qp_is_mid"):
            try:
                cases = [run(kernel, frame, alignment, delta0) for delta0 in (-8, 0, 8)]; rows.extend(cases)
                group = {"frame_index": index, "frame": cases[0]["frame"], "alignment": alignment, "valid": True,
                         "distinct_signatures": len({case["signature_sha256"] for case in cases}),
                         "all_future_writable": all(case["post16_delta_transitions"] >= 3 for case in cases),
                         "all_dynamic_comparator": all(case["comparator_present_ticks"] > 0 and case["comparator_absent_ticks"] > 0 for case in cases)}
                group["candidate"] = group["distinct_signatures"] >= 2 and group["all_future_writable"]
                groups.append(group)
            except RuntimeError as exc:
                groups.append({"frame_index": index, "frame": {"permutation": list(frame[0]), "signs": list(frame[1])}, "alignment": alignment, "valid": False, "candidate": False, "reason": str(exc)})
    candidates = [group for group in groups if group["candidate"]]
    result = seal({"schema": "dee.v27.ing03.final.discovery.recurrent_reader_path_gate.v1", "question": "Can a native two-site recycle oscillator periodically gate the maintained reader path so that the comparator is informative while the relation remains writable?", "groups": groups, "rows": rows, "candidate_count": len(candidates), "candidates": candidates, "runtime": runtime})
    output = ROOT / "DISCOVERY/ING03_FINAL_D33_RECURRENT_READER_PATH_GATE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "groups": len(groups), "valid": sum(g["valid"] for g in groups), "candidates": candidates, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
