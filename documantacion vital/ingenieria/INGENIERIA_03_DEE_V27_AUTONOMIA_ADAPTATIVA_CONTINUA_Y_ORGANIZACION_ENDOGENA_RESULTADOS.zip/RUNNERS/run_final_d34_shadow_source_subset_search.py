#!/usr/bin/env python3
"""Search subsets of the new shadow scaffold for continuous coupling to changing delta."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from compatible_relational_reader_v1 import construct, projection, relational_delta
from ing03_common import ROOT, load_kernel, read, seal, write_json


def sign(value):
    return "NEGATIVE" if value < 0 else "POSITIVE" if value > 0 else "ZERO"


def run(kernel, indices, horizon=2048):
    spec = {"n": 23, "origin": [11, 11, 11], "initial_delta": -8, "writer_side": "b", "reader_mode": "full", "reader_source_indices": list(indices)}
    world, ports = construct(kernel, spec); samples = []; transitions = []; previous = relational_delta(world, ports); last_class_change = 0
    pair_sets = {"NEGATIVE": set(), "ZERO": set(), "POSITIVE": set()}; previous_x = None; sources_fixed = True; trace = []
    for tick in range(1, horizon + 1):
        world.tick(); d = relational_delta(world, ports); x = projection(read(world.raw, ports["c"])); samples.append((tick, d, x))
        if d != previous: transitions.append({"tick": tick, "before": previous, "after": d})
        if sign(d) != sign(previous): last_class_change = tick
        previous = d
        sources_fixed = sources_fixed and all(int(world.raw[q]) == raw0 for q, raw0 in ports["sources"])
        if tick % 2 == 0 and tick >= 10 and tick - last_class_change >= 8:
            pair_sets[sign(d)].add((previous_x, x))
        previous_x = x
        if tick <= 12 or tick in {256, 512, 1024, 1300, 1302, 1560, 1562, 1792, 2048}:
            trace.append({"tick": tick, "delta": d, "x": x, "comparator": read(world.raw, ports["c"])})
    nonempty = all(pair_sets[key] for key in pair_sets)
    disjoint = all(pair_sets[a].isdisjoint(pair_sets[b]) for a, b in itertools.combinations(pair_sets, 2)) if nonempty else False
    return {
        "source_indices": list(indices), "source_count": len(indices), "delta_transitions": transitions,
        "terminal_delta": previous, "source_raw_fixed": sources_fixed,
        "pair_sets": {key: [list(pair) for pair in sorted(values, key=str)] for key, values in pair_sets.items()},
        "all_three_classes_observed": nonempty, "class_pair_sets_disjoint": disjoint,
        "candidate": nonempty and disjoint and len(transitions) >= 8,
        "trace": trace, "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); rows = []
    for mask in range(16):
        indices = tuple(index for index in range(4) if mask & (1 << index))
        try: rows.append(run(kernel, indices))
        except RuntimeError as exc: rows.append({"source_indices": list(indices), "valid": False, "candidate": False, "reason": str(exc)})
    candidates = [row for row in rows if row.get("candidate")]
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.shadow_source_subset_search.v1",
        "question": "Can a causal subset of the shadow scaffold remain coupled as delta traverses negative, zero and positive regimes?",
        "rows": rows, "candidate_count": len(candidates), "candidates": candidates, "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D34_SHADOW_SOURCE_SUBSET_SEARCH.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "rows": [{"sources": r.get("source_indices"), "changes": len(r.get("delta_transitions", [])), "terminal": r.get("terminal_delta"), "sets": r.get("pair_sets"), "candidate": r.get("candidate")} for r in rows], "candidates": len(candidates), "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
