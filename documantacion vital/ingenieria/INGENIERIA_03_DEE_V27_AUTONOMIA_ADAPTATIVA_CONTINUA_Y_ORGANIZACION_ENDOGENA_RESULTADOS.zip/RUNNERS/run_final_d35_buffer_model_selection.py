#!/usr/bin/env python3
"""Model selection for the D32 native consequence buffer across frames and sizes."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from native_consequence_buffer_v1 import run_case


def main():
    kernel, runtime = load_kernel(1)
    frames = [
        ((0, 1, 2), (1, 1, 1)),
        ((1, 2, 0), (-1, 1, 1)),
        ((2, 0, 1), (1, -1, 1)),
        ((0, 2, 1), (-1, -1, 1)),
        ((2, 1, 0), (1, 1, -1)),
        ((1, 0, 2), (-1, 1, -1)),
    ]
    families = [(255, 3, 6), (252, 6, 9)]
    sizes = [23, 29, 31]
    rows = []
    group_id = 0
    for n, (permutation, signs), (phase, distance, expected_tick), target in itertools.product(sizes, frames, families, ("a", "b")):
        group_id += 1
        origin = ((5 + 3 * group_id) % n, (7 + 5 * group_id) % n, (11 + 7 * group_id) % n)
        for mode in ("treatment", "missing_d1", "missing_d2", "wrong_cancel"):
            try:
                row = run_case(
                    kernel,
                    n=n,
                    origin=origin,
                    target_name=target,
                    memory_phase=phase,
                    distance=distance,
                    permutation=permutation,
                    signs=signs,
                    mode=mode,
                    horizon=24,
                )
                row["group_id"] = group_id
                row["expected_write_tick"] = expected_tick
                row["valid_geometry"] = True
            except RuntimeError as exc:
                row = {"group_id": group_id, "mode": mode, "valid_geometry": False, "error": str(exc)}
            rows.append(row)

    valid_groups = []
    for group_id in sorted({row["group_id"] for row in rows}):
        group = [row for row in rows if row["group_id"] == group_id]
        if len(group) != 4 or not all(row.get("valid_geometry") for row in group):
            continue
        treatment = next(row for row in group if row["mode"] == "treatment")
        controls = [row for row in group if row["mode"] != "treatment"]
        passed = (
            treatment["generated_route_exact"]
            and treatment["first_nonzero_delta"] == treatment["expected_write_tick"]
            and treatment["sign_correct"]
            and all(row["first_nonzero_delta"] is None and row["terminal_delta"] == 0 for row in controls)
        )
        valid_groups.append({"group_id": group_id, "passed": passed, "treatment": treatment, "controls": controls})

    result = seal({
        "schema": "dee.v27.ing03.final.mechanism_selection.native_consequence_buffer.v1",
        "question": "Does the generated-consequence delay/write mechanism retain its exact causal timing, sign, and prerequisites across transformed frames, positions, and N?",
        "frozen_candidate_families": [
            {"memory_phase": phase, "distance": distance, "expected_write_tick": tick}
            for phase, distance, tick in families
        ],
        "dimensions": {"N": sizes, "frames": [{"permutation": list(p), "signs": list(s)} for p, s in frames], "targets": ["a", "b"]},
        "rows": rows,
        "valid_groups": valid_groups,
        "summary": {
            "attempted_groups": group_id,
            "valid_groups": len(valid_groups),
            "passed_groups": sum(item["passed"] for item in valid_groups),
            "all_valid_passed": bool(valid_groups) and all(item["passed"] for item in valid_groups),
        },
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_FINAL_D35_NATIVE_BUFFER_MODEL_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
