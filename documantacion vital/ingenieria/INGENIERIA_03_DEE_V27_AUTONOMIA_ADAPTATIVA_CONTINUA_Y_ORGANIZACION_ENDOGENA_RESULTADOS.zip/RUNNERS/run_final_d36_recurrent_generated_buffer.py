#!/usr/bin/env python3
"""Test whether persistent proposal sources make the native consequence buffer reusable."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, transform, write_json
from native_consequence_buffer_v1 import build_world


def rle(values):
    output = []
    for tick, value in enumerate(values, 1):
        if output and output[-1][2] == value:
            output[-1][1] = tick
        else:
            output.append([tick, tick, value])
    return output


def run(kernel, *, target_name, semantic, mode="treatment", horizon=4096):
    permutation, signs = (0, 1, 2), (1, 1, 1)
    world, metadata = build_world(
        kernel, n=29, origin=(8, 13, 11), target_name=target_name,
        memory_phase=255, distance=3, permutation=permutation, signs=signs, mode=mode,
    )
    generator = tuple(metadata["generator"])
    d1, d2 = transform((1, 0, 1), permutation, signs), transform((-1, 0, 1), permutation, signs)
    source_positions = [add(generator, d1, -1, 29), add(generator, d2, -1, 29)]
    source_specs = [(5001, 3, d1), (5002, 3, d2)]
    for index, (q, (state, sreg, direction)) in enumerate(zip(source_positions, source_specs)):
        if (mode == "missing_d1" and index == 0) or (mode == "missing_d2" and index == 1):
            continue
        actual_direction = d1 if mode == "wrong_cancel" and index == 1 else direction
        value = pack(state, sreg, actual_direction, semantic)
        world.raw_a[q] = value
        world.raw_b[q] = value
    initial_sources = [int(world.raw[q]) for q in source_positions]
    a, b = tuple(metadata["a"]), tuple(metadata["b"])
    deltas, generator_records = [], []
    for tick in range(1, horizon + 1):
        world.tick()
        ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        deltas.append(delta)
        if tick <= 32 or tick in {64, 128, 256, 512, 1024, 2048, 4096}:
            generator_records.append({"tick": tick, "record": read(world.raw, generator), "delta": delta})
    delta_rle = rle(deltas)
    return {
        **metadata,
        "proposal_semantic": semantic,
        "mode": mode,
        "horizon": horizon,
        "delta_rle": delta_rle,
        "delta_transitions": max(0, len(delta_rle) - 1),
        "distinct_delta_values": sorted({value for value in deltas if value is not None}),
        "terminal_delta": deltas[-1],
        "source_raw_fixed": [int(world.raw[q]) for q in source_positions] == initial_sources,
        "generator_trace": generator_records,
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    rows = []
    for semantic in (1, 4):
        for target in ("a", "b"):
            for mode in ("treatment", "missing_d1", "missing_d2", "wrong_cancel"):
                rows.append(run(kernel, target_name=target, semantic=semantic, mode=mode))
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.recurrent_generated_buffer.v1",
        "question": "Do persistent semantic4 proposal sources turn the frozen one-shot generated-consequence buffer into a reusable consequence generator/write path?",
        "rows": rows,
        "summary": {
            "semantic4_treatments": [
                {k: row[k] for k in ("target_name", "delta_transitions", "distinct_delta_values", "terminal_delta", "source_raw_fixed")}
                for row in rows if row["proposal_semantic"] == 4 and row["mode"] == "treatment"
            ],
            "semantic1_treatments": [
                {k: row[k] for k in ("target_name", "delta_transitions", "distinct_delta_values", "terminal_delta", "source_raw_fixed")}
                for row in rows if row["proposal_semantic"] == 1 and row["mode"] == "treatment"
            ],
        },
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D36_RECURRENT_GENERATED_BUFFER.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
