#!/usr/bin/env python3
"""Cross-frame model selection for the persistent generated-consequence writer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from persistent_generated_buffer_v1 import run_case


def main():
    kernel, runtime = load_kernel(1)
    frames = [
        ((0, 1, 2), (1, 1, 1)), ((1, 2, 0), (-1, 1, 1)),
        ((2, 0, 1), (1, -1, 1)), ((0, 2, 1), (-1, -1, 1)),
        ((2, 1, 0), (1, 1, -1)), ((1, 0, 2), (-1, 1, -1)),
    ]
    groups = []
    group_id = 0
    for frame_index, (permutation, signs) in enumerate(frames):
        for target in ("a", "b"):
            group_id += 1
            n = 29 if frame_index % 2 == 0 else 31
            origin = ((7 + 3 * group_id) % n, (9 + 5 * group_id) % n, (13 + 7 * group_id) % n)
            rows = []
            for mode in ("treatment", "missing_d1", "missing_d2", "wrong_cancel"):
                rows.append(run_case(
                    kernel, n=n, origin=origin, target_name=target, memory_phase=255, distance=3,
                    permutation=permutation, signs=signs, mode=mode, horizon=1024,
                ))
            treatment = next(row for row in rows if row["mode"] == "treatment")
            controls = [row for row in rows if row["mode"] != "treatment"]
            passed = (
                treatment["source_raw_fixed"] and treatment["net_sign_correct"]
                and treatment["delta_transitions"] >= 4 and len(treatment["distinct_delta_values"]) >= 4
                and all(row["delta_transitions"] == 0 and row["terminal_delta"] == 0 for row in controls)
            )
            groups.append({"group_id": group_id, "passed": passed, "treatment": treatment, "controls": controls})
    result = seal({
        "schema": "dee.v27.ing03.final.mechanism_selection.persistent_generated_buffer.v1",
        "question": "Does the persistent two-source generator produce repeated, prerequisite-dependent relational writes across transformed frames and N?",
        "groups": groups,
        "summary": {"groups": len(groups), "worlds": 4 * len(groups), "passed_groups": sum(g["passed"] for g in groups), "all_passed": all(g["passed"] for g in groups)},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_FINAL_D37_PERSISTENT_BUFFER_MODEL_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
