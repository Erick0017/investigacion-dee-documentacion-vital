#!/usr/bin/env python3
"""Integrate the generated-consequence buffer with the native relational reader topology."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from read_write_extension_apparatus_v1 import PA, PB


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def run(kernel, *, target_name, phase, distance, mode="treatment", horizon=64):
    n = 29; c = (14, 14, 14); a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100, semantic=1, phase=phase)
    put(raw, clock, b, 2000, 100, semantic=1, phase=phase)
    for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    target = a if target_name == "a" else b
    event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1); generator = add(event, route, -distance, n)
    d1, d2 = (1, 0, 1), (-1, 0, 1)
    if mode != "missing_d1": put(raw, clock, add(generator, d1, -1, n), 5001, 3, d1, 1, 0)
    if mode != "missing_d2": put(raw, clock, add(generator, d2, -1, n), 5002, 3, d2, 1, 0)
    if mode == "wrong_cancel":
        q = add(generator, d2, -1, n); raw[q] = pack(5002, 3, d1, 1)
    world = NativeWorld(kernel, raw, clock)
    deltas, first = [], None
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        deltas.append(delta)
        if delta not in (0, None) and first is None: first = tick
    return {"target_name": target_name, "phase": phase, "distance": distance, "mode": mode, "first_nonzero_delta": first, "terminal_delta": deltas[-1], "delta_trace": deltas, "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1); rows = []; candidates = []
    for target in ("a", "b"):
        for phase in range(240, 261):
            for distance in range(1, 7):
                try:
                    row = run(kernel, target_name=target, phase=phase, distance=distance)
                    rows.append(row)
                    if row["first_nonzero_delta"] is not None and row["first_nonzero_delta"] > 1: candidates.append(row)
                except RuntimeError:
                    pass
    selected = []
    for target in ("a", "b"):
        subset = [row for row in candidates if row["target_name"] == target]
        if subset:
            selected.append(sorted(subset, key=lambda row: (row["first_nonzero_delta"], row["distance"]))[-1])
    controls = []
    for row in selected:
        for mode in ("missing_d1", "missing_d2", "wrong_cancel"):
            controls.append(run(kernel, target_name=row["target_name"], phase=row["phase"], distance=row["distance"], mode=mode))
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.relational_buffer_integration.v1",
        "question": "Can the generated-consequence buffer write the compact master topology used by the answer-independent relational reader?",
        "rows": rows, "candidates": candidates, "selected": selected, "controls": controls,
        "summary": {"valid_worlds": len(rows), "candidates": len(candidates), "selected": selected, "controls_clean": all(row["first_nonzero_delta"] is None for row in controls)},
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D38_RELATIONAL_BUFFER_INTEGRATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
