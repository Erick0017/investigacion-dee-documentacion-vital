#!/usr/bin/env python3
"""One-cycle native schedule: generated consequence, delayed master write, then delayed query."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from relative_magnitude_reader_v1 import PA, PB


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def run(kernel, *, target_name, memory_phase, consequence_distance, query_distance, consequence=True, query=True, horizon=72):
    n = 61; c = (30, 30, 30); a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100, semantic=1, phase=memory_phase); put(raw, clock, b, 2000, 100, semantic=1, phase=memory_phase)
    for i, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + i, 0, semantic=4, phase=31 + i)
    for i, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + i, 0, semantic=4, phase=41 + i)
    target = a if target_name == "a" else b
    event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1); generator = add(event, route, -consequence_distance, n)
    d1, d2 = (1, 0, 1), (-1, 0, 1)
    if consequence:
        put(raw, clock, add(generator, d1, -1, n), 5001, 3, d1, 1, 0)
        put(raw, clock, add(generator, d2, -1, n), 5002, 3, d2, 1, 0)
    query_start = add(c, (0, 1, 0), -query_distance, n)
    if query:
        put(raw, clock, query_start, 6000, 7, (0, 1, 0), 1, 23)
    world = NativeWorld(kernel, raw, clock); delta_trace = []; c_trace = []
    digest = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb, rc = read(world.raw, a), read(world.raw, b), read(world.raw, c)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        delta_trace.append(delta)
        record = None if rc is None else [rc["state"], rc["sreg"], rc["direction"], rc["semantic"]]
        c_trace.append({"tick": tick, "record": record, "delta": delta})
        digest.update(json.dumps(record, sort_keys=True, separators=(",", ":")).encode())
    first_write = next((i + 1 for i, value in enumerate(delta_trace) if value not in (0, None)), None)
    c_events = [item for item in c_trace if item["record"] is not None]
    return {
        "target_name": target_name, "memory_phase": memory_phase, "consequence_distance": consequence_distance,
        "query_distance": query_distance, "consequence": consequence, "query": query,
        "first_write": first_write, "terminal_delta": delta_trace[-1],
        "comparator_signature": digest.hexdigest(), "comparator_events": c_events,
        "first_comparator_event": None if not c_events else c_events[0]["tick"],
        "write_precedes_read": first_write is not None and bool(c_events) and first_write < c_events[0]["tick"],
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1); rows = []
    configs = [("a", 252, 6, range(12, 19)), ("b", 240, 6, range(24, 31))]
    for target, phase, distance, query_distances in configs:
        for qdistance in query_distances:
            for consequence, query in ((True, True), (False, True), (True, False)):
                try: rows.append(run(kernel, target_name=target, memory_phase=phase, consequence_distance=distance, query_distance=qdistance, consequence=consequence, query=query))
                except RuntimeError: pass
    candidates = []
    for target, _, _, _ in configs:
        for qdistance in sorted({row["query_distance"] for row in rows if row["target_name"] == target}):
            group = [row for row in rows if row["target_name"] == target and row["query_distance"] == qdistance]
            if len(group) != 3: continue
            treatment = next(row for row in group if row["consequence"] and row["query"])
            no_consequence = next(row for row in group if not row["consequence"] and row["query"])
            no_query = next(row for row in group if row["consequence"] and not row["query"])
            if treatment["write_precedes_read"] and treatment["comparator_signature"] != no_consequence["comparator_signature"] and not no_query["comparator_events"]:
                candidates.append({"target_name": target, "query_distance": qdistance, "treatment": treatment, "no_consequence": no_consequence, "no_query": no_query})
    result = seal({
        "schema": "dee.v27.ing03.final.discovery.buffered_offline_readout.v1",
        "question": "Can a t0-complete DEE schedule generate a consequence, buffer it until a later master write, and only afterward activate an answer-independent relational query?",
        "rows": rows, "candidates": candidates,
        "summary": {"worlds": len(rows), "candidates": len(candidates), "candidate_coordinates": [{"target": c["target_name"], "query_distance": c["query_distance"], "write_tick": c["treatment"]["first_write"], "read_tick": c["treatment"]["first_comparator_event"]} for c in candidates]},
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_FINAL_D39_BUFFERED_OFFLINE_READOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
