#!/usr/bin/env python3
"""Model selection for the one-cycle native buffered offline readout."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from buffered_offline_readout_v1 import run_case
from ing03_common import ROOT, load_kernel, seal, write_json


def main():
    kernel, runtime = load_kernel(1)
    frames = [
        ((0, 1, 2), (1, 1, 1)), ((1, 2, 0), (-1, 1, 1)), ((2, 0, 1), (1, -1, 1)),
        ((0, 2, 1), (-1, -1, 1)), ((2, 1, 0), (1, 1, -1)), ((1, 0, 2), (-1, 1, -1)),
    ]
    groups = []
    for index, (permutation, signs) in enumerate(frames, 1):
        for target in ("a", "b"):
            n = 47 if index % 2 else 53; origin = ((9 + index * 3) % n, (13 + index * 5) % n, (17 + index * 7) % n)
            rows = [run_case(kernel, n=n, origin=origin, target_name=target, permutation=permutation, signs=signs, mode=mode) for mode in ("treatment", "no_consequence", "missing_d1", "no_query")]
            treatment = rows[0]; no_consequence, missing_d1, no_query = rows[1:]
            passed = (
                treatment["first_write"] == treatment["expected_write_tick"]
                and treatment["first_comparator_event"] == treatment["query_distance"]
                and treatment["second_comparator_direction"] == treatment["expected_second_direction"]
                and no_consequence["first_write"] is None and no_consequence["second_comparator_direction"] == [0, 0, 0]
                and missing_d1["first_write"] is None and missing_d1["second_comparator_direction"] == [0, 0, 0]
                and no_query["first_write"] == no_query["expected_write_tick"] and not no_query["comparator_events"]
            )
            groups.append({"passed": passed, "treatment": treatment, "no_consequence": no_consequence, "missing_d1": missing_d1, "no_query": no_query})
    result = seal({
        "schema": "dee.v27.ing03.final.mechanism_selection.buffered_offline_readout.v1",
        "question": "Does a complete t0 organization write from a generated consequence and later expose the new relation through a delayed native query across transformed worlds?",
        "groups": groups,
        "summary": {"groups": len(groups), "worlds": 4 * len(groups), "passed_groups": sum(g["passed"] for g in groups), "all_passed": all(g["passed"] for g in groups)},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_FINAL_D40_OFFLINE_READOUT_MODEL_SELECTION.json"; write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
