#!/usr/bin/env python3
"""Find early native phases for a persistent generated writer in the compact reader topology."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json
from relative_magnitude_reader_v1 import PA,PB

def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)

def run(kernel,target_name,source_phase,mode="treatment",horizon=64):
    n=29;c=(14,14,14);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    target=a if target_name=="a" else b;event=add(target,(0,-1,0),1,n);route=(0,0,1);generator=add(event,route,-3,n);d1=(1,0,1);d2=(-1,0,1);sources=[]
    if mode!="missing_d1":q=add(generator,d1,-1,n);put(raw,clock,q,5001,3,d1,4,source_phase);sources.append(q)
    if mode!="missing_d2":q=add(generator,d2,-1,n);put(raw,clock,q,5002,3,d2,4,source_phase);sources.append(q)
    if mode=="wrong_cancel":q=add(generator,d2,-1,n);raw[q]=pack(5002,3,d1,4)
    initial=[int(raw[q]) for q in sources];world=NativeWorld(kernel,raw,clock);deltas=[]
    for _ in range(horizon):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);deltas.append(None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"]))
    first=next((i+1 for i,v in enumerate(deltas) if v not in (0,None)),None)
    return {"target_name":target_name,"source_phase":source_phase,"mode":mode,"first_write":first,"terminal_delta":deltas[-1],"delta_trace":deltas,"sources_fixed":[int(world.raw[q]) for q in sources]==initial,"python_interventions_after_t0":0}

def main():
    kernel,runtime=load_kernel(1);rows=[]
    for target in ("a","b"):
        for phase in range(195):rows.append(run(kernel,target,phase))
    candidates=[r for r in rows if r["first_write"] is not None and r["first_write"]<=32 and r["sources_fixed"]]
    selected=[];controls=[]
    for target in ("a","b"):
        subset=sorted((r for r in candidates if r["target_name"]==target),key=lambda r:(r["first_write"],r["source_phase"]))
        if subset:
            chosen=subset[0];selected.append(chosen)
            for mode in ("missing_d1","missing_d2","wrong_cancel"):controls.append(run(kernel,target,chosen["source_phase"],mode))
    result=seal({"schema":"dee.v27.ing03.final.discovery.persistent_compact_phase_search.v1","question":"Which semantic4 source phases create an early persistent generated write inside the exact compact reader topology?","rows":rows,"candidates":candidates,"selected":selected,"controls":controls,"summary":{"worlds":len(rows),"early_candidates":len(candidates),"selected":[{k:r[k] for k in ("target_name","source_phase","first_write","terminal_delta")} for r in selected],"controls_clean":all(r["first_write"] is None for r in controls)},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D41_PERSISTENT_COMPACT_PHASE_SEARCH.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
