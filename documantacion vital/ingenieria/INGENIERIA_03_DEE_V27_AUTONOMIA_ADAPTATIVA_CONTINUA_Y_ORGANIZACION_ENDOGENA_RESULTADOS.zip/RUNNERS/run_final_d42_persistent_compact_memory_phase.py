#!/usr/bin/env python3
"""Test whether compact-master clock phase can create an early persistent generated write."""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json
from relative_magnitude_reader_v1 import PA,PB
def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)
def run(kernel,target_name,memory_phase,horizon=64):
    n=29;c=(14,14,14);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=memory_phase);put(raw,clock,b,2000,100,semantic=1,phase=memory_phase)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    target=a if target_name=="a" else b;event=add(target,(0,-1,0),1,n);generator=add(event,(0,0,1),-3,n);d1=(1,0,1);d2=(-1,0,1);sources=[]
    for q,state,direction in ((add(generator,d1,-1,n),5001,d1),(add(generator,d2,-1,n),5002,d2)):
        put(raw,clock,q,state,3,direction,4,0);sources.append(q)
    initial=[int(raw[q]) for q in sources];world=NativeWorld(kernel,raw,clock);deltas=[]
    for _ in range(horizon):
        world.tick();ra,rb=read(world.raw,a),read(world.raw,b);deltas.append(None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"]))
    first=next((i+1 for i,v in enumerate(deltas) if v not in (0,None)),None)
    return {"target_name":target_name,"memory_phase":memory_phase,"first_write":first,"terminal_delta":deltas[-1],"sources_fixed":[int(world.raw[q]) for q in sources]==initial,"python_interventions_after_t0":0}
def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,t,p) for t in ("a","b") for p in range(261)];candidates=[r for r in rows if r["first_write"] is not None]
    result=seal({"schema":"dee.v27.ing03.final.discovery.persistent_compact_memory_phase.v1","question":"Can compact-master phase shift the persistent generated writer into an early read-compatible window?","rows":rows,"candidates":candidates,"summary":{"worlds":len(rows),"candidates":len(candidates),"earliest":None if not candidates else min(r["first_write"] for r in candidates)},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D42_PERSISTENT_COMPACT_MEMORY_PHASE.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
