#!/usr/bin/env python3
"""Critical test: does a delayed native query preserve later persistent generated writes?"""
from __future__ import annotations
import json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json
from relative_magnitude_reader_v1 import PA,PB
def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)
def rle(values):
    out=[]
    for tick,value in enumerate(values,1):
        if out and out[-1][2]==value:out[-1][1]=tick
        else:out.append([tick,tick,value])
    return out
def run(kernel,target_name,mode,horizon=1024):
    n=29;c=(14,14,14);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=257);put(raw,clock,b,2000,100,semantic=1,phase=257)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    target=a if target_name=="a" else b;event=add(target,(0,-1,0),1,n);generator=add(event,(0,0,1),-3,n);d1=(1,0,1);d2=(-1,0,1);sources=[]
    if mode!="query_missing_d1":q=add(generator,d1,-1,n);put(raw,clock,q,5001,3,d1,4,0);sources.append(q)
    q=add(generator,d2,-1,n);put(raw,clock,q,5002,3,d2,4,0);sources.append(q)
    if mode!="no_query":put(raw,clock,add(c,(0,1,0),-12,n),6000,7,(0,1,0),1,23)
    initial=[int(raw[q]) for q in sources];world=NativeWorld(kernel,raw,clock);deltas=[];events=[]
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"]);deltas.append(delta)
        if rc is not None and tick<=40:events.append({"tick":tick,"delta":delta,"record":rc})
    runs=rle(deltas);post16=[value for value in deltas[16:] if value is not None]
    return {"target_name":target_name,"mode":mode,"horizon":horizon,"delta_rle":runs,"all_transitions":max(0,len(runs)-1),"post16_transitions":sum(post16[i]!=post16[i-1] for i in range(1,len(post16))),"distinct_post16":sorted(set(post16)),"terminal_delta":deltas[-1],"comparator_events":events,"sources_fixed":[int(world.raw[q]) for q in sources]==initial,"python_interventions_after_t0":0}
def main():
    kernel,runtime=load_kernel(1);rows=[run(kernel,t,m) for t in ("a","b") for m in ("no_query","query","query_missing_d1")]
    comparisons=[]
    for target in ("a","b"):
        no_query=next(r for r in rows if r["target_name"]==target and r["mode"]=="no_query");query=next(r for r in rows if r["target_name"]==target and r["mode"]=="query");canary=next(r for r in rows if r["target_name"]==target and r["mode"]=="query_missing_d1")
        comparisons.append({"target_name":target,"no_query_post16_transitions":no_query["post16_transitions"],"query_post16_transitions":query["post16_transitions"],"canary_post16_transitions":canary["post16_transitions"],"query_exposes_delta":any(e["tick"]>=12 and e["delta"] not in (0,None) for e in query["comparator_events"]),"query_blocks_later_writes":no_query["post16_transitions"]>0 and query["post16_transitions"]==0})
    result=seal({"schema":"dee.v27.ing03.final.discovery.recurrent_write_after_delayed_read.v1","question":"After a persistent generated writer changes the compact master before tick 12, does a one-shot native query expose it while preserving subsequent recurrent writes?","rows":rows,"comparisons":comparisons,"summary":{"worlds":len(rows),"all_queries_expose":all(c["query_exposes_delta"] for c in comparisons),"all_queries_block_later_writes":all(c["query_blocks_later_writes"] for c in comparisons)},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D43_RECURRENT_WRITE_AFTER_DELAYED_READ.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"comparisons":comparisons,"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
