#!/usr/bin/env python3
"""Extend native temporal memory from AB/BA to all binary length-three histories."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json
from relative_magnitude_reader_v1 import PA,PB
def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)
def install(raw,clock,center,identity,slot,n,state):
    offset=(0,-1,0) if identity=="A" else (0,1,0);direction=(0,0,-1) if identity=="A" else (0,0,1);target=add(center,offset,1,n)
    if slot==0:put(raw,clock,target,state,0,direction,1,17)
    else:put(raw,clock,add(target,direction,-slot,n),0,0,direction,1,19)
def run(kernel,sequence,slots,query_delay,horizon=40):
    n=31;c=(15,15,15);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    for index,(identity,slot) in enumerate(zip(sequence,slots)):install(raw,clock,a if identity=="A" else b,identity,slot,n,5000+index)
    put(raw,clock,add(c,(0,1,0),-query_delay,n),6000,7,(0,1,0),1,23)
    world=NativeWorld(kernel,raw,clock);deltas=[];events=[];digest=hashlib.sha256()
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"]);deltas.append(delta);record=None if rc is None else [rc["state"],rc["sreg"],rc["direction"],rc["semantic"]];digest.update(json.dumps(record,separators=(",",":"),sort_keys=True).encode())
        if rc is not None:events.append({"tick":tick,"delta":delta,"record":record})
    return {"sequence":sequence,"slots":slots,"query_delay":query_delay,"delta_trace":deltas,"delta_before_query":deltas[query_delay-2],"signature":digest.hexdigest(),"events":events,"python_interventions_after_t0":0}
def main():
    kernel,runtime=load_kernel(1);sequences=["".join(bits) for bits in __import__('itertools').product("AB",repeat=3)];schedules=[([0,1,2],8),([0,2,4],10),([0,3,6],12)];rows=[]
    for slots,delay in schedules:
        for sequence in sequences:rows.append(run(kernel,sequence,slots,delay))
    panels=[]
    for slots,delay in schedules:
        panel=[r for r in rows if r["slots"]==slots];panels.append({"slots":slots,"query_delay":delay,"distinct_delta_states":len(set(r["delta_before_query"] for r in panel)),"distinct_output_signatures":len(set(r["signature"] for r in panel)),"classes":{r["sequence"]:{"delta":r["delta_before_query"],"signature":r["signature"]} for r in panel}})
    result=seal({"schema":"dee.v27.ing03.final.discovery.binary_temporal_grammar.v1","question":"Can experience-written length-three binary histories survive until a delayed native query and produce history-specific output under variable delays?","rows":rows,"panels":panels,"summary":{"worlds":len(rows),"sequences":sequences,"panels":[{k:p[k] for k in ("slots","query_delay","distinct_delta_states","distinct_output_signatures")} for p in panels],"full_eight_class_decode":all(p["distinct_output_signatures"]==8 for p in panels)},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D44_BINARY_TEMPORAL_GRAMMAR.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
