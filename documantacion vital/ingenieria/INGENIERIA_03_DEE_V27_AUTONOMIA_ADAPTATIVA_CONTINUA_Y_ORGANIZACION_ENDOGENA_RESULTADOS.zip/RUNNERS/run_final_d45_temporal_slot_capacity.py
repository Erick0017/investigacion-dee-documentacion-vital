#!/usr/bin/env python3
"""Exact small enumeration of three-event schedules to bound functional history capacity."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from run_final_d44_binary_temporal_grammar import run
def main():
    kernel,runtime=load_kernel(1);sequences=["".join(bits) for bits in itertools.product("AB",repeat=3)];panels=[];rows=[]
    for second,third in itertools.combinations(range(1,11),2):
        slots=[0,second,third];query_delay=third+4;panel=[]
        try:
            for sequence in sequences:
                row=run(kernel,sequence,slots,query_delay,horizon=query_delay+24);rows.append(row);panel.append(row)
        except RuntimeError:
            continue
        signatures={row["sequence"]:row["signature"] for row in panel};deltas={row["sequence"]:row["delta_before_query"] for row in panel};classes={}
        for sequence,signature in signatures.items():classes.setdefault(signature,[]).append(sequence)
        panels.append({"slots":slots,"query_delay":query_delay,"distinct_output_signatures":len(classes),"distinct_delta_states":len(set(deltas.values())),"classes":list(classes.values()),"deltas":deltas})
    maximum=max((p["distinct_output_signatures"] for p in panels),default=0);best=[p for p in panels if p["distinct_output_signatures"]==maximum]
    third_event_sensitive=[]
    for panel in panels:
        lookup={seq:next(i for i,items in enumerate(panel["classes"]) if seq in items) for seq in sequences}
        pairs=[(prefix+"A",prefix+"B") for prefix in ("AA","AB","BA","BB")]
        sensitive=[pair for pair in pairs if lookup[pair[0]]!=lookup[pair[1]]]
        if sensitive:third_event_sensitive.append({"slots":panel["slots"],"pairs":sensitive,"classes":panel["classes"]})
    result=seal({"schema":"dee.v27.ing03.final.discovery.temporal_slot_capacity.v1","question":"Across all 45 three-slot schedules with first event at t0 and later events in t1..t10, how many of eight binary histories become functionally distinct and does any output depend on the third event?","rows":rows,"panels":panels,"best":best,"third_event_sensitive":third_event_sensitive,"summary":{"valid_schedules":len(panels),"worlds":len(rows),"maximum_classes":maximum,"best_schedule_count":len(best),"third_event_sensitive_schedules":len(third_event_sensitive),"full_eight_class_schedule":maximum==8},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D45_TEMPORAL_SLOT_CAPACITY.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"best":[{"slots":p["slots"],"classes":p["classes"]} for p in best[:10]],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
