#!/usr/bin/env python3
"""Cross-frame selection for the three-class temporal-prefix mechanism."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from temporal_prefix_reader_v1 import run_case
def main():
    kernel,runtime=load_kernel(1);frames=[((0,1,2),(1,1,1)),((1,2,0),(-1,1,1)),((2,0,1),(1,-1,1)),((0,2,1),(-1,-1,1)),((2,1,0),(1,1,-1)),((1,0,2),(-1,1,-1))];sequences=["".join(x) for x in itertools.product("AB",repeat=3)];groups=[]
    for index,(p,s) in enumerate(frames,1):
        n=31 if index%2 else 37;origin=((7+3*index)%n,(11+5*index)%n,(13+7*index)%n);rows=[run_case(kernel,n=n,origin=origin,sequence=seq,permutation=p,signs=s) for seq in sequences];no_events=run_case(kernel,n=n,origin=origin,sequence="AAA",permutation=p,signs=s,mode="no_events");no_query=run_case(kernel,n=n,origin=origin,sequence="AAA",permutation=p,signs=s,mode="no_query")
        by_class={}
        for row in rows:by_class.setdefault(row["expected_class"],set()).add(row["signature"])
        representatives={key:next(iter(value)) for key,value in by_class.items()};passed=(all(len(value)==1 for value in by_class.values()) and len(set(representatives.values()))==3 and all((row["delta_before_query"]>0)==(row["sequence"][0]=="A") for row in rows) and no_events["delta_before_query"]==0 and no_events["signature"] not in set(representatives.values()) and not no_query["events"])
        groups.append({"passed":passed,"rows":rows,"class_signatures":representatives,"no_events":no_events,"no_query":no_query})
    result=seal({"schema":"dee.v27.ing03.final.mechanism_selection.temporal_prefix.v1","question":"Is the schedule [0,1,8] a frame-covariant three-class functional prefix memory rather than an orientation-specific trajectory?","groups":groups,"summary":{"groups":len(groups),"worlds":10*len(groups),"passed_groups":sum(g["passed"] for g in groups),"all_passed":all(g["passed"] for g in groups)},"runtime":runtime})
    out=ROOT/"MECHANISM_SELECTION/ING03_FINAL_D46_TEMPORAL_PREFIX_MODEL_SELECTION.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
