#!/usr/bin/env python3
"""Exact 48-frame boundary map for the conditional three-class temporal prefix."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from temporal_prefix_reader_v1 import run_case
def parity(permutation):
    inversions=sum(permutation[i]>permutation[j] for i in range(3) for j in range(i+1,3));return -1 if inversions%2 else 1
def main():
    kernel,runtime=load_kernel(1);sequences=["".join(x) for x in itertools.product("AB",repeat=3)];frames=list(itertools.product(itertools.permutations((0,1,2)),itertools.product((-1,1),repeat=3)));rows=[]
    for index,(p,s) in enumerate(frames):
        n=31;origin=((7+3*index)%n,(11+5*index)%n,(13+7*index)%n);cases=[run_case(kernel,n=n,origin=origin,sequence=seq,permutation=p,signs=s) for seq in sequences];by={}
        for case in cases:by.setdefault(case["expected_class"],set()).add(case["signature"])
        representatives={key:next(iter(value)) for key,value in by.items()};three=all(len(value)==1 for value in by.values()) and len(set(representatives.values()))==3;rows.append({"permutation":list(p),"signs":list(s),"permutation_parity":parity(p),"sign_product":s[0]*s[1]*s[2],"determinant_class":parity(p)*s[0]*s[1]*s[2],"three_classes":three,"observed_classes":len(set(representatives.values())),"cases":cases})
    result=seal({"schema":"dee.v27.ing03.final.mechanism_selection.temporal_prefix_all_frames.v1","question":"Exactly which of all 48 signed/permuted frames preserve the third functional temporal-prefix class?","rows":rows,"summary":{"frames":len(rows),"three_class_frames":sum(r["three_classes"] for r in rows),"two_class_frames":sum(not r["three_classes"] for r in rows),"pass_by_first_sign":{str(sign):{"pass":sum(r["three_classes"] and r["signs"][0]==sign for r in rows),"total":sum(r["signs"][0]==sign for r in rows)} for sign in (-1,1)},"pass_by_determinant":{str(det):{"pass":sum(r["three_classes"] and r["determinant_class"]==det for r in rows),"total":sum(r["determinant_class"]==det for r in rows)} for det in (-1,1)}},"runtime":runtime})
    out=ROOT/"MECHANISM_SELECTION/ING03_FINAL_D47_TEMPORAL_PREFIX_ALL_FRAMES.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
