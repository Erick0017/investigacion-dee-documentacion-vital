#!/usr/bin/env python3
"""Measure topology-scaled causal return of second and third event identity."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from run_final_d44_binary_temporal_grammar import run
SEQUENCES=["".join(x) for x in itertools.product("AB",repeat=3)]
def event_map(row):return {e["tick"]:e["record"] for e in row["events"]}
def first_difference(left,right,start=12):
    lm,rm=event_map(left),event_map(right)
    for tick in range(start,max(max(lm,default=start),max(rm,default=start))+1):
        if lm.get(tick)!=rm.get(tick):return tick
    return None
def main():
    kernel,runtime=load_kernel(1);panels=[];rows=[]
    for n in (23,29,31,37,43):
        # run() uses fixed N=31, so preserve N as a controlled horizon proxy here; a later apparatus will test true-N covariance.
        horizon=2*n+20;panel=[run(kernel,seq,[0,1,8],12,horizon=horizon) for seq in SEQUENCES];rows.extend(panel);lookup={r["sequence"]:r for r in panel};classes={}
        for row in panel:classes.setdefault(row["signature"],[]).append(row["sequence"])
        panels.append({"horizon_proxy_n":n,"actual_n":31,"horizon":horizon,"distinct_signatures":len(classes),"classes":list(classes.values()),"first_event_difference":first_difference(lookup["AAA"],lookup["BAA"]),"second_event_difference":first_difference(lookup["BAA"],lookup["BBA"]),"third_event_difference_AA":first_difference(lookup["AAA"],lookup["AAB"]),"third_event_difference_BA":first_difference(lookup["BAA"],lookup["BAB"])})
    result=seal({"schema":"dee.v27.ing03.final.discovery.long_horizon_temporal_return.v1","question":"At horizons beyond one and two toroidal returns, do second and third event identities causally reappear in the fixed N=31 reader trajectory?","method_note":"This stage varies horizon only in the fixed N=31 discovery apparatus; horizon_proxy_n is not a true N variation.","rows":rows,"panels":panels,"summary":{"worlds":len(rows),"maximum_classes":max(p["distinct_signatures"] for p in panels),"panels":[{k:p[k] for k in ("horizon","distinct_signatures","first_event_difference","second_event_difference","third_event_difference_AA","third_event_difference_BA")} for p in panels]},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D48_LONG_HORIZON_TEMPORAL_RETURN.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
