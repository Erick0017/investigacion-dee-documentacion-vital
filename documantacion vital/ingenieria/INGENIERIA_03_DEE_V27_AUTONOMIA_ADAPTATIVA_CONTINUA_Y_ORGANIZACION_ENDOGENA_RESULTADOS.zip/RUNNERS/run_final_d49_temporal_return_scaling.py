#!/usr/bin/env python3
"""True-N scaling test for multi-event causal return and five functional history classes."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from temporal_prefix_reader_v1 import run_case
SEQUENCES=["".join(x) for x in itertools.product("AB",repeat=3)]
def emap(row):return {e["tick"]:e["normalized_record"] for e in row["events"]}
def first_diff(left,right,start=12):
    lm,rm=emap(left),emap(right);end=max(max(lm,default=start),max(rm,default=start))
    return next((tick for tick in range(start,end+1) if lm.get(tick)!=rm.get(tick)),None)
def main():
    kernel,runtime=load_kernel(1);panels=[];all_rows=[]
    for n in (23,29,31,37,43):
        horizon=2*n+20;origin=(n//2,)*3;rows=[run_case(kernel,n=n,origin=origin,sequence=seq,horizon=horizon) for seq in SEQUENCES];all_rows.extend(rows);lookup={r["sequence"]:r for r in rows};classes={}
        for row in rows:classes.setdefault(row["signature"],[]).append(row["sequence"])
        first=first_diff(lookup["AAA"],lookup["BAA"]);second=first_diff(lookup["BAA"],lookup["BBA"]);third_ba=first_diff(lookup["BAA"],lookup["BAB"]);third_aa=first_diff(lookup["AAA"],lookup["AAB"])
        panels.append({"n":n,"horizon":horizon,"distinct_signatures":len(classes),"classes":list(classes.values()),"first_event_difference":first,"second_event_difference":second,"third_event_difference_BA":third_ba,"third_event_difference_AA":third_aa,"second_minus_n":None if second is None else second-n,"third_ba_minus_n":None if third_ba is None else third_ba-n})
    result=seal({"schema":"dee.v27.ing03.final.mechanism_selection.temporal_return_scaling.v1","question":"Do second/third event identities re-enter functional output with topology-scaled latency on true fresh N values?","prediction":{"second_event_tick":"N+3","third_event_tick_for_BA_prefix":"N+10","class_count":5},"rows":all_rows,"panels":panels,"summary":{"worlds":len(all_rows),"all_five_classes":all(p["distinct_signatures"]==5 for p in panels),"all_second_N_plus_3":all(p["second_minus_n"]==3 for p in panels),"all_third_N_plus_10":all(p["third_ba_minus_n"]==10 for p in panels),"all_A_prefix_third_collapsed":all(p["third_event_difference_AA"] is None for p in panels)},"runtime":runtime})
    out=ROOT/"MECHANISM_SELECTION/ING03_FINAL_D49_TEMPORAL_RETURN_SCALING.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"panels":panels,"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
