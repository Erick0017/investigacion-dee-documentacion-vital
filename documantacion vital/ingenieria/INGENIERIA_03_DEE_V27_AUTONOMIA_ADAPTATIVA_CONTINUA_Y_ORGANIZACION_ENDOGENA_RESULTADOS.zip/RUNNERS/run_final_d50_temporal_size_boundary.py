#!/usr/bin/env python3
"""Targeted odd-N boundary map for topology-dependent temporal capacity."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from temporal_prefix_reader_v1 import run_case
SEQS=["".join(x) for x in itertools.product("AB",repeat=3)]
def first_diff(left,right):
    lm={e["tick"]:e["normalized_record"] for e in left["events"]};rm={e["tick"]:e["normalized_record"] for e in right["events"]};end=max(max(lm,default=12),max(rm,default=12));return next((t for t in range(12,end+1) if lm.get(t)!=rm.get(t)),None)
def main():
    kernel,runtime=load_kernel(1);panels=[]
    for n in range(21,46,2):
        horizon=2*n+20;rows=[run_case(kernel,n=n,origin=(n//2,)*3,sequence=seq,horizon=horizon) for seq in SEQS];lookup={r["sequence"]:r for r in rows};classes={}
        for row in rows:classes.setdefault(row["signature"],[]).append(row["sequence"])
        second=first_diff(lookup["BAA"],lookup["BBA"]);third=first_diff(lookup["BAA"],lookup["BAB"]);panels.append({"n":n,"horizon":horizon,"classes":len(classes),"partition":list(classes.values()),"second_tick":second,"third_tick":third,"second_minus_n":None if second is None else second-n,"third_minus_n":None if third is None else third-n})
    five=[p["n"] for p in panels if p["classes"]==5];three=[p["n"] for p in panels if p["classes"]==3]
    result=seal({"schema":"dee.v27.ing03.final.discovery.temporal_size_boundary.v1","question":"Where is the odd-N transition between three and five functional history classes for the frozen schedule geometry?","panels":panels,"summary":{"worlds":8*len(panels),"five_class_N":five,"three_class_N":three,"minimum_five_class_N":None if not five else min(five),"contiguous_five_class_above_min":bool(five) and five==list(range(min(five),46,2))},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D50_TEMPORAL_SIZE_BOUNDARY.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"panels":panels,"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
