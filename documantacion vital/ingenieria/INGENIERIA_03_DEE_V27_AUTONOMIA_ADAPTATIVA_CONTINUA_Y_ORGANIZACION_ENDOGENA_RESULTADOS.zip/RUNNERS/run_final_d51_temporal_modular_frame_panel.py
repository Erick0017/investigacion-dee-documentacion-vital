#!/usr/bin/env python3
"""Cross-frame selection for the N mod 6 temporal-return law."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,write_json
from temporal_prefix_reader_v1 import run_case
SEQS=["".join(x) for x in itertools.product("AB",repeat=3)]
FRAMES=[((0,1,2),(1,1,1)),((1,2,0),(-1,1,1)),((2,0,1),(1,-1,1)),((0,2,1),(-1,-1,1)),((2,1,0),(1,1,-1)),((1,0,2),(-1,1,-1))]
def emap(row):return {e["tick"]:e["normalized_record"] for e in row["events"]}
def fd(a,b):
    am,bm=emap(a),emap(b);end=max(max(am,default=12),max(bm,default=12));return next((t for t in range(12,end+1) if am.get(t)!=bm.get(t)),None)
def expected_key(sequence,residue):
    if sequence[0]=="A":return "A_COLLAPSED"
    if residue==1:return sequence
    if residue==3:return "B_THIRD_"+sequence[2]
    return "B_SECOND_"+sequence[1]
def main():
    kernel,runtime=load_kernel(1);groups=[]
    for n in (33,35,37):
        residue=n%6;horizon=2*n+20
        for index,(p,s) in enumerate(FRAMES):
            origin=((n//2+3*index)%n,(n//2+5*index)%n,(n//2+7*index)%n);rows=[run_case(kernel,n=n,origin=origin,sequence=seq,permutation=p,signs=s,horizon=horizon) for seq in SEQS];lookup={r["sequence"]:r for r in rows};by_expected={}
            for row in rows:by_expected.setdefault(expected_key(row["sequence"],residue),set()).add(row["signature"])
            observed=len({r["signature"] for r in rows});expected_count=5 if residue==1 else 3;second=fd(lookup["BAA"],lookup["BBA"]);third=fd(lookup["BAA"],lookup["BAB"])
            timing=(second==n+3 and third==n+10) if residue==1 else (second is None and third==n+10) if residue==3 else (second==2*n+1 and third is None)
            passed=observed==expected_count and all(len(v)==1 for v in by_expected.values()) and timing
            groups.append({"n":n,"residue":residue,"permutation":list(p),"signs":list(s),"passed":passed,"observed_classes":observed,"second_tick":second,"third_tick":third,"rows":rows})
    result=seal({"schema":"dee.v27.ing03.final.mechanism_selection.temporal_modular_frame_panel.v1","question":"Is the N mod 6 temporal-return capacity/latency law covariant across signed/permuted frames?","groups":groups,"summary":{"groups":len(groups),"worlds":8*len(groups),"passed_groups":sum(g["passed"] for g in groups),"all_passed":all(g["passed"] for g in groups),"by_residue":{str(r):{"pass":sum(g["passed"] and g["residue"]==r for g in groups),"total":sum(g["residue"]==r for g in groups)} for r in (1,3,5)}},"runtime":runtime})
    out=ROOT/"MECHANISM_SELECTION/ING03_FINAL_D51_TEMPORAL_MODULAR_FRAME_PANEL.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
