#!/usr/bin/env python3
"""Bounded three-identity temporal search for the six ABC permutations."""
from __future__ import annotations
import hashlib,itertools,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,load_kernel,pack,read,seal,write_json
from relative_magnitude_reader_v1 import PA,PB
SLOTS=(0,1,8);SEQUENCES=["".join(x) for x in itertools.permutations("ABC")];AXES=[(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1)]
def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)
def install(raw,clock,target,direction,slot,n,state):
    if slot==0:put(raw,clock,target,state,0,direction,1,17)
    else:put(raw,clock,add(target,direction,-slot,n),0,0,direction,1,19)
def run(kernel,sequence,c_direction,mode="treatment",horizon=82):
    n=31;c=(15,15,15);a=add(c,(-1,0,0),1,n);b=add(c,(1,0,0),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    put(raw,clock,a,1000,100,semantic=1,phase=260);put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):put(raw,clock,add(a,o,1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):put(raw,clock,add(b,o,1,n),4000+i,0,semantic=4,phase=41+i)
    for index,(identity,slot) in enumerate(zip(sequence,SLOTS)):
        if identity=="C" and mode=="drop_c":continue
        if identity=="A":target,direction=add(a,(0,-1,0),1,n),(0,0,-1)
        elif identity=="B":target,direction=add(b,(0,1,0),1,n),(0,0,1)
        else:target,direction=c,c_direction
        install(raw,clock,target,direction,slot,n,5000+index)
    if mode!="no_query":put(raw,clock,add(c,(0,1,0),-12,n),6000,7,(0,1,0),1,23)
    world=NativeWorld(kernel,raw,clock);digest=hashlib.sha256();events=[]
    for tick in range(1,horizon+1):
        world.tick();rc=read(world.raw,c)
        if tick>=12:
            record=None if rc is None else [rc["state"],rc["sreg"],rc["direction"],rc["semantic"]];digest.update(json.dumps(record,separators=(",",":"),sort_keys=True).encode())
            if rc is not None:events.append({"tick":tick,"record":record})
    return {"sequence":sequence,"c_direction":list(c_direction),"mode":mode,"signature_after_query":digest.hexdigest(),"events_after_query":events,"python_interventions_after_t0":0}
def main():
    kernel,runtime=load_kernel(1);families=[];rows=[]
    for direction in AXES:
        try:
            cases=[run(kernel,seq,direction) for seq in SEQUENCES];rows.extend(cases);classes={}
            for row in cases:classes.setdefault(row["signature_after_query"],[]).append(row["sequence"])
            controls=[run(kernel,"ABC",direction,"drop_c"),run(kernel,"ABC",direction,"no_query")];rows.extend(controls)
            families.append({"c_direction":list(direction),"valid":True,"distinct_permutations":len(classes),"classes":list(classes.values()),"controls":controls})
        except RuntimeError as exc:families.append({"c_direction":list(direction),"valid":False,"error":str(exc)})
    valid=[f for f in families if f["valid"]];maximum=max((f["distinct_permutations"] for f in valid),default=0)
    result=seal({"schema":"dee.v27.ing03.final.discovery.three_identity_temporal_search.v1","question":"Can a third native event route leave delayed-query-accessible information that distinguishes the six ABC permutations?","apparatus_scope":"six straight C routes through the comparator; output signature starts only at delayed query tick 12","rows":rows,"families":families,"summary":{"valid_families":len(valid),"maximum_classes":maximum,"full_six_class_family":any(f["distinct_permutations"]==6 for f in valid),"best":[f for f in valid if f["distinct_permutations"]==maximum]},"runtime":runtime})
    out=ROOT/"DISCOVERY/ING03_FINAL_D52_THREE_IDENTITY_TEMPORAL_SEARCH.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
