#!/usr/bin/env python3
"""Execute the frozen native consequence-buffer apparatus on unseen challenge worlds."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
from native_consequence_buffer_v1 import run_case


def main():
    lock_path = ROOT / "FREEZE/ING03_FINAL_NATIVE_BUFFER_LOCK.json"
    challenge_path = ROOT / "CHALLENGES/ING03_FINAL_NATIVE_BUFFER_CHALLENGES.json"
    lock = json.loads(lock_path.read_text(encoding="utf-8"))
    apparatus = ROOT / lock["apparatus"]["path"]
    if sha256_file(apparatus) != lock["apparatus"]["sha256"]:
        raise RuntimeError("frozen apparatus hash mismatch")
    challenges = json.loads(challenge_path.read_text(encoding="utf-8"))
    if challenges["freeze_lock"]["sha256"] != sha256_file(lock_path):
        raise RuntimeError("challenge does not reference current frozen lock")
    kernel, runtime = load_kernel(1)
    groups = []
    for spec in challenges["groups"]:
        rows = []
        for mode in spec["modes"]:
            row = run_case(
                kernel,
                n=spec["n"], origin=tuple(spec["origin"]), target_name=spec["target_name"],
                memory_phase=spec["memory_phase"], distance=spec["distance"],
                permutation=tuple(spec["permutation"]), signs=tuple(spec["signs"]), mode=mode, horizon=24,
            )
            rows.append(row)
        treatment = next(row for row in rows if row["mode"] == "treatment")
        controls = [row for row in rows if row["mode"] != "treatment"]
        passed = (
            treatment["generated_route_exact"]
            and treatment["first_nonzero_delta"] == spec["expected_write_tick"]
            and treatment["sign_correct"]
            and all(row["first_nonzero_delta"] is None and row["terminal_delta"] == 0 for row in controls)
        )
        groups.append({"spec": spec, "passed": passed, "treatment": treatment, "controls": controls})
    result = seal({
        "schema": "dee.v27.ing03.final.holdout.native_consequence_buffer.v1",
        "phase": "FRESH_HOLDOUT",
        "freeze_lock_sha256": sha256_file(lock_path),
        "challenge_sha256": sha256_file(challenge_path),
        "groups": groups,
        "summary": {
            "groups": len(groups),
            "worlds": 4 * len(groups),
            "passed_groups": sum(group["passed"] for group in groups),
            "all_passed": bool(groups) and all(group["passed"] for group in groups),
            "python_interventions_after_t0": 0,
        },
        "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_FINAL_NATIVE_BUFFER_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), **result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
