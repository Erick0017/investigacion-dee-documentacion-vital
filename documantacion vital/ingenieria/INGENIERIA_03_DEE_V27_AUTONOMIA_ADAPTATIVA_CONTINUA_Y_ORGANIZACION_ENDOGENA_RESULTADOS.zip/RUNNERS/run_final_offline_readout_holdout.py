#!/usr/bin/env python3
"""Fresh holdout for frozen one-cycle buffered offline readout."""
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from buffered_offline_readout_v1 import run_case
from ing03_common import ROOT,load_kernel,seal,sha256_file,write_json
def main():
    lp=ROOT/"FREEZE/ING03_FINAL_OFFLINE_READOUT_LOCK.json";cp=ROOT/"CHALLENGES/ING03_FINAL_OFFLINE_READOUT_CHALLENGES.json";lock=json.loads(lp.read_text(encoding="utf-8"))
    for k in ("apparatus","discovery","model_selection","predictions"):
        if sha256_file(ROOT/lock[k]["path"])!=lock[k]["sha256"]:raise RuntimeError(f"hash mismatch {k}")
    challenges=json.loads(cp.read_text(encoding="utf-8"))
    if challenges["freeze_lock"]["sha256"]!=sha256_file(lp):raise RuntimeError("lock mismatch")
    kernel,runtime=load_kernel(1);groups=[]
    for spec in challenges["groups"]:
        rows=[run_case(kernel,n=spec["n"],origin=tuple(spec["origin"]),target_name=spec["target_name"],permutation=tuple(spec["permutation"]),signs=tuple(spec["signs"]),mode=mode) for mode in spec["modes"]]
        treatment,no_consequence,missing_d1,no_query=rows
        passed=(treatment["first_write"]==treatment["expected_write_tick"] and treatment["first_comparator_event"]==treatment["query_distance"] and treatment["second_comparator_direction"]==treatment["expected_second_direction"] and no_consequence["first_write"] is None and no_consequence["second_comparator_direction"]==[0,0,0] and missing_d1["first_write"] is None and missing_d1["second_comparator_direction"]==[0,0,0] and no_query["first_write"]==no_query["expected_write_tick"] and not no_query["comparator_events"])
        groups.append({"spec":spec,"passed":passed,"treatment":treatment,"no_consequence":no_consequence,"missing_d1":missing_d1,"no_query":no_query})
    result=seal({"schema":"dee.v27.ing03.final.holdout.buffered_offline_readout.v1","phase":"FRESH_HOLDOUT","freeze_lock_sha256":sha256_file(lp),"challenge_sha256":sha256_file(cp),"groups":groups,"summary":{"groups":len(groups),"worlds":4*len(groups),"passed_groups":sum(g["passed"] for g in groups),"all_passed":all(g["passed"] for g in groups),"python_interventions_after_t0":0},"runtime":runtime})
    out=ROOT/"HOLDOUT/ING03_FINAL_OFFLINE_READOUT_HOLDOUT.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
