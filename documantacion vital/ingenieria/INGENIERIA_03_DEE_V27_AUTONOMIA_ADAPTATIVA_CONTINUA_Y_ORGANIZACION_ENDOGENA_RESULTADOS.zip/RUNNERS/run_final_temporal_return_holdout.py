#!/usr/bin/env python3
"""Fresh holdout for the frozen topology-dependent temporal-return grammar."""
from __future__ import annotations
import itertools,json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,sha256_file,write_json
from temporal_prefix_reader_v1 import run_case
SEQS=["".join(x) for x in itertools.product("AB",repeat=3)]
def emap(row):return {e["tick"]:e["normalized_record"] for e in row["events"]}
def fd(a,b):
    am,bm=emap(a),emap(b);end=max(max(am,default=12),max(bm,default=12));return next((t for t in range(12,end+1) if am.get(t)!=bm.get(t)),None)
def key(seq,res):
    if seq[0]=="A":return "Axx"
    if res==1:return seq
    if res==3:return "Bx"+seq[2]
    return "B"+seq[1]+"x"
def main():
    lp=ROOT/"FREEZE/ING03_FINAL_TEMPORAL_RETURN_LOCK.json";cp=ROOT/"CHALLENGES/ING03_FINAL_TEMPORAL_RETURN_CHALLENGES.json";lock=json.loads(lp.read_text(encoding="utf-8"))
    for k in ("apparatus","slot_enumeration","size_boundary","model_selection","predictions"):
        if sha256_file(ROOT/lock[k]["path"])!=lock[k]["sha256"]:raise RuntimeError(f"hash mismatch {k}")
    challenges=json.loads(cp.read_text(encoding="utf-8"));kernel,runtime=load_kernel(1);groups=[]
    for spec in challenges["groups"]:
        p,s=tuple(spec["permutation"]),tuple(spec["signs"]);origin=tuple(spec["origin"]);rows=[run_case(kernel,n=spec["n"],origin=origin,sequence=seq,permutation=p,signs=s,horizon=spec["horizon"]) for seq in SEQS];no_events=run_case(kernel,n=spec["n"],origin=origin,sequence="AAA",permutation=p,signs=s,mode="no_events",horizon=spec["horizon"]);no_query=run_case(kernel,n=spec["n"],origin=origin,sequence="AAA",permutation=p,signs=s,mode="no_query",horizon=spec["horizon"]);res=spec["n"]%6;lookup={r["sequence"]:r for r in rows};by={}
        for row in rows:by.setdefault(key(row["sequence"],res),set()).add(row["signature"])
        observed=len({r["signature"] for r in rows});expected=5 if res==1 else 3;second,third=fd(lookup["BAA"],lookup["BBA"]),fd(lookup["BAA"],lookup["BAB"]);timing=(second==spec["n"]+3 and third==spec["n"]+10) if res==1 else (second is None and third==spec["n"]+10) if res==3 else (second==2*spec["n"]+1 and third is None);passed=observed==expected and all(len(v)==1 for v in by.values()) and timing and no_events["signature"] not in {r["signature"] for r in rows} and not no_query["events"]
        groups.append({"spec":spec,"passed":passed,"observed_classes":observed,"second_tick":second,"third_tick":third,"rows":rows,"no_events":no_events,"no_query":no_query})
    result=seal({"schema":"dee.v27.ing03.final.holdout.temporal_return.v1","phase":"FRESH_HOLDOUT","freeze_lock_sha256":sha256_file(lp),"challenge_sha256":sha256_file(cp),"groups":groups,"summary":{"groups":len(groups),"worlds":10*len(groups),"passed_groups":sum(g["passed"] for g in groups),"all_passed":all(g["passed"] for g in groups),"python_interventions_after_t0":0},"runtime":runtime})
    out=ROOT/"HOLDOUT/ING03_FINAL_TEMPORAL_RETURN_HOLDOUT.json";write_json(out,result);print(json.dumps({"output":str(out),**result["summary"],"content_sha256":result["content_sha256"]},indent=2))
if __name__=="__main__":main()
