#!/usr/bin/env python3
from __future__ import annotations
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,seal,sha256_file,write_json
from read_write_extension_apparatus_v1 import run_probe_class

def main():
    cp=ROOT/"CHALLENGES/ING03_EXTENSION_FRESH_CHALLENGES.json";lp=ROOT/"FREEZE/ING03_EXTENSION_FINAL_LOCK.json";c=json.loads(cp.read_text(encoding="utf-8"));lock=json.loads(lp.read_text(encoding="utf-8"))
    if lock["challenge_file_sha256"]!=sha256_file(cp):raise RuntimeError("challenge changed")
    kernel,runtime=load_kernel(1);rows=[]
    for spec in c["groups"]:rows.append(run_probe_class(kernel,spec))
    summary={"groups":len(rows),"native_worlds":len(rows)*6,"pass":sum(r["prediction_pass"] for r in rows),"informative_blocking":sum(r["spec"]["probe_kind"]=="INFORMATIVE_BLOCKING" and r["prediction_pass"] for r in rows),"writable_uninformative":sum(r["spec"]["probe_kind"]=="WRITABLE_UNINFORMATIVE" and r["prediction_pass"] for r in rows)};summary["overall_pass"]=summary["pass"]==summary["groups"]
    outdata=seal({"schema":"dee.v27.ing03.extension.holdout.result.v1","phase":"FRESH_HOLDOUT","challenge_file_sha256":sha256_file(cp),"final_lock_file_sha256":sha256_file(lp),"rows":rows,"summary":summary,"runtime":runtime})
    out=ROOT/"HOLDOUT/ING03_EXTENSION_FRESH_HOLDOUT_RESULTS.json";write_json(out,outdata);print(json.dumps({"output":str(out),"summary":summary,"content_sha256":outdata["content_sha256"]},indent=2))
    if not summary["overall_pass"]:raise SystemExit(2)
if __name__=="__main__":main()
