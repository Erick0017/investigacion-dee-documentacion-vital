#!/usr/bin/env python3
"""Execute the sealed ING03 fresh holdout without tuning."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
from recurrent_writer_apparatus_v1 import run_recovery_case, run_writer_case
from relative_magnitude_reader_v1 import run_case as run_magnitude_case


def main():
    final_lock_path = ROOT / "FREEZE/ING03_FINAL_LOCK.json"
    challenges_path = ROOT / "CHALLENGES/ING03_FRESH_HOLDOUT_CHALLENGES.json"
    predictions_path = ROOT / "FREEZE/ING03_FROZEN_PREDICTIONS.json"
    final_lock = json.loads(final_lock_path.read_text(encoding="utf-8"))
    challenges = json.loads(challenges_path.read_text(encoding="utf-8"))
    predictions = json.loads(predictions_path.read_text(encoding="utf-8"))
    if final_lock["challenge_file_sha256"] != sha256_file(challenges_path):
        raise RuntimeError("challenge changed after final lock")
    kernel, runtime = load_kernel(1)
    writer_rows = []
    for spec in challenges["writer_worlds"]:
        out = run_writer_case(kernel, spec)
        expected = predictions["writer_expected_delta_by_tick"][spec["mode"]]
        observed = {str(row["tick"]): row["delta"] for row in out["trace"]}
        out["exact_prediction"] = observed == expected
        out["expected_delta_by_tick"] = expected
        writer_rows.append(out)
    recovery_rows = []
    for spec in challenges["recovery_worlds"]:
        out = run_recovery_case(kernel, spec)
        treatment = spec["mode"] in predictions["recovery_predictions"]["treatment_modes"]
        out["role"] = "TREATMENT" if treatment else "CAUSAL_CANARY"
        out["prediction_pass"] = (out["first_functional_return"] is not None) if treatment else (out["first_functional_return"] is None)
        recovery_rows.append(out)
    magnitude_rows = []
    refs = predictions["magnitude_class_signatures"]
    for spec in challenges["magnitude_worlds"]:
        out = run_magnitude_case(kernel, spec)
        out["exact_prediction"] = out["expected_class"] == spec["expected_class"] and out["signature"] == refs[spec["expected_class"]]
        magnitude_rows.append(out)
    summary = {
        "worlds": len(writer_rows) + len(recovery_rows) + len(magnitude_rows),
        "writer_exact": sum(row["exact_prediction"] for row in writer_rows),
        "writer_total": len(writer_rows),
        "recovery_pass": sum(row["prediction_pass"] for row in recovery_rows),
        "recovery_total": len(recovery_rows),
        "recovery_treatments": sum(row["role"] == "TREATMENT" for row in recovery_rows),
        "recovery_canaries": sum(row["role"] == "CAUSAL_CANARY" for row in recovery_rows),
        "magnitude_exact": sum(row["exact_prediction"] for row in magnitude_rows),
        "magnitude_total": len(magnitude_rows),
    }
    summary["overall_pass"] = summary["writer_exact"] == summary["writer_total"] and summary["recovery_pass"] == summary["recovery_total"] and summary["magnitude_exact"] == summary["magnitude_total"]
    result = seal({
        "schema": "dee.v27.ing03.holdout.result.v1",
        "phase": "FRESH_HOLDOUT",
        "no_tuning_after_freeze": True,
        "challenge_file_sha256": sha256_file(challenges_path),
        "final_lock_file_sha256": sha256_file(final_lock_path),
        "summary": summary,
        "writer_rows": writer_rows,
        "recovery_rows": recovery_rows,
        "magnitude_rows": magnitude_rows,
        "runtime": runtime,
    })
    out = ROOT / "HOLDOUT/ING03_FRESH_HOLDOUT_RESULTS.json"
    write_json(out, result)
    print(json.dumps({"output": str(out), "summary": summary, "content_sha256": result["content_sha256"]}, indent=2))
    if not summary["overall_pass"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
