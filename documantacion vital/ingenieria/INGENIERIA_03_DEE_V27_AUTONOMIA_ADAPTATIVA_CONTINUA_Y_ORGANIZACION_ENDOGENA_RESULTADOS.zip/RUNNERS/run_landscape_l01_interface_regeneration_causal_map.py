#!/usr/bin/env python3
"""Resolve the causal source of N09 interface return and test natural turnover."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB, build, policy_class


def clear(world, positions):
    for q in positions:
        world.raw_a[q] = np.uint64(0)
        world.raw_b[q] = np.uint64(0)


def groups(meta):
    n = meta["n"]
    pa = [add(meta["a"], offset, 1, n) for offset in PA]
    pb = [add(meta["b"], offset, 1, n) for offset in PB]
    return {
        "a": [meta["a"]],
        "b": [meta["b"]],
        "a_b": [meta["a"], meta["b"]],
        "pa": pa,
        "pb": pb,
        "pa_pb": pa + pb,
        "transducer_sources": [q for q, _ in meta["sources"]],
        "writer": [] if meta["writer"] is None else [meta["writer"]],
        "master_scaffold": [meta["a"], meta["b"]] + pa + pb,
    }


def moore_snapshot(world, c):
    rows = []
    for offset in itertools.product((-1, 0, 1), repeat=3):
        if offset == (0, 0, 0):
            continue
        q = add(c, offset, 1, world.n)
        record = read(world.raw, q)
        points_to_c = False
        if record is not None:
            points_to_c = add(q, record["direction"], 1, world.n) == c
        rows.append({"offset": list(offset), "position": list(q), "record": record,
                     "clock": int(world.clock_a[q]), "points_to_c_next_tick": points_to_c})
    return rows


def return_after(branch, c, before, steps=4):
    trace = []
    for latency in range(1, steps + 1):
        branch.tick()
        record = read(branch.raw, c)
        trace.append({"latency": latency, "record": record,
                      "policy_class": policy_class(record)})
        if record is not None:
            return {"returned": True, "latency": latency, "record": record,
                    "exact_raw_return": record["raw"] == before["raw"],
                    "functional_class_before": policy_class(before),
                    "functional_class_return": policy_class(record), "trace": trace}
    return {"returned": False, "latency": None, "record": None,
            "exact_raw_return": False, "functional_class_before": policy_class(before),
            "functional_class_return": "ABSENT", "trace": trace}


def branch_at_tick(kernel, damage_tick=200):
    world, meta = build(kernel, initial_delta=2, with_writer=True)
    for _ in range(damage_tick):
        world.tick()
    before = read(world.raw, meta["c"])
    return world, meta, before


def diagnostic_branches(kernel):
    base, meta, before = branch_at_tick(kernel)
    snapshot = moore_snapshot(base, meta["c"])
    group_map = groups(meta)
    modes = {"damage_only": []}
    for name, positions in group_map.items():
        modes[f"cut_{name}_at_damage"] = positions
    rows = []
    for mode, cuts in modes.items():
        branch = NativeWorld(kernel, base.raw_a, base.clock_a)
        clear(branch, cuts)
        clear(branch, [meta["c"]])
        result = return_after(branch, meta["c"], before)
        rows.append({"mode": mode, "cut_positions": [list(q) for q in cuts], **result})

    # Exhaust the four-source causal combinations (16 masks, not parameter tuning).
    source_positions = group_map["transducer_sources"]
    source_subset_panel = []
    for mask in range(16):
        cuts = [q for index, q in enumerate(source_positions) if mask & (1 << index)]
        branch = NativeWorld(kernel, base.raw_a, base.clock_a)
        clear(branch, cuts); clear(branch, [meta["c"]])
        result = return_after(branch, meta["c"], before)
        source_subset_panel.append({"cut_mask": mask,
                                    "cut_source_indices": [i for i in range(4) if mask & (1 << i)],
                                    "kept_source_indices": [i for i in range(4) if not mask & (1 << i)],
                                    **result})

    # Sufficiency diagnostics deliberately retain only selected state at damage time.
    sufficiency = []
    current_raw = base.raw_a.copy(); current_clock = base.clock_a.copy()
    keep_modes = {
        "keep_only_a_b": group_map["a_b"],
        "keep_only_master_scaffold": group_map["master_scaffold"],
        "keep_only_moore_neighbors": [tuple(row["position"]) for row in snapshot],
        "keep_only_inbound_neighbors": [tuple(row["position"]) for row in snapshot if row["points_to_c_next_tick"]],
        "keep_only_all_sources": source_positions,
    }
    for index, q in enumerate(source_positions):
        keep_modes[f"keep_only_source_{index}"] = [q]
    for mode, keep in keep_modes.items():
        raw = np.zeros_like(current_raw); clock = np.zeros_like(current_clock)
        for q in keep:
            raw[q] = current_raw[q]; clock[q] = current_clock[q]
        branch = NativeWorld(kernel, raw, clock)
        result = return_after(branch, meta["c"], before)
        sufficiency.append({"mode": mode, "kept_positions": [list(q) for q in keep], **result})
    source_paths = []
    for index, q in enumerate(source_positions):
        record = read(base.raw, q)
        path = []
        cursor = q
        if record is not None:
            for step in range(1, 5):
                cursor = add(cursor, record["direction"], 1, meta["n"])
                path.append({"step": step, "position": list(cursor),
                             "reaches_interface": cursor == meta["c"]})
        source_paths.append({"source_index": index, "position": list(q),
                             "record": record, "ballistic_path": path})
    return {"damage_tick": 200, "before": before, "moore_pre_damage": snapshot,
            "incoming_neighbor_count": sum(row["points_to_c_next_tick"] for row in snapshot),
            "source_ballistic_paths": source_paths,
            "necessity_diagnostics": rows, "source_subset_panel": source_subset_panel,
            "sufficiency_diagnostics": sufficiency}


def natural_turnover(kernel, horizon=4096):
    world, meta = build(kernel, initial_delta=2, with_writer=True)
    absent_ticks = []; class_transitions = []; raw_transitions = 0
    previous_class = None; previous_raw = None; master_transitions = []
    previous_delta = None
    for tick in range(1, horizon + 1):
        world.tick()
        output = read(world.raw, meta["c"]); cls = policy_class(output)
        if output is None:
            absent_ticks.append(tick)
        raw = None if output is None else output["raw"]
        if previous_raw is not None and raw != previous_raw:
            raw_transitions += 1
        if previous_class is not None and cls != previous_class:
            class_transitions.append({"tick": tick, "before": previous_class, "after": cls})
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if previous_delta is not None and delta != previous_delta:
            master_transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        previous_class, previous_raw, previous_delta = cls, raw, delta
    return {"horizon": horizon, "present_ticks": horizon - len(absent_ticks),
            "absent_ticks": absent_ticks, "autonomous_occupancy_turnover": bool(absent_ticks),
            "raw_transitions": raw_transitions, "functional_class_transitions": class_transitions,
            "master_transitions": master_transitions, "python_interventions_after_t0": 0}


def size_and_damage_phase_panel(kernel):
    rows = []
    for n in (17, 23, 29):
        for damage_tick in (199, 200, 201, 259, 260, 261):
            world, meta = build(kernel, initial_delta=2, with_writer=True, n=n)
            previous_delta = None; transitions = []
            before = None; result = None
            for tick in range(1, damage_tick + 5):
                world.tick()
                ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
                delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
                if previous_delta is not None and delta != previous_delta:
                    transitions.append({"tick": tick, "before": previous_delta, "after": delta})
                previous_delta = delta
                if tick == damage_tick:
                    before = read(world.raw, meta["c"]); clear(world, [meta["c"]])
                elif tick > damage_tick and result is None:
                    record = read(world.raw, meta["c"])
                    if record is not None:
                        result = {"returned": True, "latency": tick - damage_tick, "record": record}
            if result is None:
                result = {"returned": False, "latency": None, "record": None}
            rows.append({"n": n, "damage_tick": damage_tick, "before": before,
                         "return": result, "master_transitions": transitions})
    return rows


def main():
    kernel, runtime = load_kernel(1)
    causal_map = diagnostic_branches(kernel)
    natural = natural_turnover(kernel)
    scaling = size_and_damage_phase_panel(kernel)
    damage_only = next(row for row in causal_map["necessity_diagnostics"] if row["mode"] == "damage_only")
    abolished = [row["mode"] for row in causal_map["necessity_diagnostics"] if not row["returned"]]
    sufficient = [row["mode"] for row in causal_map["sufficiency_diagnostics"] if row["returned"]]
    minimal_kept_source_sets = []
    returning_masks = [row for row in causal_map["source_subset_panel"] if row["returned"]]
    for row in returning_masks:
        kept = set(row["kept_source_indices"])
        if not any(set(other["kept_source_indices"]) < kept for other in returning_masks):
            minimal_kept_source_sets.append(sorted(kept))
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.interface_regeneration_map.v1",
        "question": "What causally reinstantiates the N09 interface, and does the undamaged organization exhibit autonomous occupancy turnover?",
        "apparatus_origin": "N04 temporal-expression apparatus and N09 host-damage observation",
        "causal_map": causal_map,
        "natural_turnover": natural,
        "size_damage_phase_panel": scaling,
        "summary": {"damage_only_returned": damage_only["returned"],
                    "damage_only_latency": damage_only["latency"],
                    "cuts_abolishing_return": abolished,
                    "diagnostically_sufficient_subsets": sufficient,
                    "minimal_source_sets_preserving_return": minimal_kept_source_sets,
                    "autonomous_absent_ticks_4096": len(natural["absent_ticks"]),
                    "autonomous_occupancy_turnover": natural["autonomous_occupancy_turnover"]},
        "claim_guard": "Host damage is used only for causal mapping. Return after host deletion is not endogenous turnover; promotion requires native OFF/ON cycling without post-t0 host intervention.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_LANDSCAPE_L01_INTERFACE_REGENERATION_CAUSAL_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
