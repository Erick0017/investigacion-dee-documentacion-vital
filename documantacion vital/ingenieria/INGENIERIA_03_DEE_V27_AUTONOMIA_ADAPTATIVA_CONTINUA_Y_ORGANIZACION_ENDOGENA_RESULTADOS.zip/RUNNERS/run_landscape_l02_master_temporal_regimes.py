#!/usr/bin/env python3
"""Measure repeatable master-dependent temporal regimes and remote expression ports."""
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import build, policy_class


def minimal_period(sequence, max_period=1024):
    if len(sequence) < 2:
        return None
    maximum = min(max_period, len(sequence) // 2)
    for period in range(1, maximum + 1):
        if sequence[period:] == sequence[:-period]:
            return period
    return None


def configure(kernel, delta, phase, n=23):
    world, meta = build(kernel, initial_delta=delta, with_writer=False, n=n)
    for q in (meta["a"], meta["b"]):
        world.clock_a[q] = np.uint64(phase); world.clock_b[q] = np.uint64(phase)
    return world, meta


def regime_run(kernel, delta, phase, horizon=2048):
    world, meta = configure(kernel, delta, phase)
    raw_sequence = []; class_sequence = []; presence_sequence = []
    master_delta_sequence = []; digest = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick(); record = read(world.raw, meta["c"])
        raw = 0 if record is None else record["raw"]
        raw_sequence.append(raw); class_sequence.append(policy_class(record)); presence_sequence.append(record is not None)
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        master_delta_sequence.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        if tick > horizon // 2:
            digest.update(int(raw).to_bytes(8, "little", signed=False))
    suffix_start = horizon // 2
    raw_suffix = raw_sequence[suffix_start:]; class_suffix = class_sequence[suffix_start:]
    raw_change_ticks = [tick + 2 for tick, (a, b) in enumerate(zip(raw_sequence, raw_sequence[1:])) if a != b]
    class_change_ticks = [tick + 2 for tick, (a, b) in enumerate(zip(class_sequence, class_sequence[1:])) if a != b]
    class_intervals = [b - a for a, b in zip(class_change_ticks, class_change_ticks[1:])]
    return {"delta": delta, "master_phase": phase, "horizon": horizon,
            "terminal_master_delta": master_delta_sequence[-1],
            "master_delta_unique": sorted({value for value in master_delta_sequence if value is not None}),
            "output_present_fraction": sum(presence_sequence) / horizon,
            "raw_unique_suffix": len(set(raw_suffix)), "class_counts_suffix": dict(Counter(class_suffix)),
            "raw_period_suffix": minimal_period(raw_suffix),
            "class_period_suffix": minimal_period(class_suffix),
            "raw_change_count": len(raw_change_ticks), "class_change_count": len(class_change_ticks),
            "class_change_interval_counts": {str(k): v for k, v in sorted(Counter(class_intervals).items())},
            "suffix_raw_sha256": digest.hexdigest(),
            "samples": [{"tick": tick, "raw": raw_sequence[tick - 1], "class": class_sequence[tick - 1]}
                        for tick in (1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 1536, 2048)
                        if tick <= horizon],
            "python_interventions_after_t0": 0}


def toroidal_radius(q, c, n):
    components = []
    for x, y in zip(q, c):
        d = abs(int(x) - int(y)); components.append(min(d, n - d))
    return max(components)


def remote_port_census(kernel, horizon=1024):
    deltas = (-8, 0, 8); worlds = [configure(kernel, delta, 260) for delta in deltas]
    n = worlds[0][1]["n"]; c = worlds[0][1]["c"]
    counts = np.zeros((n, n, n), np.int32); first = np.zeros_like(counts); last = np.zeros_like(counts)
    for tick in range(1, horizon + 1):
        for world, _ in worlds:
            world.tick()
        raw0, raw1, raw2 = [world.raw for world, _ in worlds]
        mask = (raw0 != raw1) | (raw0 != raw2) | (raw1 != raw2)
        counts[mask] += 1; first[(first == 0) & mask] = tick; last[mask] = tick
    candidates = []
    for q_array in np.argwhere(counts > 0):
        q = tuple(int(x) for x in q_array); radius = toroidal_radius(q, c, n)
        if radius >= 4:
            candidates.append({"position": list(q), "toroidal_chebyshev_radius": radius,
                               "distinct_tick_count": int(counts[q]), "first_distinct_tick": int(first[q]),
                               "last_distinct_tick": int(last[q])})
    candidates.sort(key=lambda row: (-row["distinct_tick_count"], row["first_distinct_tick"], row["position"]))
    selected = candidates[:24]

    # Re-run only the frozen selected ports to extract objective temporal signatures.
    worlds = [configure(kernel, delta, 260) for delta in deltas]
    sequences = {tuple(row["position"]): {delta: [] for delta in deltas} for row in selected}
    for _ in range(horizon):
        for world, _ in worlds:
            world.tick()
        for row in selected:
            q = tuple(row["position"])
            for delta, (world, _) in zip(deltas, worlds):
                sequences[q][delta].append(int(world.raw[q]))
    for row in selected:
        q = tuple(row["position"]); signatures = {}
        periods = {}
        for delta in deltas:
            suffix = sequences[q][delta][horizon // 2:]
            digest = hashlib.sha256()
            for raw in suffix:
                digest.update(int(raw).to_bytes(8, "little", signed=False))
            signatures[str(delta)] = digest.hexdigest(); periods[str(delta)] = minimal_period(suffix)
        row["state_signatures"] = signatures; row["raw_periods_suffix"] = periods
        row["distinct_state_signatures"] = len(set(signatures.values()))
    return {"horizon": horizon, "states": list(deltas), "same_clock": 260,
            "remote_candidate_count_radius_ge_4": len(candidates), "selected_ports": selected}


def main():
    kernel, runtime = load_kernel(1)
    fixed_phase = [regime_run(kernel, delta, 260, 2048) for delta in (-8, -2, -1, 0, 1, 2, 8)]
    phase_panel = [regime_run(kernel, delta, phase, 1024)
                   for delta in (-8, 0, 8) for phase in (0, 259, 260, 261, 455, 782)]
    remote = remote_port_census(kernel)
    fixed_signatures = {row["suffix_raw_sha256"] for row in fixed_phase}
    same_state_phase_dependence = {}
    for delta in (-8, 0, 8):
        rows = [row for row in phase_panel if row["delta"] == delta]
        same_state_phase_dependence[str(delta)] = len({row["suffix_raw_sha256"] for row in rows})
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.master_temporal_regimes.v1",
        "question": "Does a fixed stored master state select a repeatable temporal regime independently of absolute clock, and where is that regime expressed remotely?",
        "fixed_clock_state_panel": fixed_phase,
        "clock_leak_control_panel": phase_panel,
        "remote_expression_port_census": remote,
        "summary": {"distinct_fixed_clock_state_signatures": len(fixed_signatures),
                    "same_state_signature_counts_across_phases": same_state_phase_dependence,
                    "fixed_clock_periods": {str(row["delta"]): row["raw_period_suffix"] for row in fixed_phase},
                    "remote_ports_with_three_state_signatures": sum(row["distinct_state_signatures"] == 3 for row in remote["selected_ports"])},
        "claim_guard": "Master-dependent repeatable temporal signatures are not resonance. Resonance additionally requires a second freely evolving organization whose dynamics are causally changed by local coupling.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_LANDSCAPE_L02_MASTER_TEMPORAL_REGIMES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
