#!/usr/bin/env python3
"""Place a free-running native receiver on master-dependent remote trajectories."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB

P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def put_transducer(raw, clock, c, n, state_base):
    q = c; qp = add(q, P, 1, n)
    put(raw, clock, q, state_base, 7, P, 1, 11)
    specs = ((add(qp, S1, -1, n), S1, 11), (add(qp, S2, -1, n), S2, 13),
             (add(q, N1, -2, n), N1, 17), (add(q, N2, -2, n), N2, 19))
    sources = []
    for index, (position, direction, sreg) in enumerate(specs):
        put(raw, clock, position, state_base + 100 + index, sreg, direction, 4, 100 + index)
        sources.append((position, int(raw[position])))
    return {"q": q, "qp": qp, "sources": sources}


def build(kernel, offset, a_mode, n=29):
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3
    a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    if a_mode != "absent":
        if a_mode != "no_master":
            delta = int(a_mode.split("_")[-1])
            put(raw, clock, a, 1000, 100 + delta, semantic=1, phase=260)
            put(raw, clock, b, 2000, 100, semantic=1, phase=260)
            for index, rel in enumerate(PA): put(raw, clock, add(a, rel, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
            for index, rel in enumerate(PB): put(raw, clock, add(b, rel, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
        organ_a = put_transducer(raw, clock, c, n, 1)
    else:
        organ_a = None
    q_b = add(c, offset, 1, n)
    organ_b = put_transducer(raw, clock, q_b, n, 9000)
    return NativeWorld(kernel, raw, clock), {"n": n, "c_a": c, "a": a, "b": b,
        "organ_a": organ_a, "organ_b": organ_b, "q_b": q_b, "qp_b": add(q_b, P, 1, n),
        "offset": list(offset), "a_mode": a_mode}


def minimal_period(sequence, maximum=64):
    for period in range(1, min(maximum, len(sequence) // 2) + 1):
        if sequence[period:] == sequence[:-period]:
            return period
    return None


def pair_token(world, meta):
    return (int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]]))


def active_site(token):
    q, qp = token
    if q and not qp: return -1
    if qp and not q: return 1
    if q and qp: return 2
    return 0


def run(kernel, offset, a_mode, horizon=512, perturb_tick=None):
    try:
        world, meta = build(kernel, offset, a_mode)
    except RuntimeError as exc:
        return {"offset": list(offset), "a_mode": a_mode, "valid": False, "reason": str(exc)}
    pair_sequence = []; site_sequence = []; a_sequence = []; delta_sequence = []
    b_source_initial = list(meta["organ_b"]["sources"])
    for tick in range(1, horizon + 1):
        world.tick()
        if perturb_tick is not None and tick == perturb_tick:
            for q in (meta["q_b"], meta["qp_b"]):
                world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
        token = pair_token(world, meta); pair_sequence.append(token); site_sequence.append(active_site(token))
        a_record = None if meta["organ_a"] is None else read(world.raw, meta["c_a"])
        a_sequence.append(0 if a_record is None else int(np.sign(a_record["direction"][0])))
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta_sequence.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
    suffix = pair_sequence[horizon // 2:]; site_suffix = site_sequence[horizon // 2:]
    digest = hashlib.sha256()
    for pair in suffix:
        for raw in pair: digest.update(int(raw).to_bytes(8, "little", signed=False))
    a_suffix = a_sequence[horizon // 2:]
    best_lag = None; best_match = -1.0
    for lag in range(-8, 9):
        pairs = [(a_suffix[i], site_suffix[i + lag]) for i in range(max(0, -lag), min(len(a_suffix), len(a_suffix) - lag))]
        informative = [(a, b) for a, b in pairs if a in (-1, 1) and b in (-1, 1)]
        match = 0.0 if not informative else max(sum(a == b for a, b in informative), sum(a == -b for a, b in informative)) / len(informative)
        if match > best_match: best_lag, best_match = lag, match
    source_fixed = all(int(world.raw[q]) == initial for q, initial in b_source_initial)
    return {"offset": list(offset), "a_mode": a_mode, "valid": True, "horizon": horizon,
            "perturb_tick": perturb_tick, "b_pair_period_suffix": minimal_period(suffix),
            "b_active_site_period_suffix": minimal_period(site_suffix),
            "b_pair_suffix_sha256": digest.hexdigest(),
            "b_both_absent_ticks": sum(site == 0 for site in site_sequence),
            "b_both_present_ticks": sum(site == 2 for site in site_sequence),
            "b_source_raw_fixed": source_fixed,
            "a_b_best_phase_lag": best_lag, "a_b_best_binary_phase_match": best_match,
            "master_delta_initial": delta_sequence[0], "master_delta_terminal": delta_sequence[-1],
            "master_delta_unique": sorted({value for value in delta_sequence if value is not None}),
            "samples": [{"tick": tick, "pair": list(pair_sequence[tick - 1]),
                         "active_site": site_sequence[tick - 1], "a_sign": a_sequence[tick - 1],
                         "master_delta": delta_sequence[tick - 1]}
                        for tick in (1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 512, 768, 1024)
                        if tick <= horizon],
            "python_interventions_after_t0": 0 if perturb_tick is None else 1}


def main():
    kernel, runtime = load_kernel(1)
    offsets = ((-2, 3, 4), (-3, 4, 5), (-4, 5, 6), (-5, 6, 7), (-6, 7, 8),
               (-2, -3, 4), (2, 3, 4))
    modes = ("absent", "no_master", "delta_-8", "delta_0", "delta_8")
    rows = [run(kernel, offset, mode) for offset in offsets for mode in modes]
    groups = []
    for offset in offsets:
        subset = [row for row in rows if row["offset"] == list(offset) and row.get("valid")]
        by_mode = {row["a_mode"]: row for row in subset}
        if len(by_mode) != len(modes):
            groups.append({"offset": list(offset), "valid": False}); continue
        state_rows = [by_mode[f"delta_{delta}"] for delta in (-8, 0, 8)]
        free = by_mode["absent"]
        distinct = len({row["b_pair_suffix_sha256"] for row in state_rows})
        coupling = [row["b_pair_suffix_sha256"] != free["b_pair_suffix_sha256"] for row in state_rows]
        survived = all(row["b_source_raw_fixed"] and row["b_both_absent_ticks"] < 16 for row in state_rows)
        group = {"offset": list(offset), "valid": True,
                 "free_period": free["b_pair_period_suffix"],
                 "state_dependent_receiver_signatures": distinct,
                 "state_rows_differ_from_free": coupling,
                 "receiver_survives": survived,
                 "candidate_coupling": distinct >= 2 and any(coupling) and survived,
                 "candidate_entrainment": distinct >= 2 and survived and any(row["b_pair_period_suffix"] != free["b_pair_period_suffix"] for row in state_rows)}
        groups.append(group)
    candidates = [group for group in groups if group.get("candidate_coupling")]
    perturbation_rows = []
    for group in candidates[:2]:
        offset = tuple(group["offset"])
        for mode in ("absent", "delta_-8", "delta_8"):
            perturbation_rows.append(run(kernel, offset, mode, perturb_tick=256))
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.two_organ_coupling_search.v1",
        "question": "Can a spatially separated native receiver's free-running temporal dynamics be changed by locally propagated master-dependent trajectories?",
        "design": {"organ_a": "initial-master-selected temporal transducer", "organ_b": "independent two-site recycle oscillator",
                   "offsets": [list(offset) for offset in offsets], "modes": list(modes), "horizon": 512},
        "rows": rows, "groups": groups, "perturbation_rows": perturbation_rows,
        "summary": {"valid_groups": sum(group.get("valid", False) for group in groups),
                    "coupling_candidate_count": len(candidates),
                    "entrainment_candidate_count": sum(group.get("candidate_entrainment", False) for group in groups),
                    "candidate_offsets": [group["offset"] for group in candidates]},
        "claim_guard": "A changed receiver signature establishes coupling only. Resonance/entrainment requires preserved oscillatory identity, objective locking, perturbation unlock/re-lock, and route-cut controls.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_LANDSCAPE_L03_TWO_ORGAN_COUPLING_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
