#!/usr/bin/env python3
"""Adversarial controls for the period-6 remote receiver candidate."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, read, seal, unpack_scalar, write_json, load_kernel
from run_landscape_l03_two_organ_coupling_search import build, minimal_period


def clear(world, positions):
    for q in positions:
        world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)


def component_token(pair):
    result = []
    for raw in pair:
        if raw == 0:
            result.append((0, 0, (0, 0, 0), 0))
        else:
            record = unpack_scalar(raw)
            result.append((record["state"], record["sreg"], tuple(record["direction"]), record["semantic"]))
    return tuple(result)


def periods(pair_sequence):
    occupancy = [tuple(int(raw != 0) for raw in pair) for pair in pair_sequence]
    records = [component_token(pair) for pair in pair_sequence]
    directions = [tuple(record[2] for record in token) for token in records]
    sregs = [tuple(record[1] for record in token) for token in records]
    states = [tuple(record[0] for record in token) for token in records]
    return {"raw_pair": minimal_period(pair_sequence, 128),
            "occupancy": minimal_period(occupancy, 128),
            "direction": minimal_period(directions, 128),
            "sreg": minimal_period(sregs, 128),
            "state": minimal_period(states, 128)}


def digest_pairs(sequence):
    digest = hashlib.sha256()
    for pair in sequence:
        for raw in pair: digest.update(int(raw).to_bytes(8, "little", signed=False))
    return digest.hexdigest()


def run(kernel, label, offset=(-3, 4, 5), a_mode="delta_-8", source_cuts=(),
        master_ablation_tick=None, receiver_perturb_tick=None, receiver_phase=11, horizon=1536):
    world, meta = build(kernel, offset, a_mode)
    for index in source_cuts:
        clear(world, [meta["organ_a"]["sources"][index][0]])
    world.clock_a[meta["q_b"]] = np.uint64(receiver_phase)
    world.clock_b[meta["q_b"]] = np.uint64(receiver_phase)
    pair_sequence = []; master_deltas = []; a_outputs = []; a_direction_sequence = []
    for tick in range(1, horizon + 1):
        world.tick()
        if master_ablation_tick == tick:
            clear(world, [meta["a"], meta["b"]])
        if receiver_perturb_tick == tick:
            clear(world, [meta["q_b"], meta["qp_b"]])
        pair_sequence.append((int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]])))
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        master_deltas.append(None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"]))
        oa = None if meta["organ_a"] is None else read(world.raw, meta["c_a"])
        a_outputs.append(None if oa is None else {"raw": oa["raw"], "direction": oa["direction"]})
        a_direction_sequence.append((0, 0, 0) if oa is None else tuple(oa["direction"]))
    windows = ((1, 256), (257, 512), (513, 768), (769, 1024), (1025, 1280), (1281, 1536))
    window_rows = []
    for start, end in windows:
        sequence = pair_sequence[start - 1:end]
        a_directions = a_direction_sequence[start - 1:end]
        b_directions = [tuple(component_token(pair)[site][2] for site in (0, 1)) for pair in sequence]
        joint_directions = list(zip(a_directions, b_directions))
        window_rows.append({"start": start, "end": end, "periods": periods(sequence),
                            "a_direction_period": minimal_period(a_directions, 128),
                            "joint_direction_period": minimal_period(joint_directions, 128),
                            "raw_sha256": digest_pairs(sequence),
                            "both_absent_ticks": sum(not a and not b for a, b in sequence),
                            "both_present_ticks": sum(bool(a) and bool(b) for a, b in sequence)})
    return {"label": label, "offset": list(offset), "a_mode": a_mode,
            "source_cuts": list(source_cuts), "master_ablation_tick": master_ablation_tick,
            "receiver_perturb_tick": receiver_perturb_tick, "receiver_phase": receiver_phase,
            "windows": window_rows, "master_delta_initial": master_deltas[0],
            "master_delta_terminal": master_deltas[-1],
            "master_present_after_ablation": all(value is not None for value in master_deltas[(master_ablation_tick or horizon):]) if master_ablation_tick else None,
            "a_output_samples": [{"tick": tick, "record": a_outputs[tick - 1]}
                                 for tick in (1, 256, 512, 513, 514, 768, 1024, 1280, 1536)],
            "receiver_samples": [{"tick": tick, "pair": list(pair_sequence[tick - 1])}
                                 for tick in (1, 2, 3, 4, 256, 510, 511, 512, 513, 514, 515, 516, 520, 528, 544, 576, 640, 768, 1024, 1280, 1536)],
            "python_interventions_after_t0": int(master_ablation_tick is not None) + int(receiver_perturb_tick is not None)}


def main():
    kernel, runtime = load_kernel(1)
    rows = [
        run(kernel, "free_receiver", a_mode="absent"),
        run(kernel, "transducer_without_master", a_mode="no_master"),
        run(kernel, "master_minus8", a_mode="delta_-8"),
        run(kernel, "master_zero", a_mode="delta_0"),
        run(kernel, "master_plus8", a_mode="delta_8"),
        run(kernel, "spatial_sham_plus_x", offset=(3, 4, 5), a_mode="delta_-8"),
    ]
    rows.extend(run(kernel, f"cut_a_source_{index}", a_mode="delta_-8", source_cuts=(index,)) for index in range(4))
    rows.append(run(kernel, "cut_all_a_sources", a_mode="delta_-8", source_cuts=(0, 1, 2, 3)))
    rows.extend(run(kernel, f"receiver_phase_{phase}", a_mode="delta_-8", receiver_phase=phase)
                for phase in (0, 10, 12, 260))
    rows.append(run(kernel, "master_ablation_512", a_mode="delta_-8", master_ablation_tick=512))
    rows.append(run(kernel, "receiver_perturb_512", a_mode="delta_-8", receiver_perturb_tick=512))
    rows.append(run(kernel, "free_receiver_perturb_512", a_mode="absent", receiver_perturb_tick=512))
    by_label = {row["label"]: row for row in rows}
    coupled = by_label["master_minus8"]
    free = by_label["free_receiver"]
    reference_post = by_label["master_minus8"]["windows"][2:]
    perturb_post = by_label["receiver_perturb_512"]["windows"][2:]
    relocked = all(candidate["periods"]["raw_pair"] == reference["periods"]["raw_pair"] and
                   candidate["joint_direction_period"] == reference["joint_direction_period"]
                   for reference, candidate in zip(reference_post, perturb_post))
    state_source_cuts = {str(index): by_label[f"cut_a_source_{index}"]["windows"][-1]["periods"] for index in range(4)}
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.coupling_controls.v1",
        "question": "Is the remote period-6 receiver regime genuine causal entrainment rather than periodic collision or oscillator destruction?",
        "candidate": {"offset": [-3, 4, 5], "free_functional_period": 2, "coupled_exact_raw_period": 6},
        "rows": rows,
        "summary": {"free_terminal_periods": free["windows"][-1]["periods"],
                    "coupled_terminal_periods": coupled["windows"][-1]["periods"],
                    "state_source_cut_terminal_periods": state_source_cuts,
                    "receiver_relocks_to_period6_after_perturbation": relocked,
                    "coupled_joint_direction_periods": [window["joint_direction_period"] for window in coupled["windows"]],
                    "master_ablation_terminal_periods": by_label["master_ablation_512"]["windows"][-1]["periods"],
                    "spatial_sham_terminal_periods": by_label["spatial_sham_plus_x"]["windows"][-1]["periods"]},
        "decision_rule": "Promote entrainment only if the receiver retains an identifiable oscillator, coupling is spatial/source/master dependent, initial receiver phase does not encode the result, and period-6 recurs after a destructive phase perturbation.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_LANDSCAPE_L04_COUPLING_MECHANISM_CONTROLS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
