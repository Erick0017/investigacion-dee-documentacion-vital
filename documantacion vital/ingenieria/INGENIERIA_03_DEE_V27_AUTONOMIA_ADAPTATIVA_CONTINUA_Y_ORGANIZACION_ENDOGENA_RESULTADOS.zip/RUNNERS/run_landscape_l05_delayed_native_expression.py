#!/usr/bin/env python3
"""Temporal-separation test: native write first, delayed source-built interface later."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json
from run_nature_n04_dynamic_temporal_expression import policy_class
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value

P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)


def set_both(world, q, raw, phase):
    if int(world.raw_a[q]) or int(world.raw_b[q]):
        raise RuntimeError(f"overlap {q}")
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(phase); world.clock_b[q] = np.uint64(phase)


def add_delayed_sources(world, meta, source_distance, source_cut=()):
    c = meta["c"]; n = meta["n"]; qp = add(c, P, 1, n)
    specs = ((add(qp, S1, -source_distance, n), S1, 11),
             (add(qp, S2, -source_distance, n), S2, 13),
             (add(c, N1, -source_distance, n), N1, 17),
             (add(c, N2, -source_distance, n), N2, 19))
    sources = []
    for index, (q, direction, sreg) in enumerate(specs):
        if index in source_cut:
            continue
        raw = pack(7000 + index, sreg, direction, 4)
        set_both(world, q, raw, 100 + index); sources.append((q, int(raw)))
    return sources


def run(kernel, target, source_distance, master_intervention=None, generator_mode="treatment",
        source_cut=(), horizon=256):
    world, meta = build_consequence(kernel, target, generator_mode=generator_mode, with_transducer=False, n=41,
                                    memory_phase=252, consequence_distance=6)
    sources = add_delayed_sources(world, meta, source_distance, source_cut)
    deltas = []; outputs = []; transitions = []; previous_delta = None
    first_output_tick = None; first_write_tick = None; intervention_record = None
    for tick in range(1, horizon + 1):
        world.tick()
        if tick == 10 and master_intervention is not None:
            ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
            intervention_record = {"tick": tick, "mode": master_intervention,
                                   "before_delta": None if ra is None or rb is None else ra["sreg"] - rb["sreg"]}
            if master_intervention == "ablate":
                for q in (meta["a"], meta["b"]):
                    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
            elif master_intervention in ("equalize", "invert") and ra is not None and rb is not None:
                a_sreg, b_sreg = ((rb["sreg"], rb["sreg"]) if master_intervention == "equalize" else (rb["sreg"], ra["sreg"]))
                for q, record, sreg in ((meta["a"], ra, a_sreg), (meta["b"], rb, b_sreg)):
                    raw = pack(record["state"], sreg, record["direction"], record["semantic"])
                    world.raw_a[q] = raw; world.raw_b[q] = raw
        delta = delta_value(world, meta); output = read(world.raw, meta["c"])
        if previous_delta is not None and delta != previous_delta:
            transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        if delta not in (None, 0) and first_write_tick is None:
            first_write_tick = tick
        if output is not None and first_output_tick is None:
            first_output_tick = tick
        deltas.append(delta); outputs.append(None if output is None else output["raw"])
        previous_delta = delta
    digest = hashlib.sha256()
    for raw in outputs[31:]:
        digest.update(int(raw or 0).to_bytes(8, "little", signed=False))
    checkpoints = (1, 2, 4, 8, 9, 10, 12, 16, 20, 24, 32, 48, 64, 96, 128, 192, 256)
    return {"target": target, "source_distance": source_distance,
            "master_intervention": master_intervention, "master_intervention_record": intervention_record,
            "generator_mode": generator_mode, "source_cut": list(source_cut),
            "first_write_tick": first_write_tick, "first_output_tick": first_output_tick,
            "stored_without_interface_ticks": None if first_write_tick is None or first_output_tick is None else first_output_tick - first_write_tick,
            "master_transitions": transitions, "terminal_delta": deltas[-1],
            "output_32_256_sha256": digest.hexdigest(),
            "output_samples": [{"tick": tick, "delta": deltas[tick - 1],
                                "raw": outputs[tick - 1],
                                "class": policy_class(None if outputs[tick - 1] is None else unpack_scalar(outputs[tick - 1]))}
                               for tick in checkpoints],
            "sources_fixed_terminal": all(int(world.raw[q]) == raw for q, raw in sources),
            "python_interventions_after_t0": int(master_intervention is not None)}


def main():
    kernel, runtime = load_kernel(1)
    distances = (10, 12, 16, 24)
    rows = [run(kernel, target, distance) for distance in distances for target in ("a", "b", None)]
    groups = []
    for distance in distances:
        subset = [row for row in rows if row["source_distance"] == distance]
        by_target = {str(row["target"]): row for row in subset}
        signatures = {key: row["output_32_256_sha256"] for key, row in by_target.items()}
        groups.append({"source_distance": distance,
                       "opposite_native_writes": by_target["a"]["first_write_tick"] is not None and by_target["b"]["first_write_tick"] is not None and
                                                  by_target["a"]["terminal_delta"] * by_target["b"]["terminal_delta"] < 0,
                       "distinct_later_expression_signatures": len(set(signatures.values())),
                       "signatures": signatures,
                       "stored_intervals": {key: row["stored_without_interface_ticks"] for key, row in by_target.items()},
                       "rw2_discovery_candidate": by_target["a"]["first_write_tick"] is not None and by_target["b"]["first_write_tick"] is not None and
                                                  len(set(signatures.values())) >= 2})
    candidate_distances = [group["source_distance"] for group in groups if group["rw2_discovery_candidate"]]
    controls = []
    if candidate_distances:
        distance = max(candidate_distances)
        controls.extend(run(kernel, target, distance, master_intervention=mode)
                        for target in ("a", "b") for mode in ("ablate", "equalize", "invert"))
        controls.extend(run(kernel, target, distance, generator_mode=mode)
                        for target in ("a", "b") for mode in ("missing_d1", "missing_d2", "wrong_cancel"))
        controls.extend(run(kernel, target, distance, source_cut=(index,)) for target in ("a", "b") for index in range(4))
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.delayed_native_expression.v1",
        "question": "Can a native consequence write a stored relation before a delayed source-built interface later expresses it?",
        "design": {"memory_phase": 252, "consequence_distance": 6, "initial_interface": "absent",
                   "source_distances": list(distances), "source_traffic": "state-independent and complete at t0"},
        "rows": rows, "groups": groups, "controls": controls,
        "summary": {"rw2_discovery_candidate_distances": candidate_distances,
                    "maximum_distinct_later_signatures": max(group["distinct_later_expression_signatures"] for group in groups)},
        "claim_guard": "Hash separation is discovery only. RW2 requires fixed action localization, post-learning master necessity, event/master/expression separation, canaries, freeze, and fresh holdout.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_LANDSCAPE_L05_DELAYED_NATIVE_EXPRESSION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "groups": groups, "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
