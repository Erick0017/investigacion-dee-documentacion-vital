#!/usr/bin/env python3
"""Mechanism-selection panel for the delayed native RW2 candidate in 3D frames."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, canonical_hash, load_kernel, pack, read, seal, transform, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB

P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def build(kernel, target, frame, n=41, source_distance=24):
    permutation, signs = frame; tf = lambda vector: transform(vector, permutation, signs)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; p = tf(P); a = add(c, p, -1, n); b = add(c, p, 1, n)
    learner_positions = []
    put(raw, clock, a, 1000, 100, semantic=1, phase=252); learner_positions.append(a)
    put(raw, clock, b, 2000, 100, semantic=1, phase=252); learner_positions.append(b)
    for index, rel in enumerate(PA):
        q = add(a, tf(rel), 1, n); put(raw, clock, q, 3000 + index, 0, semantic=4, phase=31 + index); learner_positions.append(q)
    for index, rel in enumerate(PB):
        q = add(b, tf(rel), 1, n); put(raw, clock, q, 4000 + index, 0, semantic=4, phase=41 + index); learner_positions.append(q)
    environment_positions = []
    if target in ("a", "b"):
        target_q = a if target == "a" else b
        event = add(target_q, tf((0, -1, 0)), 1, n); route = tf((0, 0, 1))
        generator = add(event, route, -6, n)
        for index, d in enumerate((tf((1, 0, 1)), tf((-1, 0, 1)))):
            q = add(generator, d, -1, n); put(raw, clock, q, 5001 + index, 3, d, 1, 0); environment_positions.append(q)
    qp = add(c, p, 1, n)
    specs = ((add(qp, tf(S1), -source_distance, n), tf(S1), 11),
             (add(qp, tf(S2), -source_distance, n), tf(S2), 13),
             (add(c, tf(N1), -source_distance, n), tf(N1), 17),
             (add(c, tf(N2), -source_distance, n), tf(N2), 19))
    sources = []
    for index, (q, direction, sreg) in enumerate(specs):
        put(raw, clock, q, 7000 + index, sreg, direction, 4, 100 + index)
        learner_positions.append(q); sources.append((q, int(raw[q])))
    learner_state = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in sorted(set(learner_positions))]
    environment_state = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in sorted(set(environment_positions))]
    meta = {"n": n, "c": c, "a": a, "b": b, "p": p, "target": target,
            "sources": sources, "learner_t0_hash": canonical_hash(learner_state),
            "environment_t0_hash": canonical_hash(environment_state),
            "frame": {"permutation": list(permutation), "signs": list(signs)}}
    return NativeWorld(kernel, raw, clock), meta


def projection(direction, p):
    value = sum(int(x) * int(y) for x, y in zip(direction, p))
    return -1 if value < 0 else (1 if value > 0 else 0)


def run_case(kernel, target, frame, horizon=256):
    try:
        world, meta = build(kernel, target, frame)
    except RuntimeError as exc:
        return {"target": target, "frame": {"permutation": list(frame[0]), "signs": list(frame[1])},
                "valid": False, "reason": str(exc)}
    first_write = None; first_output = None; delta = None; output = None
    trajectory = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        output = read(world.raw, meta["c"])
        if delta not in (None, 0) and first_write is None: first_write = tick
        if output is not None and first_output is None: first_output = tick
        if tick >= 24:
            trajectory.update(int(0 if output is None else output["raw"]).to_bytes(8, "little", signed=False))
    action = None if output is None else projection(output["direction"], meta["p"])
    expected = {"a": -1, "b": 1, None: 0}[target]
    return {"target": target, "frame": meta["frame"], "valid": True,
            "learner_t0_hash": meta["learner_t0_hash"], "environment_t0_hash": meta["environment_t0_hash"],
            "first_write_tick": first_write, "first_output_tick": first_output,
            "terminal_delta": delta, "action_tick256": action, "expected_action": expected,
            "passed": action == expected and ((target is None and delta == 0) or (target == "a" and delta > 0) or (target == "b" and delta < 0)),
            "trajectory_24_256_sha256": trajectory.hexdigest(),
            "sources_fixed": all(int(world.raw[q]) == raw for q, raw in meta["sources"]),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    frames = [
        ((0, 1, 2), (1, 1, 1)), ((0, 2, 1), (-1, 1, 1)),
        ((1, 0, 2), (1, -1, 1)), ((1, 2, 0), (-1, -1, 1)),
        ((2, 0, 1), (1, 1, -1)), ((2, 1, 0), (-1, 1, -1)),
        ((0, 1, 2), (1, -1, -1)), ((2, 1, 0), (-1, -1, -1)),
    ]
    rows = [run_case(kernel, target, frame) for frame in frames for target in ("a", "b", None)]
    groups = []
    for frame in frames:
        frame_value = {"permutation": list(frame[0]), "signs": list(frame[1])}
        subset = [row for row in rows if row["frame"] == frame_value]
        valid = len(subset) == 3 and all(row.get("valid") for row in subset)
        groups.append({"frame": frame_value, "valid": valid,
                       "learner_identity_across_counterfactuals": valid and len({row["learner_t0_hash"] for row in subset}) == 1,
                       "actions": {str(row["target"]): row.get("action_tick256") for row in subset},
                       "all_passed": valid and all(row["passed"] for row in subset)})
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.rw2_geometry_mechanism_selection.v1",
        "question": "Does the delayed native consequence-to-expression chain follow relative 3D geometry across signed/permuted frames?",
        "frozen_candidate_parameters": {"n": 41, "memory_phase": 252, "consequence_distance": 6,
                                        "source_distance": 24, "output_tick": 256,
                                        "action_decoder": "sign of output direction projected onto transformed relational axis P"},
        "rows": rows, "groups": groups,
        "summary": {"valid_groups": sum(group["valid"] for group in groups),
                    "groups_with_identical_counterfactual_learners": sum(group["learner_identity_across_counterfactuals"] for group in groups),
                    "groups_passing_exact_three_class_decoder": sum(group["all_passed"] for group in groups),
                    "total_groups": len(groups)},
        "python_role": "PYTHON_ARCHITECTURE_SEARCH before freeze; tick/log only after each t0",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_LANDSCAPE_L06_RW2_GEOMETRY_MECHANISM_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
