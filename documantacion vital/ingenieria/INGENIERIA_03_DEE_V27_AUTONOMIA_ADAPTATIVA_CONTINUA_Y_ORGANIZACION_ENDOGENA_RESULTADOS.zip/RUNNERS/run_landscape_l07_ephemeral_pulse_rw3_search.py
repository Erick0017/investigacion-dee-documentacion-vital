#!/usr/bin/env python3
"""Search three write/expression cycles using finite native expression pulses."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, canonical_hash, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB, policy_class

P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)
WRITE_DISTANCES = (6, 18, 30)
PULSE_DISTANCES = (12, 24, 36)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def build(kernel, sequence, mode="treatment", n=41):
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; a = add(c, P, -1, n); b = add(c, P, 1, n)
    learner_positions = []
    put(raw, clock, a, 1000, 100, semantic=1, phase=252); learner_positions.append(a)
    put(raw, clock, b, 2000, 100, semantic=1, phase=252); learner_positions.append(b)
    for index, rel in enumerate(PA):
        q = add(a, rel, 1, n); put(raw, clock, q, 3000 + index, 0, semantic=4, phase=31 + index); learner_positions.append(q)
    for index, rel in enumerate(PB):
        q = add(b, rel, 1, n); put(raw, clock, q, 4000 + index, 0, semantic=4, phase=41 + index); learner_positions.append(q)
    environment_positions = []
    if mode != "no_consequence":
        for event_index, (target_name, distance) in enumerate(zip(sequence, WRITE_DISTANCES)):
            if mode == f"remove_write_{event_index}":
                continue
            target = a if target_name == "a" else b
            event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1)
            generator = add(event, route, -distance, n)
            for branch, direction in enumerate(((1, 0, 1), (-1, 0, 1))):
                q = add(generator, direction, -1, n)
                put(raw, clock, q, 5000 + 10 * event_index + branch, 3, direction, 1, 0)
                environment_positions.append(q)
    pulse_positions = []
    specs = ((add(c, P, 1, n), S1, 11), (add(c, P, 1, n), S2, 13),
             (c, N1, 17), (c, N2, 19))
    for pulse_index, distance in enumerate(PULSE_DISTANCES):
        if mode == f"remove_pulse_{pulse_index}":
            continue
        for branch, (destination, direction, sreg) in enumerate(specs):
            q = add(destination, direction, -distance, n)
            put(raw, clock, q, 1, sreg, direction, 1, 100 + pulse_index)
            learner_positions.append(q); pulse_positions.append(q)
    learner_state = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in sorted(set(learner_positions))]
    environment_state = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in sorted(set(environment_positions))]
    return NativeWorld(kernel, raw, clock), {"n": n, "c": c, "a": a, "b": b,
        "sequence": sequence, "mode": mode, "pulse_positions": pulse_positions,
        "learner_t0_hash": canonical_hash(learner_state), "environment_t0_hash": canonical_hash(environment_state)}


def run(kernel, sequence, mode="treatment", horizon=128):
    try:
        world, meta = build(kernel, sequence, mode)
    except RuntimeError as exc:
        return {"sequence": sequence, "mode": mode, "valid": False, "reason": str(exc)}
    previous_delta = None; transitions = []; trace = []; absent_ticks = []
    output_raws = []; output_classes = []
    sample_ticks = set(range(1, 42)) | {48, 64, 80, 96, 112, 128}
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        output = read(world.raw, meta["c"]); cls = policy_class(output)
        output_raws.append(0 if output is None else output["raw"]); output_classes.append(cls)
        if output is None: absent_ticks.append(tick)
        if previous_delta is not None and delta != previous_delta:
            transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        if tick in sample_ticks:
            trace.append({"tick": tick, "delta": delta, "output": output, "class": cls})
        previous_delta = delta
    digest = hashlib.sha256()
    for raw in output_raws: digest.update(int(raw).to_bytes(8, "little", signed=False))
    pulse_windows = []
    for pulse_tick in PULSE_DISTANCES:
        indices = range(pulse_tick - 1, min(horizon, pulse_tick + 5))
        pulse_windows.append({"nominal_tick": pulse_tick,
                              "delta_classes": [{"tick": index + 1,
                                                 "class": output_classes[index],
                                                 "raw": output_raws[index]} for index in indices]})
    return {"sequence": sequence, "mode": mode, "valid": True,
            "learner_t0_hash": meta["learner_t0_hash"], "environment_t0_hash": meta["environment_t0_hash"],
            "master_transitions": transitions, "terminal_delta": previous_delta,
            "absent_tick_count": len(absent_ticks), "absent_ticks_1_48": [tick for tick in absent_ticks if tick <= 48],
            "pulse_windows": pulse_windows, "trace": trace,
            "output_1_128_sha256": digest.hexdigest(),
            "remaining_initial_pulse_voxels": sum(int(world.raw[q]) != 0 for q in meta["pulse_positions"]),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    sequences = ("abb", "baa")
    rows = [run(kernel, sequence) for sequence in sequences]
    rows.append(run(kernel, "abb", mode="no_consequence"))
    for index in range(3):
        rows.append(run(kernel, "abb", mode=f"remove_write_{index}"))
        rows.append(run(kernel, "abb", mode=f"remove_pulse_{index}"))
    treatments = [row for row in rows if row["mode"] == "treatment"]
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.ephemeral_pulse_rw3_search.v1",
        "question": "Can finite native expression pulses alternate with three consequence-driven writes in one uninterrupted world?",
        "design": {"write_distances": list(WRITE_DISTANCES), "nominal_write_ticks": [9, 21, 33],
                   "pulse_distances": list(PULSE_DISTANCES), "pulse_ticks": list(PULSE_DISTANCES),
                   "all_components_present_at_t0": True, "resource_class": "finite preloaded pulse stock"},
        "rows": rows,
        "summary": {"valid_treatments": sum(row.get("valid", False) for row in treatments),
                    "treatment_transition_counts": {row["sequence"]: len(row["master_transitions"]) for row in treatments if row.get("valid")},
                    "treatment_absent_ticks_1_48": {row["sequence"]: row["absent_ticks_1_48"] for row in treatments if row.get("valid")},
                    "three_write_candidates": [row["sequence"] for row in treatments if len(row.get("master_transitions", [])) >= 3]},
        "claim_guard": "Even a positive result is finite-stock RW3 at most. RW4 requires native regeneration/recycling rather than one preloaded pulse set per expression.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_LANDSCAPE_L07_EPHEMERAL_PULSE_RW3_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
