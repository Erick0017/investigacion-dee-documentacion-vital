#!/usr/bin/env python3
"""Generate and execute the frozen RW2 fresh signed/permuted-frame holdout."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
from run_landscape_l06_rw2_geometry_mechanism_selection import run_case

LOCK = ROOT / "FREEZE/ING03_CAUSAL_LANDSCAPE_RW2_LOCK.json"
EXCLUDED = {
    ((0, 1, 2), (1, 1, 1)), ((0, 2, 1), (-1, 1, 1)),
    ((1, 0, 2), (1, -1, 1)), ((1, 2, 0), (-1, -1, 1)),
    ((2, 0, 1), (1, 1, -1)), ((2, 1, 0), (-1, 1, -1)),
    ((0, 1, 2), (1, -1, -1)), ((2, 1, 0), (-1, -1, -1)),
}


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def main():
    lock = json.loads(LOCK.read_text(encoding="utf-8"))
    if lock["status"] != "FROZEN_BEFORE_FRESH_GENERATION" or not lock["post_holdout_tuning_forbidden"]:
        raise RuntimeError("invalid freeze lock")
    salt = lock["fresh_generation"]["salt"]
    all_frames = [(permutation, signs) for permutation in itertools.permutations((0, 1, 2))
                  for signs in itertools.product((-1, 1), repeat=3)]
    available = [frame for frame in all_frames if frame not in EXCLUDED]
    available.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True, separators=(",", ":")) + salt).encode()).hexdigest())
    frames = available[:lock["fresh_generation"]["fresh_frame_count"]]
    challenge = seal({
        "schema": "dee.v27.ing03.causal_landscape.rw2_fresh_challenges.v1",
        "lock_id": lock["lock_id"], "freeze_lock_sha256": sha256_file(LOCK),
        "generation_algorithm": lock["fresh_generation"]["algorithm"], "salt": salt,
        "mechanism_selection_frames_excluded": [frame_json(frame) for frame in sorted(EXCLUDED)],
        "challenges": [{"challenge_id": f"RW2CF{index:02d}", "frame": frame_json(frame),
                        "conditions": ["a", "b", "sham"]}
                       for index, frame in enumerate(frames, 1)],
        "outcomes_absent_at_generation": True,
    })
    challenge_path = ROOT / "HOLDOUT/ING03_CAUSAL_LANDSCAPE_RW2_CHALLENGES.json"
    write_json(challenge_path, challenge)

    kernel, runtime = load_kernel(1)
    rows = []
    for index, frame in enumerate(frames, 1):
        for condition in ("a", "b", None):
            row = run_case(kernel, condition, frame)
            row["challenge_id"] = f"RW2CF{index:02d}"; rows.append(row)
    groups = []
    for index, frame in enumerate(frames, 1):
        cid = f"RW2CF{index:02d}"; subset = [row for row in rows if row["challenge_id"] == cid]
        valid = len(subset) == 3 and all(row.get("valid") for row in subset)
        groups.append({"challenge_id": cid, "frame": frame_json(frame), "valid": valid,
                       "learner_t0_identical": valid and len({row["learner_t0_hash"] for row in subset}) == 1,
                       "environment_t0_distinct": valid and len({row["environment_t0_hash"] for row in subset}) == 3,
                       "actions": {str(row["target"]): row.get("action_tick256") for row in subset},
                       "passed": valid and len({row["learner_t0_hash"] for row in subset}) == 1 and all(row["passed"] for row in subset)})
    result = seal({
        "schema": "dee.v27.ing03.causal_landscape.rw2_fresh_holdout.v1",
        "lock_id": lock["lock_id"], "freeze_lock_sha256": sha256_file(LOCK),
        "challenge_artifact": str(challenge_path.relative_to(ROOT)).replace("\\", "/"),
        "challenge_content_sha256": challenge["content_sha256"],
        "rows": rows, "groups": groups,
        "summary": {"fresh_frames": len(groups), "fresh_worlds": len(rows),
                    "valid_groups": sum(group["valid"] for group in groups),
                    "learner_identity_groups": sum(group["learner_t0_identical"] for group in groups),
                    "passed_groups": sum(group["passed"] for group in groups),
                    "all_passed": all(group["passed"] for group in groups)},
        "post_freeze_tuning": False,
        "python_role": "challenge generation after freeze, then tick/log only after each t0",
        "runtime": runtime,
    })
    output = ROOT / "HOLDOUT/ING03_CAUSAL_LANDSCAPE_RW2_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
