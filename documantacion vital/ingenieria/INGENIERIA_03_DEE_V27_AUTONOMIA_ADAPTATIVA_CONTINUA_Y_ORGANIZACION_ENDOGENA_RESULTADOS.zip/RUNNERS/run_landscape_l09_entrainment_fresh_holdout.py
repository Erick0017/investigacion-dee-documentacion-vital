#!/usr/bin/env python3
"""Fresh signed/permuted-frame holdout for configured two-organ entrainment."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, sha256_file, transform, unpack_scalar, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_landscape_l03_two_organ_coupling_search import minimal_period

LOCK = ROOT / "FREEZE/ING03_CAUSAL_LANDSCAPE_ENTRAINMENT_LOCK.json"
P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def put_transducer(raw, clock, c, n, tf, base):
    p = tf(P); qp = add(c, p, 1, n)
    put(raw, clock, c, base, 7, p, 1, 11)
    specs = ((add(qp, tf(S1), -1, n), tf(S1), 11), (add(qp, tf(S2), -1, n), tf(S2), 13),
             (add(c, tf(N1), -2, n), tf(N1), 17), (add(c, tf(N2), -2, n), tf(N2), 19))
    sources = []
    for index, (q, direction, sreg) in enumerate(specs):
        put(raw, clock, q, base + 100 + index, sreg, direction, 4, 100 + index); sources.append((q, int(raw[q])))
    return {"q": c, "qp": qp, "sources": sources}


def build(kernel, frame, condition, n=29):
    permutation, signs = frame; tf = lambda v: transform(v, permutation, signs)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw); c = (n // 2,) * 3
    organ_a = None
    if condition != "free_receiver":
        if condition != "transducer_without_master":
            p = tf(P); a = add(c, p, -1, n); b = add(c, p, 1, n)
            put(raw, clock, a, 1000, 92, semantic=1, phase=260); put(raw, clock, b, 2000, 100, semantic=1, phase=260)
            for index, rel in enumerate(PA): put(raw, clock, add(a, tf(rel), 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
            for index, rel in enumerate(PB): put(raw, clock, add(b, tf(rel), 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
        organ_a = put_transducer(raw, clock, c, n, tf, 1)
    offset = tf((3, 4, 5)) if condition == "spatial_sham" else tf((-3, 4, 5))
    q_b = add(c, offset, 1, n); organ_b = put_transducer(raw, clock, q_b, n, tf, 9000)
    return NativeWorld(kernel, raw, clock), {"c": c, "organ_a": organ_a, "organ_b": organ_b, "p": tf(P),
        "sources": ([] if organ_a is None else organ_a["sources"]) + organ_b["sources"]}


def pair_components(pair):
    records = []
    for raw in pair:
        if raw == 0: records.append((0, 0, (0, 0, 0), 0))
        else:
            r = unpack_scalar(raw); records.append((r["state"], r["sreg"], tuple(r["direction"]), r["semantic"]))
    return tuple(records)


def metrics(pair_sequence, a_directions):
    occupancy = [tuple(int(raw != 0) for raw in pair) for pair in pair_sequence]
    components = [pair_components(pair) for pair in pair_sequence]
    directions = [tuple(record[2] for record in pair) for pair in components]
    sregs = [tuple(record[1] for record in pair) for pair in components]
    states = [tuple(record[0] for record in pair) for pair in components]
    joint = list(zip(a_directions, directions))
    return {"raw_pair": minimal_period(pair_sequence, 128), "occupancy": minimal_period(occupancy, 128),
            "direction": minimal_period(directions, 128), "sreg": minimal_period(sregs, 128),
            "state": minimal_period(states, 128), "joint_direction": minimal_period(joint, 128)}


def run_case(kernel, frame, condition, horizon=1536):
    try: world, meta = build(kernel, frame, condition)
    except RuntimeError as exc: return {"condition": condition, "valid": False, "reason": str(exc)}
    pairs = []; a_directions = []
    for _ in range(horizon):
        world.tick(); pairs.append((int(world.raw[meta["organ_b"]["q"]]), int(world.raw[meta["organ_b"]["qp"]])))
        oa = None if meta["organ_a"] is None else read(world.raw, meta["c"])
        a_directions.append((0, 0, 0) if oa is None else tuple(oa["direction"]))
    terminal_metrics = metrics(pairs[1280:1536], a_directions[1280:1536])
    if condition == "coupled":
        passed = terminal_metrics == {"raw_pair": 6, "occupancy": 2, "direction": 6, "sreg": 6, "state": 2, "joint_direction": 6}
    else:
        passed = all(terminal_metrics[key] == 2 for key in ("raw_pair", "occupancy", "direction", "sreg", "state"))
    return {"condition": condition, "valid": True, "metrics_1281_1536": terminal_metrics,
            "sources_fixed": all(int(world.raw[q]) == initial for q, initial in meta["sources"]),
            "passed": passed, "python_interventions_after_t0": 0}


def frame_json(frame): return {"permutation": list(frame[0]), "signs": list(frame[1])}


def main():
    lock = json.loads(LOCK.read_text(encoding="utf-8")); salt = lock["fresh_generation"]["salt"]
    identity = ((0, 1, 2), (1, 1, 1))
    frames = [(p, s) for p in itertools.permutations((0, 1, 2)) for s in itertools.product((-1, 1), repeat=3) if (p, s) != identity]
    frames.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True, separators=(",", ":")) + salt).encode()).hexdigest())
    frames = frames[:lock["fresh_generation"]["fresh_frames"]]
    challenge = seal({"schema": "dee.v27.ing03.causal_landscape.entrainment_challenges.v1",
                      "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK),
                      "algorithm": lock["fresh_generation"]["algorithm"], "salt": salt,
                      "challenges": [{"id": f"ENT{index:02d}", "frame": frame_json(frame),
                                      "conditions": lock["fresh_generation"]["conditions"]}
                                     for index, frame in enumerate(frames, 1)],
                      "outcomes_absent_at_generation": True})
    challenge_path = ROOT / "HOLDOUT/ING03_CAUSAL_LANDSCAPE_ENTRAINMENT_CHALLENGES.json"; write_json(challenge_path, challenge)
    kernel, runtime = load_kernel(1); rows = []
    for index, frame in enumerate(frames, 1):
        for condition in lock["fresh_generation"]["conditions"]:
            row = run_case(kernel, frame, condition); row["challenge_id"] = f"ENT{index:02d}"; row["frame"] = frame_json(frame); rows.append(row)
    groups = []
    for index, frame in enumerate(frames, 1):
        cid = f"ENT{index:02d}"; subset = [row for row in rows if row["challenge_id"] == cid]
        groups.append({"challenge_id": cid, "frame": frame_json(frame), "passed": len(subset) == 4 and all(row.get("passed") for row in subset),
                       "metrics": {row["condition"]: row.get("metrics_1281_1536") for row in subset}})
    result = seal({"schema": "dee.v27.ing03.causal_landscape.entrainment_holdout.v1",
                   "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK),
                   "challenge_content_sha256": challenge["content_sha256"], "rows": rows, "groups": groups,
                   "summary": {"fresh_frames": len(groups), "fresh_worlds": len(rows),
                               "passed_groups": sum(group["passed"] for group in groups),
                               "all_passed": all(group["passed"] for group in groups)},
                   "post_freeze_tuning": False,
                   "claim_scope": lock["claim_scope"], "runtime": runtime})
    output = ROOT / "HOLDOUT/ING03_CAUSAL_LANDSCAPE_ENTRAINMENT_HOLDOUT.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
