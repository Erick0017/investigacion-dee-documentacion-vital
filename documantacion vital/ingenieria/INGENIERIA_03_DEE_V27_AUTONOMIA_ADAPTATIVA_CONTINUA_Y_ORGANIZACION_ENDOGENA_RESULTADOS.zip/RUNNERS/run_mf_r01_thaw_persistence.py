#!/usr/bin/env python3
"""Long follow-up of the diagnostic master-thaw pulse.

This run asks whether the known 150-tick clamp merely exposes one competent
writer opportunity or puts the master into a durable writable regime after the
clamp has been released.  Every clamp is a DIAGNOSTIC_INTERVENTION.
"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

CUT_TICK = 184
HORIZON = 1024
DURATIONS = (128, 149, 150, 195)


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def main():
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, reference_meta = build(kernel, "a", expression=False)
    first_difference = {}
    core_offsets = list(product((-1, 0, 1), repeat=3))
    neg_offsets = [(-2, y, z) for y in range(-2, 3) for z in range(-2, 3)]
    candidates = sorted({add(meta["c"], d, 1, meta["n"]) for d in core_offsets + neg_offsets})
    for tick in range(1, CUT_TICK + 1):
        expression.tick(); reference.tick()
        for q in candidates:
            if q not in first_difference and (int(expression.raw[q]) != int(reference.raw[q]) or
                                              int(expression.clock_a[q]) != int(reference.clock_a[q])):
                first_difference[q] = tick
    core = {add(meta["c"], d, 1, meta["n"]) for d in core_offsets}
    changed_neg = {q for q in candidates if int(expression.raw[q]) != int(reference.raw[q]) or
                   int(expression.clock_a[q]) != int(reference.clock_a[q])}
    selected = sorted(core | changed_neg)
    reset.install_writer(reference, reference_meta)
    branches = []
    for duration in DURATIONS:
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        reset.restore_nonlearning_fields(world, reference, meta, selected)
        writer = reset.install_writer(world, meta)
        branches.append({"duration": duration, "world": world, "writer": writer,
                         "previous": delta_value(world, meta), "transitions": [], "samples": []})
    checkpoints = {185, 312, 333, 334, 335, 379, 529, 531, 724, 800, 1024}
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick()
        dt = tick - CUT_TICK
        for branch in branches:
            branch["world"].tick()
            if dt < branch["duration"]:
                reset.restore_nonlearning_fields(branch["world"], reference, meta, selected)
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]:
                branch["transitions"].append({"tick": tick, "dt": dt,
                                              "before": branch["previous"], "after": delta})
            if tick in checkpoints:
                branch["samples"].append({"tick": tick, "dt": dt, "delta": delta,
                                          "remote_pair": pair(branch["world"], meta)})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        post_release = [event for event in branch["transitions"] if event["dt"] >= branch["duration"]]
        later_after_first = branch["transitions"][1:] if len(branch["transitions"]) > 1 else []
        rows.append({
            "pulse_duration_ticks": branch["duration"],
            "restored_voxel_count": len(selected),
            "writer": branch["writer"],
            "post_cut_transitions": branch["transitions"],
            "transition_count": len(branch["transitions"]),
            "write_reopened": bool(branch["transitions"]),
            "multiple_post_cut_writes": bool(later_after_first),
            "post_release_transition_count": len(post_release),
            "samples": branch["samples"],
            "python_interventions_after_t0": branch["duration"],
            "intervention_class": "DIAGNOSTIC_INTERVENTION"
        })
    by = {row["pulse_duration_ticks"]: row for row in rows}
    first_rank = sorted(([tick, list(q)] for q, tick in first_difference.items()), key=lambda item: (item[0], item[1]))
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.thaw_persistence.v1",
        "question": "After the minimum successful diagnostic thaw pulse is released, does competent recurrent writing continue?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON, "durations": list(DURATIONS),
                   "surface": "master core radius1 plus cut-time-divergent causal negative-x face",
                   "restored_voxel_count": len(selected),
                   "known_reference_writer_opportunities": [334, 529, 531, 724]},
        "control_manifold": {"selected_positions": [list(q) for q in selected],
                             "first_difference_rank": first_rank},
        "rows": rows,
        "summary": {"duration_149_reopens": by[149]["write_reopened"],
                    "duration_150_reopens": by[150]["write_reopened"],
                    "duration_150_multiple_writes": by[150]["multiple_post_cut_writes"],
                    "duration_150_post_release_transition_count": by[150]["post_release_transition_count"],
                    "duration_195_multiple_writes": by[195]["multiple_post_cut_writes"],
                    "durable_plasticity_after_release_supported": by[150]["multiple_post_cut_writes"]},
        "claim_guard": "Host-clamped thaw remains diagnostic and does not establish a native trigger, native maintenance, or RW3.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R01_THAW_PERSISTENCE.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
