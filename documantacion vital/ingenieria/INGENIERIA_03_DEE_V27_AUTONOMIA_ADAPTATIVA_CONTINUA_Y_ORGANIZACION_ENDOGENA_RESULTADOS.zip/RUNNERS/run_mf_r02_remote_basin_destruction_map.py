#!/usr/bin/env python3
"""One-shot diagnostic destruction map of the non-overlapping far REMOTE_A basin."""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair, receiver_source_positions

OFFSET = (-6, 7, 8)
RESET_TICK = 512
FOLLOWUP = 256


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def digest_region(world, positions):
    h = hashlib.sha256()
    for q in sorted(positions):
        h.update(int(world.raw[q]).to_bytes(8, "little")); h.update(int(world.clock_a[q]).to_bytes(8, "little"))
    return h.hexdigest()


def clear_positions(world, positions):
    for q in positions:
        world.raw_a[q] = 0; world.raw_b[q] = 0
        world.clock_a[q] = 0; world.clock_b[q] = 0


def copy_positions(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    wa, meta = r10.build(kernel, "a")
    wb, _ = r10.build(kernel, "b")
    ws, _ = r10.build(kernel, None)
    initial, _ = r10.build(kernel, None)
    for _ in range(RESET_TICK): wa.tick(); wb.tick(); ws.tick()
    q, n = meta["q_receiver"], meta["n"]
    r1, r2, r3 = region(q, n, 1), region(q, n, 2), region(q, n, 3)
    shell2 = r2 - r1
    neg_face = {add(q, (-2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)}
    pos_face = {add(q, (2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)}
    apparatus = {meta["q_receiver"], meta["qp_receiver"], *receiver_source_positions(meta)}
    specs = {
        "intact_a": (set(), "none"),
        "clear_observed_pair": ({meta["q_receiver"], meta["qp_receiver"]}, "zero"),
        "clear_receiver_apparatus": (apparatus, "zero"),
        "clear_radius1": (r1, "zero"),
        "clear_radius2": (r2, "zero"),
        "clear_radius3": (r3, "zero"),
        "clear_radius2_shell_only": (shell2, "zero"),
        "clear_radius2_negative_x_face": (neg_face, "zero"),
        "clear_radius2_positive_x_face": (pos_face, "zero"),
        "restore_radius2_to_t0_neutral": (r2, "t0_neutral"),
    }
    branches = []
    for name, (positions, operation) in specs.items():
        world = clone_world(wa)
        before = digest_region(world, r3)
        if operation == "zero": clear_positions(world, positions)
        elif operation == "t0_neutral": copy_positions(world, initial, positions)
        branches.append({"name": name, "world": world, "positions": positions, "operation": operation,
                         "pre_r3_sha256": before, "samples": [{"dt": 0, "pair": pair(world, meta)}]})
    checkpoints = {1, 2, 4, 8, 16, 32, 64, 128, 192, 256}
    for dt in range(1, FOLLOWUP + 1):
        wa.tick(); wb.tick(); ws.tick()
        for branch in branches:
            branch["world"].tick()
            if dt in checkpoints:
                branch["samples"].append({"dt": dt, "pair": pair(branch["world"], meta),
                                          "r3_sha256": digest_region(branch["world"], r3)})
    canonical = {"a": pair(wa, meta), "b": pair(wb, meta), "sham": pair(ws, meta)}
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        suffix = [sample["pair"] for sample in branch["samples"] if sample["dt"] >= 192]
        rows.append({
            "variant": branch["name"], "operation": branch["operation"],
            "affected_voxel_count": len(branch["positions"]),
            "pre_r3_sha256": branch["pre_r3_sha256"],
            "terminal_r3_sha256": digest_region(branch["world"], r3),
            "samples": branch["samples"], "terminal_pair": terminal,
            "terminal_is_a": terminal == canonical["a"],
            "terminal_is_b": terminal == canonical["b"],
            "terminal_is_sham": terminal == canonical["sham"],
            "terminal_pair_fixed_over_last_64_sample_window": bool(suffix) and all(value == suffix[-1] for value in suffix),
            "a_specific_function_lost": terminal != canonical["a"],
            "usefully_neutral_by_sham_pair": terminal == canonical["sham"],
            "python_interventions_after_t0": 0 if branch["name"] == "intact_a" else 1,
            "intervention_class": "NONE" if branch["name"] == "intact_a" else "DIAGNOSTIC_INTERVENTION"
        })
    by = {row["variant"]: row for row in rows}
    lost = [row["variant"] for row in rows if row["a_specific_function_lost"]]
    neutral = [row["variant"] for row in rows if row["usefully_neutral_by_sham_pair"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.remote_basin_destruction_map.v1",
        "question": "Which one-shot receiver-centered transformations destroy the mature far REMOTE_A basin rather than only its observed output pair?",
        "design": {"receiver_offset": list(OFFSET), "reset_tick": RESET_TICK,
                   "followup_ticks": FOLLOWUP, "reference_states": ["a", "b", "sham"],
                   "interventions": list(specs)},
        "canonical_terminal_pairs": canonical,
        "rows": rows,
        "summary": {"intact_remains_a": by["intact_a"]["terminal_is_a"],
                    "a_function_lost_variants": lost,
                    "sham_neutral_variants": neutral,
                    "pair_damage_destroys_basin": by["clear_observed_pair"]["a_specific_function_lost"],
                    "radius1_damage_destroys_basin": by["clear_radius1"]["a_specific_function_lost"],
                    "radius2_damage_destroys_basin": by["clear_radius2"]["a_specific_function_lost"],
                    "radius3_damage_destroys_basin": by["clear_radius3"]["a_specific_function_lost"],
                    "t0_receiver_restore_yields_sham_pair": by["restore_radius2_to_t0_neutral"]["terminal_is_sham"]},
        "claim_guard": "All post-establishment transformations are diagnostic. This map neither supplies a native destructive signal nor proves later B reformation.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R02_REMOTE_BASIN_DESTRUCTION_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
