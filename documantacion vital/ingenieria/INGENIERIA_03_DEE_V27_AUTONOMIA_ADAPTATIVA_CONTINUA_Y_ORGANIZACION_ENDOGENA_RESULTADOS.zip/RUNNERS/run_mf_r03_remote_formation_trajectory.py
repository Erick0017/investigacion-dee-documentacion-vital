#!/usr/bin/env python3
"""Tick-resolved formation history of the far A/B/sham remote basin."""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start

OFFSET = (-6, 7, 8)
HORIZON = 512
CHECKPOINTS = (1, 2, 4, 8, 9, 16, 24, 32, 48, 64, 96, 128, 160, 176, 182, 192, 201, 224, 256, 320, 379, 448, 512)


def region(center, n, radius):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def region_digest(world, positions):
    h = hashlib.sha256()
    for q in positions:
        h.update(int(world.raw[q]).to_bytes(8, "little")); h.update(int(world.clock_a[q]).to_bytes(8, "little"))
    return h.hexdigest()


def rle(values):
    out = []
    for tick, value in enumerate(values, 1):
        if not out or out[-1]["value"] != value:
            out.append({"start_tick": tick, "end_tick": tick, "value": value})
        else:
            out[-1]["end_tick"] = tick
    return out


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    worlds = {}; metas = {}
    for label, target in (("a", "a"), ("b", "b"), ("sham", None)):
        worlds[label], metas[label] = r10.build(kernel, target)
    meta = metas["a"]; positions = region(meta["q_receiver"], meta["n"], 3)
    initial_raw = {label: {q: int(world.raw[q]) for q in positions} for label, world in worlds.items()}
    pair_history = {label: [] for label in worlds}
    first_ab_difference = {}; first_a_sham_difference = {}; first_b_sham_difference = {}
    checkpoints = []
    for tick in range(1, HORIZON + 1):
        for world in worlds.values(): world.tick()
        for label, world in worlds.items(): pair_history[label].append(pair(world, meta))
        for q in positions:
            ra, rb, rs = (int(worlds[label].raw[q]) for label in ("a", "b", "sham"))
            ca, cb, cs = (int(worlds[label].clock_a[q]) for label in ("a", "b", "sham"))
            if q not in first_ab_difference and (ra != rb or ca != cb): first_ab_difference[q] = tick
            if q not in first_a_sham_difference and (ra != rs or ca != cs): first_a_sham_difference[q] = tick
            if q not in first_b_sham_difference and (rb != rs or cb != cs): first_b_sham_difference[q] = tick
        if tick in CHECKPOINTS:
            row = {"tick": tick, "states": {}}
            for label, world in worlds.items():
                changed = sum(int(world.raw[q]) != initial_raw[label][q] for q in positions)
                row["states"][label] = {"pair": pair(world, meta), "r3_sha256": region_digest(world, positions),
                                          "r3_raw_changed_from_t0_count": changed}
            row["a_b_different_r3_voxels"] = sum(
                int(worlds["a"].raw[q]) != int(worlds["b"].raw[q]) or
                int(worlds["a"].clock_a[q]) != int(worlds["b"].clock_a[q]) for q in positions)
            checkpoints.append(row)
    trajectories = {}
    for label in worlds:
        history = [tuple(value) for value in pair_history[label]]
        start = constant_suffix_start(history)
        trajectories[label] = {"terminal_pair": list(history[-1]), "constant_suffix_start": start,
                               "terminal_constant_duration": HORIZON - start + 1,
                               "pair_run_length_encoding": rle(pair_history[label])}
    def ranked(mapping):
        return [{"tick": tick, "q": list(q), "relative_to_receiver": [
                    ((q[i] - meta["q_receiver"][i] + meta["n"] // 2) % meta["n"]) - meta["n"] // 2 for i in range(3)]}
                for q, tick in sorted(mapping.items(), key=lambda item: (item[1], item[0]))]
    pair_first = next((tick for tick, (va, vb) in enumerate(zip(pair_history["a"], pair_history["b"]), 1) if va != vb), None)
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.remote_formation_trajectory.v1",
        "question": "Where and when does the native A/B/sham formation history first diverge and mature into the far remote basin?",
        "design": {"receiver_offset": list(OFFSET), "horizon": HORIZON, "instrumented_radius": 3,
                   "instrumented_voxel_count": len(positions), "checkpoints": list(CHECKPOINTS)},
        "trajectories": trajectories,
        "checkpoints": checkpoints,
        "first_difference_maps": {"a_vs_b": ranked(first_ab_difference),
                                  "a_vs_sham": ranked(first_a_sham_difference),
                                  "b_vs_sham": ranked(first_b_sham_difference)},
        "summary": {"a_b_pair_first_difference_tick": pair_first,
                    "a_b_r3_first_difference_tick": min(first_ab_difference.values()) if first_ab_difference else None,
                    "a_sham_r3_first_difference_tick": min(first_a_sham_difference.values()) if first_a_sham_difference else None,
                    "b_sham_r3_first_difference_tick": min(first_b_sham_difference.values()) if first_b_sham_difference else None,
                    "a_maturation_tick": trajectories["a"]["constant_suffix_start"],
                    "b_maturation_tick": trajectories["b"]["constant_suffix_start"],
                    "sham_maturation_tick": trajectories["sham"]["constant_suffix_start"],
                    "formation_history_is_state_dependent": trajectories["a"]["terminal_pair"] != trajectories["b"]["terminal_pair"]},
        "claim_guard": "Trajectory instrumentation is observational. It identifies candidate formation stages but not their causal sufficiency.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R03_REMOTE_FORMATION_TRAJECTORY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
