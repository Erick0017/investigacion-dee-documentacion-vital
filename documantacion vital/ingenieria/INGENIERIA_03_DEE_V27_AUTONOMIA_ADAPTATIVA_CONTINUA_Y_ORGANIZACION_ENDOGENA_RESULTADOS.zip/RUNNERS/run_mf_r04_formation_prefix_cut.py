#!/usr/bin/env python3
"""Causal cutoff map for the state-dependent prefix that forms the far latch."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair

OFFSET = (-6, 7, 8)
HORIZON = 384
CUT_TICKS = (24, 30, 38, 64, 128, 182, 201)


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    bases = {}; metas = {}
    for target in ("a", "b"):
        bases[target], metas[target] = r10.build(kernel, target)
    branches = []
    intact_history = {target: [] for target in bases}
    checkpoints = {24, 30, 38, 64, 128, 182, 201, 224, 256, 320, 384}
    for tick in range(1, HORIZON + 1):
        for target, world in bases.items():
            world.tick(); intact_history[target].append(pair(world, metas[target]))
            if tick in CUT_TICKS:
                cut = clone_world(world)
                removed = []
                for q in delayed_source_positions(metas[target]):
                    removed.append({"q": list(q), "raw": int(cut.raw[q])}); clear(cut, q)
                branches.append({"target": target, "cut_tick": tick, "world": cut,
                                 "meta": metas[target], "removed": removed,
                                 "samples": [{"tick": tick, "pair": pair(cut, metas[target])}]})
        for branch in branches:
            if branch["cut_tick"] < tick:
                branch["world"].tick()
                if tick in checkpoints:
                    branch["samples"].append({"tick": tick, "pair": pair(branch["world"], branch["meta"])})
    canonical = {target: pair(world, metas[target]) for target, world in bases.items()}
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], branch["meta"])
        suffix = [sample["pair"] for sample in branch["samples"] if sample["tick"] >= 320]
        rows.append({"target": branch["target"], "cut_tick": branch["cut_tick"],
                     "removed_bridge_sources": branch["removed"], "samples": branch["samples"],
                     "terminal_pair": terminal,
                     "terminal_matches_intact_target": terminal == canonical[branch["target"]],
                     "sampled_terminal_fixed_64_plus": bool(suffix) and all(value == suffix[-1] for value in suffix),
                     "python_interventions_after_t0": 1,
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    by_target = {}
    for target in ("a", "b"):
        target_rows = [row for row in rows if row["target"] == target]
        sufficient = [row["cut_tick"] for row in target_rows if row["terminal_matches_intact_target"]]
        by_target[target] = {"cut_results": {str(row["cut_tick"]): row["terminal_matches_intact_target"] for row in target_rows},
                             "earliest_tested_sufficient_prefix_tick": min(sufficient) if sufficient else None}
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.formation_prefix_cut.v1",
        "question": "How much state-dependent bridge history is necessary before the far A/B basin completes autonomously?",
        "design": {"receiver_offset": list(OFFSET), "horizon": HORIZON,
                   "cut_ticks": list(CUT_TICKS), "cut": "all four state-expression bridge sources",
                   "cut_stage_rationale": {"24": "before remote divergence", "30": "first r3 divergence",
                                           "38": "first pair divergence", "182": "B maturation",
                                           "201": "A maturation"}},
        "canonical_terminal_pairs": canonical,
        "rows": rows,
        "summary": by_target,
        "claim_guard": "Bridge cuts are diagnostic. A sufficient prefix does not supply a native replay or native route gate.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R04_FORMATION_PREFIX_CUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
