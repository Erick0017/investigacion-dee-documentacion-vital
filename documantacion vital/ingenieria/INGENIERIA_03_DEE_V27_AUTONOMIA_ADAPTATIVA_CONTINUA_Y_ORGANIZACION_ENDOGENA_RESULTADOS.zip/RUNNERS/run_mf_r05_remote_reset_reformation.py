#!/usr/bin/env python3
"""Diagnostic composition: destroy mature REMOTE_A, then replay a fresh B driver trajectory.

The receiver is never copied from the B reference.  The host-enforced driver
trajectory is explicitly diagnostic; it tests whether a destroyed domain is
receptive to the known 182-tick native formation program.
"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair

OFFSET = (-6, 7, 8)
MATURE_TICK = 512
REPLAY_TICKS = 182
FOLLOWUP = 256


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def zero(world, positions):
    for q in positions:
        world.raw_a[q] = 0; world.raw_b[q] = 0; world.clock_a[q] = 0; world.clock_b[q] = 0


def copy_positions(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    mature_a, meta = r10.build(kernel, "a")
    fresh_b, bmeta = r10.build(kernel, "b")
    fresh_neutral, _ = r10.build(kernel, None)
    for _ in range(MATURE_TICK): mature_a.tick()
    q, n, c = meta["q_receiver"], meta["n"], meta["c"]
    r1, r2 = region(q, n, 1), region(q, n, 2)
    neg_face = {add(q, (-2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)}
    master_r2 = region(c, n, 2)
    driver = set(master_r2) | set(delayed_source_positions(meta)) | set(meta.get("generator_positions", []))
    specs = {
        "intact_a_plus_b_driver_replay": (set(), "none", True),
        "clear_pair_plus_b_driver_replay": ({meta["q_receiver"], meta["qp_receiver"]}, "zero", True),
        "clear_negative_x_face_plus_b_driver_replay": (neg_face, "zero", True),
        "clear_radius1_plus_b_driver_replay": (r1, "zero", True),
        "clear_radius2_plus_b_driver_replay": (r2, "zero", True),
        "restore_radius2_t0_plus_b_driver_replay": (r2, "t0", True),
        "restore_radius2_t0_no_replay": (r2, "t0", False),
    }
    branches = []
    for name, (reset_positions, reset_mode, replay) in specs.items():
        world = clone_world(mature_a)
        if reset_mode == "zero": zero(world, reset_positions)
        elif reset_mode == "t0": copy_positions(world, fresh_neutral, reset_positions)
        if replay: copy_positions(world, fresh_b, driver)
        branches.append({"name": name, "world": world, "reset_positions": reset_positions,
                         "reset_mode": reset_mode, "replay": replay,
                         "samples": [{"phase": "post_reset", "dt": 0, "pair": pair(world, meta)}]})
    checkpoints = {1, 2, 4, 8, 9, 16, 24, 30, 38, 64, 128, 160, 182, 183, 198, 246, 310, 438}
    total = REPLAY_TICKS + FOLLOWUP
    for dt in range(1, total + 1):
        fresh_b.tick()
        for branch in branches:
            branch["world"].tick()
            if branch["replay"] and dt < REPLAY_TICKS:
                copy_positions(branch["world"], fresh_b, driver)
            if dt == REPLAY_TICKS:
                for source in delayed_source_positions(meta): clear(branch["world"], source)
            if dt in checkpoints:
                branch["samples"].append({"phase": "replay" if dt <= REPLAY_TICKS else "released",
                                          "dt": dt, "pair": pair(branch["world"], meta)})
    canonical_b = pair(fresh_b, bmeta)
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        post_release = [sample["pair"] for sample in branch["samples"] if sample["dt"] >= REPLAY_TICKS]
        rows.append({"variant": branch["name"], "reset_mode": branch["reset_mode"],
                     "reset_voxel_count": len(branch["reset_positions"]),
                     "b_driver_replayed": branch["replay"], "driver_voxel_count": len(driver),
                     "driver_replay_ticks": REPLAY_TICKS if branch["replay"] else 0,
                     "samples": branch["samples"], "terminal_pair": terminal,
                     "terminal_is_canonical_b": terminal == canonical_b,
                     "post_release_samples_all_b": bool(post_release) and all(value == canonical_b for value in post_release),
                     "python_interventions_after_t0": (1 if branch["reset_mode"] != "none" else 0) +
                                                      (REPLAY_TICKS if branch["replay"] else 0),
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    by = {row["variant"]: row for row in rows}
    receptive = [row["variant"] for row in rows if row["terminal_is_canonical_b"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.remote_reset_reformation.v1",
        "question": "After mature A is destroyed without copying B into the receiver, can the known fresh B driver history reform canonical REMOTE_B?",
        "design": {"receiver_offset": list(OFFSET), "mature_tick": MATURE_TICK,
                   "driver_replay_ticks": REPLAY_TICKS, "followup_ticks": FOLLOWUP,
                   "driver": "master radius2 plus native consequence generator and four expression bridge sources",
                   "receiver_b_state_never_copied": True},
        "canonical_b_terminal_pair": canonical_b,
        "rows": rows,
        "summary": {"intact_mature_a_resists_b_replay": not by["intact_a_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "receptive_reset_variants": receptive,
                    "pair_clear_enables_b_reformation": by["clear_pair_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "negative_x_face_clear_enables_b_reformation": by["clear_negative_x_face_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "radius1_clear_enables_b_reformation": by["clear_radius1_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "radius2_clear_enables_b_reformation": by["clear_radius2_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "t0_restore_enables_b_reformation": by["restore_radius2_t0_plus_b_driver_replay"]["terminal_is_canonical_b"],
                    "t0_restore_without_replay_fails": not by["restore_radius2_t0_no_replay"]["terminal_is_canonical_b"]},
        "claim_guard": "The B driver history and reset are host-enforced diagnostics. Success would establish causal compatibility, not a native reset/replay cycle or RW3.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R05_REMOTE_RESET_REFORMATION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
