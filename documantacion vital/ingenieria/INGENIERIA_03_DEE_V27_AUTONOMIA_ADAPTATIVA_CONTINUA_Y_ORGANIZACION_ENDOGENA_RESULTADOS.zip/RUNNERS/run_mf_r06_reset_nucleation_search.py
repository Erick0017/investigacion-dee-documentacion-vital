#!/usr/bin/env python3
"""Causally ranked nuclei for an expressive-to-plastic master transition."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions
import run_dd_r02_remote_hold_master_reset as reset

CUT_TICK = 184
HORIZON = 400


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def mismatch_count(world, reference, positions):
    return sum(int(world.raw[q]) != int(reference.raw[q]) or int(world.clock_a[q]) != int(reference.clock_a[q])
               for q in positions)


def main():
    reset.CUT_TICK = CUT_TICK
    kernel, runtime = load_kernel(1)
    expression, meta = build(kernel, "a", expression=True)
    reference, rmeta = build(kernel, "a", expression=False)
    core = {add(meta["c"], d, 1, meta["n"]) for d in product((-1, 0, 1), repeat=3)}
    neg_face_all = {add(meta["c"], (-2, y, z), 1, meta["n"]) for y in range(-2, 3) for z in range(-2, 3)}
    first_difference = {}
    for tick in range(1, CUT_TICK + 1):
        expression.tick(); reference.tick()
        for q in core | neg_face_all:
            if q not in first_difference and (int(expression.raw[q]) != int(reference.raw[q]) or
                                              int(expression.clock_a[q]) != int(reference.clock_a[q])):
                first_difference[q] = tick
    changed_neg = {q for q in neg_face_all if int(expression.raw[q]) != int(reference.raw[q]) or
                   int(expression.clock_a[q]) != int(reference.clock_a[q])}
    surface = sorted(core | changed_neg)
    ranked = [q for q, _ in sorted(first_difference.items(), key=lambda item: (item[1], item[0])) if q in surface]
    wave6 = set(ranked[:6]); earliest_pair = set(ranked[:2]); earliest1 = set(ranked[:1])
    moving_rows = [sorted(q for q in changed_neg if q[1] == (meta["c"][1] + y) % meta["n"]) for y in range(-2, 3)]
    specs = {
        "intact_expressive": {"positions": set(), "duration": 0, "mode": "none"},
        "full_surface_once": {"positions": set(surface), "duration": 1, "mode": "pulse"},
        "full_surface_16": {"positions": set(surface), "duration": 16, "mode": "pulse"},
        "earliest_single_16": {"positions": earliest1, "duration": 16, "mode": "pulse"},
        "earliest_pair_16": {"positions": earliest_pair, "duration": 16, "mode": "pulse"},
        "earliest_wave6_16": {"positions": wave6, "duration": 16, "mode": "pulse"},
        "negative_x_face_16": {"positions": changed_neg, "duration": 16, "mode": "pulse"},
        "core_radius1_16": {"positions": core, "duration": 16, "mode": "pulse"},
        "moving_negative_x_rows": {"positions": changed_neg, "duration": 5, "mode": "moving_rows"},
        "full_surface_150_positive_control": {"positions": set(surface), "duration": 150, "mode": "pulse"},
    }
    reset.install_writer(reference, rmeta)
    branches = []
    for name, spec in specs.items():
        world = clone_world(expression)
        for q in delayed_source_positions(meta): clear(world, q)
        if spec["mode"] == "pulse": reset.restore_nonlearning_fields(world, reference, meta, spec["positions"])
        elif spec["mode"] == "moving_rows" and moving_rows: reset.restore_nonlearning_fields(world, reference, meta, moving_rows[0])
        writer = reset.install_writer(world, meta)
        branches.append({"name": name, "spec": spec, "world": world, "writer": writer,
                         "previous": delta_value(world, meta), "transitions": [], "samples": []})
    checkpoints = {1, 2, 4, 8, 16, 32, 64, 96, 128, 149, 150, 151, 200, 216}
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        reference.tick(); dt = tick - CUT_TICK
        for branch in branches:
            branch["world"].tick(); spec = branch["spec"]
            if spec["mode"] == "pulse" and dt < spec["duration"]:
                reset.restore_nonlearning_fields(branch["world"], reference, meta, spec["positions"])
            elif spec["mode"] == "moving_rows" and dt < len(moving_rows):
                reset.restore_nonlearning_fields(branch["world"], reference, meta, moving_rows[dt])
            delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]:
                branch["transitions"].append({"tick": tick, "dt": dt,
                                              "before": branch["previous"], "after": delta})
            if dt in checkpoints:
                branch["samples"].append({"dt": dt, "master_delta": delta,
                                          "surface_mismatch_to_plastic_reference": mismatch_count(branch["world"], reference, surface)})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        spec = branch["spec"]
        post_release = [sample["surface_mismatch_to_plastic_reference"] for sample in branch["samples"]
                        if sample["dt"] >= spec["duration"]]
        rows.append({"variant": branch["name"], "motif_mode": spec["mode"],
                     "motif_voxel_count": len(spec["positions"]), "pulse_duration_ticks": spec["duration"],
                     "writer": branch["writer"], "post_cut_transitions": branch["transitions"],
                     "write_reopened": bool(branch["transitions"]), "samples": branch["samples"],
                     "minimum_post_release_surface_mismatch": min(post_release) if post_release else None,
                     "terminal_surface_mismatch": mismatch_count(branch["world"], reference, surface),
                     "python_interventions_after_t0": spec["duration"] if spec["mode"] == "pulse" else len(moving_rows),
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    by = {row["variant"]: row for row in rows}
    nuclei = [row["variant"] for row in rows if row["write_reopened"] and row["variant"] != "full_surface_150_positive_control"]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.reset_nucleation_search.v1",
        "question": "Can a causally ranked compact seed launch a self-propagating expressive-to-plastic master transition?",
        "design": {"cut_tick": CUT_TICK, "horizon": HORIZON, "surface_voxel_count": len(surface),
                   "negative_x_changed_voxel_count": len(changed_neg),
                   "motifs": list(specs), "brute_force_subsets": False},
        "ranked_control_sites": [{"q": list(q), "first_difference_tick": first_difference.get(q)} for q in ranked],
        "rows": rows,
        "summary": {"native_nucleus_candidates": nuclei,
                    "any_compact_nucleus_reopens": bool(nuclei),
                    "moving_seed_reopens": by["moving_negative_x_rows"]["write_reopened"],
                    "full_16_reopens": by["full_surface_16"]["write_reopened"],
                    "full_150_positive_control_reopens": by["full_surface_150_positive_control"]["write_reopened"],
                    "small_seed_launches_convergent_front": any(
                        row["minimum_post_release_surface_mismatch"] == 0 for row in rows
                        if row["variant"] not in ("intact_expressive", "full_surface_150_positive_control"))},
        "claim_guard": "Every seed is host-applied diagnostic intervention. A null is bounded to the ranked motifs, durations, geometry, and writer opportunity tested.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R06_RESET_NUCLEATION_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
