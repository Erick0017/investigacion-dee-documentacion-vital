#!/usr/bin/env python3
"""Adaptive screen for lower-hysteresis receiver organizations with retained hold."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, pack, seal, unpack_scalar, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair, receiver_source_positions

OFFSET = (-6, 7, 8)
ESTABLISH = 512
SCREEN_HOLD = 256
VARIANTS = ("baseline", "tangential_support_only", "normal_support_only",
            "finite_semantic1_support", "low_core_sreg3")


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def set_raw_both(world, q, raw):
    world.raw_a[q] = raw; world.raw_b[q] = raw


def configure(world, meta, variant):
    sources = receiver_source_positions(meta)
    if variant == "tangential_support_only":
        for q in sources[2:]: clear(world, q)
    elif variant == "normal_support_only":
        for q in sources[:2]: clear(world, q)
    elif variant == "finite_semantic1_support":
        for q in sources:
            item = unpack_scalar(world.raw[q])
            set_raw_both(world, q, pack(item["state"], item["sreg"], item["direction"], 1))
    elif variant == "low_core_sreg3":
        q = meta["q_receiver"]; item = unpack_scalar(world.raw[q])
        set_raw_both(world, q, pack(item["state"], 3, item["direction"], item["semantic"]))
    elif variant != "baseline":
        raise ValueError(variant)
    return {"variant": variant, "receiver_source_positions": [list(q) for q in sources]}


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    established = []
    for variant in VARIANTS:
        for target in ("a", "b"):
            world, meta = r10.build(kernel, target)
            config = configure(world, meta, variant)
            history = []
            for _ in range(ESTABLISH): world.tick(); history.append(pair(world, meta))
            established.append({"variant": variant, "target": target, "world": world, "meta": meta,
                                "config": config, "pre_cut_pair": pair(world, meta),
                                "establish_suffix_fixed_64": len(history) >= 64 and all(value == history[-1] for value in history[-64:])})
    branches = []
    for item in established:
        world = clone_world(item["world"]); meta = item["meta"]
        removed = {meta["a"], meta["b"], *delayed_source_positions(meta), *receiver_source_positions(meta)}
        for q in removed: clear(world, q)
        branches.append({**item, "world": world, "removed": [list(q) for q in sorted(removed)],
                         "samples": [{"dt": 0, "pair": pair(world, meta)}]})
    checkpoints = {1, 2, 4, 8, 16, 64, 128, 192, 256}
    for dt in range(1, SCREEN_HOLD + 1):
        for branch in branches:
            branch["world"].tick()
            if dt in checkpoints: branch["samples"].append({"dt": dt, "pair": pair(branch["world"], branch["meta"])})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], branch["meta"])
        rows.append({"variant": branch["variant"], "target": branch["target"],
                     "pre_cut_pair": branch["pre_cut_pair"], "terminal_pair": terminal,
                     "a_b_establishment_suffix_fixed_64": branch["establish_suffix_fixed_64"],
                     "hold_samples": branch["samples"],
                     "terminal_equals_pre_cut": terminal == branch["pre_cut_pair"],
                     "all_sampled_pairs_equal_pre_cut": all(sample["pair"] == branch["pre_cut_pair"] for sample in branch["samples"]),
                     "python_interventions_after_t0": 1,
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    groups = []
    for variant in VARIANTS:
        subset = [row for row in rows if row["variant"] == variant]
        by = {row["target"]: row for row in subset}
        groups.append({"variant": variant,
                       "a_b_distinct_after_establishment": by["a"]["pre_cut_pair"] != by["b"]["pre_cut_pair"],
                       "both_fixed_before_cut": all(row["a_b_establishment_suffix_fixed_64"] for row in subset),
                       "both_hold_exact_256_after_cut": all(row["all_sampled_pairs_equal_pre_cut"] for row in subset),
                       "screen_viable": by["a"]["pre_cut_pair"] != by["b"]["pre_cut_pair"] and
                                         all(row["a_b_establishment_suffix_fixed_64"] and row["all_sampled_pairs_equal_pre_cut"] for row in subset),
                       "a_pair": by["a"]["pre_cut_pair"], "b_pair": by["b"]["pre_cut_pair"]})
    viable = [group["variant"] for group in groups if group["screen_viable"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.soft_latch_screen.v1",
        "question": "Can causally different receiver support organizations preserve state separation while reducing structural support and retaining disconnected hold?",
        "design": {"receiver_offset": list(OFFSET), "establish_ticks": ESTABLISH,
                   "disconnected_screen_hold_ticks": SCREEN_HOLD, "variants": list(VARIANTS),
                   "adaptive_rule": "Only variants separating A/B and exactly holding both states advance to the 1024-tick retention/switchability frontier."},
        "rows": rows, "groups": groups,
        "summary": {"screen_viable_variants": viable,
                    "nonbaseline_viable_variants": [name for name in viable if name != "baseline"],
                    "baseline_viable": "baseline" in viable},
        "claim_guard": "This is a 256-tick screen, not the required 1024-tick soft-latch validation. Post-establishment cuts are diagnostic.",
        "runtime": runtime
    })
    output = ROOT / "DISCOVERY/ING03_MF_R07_SOFT_LATCH_SCREEN.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
