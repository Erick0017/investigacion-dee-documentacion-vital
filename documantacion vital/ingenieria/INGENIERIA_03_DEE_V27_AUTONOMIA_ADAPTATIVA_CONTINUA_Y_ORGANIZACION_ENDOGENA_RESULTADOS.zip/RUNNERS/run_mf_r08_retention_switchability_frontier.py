#!/usr/bin/env python3
"""1024-tick retention and diagnostic bidirectional switchability frontier."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, full_sha, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair, receiver_source_positions
from run_mf_r07_soft_latch_screen import configure

OFFSET = (-6, 7, 8)
ESTABLISH = 512
HOLD = 1024
SWITCH_FOLLOWUP = 384
CANDIDATES = ("baseline", "low_core_sreg3")


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def copy_positions(world, reference, positions):
    for q in positions:
        world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
        world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def follow(world, meta, ticks, checkpoints):
    samples = []
    for dt in range(1, ticks + 1):
        world.tick()
        if dt in checkpoints: samples.append({"dt": dt, "pair": pair(world, meta)})
    return samples


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    bases = {}
    for variant in CANDIDATES:
        for target in ("a", "b"):
            world, meta = r10.build(kernel, target); configure(world, meta, variant)
            for _ in range(ESTABLISH): world.tick()
            bases[(variant, target)] = (world, meta)
    equivalence = {}
    for target in ("a", "b"):
        baseline = bases[("baseline", target)][0]; low = bases[("low_core_sreg3", target)][0]
        equivalence[target] = bool(np.array_equal(baseline.raw_a, low.raw_a) and
                                   np.array_equal(baseline.clock_a, low.clock_a))
    active = ["baseline"] if all(equivalence.values()) else list(CANDIDATES)
    retention_rows = []
    hold_checkpoints = {1, 2, 4, 8, 16, 64, 128, 256, 512, 768, 1024}
    for variant in active:
        for target in ("a", "b"):
            base, meta = bases[(variant, target)]; world = clone_world(base); pre = pair(world, meta)
            removed = {meta["a"], meta["b"], *delayed_source_positions(meta), *receiver_source_positions(meta)}
            for q in removed: clear(world, q)
            samples = follow(world, meta, HOLD, hold_checkpoints); terminal = pair(world, meta)
            retention_rows.append({"variant": variant, "target": target, "pre_cut_pair": pre,
                                   "samples": samples, "terminal_pair": terminal,
                                   "terminal_equals_pre_cut": terminal == pre,
                                   "terminal_fixed_last_256_sampled": all(sample["pair"] == terminal for sample in samples if sample["dt"] >= 768),
                                   "disconnected_hold_ticks": HOLD,
                                   "python_interventions_after_t0": 1,
                                   "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    switch_rows = []
    reverse_rows = []
    for variant in active:
        wa, meta = bases[(variant, "a")]; wb, _ = bases[(variant, "b")]
        q, n = meta["q_receiver"], meta["n"]
        r1, r2 = region(q, n, 1), region(q, n, 2)
        specs = {
            "pair": {meta["q_receiver"], meta["qp_receiver"]},
            "apparatus": {meta["q_receiver"], meta["qp_receiver"], *receiver_source_positions(meta)},
            "negative_x_face_r2": {add(q, (-2, y, z), 1, n) for y in range(-2, 3) for z in range(-2, 3)},
            "radius1": r1,
            "radius2": r2,
        }
        for name, positions in specs.items():
            world = clone_world(wa); copy_positions(world, wb, positions)
            samples = follow(world, meta, SWITCH_FOLLOWUP, {1, 2, 4, 8, 16, 64, 128, 192, 256, 320, 384})
            terminal = pair(world, meta); canonical_b = pair(wb, meta)
            switch_rows.append({"variant": variant, "direction": "a_to_b", "perturbation": name,
                                "affected_voxel_count": len(positions), "samples": samples,
                                "terminal_pair": terminal, "terminal_is_target": terminal == canonical_b,
                                "python_interventions_after_t0": 1,
                                "intervention_class": "DIAGNOSTIC_INTERVENTION"})
        successes = [row for row in switch_rows if row["variant"] == variant and row["terminal_is_target"]]
        if successes:
            selected = min(successes, key=lambda row: (row["affected_voxel_count"], row["perturbation"]))
            positions = specs[selected["perturbation"]]
            world = clone_world(wb); copy_positions(world, wa, positions)
            samples = follow(world, meta, SWITCH_FOLLOWUP, {1, 2, 4, 8, 16, 64, 128, 192, 256, 320, 384})
            reverse_rows.append({"variant": variant, "direction": "b_to_a",
                                 "perturbation": selected["perturbation"],
                                 "affected_voxel_count": len(positions), "samples": samples,
                                 "terminal_pair": pair(world, meta),
                                 "terminal_is_target": pair(world, meta) == pair(wa, meta),
                                 "python_interventions_after_t0": 1,
                                 "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    groups = []
    for variant in active:
        holds = [row for row in retention_rows if row["variant"] == variant]
        switches = [row for row in switch_rows if row["variant"] == variant and row["terminal_is_target"]]
        reverse = next((row for row in reverse_rows if row["variant"] == variant), None)
        groups.append({"variant": variant,
                       "both_states_hold_1024": all(row["terminal_equals_pre_cut"] and row["terminal_fixed_last_256_sampled"] for row in holds),
                       "successful_a_to_b_perturbations": [row["perturbation"] for row in switches],
                       "minimum_diagnostic_switch_voxels": min((row["affected_voxel_count"] for row in switches), default=None),
                       "diagnostic_b_to_a_with_minimal_perturbation": None if reverse is None else reverse["terminal_is_target"],
                       "native_smooth_switching_demonstrated": False})
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.retention_switchability_frontier.v1",
        "question": "Which screened receiver organizations combine 1024-tick disconnected retention with low-volume bidirectional switching?",
        "design": {"receiver_offset": list(OFFSET), "establish_ticks": ESTABLISH,
                   "disconnected_hold_ticks": HOLD, "switch_followup_ticks": SWITCH_FOLLOWUP,
                   "candidate_variants": list(CANDIDATES), "active_variants": active,
                   "adaptive_equivalence_rule": "Skip the low-sreg candidate if both mature A/B full raw+clock states exactly equal baseline."},
        "mature_full_state_equivalence_low_sreg3_to_baseline": equivalence,
        "retention_rows": retention_rows, "switch_rows": switch_rows, "reverse_rows": reverse_rows,
        "groups": groups,
        "summary": {"active_variants": active,
                    "all_active_hold_both_states_1024": all(group["both_states_hold_1024"] for group in groups),
                    "any_diagnostic_bidirectional_switch": any(group["diagnostic_b_to_a_with_minimal_perturbation"] is True for group in groups),
                    "any_native_smooth_switch": False},
        "claim_guard": "Basin copying is a diagnostic perturbation, not native switching. This frontier cannot promote a soft latch without a native update trajectory.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R08_RETENTION_SWITCHABILITY_FRONTIER.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "groups": groups,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
