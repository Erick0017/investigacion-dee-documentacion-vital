#!/usr/bin/env python3
"""Diagnostic test of recruiting a fresh second remote after R0 has matured."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair
from run_landscape_l03_two_organ_coupling_search import P, put_transducer

R0_OFFSET = (-6, 7, 8)
CANDIDATE_R1 = ((-6, -7, 8), (-6, 7, -8), (-8, -6, 7))
MATURE = 512
FOLLOWUP = 512
HANDOFF_FOLLOWUP = 256


def receiver_meta(meta, offset):
    q = add(meta["c"], offset, 1, meta["n"])
    return {**meta, "q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"]), "receiver_offset": offset}


def receiver_sites(meta, offset):
    q = add(meta["c"], offset, 1, meta["n"]); qp = add(q, P, 1, meta["n"])
    from run_landscape_l03_two_organ_coupling_search import S1, S2, N1, N2
    return {q, qp, add(qp, S1, -1, meta["n"]), add(qp, S2, -1, meta["n"]),
            add(q, N1, -2, meta["n"]), add(q, N2, -2, meta["n"])}


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def main():
    kernel, runtime = load_kernel(1)
    canonical_rows = []
    canonical_worlds = {}
    for offset in CANDIDATE_R1:
        for target in ("a", "b"):
            r10.OFFSET = offset
            world, meta = r10.build(kernel, target); history = []
            for _ in range(MATURE): world.tick(); history.append(pair(world, meta))
            canonical_worlds[(offset, target)] = (world, meta)
            canonical_rows.append({"offset": list(offset), "target": target,
                                   "terminal_pair": pair(world, meta),
                                   "fixed_last_64": all(value == history[-1] for value in history[-64:]),
                                   "python_interventions_after_t0": 0})
    valid_offsets = []
    for offset in CANDIDATE_R1:
        rows = [row for row in canonical_rows if tuple(row["offset"]) == offset]
        by = {row["target"]: row for row in rows}
        if by["a"]["fixed_last_64"] and by["b"]["fixed_last_64"] and by["a"]["terminal_pair"] != by["b"]["terminal_pair"]:
            valid_offsets.append(offset)
    r10.OFFSET = R0_OFFSET
    mature_r0 = {}
    for target in ("a", "b"):
        world, meta = r10.build(kernel, target)
        for _ in range(MATURE): world.tick()
        mature_r0[target] = (world, meta, pair(world, meta))
    selected = None
    availability = []
    for offset in valid_offsets:
        empty_by_target = {}
        for target in ("a", "b"):
            world, meta, _ = mature_r0[target]
            sites = receiver_sites(meta, offset)
            empty_by_target[target] = all(int(world.raw[q]) == 0 for q in sites)
        availability.append({"offset": list(offset), "empty_receiver_apparatus_sites": empty_by_target})
        if selected is None and all(empty_by_target.values()): selected = offset
    recruitment_rows = []; handoff_rows = []
    if selected is not None:
        for target in ("a", "b"):
            base, meta, r0_pair = mature_r0[target]
            # Mature bases are not reused after this branch; install the fresh R1 apparatus diagnostically.
            q1 = add(meta["c"], selected, 1, meta["n"])
            put_transducer(base.raw_a, base.clock_a, q1, meta["n"], 9000)
            base.raw_b[:] = base.raw_a; base.clock_b[:] = base.clock_a
            r1meta = receiver_meta(meta, selected); samples = []
            for dt in range(1, FOLLOWUP + 1):
                base.tick()
                if dt in (1, 2, 4, 8, 16, 30, 38, 64, 128, 182, 201, 256, 384, 512):
                    samples.append({"dt": dt, "r0_pair": pair(base, meta), "r1_pair": pair(base, r1meta)})
            canonical_r1 = pair(canonical_worlds[(selected, target)][0], canonical_worlds[(selected, target)][1])
            canonical_r0 = r0_pair
            recruited = pair(base, r1meta) == canonical_r1
            recruitment_rows.append({"target": target, "r1_offset": list(selected),
                                     "samples": samples, "r0_terminal_pair": pair(base, meta),
                                     "r0_holds_original_function": pair(base, meta) == canonical_r0,
                                     "r1_terminal_pair": pair(base, r1meta),
                                     "fresh_t0_r1_canonical_pair": canonical_r1,
                                     "late_r1_reaches_fresh_canonical": recruited,
                                     "python_interventions_after_t0": 1,
                                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
            if recruited:
                for q in region(meta["q_receiver"], meta["n"], 2):
                    base.raw_a[q] = 0; base.raw_b[q] = 0; base.clock_a[q] = 0; base.clock_b[q] = 0
                handoff_samples = []
                for dt in range(1, HANDOFF_FOLLOWUP + 1):
                    base.tick()
                    if dt in (1, 2, 4, 8, 16, 64, 128, 256):
                        handoff_samples.append({"dt": dt, "r1_pair": pair(base, r1meta)})
                handoff_rows.append({"target": target, "r1_offset": list(selected),
                                    "diagnostic_r0_radius2_retirement": True,
                                    "r1_terminal_pair": pair(base, r1meta),
                                    "r1_holds_after_r0_retirement": pair(base, r1meta) == canonical_r1,
                                    "samples": handoff_samples,
                                    "python_interventions_after_t0": 2,
                                    "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.generational_remote_recruitment.v1",
        "question": "Can a fresh second compartment installed after R0 maturation be recruited by the mature state-expression regime, and can it hold after diagnostic R0 retirement?",
        "design": {"r0_offset": list(R0_OFFSET), "candidate_r1_offsets": [list(value) for value in CANDIDATE_R1],
                   "mature_tick": MATURE, "late_recruitment_followup_ticks": FOLLOWUP,
                   "adaptive_rule": "Select the first t0-valid A/B-separating R1 whose six apparatus sites are empty in mature R0 A and B worlds."},
        "canonical_r1_rows": canonical_rows, "valid_r1_offsets": [list(value) for value in valid_offsets],
        "mature_site_availability": availability, "selected_r1_offset": None if selected is None else list(selected),
        "recruitment_rows": recruitment_rows, "handoff_rows": handoff_rows,
        "summary": {"valid_fresh_r1_offset_count": len(valid_offsets),
                    "selected_late_install_offset": None if selected is None else list(selected),
                    "late_fresh_r1_recruited_for_both_states": bool(recruitment_rows) and all(row["late_r1_reaches_fresh_canonical"] for row in recruitment_rows),
                    "r0_function_preserved_during_recruitment": bool(recruitment_rows) and all(row["r0_holds_original_function"] for row in recruitment_rows),
                    "diagnostic_handoff_holds_for_both_states": bool(handoff_rows) and len(handoff_rows) == 2 and all(row["r1_holds_after_r0_retirement"] for row in handoff_rows),
                    "native_generation_or_handoff_demonstrated": False},
        "claim_guard": "Late R1 construction and any R0 retirement are diagnostic Python interventions. Even a positive recruitment result would leave native generation, role selection, and bounded reuse unresolved.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R09_GENERATIONAL_REMOTE_RECRUITMENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
