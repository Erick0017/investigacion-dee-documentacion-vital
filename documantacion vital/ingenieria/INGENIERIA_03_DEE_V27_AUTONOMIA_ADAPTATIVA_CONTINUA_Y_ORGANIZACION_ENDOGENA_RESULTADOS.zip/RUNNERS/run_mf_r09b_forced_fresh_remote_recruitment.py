#!/usr/bin/env python3
"""Diagnostic forced creation of a fresh R1 niche in a mature R0 world."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2, put_transducer

R0_OFFSET = (-6, 7, 8)
R1_OFFSET = (-6, -7, 8)
MATURE = 512
FOLLOWUP = 512
HANDOFF_FOLLOWUP = 256


def receiver_meta(meta, offset):
    q = add(meta["c"], offset, 1, meta["n"])
    return {**meta, "q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"]), "receiver_offset": offset}


def receiver_sites(meta, offset):
    q = add(meta["c"], offset, 1, meta["n"]); qp = add(q, P, 1, meta["n"])
    return {q, qp, add(qp, S1, -1, meta["n"]), add(qp, S2, -1, meta["n"]),
            add(q, N1, -2, meta["n"]), add(q, N2, -2, meta["n"])}


def clear(world, q):
    world.raw_a[q] = 0; world.raw_b[q] = 0; world.clock_a[q] = 0; world.clock_b[q] = 0


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def main():
    kernel, runtime = load_kernel(1)
    canonical = {}; rows = []; handoff_rows = []
    for target in ("a", "b"):
        r10.OFFSET = R1_OFFSET
        ref, rmeta = r10.build(kernel, target)
        for _ in range(MATURE): ref.tick()
        canonical[target] = pair(ref, rmeta)
    for target in ("a", "b"):
        r10.OFFSET = R0_OFFSET
        world, meta = r10.build(kernel, target)
        for _ in range(MATURE): world.tick()
        r0_canonical = pair(world, meta)
        sites = receiver_sites(meta, R1_OFFSET)
        occupied = [{"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q])}
                    for q in sorted(sites) if int(world.raw[q]) or int(world.clock_a[q])]
        for q in sites: clear(world, q)
        q1 = add(meta["c"], R1_OFFSET, 1, meta["n"])
        put_transducer(world.raw_a, world.clock_a, q1, meta["n"], 9000)
        world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
        r1meta = receiver_meta(meta, R1_OFFSET); samples = []
        for dt in range(1, FOLLOWUP + 1):
            world.tick()
            if dt in (1, 2, 4, 8, 16, 30, 38, 64, 128, 182, 201, 256, 384, 512):
                samples.append({"dt": dt, "r0_pair": pair(world, meta), "r1_pair": pair(world, r1meta)})
        recruited = pair(world, r1meta) == canonical[target]
        r0_held = pair(world, meta) == r0_canonical
        rows.append({"target": target, "overwritten_preexisting_sites": occupied,
                     "overwritten_site_count": len(occupied), "samples": samples,
                     "r0_terminal_pair": pair(world, meta), "r0_holds_original": r0_held,
                     "r1_terminal_pair": pair(world, r1meta), "fresh_t0_r1_canonical_pair": canonical[target],
                     "late_r1_reaches_fresh_canonical": recruited,
                     "python_interventions_after_t0": 1,
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
        if recruited:
            for q in region(meta["q_receiver"], meta["n"], 2): clear(world, q)
            hs = []
            for dt in range(1, HANDOFF_FOLLOWUP + 1):
                world.tick()
                if dt in (1, 2, 4, 8, 16, 64, 128, 256): hs.append({"dt": dt, "r1_pair": pair(world, r1meta)})
            handoff_rows.append({"target": target, "samples": hs,
                                 "r1_holds_after_diagnostic_r0_retirement": pair(world, r1meta) == canonical[target],
                                 "python_interventions_after_t0": 2,
                                 "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.forced_fresh_remote_recruitment.v1",
        "question": "If a six-site fresh R1 niche is diagnostically constructed inside the mature landscape, does the mature state-expression regime recruit the same canonical R1 formed from t0?",
        "design": {"r0_offset": list(R0_OFFSET), "r1_offset": list(R1_OFFSET),
                   "mature_tick": MATURE, "followup_ticks": FOLLOWUP,
                   "fresh_r1_site_count": 6, "r0_modified_during_recruitment": False},
        "canonical_r1_pairs": canonical, "rows": rows, "handoff_rows": handoff_rows,
        "summary": {"forced_fresh_r1_recruited_for_both_states": all(row["late_r1_reaches_fresh_canonical"] for row in rows),
                    "r0_function_preserved_for_both_states": all(row["r0_holds_original"] for row in rows),
                    "diagnostic_handoff_holds_for_both_states": len(handoff_rows) == 2 and all(row["r1_holds_after_diagnostic_r0_retirement"] for row in handoff_rows),
                    "native_niche_creation_demonstrated": False,
                    "native_role_handoff_demonstrated": False},
        "claim_guard": "Clearing and constructing the R1 niche is a diagnostic host intervention. This tests recruitment compatibility only, not native generation, role selection, ping-pong reuse, or RW3.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R09B_FORCED_FRESH_REMOTE_RECRUITMENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
