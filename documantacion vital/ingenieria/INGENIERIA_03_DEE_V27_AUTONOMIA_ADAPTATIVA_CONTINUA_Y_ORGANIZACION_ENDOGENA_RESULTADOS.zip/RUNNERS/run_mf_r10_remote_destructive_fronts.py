#!/usr/bin/env python3
"""Diagnostic DEE-carrier fronts aimed at a mature far REMOTE_A basin."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair

OFFSET = (-6, 7, 8)
INJECT_TICK = 512
FOLLOWUP = 256


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def sign(value):
    return 0 if value == 0 else (1 if value > 0 else -1)


def direction_set(kind):
    if kind == "single_negative_x": return [(-1, 0, 0)]
    if kind == "axes6": return [(sx, 0, 0) for sx in (-1, 1)] + [(0, sy, 0) for sy in (-1, 1)] + [(0, 0, sz) for sz in (-1, 1)]
    if kind == "corners8": return list(product((-1, 1), repeat=3))
    if kind == "moore26": return [d for d in product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]
    raise ValueError(kind)


def inject_front(world, meta, kind, sreg):
    q0, n = meta["q_receiver"], meta["n"]; records = []
    for index, unit in enumerate(direction_set(kind)):
        source = add(q0, unit, 3, n); direction = tuple(-sign(value) for value in unit)
        before = int(world.raw[source]); raw = pack(30000 + index, sreg, direction, 1)
        world.raw_a[source] = raw; world.raw_b[source] = raw
        world.clock_a[source] = INJECT_TICK; world.clock_b[source] = INJECT_TICK
        records.append({"q": list(source), "direction": list(direction), "replaced_raw": before, "raw": int(raw)})
    return records


def main():
    kernel, runtime = load_kernel(1)
    r10.OFFSET = OFFSET
    wa, meta = r10.build(kernel, "a"); wb, _ = r10.build(kernel, "b"); ws, _ = r10.build(kernel, None)
    for _ in range(INJECT_TICK): wa.tick(); wb.tick(); ws.tick()
    canonical = {"a": pair(wa, meta), "b": pair(wb, meta), "sham": pair(ws, meta)}
    specs = {
        "intact_a": (None, 0),
        "single_negative_x_low": ("single_negative_x", 0),
        "axes6_low": ("axes6", 0),
        "axes6_high": ("axes6", 65535),
        "corners8_low": ("corners8", 0),
        "corners8_high": ("corners8", 65535),
        "moore26_low": ("moore26", 0),
        "moore26_high": ("moore26", 65535),
    }
    branches = []
    for name, (kind, sreg) in specs.items():
        world = clone_world(wa); injection = [] if kind is None else inject_front(world, meta, kind, sreg)
        branches.append({"name": name, "kind": kind, "sreg": sreg, "world": world,
                         "injection": injection, "samples": [{"dt": 0, "pair": pair(world, meta)}]})
    checkpoints = {1, 2, 3, 4, 8, 16, 32, 64, 128, 192, 256}
    for dt in range(1, FOLLOWUP + 1):
        for branch in branches:
            branch["world"].tick()
            if dt in checkpoints: branch["samples"].append({"dt": dt, "pair": pair(branch["world"], meta)})
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta); suffix = [sample["pair"] for sample in branch["samples"] if sample["dt"] >= 192]
        rows.append({"variant": branch["name"], "front_kind": branch["kind"], "carrier_sreg": branch["sreg"],
                     "carrier_count": len(branch["injection"]), "injection": branch["injection"],
                     "samples": branch["samples"], "terminal_pair": terminal,
                     "terminal_is_a": terminal == canonical["a"], "terminal_is_b": terminal == canonical["b"],
                     "terminal_is_sham": terminal == canonical["sham"],
                     "a_basin_function_lost": terminal != canonical["a"],
                     "terminal_fixed_last_64_sampled": bool(suffix) and all(value == suffix[-1] for value in suffix),
                     "python_interventions_after_t0": 0 if branch["kind"] is None else 1,
                     "intervention_class": "NONE" if branch["kind"] is None else "DIAGNOSTIC_INTERVENTION"})
    by = {row["variant"]: row for row in rows}; destructive = [row["variant"] for row in rows if row["a_basin_function_lost"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.remote_destructive_fronts.v1",
        "question": "Can actual DEE carrier collisions launched outside radius2 destabilize the mature REMOTE_A basin?",
        "design": {"receiver_offset": list(OFFSET), "inject_tick": INJECT_TICK,
                   "launch_chebyshev_radius": 3, "followup_ticks": FOLLOWUP,
                   "fronts": list(specs), "direct_receiver_voxel_overwrite": False},
        "canonical_pairs": canonical, "rows": rows,
        "summary": {"intact_remains_a": by["intact_a"]["terminal_is_a"],
                    "destructive_front_variants": destructive,
                    "any_front_destroys_a": bool([name for name in destructive if name != "intact_a"]),
                    "any_front_yields_sham_receptive_pair": any(row["terminal_is_sham"] for row in rows if row["variant"] != "intact_a"),
                    "native_front_generation_or_timing_demonstrated": False},
        "claim_guard": "Carrier fronts are host-injected diagnostic interventions. The experiment tests DEE collision consequences, not native signal generation, scheduling, or RW3.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R10_REMOTE_DESTRUCTIVE_FRONTS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
