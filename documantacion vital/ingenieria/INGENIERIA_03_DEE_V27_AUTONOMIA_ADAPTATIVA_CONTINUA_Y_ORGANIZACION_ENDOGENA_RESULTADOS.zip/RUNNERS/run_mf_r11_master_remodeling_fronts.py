#!/usr/bin/env python3
"""High-impact carrier fronts as a diagnostic native-dynamics master thaw mechanism."""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n07_native_consequence_expression import delta_value
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair
import run_dd_r02_remote_hold_master_reset as reset

OFFSET = (-6, 7, 8)
CUT_TICK = 184
HORIZON = 400


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def sign(value): return 0 if value == 0 else (1 if value > 0 else -1)


def units(kind):
    if kind == "axes6": return [(s, 0, 0) for s in (-1, 1)] + [(0, s, 0) for s in (-1, 1)] + [(0, 0, s) for s in (-1, 1)]
    if kind == "corners8": return list(product((-1, 1), repeat=3))
    if kind == "moore26": return [d for d in product((-1, 0, 1), repeat=3) if d != (0, 0, 0)]
    raise ValueError(kind)


def inject(world, meta, kind, sreg, protected):
    records = []
    for index, unit in enumerate(units(kind)):
        q = add(meta["c"], unit, 3, meta["n"])
        if q in protected:
            records.append({"q": list(q), "skipped": "protected_writer"}); continue
        direction = tuple(-sign(value) for value in unit); before = int(world.raw[q])
        raw = pack(31000 + index, sreg, direction, 1)
        world.raw_a[q] = raw; world.raw_b[q] = raw
        world.clock_a[q] = CUT_TICK; world.clock_b[q] = CUT_TICK
        records.append({"q": list(q), "direction": list(direction), "replaced_raw": before, "raw": int(raw)})
    return records


def main():
    kernel, runtime = load_kernel(1); reset.CUT_TICK = CUT_TICK; r10.OFFSET = OFFSET
    base, meta = r10.build(kernel, "a")
    for _ in range(CUT_TICK): base.tick()
    specs = {
        "intact_no_front": (None, 0),
        "axes6_low": ("axes6", 0), "axes6_high": ("axes6", 65535),
        "corners8_high": ("corners8", 65535),
        "moore26_low": ("moore26", 0), "moore26_high": ("moore26", 65535),
    }
    branches = []
    for name, (kind, sreg) in specs.items():
        world = clone_world(base)
        for q in delayed_source_positions(meta): clear(world, q)
        writer = reset.install_writer(world, meta); injection = []
        if kind is not None: injection = inject(world, meta, kind, sreg, {tuple(writer["q"])})
        branches.append({"name": name, "kind": kind, "sreg": sreg, "world": world,
                         "writer": writer, "injection": injection,
                         "previous": delta_value(world, meta), "transitions": [],
                         "samples": [{"tick": CUT_TICK, "dt": 0, "delta": delta_value(world, meta),
                                      "remote_pair": pair(world, meta)}]})
    checkpoints = {1, 2, 3, 4, 8, 16, 32, 64, 96, 128, 149, 150, 151, 192, 216}
    for tick in range(CUT_TICK + 1, HORIZON + 1):
        dt = tick - CUT_TICK
        for branch in branches:
            branch["world"].tick(); delta = delta_value(branch["world"], meta)
            if delta != branch["previous"]:
                branch["transitions"].append({"tick": tick, "dt": dt,
                                              "before": branch["previous"], "after": delta})
            if dt in checkpoints:
                branch["samples"].append({"tick": tick, "dt": dt, "delta": delta,
                                          "remote_pair": pair(branch["world"], meta)})
            branch["previous"] = delta
    rows = []
    for branch in branches:
        rows.append({"variant": branch["name"], "front_kind": branch["kind"], "carrier_sreg": branch["sreg"],
                     "writer": branch["writer"], "injection": branch["injection"],
                     "post_cut_transitions": branch["transitions"], "write_reopened": bool(branch["transitions"]),
                     "samples": branch["samples"], "remote_terminal_pair": pair(branch["world"], meta),
                     "python_interventions_after_t0": 1 if branch["kind"] is None else 2,
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    successful = [row["variant"] for row in rows if row["write_reopened"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_multifront.master_remodeling_fronts.v1",
        "question": "Can convergent DEE carrier collisions launched outside the known 49-site control surface restore a competent write without a distributed clamp?",
        "design": {"receiver_offset": list(OFFSET), "cut_tick": CUT_TICK, "horizon": HORIZON,
                   "front_launch_radius": 3, "fronts": list(specs),
                   "bridge_sources_cut_before_front": True, "competent_writer_installed_in_all_branches": True},
        "rows": rows,
        "summary": {"successful_write_reopening_fronts": successful,
                    "any_high_front_reopens": any(name.endswith("high") for name in successful),
                    "low_fronts_reopen": any("low" in name for name in successful),
                    "intact_control_reopens": "intact_no_front" in successful,
                    "native_front_source_or_trigger_demonstrated": False},
        "claim_guard": "Fronts and writer are host-installed diagnostic interventions. A positive collision effect would identify a DEE remodeling primitive, not native triggering or RW3.",
        "runtime": runtime
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_MF_R11_MASTER_REMODELING_FRONTS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
