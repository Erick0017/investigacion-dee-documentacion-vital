#!/usr/bin/env python3
"""Search 3D tangential neutral-probe paths around a plastic relational organ.

This is deliberately outside the bounded D17 radial/direct-contact family: every
accepted path avoids the two stored sites, the comparator, the writer event, and
the persistent scaffold during the complete early observation interval.
"""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
DIRECTIONS = tuple(v for v in itertools.product((-1, 0, 1), repeat=3) if v != (0, 0, 0))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def build(kernel, delta, probe=None, n=23):
    c = (n // 2,) * 3
    a = add(c, (-1, 0, 0), 1, n)
    b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100 + delta, semantic=1, phase=260)
    put(raw, clock, b, 2000, 100, semantic=1, phase=260)
    scaffold = set()
    for index, offset in enumerate(PA):
        q = add(a, offset, 1, n)
        put(raw, clock, q, 3000 + index, 0, semantic=4, phase=31 + index)
        scaffold.add(q)
    for index, offset in enumerate(PB):
        q = add(b, offset, 1, n)
        put(raw, clock, q, 4000 + index, 0, semantic=4, phase=41 + index)
        scaffold.add(q)
    event = add(b, (0, -1, 0), 1, n)
    writer = add(event, (0, 0, 1), -3, n)
    put(raw, clock, writer, 5000, 0, (0, 0, 1), 4, 0)
    protected = {a, b, c, event, writer} | scaffold
    probe_start = None
    if probe is not None:
        q0 = add(c, tuple(probe["offset"]), 1, n)
        direction = tuple(probe["direction"])
        probe_start = add(q0, direction, -int(probe["lead"]), n)
        put(raw, clock, probe_start, 7001, int(probe["sreg"]), direction, 1, int(probe["phase"]))
    return NativeWorld(kernel, raw, clock), {
        "n": n, "c": c, "a": a, "b": b, "event": event, "writer": writer,
        "scaffold": scaffold, "protected": protected, "probe_start": probe_start,
    }


def delta_value(world, meta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])


def path_is_disjoint(meta, probe, observation_ticks=12):
    q0 = add(meta["c"], tuple(probe["offset"]), 1, meta["n"])
    direction = tuple(probe["direction"])
    start = add(q0, direction, -int(probe["lead"]), meta["n"])
    visited = {add(start, direction, step, meta["n"]) for step in range(observation_ticks + 1)}
    return not bool(visited & meta["protected"])


def early_pair(kernel, delta, probe, horizon=16):
    baseline, base_meta = build(kernel, delta)
    world, meta = build(kernel, delta, probe)
    h = hashlib.sha256()
    trace = []
    protected_changed = []
    external_event_count = 0
    for tick in range(1, horizon + 1):
        baseline.tick(); world.tick()
        differences = []
        for row in np.argwhere(world.raw != baseline.raw):
            q = tuple(int(value) for value in row)
            if q in meta["protected"]:
                protected_changed.append({"tick": tick, "q": list(q)})
                continue
            probe_raw, base_raw = int(world.raw[q]), int(baseline.raw[q])
            differences.append((q, probe_raw, base_raw))
        differences.sort(key=lambda item: item[0])
        external_event_count += len(differences)
        canonical = [(list(q), x, y) for q, x, y in differences]
        h.update(json.dumps(canonical, separators=(",", ":")).encode("utf-8"))
        if differences and len(trace) < 10:
            trace.append({
                "tick": tick,
                "differences": [
                    {"q": list(q), "probe_raw": x, "baseline_raw": y,
                     "probe_decoded": None if x == 0 else unpack_scalar(x)}
                    for q, x, y in differences[:12]
                ],
            })
    return {
        "initial_delta": delta,
        "signature_sha256": h.hexdigest(),
        "external_event_count": external_event_count,
        "protected_changed": protected_changed[:40],
        "protected_change_count": len(protected_changed),
        "trace": trace,
        "terminal_delta": delta_value(world, meta),
    }


def long_pair(kernel, delta, probe, horizon=1024):
    baseline, base_meta = build(kernel, delta)
    world, meta = build(kernel, delta, probe)
    deltas = []
    base_deltas = []
    protected_change_ticks = set()
    for tick in range(1, horizon + 1):
        baseline.tick(); world.tick()
        deltas.append(delta_value(world, meta)); base_deltas.append(delta_value(baseline, base_meta))
        if any(int(world.raw[q]) != int(baseline.raw[q]) for q in meta["protected"]):
            protected_change_ticks.add(tick)
    def transitions(values, start=16):
        return sum(values[index] != values[index - 1] for index in range(max(1, start), len(values)))
    observed = transitions(deltas)
    expected = transitions(base_deltas)
    return {
        "initial_delta": delta,
        "post16_delta_transitions": observed,
        "baseline_post16_delta_transitions": expected,
        "future_writable": observed >= max(1, expected - 2),
        "terminal_delta": deltas[-1],
        "baseline_terminal_delta": base_deltas[-1],
        "protected_change_tick_count": len(protected_change_ticks),
        "first_protected_change_tick": None if not protected_change_ticks else min(protected_change_ticks),
        "python_interventions_after_t0": 0,
    }


def geometry_catalog(kernel):
    _, meta = build(kernel, 0)
    rows = []
    # Chebyshev radii 1 and 2, with an exactly tangential lattice direction.
    for radius in (1, 2):
        offsets = [v for v in itertools.product(range(-radius, radius + 1), repeat=3)
                   if max(abs(x) for x in v) == radius]
        for offset in offsets:
            for direction in DIRECTIONS:
                if sum(offset[i] * direction[i] for i in range(3)) != 0:
                    continue
                probe = {"offset": list(offset), "direction": list(direction), "lead": 3,
                         "sreg": 7, "phase": 0}
                if path_is_disjoint(meta, probe):
                    rows.append(probe)
    # Exact duplicates are impossible, but sorting makes the discovery order canonical.
    return sorted(rows, key=lambda item: (item["offset"], item["direction"]))


def main():
    kernel, runtime = load_kernel(1)
    geometries = geometry_catalog(kernel)
    rows = []
    shortlisted = []
    for index, probe in enumerate(geometries):
        classes = [early_pair(kernel, delta, probe) for delta in (-8, 0, 8)]
        signatures = [row["signature_sha256"] for row in classes]
        external = [row["external_event_count"] for row in classes]
        row = {
            "config_id": f"N01_{index:04d}", "probe": probe, "classes": classes,
            "distinct_delta_signatures": len(set(signatures)),
            "all_classes_external": all(value > 0 for value in external),
            "any_protected_change": any(item["protected_change_count"] for item in classes),
        }
        row["shortlisted"] = row["distinct_delta_signatures"] >= 2 and row["all_classes_external"] and not row["any_protected_change"]
        rows.append(row)
        if row["shortlisted"]:
            shortlisted.append(row)
    # Long-horizon writability is expensive and only justified for informative, non-contact candidates.
    for row in shortlisted:
        row["long_horizon"] = [long_pair(kernel, delta, row["probe"]) for delta in (-8, 0, 8)]
        row["rw1_passive_candidate"] = all(item["future_writable"] for item in row["long_horizon"])
    candidates = [row for row in shortlisted if row.get("rw1_passive_candidate")]
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.tangential_scatter_search.v1",
        "question": "Can a neutral carrier traverse a tangential 3D path near, but not through, the plastic interface and acquire a stored-delta-dependent trajectory while future writes survive?",
        "causal_novelty": "Paths are tangential and disjoint from a,b,comparator,writer event,writer source,and semantic4 scaffold during the early observation interval; D17 radial/direct-contact geometries are excluded.",
        "search": {"chebyshev_radii": [1, 2], "directions": [list(v) for v in DIRECTIONS],
                   "tangency_rule": "offset dot direction == 0", "lead": 3, "sreg": 7,
                   "phase": 0, "deltas": [-8, 0, 8], "early_horizon": 16,
                   "long_horizon": 1024},
        "valid_geometries": len(geometries), "rows": rows,
        "shortlisted_count": len(shortlisted), "candidate_count": len(candidates),
        "candidate_ids": [row["config_id"] for row in candidates],
        "claim_guard": "Discovery search only. A signature is not a passive-expression claim until mechanism selection, many-probe backaction, master-ablation, freeze, and fresh tests pass.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N01_TANGENTIAL_SCATTER_SEARCH.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "valid_geometries": len(geometries),
                      "shortlisted": len(shortlisted), "candidates": len(candidates),
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
