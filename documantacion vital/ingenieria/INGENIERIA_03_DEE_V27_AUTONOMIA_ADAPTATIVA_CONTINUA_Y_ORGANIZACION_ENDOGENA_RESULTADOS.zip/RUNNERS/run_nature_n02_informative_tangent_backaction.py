#!/usr/bin/env python3
"""Long-horizon causal test of every informative tangential N01 geometry."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_nature_n01_tangential_scatter_search import long_pair


def main():
    source_path = ROOT / "DISCOVERY/ING03_NATURE_N01_TANGENTIAL_SCATTER_SEARCH.json"
    source = json.loads(source_path.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    informative = [row for row in source["rows"] if row["distinct_delta_signatures"] >= 2]
    rows = []
    for source_row in informative:
        classes = [long_pair(kernel, delta, source_row["probe"], horizon=1024) for delta in (-8, 0, 8)]
        rows.append({
            "config_id": source_row["config_id"],
            "probe": source_row["probe"],
            "distinct_delta_signatures": source_row["distinct_delta_signatures"],
            "classes": classes,
            "all_future_writable": all(row["future_writable"] for row in classes),
            "minimum_post16_transitions": min(row["post16_delta_transitions"] for row in classes),
            "maximum_post16_transitions": max(row["post16_delta_transitions"] for row in classes),
        })
    survivors = [row for row in rows if row["all_future_writable"]]
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.informative_tangent_backaction.v1",
        "question": "Are N01's stored-delta-informative tangential interactions transient perturbations, or do they eliminate later recurrent writing?",
        "source": str(source_path.relative_to(ROOT)).replace("\\", "/"),
        "selection_rule": "All and only N01 geometries with at least two stored-delta-dependent early signatures; no post-result parameter selection.",
        "horizon": 1024,
        "rows": rows,
        "informative_geometries": len(rows),
        "writability_survivors": len(survivors),
        "survivor_ids": [row["config_id"] for row in survivors],
        "claim_guard": "A null bounds tangential paths whose interaction perturbs at least one of a/b/c; it does not cover environmental traces, downstream morphology, temporal regimes, or other non-contact mechanisms.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N02_INFORMATIVE_TANGENT_BACKACTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "informative_geometries": len(rows),
                      "writability_survivors": len(survivors),
                      "transition_ranges": sorted({(row["minimum_post16_transitions"], row["maximum_post16_transitions"]) for row in rows}),
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
