#!/usr/bin/env python3
"""Census state-dependent external traces produced without probes or a writer."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, full_sha, load_kernel, seal, unpack_scalar, write_json
from run_nature_n01_tangential_scatter_search import build


def toroidal_chebyshev(a, b, n):
    return max(min((a[i] - b[i]) % n, (b[i] - a[i]) % n) for i in range(3))


def build_quiescent(kernel, delta):
    world, meta = build(kernel, delta, probe=None, n=23)
    # This is part of t0 construction, not an intervention during the episode.
    world.raw_a[meta["writer"]] = np.uint64(0)
    world.raw_b[meta["writer"]] = np.uint64(0)
    meta["protected"] = set(meta["protected"])
    return world, meta


def main():
    kernel, runtime = load_kernel(1)
    deltas = (-8, 0, 8)
    built = [build_quiescent(kernel, delta) for delta in deltas]
    worlds = [item[0] for item in built]
    metas = [item[1] for item in built]
    c = metas[0]["c"]; n = metas[0]["n"]
    excluded = set().union(*(meta["protected"] for meta in metas))
    samples = []
    any_external_ticks = 0
    any_far_ticks = 0
    max_radius = 0
    persistent_positions = None
    first_external = None
    first_far = None
    signature = hashlib.sha256()
    checkpoints = {1, 2, 3, 4, 8, 16, 32, 64, 128, 256, 512, 1024}
    for tick in range(1, 1025):
        for world in worlds:
            world.tick()
        differing = []
        far = []
        for row in np.argwhere((worlds[0].raw != worlds[1].raw) | (worlds[1].raw != worlds[2].raw)):
            q = tuple(int(value) for value in row)
            if q in excluded:
                continue
            raws = [int(world.raw[q]) for world in worlds]
            radius = toroidal_chebyshev(q, c, n)
            differing.append((q, raws, radius))
            max_radius = max(max_radius, radius)
            if radius >= 3:
                far.append((q, raws, radius))
        if differing:
            any_external_ticks += 1
            first_external = tick if first_external is None else first_external
        if far:
            any_far_ticks += 1
            first_far = tick if first_far is None else first_far
        current_positions = {item[0] for item in far}
        persistent_positions = current_positions if persistent_positions is None else persistent_positions & current_positions
        if tick in checkpoints or (differing and len(samples) < 12):
            samples.append({
                "tick": tick,
                "external_difference_count": len(differing),
                "far_difference_count": len(far),
                "maximum_radius": max((item[2] for item in differing), default=0),
                "examples": [
                    {"q": list(q), "radius": radius,
                     "raw_by_delta": dict(zip(map(str, deltas), raws)),
                     "decoded_by_delta": dict(zip(map(str, deltas), [None if raw == 0 else unpack_scalar(raw) for raw in raws]))}
                    for q, raws, radius in differing[:12]
                ],
            })
        signature.update(json.dumps([(q, raws, radius) for q, raws, radius in differing],
                                    sort_keys=True, separators=(",", ":")).encode("utf-8"))
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.spontaneous_trace_census.v1",
        "question": "Does a quiescent stored relational state autonomously create a delta-dependent external DEE trace without a probe, writer, or host intervention?",
        "apparatus": "Same compact relational organ for delta=-8,0,+8; persistent writer source removed at t0; no other carriers; clocks and geometry identical.",
        "horizon": 1024,
        "excluded_positions": [list(q) for q in sorted(excluded)],
        "external_difference_ticks": any_external_ticks,
        "far_difference_ticks_radius_ge_3": any_far_ticks,
        "first_external_tick": first_external,
        "first_far_tick": first_far,
        "maximum_toroidal_chebyshev_radius": max_radius,
        "persistent_far_positions_all_ticks": [list(q) for q in sorted(persistent_positions or set())],
        "samples": samples,
        "trajectory_signature_sha256": signature.hexdigest(),
        "terminal_world_hashes": [full_sha(world.raw, world.clock_a) for world in worlds],
        "python_interventions_after_t0": 0,
        "claim_guard": "A null applies to spontaneous traces from this compact source-supported relation; triggered, pumped, or alternative morphologies remain separate families.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N03_SPONTANEOUS_TRACE_CENSUS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "external_difference_ticks": any_external_ticks,
                      "far_difference_ticks": any_far_ticks, "first_external": first_external,
                      "first_far": first_far, "max_radius": max_radius,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
