#!/usr/bin/env python3
"""Resolve whether D27's unexpected writable comparator tracks later master updates."""
from __future__ import annotations

import collections
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, transform, write_json

PA = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PB = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))
FRAME = ((0, 1, 2), (1, -1, -1))
P = (1, 0, 0); S1 = (-1, 1, 0); S2 = (-1, -1, 0); N1 = (1, 0, 1); N2 = (1, 0, -1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def build(kernel, initial_delta, with_writer=True, with_master=True, n=23):
    permutation, signs = FRAME
    tf = lambda vector: transform(vector, permutation, signs)
    c = (n // 2,) * 3; a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    writer = None
    if with_master:
        put(raw, clock, a, 1000, 100 + initial_delta, semantic=1, phase=260)
        put(raw, clock, b, 2000, 100, semantic=1, phase=260)
        for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
        for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
        if with_writer:
            event = add(b, (0, -1, 0), 1, n); writer = add(event, (0, 0, 1), -3, n)
            put(raw, clock, writer, 5000, 0, (0, 0, 1), 4, 0)
    p, s1, s2, n1, n2 = (tf(vector) for vector in (P, S1, S2, N1, N2))
    q = c; qp = add(q, p, 1, n)
    put(raw, clock, q, 1, 7, p, 1, 11)
    source_specs = ((add(qp, s1, -1, n), s1, 11), (add(qp, s2, -1, n), s2, 13),
                    (add(q, n1, -2, n), n1, 17), (add(q, n2, -2, n), n2, 19))
    sources = []
    for index, (position, direction, sreg) in enumerate(source_specs):
        put(raw, clock, position, 7000 + index, sreg, direction, 4, 100 + index)
        sources.append((position, int(raw[position])))
    return NativeWorld(kernel, raw, clock), {"n": n, "a": a, "b": b, "c": c, "q": q, "qp": qp,
                                                   "writer": writer,
                                                   "sources": sources}


def policy_class(record):
    if record is None:
        return "ABSENT"
    dx = int(record["direction"][0])
    return "X_NEG" if dx < 0 else ("X_POS" if dx > 0 else "X_ZERO")


def run(kernel, initial_delta, with_writer, horizon=1024):
    world, meta = build(kernel, initial_delta, with_writer=with_writer)
    previous_delta = None; previous_class = None
    transitions = []; output_transitions = []; around_updates = []
    joint = collections.Counter(); trace = []
    recent = collections.deque(maxlen=4)
    for tick in range(1, horizon + 1):
        world.tick()
        ra, rb, output = read(world.raw, meta["a"]), read(world.raw, meta["b"]), read(world.raw, meta["c"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        cls = policy_class(output)
        joint[(delta, cls)] += 1
        item = {"tick": tick, "delta": delta, "output_class": cls,
                "output_direction": None if output is None else output["direction"]}
        if previous_delta is not None and delta != previous_delta:
            transitions.append({"tick": tick, "before": previous_delta, "after": delta,
                                "output_at_update": item, "prehistory": list(recent)})
        if previous_class is not None and cls != previous_class:
            output_transitions.append({"tick": tick, "before": previous_class, "after": cls, "delta": delta})
        if tick <= 16 or tick in {32, 64, 128, 256, 512, 768, 1024}:
            trace.append(item)
        if transitions and 0 <= tick - transitions[-1]["tick"] <= 4:
            around_updates.append(item)
        recent.append(item)
        previous_delta, previous_class = delta, cls
    return {
        "initial_delta": initial_delta, "with_writer": with_writer,
        "master_transitions": transitions, "output_transitions": output_transitions,
        "joint_delta_output_counts": [{"delta": delta, "output_class": cls, "ticks": count}
                                      for (delta, cls), count in sorted(joint.items(), key=lambda x: str(x[0]))],
        "around_updates": around_updates, "trace": trace,
        "terminal_delta": previous_delta, "terminal_output_class": previous_class,
        "source_raw_fixed": all(int(world.raw[position]) == raw for position, raw in meta["sources"]),
        "python_interventions_after_t0": 0,
    }


def main():
    kernel, runtime = load_kernel(1)
    initial_deltas = (-8, -2, -1, 0, 1, 2, 8)
    rows = [run(kernel, delta, with_writer) for with_writer in (False, True) for delta in initial_deltas]
    writer_rows = [row for row in rows if row["with_writer"]]
    tracking_events = []
    for row in writer_rows:
        for event in row["output_transitions"]:
            if any(abs(event["tick"] - update["tick"]) <= 4 for update in row["master_transitions"]):
                tracking_events.append({"initial_delta": row["initial_delta"], **event})
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.dynamic_temporal_expression.v1",
        "question": "Does the writable D27 comparator's derived output update when the stored master changes later, or only preserve an initial-condition transient?",
        "apparatus_origin": "ING03_FINAL_D27_TRUE_PHASE_MULTIPLEXER candidate frame 1, q_is_comparator; reclassified here as a possible derived temporal-expression mechanism rather than a phase-release mechanism.",
        "frame": {"permutation": list(FRAME[0]), "signs": list(FRAME[1])},
        "initial_deltas": list(initial_deltas), "horizon": 1024,
        "rows": rows,
        "output_transitions_near_master_updates": tracking_events,
        "current_state_tracking_candidate": bool(tracking_events),
        "claim_guard": "Temporal coincidence is only discovery evidence. RW2 additionally requires a later neutral trigger, master necessity after learning, and fresh controls.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N04_DYNAMIC_TEMPORAL_EXPRESSION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output),
                      "master_transition_counts": {str(row['initial_delta']): len(row['master_transitions']) for row in writer_rows},
                      "output_transition_counts": {str(row['initial_delta']): len(row['output_transitions']) for row in writer_rows},
                      "near_update_events": tracking_events,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
