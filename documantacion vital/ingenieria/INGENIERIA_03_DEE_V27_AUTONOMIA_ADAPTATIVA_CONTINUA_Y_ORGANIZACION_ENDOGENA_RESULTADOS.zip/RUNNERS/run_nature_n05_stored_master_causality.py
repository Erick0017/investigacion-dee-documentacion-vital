#!/usr/bin/env python3
"""Predeclared tick-800 interventions for the N04 temporal-expression signal."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, pack, read, seal, write_json, load_kernel
from run_nature_n04_dynamic_temporal_expression import build, policy_class

INTERVENTION_TICK = 800
HORIZON = 900


def set_both(world, q, value):
    world.raw_a[q] = np.uint64(value)
    world.raw_b[q] = np.uint64(value)


def current_delta(world, meta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])


def substitute_delta(world, meta, target_delta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    if ra is None or rb is None:
        raise RuntimeError("master absent before substitution")
    new_sreg = int(rb["sreg"] + target_delta)
    replacement = pack(ra["state"], new_sreg, tuple(ra["direction"]), ra["semantic"])
    set_both(world, meta["a"], replacement)


def apply_intervention(world, meta, mode):
    before = {"delta": current_delta(world, meta), "a": read(world.raw, meta["a"]),
              "b": read(world.raw, meta["b"]), "writer": None if meta["writer"] is None else read(world.raw, meta["writer"])}
    if mode == "none":
        pass
    elif mode == "remove_writer":
        set_both(world, meta["writer"], 0)
    elif mode == "ablate_master":
        set_both(world, meta["a"], 0); set_both(world, meta["b"], 0)
    elif mode == "substitute_delta3":
        substitute_delta(world, meta, 3)
    elif mode == "substitute_delta11":
        substitute_delta(world, meta, 11)
    elif mode == "remove_comparator":
        set_both(world, meta["c"], 0)
    else:
        raise ValueError(mode)
    after = {"delta": current_delta(world, meta), "a": read(world.raw, meta["a"]),
             "b": read(world.raw, meta["b"]), "writer": None if meta["writer"] is None else read(world.raw, meta["writer"])}
    return {"mode": mode, "tick": INTERVENTION_TICK, "before": before, "after": after}


def run(kernel, mode, with_writer=True):
    world, meta = build(kernel, initial_delta=2, with_writer=with_writer)
    trace = []; intervention = None; h = hashlib.sha256(); transitions = []
    previous_delta = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        delta = current_delta(world, meta)
        output = read(world.raw, meta["c"])
        if previous_delta is not None and delta != previous_delta:
            transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        if tick == INTERVENTION_TICK:
            intervention = apply_intervention(world, meta, mode)
            delta = current_delta(world, meta); output = read(world.raw, meta["c"])
        item = {"tick": tick, "delta": delta, "output_class": policy_class(output),
                "output": output}
        if tick >= 790:
            h.update(json.dumps(item, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        if tick in {1, 132, 261, 521, 781, 790, 799, 800, 801, 820, 834, 835, 840, 845, 846, 860, 880, 900}:
            trace.append(item)
        previous_delta = delta
    window = []
    # Rerun hashes are enough for whole trajectory; the decisive window is retained losslessly by class.
    # Its direct class sequence is reconstructed from a second deterministic pass to avoid storing 900 rows.
    world2, meta2 = build(kernel, initial_delta=2, with_writer=with_writer)
    for tick in range(1, HORIZON + 1):
        world2.tick()
        if tick == INTERVENTION_TICK:
            apply_intervention(world2, meta2, mode)
        if 820 <= tick <= 860:
            output = read(world2.raw, meta2["c"])
            window.append({"tick": tick, "delta": current_delta(world2, meta2), "output_class": policy_class(output),
                           "output_direction": None if output is None else output["direction"]})
    return {"mode": mode, "with_writer": with_writer, "intervention": intervention,
            "master_transitions_before_intervention": [event for event in transitions if event["tick"] < INTERVENTION_TICK],
            "trajectory_790_900_sha256": h.hexdigest(), "decisive_window_820_860": window,
            "trace": trace, "terminal_delta": current_delta(world, meta),
            "python_role": "predeclared causal intervention at tick 800; diagnostic only, not an autonomous-episode claim"}


def main():
    kernel, runtime = load_kernel(1)
    modes = ("none", "remove_writer", "ablate_master", "substitute_delta3", "substitute_delta11", "remove_comparator")
    rows = [run(kernel, mode, with_writer=True) for mode in modes]
    no_writer = run(kernel, "none", with_writer=False)
    rows.append(no_writer)
    by_mode = {row["mode"] + ("_no_writer" if not row["with_writer"] else ""): row for row in rows}
    def class_string(row):
        return "".join({"X_NEG": "-", "X_ZERO": "0", "X_POS": "+", "ABSENT": "."}[item["output_class"]]
                       for item in row["decisive_window_820_860"])
    patterns = {key: class_string(row) for key, row in by_mode.items()}
    treatment = patterns["none"]
    summary = {
        "patterns_820_860": patterns,
        "remove_writer_matches_treatment": patterns["remove_writer"] == treatment,
        "master_ablation_changes_output": patterns["ablate_master"] != treatment,
        "delta3_substitution_matches_no_writer_delta3_control": patterns["substitute_delta3"] == patterns["none_no_writer"],
        "delta11_substitution_changes_output": patterns["substitute_delta11"] != treatment,
        "comparator_removal_changes_output": patterns["remove_comparator"] != treatment,
    }
    summary["stored_master_causally_necessary"] = summary["remove_writer_matches_treatment"] and summary["master_ablation_changes_output"]
    result = seal({
        "schema": "dee.v27.ing03.nature.mechanism_selection.stored_master_causality.v1",
        "question": "Is N04's later temporal-output divergence caused by the stored master state rather than the persistent writer source or an initial-condition-only regime?",
        "predeclared_from_discovery": {"source": "DISCOVERY/ING03_NATURE_N04_DYNAMIC_TEMPORAL_EXPRESSION.json",
                                       "initial_delta": 2, "intervention_tick": INTERVENTION_TICK,
                                       "decisive_window": [820, 860], "discovery_divergence": [835, 845]},
        "rows": rows, "summary": summary,
        "claim_guard": "These interventions establish or reject stored-state necessity. They do not by themselves establish a remote native action, autonomous consequence selection, RW2, or L4.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_NATURE_N05_STORED_MASTER_CAUSALITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": summary,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
