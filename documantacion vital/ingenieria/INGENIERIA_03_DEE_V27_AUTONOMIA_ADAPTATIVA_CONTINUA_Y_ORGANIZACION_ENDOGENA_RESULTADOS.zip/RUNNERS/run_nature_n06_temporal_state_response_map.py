#!/usr/bin/env python3
"""Map counterfactual stored-state response and its outward spatial propagation."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, read, seal, write_json, load_kernel
from run_nature_n04_dynamic_temporal_expression import build, policy_class
from run_nature_n05_stored_master_causality import set_both, substitute_delta

INTERVENTION_TICK = 800
TARGET_DELTAS = (-8, -4, -1, 0, 1, 3, 7, 11, 15)


def toroidal_chebyshev(a, b, n):
    return max(min((a[i] - b[i]) % n, (b[i] - a[i]) % n) for i in range(3))


def current_delta(world, meta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])


def main():
    kernel, runtime = load_kernel(1)
    built = [build(kernel, initial_delta=2, with_writer=True) for _ in TARGET_DELTAS]
    worlds = [item[0] for item in built]; metas = [item[1] for item in built]
    c = metas[0]["c"]; n = metas[0]["n"]
    protected = {metas[0]["a"], metas[0]["b"], metas[0]["c"], metas[0]["writer"]}
    protected |= {position for position, _ in metas[0]["sources"]}
    traces = {str(delta): [] for delta in TARGET_DELTAS}
    hashes = {str(delta): hashlib.sha256() for delta in TARGET_DELTAS}
    spatial = {str(delta): {"first_external_difference": None, "first_radius_ge_3": None,
                            "max_radius": 0, "difference_ticks": 0, "far_difference_ticks": 0,
                            "examples": []} for delta in TARGET_DELTAS}
    state_at_intervention = []
    for tick in range(1, 901):
        for world in worlds:
            world.tick()
        if tick == INTERVENTION_TICK:
            for target, world, meta in zip(TARGET_DELTAS, worlds, metas):
                before = current_delta(world, meta)
                set_both(world, meta["writer"], 0)
                substitute_delta(world, meta, target)
                state_at_intervention.append({"target_delta": target, "before": before,
                                              "after": current_delta(world, meta)})
        if tick < INTERVENTION_TICK:
            continue
        reference = worlds[TARGET_DELTAS.index(7)]
        for target, world, meta in zip(TARGET_DELTAS, worlds, metas):
            output = read(world.raw, meta["c"])
            item = {"tick": tick, "delta": current_delta(world, meta),
                    "output_class": policy_class(output),
                    "output_direction": None if output is None else output["direction"]}
            hashes[str(target)].update(json.dumps(item, sort_keys=True, separators=(",", ":")).encode("utf-8"))
            if tick in {800, 801, 802, 804, 808, 816, 820, 824, 832, 834, 835, 836, 840, 845, 846, 852, 860, 880, 900}:
                traces[str(target)].append(item)
            if target == 7:
                continue
            differences = []
            far = []
            for row in np.argwhere(world.raw != reference.raw):
                q = tuple(int(value) for value in row)
                if q in protected:
                    continue
                radius = toroidal_chebyshev(q, c, n)
                record = (q, int(world.raw[q]), int(reference.raw[q]), radius)
                differences.append(record)
                if radius >= 3:
                    far.append(record)
            entry = spatial[str(target)]
            if differences:
                entry["difference_ticks"] += 1
                entry["first_external_difference"] = tick if entry["first_external_difference"] is None else entry["first_external_difference"]
                entry["max_radius"] = max(entry["max_radius"], max(item[3] for item in differences))
            if far:
                entry["far_difference_ticks"] += 1
                entry["first_radius_ge_3"] = tick if entry["first_radius_ge_3"] is None else entry["first_radius_ge_3"]
            if (differences or far) and len(entry["examples"]) < 12:
                entry["examples"].append({"tick": tick, "difference_count": len(differences),
                                          "far_count": len(far),
                                          "positions": [{"q": list(q), "target_raw": x,
                                                         "reference_raw": y, "radius": radius}
                                                        for q, x, y, radius in differences[:12]]})
    patterns = {str(target): "".join({"X_NEG": "-", "X_ZERO": "0", "X_POS": "+", "ABSENT": "."}[
        policy_class(read(world.raw, meta["c"]))] for world, meta in []) for target in ()}
    # The full 800..900 behavior is represented by cryptographic trajectories; compact traces expose decisive times.
    distinct_hashes = len({value.hexdigest() for value in hashes.values()})
    result = seal({
        "schema": "dee.v27.ing03.nature.mechanism_selection.temporal_state_response_map.v1",
        "question": "From byte-identical histories through tick 799, do counterfactual stored deltas at tick 800 select different later temporal outputs and propagate beyond the central organ?",
        "design": {"common_initial_delta": 2, "identical_history_through_tick": 799,
                   "predeclared_intervention_tick": INTERVENTION_TICK,
                   "persistent_writer_removed_for_all_cases_at_tick": INTERVENTION_TICK,
                   "target_deltas": list(TARGET_DELTAS), "reference_delta": 7,
                   "horizon": 900},
        "state_at_intervention": state_at_intervention,
        "trajectory_hash_by_target_delta": {key: value.hexdigest() for key, value in hashes.items()},
        "distinct_temporal_trajectories": distinct_hashes,
        "traces": traces, "spatial_propagation_vs_delta7": spatial,
        "any_remote_propagation": any(entry["first_radius_ge_3"] is not None for entry in spatial.values()),
        "python_role": "predeclared counterfactual state substitution for mechanism selection; not autonomous learning",
        "claim_guard": "This maps the native response function. RW2 requires the analogous state transition to arise from a native consequence and to control a later action without host substitution.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_NATURE_N06_TEMPORAL_STATE_RESPONSE_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "distinct_trajectories": distinct_hashes,
                      "first_far_by_delta": {key: value["first_radius_ge_3"] for key, value in spatial.items()},
                      "max_radius_by_delta": {key: value["max_radius"] for key, value in spatial.items()},
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
