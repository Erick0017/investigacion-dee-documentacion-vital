#!/usr/bin/env python3
"""Integrate a native delayed consequence with the regenerative temporal transducer."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB, policy_class


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def build(kernel, consequence_target, generator_mode="treatment", with_transducer=True, n=41,
          memory_phase=252, consequence_distance=6):
    c = (n // 2,) * 3; a = add(c, (-1, 0, 0), 1, n); b = add(c, (1, 0, 0), 1, n)
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100, semantic=1, phase=memory_phase)
    put(raw, clock, b, 2000, 100, semantic=1, phase=memory_phase)
    for index, offset in enumerate(PA): put(raw, clock, add(a, offset, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, offset in enumerate(PB): put(raw, clock, add(b, offset, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    generator_positions = []
    if consequence_target in ("a", "b"):
        target = a if consequence_target == "a" else b
        event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1); generator = add(event, route, -consequence_distance, n)
        d1, d2 = (1, 0, 1), (-1, 0, 1)
        if generator_mode != "missing_d1":
            q = add(generator, d1, -1, n); put(raw, clock, q, 5001, 3, d1, 1, 0); generator_positions.append(q)
        if generator_mode != "missing_d2":
            q = add(generator, d2, -1, n); put(raw, clock, q, 5002, 3, d2, 1, 0); generator_positions.append(q)
        if generator_mode == "wrong_cancel":
            q = add(generator, d2, -1, n); raw[q] = pack(5002, 3, d1, 1)
    transducer_sources = []
    if with_transducer:
        put(raw, clock, c, 1, 7, (1, 0, 0), 1, 11)
        specs = (
            (add(b, (-1, -1, 0), -1, n), (-1, -1, 0), 11),
            (add(b, (-1, 1, 0), -1, n), (-1, 1, 0), 13),
            (add(c, (1, 0, -1), -2, n), (1, 0, -1), 17),
            (add(c, (1, 0, 1), -2, n), (1, 0, 1), 19),
        )
        for index, (q, direction, sreg) in enumerate(specs):
            put(raw, clock, q, 7000 + index, sreg, direction, 4, 100 + index)
            transducer_sources.append((q, int(raw[q])))
    return NativeWorld(kernel, raw, clock), {"n": n, "a": a, "b": b, "c": c,
        "consequence_target": consequence_target, "generator_mode": generator_mode,
        "generator_positions": generator_positions, "transducer_sources": transducer_sources,
        "memory_phase": memory_phase, "consequence_distance": consequence_distance}


def delta_value(world, meta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])


def run(kernel, consequence_target, generator_mode="treatment", with_transducer=True,
        ablate_master_tick=None, horizon=512, memory_phase=252, consequence_distance=6):
    world, meta = build(kernel, consequence_target, generator_mode, with_transducer,
                        memory_phase=memory_phase, consequence_distance=consequence_distance)
    outputs = []; deltas = []; events = []; previous_delta = None; digest = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick()
        if tick == ablate_master_tick:
            for q in (meta["a"], meta["b"]):
                world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
        delta = delta_value(world, meta); output = read(world.raw, meta["c"])
        item = {"tick": tick, "delta": delta, "output_class": policy_class(output),
                "output_direction": None if output is None else output["direction"],
                "output_raw": None if output is None else output["raw"]}
        deltas.append(delta); outputs.append(item)
        if previous_delta is not None and delta != previous_delta:
            events.append({"tick": tick, "before": previous_delta, "after": delta})
        if tick >= 32:
            digest.update(json.dumps(item, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        previous_delta = delta
    checkpoints = {1, 2, 4, 8, 9, 10, 16, 24, 32, 48, 64, 65, 72, 80, 96, 128, 160, 192, 256, 384, 512}
    return {
        "consequence_target": consequence_target, "generator_mode": generator_mode,
        "with_transducer": with_transducer, "ablate_master_tick": ablate_master_tick,
        "master_transitions": events, "terminal_delta": deltas[-1],
        "output_32_512_sha256": digest.hexdigest(),
        "output_samples": [item for item in outputs if item["tick"] in checkpoints],
        "output_class_counts_post32": {name: sum(item["output_class"] == name for item in outputs[31:])
                                       for name in ("X_NEG", "X_ZERO", "X_POS", "ABSENT")},
        "source_raw_fixed": all(int(world.raw[q]) == initial for q, initial in meta["transducer_sources"]),
        "python_interventions_after_t0": 0 if ablate_master_tick is None else 1,
        "python_role": "tick/log only" if ablate_master_tick is None else "predeclared diagnostic master ablation",
    }


def main():
    kernel, runtime = load_kernel(1)
    discovery = [run(kernel, target) for target in ("a", "b", None)]
    generator_canaries = [run(kernel, target, mode) for target in ("a", "b")
                          for mode in ("missing_d1", "missing_d2", "wrong_cancel")]
    transducer_canaries = [run(kernel, target, with_transducer=False) for target in ("a", "b")]
    ablations = [run(kernel, target, ablate_master_tick=64) for target in ("a", "b")]
    signatures = {str(row["consequence_target"]): row["output_32_512_sha256"] for row in discovery}
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.native_consequence_expression.v1",
        "question": "Can a one-shot native delayed consequence write opposite relational states which later select different outputs from the same regenerative temporal transducer?",
        "apparatus": {"memory_phase": 252, "initial_delta": 0, "consequence_distance": 6,
                      "consequence_targets": ["a", "b"], "transducer_frame": {"permutation": [0, 1, 2], "signs": [1, -1, -1]},
                      "horizon": 512},
        "discovery": discovery, "generator_canaries": generator_canaries,
        "transducer_canaries": transducer_canaries, "master_ablations": ablations,
        "summary": {
            "output_signatures": signatures,
            "distinct_consequence_selected_outputs": len(set(signatures.values())),
            "opposite_terminal_master_states": discovery[0]["terminal_delta"] is not None and discovery[1]["terminal_delta"] is not None and discovery[0]["terminal_delta"] * discovery[1]["terminal_delta"] < 0,
            "generator_canaries_block_write": all(not row["master_transitions"] for row in generator_canaries),
            "native_episode_python_interventions_after_t0": 0,
        },
        "claim_guard": "Discovery only. Distinct hashes require fixed-port/action localization and master-necessity timing before RW2 promotion.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N07_NATIVE_CONSEQUENCE_EXPRESSION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "discovery": [{"target": row["consequence_target"], "transitions": row["master_transitions"],
                                     "terminal_delta": row["terminal_delta"], "classes": row["output_class_counts_post32"]}
                                    for row in discovery],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
