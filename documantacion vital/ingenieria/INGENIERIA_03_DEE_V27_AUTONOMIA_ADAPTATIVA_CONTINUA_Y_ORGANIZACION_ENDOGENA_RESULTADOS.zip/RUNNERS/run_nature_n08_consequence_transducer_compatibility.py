#!/usr/bin/env python3
"""Causal grid for compatibility between the delayed consequence and transducer."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, read, seal, write_json
from run_nature_n07_native_consequence_expression import build, delta_value


def compact_run(kernel, target, phase, distance, horizon=96):
    world, meta = build(kernel, target, n=29, memory_phase=phase, consequence_distance=distance)
    deltas = []; outputs = []; digest = hashlib.sha256()
    for tick in range(1, horizon + 1):
        world.tick(); delta = delta_value(world, meta); output = read(world.raw, meta["c"])
        record = None if output is None else (output["state"], output["sreg"], tuple(output["direction"]), output["semantic"])
        deltas.append(delta); outputs.append(record)
        if tick >= 16:
            digest.update(json.dumps(record, separators=(",", ":")).encode("utf-8"))
    return {"target": target, "phase": phase, "distance": distance, "delta_trace": deltas,
            "output_16_96_sha256": digest.hexdigest(),
            "output_direction_classes": sorted({str(None if record is None else record[2]) for record in outputs[15:]}),
            "terminal_delta": deltas[-1], "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    groups = []; candidates = []
    for phase in range(252, 261):
        for distance in range(3, 7):
            rows = [compact_run(kernel, target, phase, distance) for target in ("a", "b", None)]
            by_target = {str(row["target"]): row for row in rows}
            a, b, control = by_target["a"], by_target["b"], by_target["None"]
            a_ticks = [tick + 1 for tick, (x, y) in enumerate(zip(a["delta_trace"], control["delta_trace"])) if x != y]
            b_ticks = [tick + 1 for tick, (x, y) in enumerate(zip(b["delta_trace"], control["delta_trace"])) if x != y]
            ab_ticks = [tick + 1 for tick, (x, y) in enumerate(zip(a["delta_trace"], b["delta_trace"])) if x != y]
            terminal_effect_a = None if a["terminal_delta"] is None or control["terminal_delta"] is None else a["terminal_delta"] - control["terminal_delta"]
            terminal_effect_b = None if b["terminal_delta"] is None or control["terminal_delta"] is None else b["terminal_delta"] - control["terminal_delta"]
            group = {"phase": phase, "distance": distance, "rows": rows,
                     "a_vs_control_ticks": a_ticks, "b_vs_control_ticks": b_ticks,
                     "a_vs_b_ticks": ab_ticks, "terminal_effect_a": terminal_effect_a,
                     "terminal_effect_b": terminal_effect_b,
                     "distinct_output_signatures": len({row["output_16_96_sha256"] for row in rows})}
            group["candidate"] = bool(a_ticks and b_ticks and ab_ticks and group["distinct_output_signatures"] >= 2)
            group["opposite_effect_candidate"] = group["candidate"] and terminal_effect_a is not None and terminal_effect_b is not None and terminal_effect_a * terminal_effect_b < 0
            groups.append(group)
            if group["candidate"]:
                candidates.append(group)
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.consequence_transducer_compatibility.v1",
        "question": "Across the evidence-supported shared phase/distance domain, can both opposite delayed consequences causally separate the master and later transducer trajectory from a no-consequence control?",
        "search": {"memory_phases": [252, 253, 254, 255, 256, 257, 258, 259, 260],
                   "consequence_distances": [3, 4, 5, 6], "targets": ["a", "b", None],
                   "horizon": 96, "all_worlds_t0_complete": True},
        "groups": groups, "candidate_count": len(candidates),
        "opposite_effect_candidate_count": sum(group["opposite_effect_candidate"] for group in candidates),
        "candidate_coordinates": [{"phase": group["phase"], "distance": group["distance"],
                                   "effect_a": group["terminal_effect_a"], "effect_b": group["terminal_effect_b"],
                                   "output_classes": group["distinct_output_signatures"]}
                                  for group in candidates],
        "claim_guard": "Architecture search only. Candidate promotion requires component canaries, stored-master ablation, fixed-port localization, and fresh tests.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N08_CONSEQUENCE_TRANSDUCER_COMPATIBILITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "candidate_count": len(candidates),
                      "opposite_effect_candidates": result["opposite_effect_candidate_count"],
                      "coordinates": result["candidate_coordinates"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
