#!/usr/bin/env python3
"""Repeatedly remove the temporal interface and measure native reinstantiation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, read, seal, write_json, load_kernel
from run_nature_n04_dynamic_temporal_expression import build, policy_class

DAMAGE_TICKS = (200, 400, 600, 800)


def set_both(world, q, value):
    world.raw_a[q] = np.uint64(value); world.raw_b[q] = np.uint64(value)


def run(kernel, mode, horizon=1024):
    world, meta = build(kernel, initial_delta=2, with_writer=True)
    if mode == "source_cut_t0":
        for q, _ in meta["sources"]:
            set_both(world, q, 0)
    damage_records = []; pending = None; transitions = []; previous_delta = None
    for tick in range(1, horizon + 1):
        world.tick()
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if previous_delta is not None and delta != previous_delta:
            transitions.append({"tick": tick, "before": previous_delta, "after": delta})
        if tick in DAMAGE_TICKS:
            if mode in ("treatment", "source_cut_t0"):
                before = read(world.raw, meta["c"]); set_both(world, meta["c"], 0)
                pending = {"damage_tick": tick, "before": before, "first_return_tick": None,
                           "return_record": None}
                damage_records.append(pending)
            elif mode == "sham_far_site":
                far = ((meta["c"][0] + 7) % meta["n"], meta["c"][1], meta["c"][2])
                set_both(world, far, 0)
        if pending is not None and tick > pending["damage_tick"]:
            record = read(world.raw, meta["c"])
            if record is not None and pending["first_return_tick"] is None:
                pending["first_return_tick"] = tick; pending["return_record"] = record
                pending["latency"] = tick - pending["damage_tick"]; pending = None
        previous_delta = delta
    return {"mode": mode, "damage_ticks": list(DAMAGE_TICKS), "damage_records": damage_records,
            "all_interfaces_returned": bool(damage_records) and all(item["first_return_tick"] is not None for item in damage_records),
            "master_transitions": transitions, "terminal_delta": previous_delta,
            "python_role": "predeclared damage interventions only; restoration is native",
            "python_interventions_after_t0": len(DAMAGE_TICKS)}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode) for mode in ("treatment", "source_cut_t0", "sham_far_site")]
    treatment, source_cut, sham = rows
    result = seal({
        "schema": "dee.v27.ing03.nature.mechanism_selection.ephemeral_interface_turnover.v1",
        "question": "Can the configured organization natively reinstate a repeatedly removed temporary output interface while the master continues changing?",
        "rows": rows,
        "summary": {"treatment_returns": treatment["all_interfaces_returned"],
                    "treatment_latencies": [item.get("latency") for item in treatment["damage_records"]],
                    "source_cut_returns": source_cut["all_interfaces_returned"],
                    "treatment_master_transitions": len(treatment["master_transitions"]),
                    "sham_master_transitions": len(sham["master_transitions"])},
        "claim_guard": "Interface reinstantiation is a configured maintenance primitive, not learned self-repair or L4.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_NATURE_N09_EPHEMERAL_INTERFACE_TURNOVER.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
