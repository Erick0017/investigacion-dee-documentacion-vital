#!/usr/bin/env python3
"""Adaptive weak-interaction map over the complete N01 tangential catalog."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_nature_n01_tangential_scatter_search import early_pair, geometry_catalog, long_pair

LEVELS = (0, 1, 3)


def compact_class(row, retain_trace=False):
    value = {key: row[key] for key in ("initial_delta", "signature_sha256", "external_event_count",
                                       "protected_change_count", "terminal_delta")}
    if retain_trace:
        value["protected_changed"] = row["protected_changed"]
        value["trace"] = row["trace"]
    return value


def main():
    kernel, runtime = load_kernel(1)
    geometries = geometry_catalog(kernel)
    rows = []; shortlisted = []
    for level in LEVELS:
        for index, base_probe in enumerate(geometries):
            probe = dict(base_probe); probe["sreg"] = level
            full = [early_pair(kernel, delta, probe) for delta in (-8, 0, 8)]
            distinct = len({item["signature_sha256"] for item in full})
            informative = distinct >= 2
            protected = any(item["protected_change_count"] for item in full)
            row = {"config_id": f"N10_S{level}_{index:04d}", "probe": probe,
                   "distinct_delta_signatures": distinct, "informative": informative,
                   "any_protected_change": protected,
                   "classes": [compact_class(item, retain_trace=informative) for item in full]}
            row["shortlisted"] = informative and not protected
            rows.append(row)
            if row["shortlisted"]:
                shortlisted.append(row)
    for row in shortlisted:
        row["long_horizon"] = [long_pair(kernel, delta, row["probe"], 1024) for delta in (-8, 0, 8)]
        row["future_writable"] = all(item["future_writable"] for item in row["long_horizon"])
    candidates = [row for row in shortlisted if row.get("future_writable")]
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.weak_tangential_probe_map.v1",
        "question": "Does lowering single-probe interaction strength reveal a stored-delta-dependent tangential response before the interface enters the blocking regime?",
        "levels": list(LEVELS), "geometries_per_level": len(geometries), "rows": rows,
        "summary_by_level": {str(level): {"informative": sum(row["informative"] for row in rows if row["probe"]["sreg"] == level),
                                         "informative_without_protected_change": sum(row["shortlisted"] for row in rows if row["probe"]["sreg"] == level)}
                             for level in LEVELS},
        "candidate_count": len(candidates), "candidate_ids": [row["config_id"] for row in candidates],
        "claim_guard": "Single weak probes only. Population nonlinearities are tested separately if this prerequisite warrants it.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N10_WEAK_TANGENTIAL_PROBE_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary_by_level"],
                      "candidates": len(candidates), "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
