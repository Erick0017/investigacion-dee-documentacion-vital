#!/usr/bin/env python3
"""Long-horizon test of causal geometry classes among informative weak probes."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
from run_nature_n01_tangential_scatter_search import long_pair


def direction_order(probe):
    return sum(value != 0 for value in probe["direction"])


def main():
    source_path = ROOT / "DISCOVERY/ING03_NATURE_N10_WEAK_TANGENTIAL_PROBE_MAP.json"
    source = json.loads(source_path.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    selected = []
    for level in source["levels"]:
        informative = [row for row in source["rows"] if row["probe"]["sreg"] == level and row["informative"]]
        for order in (1, 2, 3):
            subset = [row for row in informative if direction_order(row["probe"]) == order]
            if subset:
                selected.append(sorted(subset, key=lambda row: row["config_id"])[0])
    rows = []
    for source_row in selected:
        classes = [long_pair(kernel, delta, source_row["probe"], 1024) for delta in (-8, 0, 8)]
        rows.append({"source_config_id": source_row["config_id"], "probe": source_row["probe"],
                     "direction_order": direction_order(source_row["probe"]), "classes": classes,
                     "all_future_writable": all(item["future_writable"] for item in classes),
                     "transition_counts": [item["post16_delta_transitions"] for item in classes]})
    survivors = [row for row in rows if row["all_future_writable"]]
    result = seal({
        "schema": "dee.v27.ing03.nature.discovery.weak_probe_backaction_classes.v1",
        "question": "Across axis, face-diagonal, and corner-diagonal tangential geometries, can an individually informative s_reg=0/1/3 interaction preserve recurrent writing?",
        "selection_rule": "Canonical first informative geometry for each available direction order at every weak level; no outcome-dependent selection.",
        "source": str(source_path.relative_to(ROOT)).replace("\\", "/"),
        "rows": rows, "selected_count": len(rows), "survivor_count": len(survivors),
        "survivor_ids": [row["source_config_id"] for row in survivors],
        "quorum_prerequisite": "PASS" if any(row["probe"]["sreg"] == 0 and row["all_future_writable"] for row in rows) else "FAIL_IN_TESTED_CLASSES",
        "claim_guard": "This closes tested weak single-interaction prerequisites, not every possible distributed organization.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_NATURE_N11_WEAK_PROBE_BACKACTION_CLASSES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "selected": len(rows), "survivors": len(survivors),
                      "rows": [{"id": row["source_config_id"], "level": row["probe"]["sreg"],
                                "order": row["direction_order"], "transitions": row["transition_counts"]}
                               for row in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
