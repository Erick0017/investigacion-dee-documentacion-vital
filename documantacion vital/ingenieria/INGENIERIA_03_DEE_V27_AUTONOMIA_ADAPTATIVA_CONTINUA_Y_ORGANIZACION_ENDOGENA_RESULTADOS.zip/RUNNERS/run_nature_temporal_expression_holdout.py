#!/usr/bin/env python3
"""Fresh holdout for counterfactual stored-state temporal/spatial expression."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, full_sha, load_kernel, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import build, policy_class
from run_nature_n05_stored_master_causality import set_both, substitute_delta


def toroidal_chebyshev(a, b, n):
    return max(min((a[i] - b[i]) % n, (b[i] - a[i]) % n) for i in range(3))


def delta_value(world, meta):
    ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])


def main():
    freeze_path = ROOT / "FREEZE/ING03_NATURE_TEMPORAL_EXPRESSION_LOCK.json"
    challenge_path = ROOT / "HOLDOUT/ING03_NATURE_TEMPORAL_EXPRESSION_CHALLENGES.json"
    freeze = json.loads(freeze_path.read_text(encoding="utf-8"))
    challenge = json.loads(challenge_path.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    targets = challenge["fresh_target_deltas"]
    reference_delta = challenge["reference_delta"]
    built = [build(kernel, initial_delta=freeze["fixed"]["common_initial_delta"], with_writer=True) for _ in targets]
    canary_world, canary_meta = build(kernel, initial_delta=freeze["fixed"]["common_initial_delta"], with_writer=True)
    worlds = [item[0] for item in built]; metas = [item[1] for item in built]
    pre_hashes = None; post_hashes = {str(target): hashlib.sha256() for target in targets}; canary_hash = hashlib.sha256()
    first_far = {str(target): None for target in targets if target != reference_delta}
    max_radius = {str(target): 0 for target in targets if target != reference_delta}
    exact_installs = []; samples = {str(target): [] for target in targets}; canary_samples = []
    for tick in range(1, freeze["fixed"]["horizon"] + 1):
        for world in worlds: world.tick()
        canary_world.tick()
        if tick == freeze["fixed"]["common_history_through_tick"]:
            pre_hashes = [full_sha(world.raw, world.clock_a) for world in worlds] + [full_sha(canary_world.raw, canary_world.clock_a)]
        if tick == 800:
            for target, world, meta in zip(targets, worlds, metas):
                set_both(world, meta["writer"], 0); substitute_delta(world, meta, target)
                exact_installs.append({"target": target, "observed": delta_value(world, meta)})
            set_both(canary_world, canary_meta["writer"], 0)
            set_both(canary_world, canary_meta["a"], 0); set_both(canary_world, canary_meta["b"], 0)
        if tick < 800:
            continue
        for target, world, meta in zip(targets, worlds, metas):
            output = read(world.raw, meta["c"])
            item = {"tick": tick, "delta": delta_value(world, meta), "output_class": policy_class(output),
                    "direction": None if output is None else output["direction"], "raw": None if output is None else output["raw"]}
            post_hashes[str(target)].update(json.dumps(item, sort_keys=True, separators=(",", ":")).encode("utf-8"))
            if tick in {800, 801, 804, 808, 816, 824, 832, 840, 860, 880, 900}:
                samples[str(target)].append(item)
        output = read(canary_world.raw, canary_meta["c"])
        canary_item = {"tick": tick, "delta": delta_value(canary_world, canary_meta),
                       "output_class": policy_class(output), "direction": None if output is None else output["direction"]}
        canary_hash.update(json.dumps(canary_item, sort_keys=True, separators=(",", ":")).encode("utf-8"))
        if tick in {800, 801, 804, 808, 816, 824, 832, 840, 860, 880, 900}:
            canary_samples.append(canary_item)
        reference = worlds[targets.index(reference_delta)]
        reference_meta = metas[targets.index(reference_delta)]
        excluded = {reference_meta["a"], reference_meta["b"], reference_meta["c"], reference_meta["writer"]}
        excluded |= {position for position, _ in reference_meta["sources"]}
        for target, world in zip(targets, worlds):
            if target == reference_delta:
                continue
            for row in np.argwhere(world.raw != reference.raw):
                q = tuple(int(value) for value in row)
                if q in excluded:
                    continue
                radius = toroidal_chebyshev(q, reference_meta["c"], reference_meta["n"])
                max_radius[str(target)] = max(max_radius[str(target)], radius)
                if radius >= 3 and first_far[str(target)] is None:
                    first_far[str(target)] = tick
    hashes = {key: value.hexdigest() for key, value in post_hashes.items()}
    history_identity = pre_hashes is not None and len(set(pre_hashes)) == 1
    exact = all(item["target"] == item["observed"] for item in exact_installs)
    distinct = len(set(hashes.values()))
    far_passes = sum(value is not None for value in first_far.values())
    master_ablation_changes = canary_hash.hexdigest() != hashes[str(reference_delta)]
    passed = history_identity and exact and distinct >= 4 and far_passes >= 5 and master_ablation_changes
    result = seal({
        "schema": "dee.v27.ing03.nature.holdout.temporal_expression_results.v1",
        "freeze": str(freeze_path.relative_to(ROOT)).replace("\\", "/"),
        "challenge": str(challenge_path.relative_to(ROOT)).replace("\\", "/"),
        "fresh_target_deltas": targets, "reference_delta": reference_delta,
        "pre_intervention_world_hashes": pre_hashes,
        "history_identity_pass": history_identity, "exact_state_install_pass": exact,
        "exact_installs": exact_installs, "trajectory_hashes": hashes,
        "distinct_temporal_trajectories": distinct,
        "first_remote_difference_tick": first_far, "maximum_radius": max_radius,
        "remote_states_passing": far_passes,
        "master_ablation_trajectory_sha256": canary_hash.hexdigest(),
        "master_ablation_changes_output": master_ablation_changes,
        "samples": samples, "master_ablation_samples": canary_samples,
        "pass_criterion": freeze["pass_criterion"], "passed": passed,
        "post_freeze_tuning": False,
        "python_intervention_disclosure": freeze["python_intervention_disclosure"],
        "claim_scope": "counterfactually installed stored states select later native temporal/spatial dynamics; not native learning or RW2",
        "runtime": runtime,
    })
    output_path = ROOT / "HOLDOUT/ING03_NATURE_TEMPORAL_EXPRESSION_HOLDOUT.json"
    write_json(output_path, result)
    print(json.dumps({"output": str(output_path), "passed": passed, "history_identity": history_identity,
                      "exact_install": exact, "distinct": distinct, "remote_passes": far_passes,
                      "master_ablation_changes": master_ablation_changes,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
