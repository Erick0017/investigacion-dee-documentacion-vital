#!/usr/bin/env python3
"""Screen native t0-complete B pressures against the established A-history/P1 regime."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
DISTANCES = (4, 8, 12, 16, 20)
CLOCKS = (0, 128, 252)
TARGETS = ("a", "b")
HORIZON = 512
CHECKPOINTS = {1, 9, 64, 96, 125, 138, 140, 141, 160, 184, 208, 256, 320, 384, 448, 512}


def install_pressure(world, meta, node, target_name, distance, clock):
    target = node[target_name]
    event = add(target, meta["tf"]((0, -1, 0)), 1, meta["n"])
    direction = meta["tf"]((0, 0, 1))
    source = add(event, direction, -distance, meta["n"])
    if int(world.raw[source]): raise RuntimeError(f"B-pressure overlap {source}")
    raw = int(pack(43000 + distance + (100 if target_name == "b" else 0), 0, direction, 4))
    world.raw_a[source] = np.uint64(raw); world.raw_b[source] = np.uint64(raw)
    world.clock_a[source] = np.uint64(clock); world.clock_b[source] = np.uint64(clock)
    return source, raw


def order_parameters(world):
    raw = world.raw
    occupied = raw != 0
    values = raw[occupied]
    if not len(values): return {"occupied": 0, "semantic_histogram": {}, "nonzero_sreg": 0}
    semantics = ((values >> np.uint64(60)) & np.uint64(0xF)).astype(np.uint8)
    sreg = ((values >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.uint16)
    return {"occupied": int(len(values)),
            "semantic_histogram": {str(i): int((semantics == i).sum()) for i in np.unique(semantics)},
            "nonzero_sreg": int((sreg != 0).sum()),
            "raw_sha256": hashlib.sha256(raw.tobytes(order="C")).hexdigest()}


def run_pair(kernel, architecture, target, distance, clock):
    try:
        treatment, meta, node = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
        control, control_meta, control_node = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
        a_source, a_raw = d15.install_source(treatment, meta, architecture)
        control_a_source, control_a_raw = d15.install_source(control, control_meta, architecture)
        b_source, b_raw = install_pressure(treatment, meta, node, target, distance, clock)
    except RuntimeError as exc:
        return {"valid": False, "reason": str(exc), "target": target, "distance": distance, "clock": clock}
    previous = {"p0_t": delta_value(treatment, meta), "p0_c": delta_value(control, control_meta),
                "p1_t": d15.reserve_delta(treatment, node), "p1_c": d15.reserve_delta(control, control_node)}
    transitions = {key: [] for key in previous}; checkpoints = []
    pair_difference_ticks = 0; difference_counts = []
    p1_last_change = None
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        values = {"p0_t": delta_value(treatment, meta), "p0_c": delta_value(control, control_meta),
                  "p1_t": d15.reserve_delta(treatment, node), "p1_c": d15.reserve_delta(control, control_node)}
        for key, value in values.items():
            if value != previous[key]:
                transitions[key].append({"tick": tick, "before": previous[key], "after": value})
                if key == "p1_t": p1_last_change = tick
        previous = values
        pt, pc = pair(treatment, meta), pair(control, control_meta)
        pair_difference_ticks += int(pt != pc)
        difference_counts.append(int((treatment.raw != control.raw).sum()))
        if tick in CHECKPOINTS:
            checkpoints.append({"tick": tick, "values": dict(values), "treatment_pair": pt,
                                "control_pair": pc, "difference_count": difference_counts[-1],
                                "treatment_order": order_parameters(treatment),
                                "control_order": order_parameters(control)})
    post_a_changes = [row for row in transitions["p1_t"] if row["tick"] > 140]
    retained_after_late_change = bool(p1_last_change and p1_last_change > 140 and
                                      HORIZON - p1_last_change >= 64 and previous["p1_t"] != previous["p1_c"])
    return {"valid": True, "target": target, "distance": distance, "clock": clock,
            "a_source": list(a_source), "b_source": list(b_source),
            "a_source_persistent": int(treatment.raw[a_source]) == a_raw and int(control.raw[control_a_source]) == control_a_raw,
            "b_source_persistent": int(treatment.raw[b_source]) == b_raw,
            "transitions": transitions, "terminal": previous, "post_tick140_p1_changes": post_a_changes,
            "retained_post140_p1_transition": retained_after_late_change,
            "pair_difference_ticks": pair_difference_ticks, "maximum_world_difference": max(difference_counts),
            "terminal_world_difference": difference_counts[-1], "checkpoints": checkpoints,
            "python_interventions_after_t0": 0}


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8")); architecture = dict(lock["architecture"])
    architecture["horizon"] = HORIZON
    kernel, runtime = load_kernel(1); rows = []
    # D09 found clock phase irrelevant, and this campaign pre-screened all three phases at
    # target-a/distance4 with the same null. Keep that triplet, then vary causal geometry only.
    specs = [("a", 4, clock) for clock in CLOCKS]
    specs += [(target, distance, 0) for target in TARGETS for distance in DISTANCES
              if not (target == "a" and distance == 4)]
    for target, distance, clock in specs:
        row = run_pair(kernel, architecture, target, distance, clock); rows.append(row)
        print(json.dumps({"target": target, "distance": distance, "clock": clock,
                          "valid": row.get("valid"), "late": row.get("post_tick140_p1_changes"),
                          "retained": row.get("retained_post140_p1_transition")}, sort_keys=True), flush=True)
    candidates = [row for row in rows if row.get("valid") and row.get("retained_post140_p1_transition") and
                  row["terminal"]["p0_t"] == 1 and row["pair_difference_ticks"] > 0]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.drt01_second_experience_interference.v1",
        "question": "Can a causally distinct persistent B pressure intersect the established A landscape and natively produce a later retained transition?",
        "planning": {"families": ["H1 smooth conversion", "H2 destabilization", "H5 native order-parameter transition"],
            "world_pairs": len(specs), "ticks_per_world": HORIZON,
            "kernel_worlds": 2 * len(specs), "estimated_storage_mb": 8,
            "information_gain": "distinguishes no coupling, early contamination, late conversion and retained transition",
            "stop_condition": "two target signs x five spatial delays x three source phases"},
        "design": {"all_components_at_t0": True, "python_interventions_after_t0": 0,
                   "initial_environment": "A consequence plus answer-neutral DR03 source",
                   "second_pressure": "persistent semantic4 state aimed at P1 a or b surface",
                   "targets": list(TARGETS), "distances": list(DISTANCES), "phase_prescreen": list(CLOCKS),
                   "phase_saturation_rule": "all phases at target-a/distance4; clock0 elsewhere after identical nulls",
                   "horizon": HORIZON},
        "rows": rows,
        "summary": {"valid_configurations": sum(row.get("valid", False) for row in rows),
                    "late_retained_transition_candidates": len(candidates),
                    "candidate_keys": [{"target": row["target"], "distance": row["distance"], "clock": row["clock"],
                                        "late_changes": row["post_tick140_p1_changes"], "terminal": row["terminal"],
                                        "pair_difference_ticks": row["pair_difference_ticks"]} for row in candidates],
                    "second_independent_experience_demonstrated": False,
                    "native_regime_reversal_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "The B pressure is encoded as a persistent t0 source for discovery. Even a late transition is not promoted as independent adaptive experience until causal separation, answer-leakage controls and native environmental generation pass.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT01_SECOND_EXPERIENCE_INTERFERENCE.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
