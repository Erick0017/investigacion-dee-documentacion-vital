#!/usr/bin/env python3
"""Test competing and distributed native pressures against the established A regime."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


IDENTITY = ((0, 1, 2), (1, 1, 1))
HORIZON = 384
CHECKPOINTS = (64, 96, 125, 138, 140, 160, 184, 208, 256, 320, 384)
CONFIGS = (
    {"id": "single_axial_a_d10", "target": "a", "directions": [(0, 0, 1)], "distance": 10},
    {"id": "single_diag_a_d10", "target": "a", "directions": [(-1, -1, 1)], "distance": 10},
    {"id": "single_mirror_a_d10", "target": "a", "directions": [(1, -1, 1)], "distance": 10},
    {"id": "single_reverse_a_d10", "target": "a", "directions": [(1, 1, -1)], "distance": 10},
    {"id": "single_diag_a_d4", "target": "a", "directions": [(-1, -1, 1)], "distance": 4},
    {"id": "single_diag_a_d16", "target": "a", "directions": [(-1, -1, 1)], "distance": 16},
    {"id": "distributed3_a_d10", "target": "a", "directions": [(0, 0, 1), (-1, -1, 1), (1, -1, 1)], "distance": 10},
    {"id": "distributed6_a_d10", "target": "a", "directions": [(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1)], "distance": 10},
    {"id": "same_target_b_control", "target": "b", "directions": [(-1, -1, 1)], "distance": 10},
)


def install_pressure(world, meta, config):
    target = meta[config["target"]]; sources = []
    for index, canonical_direction in enumerate(config["directions"]):
        direction = meta["tf"](canonical_direction)
        event = add(target, meta["tf"]((0, -1, 0)), 1, meta["n"])
        source = add(event, direction, -config["distance"], meta["n"])
        if int(world.raw[source]): raise RuntimeError(f"pressure overlap {source}")
        raw = int(pack(44000 + 100 * index + config["distance"], 0, direction, 4))
        world.raw_a[source] = np.uint64(raw); world.raw_b[source] = np.uint64(raw)
        world.clock_a[source] = np.uint64(0); world.clock_b[source] = np.uint64(0)
        sources.append((source, raw))
    return sources


def build_world(kernel, architecture, config=None):
    world, meta, p1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    a_source, a_raw = d15.install_source(world, meta, architecture)
    pressures = [] if config is None else install_pressure(world, meta, config)
    return world, meta, p1, a_source, a_raw, pressures


def run_world(kernel, architecture, config=None, baseline=None):
    try: world, meta, p1, a_source, a_raw, pressures = build_world(kernel, architecture, config)
    except RuntimeError as exc: return {"valid": False, "reason": str(exc)}, None
    previous = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
    transitions = {"p0": [], "p1": []}; pairs = []; checkpoints = []
    for tick in range(1, HORIZON + 1):
        world.tick(); values = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
        for key in values:
            if values[key] != previous[key]: transitions[key].append({"tick": tick, "before": previous[key], "after": values[key]})
        previous = values; pairs.append(pair(world, meta))
        if tick in CHECKPOINTS:
            item = {"tick": tick, "p0": values["p0"], "p1": values["p1"], "pair": pairs[-1],
                    "occupied": int((world.raw != 0).sum()),
                    "raw_sha256": hashlib.sha256(world.raw.tobytes(order="C")).hexdigest()}
            if baseline is not None:
                base = baseline["checkpoint_raws"][str(tick)]
                item["baseline_difference"] = int((world.raw != base).sum())
            checkpoints.append(item)
    late = [row for row in transitions["p1"] if row["tick"] > 140]
    result = {"valid": True, "transitions": transitions, "terminal": previous,
              "pair_sequence": pairs, "checkpoints": checkpoints,
              "a_source_persistent": int(world.raw[a_source]) == a_raw,
              "pressure_sources_persistent": all(int(world.raw[q]) == raw for q, raw in pressures),
              "python_interventions_after_t0": 0}
    if config is None: result["checkpoint_raws"] = {str(t): None for t in CHECKPOINTS}
    result["post140_p1_changes"] = late
    return result, world


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8")); architecture = dict(lock["architecture"])
    kernel, runtime = load_kernel(1)
    base_result, base_world_final = run_world(kernel, architecture)
    # Re-run the single baseline while retaining only checkpoint arrays; it is one control for all treatments.
    base, meta, p1, _, _, _ = build_world(kernel, architecture, None)
    raw_by_tick = {}; pair_by_tick = []
    for tick in range(1, HORIZON + 1):
        base.tick(); pair_by_tick.append(pair(base, meta))
        if tick in CHECKPOINTS: raw_by_tick[str(tick)] = base.raw.copy()
    baseline = {"checkpoint_raws": raw_by_tick, "pair_sequence": pair_by_tick,
                "transitions": base_result["transitions"], "terminal": base_result["terminal"]}
    rows = []
    for config in CONFIGS:
        outcome, _ = run_world(kernel, architecture, config, baseline)
        if outcome.get("valid"):
            outcome["pair_difference_ticks"] = sum(a != b for a, b in zip(outcome["pair_sequence"], pair_by_tick))
            outcome.pop("pair_sequence", None)
        rows.append({"config": config, "outcome": outcome})
        print(json.dumps({"id": config["id"], "valid": outcome.get("valid"),
                          "late": outcome.get("post140_p1_changes"),
                          "pair_difference_ticks": outcome.get("pair_difference_ticks")}, sort_keys=True), flush=True)
    candidates = [row for row in rows if row["outcome"].get("valid") and row["outcome"].get("post140_p1_changes") and
                  row["outcome"]["terminal"]["p0"] == 1 and row["outcome"].get("pair_difference_ticks", 0) > 0]
    base_result.pop("checkpoint_raws", None); base_result.pop("pair_sequence", None)
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.drt02_distributed_destabilization.v1",
        "question": "Can point competition or distributed persistent B pressure destabilize/remature the established A-history regime?",
        "planning": {"families": ["H2 critical transition", "H3 stratification", "H10 morphology"],
                     "treatment_worlds": len(CONFIGS), "shared_baseline_worlds": 2, "ticks_per_world": HORIZON,
                     "estimated_storage_mb": 4, "information_gain": "contrasts sign, direction, distance and spatial extent",
                     "stop_condition": "four directions, two distance controls, 3-source and 6-source pressure"},
        "design": {"all_components_at_t0": True, "python_interventions_after_t0": 0,
                   "baseline": "DR03 A-history plus original answer-neutral source", "configs": list(CONFIGS)},
        "baseline": base_result, "rows": rows,
        "summary": {"valid_configurations": sum(row["outcome"].get("valid", False) for row in rows),
                    "post140_order_parameter_transitions": sum(bool(row["outcome"].get("post140_p1_changes")) for row in rows),
                    "candidate_count": len(candidates), "candidate_ids": [row["config"]["id"] for row in candidates],
                    "adaptive_rematuration_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "These pressures are frozen at t0 and test causal conversion classes. A positive transition would still require independent-environment, retention, functional and fresh controls before promotion.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT02_DISTRIBUTED_DESTABILIZATION.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
