#!/usr/bin/env python3
"""Construct early and late native consequences in one interacting landscape."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2


N = 41
HORIZON = 256
REMOTE_OFFSET = (-6, 7, 8)
FIRST_DISTANCE = 18
FIRST_PHASE = 240
SECOND_DISTANCE = 40
SECOND_PHASE = (252 - (SECOND_DISTANCE - 6)) & 255
SOURCE_DISTANCES = (24, 24, 32, 24)
C1_OFFSETS = ((12, -12, 10), (-12, 12, 10), (10, 12, -12), (-10, -12, -12), (14, 9, 11))
CONDITIONS = (
    ("AB", "a", "b", "treatment"),
    ("A_SHAM", "a", None, "treatment"),
    ("SHAM_B", None, "b", "treatment"),
    ("AA", "a", "a", "treatment"),
    ("BA", "b", "a", "treatment"),
    ("A_B_MISSING_D1", "a", "b", "missing_d1"),
)
CHECKPOINTS = {1, 9, 21, 30, 38, 42, 43, 44, 52, 64, 80, 96, 128, 160, 192, 224, 256}


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def add_organ(raw, clock, center, target, distance, phase, state_base, generator_mode="treatment"):
    a = add(center, (-1, 0, 0), 1, N); b = add(center, (1, 0, 0), 1, N)
    put(raw, clock, a, state_base + 1, 100, semantic=1, phase=phase)
    put(raw, clock, b, state_base + 2, 100, semantic=1, phase=phase)
    for i, rel in enumerate(PA): put(raw, clock, add(a, rel, 1, N), state_base + 100 + i, 0, semantic=4, phase=31 + i)
    for i, rel in enumerate(PB): put(raw, clock, add(b, rel, 1, N), state_base + 200 + i, 0, semantic=4, phase=41 + i)
    generator_positions = []
    if target in ("a", "b"):
        target_q = a if target == "a" else b; event = add(target_q, (0, -1, 0), 1, N)
        route = (0, 0, 1); generator = add(event, route, -distance, N)
        for label, direction, sid in (("d1", (1, 0, 1), 1), ("d2", (-1, 0, 1), 2)):
            if generator_mode == f"missing_{label}": continue
            q = add(generator, direction, -1, N)
            put(raw, clock, q, state_base + 500 + sid, 3, direction, 1, phase=0); generator_positions.append(q)
    qp = add(center, P, 1, N)
    anchors = (qp, qp, center, center); directions = (S1, S2, N1, N2); sregs = (11, 13, 17, 19)
    sources = []
    for i, (anchor, direction, sreg, source_distance) in enumerate(zip(anchors, directions, sregs, SOURCE_DISTANCES)):
        q = add(anchor, direction, -source_distance, N)
        put(raw, clock, q, state_base + 700 + i, sreg, direction, 4, phase=100 + i); sources.append(q)
    remote = add(center, REMOTE_OFFSET, 1, N); remote_qp = add(remote, P, 1, N)
    put(raw, clock, remote, state_base + 900, 7, P, 1, 11)
    specs = ((add(remote_qp, S1, -1, N), S1, 11), (add(remote_qp, S2, -1, N), S2, 13),
             (add(remote, N1, -2, N), N1, 17), (add(remote, N2, -2, N), N2, 19))
    for i, (q, direction, sreg) in enumerate(specs):
        put(raw, clock, q, state_base + 1000 + i, sreg, direction, 4, 100 + i)
    return {"center": center, "a": a, "b": b, "remote": remote, "remote_qp": remote_qp,
            "generators": generator_positions, "sources": sources, "target": target,
            "distance": distance, "phase": phase}


def build(kernel, first, second, second_mode):
    errors = []
    for offset in C1_OFFSETS:
        raw = np.zeros((N, N, N), np.uint64); clock = np.zeros_like(raw); c0 = (N // 2,) * 3
        try:
            org0 = add_organ(raw, clock, c0, first, FIRST_DISTANCE, FIRST_PHASE, 10000)
            c1 = add(c0, offset, 1, N)
            org1 = add_organ(raw, clock, c1, second, SECOND_DISTANCE, SECOND_PHASE, 30000, second_mode)
            return NativeWorld(kernel, raw, clock), org0, org1, offset
        except RuntimeError as exc: errors.append({"offset": offset, "reason": str(exc)})
    raise RuntimeError(json.dumps(errors))


def delta(world, organ):
    a, b = read(world.raw, organ["a"]), read(world.raw, organ["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def remote_pair(world, organ):
    return (int(world.raw[organ["remote"]]), int(world.raw[organ["remote_qp"]]))


def run(kernel, name, first, second, second_mode):
    try: world, org0, org1, offset = build(kernel, first, second, second_mode)
    except RuntimeError as exc: return {"name": name, "valid": False, "reason": str(exc)}
    previous = {"first": delta(world, org0), "second": delta(world, org1)}
    transitions = {"first": [], "second": []}; pair0 = []; pair1 = []; raw_hashes = []; samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); values = {"first": delta(world, org0), "second": delta(world, org1)}
        for key in values:
            if values[key] != previous[key]: transitions[key].append({"tick": tick, "before": previous[key], "after": values[key]})
        previous = values; p0 = remote_pair(world, org0); p1 = remote_pair(world, org1)
        pair0.append(p0); pair1.append(p1)
        raw_hashes.append(hashlib.sha256(world.raw.tobytes(order="C")).hexdigest() if tick in CHECKPOINTS else None)
        if tick in CHECKPOINTS:
            samples.append({"tick": tick, "first_delta": values["first"], "second_delta": values["second"],
                            "first_function": p0, "second_function": p1,
                            "occupied": int((world.raw != 0).sum()), "raw_sha256": raw_hashes[-1]})
    return {"name": name, "valid": True, "first": first, "second": second, "second_mode": second_mode,
            "selected_second_offset": list(offset), "transitions": transitions, "terminal": previous,
            "pair0_sequence": pair0, "pair1_sequence": pair1, "samples": samples,
            "sources_persistent": all(int(world.raw[q]) != 0 for q in org0["sources"] + org1["sources"]),
            "python_interventions_after_t0": 0}


def first_difference(a, b, start=1):
    return next((tick for tick, (x, y) in enumerate(zip(a, b), 1) if tick >= start and x != y), None)


def main():
    kernel, runtime = load_kernel(1); rows = []
    for spec in CONDITIONS:
        row = run(kernel, *spec); rows.append(row)
        print(json.dumps({"name": spec[0], "valid": row.get("valid"), "transitions": row.get("transitions"),
                          "terminal": row.get("terminal")}, sort_keys=True), flush=True)
    by = {row["name"]: row for row in rows if row.get("valid")}
    metrics = {}
    if len(by) == len(CONDITIONS):
        ab, ash, sb, aa, ba, broken = (by[k] for k in ("AB", "A_SHAM", "SHAM_B", "AA", "BA", "A_B_MISSING_D1"))
        a_function_tick = first_difference(ab["pair0_sequence"], sb["pair0_sequence"])
        b_effect_tick = first_difference(ab["pair1_sequence"], ash["pair1_sequence"])
        b_write_tick = next((r["tick"] for r in ab["transitions"]["second"] if r["after"] not in (0, None)), None)
        metrics = {"first_A_function_difference_tick": a_function_tick, "second_B_write_tick": b_write_tick,
                   "second_B_function_difference_tick": b_effect_tick,
                   "A_function_before_B_write": a_function_tick is not None and b_write_tick is not None and a_function_tick < b_write_tick,
                   "B_effect_after_B_write": b_effect_tick is not None and b_write_tick is not None and b_effect_tick > b_write_tick,
                   "broken_B_generator_equals_A_SHAM_terminal": broken["terminal"] == ash["terminal"] and broken["pair1_sequence"][-1] == ash["pair1_sequence"][-1],
                   "AB_vs_BA_terminal_order_specific": (ab["terminal"], ab["pair0_sequence"][-1], ab["pair1_sequence"][-1]) !=
                                                       (ba["terminal"], ba["pair0_sequence"][-1], ba["pair1_sequence"][-1]),
                   "AB_vs_AA_terminal_distinct": (ab["terminal"], ab["pair1_sequence"][-1]) != (aa["terminal"], aa["pair1_sequence"][-1])}
    for row in rows:
        if row.get("valid"):
            row["pair0_sha256"] = hashlib.sha256(json.dumps(row.pop("pair0_sequence"), separators=(",", ":")).encode()).hexdigest()
            row["pair1_sha256"] = hashlib.sha256(json.dumps(row.pop("pair1_sequence"), separators=(",", ":")).encode()).hexdigest()
    partial = bool(metrics.get("A_function_before_B_write") and metrics.get("B_effect_after_B_write") and metrics.get("AB_vs_AA_terminal_distinct"))
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.drt03_native_ordered_experiences.v1",
        "question": "Can one t0-complete landscape express A, then receive an independent route-delayed B consequence and produce a later B-specific function?",
        "planning": {"families": ["H3 stratification", "H6 collective transition", "H10 morphological adaptation"],
                     "worlds": len(CONDITIONS), "ticks_per_world": HORIZON, "estimated_storage_mb": 3,
                     "information_gain": "directly tests two native consequence times and two functional organizations",
                     "stop_condition": "AB plus order/repetition/sham/broken-generator controls"},
        "design": {"n": N, "first_distance": FIRST_DISTANCE, "first_phase": FIRST_PHASE,
                   "second_distance": SECOND_DISTANCE, "second_phase": SECOND_PHASE,
                   "all_components_at_t0": True, "python_interventions_after_t0": 0,
                   "future_state_preassigned_to_second_organ": True},
        "rows": rows, "metrics": metrics,
        "summary": {"valid_conditions": len(by), "two_native_experiences_with_later_function_candidate": partial,
                    "state_dependent_shared_landscape_transition_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "The second answer and destination are preassigned in this diagnostic architecture. A positive result proves compatibility/timing and possible stratification, not state-selected recurrent adaptation or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT03_NATIVE_ORDERED_EXPERIENCES.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "metrics": metrics,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
