#!/usr/bin/env python3
"""Retest ordered A then B in the validated N83/distance80 scheduling domain."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_open_drt03_native_ordered_experiences as d03


CONDITIONS = (
    ("AB", "a", "b", "treatment"),
    ("A_SHAM", "a", None, "treatment"),
    ("SHAM_B", None, "b", "treatment"),
    ("A_B_MISSING_D1", "a", "b", "missing_d1"),
)


def first_difference(a, b, start=1):
    return next((tick for tick, (x, y) in enumerate(zip(a, b), 1) if tick >= start and x != y), None)


def main():
    d03.N = 83; d03.HORIZON = 160; d03.FIRST_DISTANCE = 18; d03.FIRST_PHASE = 240
    d03.SECOND_DISTANCE = 80; d03.SECOND_PHASE = (252 - (80 - 6)) & 255
    d03.C1_OFFSETS = ((30, -30, 25), (-30, 30, 25), (25, 30, -30), (-25, -30, -30))
    d03.CHECKPOINTS = {1, 21, 30, 38, 64, 80, 82, 83, 84, 96, 112, 128, 144, 160}
    kernel, runtime = load_kernel(1); rows = []
    for spec in CONDITIONS:
        row = d03.run(kernel, *spec); rows.append(row)
        print(json.dumps({"name": spec[0], "valid": row.get("valid"), "transitions": row.get("transitions"),
                          "terminal": row.get("terminal")}, sort_keys=True), flush=True)
    by = {row["name"]: row for row in rows if row.get("valid")}; metrics = {}
    if len(by) == len(CONDITIONS):
        ab, ash, sb, broken = (by[k] for k in ("AB", "A_SHAM", "SHAM_B", "A_B_MISSING_D1"))
        a_func = first_difference(ab["pair0_sequence"], sb["pair0_sequence"])
        b_write = next((x["tick"] for x in ab["transitions"]["second"] if x["after"] not in (0, None)), None)
        b_effect_any = first_difference(ab["pair1_sequence"], ash["pair1_sequence"])
        b_effect_post = first_difference(ab["pair1_sequence"], ash["pair1_sequence"], (b_write or 160) + 1)
        broken_write = next((x["tick"] for x in broken["transitions"]["second"] if x["after"] not in (0, None)), None)
        metrics = {"first_A_function_difference_tick": a_func, "second_B_write_tick": b_write,
                   "second_B_effect_first_any_tick": b_effect_any, "second_B_effect_first_post_write_tick": b_effect_post,
                   "A_function_before_B_write": a_func is not None and b_write is not None and a_func < b_write,
                   "B_effect_after_B_write": b_effect_post is not None,
                   "broken_generator_second_write_tick": broken_write,
                   "broken_generator_blocks_second_write": broken_write is None,
                   "A_preserved_after_B": ab["terminal"]["first"] == 1}
    for row in rows:
        if row.get("valid"):
            p0 = row.pop("pair0_sequence"); p1 = row.pop("pair1_sequence")
            row["pair0_sha256"] = hashlib.sha256(json.dumps(p0, separators=(",", ":")).encode()).hexdigest()
            row["pair1_sha256"] = hashlib.sha256(json.dumps(p1, separators=(",", ":")).encode()).hexdigest()
    partial = bool(metrics.get("A_function_before_B_write") and metrics.get("B_effect_after_B_write") and
                   metrics.get("broken_generator_blocks_second_write") and metrics.get("A_preserved_after_B"))
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.drt04_large_world_ordered_chain.v1",
        "question": "In the validated N83/distance80 domain, can A function before an independent native B write and B-specific later effect?",
        "planning": {"families": ["H3 stratification", "H10 morphological adaptation"], "worlds": len(CONDITIONS),
                     "ticks_per_world": d03.HORIZON, "world_shape": [83, 83, 83], "estimated_storage_mb": 4,
                     "information_gain": "removes the distance40 toroidal/sham artifact",
                     "stop_condition": "AB, A-sham, sham-B and missing-B-generator"},
        "design": {"first": {"distance": 18, "phase": 240}, "second": {"distance": 80, "phase": d03.SECOND_PHASE},
                   "all_components_at_t0": True, "python_interventions_after_t0": 0,
                   "future_state_preassigned_to_second_organ": True},
        "rows": rows, "metrics": metrics,
        "summary": {"valid_conditions": len(by), "two_native_experiences_with_later_function_candidate": partial,
                    "state_selected_destination": False, "rw3_demonstrated": False},
        "claim_guard": "A positive chain remains diagnostic/configured because the second answer and organ are preassigned at t0. It cannot establish RW3 without state-selected destination and a third experience.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT04_LARGE_WORLD_ORDERED_CHAIN.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "metrics": metrics,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
