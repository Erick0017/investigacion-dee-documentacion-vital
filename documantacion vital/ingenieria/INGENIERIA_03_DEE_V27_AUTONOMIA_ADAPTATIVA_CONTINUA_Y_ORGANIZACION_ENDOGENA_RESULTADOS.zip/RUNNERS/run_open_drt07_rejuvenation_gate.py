#!/usr/bin/env python3
"""Gate controlled-rejuvenation work on the D15 reserve organization.

Before destructive variants are attempted, this diagnostic determines whether
the same exact directed interaction can write an uncommitted and an already
committed reserve at matched late ticks.  A destructive recovery experiment is
interpretable only if an age-matched uncommitted control remains competent.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, pack, seal, sha256_file, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15


LOCK_PATH = ROOT / "FREEZE/ING03_DR_D15_NATIVE_RESERVE_TRANSFER_LOCK.json"
OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT07_REJUVENATION_GATE.json"
HORIZON = 280
FRAME = ((0, 1, 2), (1, 1, 1))
SHIFT = (0, 0, 0)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw)
    world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock)
    world.clock_b[q] = np.uint64(clock)


def run_case(kernel, architecture, history: str, install_tick: int, direction: tuple[int, int, int] | None):
    world, meta, node = d15.build(kernel, FRAME, SHIFT, "A", architecture)
    source = None
    if history == "A_TRANSFER":
        source, _ = d15.install_source(world, meta, architecture)
    previous = d15.reserve_delta(world, node)
    transitions = []
    installed = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if direction is not None and tick == install_tick:
            writer_raw = int(pack(53000 + install_tick, 0, direction, 4))
            installed = {
                "q": list(node["writer_q"]),
                "direction": list(direction),
                "replaced_raw": int(world.raw[node["writer_q"]]),
                "writer_raw": writer_raw,
            }
            set_both(world, node["writer_q"], writer_raw, tick)
        current = d15.reserve_delta(world, node)
        if current != previous:
            transitions.append({"tick": tick, "before": previous, "after": current})
        previous = current
    post = [row for row in transitions if row["tick"] > install_tick] if direction is not None else []
    return {
        "history": history,
        "install_tick": install_tick if direction is not None else None,
        "direction": list(direction) if direction is not None else None,
        "source": list(source) if source is not None else None,
        "installed": installed,
        "transitions": transitions,
        "post_install_transitions": post,
        "terminal_delta": previous,
        "write_response_after_install": bool(post),
        "python_interventions_after_t0": 1 if direction is not None else 0,
        "intervention_class": "DIAGNOSTIC_INTERVENTION" if direction is not None else "T0_NATIVE_CONTROL",
    }


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    architecture = lock["architecture"]
    kernel, runtime = load_kernel(1)
    route = tuple(int(x) for x in architecture["probe_direction"])
    # The reserve's direct approach axis is +z in the identity frame.  Include
    # the D15 probe direction as a distinct control because it generated the
    # distributed transfer rather than a direct local write.
    directions = ((0, 0, 1), (0, 0, -1), route)
    rows = []
    for history in ("UNCOMMITTED", "A_TRANSFER"):
        rows.append(run_case(kernel, architecture, history, 0, None))
        for tick in (100, 142, 160, 208):
            for direction in directions:
                row = run_case(kernel, architecture, history, tick, direction)
                rows.append(row)
                print(json.dumps({"history": history, "tick": tick, "direction": direction,
                                  "post": row["post_install_transitions"]}, sort_keys=True), flush=True)

    # Remove transitions that occur in the no-writer trajectory at the same
    # absolute tick.  In particular, the native A transfer at tick 140 must not
    # be misattributed to a diagnostic writer installed at tick 100.
    baselines = {row["history"]: row for row in rows if row["direction"] is None}
    for row in rows:
        if row["direction"] is None:
            continue
        baseline_post = [transition for transition in baselines[row["history"]]["transitions"]
                         if transition["tick"] > row["install_tick"]]
        specific = [transition for transition in row["post_install_transitions"]
                    if transition not in baseline_post]
        row["baseline_post_install_transitions"] = baseline_post
        row["writer_specific_post_install_transitions"] = specific
        row["write_response_after_install"] = bool(specific)

    controls = [row for row in rows if row["history"] == "UNCOMMITTED" and row["direction"] is not None]
    committed = [row for row in rows if row["history"] == "A_TRANSFER" and row["direction"] is not None]
    late_control_competence = [row for row in controls if row["install_tick"] >= 142 and row["write_response_after_install"]]
    late_committed_competence = [row for row in committed if row["install_tick"] >= 142 and row["write_response_after_install"]]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.controlled_rejuvenation_gate.v1",
        "question": "Is a late destructive-rejuvenation test on the D15 reserve interpretable against an age-matched uncommitted competent control?",
        "planning": {
            "mechanism": "exact directed semantic4 writer installation at the D15 reserve before and after native A-history commitment",
            "controls": ["uncommitted no-source reserve", "native A-transfer reserve", "no-writer trajectories", "three writer directions", "four install times"],
            "predicted_outcomes": ["age-matched control competent but committed refractory", "both late competent", "both late noncompetent"],
            "estimated_runtime_minutes": 4,
            "stop_condition": "all 26 trajectories reach tick 280",
        },
        "rows": rows,
        "summary": {
            "uncommitted_late_write_responses": len(late_control_competence),
            "committed_late_write_responses": len(late_committed_competence),
            "age_matched_late_rejuvenation_gate_available": bool(late_control_competence),
            "destructive_rejuvenation_variants_justified": bool(late_control_competence and not late_committed_competence),
            "native_rejuvenation_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "interpretation_rule": "Damage cannot be credited with restoring competence at a tick when the undamaged age-matched uncommitted reserve is itself noncompetent under the same exact writer.",
        "claim_guard": "All writer installations are diagnostic. This gate neither performs destruction nor demonstrates native rejuvenation.",
        "evidence": [
            {"path": LOCK_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(LOCK_PATH), "content_sha256": lock.get("content_sha256")},
        ],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
