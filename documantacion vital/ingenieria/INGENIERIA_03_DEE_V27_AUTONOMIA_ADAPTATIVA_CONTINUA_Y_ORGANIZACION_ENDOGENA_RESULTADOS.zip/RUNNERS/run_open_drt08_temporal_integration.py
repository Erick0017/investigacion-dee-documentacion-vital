#!/usr/bin/env python3
"""Diagnostic transient-versus-persistent pressure test on the DRT02 frontier."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_open_drt02_distributed_destabilization as drt02
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT08_TEMPORAL_INTEGRATION.json"
DRT02_PATH = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT02_DISTRIBUTED_DESTABILIZATION.json"
HORIZON = 384
DURATIONS = (1, 4, 8, 16, 32, 64, 96, 128, None)
CONFIG = next(row for row in drt02.CONFIGS if row["id"] == "single_axial_a_d10")


def clear_source(world, q, tick):
    before = int(world.raw[q])
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(tick); world.clock_b[q] = np.uint64(tick)
    return before


def run_case(kernel, architecture, duration):
    world, meta, p1, _, _, pressures = drt02.build_world(kernel, architecture, CONFIG)
    if len(pressures) != 1:
        raise RuntimeError("DRT08 requires exactly one pressure source")
    pressure_q, pressure_raw = pressures[0]
    previous = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
    transitions = {"p0": [], "p1": []}
    pairs = []; counts = []; cleared = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if duration is not None and tick == duration:
            cleared = {"tick": tick, "q": list(pressure_q), "raw_before_clear": clear_source(world, pressure_q, tick)}
        current = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
        for key in current:
            if current[key] != previous[key]:
                transitions[key].append({"tick": tick, "before": previous[key], "after": current[key]})
        previous = current
        pairs.append(pair(world, meta)); counts.append(int(np.count_nonzero(world.raw)))
    return {
        "pressure_duration_ticks": "PERSISTENT" if duration is None else duration,
        "cleared": cleared,
        "pressure_source": list(pressure_q),
        "pressure_raw": pressure_raw,
        "pressure_present_terminal": int(world.raw[pressure_q]) == pressure_raw,
        "transitions": transitions,
        "terminal": previous,
        "receiver_pair_digest": hashlib.sha256(json.dumps(pairs, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "receiver_pair_first_64": pairs[:64],
        "receiver_pair_last_64": pairs[-64:],
        "occupied_count_checkpoints": {str(t): counts[t - 1] for t in (1, 8, 16, 32, 64, 96, 128, 140, 184, 256, 384)},
        "python_interventions_after_t0": 0 if duration is None else 1,
        "intervention_class": "T0_NATIVE_PERSISTENT_CONTROL" if duration is None else "DIAGNOSTIC_INTERVENTION",
    }


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8"))
    prior = json.loads(DRT02_PATH.read_text(encoding="utf-8"))
    architecture = dict(lock["architecture"])
    kernel, runtime = load_kernel(1)
    rows = []
    for duration in DURATIONS:
        row = run_case(kernel, architecture, duration)
        rows.append(row)
        print(json.dumps({"duration": row["pressure_duration_ticks"], "terminal": row["terminal"],
                          "p1_transitions": row["transitions"]["p1"]}, sort_keys=True), flush=True)

    outcomes = {}
    for row in rows:
        key = str(row["terminal"]["p1"])
        outcomes.setdefault(key, []).append(row["pressure_duration_ticks"])
    finite = [row for row in rows if isinstance(row["pressure_duration_ticks"], int)]
    distinct_finite_outcomes = len({row["terminal"]["p1"] for row in finite})
    persistent = next(row for row in rows if row["pressure_duration_ticks"] == "PERSISTENT")
    threshold_candidate = None
    for row in finite:
        if row["terminal"]["p1"] == persistent["terminal"]["p1"]:
            threshold_candidate = row["pressure_duration_ticks"]
            break
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.temporal_integration.v1",
        "question": "Does the A-history landscape distinguish brief from sustained competing pressure before the retained P1 outcome forms?",
        "planning": {
            "mechanism": "freeze DRT02 axial pressure geometry and vary only diagnostic source lifetime",
            "controls": ["1/4/8/16/32/64/96/128 tick pulses", "persistent t0 source", "same A-history source and geometry"],
            "predicted_outcomes": ["single encounter sufficient", "duration-dependent threshold", "graded/layered outcome"],
            "estimated_runtime_minutes": 2,
            "stop_condition": "all nine duration conditions reach tick 384",
        },
        "design": {
            "base_config": CONFIG,
            "durations": ["PERSISTENT" if value is None else value for value in DURATIONS],
            "host_clear_used_for_finite_pulses": True,
            "native_integration_claim_allowed": False,
        },
        "rows": rows,
        "outcome_groups": outcomes,
        "hypothesis_status": {
            "H14_transient_vs_persistent_integration": {
                "status": "DIAGNOSTIC_ONLY" if distinct_finite_outcomes > 1 else "BOUNDED_NULL",
                "duration_dependent_terminal_outcome": bool(distinct_finite_outcomes > 1),
                "shortest_tested_duration_matching_persistent_terminal": threshold_candidate,
                "scope": "one DRT02 axial pressure geometry during initial A/P1 formation; finite pulses use one explicit host removal",
            }
        },
        "summary": {
            "distinct_finite_terminal_p1_outcomes": distinct_finite_outcomes,
            "duration_dependence_observed": bool(distinct_finite_outcomes > 1),
            "native_temporal_integrator_demonstrated": False,
            "second_independent_experience_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "next_native_test": "If duration dependence exists, replace host removal with frozen t0 route length, finite moving carriers, or an endogenous source lifetime and verify the same threshold forward.",
        "claim_guard": "Finite-duration conditions are diagnostic interventions. Duration dependence would identify a causal timescale but not native integration or a second independent experience.",
        "evidence": [
            {"path": d15.LOCK_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(d15.LOCK_PATH), "content_sha256": lock.get("content_sha256")},
            {"path": DRT02_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(DRT02_PATH), "content_sha256": prior.get("content_sha256")},
        ],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "status": result["hypothesis_status"]["H14_transient_vs_persistent_integration"],
                      "content_sha256": result["content_sha256"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
