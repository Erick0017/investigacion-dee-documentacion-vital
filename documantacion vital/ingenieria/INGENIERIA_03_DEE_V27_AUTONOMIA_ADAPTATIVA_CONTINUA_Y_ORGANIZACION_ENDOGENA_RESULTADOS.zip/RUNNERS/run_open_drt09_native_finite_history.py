#!/usr/bin/env python3
"""All-t0 finite-carrier history synthesis for the DRT02 temporal frontier."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_open_drt02_distributed_destabilization as drt02
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT09_NATIVE_FINITE_HISTORY.json"
DRT08_PATH = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT08_TEMPORAL_INTEGRATION.json"
D56_PATH = ROOT / "DISCOVERY/ING03_DEEP_D56_MESSENGER_LIFETIME_SINK.json"
HORIZON = 384
TRAIN_LENGTHS = (0, 1, 4, 8, 16)


def put(world, q, raw, clock=0):
    if int(world.raw[q]):
        raise RuntimeError(f"t0 overlap at {q}")
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install_train(world, meta, length, sink):
    target = meta["a"]
    event = add(target, meta["tf"]((0, -1, 0)), 1, meta["n"])
    route = meta["tf"]((0, 0, 1))
    carriers = []
    for index in range(length):
        distance = 10 + index
        q = add(event, route, -distance, meta["n"])
        raw = int(pack(56000 + index, 0, route, 1))
        put(world, q, raw, 0)
        carriers.append({"q": list(q), "raw": raw, "nominal_arrival_tick": distance})
    sink_q = None
    if sink:
        # A stationary semantic4 interaction terminated toroidal semantic1
        # messenger return in D56.  Place it downstream rather than on the
        # learner surface; sink-only is included as a matched control.
        sink_q = add(event, route, 10, meta["n"])
        put(world, sink_q, int(pack(56999, 0, (0, 0, 0), 4)), 0)
    return event, route, carriers, sink_q


def run_case(kernel, architecture, length, sink):
    try:
        world, meta, p1, _, _, _ = drt02.build_world(kernel, architecture, None)
        event, route, carriers, sink_q = install_train(world, meta, length, sink)
    except RuntimeError as exc:
        return {"valid": False, "reason": str(exc), "train_length": length, "sink": sink}
    previous = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
    transitions = {"p0": [], "p1": []}; pairs = []; carrier_survival = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        current = {"p0": delta_value(world, meta), "p1": d15.reserve_delta(world, p1)}
        for key in current:
            if current[key] != previous[key]:
                transitions[key].append({"tick": tick, "before": previous[key], "after": current[key]})
        previous = current; pairs.append(pair(world, meta))
        if tick in (1, 10, 20, 41, 51, 82, 123, 140, 184, 256, 384):
            states = set(item["raw"] & 0xFFFFFFFF for item in carriers)
            raw_state = (world.raw & np.uint64(0xFFFFFFFF)).astype(np.uint32)
            carrier_survival.append({"tick": tick, "matching_train_states": int(np.isin(raw_state, list(states)).sum()) if states else 0})
    return {
        "valid": True,
        "train_length": length,
        "sink": sink,
        "event": list(event),
        "route": list(route),
        "carriers": carriers,
        "sink_q": list(sink_q) if sink_q is not None else None,
        "transitions": transitions,
        "terminal": previous,
        "receiver_pair_digest": hashlib.sha256(json.dumps(pairs, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "carrier_survival": carrier_survival,
        "python_interventions_after_t0": 0,
    }


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8"))
    prior = json.loads(DRT08_PATH.read_text(encoding="utf-8"))
    d56 = json.loads(D56_PATH.read_text(encoding="utf-8"))
    architecture = dict(lock["architecture"])
    kernel, runtime = load_kernel(1)
    cases = [(length, True) for length in TRAIN_LENGTHS] + [(1, False), (4, False)]
    rows = []
    for length, sink in cases:
        row = run_case(kernel, architecture, length, sink); rows.append(row)
        print(json.dumps({"length": length, "sink": sink, "valid": row.get("valid"),
                          "terminal": row.get("terminal"), "p1": row.get("transitions", {}).get("p1")}, sort_keys=True), flush=True)

    valid_sink = [row for row in rows if row.get("valid") and row["sink"]]
    sink_only = next((row for row in valid_sink if row["train_length"] == 0), None)
    distinct = len({row["terminal"]["p1"] for row in valid_sink}) if valid_sink else 0
    train_specific = [row for row in valid_sink if row["train_length"] > 0 and sink_only is not None and
                      (row["terminal"]["p1"] != sink_only["terminal"]["p1"] or row["receiver_pair_digest"] != sink_only["receiver_pair_digest"])]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.native_finite_history.v1",
        "question": "Can an all-t0 finite semantic1 carrier history, with native toroidal-return termination, reproduce history-length-dependent retained outcomes without host intervention?",
        "planning": {
            "mechanism": "finite co-directed carrier trains plus downstream stationary semantic4 sink",
            "controls": ["sink only", "train lengths 1/4/8/16", "length 1/4 without sink", "persistent DRT02 and diagnostic DRT08 references"],
            "predicted_outcomes": ["no coupling", "length-dependent retained state", "sink dominates", "toroidal returns dominate without sink"],
            "estimated_runtime_minutes": 2,
            "stop_condition": "all seven t0 worlds reach tick 384",
        },
        "design": {"all_components_at_t0": True, "python_interventions_after_t0": 0,
                   "train_lengths": list(TRAIN_LENGTHS), "sink_downstream_offset": 10,
                   "future_answer_preconfigured_by_train": True},
        "rows": rows,
        "hypothesis_status": {
            "H14_transient_vs_persistent_integration": {
                "status": "PARTIALLY_SUPPORTED" if len(train_specific) > 0 and distinct > 1 else "BOUNDED_NULL",
                "native_finite_history_changes_outcome": bool(train_specific),
                "distinct_sinked_terminal_p1_outcomes": distinct,
                "scope": "finite semantic1 trains in one DRT02 A-history morphology; not an independent later environment",
            }
        },
        "summary": {
            "valid_worlds": sum(row.get("valid", False) for row in rows),
            "native_history_length_dependence_observed": bool(train_specific and distinct > 1),
            "native_temporal_primitive_demonstrated": bool(train_specific),
            "second_independent_experience_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "All histories are frozen at t0 and encode their own finite train length. A positive result is a native temporal primitive, not adaptive selection, recurrence, or RW3.",
        "evidence": [
            {"path": d15.LOCK_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(d15.LOCK_PATH), "content_sha256": lock.get("content_sha256")},
            {"path": DRT08_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(DRT08_PATH), "content_sha256": prior.get("content_sha256")},
            {"path": D56_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(D56_PATH), "content_sha256": d56.get("content_sha256")},
        ],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "status": result["hypothesis_status"]["H14_transient_vs_persistent_integration"],
                      "content_sha256": result["content_sha256"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
