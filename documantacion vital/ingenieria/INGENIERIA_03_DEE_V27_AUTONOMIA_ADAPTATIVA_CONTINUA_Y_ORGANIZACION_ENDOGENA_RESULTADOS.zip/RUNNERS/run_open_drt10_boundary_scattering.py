#!/usr/bin/env python3
"""Diagnostic boundary-scattering test for DR01 A and PLASTIC regimes."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_distributed_d01_regime_cartography as d01


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT10_BOUNDARY_SCATTERING.json"
DRT05_PATH = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT05_WAVE_FIELD_AUDIT.json"
HORIZON = 128
MODES = ("NONE", "SEMANTIC1_SHEET", "SEMANTIC4_SHEET", "SEMANTIC4_APERTURE")
LABELS = ("A", "PLASTIC")


def signed_axis(n, origin, axis):
    index = np.indices((n, n, n), dtype=np.int16)[axis]
    return (index.astype(np.int32) - int(origin[axis]) + n // 2) % n - n // 2


def install_sheet(treatment, control, event, mode, clock):
    if mode == "NONE":
        return {"installed": 0, "skipped_occupied": 0, "positions": []}
    semantic = 1 if mode == "SEMANTIC1_SHEET" else 4
    positions = []; skipped = 0
    serial = 0
    # Plane normal to the diagnostic +z source route, five cells beyond the
    # event.  Use only empty matched sites; do not delete the mature regime.
    for dx in range(-5, 6):
        for dy in range(-5, 6):
            if mode == "SEMANTIC4_APERTURE" and abs(dx) <= 1 and abs(dy) <= 1:
                continue
            q = ((event[0] + dx) % treatment.n, (event[1] + dy) % treatment.n,
                 (event[2] + 5) % treatment.n)
            if int(treatment.raw[q]) or int(control.raw[q]):
                skipped += 1; continue
            raw = int(pack(58000 + serial, 0, (0, 0, 0), semantic)); serial += 1
            d01.set_both(treatment, q, raw, clock); d01.set_both(control, q, raw, clock)
            positions.append(q)
    return {"installed": len(positions), "skipped_occupied": skipped,
            "positions": [list(q) for q in positions]}


def run_case(kernel, label, mode):
    base, meta = d01.build_mature(kernel, label)
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    source = add(event, (0, 0, 1), -3, meta["n"])
    d01.set_both(treatment, source, 0, 0); d01.set_both(control, source, 0, 0)
    sheet = install_sheet(treatment, control, event, mode, d01.MATURATION)
    source_raw = int(pack(41000, 0, (0, 0, 1), 4))
    d01.set_both(treatment, source, source_raw, d01.MATURATION)

    zoff = signed_axis(meta["n"], event, 2)
    source_side = zoff <= 0
    pre_boundary = (zoff > 0) & (zoff < 5)
    boundary_plane = zoff == 5
    beyond = zoff > 5
    counts = []; mask_bytes = []; first_beyond = None
    for latency in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        mask = treatment.raw != control.raw
        mask_bytes.append(np.packbits(mask.reshape(-1), bitorder="little"))
        row = {
            "latency": latency,
            "total": int(mask.sum()),
            "source_side": int((mask & source_side).sum()),
            "pre_boundary": int((mask & pre_boundary).sum()),
            "boundary_plane": int((mask & boundary_plane).sum()),
            "beyond_boundary": int((mask & beyond).sum()),
        }
        if row["beyond_boundary"] and first_beyond is None:
            first_beyond = latency
        counts.append(row)
    packed = np.stack(mask_bytes)
    return {
        "label": label, "mode": mode, "event": list(event), "source": list(source),
        "sheet": sheet,
        "first_beyond_boundary_tick": first_beyond,
        "maximum_beyond_boundary": max(row["beyond_boundary"] for row in counts),
        "terminal": counts[-1],
        "checkpoints": [counts[t - 1] for t in (1, 4, 8, 12, 16, 24, 32, 48, 64, 96, 128)],
        "response_sequence_sha256": hashlib.sha256(packed.tobytes()).hexdigest(),
        "packed_masks": packed,
        "python_interventions_after_t0": 2,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    prior = json.loads(DRT05_PATH.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    rows = []
    for label in LABELS:
        for mode in MODES:
            row = run_case(kernel, label, mode); rows.append(row)
            print(json.dumps({"label": label, "mode": mode, "first_beyond": row["first_beyond_boundary_tick"],
                              "max_beyond": row["maximum_beyond_boundary"], "terminal": row["terminal"]}, sort_keys=True), flush=True)

    comparisons = []
    for label in LABELS:
        baseline = next(row for row in rows if row["label"] == label and row["mode"] == "NONE")
        for row in (item for item in rows if item["label"] == label and item["mode"] != "NONE"):
            hamming = int(np.unpackbits(np.bitwise_xor(row["packed_masks"], baseline["packed_masks"]), bitorder="little").sum())
            terminal_source_excess = row["terminal"]["source_side"] - baseline["terminal"]["source_side"]
            terminal_beyond_change = row["terminal"]["beyond_boundary"] - baseline["terminal"]["beyond_boundary"]
            comparisons.append({
                "label": label, "mode": row["mode"],
                "response_sequence_hamming_voxel_ticks_vs_no_boundary": hamming,
                "first_beyond_tick_change": None if baseline["first_beyond_boundary_tick"] is None or row["first_beyond_boundary_tick"] is None else row["first_beyond_boundary_tick"] - baseline["first_beyond_boundary_tick"],
                "terminal_source_side_excess": terminal_source_excess,
                "terminal_beyond_change": terminal_beyond_change,
                "boundary_changes_response": hamming > 0,
                "attenuation_like": terminal_beyond_change < 0,
                "source_side_excess_reflection_like": terminal_source_excess > 0 and terminal_beyond_change < 0,
            })
    for row in rows:
        row.pop("packed_masks", None)
    any_effect = any(row["boundary_changes_response"] for row in comparisons)
    any_reflection_like = any(row["source_side_excess_reflection_like"] for row in comparisons)
    aperture_specific = any(row["mode"] == "SEMANTIC4_APERTURE" and row["boundary_changes_response"] for row in comparisons)
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.boundary_scattering.v1",
        "question": "Does an explicit causal sheet alter passage, attenuation, or reflection-like redistribution of the DR01 A/PLASTIC responses?",
        "planning": {
            "mechanism": "matched diagnostic sheets perpendicular to the +z probe route",
            "controls": ["no sheet", "semantic1 sheet", "semantic4 sheet", "semantic4 sheet with 3x3 aperture", "A extensive and PLASTIC sparse regimes"],
            "predicted_outcomes": ["no effect", "attenuation", "aperture passage", "source-side excess", "global reorganization"],
            "estimated_runtime_minutes": 3,
            "stop_condition": "eight paired worlds reach 128 post-probe ticks",
        },
        "design": {"sheet_relative_z": 5, "sheet_extent": "11x11", "aperture": "3x3",
                   "only_empty_sites_filled": True, "horizon": HORIZON,
                   "diagnostic_post_maturation_intervention": True},
        "rows": rows,
        "comparisons": comparisons,
        "hypothesis_status": {
            "H4_state_dependent_boundary_scattering": {
                "status": "DIAGNOSTIC_ONLY" if any_effect else "BOUNDED_NULL",
                "boundary_changes_response": any_effect,
                "reflection_like_redistribution": any_reflection_like,
                "aperture_specific_response": aperture_specific,
                "scope": "two DR01 regimes, 11x11 diagnostic sheets at one relative position",
            },
            "H7_wave_like_distributed_dynamics": {
                "status": "PARTIALLY_SUPPORTED" if any_reflection_like else prior["hypothesis_status"]["H7_wave_like_distributed_dynamics"]["status"],
                "claim": "Reflection-like count redistribution is not wave reflection without phase/coherence and geometric replication." if any_reflection_like else "No new reflection-like property established; prior ordered propagation remains the supported property.",
            },
            "H8_field_like_distributed_coupling": {
                "status": "UNRESOLVED",
                "claim": "A finite porous sheet cannot exclude alternate local paths or establish carrier-free coupling.",
            },
        },
        "summary": {
            "boundary_effect_observed": any_effect,
            "reflection_like_observed": any_reflection_like,
            "wave_demonstrated": False,
            "field_demonstrated": False,
            "second_independent_experience_added": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "The sheets are diagnostic post-maturation interventions. Count redistribution is described operationally and is not automatically reflection, refraction, a wave, or a field.",
        "evidence": [{"path": DRT05_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(DRT05_PATH), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "statuses": result["hypothesis_status"], "content_sha256": result["content_sha256"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
