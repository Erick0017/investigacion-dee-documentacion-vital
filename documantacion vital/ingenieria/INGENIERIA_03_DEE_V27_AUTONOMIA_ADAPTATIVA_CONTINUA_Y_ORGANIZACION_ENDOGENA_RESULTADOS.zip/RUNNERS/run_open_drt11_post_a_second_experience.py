#!/usr/bin/env python3
"""Diagnostic insertion of a genuinely post-A second environmental pressure."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_distributed_d15_native_reserve_transfer_holdout as d15
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT11_POST_A_SECOND_EXPERIENCE.json"
DRT01_PATH = ROOT / "MECHANISM_SELECTION/ING03_OH_DRT01_SECOND_EXPERIENCE_INTERFERENCE.json"
INSERT_TICK = 160
HORIZON = 448
IDENTITY = ((0, 1, 2), (1, 1, 1))
CONFIGS = (
    {"id": "P1_A_AXIAL", "target": "p1_a", "directions": [(0, 0, 1)], "distance": 4},
    {"id": "P1_B_AXIAL", "target": "p1_b", "directions": [(0, 0, 1)], "distance": 4},
    {"id": "P1_A_DIAGONAL", "target": "p1_a", "directions": [(-1, -1, 1)], "distance": 10},
    {"id": "P0_A_AXIAL", "target": "p0_a", "directions": [(0, 0, 1)], "distance": 10},
    {"id": "P0_A_DIAGONAL", "target": "p0_a", "directions": [(-1, -1, 1)], "distance": 10},
    {"id": "P0_A_DISTRIBUTED3", "target": "p0_a", "directions": [(0, 0, 1), (-1, -1, 1), (1, -1, 1)], "distance": 10},
    {"id": "RECEIVER_AXIAL", "target": "receiver", "directions": [(0, 0, 1)], "distance": 10},
    {"id": "RECEIVER_DISTRIBUTED3", "target": "receiver", "directions": [(0, 0, 1), (-1, -1, 1), (1, -1, 1)], "distance": 10},
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def target_q(meta, p1, name):
    return {"p1_a": p1["a"], "p1_b": p1["b"], "p0_a": meta["a"],
            "receiver": meta["q_receiver"]}[name]


def install_matched_pressure(treatment, control, meta, p1, config, tick):
    target = target_q(meta, p1, config["target"]); rows = []
    for index, canonical in enumerate(config["directions"]):
        direction = meta["tf"](canonical)
        event = add(target, meta["tf"]((0, -1, 0)), 1, meta["n"])
        source = add(event, direction, -config["distance"], meta["n"])
        before_t = int(treatment.raw[source]); before_c = int(control.raw[source])
        set_both(treatment, source, 0, tick); set_both(control, source, 0, tick)
        raw = int(pack(59000 + 100 * index + config["distance"], 0, direction, 4))
        set_both(treatment, source, raw, tick)
        rows.append({"q": list(source), "event": list(event), "direction": list(direction),
                     "raw": raw, "treatment_before": before_t, "control_before": before_c})
    return rows


def run_case(kernel, architecture, config):
    treatment, meta, p1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    control, cmeta, cp1 = d15.build(kernel, IDENTITY, (0, 0, 0), "A", architecture)
    d15.install_source(treatment, meta, architecture); d15.install_source(control, cmeta, architecture)
    previous = {"p0_t": delta_value(treatment, meta), "p0_c": delta_value(control, cmeta),
                "p1_t": d15.reserve_delta(treatment, p1), "p1_c": d15.reserve_delta(control, cp1)}
    transitions = {key: [] for key in previous}; pair_different = []; world_differences = []
    installed = None; checkpoints = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        if tick == INSERT_TICK:
            installed = install_matched_pressure(treatment, control, meta, p1, config, tick)
        current = {"p0_t": delta_value(treatment, meta), "p0_c": delta_value(control, cmeta),
                   "p1_t": d15.reserve_delta(treatment, p1), "p1_c": d15.reserve_delta(control, cp1)}
        for key in current:
            if current[key] != previous[key]:
                transitions[key].append({"tick": tick, "before": previous[key], "after": current[key]})
        previous = current
        different = pair(treatment, meta) != pair(control, cmeta)
        pair_different.append(different); world_differences.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if tick in (140, 159, 160, 161, 168, 184, 208, 256, 320, 384, 448):
            checkpoints.append({"tick": tick, "values": dict(current), "treatment_pair": pair(treatment, meta),
                                "control_pair": pair(control, cmeta), "world_difference": world_differences[-1]})
    late_p0 = [row for row in transitions["p0_t"] if row["tick"] > INSERT_TICK and row not in transitions["p0_c"]]
    late_p1 = [row for row in transitions["p1_t"] if row["tick"] > INSERT_TICK and row not in transitions["p1_c"]]
    terminal_pair_retained = bool(all(pair_different[-64:]))
    retained_parameter = bool((previous["p0_t"] != previous["p0_c"] and late_p0) or
                              (previous["p1_t"] != previous["p1_c"] and late_p1))
    return {
        "config": config,
        "installed": installed,
        "transitions": transitions,
        "late_treatment_specific_p0_transitions": late_p0,
        "late_treatment_specific_p1_transitions": late_p1,
        "terminal": previous,
        "pair_difference_ticks_after_insertion": int(sum(pair_different[INSERT_TICK:])),
        "terminal_pair_difference_retained_64_ticks": terminal_pair_retained,
        "retained_late_order_parameter_change": retained_parameter,
        "maximum_world_difference": max(world_differences),
        "terminal_world_difference": world_differences[-1],
        "world_difference_sequence_sha256": hashlib.sha256(np.asarray(world_differences, dtype=np.int32).tobytes()).hexdigest(),
        "checkpoints": checkpoints,
        "python_interventions_after_t0": 2 * len(config["directions"]),
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    lock = json.loads(d15.LOCK_PATH.read_text(encoding="utf-8"))
    prior = json.loads(DRT01_PATH.read_text(encoding="utf-8"))
    architecture = dict(lock["architecture"])
    kernel, runtime = load_kernel(1); rows = []
    for config in CONFIGS:
        row = run_case(kernel, architecture, config); rows.append(row)
        print(json.dumps({"id": config["id"], "late_p0": row["late_treatment_specific_p0_transitions"],
                          "late_p1": row["late_treatment_specific_p1_transitions"],
                          "pair_retained": row["terminal_pair_difference_retained_64_ticks"],
                          "terminal": row["terminal"]}, sort_keys=True), flush=True)
    retained = [row for row in rows if row["retained_late_order_parameter_change"]]
    functional = [row for row in retained if row["terminal_pair_difference_retained_64_ticks"]]
    result = seal({
        "schema": "dee.v27.ing03.open_hypothesis.post_a_second_experience.v1",
        "question": "After native A learning, A function and P1 retention already exist, can an explicitly later independent B-like pressure reorganize the learned landscape and change later function?",
        "planning": {
            "mechanism": "paired diagnostic pressure insertion at tick 160, after P0 tick9 and P1 tick140 transitions",
            "controls": ["matched no-pressure branch", "matched port clearing", "P0/P1/receiver targets", "axial/diagonal/distributed pressure"],
            "predicted_outcomes": ["no susceptibility", "local retained transition", "functional pair change", "damage without retained order"],
            "estimated_runtime_minutes": 3,
            "stop_condition": "eight paired worlds reach tick 448",
        },
        "design": {"insertion_tick": INSERT_TICK, "horizon": HORIZON,
                   "configs": list(CONFIGS), "host_insertion_used": True,
                   "ports_equalized_in_treatment_and_control": True},
        "rows": rows,
        "summary": {
            "retained_late_order_parameter_candidates": len(retained),
            "retained_function_change_candidates": len(functional),
            "candidate_ids": [row["config"]["id"] for row in functional],
            "diagnostic_second_experience_sufficiency": bool(functional),
            "native_second_experience_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "hypothesis_status": {
            "H1_smooth_conversion": "DIAGNOSTIC_ONLY" if functional else "BOUNDED_NULL",
            "H2_critical_transition": "DIAGNOSTIC_ONLY" if functional else "BOUNDED_NULL",
            "H5_native_DR04_order_transition": "DIAGNOSTIC_ONLY" if retained else "BOUNDED_NULL",
        },
        "next_step": "Any diagnostic candidate must be reconstructed from t0 by backward causal synthesis and must pass answer-leakage, retention and fresh controls before it can count as a native second experience.",
        "claim_guard": "B-like pressures are inserted by Python at tick160 and therefore cannot count as native adaptation, RW3, or autonomous environmental change.",
        "evidence": [
            {"path": d15.LOCK_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(d15.LOCK_PATH), "content_sha256": lock.get("content_sha256")},
            {"path": DRT01_PATH.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(DRT01_PATH), "content_sha256": prior.get("content_sha256")},
        ],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "status": result["hypothesis_status"], "content_sha256": result["content_sha256"]}, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
