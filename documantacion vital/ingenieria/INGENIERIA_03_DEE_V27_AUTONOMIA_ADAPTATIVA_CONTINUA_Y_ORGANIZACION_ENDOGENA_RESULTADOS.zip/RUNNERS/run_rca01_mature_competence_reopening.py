#!/usr/bin/env python3
"""Diagnostic search for mature-regime competence reopening.

Every environmental priming construction has a matched prime-only branch.  A
standardized writer is then applied to its paired challenge branch.  This keeps
damage, direct environmental effects and actual restoration of write response
separate.  All post-t0 modifications are diagnostic interventions and cannot
count as RW3.
"""
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, sha256_file, write_json
import run_reactivation_c15_fresh_holdout as c15
import run_succession_s05_susceptibility_holdout as s05


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA01_MATURE_COMPETENCE_REOPENING.json"
C15_LOCK = ROOT / "FREEZE/ING03_REACT_C15_LATE_DEVELOPMENT_LOCK.json"
S05B_LOCK = ROOT / "FREEZE/ING03_SUCCESSION_S05B_SUSCEPTIBILITY_LOCK.json"
FRAME = ((0, 1, 2), (1, 1, 1))
PRIME_TICK = 128
CHALLENGE_TICK = 184
HORIZON = 360
RETENTION = 64
MODES = (
    "NONE",
    "SEMANTIC1_CLOSED_R4",
    "SEMANTIC4_CLOSED_R4",
    "MIXED_PHASE_SPARSE_R5",
    "OPEN_SEMANTIC4_SHEET",
    "LOCALIZED_B_PRESSURE",
    "DISTRIBUTED_B_PRESSURE",
    "BOUNDARY_CLEAR_R2",
    "LOCAL_PHASE_REORGANIZATION",
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def delta(world, meta):
    a, b = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def functional_pair(world, meta):
    return [int(world.raw[meta["q"]]), int(world.raw[meta["qp"]])]


def macro(world):
    raw = world.raw; mask = raw != 0; values = raw[mask]
    semantics = ((values >> np.uint64(60)) & np.uint64(15)).astype(np.int16)
    sregs = ((values >> np.uint64(32)) & np.uint64(0xFFFF)).astype(np.int32)
    directions = np.column_stack([((values >> np.uint64(shift)) & np.uint64(15)).astype(np.int16)
                                  for shift in (48, 52, 56)]) if len(values) else np.empty((0, 3), np.int16)
    if len(directions): directions[directions >= 8] -= 16
    semantic_counts = Counter(int(x) for x in semantics.tolist())
    return {"support": int(mask.sum()),
            "semantic_counts": {str(k): v for k, v in sorted(semantic_counts.items())},
            "distinct_sregs": int(len(np.unique(sregs))) if len(sregs) else 0,
            "directed_support": int(np.count_nonzero(np.any(directions != 0, axis=1))) if len(directions) else 0}


def shell_positions(center, radius, n):
    rows = []
    for d in product(range(-radius, radius + 1), repeat=3):
        if max(abs(x) for x in d) == radius:
            rows.append(add(center, d, 1, n))
    return sorted(set(rows))


def install_empty(world, positions, semantic, clock, phase_mode=False):
    installed = []; skipped = []; serial = 0
    for q in positions:
        if int(world.raw[q]): skipped.append(q); continue
        raw = int(pack(61000 + serial, serial % 7, (0, 0, 0), semantic if not phase_mode else (1 if serial % 2 == 0 else 4)))
        set_both(world, q, raw, clock + (serial % 32 if phase_mode else 0))
        installed.append(q); serial += 1
    return installed, skipped


def apply_prime(world, meta, mode, n):
    center = (n // 2,) * 3
    protected = {meta["a"], meta["b"], meta["q"], meta["qp"]} | {q for q, _ in meta["sources"]}
    record = {"mode": mode, "type": "DIAGNOSTIC_INTERVENTION", "installed": [], "removed": [], "modified": [], "skipped": []}
    if mode == "NONE": return record
    if mode in ("SEMANTIC1_CLOSED_R4", "SEMANTIC4_CLOSED_R4"):
        semantic = 1 if mode.startswith("SEMANTIC1") else 4
        positions = [q for q in shell_positions(center, 4, n) if q not in protected]
        installed, skipped = install_empty(world, positions, semantic, PRIME_TICK)
        record["installed"] = [list(q) for q in installed]; record["skipped"] = [list(q) for q in skipped]
    elif mode == "MIXED_PHASE_SPARSE_R5":
        positions = [q for index, q in enumerate(shell_positions(center, 5, n)) if index % 3 == 0 and q not in protected]
        installed, skipped = install_empty(world, positions, 4, PRIME_TICK, phase_mode=True)
        record["installed"] = [list(q) for q in installed]; record["skipped"] = [list(q) for q in skipped]
    elif mode == "OPEN_SEMANTIC4_SHEET":
        positions = []
        for dx in range(-5, 6):
            for dy in range(-5, 6):
                if abs(dx) <= 1 and abs(dy) <= 1: continue
                q = ((center[0] + dx) % n, (center[1] + dy) % n, (center[2] + 5) % n)
                if q not in protected: positions.append(q)
        installed, skipped = install_empty(world, positions, 4, PRIME_TICK)
        record["installed"] = [list(q) for q in installed]; record["skipped"] = [list(q) for q in skipped]
    elif mode in ("LOCALIZED_B_PRESSURE", "DISTRIBUTED_B_PRESSURE"):
        event = add(meta["b"], (0, -1, 0), 1, n)
        directions = [(0, 0, 1)] if mode == "LOCALIZED_B_PRESSURE" else [(0, 0, 1), (1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1)]
        for serial, direction in enumerate(directions):
            q = add(event, direction, -10, n)
            if q in protected or int(world.raw[q]): record["skipped"].append(list(q)); continue
            raw = int(pack(62000 + serial, 0, direction, 4)); set_both(world, q, raw, PRIME_TICK)
            record["installed"].append(list(q))
    elif mode == "BOUNDARY_CLEAR_R2":
        for q in shell_positions(center, 2, n):
            if q in protected or not int(world.raw[q]): continue
            record["removed"].append({"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q])})
            set_both(world, q, 0, 0)
    elif mode == "LOCAL_PHASE_REORGANIZATION":
        for d in product(range(-3, 4), repeat=3):
            q = add(center, d, 1, n)
            if q in protected or not int(world.raw[q]): continue
            before = int(world.clock_a[q]); after = PRIME_TICK + (sum(abs(x) for x in d) % 7)
            world.clock_a[q] = np.uint64(after); world.clock_b[q] = np.uint64(after)
            record["modified"].append({"q": list(q), "clock_before": before, "clock_after": after})
    else:
        raise ValueError(mode)
    return record


def writer_site(meta, n):
    event = add(meta["b"], (0, -1, 0), 1, n)
    return add(event, (0, 0, 1), -3, n)


def equalize_and_install(control, challenge, q, raw):
    before = {"control_raw": int(control.raw[q]), "challenge_raw": int(challenge.raw[q]),
              "control_clock": int(control.clock_a[q]), "challenge_clock": int(challenge.clock_a[q])}
    set_both(control, q, 0, CHALLENGE_TICK); set_both(challenge, q, 0, CHALLENGE_TICK)
    set_both(challenge, q, raw, CHALLENGE_TICK)
    return before


def run_mode(kernel, architecture, mode):
    base, meta = c15.build(kernel, FRAME, "learn_a", architecture)
    for _ in range(PRIME_TICK): base.tick()
    control = NativeWorld(kernel, base.raw, base.clock_a)
    challenge = NativeWorld(kernel, base.raw, base.clock_a)
    prime_control = apply_prime(control, meta, mode, architecture["n"])
    prime_challenge = apply_prime(challenge, meta, mode, architecture["n"])
    if prime_control != prime_challenge: raise RuntimeError(f"nonidentical matched prime {mode}")
    q = writer_site(meta, architecture["n"])
    writer_raw = int(pack(36000, 0, (0, 0, 1), 4))
    delta_c = [delta(control, meta)]; delta_t = [delta(challenge, meta)]
    pair_c = [functional_pair(control, meta)]; pair_t = [functional_pair(challenge, meta)]
    world_difference = [0]; checkpoints = []
    port = None
    for tick in range(PRIME_TICK + 1, HORIZON + 1):
        control.tick(); challenge.tick()
        if tick == CHALLENGE_TICK:
            port = equalize_and_install(control, challenge, q, writer_raw)
        delta_c.append(delta(control, meta)); delta_t.append(delta(challenge, meta))
        pair_c.append(functional_pair(control, meta)); pair_t.append(functional_pair(challenge, meta))
        world_difference.append(int(np.count_nonzero(control.raw != challenge.raw)))
        if tick in (129, 144, 160, 183, 184, 185, 192, 208, 240, 296, 360):
            checkpoints.append({"tick": tick, "control_delta": delta_c[-1], "challenge_delta": delta_t[-1],
                                "control_pair": pair_c[-1], "challenge_pair": pair_t[-1],
                                "world_difference": world_difference[-1],
                                "control_macro": macro(control), "challenge_macro": macro(challenge)})
    post_index = CHALLENGE_TICK - PRIME_TICK
    post_delta_diff = [i + PRIME_TICK for i, (a, b) in enumerate(zip(delta_t, delta_c)) if i > post_index and a != b]
    post_pair_diff = [i + PRIME_TICK for i, (a, b) in enumerate(zip(pair_t, pair_c)) if i > post_index and a != b]
    retained_delta = all(a != b for a, b in zip(delta_t[-RETENTION:], delta_c[-RETENTION:]))
    retained_pair = all(a != b for a, b in zip(pair_t[-RETENTION:], pair_c[-RETENTION:]))
    return {
        "mode": mode, "prime_record": prime_control, "writer_site": list(q), "writer_raw": writer_raw,
        "port_equalization": port, "pre_prime_delta": delta(base, meta), "pre_prime_pair": functional_pair(base, meta),
        "control_terminal_delta": delta_c[-1], "challenge_terminal_delta": delta_t[-1],
        "control_terminal_pair": pair_c[-1], "challenge_terminal_pair": pair_t[-1],
        "writer_specific_delta_difference_ticks": post_delta_diff,
        "writer_specific_pair_difference_ticks": post_pair_diff,
        "retained_delta_difference_last64": retained_delta,
        "retained_function_difference_last64": retained_pair,
        "maximum_world_difference": max(world_difference), "terminal_world_difference": world_difference[-1],
        "world_difference_sequence_sha256": hashlib.sha256(np.asarray(world_difference, np.int32).tobytes()).hexdigest(),
        "checkpoints": checkpoints,
        "components": {"experience_specific_change": bool(post_delta_diff),
                       "retained_change": retained_delta,
                       "later_function_change": retained_pair,
                       "native_after_t0": False,
                       "recurrent_capacity": False},
        "diagnostic_competence_reopened": bool(post_delta_diff and retained_delta and retained_pair),
        "python_interventions_after_t0": 2 + int(mode != "NONE"),
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def plastic_control(kernel, s05_architecture):
    world, meta = s05.plastic_world(kernel, FRAME, s05_architecture)
    control = NativeWorld(kernel, world.raw, world.clock_a)
    q = writer_site(meta, s05_architecture["n"]); raw = int(pack(36000, 0, (0, 0, 1), 4))
    previous_t = delta(world, meta); previous_c = delta(control, meta); transitions_t = []; transitions_c = []; port = None
    for tick in range(1, HORIZON + 1):
        world.tick(); control.tick()
        if tick == CHALLENGE_TICK: port = equalize_and_install(control, world, q, raw)
        now_t, now_c = delta(world, meta), delta(control, meta)
        if now_t != previous_t: transitions_t.append({"tick": tick, "before": previous_t, "after": now_t})
        if now_c != previous_c: transitions_c.append({"tick": tick, "before": previous_c, "after": now_c})
        previous_t, previous_c = now_t, now_c
    post_t = [row for row in transitions_t if row["tick"] > CHALLENGE_TICK]
    post_c = [row for row in transitions_c if row["tick"] > CHALLENGE_TICK]
    return {"writer_site": list(q), "port_equalization": port, "treatment_transitions": transitions_t,
            "control_transitions": transitions_c, "treatment_specific_post_challenge": [x for x in post_t if x not in post_c],
            "assay_positive": bool([x for x in post_t if x not in post_c]), "python_interventions_after_t0": 2}


def main():
    c15_lock = json.loads(C15_LOCK.read_text(encoding="utf-8")); architecture = c15_lock["architecture"]
    s05b_lock = json.loads(S05B_LOCK.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    rows = []
    for mode in MODES:
        row = run_mode(kernel, architecture, mode); rows.append(row)
        print(json.dumps({"mode": mode, "components": row["components"],
                          "diagnostic_reopening": row["diagnostic_competence_reopened"],
                          "terminal_deltas": [row["control_terminal_delta"], row["challenge_terminal_delta"]]}, sort_keys=True), flush=True)
    plastic = plastic_control(kernel, s05b_lock["architecture"])
    baseline = next(row for row in rows if row["mode"] == "NONE")
    for row in rows:
        row["prime_damage_or_regime_change"] = bool(
            row["control_terminal_delta"] != baseline["control_terminal_delta"]
            or row["control_terminal_pair"] != baseline["control_terminal_pair"])
        if row["diagnostic_competence_reopened"]:
            row["outcome_class"] = "COMPETENCE_REOPENING_FOLLOWED_BY_FUNCTIONAL_REMATURATION_DIAGNOSTIC"
        elif row["components"]["experience_specific_change"]:
            row["outcome_class"] = "TRANSIENT_OR_NONFUNCTIONAL_RESPONSE"
        elif row["prime_damage_or_regime_change"]:
            row["outcome_class"] = "DAMAGE_OR_REGIME_CHANGE_WITHOUT_COMPETENCE"
        else:
            row["outcome_class"] = "NO_COMPETENCE_EFFECT"
    candidates = [row["mode"] for row in rows if row["diagnostic_competence_reopened"] and row["mode"] != "NONE"]
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.mature_reopening.v1",
        "question": "Can causally distinct environmental reorganizations restore functional competence to a mature A regime?",
        "competence_rule": "writer-specific retained master change AND retained later functional-pair change; damage or response amplitude alone is insufficient",
        "planning": {"mechanisms": list(MODES),
                     "controls": ["matched prime-only branch", "equalized challenge port", "writer-only mature baseline", "known plastic positive assay"],
                     "predicted_classes": ["NO_EFFECT", "DAMAGE_WITHOUT_COMPETENCE", "TRANSIENT_COMPETENCE", "REOPENING_AND_REMATURATION"],
                     "estimated_runtime_minutes": 4, "stop_condition": "all nine causal variants through tick360"},
        "design": {"prime_tick": PRIME_TICK, "challenge_tick": CHALLENGE_TICK, "horizon": HORIZON,
                   "retention_ticks": RETENTION, "history": "C15 native mature learn_a", "diagnostic_after_t0": True},
        "plastic_positive_control": plastic,
        "rows": rows,
        "summary": {"modes": len(rows), "plastic_assay_positive": plastic["assay_positive"],
                    "diagnostic_reopening_candidates": candidates,
                    "diagnostic_competence_reopening_demonstrated": bool(candidates),
                    "native_competence_reopening_demonstrated": False,
                    "native_rematuration_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_CANDIDATE" if candidates else "BOUNDED_NULL_IN_TESTED_MATURE_REORGANIZATIONS",
        "bounded_scope": "identity-frame C15 A regime; eight post-maturation environmental reorganizations; one frozen exact writer and receiver-function assay",
        "claim_guard": "Prime construction, port equalization and challenge writer are host diagnostic interventions. A candidate would still require backward causal synthesis, t0-native reconstruction, freeze and fresh holdout.",
        "evidence": [{"path": C15_LOCK.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(C15_LOCK), "content_sha256": c15_lock.get("content_sha256")},
                     {"path": S05B_LOCK.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(S05B_LOCK), "content_sha256": s05b_lock.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "status": result["status"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
