#!/usr/bin/env python3
"""Longevity assay for a mature functional core plus separated competent regions."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, sha256_file, write_json
import run_reactivation_r09_distributed_rotated_array as r09
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA02_CONTINUOUS_COMPETENCE_CORE_PERIPHERY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_REACT_R09_DISTRIBUTED_ROTATED_ARRAY.json"
PROBE_TICKS = (184, 512, 1024)
FOLLOWUP = 128
RETENTION = 64
SPECS = (((0, 14, 0), "x"), ((14, 0, 0), "y"), ((0, 0, 14), "z"))


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def toroidal_radius_grid(n, origins):
    indices = np.indices((n, n, n)).reshape(3, -1).T
    distance = np.full(len(indices), n, np.int16)
    for origin in origins:
        offset = (indices - np.asarray(origin) + n // 2) % n - n // 2
        distance = np.minimum(distance, np.max(np.abs(offset), axis=1))
    return distance.reshape((n, n, n))


def build(kernel):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, "a", expression=True)
    nodes = [r09.add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), index + 1, frame)
             for index, (offset, frame) in enumerate(SPECS)]
    return world, meta, nodes


def assay(kernel, base, meta, node, tick):
    treatment = NativeWorld(kernel, base.raw, base.clock_a)
    control = NativeWorld(kernel, base.raw, base.clock_a)
    q = node["writer_q"]
    before = {"treatment_raw": int(treatment.raw[q]), "control_raw": int(control.raw[q]),
              "treatment_clock": int(treatment.clock_a[q]), "control_clock": int(control.clock_a[q])}
    set_both(treatment, q, 0, tick); set_both(control, q, 0, tick)
    set_both(treatment, q, node["writer_raw"], tick)
    radius = toroidal_radius_grid(meta["n"], (node["a"], node["b"]))
    node_t = [r09.delta(treatment, node)]; node_c = [r09.delta(control, node)]
    core_t = [delta_value(treatment, meta)]; core_c = [delta_value(control, meta)]
    pair_t = [pair(treatment, meta)]; pair_c = [pair(control, meta)]
    outside_r6 = []; world_differences = []; checkpoints = []
    for latency in range(1, FOLLOWUP + 1):
        treatment.tick(); control.tick()
        node_t.append(r09.delta(treatment, node)); node_c.append(r09.delta(control, node))
        core_t.append(delta_value(treatment, meta)); core_c.append(delta_value(control, meta))
        pair_t.append(pair(treatment, meta)); pair_c.append(pair(control, meta))
        mask = treatment.raw != control.raw
        world_differences.append(int(mask.sum())); outside_r6.append(int((mask & (radius > 6)).sum()))
        if latency in (1, 2, 4, 8, 16, 32, 64, 96, 128):
            checkpoints.append({"latency": latency, "node_treatment": node_t[-1], "node_control": node_c[-1],
                                "core_treatment": core_t[-1], "core_control": core_c[-1],
                                "pair_treatment": pair_t[-1], "pair_control": pair_c[-1],
                                "world_difference": world_differences[-1], "outside_r6": outside_r6[-1]})
    response = any(a != b for a, b in zip(node_t[1:], node_c[1:]))
    retained = all(a != b for a, b in zip(node_t[-RETENTION:], node_c[-RETENTION:]))
    core_state_preserved = all(a == b for a, b in zip(core_t[-RETENTION:], core_c[-RETENTION:]))
    core_function_preserved = all(a == b for a, b in zip(pair_t[-RETENTION:], pair_c[-RETENTION:]))
    return {
        "probe_tick": tick, "node_id": node["id"], "frame": node["frame"], "center": list(node["center"]),
        "writer_site": list(q), "port_equalization": before,
        "writer_raw_persistent": int(treatment.raw[q]) == node["writer_raw"],
        "write_response": response, "retained_node_change_last64": retained,
        "core_state_preserved_last64": core_state_preserved,
        "core_function_preserved_last64": core_function_preserved,
        "ever_nonlocal_outside_r6": max(outside_r6) > 0,
        "maximum_outside_r6": max(outside_r6), "terminal_outside_r6": outside_r6[-1],
        "maximum_world_difference": max(world_differences), "terminal_world_difference": world_differences[-1],
        "world_difference_sha256": hashlib.sha256(np.asarray(world_differences, np.int32).tobytes()).hexdigest(),
        "checkpoints": checkpoints,
        "diagnostic_competence": response and retained,
        "core_plus_competent_periphery": response and retained and core_state_preserved and core_function_preserved,
        "native_new_function_from_periphery": False,
        "python_interventions_after_t0": 2,
        "intervention_class": "DIAGNOSTIC_INTERVENTION",
    }


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    base, meta, nodes = build(kernel); snapshots = {}
    for tick in range(1, max(PROBE_TICKS) + 1):
        base.tick()
        if tick in PROBE_TICKS: snapshots[tick] = NativeWorld(kernel, base.raw, base.clock_a)
    rows = []
    for tick in PROBE_TICKS:
        for node in nodes:
            row = assay(kernel, snapshots[tick], meta, node, tick); rows.append(row)
            print(json.dumps({"tick": tick, "node": node["id"], "frame": node["frame"],
                              "competence": row["diagnostic_competence"],
                              "core_preserved": row["core_plus_competent_periphery"],
                              "outside_r6": row["maximum_outside_r6"]}, sort_keys=True), flush=True)
    by_tick = []
    for tick in PROBE_TICKS:
        subset = [row for row in rows if row["probe_tick"] == tick]
        by_tick.append({"tick": tick, "competent_regions": [row["node_id"] for row in subset if row["diagnostic_competence"]],
                        "core_preserving_competent_regions": [row["node_id"] for row in subset if row["core_plus_competent_periphery"]],
                        "max_x_C_diagnostic": int(any(row["diagnostic_competence"] for row in subset))})
    sampled_continuous = all(row["max_x_C_diagnostic"] == 1 for row in by_tick)
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.core_periphery_longevity.v1",
        "question": "Can a bounded mature A organization retain at least one function-preserving competent peripheral region at separated late times?",
        "planning": {"mechanism": "three relationally rotated regions at Chebyshev separation14 from a mature functional A core",
                     "controls": ["matched no-writer branch per node/time", "port equalization", "core-state and core-function preservation", "prior separation10/14 comparison"],
                     "predicted_outcomes": ["global loss", "partial spatial competence", "sampled persistent competence", "competence with core disruption"],
                     "estimated_runtime_minutes": 4, "stop_condition": "nine paired assays through 128-tick followup"},
        "design": {"specs": [{"offset": list(offset), "frame": frame} for offset, frame in SPECS],
                   "probe_ticks": list(PROBE_TICKS), "followup": FOLLOWUP, "retention": RETENTION,
                   "bounded_regions": len(SPECS), "diagnostic_after_t0": True},
        "rows": rows, "time_summary": by_tick,
        "summary": {"assays": len(rows), "diagnostic_competent_assays": sum(row["diagnostic_competence"] for row in rows),
                    "core_preserving_competent_assays": sum(row["core_plus_competent_periphery"] for row in rows),
                    "sampled_min_t_max_x_C": int(sampled_continuous),
                    "sampled_continuous_competence_supported": sampled_continuous,
                    "native_second_experience_demonstrated": False,
                    "native_peripheral_function_demonstrated": False,
                    "renewal_or_cycle_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "PARTIALLY_SUPPORTED_DIAGNOSTIC" if sampled_continuous else "BOUNDED_NULL_AT_SAMPLED_TIMES",
        "claim_guard": "Competence is assayed in separate host-probed branches. Even a positive min_t max_x C at sampled times does not establish native experience capture, continuous-time coverage, renewal, function B or RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "time_summary": by_tick, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
