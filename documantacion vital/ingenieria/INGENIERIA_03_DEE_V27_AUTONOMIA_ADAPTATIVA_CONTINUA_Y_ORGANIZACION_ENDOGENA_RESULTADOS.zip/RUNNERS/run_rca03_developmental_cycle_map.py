#!/usr/bin/env python3
"""Map late susceptibility windows without presuming a developmental cycle."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA03_DEVELOPMENTAL_CYCLE_MAP.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA02_CONTINUOUS_COMPETENCE_CORE_PERIPHERY.json"
NEW_TICKS = (64, 128, 256, 320, 384, 640, 768, 896, 1152, 1280, 1536, 1792, 2048)


def runs(values):
    if not values: return []
    output = []; start = previous = values[0]
    for value in values[1:]:
        if value != previous + 1:
            output.append([start, previous]); start = value
        previous = value
    output.append([start, previous]); return output


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    if "--reanalyze" in sys.argv and OUTPUT.exists():
        existing = json.loads(OUTPUT.read_text(encoding="utf-8")); rows = existing["new_rows"]; runtime = existing["runtime"]
    else:
        kernel, runtime = load_kernel(1)
        base, meta, nodes = rca02.build(kernel); snapshots = {}
        for tick in range(1, max(NEW_TICKS) + 1):
            base.tick()
            if tick in NEW_TICKS: snapshots[tick] = NativeWorld(kernel, base.raw, base.clock_a)
        rows = []
        for tick in NEW_TICKS:
            for node in nodes:
                row = rca02.assay(kernel, snapshots[tick], meta, node, tick); rows.append(row)
                print(json.dumps({"tick": tick, "node": node["id"], "response": row["write_response"],
                                  "retained": row["retained_node_change_last64"],
                                  "core_preserved": row["core_state_preserved_last64"] and row["core_function_preserved_last64"]}, sort_keys=True), flush=True)
    combined = []
    for row in prior["rows"]:
        combined.append({"probe_tick": row["probe_tick"], "node_id": row["node_id"],
                         "write_response": row["write_response"],
                         "retained_node_change_last64": row["retained_node_change_last64"],
                         "core_preserved": row["core_state_preserved_last64"] and row["core_function_preserved_last64"],
                         "source": "RCA02"})
    for row in rows:
        combined.append({"probe_tick": row["probe_tick"], "node_id": row["node_id"],
                         "write_response": row["write_response"],
                         "retained_node_change_last64": row["retained_node_change_last64"],
                         "core_preserved": row["core_state_preserved_last64"] and row["core_function_preserved_last64"],
                         "source": "RCA03"})
    combined.sort(key=lambda x: (x["node_id"], x["probe_tick"]))
    node_summary = []
    for node_id in sorted({row["node_id"] for row in combined}):
        subset = [row for row in combined if row["node_id"] == node_id]
        response_ticks = [row["probe_tick"] for row in subset if row["write_response"]]
        retained_ticks = [row["probe_tick"] for row in subset if row["retained_node_change_last64"]]
        status_sequence = [int(row["write_response"]) for row in subset]
        returns = sum(status_sequence[i - 1] == 0 and status_sequence[i] == 1
                      for i in range(1, len(status_sequence)))
        node_summary.append({"node_id": node_id, "sampled_ticks": [row["probe_tick"] for row in subset],
                             "response_ticks": response_ticks, "retained_ticks": retained_ticks,
                             "response_runs_in_sample_index": runs([i for i, value in enumerate(status_sequence) if value]),
                             "positive_returns_after_sampled_null": returns,
                             "all_positive_core_preserving": all(row["core_preserved"] for row in subset if row["write_response"])})
    response_count = sum(row["write_response"] for row in combined)
    retained_count = sum(row["retained_node_change_last64"] for row in combined)
    recurring_nodes = [row["node_id"] for row in node_summary if row["positive_returns_after_sampled_null"] >= 1]
    # Unequally spaced diagnostic samples can establish returns of susceptibility,
    # but not a period, phase-locked orbit or convergence to a limit cycle.
    cycle_demonstrated = False
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.developmental_cycle_map.v1",
        "question": "Are the late response windows in separated peripheral regions isolated, developmental, or recurrent/cyclic?",
        "planning": {"mechanism": "paired exact-writer assay at thirteen new temporal strata through tick2048",
                     "controls": ["matched no-writer branch", "three rotated peripheral regions", "core state/function preservation", "RCA02 ticks184/512/1024 reused rather than rerun"],
                     "predicted_outcomes": ["no late response", "single transient window", "recurrent susceptibility", "retained cyclic competence"],
                     "estimated_runtime_minutes": 3, "stop_condition": "39 new paired assays through 128-tick followup"},
        "design": {"new_probe_ticks": list(NEW_TICKS), "reused_probe_ticks": list(rca02.PROBE_TICKS),
                   "followup": rca02.FOLLOWUP, "retention": rca02.RETENTION,
                   "diagnostic_after_t0": True, "no_global_clock_assignment_to_answers": True},
        "new_rows": rows, "combined_compact_rows": combined, "node_summary": node_summary,
        "summary": {"sampled_node_time_assays": len(combined), "writer_specific_responses": response_count,
                    "retained_responses_last64": retained_count,
                    "nodes_with_positive_return_after_sampled_null": recurring_nodes,
                    "recurrent_susceptibility_supported": bool(recurring_nodes),
                    "developmental_limit_cycle_demonstrated": cycle_demonstrated,
                    "renewed_functional_competence_demonstrated": False,
                    "periodicity_or_phase_locked_cycle_demonstrated": False,
                    "native_experience_capture_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "PARTIALLY_SUPPORTED_RECURRENT_SAMPLED_SUSCEPTIBILITY" if recurring_nodes else "BOUNDED_NULL_NO_RECURRENT_WINDOW",
        "claim_guard": "Sampling is diagnostic and does not prove continuous-time coverage or a limit cycle. A limit-cycle claim additionally requires repeated retained functional competence and convergence/phase evidence.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "node_summary": node_summary, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
