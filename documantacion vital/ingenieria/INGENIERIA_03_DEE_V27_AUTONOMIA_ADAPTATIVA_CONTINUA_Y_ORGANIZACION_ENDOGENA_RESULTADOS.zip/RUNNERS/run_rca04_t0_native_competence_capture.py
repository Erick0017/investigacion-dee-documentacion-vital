#!/usr/bin/env python3
"""Test whether t0-complete environments are captured by recurrent susceptibility."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA04_T0_NATIVE_COMPETENCE_CAPTURE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA03_DEVELOPMENTAL_CYCLE_MAP.json"
HORIZON = 2048
RETENTION = 64
MODES = (
    {"id": "NODE1_LOCAL_PHASE0", "nodes": [1], "placement": "local", "clock": 0},
    {"id": "NODE1_LOCAL_PHASE128", "nodes": [1], "placement": "local", "clock": 128},
    {"id": "NODE1_LOCAL_PHASE252", "nodes": [1], "placement": "local", "clock": 252},
    {"id": "NODE2_LOCAL_PHASE0", "nodes": [2], "placement": "local", "clock": 0},
    {"id": "NODE2_LOCAL_PHASE128", "nodes": [2], "placement": "local", "clock": 128},
    {"id": "NODES12_LOCAL_PHASE0", "nodes": [1, 2], "placement": "local", "clock": 0},
    {"id": "NODE1_UPSTREAM10_PHASE0", "nodes": [1], "placement": "upstream10", "clock": 0},
    {"id": "NODE1_UPSTREAM10_PHASE252", "nodes": [1], "placement": "upstream10", "clock": 252},
    {"id": "NODE2_UPSTREAM10_PHASE0", "nodes": [2], "placement": "upstream10", "clock": 0},
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def source_position(node, mode, n):
    if mode["placement"] == "local": return node["writer_q"]
    direction = tuple(int(x) for x in r09.transform((0, 0, 1), node["frame"]))
    return add(node["writer_q"], direction, -10, n)


def run(kernel, mode):
    treatment, meta, nodes = rca02.build(kernel)
    control, cmeta, cnodes = rca02.build(kernel)
    by = {node["id"]: node for node in nodes}; cby = {node["id"]: node for node in cnodes}
    installed = []
    for node_id in mode["nodes"]:
        node = by[node_id]; q = source_position(node, mode, meta["n"])
        if int(treatment.raw[q]):
            return {"mode": mode, "valid": False, "reason": "t0_source_overlap", "q": list(q), "raw": int(treatment.raw[q])}
        set_both(treatment, q, node["writer_raw"], mode["clock"])
        installed.append({"node_id": node_id, "q": list(q), "raw": node["writer_raw"], "clock": mode["clock"],
                          "placement": mode["placement"]})
    previous_t = {node["id"]: r09.delta(treatment, node) for node in nodes}
    previous_c = {node["id"]: r09.delta(control, cby[node["id"]]) for node in nodes}
    transitions_t = {node["id"]: [] for node in nodes}; transitions_c = {node["id"]: [] for node in nodes}
    core_differences = []; pair_differences = []; world_differences = []; checkpoints = []
    node_difference = {node["id"]: [] for node in nodes}
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node in nodes:
            node_id = node["id"]; vt = r09.delta(treatment, node); vc = r09.delta(control, cby[node_id])
            if vt != previous_t[node_id]: transitions_t[node_id].append({"tick": tick, "before": previous_t[node_id], "after": vt})
            if vc != previous_c[node_id]: transitions_c[node_id].append({"tick": tick, "before": previous_c[node_id], "after": vc})
            previous_t[node_id], previous_c[node_id] = vt, vc
            node_difference[node_id].append(vt != vc)
        core_differences.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        pair_differences.append(pair(treatment, meta) != pair(control, cmeta))
        world_differences.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if tick in (1, 9, 21, 38, 64, 128, 184, 256, 320, 384, 512, 640, 768, 896, 1024, 1152, 1280, 1536, 1792, 2048):
            checkpoints.append({"tick": tick, "node_treatment": {str(i): previous_t[i] for i in previous_t},
                                "node_control": {str(i): previous_c[i] for i in previous_c},
                                "core_treatment": delta_value(treatment, meta), "core_control": delta_value(control, cmeta),
                                "pair_different": pair_differences[-1], "world_difference": world_differences[-1]})
    node_results = []
    for node in nodes:
        node_id = node["id"]
        specific = [row for row in transitions_t[node_id] if row not in transitions_c[node_id]]
        early_specific = [row for row in specific if row["tick"] <= 38]
        late_specific = [row for row in specific if row["tick"] > 38]
        retained = all(node_difference[node_id][-RETENTION:])
        node_results.append({"node_id": node_id, "treatment_transitions": transitions_t[node_id],
                             "control_transitions": transitions_c[node_id], "treatment_specific_transitions": specific,
                             "early_before_or_at_core_function_transitions": early_specific,
                             "late_after_core_function_transitions": late_specific,
                             "terminal_treatment": previous_t[node_id], "terminal_control": previous_c[node_id],
                             "retained_difference_last64": retained,
                             "late_native_capture": bool(late_specific),
                             "late_retained_native_capture": bool(late_specific and retained),
                             "independent_late_retained_capture": bool(late_specific and retained and not early_specific)})
    sources_persistent = all(int(treatment.raw[tuple(row["q"])]) == row["raw"] for row in installed)
    any_retained = any(row["independent_late_retained_capture"] for row in node_results)
    pair_retained = all(pair_differences[-RETENTION:])
    return {
        "mode": mode, "valid": True, "t0_environment": installed, "source_raw_fixed_terminal": sources_persistent,
        "node_results": node_results, "checkpoints": checkpoints,
        "core_state_difference_ticks": int(sum(core_differences)), "functional_pair_difference_ticks": int(sum(pair_differences)),
        "functional_pair_difference_retained_last64": pair_retained,
        "maximum_world_difference": max(world_differences), "terminal_world_difference": world_differences[-1],
        "world_difference_sha256": hashlib.sha256(np.asarray(world_differences, np.int32).tobytes()).hexdigest(),
        "late_retained_native_capture": any_retained,
        "late_capture_changes_shared_function": any_retained and pair_retained,
        "python_interventions_after_t0": 0,
    }


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    if "--reanalyze" in sys.argv and OUTPUT.exists():
        existing = json.loads(OUTPUT.read_text(encoding="utf-8")); rows = existing["rows"]; runtime = existing["runtime"]
        for row in rows:
            if not row.get("valid"): continue
            for node in row["node_results"]:
                specific = node["treatment_specific_transitions"]
                early = [x for x in specific if x["tick"] <= 38]; late = [x for x in specific if x["tick"] > 38]
                node["early_before_or_at_core_function_transitions"] = early
                node["late_after_core_function_transitions"] = late
                node["late_native_capture"] = bool(late)
                node["late_retained_native_capture"] = bool(late and node["retained_difference_last64"])
                node["independent_late_retained_capture"] = bool(late and node["retained_difference_last64"] and not early)
            row["late_retained_native_capture"] = any(n["independent_late_retained_capture"] for n in row["node_results"])
            row["late_capture_changes_shared_function"] = row["late_retained_native_capture"] and row["functional_pair_difference_retained_last64"]
    else:
        kernel, runtime = load_kernel(1); rows = []
        for mode in MODES:
            row = run(kernel, mode); rows.append(row)
            print(json.dumps({"mode": mode["id"], "valid": row.get("valid"),
                              "late_retained_capture": row.get("late_retained_native_capture"),
                              "shared_function": row.get("late_capture_changes_shared_function"),
                              "node_results": [{"node": n["node_id"], "late": n["late_native_capture"],
                                                "retained": n["late_retained_native_capture"],
                                                "independent": n["independent_late_retained_capture"]}
                                               for n in row.get("node_results", [])]}, sort_keys=True), flush=True)
    valid = [row for row in rows if row.get("valid")]
    captured = [row["mode"]["id"] for row in valid if row["late_retained_native_capture"]]
    functional = [row["mode"]["id"] for row in valid if row["late_capture_changes_shared_function"]]
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.t0_native_capture.v1",
        "question": "Can an all-t0 environmental organization be incorporated during recurrent peripheral susceptibility after Function A already exists?",
        "planning": {"mechanisms": ["local persistent contact", "upstream directed contact", "initial phase variation", "single versus distributed exposure"],
                     "controls": ["identical no-environment world", "identical learner/core at t0", "three peripheral regions", "shared-function trajectory"],
                     "predicted_outcomes": ["no capture", "early-only capture", "late retained capture", "late capture with shared function"],
                     "estimated_runtime_minutes": 4, "stop_condition": "nine paired all-t0 worlds through tick2048"},
        "design": {"horizon": HORIZON, "retention": RETENTION, "core_function_established_by_tick": 38,
                   "modes": list(MODES), "python_after_t0": ["tick", "log", "stop"]},
        "rows": rows,
        "summary": {"valid_modes": len(valid), "modes_with_late_retained_native_capture": captured,
                    "modes_with_shared_function_change": functional,
                    "t0_environment_late_capture_demonstrated": bool(captured),
                    "shared_function_change_demonstrated": bool(functional),
                    "second_independent_experience_demonstrated": False,
                    "reason_not_rw3": "the B-like causal influence is present from t0 and is not generated later by a frozen environmental transition",
                    "rw3_demonstrated": False},
        "status": "PARTIALLY_SUPPORTED_T0_ENVIRONMENT_CAPTURE" if captured else "BOUNDED_NULL_T0_ENVIRONMENTS",
        "claim_guard": "All dynamics after t0 are native. A late-capture candidate additionally excludes every treatment-specific node transition at or before Function A tick38. The B influence is nevertheless installed at t0, so this remains mechanism discovery rather than an autonomous second experience or RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
