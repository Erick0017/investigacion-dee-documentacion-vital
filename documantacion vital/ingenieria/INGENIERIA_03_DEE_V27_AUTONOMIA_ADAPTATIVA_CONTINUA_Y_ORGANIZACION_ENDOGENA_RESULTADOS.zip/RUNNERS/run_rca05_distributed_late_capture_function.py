#!/usr/bin/env python3
"""Causal controls for distributed all-t0 late capture and shared function."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca04_t0_native_competence_capture as rca04
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA05_DISTRIBUTED_LATE_CAPTURE_FUNCTION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA04_T0_NATIVE_COMPETENCE_CAPTURE.json"
HORIZON = 2048
RETENTION = 64
MODES = (
    {"id": "BOTH_VALID_PHASE0", "nodes": [1, 2], "semantic": 4, "direction_mode": "toward", "clock": 0, "periphery": True},
    {"id": "BOTH_VALID_PHASE252", "nodes": [1, 2], "semantic": 4, "direction_mode": "toward", "clock": 252, "periphery": True},
    {"id": "BOTH_SEMANTIC1", "nodes": [1, 2], "semantic": 1, "direction_mode": "toward", "clock": 0, "periphery": True},
    {"id": "BOTH_REVERSED", "nodes": [1, 2], "semantic": 4, "direction_mode": "away", "clock": 0, "periphery": True},
    {"id": "NODE3_NEGATIVE_REGION", "nodes": [3], "semantic": 4, "direction_mode": "toward", "clock": 0, "periphery": True},
    {"id": "BOTH_VALID_NO_PERIPHERY", "nodes": [1, 2], "semantic": 4, "direction_mode": "toward", "clock": 0, "periphery": False},
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def node_positions(node, n):
    positions = {node["a"], node["b"]}
    for rel in PA: positions.add(add(node["a"], r09.transform(rel, node["frame"]), 1, n))
    for rel in PB: positions.add(add(node["b"], r09.transform(rel, node["frame"]), 1, n))
    return sorted(positions)


def configure(world, meta, nodes, mode):
    if not mode["periphery"]:
        for node in nodes:
            for q in node_positions(node, meta["n"]): set_both(world, q, 0, 0)
    by = {node["id"]: node for node in nodes}; installed = []
    for node_id in mode["nodes"]:
        node = by[node_id]; toward = tuple(int(x) for x in r09.transform((0, 0, 1), node["frame"]))
        q = add(node["writer_q"], toward, -10, meta["n"])
        if int(world.raw[q]): raise RuntimeError(f"source overlap {mode['id']} {q}")
        direction = toward if mode["direction_mode"] == "toward" else tuple(-x for x in toward)
        raw = int(pack(63000 + node_id, 0, direction, mode["semantic"]))
        set_both(world, q, raw, mode["clock"])
        installed.append({"node_id": node_id, "q": list(q), "raw": raw, "direction": list(direction),
                          "semantic": mode["semantic"], "clock": mode["clock"]})
    return installed


def run(kernel, mode):
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    try: installed = configure(treatment, meta, nodes, mode)
    except RuntimeError as exc: return {"mode": mode, "valid": False, "reason": str(exc)}
    if not mode["periphery"]:
        for node in cnodes:
            for q in node_positions(node, cmeta["n"]): set_both(control, q, 0, 0)
    by = {node["id"]: node for node in nodes}; cby = {node["id"]: node for node in cnodes}
    histories = {node_id: {"t": [], "c": []} for node_id in by}; transitions = {node_id: [] for node_id in by}
    previous = {node_id: (r09.delta(treatment, by[node_id]), r09.delta(control, cby[node_id])) for node_id in by}
    pair_diff = []; core_diff = []; world_diff = []; checkpoints = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node_id in by:
            vt, vc = r09.delta(treatment, by[node_id]), r09.delta(control, cby[node_id])
            histories[node_id]["t"].append(vt); histories[node_id]["c"].append(vc)
            if vt != previous[node_id][0]: transitions[node_id].append({"tick": tick, "before": previous[node_id][0], "after": vt, "branch": "treatment"})
            if vc != previous[node_id][1]: transitions[node_id].append({"tick": tick, "before": previous[node_id][1], "after": vc, "branch": "control"})
            previous[node_id] = (vt, vc)
        pair_diff.append(pair(treatment, meta) != pair(control, cmeta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        world_diff.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if tick in (1, 9, 21, 38, 64, 128, 139, 140, 184, 256, 320, 512, 768, 1024, 1536, 2048):
            checkpoints.append({"tick": tick, "nodes_t": {str(i): histories[i]["t"][-1] for i in by},
                                "nodes_c": {str(i): histories[i]["c"][-1] for i in by},
                                "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta),
                                "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta),
                                "world_difference": world_diff[-1]})
    node_results = []
    for node_id in by:
        differences = [a != b for a, b in zip(histories[node_id]["t"], histories[node_id]["c"])]
        first = next((i + 1 for i, value in enumerate(differences) if value), None)
        retained = all(differences[-RETENTION:])
        node_results.append({"node_id": node_id, "first_difference_tick": first,
                             "terminal_treatment": histories[node_id]["t"][-1], "terminal_control": histories[node_id]["c"][-1],
                             "retained_difference_last64": retained,
                             "independent_late_retained_capture": first is not None and first > 38 and retained})
    capture = any(row["independent_late_retained_capture"] for row in node_results)
    pair_retained = all(pair_diff[-RETENTION:]); core_preserved = not any(core_diff)
    return {"mode": mode, "valid": True, "t0_environment": installed, "node_results": node_results,
            "functional_pair_difference_ticks": int(sum(pair_diff)), "functional_pair_difference_retained_last64": pair_retained,
            "core_state_preserved": core_preserved, "late_retained_capture": capture,
            "capture_and_shared_function": capture and pair_retained and core_preserved,
            "maximum_world_difference": max(world_diff), "terminal_world_difference": world_diff[-1],
            "world_difference_sha256": hashlib.sha256(np.asarray(world_diff, np.int32).tobytes()).hexdigest(),
            "checkpoints": checkpoints, "python_interventions_after_t0": 0}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1); rows = []
    for mode in MODES:
        row = run(kernel, mode); rows.append(row)
        print(json.dumps({"mode": mode["id"], "valid": row.get("valid"), "capture": row.get("late_retained_capture"),
                          "function": row.get("capture_and_shared_function"), "nodes": row.get("node_results")}, sort_keys=True), flush=True)
    by = {row["mode"]["id"]: row for row in rows if row.get("valid")}
    candidates = [mode for mode in ("BOTH_VALID_PHASE0", "BOTH_VALID_PHASE252") if by.get(mode, {}).get("capture_and_shared_function")]
    controls_clean = (not by.get("BOTH_SEMANTIC1", {}).get("capture_and_shared_function", False)
                      and not by.get("BOTH_REVERSED", {}).get("capture_and_shared_function", False)
                      and not by.get("NODE3_NEGATIVE_REGION", {}).get("capture_and_shared_function", False)
                      and not by.get("BOTH_VALID_NO_PERIPHERY", {}).get("functional_pair_difference_retained_last64", False))
    controlled = candidates if controls_clean else []
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.distributed_late_capture_function.v1",
        "question": "Can distributed late capture by the two susceptible regions alter the shared function, with direction/semantic/region/direct-effect canaries?",
        "planning": {"mechanism": "two upstream environmental contacts whose native first differences occur after Function A",
                     "controls": ["semantic1", "reversed direction", "nonresponsive region3", "same sources with peripheral organization absent", "phase0/252"],
                     "predicted_outcomes": ["additive capture only", "shared function through captured state", "direct source leakage", "direction/semantic nonspecificity"],
                     "estimated_runtime_minutes": 4, "stop_condition": "six paired all-t0 constructions reach tick2048"},
        "design": {"horizon": HORIZON, "retention": RETENTION, "function_A_tick": 38,
                   "modes": list(MODES), "python_after_t0": ["tick", "log", "stop"]},
        "rows": rows,
        "summary": {"candidate_modes_before_canaries": candidates, "all_canaries_clean": controls_clean,
                    "controlled_capture_function_candidates": controlled,
                    "t0_distributed_capture_changes_shared_function": bool(controlled),
                    "second_independent_experience_demonstrated": False,
                    "native_environmental_transition_after_A_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_T0_CAUSAL_CHAIN" if controlled else "BOUNDED_NULL_OR_CANARY_FAILURE",
        "claim_guard": "A controlled positive would connect t0 environment, late capture and shared function. It still would not be RW3 because the B-specific contacts and destinations are configured at t0 rather than generated by an independent later environmental transition.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
