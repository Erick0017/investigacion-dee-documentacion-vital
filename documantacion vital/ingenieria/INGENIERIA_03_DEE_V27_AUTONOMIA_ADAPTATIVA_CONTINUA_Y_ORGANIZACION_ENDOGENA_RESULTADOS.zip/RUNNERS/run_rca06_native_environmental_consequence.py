#!/usr/bin/env python3
"""Generate peripheral consequences natively from t0 environmental parents."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA06_NATIVE_ENVIRONMENTAL_CONSEQUENCE.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA05_DISTRIBUTED_LATE_CAPTURE_FUNCTION.json"
HORIZON = 1024
RETENTION = 64
MODES = tuple(
    {"id": f"NODE{node}_D{distance}", "nodes": [node], "distance": distance, "broken": False}
    for node in (1, 2) for distance in (6, 12, 18)
) + tuple(
    {"id": f"BOTH_D{distance}", "nodes": [1, 2], "distance": distance, "broken": False}
    for distance in (6, 12, 18)
) + (
    {"id": "BOTH_D18_BROKEN_FIRST_PARENT", "nodes": [1, 2], "distance": 18, "broken": True},
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install_generator(world, meta, node, distance, broken, serial_base):
    tf = lambda v: r09.transform(v, node["frame"])
    event = add(node["b"], tf((0, -1, 0)), 1, meta["n"])
    route = tf((0, 0, 1)); generator = add(event, route, -distance, meta["n"])
    installed = []
    for index, canonical in enumerate(((1, 0, 1), (-1, 0, 1))):
        if broken and index == 0: continue
        direction = tf(canonical); q = add(generator, direction, -1, meta["n"])
        if int(world.raw[q]): raise RuntimeError(f"generator overlap node{node['id']} d{distance} {q}")
        raw = int(pack(serial_base + index, 3, direction, 1)); set_both(world, q, raw, 0)
        installed.append({"q": list(q), "raw": raw, "direction": list(direction), "parent_index": index})
    return {"node_id": node["id"], "event": list(event), "generator": list(generator), "route": list(route),
            "distance": distance, "broken": broken, "parents": installed}


def run(kernel, mode):
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    by = {node["id"]: node for node in nodes}; cby = {node["id"]: node for node in cnodes}
    try:
        generators = [install_generator(treatment, meta, by[node_id], mode["distance"], mode["broken"], 64000 + 10 * node_id)
                      for node_id in mode["nodes"]]
    except RuntimeError as exc:
        return {"mode": mode, "valid": False, "reason": str(exc)}
    history_t = {node_id: [] for node_id in by}; history_c = {node_id: [] for node_id in by}
    pair_diff = []; core_diff = []; world_diff = []; checkpoints = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node_id in by:
            history_t[node_id].append(r09.delta(treatment, by[node_id])); history_c[node_id].append(r09.delta(control, cby[node_id]))
        pair_diff.append(pair(treatment, meta) != pair(control, cmeta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        world_diff.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if tick in (1, 9, 21, 32, 38, 48, 64, 96, 128, 160, 184, 256, 320, 384, 512, 768, 1024):
            checkpoints.append({"tick": tick, "nodes_t": {str(i): history_t[i][-1] for i in by},
                                "nodes_c": {str(i): history_c[i][-1] for i in by},
                                "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta),
                                "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta),
                                "world_difference": world_diff[-1]})
    node_results = []
    for node_id in by:
        differences = [a != b for a, b in zip(history_t[node_id], history_c[node_id])]
        first = next((i + 1 for i, value in enumerate(differences) if value), None)
        retained = all(differences[-RETENTION:])
        node_results.append({"node_id": node_id, "first_difference_tick": first,
                             "terminal_treatment": history_t[node_id][-1], "terminal_control": history_c[node_id][-1],
                             "retained_difference_last64": retained,
                             "independent_late_retained_capture": first is not None and first > 38 and retained})
    target_rows = [row for row in node_results if row["node_id"] in mode["nodes"]]
    no_target_early_change = all(row["first_difference_tick"] is None or row["first_difference_tick"] > 38
                                 for row in target_rows)
    capture = no_target_early_change and any(row["independent_late_retained_capture"] for row in target_rows)
    pair_retained = all(pair_diff[-RETENTION:]); core_preserved = not any(core_diff)
    return {"mode": mode, "valid": True, "t0_environmental_parents": generators,
            "node_results": node_results, "late_retained_capture": capture,
            "no_target_change_before_or_at_function_A": no_target_early_change,
            "functional_pair_difference_ticks": int(sum(pair_diff)), "functional_pair_difference_retained_last64": pair_retained,
            "core_state_preserved": core_preserved,
            "capture_and_shared_function": capture and pair_retained and core_preserved,
            "maximum_world_difference": max(world_diff), "terminal_world_difference": world_diff[-1],
            "world_difference_sha256": hashlib.sha256(np.asarray(world_diff, np.int32).tobytes()).hexdigest(),
            "checkpoints": checkpoints, "python_interventions_after_t0": 0}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8"))
    if "--reanalyze" in sys.argv and OUTPUT.exists():
        existing = json.loads(OUTPUT.read_text(encoding="utf-8")); rows = existing["rows"]; runtime = existing["runtime"]
        for row in rows:
            if not row.get("valid"): continue
            target_rows = [item for item in row["node_results"] if item["node_id"] in row["mode"]["nodes"]]
            no_early = all(item["first_difference_tick"] is None or item["first_difference_tick"] > 38 for item in target_rows)
            capture = no_early and any(item["independent_late_retained_capture"] for item in target_rows)
            row["no_target_change_before_or_at_function_A"] = no_early
            row["late_retained_capture"] = capture
            row["capture_and_shared_function"] = capture and row["functional_pair_difference_retained_last64"] and row["core_state_preserved"]
    else:
        kernel, runtime = load_kernel(1); rows = []
        for mode in MODES:
            row = run(kernel, mode); rows.append(row)
            print(json.dumps({"mode": mode["id"], "valid": row.get("valid"), "capture": row.get("late_retained_capture"),
                              "function": row.get("capture_and_shared_function"), "nodes": row.get("node_results")}, sort_keys=True), flush=True)
    valid = [row for row in rows if row.get("valid")]
    positive = [row["mode"]["id"] for row in valid if row["capture_and_shared_function"] and not row["mode"]["broken"]]
    broken = next((row for row in valid if row["mode"]["broken"]), None)
    controlled = positive if broken is not None and not broken["capture_and_shared_function"] else []
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.native_environmental_consequence.v1",
        "question": "Can t0 semantic1 parents generate a later consequence that is retained by the competent periphery and changes shared function after Function A?",
        "planning": {"mechanism": "two-parent native consequence generators in each peripheral relational frame",
                     "controls": ["single-region generators", "distributed generators", "distances6/12/18", "broken-parent generator"],
                     "predicted_outcomes": ["early capture", "late capture", "shared function", "generator-independent leakage"],
                     "estimated_runtime_minutes": 4, "stop_condition": "ten paired all-t0 worlds reach tick1024"},
        "design": {"horizon": HORIZON, "retention": RETENTION, "function_A_tick": 38,
                   "modes": list(MODES), "python_after_t0": ["tick", "log", "stop"],
                   "answer_carrier_present_at_t0": False, "environmental_parents_present_at_t0": True},
        "rows": rows,
        "summary": {"valid_modes": len(valid), "candidate_modes_before_broken_canary": positive,
                    "broken_generator_blocks_candidate": broken is not None and not broken["capture_and_shared_function"],
                    "controlled_native_generator_candidates": controlled,
                    "native_generated_late_capture_and_function": bool(controlled),
                    "independent_environmental_reversal_demonstrated": False,
                    "third_experience_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_NATIVE_GENERATOR_CHAIN" if controlled else "BOUNDED_NULL_OR_CANARY_FAILURE",
        "claim_guard": "A positive generator is all-t0 and creates the carrier natively, but the generator geometry still targets predefined peripheral regions. RW3 additionally requires an independent later environmental change, no answer-specific destination, a third transition, and native functional causality controls.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
