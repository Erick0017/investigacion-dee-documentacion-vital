#!/usr/bin/env python3
"""Test whether the late-captured peripheral organization causes new function."""
from __future__ import annotations

import hashlib
import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA07_PERIPHERAL_STATE_FUNCTION_NECESSITY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA06_NATIVE_ENVIRONMENTAL_CONSEQUENCE.json"
INTERVENTION_TICK = 184
FOLLOWUP = 512
RETENTION = 64
MODES = ("INTACT", "SHAM_REWRITE", "ORDER_PAIR_EQUALIZE", "STRUCTURE_EQUALIZE", "LOCAL_R6_EQUALIZE", "GENERATOR_CUT")


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def copy_site(target, source, q):
    set_both(target, q, int(source.raw[q]), int(source.clock_a[q]))


def radius_positions(center, radius, n):
    return sorted({add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)})


def intervention(world, control, nodes, generators, mode, n):
    positions = []
    if mode in ("INTACT",): return {"mode": mode, "positions": [], "type": "NO_INTERVENTION"}
    if mode == "SHAM_REWRITE":
        positions = [q for node in nodes[:2] for q in (node["a"], node["b"])]
        before = [{"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q])} for q in positions]
        for q in positions: set_both(world, q, int(world.raw[q]), int(world.clock_a[q]))
        return {"mode": mode, "positions": before, "type": "DIAGNOSTIC_INTERVENTION"}
    if mode == "ORDER_PAIR_EQUALIZE":
        positions = [q for node in nodes[:2] for q in (node["a"], node["b"])]
    elif mode == "STRUCTURE_EQUALIZE":
        positions = sorted({q for node in nodes[:2] for q in rca05.node_positions(node, n)})
    elif mode == "LOCAL_R6_EQUALIZE":
        positions = sorted({q for node in nodes[:2] for q in radius_positions(node["center"], 6, n)})
    elif mode == "GENERATOR_CUT":
        positions = [tuple(parent["q"]) for generator in generators for parent in generator["parents"]]
    else:
        raise ValueError(mode)
    before = [{"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q]),
               "control_raw": int(control.raw[q]), "control_clock": int(control.clock_a[q])} for q in positions]
    if mode == "GENERATOR_CUT":
        for q in positions: set_both(world, q, 0, 0)
    else:
        for q in positions: copy_site(world, control, q)
    return {"mode": mode, "positions": before, "position_count": len(positions), "type": "DIAGNOSTIC_INTERVENTION"}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    generators = [rca06.install_generator(treatment, meta, node, 12, False, 65000 + 10 * node["id"])
                  for node in nodes[:2]]
    pre_rows = []
    for tick in range(1, INTERVENTION_TICK + 1):
        treatment.tick(); control.tick()
        if tick in (1, 9, 21, 38, 64, 96, 128, 139, 140, 160, 184):
            pre_rows.append({"tick": tick, "nodes_t": {str(n["id"]): r09.delta(treatment, n) for n in nodes},
                             "nodes_c": {str(n["id"]): r09.delta(control, cnodes[n["id"] - 1]) for n in nodes},
                             "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta),
                             "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta)})
    branches = {mode: NativeWorld(kernel, treatment.raw, treatment.clock_a) for mode in MODES}
    records = {mode: intervention(branches[mode], control, nodes, generators, mode, meta["n"]) for mode in MODES}
    pair_diff = {mode: [] for mode in MODES}; node_histories = {mode: {n["id"]: [] for n in nodes} for mode in MODES}
    world_diff = {mode: [] for mode in MODES}; checkpoints = {mode: [] for mode in MODES}
    for latency in range(1, FOLLOWUP + 1):
        control.tick()
        for mode, world in branches.items():
            world.tick(); pair_diff[mode].append(pair(world, meta) != pair(control, cmeta))
            world_diff[mode].append(int(np.count_nonzero(world.raw != control.raw)))
            for node in nodes: node_histories[mode][node["id"]].append(r09.delta(world, node))
            if latency in (1, 2, 4, 8, 16, 32, 42, 64, 96, 128, 192, 256, 384, 512):
                checkpoints[mode].append({"latency": latency, "tick": INTERVENTION_TICK + latency,
                                          "nodes": {str(n["id"]): node_histories[mode][n["id"]][-1] for n in nodes},
                                          "pair": pair(world, meta), "control_pair": pair(control, cmeta),
                                          "core": delta_value(world, meta), "control_core": delta_value(control, cmeta),
                                          "world_difference": world_diff[mode][-1]})
    rows = []
    for mode in MODES:
        retained_function = all(pair_diff[mode][-RETENTION:])
        first_function = next((i + 1 for i, value in enumerate(pair_diff[mode]) if value), None)
        rows.append({"mode": mode, "intervention": records[mode],
                     "first_function_difference_latency": first_function,
                     "functional_difference_ticks": int(sum(pair_diff[mode])),
                     "retained_function_difference_last64": retained_function,
                     "terminal_node_deltas": {str(n["id"]): node_histories[mode][n["id"]][-1] for n in nodes},
                     "terminal_world_difference": world_diff[mode][-1], "maximum_world_difference": max(world_diff[mode]),
                     "world_difference_sha256": hashlib.sha256(np.asarray(world_diff[mode], np.int32).tobytes()).hexdigest(),
                     "checkpoints": checkpoints[mode],
                     "python_interventions_after_t0": 0 if mode == "INTACT" else 1})
    by = {row["mode"]: row for row in rows}
    sham_matches = (by["SHAM_REWRITE"]["retained_function_difference_last64"] == by["INTACT"]["retained_function_difference_last64"]
                    and by["SHAM_REWRITE"]["first_function_difference_latency"] == by["INTACT"]["first_function_difference_latency"])
    blocked_modes = [mode for mode in ("ORDER_PAIR_EQUALIZE", "STRUCTURE_EQUALIZE", "LOCAL_R6_EQUALIZE")
                     if not by[mode]["retained_function_difference_last64"]]
    necessity = bool(by["INTACT"]["retained_function_difference_last64"] and sham_matches and blocked_modes)
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.peripheral_function_necessity.v1",
        "question": "Is the shared functional transition caused by the late-captured peripheral organization rather than direct generator drive?",
        "planning": {"mechanism": "neutralize captured organization at tick184 before the shared pair first diverges",
                     "controls": ["intact", "same-value sham", "order-pair equalization", "full learner-structure equalization", "radius6 equalization", "generator cut"],
                     "predicted_outcomes": ["local stored-state necessity", "distributed neighborhood necessity", "ongoing generator dependence", "state-independent direct drive"],
                     "estimated_runtime_minutes": 2, "stop_condition": "six branches followed 512 ticks"},
        "design": {"candidate": "BOTH_D12", "native_prefix_ticks": INTERVENTION_TICK,
                   "intervention_before_first_function_difference": True, "followup": FOLLOWUP, "retention": RETENTION},
        "native_prefix": pre_rows, "rows": rows,
        "summary": {"intact_function_retained": by["INTACT"]["retained_function_difference_last64"],
                    "sham_matches_intact": sham_matches, "equalization_modes_blocking_retained_function": blocked_modes,
                    "generator_cut_function_retained": by["GENERATOR_CUT"]["retained_function_difference_last64"],
                    "captured_peripheral_organization_causally_necessary": necessity,
                    "causal_result_is_diagnostic": True,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_CAUSAL_NECESSITY" if necessity else "FUNCTION_NOT_LOCALIZED_TO_TESTED_PERIPHERAL_SCALES",
        "claim_guard": "Equalizations and cuts are diagnostic host interventions. Necessity does not remove the predefined generator destinations or supply an independent third experience.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "rows": [{"mode": r["mode"], "first": r["first_function_difference_latency"], "retained": r["retained_function_difference_last64"]} for r in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
