#!/usr/bin/env python3
"""Pre-capture tomography of the native D12 distributed functional transition."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_rca07_peripheral_state_function_necessity as rca07
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA08_PRECAPTURE_DISTRIBUTED_NECESSITY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA07_PERIPHERAL_STATE_FUNCTION_NECESSITY.json"
INTERVENTION_TICK = 128
FOLLOWUP = 512
RETENTION = 64
MODES = ("INTACT", "SHAM_REWRITE", "PERIPHERY_REMOVE", "LOCAL_R6_EQUALIZE", "LOCAL_R10_EQUALIZE", "GENERATOR_CUT")


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def intervene(world, control, nodes, generators, mode, n):
    if mode == "INTACT": return {"mode": mode, "position_count": 0, "type": "NO_INTERVENTION"}
    if mode in ("SHAM_REWRITE", "PERIPHERY_REMOVE"):
        positions = sorted({q for node in nodes[:2] for q in rca05.node_positions(node, n)})
    elif mode == "LOCAL_R6_EQUALIZE":
        positions = sorted({q for node in nodes[:2] for q in rca07.radius_positions(node["center"], 6, n)})
    elif mode == "LOCAL_R10_EQUALIZE":
        positions = sorted({q for node in nodes[:2] for q in rca07.radius_positions(node["center"], 10, n)})
    elif mode == "GENERATOR_CUT":
        positions = [tuple(parent["q"]) for generator in generators for parent in generator["parents"]]
    else: raise ValueError(mode)
    before = [{"q": list(q), "raw": int(world.raw[q]), "clock": int(world.clock_a[q]),
               "control_raw": int(control.raw[q]), "control_clock": int(control.clock_a[q])} for q in positions]
    if mode == "SHAM_REWRITE":
        for q in positions: set_both(world, q, int(world.raw[q]), int(world.clock_a[q]))
    elif mode in ("PERIPHERY_REMOVE", "GENERATOR_CUT"):
        for q in positions: set_both(world, q, 0, 0)
    else:
        for q in positions: rca07.copy_site(world, control, q)
    return {"mode": mode, "position_count": len(positions), "positions": before, "type": "DIAGNOSTIC_INTERVENTION"}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    generators = [rca06.install_generator(treatment, meta, node, 12, False, 66000 + 10 * node["id"])
                  for node in nodes[:2]]
    for _ in range(INTERVENTION_TICK): treatment.tick(); control.tick()
    prefix = {"nodes_t": {str(n["id"]): r09.delta(treatment, n) for n in nodes},
              "nodes_c": {str(n["id"]): r09.delta(control, cnodes[n["id"] - 1]) for n in nodes},
              "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta),
              "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta),
              "world_difference": int(np.count_nonzero(treatment.raw != control.raw))}
    branches = {mode: NativeWorld(kernel, treatment.raw, treatment.clock_a) for mode in MODES}
    records = {mode: intervene(branches[mode], control, nodes, generators, mode, meta["n"]) for mode in MODES}
    pair_diff = {mode: [] for mode in MODES}; node_diff = {mode: [] for mode in MODES}; checkpoints = {mode: [] for mode in MODES}
    for latency in range(1, FOLLOWUP + 1):
        control.tick()
        for mode, world in branches.items():
            world.tick(); pair_diff[mode].append(pair(world, meta) != pair(control, cmeta))
            current_nodes = {str(n["id"]): r09.delta(world, n) for n in nodes}
            control_nodes = {str(n["id"]): r09.delta(control, cnodes[n["id"] - 1]) for n in nodes}
            node_diff[mode].append(current_nodes != control_nodes)
            if latency in (1, 2, 4, 8, 11, 12, 16, 32, 56, 64, 98, 128, 192, 256, 384, 512):
                checkpoints[mode].append({"latency": latency, "tick": INTERVENTION_TICK + latency,
                                          "nodes": current_nodes, "control_nodes": control_nodes,
                                          "pair": pair(world, meta), "control_pair": pair(control, cmeta),
                                          "core": delta_value(world, meta), "control_core": delta_value(control, cmeta)})
    rows = []
    for mode in MODES:
        first_pair = next((i + 1 for i, value in enumerate(pair_diff[mode]) if value), None)
        first_node = next((i + 1 for i, value in enumerate(node_diff[mode]) if value), None)
        rows.append({"mode": mode, "intervention": records[mode],
                     "first_node_difference_latency": first_node,
                     "first_function_difference_latency": first_pair,
                     "retained_node_difference_last64": all(node_diff[mode][-RETENTION:]),
                     "retained_function_difference_last64": all(pair_diff[mode][-RETENTION:]),
                     "functional_difference_ticks": int(sum(pair_diff[mode])), "checkpoints": checkpoints[mode],
                     "python_interventions_after_t0": 0 if mode == "INTACT" else 1})
    by = {row["mode"]: row for row in rows}
    sham_matches = (by["SHAM_REWRITE"]["first_function_difference_latency"] == by["INTACT"]["first_function_difference_latency"]
                    and by["SHAM_REWRITE"]["retained_function_difference_last64"] == by["INTACT"]["retained_function_difference_last64"])
    blocked = [mode for mode in ("PERIPHERY_REMOVE", "LOCAL_R6_EQUALIZE", "LOCAL_R10_EQUALIZE", "GENERATOR_CUT")
               if not by[mode]["retained_function_difference_last64"]]
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.precapture_distributed_necessity.v1",
        "question": "Before local capture and shared-function divergence, which spatial causal domain is necessary for the D12 transition?",
        "planning": {"mechanism": "intervene at tick128, after Function A but before node and action divergence",
                     "controls": ["intact", "same-value sham", "remove peripheral structure", "copy matched control within r6/r10", "cut generator parents"],
                     "predicted_outcomes": ["peripheral transducer necessity", "distributed neighborhood necessity", "ongoing parent dependence", "already escaped causal cone"],
                     "estimated_runtime_minutes": 2, "stop_condition": "six branches followed 512 ticks"},
        "design": {"candidate": "BOTH_D12", "intervention_tick": INTERVENTION_TICK, "followup": FOLLOWUP,
                   "before_local_capture": True, "before_shared_function_divergence": True},
        "prefix_state": prefix, "rows": rows,
        "summary": {"intact_first_function_latency": by["INTACT"]["first_function_difference_latency"],
                    "sham_matches_intact": sham_matches, "modes_blocking_retained_function": blocked,
                    "periphery_removal_blocks": "PERIPHERY_REMOVE" in blocked,
                    "r6_equalization_blocks": "LOCAL_R6_EQUALIZE" in blocked,
                    "r10_equalization_blocks": "LOCAL_R10_EQUALIZE" in blocked,
                    "generator_cut_blocks": "GENERATOR_CUT" in blocked,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_PRECAPTURE_CAUSAL_DOMAIN_MAPPED",
        "claim_guard": "All removals/equalizations are diagnostic. Spatial necessity cannot by itself turn predefined t0 generator geometry into an independent later environment or RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "rows": [{"mode": r["mode"], "node": r["first_node_difference_latency"],
                                "function": r["first_function_difference_latency"], "retained": r["retained_function_difference_last64"]} for r in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
