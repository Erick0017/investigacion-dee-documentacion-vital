#!/usr/bin/env python3
"""Determine whether the peripheral morphology is an early causal transducer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_rca07_peripheral_state_function_necessity as rca07
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA09_EARLY_MORPHOLOGICAL_TRANSDUCTION.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA08_PRECAPTURE_DISTRIBUTED_NECESSITY.json"
HORIZON = 512
RETENTION = 64
MODES = ("INTACT", "NO_PERIPHERY_T0", "REMOVE_PERIPHERY_T38", "EQUALIZE_LOCAL_R10_T38", "BROKEN_GENERATOR")


def clear(world, positions):
    for q in positions:
        world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
        world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def run(kernel, mode):
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    broken = mode == "BROKEN_GENERATOR"
    generators = [rca06.install_generator(treatment, meta, node, 12, broken, 67000 + 10 * node["id"])
                  for node in nodes[:2]]
    periphery = sorted({q for node in nodes for q in rca05.node_positions(node, meta["n"])})
    record = {"mode": mode, "type": "T0_CONFIGURATION" if mode == "NO_PERIPHERY_T0" else "NONE", "positions": []}
    if mode == "NO_PERIPHERY_T0":
        record["positions"] = [{"q": list(q), "treatment_raw": int(treatment.raw[q]), "control_raw": int(control.raw[q])} for q in periphery]
        clear(treatment, periphery); clear(control, periphery)
    pair_diff = []; core_diff = []; node_diff = []; checkpoints = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        if tick == 38 and mode == "REMOVE_PERIPHERY_T38":
            record = {"mode": mode, "type": "DIAGNOSTIC_INTERVENTION", "positions": [{"q": list(q), "treatment_raw": int(treatment.raw[q]), "control_raw": int(control.raw[q])} for q in periphery]}
            clear(treatment, periphery); clear(control, periphery)
        elif tick == 38 and mode == "EQUALIZE_LOCAL_R10_T38":
            positions = sorted({q for node in nodes[:2] for q in rca07.radius_positions(node["center"], 10, meta["n"])})
            record = {"mode": mode, "type": "DIAGNOSTIC_INTERVENTION", "position_count": len(positions)}
            for q in positions: rca07.copy_site(treatment, control, q)
        pair_diff.append(pair(treatment, meta) != pair(control, cmeta))
        core_diff.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        current_nodes = {str(n["id"]): r09.delta(treatment, n) for n in nodes}
        control_nodes = {str(n["id"]): r09.delta(control, cnodes[n["id"] - 1]) for n in nodes}
        node_diff.append(current_nodes != control_nodes)
        if tick in (1, 9, 21, 32, 38, 39, 48, 64, 96, 128, 139, 140, 160, 184, 226, 256, 320, 384, 512):
            checkpoints.append({"tick": tick, "nodes_t": current_nodes, "nodes_c": control_nodes,
                                "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta),
                                "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta)})
    first_pair = next((i + 1 for i, value in enumerate(pair_diff) if value), None)
    first_node = next((i + 1 for i, value in enumerate(node_diff) if value), None)
    return {"mode": mode, "valid": True, "generators": generators, "structural_control": record,
            "first_node_difference_tick": first_node, "first_function_difference_tick": first_pair,
            "retained_node_difference_last64": all(node_diff[-RETENTION:]),
            "retained_function_difference_last64": all(pair_diff[-RETENTION:]),
            "core_state_preserved": not any(core_diff), "checkpoints": checkpoints,
            "python_interventions_after_t0": int(mode in ("REMOVE_PERIPHERY_T38", "EQUALIZE_LOCAL_R10_T38"))}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode) for mode in MODES]
    by = {row["mode"]: row for row in rows}
    for row in rows:
        print(json.dumps({"mode": row["mode"], "node": row["first_node_difference_tick"],
                          "function": row["first_function_difference_tick"], "retained": row["retained_function_difference_last64"]}, sort_keys=True), flush=True)
    intact = by["INTACT"]["retained_function_difference_last64"]
    blocks = [mode for mode in ("NO_PERIPHERY_T0", "REMOVE_PERIPHERY_T38", "EQUALIZE_LOCAL_R10_T38", "BROKEN_GENERATOR")
              if not by[mode]["retained_function_difference_last64"]]
    morphology_required = intact and "NO_PERIPHERY_T0" in blocks
    early_required = intact and ("REMOVE_PERIPHERY_T38" in blocks or "EQUALIZE_LOCAL_R10_T38" in blocks)
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.early_morphological_transduction.v1",
        "question": "Does the distributed D12 environment require peripheral morphology before/at Function A to seed its later shared functional transition?",
        "planning": {"mechanism": "remove the prospective transducer at t0 or tick38 with matched structural controls",
                     "controls": ["intact", "no periphery t0", "paired removal tick38", "r10 counterfactual copy tick38", "broken generator"],
                     "predicted_outcomes": ["direct environmental action", "morphological transduction", "early distributed escape", "generator leakage"],
                     "estimated_runtime_minutes": 2, "stop_condition": "five paired worlds reach tick512"},
        "design": {"candidate": "BOTH_D12", "horizon": HORIZON, "retention": RETENTION,
                   "function_A_tick": 38, "structural_changes_paired_in_treatment_and_control": True},
        "rows": rows,
        "summary": {"intact_function_retained": intact, "modes_blocking_retained_function": blocks,
                    "peripheral_morphology_required_from_t0": morphology_required,
                    "peripheral_domain_required_at_tick38": early_required,
                    "morphological_learning_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "DIAGNOSTIC_MORPHOLOGICAL_TRANSDUCTION" if morphology_required else "DIRECT_OR_NONPERIPHERAL_DISTRIBUTED_EFFECT",
        "claim_guard": "Structural necessity is not experience-dependent remodelling. The intervention branches are diagnostic, and the intact generator still uses predefined destination geometry.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
