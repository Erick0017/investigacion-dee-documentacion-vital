#!/usr/bin/env python3
"""Longitudinal turnover, morphology, regime and viability audit of BOTH_D12."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_rca06_native_environmental_consequence as rca06
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_landscape_l04_coupling_mechanism_controls import periods
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA10_LONGITUDINAL_CAUSAL_ECOLOGY.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA09_EARLY_MORPHOLOGICAL_TRANSDUCTION.json"
HORIZON = 1024
WINDOW = 128


def digest_values(values):
    h = hashlib.sha256()
    for value in values: h.update(int(value).to_bytes(8, "little"))
    return h.hexdigest()


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    generators = [rca06.install_generator(treatment, meta, node, 12, False, 68000 + 10 * node["id"])
                  for node in nodes[:2]]
    periphery = sorted({q for node in nodes for q in rca05.node_positions(node, meta["n"])})
    pair_t = []; pair_c = []; core_t = []; core_c = []; viability = []
    pair_empty = []; pair_raw_change_ticks = []; periphery_change_ticks = []; morphology_difference_ticks = []
    checkpoints = []; previous_pair = None; previous_periphery = None
    empty_episode = False; endogenous_repopulation_ticks = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        pt, pc = pair(treatment, meta), pair(control, cmeta); pair_t.append(tuple(pt)); pair_c.append(tuple(pc))
        dt, dc = delta_value(treatment, meta), delta_value(control, cmeta); core_t.append(dt); core_c.append(dc)
        occupied = bool(pt[0] or pt[1]); pair_empty.append(not occupied)
        viability.append(tick < 38 or (dt == 1 and occupied))
        if previous_pair is not None and tuple(pt) != previous_pair: pair_raw_change_ticks.append(tick)
        if not occupied: empty_episode = True
        elif empty_episode:
            endogenous_repopulation_ticks.append(tick); empty_episode = False
        local = tuple(int(treatment.raw[q]) for q in periphery)
        local_control = tuple(int(control.raw[q]) for q in periphery)
        if previous_periphery is not None and local != previous_periphery: periphery_change_ticks.append(tick)
        if local != local_control: morphology_difference_ticks.append(tick)
        previous_pair = tuple(pt); previous_periphery = local
        if tick in (1, 9, 21, 38, 64, 96, 128, 139, 140, 160, 184, 226, 256, 320, 384, 512, 640, 768, 896, 1024):
            checkpoints.append({"tick": tick, "core_t": dt, "core_c": dc, "pair_t": pt, "pair_c": pc,
                                "viability": viability[-1],
                                "node_deltas_t": {str(n["id"]): r09.delta(treatment, n) for n in nodes},
                                "node_deltas_c": {str(n["id"]): r09.delta(control, cnodes[n["id"] - 1]) for n in nodes},
                                "periphery_occupied_t": sum(bool(value) for value in local),
                                "periphery_occupied_c": sum(bool(value) for value in local_control),
                                "periphery_raw_sha256_t": digest_values(local),
                                "periphery_raw_sha256_c": digest_values(local_control),
                                "world_support_t": int(np.count_nonzero(treatment.raw)),
                                "world_support_c": int(np.count_nonzero(control.raw))})
    windows = []
    for start in range(0, HORIZON, WINDOW):
        t_seq = pair_t[start:start + WINDOW]; c_seq = pair_c[start:start + WINDOW]
        windows.append({"start": start + 1, "end": start + len(t_seq),
                        "treatment_periods": periods(t_seq), "control_periods": periods(c_seq),
                        "treatment_pair_digest": digest_values([value for item in t_seq for value in item]),
                        "control_pair_digest": digest_values([value for item in c_seq for value in item]),
                        "function_distinct": t_seq != c_seq})
    stable_viability = all(viability[37:])
    raw_periods = [row["treatment_periods"]["raw_pair"] for row in windows]
    exact_cycle_supported = any(value not in (None, 1) for value in raw_periods)
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.longitudinal_causal_ecology.v1",
        "question": "During the native BOTH_D12 transition, do constituents turn over, morphology change, a collective period emerge, or a predefined viability invariant require active restoration?",
        "planning": {"mechanism": "uninterrupted all-t0 treatment/control trajectory",
                     "controls": ["matched no-generator world", "fixed periphery support set", "frozen viability V=core_delta1 AND nonempty action pair after tick38"],
                     "predicted_outcomes": ["static morphology", "dynamic constituents", "empty/repopulation turnover", "periodic collective regime", "viability loss/restoration"],
                     "estimated_runtime_minutes": 1, "stop_condition": "two worlds reach tick1024"},
        "design": {"candidate": "BOTH_D12", "horizon": HORIZON, "window": WINDOW,
                   "viability_definition": "V=1 iff core delta is 1 and at least one shared-action site is occupied after Function A tick38",
                   "python_after_t0": ["tick", "log", "stop"]},
        "generators": generators, "checkpoints": checkpoints, "functional_windows": windows,
        "summary": {"core_delta_treatment_values_after_tick38": sorted({x for x in core_t[37:] if x is not None}),
                    "viability_held_all_ticks_after_function_A": stable_viability,
                    "viability_loss_ticks_after_function_A": [i + 38 for i, value in enumerate(viability[37:]) if not value],
                    "active_viability_restoration_events": 0,
                    "pair_raw_change_ticks": len(pair_raw_change_ticks),
                    "pair_empty_ticks": int(sum(pair_empty)),
                    "endogenous_pair_repopulation_ticks": endogenous_repopulation_ticks,
                    "periphery_raw_change_ticks": len(periphery_change_ticks),
                    "treatment_control_morphology_difference_ticks": len(morphology_difference_ticks),
                    "raw_pair_period_path": raw_periods,
                    "collective_attractor_demonstrated": False,
                    "endogenous_turnover_demonstrated": bool(endogenous_repopulation_ticks),
                    "morphological_adaptation_demonstrated": False,
                    "self_maintenance_demonstrated": False,
                    "passive_functional_invariant_preservation": stable_viability,
                    "rw3_demonstrated": False},
        "interpretation": {"turnover": "Raw constituent changes or action-pair dynamics are not regeneration unless loss is followed by native functional restoration.",
                           "attractor": "Periodicity alone is insufficient without basin/convergence across microstates.",
                           "viability": "An invariant that never leaves its domain demonstrates robustness, not active self-maintenance."},
        "claim_guard": "This uninterrupted trajectory characterizes dynamics but does not add a new environmental reversal or recurrent learning episode.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
