#!/usr/bin/env python3
"""Test non-addressed common environmental fronts against the causal tissue."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, write_json
import run_rca02_continuous_competence_core_periphery as rca02
import run_rca05_distributed_late_capture_function as rca05
import run_reactivation_r09_distributed_rotated_array as r09
from run_dd_r01_remote_dependency_map import pair
from run_nature_n07_native_consequence_expression import delta_value


OUTPUT = ROOT / "MECHANISM_SELECTION/ING03_RCA11_COMMON_ENVIRONMENTAL_FRONT.json"
PRIOR = ROOT / "MECHANISM_SELECTION/ING03_RCA10_LONGITUDINAL_CAUSAL_ECOLOGY.json"
HORIZON = 768
RETENTION = 64
MODES = (
    {"id": "Z_SPARSE3_SEM4", "axis": 2, "offsets": [-14, 0, 14], "semantic": 4, "periphery": True},
    {"id": "X_SPARSE3_SEM4", "axis": 0, "offsets": [-14, 0, 14], "semantic": 4, "periphery": True},
    {"id": "Y_SPARSE3_SEM4", "axis": 1, "offsets": [-14, 0, 14], "semantic": 4, "periphery": True},
    {"id": "Z_DENSE5_SEM4", "axis": 2, "offsets": [-16, -8, 0, 8, 16], "semantic": 4, "periphery": True},
    {"id": "Z_SPARSE3_SEM1", "axis": 2, "offsets": [-14, 0, 14], "semantic": 1, "periphery": True},
    {"id": "Z_SPARSE3_NO_PERIPHERY", "axis": 2, "offsets": [-14, 0, 14], "semantic": 4, "periphery": False},
)


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def install_front(world, meta, mode):
    center = meta["c"]; n = meta["n"]; axis = mode["axis"]
    direction = [0, 0, 0]; direction[axis] = 1; direction = tuple(direction)
    fixed = list(center); fixed[axis] = (center[axis] - 16) % n
    transverse = [index for index in range(3) if index != axis]
    installed = []; skipped = []; serial = 0
    for u in mode["offsets"]:
        for v in mode["offsets"]:
            q = list(fixed); q[transverse[0]] = (center[transverse[0]] + u) % n; q[transverse[1]] = (center[transverse[1]] + v) % n; q = tuple(q)
            if int(world.raw[q]): skipped.append(list(q)); continue
            raw = int(pack(69000 + serial, 0, direction, mode["semantic"])); set_both(world, q, raw, 0)
            installed.append({"q": list(q), "raw": raw, "direction": list(direction), "u": u, "v": v}); serial += 1
    return {"axis": axis, "normal": list(direction), "plane_offset": -16, "installed": installed, "skipped": skipped}


def run(kernel, mode):
    treatment, meta, nodes = rca02.build(kernel); control, cmeta, cnodes = rca02.build(kernel)
    if not mode["periphery"]:
        positions = sorted({q for node in nodes for q in rca05.node_positions(node, meta["n"])})
        for q in positions: set_both(treatment, q, 0, 0); set_both(control, q, 0, 0)
    front = install_front(treatment, meta, mode)
    histories_t = {n["id"]: [] for n in nodes}; histories_c = {n["id"]: [] for n in nodes}
    pair_diff = []; core_diff = []; world_diff = []; checkpoints = []
    for tick in range(1, HORIZON + 1):
        treatment.tick(); control.tick()
        for node in nodes:
            histories_t[node["id"]].append(r09.delta(treatment, node)); histories_c[node["id"]].append(r09.delta(control, cnodes[node["id"] - 1]))
        pair_diff.append(pair(treatment, meta) != pair(control, cmeta)); core_diff.append(delta_value(treatment, meta) != delta_value(control, cmeta))
        world_diff.append(int(np.count_nonzero(treatment.raw != control.raw)))
        if tick in (1, 9, 21, 38, 64, 96, 128, 139, 140, 184, 226, 256, 320, 384, 512, 640, 768):
            checkpoints.append({"tick": tick, "nodes_t": {str(i): histories_t[i][-1] for i in histories_t},
                                "nodes_c": {str(i): histories_c[i][-1] for i in histories_c},
                                "core_t": delta_value(treatment, meta), "core_c": delta_value(control, cmeta),
                                "pair_t": pair(treatment, meta), "pair_c": pair(control, cmeta), "world_difference": world_diff[-1]})
    node_results = []
    for node_id in histories_t:
        differences = [a != b for a, b in zip(histories_t[node_id], histories_c[node_id])]
        first = next((i + 1 for i, value in enumerate(differences) if value), None)
        node_results.append({"node_id": node_id, "first_difference_tick": first,
                             "retained_difference_last64": all(differences[-RETENTION:]),
                             "terminal_treatment": histories_t[node_id][-1], "terminal_control": histories_c[node_id][-1]})
    first_pair = next((i + 1 for i, value in enumerate(pair_diff) if value), None)
    no_early_node = all(row["first_difference_tick"] is None or row["first_difference_tick"] > 38 for row in node_results)
    transition = (first_pair is not None and first_pair > 38 and all(pair_diff[-RETENTION:]) and not any(core_diff) and no_early_node)
    return {"mode": mode, "valid": True, "front": front, "node_results": node_results,
            "first_function_difference_tick": first_pair, "retained_function_difference_last64": all(pair_diff[-RETENTION:]),
            "core_state_preserved": not any(core_diff), "no_node_difference_before_or_at_A": no_early_node,
            "nonaddressed_late_functional_transition": transition,
            "maximum_world_difference": max(world_diff), "terminal_world_difference": world_diff[-1],
            "world_difference_sha256": hashlib.sha256(np.asarray(world_diff, np.int32).tobytes()).hexdigest(),
            "checkpoints": checkpoints, "python_interventions_after_t0": 0}


def main():
    prior = json.loads(PRIOR.read_text(encoding="utf-8")); kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode) for mode in MODES]
    for row in rows:
        print(json.dumps({"mode": row["mode"]["id"], "first_function": row["first_function_difference_tick"],
                          "transition": row["nonaddressed_late_functional_transition"], "nodes": row["node_results"]}, sort_keys=True), flush=True)
    positives = [row["mode"]["id"] for row in rows if row["nonaddressed_late_functional_transition"] and row["mode"]["periphery"]]
    no_periphery = next(row for row in rows if row["mode"]["id"] == "Z_SPARSE3_NO_PERIPHERY")
    controlled = positives if not no_periphery["retained_function_difference_last64"] else []
    result = seal({
        "schema": "dee.v27.ing03.renewable_competence.common_environmental_front.v1",
        "question": "Can a common non-addressed spatial front induce a state-dependent late functional transition in the mature causal tissue?",
        "planning": {"mechanism": "sparse/dense planes entering the complete 3D organization without per-region destinations",
                     "controls": ["x/y/z normals", "3x3 versus5x5", "semantic1 versus4", "same front without periphery"],
                     "predicted_outcomes": ["no interaction", "early nonspecific disturbance", "late tissue-selected capture", "direct core effect"],
                     "estimated_runtime_minutes": 2, "stop_condition": "six paired all-t0 worlds reach tick768"},
        "design": {"horizon": HORIZON, "retention": RETENTION, "function_A_tick": 38,
                   "modes": list(MODES), "explicit_destination_encoded": False,
                   "future_answer_encoded": False, "python_after_t0": ["tick", "log", "stop"]},
        "rows": rows,
        "summary": {"positive_fronts_before_no_periphery_canary": positives,
                    "no_periphery_front_changes_function": no_periphery["retained_function_difference_last64"],
                    "controlled_nonaddressed_front_candidates": controlled,
                    "state_dependent_common_front_transition": bool(controlled),
                    "second_environmental_class_learned": False,
                    "third_experience_demonstrated": False,
                    "rw3_demonstrated": False},
        "status": "NATIVE_NONADDRESSED_FRONT_CANDIDATE" if controlled else "BOUNDED_NULL_OR_DIRECT_FRONT_EFFECT",
        "claim_guard": "The front is a frozen t0 environmental condition. A positive non-addressed transition still requires counterfactual learned content, causal dependence on retained change, a later native environmental reversal and a third adaptive transition for RW3.",
        "evidence": [{"path": PRIOR.relative_to(ROOT).as_posix(), "file_sha256": sha256_file(PRIOR), "content_sha256": prior.get("content_sha256")}],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({"output": OUTPUT.relative_to(ROOT).as_posix(), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
