#!/usr/bin/env python3
"""Fresh signed/permuted holdout for frozen C15 late development."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, canonical_hash, load_kernel, pack, read, seal, sha256_file, transform, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB


LOCK = ROOT / "FREEZE/ING03_REACT_C15_LATE_DEVELOPMENT_LOCK.json"
P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def put_transducer(raw, clock, c, n, tf, base):
    p = tf(P); qp = add(c, p, 1, n); put(raw, clock, c, base, 7, p, 1, 11)
    specs = ((add(qp, tf(S1), -1, n), tf(S1), 11), (add(qp, tf(S2), -1, n), tf(S2), 13),
             (add(c, tf(N1), -2, n), tf(N1), 17), (add(c, tf(N2), -2, n), tf(N2), 19))
    positions = [c, qp]
    for index, (q, direction, sreg) in enumerate(specs):
        put(raw, clock, q, base + 100 + index, sreg, direction, 4, 100 + index); positions.append(q)
    return c, qp, positions


def build(kernel, frame, condition, architecture):
    permutation, signs = frame; tf = lambda vector: transform(vector, permutation, signs)
    n = architecture["n"]; raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; p = tf(P); a = add(c, p, -1, n); b = add(c, p, 1, n)
    learner = []
    put(raw, clock, a, 1000, 100, semantic=1, phase=architecture["memory_phase"])
    put(raw, clock, b, 2000, 100, semantic=1, phase=architecture["memory_phase"]); learner += [a, b]
    for index, offset in enumerate(PA):
        q = add(a, tf(offset), 1, n); put(raw, clock, q, 3000 + index, 0, semantic=4, phase=31 + index); learner.append(q)
    for index, offset in enumerate(PB):
        q = add(b, tf(offset), 1, n); put(raw, clock, q, 4000 + index, 0, semantic=4, phase=41 + index); learner.append(q)
    environment = []
    if condition in ("learn_a", "learn_b", "broken_generator"):
        target = a if condition in ("learn_a", "broken_generator") else b
        event = add(target, tf((0, -1, 0)), 1, n); route = tf((0, 0, 1))
        generator = add(event, route, -architecture["consequence_distance"], n)
        for index, direction in enumerate((tf((1, 0, 1)), tf((-1, 0, 1)))):
            if condition == "broken_generator" and index == 0: continue
            q = add(generator, direction, -1, n)
            put(raw, clock, q, 5001 + index, 3, direction, 1, 0); environment.append(q)
    qp = add(c, p, 1, n); source_distances = architecture["bridge_source_distances"]
    specs = ((qp, tf(S1), 11), (qp, tf(S2), 13), (c, tf(N1), 17), (c, tf(N2), 19))
    sources = []
    for index, ((anchor, direction, sreg), distance) in enumerate(zip(specs, source_distances)):
        q = add(anchor, direction, -distance, n); put(raw, clock, q, 7000 + index, sreg, direction, 4, 100 + index)
        sources.append((q, int(raw[q]))); learner.append(q)
    receiver = add(c, tf(tuple(architecture["receiver_relative_offset"])), 1, n)
    q_receiver, qp_receiver, receiver_positions = put_transducer(raw, clock, receiver, n, tf, 9000)
    learner += receiver_positions
    learner_state = [{"q": list(q), "raw": int(raw[q]), "clock": int(clock[q])} for q in sorted(set(learner))]
    return NativeWorld(kernel, raw, clock), {"a": a, "b": b, "q": q_receiver, "qp": qp_receiver,
        "sources": sources, "learner_t0_hash": canonical_hash(learner_state),
        "environment_positions": [list(q) for q in environment]}


def run_case(kernel, frame, condition, architecture):
    try: world, meta = build(kernel, frame, condition, architecture)
    except RuntimeError as exc: return {"condition": condition, "valid": False, "reason": str(exc)}
    pairs = []; transitions = []; previous = 0; first_write = None
    for tick in range(1, architecture["horizon"] + 1):
        world.tick(); a, b = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        value = None if a is None or b is None else int(a["sreg"] - b["sreg"])
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        pairs.append((int(world.raw[meta["q"]]), int(world.raw[meta["qp"]]))); previous = value
    terminal = pairs[-1]; start = architecture["stable_window_start"] - 1
    return {"condition": condition, "valid": True, "learner_t0_hash": meta["learner_t0_hash"],
            "environment_positions": meta["environment_positions"], "first_write_tick": first_write,
            "master_transitions": transitions, "terminal_delta": previous,
            "terminal_pair_raw": list(terminal), "pair_sequence": pairs,
            "terminal_window_constant": all(value == terminal for value in pairs[start:]),
            "persistent_sources_raw_fixed": all(int(world.raw[q]) == initial for q, initial in meta["sources"]),
            "python_interventions_after_t0": 0}


def frame_json(frame): return {"permutation": list(frame[0]), "signs": list(frame[1])}


def main():
    lock = json.loads(LOCK.read_text(encoding="utf-8")); architecture = lock["architecture"]
    identity = ((0, 1, 2), (1, 1, 1)); salt = lock["fresh_generation"]["salt"]
    frames = [(p, s) for p in itertools.permutations((0, 1, 2))
              for s in itertools.product((-1, 1), repeat=3) if (p, s) != identity]
    frames.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True,
                       separators=(",", ":")) + salt).encode()).hexdigest())
    frames = frames[:lock["fresh_generation"]["fresh_frames"]]
    challenge = seal({"schema": "dee.v27.ing03.rw3_reactivation.c15_challenges.v1",
                      "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK),
                      "algorithm": lock["fresh_generation"]["algorithm"], "salt": salt,
                      "challenges": [{"id": f"RC15-{index:02d}", "frame": frame_json(frame),
                                      "conditions": lock["conditions"]}
                                     for index, frame in enumerate(frames, 1)],
                      "outcomes_absent_at_generation": True})
    challenge_path = ROOT / "HOLDOUT/ING03_REACT_C15_CHALLENGES.json"; write_json(challenge_path, challenge)
    kernel, runtime = load_kernel(1); rows = []
    for index, frame in enumerate(frames, 1):
        for condition in lock["conditions"]:
            row = run_case(kernel, frame, condition, architecture)
            row.update({"challenge_id": f"RC15-{index:02d}", "frame": frame_json(frame)}); rows.append(row)
    groups = []
    for index, frame in enumerate(frames, 1):
        cid = f"RC15-{index:02d}"; subset = [row for row in rows if row["challenge_id"] == cid]
        by = {row["condition"]: row for row in subset}; hashes = {row.get("learner_t0_hash") for row in subset}
        first_difference = next((tick for tick, (pa, pb) in enumerate(zip(by["learn_a"].get("pair_sequence", []),
                                                                          by["learn_b"].get("pair_sequence", [])), 1)
                                 if pa != pb), None)
        pairs = {name: tuple(by[name].get("terminal_pair_raw", [])) for name in lock["conditions"]}
        passed = (len(subset) == 4 and all(row.get("valid") and row.get("terminal_window_constant") and
                  row.get("persistent_sources_raw_fixed") and row.get("python_interventions_after_t0") == 0 for row in subset)
                  and len(hashes) == 1 and by["learn_a"]["terminal_delta"] == 1 and by["learn_b"]["terminal_delta"] == -1
                  and by["sham"]["terminal_delta"] == 0 and by["broken_generator"]["terminal_delta"] == 0
                  and by["learn_a"]["first_write_tick"] == 21 and by["learn_b"]["first_write_tick"] == 21
                  and first_difference == 38 and len({pairs["learn_a"], pairs["learn_b"], pairs["sham"]}) == 3
                  and pairs["broken_generator"] == pairs["sham"])
        groups.append({"challenge_id": cid, "frame": frame_json(frame),
                       "learner_hashes_identical": len(hashes) == 1,
                       "first_remote_a_b_difference_tick": first_difference,
                       "terminal_pairs": {key: list(value) for key, value in pairs.items()}, "passed": passed})
    for row in rows: row.pop("pair_sequence", None)
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.c15_holdout.v1",
                   "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK),
                   "challenge_content_sha256": challenge["content_sha256"],
                   "rows": rows, "groups": groups,
                   "summary": {"fresh_frames": len(groups), "fresh_worlds": len(rows),
                               "passed_groups": sum(group["passed"] for group in groups),
                               "all_passed": all(group["passed"] for group in groups)},
                   "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime})
    output = ROOT / "HOLDOUT/ING03_REACT_C15_LATE_DEVELOPMENT_HOLDOUT.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
