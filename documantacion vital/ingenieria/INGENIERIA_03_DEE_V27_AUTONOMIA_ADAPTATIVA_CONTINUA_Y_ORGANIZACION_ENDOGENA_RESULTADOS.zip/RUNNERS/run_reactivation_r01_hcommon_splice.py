#!/usr/bin/env python3
"""Diagnostic search for a common causal precursor and later A/B branch."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from itertools import product
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2
from run_dd_r01_remote_dependency_map import delayed_source_positions, pair


OFFSET = (-6, 7, 8)
HORIZON = 384
CANDIDATE_TICKS = (8, 16, 24, 28, 29, 30, 32, 38, 64)


def clone_world(world):
    clone = NativeWorld(world.kernel, world.raw_a, world.clock_a, world.threads)
    clone.raw_b = world.raw_b.copy(); clone.clock_b = world.clock_b.copy()
    return clone


def copy_site(destination, source, q):
    destination.raw_a[q] = source.raw_a[q]; destination.raw_b[q] = source.raw_b[q]
    destination.clock_a[q] = source.clock_a[q]; destination.clock_b[q] = source.clock_b[q]


def token(world, q):
    return (int(world.raw[q]), int(world.clock_a[q]))


def region(center, n, radius):
    return {add(center, d, 1, n) for d in product(range(-radius, radius + 1), repeat=3)}


def causal_domain(meta, metas):
    n = meta["n"]; positions = set(region(meta["q_receiver"], n, 3))
    positions |= region(meta["c"], n, 2)
    sources = delayed_source_positions(meta); directions = (S1, S2, N1, N2)
    for source, direction in zip(sources, directions):
        positions |= {add(source, direction, step, n) for step in range(25)}
    for other in metas.values():
        for q in other.get("generator_positions", []): positions |= region(q, n, 2)
    return sorted(positions)


def digest_sites(world, positions):
    h = hashlib.sha256()
    for q in positions:
        h.update(int(world.raw[q]).to_bytes(8, "little")); h.update(int(world.clock_a[q]).to_bytes(8, "little"))
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate-ticks", default=",".join(str(tick) for tick in CANDIDATE_TICKS))
    parser.add_argument("--output-name", default="ING03_REACT_R01_HCOMMON_SPLICE.json")
    args = parser.parse_args()
    candidate_ticks = tuple(sorted({int(value) for value in args.candidate_ticks.split(",") if value.strip()}))
    if not candidate_ticks or min(candidate_ticks) < 1 or max(candidate_ticks) >= HORIZON:
        raise ValueError("candidate ticks must lie inside the simulated horizon")
    kernel, runtime = load_kernel(1); r10.OFFSET = OFFSET
    worlds = {}; metas = {}
    for label, target in (("a", "a"), ("b", "b"), ("sham", None)):
        worlds[label], metas[label] = r10.build(kernel, target)
    meta = metas["sham"]; remote = sorted(region(meta["q_receiver"], meta["n"], 3))
    domain = causal_domain(meta, metas)
    branches = []
    alignment = []
    for tick in range(1, HORIZON + 1):
        for world in worlds.values(): world.tick()
        if tick in candidate_ticks:
            common = [q for q in domain if token(worlds["a"], q) == token(worlds["b"], q)]
            divergent = [q for q in domain if token(worlds["a"], q) != token(worlds["b"], q)]
            remote_common = [q for q in remote if token(worlds["a"], q) == token(worlds["b"], q)]
            row = {"tick": tick, "domain_count": len(domain), "common_count": len(common),
                   "divergent_count": len(divergent), "common_fraction": len(common) / len(domain),
                   "remote_count": len(remote), "remote_common_count": len(remote_common),
                   "remote_raw_clock_exact_equivalence": len(remote_common) == len(remote),
                   "a_remote_sha256": digest_sites(worlds["a"], remote),
                   "b_remote_sha256": digest_sites(worlds["b"], remote)}
            alignment.append(row)
            for target in ("a", "b", "sham"):
                branch = clone_world(worlds["sham"])
                for q in common: copy_site(branch, worlds["a"], q)
                if target in ("a", "b"):
                    for q in divergent: copy_site(branch, worlds[target], q)
                branches.append({"candidate_tick": tick, "target": target, "world": branch,
                                 "common_count": len(common), "divergent_count": len(divergent),
                                 "remote_exact": row["remote_raw_clock_exact_equivalence"], "samples": []})
        for branch in branches:
            if branch["candidate_tick"] < tick:
                branch["world"].tick()
                if tick in (30, 38, 64, 96, 128, 182, 201, 256, 320, 384):
                    branch["samples"].append({"tick": tick, "pair": pair(branch["world"], meta)})
    canonical = {label: pair(world, metas[label]) for label, world in worlds.items()}
    rows = []
    for branch in branches:
        terminal = pair(branch["world"], meta)
        rows.append({"candidate_tick": branch["candidate_tick"], "target": branch["target"],
                     "common_count": branch["common_count"], "divergent_count": branch["divergent_count"],
                     "remote_exact": branch["remote_exact"], "terminal_pair": terminal,
                     "canonical_pair": canonical[branch["target"]],
                     "terminal_matches_canonical": terminal == canonical[branch["target"]],
                     "samples": branch["samples"], "python_interventions_after_t0": 1,
                     "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    by_tick = []
    for tick in candidate_ticks:
        subset = {row["target"]: row for row in rows if row["candidate_tick"] == tick}
        by_tick.append({"tick": tick,
                        "remote_exact": subset["a"]["remote_exact"],
                        "a_branch_canonical": subset["a"]["terminal_matches_canonical"],
                        "b_branch_canonical": subset["b"]["terminal_matches_canonical"],
                        "sham_branch_neutral": subset["sham"]["terminal_matches_canonical"],
                        "diagnostic_hcommon_sufficient": subset["a"]["remote_exact"] and
                            all(subset[target]["terminal_matches_canonical"] for target in ("a", "b", "sham"))})
    candidates = [row["tick"] for row in by_tick if row["diagnostic_hcommon_sufficient"]]
    latest_exact = max((row["tick"] for row in alignment if row["remote_raw_clock_exact_equivalence"]), default=None)
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.hcommon_splice.v1",
      "question": "Does a raw-equivalent remote precursor plus the contemporaneous causal A/B branch suffice for canonical completion?",
      "cost_estimate": {"intact_worlds": 3, "diagnostic_branches": len(branches), "horizon": HORIZON,
                        "information_gain": "high", "storage": "checkpoint telemetry"},
      "design": {"receiver_offset": list(OFFSET), "candidate_ticks": list(candidate_ticks),
                 "causal_domain_count": len(domain), "remote_radius": 3,
                 "quotient": "raw+clock equality inside receiver r3; common-versus-divergent factorization on instrumented causal domain",
                 "clone_role": "diagnostic sufficiency only"},
      "alignment": alignment, "canonical_terminal_pairs": canonical, "splice_rows": rows, "by_tick": by_tick,
      "summary": {"latest_exact_remote_equivalence_tick_tested": latest_exact,
                  "diagnostic_hcommon_candidate_ticks": candidates,
                  "latest_diagnostic_hcommon_candidate_tick": max(candidates) if candidates else None,
                  "native_hcommon_precursor_demonstrated": False},
      "claim_guard": "Every splice is a Python diagnostic. Even a sufficient H_common must later be developed natively from t0 before contributing to RW3.",
      "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION" / args.output_name; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "by_tick": by_tick,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
