#!/usr/bin/env python3
"""Factor bridge-source identity from required activity time."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_dd_r01_remote_dependency_map import clear, delayed_source_positions, pair


OFFSET = (-6, 7, 8)
HORIZON = 384
CUTOFF_TICKS = (16, 32, 64, 96, 128, 160, 182)
SOURCE2_ONSETS = (0, 4, 8, 12, 16, 20, 24, 32)
PARTIAL = ROOT / "DISCOVERY/REACT_R02_CHECKPOINTS"


def restore_source(world, reference, q):
    world.raw_a[q] = reference.raw_a[q]; world.raw_b[q] = reference.raw_b[q]
    world.clock_a[q] = reference.clock_a[q]; world.clock_b[q] = reference.clock_b[q]


def cutoff_row(kernel, target, source_index, cutoff):
    world, meta = r10.build(kernel, target); reference, rmeta = r10.build(kernel, target)
    q = delayed_source_positions(meta)[source_index]; samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); reference.tick()
        if tick == cutoff: clear(world, q)
        if tick in (16, 24, 30, 38, 64, 96, 128, 160, 182, 201, 256, 320, 384):
            samples.append({"tick": tick, "pair": pair(world, meta)})
    terminal = pair(world, meta); canonical = pair(reference, rmeta)
    return {"target": target, "source_index": source_index, "cutoff_tick": cutoff,
            "terminal_pair": terminal, "canonical_pair": canonical,
            "terminal_matches_canonical": terminal == canonical, "samples": samples,
            "python_interventions_after_t0": 1, "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def onset_row(kernel, target, onset):
    world, meta = r10.build(kernel, target); reference, rmeta = r10.build(kernel, target)
    q = delayed_source_positions(meta)[2]
    if onset > 0: clear(world, q)
    for tick in range(1, HORIZON + 1):
        world.tick(); reference.tick()
        if tick == onset and onset > 0: restore_source(world, reference, q)
    terminal = pair(world, meta); canonical = pair(reference, rmeta)
    return {"target": target, "source_index": 2, "onset_tick": onset,
            "terminal_pair": terminal, "canonical_pair": canonical,
            "terminal_matches_canonical": terminal == canonical,
            "python_interventions_after_t0": int(onset > 0), "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def save(name, payload, runtime):
    value = seal({"schema": f"dee.v27.ing03.rw3_reactivation.source_time_checkpoint.{name}.v1",
                  "phase": name, "payload": payload, "runtime": runtime})
    write_json(PARTIAL / f"{name}.json", value)
    print(json.dumps({"checkpoint": str(PARTIAL / f'{name}.json'), "content_sha256": value["content_sha256"]}, indent=2))


def load(name):
    return json.loads((PARTIAL / f"{name}.json").read_text(encoding="utf-8"))["payload"]


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--phase", choices=("source0", "source1", "source2", "source3", "onset", "assemble"), required=True)
    args = parser.parse_args(); kernel, runtime = load_kernel(1); r10.OFFSET = OFFSET
    if args.phase.startswith("source"):
        source_index = int(args.phase[-1])
        rows = [cutoff_row(kernel, target, source_index, cutoff) for target in ("a", "b") for cutoff in CUTOFF_TICKS]
        save(args.phase, rows, runtime); return
    if args.phase == "onset":
        rows = [onset_row(kernel, target, onset) for target in ("a", "b") for onset in SOURCE2_ONSETS]
        save("onset", rows, runtime); return
    source_rows = [row for index in range(4) for row in load(f"source{index}")]
    onset_rows = load("onset")
    earliest_sufficient_cutoff = {}
    for target in ("a", "b"):
        earliest_sufficient_cutoff[target] = {}
        for index in range(4):
            candidates = [row["cutoff_tick"] for row in source_rows if row["target"] == target and
                          row["source_index"] == index and row["terminal_matches_canonical"]]
            earliest_sufficient_cutoff[target][str(index)] = min(candidates) if candidates else None
    latest_source2_onset = {}
    for target in ("a", "b"):
        candidates = [row["onset_tick"] for row in onset_rows if row["target"] == target and row["terminal_matches_canonical"]]
        latest_source2_onset[target] = max(candidates) if candidates else None
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.source_time_factorization.v1",
      "question": "For each bridge source, how long must activity persist, and how late may source2 begin, while preserving canonical A/B?",
      "cost_estimate": {"cutoff_worlds": len(source_rows), "onset_worlds": len(onset_rows), "horizon": HORIZON,
                        "information_gain": "high", "storage": "checkpoint telemetry"},
      "design": {"receiver_offset": list(OFFSET), "cutoff_ticks": list(CUTOFF_TICKS),
                 "source2_onsets": list(SOURCE2_ONSETS), "all_manipulations": "DIAGNOSTIC_INTERVENTION"},
      "cutoff_rows": source_rows, "source2_onset_rows": onset_rows,
      "summary": {"earliest_tested_sufficient_cutoff_tick": earliest_sufficient_cutoff,
                  "latest_tested_canonical_source2_onset": latest_source2_onset,
                  "continuous_vs_intermittent_fully_resolved": False,
                  "globally_minimal_program_demonstrated": False,
                  "native_program_generator_demonstrated": False},
      "claim_guard": "Host source cutoffs/onsets diagnose sufficiency only; they are not a native formation program.", "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R02_SOURCE_TIME_FACTORIZATION.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
