#!/usr/bin/env python3
"""Map whether expressive freezing propagates into spatially separate learner nodes."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
from run_nature_n04_dynamic_temporal_expression import PA, PB
from run_dd_r01_remote_dependency_map import pair


OFFSET = (-6, 7, 8)
PROBE_TICK = 184
HORIZON = 400
SPARE_OFFSETS = ((0, 6, 0), (0, 10, 0), (0, 14, 0), (6, 0, 0), (10, 0, 0),
                 (0, 0, 6), (0, 0, 10), (6, 6, 0), (8, 8, 0))


def set_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def put(world, q, raw, clock):
    if int(world.raw[q]): raise RuntimeError(f"overlap {q}")
    set_both(world, q, raw, clock)


def add_learner(world, meta, center, node_id):
    n = meta["n"]; a = add(center, (-1, 0, 0), 1, n); b = add(center, (1, 0, 0), 1, n)
    put(world, a, int(pack(20000 + node_id * 100, 100, semantic=1)), 252)
    put(world, b, int(pack(20001 + node_id * 100, 100, semantic=1)), 252)
    for index, rel in enumerate(PA):
        put(world, add(a, rel, 1, n), int(pack(20100 + node_id * 100 + index, 0, semantic=4)), 31 + index)
    for index, rel in enumerate(PB):
        put(world, add(b, rel, 1, n), int(pack(20200 + node_id * 100 + index, 0, semantic=4)), 41 + index)
    event = add(b, (0, -1, 0), 1, n); writer_q = add(event, (0, 0, 1), -3, n)
    return {"id": node_id, "center": center, "a": a, "b": b, "writer_q": writer_q,
            "writer_raw": int(pack(21000 + node_id, 0, (0, 0, 1), 4))}


def delta(world, node):
    a, b = read(world.raw, node["a"]), read(world.raw, node["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def install_probe(world, node):
    q = node["writer_q"]; replaced = int(world.raw[q]); set_both(world, q, node["writer_raw"], PROBE_TICK)
    return {"type": "DIAGNOSTIC_INTERVENTION", "q": list(q), "raw": node["writer_raw"], "replaced_raw": replaced}


def run(kernel, spare_offsets, expression):
    r10.OFFSET = OFFSET
    try:
        world, meta = r10.build(kernel, "a", expression=expression)
        nodes = [add_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), index + 1)
                 for index, offset in enumerate(spare_offsets)]
    except RuntimeError as exc:
        return {"spare_offsets": [list(x) for x in spare_offsets], "expression": expression,
                "valid": False, "reason": str(exc)}
    previous = {node["id"]: 0 for node in nodes}; transitions = {node["id"]: [] for node in nodes}
    probes = []; samples = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            probes = [install_probe(world, node) for node in nodes]
        for node in nodes:
            value = delta(world, node)
            if value != previous[node["id"]]:
                transitions[node["id"]].append({"tick": tick, "before": previous[node["id"]], "after": value})
            previous[node["id"]] = value
        if tick in (9, 24, 64, 128, 183, 184, 185, 256, 334, 400):
            samples.append({"tick": tick, "spare_deltas": {str(node["id"]): delta(world, node) for node in nodes},
                            "primary_remote_pair": pair(world, meta)})
    post = {str(node["id"]): [event for event in transitions[node["id"]] if event["tick"] > PROBE_TICK] for node in nodes}
    return {"spare_offsets": [list(x) for x in spare_offsets], "expression": expression, "valid": True,
            "node_count": len(nodes), "diagnostic_probes": probes,
            "transitions": {str(k): v for k, v in transitions.items()}, "post_probe_transitions": post,
            "spare_write_compatible": {key: bool(value) for key, value in post.items()},
            "primary_remote_pair_terminal": pair(world, meta), "samples": samples,
            "python_interventions_after_t0": len(probes),
            "claim_guard": "Spare-node writer insertion is diagnostic; no native node selector or recurrent learning is claimed."}


def main():
    kernel, runtime = load_kernel(1)
    single_rows = [run(kernel, (offset,), expression) for offset in SPARE_OFFSETS for expression in (True, False)]
    array_offsets = ((0, 10, 0), (0, -10, 0))
    array_rows = [run(kernel, array_offsets, expression) for expression in (True, False)]
    valid = [row for row in single_rows if row.get("valid")]
    map_rows = []
    for offset in SPARE_OFFSETS:
        treatment = next((row for row in valid if row["expression"] and row["spare_offsets"] == [list(offset)]), None)
        control = next((row for row in valid if not row["expression"] and row["spare_offsets"] == [list(offset)]), None)
        map_rows.append({"offset": list(offset), "valid_treatment": treatment is not None,
                         "valid_control": control is not None,
                         "treatment_writable": None if treatment is None else treatment["spare_write_compatible"]["1"],
                         "control_writable": None if control is None else control["spare_write_compatible"]["1"]})
    coexist = [row["offset"] for row in map_rows if row["treatment_writable"] and row["control_writable"]]
    array_treatment = next((row for row in array_rows if row.get("valid") and row["expression"]), None)
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.distributed_plasticity.v1",
      "question": "Does local expressive freezing propagate to separate relational learner nodes, or can writable reserves coexist with remote function?",
      "cost_estimate": {"single_node_worlds": len(single_rows), "array_worlds": len(array_rows),
                        "ticks_per_world": HORIZON, "information_gain": "high"},
      "design": {"primary_remote_offset": list(OFFSET), "probe_tick": PROBE_TICK,
                 "spare_offsets": [list(x) for x in SPARE_OFFSETS], "array_offsets": [list(x) for x in array_offsets]},
      "single_rows": single_rows, "freezing_radius_map": map_rows, "array_rows": array_rows,
      "summary": {"valid_single_worlds": len(valid), "coexisting_writable_spare_offsets": coexist,
                  "two_spare_array_valid": array_treatment is not None,
                  "two_spare_array_all_writable": bool(array_treatment) and all(array_treatment["spare_write_compatible"].values()),
                  "native_node_selection_demonstrated": False,
                  "bounded_rotation_demonstrated": False, "rw3_demonstrated": False},
      "claim_guard": "A positive coexistence result establishes distributed plastic reserve only. Native routing, delegation, recovery and reuse remain separate requirements.",
      "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R03_DISTRIBUTED_PLASTICITY.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "freezing_radius_map": map_rows,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
