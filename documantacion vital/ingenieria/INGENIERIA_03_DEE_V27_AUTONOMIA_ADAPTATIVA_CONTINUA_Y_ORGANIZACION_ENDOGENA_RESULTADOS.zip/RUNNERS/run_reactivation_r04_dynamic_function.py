#!/usr/bin/env python3
"""Configured dynamic-function switchability and constituent-turnover test."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, load_kernel, seal, unpack_scalar, write_json
from run_landscape_l03_two_organ_coupling_search import build
from run_landscape_l04_coupling_mechanism_controls import periods


OFFSET = (-3, 4, 5)
HORIZON = 1536
CUTS = (512, 1024)
RESTORES = (768, 1280)
NECESSARY_SOURCES = (0, 1, 3)


def set_site(destination, source, q):
    destination.raw_a[q] = source.raw_a[q]; destination.raw_b[q] = source.raw_b[q]
    destination.clock_a[q] = source.clock_a[q]; destination.clock_b[q] = source.clock_b[q]


def clear(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def digest(sequence):
    h = hashlib.sha256()
    for pair_value in sequence:
        for raw in pair_value: h.update(int(raw).to_bytes(8, "little"))
    return h.hexdigest()


def run(kernel, mode):
    a_mode = "absent" if mode == "free" else "delta_-8"
    world, meta = build(kernel, OFFSET, a_mode); reference = None; rmeta = None
    if mode == "switch_twice": reference, rmeta = build(kernel, OFFSET, "delta_-8")
    sources = [] if meta["organ_a"] is None else [item[0] for item in meta["organ_a"]["sources"]]
    sequence = []; interventions = []; unique_states = set(); occupancy_switches = 0; previous_occupancy = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if reference is not None: reference.tick()
        if mode in ("cut_once", "switch_twice") and tick in CUTS:
            for index in NECESSARY_SOURCES:
                q = sources[index]; interventions.append({"tick": tick, "op": "cut", "source_index": index, "q": list(q)}); clear(world, q)
        if mode == "switch_twice" and tick in RESTORES:
            for index in NECESSARY_SOURCES:
                q = sources[index]; set_site(world, reference, q)
                interventions.append({"tick": tick, "op": "restore_from_intact_reference", "source_index": index, "q": list(q)})
        pair_value = (int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]])); sequence.append(pair_value)
        occupancy = tuple(int(bool(raw)) for raw in pair_value)
        if previous_occupancy is not None and occupancy != previous_occupancy: occupancy_switches += 1
        previous_occupancy = occupancy
        for raw in pair_value:
            if raw: unique_states.add(unpack_scalar(raw)["state"])
    windows = []
    for start in range(1, HORIZON + 1, 256):
        end = start + 255; seq = sequence[start - 1:end]
        windows.append({"start": start, "end": end, "periods": periods(seq), "raw_sha256": digest(seq),
                        "unique_raw_count": len({raw for pair_value in seq for raw in pair_value if raw}),
                        "occupancy_changes": sum(tuple(int(bool(x)) for x in seq[i]) != tuple(int(bool(x)) for x in seq[i-1]) for i in range(1, len(seq)))})
    return {"mode": mode, "windows": windows, "interventions": interventions,
            "global_unique_receiver_state_ids": len(unique_states), "global_occupancy_switches": occupancy_switches,
            "python_interventions_after_t0": len(interventions),
            "intervention_class": "NONE" if not interventions else "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, mode) for mode in ("free", "coupled", "cut_once", "switch_twice")]
    by = {row["mode"]: row for row in rows}
    switch_periods = [window["periods"]["raw_pair"] for window in by["switch_twice"]["windows"]]
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.dynamic_function.v1",
      "question": "Can a bounded dynamic receiver retain function through constituent turnover and switch repeatedly between configured P2/P6 regimes?",
      "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
      "design": {"offset": list(OFFSET), "coupled_mode": "delta_-8", "cut_sources": list(NECESSARY_SOURCES),
                 "cut_ticks": list(CUTS), "restore_ticks": list(RESTORES)},
      "rows": rows,
      "summary": {"free_terminal_period": by["free"]["windows"][-1]["periods"]["raw_pair"],
                  "coupled_terminal_period": by["coupled"]["windows"][-1]["periods"]["raw_pair"],
                  "switch_twice_window_periods": switch_periods,
                  "configured_repeated_dynamic_switching": switch_periods == [6, 6, 2, 6, 2, 6],
                  "organizational_turnover_observed": by["coupled"]["global_occupancy_switches"] > 0 and by["coupled"]["global_unique_receiver_state_ids"] > 2,
                  "learned_dynamic_selection_demonstrated": False,
                  "native_dynamic_switching_demonstrated": False},
      "claim_guard": "P2/P6 are DEE-native regimes, but the cut/restore switch schedule is diagnostic Python. It does not establish learned or autonomous switching.",
      "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R04_DYNAMIC_FUNCTION.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
