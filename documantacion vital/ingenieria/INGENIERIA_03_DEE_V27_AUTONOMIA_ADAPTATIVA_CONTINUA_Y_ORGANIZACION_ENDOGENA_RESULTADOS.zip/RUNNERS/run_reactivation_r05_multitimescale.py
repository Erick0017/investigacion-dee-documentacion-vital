#!/usr/bin/env python3
"""Native fast-learning versus slow persistent-formation comparison."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2, put_transducer
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start


OFFSET = (-6, 7, 8)
HORIZON = 512


def set_both(world, q, raw, clock):
    if int(world.raw[q]): raise RuntimeError(f"overlap {q}")
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def bridge_specs(meta, distance):
    c, n = meta["c"], meta["n"]; qp = add(c, P, 1, n)
    return ((add(qp, S1, -distance, n), S1, 11), (add(qp, S2, -distance, n), S2, 13),
            (add(c, N1, -distance, n), N1, 17), (add(c, N2, -distance, n), N2, 19))


def add_bridge(world, meta, mode):
    installed = []
    if mode == "none": return installed
    if mode == "persistent": plans = [(24, 4)]
    elif mode == "finite_single": plans = [(20, 1)]
    elif mode == "finite_train3": plans = [(12, 1), (16, 1), (20, 1)]
    else: raise ValueError(mode)
    state = 30000
    for plan_index, (distance, semantic) in enumerate(plans):
        for source_index, (q, direction, sreg) in enumerate(bridge_specs(meta, distance)):
            raw = int(pack(state, sreg, direction, semantic)); state += 1
            set_both(world, q, raw, 100 + plan_index * 10 + source_index)
            installed.append({"q": list(q), "raw": raw, "distance": distance,
                              "semantic": semantic, "direction": list(direction), "s_reg": sreg})
    return installed


def build(kernel, target, mode):
    world, meta = build_consequence(kernel, target, with_transducer=False, n=41,
                                    memory_phase=252, consequence_distance=6)
    bridge = add_bridge(world, meta, mode)
    q = add(meta["c"], OFFSET, 1, meta["n"]); put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"]), "bridge": bridge})
    return world, meta


def run(kernel, target, mode):
    try: world, meta = build(kernel, target, mode)
    except RuntimeError as exc: return {"target": target, "mode": mode, "valid": False, "reason": str(exc)}
    previous = 0; transitions = []; pairs = []; first_write = None
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta_value(world, meta); pairs.append(pair(world, meta))
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        previous = value
    start = constant_suffix_start([tuple(value) for value in pairs])
    return {"target": target, "mode": mode, "valid": True, "first_fast_write_tick": first_write,
            "master_transitions": transitions, "master_terminal_delta": previous,
            "remote_terminal_pair": pairs[-1], "remote_constant_suffix_start": start,
            "remote_constant_duration": HORIZON - start + 1,
            "bridge_count": len(meta["bridge"]),
            "persistent_sources_raw_fixed": all(int(world.raw[tuple(item["q"])]) == item["raw"] for item in meta["bridge"] if item["semantic"] == 4),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    modes = ("none", "finite_single", "finite_train3", "persistent")
    rows = [run(kernel, target, mode) for mode in modes for target in ("a", "b", None)]
    valid = [row for row in rows if row.get("valid")]
    by = {(row["mode"], str(row["target"])): row for row in valid}
    canonical = {target: by[("persistent", target)]["remote_terminal_pair"] for target in ("a", "b", "None") if ("persistent", target) in by}
    mode_summary = []
    for mode in modes:
        subset = {str(row["target"]): row for row in valid if row["mode"] == mode}
        mode_summary.append({"mode": mode, "valid": len(subset) == 3,
            "a_b_master_opposite": len(subset) == 3 and subset["a"]["master_terminal_delta"] * subset["b"]["master_terminal_delta"] < 0,
            "sham_master_zero": len(subset) == 3 and subset["None"]["master_terminal_delta"] == 0,
            "a_b_remote_distinct": len(subset) == 3 and subset["a"]["remote_terminal_pair"] != subset["b"]["remote_terminal_pair"],
            "matches_persistent_canonical": {target: subset[target]["remote_terminal_pair"] == canonical.get(target) for target in subset}})
    persistent_group = next(row for row in mode_summary if row["mode"] == "persistent")
    transient_groups = [row for row in mode_summary if row["mode"] in ("finite_single", "finite_train3")]
    result = seal({"schema": "dee.v27.ing03.rw3_reactivation.multitimescale.v1",
      "question": "Can a fast consequence-written master coexist with a slower remote that distinguishes finite from persistent causal support without host counting?",
      "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
      "design": {"remote_offset": list(OFFSET), "modes": list(modes),
                 "finite_single_distance": 20, "finite_train_distances": [12, 16, 20],
                 "persistent_distance": 24, "all_worlds_t0_complete": True},
      "rows": rows, "mode_summary": mode_summary,
      "summary": {"fast_native_learning_preserved_in_persistent_group": persistent_group["a_b_master_opposite"],
                  "persistent_group_canonical_a_b_distinct": persistent_group["a_b_remote_distinct"],
                  "finite_groups_match_persistent_for_both_states": {row["mode"]: all(row["matches_persistent_canonical"].get(target, False) for target in ("a", "b")) for row in transient_groups},
                  "native_persistence_filter_candidate": persistent_group["a_b_remote_distinct"] and any(not all(row["matches_persistent_canonical"].get(target, False) for target in ("a", "b")) for row in transient_groups),
                  "native_reversal_or_rw3_demonstrated": False},
      "claim_guard": "A persistence-filter candidate is a configured two-timescale primitive, not repeated learning, consolidation reversal, RW3 or autonomous event counting.",
      "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R05_MULTITIMESCALE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "mode_summary": mode_summary,
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
