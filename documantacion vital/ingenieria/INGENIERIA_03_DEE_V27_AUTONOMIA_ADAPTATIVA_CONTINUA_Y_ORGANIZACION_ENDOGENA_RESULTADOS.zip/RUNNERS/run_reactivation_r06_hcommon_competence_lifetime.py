#!/usr/bin/env python3
"""Diagnostic lifetime of the tick-8 common competent precursor."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r01_hcommon_splice as r01
from run_dd_r01_remote_dependency_map import pair


BRANCH_TICK = 8
BASE_HORIZON = 384
DELAYS = (0, 8, 16, 32, 64, 128)


def snapshot(world, positions):
    return {q: (int(world.raw_a[q]), int(world.raw_b[q]),
                int(world.clock_a[q]), int(world.clock_b[q])) for q in positions}


def apply_snapshot(world, values, delay, phase_shifted):
    for q, (raw_a, raw_b, clock_a, clock_b) in values.items():
        world.raw_a[q] = raw_a; world.raw_b[q] = raw_b
        world.clock_a[q] = (clock_a + delay) & 255 if phase_shifted else clock_a
        world.clock_b[q] = (clock_b + delay) & 255 if phase_shifted else clock_b


def run_branch(base, meta, program, delay, phase_shifted):
    world = r01.clone_world(base)
    for _ in range(delay):
        world.tick()
    apply_snapshot(world, program, delay, phase_shifted)
    samples = []
    for age in range(1, BASE_HORIZON - BRANCH_TICK + 1):
        world.tick()
        if age in (1, 8, 16, 30, 64, 128, 182, 256, BASE_HORIZON - BRANCH_TICK):
            samples.append({"post_commit_age": age, "pair": pair(world, meta)})
    return pair(world, meta), samples


def main():
    kernel, runtime = load_kernel(1); r10.OFFSET = r01.OFFSET
    worlds = {}; metas = {}
    for label, target in (("a", "a"), ("b", "b"), ("sham", None)):
        worlds[label], metas[label] = r10.build(kernel, target)
    meta = metas["sham"]; domain = r01.causal_domain(meta, metas)
    for _ in range(BRANCH_TICK):
        for world in worlds.values(): world.tick()
    common = [q for q in domain if r01.token(worlds["a"], q) == r01.token(worlds["b"], q)]
    divergent = [q for q in domain if r01.token(worlds["a"], q) != r01.token(worlds["b"], q)]
    precursor = r01.clone_world(worlds["sham"])
    for q in common: r01.copy_site(precursor, worlds["a"], q)
    programs = {target: snapshot(worlds[target], divergent) for target in ("a", "b")}
    intact = {label: r01.clone_world(world) for label, world in worlds.items()}
    for _ in range(BASE_HORIZON - BRANCH_TICK):
        for world in intact.values(): world.tick()
    canonical = {label: pair(world, metas[label]) for label, world in intact.items()}
    rows = []
    for phase_mode in ("absolute_clock", "phase_shifted"):
        for delay in DELAYS:
            for target in ("a", "b"):
                terminal, samples = run_branch(precursor, meta, programs[target], delay,
                                               phase_mode == "phase_shifted")
                rows.append({"target": target, "delay": delay, "phase_mode": phase_mode,
                             "terminal_pair": terminal, "canonical_pair": canonical[target],
                             "terminal_matches_canonical": terminal == canonical[target],
                             "samples": samples, "python_interventions_after_t0": 1,
                             "intervention_class": "DIAGNOSTIC_INTERVENTION"})
    sham_rows = []
    for delay in DELAYS:
        world = r01.clone_world(precursor)
        for _ in range(delay + BASE_HORIZON - BRANCH_TICK): world.tick()
        terminal = pair(world, meta)
        sham_rows.append({"delay": delay, "terminal_pair": terminal,
                          "canonical_sham_pair": canonical["sham"],
                          "remains_canonical_sham": terminal == canonical["sham"]})
    sufficient = {}
    for phase_mode in ("absolute_clock", "phase_shifted"):
        sufficient[phase_mode] = [delay for delay in DELAYS
            if all(next(row for row in rows if row["phase_mode"] == phase_mode and
                        row["delay"] == delay and row["target"] == target)["terminal_matches_canonical"]
                   for target in ("a", "b"))]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.hcommon_competence_lifetime.v1",
        "question": "How long can the diagnostic tick-8 common precursor evolve uncommitted and still accept the same A/B branch program?",
        "cost_estimate": {"branch_worlds": len(rows), "sham_worlds": len(sham_rows),
                          "post_commit_ticks": BASE_HORIZON - BRANCH_TICK,
                          "information_gain": "high"},
        "design": {"branch_tick": BRANCH_TICK, "delays": list(DELAYS),
                   "phase_controls": ["absolute_clock", "phase_shifted"],
                   "common_count": len(common), "divergent_count": len(divergent),
                   "program": "diagnostic copy of tick-8 target-specific divergent causal-domain sites"},
        "canonical_terminal_pairs": canonical, "rows": rows, "sham_rows": sham_rows,
        "summary": {"sufficient_delays_by_phase_mode": sufficient,
                    "maximum_competence_delay_tested": {key: max(values) if values else None
                                                         for key, values in sufficient.items()},
                    "native_competence_maintenance_demonstrated": False,
                    "native_late_commitment_demonstrated": False},
        "claim_guard": "All branch insertions are Python diagnostics. This tests causal sufficiency and lifetime, not native late commitment or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R06_HCOMMON_COMPETENCE_LIFETIME.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
