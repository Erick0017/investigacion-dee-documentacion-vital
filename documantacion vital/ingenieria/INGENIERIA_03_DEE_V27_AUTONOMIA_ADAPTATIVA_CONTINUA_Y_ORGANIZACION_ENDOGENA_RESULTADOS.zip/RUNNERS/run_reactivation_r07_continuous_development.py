#!/usr/bin/env python3
"""Measure constituent turnover beneath fixed and dynamic remote organization."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r01_hcommon_splice as r01
from run_landscape_l03_two_organ_coupling_search import build as build_dynamic
from run_landscape_l04_coupling_mechanism_controls import periods
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start


HORIZON = 1024
TRACK_START = 201


def identity_map(world, positions):
    result = {}
    for q in positions:
        item = read(world.raw, q)
        result[q] = None if item is None else int(item["state"])
    return result


def observe(world, positions, pair_sites):
    previous = None; replacements = arrivals = departures = identity_set_changes = 0
    unique_identities = set(); pair_sequence = []; occupied_counts = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick < TRACK_START: continue
        current = identity_map(world, positions)
        identities = {value for value in current.values() if value is not None}
        unique_identities |= identities
        occupied_counts.append(len(identities))
        if previous is not None:
            prior_identities = {value for value in previous.values() if value is not None}
            identity_set_changes += int(identities != prior_identities)
            for q in positions:
                before, after = previous[q], current[q]
                if before == after: continue
                if before is None and after is not None: arrivals += 1
                elif before is not None and after is None: departures += 1
                else: replacements += 1
        previous = current
        pair_sequence.append(tuple(int(world.raw[q]) for q in pair_sites))
    return {"track_start": TRACK_START, "track_end": HORIZON,
            "unique_constituent_state_ids": len(unique_identities),
            "identity_set_change_ticks": identity_set_changes,
            "site_identity_replacements": replacements,
            "site_arrivals": arrivals, "site_departures": departures,
            "occupied_identity_count_min": min(occupied_counts),
            "occupied_identity_count_max": max(occupied_counts),
            "pair_periods": periods(pair_sequence),
            "pair_constant_suffix_start_relative": constant_suffix_start(pair_sequence),
            "terminal_pair": list(pair_sequence[-1])}


def fixed_row(kernel, target):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, target)
    positions = sorted(r01.region(meta["q_receiver"], meta["n"], 3))
    metrics = observe(world, positions, (meta["q_receiver"], meta["qp_receiver"]))
    return {"family": "fixed_remote", "target": target, "region_radius": 3,
            "metrics": metrics, "python_interventions_after_t0": 0}


def dynamic_row(kernel, mode):
    world, meta = build_dynamic(kernel, (-3, 4, 5), mode)
    positions = sorted(r01.region(meta["q_b"], meta["n"], 2))
    metrics = observe(world, positions, (meta["q_b"], meta["qp_b"]))
    return {"family": "dynamic_remote", "mode": mode, "region_radius": 2,
            "metrics": metrics, "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = [fixed_row(kernel, target) for target in ("a", "b", None)]
    rows += [dynamic_row(kernel, mode) for mode in ("absent", "delta_-8")]
    fixed = [row for row in rows if row["family"] == "fixed_remote"]
    dynamic = [row for row in rows if row["family"] == "dynamic_remote"]
    useful_turnover = [row for row in rows if row["metrics"]["identity_set_change_ticks"] > 0 and
                       (row["metrics"]["pair_periods"]["raw_pair"] in (1, 2, 6) or
                        row["metrics"]["pair_constant_suffix_start_relative"] is not None)]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.continuous_development.v1",
        "question": "Does stable remote function or competence persist while constituent state identities turn over?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "tracked_voxels_fixed": 343, "tracked_voxels_dynamic": 125,
                          "information_gain": "medium-high"},
        "design": {"track_start": TRACK_START, "horizon": HORIZON,
                   "fixed_targets": ["a", "b", "sham"],
                   "dynamic_modes": ["free_P2", "coupled_P6"],
                   "identity_observable": "kernel state identifier at occupied sites"},
        "rows": rows,
        "summary": {"fixed_remote_identity_turnover": {str(row["target"]): row["metrics"]["identity_set_change_ticks"]
                                                         for row in fixed},
                    "dynamic_remote_identity_turnover": {row["mode"]: row["metrics"]["identity_set_change_ticks"]
                                                           for row in dynamic},
                    "function_with_constituent_turnover_rows": len(useful_turnover),
                    "continuous_competence_renewal_demonstrated": False,
                    "offline_remote_renewal_demonstrated": False},
        "claim_guard": "Motion or phase cycling of the same state identity is not constituent renewal. No row establishes restored uncommitted competence or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R07_CONTINUOUS_DEVELOPMENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
