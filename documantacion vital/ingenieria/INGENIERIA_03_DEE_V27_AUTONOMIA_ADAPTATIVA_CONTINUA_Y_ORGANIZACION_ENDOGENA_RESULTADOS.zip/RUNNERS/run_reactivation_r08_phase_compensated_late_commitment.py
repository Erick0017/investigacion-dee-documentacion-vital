#!/usr/bin/env python3
"""Test native late commitment with route-length-derived phase compensation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start


OFFSET = (-6, 7, 8)
HORIZON = 512
DISTANCES = (6, 10, 14, 18)


def predicted_phase(distance):
    return (252 - (distance - 6)) & 255


def build(kernel, target, distance, phase):
    world, meta = build_consequence(kernel, target, with_transducer=False, n=41,
                                    memory_phase=phase, consequence_distance=distance)
    add_delayed_sources(world, meta, 24)
    q = add(meta["c"], OFFSET, 1, meta["n"])
    put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"])})
    return world, meta


def run(kernel, target, distance, phase, phase_class):
    try:
        world, meta = build(kernel, target, distance, phase)
    except RuntimeError as exc:
        return {"target": target, "distance": distance, "memory_phase": phase,
                "phase_class": phase_class, "valid": False, "reason": str(exc)}
    previous = 0; transitions = []; first_write = None; pairs = []; samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta_value(world, meta); pairs.append(pair(world, meta))
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        if tick in (8, 9, 10, 12, 13, 16, 17, 20, 21, 24, 30, 38, 64, 128, 182, 256, 384, 512):
            samples.append({"tick": tick, "master_delta": value, "pair": pairs[-1]})
        previous = value
    start = constant_suffix_start([tuple(value) for value in pairs])
    return {"target": target, "distance": distance, "memory_phase": phase,
            "phase_class": phase_class, "valid": True, "first_native_write_tick": first_write,
            "master_transitions": transitions, "terminal_master_delta": previous,
            "terminal_pair": pairs[-1], "remote_constant_suffix_start": start,
            "remote_constant_duration": HORIZON - start + 1, "samples": samples,
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    phase_specs = []
    for distance in DISTANCES:
        predicted = predicted_phase(distance)
        for phase, label in ((252, "uncompensated_control"),
                             ((predicted - 1) & 255, "predicted_minus_1"),
                             (predicted, "route_compensated"),
                             ((predicted + 1) & 255, "predicted_plus_1")):
            if (distance, phase) not in {(d, p) for d, p, _ in phase_specs}:
                phase_specs.append((distance, phase, label))
    rows = [run(kernel, target, distance, phase, label)
            for distance, phase, label in phase_specs for target in ("a", "b", None)]
    groups = []
    for distance, phase, label in phase_specs:
        subset = {str(row["target"]): row for row in rows if row.get("valid") and
                  row["distance"] == distance and row["memory_phase"] == phase}
        valid = len(subset) == 3
        groups.append({"distance": distance, "memory_phase": phase, "phase_class": label,
                       "valid": valid,
                       "a_write_tick": subset.get("a", {}).get("first_native_write_tick"),
                       "b_write_tick": subset.get("b", {}).get("first_native_write_tick"),
                       "sham_write_tick": subset.get("None", {}).get("first_native_write_tick"),
                       "a_b_remote_distinct": valid and subset["a"]["terminal_pair"] != subset["b"]["terminal_pair"],
                       "a_b_master_opposite": valid and subset["a"]["terminal_master_delta"] * subset["b"]["terminal_master_delta"] < 0,
                       "sham_master_zero": valid and subset["None"]["terminal_master_delta"] == 0})
    candidates = [group for group in groups if group["valid"] and group["distance"] > 6 and
                  group["a_write_tick"] is not None and group["b_write_tick"] is not None and
                  group["a_b_master_opposite"] and group["sham_master_zero"] and group["a_b_remote_distinct"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.phase_compensated_late_commitment.v1",
        "question": "Can route-length-derived clock compensation preserve native A/B write and remote differentiation after the tick-9 competence boundary?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "information_gain": "high"},
        "design": {"distances": list(DISTANCES), "baseline_phase": 252,
                   "predicted_phase_law": "(252-(distance-6)) mod 256",
                   "phase_controls": ["uncompensated", "predicted-1", "predicted", "predicted+1"],
                   "remote_present_from_t0": True, "all_worlds_t0_complete": True},
        "rows": rows, "groups": groups,
        "summary": {"native_late_commitment_candidates": candidates,
                    "native_late_commitment_demonstrated": bool(candidates),
                    "rw3_demonstrated": False},
        "claim_guard": "A positive row is native late first commitment from t0, not recurrent learning, remote reuse, RW3, RW4, RW5 or L4.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R08_PHASE_COMPENSATED_LATE_COMMITMENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "groups": groups, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
