#!/usr/bin/env python3
"""Test bounded learner arrays with distinct relational frames."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
from run_nature_n04_dynamic_temporal_expression import PA, PB


PROBE_TICK = 184
HORIZON = 400


def transform(vector, frame):
    x, y, z = vector
    if frame == "x": return (x, y, z)
    if frame == "y": return (y, x, z)
    if frame == "z": return (z, y, x)
    raise ValueError(frame)


def add_rotated_learner(world, meta, center, node_id, frame):
    n = meta["n"]; axis = transform((1, 0, 0), frame)
    a = add(center, axis, -1, n); b = add(center, axis, 1, n)
    r03.put(world, a, int(pack(24000 + node_id * 100, 100, semantic=1)), 252)
    r03.put(world, b, int(pack(24001 + node_id * 100, 100, semantic=1)), 252)
    for index, rel in enumerate(PA):
        r03.put(world, add(a, transform(rel, frame), 1, n),
                int(pack(24100 + node_id * 100 + index, 0, semantic=4)), 31 + index)
    for index, rel in enumerate(PB):
        r03.put(world, add(b, transform(rel, frame), 1, n),
                int(pack(24200 + node_id * 100 + index, 0, semantic=4)), 41 + index)
    event = add(b, transform((0, -1, 0), frame), 1, n)
    route = transform((0, 0, 1), frame); writer_q = add(event, route, -3, n)
    return {"id": node_id, "frame": frame, "center": center, "a": a, "b": b,
            "writer_q": writer_q, "writer_raw": int(pack(25000 + node_id, 0, route, 4))}


def delta(world, node):
    a, b = read(world.raw, node["a"]), read(world.raw, node["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def run(kernel, specs, expression):
    r10.OFFSET = (-6, 7, 8)
    try:
        world, meta = r10.build(kernel, "a", expression=expression)
        nodes = [add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]),
                                     index + 1, frame)
                 for index, (offset, frame) in enumerate(specs)]
    except RuntimeError as exc:
        return {"specs": [{"offset": list(o), "frame": f} for o, f in specs],
                "expression": expression, "valid": False, "reason": str(exc)}
    previous = {node["id"]: 0 for node in nodes}; transitions = {node["id"]: [] for node in nodes}
    probes = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            for node in nodes:
                replaced = int(world.raw[node["writer_q"]])
                r03.set_both(world, node["writer_q"], node["writer_raw"], PROBE_TICK)
                probes.append({"node": node["id"], "frame": node["frame"],
                               "q": list(node["writer_q"]), "replaced_raw": replaced})
        for node in nodes:
            value = delta(world, node)
            if value != previous[node["id"]]:
                transitions[node["id"]].append({"tick": tick, "before": previous[node["id"]], "after": value})
            previous[node["id"]] = value
    post = {str(node["id"]): [event for event in transitions[node["id"]] if event["tick"] > PROBE_TICK]
            for node in nodes}
    return {"specs": [{"offset": list(o), "frame": f} for o, f in specs],
            "expression": expression, "valid": True, "diagnostic_probes": probes,
            "transitions": {str(key): value for key, value in transitions.items()},
            "post_probe_transitions": post,
            "write_compatible": {key: bool(value) for key, value in post.items()},
            "python_interventions_after_t0": len(probes),
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    designs = {
        "two_frame_xy": (((0, 10, 0), "x"), ((10, 0, 0), "y")),
        "three_frame_xyz": (((0, 10, 0), "x"), ((10, 0, 0), "y"), ((0, 0, 10), "z")),
        "three_frame_separated": (((0, 14, 0), "x"), ((14, 0, 0), "y"), ((0, 0, 14), "z")),
    }
    rows = []
    for name, specs in designs.items():
        for expression in (True, False):
            row = run(kernel, specs, expression); row["design_name"] = name; rows.append(row)
    comparisons = []
    for name in designs:
        treatment = next(row for row in rows if row["design_name"] == name and row["expression"])
        control = next(row for row in rows if row["design_name"] == name and not row["expression"])
        comparisons.append({"design_name": name,
                            "treatment_valid": treatment.get("valid", False),
                            "control_valid": control.get("valid", False),
                            "treatment_write_compatible": treatment.get("write_compatible"),
                            "control_write_compatible": control.get("write_compatible"),
                            "all_treatment_nodes_writable": treatment.get("valid", False) and all(treatment["write_compatible"].values()),
                            "all_control_nodes_writable": control.get("valid", False) and all(control["write_compatible"].values())})
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.distributed_rotated_array.v1",
        "question": "Can bounded learner arrays in distinct relational frames retain writable nodes after primary expression?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "information_gain": "high"},
        "design": {"probe_tick": PROBE_TICK, "arrays": {name: [{"offset": list(o), "frame": f}
                                                                 for o, f in specs]
                                                              for name, specs in designs.items()}},
        "rows": rows, "comparisons": comparisons,
        "summary": {"valid_treatment_arrays": sum(item["treatment_valid"] for item in comparisons),
                    "arrays_with_all_writable_reserves": [item["design_name"] for item in comparisons
                                                          if item["all_treatment_nodes_writable"]],
                    "native_node_selection_demonstrated": False,
                    "bounded_learner_rotation_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "Writer insertion remains diagnostic. Frame diversity tests a distinct distributed organization but does not supply native selection or reuse.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R09_DISTRIBUTED_ROTATED_ARRAY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "comparisons": comparisons, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
