#!/usr/bin/env python3
"""Late native persistent write into a pre-existing dynamic receiver system."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import build
from run_landscape_l04_coupling_mechanism_controls import periods


OFFSET = (-3, 4, 5)
HORIZON = 1024
WINDOW = 128


def install_persistent_writer(world, meta, target):
    if target is None: return None
    center = meta["a"] if target == "a" else meta["b"]
    event = add(center, (0, -1, 0), 1, meta["n"]); direction = (0, 0, 1)
    q = add(event, direction, -3, meta["n"])
    if int(world.raw[q]): raise RuntimeError(f"overlap {q}")
    raw = int(pack(27000 if target == "a" else 28000, 0, direction, 4))
    world.raw_a[q] = raw; world.raw_b[q] = raw
    world.clock_a[q] = 0; world.clock_b[q] = 0
    return {"q": list(q), "raw": raw, "target": target}


def delta(world, meta):
    a, b = read(world.raw, meta["a"]), read(world.raw, meta["b"])
    return None if a is None or b is None else int(a["sreg"] - b["sreg"])


def digest(sequence):
    h = hashlib.sha256()
    for values in sequence:
        for value in values: h.update(int(value).to_bytes(8, "little"))
    return h.hexdigest()


def run(kernel, target, receiver_mode):
    a_mode = "delta_0" if receiver_mode == "coupled" else "absent"
    world, meta = build(kernel, OFFSET, a_mode, n=41)
    source = install_persistent_writer(world, meta, target) if a_mode != "absent" else None
    previous = delta(world, meta); transitions = []; sequence = []; samples = []
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta(world, meta)
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
        token = (int(world.raw[meta["q_b"]]), int(world.raw[meta["qp_b"]])); sequence.append(token)
        if tick in (1, 32, 64, 128, 130, 131, 132, 195, 256, 260, 261, 326, 384, 512, 716, 911, 1024):
            samples.append({"tick": tick, "master_delta": value, "receiver_pair": list(token)})
    windows = []
    for start in range(1, HORIZON + 1, WINDOW):
        values = sequence[start - 1:start - 1 + WINDOW]
        windows.append({"start": start, "end": start + WINDOW - 1,
                        "periods": periods(values), "sha256": digest(values)})
    source_fixed = source is None or int(world.raw[tuple(source["q"])]) == source["raw"]
    return {"target": target, "receiver_mode": receiver_mode,
            "persistent_writer": source, "master_transitions": transitions,
            "master_terminal_delta": previous, "receiver_windows": windows,
            "samples": samples, "source_raw_fixed": source_fixed,
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target, "coupled") for target in ("a", "b", None)]
    rows += [run(kernel, None, "free")]
    by = {(row["receiver_mode"], str(row["target"])): row for row in rows}
    a = by[("coupled", "a")]; b = by[("coupled", "b")]; sham = by[("coupled", "None")]
    first_write = {target: next((event["tick"] for event in row["master_transitions"]
                                 if event["after"] not in (None, 0)), None)
                   for target, row in (("a", a), ("b", b))}
    pre_window = 0
    post_window = next((index for index, window in enumerate(a["receiver_windows"])
                        if window["start"] > (first_write["a"] or HORIZON)), None)
    pre_equal = a["receiver_windows"][pre_window]["sha256"] == b["receiver_windows"][pre_window]["sha256"]
    post_distinct = post_window is not None and a["receiver_windows"][post_window]["sha256"] != b["receiver_windows"][post_window]["sha256"]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.late_dynamic_selection.v1",
        "question": "Can a t0-present dynamic receiver change regime after a native persistent writer first changes a neutral master near tick 131?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "information_gain": "high"},
        "design": {"offset": list(OFFSET), "initial_master_delta": 0,
                   "writer": "one semantic4 source at distance3 on target side",
                   "receiver": "native P2/P6 two-site dynamic organization",
                   "all_worlds_t0_complete": True},
        "rows": rows,
        "summary": {"first_native_nonzero_write_tick": first_write,
                    "a_b_receiver_equal_before_write": pre_equal,
                    "a_b_receiver_distinct_after_write": post_distinct,
                    "persistent_sources_survive": a["source_raw_fixed"] and b["source_raw_fixed"],
                    "native_late_dynamic_selection_demonstrated": all(value is not None for value in first_write.values()) and pre_equal and post_distinct,
                    "repeated_learned_switching_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "A late first transition is not recurrent reversal. The persistent source side is configured at t0 and cannot by itself establish environmental learning or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R10_LATE_DYNAMIC_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
