#!/usr/bin/env python3
"""Generate the delayed S2 branch natively by route length from t0."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, S1, S2, N1, N2, put_transducer
from run_landscape_l05_delayed_native_expression import set_both
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair


OFFSET = (-6, 7, 8)
HORIZON = 384
BASE_DISTANCE = 24
SOURCE2_DISTANCES = (24, 32, 38, 39, 40)


def add_heterogeneous_sources(world, meta, source2_distance):
    c, n = meta["c"], meta["n"]; qp = add(c, P, 1, n)
    distances = (BASE_DISTANCE, BASE_DISTANCE, source2_distance, BASE_DISTANCE)
    anchors = (qp, qp, c, c); directions = (S1, S2, N1, N2); sregs = (11, 13, 17, 19)
    sources = []
    for index, (anchor, direction, sreg, distance) in enumerate(zip(anchors, directions, sregs, distances)):
        q = add(anchor, direction, -distance, n); raw = int(pack(7000 + index, sreg, direction, 4))
        set_both(world, q, raw, 100 + index)
        sources.append({"index": index, "q": list(q), "raw": raw, "distance": distance})
    return sources


def run(kernel, target, source2_distance):
    try:
        world, meta = build_consequence(kernel, target, with_transducer=False, n=41,
                                        memory_phase=252, consequence_distance=6)
        sources = add_heterogeneous_sources(world, meta, source2_distance)
        q = add(meta["c"], OFFSET, 1, meta["n"])
        put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
        world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
        meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"])})
    except RuntimeError as exc:
        return {"target": target, "source2_distance": source2_distance,
                "valid": False, "reason": str(exc)}
    samples = []; first_write = None
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta_value(world, meta)
        if value not in (None, 0) and first_write is None: first_write = tick
        if tick in (8, 9, 16, 24, 30, 32, 38, 40, 48, 64, 96, 128, 160, 182, 201, 256, 320, 384):
            samples.append({"tick": tick, "master_delta": value, "pair": pair(world, meta)})
    return {"target": target, "source2_distance": source2_distance, "valid": True,
            "first_native_write_tick": first_write, "terminal_pair": pair(world, meta),
            "sources": sources, "sources_raw_fixed": all(int(world.raw[tuple(item["q"])]) == item["raw"] for item in sources),
            "samples": samples, "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target, distance) for distance in SOURCE2_DISTANCES
            for target in ("a", "b", None)]
    canonical = {str(row["target"]): row["terminal_pair"] for row in rows
                 if row.get("valid") and row["source2_distance"] == BASE_DISTANCE}
    groups = []
    for distance in SOURCE2_DISTANCES:
        subset = {str(row["target"]): row for row in rows if row.get("valid") and row["source2_distance"] == distance}
        valid = len(subset) == 3
        matches = {target: valid and subset[target]["terminal_pair"] == canonical.get(target)
                   for target in ("a", "b", "None")}
        groups.append({"source2_distance": distance, "nominal_extra_route_ticks": distance - BASE_DISTANCE,
                       "valid": valid, "matches_canonical": matches,
                       "canonical_a_b_preserved": matches["a"] and matches["b"],
                       "sham_preserved": matches["None"],
                       "all_sources_fixed": valid and all(row["sources_raw_fixed"] for row in subset.values())})
    candidates = [group for group in groups if group["source2_distance"] > BASE_DISTANCE and
                  group["canonical_a_b_preserved"] and group["sham_preserved"] and group["all_sources_fixed"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.native_formation_program_generator.v1",
        "question": "Can a longer t0 route for source S2 natively realize the compressed later-arrival formation program without Python activation?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "information_gain": "high"},
        "design": {"base_distance": BASE_DISTANCE, "source2_distances": list(SOURCE2_DISTANCES),
                   "other_source_distances": [BASE_DISTANCE, BASE_DISTANCE, BASE_DISTANCE],
                   "all_sources_present_at_t0": True, "all_worlds_t0_complete": True},
        "rows": rows, "groups": groups,
        "summary": {"native_route_delayed_canonical_candidates": candidates,
                    "native_compressed_program_generator_demonstrated": bool(candidates),
                    "globally_minimal_program_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "A route-delayed S2 source can implement one formation schedule natively, but does not prove global minimality, state-selected reuse or recurrent learning.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R11_NATIVE_FORMATION_PROGRAM_GENERATOR.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "groups": groups, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
