#!/usr/bin/env python3
"""Causal controls for the phase-compensated late commitment candidate."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair


OFFSET = (-6, 7, 8)
DISTANCE = 18
MEMORY_PHASE = 240
WRITE_TICK = 21
INTERVENTION_TICK = 22
HORIZON = 512


def build(kernel, target, generator_mode="treatment"):
    world, meta = build_consequence(kernel, target, generator_mode=generator_mode,
                                    with_transducer=False, n=41,
                                    memory_phase=MEMORY_PHASE, consequence_distance=DISTANCE)
    add_delayed_sources(world, meta, 24)
    q = add(meta["c"], OFFSET, 1, meta["n"])
    put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"])})
    return world, meta


def intervene(world, meta, mode):
    before = []
    records = {name: read(world.raw, meta[name]) for name in ("a", "b")}
    for name in ("a", "b"):
        item = records[name]; before.append(None if item is None else int(item["raw"]))
    if mode == "ablate":
        for name in ("a", "b"):
            q = meta[name]; world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    elif mode == "equalize":
        if any(item is None for item in records.values()): raise RuntimeError("master absent")
        common = records["b"]["sreg"]
        for name in ("a", "b"):
            item = records[name]; q = meta[name]
            raw = pack(item["state"], common, item["direction"], item["semantic"])
            world.raw_a[q] = raw; world.raw_b[q] = raw
    else:
        raise ValueError(mode)
    return {"tick": INTERVENTION_TICK, "mode": mode, "before_raw": before}


def run(kernel, target, generator_mode="treatment", intervention=None):
    world, meta = build(kernel, target, generator_mode)
    previous = 0; transitions = []; first_write = None; pairs = []; record = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if intervention is not None and tick == INTERVENTION_TICK:
            record = intervene(world, meta, intervention)
        value = delta_value(world, meta); token = pair(world, meta); pairs.append(token)
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        previous = value
    return {"target": target, "generator_mode": generator_mode, "intervention": intervention,
            "intervention_record": record, "first_write_tick": first_write,
            "master_transitions": transitions, "terminal_master_delta": previous,
            "terminal_pair": pairs[-1], "pair_sequence": pairs,
            "python_interventions_after_t0": int(intervention is not None),
            "intervention_class": "NONE" if intervention is None else "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    treatments = [run(kernel, target) for target in ("a", "b", None)]
    canaries = [run(kernel, target, mode) for target in ("a", "b")
                for mode in ("missing_d1", "missing_d2", "wrong_cancel")]
    interventions = [run(kernel, target, intervention=mode) for target in ("a", "b")
                     for mode in ("equalize", "ablate")]
    by = {str(row["target"]): row for row in treatments}; a, b, sham = by["a"], by["b"], by["None"]
    first_remote_difference = next((tick for tick, (pa, pb) in enumerate(zip(a["pair_sequence"], b["pair_sequence"]), 1)
                                    if pa != pb), None)
    canaries_equal_sham = all(row["terminal_pair"] == sham["terminal_pair"] and
                              row["terminal_master_delta"] == 0 for row in canaries)
    interventions_change_remote = all(row["terminal_pair"] != by[str(row["target"])]["terminal_pair"]
                                      for row in interventions)
    for row in treatments + canaries + interventions:
        row.pop("pair_sequence", None)
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.late_commitment_controls.v1",
        "question": "Does the distance18/phase240 late remote state require the valid consequence generator and stored master after tick21?",
        "cost_estimate": {"worlds": len(treatments) + len(canaries) + len(interventions),
                          "ticks_per_world": HORIZON, "information_gain": "high"},
        "design": {"distance": DISTANCE, "memory_phase": MEMORY_PHASE,
                   "expected_write_tick": WRITE_TICK, "intervention_tick": INTERVENTION_TICK,
                   "generator_canaries": ["missing_d1", "missing_d2", "wrong_cancel"]},
        "treatments": treatments, "generator_canaries": canaries,
        "master_interventions": interventions,
        "summary": {"opposite_native_writes": a["terminal_master_delta"] * b["terminal_master_delta"] < 0,
                    "first_remote_a_b_difference_tick": first_remote_difference,
                    "stored_interval_before_remote_divergence": None if first_remote_difference is None else first_remote_difference - WRITE_TICK,
                    "generator_canaries_equal_sham": canaries_equal_sham,
                    "post_write_master_interventions_change_remote": interventions_change_remote,
                    "late_commitment_causally_supported": a["terminal_master_delta"] * b["terminal_master_delta"] < 0 and
                                                         first_remote_difference is not None and first_remote_difference > WRITE_TICK and
                                                         canaries_equal_sham and interventions_change_remote,
                    "native_recurrent_learning_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "Master equalization/ablation are diagnostic. A supported late first commitment still lacks a second native consequence and cannot establish RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R12_LATE_COMMITMENT_CONTROLS.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
