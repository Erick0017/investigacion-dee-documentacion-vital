#!/usr/bin/env python3
"""Combine native late consequence writing with route-delayed S2 formation."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start
from run_reactivation_r11_native_formation_program_generator import add_heterogeneous_sources


OFFSET = (-6, 7, 8)
CONSEQUENCE_DISTANCE = 18
MEMORY_PHASE = 240
SOURCE2_DISTANCE = 32
HORIZON = 512


def build(kernel, target, generator_mode="treatment"):
    world, meta = build_consequence(kernel, target, generator_mode=generator_mode,
                                    with_transducer=False, n=41,
                                    memory_phase=MEMORY_PHASE,
                                    consequence_distance=CONSEQUENCE_DISTANCE)
    sources = add_heterogeneous_sources(world, meta, SOURCE2_DISTANCE)
    q = add(meta["c"], OFFSET, 1, meta["n"])
    put_transducer(world.raw_a, world.clock_a, q, meta["n"], 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, meta["n"])})
    return world, meta, sources


def run(kernel, target, generator_mode="treatment"):
    try: world, meta, sources = build(kernel, target, generator_mode)
    except RuntimeError as exc:
        return {"target": target, "generator_mode": generator_mode, "valid": False, "reason": str(exc)}
    previous = 0; transitions = []; first_write = None; pairs = []
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta_value(world, meta); pairs.append(pair(world, meta))
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        previous = value
    start = constant_suffix_start([tuple(value) for value in pairs])
    return {"target": target, "generator_mode": generator_mode, "valid": True,
            "first_write_tick": first_write, "master_transitions": transitions,
            "terminal_master_delta": previous, "terminal_pair": pairs[-1],
            "pair_sequence": pairs, "remote_constant_suffix_start": start,
            "remote_constant_duration": HORIZON - start + 1,
            "sources_raw_fixed": all(int(world.raw[tuple(item["q"])]) == item["raw"] for item in sources),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, target) for target in ("a", "b", None)]
    rows += [run(kernel, "a", mode) for mode in ("missing_d1", "missing_d2", "wrong_cancel")]
    valid = [row for row in rows if row.get("valid")]; treatments = {str(row["target"]): row for row in valid
                 if row["generator_mode"] == "treatment"}
    a, b, sham = treatments["a"], treatments["b"], treatments["None"]
    first_difference = next((tick for tick, (pa, pb) in enumerate(zip(a["pair_sequence"], b["pair_sequence"]), 1)
                             if pa != pb), None)
    canaries = [row for row in valid if row["generator_mode"] != "treatment"]
    canaries_equal_sham = all(row["terminal_master_delta"] == 0 and row["terminal_pair"] == sham["terminal_pair"]
                              for row in canaries)
    for row in rows: row.pop("pair_sequence", None)
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.combined_late_development.v1",
        "question": "Are phase-compensated late learning and the native +8 S2 formation route compatible in one t0-complete organization?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "information_gain": "high"},
        "design": {"consequence_distance": CONSEQUENCE_DISTANCE, "memory_phase": MEMORY_PHASE,
                   "source2_distance": SOURCE2_DISTANCE, "other_source_distances": [24, 24, 24],
                   "remote_offset": list(OFFSET), "all_worlds_t0_complete": True},
        "rows": rows,
        "summary": {"a_b_native_writes_opposite": a["terminal_master_delta"] * b["terminal_master_delta"] < 0,
                    "write_ticks": {"a": a["first_write_tick"], "b": b["first_write_tick"]},
                    "first_remote_a_b_difference_tick": first_difference,
                    "stored_interval_before_remote_divergence": None if first_difference is None else first_difference - max(a["first_write_tick"], b["first_write_tick"]),
                    "a_b_remote_distinct": a["terminal_pair"] != b["terminal_pair"],
                    "sham_distinct": sham["terminal_pair"] not in (a["terminal_pair"], b["terminal_pair"]),
                    "generator_canaries_equal_sham": canaries_equal_sham,
                    "sources_fixed": all(row["sources_raw_fixed"] for row in valid),
                    "combined_native_late_development_demonstrated": a["terminal_master_delta"] * b["terminal_master_delta"] < 0 and
                                                                     first_difference is not None and first_difference > max(a["first_write_tick"], b["first_write_tick"]) and
                                                                     a["terminal_pair"] != b["terminal_pair"] and canaries_equal_sham,
                    "rw3_demonstrated": False},
        "claim_guard": "This is a native late first learning/development episode. It does not contain a second consequence, niche reuse or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R13_COMBINED_LATE_DEVELOPMENT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
