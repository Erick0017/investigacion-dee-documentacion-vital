#!/usr/bin/env python3
"""Extend the phase-compensated native consequence law toward a full toroidal route."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, load_kernel, seal, write_json
import run_reactivation_r08_phase_compensated_late_commitment as r08


DISTANCES = (22, 30, 38, 40)


def main():
    kernel, runtime = load_kernel(1)
    specs = []
    for distance in DISTANCES:
        predicted = r08.predicted_phase(distance)
        specs += [(distance, 252, "uncompensated_control"),
                  (distance, predicted, "route_compensated")]
    rows = [r08.run(kernel, target, distance, phase, label)
            for distance, phase, label in specs for target in ("a", "b", None)]
    checkpoint = seal({"schema": "dee.v27.ing03.rw3_reactivation.extended_late_routes.rows.v1",
                       "specs": [{"distance": distance, "memory_phase": phase, "phase_class": label}
                                 for distance, phase, label in specs],
                       "rows": rows, "runtime": runtime})
    write_json(ROOT / "DISCOVERY/ING03_REACT_R14_EXTENDED_LATE_ROUTE_ROWS.json", checkpoint)
    groups = []
    for distance, phase, label in specs:
        subset = {str(row["target"]): row for row in rows if row.get("valid") and
                  row["distance"] == distance and row["memory_phase"] == phase}
        valid = len(subset) == 3
        groups.append({"distance": distance, "memory_phase": phase, "phase_class": label,
                       "valid": valid,
                       "write_ticks": {target: subset.get(target, {}).get("first_native_write_tick")
                                       for target in ("a", "b", "None")},
                       "a_b_master_opposite": valid and subset["a"]["terminal_master_delta"] * subset["b"]["terminal_master_delta"] < 0,
                       "a_b_remote_distinct": valid and subset["a"]["terminal_pair"] != subset["b"]["terminal_pair"],
                       "sham_master_zero": valid and subset["None"]["terminal_master_delta"] == 0})
    candidates = [group for group in groups if group["phase_class"] == "route_compensated" and
                  group["valid"] and group["a_b_master_opposite"] and group["a_b_remote_distinct"] and group["sham_master_zero"]]
    post_early_function = [group for group in candidates if min(group["write_ticks"][target] for target in ("a", "b")) > 38]
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.extended_late_routes.v1",
        "question": "Does route-length phase compensation remain valid through distances22..40 and create a write after the prior apparatus' tick38 functional divergence?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": r08.HORIZON,
                          "information_gain": "high"},
        "design": {"distances": list(DISTANCES),
                   "predicted_phase_law": "(252-(distance-6)) mod 256",
                   "controls": "fixed phase252 at each distance", "all_worlds_t0_complete": True},
        "rows": rows, "groups": groups,
        "summary": {"route_compensated_candidates": candidates,
                    "candidates_writing_after_tick38": post_early_function,
                    "native_post_function_write_candidate": bool(post_early_function),
                    "single_world_sequence_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "Separate worlds establish a scheduling primitive only. They do not establish native node selection, a single-world A-to-B sequence or RW3.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R14_EXTENDED_LATE_ROUTES.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "groups": groups, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
