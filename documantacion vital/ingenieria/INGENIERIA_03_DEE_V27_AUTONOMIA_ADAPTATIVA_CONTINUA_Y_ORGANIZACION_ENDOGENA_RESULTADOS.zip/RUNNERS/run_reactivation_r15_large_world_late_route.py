#!/usr/bin/env python3
"""Test the phase/route law at distance80 in a larger toroidal world."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value
from run_dd_r01_remote_dependency_map import pair
from run_rw3_r12_remote_fixed_point_characterization import constant_suffix_start
from run_reactivation_r11_native_formation_program_generator import add_heterogeneous_sources


N = 83
DISTANCE = 80
MEMORY_PHASE = (252 - (DISTANCE - 6)) & 255
SOURCE2_DISTANCE = 32
OFFSET = (-6, 7, 8)
HORIZON = 512


def build(kernel, target):
    world, meta = build_consequence(kernel, target, with_transducer=False, n=N,
                                    memory_phase=MEMORY_PHASE, consequence_distance=DISTANCE)
    sources = add_heterogeneous_sources(world, meta, SOURCE2_DISTANCE)
    q = add(meta["c"], OFFSET, 1, N); put_transducer(world.raw_a, world.clock_a, q, N, 9000)
    world.raw_b[:] = world.raw_a; world.clock_b[:] = world.clock_a
    meta = dict(meta); meta.update({"q_receiver": q, "qp_receiver": add(q, P, 1, N)})
    return world, meta, sources


def run(kernel, target):
    try: world, meta, sources = build(kernel, target)
    except RuntimeError as exc: return {"target": target, "valid": False, "reason": str(exc)}
    previous = 0; transitions = []; first_write = None; pairs = []
    for tick in range(1, HORIZON + 1):
        world.tick(); value = delta_value(world, meta); pairs.append(pair(world, meta))
        if value != previous: transitions.append({"tick": tick, "before": previous, "after": value})
        if value not in (None, 0) and first_write is None: first_write = tick
        previous = value
    start = constant_suffix_start([tuple(value) for value in pairs])
    return {"target": target, "valid": True, "first_native_write_tick": first_write,
            "master_transitions": transitions, "terminal_master_delta": previous,
            "terminal_pair": pairs[-1], "pair_sequence": pairs,
            "remote_constant_suffix_start": start, "remote_constant_duration": HORIZON - start + 1,
            "sources_raw_fixed": all(int(world.raw[tuple(item["q"])]) == item["raw"] for item in sources),
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1); rows = [run(kernel, target) for target in ("a", "b", None)]
    valid = {str(row["target"]): row for row in rows if row.get("valid")}
    if len(valid) == 3:
        a, b, sham = valid["a"], valid["b"], valid["None"]
        first_difference = next((tick for tick, (pa, pb) in enumerate(zip(a["pair_sequence"], b["pair_sequence"]), 1)
                                 if pa != pb), None)
        success = (a["terminal_master_delta"] * b["terminal_master_delta"] < 0 and
                   a["first_native_write_tick"] == b["first_native_write_tick"] == DISTANCE + 3 and
                   first_difference is not None and first_difference > DISTANCE + 3 and
                   len({tuple(a["terminal_pair"]), tuple(b["terminal_pair"]), tuple(sham["terminal_pair"])}) == 3)
    else:
        a = b = sham = {}; first_difference = None; success = False
    for row in rows: row.pop("pair_sequence", None)
    result = seal({
        "schema": "dee.v27.ing03.rw3_reactivation.large_world_late_route.v1",
        "question": "Does the compensated consequence law scale to distance80/n83 and preserve a stored interval before remote differentiation?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON,
                          "world_shape": [N, N, N], "information_gain": "high"},
        "design": {"n": N, "distance": DISTANCE, "memory_phase": MEMORY_PHASE,
                   "source2_distance": SOURCE2_DISTANCE, "remote_offset": list(OFFSET),
                   "all_worlds_t0_complete": True},
        "rows": rows,
        "summary": {"write_ticks": {key: value.get("first_native_write_tick") for key, value in valid.items()},
                    "first_remote_a_b_difference_tick": first_difference,
                    "stored_interval_before_remote_divergence": None if first_difference is None else first_difference - (DISTANCE + 3),
                    "phase_route_law_scaled": success,
                    "single_world_sequence_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "Separate counterfactual worlds validate a scheduling primitive, not multiple learning episodes in one world.",
        "runtime": runtime})
    output = ROOT / "MECHANISM_SELECTION/ING03_REACT_R15_LARGE_WORLD_LATE_ROUTE.json"; write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__": main()
