#!/usr/bin/env python3
"""Audit whether the late consequence generators used by L07 can write in isolation.

This is a prerequisite audit, not an autonomy claim.  It deliberately separates
generator validity from any post-expression residue so an invalid delay line is
not misreported as read/write backaction.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB

P = (1, 0, 0)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def add_master(raw, clock, c, n, phase=252):
    a = add(c, P, -1, n); b = add(c, P, 1, n)
    put(raw, clock, a, 1000, 100, semantic=1, phase=phase)
    put(raw, clock, b, 2000, 100, semantic=1, phase=phase)
    for index, rel in enumerate(PA):
        put(raw, clock, add(a, rel, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, rel in enumerate(PB):
        put(raw, clock, add(b, rel, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    return a, b


def add_generator(raw, clock, target, distance, state_base, n):
    event = add(target, (0, -1, 0), 1, n)
    route = (0, 0, 1)
    generator = add(event, route, -distance, n)
    positions = []
    for branch, direction in enumerate(((1, 0, 1), (-1, 0, 1))):
        q = add(generator, direction, -1, n)
        put(raw, clock, q, state_base + branch, 3, direction, 1, 0)
        positions.append(q)
    return positions


def run_isolated(kernel, target_name, distance, horizon=64, n=41):
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; a, b = add_master(raw, clock, c, n)
    target = a if target_name == "a" else b
    generator_positions = add_generator(raw, clock, target, distance, 5000, n)
    world = NativeWorld(kernel, raw, clock)
    deltas = []; transitions = []; previous = 0
    target_sreg = []
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        deltas.append(delta); target_sreg.append(None if (ra if target_name == "a" else rb) is None else (ra if target_name == "a" else rb)["sreg"])
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        previous = delta
    return {
        "target": target_name, "distance": distance,
        "nominal_write_tick": distance + 3,
        "transitions": transitions,
        "first_transition_tick": None if not transitions else transitions[0]["tick"],
        "terminal_delta": deltas[-1],
        "nonzero_delta_ticks": [i + 1 for i, value in enumerate(deltas) if value not in (0, None)],
        "target_sreg_1_40": target_sreg[:40],
        "initial_generator_positions": [list(q) for q in generator_positions],
        "python_interventions_after_t0": 0,
    }


def run_l07_generators_without_expression(kernel, sequence="abb", distances=(6, 18, 30), horizon=64, n=41):
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; a, b = add_master(raw, clock, c, n)
    positions = []
    for index, (name, distance) in enumerate(zip(sequence, distances)):
        positions.extend(add_generator(raw, clock, a if name == "a" else b, distance, 5000 + 10 * index, n))
    world = NativeWorld(kernel, raw, clock)
    transitions = []; trace = []; previous = 0
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, a), read(world.raw, b)
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick <= 40:
            trace.append({"tick": tick, "delta": delta,
                          "a_sreg": None if ra is None else ra["sreg"],
                          "b_sreg": None if rb is None else rb["sreg"]})
        previous = delta
    return {"sequence": sequence, "distances": list(distances), "transitions": transitions,
            "trace_1_40": trace, "terminal_delta": previous,
            "initial_generator_positions": [list(q) for q in positions],
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    distances = tuple(range(1, 21)) + (24, 30)
    isolated = [run_isolated(kernel, target, distance) for target in ("a", "b") for distance in distances]
    compound = [run_l07_generators_without_expression(kernel, sequence) for sequence in ("abb", "baa")]
    valid = [row for row in isolated if row["first_transition_tick"] is not None]
    invalid = [row for row in isolated if row["first_transition_tick"] is None]
    l07_distances = {distance: {target: next(row for row in isolated if row["target"] == target and row["distance"] == distance)
                                for target in ("a", "b")} for distance in (6, 18, 30)}
    result = seal({
        "schema": "dee.v27.ing03.rw3.delayed_write_validity.v1",
        "question": "Did each L07 late consequence generator independently possess the ability to write the master?",
        "isolated_rows": isolated,
        "compound_l07_rows_without_expression": compound,
        "l07_distance_audit": l07_distances,
        "summary": {
            "valid_isolated_rows": len(valid),
            "invalid_isolated_rows": len(invalid),
            "valid_distance_by_target": {target: [row["distance"] for row in valid if row["target"] == target] for target in ("a", "b")},
            "l07_late_generators_valid_in_isolation": all(l07_distances[d][target]["first_transition_tick"] is not None for d, target in ((18, "b"), (30, "b"))),
            "l07_compound_transition_counts_without_expression": {row["sequence"]: len(row["transitions"]) for row in compound},
        },
        "interpretation_guard": "Failure of an isolated late generator invalidates its use as evidence of post-expression write blocking. It does not establish compatibility or incompatibility.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_RW3_R01_DELAYED_WRITE_VALIDITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
