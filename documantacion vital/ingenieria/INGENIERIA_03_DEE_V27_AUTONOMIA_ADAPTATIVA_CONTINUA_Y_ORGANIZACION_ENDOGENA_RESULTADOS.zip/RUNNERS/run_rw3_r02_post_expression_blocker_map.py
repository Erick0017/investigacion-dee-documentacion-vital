#!/usr/bin/env python3
"""Map the actual post-expression condition that controls a validated later write.

Host interventions are predeclared diagnostic ablations/installations.  They are
never promoted as native RW capability.  The later consequence itself is the
same validated two-carrier DEE generator in every paired branch.
"""
from __future__ import annotations

import json
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value

P = (1, 0, 0)
DIAGNOSTIC_TICK = 40
GENERATOR_DISTANCE = 6
EXPECTED_WRITE_TICK = DIAGNOSTIC_TICK + GENERATOR_DISTANCE + 3


def build_world(kernel, expression=True):
    world, meta = build_consequence(kernel, "a", generator_mode="treatment", with_transducer=False,
                                    n=41, memory_phase=252, consequence_distance=6)
    sources = add_delayed_sources(world, meta, 24) if expression else []
    meta = dict(meta); meta["expression_sources"] = [q for q, _ in sources]
    return world, meta


def local_positions(meta, radius=1):
    c = meta["c"]; n = meta["n"]
    return sorted({add(c, (dx, dy, dz), 1, n)
                   for dx, dy, dz in product(range(-radius, radius + 1), repeat=3)})


def snapshot(world, positions):
    return {q: (int(world.raw_a[q]), int(world.clock_a[q])) for q in positions}


def set_zero_both(world, q):
    world.raw_a[q] = np.uint64(0); world.raw_b[q] = np.uint64(0)
    world.clock_a[q] = np.uint64(0); world.clock_b[q] = np.uint64(0)


def set_record_both(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def inject_validated_generator(world, target, n, phase, state_base=8500):
    event = add(target, (0, -1, 0), 1, n); route = (0, 0, 1)
    generator = add(event, route, -GENERATOR_DISTANCE, n)
    positions = []
    for branch, direction in enumerate(((1, 0, 1), (-1, 0, 1))):
        q = add(generator, direction, -1, n)
        if int(world.raw_a[q]) or int(world.raw_b[q]):
            return {"installed": False, "overlap": list(q), "positions": [list(p) for p in positions]}
        raw = pack(state_base + branch, 3, direction, 1)
        # Preserve the same relative clock relation as the validated t0
        # generator: target and generator clocks have both advanced by `phase`.
        set_record_both(world, q, raw, phase); positions.append(q)
    return {"installed": True, "overlap": None, "positions": [list(q) for q in positions]}


def compact_site(world, q):
    record = read(world.raw, q)
    return {"q": list(q), "record": record, "clock": int(world.clock_a[q])}


def run_capture(kernel, expression, horizon=40):
    world, meta = build_world(kernel, expression)
    positions = local_positions(meta, 1)
    captures = {}
    for tick in range(1, horizon + 1):
        world.tick()
        if tick in (8, 9, 10, 23, 24, 25, 40):
            captures[tick] = snapshot(world, positions)
    return world, meta, captures


def apply_intervention(world, meta, mode, reference):
    c, a, b = meta["c"], meta["a"], meta["b"]
    interventions = []
    if mode.startswith("cut_sources"):
        for q in meta["expression_sources"]:
            set_zero_both(world, q); interventions.append({"operation": "clear_source", "q": list(q)})
    if mode in ("clear_c", "cut_sources_clear_c", "hold_clear_c"):
        set_zero_both(world, c); interventions.append({"operation": "clear", "q": list(c)})
    if mode in ("clear_c_and_b", "cut_sources_clear_c_and_b", "hold_clear_c_and_b"):
        for q in (c, b):
            set_zero_both(world, q); interventions.append({"operation": "clear", "q": list(q)})
    if mode in ("restore_b_from_no_expression", "restore_c_b_from_no_expression"):
        for q in ((b,) if mode == "restore_b_from_no_expression" else (c, b)):
            raw, clock = reference["no_expression"][q]
            set_record_both(world, q, raw, clock)
            interventions.append({"operation": "restore_no_expression", "q": list(q), "raw": raw, "clock": clock})
    if mode == "restore_b_fields_except_sreg":
        source_raw, source_clock = reference["no_expression"][b]
        source = unpack_scalar(source_raw); current = read(world.raw, b)
        if current is not None:
            raw = pack(source["state"], current["sreg"], source["direction"], source["semantic"])
            set_record_both(world, b, raw, source_clock)
            interventions.append({"operation": "restore_fields_preserve_sreg", "q": list(b), "raw": int(raw), "clock": source_clock})
    if mode in ("install_expression_b", "install_expression_c_b"):
        for q in ((b,) if mode == "install_expression_b" else (c, b)):
            raw, clock = reference["expression"][q]
            set_record_both(world, q, raw, clock)
            interventions.append({"operation": "install_expression_condition", "q": list(q), "raw": raw, "clock": clock})
    if mode == "install_expression_moore":
        for q, (raw, clock) in reference["expression"].items():
            set_record_both(world, q, raw, clock)
        interventions.append({"operation": "install_expression_moore27", "count": len(reference["expression"])})
    return interventions


def run_branch(kernel, expression, mode, reference, horizon=64):
    world, meta = build_world(kernel, expression)
    trace = []; transitions = []; previous = 0; interventions = []; injection = None
    held_modes = {"hold_clear_c", "hold_clear_c_and_b"}
    for tick in range(1, horizon + 1):
        world.tick()
        if tick == DIAGNOSTIC_TICK:
            interventions.extend(apply_intervention(world, meta, mode, reference))
            injection = inject_validated_generator(world, meta["b"], meta["n"], tick)
            interventions.append({"operation": "inject_validated_generator", "tick": tick, **injection})
        elif tick > DIAGNOSTIC_TICK and tick < EXPECTED_WRITE_TICK and mode in held_modes:
            qs = (meta["c"],) if mode == "hold_clear_c" else (meta["c"], meta["b"])
            for q in qs:
                set_zero_both(world, q)
            interventions.append({"operation": "held_clear", "tick": tick, "positions": [list(q) for q in qs]})
        delta = delta_value(world, meta)
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick in (8, 9, 10, 23, 24, 25, 39, 40, 41, 47, 48, 49, 50, 56, 64):
            trace.append({"tick": tick, "delta": delta,
                          "a": compact_site(world, meta["a"]),
                          "b": compact_site(world, meta["b"]),
                          "c": compact_site(world, meta["c"])})
        previous = delta
    later = [event for event in transitions if event["tick"] >= DIAGNOSTIC_TICK]
    return {
        "expression": expression, "mode": mode,
        "diagnostic_generator": injection,
        "master_transitions": transitions,
        "later_transitions": later,
        "validated_later_write_succeeded": any(event["tick"] >= EXPECTED_WRITE_TICK - 1 for event in later),
        "terminal_delta": previous,
        "trace": trace,
        "host_diagnostic_interventions": interventions,
        "python_interventions_after_t0": len(interventions),
        "claim_guard": "Diagnostic branch only; host interventions cannot establish native RW3."
    }


def differences(captures_a, captures_b, tick):
    rows = []
    for q in sorted(captures_a[tick]):
        a_raw, a_clock = captures_a[tick][q]; b_raw, b_clock = captures_b[tick][q]
        if (a_raw, a_clock) != (b_raw, b_clock):
            rows.append({"q": list(q), "expression": {"record": None if not a_raw else unpack_scalar(a_raw), "clock": a_clock},
                         "no_expression": {"record": None if not b_raw else unpack_scalar(b_raw), "clock": b_clock}})
    return rows


def main():
    kernel, runtime = load_kernel(1)
    expression_world, expression_meta, expression_captures = run_capture(kernel, True)
    noexpr_world, noexpr_meta, noexpr_captures = run_capture(kernel, False)
    positions = local_positions(expression_meta, 1)
    reference = {"expression": snapshot(expression_world, positions),
                 "no_expression": snapshot(noexpr_world, positions)}
    modes_expression = ("none", "cut_sources", "clear_c", "cut_sources_clear_c",
                        "restore_b_from_no_expression", "restore_c_b_from_no_expression",
                        "restore_b_fields_except_sreg", "hold_clear_c")
    modes_noexpr = ("none", "install_expression_b", "install_expression_c_b", "install_expression_moore")
    rows = [run_branch(kernel, True, mode, reference) for mode in modes_expression]
    rows += [run_branch(kernel, False, mode, reference) for mode in modes_noexpr]
    base_expression = next(row for row in rows if row["expression"] and row["mode"] == "none")
    base_noexpr = next(row for row in rows if not row["expression"] and row["mode"] == "none")
    restoring = [row["mode"] for row in rows if row["expression"] and row["validated_later_write_succeeded"]]
    blocking = [row["mode"] for row in rows if not row["expression"] and not row["validated_later_write_succeeded"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3.post_expression_blocker_map.v1",
        "question": "Does a validated later consequence fail specifically after expression, and which local condition is necessary/sufficient for that failure?",
        "diagnostic_design": {"first_native_write_tick": 9, "first_expression_tick": 24,
                              "host_diagnostic_tick": DIAGNOSTIC_TICK,
                              "validated_later_generator_distance": GENERATOR_DISTANCE,
                              "injected_generator_clock": DIAGNOSTIC_TICK,
                              "expected_later_write_tick": EXPECTED_WRITE_TICK,
                              "paired_generator_identical": True,
                              "host_interventions_are_diagnostic_only": True},
        "local_differences": {str(tick): differences(expression_captures, noexpr_captures, tick) for tick in (23, 24, 25, 40)},
        "rows": rows,
        "summary": {"expression_base_later_write": base_expression["validated_later_write_succeeded"],
                    "no_expression_base_later_write": base_noexpr["validated_later_write_succeeded"],
                    "expression_modes_restoring_write": restoring,
                    "no_expression_installs_blocking_write": blocking,
                    "necessary_and_sufficient_candidate_found": bool(restoring and blocking)},
        "classification_rule": "A residue is necessary only if removing/restoring it reopens the paired write; sufficient only if installing it blocks the otherwise successful paired write.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_RW3_R02_POST_EXPRESSION_BLOCKER_MAP.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
