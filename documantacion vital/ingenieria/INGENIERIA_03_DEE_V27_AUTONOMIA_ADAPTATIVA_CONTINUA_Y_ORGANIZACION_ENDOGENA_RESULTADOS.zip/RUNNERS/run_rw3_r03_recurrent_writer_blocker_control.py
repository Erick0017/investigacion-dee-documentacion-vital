#!/usr/bin/env python3
"""Use the validated persistent writer as a positive control after RW2 expression.

Unlike L07's invalid long-delay one-shot carriers, the semantic4 source remains
present and has a known recurrent write opportunity.  This experiment therefore
tests post-expression writability without relying on an unvalidated delay line.
"""
from __future__ import annotations

import json
import argparse
import sys
from itertools import product
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, unpack_scalar, write_json
from run_landscape_l05_delayed_native_expression import add_delayed_sources, set_both
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value

P = (1, 0, 0)
INTERVENTION_TICK = 40


def persistent_writer_spec(meta, target_name="b"):
    target = meta[target_name]
    event = add(target, (0, -1, 0), 1, meta["n"])
    direction = (0, 0, 1)
    q = add(event, direction, -3, meta["n"])
    raw = pack(9100, 0, direction, 4)
    return q, int(raw)


def build_world(kernel, expression):
    world, meta = build_consequence(kernel, "a", generator_mode="treatment", with_transducer=False,
                                    n=41, memory_phase=252, consequence_distance=6)
    writer_q, writer_raw = persistent_writer_spec(meta, "b")
    expression_sources = add_delayed_sources(world, meta, 24) if expression else []
    meta = dict(meta); meta.update({"writer_q": writer_q, "writer_raw": writer_raw,
                                    "expression_sources": [q for q, _ in expression_sources]})
    return world, meta


def local_positions(meta, radius=1):
    c = meta["c"]; n = meta["n"]
    return sorted({add(c, (dx, dy, dz), 1, n)
                   for dx, dy, dz in product(range(-radius, radius + 1), repeat=3)})


def snap(world, positions):
    return {q: (int(world.raw_a[q]), int(world.clock_a[q])) for q in positions}


def set_both_record(world, q, raw, clock):
    world.raw_a[q] = np.uint64(raw); world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock); world.clock_b[q] = np.uint64(clock)


def clear(world, q):
    set_both_record(world, q, 0, 0)


def inject_persistent_writer(world, meta, tick):
    q = meta["writer_q"]
    if int(world.raw_a[q]) or int(world.raw_b[q]):
        return {"op": "inject_persistent_writer", "installed": False, "overlap": list(q), "tick": tick}
    set_both_record(world, q, meta["writer_raw"], tick)
    return {"op": "inject_persistent_writer", "installed": True, "q": list(q), "raw": meta["writer_raw"], "clock": tick, "tick": tick}


def precompute_reference(kernel):
    references = {}; trajectories = {}
    for expression in (False, True):
        world, meta = build_world(kernel, expression)
        positions = local_positions(meta, 1)
        trajectory = {}
        for tick in range(1, 141):
            world.tick()
            trajectory[tick] = snap(world, positions)
        references[expression] = trajectory[INTERVENTION_TICK]
        trajectories[expression] = trajectory
    references["trajectories"] = trajectories
    return references


def restore_local_nonlearning_fields(world, meta, reference_snapshot):
    ops = []
    for q, (raw, clock) in reference_snapshot.items():
        if q in (meta["a"], meta["b"]):
            current = read(world.raw, q)
            source = None if not raw else unpack_scalar(raw)
            if current is None or source is None:
                continue
            raw = int(pack(source["state"], current["sreg"], source["direction"], source["semantic"]))
        set_both_record(world, q, raw, clock)
        ops.append({"q": list(q), "raw": raw, "clock": clock})
    return ops


def apply_mode(world, meta, mode, references):
    ops = []; c, b = meta["c"], meta["b"]
    if "cut_sources" in mode:
        for q in meta["expression_sources"]:
            clear(world, q); ops.append({"op": "cut_expression_source", "q": list(q)})
    if mode in ("clear_c", "cut_sources_clear_c", "hold_clear_c", "cut_sources_hold_clear_c"):
        clear(world, c); ops.append({"op": "clear_c", "q": list(c)})
    if mode == "restore_b_noexpr":
        raw, clock = references[False][b]; set_both_record(world, b, raw, clock)
        ops.append({"op": "restore_b_noexpr", "raw": raw, "clock": clock})
    if mode == "restore_c_b_noexpr":
        for q in (c, b):
            raw, clock = references[False][q]; set_both_record(world, q, raw, clock)
            ops.append({"op": "restore_noexpr", "q": list(q), "raw": raw, "clock": clock})
    if mode == "install_b_expression":
        raw, clock = references[True][b]; set_both_record(world, b, raw, clock)
        ops.append({"op": "install_b_expression", "raw": raw, "clock": clock})
    if mode == "install_c_b_expression":
        for q in (c, b):
            raw, clock = references[True][q]; set_both_record(world, q, raw, clock)
            ops.append({"op": "install_expression", "q": list(q), "raw": raw, "clock": clock})
    if mode == "install_moore_expression":
        for q, (raw, clock) in references[True].items():
            set_both_record(world, q, raw, clock)
        ops.append({"op": "install_moore_expression", "count": len(references[True])})
    if mode in ("restore_moore_noexpr", "cut_sources_restore_moore_noexpr",
                "cut_sources_hold_restore_moore_noexpr"):
        changed = restore_local_nonlearning_fields(world, meta, references[False])
        ops.append({"op": "restore_moore_noexpr_preserve_master_sreg", "count": len(changed)})
    return ops


def run(kernel, expression, mode, references, horizon=512):
    world, meta = build_world(kernel, expression)
    transitions = []; previous = 0; trace = []; ops = []
    hold = mode in ("hold_clear_c", "cut_sources_hold_clear_c")
    hold_restore = mode == "cut_sources_hold_restore_moore_noexpr"
    for tick in range(1, horizon + 1):
        world.tick()
        if tick == INTERVENTION_TICK:
            if mode != "none":
                ops.extend(apply_mode(world, meta, mode, references))
            ops.append(inject_persistent_writer(world, meta, tick))
        elif tick > INTERVENTION_TICK and hold:
            clear(world, meta["c"])
            ops.append({"op": "held_clear_c", "tick": tick})
        elif tick > INTERVENTION_TICK and tick <= 140 and hold_restore:
            changed = restore_local_nonlearning_fields(world, meta, references["trajectories"][False][tick])
            ops.append({"op": "held_restore_noexpr_nonlearning_fields", "tick": tick, "count": len(changed)})
        delta = delta_value(world, meta)
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick in (1, 8, 9, 10, 23, 24, 25, 63, 64, 65, 128, 131, 195, 260, 326, 390, 521, 716, 911, 1024):
            trace.append({"tick": tick, "delta": delta,
                          "a": read(world.raw, meta["a"]), "b": read(world.raw, meta["b"]),
                          "c": read(world.raw, meta["c"]),
                          "writer_fixed": int(world.raw[meta["writer_q"]]) == meta["writer_raw"]})
        previous = delta
    post_first = [event for event in transitions if event["tick"] > 9]
    return {"expression": expression, "mode": mode, "transitions": transitions,
            "post_first_write_transitions": post_first,
            "post_first_write_count": len(post_first), "terminal_delta": previous,
            "writer_source_raw_fixed": int(world.raw[meta["writer_q"]]) == meta["writer_raw"],
            "trace": trace, "host_diagnostic_operations": ops,
            "python_interventions_after_t0": len(ops),
            "claim_guard": "Only mode=none is host-free; intervention branches diagnose necessity/sufficiency and cannot establish RW3."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base-only", action="store_true")
    parser.add_argument("--target-mode", choices=("restore_moore_noexpr", "cut_sources_restore_moore_noexpr",
                                                   "cut_sources_hold_restore_moore_noexpr"))
    args = parser.parse_args()
    kernel, runtime = load_kernel(1); references = precompute_reference(kernel)
    expression_modes = ("none", "cut_sources", "clear_c", "cut_sources_clear_c",
                        "restore_b_noexpr", "restore_c_b_noexpr", "restore_moore_noexpr",
                        "cut_sources_restore_moore_noexpr", "cut_sources_hold_restore_moore_noexpr")
    noexpr_modes = ("none", "install_b_expression", "install_c_b_expression", "install_moore_expression")
    if args.target_mode:
        rows = [run(kernel, True, "none", references), run(kernel, False, "none", references),
                run(kernel, True, args.target_mode, references)]
    elif args.base_only:
        rows = [run(kernel, True, "none", references), run(kernel, False, "none", references)]
    else:
        rows = [run(kernel, True, mode, references) for mode in expression_modes]
        rows += [run(kernel, False, mode, references) for mode in noexpr_modes]
    base_expr = next(row for row in rows if row["expression"] and row["mode"] == "none")
    base_free = next(row for row in rows if not row["expression"] and row["mode"] == "none")
    restored = [row["mode"] for row in rows if row["expression"] and row["post_first_write_count"] > 0]
    installed_block = [row["mode"] for row in rows if not row["expression"] and row["mode"] != "none" and row["post_first_write_count"] == 0]
    result = seal({
        "schema": "dee.v27.ing03.rw3.recurrent_writer_blocker_control.v1",
        "question": "Does the validated persistent writer retain later write opportunities without expression and lose them after the RW2 interface appears?",
        "design": {"first_native_consequence_tick": 9, "expression_first_tick": 24,
                   "persistent_writer_target": "b", "horizon": 512,
                   "diagnostic_writer_insertion_tick": INTERVENTION_TICK,
                   "diagnostic_writer_clock": INTERVENTION_TICK,
                   "writer_insertion_is_host_diagnostic_not_native_capability": True},
        "rows": rows,
        "base_only": args.base_only,
        "summary": {"positive_control_post_first_writes": base_free["post_first_write_count"],
                    "expression_post_first_writes": base_expr["post_first_write_count"],
                    "paired_blockade_observed": base_free["post_first_write_count"] > 0 and base_expr["post_first_write_count"] == 0,
                    "expression_modes_restoring_write": restored,
                    "installed_expression_conditions_blocking": installed_block,
                    "necessary_and_sufficient_candidate_found": bool(restored and installed_block)},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_RW3_R03_RECURRENT_WRITER_BLOCKER_CONTROL.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
