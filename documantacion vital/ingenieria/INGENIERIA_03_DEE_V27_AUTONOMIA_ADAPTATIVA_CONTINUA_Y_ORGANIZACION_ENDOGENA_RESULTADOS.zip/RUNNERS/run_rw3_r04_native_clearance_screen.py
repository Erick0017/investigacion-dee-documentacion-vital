#!/usr/bin/env python3
"""Screen causally distinct 3D collisions for native post-expression clearance."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB, policy_class

P = (1, 0, 0); S1 = (-1, -1, 0); S2 = (-1, 1, 0); N1 = (1, 0, -1); N2 = (1, 0, 1)
EXPRESSION_DISTANCE = 24
CLEARANCE_DISTANCE = 32


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0):
    if int(raw[q]):
        raise RuntimeError(f"overlap {q}")
    raw[q] = pack(state, sreg, direction, semantic); clock[q] = np.uint64(phase)


def base_world(kernel, clearance, n=41, expression=True):
    raw = np.zeros((n, n, n), np.uint64); clock = np.zeros_like(raw)
    c = (n // 2,) * 3; a = add(c, P, -1, n); b = add(c, P, 1, n)
    put(raw, clock, a, 1000, 100, semantic=1, phase=252)
    put(raw, clock, b, 2000, 100, semantic=1, phase=252)
    for index, rel in enumerate(PA): put(raw, clock, add(a, rel, 1, n), 3000 + index, 0, semantic=4, phase=31 + index)
    for index, rel in enumerate(PB): put(raw, clock, add(b, rel, 1, n), 4000 + index, 0, semantic=4, phase=41 + index)
    # One native consequence, validated distance 6, writes A at tick 9.
    event = add(a, (0, -1, 0), 1, n); generator = add(event, (0, 0, 1), -6, n)
    for branch, direction in enumerate(((1, 0, 1), (-1, 0, 1))):
        put(raw, clock, add(generator, direction, -1, n), 5000 + branch, 3, direction, 1, 0)
    # One finite, state-independent four-carrier expression pulse arriving at tick 24.
    if expression:
        qp = add(c, P, 1, n)
        specs = ((add(qp, S1, -EXPRESSION_DISTANCE, n), S1, 11),
                 (add(qp, S2, -EXPRESSION_DISTANCE, n), S2, 13),
                 (add(c, N1, -EXPRESSION_DISTANCE, n), N1, 17),
                 (add(c, N2, -EXPRESSION_DISTANCE, n), N2, 19))
        for index, (q, direction, sreg) in enumerate(specs):
            put(raw, clock, q, 6000 + index, sreg, direction, 1, 100)
    clearance_positions = []
    if clearance["kind"] != "none":
        target = c if clearance["target"] == "c" else add(c, N2, 1, n)
        directions = [tuple(clearance["direction"])]
        if clearance["kind"] == "opposed_pair":
            directions.append(tuple(-v for v in clearance["direction"]))
        semantic = 4 if clearance["kind"] == "persistent_source" else 1
        for index, direction in enumerate(directions):
            q = add(target, direction, -CLEARANCE_DISTANCE, n)
            put(raw, clock, q, 8000 + index, clearance["sreg"], direction, semantic, 0)
            clearance_positions.append(q)
    return NativeWorld(kernel, raw, clock), {"n": n, "a": a, "b": b, "c": c,
        "qd": add(c, N2, 1, n), "clearance_positions": clearance_positions}


def run(kernel, clearance, horizon=64):
    try:
        world, meta = base_world(kernel, clearance)
    except RuntimeError as exc:
        return {"clearance": clearance, "valid": False, "reason": str(exc)}
    trace = []; c_absent_after = []; qd_absent_after = []; local_digest = hashlib.sha256()
    master_intact = True; expression_class = None
    for tick in range(1, horizon + 1):
        world.tick(); ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        c_record, qd_record = read(world.raw, meta["c"]), read(world.raw, meta["qd"])
        if tick == EXPRESSION_DISTANCE: expression_class = policy_class(c_record)
        if tick > CLEARANCE_DISTANCE:
            if c_record is None: c_absent_after.append(tick)
            if qd_record is None: qd_absent_after.append(tick)
            local_digest.update(int(world.raw[meta["c"]]).to_bytes(8, "little"))
            local_digest.update(int(world.raw[meta["qd"]]).to_bytes(8, "little"))
        if delta != 1 and tick >= 9: master_intact = False
        if tick in (8, 9, 10, 23, 24, 25, 31, 32, 33, 34, 40, 48, 56, 64):
            trace.append({"tick": tick, "delta": delta, "c": c_record, "qd": qd_record,
                          "class": policy_class(c_record)})
    return {"clearance": clearance, "valid": True, "expression_class_tick24": expression_class,
            "master_delta_preserved_through64": master_intact,
            "c_absent_ticks_33_64": c_absent_after,
            "qd_absent_ticks_33_64": qd_absent_after,
            "post_clear_local_sha256": local_digest.hexdigest(),
            "clearance_initial_positions_nonzero_terminal": sum(int(world.raw[q]) != 0 for q in meta["clearance_positions"]),
            "trace": trace, "python_interventions_after_t0": 0}


def candidates():
    directions = ((1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1),
                  (0,1,1),(0,1,-1),(0,-1,1),(0,-1,-1),
                  (1,1,1),(1,1,-1),(1,-1,1),(1,-1,-1),
                  (-1,1,1),(-1,1,-1),(-1,-1,1),(-1,-1,-1))
    rows = [{"kind": "none", "target": "c", "direction": [0,0,0], "sreg": 0}]
    for target in ("c", "qd"):
        for direction in directions:
            for sreg in (0, 19):
                rows.append({"kind": "single_finite", "target": target, "direction": list(direction), "sreg": sreg})
    for direction in directions[::2]:
        for sreg in (0, 19):
            rows.append({"kind": "opposed_pair", "target": "c", "direction": list(direction), "sreg": sreg})
    for direction in ((0,1,0),(0,0,1),(1,1,1),(-1,1,1)):
        for sreg in (0, 19):
            rows.append({"kind": "persistent_source", "target": "c", "direction": list(direction), "sreg": sreg})
    return rows


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, candidate) for candidate in candidates()]
    base = rows[0]
    changed = [row for row in rows[1:] if row.get("valid") and row["post_clear_local_sha256"] != base["post_clear_local_sha256"]]
    clearance = [row for row in changed if row["master_delta_preserved_through64"] and row["c_absent_ticks_33_64"]]
    result = seal({
        "schema": "dee.v27.ing03.rw3.native_clearance_screen.v1",
        "question": "Can a t0-complete 3D collision arriving after finite expression natively vacate or transform the blocking local regime while preserving learned delta?",
        "design": {"native_write_tick": 9, "finite_expression_tick": 24,
                   "clearance_nominal_tick": CLEARANCE_DISTANCE, "horizon": 64,
                   "families": ["single finite collision", "opposed-pair collision", "persistent-source collision"],
                   "targets": ["comparator c", "post-expression diagonal qd"],
                   "all_components_at_t0": True},
        "rows": rows,
        "summary": {"candidate_count": len(rows) - 1, "valid_count": sum(row.get("valid", False) for row in rows),
                    "changed_local_regime_count": len(changed), "clearance_screen_count": len(clearance),
                    "clearance_candidates": [row["clearance"] for row in clearance]},
        "claim_guard": "Local vacancy is a screen only. Write-reopen requires a validated later writer and master-state preservation; native RW3 requires all writes and cycles at t0 without host insertion.",
        "runtime": runtime,
    })
    output = ROOT / "DISCOVERY/ING03_RW3_R04_NATIVE_CLEARANCE_SCREEN.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
