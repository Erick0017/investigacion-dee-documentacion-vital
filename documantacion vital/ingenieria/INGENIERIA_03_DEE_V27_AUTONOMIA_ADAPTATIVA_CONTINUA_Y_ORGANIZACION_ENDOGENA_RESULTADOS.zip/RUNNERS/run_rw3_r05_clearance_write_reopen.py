#!/usr/bin/env python3
"""Functionally test each distinct R04 local transformation for write reopening."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, read, seal, write_json
from run_rw3_r04_native_clearance_screen import base_world

INSERT_TICK = 40
HORIZON = 180


def inject_writer(world, meta):
    target = meta["b"]; event = add(target, (0, -1, 0), 1, meta["n"])
    q = add(event, (0, 0, 1), -3, meta["n"]); raw = pack(9100, 0, (0, 0, 1), 4)
    if int(world.raw_a[q]) or int(world.raw_b[q]):
        return {"installed": False, "q": list(q), "overlap_raw": int(world.raw_a[q])}
    for array in (world.raw_a, world.raw_b): array[q] = raw
    for array in (world.clock_a, world.clock_b): array[q] = np.uint64(INSERT_TICK)
    return {"installed": True, "q": list(q), "raw": int(raw), "clock": INSERT_TICK}


def run(kernel, clearance, expression=True):
    try:
        world, meta = base_world(kernel, clearance, expression=expression)
    except RuntimeError as exc:
        return {"clearance": clearance, "expression": expression, "valid": False, "reason": str(exc)}
    transitions = []; previous = 0; injection = None; trace = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == INSERT_TICK:
            injection = inject_writer(world, meta)
        ra, rb = read(world.raw, meta["a"]), read(world.raw, meta["b"])
        delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
        if delta != previous:
            transitions.append({"tick": tick, "before": previous, "after": delta})
        if tick in (8,9,10,23,24,25,31,32,33,39,40,41,64,96,128,138,139,140,160,180):
            trace.append({"tick": tick, "delta": delta, "c": read(world.raw, meta["c"]),
                          "qd": read(world.raw, meta["qd"])})
        previous = delta
    later = [event for event in transitions if event["tick"] > INSERT_TICK]
    return {"clearance": clearance, "expression": expression, "valid": True,
            "writer_injection": injection, "transitions": transitions,
            "post_insertion_transitions": later, "write_reopened": bool(later),
            "terminal_delta": previous, "trace": trace,
            "python_interventions_after_t0": 1,
            "claim_guard": "Writer insertion is diagnostic; even a positive clearance is not native RW3."}


def main():
    kernel, runtime = load_kernel(1)
    source = json.loads((ROOT / "DISCOVERY/ING03_RW3_R04_NATIVE_CLEARANCE_SCREEN.json").read_text(encoding="utf-8"))
    base_signature = source["rows"][0]["post_clear_local_sha256"]
    representatives = []; seen = set()
    for row in source["rows"][1:]:
        if not row.get("valid") or not row.get("master_delta_preserved_through64"):
            continue
        signature = row["post_clear_local_sha256"]
        if signature == base_signature or signature in seen:
            continue
        seen.add(signature); representatives.append(row["clearance"])
    none = {"kind": "none", "target": "c", "direction": [0,0,0], "sreg": 0}
    controls = [run(kernel, none, expression=False), run(kernel, none, expression=True)]
    rows = [run(kernel, candidate, expression=True) for candidate in representatives]
    reopened = [row for row in rows if row.get("write_reopened")]
    result = seal({
        "schema": "dee.v27.ing03.rw3.clearance_write_reopen.v1",
        "question": "Does any causally distinct native post-expression transformation restore the next validated recurrent-writer opportunity?",
        "design": {"source_screen": "DISCOVERY/ING03_RW3_R04_NATIVE_CLEARANCE_SCREEN.json",
                   "one_representative_per_distinct_local_signature": True,
                   "native_first_write_tick": 9, "finite_expression_tick": 24,
                   "native_clearance_tick": 32, "diagnostic_writer_insertion_tick": INSERT_TICK,
                   "first_expected_writer_opportunity": 139, "horizon": HORIZON},
        "controls": controls, "rows": rows,
        "summary": {"distinct_signature_representatives": len(representatives),
                    "positive_control_reopens": controls[0].get("write_reopened"),
                    "blocked_control_reopens": controls[1].get("write_reopened"),
                    "native_clearance_write_reopen_count": len(reopened),
                    "reopened_candidates": [row["clearance"] for row in reopened]},
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_RW3_R05_CLEARANCE_WRITE_REOPEN.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"], "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
