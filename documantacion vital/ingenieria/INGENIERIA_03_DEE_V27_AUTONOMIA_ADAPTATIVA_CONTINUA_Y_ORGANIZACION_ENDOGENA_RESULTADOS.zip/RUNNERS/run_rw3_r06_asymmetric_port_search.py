#!/usr/bin/env python3
"""Search signed/permuted 3D consequence ports after finite RW2 expression."""
from __future__ import annotations

import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, transform, write_json
from run_nature_n04_dynamic_temporal_expression import PA, PB

P=(1,0,0); S1=(-1,-1,0); S2=(-1,1,0); N1=(1,0,-1); N2=(1,0,1)
N=29; EXPRESSION_DISTANCE=16; INSERT_TICK=24; HORIZON=160


def put(raw, clock, q, state, sreg, direction=(0,0,0), semantic=1, phase=0):
    if int(raw[q]): raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic); clock[q]=np.uint64(phase)


def build(kernel, expression):
    raw=np.zeros((N,N,N),np.uint64); clock=np.zeros_like(raw); c=(N//2,)*3
    a=add(c,P,-1,N); b=add(c,P,1,N)
    put(raw,clock,a,1000,100,semantic=1,phase=252); put(raw,clock,b,2000,100,semantic=1,phase=252)
    for i,o in enumerate(PA): put(raw,clock,add(a,o,1,N),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB): put(raw,clock,add(b,o,1,N),4000+i,0,semantic=4,phase=41+i)
    event=add(a,(0,-1,0),1,N); generator=add(event,(0,0,1),-6,N)
    for i,d in enumerate(((1,0,1),(-1,0,1))): put(raw,clock,add(generator,d,-1,N),5000+i,3,d,1,0)
    if expression:
        qp=add(c,P,1,N)
        specs=((add(qp,S1,-EXPRESSION_DISTANCE,N),S1,11),(add(qp,S2,-EXPRESSION_DISTANCE,N),S2,13),
               (add(c,N1,-EXPRESSION_DISTANCE,N),N1,17),(add(c,N2,-EXPRESSION_DISTANCE,N),N2,19))
        for i,(q,d,s) in enumerate(specs): put(raw,clock,q,6000+i,s,d,1,100)
    return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"c":c,"n":N}


def inject_writer(world,meta,permutation,signs):
    tf=lambda v:transform(v,permutation,signs); target=meta["b"]
    event=add(target,tf((0,-1,0)),1,N); direction=tf((0,0,1)); q=add(event,direction,-3,N)
    raw=pack(9100,0,direction,4)
    if int(world.raw_a[q]) or int(world.raw_b[q]):
        return {"installed":False,"q":list(q),"overlap_raw":int(world.raw_a[q]),"event":list(event),"direction":list(direction)}
    for x in (world.raw_a,world.raw_b): x[q]=raw
    for x in (world.clock_a,world.clock_b): x[q]=np.uint64(INSERT_TICK)
    return {"installed":True,"q":list(q),"raw":int(raw),"clock":INSERT_TICK,"event":list(event),"direction":list(direction)}


def run(kernel,frame_id,permutation,signs,expression):
    try: world,meta=build(kernel,expression)
    except RuntimeError as exc: return {"frame_id":frame_id,"valid":False,"reason":str(exc),"expression":expression}
    transitions=[];previous=0;injection=None
    for tick in range(1,HORIZON+1):
        world.tick()
        if tick==INSERT_TICK: injection=inject_writer(world,meta,permutation,signs)
        ra,rb=read(world.raw,meta["a"]),read(world.raw,meta["b"])
        delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"])
        if delta!=previous: transitions.append({"tick":tick,"before":previous,"after":delta})
        previous=delta
    later=[e for e in transitions if e["tick"]>INSERT_TICK]
    return {"frame_id":frame_id,"permutation":list(permutation),"signs":list(signs),"expression":expression,
            "valid":True,"writer_injection":injection,"transitions":transitions,
            "post_insertion_transitions":later,"later_write":bool(later),"terminal_delta":previous,
            "python_interventions_after_t0":1,"claim_guard":"Diagnostic port insertion only; not native RW3."}


def main():
    kernel,runtime=load_kernel(1)
    frames=[(i,p,s) for i,(p,s) in enumerate(itertools.product(itertools.permutations((0,1,2)),itertools.product((-1,1),repeat=3)))]
    rows=[]
    for frame_id,permutation,signs in frames:
        rows.append(run(kernel,frame_id,permutation,signs,False))
        rows.append(run(kernel,frame_id,permutation,signs,True))
    groups=[]
    for frame_id,permutation,signs in frames:
        control=next(r for r in rows if r["frame_id"]==frame_id and not r["expression"])
        treatment=next(r for r in rows if r["frame_id"]==frame_id and r["expression"])
        groups.append({"frame_id":frame_id,"permutation":list(permutation),"signs":list(signs),
                       "control_valid_write":control.get("later_write",False),
                       "post_expression_write":treatment.get("later_write",False),
                       "asymmetric_port_candidate":control.get("later_write",False) and treatment.get("later_write",False)})
    candidates=[g for g in groups if g["asymmetric_port_candidate"]]
    result=seal({"schema":"dee.v27.ing03.rw3.asymmetric_port_search.v1",
        "question":"Can a causally distinct signed/permuted 3D consequence surface write B after the finite expression interface has formed?",
        "design":{"frame_count":len(frames),"paired_worlds":len(rows),"n":N,
                  "native_first_write_tick":9,"finite_expression_tick":EXPRESSION_DISTANCE,
                  "diagnostic_writer_insertion_tick":INSERT_TICK,"horizon":HORIZON,
                  "same_frame_control_for_every_treatment":True},
        "rows":rows,"groups":groups,
        "summary":{"valid_positive_controls":sum(g["control_valid_write"] for g in groups),
                   "asymmetric_port_candidate_count":len(candidates),
                   "candidate_frames":candidates},
        "runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_RW3_R06_ASYMMETRIC_PORT_SEARCH.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
