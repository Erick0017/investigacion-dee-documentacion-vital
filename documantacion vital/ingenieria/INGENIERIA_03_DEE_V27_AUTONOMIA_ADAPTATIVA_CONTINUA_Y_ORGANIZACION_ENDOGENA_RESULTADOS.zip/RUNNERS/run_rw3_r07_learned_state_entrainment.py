#!/usr/bin/env python3
"""Compose native consequence-written master states with the remote receiver."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_landscape_l04_coupling_mechanism_controls import periods
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value

OFFSET=(-3,4,5); HORIZON=768


def build(kernel,target,generator_mode="treatment",source_cut=()):
    world,meta=build_consequence(kernel,target,generator_mode=generator_mode,with_transducer=True,
                                 n=29,memory_phase=252,consequence_distance=6)
    q_b=add(meta["c"],OFFSET,1,meta["n"])
    organ_b=put_transducer(world.raw_a,world.clock_a,q_b,meta["n"],9000)
    world.raw_b[:]=world.raw_a;world.clock_b[:]=world.clock_a
    for index in source_cut:
        q=meta["transducer_sources"][index][0]
        world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
    meta=dict(meta);meta.update({"q_b":q_b,"qp_b":add(q_b,P,1,meta["n"]),"organ_b":organ_b})
    return world,meta


def digest(sequence):
    h=hashlib.sha256()
    for pair in sequence:
        for raw in pair:h.update(int(raw).to_bytes(8,"little"))
    return h.hexdigest()


def run(kernel,target,generator_mode="treatment",source_cut=()):
    try:world,meta=build(kernel,target,generator_mode,source_cut)
    except RuntimeError as exc:return {"target":target,"valid":False,"reason":str(exc),"source_cut":list(source_cut)}
    pairs=[];deltas=[];transitions=[];previous=0
    for tick in range(1,HORIZON+1):
        world.tick();delta=delta_value(world,meta);deltas.append(delta)
        if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
        pairs.append((int(world.raw[meta["q_b"]]),int(world.raw[meta["qp_b"]])))
        previous=delta
    windows=[]
    for start,end in ((1,256),(257,512),(513,768)):
        sequence=pairs[start-1:end]
        windows.append({"start":start,"end":end,"periods":periods(sequence),"raw_sha256":digest(sequence)})
    return {"target":target,"generator_mode":generator_mode,"source_cut":list(source_cut),"valid":True,
            "master_transitions":transitions,"master_delta_terminal":deltas[-1],"master_delta_unique":sorted({d for d in deltas if d is not None}),
            "receiver_windows":windows,"receiver_terminal_signature":windows[-1]["raw_sha256"],
            "receiver_terminal_periods":windows[-1]["periods"],"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1)
    discovery=[run(kernel,target) for target in ("a","b",None)]
    generator_canaries=[run(kernel,target,mode) for target in ("a","b") for mode in ("missing_d1","missing_d2","wrong_cancel")]
    coupling_canaries=[run(kernel,target,source_cut=(0,1,3)) for target in ("a","b")]
    signatures={str(row["target"]):row.get("receiver_terminal_signature") for row in discovery}
    periods_by_target={str(row["target"]):row.get("receiver_terminal_periods") for row in discovery}
    result=seal({"schema":"dee.v27.ing03.rw3.learned_state_entrainment.v1",
        "question":"Can a native consequence select a later remote temporal receiver regime through the existing local coupling path?",
        "design":{"native_targets":["a","b","sham"],"offset":list(OFFSET),"horizon":HORIZON,
                  "same_initial_clock_geometry_receiver":True,"all_components_at_t0":True},
        "discovery":discovery,"generator_canaries":generator_canaries,"coupling_canaries":coupling_canaries,
        "summary":{"terminal_signatures":signatures,"terminal_periods":periods_by_target,
                   "distinct_native_target_signatures":len(set(signatures.values())),
                   "a_b_receiver_distinct":signatures["a"]!=signatures["b"],
                   "opposite_native_master_states":discovery[0].get("master_delta_terminal",0)*discovery[1].get("master_delta_terminal",0)<0,
                   "generator_canaries_block_learning":all(not row.get("master_transitions") for row in generator_canaries),
                   "coupling_cut_changes_receiver":all(row.get("receiver_terminal_signature") not in (signatures[str(row["target"])],None) for row in coupling_canaries)},
        "claim_guard":"Distinct receiver regimes establish learned state-selected coupling only if generator and route canaries agree. RW3 additionally requires a second native master write while coupled.",
        "runtime":runtime})
    output=ROOT/"DISCOVERY/ING03_RW3_R07_LEARNED_STATE_ENTRAINMENT.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
