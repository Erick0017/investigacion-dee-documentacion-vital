#!/usr/bin/env python3
"""Correct learned-entrainment composition: learn first, couple later."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, read, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
from run_landscape_l04_coupling_mechanism_controls import periods
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence, delta_value

OFFSET=(-3,4,5); HORIZON=768; SOURCE_DISTANCE=24


def build(kernel,target,generator_mode="treatment",source_cut=(),receiver=True):
    world,meta=build_consequence(kernel,target,generator_mode=generator_mode,with_transducer=False,
                                 n=41,memory_phase=252,consequence_distance=6)
    sources=add_delayed_sources(world,meta,SOURCE_DISTANCE)
    for index in source_cut:
        q=sources[index][0];world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
    if receiver:
        q_b=add(meta["c"],OFFSET,1,meta["n"]);organ_b=put_transducer(world.raw_a,world.clock_a,q_b,meta["n"],9000)
        world.raw_b[:]=world.raw_a;world.clock_b[:]=world.clock_a
        meta=dict(meta);meta.update({"q_b":q_b,"qp_b":add(q_b,P,1,meta["n"]),"organ_b":organ_b})
    return world,meta


def digest(sequence):
    h=hashlib.sha256()
    for pair in sequence:
        for raw in pair:h.update(int(raw).to_bytes(8,"little"))
    return h.hexdigest()


def run(kernel,target,generator_mode="treatment",source_cut=(),receiver=True):
    try:world,meta=build(kernel,target,generator_mode,source_cut,receiver)
    except RuntimeError as exc:return {"target":target,"valid":False,"reason":str(exc),"source_cut":list(source_cut),"receiver":receiver}
    pairs=[];transitions=[];previous=0
    for tick in range(1,HORIZON+1):
        world.tick();delta=delta_value(world,meta)
        if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
        if receiver:pairs.append((int(world.raw[meta["q_b"]]),int(world.raw[meta["qp_b"]])))
        previous=delta
    windows=[]
    if receiver:
        for start,end in ((1,256),(257,512),(513,768)):
            seq=pairs[start-1:end];windows.append({"start":start,"end":end,"periods":periods(seq),"raw_sha256":digest(seq)})
    return {"target":target,"generator_mode":generator_mode,"source_cut":list(source_cut),"receiver":receiver,"valid":True,
            "master_transitions":transitions,"master_delta_terminal":previous,
            "receiver_windows":windows,"receiver_terminal_signature":None if not windows else windows[-1]["raw_sha256"],
            "receiver_terminal_periods":None if not windows else windows[-1]["periods"],"python_interventions_after_t0":0}


def main():
    kernel,runtime=load_kernel(1)
    discovery=[run(kernel,target) for target in ("a","b",None)]
    no_receiver=[run(kernel,target,receiver=False) for target in ("a","b",None)]
    generator_canaries=[run(kernel,target,mode) for target in ("a","b") for mode in ("missing_d1","missing_d2","wrong_cancel")]
    coupling_canaries=[run(kernel,target,source_cut=(0,1,3)) for target in ("a","b")]
    signatures={str(r["target"]):r.get("receiver_terminal_signature") for r in discovery}
    result=seal({"schema":"dee.v27.ing03.rw3.delayed_learned_entrainment.v1",
        "question":"After native A/B learning and a stored interval, can delayed coupling select distinct remote temporal regimes without sham writing?",
        "design":{"native_write_tick":9,"delayed_transducer_first_arrival":24,"offset":list(OFFSET),
                  "horizon":HORIZON,"all_components_at_t0":True,"same_receiver_clock_geometry":True},
        "discovery":discovery,"no_receiver_controls":no_receiver,"generator_canaries":generator_canaries,"coupling_canaries":coupling_canaries,
        "summary":{"master_terminal_by_target":{str(r["target"]):r.get("master_delta_terminal") for r in discovery},
                   "opposite_a_b_master_states":discovery[0].get("master_delta_terminal",0)*discovery[1].get("master_delta_terminal",0)<0,
                   "sham_master_remains_zero":discovery[2].get("master_delta_terminal")==0 and not discovery[2].get("master_transitions"),
                   "terminal_signatures":signatures,"a_b_receiver_distinct":signatures["a"]!=signatures["b"],
                   "generator_canaries_block_learning":all(not r.get("master_transitions") for r in generator_canaries),
                   "coupling_cut_changes_receiver":all(r.get("receiver_terminal_signature") not in (signatures[str(r["target"])],None) for r in coupling_canaries)},
        "claim_guard":"RW2-like learned entrainment requires all causal predicates. RW3 still requires another consequence-written reversal while the receiver remains functional.",
        "runtime":runtime})
    output=ROOT/"MECHANISM_SELECTION/ING03_RW3_R08_DELAYED_LEARNED_ENTRAINMENT.json";write_json(output,result)
    print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
