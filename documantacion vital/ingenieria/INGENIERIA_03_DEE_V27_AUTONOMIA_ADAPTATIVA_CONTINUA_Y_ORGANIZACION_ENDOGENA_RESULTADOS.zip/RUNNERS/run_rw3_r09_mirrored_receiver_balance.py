#!/usr/bin/env python3
"""Test whether mirrored remote receivers cancel write backaction but retain expression."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,add,load_kernel,seal,write_json
from run_landscape_l03_two_organ_coupling_search import P,put_transducer
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence,delta_value

HORIZON=512
ARRANGEMENTS={
 "single_pos":[(-2,3,4)],
 "single_neg":[(-2,-3,4)],
 "mirror_pair_234":[(-2,3,4),(-2,-3,4)],
 "mirror_pair_345":[(-3,4,5),(-3,-4,5)],
}


def joint_digest(sequences):
 h=hashlib.sha256()
 for tick in range(len(sequences[0])):
  for sequence in sequences:
   for raw in sequence[tick]:h.update(int(raw).to_bytes(8,"little"))
 return h.hexdigest()


def run(kernel,target,name,offsets):
 try:
  world,meta=build_consequence(kernel,target,with_transducer=False,n=41,memory_phase=252,consequence_distance=6)
  add_delayed_sources(world,meta,24);ports=[]
  for index,offset in enumerate(offsets):
   q=add(meta["c"],offset,1,meta["n"]);put_transducer(world.raw_a,world.clock_a,q,meta["n"],9000+1000*index)
   ports.append((q,add(q,P,1,meta["n"])))
  world.raw_b[:]=world.raw_a;world.clock_b[:]=world.clock_a
 except RuntimeError as exc:return {"arrangement":name,"target":target,"valid":False,"reason":str(exc)}
 sequences=[[] for _ in ports];transitions=[];previous=0
 for tick in range(1,HORIZON+1):
  world.tick();delta=delta_value(world,meta)
  if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
  for sequence,(q,qp) in zip(sequences,ports):sequence.append((int(world.raw[q]),int(world.raw[qp])))
  previous=delta
 suffix=[sequence[256:] for sequence in sequences]
 return {"arrangement":name,"offsets":[list(x) for x in offsets],"target":target,"valid":True,
         "master_transitions":transitions,"master_delta_terminal":previous,
         "receiver_joint_suffix_sha256":joint_digest(suffix),"receiver_count":len(ports),"python_interventions_after_t0":0}


def main():
 kernel,runtime=load_kernel(1);rows=[]
 for name,offsets in ARRANGEMENTS.items():
  for target in ("a","b",None):rows.append(run(kernel,target,name,offsets))
 groups=[]
 for name in ARRANGEMENTS:
  subset=[r for r in rows if r["arrangement"]==name and r.get("valid")];by={str(r["target"]):r for r in subset}
  if len(by)!=3:groups.append({"arrangement":name,"valid":False});continue
  groups.append({"arrangement":name,"valid":True,
    "master_terminal":{"a":by["a"]["master_delta_terminal"],"b":by["b"]["master_delta_terminal"],"sham":by["None"]["master_delta_terminal"]},
    "sham_stable_zero":by["None"]["master_delta_terminal"]==0 and not by["None"]["master_transitions"],
    "opposite_a_b":by["a"]["master_delta_terminal"]*by["b"]["master_delta_terminal"]<0,
    "a_b_remote_distinct":by["a"]["receiver_joint_suffix_sha256"]!=by["b"]["receiver_joint_suffix_sha256"],
    "balanced_expression_candidate":by["None"]["master_delta_terminal"]==0 and by["a"]["master_delta_terminal"]*by["b"]["master_delta_terminal"]<0 and by["a"]["receiver_joint_suffix_sha256"]!=by["b"]["receiver_joint_suffix_sha256"]})
 candidates=[g for g in groups if g.get("balanced_expression_candidate")]
 result=seal({"schema":"dee.v27.ing03.rw3.mirrored_receiver_balance.v1",
  "question":"Can a mirrored 3D receiver organization cancel receiver-induced master writing while preserving A/B-dependent remote dynamics?",
  "arrangements":{k:[list(x) for x in v] for k,v in ARRANGEMENTS.items()},"rows":rows,"groups":groups,
  "summary":{"valid_groups":sum(g.get("valid",False) for g in groups),"balanced_candidate_count":len(candidates),"candidates":candidates},
  "claim_guard":"A balanced candidate would still require route canaries, later reversal and write-reopen before RW3.","runtime":runtime})
 output=ROOT/"DISCOVERY/ING03_RW3_R09_MIRRORED_RECEIVER_BALANCE.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
