#!/usr/bin/env python3
"""Mechanism controls and post-expression writability for the (-2,3,4) receiver."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,add,load_kernel,pack,read,seal,write_json
from run_landscape_l03_two_organ_coupling_search import P,put_transducer
from run_landscape_l04_coupling_mechanism_controls import periods
from run_landscape_l05_delayed_native_expression import add_delayed_sources
from run_nature_n07_native_consequence_expression import build as build_consequence,delta_value

OFFSET=(-2,3,4);HORIZON=512;INSERT_TICK=40


def digest(sequence):
 h=hashlib.sha256()
 for pair in sequence:
  for raw in pair:h.update(int(raw).to_bytes(8,"little"))
 return h.hexdigest()


def build(kernel,target,generator_mode="treatment",source_cut=(),receiver_mode="candidate",expression=True):
 world,meta=build_consequence(kernel,target,generator_mode=generator_mode,with_transducer=False,n=41,memory_phase=252,consequence_distance=6)
 sources=add_delayed_sources(world,meta,24) if expression else []
 for index in source_cut:
  q=sources[index][0];world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
 if receiver_mode!="absent":
  offset=OFFSET if receiver_mode=="candidate" else (2,3,4)
  q=add(meta["c"],offset,1,meta["n"]);put_transducer(world.raw_a,world.clock_a,q,meta["n"],9000)
  world.raw_b[:]=world.raw_a;world.clock_b[:]=world.clock_a
  meta=dict(meta);meta.update({"q_receiver":q,"qp_receiver":add(q,P,1,meta["n"]),"receiver_offset":offset})
 return world,meta


def run_state(kernel,label,target,generator_mode="treatment",source_cut=(),receiver_mode="candidate",expression=True):
 try:world,meta=build(kernel,target,generator_mode,source_cut,receiver_mode,expression)
 except RuntimeError as exc:return {"label":label,"valid":False,"reason":str(exc)}
 pairs=[];transitions=[];previous=0
 for tick in range(1,HORIZON+1):
  world.tick();delta=delta_value(world,meta)
  if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
  if receiver_mode!="absent":pairs.append((int(world.raw[meta["q_receiver"]]),int(world.raw[meta["qp_receiver"]])))
  previous=delta
 suffix=pairs[256:] if pairs else []
 return {"label":label,"target":target,"generator_mode":generator_mode,"source_cut":list(source_cut),
  "receiver_mode":receiver_mode,"expression":expression,"valid":True,"master_transitions":transitions,
  "master_delta_terminal":previous,"receiver_suffix_sha256":None if not suffix else digest(suffix),
  "receiver_suffix_periods":None if not suffix else periods(suffix),"python_interventions_after_t0":0}


def inject_writer(world,meta):
 target=meta["b"];event=add(target,(0,-1,0),1,meta["n"]);q=add(event,(0,0,1),-3,meta["n"]);raw=pack(9100,0,(0,0,1),4)
 if int(world.raw_a[q]) or int(world.raw_b[q]):return {"installed":False,"q":list(q),"overlap_raw":int(world.raw_a[q])}
 for x in (world.raw_a,world.raw_b):x[q]=raw
 for x in (world.clock_a,world.clock_b):x[q]=np.uint64(INSERT_TICK)
 return {"installed":True,"q":list(q),"raw":int(raw),"clock":INSERT_TICK}


def run_write_reopen(kernel,label,expression,receiver_mode):
 try:world,meta=build(kernel,"a",receiver_mode=receiver_mode,expression=expression)
 except RuntimeError as exc:return {"label":label,"valid":False,"reason":str(exc)}
 transitions=[];previous=0;injection=None
 for tick in range(1,181):
  world.tick()
  if tick==INSERT_TICK:injection=inject_writer(world,meta)
  delta=delta_value(world,meta)
  if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
  previous=delta
 later=[e for e in transitions if e["tick"]>INSERT_TICK]
 return {"label":label,"valid":True,"expression":expression,"receiver_mode":receiver_mode,
  "writer_injection":injection,"transitions":transitions,"post_insertion_transitions":later,
  "write_reopened":bool(later),"python_interventions_after_t0":1,
  "claim_guard":"Diagnostic writer insertion only; not native RW3."}


def main():
 kernel,runtime=load_kernel(1)
 state_rows=[run_state(kernel,f"learn_{target}",target) for target in ("a","b",None)]
 state_rows += [run_state(kernel,f"canary_{target}_{mode}",target,generator_mode=mode)
                for target in ("a","b") for mode in ("missing_d1","missing_d2","wrong_cancel")]
 state_rows += [run_state(kernel,f"cut_path_{target}",target,source_cut=(0,1,3)) for target in ("a","b")]
 state_rows += [run_state(kernel,f"spatial_sham_{target}",target,receiver_mode="spatial_sham") for target in ("a","b")]
 state_rows += [run_state(kernel,f"no_receiver_{target}",target,receiver_mode="absent") for target in ("a","b",None)]
 by={r["label"]:r for r in state_rows};a=by["learn_a"];b=by["learn_b"];sham=by["learn_None"]
 write_rows=[run_write_reopen(kernel,"candidate_coupled",True,"candidate"),
             run_write_reopen(kernel,"expression_no_receiver",True,"absent"),
             run_write_reopen(kernel,"receiver_no_expression",False,"candidate"),
             run_write_reopen(kernel,"neither",False,"absent")]
 result=seal({"schema":"dee.v27.ing03.rw3.state_selected_entrainment_controls.v1",
  "question":"Is the (-2,3,4) remote regime selected by consequence-written stored state, and does that coupling preserve a later write?",
  "design":{"offset":list(OFFSET),"native_write_tick":9,"coupling_first_arrival":24,"horizon":HORIZON,
            "diagnostic_writer_insertion_tick":INSERT_TICK,"all_state_claim_worlds_t0_complete":True},
  "state_rows":state_rows,"write_reopen_rows":write_rows,
  "summary":{"a_b_opposite":a["master_delta_terminal"]*b["master_delta_terminal"]<0,
             "sham_stable_zero":sham["master_delta_terminal"]==0 and not sham["master_transitions"],
             "a_b_remote_distinct":a["receiver_suffix_sha256"]!=b["receiver_suffix_sha256"],
             "a_periods":a["receiver_suffix_periods"],"b_periods":b["receiver_suffix_periods"],"sham_periods":sham["receiver_suffix_periods"],
             "generator_canaries_stable_zero":all(by[f"canary_{target}_{mode}"]["master_delta_terminal"]==0 for target in ("a","b") for mode in ("missing_d1","missing_d2","wrong_cancel")),
             "path_cut_changes_remote":all(by[f"cut_path_{target}"]["receiver_suffix_sha256"]!=by[f"learn_{target}"]["receiver_suffix_sha256"] for target in ("a","b")),
             "candidate_coupled_write_reopened":write_rows[0]["write_reopened"],
             "write_control_without_expression":write_rows[2]["write_reopened"] and write_rows[3]["write_reopened"]},
  "runtime":runtime})
 output=ROOT/"MECHANISM_SELECTION/ING03_RW3_R10_STATE_SELECTED_ENTRAINMENT_CONTROLS.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
