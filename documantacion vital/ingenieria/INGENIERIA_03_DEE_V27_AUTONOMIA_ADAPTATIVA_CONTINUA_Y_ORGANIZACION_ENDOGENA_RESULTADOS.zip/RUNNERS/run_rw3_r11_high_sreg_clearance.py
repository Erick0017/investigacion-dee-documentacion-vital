#!/usr/bin/env python3
"""Test high-s_reg finite collision clearance against a validated later writer."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,read,seal,write_json
from run_rw3_r04_native_clearance_screen import base_world
from run_rw3_r05_clearance_write_reopen import HORIZON,INSERT_TICK,inject_writer

SREGS=(31,255,4095,19664,19665,65535)
DIRECTIONS=((0,1,0),(0,-1,0),(0,0,1),(0,0,-1),(1,1,1),(-1,1,1))


def run(kernel,clearance,expression=True):
 try:world,meta=base_world(kernel,clearance,expression=expression)
 except RuntimeError as exc:return {"clearance":clearance,"expression":expression,"valid":False,"reason":str(exc)}
 transitions=[];previous=0;injection=None
 for tick in range(1,HORIZON+1):
  world.tick()
  if tick==INSERT_TICK:injection=inject_writer(world,meta)
  ra,rb=read(world.raw,meta["a"]),read(world.raw,meta["b"])
  delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"])
  if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
  previous=delta
 later=[event for event in transitions if event["tick"]>INSERT_TICK]
 return {"clearance":clearance,"expression":expression,"valid":True,"writer_injection":injection,
         "transitions":transitions,"post_insertion_transitions":later,"write_reopened":bool(later),
         "terminal_delta":previous,"python_interventions_after_t0":1,
         "claim_guard":"Only the writer insertion is diagnostic; the high-s_reg clearance is native and present at t0."}


def main():
 kernel,runtime=load_kernel(1);none={"kind":"none","target":"c","direction":[0,0,0],"sreg":0}
 controls=[run(kernel,none,False),run(kernel,none,True)];candidates=[]
 for target in ("c","qd"):
  for direction in DIRECTIONS:
   for sreg in SREGS:candidates.append({"kind":"single_finite","target":target,"direction":list(direction),"sreg":sreg})
 rows=[run(kernel,candidate,True) for candidate in candidates];reopened=[row for row in rows if row.get("write_reopened")]
 result=seal({"schema":"dee.v27.ing03.rw3.high_sreg_clearance.v1",
  "question":"Can a high-load finite 3D collision transform the post-expression interface into a write-compatible regime?",
  "design":{"legal_sreg_range":[0,65535],"levels":list(SREGS),"directions":[list(x) for x in DIRECTIONS],
            "targets":["c","qd"],"candidate_count":len(candidates),"native_write_tick":9,
            "expression_tick":24,"clearance_tick":32,"diagnostic_writer_tick":INSERT_TICK,"horizon":HORIZON},
  "controls":controls,"rows":rows,
  "summary":{"positive_control_reopens":controls[0].get("write_reopened"),"blocked_control_reopens":controls[1].get("write_reopened"),
             "valid_candidates":sum(row.get("valid",False) for row in rows),"write_reopen_count":len(reopened),
             "reopened_candidates":[row["clearance"] for row in reopened]},
  "runtime":runtime})
 output=ROOT/"MECHANISM_SELECTION/ING03_RW3_R11_HIGH_SREG_CLEARANCE.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
