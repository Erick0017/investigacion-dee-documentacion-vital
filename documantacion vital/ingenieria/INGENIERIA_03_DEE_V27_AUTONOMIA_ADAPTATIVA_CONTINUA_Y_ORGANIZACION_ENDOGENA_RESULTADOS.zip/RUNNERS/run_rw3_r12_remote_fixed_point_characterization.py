#!/usr/bin/env python3
"""Characterize latency and terminal microstate of learned remote fixed points."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,read,seal,write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value

HORIZON=512


def constant_suffix_start(sequence):
 terminal=sequence[-1];index=len(sequence)-1
 while index>0 and sequence[index-1]==terminal:index-=1
 return index+1


def run(kernel,target):
 world,meta=build(kernel,target)
 pairs=[];deltas=[]
 for _ in range(HORIZON):
  world.tick();pairs.append((int(world.raw[meta["q_receiver"]]),int(world.raw[meta["qp_receiver"]])));deltas.append(delta_value(world,meta))
 start=constant_suffix_start(pairs);q,qp=meta["q_receiver"],meta["qp_receiver"]
 return {"target":target,"master_delta_terminal":deltas[-1],"master_delta_unique":sorted({x for x in deltas if x is not None}),
  "terminal_constant_suffix_start":start,"terminal_constant_duration":HORIZON-start+1,
  "terminal_pair_raw":list(pairs[-1]),"terminal_pair_records":[read(world.raw,q),read(world.raw,qp)],
  "first_64_pair_changes":sum(pairs[i]!=pairs[i-1] for i in range(1,64)),
  "post256_pair_changes":sum(pairs[i]!=pairs[i-1] for i in range(256,HORIZON)),"python_interventions_after_t0":0}


def main():
 kernel,runtime=load_kernel(1);rows=[run(kernel,target) for target in ("a","b",None)];by={str(r["target"]):r for r in rows}
 result=seal({"schema":"dee.v27.ing03.rw3.remote_fixed_point_characterization.v1",
  "question":"When do consequence-selected remote regimes converge, and are A/B fixed points microstate-distinct under an answer-independent two-site observer?",
  "architecture":{"receiver_offset":[-2,3,4],"horizon":HORIZON,"observer":"both receiver sites every tick"},"rows":rows,
  "summary":{"a_b_terminal_distinct":by["a"]["terminal_pair_raw"]!=by["b"]["terminal_pair_raw"],
             "a_fixed_by_tick":by["a"]["terminal_constant_suffix_start"],"b_fixed_by_tick":by["b"]["terminal_constant_suffix_start"],
             "sham_not_fixed":by["None"]["terminal_constant_duration"]<128,
             "fresh_horizon_criterion":max(by["a"]["terminal_constant_suffix_start"],by["b"]["terminal_constant_suffix_start"])+128},
  "runtime":runtime})
 output=ROOT/"MECHANISM_SELECTION/ING03_RW3_R12_REMOTE_FIXED_POINT_CHARACTERIZATION.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
