#!/usr/bin/env python3
"""Frozen fresh signed/permuted holdout for consequence-selected remote fixed points."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,ROOT,add,canonical_hash,load_kernel,pack,read,seal,sha256_file,transform,write_json
from run_nature_n04_dynamic_temporal_expression import PA,PB

LOCK=ROOT/"FREEZE/ING03_RW3_REMOTE_FIXED_POINT_LOCK.json"
P=(1,0,0);S1=(-1,-1,0);S2=(-1,1,0);N1=(1,0,-1);N2=(1,0,1)


def put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
 if int(raw[q]):raise RuntimeError(f"overlap {q}")
 raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)


def put_transducer(raw,clock,c,n,tf,base):
 p=tf(P);qp=add(c,p,1,n);put(raw,clock,c,base,7,p,1,11)
 specs=((add(qp,tf(S1),-1,n),tf(S1),11),(add(qp,tf(S2),-1,n),tf(S2),13),
        (add(c,tf(N1),-2,n),tf(N1),17),(add(c,tf(N2),-2,n),tf(N2),19))
 for i,(q,d,s) in enumerate(specs):put(raw,clock,q,base+100+i,s,d,4,100+i)
 return c,qp


def build(kernel,frame,condition,n=41):
 permutation,signs=frame;tf=lambda v:transform(v,permutation,signs)
 raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw);c=(n//2,)*3;p=tf(P);a=add(c,p,-1,n);b=add(c,p,1,n)
 learner_positions=[]
 put(raw,clock,a,1000,100,semantic=1,phase=252);put(raw,clock,b,2000,100,semantic=1,phase=252);learner_positions.extend((a,b))
 for i,o in enumerate(PA):q=add(a,tf(o),1,n);put(raw,clock,q,3000+i,0,semantic=4,phase=31+i);learner_positions.append(q)
 for i,o in enumerate(PB):q=add(b,tf(o),1,n);put(raw,clock,q,4000+i,0,semantic=4,phase=41+i);learner_positions.append(q)
 environment_positions=[]
 if condition in ("learn_a","learn_b","broken_generator"):
  target=a if condition in ("learn_a","broken_generator") else b;event=add(target,tf((0,-1,0)),1,n);route=tf((0,0,1));generator=add(event,route,-6,n)
  directions=(tf((1,0,1)),tf((-1,0,1)))
  for i,d in enumerate(directions):
   if condition=="broken_generator" and i==0:continue
   q=add(generator,d,-1,n);put(raw,clock,q,5000+i,3,d,1,0);environment_positions.append(q)
 # Delayed master-expression transducer sources.
 qp=add(c,p,1,n);specs=((add(qp,tf(S1),-24,n),tf(S1),11),(add(qp,tf(S2),-24,n),tf(S2),13),
                         (add(c,tf(N1),-24,n),tf(N1),17),(add(c,tf(N2),-24,n),tf(N2),19))
 for i,(q,d,s) in enumerate(specs):put(raw,clock,q,6000+i,s,d,4,100+i);learner_positions.append(q)
 q_receiver=add(c,tf((-2,3,4)),1,n);q_receiver,qp_receiver=put_transducer(raw,clock,q_receiver,n,tf,9000)
 # Receiver is fixed learner machinery, not the environmental contingency.
 for q in np.argwhere(raw!=0):
  qt=tuple(int(x) for x in q)
  if qt not in environment_positions and qt not in learner_positions:learner_positions.append(qt)
 learner_state=[{"q":list(q),"raw":int(raw[q]),"clock":int(clock[q])} for q in sorted(set(learner_positions))]
 return NativeWorld(kernel,raw,clock),{"a":a,"b":b,"q":q_receiver,"qp":qp_receiver,
  "learner_t0_hash":canonical_hash(learner_state),"environment_positions":[list(q) for q in environment_positions]}


def run_case(kernel,frame,condition,horizon=512):
 try:world,meta=build(kernel,frame,condition)
 except RuntimeError as exc:return {"condition":condition,"valid":False,"reason":str(exc)}
 pairs=[];transitions=[];previous=0
 for tick in range(1,horizon+1):
  world.tick();ra,rb=read(world.raw,meta["a"]),read(world.raw,meta["b"]);delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"])
  if delta!=previous:transitions.append({"tick":tick,"before":previous,"after":delta})
  pairs.append((int(world.raw[meta["q"]]),int(world.raw[meta["qp"]])));previous=delta
 terminal=pairs[-1];constant=all(pair==terminal for pair in pairs[384:])
 return {"condition":condition,"valid":True,"learner_t0_hash":meta["learner_t0_hash"],
  "environment_positions":meta["environment_positions"],"master_transitions":transitions,"terminal_delta":previous,
  "terminal_pair_raw":list(terminal),"terminal_window_constant":constant,"python_interventions_after_t0":0}


def frame_json(frame):return {"permutation":list(frame[0]),"signs":list(frame[1])}


def main():
 lock=json.loads(LOCK.read_text(encoding="utf-8"));salt=lock["fresh_generation"]["salt"];identity=((0,1,2),(1,1,1))
 frames=[(p,s) for p in itertools.permutations((0,1,2)) for s in itertools.product((-1,1),repeat=3) if (p,s)!=identity]
 frames.sort(key=lambda f:hashlib.sha256((json.dumps(frame_json(f),sort_keys=True,separators=(",",":"))+salt).encode()).hexdigest());frames=frames[:8]
 challenge=seal({"schema":"dee.v27.ing03.rw3.remote_fixed_point_challenges.v1","lock_id":lock["lock_id"],
  "lock_sha256":sha256_file(LOCK),"algorithm":lock["fresh_generation"]["algorithm"],"salt":salt,
  "challenges":[{"id":f"RFP{i:02d}","frame":frame_json(frame),"conditions":lock["conditions"]} for i,frame in enumerate(frames,1)],
  "outcomes_absent_at_generation":True})
 challenge_path=ROOT/"HOLDOUT/ING03_RW3_REMOTE_FIXED_POINT_CHALLENGES.json";write_json(challenge_path,challenge)
 kernel,runtime=load_kernel(1);rows=[]
 for i,frame in enumerate(frames,1):
  for condition in lock["conditions"]:
   row=run_case(kernel,frame,condition);row.update({"challenge_id":f"RFP{i:02d}","frame":frame_json(frame)});rows.append(row)
 groups=[]
 for i,frame in enumerate(frames,1):
  cid=f"RFP{i:02d}";subset=[r for r in rows if r["challenge_id"]==cid];by={r["condition"]:r for r in subset}
  learner_hashes={r.get("learner_t0_hash") for r in subset};pairs={name:tuple(by[name].get("terminal_pair_raw",[])) for name in ("learn_a","learn_b","sham","broken_generator")}
  passed=(len(subset)==4 and all(r.get("valid") and r.get("terminal_window_constant") and r.get("python_interventions_after_t0")==0 for r in subset)
          and len(learner_hashes)==1 and by["learn_a"]["terminal_delta"]==1 and by["learn_b"]["terminal_delta"]==-1
          and by["sham"]["terminal_delta"]==0 and by["broken_generator"]["terminal_delta"]==0
          and len({pairs["learn_a"],pairs["learn_b"],pairs["sham"]})==3 and pairs["broken_generator"]==pairs["sham"])
  groups.append({"challenge_id":cid,"frame":frame_json(frame),"learner_hashes_identical":len(learner_hashes)==1,
                 "terminal_pairs":{k:list(v) for k,v in pairs.items()},"passed":passed})
 result=seal({"schema":"dee.v27.ing03.rw3.remote_fixed_point_holdout.v1","lock_id":lock["lock_id"],
  "lock_sha256":sha256_file(LOCK),"challenge_content_sha256":challenge["content_sha256"],"rows":rows,"groups":groups,
  "summary":{"fresh_frames":len(groups),"fresh_worlds":len(rows),"passed_groups":sum(g["passed"] for g in groups),"all_passed":all(g["passed"] for g in groups)},
  "post_freeze_tuning":False,"claim_scope":lock["claim_scope"],"runtime":runtime})
 output=ROOT/"HOLDOUT/ING03_RW3_REMOTE_FIXED_POINT_HOLDOUT.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
