#!/usr/bin/env python3
"""Post-learning, pre-expression master necessity for the remote fixed point."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import ROOT,load_kernel,pack,read,seal,write_json
from run_rw3_r10_state_selected_entrainment_controls import build
from run_nature_n07_native_consequence_expression import delta_value


def pair_hash(pair):
 h=hashlib.sha256()
 for raw in pair:h.update(int(raw).to_bytes(8,"little"))
 return h.hexdigest()


def run(kernel,target,intervention):
 world,meta=build(kernel,target);record=None
 for tick in range(1,513):
  world.tick()
  if tick==10 and intervention:
   ra,rb=read(world.raw,meta["a"]),read(world.raw,meta["b"]);record={"tick":tick,"mode":intervention,"before_delta":delta_value(world,meta)}
   if intervention=="ablate":
    for q in (meta["a"],meta["b"]):world.raw_a[q]=0;world.raw_b[q]=0;world.clock_a[q]=0;world.clock_b[q]=0
   elif intervention=="equalize":
    common=rb["sreg"]
    for q,old in ((meta["a"],ra),(meta["b"],rb)):
     raw=pack(old["state"],common,old["direction"],old["semantic"]);world.raw_a[q]=raw;world.raw_b[q]=raw
  terminal=(int(world.raw[meta["q_receiver"]]),int(world.raw[meta["qp_receiver"]]))
 return {"target":target,"intervention":intervention,"intervention_record":record,"terminal_delta":delta_value(world,meta),
         "terminal_pair_raw":list(terminal),"terminal_pair_sha256":pair_hash(terminal),
         "python_interventions_after_t0":0 if intervention is None else 1,
         "claim_guard":"Interventions diagnose necessity; they are not native capability."}


def main():
 kernel,runtime=load_kernel(1);rows=[run(kernel,target,mode) for target in ("a","b") for mode in (None,"ablate","equalize")]
 groups=[]
 for target in ("a","b"):
  subset={str(r["intervention"]):r for r in rows if r["target"]==target};intact=subset["None"]
  groups.append({"target":target,"intact_pair":intact["terminal_pair_raw"],
                 "ablation_changes_remote":subset["ablate"]["terminal_pair_raw"]!=intact["terminal_pair_raw"],
                 "equalization_changes_remote":subset["equalize"]["terminal_pair_raw"]!=intact["terminal_pair_raw"]})
 result=seal({"schema":"dee.v27.ing03.rw3.remote_master_necessity.v1",
  "question":"After learning but before delayed expression, is the stored master necessary for the eventual remote fixed point?",
  "design":{"native_write_tick":9,"diagnostic_intervention_tick":10,"expression_arrival_tick":24,"horizon":512},
  "rows":rows,"groups":groups,
  "summary":{"ablation_changes_both":all(g["ablation_changes_remote"] for g in groups),
             "equalization_changes_both":all(g["equalization_changes_remote"] for g in groups)},
  "runtime":runtime})
 output=ROOT/"ADVERSARIAL_CHALLENGE/ING03_RW3_R14_REMOTE_MASTER_NECESSITY.json";write_json(output,result)
 print(json.dumps({"output":str(output),"summary":result["summary"],"content_sha256":result["content_sha256"]},indent=2))


if __name__=="__main__":main()
