#!/usr/bin/env python3
"""Map competent-writer susceptibility and native source delay for plastic/frozen learners."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, pack, read, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09
from run_nature_n07_native_consequence_expression import delta_value


PROBE_TICK = 184
HORIZON = 360


def line_snapshot(world, q0, direction, n):
    rows = []
    for k in range(0, 9):
        q = add(q0, direction, k, n)
        value = read(world.raw, q)
        rows.append({"k": k, "q": list(q), "raw": None if value is None else value["raw"],
                     "state": None if value is None else value["state"],
                     "s_reg": None if value is None else value["sreg"],
                     "semantic": None if value is None else value["semantic"],
                     "direction": None if value is None else value["direction"]})
    return rows


def primary_probe(kernel, expression, target_kind):
    r10.OFFSET = (-6, 7, 8)
    initial_target = "a" if expression else None
    world, meta = r10.build(kernel, initial_target, expression=expression,
                            receiver_mode="candidate" if expression else "absent")
    if target_kind == "primary":
        node = {"a": meta["a"], "b": meta["b"]}
        event = add(meta["b"], (0, -1, 0), 1, meta["n"])
        route = (0, 0, 1)
        q = add(event, route, -3, meta["n"])
    else:
        node = r09.add_rotated_learner(world, meta, add(meta["c"], (0, 0, 14), 1, meta["n"]), 71, "z")
        q = node["writer_q"]
        route = r09.transform((0, 0, 1), "z")
    writer_raw = int(pack(31000, 0, route, 4))
    previous = delta_value(world, meta) if target_kind == "primary" else r09.delta(world, node)
    transitions = []
    samples = []
    installed = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            installed = {"q": list(q), "replaced_raw": int(world.raw[q]), "raw": writer_raw}
            r03.set_both(world, q, writer_raw, PROBE_TICK)
        value = delta_value(world, meta) if target_kind == "primary" else r09.delta(world, node)
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        if tick in set(range(PROBE_TICK - 1, PROBE_TICK + 13)) | {256, 268, 269, 270, 320, 333, 334, 335, 360}:
            samples.append({"tick": tick, "delta": value,
                            "writer_source_raw": int(world.raw[q]),
                            "line": line_snapshot(world, q, route, meta["n"])})
        previous = value
    post = [item for item in transitions if item["tick"] > PROBE_TICK]
    downstream_nonzero = sum(1 for sample in samples for item in sample["line"][4:] if item["raw"] is not None)
    return {"expression": expression, "target_kind": target_kind, "installed": installed,
            "initial_state_class": "EXPRESSIVE_FROZEN" if expression and target_kind == "primary" else "PLASTIC_RESERVE",
            "transitions": transitions, "post_probe_transitions": post, "write_success": bool(post),
            "source_persistent": samples[-1]["writer_source_raw"] == writer_raw,
            "downstream_nonzero_observations": downstream_nonzero, "samples": samples,
            "python_interventions_after_t0": 1, "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def add_simple_learner(world, center):
    meta = {"n": world.n}
    return r09.add_rotated_learner(world, meta, center, 81, "x")


def delay_calibration(kernel, distance, phase):
    n = 41
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    world = NativeWorld(kernel, raw, clock)
    node = add_simple_learner(world, (n // 2,) * 3)
    event = add(node["writer_q"], (0, 0, 1), 3, n)
    q = add(event, (0, 0, 1), -distance, n)
    if int(world.raw[q]):
        return {"distance": distance, "phase": phase, "valid": False, "reason": "overlap"}
    raw_value = int(pack(32000, 0, (0, 0, 1), 4))
    r03.set_both(world, q, raw_value, phase)
    previous = 0
    first = None
    transitions = []
    for tick in range(1, 129):
        world.tick()
        value = r09.delta(world, node)
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
            if first is None:
                first = tick
        previous = value
    return {"distance": distance, "phase": phase, "valid": True,
            "first_write_tick": first, "terminal_delta": previous,
            "source_persistent": int(world.raw[q]) == raw_value, "transitions": transitions,
            "python_interventions_after_t0": 0}


def main():
    kernel, runtime = load_kernel(1)
    atlas = [primary_probe(kernel, True, "primary"),
             primary_probe(kernel, False, "primary"),
             primary_probe(kernel, True, "reserve")]
    calibration = [delay_calibration(kernel, distance, phase)
                   for distance in (3, 8, 12, 16) for phase in (0, 184, 252)]
    index = []
    for row in atlas:
        index.append({"state_class": row["initial_state_class"], "target_kind": row["target_kind"],
                      "write_success": row["write_success"], "source_persistent": row["source_persistent"],
                      "downstream_nonzero_observations": row["downstream_nonzero_observations"],
                      "susceptibility_index": int(row["write_success"])})
    frozen = atlas[0]
    plastic = atlas[1:]
    result = seal({
        "schema": "dee.v27.ing03.native_succession.susceptibility.v1",
        "question": "Does the same competent incoming writer interact differently with expressive-frozen and plastic learners, and can a t0 source generate a delayed native event?",
        "cost_estimate": {"diagnostic_worlds": len(atlas), "native_calibration_worlds": len(calibration),
                          "ticks": len(atlas) * HORIZON + len(calibration) * 128,
                          "information_gain": "high"},
        "atlas": atlas, "native_delay_calibration": calibration,
        "accessibility_index": index,
        "summary": {
            "plastic_writes": all(row["write_success"] for row in plastic),
            "frozen_writes": frozen["write_success"],
            "susceptibility_differential": all(row["write_success"] for row in plastic) and not frozen["write_success"],
            "frozen_source_survives": frozen["source_persistent"],
            "frozen_node_pass_through_demonstrated": False,
            "frozen_downstream_lineage_resolution": "unresolved: downstream occupancy is confounded by the maintained expressive regime",
            "native_delayed_source_candidates": [row for row in calibration if row.get("first_write_tick")],
            "native_selection_demonstrated": False,
            "rw3_demonstrated": False,
        },
        "claim_guard": "Atlas writer insertions are diagnostic. Native delay calibration is t0-complete but does not by itself select a learner.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S01_SUSCEPTIBILITY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "accessibility_index": index, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
