#!/usr/bin/env python3
"""Test whether rejection by a frozen P0 passes a common writer corridor to a plastic P1."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09
from run_nature_n07_native_consequence_expression import delta_value


PROBE_TICK = 184
HORIZON = 400


def build(kernel, p0_frozen):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, "a" if p0_frozen else None,
                            expression=p0_frozen,
                            receiver_mode="candidate" if p0_frozen else "absent")
    center1 = add(meta["c"], (2, -2, 14), 1, meta["n"])
    p1 = r09.add_rotated_learner(world, meta, center1, 91, "y")
    p0_event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    p1_route = r09.transform((0, 0, 1), "y")
    p1_event = add(p1["writer_q"], p1_route, 3, meta["n"])
    expected = add(p0_event, (0, 0, 1), 14, meta["n"])
    if p1_event != expected:
        raise RuntimeError(f"corridor alignment failed: {p1_event} != {expected}")
    return world, meta, p1


def run(kernel, label, p0_frozen, source_target):
    world, meta, p1 = build(kernel, p0_frozen)
    p0_q = add(add(meta["b"], (0, -1, 0), 1, meta["n"]), (0, 0, 1), -3, meta["n"])
    p1_q = p1["writer_q"]
    source_q = p0_q if source_target == "common_upstream" else p1_q if source_target == "direct_p1" else None
    previous0 = delta_value(world, meta)
    previous1 = r09.delta(world, p1)
    p0_transitions = []
    p1_transitions = []
    installed = None
    samples = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK and source_q is not None:
            raw = int(pack(33000, 0, (0, 0, 1), 4))
            installed = {"q": list(source_q), "replaced_raw": int(world.raw[source_q]), "raw": raw}
            r03.set_both(world, source_q, raw, PROBE_TICK)
        value0 = delta_value(world, meta)
        value1 = r09.delta(world, p1)
        if value0 != previous0:
            p0_transitions.append({"tick": tick, "before": previous0, "after": value0})
        if value1 != previous1:
            p1_transitions.append({"tick": tick, "before": previous1, "after": value1})
        if tick in (9, 38, 139, 183, 184, 185, 186, 187, 198, 256, 268, 269, 270, 320, 333, 334, 335, 360, 400):
            samples.append({"tick": tick, "p0_delta": value0, "p1_delta": value1,
                            "p0_source_raw": int(world.raw[p0_q]), "p1_source_raw": int(world.raw[p1_q])})
        previous0, previous1 = value0, value1
    return {"label": label, "p0_frozen": p0_frozen, "source_target": source_target,
            "installed": installed, "p0_transitions": p0_transitions, "p1_transitions": p1_transitions,
            "p0_post_probe": [x for x in p0_transitions if x["tick"] > PROBE_TICK],
            "p1_post_probe": [x for x in p1_transitions if x["tick"] > PROBE_TICK],
            "terminal": {"p0": previous0, "p1": previous1}, "samples": samples,
            "python_interventions_after_t0": int(source_q is not None),
            "intervention_class": "DIAGNOSTIC_INTERVENTION" if source_q is not None else "NONE"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [
        run(kernel, "frozen_common", True, "common_upstream"),
        run(kernel, "frozen_no_source", True, None),
        run(kernel, "plastic_common", False, "common_upstream"),
        run(kernel, "plastic_no_source", False, None),
        run(kernel, "frozen_direct_p1", True, "direct_p1"),
    ]
    by = {row["label"]: row for row in rows}
    def signature(row, key):
        return [(x["tick"], x["before"], x["after"]) for x in row[key]]
    direct_positive = signature(by["frozen_direct_p1"], "p1_post_probe") != signature(by["frozen_no_source"], "p1_post_probe")
    serial_effect = signature(by["frozen_common"], "p1_post_probe") != signature(by["frozen_no_source"], "p1_post_probe")
    p0_absorbs_when_plastic = signature(by["plastic_common"], "p0_post_probe") != signature(by["plastic_no_source"], "p0_post_probe")
    result = seal({
        "schema": "dee.v27.ing03.native_succession.serial_filter.v1",
        "question": "Does a common writer corridor pass a rejected consequence from frozen P0 to an aligned plastic P1?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "geometry": {"p0_p1_event_separation": 14, "common_direction": [0, 0, 1],
                     "p1_frame": "y", "probe_tick": PROBE_TICK},
        "rows": rows,
        "summary": {"p1_direct_positive_control": direct_positive,
                    "plastic_p0_absorbs_or_writes": p0_absorbs_when_plastic,
                    "frozen_p0_to_p1_serial_effect": serial_effect,
                    "first_compatible_sink_demonstrated": direct_positive and p0_absorbs_when_plastic and serial_effect,
                    "native_selection_demonstrated": False,
                    "rw3_demonstrated": False},
        "claim_guard": "The writer is inserted diagnostically at tick184. A serial effect would establish pass-through ancestry, not a promoted native selector until reconstructed from t0.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S02_SERIAL_FILTER.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "post_probe": {k: {"p0": v["p0_post_probe"], "p1": v["p1_post_probe"]} for k, v in by.items()},
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
