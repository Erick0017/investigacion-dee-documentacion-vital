#!/usr/bin/env python3
"""Find whether a corridor-aligned downstream learner retains direct writer competence."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09


PROBE_TICK = 184
HORIZON = 360
CANDIDATES = (
    ("y_aligned_10", (2, -2, 10), "y"),
    ("y_aligned_14", (2, -2, 14), "y"),
    ("y_aligned_18", (2, -2, 18), "y"),
    ("x_aligned_14", (0, 0, 14), "x"),
    ("x_aligned_18", (0, 0, 18), "x"),
    ("known_y_separated", (14, 0, 0), "y"),
)


def run(kernel, label, offset, frame):
    r10.OFFSET = (-6, 7, 8)
    try:
        world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
        node = r09.add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), 101, frame)
    except RuntimeError as exc:
        return {"label": label, "offset": list(offset), "frame": frame, "valid": False, "reason": str(exc)}
    route = r09.transform((0, 0, 1), frame)
    p0_event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    p1_event = add(node["writer_q"], route, 3, meta["n"])
    previous = r09.delta(world, node)
    transitions = []
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK:
            r03.set_both(world, node["writer_q"], int(pack(34000, 0, route, 4)), PROBE_TICK)
        value = r09.delta(world, node)
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    post = [x for x in transitions if x["tick"] > PROBE_TICK]
    common_direction = route == (0, 0, 1)
    aligned = common_direction and p1_event[0] == p0_event[0] and p1_event[1] == p0_event[1]
    axial_distance = (p1_event[2] - p0_event[2]) % meta["n"] if aligned else None
    return {"label": label, "offset": list(offset), "frame": frame, "valid": True,
            "p0_event": list(p0_event), "p1_event": list(p1_event), "route": list(route),
            "corridor_aligned": aligned, "axial_distance": axial_distance,
            "transitions": transitions, "post_probe_transitions": post,
            "direct_writer_competent": bool(post), "terminal_delta": previous,
            "python_interventions_after_t0": 1, "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, *spec) for spec in CANDIDATES]
    aligned_competent = [row for row in rows if row.get("corridor_aligned") and row.get("direct_writer_competent")]
    result = seal({
        "schema": "dee.v27.ing03.native_succession.corridor_geometry.v1",
        "question": "Is the S02 serial-filter null caused by lack of pass-through or by an incompetent aligned P1 geometry?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "rows": rows,
        "summary": {"valid_worlds": sum(row.get("valid", False) for row in rows),
                    "direct_competent_labels": [row["label"] for row in rows if row.get("direct_writer_competent")],
                    "aligned_competent_candidates": [row["label"] for row in aligned_competent],
                    "serial_filter_testable_with_current_corridor": bool(aligned_competent),
                    "native_selection_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "Diagnostic writer insertion maps geometry only. No native event selection is claimed.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S02B_CORRIDOR_GEOMETRY.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "rows": [{"label": x["label"], "valid": x.get("valid"), "aligned": x.get("corridor_aligned"),
                                "competent": x.get("direct_writer_competent"), "post": x.get("post_probe_transitions")} for x in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
