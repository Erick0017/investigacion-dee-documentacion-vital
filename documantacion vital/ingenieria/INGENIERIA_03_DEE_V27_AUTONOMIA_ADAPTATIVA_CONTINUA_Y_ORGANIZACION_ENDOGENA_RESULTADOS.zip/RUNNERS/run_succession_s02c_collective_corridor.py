#!/usr/bin/env python3
"""Test a corridor-aligned learner inside the collective three-frame reserve organization."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09
from run_nature_n07_native_consequence_expression import delta_value


PROBE_TICK = 184
HORIZON = 400
ORIGINAL = (((0, 14, 0), "x"), ((14, 0, 0), "y"), ((0, 0, 14), "z"))
SHIFT = (-12, -2, 14)
TRANSLATED = tuple((tuple(offset[i] + SHIFT[i] for i in range(3)), frame) for offset, frame in ORIGINAL)


def build(kernel, design):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, "a", expression=True, receiver_mode="candidate")
    nodes = [r09.add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), index + 1, frame)
             for index, (offset, frame) in enumerate(design)]
    return world, meta, nodes


def run(kernel, label, design, source_mode):
    try:
        world, meta, nodes = build(kernel, design)
    except RuntimeError as exc:
        return {"label": label, "source_mode": source_mode, "valid": False, "reason": str(exc)}
    p1 = nodes[1]
    p0_q = add(add(meta["b"], (0, -1, 0), 1, meta["n"]), (0, 0, 1), -3, meta["n"])
    source_q = p1["writer_q"] if source_mode == "direct" else p0_q if source_mode == "common" else None
    previous0 = delta_value(world, meta)
    previous = {node["id"]: r09.delta(world, node) for node in nodes}
    transitions = {node["id"]: [] for node in nodes}
    p0_transitions = []
    installed = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK and source_q is not None:
            raw = int(pack(25002, 0, (0, 0, 1), 4))
            installed = {"q": list(source_q), "replaced_raw": int(world.raw[source_q]), "raw": raw}
            r03.set_both(world, source_q, raw, PROBE_TICK)
        value0 = delta_value(world, meta)
        if value0 != previous0:
            p0_transitions.append({"tick": tick, "before": previous0, "after": value0})
        previous0 = value0
        for node in nodes:
            value = r09.delta(world, node)
            if value != previous[node["id"]]:
                transitions[node["id"]].append({"tick": tick, "before": previous[node["id"]], "after": value})
            previous[node["id"]] = value
    post = {str(key): [x for x in value if x["tick"] > PROBE_TICK] for key, value in transitions.items()}
    p0_event = add(meta["b"], (0, -1, 0), 1, meta["n"])
    p1_event = add(p1["writer_q"], (0, 0, 1), 3, meta["n"])
    aligned = p0_event[0:2] == p1_event[0:2]
    return {"label": label, "source_mode": source_mode, "valid": True,
            "design": [{"offset": list(offset), "frame": frame} for offset, frame in design],
            "p0_event": list(p0_event), "p1_event": list(p1_event), "corridor_aligned": aligned,
            "installed": installed, "p0_post_probe": [x for x in p0_transitions if x["tick"] > PROBE_TICK],
            "node_transitions": {str(k): v for k, v in transitions.items()}, "node_post_probe": post,
            "terminal_deltas": {str(k): v for k, v in previous.items()},
            "python_interventions_after_t0": int(source_q is not None),
            "intervention_class": "DIAGNOSTIC_INTERVENTION" if source_q is not None else "NONE"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, "original_direct", ORIGINAL, "direct"),
            run(kernel, "translated_direct", TRANSLATED, "direct"),
            run(kernel, "translated_common", TRANSLATED, "common"),
            run(kernel, "translated_none", TRANSLATED, None)]
    by = {row["label"]: row for row in rows}
    direct_reproduced = bool(by["original_direct"].get("node_post_probe", {}).get("2"))
    translated_competent = bool(by["translated_direct"].get("node_post_probe", {}).get("2"))
    common_effect = by["translated_common"].get("node_post_probe", {}).get("2") != by["translated_none"].get("node_post_probe", {}).get("2")
    result = seal({
        "schema": "dee.v27.ing03.native_succession.collective_corridor.v1",
        "question": "Can the collective three-frame reserve preserve P1 competence when translated onto the P0 common corridor, and does a rejected upstream event reach it?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "rows": rows,
        "summary": {"original_collective_direct_control": direct_reproduced,
                    "translated_collective_p1_direct_competent": translated_competent,
                    "translated_common_corridor_effect": common_effect,
                    "first_compatible_sink_demonstrated": translated_competent and common_effect,
                    "native_selection_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "Sources are diagnostic insertions. Translation tests organization-level competence and serial ancestry, not promoted autonomy.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S02C_COLLECTIVE_CORRIDOR.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "post": {k: v.get("node_post_probe") for k, v in by.items()},
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
