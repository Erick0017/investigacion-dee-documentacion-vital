#!/usr/bin/env python3
"""Test whether frozen P0 redirects one perturbation into the competent collective reserve."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, write_json
import run_rw3_r10_state_selected_entrainment_controls as r10
import run_reactivation_r03_distributed_plasticity as r03
import run_reactivation_r09_distributed_rotated_array as r09
from run_nature_n07_native_consequence_expression import delta_value


PROBE_TICK = 184
HORIZON = 400
ARRAY = (((0, 14, 0), "x"), ((14, 0, 0), "y"), ((0, 0, 14), "z"))


def run(kernel, label, p0_frozen, with_source):
    r10.OFFSET = (-6, 7, 8)
    world, meta = r10.build(kernel, "a" if p0_frozen else None,
                            expression=p0_frozen,
                            receiver_mode="candidate" if p0_frozen else "absent")
    nodes = [r09.add_rotated_learner(world, meta, add(meta["c"], offset, 1, meta["n"]), i + 1, frame)
             for i, (offset, frame) in enumerate(ARRAY)]
    p0_q = add(add(meta["b"], (0, -1, 0), 1, meta["n"]), (0, 0, 1), -3, meta["n"])
    previous0 = delta_value(world, meta)
    previous = {node["id"]: r09.delta(world, node) for node in nodes}
    transitions0 = []
    transitions = {node["id"]: [] for node in nodes}
    installed = None
    for tick in range(1, HORIZON + 1):
        world.tick()
        if tick == PROBE_TICK and with_source:
            raw = int(pack(35000, 0, (0, 0, 1), 4))
            installed = {"q": list(p0_q), "replaced_raw": int(world.raw[p0_q]), "raw": raw}
            r03.set_both(world, p0_q, raw, PROBE_TICK)
        value0 = delta_value(world, meta)
        if value0 != previous0:
            transitions0.append({"tick": tick, "before": previous0, "after": value0})
        previous0 = value0
        for node in nodes:
            value = r09.delta(world, node)
            if value != previous[node["id"]]:
                transitions[node["id"]].append({"tick": tick, "before": previous[node["id"]], "after": value})
            previous[node["id"]] = value
    return {"label": label, "p0_frozen": p0_frozen, "with_source": with_source,
            "installed": installed, "p0_transitions": transitions0,
            "p0_post_probe": [x for x in transitions0 if x["tick"] > PROBE_TICK],
            "node_transitions": {str(k): v for k, v in transitions.items()},
            "node_post_probe": {str(k): [x for x in v if x["tick"] > PROBE_TICK] for k, v in transitions.items()},
            "terminal": {"p0": previous0, "reserves": {str(k): v for k, v in previous.items()}},
            "python_interventions_after_t0": int(with_source),
            "intervention_class": "DIAGNOSTIC_INTERVENTION" if with_source else "NONE"}


def main():
    kernel, runtime = load_kernel(1)
    rows = [run(kernel, "frozen_source", True, True), run(kernel, "frozen_none", True, False),
            run(kernel, "plastic_source", False, True), run(kernel, "plastic_none", False, False)]
    by = {row["label"]: row for row in rows}
    frozen_reserve_effects = [key for key in ("1", "2", "3")
                              if by["frozen_source"]["node_post_probe"][key] != by["frozen_none"]["node_post_probe"][key]]
    plastic_reserve_effects = [key for key in ("1", "2", "3")
                               if by["plastic_source"]["node_post_probe"][key] != by["plastic_none"]["node_post_probe"][key]]
    frozen_local = by["frozen_source"]["p0_post_probe"] != by["frozen_none"]["p0_post_probe"]
    plastic_local = by["plastic_source"]["p0_post_probe"] != by["plastic_none"]["p0_post_probe"]
    result = seal({
        "schema": "dee.v27.ing03.native_succession.collective_selection.v1",
        "question": "Does P0 nonwritability redirect a single P0-entering consequence into the original competent distributed reserve array?",
        "cost_estimate": {"worlds": len(rows), "ticks_per_world": HORIZON, "information_gain": "high"},
        "rows": rows,
        "summary": {"frozen_p0_local_effect": frozen_local, "plastic_p0_local_effect": plastic_local,
                    "frozen_reserve_effect_nodes": frozen_reserve_effects,
                    "plastic_reserve_effect_nodes": plastic_reserve_effects,
                    "state_dependent_redirection": bool(frozen_reserve_effects) and not plastic_reserve_effects and not frozen_local and plastic_local,
                    "single_winner_after_redirection": len(frozen_reserve_effects) == 1,
                    "native_selection_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "The source insertion is diagnostic. A positive differential would require t0-native reconstruction and fresh state permutations before promotion.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S03_COLLECTIVE_SELECTION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "post": {k: {"p0": v["p0_post_probe"], "reserves": v["node_post_probe"]} for k, v in by.items()},
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
