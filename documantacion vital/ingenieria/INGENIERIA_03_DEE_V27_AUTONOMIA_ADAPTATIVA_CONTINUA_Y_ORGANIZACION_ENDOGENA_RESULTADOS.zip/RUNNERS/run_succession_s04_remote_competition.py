#!/usr/bin/env python3
"""Diagnose coexistence and support competition between mature A/B remote basins."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld, ROOT, add, load_kernel, seal, write_json
from run_landscape_l03_two_organ_coupling_search import P, put_transducer
import run_reactivation_r13_combined_late_development as r13


OFFSET_0 = (-6, 7, 8)
OFFSET_1 = (6, -7, -8)
MATURATION = 256
POST_HORIZON = 384


def pair_at(world, q, n):
    return [int(world.raw[q]), int(world.raw[add(q, P, 1, n)])]


def mature(kernel, target):
    world, meta, sources = r13.build(kernel, target)
    q0 = meta["q_receiver"]
    q1 = add(meta["c"], OFFSET_1, 1, meta["n"])
    put_transducer(world.raw_a, world.clock_a, q1, meta["n"], 9600)
    world.raw_b[:] = world.raw_a
    world.clock_b[:] = world.clock_a
    for _ in range(MATURATION):
        world.tick()
    return world, meta, sources, q0, q1


def copy_cube(dst, src, center, radius, n):
    copied = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = add(center, (dx, dy, dz), 1, n)
                dst.raw_a[q] = src.raw[q]
                dst.raw_b[q] = src.raw[q]
                dst.clock_a[q] = src.clock_a[q]
                dst.clock_b[q] = src.clock_a[q]
                copied.append(q)
    return copied


def follow(kernel, host, donor, meta, sources, q0, q1, donor_q1, radius, cut_support):
    world = NativeWorld(kernel, host.raw, host.clock_a)
    copied = copy_cube(world, donor, q1, radius, meta["n"])
    cut = []
    if cut_support:
        for item in sources:
            q = tuple(item["q"])
            cut.append({"q": list(q), "before_raw": int(world.raw[q])})
            for array in (world.raw_a, world.raw_b, world.clock_a, world.clock_b):
                array[q] = np.uint64(0)
    target0 = pair_at(host, q0, meta["n"])
    target1 = pair_at(donor, donor_q1, meta["n"])
    samples = []
    for tick in range(1, POST_HORIZON + 1):
        world.tick()
        if tick in (1, 2, 4, 8, 16, 32, 64, 128, 256, 384):
            samples.append({"tick": tick, "q0": pair_at(world, q0, meta["n"]),
                            "q1": pair_at(world, q1, meta["n"])})
    terminal0 = pair_at(world, q0, meta["n"])
    terminal1 = pair_at(world, q1, meta["n"])
    return {"radius": radius, "cut_support": cut_support, "copied_voxels": len(copied),
            "support_cut": cut, "target_q0_A": target0, "target_q1_B": target1,
            "samples": samples, "terminal_q0": terminal0, "terminal_q1": terminal1,
            "q0_A_persisted": terminal0 == target0, "q1_B_persisted": terminal1 == target1,
            "coexistence_persisted": terminal0 == target0 and terminal1 == target1,
            "python_interventions_after_t0": 1 + int(cut_support),
            "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    kernel, runtime = load_kernel(1)
    host_a, meta_a, sources_a, q0_a, q1_a = mature(kernel, "a")
    donor_b, meta_b, _, q0_b, q1_b = mature(kernel, "b")
    initial = {"host_A": {"q0": pair_at(host_a, q0_a, meta_a["n"]), "q1": pair_at(host_a, q1_a, meta_a["n"])},
               "donor_B": {"q0": pair_at(donor_b, q0_b, meta_b["n"]), "q1": pair_at(donor_b, q1_b, meta_b["n"])}}
    rows = [follow(kernel, host_a, donor_b, meta_a, sources_a, q0_a, q1_a, q1_b, radius, False)
            for radius in (0, 1, 2, 3)]
    best = next((row for row in rows if row["coexistence_persisted"]), None)
    if best is not None:
        rows.append(follow(kernel, host_a, donor_b, meta_a, sources_a, q0_a, q1_a, q1_b, best["radius"], True))
    active = [row for row in rows if not row["cut_support"]]
    cut = [row for row in rows if row["cut_support"]]
    result = seal({
        "schema": "dee.v27.ing03.native_succession.remote_competition.v1",
        "question": "Can diagnostically installed mature A/B remote basins coexist, and do they exclude one another through shared formation support?",
        "cost_estimate": {"maturation_worlds": 2, "post_worlds": len(rows),
                          "maturation_ticks": MATURATION, "post_ticks": POST_HORIZON,
                          "information_gain": "high"},
        "initial_mature_pairs": initial, "rows": rows,
        "summary": {"minimum_coexistence_copy_radius": None if best is None else best["radius"],
                    "mature_A_B_coexistence_demonstrated_diagnostically": best is not None,
                    "coexistence_after_shared_support_cut": any(row["coexistence_persisted"] for row in cut),
                    "support_competition_class": "NO_COMPETITION_AT_LATCH_LAYER" if best is not None else "COEXISTENCE_NOT_CONSTRUCTED",
                    "functional_dominance_switching_demonstrated": False,
                    "native_handoff_demonstrated": False, "rw3_demonstrated": False},
        "claim_guard": "Python basin copying and optional source cuts are diagnostic. Coexistence is not dominance; no shared executor or native handoff is claimed.",
        "runtime": runtime,
    })
    output = ROOT / "MECHANISM_SELECTION/ING03_SUCCESSION_S04_REMOTE_COMPETITION.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "rows": [{"radius": x["radius"], "cut": x["cut_support"],
                                "q0": x["q0_A_persisted"], "q1": x["q1_B_persisted"],
                                "both": x["coexistence_persisted"]} for x in rows],
                      "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
