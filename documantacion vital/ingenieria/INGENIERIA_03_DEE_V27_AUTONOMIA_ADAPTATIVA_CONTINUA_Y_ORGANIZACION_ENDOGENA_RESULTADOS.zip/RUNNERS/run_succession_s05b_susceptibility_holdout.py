#!/usr/bin/env python3
"""Fresh validation of S05B's exact S01/R10 susceptibility apparatus."""
from __future__ import annotations

import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from ing03_common import ROOT, add, load_kernel, pack, seal, sha256_file, transform, write_json
import run_reactivation_c15_fresh_holdout as c15
import run_succession_s05_susceptibility_holdout as s05


LOCK_PATH = ROOT / "FREEZE/ING03_SUCCESSION_S05B_SUSCEPTIBILITY_LOCK.json"


def frame_json(frame):
    return {"permutation": list(frame[0]), "signs": list(frame[1])}


def run_case(kernel, frame, state_class, architecture):
    permutation, signs = frame
    tf = lambda v: transform(v, permutation, signs)
    try:
        if state_class == "frozen":
            world, meta = c15.build(kernel, frame, "learn_a", architecture)
        else:
            world, meta = s05.plastic_world(kernel, frame, architecture)
        event = add(meta["b"], tf((0, -1, 0)), 1, architecture["n"])
        route = tf((0, 0, 1))
        q = add(event, route, -3, architecture["n"])
    except RuntimeError as exc:
        return {"state_class": state_class, "valid": False, "reason": str(exc)}
    previous = s05.delta(world, meta)
    transitions = []
    writer_raw = int(pack(architecture["writer_state"], architecture["writer_s_reg"], route,
                          architecture["writer_semantic"]))
    replaced_raw = None
    for tick in range(1, architecture["horizon"] + 1):
        world.tick()
        if tick == architecture["probe_tick"]:
            replaced_raw = int(world.raw[q])
            if replaced_raw:
                return {"state_class": state_class, "valid": False, "reason": "writer overlap",
                        "q": list(q), "overlap_raw": replaced_raw}
            world.raw_a[q] = np.uint64(writer_raw); world.raw_b[q] = np.uint64(writer_raw)
            world.clock_a[q] = np.uint64(architecture["writer_clock"]); world.clock_b[q] = np.uint64(architecture["writer_clock"])
        value = s05.delta(world, meta)
        if value != previous:
            transitions.append({"tick": tick, "before": previous, "after": value})
        previous = value
    post = [x for x in transitions if x["tick"] > architecture["probe_tick"]]
    return {"state_class": state_class, "valid": True, "q": list(q), "replaced_raw": replaced_raw,
            "transitions": transitions, "post_probe_transitions": post,
            "causal_accessibility_index": int(bool(post)),
            "writer_source_persistent": int(world.raw[q]) == writer_raw,
            "python_interventions_after_t0": 1, "intervention_class": "DIAGNOSTIC_INTERVENTION"}


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    excluded = set()
    for path in (ROOT / "HOLDOUT/ING03_REACT_C15_CHALLENGES.json", ROOT / "HOLDOUT/ING03_SUCCESSION_S05_CHALLENGES.json"):
        data = json.loads(path.read_text(encoding="utf-8"))
        excluded |= {(tuple(x["frame"]["permutation"]), tuple(x["frame"]["signs"])) for x in data["challenges"]}
    identity = ((0, 1, 2), (1, 1, 1))
    frames = [(p, s) for p in itertools.permutations((0, 1, 2)) for s in itertools.product((-1, 1), repeat=3)
              if (p, s) != identity and (p, s) not in excluded]
    salt = lock["fresh_generation"]["salt"]
    frames.sort(key=lambda frame: hashlib.sha256((json.dumps(frame_json(frame), sort_keys=True,
                    separators=(",", ":")) + salt).encode()).hexdigest())
    frames = frames[:lock["fresh_generation"]["fresh_frames"]]
    challenges = seal({"schema": "dee.v27.ing03.native_succession.s05b_challenges.v1",
                       "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
                       "challenges": [{"id": f"S05B-{i:02d}", "frame": frame_json(frame)} for i, frame in enumerate(frames, 1)],
                       "outcomes_absent_at_generation": True})
    write_json(ROOT / "HOLDOUT/ING03_SUCCESSION_S05B_CHALLENGES.json", challenges)
    kernel, runtime = load_kernel(1)
    rows = []
    for i, frame in enumerate(frames, 1):
        for state_class in ("frozen", "plastic"):
            row = run_case(kernel, frame, state_class, lock["architecture"])
            row.update({"challenge_id": f"S05B-{i:02d}", "frame": frame_json(frame)})
            rows.append(row)
    groups = []
    for i, frame in enumerate(frames, 1):
        cid = f"S05B-{i:02d}"
        by = {row["state_class"]: row for row in rows if row["challenge_id"] == cid}
        passed = (all(row.get("valid") and row.get("writer_source_persistent") and row.get("replaced_raw") == 0
                      for row in by.values()) and by["frozen"].get("causal_accessibility_index") == 0 and
                  by["plastic"].get("causal_accessibility_index") == 1)
        groups.append({"challenge_id": cid, "frame": frame_json(frame),
                       "frozen_index": by["frozen"].get("causal_accessibility_index"),
                       "plastic_index": by["plastic"].get("causal_accessibility_index"), "passed": passed})
    result = seal({"schema": "dee.v27.ing03.native_succession.s05b_holdout.v1",
                   "lock_id": lock["lock_id"], "lock_sha256": sha256_file(LOCK_PATH),
                   "challenge_content_sha256": challenges["content_sha256"], "rows": rows, "groups": groups,
                   "summary": {"fresh_frames": len(groups), "fresh_worlds": len(rows),
                               "passed_groups": sum(x["passed"] for x in groups), "all_passed": all(x["passed"] for x in groups)},
                   "post_freeze_tuning": False, "claim_scope": lock["claim_scope"], "runtime": runtime})
    output = ROOT / "HOLDOUT/ING03_SUCCESSION_S05B_SUSCEPTIBILITY_HOLDOUT.json"
    write_json(output, result)
    print(json.dumps({"output": str(output), "summary": result["summary"],
                      "groups": groups, "content_sha256": result["content_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
