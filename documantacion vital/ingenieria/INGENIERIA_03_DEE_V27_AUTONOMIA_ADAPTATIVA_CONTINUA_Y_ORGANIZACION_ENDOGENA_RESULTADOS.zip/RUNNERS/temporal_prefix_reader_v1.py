#!/usr/bin/env python3
"""Candidate three-class native temporal-prefix reader for schedule t=[0,1,8]."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from ing03_common import NativeWorld,add,pack,read,transform
from relative_magnitude_reader_v1 import PA,PB,inverse
SLOTS=(0,1,8);QUERY_DELAY=12
def _put(raw,clock,q,state,sreg,direction=(0,0,0),semantic=1,phase=0):
    if int(raw[q]):raise RuntimeError(f"overlap {q}")
    raw[q]=pack(state,sreg,direction,semantic);clock[q]=np.uint64(phase)
def expected_class(sequence):
    if sequence[0]=="A":return "A_FIRST"
    return "BA_PREFIX" if sequence[1]=="A" else "BB_PREFIX"
def run_case(kernel,*,n,origin,sequence="AAA",permutation=(0,1,2),signs=(1,1,1),mode="treatment",horizon=36):
    tf=lambda v:transform(v,permutation,signs);c=tuple(int(x)%int(n) for x in origin);a=add(c,tf((-1,0,0)),1,n);b=add(c,tf((1,0,0)),1,n);raw=np.zeros((n,n,n),np.uint64);clock=np.zeros_like(raw)
    _put(raw,clock,a,1000,100,semantic=1,phase=260);_put(raw,clock,b,2000,100,semantic=1,phase=260)
    for i,o in enumerate(PA):_put(raw,clock,add(a,tf(o),1,n),3000+i,0,semantic=4,phase=31+i)
    for i,o in enumerate(PB):_put(raw,clock,add(b,tf(o),1,n),4000+i,0,semantic=4,phase=41+i)
    if mode!="no_events":
        for index,(identity,slot) in enumerate(zip(sequence,SLOTS)):
            center=a if identity=="A" else b;offset=tf((0,-1,0) if identity=="A" else (0,1,0));direction=tf((0,0,-1) if identity=="A" else (0,0,1));target=add(center,offset,1,n)
            if slot==0:_put(raw,clock,target,5000+index,0,direction,1,17)
            else:_put(raw,clock,add(target,direction,-slot,n),0,0,direction,1,19)
    if mode!="no_query":
        qdir=tf((0,1,0));_put(raw,clock,add(c,qdir,-QUERY_DELAY,n),6000,7,qdir,1,23)
    world=NativeWorld(kernel,raw,clock);events=[];deltas=[];digest=hashlib.sha256()
    for tick in range(1,horizon+1):
        world.tick();ra,rb,rc=read(world.raw,a),read(world.raw,b),read(world.raw,c);delta=None if ra is None or rb is None else int(ra["sreg"]-rb["sreg"]);deltas.append(delta);record=None if rc is None else [rc["state"],rc["sreg"],inverse(rc["direction"],permutation,signs),rc["semantic"]];digest.update(json.dumps(record,separators=(",",":"),sort_keys=True).encode())
        if rc is not None:events.append({"tick":tick,"delta":delta,"normalized_record":record})
    return {"n":n,"origin":list(c),"sequence":sequence,"mode":mode,"permutation":list(permutation),"signs":list(signs),"slots":list(SLOTS),"query_delay":QUERY_DELAY,"expected_class":None if mode!="treatment" else expected_class(sequence),"delta_before_query":deltas[QUERY_DELAY-2],"signature":digest.hexdigest(),"events":events,"python_interventions_after_t0":0}
