# Telemetry schema

All evidence is lossless JSON. `raw` is uint64-packed state; decoded fields are `state`, `sreg`, signed-nibble `direction[3]`, and `semantic`. `delta` is exactly `sreg(A)-sreg(B)`. Tick numbers refer to completed kernel ticks. `source_raw_fixed` compares exact uint64 source values. `signature` is the complete 16-tick comparator sequence `[state,sreg,normalized_direction,semantic]` or null.

Holdout rows preserve complete critical traces, fresh specifications, expected values and pass flags. File and content hashes distinguish byte integrity from canonical JSON scientific identity.
