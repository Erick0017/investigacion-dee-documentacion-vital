# Reproducción

## Entorno

- Kernel DEE v27 SHA-256: `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.
- Python usado: distribución Anaconda CPython 3.13 del proyecto.
- `numpy`: 2.2.6.
- Hilos del kernel: 1.

## Orden

Desde `CONTINUACION_RESERVA_ADAPTATIVA`:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\RUNNERS\run_ing04_ra01_symmetric_relational_chain.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\RUNNERS\run_ing04_ra02_shared_interface_chain.py'
```

Cada runner verifica/carga el kernel congelado mediante las utilidades de ING02. Los locks contienen hipótesis, dominio, controles y claim guards.

RA02 tuvo dos abortos de construcción antes del primer tick. No son evidencia física. La corrección quedó registrada en su lock: se reemplazó la geometría que solapaba una célula plástica y luego se permitió compartir exclusivamente soportes `semantic4` existentes. La única corrida física completa de RA02 produjo el resultado sellado.

## Resultado esperado

- RA01: `BOUNDED_NULL_RA01_RELATIONAL_CHAIN`.
- RA02: `BOUNDED_NULL_RA02_SHARED_INTERFACE_CHAIN`.
- Ningún runner escribe estado después de `t0`; Python sólo ejecuta ticks y registra observaciones.

