#!/usr/bin/env python3
"""Build and validate the single integrated INGENIERIA 04 official archive."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import zipfile


CONT = Path(__file__).resolve().parents[1]
ING04 = CONT.parent
TESTS = ING04.parents[2]
OFFICIAL = TESTS / "documantacion vital" / "ingenieria"
KERNEL = (TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "ANALYSIS" /
          "binary_api" / "wheel_extracted" / "dee_universe_v27" /
          "dee_kernel_v27.cp313-win_amd64.pyd")
KERNEL_SHA = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"
FINAL_NAME = "INGENIERIA_04_DEE_V27_INTEGRADA_FINAL_RESULTADOS.zip"
FINAL_ZIP = OFFICIAL / FINAL_NAME
TEMP_ZIP = OFFICIAL / f".{FINAL_NAME}.tmp"
FIXED_TIME = (2026, 9, 25, 0, 0, 0)
PARENTS = {
    "ING04_BASE": (
        "INGENIERIA_04_DEE_V27_ECOLOGIA_CAUSAL_OBSERVER_Y_ADAPTACION_RENOVABLE_RESULTADOS.zip",
        "9cafdd5b1e8fafb87623e89318f27bf9de462a0aabade2b9275a54e98ffed1ac",
    ),
    "ING04_5": (
        "INGENIERIA_04_5_DEE_V27_ARQUITECTURA_CAUSAL_NATIVA_ESTADO_ADAPTATIVO_Y_REACHABILITY_RESULTADOS.zip",
        "b188cd77f70d9a42da5305c4080b3dea12b60f7a3dd4f74e1b9805c5996cd7a7",
    ),
    "POST_ING04_5": (
        "POST_INGENIERIA_04_5_DEE_V27_REORGANIZACION_NATIVA_Y_ESCALAMIENTO_ADAPTATIVO_RESULTADOS.zip",
        "ebe3e532b38f1732077fb8c062c2ddee0250b8d8f622fda1c25f8829cb3d457c",
    ),
}


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_inputs() -> list[dict]:
    if sha_file(KERNEL) != KERNEL_SHA:
        raise RuntimeError("Kernel SHA mismatch")
    parent_records = []
    for role, (name, expected) in PARENTS.items():
        path = (OFFICIAL / name).resolve()
        if path.parent != OFFICIAL.resolve():
            raise RuntimeError("Parent escaped official directory")
        actual = sha_file(path)
        if actual != expected:
            raise RuntimeError(f"Parent hash mismatch: {name}")
        with zipfile.ZipFile(path, "r") as archive:
            bad = archive.testzip()
            if bad is not None:
                raise RuntimeError(f"Parent CRC failure: {name}:{bad}")
            parent_records.append({"role": role, "filename": name, "sha256": actual,
                                   "bytes": path.stat().st_size,
                                   "members": len(archive.infolist()), "crc": "PASS"})
    for path in CONT.rglob("*.json"):
        json.loads(path.read_text(encoding="utf-8-sig"))
    for path in CONT.rglob("*.py"):
        ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    ra01 = json.loads((CONT / "RESULTS/ING04_RA01_SYMMETRIC_RELATIONAL_CHAIN.json").read_text(encoding="utf-8"))
    ra02 = json.loads((CONT / "RESULTS/ING04_RA02_SHARED_INTERFACE_CHAIN.json").read_text(encoding="utf-8"))
    checkpoint = json.loads((CONT / "CHECKPOINT.json").read_text(encoding="utf-8"))
    if ra01["status"] != "BOUNDED_NULL_RA01_RELATIONAL_CHAIN":
        raise RuntimeError("RA01 adjudication mismatch")
    if ra02["status"] != "BOUNDED_NULL_RA02_SHARED_INTERFACE_CHAIN":
        raise RuntimeError("RA02 adjudication mismatch")
    if checkpoint["maximum_rw"] != "RW2_INHERITED" or checkpoint["l4"] is not False:
        raise RuntimeError("Checkpoint overclaim")
    return parent_records


def payload_sources() -> dict[str, Path]:
    sources: dict[str, Path] = {}
    for role, (name, _) in PARENTS.items():
        sources[f"{role}/{name}"] = OFFICIAL / name
    master_map = {
        "MASTER_INDEX/MASTER_INDEX.md": CONT / "MASTER_INDEX.md",
        "MASTER_INDEX/FINAL_VERDICT.md": CONT / "FINAL_VERDICT.md",
        "MASTER_INDEX/FINAL_FRONTIER.md": CONT / "FINAL_FRONTIER.md",
        "MASTER_INDEX/CHECKPOINT.json": CONT / "CHECKPOINT.json",
        "MASTER_CLAIM_LEDGER/CLAIM_LEDGER.json": CONT / "CLAIM_LEDGER.json",
        "PROVENANCE/PROVENANCE.json": CONT / "PROVENANCE.json",
    }
    sources.update(master_map)
    excluded = {"MASTER_INDEX.md", "FINAL_VERDICT.md", "FINAL_FRONTIER.md", "CHECKPOINT.json",
                "CLAIM_LEDGER.json", "PROVENANCE.json"}
    for path in CONT.rglob("*"):
        if not path.is_file() or path.name in excluded or path.suffix.lower() in {".pyc", ".zip"}:
            continue
        if "__pycache__" in path.parts:
            continue
        rel = path.relative_to(CONT).as_posix()
        sources[f"CONTINUACION_RESERVA_ADAPTATIVA/{rel}"] = path
    if len(sources) != len(set(sources)):
        raise RuntimeError("Duplicate package member path")
    return dict(sorted(sources.items()))


def write_zip(parent_records: list[dict], sources: dict[str, Path]) -> None:
    manifest = {
        "schema": "dee.v27.ing04.integrated_final.manifest.v1",
        "package": FINAL_NAME,
        "status": "CLOSED_AT_CAUSAL_SATURATION",
        "kernel_sha256": KERNEL_SHA,
        "parents": parent_records,
        "maximum_rw": "RW2_INHERITED",
        "maximum_autonomy": "L3_FINITE_INHERITED",
        "rw3": False, "rw4": False, "rw5": False, "l4": False,
        "engineering_05_created": False,
        "payload": [{"path": member, "bytes": path.stat().st_size, "sha256": sha_file(path)}
                    for member, path in sources.items()],
        "hash_convention": "HASHES covers every ZIP member except itself.",
        "expected_member_count": len(sources) + 2,
    }
    manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    members = {member: path.read_bytes() for member, path in sources.items()}
    members["MANIFEST/MANIFEST.json"] = manifest_bytes
    hash_lines = [f"{sha_bytes(data)}  {member}" for member, data in sorted(members.items())]
    members["HASHES/HASHES.sha256"] = ("\n".join(hash_lines) + "\n").encode("utf-8")
    if TEMP_ZIP.exists():
        TEMP_ZIP.unlink()
    with zipfile.ZipFile(TEMP_ZIP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for member, data in sorted(members.items()):
            info = zipfile.ZipInfo(member, date_time=FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    os.replace(TEMP_ZIP, FINAL_ZIP)


def validate_integrated() -> dict:
    with zipfile.ZipFile(FINAL_ZIP, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Integrated CRC failure: {bad}")
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise RuntimeError("Duplicate integrated members")
        manifest = json.loads(archive.read("MANIFEST/MANIFEST.json"))
        if len(names) != manifest["expected_member_count"]:
            raise RuntimeError("Manifest count mismatch")
        covered = set()
        for line in archive.read("HASHES/HASHES.sha256").decode("utf-8").splitlines():
            expected, member = line.split("  ", 1)
            if sha_bytes(archive.read(member)) != expected:
                raise RuntimeError(f"Internal hash mismatch: {member}")
            covered.add(member)
        if set(names) != covered | {"HASHES/HASHES.sha256"}:
            raise RuntimeError("Internal hash coverage mismatch")
        for role, (name, expected) in PARENTS.items():
            if sha_bytes(archive.read(f"{role}/{name}")) != expected:
                raise RuntimeError(f"Embedded parent mismatch: {role}")
        return {"sha256": sha_file(FINAL_ZIP), "bytes": FINAL_ZIP.stat().st_size,
                "members": len(names), "crc": "PASS", "internal_hashes": "PASS",
                "embedded_parent_hashes": "PASS", "manifest": "PASS"}


def retire_lateral_archives() -> list[str]:
    removed = []
    for _, (name, expected) in PARENTS.items():
        path = (OFFICIAL / name).resolve()
        if path.parent != OFFICIAL.resolve() or sha_file(path) != expected:
            raise RuntimeError(f"Refusing to remove unresolved parent: {name}")
        path.unlink()
        removed.append(name)
    return removed


def validate_official_directory() -> dict:
    files = sorted(path.name for path in OFFICIAL.iterdir() if path.is_file())
    loose = [name for name in files if not name.lower().endswith(".zip")]
    lateral = [name for name in files if ("INGENIERIA_04" in name or name.startswith("POST_INGENIERIA_04_5"))
               and name != FINAL_NAME]
    if loose or lateral or FINAL_NAME not in files:
        raise RuntimeError(f"Official directory audit failed: loose={loose}, lateral={lateral}")
    return {"files": files, "loose_files": 0, "lateral_ing04_archives": 0}


def main() -> None:
    parent_records = verify_inputs()
    sources = payload_sources()
    write_zip(parent_records, sources)
    audit = validate_integrated()
    removed = retire_lateral_archives()
    directory = validate_official_directory()
    print(json.dumps({
        "final_zip": str(FINAL_ZIP), **audit,
        "retired_lateral_archives": removed,
        "official_directory": directory,
        "FINAL_ZIP_READY": "YES",
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
