#!/usr/bin/env python3
"""RA01: frozen symmetric two-edge relational-function chain pilot."""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
ING02_RUNNERS = ROOT.parent.parent / "INGENIERIA_02" / "RUNNERS"
sys.path.insert(0, str(ING02_RUNNERS))

from ing02_common import add, load_kernel, pack, read, seal, transform, write_json
from run_d09_relative_readout_longevity import PATTERN_A, PATTERN_B
from temporal_order_apparatus_v1 import construct as construct_primary


LOCK_PATH = ROOT / "FREEZE" / "ING04_RA01_LOCK.json"
OUTPUT = ROOT / "RESULTS" / "ING04_RA01_SYMMETRIC_RELATIONAL_CHAIN.json"


def put(world, q, raw, clock):
    if int(world.raw_a[q]) or int(world.raw_b[q]):
        raise RuntimeError(f"initial overlap at {q}")
    world.raw_a[q] = np.uint64(raw)
    world.raw_b[q] = np.uint64(raw)
    world.clock_a[q] = np.uint64(clock)
    world.clock_b[q] = np.uint64(clock)


def install_module(world, center, signs, reader_enabled):
    n = world.n
    tf = lambda v: transform(v, (0, 1, 2), signs)
    axis = tf((1, 0, 0))
    a = add(center, tf((-1, 0, 0)), 1, n)
    b = add(center, axis, 1, n)
    put(world, a, pack(1000, 100, (0, 0, 0), 1), 260)
    put(world, b, pack(2000, 100, (0, 0, 0), 1), 260)
    positions = [a, b]
    for index, offset in enumerate(PATTERN_A):
        q = add(a, tf(offset), 1, n)
        put(world, q, pack(3000 + index, 0, (0, 0, 0), 4), 31 + index)
        positions.append(q)
    for index, offset in enumerate(PATTERN_B):
        q = add(b, tf(offset), 1, n)
        put(world, q, pack(4000 + index, 0, (0, 0, 0), 4), 41 + index)
        positions.append(q)
    reader_source = add(center, tf((0, -2, 0)), 1, n)
    if reader_enabled:
        put(world, reader_source, pack(6000, 7, tf((0, 1, 0)), 4), 23)
        positions.append(reader_source)
    return {
        "center": center,
        "a": a,
        "b": b,
        "comparator": center,
        "reader_source": reader_source,
        "axis": axis,
        "positions": positions,
    }


def canonical_module(world, module):
    ra = read(world.raw, module["a"])
    rb = read(world.raw, module["b"])
    rc = read(world.raw, module["comparator"])
    delta = None if ra is None or rb is None else int(ra["sreg"] - rb["sreg"])
    projection = None if rc is None else int(sum(rc["direction"][i] * module["axis"][i] for i in range(3)))
    return {
        "delta": delta,
        "projection": projection,
        "a_present": ra is not None,
        "b_present": rb is not None,
        "comparator_present": rc is not None,
    }


def digest_world(world):
    h = hashlib.sha256()
    h.update(np.ascontiguousarray(world.raw).tobytes())
    h.update(np.ascontiguousarray(world.clock_a).tobytes())
    return h.hexdigest()


def build_world(kernel, mode, lock):
    domain = lock["domain"]
    base_mode = "AB" if mode.startswith("AB") else "BA" if mode.startswith("BA") else "no_events"
    world, primary = construct_primary(kernel, {
        "n": domain["n"],
        "origin": domain["origin"],
        "mode": base_mode,
        "event_sreg": 0,
    })
    if mode.endswith("PRIMARY_CUT"):
        q = tuple(primary["reader_source"])
        world.raw_a[q] = world.raw_b[q] = np.uint64(0)
        world.clock_a[q] = world.clock_b[q] = np.uint64(0)

    c = tuple(domain["origin"])
    modules = {"primary": {**primary, "center": c}}
    for stage, distance in (("secondary", domain["secondary_distance"]),
                            ("tertiary", domain["tertiary_distance"])):
        for side, sign in (("plus", 1), ("minus", -1)):
            center = add(c, (1, 0, 0), sign * distance, domain["n"])
            reader_enabled = stage == "secondary" and not mode.endswith("SECONDARY_CUT")
            if stage == "tertiary":
                reader_enabled = False
            modules[f"{stage}_{side}"] = install_module(
                world, center, (sign, 1, 1), reader_enabled
            )
    return world, modules


def stable_signature(trace, tail):
    rows = trace[-tail:]
    deltas = [row["delta"] for row in rows]
    projections = [row["projection"] for row in rows]
    return {
        "delta_tail": deltas,
        "projection_tail": projections,
        "delta_stable": len(set(deltas)) == 1,
        "projection_stable": len(set(projections)) == 1,
        "terminal_delta": deltas[-1],
        "terminal_projection": projections[-1],
        "retained_nonzero_delta": len(set(deltas)) == 1 and deltas[-1] not in (None, 0),
    }


def reflected_pair_signature(row, stage):
    return (
        row["signatures"][f"{stage}_plus"]["terminal_delta"],
        row["signatures"][f"{stage}_minus"]["terminal_delta"],
    )


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    kernel, runtime = load_kernel(1)
    rows = []
    initial_equivalence = []
    for mode in lock["domain"]["modes"]:
        world, modules = build_world(kernel, mode, lock)
        initial_support = int(np.count_nonzero(world.raw))
        initial_hash = digest_world(world)
        for stage in ("secondary", "tertiary"):
            plus = canonical_module(world, modules[f"{stage}_plus"])
            minus = canonical_module(world, modules[f"{stage}_minus"])
            initial_equivalence.append({"mode": mode, "stage": stage, "equal": plus == minus})
        traces = {name: [] for name in modules}
        support = [initial_support]
        for _ in range(lock["domain"]["horizon"]):
            world.tick()
            support.append(int(np.count_nonzero(world.raw)))
            for name, module in modules.items():
                traces[name].append(canonical_module(world, module))
        signatures = {
            name: stable_signature(trace, lock["domain"]["tail"])
            for name, trace in traces.items()
        }
        rows.append({
            "mode": mode,
            "initial_full_state_sha256": initial_hash,
            "signatures": signatures,
            "resource": {
                "initial_support": initial_support,
                "maximum_support": max(support),
                "terminal_support": support[-1],
                "world_cells": world.n ** 3,
                "terminal_support_fraction": support[-1] / (world.n ** 3),
            },
            "terminal_full_state_sha256": digest_world(world),
        })

    by_mode = {row["mode"]: row for row in rows}
    ab_secondary = reflected_pair_signature(by_mode["AB_FULL"], "secondary")
    ba_secondary = reflected_pair_signature(by_mode["BA_FULL"], "secondary")
    no_secondary = reflected_pair_signature(by_mode["NO_EVENTS"], "secondary")
    ab_primary_cut = reflected_pair_signature(by_mode["AB_PRIMARY_CUT"], "secondary")
    ba_primary_cut = reflected_pair_signature(by_mode["BA_PRIMARY_CUT"], "secondary")
    ab_tertiary = reflected_pair_signature(by_mode["AB_FULL"], "tertiary")
    ba_tertiary = reflected_pair_signature(by_mode["BA_FULL"], "tertiary")
    ab_second_cut = reflected_pair_signature(by_mode["AB_SECONDARY_CUT"], "tertiary")
    ba_second_cut = reflected_pair_signature(by_mode["BA_SECONDARY_CUT"], "tertiary")

    primary_function = bool(
        by_mode["AB_FULL"]["signatures"]["primary"]["terminal_projection"] == 1
        and by_mode["BA_FULL"]["signatures"]["primary"]["terminal_projection"] == -1
    )
    secondary_mirror_covariant = bool(
        ab_secondary == tuple(reversed(ba_secondary)) and ab_secondary[0] != ab_secondary[1]
    )
    secondary_depends_on_primary_function = bool(
        ab_secondary != ab_primary_cut and ba_secondary != ba_primary_cut
    )
    secondary_not_no_event = bool(ab_secondary != no_secondary and ba_secondary != no_secondary)
    tertiary_mirror_covariant = bool(
        ab_tertiary == tuple(reversed(ba_tertiary)) and ab_tertiary[0] != ab_tertiary[1]
    )
    tertiary_depends_on_secondary_function = bool(
        ab_tertiary != ab_second_cut and ba_tertiary != ba_second_cut
    )
    first_edge = all((secondary_mirror_covariant, secondary_depends_on_primary_function,
                      secondary_not_no_event))
    second_edge = all((tertiary_mirror_covariant, tertiary_depends_on_secondary_function))
    pilot_pass = bool(primary_function and first_edge and second_edge)
    status = "TWO_EDGE_NATIVE_CAUSAL_CHAIN_CANDIDATE" if pilot_pass else "BOUNDED_NULL_RA01_RELATIONAL_CHAIN"

    result = seal({
        "schema": "dee.v27.ing04.integrated_continuation.ra01.result.v1",
        "experiment_id": lock["experiment_id"],
        "lock": str(LOCK_PATH),
        "design": {
            "all_causes_installed_at_t0": True,
            "post_t0_python": ["tick", "log", "stop"],
            "host_edits_after_t0": 0,
            "regions_preassigned_to_answer": False,
            "candidate_regions_initially_reflection_equivalent": all(x["equal"] for x in initial_equivalence),
            "scratch_observed": False,
            **lock["domain"],
        },
        "initial_equivalence_audit": initial_equivalence,
        "rows": rows,
        "adjudication": {
            "primary_function": primary_function,
            "secondary_signatures": {"AB": ab_secondary, "BA": ba_secondary, "NO_EVENTS": no_secondary,
                                     "AB_PRIMARY_CUT": ab_primary_cut, "BA_PRIMARY_CUT": ba_primary_cut},
            "secondary_mirror_covariant": secondary_mirror_covariant,
            "secondary_depends_on_primary_function": secondary_depends_on_primary_function,
            "secondary_not_no_event": secondary_not_no_event,
            "first_native_edge": first_edge,
            "tertiary_signatures": {"AB": ab_tertiary, "BA": ba_tertiary,
                                    "AB_SECONDARY_CUT": ab_second_cut, "BA_SECONDARY_CUT": ba_second_cut},
            "tertiary_mirror_covariant": tertiary_mirror_covariant,
            "tertiary_depends_on_secondary_function": tertiary_depends_on_secondary_function,
            "second_native_edge": second_edge,
            "pilot_pass": pilot_pass,
        },
        "status": status,
        "rw_adjudication": {"RW3": False, "RW4": False, "RW5": False, "L4": False},
        "claim_guard": lock["claim_guard"],
        "runtime": runtime,
    })
    write_json(OUTPUT, result)
    print(json.dumps({
        "output": str(OUTPUT),
        "status": status,
        "adjudication": result["adjudication"],
        "content_sha256": result["content_sha256"],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
