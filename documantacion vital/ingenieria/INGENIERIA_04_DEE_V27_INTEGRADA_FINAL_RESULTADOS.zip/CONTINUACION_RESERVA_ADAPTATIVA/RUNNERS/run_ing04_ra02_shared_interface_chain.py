#!/usr/bin/env python3
"""RA02: shared-interface variant of the frozen relational chain."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve()
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE.parent))
import run_ing04_ra01_symmetric_relational_chain as ra01


LOCK_PATH = ROOT / "FREEZE" / "ING04_RA02_LOCK.json"
OUTPUT = ROOT / "RESULTS" / "ING04_RA02_SHARED_INTERFACE_CHAIN.json"


def normalize_primary_identifiers(world, primary):
    for key in ("a", "b"):
        q = tuple(primary[key])
        rec = ra01.read(world.raw, q)
        world.raw_a[q] = world.raw_b[q] = np.uint64(
            ra01.pack(1000, rec["sreg"], rec["direction"], rec["semantic"])
        )
    for q in primary["event_sources"]:
        q = tuple(q)
        rec = ra01.read(world.raw, q)
        if rec is not None:
            world.raw_a[q] = world.raw_b[q] = np.uint64(
                ra01.pack(5000, rec["sreg"], rec["direction"], rec["semantic"])
            )


def install_shared_module(world, center, signs, reader_enabled, allowed_shared):
    n = world.n
    tf = lambda v: ra01.transform(v, (0, 1, 2), signs)
    axis = tf((1, 0, 0))
    a = ra01.add(center, tf((-1, 0, 0)), 1, n)
    b = ra01.add(center, axis, 1, n)
    ra01.put(world, a, ra01.pack(1000, 100, (0, 0, 0), 1), 260)
    ra01.put(world, b, ra01.pack(2000, 100, (0, 0, 0), 1), 260)
    positions = [a, b]
    shared = []
    for index, offset in enumerate(ra01.PATTERN_A):
        q = ra01.add(a, tf(offset), 1, n)
        if int(world.raw_a[q]):
            existing = ra01.read(world.raw, q)
            if existing is None or int(existing["semantic"]) != 4:
                raise RuntimeError(f"non-semantic4 overlap at {q}: {existing}")
            shared.append(q)
        else:
            ra01.put(world, q, ra01.pack(3000 + index, 0, (0, 0, 0), 4), 31 + index)
        positions.append(q)
    for index, offset in enumerate(ra01.PATTERN_B):
        q = ra01.add(b, tf(offset), 1, n)
        if int(world.raw_a[q]):
            existing = ra01.read(world.raw, q)
            if existing is None or int(existing["semantic"]) != 4:
                raise RuntimeError(f"non-semantic4 overlap at {q}: {existing}")
            shared.append(q)
        else:
            ra01.put(world, q, ra01.pack(4000 + index, 0, (0, 0, 0), 4), 41 + index)
        positions.append(q)
    reader_source = ra01.add(center, tf((0, -2, 0)), 1, n)
    if reader_enabled:
        ra01.put(world, reader_source, ra01.pack(6000, 7, tf((0, 1, 0)), 4), 23)
        positions.append(reader_source)
    return {
        "center": center, "a": a, "b": b, "comparator": center,
        "reader_source": reader_source, "axis": axis,
        "positions": positions, "shared_positions": shared,
    }


def build_world(kernel, mode, lock):
    d = lock["domain"]
    base_mode = "AB" if mode.startswith("AB") else "BA" if mode.startswith("BA") else "no_events"
    world, primary = ra01.construct_primary(kernel, {
        "n": d["n"], "origin": d["origin"], "mode": base_mode, "event_sreg": 0,
    })
    normalize_primary_identifiers(world, primary)
    if mode.endswith("PRIMARY_CUT"):
        q = tuple(primary["reader_source"])
        world.raw_a[q] = world.raw_b[q] = np.uint64(0)
        world.clock_a[q] = world.clock_b[q] = np.uint64(0)
    c = tuple(d["origin"])
    modules = {"primary": {**primary, "center": c}}
    for side, sign, shared_key in (("plus", 1, "b"), ("minus", -1, "a")):
        center = ra01.add(c, (1, 0, 0), sign * d["secondary_distance"], d["n"])
        shared_endpoint = tuple(primary[shared_key])
        shared_support = ra01.add(shared_endpoint, (sign, 0, 0), 1, d["n"])
        modules[f"secondary_{side}"] = install_shared_module(
            world, center, (sign, 1, 1), not mode.endswith("SECONDARY_CUT"),
            {shared_support},
        )
    for side, sign in (("plus", 1), ("minus", -1)):
        center = ra01.add(c, (1, 0, 0), sign * d["tertiary_distance"], d["n"])
        secondary = modules[f"secondary_{side}"]
        shared_support = ra01.add(tuple(secondary["b"]), tuple(secondary["axis"]), 1, d["n"])
        modules[f"tertiary_{side}"] = install_shared_module(
            world, center, (sign, 1, 1), False,
            {shared_support},
        )
    return world, modules


def pair_signature(row, stage):
    return (
        row["signatures"][f"{stage}_plus"]["terminal_delta"],
        row["signatures"][f"{stage}_minus"]["terminal_delta"],
    )


def main():
    lock = json.loads(LOCK_PATH.read_text(encoding="utf-8"))
    kernel, runtime = ra01.load_kernel(1)
    rows = []
    equivalence = []
    for mode in lock["domain"]["modes"]:
        world, modules = build_world(kernel, mode, lock)
        initial_support = int(np.count_nonzero(world.raw))
        initial_hash = ra01.digest_world(world)
        for stage in ("secondary", "tertiary"):
            plus = ra01.canonical_module(world, modules[f"{stage}_plus"])
            minus = ra01.canonical_module(world, modules[f"{stage}_minus"])
            equivalence.append({"mode": mode, "stage": stage, "equal": plus == minus})
        traces = {name: [] for name in modules}
        support = [initial_support]
        for _ in range(lock["domain"]["horizon"]):
            world.tick()
            support.append(int(np.count_nonzero(world.raw)))
            for name, module in modules.items():
                traces[name].append(ra01.canonical_module(world, module))
        rows.append({
            "mode": mode,
            "initial_full_state_sha256": initial_hash,
            "signatures": {name: ra01.stable_signature(trace, lock["domain"]["tail"])
                           for name, trace in traces.items()},
            "shared_interfaces": {name: [list(q) for q in module.get("shared_positions", [])]
                                  for name, module in modules.items() if name != "primary"},
            "resource": {"initial_support": initial_support, "maximum_support": max(support),
                         "terminal_support": support[-1], "world_cells": world.n ** 3,
                         "terminal_support_fraction": support[-1] / (world.n ** 3)},
            "terminal_full_state_sha256": ra01.digest_world(world),
        })
    m = {row["mode"]: row for row in rows}
    ab_s, ba_s, no_s = pair_signature(m["AB_FULL"], "secondary"), pair_signature(m["BA_FULL"], "secondary"), pair_signature(m["NO_EVENTS"], "secondary")
    ab_pc, ba_pc = pair_signature(m["AB_PRIMARY_CUT"], "secondary"), pair_signature(m["BA_PRIMARY_CUT"], "secondary")
    ab_t, ba_t = pair_signature(m["AB_FULL"], "tertiary"), pair_signature(m["BA_FULL"], "tertiary")
    ab_sc, ba_sc = pair_signature(m["AB_SECONDARY_CUT"], "tertiary"), pair_signature(m["BA_SECONDARY_CUT"], "tertiary")
    primary_function = m["AB_FULL"]["signatures"]["primary"]["terminal_projection"] == 1 and m["BA_FULL"]["signatures"]["primary"]["terminal_projection"] == -1
    secondary_mirror = ab_s == tuple(reversed(ba_s)) and ab_s[0] != ab_s[1]
    first_edge = secondary_mirror and ab_s != no_s and ba_s != no_s and ab_s != ab_pc and ba_s != ba_pc
    tertiary_mirror = ab_t == tuple(reversed(ba_t)) and ab_t[0] != ab_t[1]
    second_edge = tertiary_mirror and ab_t != ab_sc and ba_t != ba_sc
    pilot_pass = bool(primary_function and first_edge and second_edge)
    status = "TWO_EDGE_SHARED_INTERFACE_CANDIDATE" if pilot_pass else "BOUNDED_NULL_RA02_SHARED_INTERFACE_CHAIN"
    result = ra01.seal({
        "schema": "dee.v27.ing04.integrated_continuation.ra02.result.v1",
        "experiment_id": lock["experiment_id"], "lock": str(LOCK_PATH),
        "design": {"all_causes_installed_at_t0": True, "host_edits_after_t0": 0,
                   "post_t0_python": ["tick", "log", "stop"],
                   "candidate_regions_initially_reflection_equivalent": all(x["equal"] for x in equivalence),
                   "shared_topology": True, "scratch_observed": False, **lock["domain"]},
        "initial_equivalence_audit": equivalence, "rows": rows,
        "adjudication": {
            "primary_function": bool(primary_function),
            "secondary_signatures": {"AB": ab_s, "BA": ba_s, "NO_EVENTS": no_s, "AB_PRIMARY_CUT": ab_pc, "BA_PRIMARY_CUT": ba_pc},
            "secondary_mirror_covariant": bool(secondary_mirror), "first_native_edge": bool(first_edge),
            "tertiary_signatures": {"AB": ab_t, "BA": ba_t, "AB_SECONDARY_CUT": ab_sc, "BA_SECONDARY_CUT": ba_sc},
            "tertiary_mirror_covariant": bool(tertiary_mirror), "second_native_edge": bool(second_edge),
            "pilot_pass": pilot_pass,
        },
        "status": status, "rw_adjudication": {"RW3": False, "RW4": False, "RW5": False, "L4": False},
        "claim_guard": lock["claim_guard"], "runtime": runtime,
    })
    ra01.write_json(OUTPUT, result)
    print(json.dumps({"output": str(OUTPUT), "status": status,
                      "adjudication": result["adjudication"],
                      "content_sha256": result["content_sha256"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
