# Ingeniería 04 integrada — frontera causal

## Cadena demostrada

```text
experiencia inicial
→ historia causal retenida
→ organización distribuida/relacional
→ función nativa
→ influencia causal sobre otras regiones
```

POST04.5 confirma que la última flecha puede cambiar el régimen temporal de receptores equivalentes. No confirma que esos receptores adquieran la función fuente ni competencia C2 renovada.

## Cadena que no cerró

```text
función nativa
→ cambio ambiental selectivo
→ nueva experiencia
→ nueva distinción retenida
→ nueva función
```

RA01 falla en `función → escritura ambiental`: la función se conserva, pero los pares secundarios permanecen en `delta=0`.

RA02 falla antes: la integración por soporte compartido elimina la función primaria y genera cambios independientes de historia.

## Arista faltante exacta

Se necesita una operación DEE-native que satisfaga simultáneamente:

1. la función actual produce una consecuencia física;
2. esa consecuencia cambia una contingencia ambiental real;
3. la contingencia encuentra regiones inicialmente equivalentes;
4. sólo la historia causal decide qué relación cambia;
5. el cambio queda retenido y altera función posterior;
6. la capacidad para otra experiencia permanece o se renueva;
7. el recurso no crece una unidad virgen por experiencia.

Ni el espacio vacío, ni la repoblación, ni el cambio remoto de periodo, ni una interfaz compartida satisfacen por separado esta conjunción.

## Siguiente pregunta científica

¿Existe un writer ambiental nativo generado por la función —no un reader reutilizado como writer— que transforme una relación competente sin destruir la organización funcional que produjo la consecuencia?

Responderla requiere una nueva operación causal concreta. No justifica más distancias, fases o topologías del aparato RA01/RA02.

