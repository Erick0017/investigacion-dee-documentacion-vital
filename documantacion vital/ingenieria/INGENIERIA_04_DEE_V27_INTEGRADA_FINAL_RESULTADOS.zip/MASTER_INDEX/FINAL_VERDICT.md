# Ingeniería 04 integrada — veredicto final

## Resultado

La continuación no encontró una operación nueva de reserva adaptativa. Dos composiciones causalmente distintas quedaron cerradas como nulls acotados:

- **RA01, organizaciones separadas:** la función relacional primaria AB/BA permaneció exacta, pero las cuatro organizaciones equivalentes posteriores conservaron `delta=0`. La función no escribió una nueva distinción relacional a distancia.
- **RA02, interfaz topológica compartida:** la topología compartida eliminó la función primaria y produjo cambios basales independientes de AB/BA. `AB`, `BA`, `NO_EVENTS` y los cortes causales coincidieron en los pares relevantes. No hubo selección por historia.

RA01 y RA02 convergen en el mismo obstáculo: el readout relacional de ING02 no es por sí mismo un writer ambiental capaz de crear una experiencia posterior. La separación preserva la función pero no transmite una escritura; compartir soporte transmite perturbación estructural, pero destruye discriminación funcional y no selecciona por historia.

## Veredicto solicitado

- **Mecanismo nativo descubierto:** ninguno nuevo en esta continuación. Se preserva el hallazgo POST04.5 de acoplamiento distribuido condicionado por historia (`periodo 2 → periodo 1`), sin reinstanciación funcional ni competencia renovada.
- **Arquitectura causal observada:** memoria relacional + readout persistente funciona localmente; organizaciones separadas permanecen funcionalmente desacopladas; una interfaz compartida introduce acoplamiento no selectivo y altera la organización fuente.
- **Cómo función cambia entorno:** POST04.5 demuestra cambio remoto de régimen temporal. RA01 demuestra que ese tipo de función no escribe `delta` en los receptores relacionales separados ensayados.
- **Cómo entorno genera la siguiente experiencia:** no demostrado.
- **Cómo se conserva/renueva capacidad futura:** no demostrado. Espacio vacío y bajo soporte no se interpretan como reserva causal.
- **Transiciones adaptativas completas nuevas:** 0.
- **Recurso usado/reutilizado:** RA01 alcanzó como máximo 259 posiciones ocupadas de 103.823; RA02, 216. El soporte permaneció acotado en 128 ticks, pero no produjo competencia futura.
- **Candidato L4 directo:** `NO`.
- **Fenómeno inesperado:** compartir soportes semantic4 produce asimetrías basales reproducibles y extingue la función primaria, mostrando conflicto entre integración topológica y discriminación histórica en este aparato.
- **Frontera causal:** falta un writer nativo condicionado por función que convierta una consecuencia ambiental en una nueva distinción retenida sin destruir función, sin preasignar el receptor y sin consumir soporte fresco por experiencia.

## Nivel

El máximo formal sigue siendo `RW2_INHERITED` y `L3_FINITE_INHERITED`. RW3, RW4, RW5 y L4 permanecen no demostrados. No se abre Ingeniería 05.

