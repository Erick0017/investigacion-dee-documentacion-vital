# Ingeniería 04 integrada — índice maestro

Esta entrega consolida, sin alterar sus bytes, las tres entregas previas de la misma línea científica:

- `ING04_BASE/`: Ingeniería 04 final.
- `ING04_5/`: reconstrucción causal y reachability.
- `POST_ING04_5/`: pilotos U1/U2/U3 y corrección metodológica P01R.
- `CONTINUACION_RESERVA_ADAPTATIVA/`: revisión dirigida, RA01 y RA02.

Los tres padres se conservan como ZIP embebidos con sus SHA-256 oficiales. Los resultados nuevos se entregan como locks, runners y telemetría directamente auditables.

## Lectura científica mínima

1. `FINAL_VERDICT.md` — adjudicación integrada.
2. `FINAL_FRONTIER.md` — arista causal faltante.
3. `CLAIM_LEDGER.json` — claims y límites.
4. `RESULTS/ING04_RA01_SYMMETRIC_RELATIONAL_CHAIN.json` — acoplamiento separado.
5. `RESULTS/ING04_RA02_SHARED_INTERFACE_CHAIN.json` — topología compartida.
6. `INTERVENTION_AUDIT.json` y `RESOURCE_AUDIT.json` — límites de autonomía y recursos.
7. `REPRODUCTION.md` — reproducción exacta.

## Estado

- Nuevo mecanismo adaptativo en esta continuación: `NO`.
- Máximo preservado: `RW2_INHERITED / L3_FINITE_INHERITED`.
- RW3/RW4/RW5/L4: no demostrados.
- Ingeniería 05: no creada ni autorizada.

