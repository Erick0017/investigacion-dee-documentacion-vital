# Reproducción de NRD04

Requisitos: Windows x64, CPython 3.13 y NumPy. La sección `04_RAW_CAUSAL_MINIMUM` del ZIP integrado contiene inputs, dependencias, kernel y runners.

Desde esa sección extraída, ejecutar:

```powershell
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd04_stage_ab.py' --threads 1
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd04_exhaustive_subsets.py' --threads 1
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd04_value_position.py' --threads 1
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd04_fresh_minimal_support.py' --threads 1
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd04_sequential_reachability.py' --threads 1
```

El segundo runner reutiliza los fingerprints ya generados por el primero. No ejecuta nuevamente esos subconjuntos.

Kernel canónico SHA-256:

`0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`

