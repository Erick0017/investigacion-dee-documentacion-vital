#!/usr/bin/env python3
"""Create and validate the single open Ingeniería 05 integrated archive."""
from __future__ import annotations

import hashlib
import io
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
TESTS = ROOT.parents[2]
OFFICIAL = TESTS / "documantacion vital" / "ingenieria"
OUT = OFFICIAL / "INGENIERIA_05_DEE_V27_INTEGRADA_RESULTADOS.zip"

PARENTS = (
    ("01_NATIVE_REACHABILITY", OFFICIAL / "INGENIERIA_05_DEE_V27_NATIVE_REACHABILITY_DISCOVERY_RESULTADOS.zip"),
    ("02_CAMBIO_NATIVO_FUTUROS", OFFICIAL / "DEE_V27_CAMBIO_NATIVO_DE_FUTUROS_ACCESIBLES_RESULTADOS.zip"),
    ("03_CLOCK_RESIDUE_TEST", OFFICIAL / "INGENIERIA_05_CONTINUACION_DEE_V27_CLOCK_RESIDUE_CAUSAL_TEST_RESULTADOS.zip"),
)


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def add_file(zf, source, target, inventory):
    source = Path(source)
    data = source.read_bytes()
    zf.writestr(target, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    inventory.append({"path": target, "sha256": sha_bytes(data), "size": len(data)})


def main():
    expected_parent_hashes = {
        "01_NATIVE_REACHABILITY": "a82d242803785a8d3721252c8591f65f255641b7eb6425988f5fb1afb3b10bcc",
        "02_CAMBIO_NATIVO_FUTUROS": "a82d242803785a8d3721252c8591f65f255641b7eb6425988f5fb1afb3b10bcc",
        "03_CLOCK_RESIDUE_TEST": "018aa6f3ac0cd641f30348a4007115dd91d053dc82cbb6dbb1671fbb928d76a1",
    }
    for section, path in PARENTS:
        if not path.is_file():
            raise FileNotFoundError(path)
        observed = sha_file(path)
        if observed != expected_parent_hashes[section]:
            raise RuntimeError(f"Parent hash mismatch {section}: {observed}")
        with zipfile.ZipFile(path, "r") as nested:
            if nested.testzip() is not None:
                raise RuntimeError(f"Nested ZIP CRC failure: {path}")

    local = [
        ROOT / "SCIENTIFIC_REPORT.md",
        ROOT / "REPRODUCTION.md",
        ROOT / "MASTER_INDEX.md",
        *sorted((ROOT / "FREEZE").glob("*.json")),
        *sorted((ROOT / "RUNNERS").glob("*.py")),
        *sorted((ROOT / "RESULTS").glob("*.json")),
        *sorted((ROOT / "TELEMETRY").glob("*.npz")),
    ]
    inputs = [
        ROOT.parent / "NATIVE_REACHABILITY_DEE_V27" / "TELEMETRY" / "NRD01_CHECKPOINTS.npz",
        ROOT.parent / "INGENIERIA_05_CONTINUACION_CLOCK_RESIDUE" / "TELEMETRY" / "NRD03_FACTORIAL_TRAJECTORIES.npz",
    ]
    ing02 = ROOT.parent / "INGENIERIA_02" / "RUNNERS"
    dependencies = [
        ing02 / "ing02_common.py",
        ing02 / "temporal_order_apparatus_v1.py",
        ing02 / "run_d09_relative_readout_longevity.py",
        ing02 / "paired_relative_apparatus_v2.py",
    ]
    package_dir = TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "ANALYSIS" / "binary_api" / "wheel_extracted" / "dee_universe_v27"
    kernel_files = sorted(path for path in package_dir.iterdir() if path.is_file())
    wheel = TESTS / "DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK" / "FINAL_PACKAGE" / "INPUTS" / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
    missing = [str(path) for path in local + inputs + dependencies + kernel_files + [wheel] if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)

    if OUT.exists():
        OUT.unlink()
    inventory = []
    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for section, path in PARENTS:
            add_file(zf, path, f"INGENIERIA_05/{section}/{path.name}", inventory)
        for source in local:
            if source.name == "MASTER_INDEX.md":
                target = "INGENIERIA_05/MASTER_INDEX/MASTER_INDEX.md"
            elif source.parent.name == "FREEZE":
                target = f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/FREEZE/{source.name}"
            elif source.parent.name == "RUNNERS":
                target = f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/RUNNERS/{source.name}"
            elif source.parent.name == "RESULTS":
                target = f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/RESULTS/{source.name}"
            elif source.parent.name == "TELEMETRY":
                target = f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/TELEMETRY/{source.name}"
            else:
                target = f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/{source.name}"
            add_file(zf, source, target, inventory)
        for source in inputs:
            add_file(zf, source, f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/INPUTS/{source.name}", inventory)
        for source in dependencies:
            add_file(zf, source, f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/DEPENDENCIES/INGENIERIA_02_RUNNERS/{source.name}", inventory)
        for source in kernel_files:
            add_file(zf, source, f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/DEPENDENCIES/DEE_CODEX_NATIVE_DISCOVERY_AND_CLOSURE_V1_WORK/ANALYSIS/binary_api/wheel_extracted/dee_universe_v27/{source.name}", inventory)
        add_file(zf, wheel, f"INGENIERIA_05/04_RAW_CAUSAL_MINIMUM/DEPENDENCIES/{wheel.name}", inventory)

        manifest = {
            "package": OUT.name,
            "engineering": "INGENIERIA_05_OPEN",
            "scientific_status": "DEE_NATIVE_SEQUENTIAL_REACHABILITY_CHANGE",
            "rw3": False,
            "l4": False,
            "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
            "parent_archives_preserved_byte_exact": {section: expected_parent_hashes[section] for section, _ in PARENTS},
            "members_excluding_indexes": inventory,
        }
        manifest_data = (json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
        manifest_path = "INGENIERIA_05/MANIFEST/MANIFEST.json"
        zf.writestr(manifest_path, manifest_data)
        hashes = "".join(f"{row['sha256']}  {row['path']}\n" for row in inventory)
        hashes += f"{sha_bytes(manifest_data)}  {manifest_path}\n"
        zf.writestr("INGENIERIA_05/HASHES/HASHES.sha256", hashes.encode("utf-8"))

    with zipfile.ZipFile(OUT, "r") as zf:
        if zf.testzip() is not None:
            raise RuntimeError("Outer CRC failure")
        names = set(zf.namelist())
        for section, path in PARENTS:
            member = f"INGENIERIA_05/{section}/{path.name}"
            data = zf.read(member)
            if sha_bytes(data) != expected_parent_hashes[section]:
                raise RuntimeError(f"Embedded parent changed: {section}")
            with zipfile.ZipFile(io.BytesIO(data), "r") as nested:
                if nested.testzip() is not None:
                    raise RuntimeError(f"Embedded ZIP CRC failure: {section}")
        manifest = json.loads(zf.read("INGENIERIA_05/MANIFEST/MANIFEST.json"))
        for row in manifest["members_excluding_indexes"]:
            if row["path"] not in names or sha_bytes(zf.read(row["path"])) != row["sha256"]:
                raise RuntimeError(f"Internal hash mismatch: {row['path']}")
        count = len(zf.infolist())
    print(json.dumps({"path": str(OUT), "sha256": sha_file(OUT), "size_bytes": OUT.stat().st_size, "members": count, "crc_ok": True, "internal_hashes_ok": True, "embedded_zips_ok": True}, indent=2))


if __name__ == "__main__":
    main()
