#!/usr/bin/env python3
"""NRD04 closed exhaustive subset enumeration for R1 (8) and R2 (7)."""
from __future__ import annotations

import argparse
import itertools
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ENGINEERING = ROOT.parent
BUNDLED = ROOT / "DEPENDENCIES"
ING02_RUNNERS = BUNDLED / "INGENIERIA_02_RUNNERS" if (BUNDLED / "INGENIERIA_02_RUNNERS").is_dir() else ENGINEERING / "INGENIERIA_02" / "RUNNERS"
if BUNDLED.is_dir():
    os.environ.setdefault("DEE_V27_TESTS_ROOT", str(BUNDLED))
NRD01 = ROOT / "INPUTS" / "NRD01_CHECKPOINTS.npz" if (ROOT / "INPUTS" / "NRD01_CHECKPOINTS.npz").is_file() else ENGINEERING / "NATIVE_REACHABILITY_DEE_V27" / "TELEMETRY" / "NRD01_CHECKPOINTS.npz"
STAGE_AB = ROOT / "TELEMETRY" / "NRD04_STAGE_AB_RESPONSES.npz"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ING02_RUNNERS))

import run_nrd04_stage_ab as core  # noqa: E402
from ing02_common import load_kernel, seal, write_json  # noqa: E402


def label(subset):
    return "_".join(map(str, subset)) if subset else "EMPTY"


def exact(left, right):
    return all(core.compare(left[h], right[h])["equal"] for h in core.HORIZONS)


def subset_rows(size):
    for count in range(size + 1):
        yield from itertools.combinations(range(size), count)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = load_kernel(args.threads)
    source = np.load(NRD01)
    cached = np.load(STAGE_AB)
    base = (source["H0_t4_raw_a"], source["H0_t4_clock_a"])
    telemetry, cases = {}, []

    for history in ("H1", "H2"):
        target_raw = source[f"{history}_t4_raw_a"]
        positions = [tuple(int(v) for v in q) for q in np.argwhere(target_raw != base[0])]
        size = len(positions)
        full = tuple(range(size))
        responses = {}
        executed, reused = 0, 0
        for subset in subset_rows(size):
            tag = label(subset)
            raw_key = f"{history}_S_{tag}_response_h32_raw_xor"
            if raw_key in cached:
                responses[subset] = {
                    h: (
                        cached[f"{history}_S_{tag}_response_h{h}_raw_xor"],
                        cached[f"{history}_S_{tag}_response_h{h}_clock_xor"],
                    )
                    for h in core.HORIZONS
                }
                reused += 1
            else:
                state = core.make_state(base, target_raw, positions, subset)
                c0 = core.run(kernel, state, False)
                c3 = core.run(kernel, state, True)
                responses[subset] = {h: core.response(c3[h], c0[h]) for h in core.HORIZONS}
                executed += 1
            for h in core.HORIZONS:
                telemetry[f"{history}_S_{tag}_response_h{h}_raw_xor"] = responses[subset][h][0]
                telemetry[f"{history}_S_{tag}_response_h{h}_clock_xor"] = responses[subset][h][1]

        base_response, full_response = responses[tuple()], responses[full]
        sufficient = [subset for subset in responses if exact(responses[subset], full_response)]
        minimum_size = min(len(subset) for subset in sufficient)
        minimal_sufficient = [subset for subset in sufficient if len(subset) == minimum_size]

        destructive = []
        for removed in subset_rows(size):
            remaining = tuple(i for i in range(size) if i not in removed)
            if exact(responses[remaining], base_response):
                destructive.append(removed)
        minimum_removed = min(len(subset) for subset in destructive)
        minimal_destructive = [subset for subset in destructive if len(subset) == minimum_removed]

        single = {(i,): responses[(i,)] for i in range(size)}
        synergy = []
        for subset in minimal_sufficient:
            superposed = {}
            for h in core.HORIZONS:
                raw = base_response[h][0].copy()
                clock = base_response[h][1].copy()
                for i in subset:
                    raw = np.bitwise_xor(raw, np.bitwise_xor(single[(i,)][h][0], base_response[h][0]))
                    clock = np.bitwise_xor(clock, np.bitwise_xor(single[(i,)][h][1], base_response[h][1]))
                superposed[h] = (raw, clock)
            synergy.append({
                "indices": list(subset),
                "xor_superposition_equals_full": exact(superposed, full_response),
                "distances": {str(h): core.compare(superposed[h], full_response[h]) for h in core.HORIZONS},
            })

        all_rows = []
        for subset in responses:
            all_rows.append({
                "indices": list(subset),
                "size": len(subset),
                "exact_full": exact(responses[subset], full_response),
                "exact_base": exact(responses[subset], base_response),
                "distance_to_full": {str(h): core.compare(responses[subset][h], full_response[h]) for h in core.HORIZONS},
                "distance_to_base": {str(h): core.compare(responses[subset][h], base_response[h]) for h in core.HORIZONS},
            })

        cases.append({
            "history": history,
            "R_size": size,
            "R_positions": [
                {"index": i, "position": list(q), "base_raw": int(base[0][q]), "history_raw": int(target_raw[q])}
                for i, q in enumerate(positions)
            ],
            "subsets_total": len(responses),
            "subsets_executed": executed,
            "subsets_reused": reused,
            "minimal_sufficient_size": minimum_size,
            "minimal_sufficient_sets": [list(s) for s in minimal_sufficient],
            "minimal_destructive_removal_size": minimum_removed,
            "minimal_destructive_removal_sets": [list(s) for s in minimal_destructive],
            "synergy": synergy,
            "all_subsets": all_rows,
            "adjudication": {
                "single_site": minimum_size == 1,
                "distributed_configuration": minimum_size > 1,
                "xor_nonadditive": any(not row["xor_superposition_equals_full"] for row in synergy),
            },
        })

    np.savez_compressed(ROOT / "TELEMETRY" / "NRD04_ALL_SUBSET_RESPONSES.npz", **telemetry)
    result = seal({
        "experiment_id": "NRD04_CLOSED_RAW_SUBSET_ENUMERATION",
        "status": "MINIMAL_RAW_SUPPORT_IDENTIFIED",
        "runtime": runtime,
        "checkpoint": 4,
        "challenges": ["C0_NONE", "C3_BLIND_PULSE"],
        "horizons": list(core.HORIZONS),
        "cases": cases,
        "next_gate": "Freeze value/position characterization of the identified minimal sets before fresh validation.",
        "telemetry": "TELEMETRY/NRD04_ALL_SUBSET_RESPONSES.npz"
    })
    out = ROOT / "RESULTS" / "NRD04_EXHAUSTIVE_SUBSETS.json"
    write_json(out, result)
    print(json.dumps({"result": str(out), "cases": [{"history": c["history"], "minimal_sufficient_size": c["minimal_sufficient_size"], "minimal_sufficient_sets": c["minimal_sufficient_sets"], "minimal_destructive_removal_size": c["minimal_destructive_removal_size"], "minimal_destructive_removal_sets": c["minimal_destructive_removal_sets"], **c["adjudication"]} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
