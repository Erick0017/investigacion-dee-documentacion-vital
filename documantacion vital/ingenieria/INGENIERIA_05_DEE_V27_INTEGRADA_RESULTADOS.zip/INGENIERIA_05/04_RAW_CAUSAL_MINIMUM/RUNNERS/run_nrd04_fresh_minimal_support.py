#!/usr/bin/env python3
"""Fresh necessity/sufficiency validation of frozen NRD04 RAW support rules."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ENGINEERING = ROOT.parent
BUNDLED = ROOT / "DEPENDENCIES"
ING02_RUNNERS = BUNDLED / "INGENIERIA_02_RUNNERS" if (BUNDLED / "INGENIERIA_02_RUNNERS").is_dir() else ENGINEERING / "INGENIERIA_02" / "RUNNERS"
if BUNDLED.is_dir():
    os.environ.setdefault("DEE_V27_TESTS_ROOT", str(BUNDLED))
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ING02_RUNNERS))

import run_nrd04_stage_ab as core  # noqa: E402
from ing02_common import load_kernel, pack, seal, transform, write_json  # noqa: E402
from temporal_order_apparatus_v1 import construct  # noqa: E402

CONFIGS = (
    {"id": "V1", "n": 19, "origin": (9, 9, 9), "permutation": (1, 0, 2), "signs": (1, -1, 1)},
    {"id": "V2", "n": 25, "origin": (12, 12, 12), "permutation": (2, 1, 0), "signs": (-1, 1, 1)},
    {"id": "V3", "n": 29, "origin": (14, 14, 14), "permutation": (0, 2, 1), "signs": (1, 1, -1)},
)
H2_OFFSETS = ((-1, -1, -3), (0, -1, 0), (0, 1, 0), (1, 0, 0), (1, 1, 4))
HISTORIES = {"H0": "no_events", "H1": "AB", "H2": "BA"}


def apparatus(base, mode):
    return {**base, "mode": mode, "event_sreg": 0}


def checkpoints(kernel, base):
    worlds = {h: construct(kernel, apparatus(base, mode))[0] for h, mode in HISTORIES.items()}
    for _ in range(4):
        for world in worlds.values():
            world.tick()
    return {h: (w.raw_a.copy(), w.clock_a.copy()) for h, w in worlds.items()}


def configure_pulse(base):
    offset = transform((0, 0, -3), base["permutation"], base["signs"])
    direction = tuple(-int(np.sign(v)) for v in offset)
    core.PULSE_Q = tuple((base["origin"][i] + offset[i]) % base["n"] for i in range(3))
    core.PULSE_RAW = pack(8000, 0, direction, 1)


def response_for(kernel, state):
    c0, c3 = core.run(kernel, state, False), core.run(kernel, state, True)
    return {h: core.response(c3[h], c0[h]) for h in core.HORIZONS}


def exact(left, right):
    return all(core.compare(left[h], right[h])["equal"] for h in core.HORIZONS)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = load_kernel(args.threads)
    telemetry, cases = {}, []

    for cfg in CONFIGS:
        configure_pulse(cfg)
        states = checkpoints(kernel, cfg)
        base = states["H0"]
        for history in ("H1", "H2"):
            target_raw = states[history][0]
            positions = [tuple(int(v) for v in q) for q in np.argwhere(target_raw != base[0])]
            if history == "H1":
                candidate_positions = positions
            else:
                candidate_positions = []
                for canonical in H2_OFFSETS:
                    offset = transform(canonical, cfg["permutation"], cfg["signs"])
                    q = tuple((cfg["origin"][i] + offset[i]) % cfg["n"] for i in range(3))
                    candidate_positions.append(q)
            if len(set(candidate_positions)) != len(candidate_positions) or any(q not in positions for q in candidate_positions):
                raise RuntimeError(f"Frozen candidate mapping failed for {cfg['id']} {history}: {candidate_positions} vs R={positions}")
            candidate_indices = tuple(positions.index(q) for q in candidate_positions)
            all_indices = tuple(range(len(positions)))
            remaining_indices = tuple(i for i in all_indices if i not in candidate_indices)
            full_state = core.make_state(base, target_raw, positions, all_indices)
            candidate_state = core.make_state(base, target_raw, positions, candidate_indices)
            removed_state = core.make_state(base, target_raw, positions, remaining_indices)
            base_response = response_for(kernel, base)
            full_response = response_for(kernel, full_state)
            candidate_response = response_for(kernel, candidate_state)
            removed_response = response_for(kernel, removed_state)
            sufficient = exact(candidate_response, full_response)
            removal_changes = not exact(removed_response, full_response)
            removal_to_base = exact(removed_response, base_response)
            for name, response in (("BASE", base_response), ("FULL", full_response), ("CANDIDATE", candidate_response), ("REMOVED", removed_response)):
                for h in core.HORIZONS:
                    telemetry[f"{cfg['id']}_{history}_{name}_h{h}_raw_xor"] = response[h][0]
                    telemetry[f"{cfg['id']}_{history}_{name}_h{h}_clock_xor"] = response[h][1]
            cases.append({
                "configuration": cfg["id"],
                "history": history,
                "R_size": len(positions),
                "candidate_size": len(candidate_indices),
                "candidate_indices": list(candidate_indices),
                "candidate_positions": [list(q) for q in candidate_positions],
                "candidate_within_R_prechallenge": True,
                "sufficiency_exact": sufficient,
                "necessity_removal_changes_full": removal_changes,
                "removal_reverts_exact_base": removal_to_base,
                "candidate_distance_to_full": {str(h): core.compare(candidate_response[h], full_response[h]) for h in core.HORIZONS},
                "removed_distance_to_full": {str(h): core.compare(removed_response[h], full_response[h]) for h in core.HORIZONS},
            })

    np.savez_compressed(ROOT / "TELEMETRY" / "NRD04_FRESH_SUPPORT_RESPONSES.npz", **telemetry)
    passed = all(row["sufficiency_exact"] and row["necessity_removal_changes_full"] for row in cases)
    result = seal({
        "experiment_id": "NRD04_FRESH_MINIMAL_RAW_SUPPORT",
        "status": "FRESH_CONFIRMED_MINIMAL_RAW_SUPPORT" if passed else "FRESH_RULE_NOT_CONFIRMED",
        "runtime": runtime,
        "cases": cases,
        "sequential_rewrite_authorized": passed,
        "interpretation_guard": "A fresh causal support rule does not itself demonstrate native sequential rewriting."
    })
    out = ROOT / "RESULTS" / "NRD04_FRESH_MINIMAL_SUPPORT.json"
    write_json(out, result)
    print(json.dumps({"result": str(out), "status": result["status"], "cases": [{k: row[k] for k in ("configuration", "history", "R_size", "candidate_size", "sufficiency_exact", "necessity_removal_changes_full", "removal_reverts_exact_base")} for row in cases]}, indent=2))


if __name__ == "__main__":
    main()
