#!/usr/bin/env python3
"""Conditional two-experience reachability test in one uninterrupted DEE world."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ENGINEERING = ROOT.parent
BUNDLED = ROOT / "DEPENDENCIES"
ING02_RUNNERS = BUNDLED / "INGENIERIA_02_RUNNERS" if (BUNDLED / "INGENIERIA_02_RUNNERS").is_dir() else ENGINEERING / "INGENIERIA_02" / "RUNNERS"
if BUNDLED.is_dir():
    os.environ.setdefault("DEE_V27_TESTS_ROOT", str(BUNDLED))
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ING02_RUNNERS))

import run_nrd04_stage_ab as core  # noqa: E402
from ing02_common import NativeWorld, add, load_kernel, pack, seal, transform, write_json  # noqa: E402
from temporal_order_apparatus_v1 import construct  # noqa: E402

CONFIGS = (
    {"id": "S0", "n": 23, "origin": (11, 11, 11), "permutation": (0, 1, 2), "signs": (1, 1, 1)},
    {"id": "S1", "n": 25, "origin": (12, 12, 12), "permutation": (2, 1, 0), "signs": (-1, 1, 1)},
)
WORLDS = ("CONTROL", "AB_ONLY", "AB_THEN_BA")


def apparatus(cfg, mode):
    return {**cfg, "mode": mode, "event_sreg": 0}


def configure_pulse(cfg):
    offset = transform((0, 0, -3), cfg["permutation"], cfg["signs"])
    direction = tuple(-int(np.sign(v)) for v in offset)
    core.PULSE_Q = tuple((cfg["origin"][i] + offset[i]) % cfg["n"] for i in range(3))
    core.PULSE_RAW = pack(8000, 0, direction, 1)


def event_geometry(ports, cfg):
    tf = lambda v: transform(v, cfg["permutation"], cfg["signs"])
    dir_a, dir_b = tf((0, 0, -1)), tf((0, 0, 1))
    target_a = add(tuple(ports["a"]), tf((0, -1, 0)), 1, cfg["n"])
    target_b = add(tuple(ports["b"]), tf((0, 1, 0)), 1, cfg["n"])
    return target_a, target_b, dir_a, dir_b


def initiate_ab(world, ports, cfg):
    target_a, target_b, dir_a, dir_b = event_geometry(ports, cfg)
    source_b = add(target_b, dir_b, -1, cfg["n"])
    if int(world.raw_a[target_a]) or int(world.raw_a[source_b]):
        raise RuntimeError(f"AB initiation collision: {target_a}, {source_b}")
    world.inject(target_a, pack(5000, 0, dir_a, 1), 17)
    world.inject(source_b, pack(0, 0, dir_b, 1), 19)
    return [list(target_a), list(source_b)]


def initiate_ba_late(world, ports, cfg):
    target_a, target_b, dir_a, dir_b = event_geometry(ports, cfg)
    source_b = add(target_b, dir_b, -1, cfg["n"])
    source_a = add(target_a, dir_a, -2, cfg["n"])
    if int(world.raw_a[source_b]) or int(world.raw_a[source_a]):
        raise RuntimeError(f"BA initiation requires empty sources: {source_b}={int(world.raw_a[source_b])}, {source_a}={int(world.raw_a[source_a])}")
    world.inject(source_b, pack(0, 0, dir_b, 1), 19)
    world.inject(source_a, pack(0, 0, dir_a, 1), 17)
    return [list(source_b), list(source_a)]


def checkpoint(world):
    return world.raw_a.copy(), world.clock_a.copy()


def fingerprint(kernel, state):
    c0, c3 = core.run(kernel, state, False), core.run(kernel, state, True)
    return {h: core.response(c3[h], c0[h]) for h in core.HORIZONS}


def differs_all(left, right):
    return all(not core.compare(left[h], right[h])["equal"] for h in core.HORIZONS)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = load_kernel(args.threads)
    telemetry, cases = {}, []

    for cfg in CONFIGS:
        configure_pulse(cfg)
        template, ports = construct(kernel, apparatus(cfg, "no_events"))
        worlds = {name: NativeWorld(kernel, template.raw_a, template.clock_a) for name in WORLDS}
        checkpoints = {"F0": {name: checkpoint(world) for name, world in worlds.items()}}

        touched_ab = {}
        for name in ("AB_ONLY", "AB_THEN_BA"):
            touched_ab[name] = initiate_ab(worlds[name], ports, cfg)
        expected_ab, _ = construct(kernel, apparatus(cfg, "AB"))
        for name in ("AB_ONLY", "AB_THEN_BA"):
            if not (np.array_equal(worlds[name].raw_a, expected_ab.raw_a) and np.array_equal(worlds[name].clock_a, expected_ab.clock_a)):
                raise RuntimeError(f"{cfg['id']} {name} experience-1 state does not match exact AB apparatus")
        for _ in range(4):
            for world in worlds.values():
                world.tick()
        checkpoints["F1"] = {name: checkpoint(world) for name, world in worlds.items()}

        touched_ba = initiate_ba_late(worlds["AB_THEN_BA"], ports, cfg)
        for _ in range(4):
            for world in worlds.values():
                world.tick()
        checkpoints["F2"] = {name: checkpoint(world) for name, world in worlds.items()}

        fingerprints = {}
        for stage, stage_worlds in checkpoints.items():
            for name, state in stage_worlds.items():
                fingerprints[(stage, name)] = fingerprint(kernel, state)
                telemetry[f"{cfg['id']}_{stage}_{name}_raw_a"] = state[0]
                telemetry[f"{cfg['id']}_{stage}_{name}_clock_a"] = state[1]
                for h in core.HORIZONS:
                    telemetry[f"{cfg['id']}_{stage}_{name}_response_h{h}_raw_xor"] = fingerprints[(stage, name)][h][0]
                    telemetry[f"{cfg['id']}_{stage}_{name}_response_h{h}_clock_xor"] = fingerprints[(stage, name)][h][1]

        f0_equal = all(
            all(core.compare(fingerprints[("F0", "CONTROL")][h], fingerprints[("F0", name)][h])["equal"] for h in core.HORIZONS)
            for name in ("AB_ONLY", "AB_THEN_BA")
        )
        first_change = differs_all(fingerprints[("F1", "AB_ONLY")], fingerprints[("F1", "CONTROL")])
        seq_matches_ab_f1 = all(core.compare(fingerprints[("F1", "AB_ONLY")][h], fingerprints[("F1", "AB_THEN_BA")][h])["equal"] for h in core.HORIZONS)
        second_change = differs_all(fingerprints[("F2", "AB_THEN_BA")], fingerprints[("F2", "AB_ONLY")])
        first_retained = differs_all(fingerprints[("F2", "AB_ONLY")], fingerprints[("F2", "CONTROL")])
        cases.append({
            "configuration": cfg["id"],
            "experience_1_touched_coordinates": touched_ab,
            "experience_2_touched_coordinates": touched_ba,
            "checks": {
                "F0_worlds_equal": f0_equal,
                "experience_1_exact_AB_apparatus": True,
                "F1_AB_changes_response_vs_control": first_change,
                "F1_sequence_matches_AB_only_before_second_experience": seq_matches_ab_f1,
                "F2_second_experience_changes_response_vs_AB_only": second_change,
                "F2_AB_only_remains_distinct_from_control": first_retained,
            },
            "comparisons": {
                "F1_AB_ONLY_vs_CONTROL": {str(h): core.compare(fingerprints[("F1", "AB_ONLY")][h], fingerprints[("F1", "CONTROL")][h]) for h in core.HORIZONS},
                "F2_SEQUENCE_vs_AB_ONLY": {str(h): core.compare(fingerprints[("F2", "AB_THEN_BA")][h], fingerprints[("F2", "AB_ONLY")][h]) for h in core.HORIZONS},
                "F2_AB_ONLY_vs_CONTROL": {str(h): core.compare(fingerprints[("F2", "AB_ONLY")][h], fingerprints[("F2", "CONTROL")][h]) for h in core.HORIZONS},
            },
        })

    np.savez_compressed(ROOT / "TELEMETRY" / "NRD04_SEQUENTIAL_CHECKPOINTS_AND_RESPONSES.npz", **telemetry)
    passed = all(
        c["checks"]["F0_worlds_equal"]
        and c["checks"]["F1_AB_changes_response_vs_control"]
        and c["checks"]["F1_sequence_matches_AB_only_before_second_experience"]
        and c["checks"]["F2_second_experience_changes_response_vs_AB_only"]
        for c in cases
    )
    result = seal({
        "experiment_id": "NRD04_CONDITIONAL_NATIVE_SEQUENTIAL_REACHABILITY",
        "status": "DEE_NATIVE_SEQUENTIAL_REACHABILITY_CHANGE" if passed else "SEQUENTIAL_REACHABILITY_NOT_DEMONSTRATED",
        "runtime": runtime,
        "cases": cases,
        "host_intervention_statement": "Host only initiated physical experience carriers at the two frozen boundaries; it never copied or edited the R8 causal support. After each initiation it only ticked/checkpointed/observed. Diagnostic clones received the frozen C0/C3 panel.",
        "claim_guard": "A positive two-transition result is provisional sequential reachability change, not RW3 or L4.",
        "stop_after_this_test": True
    })
    out = ROOT / "RESULTS" / "NRD04_SEQUENTIAL_REACHABILITY.json"
    write_json(out, result)
    print(json.dumps({"result": str(out), "status": result["status"], "cases": [{"configuration": c["configuration"], **c["checks"]} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
