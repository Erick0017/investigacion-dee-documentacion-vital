#!/usr/bin/env python3
"""Minimal value/position characterization of frozen NRD04 supports."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
ENGINEERING = ROOT.parent
BUNDLED = ROOT / "DEPENDENCIES"
ING02_RUNNERS = BUNDLED / "INGENIERIA_02_RUNNERS" if (BUNDLED / "INGENIERIA_02_RUNNERS").is_dir() else ENGINEERING / "INGENIERIA_02" / "RUNNERS"
if BUNDLED.is_dir():
    os.environ.setdefault("DEE_V27_TESTS_ROOT", str(BUNDLED))
NRD01 = ROOT / "INPUTS" / "NRD01_CHECKPOINTS.npz" if (ROOT / "INPUTS" / "NRD01_CHECKPOINTS.npz").is_file() else ENGINEERING / "NATIVE_REACHABILITY_DEE_V27" / "TELEMETRY" / "NRD01_CHECKPOINTS.npz"
EXHAUSTIVE = ROOT / "RESULTS" / "NRD04_EXHAUSTIVE_SUBSETS.json"
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(ING02_RUNNERS))

import run_nrd04_stage_ab as core  # noqa: E402
from ing02_common import load_kernel, seal, write_json  # noqa: E402


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = load_kernel(args.threads)
    source = np.load(NRD01)
    exhaustive = json.loads(EXHAUSTIVE.read_text(encoding="utf-8"))
    base = (source["H0_t4_raw_a"], source["H0_t4_clock_a"])
    telemetry, cases = {}, []

    for case in exhaustive["cases"]:
        history = case["history"]
        candidate = tuple(case["minimal_sufficient_sets"][0])
        target_raw = source[f"{history}_t4_raw_a"]
        positions = [tuple(row["position"]) for row in case["R_positions"]]
        exact = core.make_state(base, target_raw, positions, candidate)
        permuted_raw = base[0].copy()
        candidate_positions = [positions[i] for i in candidate]
        values = [target_raw[q] for q in candidate_positions]
        shifted = values[-1:] + values[:-1]
        for q, value in zip(candidate_positions, shifted):
            permuted_raw[q] = value
        permuted = (permuted_raw, base[1].copy())
        states = {"BASE": base, "EXACT_TRANSPLANT": exact, "VALUE_PERMUTATION": permuted}
        responses = {}
        for name, state in states.items():
            c0, c3 = core.run(kernel, state, False), core.run(kernel, state, True)
            responses[name] = {h: core.response(c3[h], c0[h]) for h in core.HORIZONS}
            for h in core.HORIZONS:
                telemetry[f"{history}_{name}_response_h{h}_raw_xor"] = responses[name][h][0]
                telemetry[f"{history}_{name}_response_h{h}_clock_xor"] = responses[name][h][1]

        exact_vs_permuted = {str(h): core.compare(responses["EXACT_TRANSPLANT"][h], responses["VALUE_PERMUTATION"][h]) for h in core.HORIZONS}
        base_vs_permuted = {str(h): core.compare(responses["BASE"][h], responses["VALUE_PERMUTATION"][h]) for h in core.HORIZONS}
        permutation_equal_exact = all(row["equal"] for row in exact_vs_permuted.values())
        cases.append({
            "history": history,
            "candidate_indices": list(candidate),
            "candidate_positions": [list(q) for q in candidate_positions],
            "original_values": [int(v) for v in values],
            "permuted_values": [int(v) for v in shifted],
            "exact_vs_permuted": exact_vs_permuted,
            "base_vs_permuted": base_vs_permuted,
            "adjudication": {
                "permutation_equal_exact": permutation_equal_exact,
                "multiset_alone_sufficient": permutation_equal_exact,
                "value_position_assignment_matters": not permutation_equal_exact,
            },
        })

    np.savez_compressed(ROOT / "TELEMETRY" / "NRD04_VALUE_POSITION_RESPONSES.npz", **telemetry)
    result = seal({
        "experiment_id": "NRD04_VALUE_POSITION_CHARACTERIZATION",
        "status": "VALUE_POSITION_ASSIGNMENT_CAUSAL" if all(c["adjudication"]["value_position_assignment_matters"] for c in cases) else "MIXED_VALUE_POSITION_RESULT",
        "runtime": runtime,
        "cases": cases,
        "fresh_candidate_rule": {
            "H1": "All transformed t=4 RAW difference positions R.",
            "H2": "Transformed canonical relative offsets (-1,-1,-3),(0,-1,0),(0,1,0),(1,0,0),(1,1,4) from apparatus origin."
        },
        "next_gate": "Run necessity and sufficiency only for the frozen equivalent candidate in V1/V2/V3."
    })
    out = ROOT / "RESULTS" / "NRD04_VALUE_POSITION.json"
    write_json(out, result)
    print(json.dumps({"result": str(out), "status": result["status"], "cases": [{"history": c["history"], **c["adjudication"]} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
