# Reproducción de NRD05

Requisitos: Windows x64, CPython 3.13 y NumPy.

Extraer el ZIP integrado y ejecutar desde `INGENIERIA_05/05_HISTORY_CONDITIONED_TRANSFORMATION`:

```powershell
& 'RUTA_PYTHON_3_13\python.exe' -I -B '.\RUNNERS\run_nrd05_history_conditioned_transformation.py' --threads 1
```

El runner reutiliza las dependencias autocontenidas de `../04_RAW_CAUSAL_MINIMUM/DEPENDENCIES` y el helper causal exacto de `../04_RAW_CAUSAL_MINIMUM/RUNNERS`.

Kernel canónico SHA-256:

`0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`

No se requiere acceso a los ZIP históricos embebidos para ejecutar NRD05.

