#!/usr/bin/env python3
"""Append NRD05 to the sole Ingeniería 05 integrated ZIP, preserving prior members."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
TESTS = ROOT.parents[2]
OUT = TESTS / "documantacion vital" / "ingenieria" / "INGENIERIA_05_DEE_V27_INTEGRADA_RESULTADOS.zip"
TMP = OUT.with_suffix(".updating.tmp")
INDEX_PATH = "INGENIERIA_05/MASTER_INDEX/MASTER_INDEX.md"
MANIFEST_PATH = "INGENIERIA_05/MANIFEST/MANIFEST.json"
HASHES_PATH = "INGENIERIA_05/HASHES/HASHES.sha256"


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main():
    if not OUT.is_file():
        raise FileNotFoundError(OUT)
    with zipfile.ZipFile(OUT, "r") as old:
        if old.testzip() is not None:
            raise RuntimeError("Existing integrated ZIP CRC failure")
        preserved = {
            info.filename: old.read(info.filename)
            for info in old.infolist()
            if info.filename not in {INDEX_PATH, MANIFEST_PATH, HASHES_PATH}
            and not info.filename.startswith("INGENIERIA_05/05_HISTORY_CONDITIONED_TRANSFORMATION/")
        }
    preserved_hashes = {name: sha_bytes(data) for name, data in preserved.items()}

    new_files = [
        ROOT / "SCIENTIFIC_REPORT.md",
        ROOT / "REPRODUCTION.md",
        ROOT / "FREEZE" / "NRD05_LOCK.json",
        ROOT / "RUNNERS" / "run_nrd05_history_conditioned_transformation.py",
        ROOT / "RUNNERS" / "update_integrated_ing05.py",
        ROOT / "RESULTS" / "NRD05_HISTORY_CONDITIONED_TRANSFORMATION.json",
        ROOT / "TELEMETRY" / "NRD05_FACTORIAL_STATES_AND_FUTURES.npz",
    ]
    missing = [str(path) for path in new_files + [ROOT / "MASTER_INDEX.md"] if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)

    additions = {}
    base = "INGENIERIA_05/05_HISTORY_CONDITIONED_TRANSFORMATION"
    for source in new_files:
        if source.parent.name in {"FREEZE", "RUNNERS", "RESULTS", "TELEMETRY"}:
            target = f"{base}/{source.parent.name}/{source.name}"
        else:
            target = f"{base}/{source.name}"
        additions[target] = source.read_bytes()
    additions[INDEX_PATH] = (ROOT / "MASTER_INDEX.md").read_bytes()

    all_content = {**preserved, **additions}
    inventory = [
        {"path": name, "sha256": sha_bytes(data), "size": len(data)}
        for name, data in sorted(all_content.items())
        if name != INDEX_PATH
    ]
    manifest = {
        "package": OUT.name,
        "engineering": "INGENIERIA_05_OPEN",
        "scientific_status": "DEE_NATIVE_HISTORY_CONDITIONED_TRANSFORMATION",
        "rw3": False,
        "l4": False,
        "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        "prior_member_count_preserved_excluding_updated_indexes": len(preserved),
        "members_excluding_generated_indexes": inventory,
        "master_index_sha256": sha_bytes(additions[INDEX_PATH]),
    }
    manifest_data = (json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    hashes = "".join(f"{row['sha256']}  {row['path']}\n" for row in inventory)
    hashes += f"{sha_bytes(additions[INDEX_PATH])}  {INDEX_PATH}\n"
    hashes += f"{sha_bytes(manifest_data)}  {MANIFEST_PATH}\n"

    if TMP.exists():
        TMP.unlink()
    with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name, data in sorted(all_content.items()):
            zf.writestr(name, data)
        zf.writestr(MANIFEST_PATH, manifest_data)
        zf.writestr(HASHES_PATH, hashes.encode("utf-8"))

    with zipfile.ZipFile(TMP, "r") as zf:
        if zf.testzip() is not None:
            raise RuntimeError("Updated ZIP CRC failure")
        names = set(zf.namelist())
        for name, expected in preserved_hashes.items():
            if name not in names or sha_bytes(zf.read(name)) != expected:
                raise RuntimeError(f"Prior member changed: {name}")
        loaded = json.loads(zf.read(MANIFEST_PATH))
        for row in loaded["members_excluding_generated_indexes"]:
            if row["path"] not in names or sha_bytes(zf.read(row["path"])) != row["sha256"]:
                raise RuntimeError(f"Internal hash mismatch: {row['path']}")
        if sha_bytes(zf.read(INDEX_PATH)) != loaded["master_index_sha256"]:
            raise RuntimeError("Master index hash mismatch")
        count = len(zf.infolist())
    TMP.replace(OUT)
    print(json.dumps({
        "path": str(OUT),
        "sha256": sha_file(OUT),
        "size_bytes": OUT.stat().st_size,
        "members": count,
        "crc_ok": True,
        "prior_members_preserved": True,
        "internal_hashes_ok": True,
    }, indent=2))


if __name__ == "__main__":
    main()
