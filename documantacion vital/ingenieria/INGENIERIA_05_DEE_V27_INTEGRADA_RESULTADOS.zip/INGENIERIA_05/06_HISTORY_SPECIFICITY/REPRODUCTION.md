# Reproducción NRD06

## Requisitos

- DEE Universe v27 congelado.
- Sección hermana `05_HISTORY_CONDITIONED_TRANSFORMATION` o workspace `INGENIERIA_05_HISTORY_CONDITIONED_TRANSFORMATION` intacto.
- Python con NumPy y la extensión binaria DEE usada por Ingeniería 05.

## Ejecución canónica

Desde `06_HISTORY_SPECIFICITY`:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\RUNNERS\run_nrd06_history_specificity.py' --threads 1
```

El runner ejecuta MAIN_S0 y sólo cruza los gates posteriores si la evidencia los autoriza. `--resume-after-main` existe exclusivamente para reanudar tras un MAIN_S0 completo sin repetirlo.

## Salidas

- `RESULTS/NRD06_HISTORY_SPECIFICITY.json`
- `RESULTS/NRD06_RECURRENT_PILOT.json` si se cruza el gate condicional
- `TELEMETRY/NRD06_SPECIFICITY_STATES_AND_FUTURES.npz`

La telemetría contiene estados públicos exactos y futuros C0/C3/RESPONSE. Python inicia experiencias físicas congeladas, crea clones diagnósticos, ejecuta, observa y registra; no copia soporte causal descubierto ni construye manualmente F1/F2/F3.

