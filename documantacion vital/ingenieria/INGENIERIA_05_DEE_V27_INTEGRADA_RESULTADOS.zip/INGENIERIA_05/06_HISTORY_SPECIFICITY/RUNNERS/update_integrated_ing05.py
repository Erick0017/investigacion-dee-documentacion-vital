#!/usr/bin/env python3
"""Add NRD06/07 to the sole Ingeniería 05 integrated ZIP."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
TESTS = ROOT.parents[2]
OUT = TESTS / "documantacion vital" / "ingenieria" / "INGENIERIA_05_DEE_V27_INTEGRADA_RESULTADOS.zip"
TMP = OUT.with_suffix(".updating.tmp")
INDEX_PATH = "INGENIERIA_05/MASTER_INDEX/MASTER_INDEX.md"
MANIFEST_PATH = "INGENIERIA_05/MANIFEST/MANIFEST.json"
HASHES_PATH = "INGENIERIA_05/HASHES/HASHES.sha256"


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    if not OUT.is_file():
        raise FileNotFoundError(OUT)
    with zipfile.ZipFile(OUT, "r") as old:
        if old.testzip() is not None:
            raise RuntimeError("Existing integrated ZIP CRC failure")
        preserved = {
            info.filename: old.read(info.filename)
            for info in old.infolist()
            if info.filename not in {INDEX_PATH, MANIFEST_PATH, HASHES_PATH}
            and not info.filename.startswith("INGENIERIA_05/06_HISTORY_SPECIFICITY/")
            and not info.filename.startswith("INGENIERIA_05/07_RECURRENT_HISTORY_CHANGE/")
        }
    preserved_hashes = {name: sha_bytes(data) for name, data in preserved.items()}

    section06 = {
        "SCIENTIFIC_REPORT.md": ROOT / "SCIENTIFIC_REPORT.md",
        "REPRODUCTION.md": ROOT / "REPRODUCTION.md",
        "FREEZE/NRD06_LOCK.json": ROOT / "FREEZE" / "NRD06_LOCK.json",
        "RUNNERS/run_nrd06_history_specificity.py": ROOT / "RUNNERS" / "run_nrd06_history_specificity.py",
        "RUNNERS/update_integrated_ing05.py": ROOT / "RUNNERS" / "update_integrated_ing05.py",
        "RESULTS/NRD06_HISTORY_SPECIFICITY.json": ROOT / "RESULTS" / "NRD06_HISTORY_SPECIFICITY.json",
        "TELEMETRY/NRD06_SPECIFICITY_STATES_AND_FUTURES.npz": ROOT / "TELEMETRY" / "NRD06_SPECIFICITY_STATES_AND_FUTURES.npz",
    }
    section07 = {
        "SCIENTIFIC_REPORT.md": ROOT / "RECURRENT" / "SCIENTIFIC_REPORT.md",
        "REPRODUCTION.md": ROOT / "RECURRENT" / "REPRODUCTION.md",
        "RESULTS/NRD06_RECURRENT_PILOT.json": ROOT / "RESULTS" / "NRD06_RECURRENT_PILOT.json",
    }
    required = list(section06.values()) + list(section07.values()) + [ROOT / "MASTER_INDEX.md"]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)

    additions = {}
    for relative, source in section06.items():
        additions[f"INGENIERIA_05/06_HISTORY_SPECIFICITY/{relative}"] = source.read_bytes()
    for relative, source in section07.items():
        additions[f"INGENIERIA_05/07_RECURRENT_HISTORY_CHANGE/{relative}"] = source.read_bytes()
    additions[INDEX_PATH] = (ROOT / "MASTER_INDEX.md").read_bytes()

    all_content = {**preserved, **additions}
    inventory = [
        {"path": name, "sha256": sha_bytes(data), "size": len(data)}
        for name, data in sorted(all_content.items())
        if name != INDEX_PATH
    ]
    result = json.loads(section06["RESULTS/NRD06_HISTORY_SPECIFICITY.json"].read_text(encoding="utf-8"))
    manifest = {
        "package": OUT.name,
        "engineering": "INGENIERIA_05_OPEN",
        "scientific_status": result["status"],
        "specificity_status": result["specificity_status"],
        "formal_RW3": False,
        "L4": False,
        "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        "prior_member_count_preserved_excluding_updated_indexes": len(preserved),
        "members_excluding_generated_indexes": inventory,
        "master_index_sha256": sha_bytes(additions[INDEX_PATH]),
    }
    manifest_data = (json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    hashes = "".join(f"{row['sha256']}  {row['path']}\n" for row in inventory)
    hashes += f"{sha_bytes(additions[INDEX_PATH])}  {INDEX_PATH}\n"
    hashes += f"{sha_bytes(manifest_data)}  {MANIFEST_PATH}\n"

    if TMP.exists():
        TMP.unlink()
    with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(all_content.items()):
            archive.writestr(name, data)
        archive.writestr(MANIFEST_PATH, manifest_data)
        archive.writestr(HASHES_PATH, hashes.encode("utf-8"))

    with zipfile.ZipFile(TMP, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"Updated ZIP CRC failure: {bad}")
        names = set(archive.namelist())
        for name, expected in preserved_hashes.items():
            if name not in names or sha_bytes(archive.read(name)) != expected:
                raise RuntimeError(f"Prior member changed: {name}")
        loaded = json.loads(archive.read(MANIFEST_PATH))
        for row in loaded["members_excluding_generated_indexes"]:
            if row["path"] not in names or sha_bytes(archive.read(row["path"])) != row["sha256"]:
                raise RuntimeError(f"Internal hash mismatch: {row['path']}")
        if sha_bytes(archive.read(INDEX_PATH)) != loaded["master_index_sha256"]:
            raise RuntimeError("Master index hash mismatch")
        count = len(archive.infolist())
    TMP.replace(OUT)
    print(json.dumps({
        "path": str(OUT),
        "sha256": sha_file(OUT),
        "size_bytes": OUT.stat().st_size,
        "members": count,
        "crc_ok": True,
        "prior_members_preserved": True,
        "internal_hashes_ok": True,
        "engineering_open": True,
        "formal_RW3": False,
        "L4": False,
    }, indent=2))


if __name__ == "__main__":
    main()
