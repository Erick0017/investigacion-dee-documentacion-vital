# Reproducción del piloto recurrente

El piloto 07 es una etapa condicional del runner NRD06 y no tiene parámetros independientes.

Ejecute `RUNNERS/run_nrd06_history_specificity.py --threads 1` desde la sección 06. Sólo se ejecuta si MAIN_S0, FRESH_V1 y FRESH_V2 conservan especificidad de historia hasta D64. La definición completa de F3 y C4 está congelada en `FREEZE/NRD06_LOCK.json`.

