#!/usr/bin/env python3
"""Ingeniería 06 phase 6A: fresh F3 and orthogonal C4 history specificity."""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BLOCK = HERE.parent
ROOT = BLOCK.parent
ENGINEERING = ROOT.parent
BUNDLED_ENGINEERING = ROOT / "DEPENDENCIES"
NRD06_RUNNERS = (
    BUNDLED_ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
    if (BUNDLED_ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS").is_dir()
    else ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
)
sys.path.insert(0, str(NRD06_RUNNERS))

import run_nrd06_history_specificity as nrd06  # noqa: E402

nrd05 = nrd06.nrd05
HISTORIES = nrd06.HISTORIES
HORIZONS = nrd06.HORIZONS


def c4_sites(cfg):
    offsets = ((3, 0, 0), (-3, 0, 0), (0, 3, 0), (0, -3, 0), (0, 0, 3), (0, 0, -3))
    result = []
    for offset in offsets:
        transformed = nrd05.transform(offset, cfg["permutation"], cfg["signs"])
        q = tuple((cfg["origin"][i] + transformed[i]) % cfg["n"] for i in range(3))
        direction = tuple(-int(np.sign(v)) for v in transformed)
        result.append((q, direction))
    return result


def initiate_c4(world, cfg):
    sites = c4_sites(cfg)
    occupied = [(q, int(world.raw_a[q])) for q, _ in sites if int(world.raw_a[q]) != 0]
    if occupied:
        raise nrd05.GeometryNotClean(f"P_NEW C4 sources not empty: {occupied}")
    for q, direction in sites:
        world.inject(q, nrd05.pack(8000, 0, direction, 1), 0)
    return [list(q) for q, _ in sites]


def save_telemetry(prefix, stage, branches, diagnostics, telemetry):
    for history in HISTORIES:
        for branch in ("CONTROL", "PROBE"):
            state = branches[history][branch]
            base = f"{prefix}_{stage}_{history}_{branch}"
            telemetry[f"{base}_raw_a"] = state[0]
            telemetry[f"{base}_clock_a"] = state[1]
            for category in ("C0", "C3", "RESPONSE"):
                for horizon in HORIZONS:
                    future = diagnostics[history][branch][category][horizon]
                    telemetry[f"{base}_{category}_h{horizon}_raw"] = future[0]
                    telemetry[f"{base}_{category}_h{horizon}_clock"] = future[1]


def run_new_probe_case(kernel, cfg, telemetry):
    nrd05.configure_pulse(cfg)
    constructed = {
        history: nrd05.construct(kernel, nrd05.apparatus(cfg, mode))
        for history, mode in HISTORIES.items()
    }
    worlds = {history: value[0] for history, value in constructed.items()}
    nrd06.tick_all(worlds, 4)
    checkpoints = {history: nrd05.checkpoint(world) for history, world in worlds.items()}
    branches = {
        history: {
            "CONTROL": nrd05.NativeWorld(kernel, state[0], state[1]),
            "PROBE": nrd05.NativeWorld(kernel, state[0], state[1]),
        }
        for history, state in checkpoints.items()
    }
    touched = {history: initiate_c4(pair["PROBE"], cfg) for history, pair in branches.items()}
    if not (touched["H0"] == touched["HA"] == touched["HB"]):
        raise RuntimeError("P_NEW did not use identical coordinates across histories")
    flat = {f"{history}_{branch}": world for history, pair in branches.items() for branch, world in pair.items()}
    nrd06.tick_all(flat, 4)
    stages = {
        "D0": {
            history: {branch: nrd05.checkpoint(world) for branch, world in pair.items()}
            for history, pair in branches.items()
        }
    }
    nrd06.tick_all(flat, 64)
    stages["D64"] = {
        history: {branch: nrd05.checkpoint(world) for branch, world in pair.items()}
        for history, pair in branches.items()
    }
    analyses = {}
    for stage, stage_branches in stages.items():
        diagnostics = {
            history: {branch: nrd05.diagnostic(kernel, state) for branch, state in pair.items()}
            for history, pair in stage_branches.items()
        }
        analyses[stage] = nrd06.analyze_three(stage_branches, diagnostics)
        save_telemetry(cfg["id"], stage, stage_branches, diagnostics, telemetry)
    return {
        "configuration": cfg["id"],
        "probe": "C4_SIX_AXIS_RADIUS3",
        "probe_touched": touched,
        "stages": analyses,
        "retained_history_specificity": all(
            analyses[stage]["classification"] == "HISTORY_SPECIFIC_TRANSFORMATION"
            for stage in ("D0", "D64")
        ),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = nrd05.load_kernel(args.threads)

    fresh_telemetry = {}
    fresh_f3 = {}
    limitations = []
    for name in ("FRESH_V1", "FRESH_V2"):
        try:
            fresh_f3[name] = nrd06.run_recurrent_pilot(kernel, nrd05.CONFIGS[name], fresh_telemetry)
        except nrd05.GeometryNotClean as error:
            limitations.append({"block": "F3_FRESH", "configuration": name, "reason": str(error)})
    fresh_f3_pass = len(fresh_f3) == 2 and all(
        result["third_history_conditioned_update"]
        and result["future_capacity"]["future_causal_capacity_observed"]
        for result in fresh_f3.values()
    )

    probe_telemetry = {}
    probe_cases = {}
    probe_cases["MAIN_S0"] = run_new_probe_case(kernel, nrd05.CONFIGS["MAIN_S0"], probe_telemetry)
    if probe_cases["MAIN_S0"]["retained_history_specificity"]:
        for name in ("FRESH_V1", "FRESH_V2"):
            try:
                probe_cases[name] = run_new_probe_case(kernel, nrd05.CONFIGS[name], probe_telemetry)
            except nrd05.GeometryNotClean as error:
                limitations.append({"block": "P_NEW", "configuration": name, "reason": str(error)})
    probe_fresh_pass = all(
        name in probe_cases and probe_cases[name]["retained_history_specificity"]
        for name in ("MAIN_S0", "FRESH_V1", "FRESH_V2")
    )

    np.savez_compressed(BLOCK / "TELEMETRY" / "ING06_F3_FRESH.npz", **fresh_telemetry)
    orthogonal = ROOT / "02_ORTHOGONAL_PROBE"
    np.savez_compressed(orthogonal / "TELEMETRY" / "ING06_PNEW_C4.npz", **probe_telemetry)

    f3_result = nrd05.seal({
        "experiment_id": "ING06_6A_F3_FRESH_REPLICATION",
        "status": "F3_FRESH_REPLICATED" if fresh_f3_pass else "F3_FRESH_NOT_REPLICATED",
        "runtime": runtime,
        "configurations": fresh_f3,
        "limitations": limitations,
        "adjudication": {"fresh_V1_V2_pass": fresh_f3_pass, "formal_RW3": False, "L4": False},
        "telemetry": "TELEMETRY/ING06_F3_FRESH.npz",
    })
    nrd05.write_json(BLOCK / "RESULTS" / "ING06_F3_FRESH.json", f3_result)
    probe_result = nrd05.seal({
        "experiment_id": "ING06_6A_ORTHOGONAL_PNEW_C4",
        "status": "HISTORY_SPECIFICITY_GENERALIZES_TO_PNEW" if probe_fresh_pass else "PNEW_DOMAIN_NOT_GENERALIZED",
        "runtime": runtime,
        "probe": "C4_SIX_AXIS_RADIUS3",
        "configurations": probe_cases,
        "limitations": limitations,
        "adjudication": {"main_and_fresh_retained_specificity": probe_fresh_pass, "formal_RW3": False, "L4": False},
        "telemetry": "TELEMETRY/ING06_PNEW_C4.npz",
    })
    nrd05.write_json(orthogonal / "RESULTS" / "ING06_PNEW_C4_HISTORY_SPECIFICITY.json", probe_result)
    gate = fresh_f3_pass and probe_fresh_pass
    summary = nrd05.seal({
        "experiment_id": "ING06_PHASE_6A_GATE",
        "status": "PROGRESSIVE_LOAD_AUTHORIZED" if gate else "STOP_BEFORE_PROGRESSIVE_LOAD",
        "f3_fresh_pass": fresh_f3_pass,
        "orthogonal_probe_fresh_pass": probe_fresh_pass,
        "progressive_load_authorized": gate,
        "limitations": limitations,
    })
    nrd05.write_json(BLOCK / "RESULTS" / "ING06_PHASE_6A_GATE.json", summary)
    print(json.dumps({
        "gate": summary["status"],
        "f3_fresh": {
            name: {
                "classification": result["classification"],
                "third_update": result["third_history_conditioned_update"],
                "future_capacity": result["future_capacity"]["future_causal_capacity_observed"],
            }
            for name, result in fresh_f3.items()
        },
        "P_NEW": {
            name: {
                "D0": result["stages"]["D0"]["classification"],
                "D64": result["stages"]["D64"]["classification"],
                "retained": result["retained_history_specificity"],
            }
            for name, result in probe_cases.items()
        },
        "limitations": limitations,
    }, indent=2))


if __name__ == "__main__":
    main()
