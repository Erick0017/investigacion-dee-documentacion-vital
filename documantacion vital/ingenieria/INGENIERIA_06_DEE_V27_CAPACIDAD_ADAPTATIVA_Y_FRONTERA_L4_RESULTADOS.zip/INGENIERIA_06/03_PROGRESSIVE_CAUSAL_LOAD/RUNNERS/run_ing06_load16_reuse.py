#!/usr/bin/env python3
"""Continue saved load-8 worlds to load 16 by exact site reuse."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BLOCK = HERE.parent
sys.path.insert(0, str(HERE))

import run_ing06_progressive_load_s0 as load8  # noqa: E402

nrd05 = load8.nrd05
nrd06 = load8.nrd06
EVENTS16 = load8.EVENTS + load8.EVENTS


def load_stage8(kernel, config):
    telemetry_path = BLOCK / "TELEMETRY" / f"ING06_PROGRESSIVE_CAUSAL_LOAD_{config}.npz"
    result_path = BLOCK / "RESULTS" / f"ING06_PROGRESSIVE_CAUSAL_LOAD_{config}.json"
    source_result = json.loads(result_path.read_text(encoding="utf-8"))
    initial_fingerprints = {
        int(index): value["relation"]["fingerprint_sha256"]
        for index, value in source_result["result"]["stages"]["8"]["distinctions"].items()
    }
    with np.load(telemetry_path) as data:
        full_state = (data["STAGE_8_FULL_raw_a"], data["STAGE_8_FULL_clock_a"])
        worlds = {
            "FULL": nrd05.NativeWorld(kernel, full_state[0], full_state[1]),
            "REPEAT": nrd05.NativeWorld(kernel, data["STAGE_8_REPEAT_raw_a"], data["STAGE_8_REPEAT_clock_a"]),
            "CONTROL": nrd05.NativeWorld(kernel, data["STAGE_8_CONTROL_raw_a"], data["STAGE_8_CONTROL_clock_a"]),
        }
        for index in range(1, 9):
            worlds[f"OMIT_{index}"] = nrd05.NativeWorld(
                kernel, data[f"STAGE_8_OMIT_{index}_raw_a"], data[f"STAGE_8_OMIT_{index}_clock_a"]
            )
        for index in range(9, 17):
            worlds[f"OMIT_{index}"] = nrd05.NativeWorld(kernel, full_state[0], full_state[1])
    return worlds, initial_fingerprints, source_result


def run_continuation(kernel, cfg, config):
    load8.EVENTS = EVENTS16
    nrd05.configure_pulse(cfg)
    _, ports = nrd05.construct(kernel, nrd05.apparatus(cfg, "no_events"))
    worlds, initial_fingerprints, source_result = load_stage8(kernel, config)
    telemetry = {}
    stages = {}
    event_audit = []
    failed_stage = None
    first_cycle_sites = set()
    for event in EVENTS16[:8]:
        first_cycle_sites.update(q for q, _, _ in load8.event_sites(event, ports, cfg))

    for stage in range(9, 17):
        event = EVENTS16[stage - 1]
        sites = load8.event_sites(event, ports, cfg)
        new_sites = sorted(q for q, _, _ in sites if q not in first_cycle_sites)
        if new_sites:
            raise RuntimeError(f"Stage {stage} introduced non-frozen new sites: {new_sites}")
        row = {"stage": stage, "event": event, "sites": [list(q) for q, _, _ in sites], "overwrites": {}}
        for name, world in worlds.items():
            if name == "CONTROL" or name == f"OMIT_{stage}":
                continue
            selected = load8.event_sites("E1_AB_MAIN", ports, cfg) if name == "REPEAT" else sites
            row["overwrites"][name] = load8.inject_event(world, selected)
        nrd06.tick_all(worlds, 4)
        load8.save_worlds(f"STAGE_{stage}", worlds, telemetry)
        analysis = load8.analyze_stage(
            kernel, worlds, stage, initial_fingerprints, nrd05.checkpoint(worlds["CONTROL"]), ports, cfg
        )
        stages[str(stage)] = analysis
        event_audit.append(row)
        if not analysis["all_prior_distinctions_active_and_unique"] or not analysis["capacity"]["future_causal_capacity_observed"]:
            failed_stage = stage
            break

    rest = None
    e_new = None
    if failed_stage is not None:
        rest = load8.rest_analysis(kernel, worlds, failed_stage, initial_fingerprints, ports, cfg)
    elif len(stages) == 8:
        pre_new = nrd05.checkpoint(worlds["FULL"])
        no_new = nrd05.NativeWorld(kernel, pre_new[0], pre_new[1])
        sites = load8.event_sites("E_NEW_EIGHT_CORNERS_R6", ports, cfg)
        overwrites = {}
        for name, world in worlds.items():
            if name in {"REPEAT", "CONTROL"}:
                continue
            overwrites[name] = load8.inject_event(world, sites)
        nrd06.tick_all(worlds, 4)
        nrd06.tick_all({"NO_NEW": no_new}, 4)
        load8.save_worlds("POST_E_NEW_16", worlds, telemetry)
        telemetry["POST_E_NEW_16_NO_NEW_raw_a"] = no_new.raw_a.copy()
        telemetry["POST_E_NEW_16_NO_NEW_clock_a"] = no_new.clock_a.copy()
        full_new = nrd05.checkpoint(worlds["FULL"])
        new_relation = load8.relation_fingerprint(kernel, full_new, nrd05.checkpoint(no_new))
        old_after_new = load8.analyze_stage(
            kernel, worlds, 16, initial_fingerprints, nrd05.checkpoint(worlds["CONTROL"]), ports, cfg
        )
        next_capacity = load8.capacity_test(kernel, full_new, ports, cfg, "CAP_EIGHT_CORNERS_R7")
        old_hashes = {value["relation"]["fingerprint_sha256"] for value in old_after_new["distinctions"].values()}
        new_unique = new_relation["causally_active"] and new_relation["fingerprint_sha256"] not in old_hashes
        e_new = {
            "event": "E_NEW_EIGHT_CORNERS_R6",
            "overwrites": overwrites,
            "new_relation": new_relation,
            "prior_distinctions_after_E_NEW": old_after_new,
            "new_distinction_independent": new_unique,
            "load_after_E_NEW": 17 if old_after_new["all_prior_distinctions_active_and_unique"] and new_unique else old_after_new["independent_unique_fingerprint_count"] + int(new_unique),
            "capacity_for_another_acquisition": next_capacity,
            "continued_adaptive_capacity": old_after_new["all_prior_distinctions_active_and_unique"] and new_unique and next_capacity["future_causal_capacity_observed"],
        }

    source_reuse = source_result["result"]["resource_reuse"]
    second_cycle_uses = sum(len(load8.event_sites(event, ports, cfg)) for event in EVENTS16[8:])
    maximum = max((value["independent_unique_fingerprint_count"] for value in stages.values()), default=8)
    if e_new:
        maximum = max(maximum, e_new["load_after_E_NEW"])
    return {
        "configuration": config,
        "continued_from_saved_stage_8": True,
        "stages": stages,
        "event_audit": event_audit,
        "failed_stage": failed_stage,
        "rest_analysis": rest,
        "conditional_E_NEW": e_new,
        "maximum_independent_causal_load_demonstrated": maximum,
        "resource_reuse": {
            "first_cycle_unique_sites": source_reuse["unique_event_sites"],
            "second_cycle_site_uses": second_cycle_uses,
            "second_cycle_new_sites": 0,
            "all_second_cycle_sites_reused": True,
            "bounded_world_voxels": cfg["n"] ** 3,
        },
        "telemetry": telemetry,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--config", choices=("MAIN_S0", "FRESH_V1"), default="MAIN_S0")
    args = parser.parse_args()
    kernel, runtime = nrd05.load_kernel(args.threads)
    cfg = nrd05.CONFIGS[args.config]
    result = run_continuation(kernel, cfg, args.config)
    telemetry = result.pop("telemetry")
    continued = bool(result["conditional_E_NEW"] and result["conditional_E_NEW"]["continued_adaptive_capacity"])
    status = (
        "CAUSAL_LOAD_INTERFERENCE_OBSERVED"
        if result["failed_stage"]
        else "CAUSAL_LOAD_17_WITH_NATIVE_SITE_REUSE_AND_CONTINUED_CAPACITY"
        if continued
        else "CAUSAL_LOAD_16_WITHOUT_CONFIRMED_CONTINUATION"
    )
    sealed = nrd05.seal({
        "experiment_id": f"ING06_CAUSAL_LOAD_16_REUSE_{args.config}",
        "status": status,
        "runtime": runtime,
        "result": result,
        "adjudication": {"formal_RW3": False, "L4": False, "autonomy_stage_authorized": False},
    })
    nrd05.write_json(BLOCK / "RESULTS" / f"ING06_CAUSAL_LOAD_16_REUSE_{args.config}.json", sealed)
    np.savez_compressed(BLOCK / "TELEMETRY" / f"ING06_CAUSAL_LOAD_16_REUSE_{args.config}.npz", **telemetry)
    print(json.dumps({
        "status": status,
        "failed_stage": result["failed_stage"],
        "maximum_load": result["maximum_independent_causal_load_demonstrated"],
        "stages": {
            stage: {
                "active": value["active_distinction_count"],
                "unique": value["independent_unique_fingerprint_count"],
                "capacity": value["capacity"]["future_causal_capacity_observed"],
                "landscape_diff": value["landscape_vs_control"]["combined_diff_positions"],
            }
            for stage, value in result["stages"].items()
        },
        "E_NEW": None if result["conditional_E_NEW"] is None else {
            "load": result["conditional_E_NEW"]["load_after_E_NEW"],
            "prior_retained": result["conditional_E_NEW"]["prior_distinctions_after_E_NEW"]["all_prior_distinctions_active_and_unique"],
            "new_independent": result["conditional_E_NEW"]["new_distinction_independent"],
            "capacity_next": result["conditional_E_NEW"]["capacity_for_another_acquisition"]["future_causal_capacity_observed"],
        },
        "resource_reuse": result["resource_reuse"],
    }, indent=2))


if __name__ == "__main__":
    main()
