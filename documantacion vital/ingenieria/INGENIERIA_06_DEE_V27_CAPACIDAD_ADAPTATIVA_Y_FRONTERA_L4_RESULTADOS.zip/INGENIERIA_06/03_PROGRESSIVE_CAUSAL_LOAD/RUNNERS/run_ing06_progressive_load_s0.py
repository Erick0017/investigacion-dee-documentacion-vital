#!/usr/bin/env python3
"""Ingeniería 06: gated progressive causal-load discovery in MAIN_S0."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import deque
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BLOCK = HERE.parent
ROOT = BLOCK.parent
ENGINEERING = ROOT.parent
BUNDLED_ENGINEERING = ROOT / "DEPENDENCIES"
NRD06_RUNNERS = (
    BUNDLED_ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
    if (BUNDLED_ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS").is_dir()
    else ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
)
sys.path.insert(0, str(NRD06_RUNNERS))

import run_nrd06_history_specificity as nrd06  # noqa: E402

nrd05 = nrd06.nrd05
HORIZONS = nrd06.HORIZONS
MAIN = nrd05.MAIN_GEOMETRY
SEP = nrd05.SEPARATED_GEOMETRY
EVENTS = (
    "E1_AB_MAIN",
    "E2_BA_MAIN",
    "E3_SIX_AXIS_R3",
    "E4_EIGHT_CORNERS_R4",
    "E5_AB_SEPARATED",
    "E6_BA_SEPARATED",
    "E7_SIX_AXIS_R5",
    "E8_EIGHT_CORNERS_R5",
)


def sha_text(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def composed(vector, secondary, cfg):
    return nrd05.compose_transform(vector, secondary, cfg)


def radial_sites(cfg, radius, corners=False):
    if corners:
        offsets = tuple((x * radius, y * radius, z * radius) for x in (-1, 1) for y in (-1, 1) for z in (-1, 1))
    else:
        offsets = ((radius, 0, 0), (-radius, 0, 0), (0, radius, 0), (0, -radius, 0), (0, 0, radius), (0, 0, -radius))
    sites = []
    for offset in offsets:
        transformed = nrd05.transform(offset, cfg["permutation"], cfg["signs"])
        q = tuple((cfg["origin"][i] + transformed[i]) % cfg["n"] for i in range(3))
        direction = tuple(-int(np.sign(v)) for v in transformed)
        sites.append((q, nrd05.pack(8000, 0, direction, 1), 0))
    return sites


def ab_sites(ports, cfg, secondary):
    target_a, target_b, dir_a, dir_b = nrd05.geometry(ports, cfg, secondary)
    source_b = nrd05.add(target_b, dir_b, -1, cfg["n"])
    return [
        (target_a, nrd05.pack(5000, 0, dir_a, 1), 17),
        (source_b, nrd05.pack(0, 0, dir_b, 1), 19),
    ]


def ba_sites(ports, cfg, secondary):
    target_a, target_b, dir_a, dir_b = nrd05.geometry(ports, cfg, secondary)
    source_b = nrd05.add(target_b, dir_b, -1, cfg["n"])
    source_a = nrd05.add(target_a, dir_a, -2, cfg["n"])
    return [
        (source_b, nrd05.pack(0, 0, dir_b, 1), 19),
        (source_a, nrd05.pack(0, 0, dir_a, 1), 17),
    ]


def event_sites(event, ports, cfg):
    if event == "E1_AB_MAIN":
        return ab_sites(ports, cfg, MAIN)
    if event == "E2_BA_MAIN":
        return ba_sites(ports, cfg, MAIN)
    if event == "E3_SIX_AXIS_R3":
        return radial_sites(cfg, 3, False)
    if event == "E4_EIGHT_CORNERS_R4":
        return radial_sites(cfg, 4, True)
    if event == "E5_AB_SEPARATED":
        return ab_sites(ports, cfg, SEP)
    if event == "E6_BA_SEPARATED":
        return ba_sites(ports, cfg, SEP)
    if event == "E7_SIX_AXIS_R5":
        return radial_sites(cfg, 5, False)
    if event == "E8_EIGHT_CORNERS_R5":
        return radial_sites(cfg, 5, True)
    if event == "E_NEW_EIGHT_CORNERS_R6":
        return radial_sites(cfg, 6, True)
    if event == "CAP_AXIS_R7":
        q, raw, clock = radial_sites(cfg, 7, False)[0]
        return [(q, raw, clock)]
    if event == "CAP_EIGHT_CORNERS_R7":
        return radial_sites(cfg, 7, True)
    raise ValueError(event)


def inject_event(world, sites):
    overwritten = []
    for q, raw, clock in sites:
        if int(world.raw_a[q]) != 0 or int(world.clock_a[q]) != 0:
            overwritten.append({"q": list(q), "raw": int(world.raw_a[q]), "clock": int(world.clock_a[q])})
        world.inject(q, raw, clock)
    return overwritten


def zero_effect_like(state):
    return np.zeros_like(state[0]), np.zeros_like(state[1])


def relation_fingerprint(kernel, left, right):
    left_diag = nrd05.diagnostic(kernel, left)
    right_diag = nrd05.diagnostic(kernel, right)
    immediate = nrd05.effect_signature(left, right)
    future = {}
    future_relevant = {}
    fingerprint_parts = [immediate["raw_xor_sha256"], immediate["clock_xor_sha256"]]
    for horizon in HORIZONS:
        row = {}
        differs = False
        for category in ("C0", "C3", "RESPONSE"):
            signature = nrd05.effect_signature(left_diag[category][horizon], right_diag[category][horizon])
            row[category] = signature
            fingerprint_parts.extend((signature["raw_xor_sha256"], signature["clock_xor_sha256"]))
            differs = differs or signature["raw_diff_positions"] > 0 or signature["clock_diff_positions"] > 0
        future[str(horizon)] = row
        future_relevant[str(horizon)] = differs
    immediate_distinct = immediate["raw_diff_positions"] > 0 or immediate["clock_diff_positions"] > 0
    return {
        "fingerprint_sha256": sha_text("|".join(fingerprint_parts)),
        "immediate": immediate,
        "future": future,
        "future_relevant": future_relevant,
        "causally_active": immediate_distinct and all(future_relevant.values()),
    }


def periodic_components(mask):
    n = mask.shape[0]
    remaining = {tuple(int(v) for v in q) for q in np.argwhere(mask)}
    sizes = []
    while remaining:
        start = remaining.pop()
        queue = deque([start])
        size = 1
        while queue:
            q = queue.popleft()
            for axis in range(3):
                for delta in (-1, 1):
                    nxt = list(q)
                    nxt[axis] = (nxt[axis] + delta) % n
                    nxt = tuple(nxt)
                    if nxt in remaining:
                        remaining.remove(nxt)
                        queue.append(nxt)
                        size += 1
        sizes.append(size)
    return sorted(sizes, reverse=True)


def landscape_metrics(state, control):
    raw_mask = state[0] != control[0]
    clock_mask = state[1] != control[1]
    combined = raw_mask | clock_mask
    positions = np.argwhere(combined)
    components = periodic_components(combined)
    return {
        "raw_diff_positions": int(np.count_nonzero(raw_mask)),
        "clock_diff_positions": int(np.count_nonzero(clock_mask)),
        "combined_diff_positions": int(np.count_nonzero(combined)),
        "density": float(np.count_nonzero(combined) / combined.size),
        "index_bbox": None if positions.size == 0 else {
            "min": positions.min(axis=0).astype(int).tolist(),
            "max": positions.max(axis=0).astype(int).tolist(),
        },
        "periodic_component_count": len(components),
        "largest_periodic_components": components[:10],
    }


def capacity_test(kernel, state, ports, cfg, event="CAP_AXIS_R7"):
    control = nrd05.NativeWorld(kernel, state[0], state[1])
    probe = nrd05.NativeWorld(kernel, state[0], state[1])
    sites = event_sites(event, ports, cfg)
    overwritten = inject_event(probe, sites)
    nrd06.tick_all({"CONTROL": control, "PROBE": probe}, 4)
    relation = relation_fingerprint(kernel, nrd05.checkpoint(probe), nrd05.checkpoint(control))
    return {
        "event": event,
        "touched": [list(q) for q, _, _ in sites],
        "preexisting_touched_positions": overwritten,
        "relation": relation,
        "future_causal_capacity_observed": relation["causally_active"],
    }


def analyze_stage(kernel, worlds, stage, initial_fingerprints, control_state, ports, cfg):
    full = nrd05.checkpoint(worlds["FULL"])
    distinctions = {}
    active_fingerprints = {}
    for event_index in range(1, stage + 1):
        omit = nrd05.checkpoint(worlds[f"OMIT_{event_index}"])
        relation = relation_fingerprint(kernel, full, omit)
        baseline = initial_fingerprints.get(event_index)
        if relation["causally_active"]:
            status = "PRESERVED" if baseline == relation["fingerprint_sha256"] else "TRANSFORMED_BUT_CAUSAL"
            active_fingerprints.setdefault(relation["fingerprint_sha256"], []).append(event_index)
        elif relation["immediate"]["raw_diff_positions"] or relation["immediate"]["clock_diff_positions"]:
            status = "DEGRADED"
        else:
            status = "LOST"
        distinctions[str(event_index)] = {"event": EVENTS[event_index - 1], "status": status, "relation": relation}
        if baseline is None:
            initial_fingerprints[event_index] = relation["fingerprint_sha256"]
    merged_groups = [members for members in active_fingerprints.values() if len(members) > 1]
    for members in merged_groups:
        for event_index in members:
            distinctions[str(event_index)]["status"] = "MERGED_WITH_NEW_HISTORY"
            distinctions[str(event_index)]["merged_with"] = [value for value in members if value != event_index]
    active = [int(key) for key, value in distinctions.items() if value["relation"]["causally_active"]]
    unique_active = len(active_fingerprints)
    capacity = capacity_test(kernel, full, ports, cfg)
    repeat_capacity = capacity_test(kernel, nrd05.checkpoint(worlds["REPEAT"]), ports, cfg)
    control_capacity = capacity_test(kernel, nrd05.checkpoint(worlds["CONTROL"]), ports, cfg)
    return {
        "stage": stage,
        "distinctions": distinctions,
        "active_distinction_count": len(active),
        "independent_unique_fingerprint_count": unique_active,
        "merged_groups": merged_groups,
        "all_prior_distinctions_active_and_unique": len(active) == stage and unique_active == stage,
        "capacity": capacity,
        "repeat_capacity": repeat_capacity,
        "control_capacity": control_capacity,
        "landscape_vs_control": landscape_metrics(full, control_state),
        "repeat_landscape_vs_control": landscape_metrics(nrd05.checkpoint(worlds["REPEAT"]), control_state),
    }


def rest_analysis(kernel, worlds, failed_stage, initial_fingerprints, ports, cfg):
    rest_worlds = {
        name: nrd05.NativeWorld(kernel, world.raw_a, world.clock_a)
        for name, world in worlds.items()
    }
    results = {}
    elapsed = 0
    for target in (16, 64, 256):
        nrd06.tick_all(rest_worlds, target - elapsed)
        elapsed = target
        control_state = nrd05.checkpoint(rest_worlds["CONTROL"])
        results[f"D{target}"] = analyze_stage(
            kernel, rest_worlds, failed_stage, initial_fingerprints, control_state, ports, cfg
        )
    before_active = sum(
        1 for value in results["D16"]["distinctions"].values() if value["relation"]["causally_active"]
    )
    best_active = max(value["active_distinction_count"] for value in results.values())
    initial_capacity = results["D16"]["capacity"]["future_causal_capacity_observed"]
    capacity_restored = (not initial_capacity) and any(
        value["capacity"]["future_causal_capacity_observed"]
        for key, value in results.items() if key != "D16"
    )
    return {
        "windows": results,
        "native_reorganization_candidate": best_active > before_active or capacity_restored,
        "note": "A candidate requires fresh causal validation; passive continued divergence is not automatically reorganization."
    }


def save_worlds(prefix, worlds, telemetry):
    for name, world in worlds.items():
        telemetry[f"{prefix}_{name}_raw_a"] = world.raw_a.copy()
        telemetry[f"{prefix}_{name}_clock_a"] = world.clock_a.copy()


def run_discovery(kernel, cfg, telemetry):
    nrd05.configure_pulse(cfg)
    template, ports = nrd05.construct(kernel, nrd05.apparatus(cfg, "no_events"))
    names = ["FULL", "REPEAT", "CONTROL"] + [f"OMIT_{index}" for index in range(1, 9)]
    worlds = {name: nrd05.NativeWorld(kernel, template.raw_a, template.clock_a) for name in names}
    initial_fingerprints = {}
    event_audit = []
    stages = {}
    touched_union = set()
    touched_total = 0
    failed_stage = None

    for stage, event in enumerate(EVENTS, start=1):
        sites = event_sites(event, ports, cfg)
        touched_union.update(q for q, _, _ in sites)
        touched_total += len(sites)
        row = {"stage": stage, "event": event, "sites": [list(q) for q, _, _ in sites], "overwrites": {}}
        for name, world in worlds.items():
            if name == "CONTROL" or name == f"OMIT_{stage}":
                continue
            selected = event_sites("E1_AB_MAIN", ports, cfg) if name == "REPEAT" else sites
            row["overwrites"][name] = inject_event(world, selected)
        nrd06.tick_all(worlds, 4)
        save_worlds(f"STAGE_{stage}", worlds, telemetry)
        control_state = nrd05.checkpoint(worlds["CONTROL"])
        analysis = analyze_stage(kernel, worlds, stage, initial_fingerprints, control_state, ports, cfg)
        stages[str(stage)] = analysis
        event_audit.append(row)
        if not analysis["all_prior_distinctions_active_and_unique"] or not analysis["capacity"]["future_causal_capacity_observed"]:
            failed_stage = stage
            break

    rest = None
    e_new = None
    if failed_stage is not None:
        rest = rest_analysis(kernel, worlds, failed_stage, initial_fingerprints, ports, cfg)
    elif len(stages) == 8:
        pre_new = nrd05.checkpoint(worlds["FULL"])
        no_new = nrd05.NativeWorld(kernel, pre_new[0], pre_new[1])
        sites = event_sites("E_NEW_EIGHT_CORNERS_R6", ports, cfg)
        e_new_overwrites = {}
        for name, world in worlds.items():
            if name in {"REPEAT", "CONTROL"}:
                continue
            e_new_overwrites[name] = inject_event(world, sites)
        nrd06.tick_all(worlds, 4)
        no_new.tick(); no_new.tick(); no_new.tick(); no_new.tick()
        full_new = nrd05.checkpoint(worlds["FULL"])
        save_worlds("POST_E_NEW", worlds, telemetry)
        telemetry["POST_E_NEW_NO_NEW_raw_a"] = no_new.raw_a.copy()
        telemetry["POST_E_NEW_NO_NEW_clock_a"] = no_new.clock_a.copy()
        new_relation = relation_fingerprint(kernel, full_new, nrd05.checkpoint(no_new))
        old_after_new = analyze_stage(
            kernel, worlds, 8, initial_fingerprints, nrd05.checkpoint(worlds["CONTROL"]), ports, cfg
        )
        next_capacity = capacity_test(kernel, full_new, ports, cfg, "CAP_EIGHT_CORNERS_R7")
        prior_unique = old_after_new["all_prior_distinctions_active_and_unique"]
        new_unique = new_relation["causally_active"] and new_relation["fingerprint_sha256"] not in {
            value["relation"]["fingerprint_sha256"] for value in old_after_new["distinctions"].values()
        }
        e_new = {
            "event": "E_NEW_EIGHT_CORNERS_R6",
            "sites": [list(q) for q, _, _ in sites],
            "overwrites": e_new_overwrites,
            "new_relation": new_relation,
            "prior_distinctions_after_E_NEW": old_after_new,
            "new_distinction_independent": new_unique,
            "load_after_E_NEW": 9 if prior_unique and new_unique else old_after_new["independent_unique_fingerprint_count"] + int(new_unique),
            "capacity_for_another_acquisition": next_capacity,
            "continued_adaptive_capacity": prior_unique and new_unique and next_capacity["future_causal_capacity_observed"],
        }

    maximum = max((value["independent_unique_fingerprint_count"] for value in stages.values()), default=0)
    if e_new is not None:
        maximum = max(maximum, e_new["load_after_E_NEW"])
    return {
        "configuration": cfg["id"],
        "stages": stages,
        "event_audit": event_audit,
        "failed_stage": failed_stage,
        "rest_analysis": rest,
        "conditional_E_NEW": e_new,
        "maximum_independent_causal_load_demonstrated": maximum,
        "resource_reuse": {
            "event_site_uses": touched_total,
            "unique_event_sites": len(touched_union),
            "reused_site_uses": touched_total - len(touched_union),
            "bounded_world_voxels": cfg["n"] ** 3,
        },
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--config", choices=("MAIN_S0", "FRESH_V1", "FRESH_V2"), default="MAIN_S0")
    args = parser.parse_args()
    kernel, runtime = nrd05.load_kernel(args.threads)
    telemetry = {}
    result = run_discovery(kernel, nrd05.CONFIGS[args.config], telemetry)
    failed = result["failed_stage"]
    continued = bool(result["conditional_E_NEW"] and result["conditional_E_NEW"]["continued_adaptive_capacity"])
    if failed:
        status = "CAUSAL_LOAD_INTERFERENCE_OBSERVED"
    elif continued:
        status = "CAUSAL_LOAD_9_WITH_CONTINUED_FUTURE_CAPACITY"
    else:
        status = "CAUSAL_LOAD_8_WITHOUT_CONFIRMED_CONTINUATION"
    sealed = nrd05.seal({
        "experiment_id": f"ING06_PROGRESSIVE_CAUSAL_LOAD_{args.config}",
        "status": status,
        "runtime": runtime,
        "result": result,
        "adjudication": {
            "formal_RW3": False,
            "L4": False,
            "fresh_validation_required": result["maximum_independent_causal_load_demonstrated"] > 0,
            "autonomy_stage_authorized": False,
        },
    })
    out = BLOCK / "RESULTS" / f"ING06_PROGRESSIVE_CAUSAL_LOAD_{args.config}.json"
    nrd05.write_json(out, sealed)
    np.savez_compressed(BLOCK / "TELEMETRY" / f"ING06_PROGRESSIVE_CAUSAL_LOAD_{args.config}.npz", **telemetry)
    print(json.dumps({
        "status": status,
        "failed_stage": failed,
        "maximum_independent_causal_load": result["maximum_independent_causal_load_demonstrated"],
        "stage_summary": {
            stage: {
                "active": value["active_distinction_count"],
                "unique": value["independent_unique_fingerprint_count"],
                "all_active_unique": value["all_prior_distinctions_active_and_unique"],
                "capacity": value["capacity"]["future_causal_capacity_observed"],
                "repeat_capacity": value["repeat_capacity"]["future_causal_capacity_observed"],
                "landscape_diff": value["landscape_vs_control"]["combined_diff_positions"],
            }
            for stage, value in result["stages"].items()
        },
        "rest": None if result["rest_analysis"] is None else {
            key: {
                "active": value["active_distinction_count"],
                "unique": value["independent_unique_fingerprint_count"],
                "capacity": value["capacity"]["future_causal_capacity_observed"],
            }
            for key, value in result["rest_analysis"]["windows"].items()
        },
        "E_NEW": None if result["conditional_E_NEW"] is None else {
            "load": result["conditional_E_NEW"]["load_after_E_NEW"],
            "new_independent": result["conditional_E_NEW"]["new_distinction_independent"],
            "prior_retained": result["conditional_E_NEW"]["prior_distinctions_after_E_NEW"]["all_prior_distinctions_active_and_unique"],
            "capacity_next": result["conditional_E_NEW"]["capacity_for_another_acquisition"]["future_causal_capacity_observed"],
            "continued": result["conditional_E_NEW"]["continued_adaptive_capacity"],
        },
    }, indent=2))


if __name__ == "__main__":
    main()
