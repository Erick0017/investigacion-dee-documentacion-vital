#!/usr/bin/env python3
"""Characterize stage-16 expansion with dose-matched order counterfactuals."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LOAD_RUNNERS = ROOT / "03_PROGRESSIVE_CAUSAL_LOAD" / "RUNNERS"
LOAD_BLOCK = ROOT / "03_PROGRESSIVE_CAUSAL_LOAD"
sys.path.insert(0, str(LOAD_RUNNERS))

import run_ing06_progressive_load_s0 as load8  # noqa: E402

nrd05 = load8.nrd05
nrd06 = load8.nrd06


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = nrd05.load_kernel(args.threads)
    cfg = nrd05.CONFIGS["MAIN_S0"]
    _, ports = nrd05.construct(kernel, nrd05.apparatus(cfg, "no_events"))
    with np.load(LOAD_BLOCK / "TELEMETRY" / "ING06_PROGRESSIVE_CAUSAL_LOAD_MAIN_S0.npz") as stage8:
        start = (stage8["STAGE_8_FULL_raw_a"], stage8["STAGE_8_FULL_clock_a"])
    with np.load(LOAD_BLOCK / "TELEMETRY" / "ING06_CAUSAL_LOAD_16_REUSE_MAIN_S0.npz") as canonical_data:
        canonical = (canonical_data["STAGE_16_FULL_raw_a"], canonical_data["STAGE_16_FULL_clock_a"])

    worlds = {
        "REVERSED": nrd05.NativeWorld(kernel, start[0], start[1]),
        "REPEAT_AB": nrd05.NativeWorld(kernel, start[0], start[1]),
        "NO_EVENT": nrd05.NativeWorld(kernel, start[0], start[1]),
    }
    audit = []
    for index, event in enumerate(reversed(load8.EVENTS), start=9):
        reversed_sites = load8.event_sites(event, ports, cfg)
        repeat_sites = load8.event_sites("E1_AB_MAIN", ports, cfg)
        audit.append({
            "stage": index,
            "reversed_event": event,
            "reversed_overwrites": load8.inject_event(worlds["REVERSED"], reversed_sites),
            "repeat_overwrites": load8.inject_event(worlds["REPEAT_AB"], repeat_sites),
        })
        nrd06.tick_all(worlds, 4)

    states = {name: nrd05.checkpoint(world) for name, world in worlds.items()}
    states["CANONICAL"] = canonical
    no_event = states["NO_EVENT"]
    metrics = {name: load8.landscape_metrics(state, no_event) for name, state in states.items() if name != "NO_EVENT"}
    world_voxels = cfg["n"] ** 3
    globalized = {
        name: value["combined_diff_positions"] >= 0.5 * world_voxels
        and bool(value["largest_periodic_components"])
        and value["largest_periodic_components"][0] >= 0.5 * world_voxels
        for name, value in metrics.items()
    }
    relation_can_rev = load8.relation_fingerprint(kernel, states["CANONICAL"], states["REVERSED"])
    relation_can_repeat = load8.relation_fingerprint(kernel, states["CANONICAL"], states["REPEAT_AB"])
    relation_rev_repeat = load8.relation_fingerprint(kernel, states["REVERSED"], states["REPEAT_AB"])
    capacity = {name: load8.capacity_test(kernel, state, ports, cfg) for name, state in states.items()}

    if globalized["CANONICAL"] and globalized["REVERSED"]:
        expansion_class = "DOSE_SUFFICIENT_FOR_GLOBAL_EXPANSION_WITH_ORDER_SPECIFIC_ORGANIZATION" if relation_can_rev["causally_active"] else "GENERIC_DOSE_DRIVEN_EXPANSION"
    elif globalized["CANONICAL"] != globalized["REVERSED"]:
        expansion_class = "HISTORY_ORDER_CONDITIONED_GLOBAL_EXPANSION"
    else:
        expansion_class = "NO_GLOBAL_EXPANSION_UNDER_DOSE_MATCHED_CONTROL"

    telemetry = {}
    for name, state in states.items():
        telemetry[f"{name}_raw_a"] = state[0]
        telemetry[f"{name}_clock_a"] = state[1]
    np.savez_compressed(HERE / "ING06_EXPANSION_CONTROL.npz", **telemetry)
    result = nrd05.seal({
        "experiment_id": "ING06_HISTORY_ORDER_VS_PHYSICAL_DOSE_CONTROL",
        "status": expansion_class,
        "runtime": runtime,
        "common_start": "MAIN_S0_STAGE_8_FULL",
        "metrics_vs_no_event": metrics,
        "globalized": globalized,
        "relations": {
            "CANONICAL_vs_REVERSED": relation_can_rev,
            "CANONICAL_vs_REPEAT_AB": relation_can_repeat,
            "REVERSED_vs_REPEAT_AB": relation_rev_repeat,
        },
        "capacity": {name: value["future_causal_capacity_observed"] for name, value in capacity.items()},
        "audit": audit,
        "adjudication": {
            "canonical_and_reversed_dose_matched": True,
            "event_order_changes_future_organization": relation_can_rev["causally_active"],
            "formal_RW3": False,
            "L4": False,
        },
        "telemetry": "ING06_EXPANSION_CONTROL.npz",
    })
    nrd05.write_json(HERE / "ING06_EXPANSION_CONTROL.json", result)
    print(json.dumps({
        "status": expansion_class,
        "globalized": globalized,
        "diff_positions": {name: value["combined_diff_positions"] for name, value in metrics.items()},
        "largest_component": {name: value["largest_periodic_components"][0] if value["largest_periodic_components"] else 0 for name, value in metrics.items()},
        "canonical_vs_reversed_future_distinct": relation_can_rev["causally_active"],
        "capacity": result["capacity"],
    }, indent=2))


if __name__ == "__main__":
    main()
