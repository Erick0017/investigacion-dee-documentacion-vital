# Reproducción — Método A

Desde la raíz de Ingeniería 06, con DEE v27 congelado y un thread:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\09_ENDOGENOUS_FREE_RUN\RUNNERS\run_ing06_endogenous_free_run.py' --threads 1
```

El freeze lock fija historias, `HOST_STOP`, checkpoints, challenges, horizontes y adjudicación. La telemetría NPZ conserva `(raw_a, clock_a)` de mundos principales y clones diagnósticos. El runner registra cero intervenciones sobre los mundos principales después de `t=4`.

