# Reproducción — Método B

Desde la raíz de Ingeniería 06, con DEE v27 congelado y un thread:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\10_EQUIVALENT_CAUSAL_OPPORTUNITIES\RUNNERS\run_ing06_equivalent_opportunities.py' --threads 1
```

El freeze lock fija las tres instancias, historias, `HOST_STOP`, checkpoints, challenge isotrópico C6, horizontes y observer rotacional. FULL y todas las ramas OMIT se construyen en `t0`; después de `t=4` sólo se ejecutan ticks y checkpoints en los mundos principales.

