#!/usr/bin/env python3
"""Method B: history-conditioned breaking of causal opportunity equivalence."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
BLOCK = HERE.parent
ROOT = BLOCK.parent
BUNDLED = ROOT / "DEPENDENCIES" / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
WORKSPACE = ROOT.parent / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
sys.path.insert(0, str(BUNDLED if BUNDLED.is_dir() else WORKSPACE))

import run_nrd06_history_specificity as nrd06  # noqa: E402

nrd05 = nrd06.nrd05
OFFSETS = (0, 16, 32, 64, 128, 256, 391)
HORIZONS = (32, 64)
HISTORIES = ("H0", "HA", "HB")
OPPORTUNITIES = ("P1", "P2", "P3")


def opportunity_sites(origin, radius=7):
    result = {}
    for index, axis in enumerate(range(3), start=1):
        sites = []
        for sign in (-1, 1):
            offset = [0, 0, 0]
            offset[axis] = sign * radius
            q = tuple(origin[i] + offset[i] for i in range(3))
            direction = [0, 0, 0]
            direction[axis] = -sign
            sites.append((q, nrd05.pack(8000, 0, tuple(direction), 1), 0))
        result[f"P{index}"] = sites
    return result


def make_world(kernel, history, omit, n=23):
    origin = (n // 2,) * 3
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    for name, sites in opportunity_sites(origin).items():
        if name == omit:
            continue
        for q, value, phase in sites:
            raw[q] = value
            clock[q] = np.uint64(phase)
    if history != "H0":
        phases = (17, 19) if history == "HA" else (19, 17)
        q_negative = (origin[0], origin[1] - 2, origin[2])
        q_positive = (origin[0], origin[1] + 2, origin[2])
        raw[q_negative] = nrd05.pack(0, 0, (0, 1, 0), 1)
        raw[q_positive] = nrd05.pack(0, 0, (0, -1, 0), 1)
        clock[q_negative] = np.uint64(phases[0])
        clock[q_positive] = np.uint64(phases[1])
    return nrd05.NativeWorld(kernel, raw, clock)


def run_c6(kernel, state, origin):
    world = nrd05.NativeWorld(kernel, state[0], state[1])
    for axis in range(3):
        for sign in (-1, 1):
            offset = [0, 0, 0]
            offset[axis] = sign * 6
            q = tuple(origin[i] + offset[i] for i in range(3))
            direction = [0, 0, 0]
            direction[axis] = -sign
            world.inject(q, nrd05.pack(8000, 0, tuple(direction), 1), 0)
    out = {}
    for tick in range(1, 65):
        world.tick()
        if tick in HORIZONS:
            out[tick] = nrd05.checkpoint(world)
    return out


def free_future(kernel, state):
    world = nrd05.NativeWorld(kernel, state[0], state[1])
    out = {}
    for tick in range(1, 65):
        world.tick()
        if tick in HORIZONS:
            out[tick] = nrd05.checkpoint(world)
    return out


def normalized_signature(left, right):
    signature = nrd05.effect_signature(left, right)
    fields = signature["field_diff_positions"]
    return (
        signature["raw_diff_positions"],
        signature["clock_diff_positions"],
        fields["state"],
        fields["sreg"],
        fields["semantic"],
        *sorted((fields["dx"], fields["dy"], fields["dz"])),
    )


def opportunity_relation(kernel, full, omitted, origin):
    full_c0, omit_c0 = free_future(kernel, full), free_future(kernel, omitted)
    full_c6, omit_c6 = run_c6(kernel, full, origin), run_c6(kernel, omitted, origin)
    vectors = [normalized_signature(full, omitted)]
    details = {"public": vectors[0], "future": {}}
    for horizon in HORIZONS:
        c0 = normalized_signature(full_c0[horizon], omit_c0[horizon])
        c6 = normalized_signature(full_c6[horizon], omit_c6[horizon])
        r_full = nrd05.pair_effect(full_c6[horizon], full_c0[horizon])
        r_omit = nrd05.pair_effect(omit_c6[horizon], omit_c0[horizon])
        response = normalized_signature(r_full, r_omit)
        vectors.extend((c0, c6, response))
        details["future"][str(horizon)] = {"C0": c0, "C6": c6, "RESPONSE": response}
    encoded = json.dumps(vectors, separators=(",", ":"))
    return {
        "rotation_invariant_fingerprint": hashlib.sha256(encoded.encode("utf-8")).hexdigest(),
        "vectors": vectors,
        "details": details,
        "future_relevant": any(any(value) for value in vectors[1:]),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    kernel, runtime = nrd05.load_kernel(args.threads)
    n = 23
    origin = (n // 2,) * 3
    worlds = {
        history: {
            "FULL": make_world(kernel, history, None, n),
            **{f"OMIT_{opportunity}": make_world(kernel, history, opportunity, n) for opportunity in OPPORTUNITIES},
        }
        for history in HISTORIES
    }
    flat = {f"{history}_{name}": world for history, branches in worlds.items() for name, world in branches.items()}
    nrd06.tick_all(flat, 4)

    checkpoints = {}
    telemetry = {}
    elapsed = 0
    for offset in OFFSETS:
        nrd06.tick_all(flat, offset - elapsed)
        elapsed = offset
        checkpoints[offset] = {
            history: {name: nrd05.checkpoint(world) for name, world in branches.items()}
            for history, branches in worlds.items()
        }
        for history, branches in checkpoints[offset].items():
            for name, state in branches.items():
                telemetry[f"T{offset}_{history}_{name}_raw_a"] = state[0]
                telemetry[f"T{offset}_{history}_{name}_clock_a"] = state[1]

    observations = {}
    for offset in OFFSETS:
        row = {}
        for history in HISTORIES:
            full = checkpoints[offset][history]["FULL"]
            relations = {
                opportunity: opportunity_relation(
                    kernel, full, checkpoints[offset][history][f"OMIT_{opportunity}"], origin
                )
                for opportunity in OPPORTUNITIES
            }
            pattern = [relations[opportunity]["rotation_invariant_fingerprint"] for opportunity in OPPORTUNITIES]
            row[history] = {
                "relations": relations,
                "pattern": pattern,
                "equivalent": len(set(pattern)) == 1,
                "all_future_relevant": all(value["future_relevant"] for value in relations.values()),
            }
        row["HA_HB_patterns_different"] = row["HA"]["pattern"] != row["HB"]["pattern"]
        observations[str(offset)] = row

    positive_offsets = []
    for index, offset in enumerate(OFFSETS):
        if index + 2 >= len(OFFSETS):
            continue
        window = OFFSETS[index:index + 3]
        if all(
            observations[str(moment)]["H0"]["equivalent"]
            and not observations[str(moment)]["HA"]["equivalent"]
            and not observations[str(moment)]["HB"]["equivalent"]
            and observations[str(moment)]["HA_HB_patterns_different"]
            and observations[str(moment)]["HA"]["all_future_relevant"]
            and observations[str(moment)]["HB"]["all_future_relevant"]
            for moment in window
        ):
            positive_offsets.append(offset)

    if positive_offsets:
        status = "HISTORY_SPECIFIC_EQUIVALENCE_BREAKING"
    elif all(observations[str(offset)]["H0"]["equivalent"] for offset in OFFSETS):
        status = "NO_HISTORY_DRIVEN_EQUIVALENCE_BREAKING"
    else:
        status = "OPPORTUNITY_EQUIVALENCE_CONTROL_INVALID"

    np.savez_compressed(BLOCK / "TELEMETRY" / "ING06_EQUIVALENT_OPPORTUNITIES.npz", **telemetry)
    result = nrd05.seal({
        "experiment_id": "ING06_EQUIVALENT_CAUSAL_OPPORTUNITIES",
        "status": status,
        "runtime": runtime,
        "host_stop_tick": 4,
        "main_world_interventions_after_host_stop": 0,
        "observations": observations,
        "persistent_positive_window_starts": positive_offsets,
        "adjudication": {
            "H0_equivalence_control_valid_all_checkpoints": all(observations[str(offset)]["H0"]["equivalent"] for offset in OFFSETS),
            "history_breaks_equivalence": bool(positive_offsets),
            "HA_HB_break_differently": bool(positive_offsets),
            "new_unpreloaded_contingency_demonstrated": False,
            "formal_RW3": False,
            "L4": False
        },
        "interpretation_guard": "All opportunities and history carriers existed at t0. The result concerns native post-stop interaction and cannot by itself establish generation of an unpreloaded contingency.",
        "telemetry": "TELEMETRY/ING06_EQUIVALENT_OPPORTUNITIES.npz"
    })
    nrd05.write_json(BLOCK / "RESULTS" / "ING06_EQUIVALENT_OPPORTUNITIES.json", result)
    print(json.dumps({
        "status": status,
        "positive_window_starts": positive_offsets,
        "H0_equivalent": result["adjudication"]["H0_equivalence_control_valid_all_checkpoints"],
        "HA_pattern": {str(offset): observations[str(offset)]["HA"]["equivalent"] for offset in OFFSETS},
        "HB_pattern": {str(offset): observations[str(offset)]["HB"]["equivalent"] for offset in OFFSETS},
        "HA_HB_different": {str(offset): observations[str(offset)]["HA_HB_patterns_different"] for offset in OFFSETS},
    }, indent=2))


if __name__ == "__main__":
    main()
