# Reproducción

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\11_RAW_ONLY_FRESH_POST_HOST\RUNNERS\run_ing06_raw_only_fresh.py' --threads 1
```

El freeze lock fija configuraciones, historias, ventanas, panel y gate sin `clock_a`. `clock_a` se guarda sólo como telemetría forense.

