# Reproducción

V1, fallo del gate de equivalencia:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\12_CAUSALLY_SENSITIVE_OPPORTUNITIES\RUNNERS\run_ing06_sensitive_opportunities.py' --threads 1
```

V2, corrección causal congelada:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\12_CAUSALLY_SENSITIVE_OPPORTUNITIES\RUNNERS\run_ing06_sensitive_opportunities_v2.py' --threads 1
```

V2 prueba sensibilidad y equivalencia antes de ejecutar historias. Toda estructura existe desde `t0`; después de `t=4` no hay intervención sobre los mundos principales.

