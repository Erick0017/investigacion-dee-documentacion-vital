# Reproducción

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\13_NATIVE_BOUNDARY_TRANSITION\RUNNERS\analyze_ing06_boundary_candidate.py'
```

El análisis consume únicamente la telemetría congelada de la sección 11. No ejecuta el kernel ni modifica mundos.

