#!/usr/bin/env python3
"""Evidence-only gate for a native near-boundary causal configuration."""
from __future__ import annotations
import hashlib, json
from datetime import datetime, timezone
from pathlib import Path
import numpy as np

HERE=Path(__file__).resolve().parent; BLOCK=HERE.parent; ROOT=BLOCK.parent
SOURCE=ROOT/"11_RAW_ONLY_FRESH_POST_HOST"/"TELEMETRY"/"ING06_RAW_ONLY_FRESH.npz"
SOURCE_RESULT=ROOT/"11_RAW_ONLY_FRESH_POST_HOST"/"RESULTS"/"ING06_RAW_ONLY_FRESH.json"
CONFIGS=("MAIN_S0","FRESH_V1","FRESH_V2"); TIMES=(0,16,32,64,128,256,391); HISTORIES=("H0","HA","HB"); HORIZONS=(32,64)

def seal(value):
    value=dict(value); value["created_utc"]=datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00","Z")
    value["content_sha256"]=hashlib.sha256(json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()).hexdigest(); return value

def main():
    z=np.load(SOURCE); source_result=json.loads(SOURCE_RESULT.read_text(encoding="utf-8")); rows=[]; candidates=[]
    for cfg in CONFIGS:
        for t in TIMES:
            for history in HISTORIES:
                for horizon in HORIZONS:
                    c0=z[f"{cfg}_T{t}_{history}_C0_h{horizon}_raw"]
                    c3=z[f"{cfg}_T{t}_{history}_C3_h{horizon}_raw"]
                    c4=z[f"{cfg}_T{t}_{history}_C4_h{horizon}_raw"]
                    row={"configuration":cfg,"offset":t,"history":history,"horizon":horizon,"C0_vs_C3_raw_diff_positions":int(np.count_nonzero(c0!=c3)),"C0_vs_C4_raw_diff_positions":int(np.count_nonzero(c0!=c4))}
                    row["strict_candidate"]=row["C0_vs_C3_raw_diff_positions"]==0 and row["C0_vs_C4_raw_diff_positions"]>0
                    rows.append(row)
                    if row["strict_candidate"]: candidates.append(row)
    stable_h0=[]
    for cfg,case in source_result["cases"].items():
        stable_h0.extend({"configuration":cfg,"before":x["before"],"after":x["after"]} for x in case["intervals"] if not x["main_raw_changed"]["H0"])
    status="NEAR_BOUNDARY_CANDIDATE_FOUND" if candidates else "NO_PREVALIDATED_NEAR_BOUNDARY_CANDIDATE_IN_TESTED_PANEL"
    result=seal({"experiment_id":"ING06_NATIVE_BOUNDARY_DISCOVERY_GATE","status":status,"source_telemetry":str(SOURCE.relative_to(ROOT)).replace("\\","/"),"comparisons":len(rows),"strict_candidates":candidates,"stable_H0_raw_intervals":stable_h0,"rows":rows,"Q_instances_executed":False,"reason":"No strict candidate; stop rule applied without threshold tuning." if not candidates else None,"endogenous_boundary_crossing_demonstrated":False,"fresh_replication":False,"new_unpreloaded_contingency_demonstrated":False,"formal_RW3":False,"L4":False})
    out=BLOCK/"RESULTS"/"ING06_NATIVE_BOUNDARY_DISCOVERY_GATE.json"; out.write_text(json.dumps(result,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding="utf-8")
    print(json.dumps({"status":status,"comparisons":len(rows),"strict_candidates":len(candidates),"stable_H0_raw_intervals":len(stable_h0),"Q_instances_executed":False},indent=2))

if __name__=="__main__": main()
