# Reproducción

Ejecutar con el kernel DEE v27 congelado y un solo thread:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\01_BASELINE_FRESH\RUNNERS\run_ing06_phase6a.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\03_PROGRESSIVE_CAUSAL_LOAD\RUNNERS\run_ing06_progressive_load_s0.py' --threads 1 --config MAIN_S0
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\03_PROGRESSIVE_CAUSAL_LOAD\RUNNERS\run_ing06_progressive_load_s0.py' --threads 1 --config FRESH_V1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\03_PROGRESSIVE_CAUSAL_LOAD\RUNNERS\run_ing06_progressive_load_s0.py' --threads 1 --config FRESH_V2
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\03_PROGRESSIVE_CAUSAL_LOAD\RUNNERS\run_ing06_load16_reuse.py' --threads 1 --config MAIN_S0
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\03_PROGRESSIVE_CAUSAL_LOAD\RUNNERS\run_ing06_load16_reuse.py' --threads 1 --config FRESH_V1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\04_RETENTION_INTERFERENCE\run_ing06_expansion_control.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\09_ENDOGENOUS_FREE_RUN\RUNNERS\run_ing06_endogenous_free_run.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\10_EQUIVALENT_CAUSAL_OPPORTUNITIES\RUNNERS\run_ing06_equivalent_opportunities.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\11_RAW_ONLY_FRESH_POST_HOST\RUNNERS\run_ing06_raw_only_fresh.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\12_CAUSALLY_SENSITIVE_OPPORTUNITIES\RUNNERS\run_ing06_sensitive_opportunities.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\12_CAUSALLY_SENSITIVE_OPPORTUNITIES\RUNNERS\run_ing06_sensitive_opportunities_v2.py' --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\13_NATIVE_BOUNDARY_TRANSITION\RUNNERS\analyze_ing06_boundary_candidate.py'
```

Los freeze locks fijan preguntas, eventos, gates y criterios antes de cada bloque. Las dependencias heredadas de Ingeniería 05 se incluyen en el ZIP oficial bajo `DEPENDENCIES/`.

En los bloques 09 y 10, los mundos principales reciben cero intervenciones después de `HOST_STOP`; los challenges se aplican sólo a clones diagnósticos.
