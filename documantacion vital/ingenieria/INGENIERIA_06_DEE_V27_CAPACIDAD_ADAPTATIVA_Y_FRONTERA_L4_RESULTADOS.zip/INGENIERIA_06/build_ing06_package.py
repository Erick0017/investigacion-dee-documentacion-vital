#!/usr/bin/env python3
"""Build and verify the sole official Ingeniería 06 checkpoint ZIP."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
TESTS = ROOT.parents[2]
ENGINEERING = ROOT.parent
OUT = TESTS / "documantacion vital" / "ingenieria" / "INGENIERIA_06_DEE_V27_CAPACIDAD_ADAPTATIVA_Y_FRONTERA_L4_RESULTADOS.zip"
TMP = OUT.with_suffix(".building.tmp")
MANIFEST = "INGENIERIA_06/MANIFEST/MANIFEST.json"
HASHES = "INGENIERIA_06/HASHES/HASHES.sha256"


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def main():
    protected_prefixes = tuple(
        f"INGENIERIA_06/{index:02d}_" for index in range(1, 11)
    ) + ("INGENIERIA_06/DEPENDENCIES/",)
    protected_parent = {}
    if OUT.is_file():
        with zipfile.ZipFile(OUT, "r") as previous:
            protected_parent = {
                name: sha_bytes(previous.read(name))
                for name in previous.namelist()
                if name.startswith(protected_prefixes)
            }
    excluded = {
        Path("03_PROGRESSIVE_CAUSAL_LOAD/RESULTS/ING06_PROGRESSIVE_CAUSAL_LOAD_S0.json"),
    }
    content = {}
    for source in ROOT.rglob("*"):
        if not source.is_file():
            continue
        relative = source.relative_to(ROOT)
        if relative in excluded or relative.parts[0] in {"MANIFEST", "HASHES"}:
            continue
        if source == TMP or source == OUT:
            continue
        content[f"INGENIERIA_06/{relative.as_posix()}"] = source.read_bytes()

    dependency_map = {
        "INGENIERIA_06/DEPENDENCIES/INGENIERIA_05_HISTORY_SPECIFICITY/RUNNERS/run_nrd06_history_specificity.py": ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS" / "run_nrd06_history_specificity.py",
        "INGENIERIA_06/DEPENDENCIES/05_HISTORY_CONDITIONED_TRANSFORMATION/RUNNERS/run_nrd05_history_conditioned_transformation.py": ENGINEERING / "INGENIERIA_05_HISTORY_CONDITIONED_TRANSFORMATION" / "RUNNERS" / "run_nrd05_history_conditioned_transformation.py",
        "INGENIERIA_06/DEPENDENCIES/04_RAW_CAUSAL_MINIMUM/RUNNERS/run_nrd04_stage_ab.py": ENGINEERING / "INGENIERIA_05_RAW_CAUSAL_MINIMUM" / "RUNNERS" / "run_nrd04_stage_ab.py",
        "INGENIERIA_06/DEPENDENCIES/INGENIERIA_02/RUNNERS/ing02_common.py": ENGINEERING / "INGENIERIA_02" / "RUNNERS" / "ing02_common.py",
        "INGENIERIA_06/DEPENDENCIES/INGENIERIA_02/RUNNERS/temporal_order_apparatus_v1.py": ENGINEERING / "INGENIERIA_02" / "RUNNERS" / "temporal_order_apparatus_v1.py",
        "INGENIERIA_06/DEPENDENCIES/INGENIERIA_02/RUNNERS/run_d09_relative_readout_longevity.py": ENGINEERING / "INGENIERIA_02" / "RUNNERS" / "run_d09_relative_readout_longevity.py",
    }
    missing = [str(path) for path in dependency_map.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)
    for target, source in dependency_map.items():
        content[target] = source.read_bytes()

    required = {
        "INGENIERIA_06/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/REPRODUCTION.md",
        "INGENIERIA_06/CLAIM_LEDGER.json",
        "INGENIERIA_06/01_BASELINE_FRESH/RESULTS/ING06_F3_FRESH.json",
        "INGENIERIA_06/02_ORTHOGONAL_PROBE/RESULTS/ING06_PNEW_C4_HISTORY_SPECIFICITY.json",
        "INGENIERIA_06/03_PROGRESSIVE_CAUSAL_LOAD/RESULTS/ING06_CAUSAL_LOAD_16_REUSE_MAIN_S0.json",
        "INGENIERIA_06/03_PROGRESSIVE_CAUSAL_LOAD/RESULTS/ING06_CAUSAL_LOAD_16_REUSE_FRESH_V1.json",
        "INGENIERIA_06/04_RETENTION_INTERFERENCE/ING06_EXPANSION_CONTROL.json",
        "INGENIERIA_06/08_AUTONOMY_CONDITIONAL/STATUS.json",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/FREEZE/ING06_FREE_RUN_LOCK.json",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/RUNNERS/run_ing06_endogenous_free_run.py",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/RESULTS/ING06_ENDOGENOUS_FREE_RUN.json",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/TELEMETRY/ING06_ENDOGENOUS_FREE_RUN.npz",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/09_ENDOGENOUS_FREE_RUN/REPRODUCTION.md",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/FREEZE/ING06_EQUIVALENT_OPPORTUNITIES_LOCK.json",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/RUNNERS/run_ing06_equivalent_opportunities.py",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/RESULTS/ING06_EQUIVALENT_OPPORTUNITIES.json",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/TELEMETRY/ING06_EQUIVALENT_OPPORTUNITIES.npz",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/10_EQUIVALENT_CAUSAL_OPPORTUNITIES/REPRODUCTION.md",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/FREEZE/ING06_RAW_ONLY_FRESH_LOCK.json",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/RUNNERS/run_ing06_raw_only_fresh.py",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/RESULTS/ING06_RAW_ONLY_FRESH.json",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/TELEMETRY/ING06_RAW_ONLY_FRESH.npz",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/11_RAW_ONLY_FRESH_POST_HOST/REPRODUCTION.md",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/FREEZE/ING06_SENSITIVE_OPPORTUNITIES_LOCK.json",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/FREEZE/ING06_SENSITIVE_OPPORTUNITIES_V2_LOCK.json",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/RUNNERS/run_ing06_sensitive_opportunities.py",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/RUNNERS/run_ing06_sensitive_opportunities_v2.py",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/RESULTS/ING06_SENSITIVE_OPPORTUNITIES.json",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/RESULTS/ING06_SENSITIVE_OPPORTUNITIES_V2.json",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/TELEMETRY/ING06_SENSITIVE_OPPORTUNITIES_V2.npz",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/12_CAUSALLY_SENSITIVE_OPPORTUNITIES/REPRODUCTION.md",
        "INGENIERIA_06/13_NATIVE_BOUNDARY_TRANSITION/FREEZE/ING06_BOUNDARY_DISCOVERY_LOCK.json",
        "INGENIERIA_06/13_NATIVE_BOUNDARY_TRANSITION/RUNNERS/analyze_ing06_boundary_candidate.py",
        "INGENIERIA_06/13_NATIVE_BOUNDARY_TRANSITION/RESULTS/ING06_NATIVE_BOUNDARY_DISCOVERY_GATE.json",
        "INGENIERIA_06/13_NATIVE_BOUNDARY_TRANSITION/SCIENTIFIC_REPORT.md",
        "INGENIERIA_06/13_NATIVE_BOUNDARY_TRANSITION/REPRODUCTION.md",
        "INGENIERIA_06/14_THREE_METHOD_CONVERGENCE/SCIENTIFIC_REPORT.md",
    }
    absent = sorted(required - set(content))
    if absent:
        raise FileNotFoundError(absent)

    parent = TESTS / "documantacion vital" / "ingenieria" / "INGENIERIA_05_DEE_V27_INTEGRADA_RESULTADOS.zip"
    parent_sha = sha_file(parent)
    if parent_sha != "016acdc42f1eb56d292c30b5c7bebe53ea8632b37b4b53c65aa4f2184389e252":
        raise RuntimeError(f"Ingeniería 05 parent changed: {parent_sha}")

    inventory = [
        {"path": name, "size": len(data), "sha256": sha_bytes(data)}
        for name, data in sorted(content.items())
    ]
    manifest = {
        "package": OUT.name,
        "engineering": "INGENIERIA_06_OPEN",
        "scientific_status": "DEE_NATIVE_BOUNDED_RECURRENT_CAUSAL_CAPACITY_WITH_POST_HOST_RAW_DYNAMICS_AND_HISTORY_CONDITIONED_EQUIVALENCE_BREAKING",
        "maximum_independent_causal_load_demonstrated": 17,
        "formal_RW3": False,
        "L4": False,
        "post_host_stop_reachability_change": True,
        "history_conditioned_post_stop_dynamics": True,
        "discrete_endogenous_transition": False,
        "new_unpreloaded_contingency": False,
        "previous_insensitive_opportunities_result": "NO_EQUIVALENCE_BREAK_OBSERVED_WITH_INSENSITIVE_OPPORTUNITY_PANEL",
        "raw_only_fresh_post_host_result": "DEE_NATIVE_HISTORY_CONDITIONED_POST_HOST_RAW_DYNAMICS",
        "causally_sensitive_opportunities_result": "HISTORY_CONDITIONED_EQUIVALENCE_BREAKING",
        "native_boundary_transition_result": "NO_PREVALIDATED_NEAR_BOUNDARY_CANDIDATE_IN_TESTED_PANEL",
        "method_convergence": "A_PLUS_B",
        "kernel_sha256": "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff",
        "parent_ing05_sha256": parent_sha,
        "excluded_superseded_artifacts": [
            "03_PROGRESSIVE_CAUSAL_LOAD/RESULTS/ING06_PROGRESSIVE_CAUSAL_LOAD_S0.json"
        ],
        "members_excluding_manifest_and_hashes": inventory,
    }
    manifest_data = (json.dumps(manifest, indent=2, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
    hashes = "".join(f"{row['sha256']}  {row['path']}\n" for row in inventory)
    hashes += f"{sha_bytes(manifest_data)}  {MANIFEST}\n"

    if TMP.exists():
        TMP.unlink()
    with zipfile.ZipFile(TMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(content.items()):
            archive.writestr(name, data)
        archive.writestr(MANIFEST, manifest_data)
        archive.writestr(HASHES, hashes.encode("utf-8"))

    with zipfile.ZipFile(TMP, "r") as archive:
        bad = archive.testzip()
        if bad is not None:
            raise RuntimeError(f"CRC failure: {bad}")
        names = set(archive.namelist())
        loaded = json.loads(archive.read(MANIFEST))
        for row in loaded["members_excluding_manifest_and_hashes"]:
            if row["path"] not in names or sha_bytes(archive.read(row["path"])) != row["sha256"]:
                raise RuntimeError(f"Internal hash mismatch: {row['path']}")
        expected_hash_lines = {
            line.split("  ", 1)[1]: line.split("  ", 1)[0]
            for line in archive.read(HASHES).decode("utf-8").splitlines()
        }
        for name, expected in expected_hash_lines.items():
            if name not in names or sha_bytes(archive.read(name)) != expected:
                raise RuntimeError(f"HASHES mismatch: {name}")
        for name, expected in protected_parent.items():
            if name not in names or sha_bytes(archive.read(name)) != expected:
                raise RuntimeError(f"Previously delivered stage changed: {name}")
        members = len(archive.infolist())
    TMP.replace(OUT)
    print(json.dumps({
        "path": str(OUT),
        "sha256": sha_file(OUT),
        "size_bytes": OUT.stat().st_size,
        "members": members,
        "crc_ok": True,
        "internal_hashes_ok": True,
        "parent_ing05_unchanged": True,
        "previous_stages_01_10_and_dependencies_byte_preserved": True,
        "engineering_open": True,
        "formal_RW3": False,
        "L4": False,
    }, indent=2))


if __name__ == "__main__":
    main()
