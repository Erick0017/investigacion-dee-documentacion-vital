# Reproducción breve

Desde la raíz lógica del ZIP, con CPython 3.13 y el WHL v27 disponible en las rutas registradas por `config.json`:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002\run_native_consequence_reprogramming.py' --output '.\CONTINUACIONES\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002\analyze_native_consequence_reprogramming.py'
```

El runner comprueba la identidad sellada mediante `pilot_pensamiento01.load_kernel`. Todos los componentes físicos se instalan en `t0`; no existen escrituras del host posteriores.
