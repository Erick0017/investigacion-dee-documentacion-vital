# PENSAMIENTO 01 — Composición nativa del retorno, retención funcional y reutilización del medio

## Pregunta examinada

Se examinó si una consecuencia producida por una interacción DEE podía modificar un linaje funcional móvil, sobrevivir en él y alterar encuentros posteriores del mismo mundo. La lectura no se diseñó como RAM estacionaria: cada consulta transforma el linaje al añadir su propia carga.

## Lo heredado

Se reutilizó la regla sectorial de C7H03: una colisión ordinaria actualiza el `s_reg` de un linaje semántico 1 y una redirección posterior conserva esa actualización durante el transporte. Del acumulativo se heredó también el producto transitorio `23+17=40`; no se reutilizó el antiguo receptor ocupado como memoria.

## Corrección del producto 40 anterior

En el montaje anterior, a `t50`, el producto `s_reg=40`, dirección `(1,1,1)`, estaba junto a un destino ya ocupado (`state=1`, `s_reg=19543`). El reducer direccional sólo se ejecuta para destinos con `estado==0`; por ello el receptor ocupado ejecutó su rama material y no incorporó el producto. En el origen, un único vecino activo produjo `rule_value=0`, y la rama material escribió vacío. A `t51`, los mundos con y sin marcador tenían RAW y clock completos exactamente iguales. Esta descripción identifica extinción del origen, inadmisibilidad del destino y precedencia de rama; no usa “disipación” como explicación suficiente.

## Modificación del aparato

El aparato nuevo es fijo en los seis mundos. En `t5`, cue y teacher producen un linaje `s_reg=4102`, dirección `(0,1,0)`. En `t8`, un suministro `23` y, cuando corresponde, un marcador `17` coinciden en un sitio vacío. El reducer crea físicamente `40` con dirección `(1,-1,0)`. Cuatro ticks después, ese producto coincide con el linaje en el puerto fijo de programación. El host no calcula ni escribe `40`.

Tres consultas fijas se encuentran con el mismo linaje en `t34`, `t46` y `t58`. Entre ellas, portadores de carga cero redirigen el resultado para mantener el linaje dentro del circuito. Todo estaba presente en `t0`; después sólo se llamó al kernel y se realizaron lecturas, hashes y checkpoints.

## Entradas y aportaciones del host

El host preparó la geometría, los portadores iniciales, el suministro `23`, el marcador `17`, dos redirecciones y tres consultas (`7`, `5`, `3`). No leyó una respuesta para elegir otra entrada, no reescribió clocks, no reparó el linaje y no realizó escrituras después de `t0`.

## Ramas nativas que actuaron

- Reducer de vacío, multiplicidad 2: `23+17→40`, dirección por signo de la suma vectorial.
- Reducer de vacío, multiplicidad 2: `4102+40→4142`, dirección `(1,0,0)`.
- Redirección de carga cero: `4142` vuelve a dirección `(0,1,0)`.
- Consultas comunes: `4142+7→4149`, luego `+5→4154` y `+3→4157`.

La carga máxima fue `4157`, por debajo del cap `19664`. No se utilizó protección estacionaria; la cantidad funcional viajó en un linaje semántico 1.

## Mediciones

Se terminaron 6 casos y no quedaron casos parciales. En el tratamiento intacto se midió `40` en `t8`, `4142` en `t12` y `t18`, y respuestas `4149`, `4154`, `4157`. Sin marcador se midió `23`, `4125` y respuestas `4132`, `4137`, `4140`. La diferencia específica del marcador fue `17` en las tres consultas. Entre `t12` y `t58`, el efecto persistió durante 46 ticks y atravesó cinco colisiones posteriores (dos redirecciones y tres consultas).

## Controles

- Marcador fuera de ruta: reprodujo exactamente las tres respuestas sin marcador (`4132`, `4137`, `4140`).
- Enlace de retorno cortado: el producto `40` apareció, pero el puerto fijo conservó `4102`; la primera consulta no encontró el linaje programado.
- Marcador sin suministro: apareció `17` con dirección `(0,-1,0)`, pero no programó el linaje.
- Sin suministro ni marcador: tampoco programó el linaje.
- La geometría de entrenamiento, programación, redirección y consultas fue idéntica en todos los mundos; sólo la ruta causal declarada cambió en su control específico.

## Hipótesis de mecanismo compatibles

Los datos son compatibles con una composición de reducers locales: una consecuencia escalar y direccional producida en una colisión se transporta, se suma a un linaje funcional móvil y permanece como diferencia aditiva durante interacciones posteriores. El control fuera de ruta delimita que la mera presencia del marcador no basta; el corte del enlace delimita que producir `40` tampoco basta si no coincide con el linaje.

## Alcance y aspectos no medidos

Se observaron tres usos posteriores de una modificación retenida, pero las consultas fueron transformativas: cada una añadió carga. No se midió lectura no destructiva, capacidad ilimitada, reparación, actualización negativa, reversión, aprendizaje de una regla, renovación indefinida ni asignación endógena de puertos. El suministro es finito y preinstalado. No se ejecutó la ruta temporal alternativa ni la extensión de péndulo/sensorial porque el núcleo y sus controles ya ocuparon la prioridad experimental.
