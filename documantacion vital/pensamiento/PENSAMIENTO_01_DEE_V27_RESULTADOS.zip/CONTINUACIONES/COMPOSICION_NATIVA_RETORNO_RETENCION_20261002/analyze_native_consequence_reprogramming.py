#!/usr/bin/env python3
"""Reduce the native-return experiment and write descriptive campaign files."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
PRIOR = STAGE / "CONTINUACIONES" / "MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002"
RESULT = HERE / "native_consequence_reprogramming_results.json"
TELEMETRY = HERE / "native_consequence_reprogramming_telemetry.npz"
KERNEL_SOURCE = TESTS / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA" / "dee_kernel_v27.cpp"
C7_RUNNER = TESTS / "DEE_V27_MASTER_REVALIDATION_REBUILD_WORK" / "RUNNERS" / "run_c7h03_reprogrammable_functional_matter.py"
C7_RESULT = TESTS / "zips de experimentos ndocumentados manuales" / "DEE_V27_CORE10_NATIVE_COUPLED_SYSTEMS_MULTISCALE_ECOLOGY_WORK" / "PARENTS" / "CORE07_EXTRACTED" / "RESULTS" / "C7H03_reprogrammable_functional_matter.json"
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def dump(name: str, value: object) -> None:
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def at(case: dict, tick: int) -> dict:
    return next(row for row in case["trace"] if int(row["tick"]) == tick)


def main() -> None:
    result = json.loads(RESULT.read_text(encoding="utf-8"))
    by_id = {case["case_id"]: case for case in result["cases"]}
    intact = by_id["INTACT_MARKER"]
    no_marker = by_id["NO_MARKER"]
    offpath = by_id["MARKER_OFFPATH"]
    cut = by_id["RETURN_LINK_CUT"]

    with np.load(TELEMETRY, allow_pickle=False) as data:
        telemetry_arrays = {name: {"shape": list(data[name].shape), "dtype": str(data[name].dtype)} for name in data.files}
        matched_clock_equal = {
            str(tick): bool(np.array_equal(data[f"INTACT_MARKER__t{tick}__clock"],
                                           data[f"NO_MARKER__t{tick}__clock"]))
            for tick in (12, 58)
        }

    old = json.loads((PRIOR / "native_return_write_results.json").read_text(encoding="utf-8"))
    old_by_id = {case["case_id"]: case for case in old["cases"]}
    old_marker = old_by_id["LOW_STREAM_MARKER"]
    old_nomarker = old_by_id["LOW_STREAM_NO_MARKER"]
    old_50_m = next(row for row in old_marker["trace"] if int(row["tick"]) == 50)
    old_51_m = next(row for row in old_marker["trace"] if int(row["tick"]) == 51)
    old_50_n = next(row for row in old_nomarker["trace"] if int(row["tick"]) == 50)
    old_51_n = next(row for row in old_nomarker["trace"] if int(row["tick"]) == 51)
    with np.load(PRIOR / "native_return_write_telemetry.npz", allow_pickle=False) as data:
        old_clock_equal_51 = bool(np.array_equal(
            data["LOW_STREAM_MARKER__t51__clock"], data["LOW_STREAM_NO_MARKER__t51__clock"]))
        old_raw_equal_51 = bool(np.array_equal(
            data["LOW_STREAM_MARKER__t51__raw"], data["LOW_STREAM_NO_MARKER__t51__raw"]))

    branch_analysis = {
        "prior_product40_observation": {
            "tick_50_with_marker": old_50_m["records"],
            "tick_50_without_marker": old_50_n["records"],
            "tick_51_with_marker": old_51_m["records"],
            "tick_51_without_marker": old_51_n["records"],
            "raw_equal_at_51": old_raw_equal_51,
            "clock_equal_at_51": old_clock_equal_51,
        },
        "kernel_mechanics": {
            "incoming_reducer": "For an empty destination, buscar_fuente_demux counts directional neighbors aimed at it; multiplicity >1 sums s_reg to cap and takes the sign of the component sums (source lines 187-225).",
            "destination_admissibility": "The reducer is called only inside the estado==0 vacuum branch (source lines 297-321). The occupied receiver therefore executes the matter branch instead of admitting the incoming product.",
            "origin_extinction": "At the product origin, one active neighbor gives rho_eff=1*2.5/26, rounded to rule_value=0. The matter branch writes void (source lines 336-347).",
            "observed_precedence": "At t50 the product points to an occupied state-1 receiver with s_reg=19543. At t51 that receiver is unchanged, the origin is empty, and marker/no-marker RAW+clock arrays are exactly equal.",
            "scope": "This is a branch-specific extinction and rejection by an occupied destination, not a statement that every DEE difference dissipates or that many-to-one means inertia.",
        },
        "new_apparatus_correction": {
            "change": "The product is created at an empty site and routed for four ticks to another empty collision destination occupied only by the mobile trained lineage at the arrival tick.",
            "why_before_convergence": "The causal geometry is fixed at t0, before the former one-tick convergence; no later receiver is added.",
        },
    }
    dump("PRIOR_PRODUCT40_BRANCH_ANALYSIS.json", branch_analysis)

    queries_intact = [record["sreg"] for record in intact["measured"]["query_responses"]]
    queries_no_marker = [record["sreg"] for record in no_marker["measured"]["query_responses"]]
    queries_offpath = [record["sreg"] for record in offpath["measured"]["query_responses"]]
    summary = {
        "campaign_id": result["campaign_id"],
        "case_accounting": {"completed": result["completed_case_count"], "partial": result["partial_case_count"]},
        "fixed_apparatus": result["config"]["fixed_apparatus_across_histories"],
        "native_chain": {
            "intact": {
                "t5_trained_sreg": intact["measured"]["trained"]["sreg"],
                "t8_consequence_sreg": intact["measured"]["native_consequence"]["sreg"],
                "t12_programmed_sreg": intact["measured"]["programmed"]["sreg"],
                "t18_redirected_sreg": intact["measured"]["redirected"]["sreg"],
                "query_ticks": result["config"]["ticks"]["queries"],
                "query_response_sreg": queries_intact,
            },
            "no_marker": {
                "t8_supply_sreg": no_marker["measured"]["native_consequence"]["sreg"],
                "t12_programmed_sreg": no_marker["measured"]["programmed"]["sreg"],
                "query_response_sreg": queries_no_marker,
            },
            "marker_specific_difference_at_all_queries": [a - b for a, b in zip(queries_intact, queries_no_marker, strict=True)],
        },
        "controls": {
            "offpath_marker_equals_no_marker_queries": queries_offpath == queries_no_marker,
            "return_link_cut_product_sreg": cut["measured"]["native_consequence"]["sreg"],
            "return_link_cut_program_site_sreg": cut["measured"]["programmed"]["sreg"],
            "return_link_cut_first_query_response": cut["measured"]["query_responses"][0],
            "no_supply_marker_program_site_sreg": by_id["NO_SUPPLY_MARKER"]["measured"]["programmed"]["sreg"],
        },
        "retention_and_use": {
            "retention_window_ticks": 58 - 12,
            "downstream_uses_measured": 3,
            "query_is_transformative": True,
            "indefinite_renewal_measured": False,
            "additional_native_update_after_each_query": list(result["config"]["loads"]["queries"]),
        },
        "clock_control": {
            "intact_vs_no_marker_full_clock_equal": matched_clock_equal,
            "host_clock_writes_after_t0": 0,
            "uniform_clock_advance_not_counted_as_functional_update": True,
        },
        "host_boundary": {
            "all_components_preinstalled_at_t0": True,
            "host_writes_after_t0": 0,
            "host_contributions": ["fixed geometry", "initial carriers", "supply and marker inventory", "three fixed query carriers", "passive measurement"],
            "kernel_contributions": ["23+17 reduction", "transport", "4102+update collision", "redirections", "three query collisions"],
        },
        "telemetry_arrays": telemetry_arrays,
        "scientific_global_verdict_generated": False,
    }
    dump("MEASUREMENT_SUMMARY.json", summary)

    config = {
        "campaign_id": result["campaign_id"],
        "author": "Ivan Erick Tlaltecatl Morales",
        "kernel": result["environment"],
        "parameters": result["config"],
        "cases": [case["spec"] for case in result["cases"]],
        "post_t0_contract": ["tick", "read", "snapshot", "hash", "log", "stop"],
        "route_b_or_c_executed": False,
        "reason_no_extension": "The native nucleus plus its causal controls supplied the requested retained-and-used link; time was reserved for reduction and package validation.",
    }
    dump("continuation_config.json", config)

    refs = {
        "parent_official_zip": {"path": str(OFFICIAL), "sha256_before_update": sha(OFFICIAL)},
        "core07_runner": {"path": str(C7_RUNNER), "sha256": sha(C7_RUNNER)},
        "core07_result": {"path": str(C7_RESULT), "sha256": sha(C7_RESULT)},
        "kernel_source": {"path": str(KERNEL_SOURCE), "sha256": sha(KERNEL_SOURCE), "used_lines": ["187-225", "297-321", "336-347"]},
        "prior_product40_result": {"path_inside_stage": str((PRIOR / "native_return_write_results.json").relative_to(STAGE)), "sha256": sha(PRIOR / "native_return_write_results.json")},
        "current_runner": {"path_inside_stage": str((HERE / "run_native_consequence_reprogramming.py").relative_to(STAGE)), "sha256": sha(HERE / "run_native_consequence_reprogramming.py")},
    }
    dump("SOURCE_REFERENCES.json", refs)

    execution = {
        "runner": "run_native_consequence_reprogramming.py",
        "runner_sha256": refs["current_runner"]["sha256"],
        "elapsed_seconds": result["elapsed_seconds"],
        "completed_cases": result["completed_case_count"],
        "partial_cases": result["partial_case_count"],
        "route_a1_executed": True,
        "route_a2_executed": False,
        "optional_extension_executed": False,
        "post_t0_host_writes": 0,
        "kernel_campaigns_reexecuted": [],
    }
    dump("EXECUTION_LOG.json", execution)

    report = f"""# PENSAMIENTO 01 — Composición nativa del retorno, retención funcional y reutilización del medio

## Pregunta examinada

Se examinó si una consecuencia producida por una interacción DEE podía modificar un linaje funcional móvil, sobrevivir en él y alterar encuentros posteriores del mismo mundo. La lectura no se diseñó como RAM estacionaria: cada consulta transforma el linaje al añadir su propia carga.

## Lo heredado

Se reutilizó la regla sectorial de C7H03: una colisión ordinaria actualiza el `s_reg` de un linaje semántico 1 y una redirección posterior conserva esa actualización durante el transporte. Del acumulativo se heredó también el producto transitorio `23+17=40`; no se reutilizó el antiguo receptor ocupado como memoria.

## Corrección del producto 40 anterior

En el montaje anterior, a `t50`, el producto `s_reg=40`, dirección `(1,1,1)`, estaba junto a un destino ya ocupado (`state=1`, `s_reg=19543`). El reducer direccional sólo se ejecuta para destinos con `estado==0`; por ello el receptor ocupado ejecutó su rama material y no incorporó el producto. En el origen, un único vecino activo produjo `rule_value=0`, y la rama material escribió vacío. A `t51`, los mundos con y sin marcador tenían RAW y clock completos exactamente iguales. Esta descripción identifica extinción del origen, inadmisibilidad del destino y precedencia de rama; no usa “disipación” como explicación suficiente.

## Modificación del aparato

El aparato nuevo es fijo en los seis mundos. En `t5`, cue y teacher producen un linaje `s_reg=4102`, dirección `(0,1,0)`. En `t8`, un suministro `23` y, cuando corresponde, un marcador `17` coinciden en un sitio vacío. El reducer crea físicamente `40` con dirección `(1,-1,0)`. Cuatro ticks después, ese producto coincide con el linaje en el puerto fijo de programación. El host no calcula ni escribe `40`.

Tres consultas fijas se encuentran con el mismo linaje en `t34`, `t46` y `t58`. Entre ellas, portadores de carga cero redirigen el resultado para mantener el linaje dentro del circuito. Todo estaba presente en `t0`; después sólo se llamó al kernel y se realizaron lecturas, hashes y checkpoints.

## Entradas y aportaciones del host

El host preparó la geometría, los portadores iniciales, el suministro `23`, el marcador `17`, dos redirecciones y tres consultas (`7`, `5`, `3`). No leyó una respuesta para elegir otra entrada, no reescribió clocks, no reparó el linaje y no realizó escrituras después de `t0`.

## Ramas nativas que actuaron

- Reducer de vacío, multiplicidad 2: `23+17→40`, dirección por signo de la suma vectorial.
- Reducer de vacío, multiplicidad 2: `4102+40→4142`, dirección `(1,0,0)`.
- Redirección de carga cero: `4142` vuelve a dirección `(0,1,0)`.
- Consultas comunes: `4142+7→4149`, luego `+5→4154` y `+3→4157`.

La carga máxima fue `4157`, por debajo del cap `19664`. No se utilizó protección estacionaria; la cantidad funcional viajó en un linaje semántico 1.

## Mediciones

Se terminaron {result['completed_case_count']} casos y no quedaron casos parciales. En el tratamiento intacto se midió `40` en `t8`, `4142` en `t12` y `t18`, y respuestas `4149`, `4154`, `4157`. Sin marcador se midió `23`, `4125` y respuestas `4132`, `4137`, `4140`. La diferencia específica del marcador fue `17` en las tres consultas. Entre `t12` y `t58`, el efecto persistió durante 46 ticks y atravesó cinco colisiones posteriores (dos redirecciones y tres consultas).

## Controles

- Marcador fuera de ruta: reprodujo exactamente las tres respuestas sin marcador (`4132`, `4137`, `4140`).
- Enlace de retorno cortado: el producto `40` apareció, pero el puerto fijo conservó `4102`; la primera consulta no encontró el linaje programado.
- Marcador sin suministro: apareció `17` con dirección `(0,-1,0)`, pero no programó el linaje.
- Sin suministro ni marcador: tampoco programó el linaje.
- La geometría de entrenamiento, programación, redirección y consultas fue idéntica en todos los mundos; sólo la ruta causal declarada cambió en su control específico.

## Hipótesis de mecanismo compatibles

Los datos son compatibles con una composición de reducers locales: una consecuencia escalar y direccional producida en una colisión se transporta, se suma a un linaje funcional móvil y permanece como diferencia aditiva durante interacciones posteriores. El control fuera de ruta delimita que la mera presencia del marcador no basta; el corte del enlace delimita que producir `40` tampoco basta si no coincide con el linaje.

## Alcance y aspectos no medidos

Se observaron tres usos posteriores de una modificación retenida, pero las consultas fueron transformativas: cada una añadió carga. No se midió lectura no destructiva, capacidad ilimitada, reparación, actualización negativa, reversión, aprendizaje de una regla, renovación indefinida ni asignación endógena de puertos. El suministro es finito y preinstalado. No se ejecutó la ruta temporal alternativa ni la extensión de péndulo/sensorial porque el núcleo y sus controles ya ocuparon la prioridad experimental.
"""
    (HERE / "SCIENTIFIC_REPORT_CONTINUATION.md").write_text(report, encoding="utf-8")

    reproduction = """# Reproducción breve

Desde la raíz lógica del ZIP, con CPython 3.13 y el WHL v27 disponible en las rutas registradas por `config.json`:

```powershell
& 'D:\\Descargas\\ANACONDA MINICONDA\\python.exe' -I -B '.\\CONTINUACIONES\\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002\\run_native_consequence_reprogramming.py' --output '.\\CONTINUACIONES\\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002'
& 'D:\\Descargas\\ANACONDA MINICONDA\\python.exe' -I -B '.\\CONTINUACIONES\\COMPOSICION_NATIVA_RETORNO_RETENCION_20261002\\analyze_native_consequence_reprogramming.py'
```

El runner comprueba la identidad sellada mediante `pilot_pensamiento01.load_kernel`. Todos los componentes físicos se instalan en `t0`; no existen escrituras del host posteriores.
"""
    (HERE / "REPRODUCTION.md").write_text(reproduction, encoding="utf-8")


if __name__ == "__main__":
    main()
