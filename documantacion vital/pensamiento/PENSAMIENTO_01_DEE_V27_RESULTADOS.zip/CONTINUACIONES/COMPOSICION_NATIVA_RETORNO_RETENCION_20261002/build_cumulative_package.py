#!/usr/bin/env python3
"""Validate this continuation and atomically replace the cumulative ZIP."""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
WORK = HERE.parents[2]
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"
TEMP = WORK / "PENSAMIENTO_01_DEE_V27_RESULTADOS.composicion.tmp.zip"
PREFIX = "CONTINUACIONES/COMPOSICION_NATIVA_RETORNO_RETENCION_20261002/"


def sha_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def files(root: Path):
    return sorted((path for path in root.rglob("*") if path.is_file()),
                  key=lambda path: path.relative_to(root).as_posix())


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    parent_sha = sha_file(OFFICIAL)
    allowed_changed = {"CUMULATIVE_INDEX.md", "CUMULATIVE_MANIFEST.json"}
    with zipfile.ZipFile(OFFICIAL, "r") as parent:
        bad = parent.testzip()
        if bad:
            raise RuntimeError(f"parent CRC failed at {bad}")
        parent_names = parent.namelist()
        mismatches = []
        for name in parent_names:
            if name.endswith("/") or name in allowed_changed:
                continue
            staged = STAGE / Path(name)
            if not staged.is_file():
                mismatches.append({"path": name, "reason": "missing"})
            elif sha_bytes(parent.read(name)) != sha_file(staged):
                mismatches.append({"path": name, "reason": "changed"})
        if mismatches:
            raise RuntimeError(f"historical preservation failed: {mismatches[:5]}")
    dump(HERE / "PARENT_PACKAGE_LOCK.json", {
        "parent_official_path": str(OFFICIAL), "parent_sha256": parent_sha,
        "parent_member_count": len(parent_names), "historical_mismatches": [],
        "allowed_updated_root_members": sorted(allowed_changed),
    })

    required_json = (
        "native_consequence_reprogramming_results.json", "MEASUREMENT_SUMMARY.json",
        "PRIOR_PRODUCT40_BRANCH_ANALYSIS.json", "continuation_config.json",
        "SOURCE_REFERENCES.json", "EXECUTION_LOG.json", "PARENT_PACKAGE_LOCK.json",
    )
    required_other = (
        "native_consequence_reprogramming_telemetry.npz",
        "run_native_consequence_reprogramming.py",
        "analyze_native_consequence_reprogramming.py",
        "build_cumulative_package.py", "SCIENTIFIC_REPORT_CONTINUATION.md", "REPRODUCTION.md",
    )
    missing = [name for name in required_json + required_other if not (HERE / name).is_file()]
    if missing:
        raise RuntimeError(f"missing required files: {missing}")
    parsed = {name: json.loads((HERE / name).read_text(encoding="utf-8")) for name in required_json}
    result = parsed["native_consequence_reprogramming_results.json"]
    if result["completed_case_count"] != 6 or result["partial_case_count"] != 0:
        raise RuntimeError("unexpected case accounting")
    by_id = {case["case_id"]: case for case in result["cases"]}
    if [r["sreg"] for r in by_id["INTACT_MARKER"]["measured"]["query_responses"]] != [4149, 4154, 4157]:
        raise RuntimeError("intact query telemetry changed")
    if [r["sreg"] for r in by_id["NO_MARKER"]["measured"]["query_responses"]] != [4132, 4137, 4140]:
        raise RuntimeError("no-marker query telemetry changed")
    with np.load(HERE / "native_consequence_reprogramming_telemetry.npz", allow_pickle=False) as data:
        if sorted(data.files) != sorted([
            f"{case}__t{tick}__{field}"
            for case in ("INTACT_MARKER", "NO_MARKER")
            for tick in (12, 58) for field in ("raw", "clock")
        ]):
            raise RuntimeError("unexpected telemetry members")

    dump(HERE / "PACKAGE_VALIDATION.json", {
        "required_files_present": True, "json_parse_valid": True, "npz_readable": True,
        "historical_members_preserved": True, "completed_cases": 6, "partial_cases": 0,
        "scientific_global_verdict_generated": False, "pensamiento_02_opened": False,
    })

    hash_lines = []
    for path in files(HERE):
        if path.name == "CONTINUATION_HASHES.sha256":
            continue
        hash_lines.append(f"{sha_file(path)}  {path.relative_to(HERE).as_posix()}")
    (HERE / "CONTINUATION_HASHES.sha256").write_text("\n".join(hash_lines) + "\n", encoding="utf-8")

    members = []
    for path in files(STAGE):
        rel = path.relative_to(STAGE).as_posix()
        if rel == "CUMULATIVE_MANIFEST.json":
            continue
        if rel.startswith(PREFIX):
            section = "current_continuation"
        elif rel.startswith("CONTINUACIONES/"):
            section = "prior_continuation"
        else:
            section = "initial_campaign"
        members.append({"path": rel, "size": path.stat().st_size,
                        "sha256": sha_file(path), "section": section})
    dump(STAGE / "CUMULATIVE_MANIFEST.json", {
        "campaign": "PENSAMIENTO_01_DEE_V27", "parent_zip_sha256": parent_sha,
        "continuations": [
            "PAISAJE_REUTILIZABLE_20261001", "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002",
            "MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002",
            "COMPOSICION_NATIVA_RETORNO_RETENCION_20261002",
        ],
        "current_completed_cases": 6, "current_partial_cases": 0,
        "member_hash_scope": "all members except this CUMULATIVE_MANIFEST.json",
        "members": members,
    })

    if TEMP.exists():
        TEMP.unlink()
    with zipfile.ZipFile(TEMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files(STAGE):
            archive.write(path, path.relative_to(STAGE).as_posix())
    expected_names = {path.relative_to(STAGE).as_posix() for path in files(STAGE)}
    with zipfile.ZipFile(TEMP, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"temporary CRC failed at {bad}")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("temporary ZIP member mismatch")
        for line in archive.read(PREFIX + "CONTINUATION_HASHES.sha256").decode("utf-8").splitlines():
            expected_hash, rel = line.split("  ", 1)
            if sha_bytes(archive.read(PREFIX + rel)) != expected_hash:
                raise RuntimeError(f"continuation hash mismatch: {rel}")
        manifest = json.loads(archive.read("CUMULATIVE_MANIFEST.json").decode("utf-8"))
        for entry in manifest["members"]:
            if sha_bytes(archive.read(entry["path"])) != entry["sha256"]:
                raise RuntimeError(f"manifest hash mismatch: {entry['path']}")
    final_sha = sha_file(TEMP)
    os.replace(TEMP, OFFICIAL)
    if sha_file(OFFICIAL) != final_sha:
        raise RuntimeError("official replacement hash mismatch")
    with zipfile.ZipFile(OFFICIAL, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"official CRC failed at {bad}")
    print(json.dumps({
        "official_path": str(OFFICIAL), "sha256": final_sha,
        "members": len(expected_names), "completed": 6, "partial": 0,
        "zip_valid": True, "manifest_valid": True,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
