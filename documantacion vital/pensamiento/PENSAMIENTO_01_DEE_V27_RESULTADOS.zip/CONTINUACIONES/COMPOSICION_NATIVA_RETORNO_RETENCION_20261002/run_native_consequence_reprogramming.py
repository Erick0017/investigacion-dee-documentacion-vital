#!/usr/bin/env python3
"""PENSAMIENTO 01: native consequence -> mobile functional reprogramming.

All carriers are installed at t=0.  Afterwards each world receives only DEE
v27 ticks and passive observations.  A baseline supply (s_reg=23) reaches a
fixed consequence site.  In the intact history a marker (s_reg=17) reaches
the same site, so the symmetric reducer creates s_reg=40 natively.  That
product travels to the already trained C7H03 lineage and updates it.  Three
fixed queries test whether the difference is retained and used again.

The query is explicitly transformating: its own s_reg is added to the mobile
lineage.  This runner therefore does not describe the readout as a stationary
or non-destructive RAM.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
if str(ZIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ZIP_ROOT))

from pilot_pensamiento01 import World, add, load_kernel, pack, place_arrival, read  # noqa: E402

CAMPAIGN_ID = "PENSAMIENTO_01_NATIVE_CONSEQUENCE_REPROGRAMMING_20261002"
N = 127
HORIZON = 60
BASE_OFFSET = 4096
DELTA = 6
TRAINING_X = 13

CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
MEMORY = (0, 1, 0)
PROGRAMMER = (1, -1, 0)
PROGRAMMED = (1, 0, 0)
REDIRECT = (-1, 1, 0)
RESPONSE = (1, 1, 0)
QUERY_REDIRECT = (-1, 0, 0)
MARKER_DIRECTION = (0, -1, 0)

TRAIN_TICK = 5
CONSEQUENCE_TICK = 8
PROGRAM_TICK = 12
REDIRECT_TICK = 18
QUERY_TICKS = (34, 46, 58)
QUERY_LOADS = (7, 5, 3)
QUERY_REDIRECT_TICKS = (38, 50)

SUPPLY_LOAD = 23
MARKER_LOAD = 17
INTACT_PRODUCT_LOAD = SUPPLY_LOAD + MARKER_LOAD
KEY_TICKS = (0, 5, 8, 9, 11, 12, 13, 18, 19, 33, 34, 35, 38, 39, 45, 46, 47, 50, 51, 57, 58, 59, 60)
FULL_CHECKPOINT_CASES = {"INTACT_MARKER", "NO_MARKER"}
FULL_CHECKPOINT_TICKS = {12, 58}

CASES = (
    {"id": "INTACT_MARKER", "supply": True, "marker": "intact", "return_link": "intact"},
    {"id": "NO_MARKER", "supply": True, "marker": "absent", "return_link": "intact"},
    {"id": "MARKER_OFFPATH", "supply": True, "marker": "offpath", "return_link": "intact"},
    {"id": "RETURN_LINK_CUT", "supply": True, "marker": "intact", "return_link": "parallel_cut"},
    {"id": "NO_SUPPLY_MARKER", "supply": False, "marker": "intact", "return_link": "intact"},
    {"id": "NO_SUPPLY_NO_MARKER", "supply": False, "marker": "absent", "return_link": "intact"},
)


def sha256_array(value: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(value).tobytes()).hexdigest()


def json_dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def sign_composition(*vectors: tuple[int, int, int]) -> tuple[int, int, int]:
    sums = [sum(v[i] for v in vectors) for i in range(3)]
    return tuple(1 if x > 0 else (-1 if x < 0 else 0) for x in sums)


def put(raw, clock, q, state, sreg, direction, semantic=1, phase=0, label=""):
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap at {q}: {label}; existing={read(raw, q)}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def place(raw, clock, target, tick, direction, state, sreg, label):
    return place_arrival(raw, clock, target, tick, direction, state, sreg, 1, label)


def local_records(raw: np.ndarray, center, radius=1):
    rows = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = ((center[0] + dx) % N, (center[1] + dy) % N, (center[2] + dz) % N)
                rec = read(raw, q)
                if rec is not None:
                    rows.append({"offset": [dx, dy, dz], "site": list(q), **rec})
    return rows


def build_world(kernel, spec):
    raw = np.zeros((N, N, N), dtype=np.uint64)
    clock = np.zeros_like(raw)
    junction = (63, 63, 63)
    program_site = add(junction, MEMORY, PROGRAM_TICK - TRAIN_TICK, N)
    consequence_site = add(program_site, PROGRAMMER, -(PROGRAM_TICK - CONSEQUENCE_TICK), N)
    if spec["return_link"] == "parallel_cut":
        consequence_site = ((consequence_site[0]) % N, consequence_site[1] % N, (consequence_site[2] + 2) % N)
    redirect_site = add(program_site, PROGRAMMED, REDIRECT_TICK - PROGRAM_TICK, N)
    receiver1 = add(redirect_site, MEMORY, QUERY_TICKS[0] - REDIRECT_TICK, N)
    qredir1 = add(receiver1, RESPONSE, QUERY_REDIRECT_TICKS[0] - QUERY_TICKS[0], N)
    receiver2 = add(qredir1, MEMORY, QUERY_TICKS[1] - QUERY_REDIRECT_TICKS[0], N)
    qredir2 = add(receiver2, RESPONSE, QUERY_REDIRECT_TICKS[1] - QUERY_TICKS[1], N)
    receiver3 = add(qredir2, MEMORY, QUERY_TICKS[2] - QUERY_REDIRECT_TICKS[1], N)

    sources = {}
    sources["training_cue"] = place(raw, clock, junction, TRAIN_TICK, CUE, 81001,
                                    BASE_OFFSET - TRAINING_X, "training_cue")
    sources["training_teacher"] = place(raw, clock, junction, TRAIN_TICK, TEACHER, 81002,
                                        TRAINING_X + DELTA, "training_teacher")
    if spec["supply"]:
        sources["supply"] = place(raw, clock, consequence_site, CONSEQUENCE_TICK,
                                  PROGRAMMER, 81003, SUPPLY_LOAD, "baseline_supply")
    marker_target = consequence_site
    if spec["marker"] == "offpath":
        marker_target = (consequence_site[0], consequence_site[1], (consequence_site[2] + 1) % N)
    if spec["marker"] != "absent":
        sources["marker"] = place(raw, clock, marker_target, CONSEQUENCE_TICK,
                                  MARKER_DIRECTION, 81004, MARKER_LOAD, "history_marker")

    sources["program_redirect"] = place(raw, clock, redirect_site, REDIRECT_TICK,
                                        REDIRECT, 81005, 0, "program_redirect")
    query_receivers = (receiver1, receiver2, receiver3)
    for index, (target, tick, load) in enumerate(zip(query_receivers, QUERY_TICKS, QUERY_LOADS, strict=True), start=1):
        sources[f"query_{index}"] = place(raw, clock, target, tick, CUE,
                                          81100 + index, load, f"query_{index}")
    for index, (target, tick) in enumerate(zip((qredir1, qredir2), QUERY_REDIRECT_TICKS, strict=True), start=1):
        sources[f"query_redirect_{index}"] = place(raw, clock, target, tick, QUERY_REDIRECT,
                                                   81200 + index, 0, f"query_redirect_{index}")

    geometry = {
        "junction": list(junction),
        "consequence_site": list(consequence_site),
        "fixed_program_site": list(program_site),
        "program_redirect_site": list(redirect_site),
        "query_receivers": [list(q) for q in query_receivers],
        "query_redirect_sites": [list(qredir1), list(qredir2)],
        "sources": {k: list(v) for k, v in sources.items()},
        "marker_target": list(marker_target),
    }
    return World(kernel, raw, clock), geometry


def expected_lineage_loads(spec):
    if spec["return_link"] != "intact":
        update = None
    elif spec["supply"]:
        update = SUPPLY_LOAD + (MARKER_LOAD if spec["marker"] == "intact" else 0)
    else:
        update = None
    if update is None:
        return {"native_update": None, "programmed": None, "queries": [None, None, None]}
    programmed = BASE_OFFSET + DELTA + update
    cumulative = programmed
    queries = []
    for q in QUERY_LOADS:
        cumulative += q
        queries.append(cumulative)
    return {"native_update": update, "programmed": programmed, "queries": queries}


def run_case(kernel, spec, telemetry):
    world, geometry = build_world(kernel, spec)
    points = {
        "junction": tuple(geometry["junction"]),
        "consequence": tuple(geometry["consequence_site"]),
        "program": tuple(geometry["fixed_program_site"]),
        "program_redirect": tuple(geometry["program_redirect_site"]),
        "query1": tuple(geometry["query_receivers"][0]),
        "query_redirect1": tuple(geometry["query_redirect_sites"][0]),
        "query2": tuple(geometry["query_receivers"][1]),
        "query_redirect2": tuple(geometry["query_redirect_sites"][1]),
        "query3": tuple(geometry["query_receivers"][2]),
    }
    trace = []
    events = []
    for tick in range(HORIZON + 1):
        if tick in KEY_TICKS:
            trace.append({
                "tick": tick,
                "records": {name: read(world.raw_a, q) for name, q in points.items()},
                "local": {
                    "consequence": local_records(world.raw_a, points["consequence"], 1),
                    "program": local_records(world.raw_a, points["program"], 1),
                } if tick in {CONSEQUENCE_TICK, PROGRAM_TICK} else None,
                "raw_support": int(np.count_nonzero(world.raw_a)),
                "buffer_hashes": {
                    "raw_a": sha256_array(world.raw_a), "raw_b": sha256_array(world.raw_b),
                    "clock_a": sha256_array(world.clock_a), "clock_b": sha256_array(world.clock_b),
                },
            })
        if spec["id"] in FULL_CHECKPOINT_CASES and tick in FULL_CHECKPOINT_TICKS:
            telemetry[f"{spec['id']}__t{tick}__raw"] = world.raw_a.copy()
            telemetry[f"{spec['id']}__t{tick}__clock"] = world.clock_a.copy()
        if tick == HORIZON:
            break
        info = world.tick()
        if any(int(info.get(name, 0)) for name in ("colisiones", "overflows", "genesis")):
            events.append({"tick": tick + 1, **info})
    by_tick = {row["tick"]: row for row in trace}
    measured = {
        "trained": by_tick[TRAIN_TICK]["records"]["junction"],
        "native_consequence": by_tick[CONSEQUENCE_TICK]["records"]["consequence"],
        "programmed": by_tick[PROGRAM_TICK]["records"]["program"],
        "redirected": by_tick[REDIRECT_TICK]["records"]["program_redirect"],
        "query_responses": [by_tick[t]["records"][f"query{i}"] for i, t in enumerate(QUERY_TICKS, start=1)],
    }
    return {
        "case_id": spec["id"], "spec": spec, "geometry": geometry,
        "expected": expected_lineage_loads(spec), "measured": measured,
        "trace": trace, "kernel_events": events, "completed": True,
        "host_writes_after_t0": 0,
        "post_t0_contract": ["tick", "read", "snapshot", "hash", "log", "stop"],
    }


def raw_effect(telemetry, left, right, tick):
    a = telemetry[f"{left}__t{tick}__raw"]
    b = telemetry[f"{right}__t{tick}__raw"]
    return {
        "raw_diff_positions": int(np.count_nonzero(a != b)),
        "raw_xor_sha256": sha256_array(np.bitwise_xor(a, b)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    kernel, environment = load_kernel()
    telemetry = {}
    cases = [run_case(kernel, spec, telemetry) for spec in CASES]
    by_id = {case["case_id"]: case for case in cases}

    fixed_geometry_keys = ("junction", "fixed_program_site", "program_redirect_site", "query_receivers", "query_redirect_sites")
    reference_geometry = by_id["INTACT_MARKER"]["geometry"]
    fixed_geometry_equal = {
        case_id: all(case["geometry"][key] == reference_geometry[key] for key in fixed_geometry_keys)
        for case_id, case in by_id.items()
    }
    comparisons = {
        "intact_minus_no_marker": {
            "native_update_difference": MARKER_LOAD,
            "query_response_sreg_differences": [
                by_id["INTACT_MARKER"]["measured"]["query_responses"][i]["sreg"]
                - by_id["NO_MARKER"]["measured"]["query_responses"][i]["sreg"]
                for i in range(3)
            ],
            "checkpoint_effects": {str(t): raw_effect(telemetry, "INTACT_MARKER", "NO_MARKER", t)
                                   for t in sorted(FULL_CHECKPOINT_TICKS)},
        },
        "offpath_marker_vs_no_marker": {
            "query_response_pairs": [
                [by_id["MARKER_OFFPATH"]["measured"]["query_responses"][i],
                 by_id["NO_MARKER"]["measured"]["query_responses"][i]]
                for i in range(3)
            ]
        },
        "return_link_cut": by_id["RETURN_LINK_CUT"]["measured"],
        "supply_controls": {
            "marker_without_supply": by_id["NO_SUPPLY_MARKER"]["measured"],
            "neither": by_id["NO_SUPPLY_NO_MARKER"]["measured"],
        },
    }
    branch_derivation = {
        "training": {
            "incoming": [list(CUE), list(TEACHER)],
            "direction": list(sign_composition(CUE, TEACHER)),
            "sreg": BASE_OFFSET + DELTA,
        },
        "native_consequence_intact": {
            "incoming": [list(PROGRAMMER), list(MARKER_DIRECTION)],
            "direction": list(sign_composition(PROGRAMMER, MARKER_DIRECTION)),
            "sreg": INTACT_PRODUCT_LOAD,
            "multiplicity": 2,
        },
        "programming_intact": {
            "incoming": [list(MEMORY), list(PROGRAMMER)],
            "direction": list(sign_composition(MEMORY, PROGRAMMER)),
            "sreg": BASE_OFFSET + DELTA + INTACT_PRODUCT_LOAD,
            "multiplicity": 2,
        },
        "first_query_intact": {
            "incoming": [list(MEMORY), list(CUE)],
            "direction": list(sign_composition(MEMORY, CUE)),
            "sreg": BASE_OFFSET + DELTA + INTACT_PRODUCT_LOAD + QUERY_LOADS[0],
            "multiplicity": 2,
        },
        "guards": {
            "all_planned_destinations_empty_before_arrival": True,
            "all_sreg_sums_below_19664": True,
            "semantic": 1,
            "phase_role": "C7H03 established raw clock as nuisance in this apparatus; clocks advance natively and are not rewritten after t0.",
            "protection": "No stationary protected cell is claimed; the functional quantity is carried by a mobile semantic-1 lineage.",
            "saturation": "Maximum planned s_reg is 4157, below cap 19664.",
        },
    }
    payload = {
        "campaign_id": CAMPAIGN_ID,
        "question": "Can a native 23+17 consequence reprogram a mobile functional lineage, survive, and alter three later fixed queries in the same world?",
        "environment": environment,
        "config": {
            "N": N, "horizon": HORIZON, "base_offset": BASE_OFFSET, "delta": DELTA,
            "training_x": TRAINING_X, "ticks": {
                "train": TRAIN_TICK, "consequence": CONSEQUENCE_TICK,
                "program": PROGRAM_TICK, "redirect": REDIRECT_TICK,
                "queries": list(QUERY_TICKS), "query_redirects": list(QUERY_REDIRECT_TICKS),
            },
            "loads": {"supply": SUPPLY_LOAD, "marker": MARKER_LOAD,
                      "intact_native_product": INTACT_PRODUCT_LOAD, "queries": list(QUERY_LOADS)},
            "fixed_apparatus_across_histories": fixed_geometry_equal,
        },
        "branch_derivation": branch_derivation,
        "cases": cases,
        "comparisons": comparisons,
        "measurement_semantics": {
            "retention": "mobile s_reg difference from program tick 12 through later collisions",
            "use": "same fixed query encounters at ticks 34, 46, 58",
            "readout": "transformative; each query adds its s_reg and is not a non-destructive RAM read",
            "recurrence_scope": "three downstream uses of one retained modification; no claim of indefinite renewal",
        },
        "completed_case_count": len(cases), "partial_case_count": 0,
        "elapsed_seconds": time.monotonic() - started,
    }
    json_dump(args.output / "native_consequence_reprogramming_results.json", payload)
    np.savez_compressed(args.output / "native_consequence_reprogramming_telemetry.npz", **telemetry)
    print(json.dumps({
        "completed": len(cases), "partial": 0,
        "fixed_geometry_equal": fixed_geometry_equal,
        "intact": by_id["INTACT_MARKER"]["measured"],
        "no_marker": by_id["NO_MARKER"]["measured"],
        "elapsed_seconds": payload["elapsed_seconds"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
