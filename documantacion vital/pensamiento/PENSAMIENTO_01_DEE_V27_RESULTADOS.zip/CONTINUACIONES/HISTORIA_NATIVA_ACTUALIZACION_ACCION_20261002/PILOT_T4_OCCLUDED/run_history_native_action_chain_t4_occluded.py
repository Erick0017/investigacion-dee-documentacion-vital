#!/usr/bin/env python3
"""Temporal history -> native consequence -> U1 -> response -> U2/U3.

The AB/BA/H0 apparatus and every supply/query carrier are installed at t=0.
Afterwards the main worlds receive only official DEE v27 ticks and passive
reads/checkpoints.  Results are saved after every case.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMON = ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
for path in (ROOT, COMMON):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import World, build_history_arrays, load_kernel  # noqa: E402
from pilot_pensamiento01 import add, pack, place_arrival, read  # noqa: E402

CAMPAIGN_ID = "PENSAMIENTO_01_HISTORY_NATIVE_UPDATE_ACTION_20261002"
N = 127
ORIGIN = (30, 30, 30)
HORIZON = 60
BASE_OFFSET = 4096
DELTA = 6
TRAINING_X = 13

CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
MEMORY = (0, 1, 0)
PROGRAMMER = (1, -1, 0)
PROGRAMMED = (1, 0, 0)
PROGRAM_REDIRECT = (-1, 1, 0)
RESPONSE = (1, 1, 0)
ACTION_DIRECTION = (-1, 0, 0)

TRAIN_TICK = 5
HISTORY_OUTPUT_TICK = 3
CONSEQUENCE_TICK = 4
RETURN_CUT_TICK = 6
PROGRAM_TICK = 12
PROGRAM_REDIRECT_TICK = 18
QUERY_TICKS = (34, 46, 58)
QUERY_LOADS = (7, 5, 3)
ACTION_TICKS = (38, 50)
ACTION_LOADS = (11, 13)
RESOURCE_LOADS = (8, 9)
RESOURCE_DIRECTIONS = ((0, -1, 1), (0, -1, -1))

KEY_TICKS = (0, 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 18, 19, 33, 34, 35, 37, 38, 39, 45, 46, 47, 49, 50, 51, 57, 58, 59, 60)
FULL_CHECKPOINT_TICKS = (4, 12, 38, 58)

CASES = (
    {"id": "HA_INTACT", "history": "HA", "return": "intact", "action1": "intact", "action2": "intact"},
    {"id": "HB_INTACT", "history": "HB", "return": "intact", "action1": "intact", "action2": "intact"},
    {"id": "H0_INTACT", "history": "H0", "return": "intact", "action1": "intact", "action2": "intact"},
    {"id": "HA_RETURN_CUT", "history": "HA", "return": "cut", "action1": "intact", "action2": "intact"},
    {"id": "HA_RETURN_SHAM", "history": "HA", "return": "sham", "action1": "intact", "action2": "intact"},
    {"id": "HA_ACTION1_CUT", "history": "HA", "return": "intact", "action1": "cut", "action2": "intact"},
    {"id": "HA_ACTION1_SHAM", "history": "HA", "return": "intact", "action1": "sham", "action2": "intact"},
    {"id": "HA_ACTION2_CUT", "history": "HA", "return": "intact", "action1": "intact", "action2": "cut"},
)


def sha_array(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def put(raw, clock, q, state, sreg, direction, label):
    if int(raw[q]) != 0:
        raise RuntimeError(f"initial overlap {label} at {q}: {read(raw, q)}")
    raw[q] = pack(state, sreg, direction, 1)
    clock[q] = np.uint64(0)


def place(raw, clock, target, tick, direction, state, sreg, label):
    return place_arrival(raw, clock, target, tick, direction, state, sreg, 1, label)


def sign_comp(*vectors):
    sums = [sum(v[i] for v in vectors) for i in range(3)]
    return [1 if value > 0 else (-1 if value < 0 else 0) for value in sums]


def build_world(kernel, spec):
    raw, clock, history_ports = build_history_arrays(N, ORIGIN, spec["history"])
    comparator = tuple(history_ports["comparator"])
    consequence_site = add(comparator, (1, 1, 0), 1, N)
    program_site = add(consequence_site, PROGRAMMER, PROGRAM_TICK - CONSEQUENCE_TICK, N)
    junction = add(program_site, MEMORY, -(PROGRAM_TICK - TRAIN_TICK), N)
    program_redirect = add(program_site, PROGRAMMED, PROGRAM_REDIRECT_TICK - PROGRAM_TICK, N)
    receiver1 = add(program_redirect, MEMORY, QUERY_TICKS[0] - PROGRAM_REDIRECT_TICK, N)
    action1 = add(receiver1, RESPONSE, ACTION_TICKS[0] - QUERY_TICKS[0], N)
    receiver2 = add(action1, MEMORY, QUERY_TICKS[1] - ACTION_TICKS[0], N)
    action2 = add(receiver2, RESPONSE, ACTION_TICKS[1] - QUERY_TICKS[1], N)
    receiver3 = add(action2, MEMORY, QUERY_TICKS[2] - ACTION_TICKS[1], N)

    sources = {}
    for index, (load, direction) in enumerate(zip(RESOURCE_LOADS, RESOURCE_DIRECTIONS, strict=True), start=1):
        sources[f"common_history_resource_{index}"] = place(
            raw, clock, consequence_site, CONSEQUENCE_TICK, direction,
            82000 + index, load, f"common_history_resource_{index}")

    sources["training_cue"] = place(raw, clock, junction, TRAIN_TICK, CUE, 82101,
                                    BASE_OFFSET - TRAINING_X, "training_cue")
    sources["training_teacher"] = place(raw, clock, junction, TRAIN_TICK, TEACHER, 82102,
                                        TRAINING_X + DELTA, "training_teacher")
    sources["program_redirect"] = place(raw, clock, program_redirect, PROGRAM_REDIRECT_TICK,
                                        PROGRAM_REDIRECT, 82103, 0, "program_redirect")

    query_receivers = (receiver1, receiver2, receiver3)
    for index, (target, tick, load) in enumerate(zip(query_receivers, QUERY_TICKS, QUERY_LOADS, strict=True), start=1):
        sources[f"query_{index}"] = place(raw, clock, target, tick, CUE,
                                          82200 + index, load, f"query_{index}")

    action_sites = (action1, action2)
    for index, (target, tick, load, mode) in enumerate(zip(
            action_sites, ACTION_TICKS, ACTION_LOADS, (spec["action1"], spec["action2"]), strict=True), start=1):
        if mode == "cut":
            continue
        actual_target = target if mode == "intact" else (target[0], target[1], (target[2] + 2) % N)
        sources[f"action_resource_{index}"] = place(raw, clock, actual_target, tick,
                                                    ACTION_DIRECTION, 82300 + index, load,
                                                    f"action_resource_{index}_{mode}")

    return_deflector_site = add(consequence_site, PROGRAMMER, RETURN_CUT_TICK - CONSEQUENCE_TICK, N)
    if spec["return"] in {"cut", "sham"}:
        actual_target = return_deflector_site
        if spec["return"] == "sham":
            actual_target = (actual_target[0], actual_target[1], (actual_target[2] + 2) % N)
        sources["return_deflector"] = place(raw, clock, actual_target, RETURN_CUT_TICK,
                                             (0, 0, 1), 82401, 0, f"return_{spec['return']}")

    geometry = {
        "history_ports": {k: list(v) if isinstance(v, tuple) else [list(q) for q in v] if isinstance(v, list) else v for k, v in history_ports.items()},
        "history_comparator": list(comparator), "consequence_site": list(consequence_site),
        "junction": list(junction), "program_site": list(program_site),
        "program_redirect": list(program_redirect),
        "query_receivers": [list(q) for q in query_receivers],
        "action_sites": [list(q) for q in action_sites],
        "return_deflector_site": list(return_deflector_site),
        "sources": {key: list(value) for key, value in sources.items()},
    }
    return World(kernel, raw, clock), geometry


def local_records(raw, center, radius=1):
    records = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = ((center[0] + dx) % N, (center[1] + dy) % N, (center[2] + dz) % N)
                record = read(raw, q)
                if record is not None:
                    records.append({"offset": [dx, dy, dz], "site": list(q), **record})
    return records


def run_case(kernel, spec, output_dir: Path):
    started = time.monotonic()
    world, geometry = build_world(kernel, spec)
    points = {
        "history_reader": (ORIGIN[0], ORIGIN[1] - 1, ORIGIN[2]),
        "history_comparator": tuple(geometry["history_comparator"]),
        "consequence": tuple(geometry["consequence_site"]),
        "return_deflector": tuple(geometry["return_deflector_site"]),
        "training": tuple(geometry["junction"]),
        "program": tuple(geometry["program_site"]),
        "program_redirect": tuple(geometry["program_redirect"]),
        "response1": tuple(geometry["query_receivers"][0]),
        "update2": tuple(geometry["action_sites"][0]),
        "response2": tuple(geometry["query_receivers"][1]),
        "update3": tuple(geometry["action_sites"][1]),
        "response3": tuple(geometry["query_receivers"][2]),
    }
    trace = []
    checkpoints = {}
    kernel_events = []
    for tick in range(HORIZON + 1):
        if tick in KEY_TICKS:
            trace.append({
                "tick": tick,
                "records": {name: read(world.raw_a, q) for name, q in points.items()},
                "critical_neighborhood": local_records(world.raw_a, points["consequence"], 1)
                    if tick == CONSEQUENCE_TICK else None,
                "raw_support": int(np.count_nonzero(world.raw_a)),
                "raw_sha256": sha_array(world.raw_a),
                "clock_sha256": sha_array(world.clock_a),
            })
        if tick in FULL_CHECKPOINT_TICKS:
            checkpoints[f"t{tick}_raw"] = world.raw_a.copy()
            checkpoints[f"t{tick}_clock"] = world.clock_a.copy()
        if tick == HORIZON:
            break
        info = world.tick()
        if any(int(info.get(name, 0)) for name in ("colisiones", "overflows", "genesis")):
            kernel_events.append({"tick": tick + 1, **info})
    indexed = {row["tick"]: row for row in trace}
    measured = {
        "history_reader_t2": indexed[2]["records"]["history_reader"],
        "history_output_t3": indexed[3]["records"]["history_comparator"],
        "consequence_t4": indexed[4]["records"]["consequence"],
        "trained_t5": indexed[5]["records"]["training"],
        "return_t6": indexed[6]["records"]["return_deflector"],
        "U1_t12": indexed[12]["records"]["program"],
        "redirected_t18": indexed[18]["records"]["program_redirect"],
        "response1_t34": indexed[34]["records"]["response1"],
        "U2_t38": indexed[38]["records"]["update2"],
        "response2_t46": indexed[46]["records"]["response2"],
        "U3_t50": indexed[50]["records"]["update3"],
        "response3_t58": indexed[58]["records"]["response3"],
    }
    case = {
        "case_id": spec["id"], "spec": spec, "geometry": geometry,
        "measured": measured, "trace": trace, "kernel_events": kernel_events,
        "completed": True, "post_t0_host_writes": 0,
        "elapsed_simulation_seconds": time.monotonic() - started,
    }
    case_dir = output_dir / "CASES"
    case_dir.mkdir(parents=True, exist_ok=True)
    dump(case_dir / f"{spec['id']}.json", case)
    np.savez_compressed(case_dir / f"{spec['id']}.npz", **checkpoints)
    return case


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    total_started = time.monotonic()
    kernel, environment = load_kernel()
    canary_raw = np.zeros((5, 5, 5), np.uint64)
    canary = World(kernel, canary_raw, canary_raw.copy()).tick()
    cases = []
    progress = args.output / "case_progress.jsonl"
    progress.write_text("", encoding="utf-8")
    for spec in CASES:
        case = run_case(kernel, spec, args.output)
        cases.append(case)
        with progress.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"case_id": spec["id"], "completed": True,
                                     "elapsed_simulation_seconds": case["elapsed_simulation_seconds"]}) + "\n")
            stream.flush()
    by_id = {case["case_id"]: case for case in cases}
    fixed_keys = ("history_comparator", "consequence_site", "junction", "program_site",
                  "program_redirect", "query_receivers", "action_sites")
    reference = by_id["HA_INTACT"]["geometry"]
    fixed_apparatus = {case_id: all(case["geometry"][key] == reference[key] for key in fixed_keys)
                       for case_id, case in by_id.items()}
    comparisons = {
        "history": {case_id: by_id[case_id]["measured"] for case_id in ("HA_INTACT", "HB_INTACT", "H0_INTACT")},
        "return_mediation": {case_id: by_id[case_id]["measured"] for case_id in ("HA_INTACT", "HA_RETURN_CUT", "HA_RETURN_SHAM")},
        "action1_mediation": {case_id: by_id[case_id]["measured"] for case_id in ("HA_INTACT", "HA_ACTION1_CUT", "HA_ACTION1_SHAM")},
        "action2_mediation": {case_id: by_id[case_id]["measured"] for case_id in ("HA_INTACT", "HA_ACTION2_CUT")},
    }
    result = {
        "campaign_id": CAMPAIGN_ID, "environment": environment,
        "operational_canary": canary,
        "config": {
            "N": N, "origin": ORIGIN, "horizon": HORIZON,
            "history_output_tick": HISTORY_OUTPUT_TICK, "consequence_tick": CONSEQUENCE_TICK,
            "train_tick": TRAIN_TICK, "program_tick": PROGRAM_TICK,
            "query_ticks": QUERY_TICKS, "action_ticks": ACTION_TICKS,
            "resource_loads": RESOURCE_LOADS, "query_loads": QUERY_LOADS,
            "action_loads": ACTION_LOADS, "fixed_apparatus": fixed_apparatus,
            "post_t0_contract": ["tick", "read", "checkpoint", "hash", "log", "stop"],
        },
        "branch_predictions": {
            "HA_t4": {"sreg": 24, "direction": sign_comp((1, 1, 0), *RESOURCE_DIRECTIONS), "multiplicity": 3},
            "H0_HB_t4": {"sreg": 17, "direction": sign_comp(*RESOURCE_DIRECTIONS), "multiplicity": 2},
            "HA_U1": 4126, "HA_response1": 4133, "HA_U2": 4144,
            "HA_response2": 4149, "HA_U3": 4162, "HA_response3": 4165,
            "max_sreg": 4165, "cap": 19664,
        },
        "cases": cases, "comparisons": comparisons,
        "completed_case_count": len(cases), "partial_case_count": 0,
        "simulation_seconds": sum(case["elapsed_simulation_seconds"] for case in cases),
        "runner_wall_seconds": time.monotonic() - total_started,
    }
    dump(args.output / "history_native_action_results.json", result)
    print(json.dumps({"completed": len(cases), "partial": 0,
                      "simulation_seconds": result["simulation_seconds"],
                      "wall_seconds": result["runner_wall_seconds"],
                      "HA": by_id["HA_INTACT"]["measured"]}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
