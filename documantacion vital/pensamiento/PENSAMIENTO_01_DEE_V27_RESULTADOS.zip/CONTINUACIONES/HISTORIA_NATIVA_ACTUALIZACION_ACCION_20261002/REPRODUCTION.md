# Reproducción breve

Con CPython 3.13 y el WHL v27 registrado en `continuation_config.json`, desde la raíz lógica del ZIP:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\run_history_native_action_chain.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\run_bounded_programmable_input.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\analyze_history_native_action.py'
```

Los pilotos están preservados con el runner exacto que produjo cada resultado. El runner final guarda cada caso JSON/NPZ antes de continuar con el siguiente.
