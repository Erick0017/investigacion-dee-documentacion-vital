#!/usr/bin/env python3
"""Reduce the native-history/action continuation without scientific adjudication."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path


HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"
RESULT = HERE / "history_native_action_results.json"
INPUT_RESULT = HERE / "bounded_programmable_input_results.json"


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(name: str, value: object) -> None:
    (HERE / name).write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sreg(case: dict, key: str):
    record = case["measured"].get(key)
    return None if record is None else int(record["sreg"])


def direction(case: dict, key: str):
    record = case["measured"].get(key)
    return None if record is None else record["direction"]


def main() -> None:
    analysis_started = time.monotonic()
    result = load(RESULT)
    input_result = load(INPUT_RESULT)
    by_id = {case["case_id"]: case for case in result["cases"]}
    input_by_id = {case["case_id"]: case for case in input_result["cases"]}

    pilot_specs = [
        ("PILOT_T4_OCCLUDED/history_native_action_results_t4_occluded.json", "semantic-4 support occupied the t4 destination"),
        ("PILOT_QUERY_OCCLUDED/history_native_action_results_query_occluded.json", "the x-axis query crossed the retained history landscape"),
        ("PILOT_ACTION_CONTROL_IMPL/history_native_action_results_action_control_impl.json", "the first action sham moved the resource rather than controlling response deflection"),
    ]
    pilots = []
    simulation_seconds = float(result["simulation_seconds"]) + float(input_result["elapsed_seconds"])
    completed = int(result["completed_case_count"]) + int(input_result["completed_case_count"])
    partial = int(result["partial_case_count"]) + int(input_result["partial_case_count"])
    for rel, observation in pilot_specs:
        data = load(HERE / rel)
        pilots.append({
            "file": rel,
            "completed_cases": int(data["completed_case_count"]),
            "partial_cases": int(data["partial_case_count"]),
            "simulation_seconds": float(data["simulation_seconds"]),
            "mechanical_observation": observation,
        })
        completed += int(data["completed_case_count"])
        partial += int(data["partial_case_count"])
        simulation_seconds += float(data["simulation_seconds"])
    exploration = load(HERE / "fixed_history_interface_exploration.json")
    completed += int(exploration["completed_cases"])
    partial += int(exploration["partial_cases"])

    intact = by_id["HA_INTACT"]
    history_rows = {}
    for case_id in ("H0_INTACT", "HA_INTACT", "HB_INTACT"):
        case = by_id[case_id]
        history_rows[case_id] = {
            "reader_t2": {"sreg": sreg(case, "history_reader_t2"), "direction": direction(case, "history_reader_t2")},
            "output_t3": {"sreg": sreg(case, "history_output_t3"), "direction": direction(case, "history_output_t3")},
            "consequence_t6": {"sreg": sreg(case, "consequence_t6"), "direction": direction(case, "consequence_t6")},
            "U1_t12": sreg(case, "U1_t12"),
            "response1_t34": sreg(case, "response1_t34"),
            "U2_t38": sreg(case, "U2_t38"),
            "response2_t46": sreg(case, "response2_t46"),
            "U3_t50": sreg(case, "U3_t50"),
            "response3_t58": sreg(case, "response3_t58"),
        }

    controls = {}
    for case_id in ("HA_RETURN_CUT", "HA_RETURN_SHAM", "HA_ACTION1_CUT", "HA_ACTION1_SHAM", "HA_ACTION2_CUT"):
        case = by_id[case_id]
        controls[case_id] = {
            "consequence_t6": sreg(case, "consequence_t6"),
            "U1_t12": sreg(case, "U1_t12"),
            "response1_t34": sreg(case, "response1_t34"),
            "U2_t38": sreg(case, "U2_t38"),
            "response2_t46": sreg(case, "response2_t46"),
            "U3_t50": sreg(case, "U3_t50"),
            "response3_t58": sreg(case, "response3_t58"),
            "post_t0_host_writes": int(case["post_t0_host_writes"]),
        }

    external = {}
    for case_id, case in input_by_id.items():
        measured = case["measured"].get("response_t34")
        external[case_id] = {
            "input_load": case["external_load"],
            "input_present": case["external_load"] is not None,
            "expected_response_sreg": case["expected_response_sreg"],
            "measured_response_sreg": None if measured is None else int(measured["sreg"]),
            "measured_direction": None if measured is None else measured["direction"],
            "post_t0_host_writes": int(case["post_t0_host_writes"]),
        }

    summary = {
        "campaign": "PENSAMIENTO_01_DEE_V27",
        "continuation": "HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002",
        "case_accounting": {
            "completed_total": completed,
            "partial_total": partial,
            "exploratory_fixed_history": int(exploration["completed_cases"]),
            "motivated_pilots": sum(p["completed_cases"] for p in pilots),
            "final_native_chain_and_controls": int(result["completed_case_count"]),
            "bounded_external_input": int(input_result["completed_case_count"]),
        },
        "history_fixed_apparatus": history_rows,
        "native_chain_HA": {
            "history_output_t3": intact["measured"]["history_output_t3"],
            "history_conditioned_consequence_t6": intact["measured"]["consequence_t6"],
            "U1_t12": intact["measured"]["U1_t12"],
            "response1_t34": intact["measured"]["response1_t34"],
            "U2_t38": intact["measured"]["U2_t38"],
            "response2_t46": intact["measured"]["response2_t46"],
            "U3_t50": intact["measured"]["U3_t50"],
            "response3_t58": intact["measured"]["response3_t58"],
            "retained_updates": 3,
            "subsequent_uses": 3,
            "updates_caused_after_the_initial_history_link": 2,
        },
        "causal_controls": controls,
        "external_input_arm": {
            "contract": input_result["config"]["input_contract"],
            "cases": external,
            "tested_load_interval": [0, 127],
            "query_load": int(input_result["config"]["query_load"]),
            "zero_and_absence_distinguished": external["LOAD_0"]["measured_response_sreg"] == 4113 and external["ABSENT"]["measured_response_sreg"] is None,
            "all_present_load_predictions_matched": all(
                row["expected_response_sreg"] == row["measured_response_sreg"]
                for row in external.values() if row["input_present"]
            ),
            "streaming_input_tested": False,
        },
        "pilot_observations": pilots,
        "host_boundary": {
            "all_main_components_present_at_t0": True,
            "post_t0_host_writes_main_worlds": 0,
            "host_prepared": ["history events", "common resources", "C7H03 lineage apparatus", "fixed queries", "fixed zero-load deflectors in controls"],
            "kernel_produced": ["history-dependent direction", "consequence 24", "U1=4126", "responses and U2/U3 collisions"],
        },
        "timing": {
            "kernel_simulation_seconds_recorded": simulation_seconds,
            "exploration_simulation_seconds": "NOT_RECORDED_SEPARATELY",
            "analysis_seconds": None,
        },
        "scientific_global_verdict_generated": False,
    }
    summary["timing"]["analysis_seconds"] = time.monotonic() - analysis_started
    dump("MEASUREMENT_SUMMARY.json", summary)

    config = {
        "campaign": summary["campaign"],
        "continuation": summary["continuation"],
        "author": "Ivan Erick Tlaltecatl Morales",
        "environment": result["environment"],
        "main_config": result["config"],
        "main_case_specs": [case["spec"] for case in result["cases"]],
        "external_input_config": input_result["config"],
        "external_case_specs": [
            {"case_id": case["case_id"], "external_load": case["external_load"]}
            for case in input_result["cases"]
        ],
        "post_t0_contract": ["tick", "read", "checkpoint", "hash", "log", "stop"],
        "kernel_modified": False,
        "pensamiento_02_opened": False,
    }
    dump("continuation_config.json", config)

    references = []
    candidates = [
        STAGE / "CONTINUACIONES" / "COMPOSICION_NATIVA_RETORNO_RETENCION_20261002" / "run_native_consequence_reprogramming.py",
        STAGE / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001" / "run_transported_sreg_receiver.py",
        STAGE / "CONTINUACIONES" / "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002" / "run_native_return_stream.py",
        STAGE / "CONTINUACIONES" / "MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002" / "run_native_memory_corrected_clock.py",
        TESTS / "DEE_V27_MASTER_REVALIDATION_REBUILD_WORK" / "RUNNERS" / "run_c7h03_reprogrammable_functional_matter.py",
        HERE / "run_history_native_action_chain.py",
        HERE / "run_bounded_programmable_input.py",
    ]
    for path in candidates:
        if path.is_file():
            references.append({"path": str(path), "sha256": sha(path)})
    dump("SOURCE_REFERENCES.json", {
        "parent_official_zip": {"path": str(OFFICIAL), "sha256_before_update": sha(OFFICIAL)},
        "sources": references,
    })

    dump("EXECUTION_LOG.json", {
        "completed_cases": completed,
        "partial_cases": partial,
        "recorded_kernel_simulation_seconds": simulation_seconds,
        "exploration_runtime": "NOT_RECORDED_SEPARATELY",
        "analysis_seconds": summary["timing"]["analysis_seconds"],
        "packaging_seconds": "TO_BE_RECORDED_BY_PACKAGER",
        "main_world_post_t0_host_writes": 0,
        "pilots_preserved": [p["file"] for p in pilots],
    })

    report = f"""# PENSAMIENTO 01 — Historia nativa, actualización funcional y nueva acción

## Pregunta examinada

Se examinó si una historia AB/BA, recibida por un aparato fijo, podía producir una consecuencia nativa que actualizara un linaje funcional y si las respuestas posteriores de ese linaje podían causar nuevas actualizaciones en el mismo mundo. En un brazo separado se caracterizó una entrada externa acotada del mismo tipo de puente.

## Preparación e intervenciones

Los mundos H0, HA=AB y HB=BA compartieron receptor, recursos, C7H03, consultas, reloj inicial y geometría. Los eventos de historia y todos los recursos estaban instalados en `t0`. No hubo escrituras del host después de `t0`. AB y BA usan el mismo multiconjunto, pero el montaje no controla separadamente el último evento; por ello la comparación informa sensibilidad a la historia ordenada del aparato, no una atribución exclusiva a sintaxis de orden superior.

## Historia y consecuencia nativa

En `t2`, el lector común produjo `s_reg=7` con direcciones H0 `(0,-1,0)`, HA `(1,-1,0)` y HB `(-1,-1,0)`. En `t3`, el comparador común mantuvo `s_reg=7` y produjo H0 `(0,1,0)`, HA `(1,1,0)` y HB `(-1,1,0)`. Dos recursos comunes, cargas 8 y 9, hicieron que HA formara en `t6` un producto `s_reg=24`, dirección `(1,-1,0)`. H0 y HB dejaron `s_reg=17`, dirección `(0,-1,0)`, que no retornó al puerto funcional.

## Actualización, uso y retorno

El linaje C7H03 común tenía `s_reg=4102` en `t5`. Sólo en HA intacto, el producto 24 llegó al puerto común y produjo U1=`4126` en `t12`. Una consulta común de carga 7 produjo respuesta1=`4133` en `t34`. Esa respuesta coincidió con un recurso común 11 y produjo U2=`4144` en `t38`. La siguiente consulta 5 produjo `4149` en `t46`; su encuentro con el recurso 13 produjo U3=`4162` en `t50`; la consulta final 3 produjo `4165` en `t58`.

Así se midieron tres estados funcionales actualizados (U1/U2/U3), tres usos posteriores y dos actualizaciones posteriores causadas por una respuesta anterior. Las consultas y recursos fueron prefijados: la trayectoria no generó el inventario, pero el kernel determinó si y cómo participaban.

## Controles causales

- H0 y HB conservaron `4102` en U1; sus consultas/resources aparecieron aislados (`7/11/5/13/3`) en los sitios de lectura.
- El corte de retorno conservó el producto 24, lo desvió en `t8` y dejó U1=`4102`; el sham fuera de ruta reprodujo la cadena intacta.
- El corte de acción1 conservó U1=`4126` y respuesta1=`4133`, pero dejó únicamente el recurso 11 en U2; su sham preservó U2=`4144` y toda la continuación.
- El corte de acción2 conservó U2=`4144` y respuesta2=`4149`, pero dejó únicamente el recurso 13 en U3.

Los recursos comunes permanecieron presentes en cortes y shams. Los deflectores tenían carga cero y actuaron sobre la ruta de respuesta o en una ubicación de control comparable.

## Pilotos preservados

El primer piloto intentó usar el producto en `t4`, pero su destino contenía soporte histórico `semantic=4`. El segundo permitió llegar a U1, pero la consulta por el eje x cruzó el paisaje histórico y no alcanzó el receptor. El tercero mostró que mover el recurso del sham no era un control comparable. Los tres se conservan con runners, trazas y checkpoints; motivaron, respectivamente, esperar hasta `t6`, mover sólo la consulta al eje z y mantener el recurso común mientras se desvía la respuesta.

## Entrada programable externa acotada

En un aparato fijo independiente se ensayaron ausencia y cargas 0, 1, 7, 17 y 127, con consulta reservada 11. Ausencia no produjo respuesta en el receptor. La carga cero sí habilitó la ruta y produjo 4113, distinguiéndose físicamente de ausencia. Las demás respuestas fueron 4114, 4120, 4130 y 4240. Coincidieron con `4096+6+entrada+11` en todos los casos presentes. No hubo saturación en 0–127 ni escrituras post-`t0`.

Este brazo caracteriza una preparación inicial programable; no ejecutó streaming durante la evolución, control arbitrario ni una interfaz comercial.

## Alcance y alternativas compatibles

Los datos son compatibles con composición local de reducers direccionales y adición de `s_reg` en un linaje móvil. El efecto histórico requiere también la geometría/ruta: HA alcanzó el recurso y el puente; H0/HB no. El aparato no separa por sí solo una explicación de “orden” de todas las variables de último evento/fase, ni muestra generación endógena de los recursos. No se midieron lectura no destructiva, capacidad ilimitada, reposición material, generalización a otra geometría, clocks como memoria ni una alternativa temporal independiente.

## Contabilidad

Se terminaron {completed} casos y quedaron {partial} parciales: 3 de exploración, 24 en tres pilotos mecánicos preservados, 8 en la cadena final/control y 6 en entrada externa. El tiempo de kernel registrado, sin incluir el breve exploratorio cuyo runtime no se guardó por separado, fue {simulation_seconds:.3f} s.

No se generó una adjudicación científica global.
"""
    (HERE / "SCIENTIFIC_REPORT_CONTINUATION.md").write_text(report, encoding="utf-8")

    reproduction = r"""# Reproducción breve

Con CPython 3.13 y el WHL v27 registrado en `continuation_config.json`, desde la raíz lógica del ZIP:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\run_history_native_action_chain.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\run_bounded_programmable_input.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002\analyze_history_native_action.py'
```

Los pilotos están preservados con el runner exacto que produjo cada resultado. El runner final guarda cada caso JSON/NPZ antes de continuar con el siguiente.
"""
    (HERE / "REPRODUCTION.md").write_text(reproduction, encoding="utf-8")

    index = STAGE / "CUMULATIVE_INDEX.md"
    marker = "HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002"
    text = index.read_text(encoding="utf-8")
    if marker not in text:
        text += (
            "\n- `CONTINUACIONES/HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002/` contiene "
            "la interfaz histórica fija H0/AB/BA, la cadena U1→respuesta1→U2→respuesta2→U3, "
            "sus cortes/shams, tres pilotos mecánicos preservados y el brazo acotado de entrada externa.\n"
            f"- Esta continuación añade {completed} casos terminados y {partial} parciales. No abre PENSAMIENTO 02.\n"
        )
        index.write_text(text, encoding="utf-8")

    print(json.dumps({
        "completed": completed,
        "partial": partial,
        "simulation_seconds_recorded": simulation_seconds,
        "analysis_seconds": summary["timing"]["analysis_seconds"],
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
