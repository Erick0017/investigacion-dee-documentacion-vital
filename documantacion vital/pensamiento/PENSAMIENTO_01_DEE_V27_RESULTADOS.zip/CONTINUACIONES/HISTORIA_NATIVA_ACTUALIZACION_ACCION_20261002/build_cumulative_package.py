#!/usr/bin/env python3
"""Validate, build, and atomically install the cumulative PENSAMIENTO 01 ZIP."""
from __future__ import annotations

import hashlib
import json
import os
import time
import zipfile
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
WORK = HERE.parents[2]
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"
TEMP = WORK / "PENSAMIENTO_01_DEE_V27_RESULTADOS.historia-accion.tmp.zip"
PREFIX = "CONTINUACIONES/HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002/"


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def files(root: Path):
    return sorted(
        (path for path in root.rglob("*") if path.is_file()),
        key=lambda path: path.relative_to(root).as_posix(),
    )


def dump(path: Path, value: object) -> None:
    path.write_text(
        json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def measured(case: dict, key: str):
    record = case["measured"].get(key)
    return None if record is None else int(record["sreg"])


def main() -> None:
    package_started = time.monotonic()
    parent_sha = sha_file(OFFICIAL)
    allowed_changed = {"CUMULATIVE_INDEX.md", "CUMULATIVE_MANIFEST.json"}
    with zipfile.ZipFile(OFFICIAL, "r") as parent:
        bad = parent.testzip()
        if bad:
            raise RuntimeError(f"parent CRC failed at {bad}")
        parent_names = parent.namelist()
        historical_mismatches = []
        for name in parent_names:
            if name.endswith("/") or name in allowed_changed:
                continue
            staged = STAGE / Path(name)
            if not staged.is_file():
                historical_mismatches.append({"path": name, "reason": "missing"})
            elif sha_bytes(parent.read(name)) != sha_file(staged):
                historical_mismatches.append({"path": name, "reason": "changed"})
        if historical_mismatches:
            raise RuntimeError(f"historical preservation failed: {historical_mismatches[:5]}")

    dump(HERE / "PARENT_PACKAGE_LOCK.json", {
        "parent_official_path": str(OFFICIAL),
        "parent_sha256": parent_sha,
        "parent_member_count": len(parent_names),
        "historical_mismatches": [],
        "allowed_updated_root_members": sorted(allowed_changed),
    })

    required = (
        "run_history_native_action_chain.py",
        "run_bounded_programmable_input.py",
        "analyze_history_native_action.py",
        "build_cumulative_package.py",
        "PREREGISTERED_PREDICTIONS.json",
        "history_native_action_results.json",
        "bounded_programmable_input_results.json",
        "fixed_history_interface_exploration.json",
        "MEASUREMENT_SUMMARY.json",
        "continuation_config.json",
        "SOURCE_REFERENCES.json",
        "EXECUTION_LOG.json",
        "SCIENTIFIC_REPORT_CONTINUATION.md",
        "REPRODUCTION.md",
        "PARENT_PACKAGE_LOCK.json",
    )
    missing = [name for name in required if not (HERE / name).is_file()]
    if missing:
        raise RuntimeError(f"missing required continuation files: {missing}")

    # Parse every current JSON/JSONL and open every NPZ before packaging.
    json_count = 0
    jsonl_count = 0
    npz_count = 0
    for path in files(HERE):
        if path.suffix.lower() == ".json":
            load(path)
            json_count += 1
        elif path.suffix.lower() == ".jsonl":
            for line in path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    json.loads(line)
            jsonl_count += 1
        elif path.suffix.lower() == ".npz":
            with np.load(path, allow_pickle=False) as data:
                for name in data.files:
                    _ = data[name].shape
            npz_count += 1

    result = load(HERE / "history_native_action_results.json")
    input_result = load(HERE / "bounded_programmable_input_results.json")
    summary = load(HERE / "MEASUREMENT_SUMMARY.json")
    by_id = {case["case_id"]: case for case in result["cases"]}
    expected_intact = {
        "consequence_t6": 24, "U1_t12": 4126, "response1_t34": 4133,
        "U2_t38": 4144, "response2_t46": 4149,
        "U3_t50": 4162, "response3_t58": 4165,
    }
    if any(measured(by_id["HA_INTACT"], key) != value for key, value in expected_intact.items()):
        raise RuntimeError("HA intact telemetry does not match recorded chain")
    if measured(by_id["HA_RETURN_CUT"], "U1_t12") != 4102:
        raise RuntimeError("return-cut telemetry changed")
    if measured(by_id["HA_ACTION1_CUT"], "response1_t34") != 4133 or measured(by_id["HA_ACTION1_CUT"], "U2_t38") != 11:
        raise RuntimeError("action1 mediation telemetry changed")
    if measured(by_id["HA_ACTION1_SHAM"], "U2_t38") != 4144:
        raise RuntimeError("action1 sham telemetry changed")
    if measured(by_id["HA_ACTION2_CUT"], "response2_t46") != 4149 or measured(by_id["HA_ACTION2_CUT"], "U3_t50") != 13:
        raise RuntimeError("action2 mediation telemetry changed")
    if any(int(case["post_t0_host_writes"]) != 0 for case in result["cases"] + input_result["cases"]):
        raise RuntimeError("post-t0 host-write contract violated")
    external = {case["case_id"]: case for case in input_result["cases"]}
    expected_external = {"ABSENT": None, "LOAD_0": 4113, "LOAD_1": 4114, "LOAD_7": 4120, "LOAD_17": 4130, "LOAD_127": 4240}
    for case_id, expected in expected_external.items():
        actual = measured(external[case_id], "response_t34")
        if actual != expected:
            raise RuntimeError(f"external input telemetry changed: {case_id} {actual} != {expected}")
    if summary["case_accounting"]["completed_total"] != 41 or summary["case_accounting"]["partial_total"] != 0:
        raise RuntimeError("unexpected case accounting")

    execution = load(HERE / "EXECUTION_LOG.json")
    execution["packaging_precompression_seconds"] = time.monotonic() - package_started
    execution["continuation_elapsed_wall_seconds_before_final_compression"] = max(0.0, time.time() - WORK.stat().st_ctime)
    execution["total_time_scope"] = "file-observed continuation span through precompression; final ZIP compression/atomic replace follows"
    dump(HERE / "EXECUTION_LOG.json", execution)

    dump(HERE / "PACKAGE_VALIDATION.json", {
        "required_files_present": True,
        "json_files_parsed": json_count,
        "jsonl_files_parsed": jsonl_count,
        "npz_files_opened": npz_count,
        "historical_parent_members_preserved": True,
        "scientific_measurement_checks": True,
        "main_world_post_t0_host_writes": 0,
        "completed_cases": 41,
        "partial_cases": 0,
        "scientific_global_verdict_generated": False,
        "pensamiento_02_opened": False,
        "zip_crc_and_manifest_validation": "performed by this packager before atomic replacement",
    })

    hash_lines = []
    for path in files(HERE):
        if path.name == "CONTINUATION_HASHES.sha256":
            continue
        hash_lines.append(f"{sha_file(path)}  {path.relative_to(HERE).as_posix()}")
    (HERE / "CONTINUATION_HASHES.sha256").write_text("\n".join(hash_lines) + "\n", encoding="utf-8")

    manifest_members = []
    for path in files(STAGE):
        rel = path.relative_to(STAGE).as_posix()
        if rel == "CUMULATIVE_MANIFEST.json":
            continue
        section = "current_continuation" if rel.startswith(PREFIX) else (
            "prior_continuation" if rel.startswith("CONTINUACIONES/") else "initial_campaign"
        )
        manifest_members.append({
            "path": rel,
            "size": path.stat().st_size,
            "sha256": sha_file(path),
            "section": section,
        })
    dump(STAGE / "CUMULATIVE_MANIFEST.json", {
        "campaign": "PENSAMIENTO_01_DEE_V27",
        "parent_zip_sha256": parent_sha,
        "continuations": [
            "PAISAJE_REUTILIZABLE_20261001",
            "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002",
            "MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002",
            "COMPOSICION_NATIVA_RETORNO_RETENCION_20261002",
            "HISTORIA_NATIVA_ACTUALIZACION_ACCION_20261002",
        ],
        "current_completed_cases": 41,
        "current_partial_cases": 0,
        "member_hash_scope": "all members except this CUMULATIVE_MANIFEST.json",
        "members": manifest_members,
    })

    if TEMP.exists():
        TEMP.unlink()
    with zipfile.ZipFile(TEMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files(STAGE):
            archive.write(path, path.relative_to(STAGE).as_posix())

    expected_names = {path.relative_to(STAGE).as_posix() for path in files(STAGE)}
    with zipfile.ZipFile(TEMP, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"temporary ZIP CRC failed at {bad}")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("temporary ZIP member mismatch")
        for line in archive.read(PREFIX + "CONTINUATION_HASHES.sha256").decode("utf-8").splitlines():
            expected_hash, rel = line.split("  ", 1)
            if sha_bytes(archive.read(PREFIX + rel)) != expected_hash:
                raise RuntimeError(f"continuation hash mismatch: {rel}")
        manifest = json.loads(archive.read("CUMULATIVE_MANIFEST.json").decode("utf-8"))
        for entry in manifest["members"]:
            if sha_bytes(archive.read(entry["path"])) != entry["sha256"]:
                raise RuntimeError(f"manifest hash mismatch: {entry['path']}")

    final_sha = sha_file(TEMP)
    os.replace(TEMP, OFFICIAL)
    if sha_file(OFFICIAL) != final_sha:
        raise RuntimeError("official replacement hash mismatch")
    with zipfile.ZipFile(OFFICIAL, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"official ZIP CRC failed at {bad}")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("official ZIP member mismatch")

    print(json.dumps({
        "official_path": str(OFFICIAL),
        "sha256": final_sha,
        "members": len(expected_names),
        "completed": 41,
        "partial": 0,
        "zip_valid": True,
        "manifest_valid": True,
        "parent_members_preserved": True,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
