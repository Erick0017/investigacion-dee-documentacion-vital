#!/usr/bin/env python3
"""Directed pilot: locate fixed local HA/HB/H0 consequences."""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
COMMON = ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
for path in (ROOT, COMMON):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import World, build_history_arrays, load_kernel  # noqa: E402
from pilot_pensamiento01 import read  # noqa: E402

N = 73
ORIGIN = (36, 36, 36)
HORIZON = 24


def roi_points(radius=5):
    out = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                out.append(((ORIGIN[0] + dx) % N, (ORIGIN[1] + dy) % N, (ORIGIN[2] + dz) % N))
    return out


def main():
    kernel, environment = load_kernel()
    worlds = {}
    ports = None
    for history in ("H0", "HA", "HB"):
        raw, clock, this_ports = build_history_arrays(N, ORIGIN, history)
        worlds[history] = World(kernel, raw, clock)
        ports = this_ports
    points = roi_points()
    timeline = []
    for tick in range(HORIZON + 1):
        rows = []
        for q in points:
            records = {history: read(worlds[history].raw_a, q) for history in worlds}
            raws = {history: int(worlds[history].raw_a[q]) for history in worlds}
            if len(set(raws.values())) > 1:
                rows.append({"site": list(q), "offset": [q[i] - ORIGIN[i] for i in range(3)],
                             "records": records})
        timeline.append({"tick": tick, "different_sites": rows})
        if tick < HORIZON:
            for world in worlds.values():
                world.tick()
    output = {"environment": environment, "N": N, "origin": ORIGIN,
              "ports": {k: list(v) if isinstance(v, tuple) else v for k, v in ports.items()},
              "timeline": timeline, "completed_cases": 3, "partial_cases": 0}
    (HERE / "fixed_history_interface_exploration.json").write_text(
        json.dumps(output, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    compact = [{"tick": row["tick"], "n": len(row["different_sites"]),
                "sample": row["different_sites"][:8]} for row in timeline]
    print(json.dumps(compact, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
