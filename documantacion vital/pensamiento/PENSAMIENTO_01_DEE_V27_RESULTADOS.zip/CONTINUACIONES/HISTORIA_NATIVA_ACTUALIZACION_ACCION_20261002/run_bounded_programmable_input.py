#!/usr/bin/env python3
"""Bounded external-input characterization of the fixed C7H03 bridge."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from pilot_pensamiento01 import World, add, load_kernel, place_arrival, read  # noqa: E402

CAMPAIGN_ID = "PENSAMIENTO_01_BOUNDED_PROGRAMMABLE_INPUT_20261002"
N = 83
BASE = 4096
DELTA = 6
X = 13
CUE = (1, 0, 0)
TEACHER = (-1, 1, 0)
MEMORY = (0, 1, 0)
PROGRAMMER = (1, -1, 0)
PROGRAMMED = (1, 0, 0)
REDIRECT = (-1, 1, 0)
TRAIN_TICK = 5
PROGRAM_TICK = 12
REDIRECT_TICK = 18
QUERY_TICK = 34
QUERY_LOAD = 11
LOADS = (None, 0, 1, 7, 17, 127)


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def place(raw, clock, target, tick, direction, state, sreg, label):
    return place_arrival(raw, clock, target, tick, direction, state, sreg, 1, label)


def build(kernel, load):
    raw = np.zeros((N, N, N), np.uint64)
    clock = np.zeros_like(raw)
    junction = (41, 41, 41)
    program = add(junction, MEMORY, PROGRAM_TICK - TRAIN_TICK, N)
    redirect = add(program, PROGRAMMED, REDIRECT_TICK - PROGRAM_TICK, N)
    receiver = add(redirect, MEMORY, QUERY_TICK - REDIRECT_TICK, N)
    sources = {
        "cue": place(raw, clock, junction, TRAIN_TICK, CUE, 83001, BASE - X, "cue"),
        "teacher": place(raw, clock, junction, TRAIN_TICK, TEACHER, 83002, X + DELTA, "teacher"),
        "redirect": place(raw, clock, redirect, REDIRECT_TICK, REDIRECT, 83003, 0, "redirect"),
        "query": place(raw, clock, receiver, QUERY_TICK, CUE, 83004, QUERY_LOAD, "query"),
    }
    if load is not None:
        sources["external_programmer"] = place(raw, clock, program, PROGRAM_TICK,
                                                PROGRAMMER, 83005, int(load), "external_programmer")
    geometry = {"junction": list(junction), "program": list(program),
                "redirect": list(redirect), "receiver": list(receiver),
                "sources": {key: list(value) for key, value in sources.items()}}
    return World(kernel, raw, clock), geometry


def run_case(kernel, load, output):
    world, geometry = build(kernel, load)
    points = {key: tuple(geometry[key]) for key in ("junction", "program", "redirect", "receiver")}
    trace = []
    snapshots = {}
    for tick in range(QUERY_TICK + 1):
        if tick in (0, 5, 12, 18, 34):
            trace.append({"tick": tick, "records": {key: read(world.raw_a, site) for key, site in points.items()},
                          "raw_support": int(np.count_nonzero(world.raw_a))})
        if tick in (12, 34):
            snapshots[f"t{tick}_raw"] = world.raw_a.copy()
            snapshots[f"t{tick}_clock"] = world.clock_a.copy()
        if tick < QUERY_TICK:
            world.tick()
    by_tick = {row["tick"]: row for row in trace}
    expected = None if load is None else BASE + DELTA + int(load) + QUERY_LOAD
    case_id = "ABSENT" if load is None else f"LOAD_{load}"
    case = {
        "case_id": case_id, "external_load": load, "geometry": geometry,
        "expected_response_sreg": expected,
        "measured": {
            "trained_t5": by_tick[5]["records"]["junction"],
            "program_t12": by_tick[12]["records"]["program"],
            "redirect_t18": by_tick[18]["records"]["redirect"],
            "response_t34": by_tick[34]["records"]["receiver"],
        },
        "trace": trace, "post_t0_host_writes": 0, "completed": True,
    }
    cases_dir = output / "INPUT_CASES"; cases_dir.mkdir(parents=True, exist_ok=True)
    dump(cases_dir / f"{case_id}.json", case)
    np.savez_compressed(cases_dir / f"{case_id}.npz", **snapshots)
    return case


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); kernel, environment = load_kernel()
    cases = []
    progress = args.output / "input_case_progress.jsonl"; progress.write_text("", encoding="utf-8")
    for load in LOADS:
        case = run_case(kernel, load, args.output); cases.append(case)
        with progress.open("a", encoding="utf-8") as stream:
            stream.write(json.dumps({"case_id": case["case_id"], "completed": True}) + "\n")
            stream.flush()
    by_id = {case["case_id"]: case for case in cases}
    measurements = {
        case["case_id"]: {
            "expected": case["expected_response_sreg"],
            "measured": None if case["measured"]["response_t34"] is None
                        else case["measured"]["response_t34"]["sreg"],
            "direction": None if case["measured"]["response_t34"] is None
                          else case["measured"]["response_t34"]["direction"],
        } for case in cases
    }
    result = {
        "campaign_id": CAMPAIGN_ID, "environment": environment,
        "config": {"N": N, "loads": LOADS, "query_load": QUERY_LOAD,
                   "fixed_geometry": all(case["geometry"][key] == cases[0]["geometry"][key]
                                         for case in cases for key in ("junction", "program", "redirect", "receiver")),
                   "input_contract": "all inputs preinstalled at t0; no streaming claim",
                   "post_t0_host_writes": 0},
        "cases": cases, "measurements": measurements,
        "zero_vs_absent": {
            "zero_response": by_id["LOAD_0"]["measured"]["response_t34"],
            "absent_response": by_id["ABSENT"]["measured"]["response_t34"],
        },
        "completed_case_count": len(cases), "partial_case_count": 0,
        "elapsed_seconds": time.monotonic() - started,
    }
    dump(args.output / "bounded_programmable_input_results.json", result)
    print(json.dumps({"completed": len(cases), "partial": 0,
                      "measurements": measurements, "elapsed_seconds": result["elapsed_seconds"]},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
