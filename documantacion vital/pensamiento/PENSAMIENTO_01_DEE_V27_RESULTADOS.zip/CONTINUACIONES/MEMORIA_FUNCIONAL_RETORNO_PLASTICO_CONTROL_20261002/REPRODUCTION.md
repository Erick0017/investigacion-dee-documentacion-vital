# Reproducción breve

Con el Python 3.13 y WHL v27 ya configurados:

1. `python -I -B run_native_memory_corrected_clock.py --output .`
2. `python -I -B run_native_return_write_pilot.py --output .`
3. `python -I -B run_virtual_pendulum_hybrid.py --output .`
4. `python -I -B analyze_memory_return_control.py`

Los tres primeros llaman al kernel oficial. El cuarto sólo reduce la telemetría. El WHL no se duplica; su identidad y ruta se registran en `continuation_config.json`.
