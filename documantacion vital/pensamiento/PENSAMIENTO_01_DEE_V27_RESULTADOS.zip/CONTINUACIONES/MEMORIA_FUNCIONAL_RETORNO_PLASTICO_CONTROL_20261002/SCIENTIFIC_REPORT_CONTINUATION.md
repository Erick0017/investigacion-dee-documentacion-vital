# PENSAMIENTO 01 — Memoria funcional, retorno plástico y control virtual

## Preparación y aportaciones del host

Se ejecutaron dos brazos separados. El brazo nativo reutilizó el aparato temporal S1/S2 y el receptor fusion/DEMUX. El host instaló bloques de experiencia declarados mediante escrituras RAW y no modificó clock; después de HOST_STOP sólo hubo ticks y lecturas. En el piloto de retorno todos los componentes existían en t0.

El brazo aplicado integró externamente un péndulo adimensional con `dt=0.08`, `gamma=0.15`, `|u|≤1.5`, 30 pasos y perturbación en el paso 15. DEE recibió observaciones actuales mediante una codificación fija; la planta, el integrador y los controles sin acción/PD son operaciones externas. Éste es un sistema híbrido.

## Procedencia de las diferencias de clock

El runner histórico asignaba `EVENT_PHASE=17` al escribir estímulos. El aparato prospectivo escribió únicamente RAW y conservó ambos buffers de clock. Realizó 16/16 entradas en cada bloque. En los diez checkpoints de cinco mundos, el clock completo se reconstruyó exactamente como `clock_inicial + ticks`: cero posiciones inexplicadas. A igual edad, S1 y S2 tuvieron cero diferencias de clock en t35, t70 y t94.

Por tanto, las diferencias funcionales nuevas descritas abajo no requieren una identidad de secuencia codificada por el host en clock. Esto no reetiqueta retrospectivamente las corridas anteriores.

## Evolución nativa, lecturas y controles

S1 y S2 dejaron 96 posiciones RAW distintas en t35, pero la consulta congelada fue idéntica: 10 posiciones y el mismo hash XOR. En t70, tras 35 ticks adicionales, S1 produjo una respuesta de 30 posiciones y S2 una de 13. Tras HOST_STOP y 24 ticks pasivos, en t94 fueron 7 y 14, con hashes diferentes.

El contraste común fue explícito. S1→S1 y S1→sin segunda experiencia tuvieron exactamente la misma consulta en t70 y t94; lo mismo ocurrió para S2→S1 y S2→sin segunda experiencia. La segunda S1 sí dejó diferencias RAW (el estado completo no es igual), pero no cambió esta lectura. La disponibilidad histórica para este observer apareció durante la continuación nativa con la edad; no puede atribuirse específicamente a la segunda experiencia común.

El control sin primera experiencia seguido por S1 produjo la respuesta de experiencia reciente (10 posiciones) en t70 y t94. Esto separa la edad global del tiempo transcurrido desde la experiencia, aunque no identifica por sí solo una variable mínima suficiente.

## Cambios retenidos y usos posteriores

La distinción S1/S2 fue invisible para la consulta en t35, visible en t70 y siguió visible —con otra magnitud— en t94. La organización funcional no fue RAW inmóvil: el resultado caracteriza disponibilidad futura bajo una consulta, no una celda de memoria fija.

En el retorno, un marcador `s_reg=17` y el primer pulso `s_reg=23` llegaron juntos al DEMUX en t50. En historia baja formaron un registro `s_reg=40`; sin marcador fue 23 y sin flujo fue 17. En historia alta el DEMUX bloqueó ambos. Cortar el bias restauró el registro 40, apoyando la mediación por esa consecuencia.

La transformación no se retuvo: el efecto específico del marcador fue una posición en t50 y cero desde t51 hasta t80. No se ejecutó A3 porque no existía una escritura retenida que pudiera ser utilizada en otro ciclo. Los pulsos posteriores pertenecen al suministro persistente, no a una actualización repetida.

## Resultado del brazo aplicado

Los canarios congelados produjeron `ACTION_POS=+1.5` para ángulo negativo y `ACTION_NEG=-1.5` para positivo. Se evaluaron cuatro estados iniciales reservados, a ambos lados de la vertical y con/sin velocidad inicial. Cada episodio recibió una perturbación que lo alejaba de la vertical.

La interfaz DEE admitió y reconoció 120/120 observaciones. Sus cuatro episodios permanecieron el 100% de los pasos dentro de `|theta|≤0.35`, con error angular acumulado medio 0.300, ángulo máximo medio 0.218, esfuerzo medio 3.600 y cero pasos más allá de `|theta|>0.75`.

Sin acción, la fracción media dentro de la región fue 0.633, el error 0.899 y hubo 16 pasos de pérdida. El PD permaneció también al 100%, con error 0.258 y esfuerzo 0.507. El relé DEE usó acción bang-bang saturada y mayor esfuerzo que PD.

Este brazo mide utilidad de una transformación DEE configurada dentro de un lazo externo. No mide aprendizaje, utilidad de la historia, adaptación durante el episodio, control en tiempo real ni mecánica del péndulo emergida del kernel.

## Repetición frente a actualización funcional

La cadencia de la fuente del retorno es repetición de suministro. La fusión 23+17 fue una transformación nueva pero transitoria. La distinción temporal S1/S2 sí modificó una respuesta futura después de continuar, aunque la segunda experiencia común no fue causalmente necesaria para esa lectura. El péndulo utilizó una política configurada; mantener el equilibrio no constituye evidencia de actualización de esa política.

## Hipótesis compatibles

1. S1 y S2 ocupan organizaciones diferentes que el observer inicial fusiona; su evolución posterior las lleva a clases de respuesta distintas.
2. El tiempo desde la experiencia, junto con la organización RAW, es relevante; el clock absoluto común no explica la separación.
3. El DEMUX es una compuerta transitoria de encuentro: puede cambiar una colisión posterior, pero el destino usado aquí no protege una escritura.
4. En el sistema híbrido, la utilidad procede del mapa de colisión configurado; no se observó modificación de ese mapa.

## Aspectos no medidos

No se probaron historias nuevas fuera de S1/S2, transferencia temporal, recuperación tras pérdida, una segunda arquitectura de retorno, tres ciclos adaptativos ni generalización del péndulo fuera de cuatro estados. Tampoco se aisló una variable mínima de memoria, se entrenó una política, se descargaron datasets o se ejecutó hardware.

La continuación contiene 12 casos nativos completos y 12 casos aplicados completos, sin casos parciales. No emite adjudicación global de pensamiento, autonomía o nivel.
