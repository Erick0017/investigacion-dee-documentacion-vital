#!/usr/bin/env python3
"""Derived analysis and descriptive report; does not call the kernel."""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def load(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                             encoding="utf-8")


def query_signature(query):
    if not query.get("measurement_available"):
        return {"available": False, "reason": query.get("reason")}
    effect = query["horizons"]["16"]["effect"]
    return {"available": True, "raw_diff_positions": effect["raw_diff_positions"],
            "raw_xor_sha256": effect["raw_xor_sha256"]}


def raw_diff(left, right):
    return int(np.count_nonzero(left != right))


def main():
    memory = load("native_memory_corrected_clock_results.json")
    ret = load("native_return_write_results.json")
    pendulum = load("virtual_pendulum_results.json")
    memory_arrays = np.load(HERE / "native_memory_corrected_clock_telemetry.npz", allow_pickle=False)
    by_memory = {c["case_id"]: c for c in memory["cases"]}

    memory_queries = {}
    for case_id, case in by_memory.items():
        memory_queries[case_id] = {
            "t35": query_signature(case["phases"][0]["diagnostic_query"]),
            "t70": query_signature(case["phases"][1]["diagnostic_query"]),
            "t94": query_signature(case["final_diagnostic_query"]),
        }
    clock_checks = []
    for case in memory["cases"]:
        for phase in case["phases"]:
            clock_checks.append({
                "case_id": case["case_id"], "phase": phase["phase"],
                "host_clock_writes": case["host_clock_writes"],
                "raw_writes_preserved_clock": phase["all_host_raw_writes_preserved_clock"],
                "unexplained_clock_positions": phase["clock_provenance"][
                    "positions_not_explained_by_initial_plus_uniform_tick"],
            })
    clock_pair_diffs = {
        "S1_vs_S2_t35": int(np.count_nonzero(
            memory_arrays["S1_THEN_S1__phase1_clock"] != memory_arrays["S2_THEN_S1__phase1_clock"])),
        "S1_vs_S2_t70": int(np.count_nonzero(
            memory_arrays["S1_THEN_S1__phase2_clock"] != memory_arrays["S2_THEN_S1__phase2_clock"])),
        "S1_vs_S2_t94": int(np.count_nonzero(
            memory_arrays["S1_THEN_S1__final_clock"] != memory_arrays["S2_THEN_S1__final_clock"])),
    }
    common_continuation = {
        "S1_history_t70_same_query_with_or_without_second_S1":
            memory_queries["S1_THEN_S1"]["t70"] == memory_queries["S1_THEN_NOEXP"]["t70"],
        "S2_history_t70_same_query_with_or_without_second_S1":
            memory_queries["S2_THEN_S1"]["t70"] == memory_queries["S2_THEN_NOEXP"]["t70"],
        "S1_history_t94_same_query_with_or_without_second_S1":
            memory_queries["S1_THEN_S1"]["t94"] == memory_queries["S1_THEN_NOEXP"]["t94"],
        "S2_history_t94_same_query_with_or_without_second_S1":
            memory_queries["S2_THEN_S1"]["t94"] == memory_queries["S2_THEN_NOEXP"]["t94"],
        "S1_second_block_raw_difference_t94": raw_diff(
            memory_arrays["S1_THEN_S1__final_raw"], memory_arrays["S1_THEN_NOEXP__final_raw"]),
        "S2_second_block_raw_difference_t94": raw_diff(
            memory_arrays["S2_THEN_S1__final_raw"], memory_arrays["S2_THEN_NOEXP__final_raw"]),
    }

    by_return = {c["case_id"]: c for c in ret["cases"]}
    def rec(case_id, tick):
        return by_return[case_id]["trace"][tick]["records"]["demux"]
    return_summary = {
        "low_stream_marker_t50": rec("LOW_STREAM_MARKER", 50),
        "low_stream_no_marker_t50": rec("LOW_STREAM_NO_MARKER", 50),
        "low_no_stream_marker_t50": rec("LOW_NO_STREAM_MARKER", 50),
        "high_stream_marker_t50": rec("HIGH_STREAM_MARKER", 50),
        "high_bias_cut_stream_marker_t50": rec("HIGH_BIAS_CUT_STREAM_MARKER", 50),
        "marker_effect_positions_t50_low": ret["mediation"]["50"]["marker_effect_low_positions"],
        "marker_effect_positions_t50_high": ret["mediation"]["50"]["marker_effect_high_positions"],
        "marker_effect_positions_t51_low": ret["mediation"]["51"]["marker_effect_low_positions"],
        "marker_effect_positions_t51_high": ret["mediation"]["51"]["marker_effect_high_positions"],
        "marker_effect_positions_t80_low": ret["mediation"]["80"]["marker_effect_low_positions"],
        "marker_effect_positions_t80_high": ret["mediation"]["80"]["marker_effect_high_positions"],
        "interpretation": (
            "At t50 the low-history pulse (s_reg 23) and marker (s_reg 17) fused to s_reg 40. "
            "The high-history DEMUX blocked both. The marker-specific effect was absent from t51 through t80; "
            "no retained write was measured."
        ),
    }

    controllers = ("NO_ACTION", "DEE_CONFIGURED_COLLISION_RELAY", "PD_REFERENCE")
    applied_aggregate = {}
    for controller in controllers:
        episodes = [e for e in pendulum["episodes"] if e["controller"] == controller]
        applied_aggregate[controller] = {
            "episodes": len(episodes),
            "mean_fraction_inside_equilibrium_region": float(np.mean([
                e["metrics"]["fraction_inside_equilibrium_region"] for e in episodes])),
            "mean_cumulative_absolute_angle_error": float(np.mean([
                e["metrics"]["cumulative_absolute_angle_error"] for e in episodes])),
            "mean_max_absolute_angle": float(np.mean([
                e["metrics"]["max_absolute_angle"] for e in episodes])),
            "mean_control_effort_l1": float(np.mean([
                e["metrics"]["control_effort_l1"] for e in episodes])),
            "total_loss_steps": int(sum(e["metrics"]["loss_steps"] for e in episodes)),
        }
        if controller == "DEE_CONFIGURED_COLLISION_RELAY":
            applied_aggregate[controller].update({
                "total_input_admitted": int(sum(e["input_admitted_steps"] for e in episodes)),
                "total_recognized_actions": int(sum(e["recognized_action_steps"] for e in episodes)),
                "possible_steps": len(episodes) * pendulum["plant"]["steps"],
            })

    summary = {
        "campaign_id": "PENSAMIENTO_01_MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002",
        "case_accounting": {
            "native_completed": memory["completed_case_count"] + ret["completed_case_count"],
            "native_partial": memory["partial_case_count"] + ret["partial_case_count"],
            "applied_completed": pendulum["completed_case_count"],
            "applied_partial": pendulum["partial_case_count"],
            "canaries_counted_as_cases": False,
            "diagnostic_clones_counted_as_cases": False,
        },
        "clock_provenance": {
            "historical_code_observation": "prior temporal runner assigned EVENT_PHASE=17 on RAW installation",
            "prospective_policy": "RAW-only writes preserve both existing clock buffers",
            "checks": clock_checks, "matched_history_clock_differences": clock_pair_diffs,
            "all_checkpoints_uniformly_reconstructed": all(
                row["unexplained_clock_positions"] == 0 for row in clock_checks),
        },
        "functional_memory": {
            "queries": memory_queries,
            "raw_comparisons": memory["comparisons"],
            "common_continuation_analysis": common_continuation,
            "observed_description": (
                "S1 and S2 have different X_FULL but the same frozen-query effect at t35. "
                "At t70 and t94 their query effects differ. The same values occur with or without the "
                "common second S1 block, so elapsed native continuation—not that second input—is sufficient "
                "for availability under this observer."
            ),
        },
        "native_return_write": return_summary,
        "hybrid_pendulum": {
            "classification": pendulum["classification"],
            "plant": pendulum["plant"], "interface": pendulum["interface"],
            "canaries": pendulum["canaries"], "aggregate_metrics": applied_aggregate,
            "observed_description": (
                "The configured DEE relay admitted and decoded all 120 observation steps. "
                "All four DEE and PD episodes remained within the chosen equilibrium region; the no-action "
                "episodes did not. The DEE relay used saturated bang-bang action and more effort than PD."
            ),
            "not_measured": ["learning", "adaptation during episode", "utility of DEE history",
                             "generalization beyond the four reserved initial states", "real-time control"],
        },
        "host_native_boundary": {
            "native_memory": "host supplies declared experience RAW; after t70 only tick/read; clock untouched",
            "native_return": "all components exist at t0; t1-t80 tick/read only",
            "hybrid": "external plant integration and sensor writes are host operations; DEE only transforms each collision",
        },
        "scientific_global_verdict_generated": False,
    }
    dump("MEASUREMENT_SUMMARY.json", summary)

    config = {
        "campaign_id": summary["campaign_id"], "author": "Ivan Erick Tlaltecatl Morales",
        "kernel": memory["environment"],
        "native_memory_apparatus": memory["apparatus"],
        "native_return_config": ret["config"],
        "hybrid_plant": pendulum["plant"], "hybrid_interface": pendulum["interface"],
        "initial_states": pendulum["initial_states"], "pd_reference": pendulum["pd_reference"],
        "random_seed": "NOT_APPLICABLE_DETERMINISTIC_PREPARATIONS",
    }
    dump("continuation_config.json", config)
    dump("EXECUTION_LOG.json", {
        "blocks": [
            {"runner": "run_native_memory_corrected_clock.py", "completed": 5, "partial": 0,
             "elapsed_seconds": memory["elapsed_seconds"]},
            {"runner": "run_native_return_write_pilot.py", "completed": 7, "partial": 0,
             "elapsed_seconds": ret["elapsed_seconds"]},
            {"runner": "run_virtual_pendulum_hybrid.py", "completed": 12, "partial": 0,
             "elapsed_seconds": pendulum["elapsed_seconds"]},
        ],
        "native_completed": 12, "native_partial": 0,
        "applied_completed": 12, "applied_partial": 0,
    })

    no_action = applied_aggregate["NO_ACTION"]
    dee = applied_aggregate["DEE_CONFIGURED_COLLISION_RELAY"]
    pd = applied_aggregate["PD_REFERENCE"]
    report = f"""# PENSAMIENTO 01 — Memoria funcional, retorno plástico y control virtual

## Preparación y aportaciones del host

Se ejecutaron dos brazos separados. El brazo nativo reutilizó el aparato temporal S1/S2 y el receptor fusion/DEMUX. El host instaló bloques de experiencia declarados mediante escrituras RAW y no modificó clock; después de HOST_STOP sólo hubo ticks y lecturas. En el piloto de retorno todos los componentes existían en t0.

El brazo aplicado integró externamente un péndulo adimensional con `dt=0.08`, `gamma=0.15`, `|u|≤1.5`, 30 pasos y perturbación en el paso 15. DEE recibió observaciones actuales mediante una codificación fija; la planta, el integrador y los controles sin acción/PD son operaciones externas. Éste es un sistema híbrido.

## Procedencia de las diferencias de clock

El runner histórico asignaba `EVENT_PHASE=17` al escribir estímulos. El aparato prospectivo escribió únicamente RAW y conservó ambos buffers de clock. Realizó 16/16 entradas en cada bloque. En los diez checkpoints de cinco mundos, el clock completo se reconstruyó exactamente como `clock_inicial + ticks`: cero posiciones inexplicadas. A igual edad, S1 y S2 tuvieron cero diferencias de clock en t35, t70 y t94.

Por tanto, las diferencias funcionales nuevas descritas abajo no requieren una identidad de secuencia codificada por el host en clock. Esto no reetiqueta retrospectivamente las corridas anteriores.

## Evolución nativa, lecturas y controles

S1 y S2 dejaron 96 posiciones RAW distintas en t35, pero la consulta congelada fue idéntica: 10 posiciones y el mismo hash XOR. En t70, tras 35 ticks adicionales, S1 produjo una respuesta de 30 posiciones y S2 una de 13. Tras HOST_STOP y 24 ticks pasivos, en t94 fueron 7 y 14, con hashes diferentes.

El contraste común fue explícito. S1→S1 y S1→sin segunda experiencia tuvieron exactamente la misma consulta en t70 y t94; lo mismo ocurrió para S2→S1 y S2→sin segunda experiencia. La segunda S1 sí dejó diferencias RAW (el estado completo no es igual), pero no cambió esta lectura. La disponibilidad histórica para este observer apareció durante la continuación nativa con la edad; no puede atribuirse específicamente a la segunda experiencia común.

El control sin primera experiencia seguido por S1 produjo la respuesta de experiencia reciente (10 posiciones) en t70 y t94. Esto separa la edad global del tiempo transcurrido desde la experiencia, aunque no identifica por sí solo una variable mínima suficiente.

## Cambios retenidos y usos posteriores

La distinción S1/S2 fue invisible para la consulta en t35, visible en t70 y siguió visible —con otra magnitud— en t94. La organización funcional no fue RAW inmóvil: el resultado caracteriza disponibilidad futura bajo una consulta, no una celda de memoria fija.

En el retorno, un marcador `s_reg=17` y el primer pulso `s_reg=23` llegaron juntos al DEMUX en t50. En historia baja formaron un registro `s_reg=40`; sin marcador fue 23 y sin flujo fue 17. En historia alta el DEMUX bloqueó ambos. Cortar el bias restauró el registro 40, apoyando la mediación por esa consecuencia.

La transformación no se retuvo: el efecto específico del marcador fue una posición en t50 y cero desde t51 hasta t80. No se ejecutó A3 porque no existía una escritura retenida que pudiera ser utilizada en otro ciclo. Los pulsos posteriores pertenecen al suministro persistente, no a una actualización repetida.

## Resultado del brazo aplicado

Los canarios congelados produjeron `ACTION_POS=+1.5` para ángulo negativo y `ACTION_NEG=-1.5` para positivo. Se evaluaron cuatro estados iniciales reservados, a ambos lados de la vertical y con/sin velocidad inicial. Cada episodio recibió una perturbación que lo alejaba de la vertical.

La interfaz DEE admitió y reconoció 120/120 observaciones. Sus cuatro episodios permanecieron el 100% de los pasos dentro de `|theta|≤0.35`, con error angular acumulado medio {dee['mean_cumulative_absolute_angle_error']:.3f}, ángulo máximo medio {dee['mean_max_absolute_angle']:.3f}, esfuerzo medio {dee['mean_control_effort_l1']:.3f} y cero pasos más allá de `|theta|>0.75`.

Sin acción, la fracción media dentro de la región fue {no_action['mean_fraction_inside_equilibrium_region']:.3f}, el error {no_action['mean_cumulative_absolute_angle_error']:.3f} y hubo {no_action['total_loss_steps']} pasos de pérdida. El PD permaneció también al 100%, con error {pd['mean_cumulative_absolute_angle_error']:.3f} y esfuerzo {pd['mean_control_effort_l1']:.3f}. El relé DEE usó acción bang-bang saturada y mayor esfuerzo que PD.

Este brazo mide utilidad de una transformación DEE configurada dentro de un lazo externo. No mide aprendizaje, utilidad de la historia, adaptación durante el episodio, control en tiempo real ni mecánica del péndulo emergida del kernel.

## Repetición frente a actualización funcional

La cadencia de la fuente del retorno es repetición de suministro. La fusión 23+17 fue una transformación nueva pero transitoria. La distinción temporal S1/S2 sí modificó una respuesta futura después de continuar, aunque la segunda experiencia común no fue causalmente necesaria para esa lectura. El péndulo utilizó una política configurada; mantener el equilibrio no constituye evidencia de actualización de esa política.

## Hipótesis compatibles

1. S1 y S2 ocupan organizaciones diferentes que el observer inicial fusiona; su evolución posterior las lleva a clases de respuesta distintas.
2. El tiempo desde la experiencia, junto con la organización RAW, es relevante; el clock absoluto común no explica la separación.
3. El DEMUX es una compuerta transitoria de encuentro: puede cambiar una colisión posterior, pero el destino usado aquí no protege una escritura.
4. En el sistema híbrido, la utilidad procede del mapa de colisión configurado; no se observó modificación de ese mapa.

## Aspectos no medidos

No se probaron historias nuevas fuera de S1/S2, transferencia temporal, recuperación tras pérdida, una segunda arquitectura de retorno, tres ciclos adaptativos ni generalización del péndulo fuera de cuatro estados. Tampoco se aisló una variable mínima de memoria, se entrenó una política, se descargaron datasets o se ejecutó hardware.

La continuación contiene 12 casos nativos completos y 12 casos aplicados completos, sin casos parciales. No emite adjudicación global de pensamiento, autonomía o nivel.
"""
    (HERE / "SCIENTIFIC_REPORT_CONTINUATION.md").write_text(report, encoding="utf-8")

    reproduction = """# Reproducción breve

Con el Python 3.13 y WHL v27 ya configurados:

1. `python -I -B run_native_memory_corrected_clock.py --output .`
2. `python -I -B run_native_return_write_pilot.py --output .`
3. `python -I -B run_virtual_pendulum_hybrid.py --output .`
4. `python -I -B analyze_memory_return_control.py`

Los tres primeros llaman al kernel oficial. El cuarto sólo reduce la telemetría. El WHL no se duplica; su identidad y ruta se registran en `continuation_config.json`.
"""
    (HERE / "REPRODUCTION.md").write_text(reproduction, encoding="utf-8")
    dump("SOURCE_REFERENCES.json", {
        "reused_internal_sources": [
            "pilot_pensamiento01.py",
            "CONTINUACIONES/PAISAJE_REUTILIZABLE_20261001/continuation_common.py",
            "CONTINUACIONES/PAISAJE_REUTILIZABLE_20261001/run_transported_sreg_receiver.py",
            "CONTINUACIONES/PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002/run_temporal_plasticity_v2_preloaded.py",
            "CONTINUACIONES/PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002/run_native_return_stream.py",
        ],
        "historical_code_check": "EVENT_PHASE=17 and clock-buffer assignment verified at lines 31, 73-81, 92 and 110 of the prior runner",
        "external_plant_source": "equations and parameters frozen in run_virtual_pendulum_hybrid.py",
    })


if __name__ == "__main__":
    main()
