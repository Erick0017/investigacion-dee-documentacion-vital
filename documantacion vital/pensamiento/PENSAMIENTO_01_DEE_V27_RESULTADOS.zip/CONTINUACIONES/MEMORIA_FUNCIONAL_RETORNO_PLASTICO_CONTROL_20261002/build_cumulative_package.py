#!/usr/bin/env python3
"""Validate the new continuation and atomically update the cumulative ZIP."""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"
WORK = TESTS / "PENSAMIENTO_01_CONT_MEMORIA_20261002"
TEMP = WORK / "PENSAMIENTO_01_DEE_V27_RESULTADOS.tmp.zip"
PREFIX = "CONTINUACIONES/MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002/"


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def files(root):
    return sorted((p for p in Path(root).rglob("*") if p.is_file()),
                  key=lambda p: p.relative_to(root).as_posix())


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                          encoding="utf-8")


def main():
    parent_sha = sha_file(OFFICIAL)
    allowed = {"CUMULATIVE_INDEX.md", "CUMULATIVE_MANIFEST.json"}
    with zipfile.ZipFile(OFFICIAL, "r") as parent:
        if parent.testzip():
            raise RuntimeError("parent ZIP failed CRC validation")
        parent_names = parent.namelist()
        mismatches = []
        for name in parent_names:
            if name.endswith("/") or name in allowed:
                continue
            path = STAGE / Path(name)
            if not path.is_file():
                mismatches.append({"path": name, "reason": "missing"})
            elif sha_bytes(parent.read(name)) != sha_file(path):
                mismatches.append({"path": name, "reason": "changed"})
        if mismatches:
            raise RuntimeError(f"historical preservation failed: {mismatches[:5]}")
    dump(HERE / "PARENT_PACKAGE_LOCK.json", {
        "parent_official_path": str(OFFICIAL), "parent_sha256": parent_sha,
        "parent_member_count": len(parent_names), "historical_mismatches": [],
        "allowed_updated_root_members": sorted(allowed),
    })

    required_json = ("native_memory_corrected_clock_results.json", "native_return_write_results.json",
                     "virtual_pendulum_results.json", "MEASUREMENT_SUMMARY.json", "continuation_config.json")
    required_npz = ("native_memory_corrected_clock_telemetry.npz", "native_return_write_telemetry.npz",
                    "virtual_pendulum_telemetry.npz")
    required_other = ("run_native_memory_corrected_clock.py", "run_native_return_write_pilot.py",
                      "run_virtual_pendulum_hybrid.py", "analyze_memory_return_control.py",
                      "SCIENTIFIC_REPORT_CONTINUATION.md", "REPRODUCTION.md", "SOURCE_REFERENCES.json",
                      "EXECUTION_LOG.json", "PARENT_PACKAGE_LOCK.json")
    missing = [name for name in required_json + required_npz + required_other if not (HERE / name).is_file()]
    if missing:
        raise RuntimeError(f"missing required files: {missing}")
    for name in required_json:
        json.loads((HERE / name).read_text(encoding="utf-8"))
    for name in required_npz:
        with np.load(HERE / name, allow_pickle=False) as data:
            if not data.files:
                raise RuntimeError(f"empty telemetry: {name}")
    summary = json.loads((HERE / "MEASUREMENT_SUMMARY.json").read_text(encoding="utf-8"))
    dump(HERE / "PACKAGE_VALIDATION.json", {
        "required_files_present": True, "json_parse_valid": True, "npz_readable": True,
        "historical_members_preserved": True,
        "native_completed": summary["case_accounting"]["native_completed"],
        "native_partial": summary["case_accounting"]["native_partial"],
        "applied_completed": summary["case_accounting"]["applied_completed"],
        "applied_partial": summary["case_accounting"]["applied_partial"],
        "scientific_global_verdict_generated": False, "pensamiento_02_opened": False,
    })

    lines = []
    for path in files(HERE):
        if path.name == "CONTINUATION_HASHES.sha256":
            continue
        lines.append(f"{sha_file(path)}  {path.relative_to(HERE).as_posix()}")
    (HERE / "CONTINUATION_HASHES.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")

    members = []
    for path in files(STAGE):
        rel = path.relative_to(STAGE).as_posix()
        if rel == "CUMULATIVE_MANIFEST.json":
            continue
        if rel.startswith(PREFIX):
            section = "current_continuation"
        elif rel.startswith("CONTINUACIONES/"):
            section = "prior_continuation"
        else:
            section = "initial_campaign"
        members.append({"path": rel, "size": path.stat().st_size,
                        "sha256": sha_file(path), "section": section})
    dump(STAGE / "CUMULATIVE_MANIFEST.json", {
        "campaign": "PENSAMIENTO_01_DEE_V27", "parent_zip_sha256": parent_sha,
        "continuations": ["PAISAJE_REUTILIZABLE_20261001", "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002",
                          "MEMORIA_FUNCIONAL_RETORNO_PLASTICO_CONTROL_20261002"],
        "current_native_completed": 12, "current_native_partial": 0,
        "current_applied_completed": 12, "current_applied_partial": 0,
        "member_hash_scope": "all members except this CUMULATIVE_MANIFEST.json",
        "members": members,
    })

    if TEMP.exists():
        TEMP.unlink()
    with zipfile.ZipFile(TEMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files(STAGE):
            archive.write(path, path.relative_to(STAGE).as_posix())
    expected_names = {p.relative_to(STAGE).as_posix() for p in files(STAGE)}
    with zipfile.ZipFile(TEMP, "r") as archive:
        if archive.testzip():
            raise RuntimeError("temporary ZIP failed CRC")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("temporary ZIP member mismatch")
        for line in archive.read(PREFIX + "CONTINUATION_HASHES.sha256").decode("utf-8").splitlines():
            expected_hash, rel = line.split("  ", 1)
            if sha_bytes(archive.read(PREFIX + rel)) != expected_hash:
                raise RuntimeError(f"internal continuation hash mismatch: {rel}")
    final_sha = sha_file(TEMP)
    os.replace(TEMP, OFFICIAL)
    if sha_file(OFFICIAL) != final_sha:
        raise RuntimeError("official replacement hash mismatch")
    with zipfile.ZipFile(OFFICIAL, "r") as archive:
        if archive.testzip():
            raise RuntimeError("official ZIP failed CRC")
    print(json.dumps({"official_path": str(OFFICIAL), "sha256": final_sha,
                      "members": len(expected_names), "native_completed": 12,
                      "native_partial": 0, "applied_completed": 12, "applied_partial": 0},
                     indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
