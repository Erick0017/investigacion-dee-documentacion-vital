#!/usr/bin/env python3
"""Prospective S1/S2 memory test with RAW-only input writes.

Unlike the historical runner, installing a stimulus never changes the clock
at its source site.  The complete input train is declared before each
experience block; there is no reset or cleaning between blocks.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
COMMON = ZIP_ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
PRIOR = ZIP_ROOT / "CONTINUACIONES" / "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002"
for path in (ZIP_ROOT, COMMON, PRIOR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import (  # noqa: E402
    World, add, build_history_arrays, effect_signature, json_dump, load_kernel,
    pack, read, sha256_array, world_summary,
)
from run_temporal_plasticity import clone_world, local_readout  # noqa: E402

CAMPAIGN = "PENSAMIENTO_01_MEMORY_CORRECTED_CLOCK_20261002"
N = 73
ORIGIN = (36, 36, 36)
ARRIVALS = list(range(5, 36, 2))
PHASE_TICKS = 35
PASSIVE_TICKS = 24
S1 = "AABBBAABBAABBAAB"
S2 = "ABAAABBBABBBAAAB"
QUERY_HORIZONS = (1, 4, 8, 16)

CASES = {
    "S1_THEN_S1": (S1, S1),
    "S2_THEN_S1": (S2, S1),
    "NOEXP_THEN_S1": ("", S1),
    "S1_THEN_NOEXP": (S1, ""),
    "S2_THEN_NOEXP": (S2, ""),
}


def write_raw_preserve_clock(world: World, q, raw_value: int, label: str) -> dict:
    q = tuple(q)
    before = read(world.raw_a, q)
    clock_before_a = int(world.clock_a[q])
    clock_before_b = int(world.clock_b[q])
    item = {
        "label": label, "site": list(q), "site_before": before,
        "clock_before_a": clock_before_a, "clock_before_b": clock_before_b,
        "written": before is None,
    }
    if before is None:
        value = np.uint64(raw_value)
        world.raw_a[q] = value
        world.raw_b[q] = value
    item["clock_after_a"] = int(world.clock_a[q])
    item["clock_after_b"] = int(world.clock_b[q])
    item["clock_preserved"] = (
        item["clock_after_a"] == clock_before_a and item["clock_after_b"] == clock_before_b
    )
    return item


def port_geometry(ports, symbol: str, n: int):
    if symbol == "A":
        return add(ports["a"], (0, -1, 0), 1, n), (0, 0, -1), 5000
    if symbol == "B":
        return add(ports["b"], (0, 1, 0), 1, n), (0, 0, 1), 5001
    raise ValueError(symbol)


def install_train(world: World, ports, symbols: str, label: str):
    writes = []
    for index, (symbol, arrival) in enumerate(zip(symbols, ARRIVALS), start=1):
        target, direction, state = port_geometry(ports, symbol, world.n)
        source = add(target, direction, -arrival, world.n)
        row = write_raw_preserve_clock(
            world, source, int(pack(state, 3, direction, 1)),
            f"{label}:event_{index}:{symbol}",
        )
        row.update({"symbol": symbol, "arrival_tick_relative": arrival,
                    "target": list(target), "direction": list(direction)})
        writes.append(row)
    return writes


def advance(world: World, ports, tick0: int):
    tick = tick0
    trace = []
    for relative in range(1, PHASE_TICKS + 1):
        info = world.tick(); tick += 1
        if relative in set(ARRIVALS) or relative in (1, PHASE_TICKS):
            trace.append({"relative_tick": relative, "absolute_tick": tick,
                          "kernel": info, "readout": local_readout(world, ports, tick)})
    return tick, trace


def query_sites(ports, n):
    center = ports["comparator"]
    directions = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))
    return [(add(center, d, 8, n), tuple(-x for x in d)) for d in directions]


def diagnostic_query(kernel, checkpoint: World, ports, tick0: int):
    query, control = clone_world(kernel, checkpoint), clone_world(kernel, checkpoint)
    writes = []
    for index, (site, inward) in enumerate(query_sites(ports, query.n)):
        writes.append(write_raw_preserve_clock(
            query, site, int(pack(8300 + index, 0, inward, 1)), f"frozen_query_{index}"
        ))
    if not all(row["written"] for row in writes):
        return {"measurement_available": False, "reason": "FIXED_QUERY_SITE_OCCUPIED", "writes": writes}
    horizons, previous = {}, 0
    for horizon in QUERY_HORIZONS:
        for _ in range(horizon - previous):
            query.tick(); control.tick()
        horizons[str(horizon)] = {
            "effect": effect_signature((query.raw_a, query.clock_a), (control.raw_a, control.clock_a)),
            "query_readout": local_readout(query, ports, tick0 + horizon),
            "control_readout": local_readout(control, ports, tick0 + horizon),
        }
        previous = horizon
    return {"measurement_available": True, "writes": writes, "horizons": horizons,
            "temporal_semantics": "DIAGNOSTIC_CLONE_CONTRAFACTUAL_RAW_ONLY_WRITE"}


def clock_provenance(initial_clock: np.ndarray, current_clock: np.ndarray, tick: int):
    expected = initial_clock + np.uint64(tick)
    difference = current_clock != expected
    return {
        "tick": tick,
        "positions_not_explained_by_initial_plus_uniform_tick": int(np.count_nonzero(difference)),
        "expected_sha256": sha256_array(expected),
        "observed_sha256": sha256_array(current_clock),
        "exact_uniform_reconstruction": not bool(np.any(difference)),
    }


def run_case(kernel, case_id: str, blocks: tuple[str, str]):
    raw, clock, ports = build_history_arrays(N, ORIGIN, "H0")
    world = World(kernel, raw, clock)
    initial_clock = world.clock_a.copy()
    tick = 0
    arrays = {f"{case_id}__t0_raw": world.raw_a.copy(),
              f"{case_id}__t0_clock": world.clock_a.copy()}
    phases = []
    for phase_number, symbols in enumerate(blocks, start=1):
        writes = install_train(world, ports, symbols, f"{case_id}:phase{phase_number}") if symbols else []
        phase_start = local_readout(world, ports, tick)
        tick, trace = advance(world, ports, tick)
        checkpoint = clone_world(kernel, world)
        query = diagnostic_query(kernel, checkpoint, ports, tick)
        arrays[f"{case_id}__phase{phase_number}_raw"] = checkpoint.raw_a
        arrays[f"{case_id}__phase{phase_number}_clock"] = checkpoint.clock_a
        phases.append({
            "phase": phase_number, "symbols": symbols or "NO_EXPERIENCE",
            "start_tick": tick - PHASE_TICKS, "end_tick": tick,
            "writes": writes, "writes_attempted": len(writes),
            "writes_realized": sum(int(x["written"]) for x in writes),
            "all_host_raw_writes_preserved_clock": all(x["clock_preserved"] for x in writes),
            "phase_start_readout": phase_start, "trace": trace,
            "phase_end_readout": local_readout(world, ports, tick),
            "clock_provenance": clock_provenance(initial_clock, world.clock_a, tick),
            "diagnostic_query": query,
        })
    host_stop = tick
    passive = []
    for offset in range(1, PASSIVE_TICKS + 1):
        info = world.tick(); tick += 1
        if offset in (1, 4, 8, 16, PASSIVE_TICKS):
            passive.append({"offset": offset, "kernel": info,
                            "readout": local_readout(world, ports, tick),
                            "clock_provenance": clock_provenance(initial_clock, world.clock_a, tick)})
    final_checkpoint = clone_world(kernel, world)
    final_query = diagnostic_query(kernel, final_checkpoint, ports, tick)
    arrays[f"{case_id}__final_raw"] = world.raw_a
    arrays[f"{case_id}__final_clock"] = world.clock_a
    completed = all(p["writes_realized"] == p["writes_attempted"] for p in phases)
    return {
        "case_id": case_id, "blocks": list(blocks), "phases": phases,
        "host_stop_tick": host_stop, "post_host_trace": passive,
        "final": local_readout(world, ports, tick), "final_diagnostic_query": final_query,
        "host_clock_writes": 0,
        "post_host_writes": 0, "status": "COMPLETED" if completed else "PARTIAL_INPUT_OCCLUSION",
    }, arrays


def raw_diff(left, right):
    mask = left != right
    return {"positions": int(np.count_nonzero(mask)),
            "xor_sha256": sha256_array(np.bitwise_xor(left, right))}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    kernel, environment = load_kernel()
    canary = World(kernel, np.zeros((5, 5, 5), np.uint64), np.zeros((5, 5, 5), np.uint64))
    canary_result = canary.tick()
    cases, arrays = [], {}
    for case_id, blocks in CASES.items():
        result, data = run_case(kernel, case_id, blocks)
        cases.append(result); arrays.update(data)
    comparisons = {}
    for left, right in (("S1_THEN_S1", "S2_THEN_S1"),
                        ("S1_THEN_S1", "NOEXP_THEN_S1"),
                        ("S1_THEN_NOEXP", "S2_THEN_NOEXP")):
        comparisons[f"{left}__vs__{right}"] = {
            f"phase_{phase}": raw_diff(arrays[f"{left}__phase{phase}_raw"],
                                        arrays[f"{right}__phase{phase}_raw"])
            for phase in (1, 2)
        }
    completed = sum(c["status"] == "COMPLETED" for c in cases)
    payload = {
        "campaign_id": CAMPAIGN,
        "question": "Does history S1 versus S2 change a common S1 continuation when RAW input writes preserve site clocks?",
        "environment": environment,
        "operational_canary": {"shape": [5, 5, 5], "tick_result": canary_result},
        "apparatus": {"N": N, "origin": ORIGIN, "arrival_ticks": ARRIVALS,
                      "phase_ticks": PHASE_TICKS, "input_clock_policy": "PRESERVE_EXISTING_SITE_CLOCK",
                      "query_clock_policy": "PRESERVE_EXISTING_SITE_CLOCK"},
        "cases": cases, "comparisons": comparisons,
        "completed_case_count": completed, "partial_case_count": len(cases) - completed,
        "elapsed_seconds": time.monotonic() - started,
    }
    json_dump(args.output / "native_memory_corrected_clock_results.json", payload)
    np.savez_compressed(args.output / "native_memory_corrected_clock_telemetry.npz", **arrays)
    print(json.dumps({"completed": completed, "partial": len(cases) - completed,
                      "elapsed_seconds": payload["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
