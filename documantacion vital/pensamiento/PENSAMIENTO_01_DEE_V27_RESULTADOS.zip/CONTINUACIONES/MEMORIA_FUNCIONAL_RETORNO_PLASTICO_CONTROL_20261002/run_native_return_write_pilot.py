#!/usr/bin/env python3
"""One bounded attempt to convert the return difference into an outgoing record.

A marker carrier, present at t0, is timed to reach the DEMUX interface at the
same t50 as the first persistent-supply pulse.  The experiment asks whether
the two-input encounter leaves a later trace distinct from marker-only and
stream-only controls.  There are no post-t0 writes.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
COMMON = ZIP_ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
PRIOR = ZIP_ROOT / "CONTINUACIONES" / "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002"
for path in (ZIP_ROOT, COMMON, PRIOR):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import effect_signature, json_dump, sha256_array  # noqa: E402
from pilot_pensamiento01 import add, load_kernel, pack, read  # noqa: E402
import run_native_return_stream as return_parent  # noqa: E402

CAMPAIGN = "PENSAMIENTO_01_NATIVE_RETURN_WRITE_PILOT_20261002"
N = return_parent.N
MARKER_DIR = (0, 0, 1)
MARKER_DISTANCE = 50
MARKER_STATE = 74000
MARKER_SREG = 17
HORIZON = 80
CHECKPOINTS = (0, 32, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 64, 70, 80)

CASES = (
    {"id": "LOW_STREAM_MARKER", "bits": (0, 0, 0, 1, 1), "stream": "intact", "marker": True, "receiver": "intact"},
    {"id": "HIGH_STREAM_MARKER", "bits": (0, 1, 1, 1, 1), "stream": "intact", "marker": True, "receiver": "intact"},
    {"id": "LOW_STREAM_NO_MARKER", "bits": (0, 0, 0, 1, 1), "stream": "intact", "marker": False, "receiver": "intact"},
    {"id": "HIGH_STREAM_NO_MARKER", "bits": (0, 1, 1, 1, 1), "stream": "intact", "marker": False, "receiver": "intact"},
    {"id": "LOW_NO_STREAM_MARKER", "bits": (0, 0, 0, 1, 1), "stream": "cut", "marker": True, "receiver": "intact"},
    {"id": "HIGH_NO_STREAM_MARKER", "bits": (0, 1, 1, 1, 1), "stream": "cut", "marker": True, "receiver": "intact"},
    {"id": "HIGH_BIAS_CUT_STREAM_MARKER", "bits": (0, 1, 1, 1, 1), "stream": "intact", "marker": True, "receiver": "bias_cut"},
)


def torus_add(q, offset):
    return tuple((int(q[i]) + int(offset[i])) % N for i in range(3))


def install_marker(world, apparatus, enabled: bool):
    if not enabled:
        return {"enabled": False, "source": None}
    target = tuple(apparatus["demux_target"])
    source = add(target, MARKER_DIR, -MARKER_DISTANCE, N)
    before = read(world.raw_a, source)
    if before is not None:
        raise RuntimeError(f"marker overlap at {source}: {before}")
    before_clock = [int(world.clock_a[source]), int(world.clock_b[source])]
    value = pack(MARKER_STATE, MARKER_SREG, MARKER_DIR, 1)
    world.raw_a[source] = value; world.raw_b[source] = value
    return {"enabled": True, "source": list(source), "target": list(target),
            "direction": list(MARKER_DIR), "state": MARKER_STATE, "sreg": MARKER_SREG,
            "clock_before_after": before_clock + [int(world.clock_a[source]), int(world.clock_b[source])],
            "clock_preserved": before_clock == [int(world.clock_a[source]), int(world.clock_b[source])],
            "nominal_arrival_tick": MARKER_DISTANCE}


def local_records(raw, center, radius=3):
    rows = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = torus_add(center, (dx, dy, dz))
                rec = read(raw, q)
                if rec is not None:
                    rows.append({"offset": [dx, dy, dz], "site": list(q), **rec})
    return rows


def build_case(kernel, spec):
    parent_spec = {"id": spec["id"], "bits": spec["bits"], "receiver": spec["receiver"],
                   "stream": spec["stream"]}
    world, tree, apparatus, stream = return_parent.build_case(kernel, parent_spec)
    marker = install_marker(world, apparatus, spec["marker"])
    return world, apparatus, stream, marker


def run_case(kernel, spec, telemetry):
    world, apparatus, stream, marker = build_case(kernel, spec)
    demux = tuple(apparatus["demux_target"])
    receiver = tuple(apparatus["receiver_target"])
    trace, events = [], []
    for tick in range(HORIZON + 1):
        trace.append({
            "tick": tick, "raw_support": int(np.count_nonzero(world.raw_a)),
            "raw_sha256": sha256_array(world.raw_a),
            "records": {"demux": read(world.raw_a, demux),
                        "receiver": read(world.raw_a, receiver)},
            "demux_neighborhood": local_records(world.raw_a, demux, 3) if tick >= 47 else None,
        })
        if tick in CHECKPOINTS:
            telemetry[f"{spec['id']}__t{tick}__raw"] = world.raw_a.copy()
            telemetry[f"{spec['id']}__t{tick}__clock"] = world.clock_a.copy()
        if tick == HORIZON:
            break
        info = world.tick()
        if any(int(info.get(key, 0)) for key in ("colisiones", "overflows", "genesis")):
            events.append({"tick": tick + 1, **info})
    return {"case_id": spec["id"], "spec": spec, "apparatus": apparatus,
            "stream": stream, "marker": marker, "trace": trace, "kernel_events": events,
            "post_t0_host_writes": 0, "completed": True}


def xor_effect(telemetry, treatment, control, tick):
    tr = telemetry[f"{treatment}__t{tick}__raw"]
    co = telemetry[f"{control}__t{tick}__raw"]
    return np.bitwise_xor(tr, co)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); kernel, environment = load_kernel()
    telemetry = {}; cases = [run_case(kernel, spec, telemetry) for spec in CASES]
    mediation = {}
    for tick in CHECKPOINTS:
        low_marker = xor_effect(telemetry, "LOW_STREAM_MARKER", "LOW_STREAM_NO_MARKER", tick)
        high_marker = xor_effect(telemetry, "HIGH_STREAM_MARKER", "HIGH_STREAM_NO_MARKER", tick)
        low_stream_on_marker = xor_effect(telemetry, "LOW_STREAM_MARKER", "LOW_NO_STREAM_MARKER", tick)
        high_stream_on_marker = xor_effect(telemetry, "HIGH_STREAM_MARKER", "HIGH_NO_STREAM_MARKER", tick)
        mediation[str(tick)] = {
            "marker_effect_low_positions": int(np.count_nonzero(low_marker)),
            "marker_effect_high_positions": int(np.count_nonzero(high_marker)),
            "history_changes_marker_effect_positions": int(np.count_nonzero(low_marker != high_marker)),
            "stream_effect_given_marker_low_positions": int(np.count_nonzero(low_stream_on_marker)),
            "stream_effect_given_marker_high_positions": int(np.count_nonzero(high_stream_on_marker)),
            "history_changes_stream_effect_positions": int(np.count_nonzero(low_stream_on_marker != high_stream_on_marker)),
            "marker_effect_low_sha256": sha256_array(low_marker),
            "marker_effect_high_sha256": sha256_array(high_marker),
        }
    payload = {
        "campaign_id": CAMPAIGN,
        "question": "Can the history-selective first return pulse participate in a second collision and leave a later trace?",
        "environment": environment,
        "config": {"N": N, "marker_direction": MARKER_DIR, "marker_distance": MARKER_DISTANCE,
                   "marker_state": MARKER_STATE, "marker_sreg": MARKER_SREG,
                   "horizon": HORIZON, "checkpoints": CHECKPOINTS},
        "cases": cases, "mediation": mediation,
        "completed_case_count": len(cases), "partial_case_count": 0,
        "elapsed_seconds": time.monotonic() - started,
    }
    json_dump(args.output / "native_return_write_results.json", payload)
    np.savez_compressed(args.output / "native_return_write_telemetry.npz", **telemetry)
    print(json.dumps({"completed": len(cases), "partial": 0,
                      "elapsed_seconds": payload["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
