#!/usr/bin/env python3
"""Bounded hybrid pilot: persistent DEE world controlling an external pendulum.

The DEE interface is deliberately a configured collision relay, not a learned
controller.  The plant is external and dimensionless.  No future plant state
or conventional-control output is supplied to DEE.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
if str(ZIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ZIP_ROOT))

from pilot_pensamiento01 import World, add, load_kernel, pack, read  # noqa: E402

CAMPAIGN = "PENSAMIENTO_01_HYBRID_VIRTUAL_PENDULUM_20261002"
N = 79
DT = 0.08
GAMMA = 0.15
TORQUE_LIMIT = 1.5
STEPS = 30
DEE_TICKS_PER_OBSERVATION = 1
LOSS_ANGLE = 0.75
EQUILIBRIUM_ANGLE = 0.35
PERTURB_STEP = 15
PD_KP = 2.2
PD_KD = 0.9

A = (1, 0, 0)
B = (0, 1, 0)
SENSOR = (-1, 0, 1)
ACTION_POS = (0, 0, 1)
ACTION_NEG = (-1, 1, 1)

INITIAL_STATES = (
    {"id": "P_POS_REST", "theta": 0.22, "omega": 0.0, "disturbance": 0.25},
    {"id": "P_NEG_REST", "theta": -0.22, "omega": 0.0, "disturbance": -0.25},
    {"id": "P_POS_MOVING", "theta": 0.15, "omega": -0.12, "disturbance": 0.25},
    {"id": "P_NEG_MOVING", "theta": -0.15, "omega": 0.12, "disturbance": -0.25},
)


def module_targets():
    values = (8, 26, 44, 62)
    result = []
    for z in (20, 50):
        for x in values:
            for y in values:
                result.append((x, y, z))
    return result[:STEPS]


TARGETS = module_targets()


def preserve_clock_write(world: World, q, value: int, label: str):
    q = tuple(q)
    before = read(world.raw_a, q)
    clocks = [int(world.clock_a[q]), int(world.clock_b[q])]
    row = {"label": label, "site": list(q), "site_before": before,
           "clock_before": clocks, "written": before is None}
    if before is None:
        word = np.uint64(value)
        world.raw_a[q] = word; world.raw_b[q] = word
    row["clock_after"] = [int(world.clock_a[q]), int(world.clock_b[q])]
    row["clock_preserved"] = row["clock_before"] == row["clock_after"]
    return row


def encode_observation(world: World, target, theta: float, omega: float, step: int):
    # Fixed causal encoder: angle sign selects an A/B carrier.  Angular-velocity
    # sign is carried only in s_reg and is not used by the torque decoder.
    bit = 1 if theta >= 0.0 else 0
    policy_dir = B if bit else A
    omega_sreg = 13 if omega >= 0.0 else 11
    policy_source = add(target, policy_dir, -1, world.n)
    sensor_source = add(target, SENSOR, -1, world.n)
    writes = [
        preserve_clock_write(world, policy_source,
                             int(pack(10000 + step, 7, policy_dir, 1)), f"step{step}:angle_sign"),
        preserve_clock_write(world, sensor_source,
                             int(pack(20000 + step, omega_sreg, SENSOR, 1)), f"step{step}:omega_sign"),
    ]
    return {"angle_bit": bit, "omega_sreg": omega_sreg,
            "policy_direction": list(policy_dir), "target": list(target), "writes": writes}


def decode_action(record):
    if record is None:
        return 0.0, "NO_RECORD_NEUTRAL"
    direction = tuple(record["direction"])
    if direction == ACTION_POS:
        return TORQUE_LIMIT, "ACTION_POS"
    if direction == ACTION_NEG:
        return -TORQUE_LIMIT, "ACTION_NEG"
    return 0.0, "UNRECOGNIZED_DIRECTION_NEUTRAL"


def plant_step(theta: float, omega: float, action: float):
    acceleration = math.sin(theta) - GAMMA * omega + action
    omega_next = omega + DT * acceleration
    theta_next = theta + DT * omega_next
    return theta_next, omega_next, acceleration


def pd_action(theta: float, omega: float):
    return max(-TORQUE_LIMIT, min(TORQUE_LIMIT, -PD_KP * theta - PD_KD * omega))


def metrics(trace):
    angles = np.array([row["theta"] for row in trace], dtype=float)
    omegas = np.array([row["omega"] for row in trace], dtype=float)
    actions = np.array([row["action"] for row in trace], dtype=float)
    return {
        "steps": len(trace),
        "simulated_time": len(trace) * DT,
        "fraction_inside_equilibrium_region": float(np.mean(np.abs(angles) <= EQUILIBRIUM_ANGLE)),
        "cumulative_absolute_angle_error": float(np.sum(np.abs(angles)) * DT),
        "max_absolute_angle": float(np.max(np.abs(angles))),
        "max_absolute_omega": float(np.max(np.abs(omegas))),
        "control_effort_l1": float(np.sum(np.abs(actions)) * DT),
        "loss_steps": int(np.count_nonzero(np.abs(angles) > LOSS_ANGLE)),
    }


def run_external_controller(initial, controller: str):
    theta, omega = float(initial["theta"]), float(initial["omega"])
    trace = []
    for step in range(STEPS):
        if step == PERTURB_STEP:
            omega += float(initial["disturbance"])
        action = 0.0 if controller == "NO_ACTION" else pd_action(theta, omega)
        row = {"step": step, "mechanical_time": step * DT, "theta": theta, "omega": omega,
               "action": action, "perturbation_applied": step == PERTURB_STEP}
        theta, omega, acceleration = plant_step(theta, omega, action)
        row.update({"acceleration": acceleration, "theta_next": theta, "omega_next": omega})
        trace.append(row)
    return {"episode_id": initial["id"], "controller": controller,
            "trace": trace, "metrics": metrics(trace), "completed": True}


def run_dee_episode(kernel, initial, telemetry):
    raw = np.zeros((N, N, N), np.uint64)
    clock = np.zeros_like(raw)
    world = World(kernel, raw, clock)
    theta, omega = float(initial["theta"]), float(initial["omega"])
    trace = []; admitted = 0; recognized = 0
    for step, target in enumerate(TARGETS):
        if step == PERTURB_STEP:
            omega += float(initial["disturbance"])
        encoded = encode_observation(world, target, theta, omega, step)
        input_admitted = all(row["written"] for row in encoded["writes"])
        admitted += int(input_admitted)
        kernel_reports = []
        for _ in range(DEE_TICKS_PER_OBSERVATION):
            kernel_reports.append(world.tick())
        record = read(world.raw_a, target)
        action, decode_class = decode_action(record) if input_admitted else (0.0, "INPUT_NOT_ADMITTED_NEUTRAL")
        recognized += int(decode_class in ("ACTION_POS", "ACTION_NEG"))
        row = {"step": step, "mechanical_time": step * DT, "kernel_tick": step + 1,
               "theta": theta, "omega": omega, "encoded": encoded,
               "input_admitted": input_admitted, "output_record": record,
               "decode_class": decode_class, "action": action,
               "kernel_reports": kernel_reports, "perturbation_applied": step == PERTURB_STEP}
        theta, omega, acceleration = plant_step(theta, omega, action)
        row.update({"acceleration": acceleration, "theta_next": theta, "omega_next": omega})
        trace.append(row)
        if step in (0, PERTURB_STEP, STEPS - 1):
            telemetry[f"{initial['id']}__step{step}__raw"] = world.raw_a.copy()
            telemetry[f"{initial['id']}__step{step}__clock"] = world.clock_a.copy()
    result = {"episode_id": initial["id"], "controller": "DEE_CONFIGURED_COLLISION_RELAY",
              "trace": trace, "metrics": metrics(trace),
              "input_admitted_steps": admitted, "recognized_action_steps": recognized,
              "world_persisted_without_reset": True, "host_clock_writes": 0,
              "completed": True}
    return result


def main():
    parser = argparse.ArgumentParser(); parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); kernel, environment = load_kernel(); telemetry = {}
    # Two fixed collision canaries establish decoder signs before plant evaluation.
    canaries = []
    for name, theta in (("NEGATIVE_THETA", -0.2), ("POSITIVE_THETA", 0.2)):
        world = World(kernel, np.zeros((N, N, N), np.uint64), np.zeros((N, N, N), np.uint64))
        encoded = encode_observation(world, TARGETS[0], theta, 0.0, 0); report = world.tick()
        record = read(world.raw_a, TARGETS[0]); action, cls = decode_action(record)
        canaries.append({"name": name, "theta": theta, "encoded": encoded,
                         "kernel_report": report, "record": record,
                         "decode_class": cls, "action": action})
    episodes = []
    for initial in INITIAL_STATES:
        episodes.append(run_external_controller(initial, "NO_ACTION"))
        episodes.append(run_dee_episode(kernel, initial, telemetry))
        episodes.append(run_external_controller(initial, "PD_REFERENCE"))
    payload = {
        "campaign_id": CAMPAIGN,
        "classification": "HYBRID_EXTERNAL_PLANT_WITH_CONFIGURED_DEE_COLLISION_RELAY",
        "environment": environment,
        "plant": {"equations": ["dtheta/dt=omega", "domega/dt=sin(theta)-gamma*omega+u"],
                  "integration": "semi_implicit_euler", "dt": DT, "gamma": GAMMA,
                  "torque_limit": TORQUE_LIMIT, "steps": STEPS,
                  "perturbation_step": PERTURB_STEP, "loss_angle": LOSS_ANGLE,
                  "equilibrium_angle": EQUILIBRIUM_ANGLE},
        "interface": {"encoder": "theta sign -> A/B direction; omega sign -> s_reg 13/11",
                      "decoder": "ACTION_POS -> +limit; ACTION_NEG -> -limit; other -> neutral",
                      "ticks_per_observation": DEE_TICKS_PER_OBSERVATION,
                      "predeclared_module_targets": [list(q) for q in TARGETS],
                      "input_clock_policy": "PRESERVE_EXISTING_SITE_CLOCK",
                      "learned": False, "future_information_used": False},
        "pd_reference": {"kp": PD_KP, "kd": PD_KD},
        "initial_states": INITIAL_STATES, "canaries": canaries,
        "episodes": episodes, "completed_case_count": len(episodes), "partial_case_count": 0,
        "elapsed_seconds": time.monotonic() - started,
    }
    (args.output / "virtual_pendulum_results.json").write_text(
        json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    np.savez_compressed(args.output / "virtual_pendulum_telemetry.npz", **telemetry)
    print(json.dumps({"completed": len(episodes), "partial": 0,
                      "elapsed_seconds": payload["elapsed_seconds"],
                      "canaries": [(x["decode_class"], x["action"]) for x in canaries]}, indent=2))


if __name__ == "__main__":
    main()
