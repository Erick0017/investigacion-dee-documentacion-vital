# Reproducción de la continuación

Requiere CPython 3.13, NumPy y el paquete oficial DEE v27 identificado en `continuation_config.json`. El WHL no se duplica en el ZIP.

Desde la raíz extraída del ZIP acumulativo:

```powershell
cd CONTINUACIONES\PAISAJE_REUTILIZABLE_20261001
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B .\run_reusable_landscape.py --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B .\run_transported_sreg_receiver.py --threads 1
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B .\analyze_continuation.py
```

Los runners importan los helpers históricos conservados en la raíz del mismo ZIP. Todos los portadores posteriores están presentes en `t0`; los scripts no escriben RAW/clock durante la evolución.
