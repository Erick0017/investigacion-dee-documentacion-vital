#!/usr/bin/env python3
"""Derive compact descriptive measurements from the two executed families."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
TESTS = HERE.parents[2]


def load(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def write(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def trace(case):
    return {int(row["tick"]): row for row in case["trace"]}


def main():
    landscape = load("reusable_landscape_results.json")
    receiver = load("transported_sreg_receiver_results.json")
    by_history = {row["history"]: row for row in landscape["cases"]}
    by_id = {row["case"]["id"]: row for row in receiver["cases"]}

    landscape_rows = {}
    for history, case in by_history.items():
        landscape_rows[history] = {
            "P1_effect_after_P1_t11_roi_raw_positions": case["analyses"]["P1_effect"]["11"]["without_later"]["raw_diff_positions"],
            "P2_effect_clean_t19_roi_raw_positions": case["analyses"]["P2_effect"]["19"]["without_P1_P3"]["raw_diff_positions"],
            "P2_effect_after_P1_t19_roi_raw_positions": case["analyses"]["P2_effect"]["19"]["with_P1_without_P3"]["raw_diff_positions"],
            "P3_effect_clean_t27_roi_raw_positions": case["analyses"]["P3_effect"]["27"]["P1_0_P2_0"]["raw_diff_positions"],
            "P3_effect_after_P1_P2_t27_roi_raw_positions": case["analyses"]["P3_effect"]["27"]["P1_1_P2_1"]["raw_diff_positions"],
            "P3_effect_after_P1_shamP2_t27_roi_raw_positions": case["analyses"]["P3_effect"]["27"]["P1_1_P2_sham"]["raw_diff_positions"],
        }

    receiver_rows = {}
    for case_id in (
        "LOW_00011_INTACT_QUERY", "MID_00111_INTACT_QUERY", "HIGH_01111_INTACT_QUERY",
        "HIGH_01111_BIAS_CUT_QUERY", "HIGH_01111_BIAS_SHAM_QUERY", "HIGH_01111_TRANSLATED_QUERY",
    ):
        case = by_id[case_id]
        t = trace(case)
        overflows = sum(int(row.get("overflows", 0)) for row in case["kernel_events"])
        receiver_rows[case_id] = {
            "transported_sreg_t38": None if t[38]["records"]["final_norm"] is None else t[38]["records"]["final_norm"]["sreg"],
            "apparatus_relation_value": case["expected_transport_sreg_apparatus_relation"],
            "receiver_sreg_t48": None if t[48]["records"]["receiver_target"] is None else t[48]["records"]["receiver_target"]["sreg"],
            "receiver_sreg_t49": None if t[49]["records"]["receiver_target"] is None else t[49]["records"]["receiver_target"]["sreg"],
            "demux_state_t49": None if t[49]["records"]["demux_target"] is None else t[49]["records"]["demux_target"]["state"],
            "kernel_overflows": overflows,
            "overflow_ticks": [int(row["tick"]) for row in case["kernel_events"] if int(row.get("overflows", 0))],
        }

    summary = {
        "completed_worlds": int(landscape["completed_worlds"] + receiver["completed_worlds"]),
        "partial_worlds": int(landscape["partial_worlds"] + receiver["partial_worlds"]),
        "post_t0_python_physical_interventions": 0,
        "family_A_repeated_same_route": landscape_rows,
        "family_B_transported_sreg_receiver": receiver_rows,
        "first_later_query_global_raw_effect": receiver["query_global_raw_effects"],
        "second_later_query_effect": receiver["second_query_effects"],
        "direct_local_records": {
            "LOW_Q1_Q2_t51": trace(by_id["LOW_00011_CHAIN_Q1_Q2"])[51]["records"]["query2_target"],
            "LOW_Q2_ONLY_t51": trace(by_id["LOW_00011_Q2_ONLY"])[51]["records"]["query2_target"],
            "HIGH_Q1_Q2_t51": trace(by_id["HIGH_01111_CHAIN_Q1_Q2"])[51]["records"]["query2_target"],
            "HIGH_Q2_ONLY_t51": trace(by_id["HIGH_01111_Q2_ONLY"])[51]["records"]["query2_target"],
        },
        "scope": {
            "supply": "finite carriers and six semantic=4 receiver supports preinstalled at t0",
            "history_domain": "five-link monotone 0*1* R14 chains plus H0/AB/BA temporal-order landscapes",
            "receiver_specificity": "fusion/DEMUX context prepared around P_KERNEL=19665; not a claim of generic readout",
            "renewal_horizon": "two preloaded later queries through t57; no indefinite renewal measured",
            "diagnostic_vs_main": "all measurements in these two families are main-world evidence; no edited clone was returned",
        },
    }
    write("MEASUREMENT_SUMMARY.json", summary)

    sources = [
        TESTS / "PENSAMIENTO_01_WORK" / "run_pensamiento01_chain.py",
        TESTS / "PENSAMIENTO_01_WORK" / "pilot_pensamiento01.py",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_02" / "RUNNERS" / "temporal_order_apparatus_v1.py",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_05_HISTORY_CONDITIONED_TRANSFORMATION" / "RUNNERS" / "run_nrd05_history_conditioned_transformation.py",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS" / "run_nrd06_history_specificity.py",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "procesos" / "PROCESOS_02" / "dee_kernel_v27.cpp",
        TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip",
    ]
    source_rows = []
    for path in sources:
        source_rows.append({
            "path": str(path),
            "found": path.is_file(),
            "sha256": sha(path) if path.is_file() else None,
            "use": "constructor, mechanism definition, or cumulative parent evidence",
        })
    write("SOURCE_REFERENCES.json", {
        "sources": source_rows,
        "DEE_V4_0_1_treatise": {
            "status": "FILE_NOT_FOUND_IN_ACCESSIBLE_TESTS_OR_KNOWN_ATTACHMENTS",
            "search_scope": "targeted filename/member search in tests, documantacion vital ZIPs, project parent, and Codex attachments",
            "effect_on_execution": "primary runners and telemetry were used; no proposition was attributed to the unavailable document",
        },
    })

    write("continuation_config.json", {
        "landscape": landscape["config"],
        "receiver": receiver["config"],
        "kernel_runtime_landscape": landscape["runtime"],
        "kernel_runtime_receiver": receiver["runtime"],
        "deadline_policy": {"target_minutes": 60, "absolute_minutes": 90},
        "scientific_verdicts_automated": False,
    })


if __name__ == "__main__":
    main()
