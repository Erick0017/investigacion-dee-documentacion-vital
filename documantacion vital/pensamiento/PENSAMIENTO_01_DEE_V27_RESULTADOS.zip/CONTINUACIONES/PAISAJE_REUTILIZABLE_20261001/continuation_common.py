#!/usr/bin/env python3
"""Shared apparatus code for the PENSAMIENTO 01 reusable-landscape continuation.

The temporal-order preparation is a literal local copy of the relevant
construction in Ingeniería 02's temporal_order_apparatus_v1.py.  Keeping the
small construction here makes this continuation reproducible without moving
the historical package.
"""
from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
if str(ZIP_ROOT) not in sys.path:
    sys.path.insert(0, str(ZIP_ROOT))

from pilot_pensamiento01 import World, add, load_kernel, pack, read  # noqa: E402

PATTERN_A = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PATTERN_B = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))

STATE_MASK = np.uint64((1 << 32) - 1)
SREG_MASK = np.uint64(0xFFFF)
SEM_MASK = np.uint64(0xF)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_array(array: np.ndarray) -> str:
    return sha256_bytes(np.ascontiguousarray(array).tobytes())


def transform(vector, permutation=(0, 1, 2), signs=(1, 1, 1)):
    return tuple(int(signs[i]) * int(vector[permutation[i]]) for i in range(3))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0, label=""):
    if int(raw[q]):
        raise RuntimeError(f"initial overlap at {q}: {label}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def install_event(raw, clock, memory, target_offset, direction, when, n, state_base, sreg=3):
    target = add(memory, target_offset, 1, n)
    if when == "early":
        put(raw, clock, target, state_base, sreg, direction, 1, 17, "history_early")
        return target
    if when == "late":
        source = add(target, direction, -1, n)
        put(raw, clock, source, 0, sreg, direction, 1, 19, "history_late")
        return source
    raise ValueError(when)


def build_history_arrays(n: int, origin, mode: str):
    """Exact MAIN geometry of the canonical Ingeniería 02 AB/BA builder."""
    c = tuple(origin)
    tf = lambda v: transform(v)
    axis = tf((1, 0, 0))
    a = add(c, tf((-1, 0, 0)), 1, n)
    b = add(c, axis, 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100, semantic=1, phase=260, label="memory_a")
    put(raw, clock, b, 2000, 100, semantic=1, phase=260, label="memory_b")
    for i, offset in enumerate(PATTERN_A):
        put(raw, clock, add(a, tf(offset), 1, n), 3000 + i, 0, semantic=4,
            phase=31 + i, label=f"support_a_{i}")
    for i, offset in enumerate(PATTERN_B):
        put(raw, clock, add(b, tf(offset), 1, n), 4000 + i, 0, semantic=4,
            phase=41 + i, label=f"support_b_{i}")
    schedule = {
        "H0": (None, None),
        "HA": ("early", "late"),
        "HB": ("late", "early"),
    }[mode]
    event_sources = []
    if schedule[0]:
        event_sources.append(install_event(raw, clock, a, tf((0, -1, 0)),
                                           tf((0, 0, -1)), schedule[0], n, 5000, 0))
    if schedule[1]:
        event_sources.append(install_event(raw, clock, b, tf((0, 1, 0)),
                                           tf((0, 0, 1)), schedule[1], n, 5001, 0))
    reader_source = add(c, tf((0, -2, 0)), 1, n)
    put(raw, clock, reader_source, 6000, 7, tf((0, 1, 0)), semantic=4,
        phase=23, label="reader_source")
    return raw, clock, {
        "a": a, "b": b, "comparator": c, "reader_source": reader_source,
        "event_sources": event_sources, "axis": axis,
    }


def probe_geometry(ports, n, translation=(0, 0, 0)):
    # Ingeniería 05 SEPARATED_GEOMETRY = permutation (1,0,2), signs (1,-1,1).
    tf = lambda v: transform(v, (1, 0, 2), (1, -1, 1))
    dir_a, dir_b = tf((0, 0, -1)), tf((0, 0, 1))
    target_a = add(tuple(ports["a"]), tf((0, -1, 0)), 1, n)
    target_b = add(tuple(ports["b"]), tf((0, 1, 0)), 1, n)
    target_a = add(target_a, translation, 1, n)
    target_b = add(target_b, translation, 1, n)
    return target_a, target_b, dir_a, dir_b


def preload_probe(raw, clock, ports, event_start: int, event_id: int,
                  translation=(0, 0, 0)):
    """Preload the canonical E2 pair so B arrives at t and A at t+1."""
    n = raw.shape[0]
    target_a, target_b, dir_a, dir_b = probe_geometry(ports, n, translation)
    source_b = add(target_b, dir_b, -event_start, n)
    source_a = add(target_a, dir_a, -(event_start + 1), n)
    put(raw, clock, source_b, 0, 0, dir_b, 1, 19, f"P{event_id}_B")
    put(raw, clock, source_a, 0, 0, dir_a, 1, 17, f"P{event_id}_A")
    return {
        "event_id": event_id, "event_start": event_start,
        "target_a": list(target_a), "target_b": list(target_b),
        "source_a": list(source_a), "source_b": list(source_b),
        "dir_a": list(dir_a), "dir_b": list(dir_b),
        "translation": list(translation),
    }


def signed_nibble_array(raw, shift):
    value = ((raw >> np.uint64(shift)) & np.uint64(0xF)).astype(np.int16)
    return np.where(value >= 8, value - 16, value)


def decoded_fields(raw):
    return {
        "state": (raw & STATE_MASK).astype(np.uint32),
        "sreg": ((raw >> np.uint64(32)) & SREG_MASK).astype(np.uint16),
        "dx": signed_nibble_array(raw, 48),
        "dy": signed_nibble_array(raw, 52),
        "dz": signed_nibble_array(raw, 56),
        "semantic": ((raw >> np.uint64(60)) & SEM_MASK).astype(np.uint8),
    }


def world_summary(world, tick: int):
    raw = world.raw_a
    fields = decoded_fields(raw)
    occupied = fields["state"] > 0
    return {
        "tick": tick,
        "raw_support": int(np.count_nonzero(raw)),
        "occupied_support": int(np.count_nonzero(occupied)),
        "sreg_sum": int(fields["sreg"].astype(np.uint64).sum()),
        "raw_sha256": sha256_array(raw),
        "clock_sha256": sha256_array(world.clock_a),
        "field_nonzero": {k: int(np.count_nonzero(v)) for k, v in fields.items()},
    }


def effect_signature(on_state, off_state, roi_mask=None):
    raw_on, clock_on = on_state
    raw_off, clock_off = off_state
    raw_diff = raw_on != raw_off
    clock_diff = clock_on != clock_off
    if roi_mask is not None:
        raw_diff_eval = raw_diff & roi_mask
        clock_diff_eval = clock_diff & roi_mask
    else:
        raw_diff_eval = raw_diff
        clock_diff_eval = clock_diff
    f_on, f_off = decoded_fields(raw_on), decoded_fields(raw_off)
    return {
        "raw_diff_positions": int(np.count_nonzero(raw_diff_eval)),
        "clock_diff_positions": int(np.count_nonzero(clock_diff_eval)),
        "raw_xor_sha256": sha256_array(np.bitwise_xor(raw_on, raw_off)),
        "clock_xor_sha256": sha256_array(np.bitwise_xor(clock_on, clock_off)),
        "raw_diff_mask_sha256": sha256_array(raw_diff),
        "field_diff_positions": {
            key: int(np.count_nonzero((f_on[key] != f_off[key]) & (roi_mask if roi_mask is not None else True)))
            for key in f_on
        },
    }


def chebyshev_roi(n: int, centers, radius: int):
    mask = np.zeros((n, n, n), dtype=bool)
    for center in centers:
        cx, cy, cz = map(int, center)
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    mask[(cx + dx) % n, (cy + dy) % n, (cz + dz) % n] = True
    return mask


def read_points(raw, points):
    return {name: read(raw, tuple(q)) for name, q in points.items()}


def json_dump(path: Path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                    encoding="utf-8")
