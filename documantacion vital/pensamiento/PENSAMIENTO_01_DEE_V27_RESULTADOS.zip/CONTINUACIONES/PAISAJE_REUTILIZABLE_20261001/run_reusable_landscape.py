#!/usr/bin/env python3
"""Preloaded repeated-interaction factorial for PENSAMIENTO 01 continuation.

All histories and three possible later E2 interactions exist as physical
carriers at t0.  After construction, every branch is advanced only through the
official v27 kernel and passively read.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from continuation_common import (
    World, build_history_arrays, chebyshev_roi, effect_signature, json_dump,
    load_kernel, preload_probe, probe_geometry, read_points, sha256_array,
    world_summary,
)

CONFIG = {
    "campaign": "PENSAMIENTO_01_CONTINUACION_PAISAJE_REUTILIZABLE_20261001",
    "family": "ING05_ING06_HISTORY_LANDSCAPE_WITH_THREE_PRELOADED_INTERACTIONS",
    "n": 83,
    "origin": [41, 41, 41],
    "histories": ["H0", "HA", "HB"],
    "interaction_starts": {"P1": 8, "P2": 16, "P3": 24},
    "horizon": 36,
    "checkpoints": [0, 4, 7, 11, 15, 19, 23, 27, 32, 36],
    "variants": ["000", "001", "010", "011", "100", "101", "110", "111", "1S0", "1S1"],
    "sham_translation": [0, 10, 0],
    "post_t0_host_calls": ["tick", "read", "hash", "checkpoint", "log", "stop"],
}


def build_variant(kernel, history: str, variant: str):
    n = CONFIG["n"]
    raw, clock, ports = build_history_arrays(n, CONFIG["origin"], history)
    placements = []
    p1, p2, p3 = variant[0], variant[1], variant[2]
    if p1 == "1":
        placements.append(preload_probe(raw, clock, ports, CONFIG["interaction_starts"]["P1"], 1))
    if p2 == "1":
        placements.append(preload_probe(raw, clock, ports, CONFIG["interaction_starts"]["P2"], 2))
    elif p2 == "S":
        placements.append(preload_probe(raw, clock, ports, CONFIG["interaction_starts"]["P2"], 2,
                                        tuple(CONFIG["sham_translation"])))
    if p3 == "1":
        placements.append(preload_probe(raw, clock, ports, CONFIG["interaction_starts"]["P3"], 3))
    return World(kernel, raw, clock), ports, placements


def capture_state(world):
    return world.raw_a.copy(), world.clock_a.copy()


def run_history(kernel, history: str, telemetry):
    worlds, ports, placements = {}, None, {}
    for variant in CONFIG["variants"]:
        world, this_ports, this_placements = build_variant(kernel, history, variant)
        worlds[variant] = world
        ports = this_ports
        placements[variant] = this_placements

    target_a, target_b, _, _ = probe_geometry(ports, CONFIG["n"])
    roi = chebyshev_roi(CONFIG["n"], [target_a, target_b, ports["a"], ports["b"], ports["comparator"]], 4)
    points = {
        "memory_a": ports["a"], "memory_b": ports["b"], "comparator": ports["comparator"],
        "probe_target_a": target_a, "probe_target_b": target_b,
    }
    summaries = {variant: [] for variant in worlds}
    local_trace = {variant: [] for variant in worlds}
    checkpoint_states = {}
    kernel_events = {variant: [] for variant in worlds}

    for tick in range(0, CONFIG["horizon"] + 1):
        if tick in CONFIG["checkpoints"]:
            checkpoint_states[tick] = {variant: capture_state(world) for variant, world in worlds.items()}
            for variant, world in worlds.items():
                summaries[variant].append(world_summary(world, tick))
                local_trace[variant].append({"tick": tick, "records": read_points(world.raw_a, points)})
                if variant in ("111", "101", "1S1") and tick in (15, 19, 23, 27, 36):
                    telemetry[f"{history}_{variant}_t{tick}_raw"] = world.raw_a.copy()
                    telemetry[f"{history}_{variant}_t{tick}_clock"] = world.clock_a.copy()
        if tick == CONFIG["horizon"]:
            break
        for variant, world in worlds.items():
            report = world.tick()
            if any(int(report.get(k, 0)) for k in ("colisiones", "overflows", "genesis")):
                kernel_events[variant].append({"tick": tick + 1, **report})

    analyses = {"P1_effect": {}, "P2_effect": {}, "P3_effect": {}, "P3_effect_comparisons": {}}
    for tick in (11, 19, 27, 36):
        states = checkpoint_states[tick]
        analyses["P1_effect"][str(tick)] = {
            "without_later": effect_signature(states["100"], states["000"], roi),
            "with_P2_P3": effect_signature(states["111"], states["011"], roi),
        }
        analyses["P2_effect"][str(tick)] = {
            "without_P1_P3": effect_signature(states["010"], states["000"], roi),
            "with_P1_without_P3": effect_signature(states["110"], states["100"], roi),
            "with_P1_P3": effect_signature(states["111"], states["101"], roi),
            "sham_with_P1_P3": effect_signature(states["1S1"], states["101"], roi),
        }
        p3_effects = {
            "P1_0_P2_0": effect_signature(states["001"], states["000"], roi),
            "P1_0_P2_1": effect_signature(states["011"], states["010"], roi),
            "P1_1_P2_0": effect_signature(states["101"], states["100"], roi),
            "P1_1_P2_1": effect_signature(states["111"], states["110"], roi),
            "P1_1_P2_sham": effect_signature(states["1S1"], states["1S0"], roi),
        }
        analyses["P3_effect"][str(tick)] = p3_effects
        raw_effects = {
            "P1_0_P2_0": np.bitwise_xor(states["001"][0], states["000"][0]),
            "P1_0_P2_1": np.bitwise_xor(states["011"][0], states["010"][0]),
            "P1_1_P2_0": np.bitwise_xor(states["101"][0], states["100"][0]),
            "P1_1_P2_1": np.bitwise_xor(states["111"][0], states["110"][0]),
            "P1_1_P2_sham": np.bitwise_xor(states["1S1"][0], states["1S0"][0]),
        }
        analyses["P3_effect_comparisons"][str(tick)] = {
            "P2_intact_vs_absent_after_P1_raw_effect_diff_positions": int(np.count_nonzero((raw_effects["P1_1_P2_1"] != raw_effects["P1_1_P2_0"]) & roi)),
            "P2_intact_vs_sham_after_P1_raw_effect_diff_positions": int(np.count_nonzero((raw_effects["P1_1_P2_1"] != raw_effects["P1_1_P2_sham"]) & roi)),
            "P1_present_vs_absent_given_P2_raw_effect_diff_positions": int(np.count_nonzero((raw_effects["P1_1_P2_1"] != raw_effects["P1_0_P2_1"]) & roi)),
            "effect_hashes": {key: sha256_array(value) for key, value in raw_effects.items()},
        }

    return {
        "history": history,
        "ports": {k: list(v) if isinstance(v, tuple) else [list(q) for q in v] if isinstance(v, list) else v for k, v in ports.items()},
        "placements": placements,
        "roi_voxels": int(np.count_nonzero(roi)),
        "summaries": summaries,
        "local_trace": local_trace,
        "kernel_events": kernel_events,
        "analyses": analyses,
        "python_interventions_after_t0": 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    started = time.time()
    kernel, runtime = load_kernel()
    if args.threads != 1:
        kernel.set_num_threads(int(args.threads))
    telemetry = {}
    cases = [run_history(kernel, history, telemetry) for history in CONFIG["histories"]]
    result = {
        "campaign": CONFIG["campaign"],
        "config": CONFIG,
        "runtime": runtime,
        "elapsed_seconds": time.time() - started,
        "completed_worlds": len(CONFIG["histories"]) * len(CONFIG["variants"]),
        "partial_worlds": 0,
        "cases": cases,
        "measurement_note": "Effect arrays compare matched physical branches; labels are descriptive measurements, not automatic scientific verdicts.",
    }
    json_dump(HERE / "reusable_landscape_results.json", result)
    np.savez_compressed(HERE / "reusable_landscape_telemetry.npz", **telemetry)
    print(json.dumps({"completed_worlds": result["completed_worlds"], "elapsed_seconds": result["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
