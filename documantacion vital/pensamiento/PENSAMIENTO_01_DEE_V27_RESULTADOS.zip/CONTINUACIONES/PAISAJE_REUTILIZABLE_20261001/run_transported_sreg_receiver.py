#!/usr/bin/env python3
"""Native use of the s_reg history transported by the prior R14 chain.

The receiver is a pre-existing v27 fusion/DEMUX context.  Its bias carrier,
six persistent observer supports, and the later query carrier all exist at t0.
After t0 the host only ticks and reads the official kernel.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
for path in (HERE, ZIP_ROOT):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import json_dump, sha256_array  # noqa: E402
from pilot_pensamiento01 import A, World, add, load_kernel, pack, place_arrival, read  # noqa: E402
from run_pensamiento01_chain import build_tree  # noqa: E402

N = 111
ROOT = (55, 55, 55)
P_KERNEL = 19665
CAP = 19664
BIAS_SREG = 18353
RECEIVER_TRAVEL = 10
BIAS_DIR = (1, 1, 1)
QUERY_DIR = (0, 0, 1)
SUPPORT_OFFSETS = (
    (1, -1, -1), (1, -1, 0), (1, -1, 1),
    (1, 0, -1), (1, 0, 0), (1, 0, 1),
)
CHECKPOINTS = (0, 30, 38, 47, 48, 49, 50, 51, 52, 55, 57)

CASES = (
    {"id": "LOW_00011_INTACT_QUERY", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "query": True, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_INTACT_QUERY", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "query": True, "translation": (0, 0, 0)},
    {"id": "MID_00111_INTACT_QUERY", "bits": (0, 0, 1, 1, 1), "receiver": "intact", "query": True, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_BIAS_CUT_QUERY", "bits": (0, 1, 1, 1, 1), "receiver": "bias_cut", "query": True, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_BIAS_SHAM_QUERY", "bits": (0, 1, 1, 1, 1), "receiver": "bias_sham", "query": True, "translation": (0, 0, 0)},
    {"id": "LOW_00011_INTACT_NO_QUERY", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "query": False, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_INTACT_NO_QUERY", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "query": False, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_TRANSLATED_QUERY", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "query": True, "translation": (0, 8, 5)},
    {"id": "LOW_00011_CHAIN_Q1_Q2", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "query": True, "query2": True, "translation": (0, 0, 0)},
    {"id": "LOW_00011_Q2_ONLY", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "query": False, "query2": True, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_CHAIN_Q1_Q2", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "query": True, "query2": True, "translation": (0, 0, 0)},
    {"id": "HIGH_01111_Q2_ONLY", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "query": False, "query2": True, "translation": (0, 0, 0)},
)


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0, label=""):
    if int(raw[q]):
        raise RuntimeError(f"receiver overlap {q}: {label}, existing={read(raw, q)}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def active_leaf(tree, bits):
    branch = 0
    for bit in bits[:-1]:
        branch = 2 * branch + int(bit)
    node = next(row for row in tree["nodes"] if row["depth"] == len(bits) and row["branch_index"] == branch)
    norm = tuple(node["norm1"] if bits[-1] else node["norm0"])
    update_tick = int(node["t1"]) + 3
    return node, norm, update_tick


def torus_add(q, offset):
    return tuple((int(q[i]) + int(offset[i])) % N for i in range(3))


def build_case(kernel, spec):
    raw = np.zeros((N, N, N), np.uint64)
    clock = np.zeros_like(raw)
    translated_root = torus_add(ROOT, spec["translation"])
    tree = build_tree(raw, clock, translated_root, spec["bits"], t1_root=3, gap=5, mode="intact")
    node, final_norm, update_tick = active_leaf(tree, spec["bits"])
    receiver_target = add(final_norm, A, RECEIVER_TRAVEL, N)
    collision_tick = update_tick + RECEIVER_TRAVEL
    evaluation_tick = collision_tick + 1
    # Empty clocks are fundamental Q0 fields.  This phase makes the occupied
    # target see clock=391 on its first material update after the collision.
    receiver_phase = 391 - collision_tick
    clock[receiver_target] = np.uint64(receiver_phase)

    supports = []
    for index, offset in enumerate(SUPPORT_OFFSETS):
        q = torus_add(receiver_target, offset)
        put(raw, clock, q, 9000 + index, 0, semantic=4, phase=0, label=f"receiver_support_{index}")
        supports.append(q)

    bias_target = receiver_target
    if spec["receiver"] == "bias_sham":
        bias_target = torus_add(receiver_target, (0, 8, 0))
    bias_source = None
    if spec["receiver"] != "bias_cut":
        bias_source = place_arrival(raw, clock, bias_target, collision_tick, BIAS_DIR,
                                    70000, BIAS_SREG, 1, "receiver_bias")

    demux_target = torus_add(receiver_target, (-1, -1, -1))
    query_tick = evaluation_tick + 1
    query_source = None
    if spec["query"]:
        query_source = place_arrival(raw, clock, demux_target, query_tick, QUERY_DIR,
                                     71000, 23, 1, "later_query")
    query2_target = torus_add(demux_target, (0, 0, 1))
    query2_tick = query_tick + 1
    query2_source = None
    if spec.get("query2", False):
        query2_source = place_arrival(raw, clock, query2_target, query2_tick, (0, 0, -1),
                                     72000, 29, 1, "second_later_query")

    return World(kernel, raw, clock), tree, {
        "translated_root": list(translated_root),
        "active_leaf_node": node,
        "final_norm": list(final_norm),
        "update_tick": update_tick,
        "receiver_target": list(receiver_target),
        "receiver_phase": receiver_phase,
        "collision_tick": collision_tick,
        "evaluation_tick": evaluation_tick,
        "demux_target": list(demux_target),
        "query_tick": query_tick,
        "query2_target": list(query2_target),
        "query2_tick": query2_tick,
        "bias_target": list(bias_target),
        "bias_source": None if bias_source is None else list(bias_source),
        "query_source": None if query_source is None else list(query_source),
        "query2_source": None if query2_source is None else list(query2_source),
        "supports": [list(q) for q in supports],
    }


def neighborhood_records(raw, center, radius=2):
    rows = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = torus_add(center, (dx, dy, dz))
                rec = read(raw, q)
                if rec is not None:
                    rows.append({"offset": [dx, dy, dz], "q": list(q), **rec})
    return rows


def run_case(kernel, spec, telemetry):
    world, tree, apparatus = build_case(kernel, spec)
    receiver_target = tuple(apparatus["receiver_target"])
    demux_target = tuple(apparatus["demux_target"])
    query2_target = tuple(apparatus["query2_target"])
    final_norm = tuple(apparatus["final_norm"])
    trace, kernel_events = [], []
    for tick in range(0, 58):
        if tick in CHECKPOINTS:
            center_records = {
                "final_norm": read(world.raw_a, final_norm),
                "receiver_target": read(world.raw_a, receiver_target),
                "demux_target": read(world.raw_a, demux_target),
                "query2_target": read(world.raw_a, query2_target),
            }
            trace.append({
                "tick": tick,
                "raw_support": int(np.count_nonzero(world.raw_a)),
                "raw_sha256": sha256_array(world.raw_a),
                "clock_sha256": sha256_array(world.clock_a),
                "records": center_records,
                "receiver_neighborhood": neighborhood_records(world.raw_a, receiver_target),
            })
            if spec["id"] in ("LOW_00011_INTACT_QUERY", "HIGH_01111_INTACT_QUERY") and tick in (38, 48, 49, 50, 55):
                telemetry[f"{spec['id']}_t{tick}_raw"] = world.raw_a.copy()
                telemetry[f"{spec['id']}_t{tick}_clock"] = world.clock_a.copy()
            if spec["id"] in ("LOW_00011_INTACT_NO_QUERY", "HIGH_01111_INTACT_NO_QUERY") and tick in (50, 55):
                telemetry[f"{spec['id']}_t{tick}_raw"] = world.raw_a.copy()
            chain_ids = {
                "LOW_00011_INTACT_QUERY", "LOW_00011_INTACT_NO_QUERY", "LOW_00011_CHAIN_Q1_Q2", "LOW_00011_Q2_ONLY",
                "HIGH_01111_INTACT_QUERY", "HIGH_01111_INTACT_NO_QUERY", "HIGH_01111_CHAIN_Q1_Q2", "HIGH_01111_Q2_ONLY",
            }
            if spec["id"] in chain_ids and tick in (51, 57):
                telemetry[f"{spec['id']}_t{tick}_raw"] = world.raw_a.copy()
        if tick == 57:
            break
        report = world.tick()
        if any(int(report.get(key, 0)) for key in ("colisiones", "overflows", "genesis")):
            kernel_events.append({"tick": tick + 1, **report})
    return {
        "case": spec,
        "apparatus": apparatus,
        "expected_transport_sreg_apparatus_relation": 7 + 212 * len(spec["bits"]) + 61 * sum(spec["bits"]),
        "trace": trace,
        "kernel_events": kernel_events,
        "python_interventions_after_t0": 0,
    }


def trace_by_tick(case):
    return {int(row["tick"]): row for row in case["trace"]}


def compare_cases(cases):
    by_id = {row["case"]["id"]: row for row in cases}
    comparisons = {}
    pairs = {
        "high_vs_low": ("HIGH_01111_INTACT_QUERY", "LOW_00011_INTACT_QUERY"),
        "high_vs_mid": ("HIGH_01111_INTACT_QUERY", "MID_00111_INTACT_QUERY"),
        "high_vs_bias_cut": ("HIGH_01111_INTACT_QUERY", "HIGH_01111_BIAS_CUT_QUERY"),
        "high_vs_bias_sham": ("HIGH_01111_INTACT_QUERY", "HIGH_01111_BIAS_SHAM_QUERY"),
    }
    for label, (left_id, right_id) in pairs.items():
        left, right = trace_by_tick(by_id[left_id]), trace_by_tick(by_id[right_id])
        comparisons[label] = {
            str(tick): {
                "left_receiver": left[tick]["records"]["receiver_target"],
                "right_receiver": right[tick]["records"]["receiver_target"],
                "left_demux": left[tick]["records"]["demux_target"],
                "right_demux": right[tick]["records"]["demux_target"],
                "raw_hash_equal": left[tick]["raw_sha256"] == right[tick]["raw_sha256"],
            }
            for tick in (38, 48, 49, 50, 52, 55, 57)
        }
    for label, query_id, noquery_id in (
        ("later_query_effect_low", "LOW_00011_INTACT_QUERY", "LOW_00011_INTACT_NO_QUERY"),
        ("later_query_effect_high", "HIGH_01111_INTACT_QUERY", "HIGH_01111_INTACT_NO_QUERY"),
    ):
        q, nq = trace_by_tick(by_id[query_id]), trace_by_tick(by_id[noquery_id])
        comparisons[label] = {
            str(tick): {
                "raw_hash_equal": q[tick]["raw_sha256"] == nq[tick]["raw_sha256"],
                "query_demux_site": q[tick]["records"]["demux_target"],
                "noquery_demux_site": nq[tick]["records"]["demux_target"],
            }
            for tick in (48, 49, 50, 52, 55, 57)
        }
    return comparisons


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    started = time.time()
    kernel, runtime = load_kernel()
    if args.threads != 1:
        kernel.set_num_threads(int(args.threads))
    telemetry = {}
    cases = [run_case(kernel, spec, telemetry) for spec in CASES]
    query_global_raw_effects = {}
    for label in ("LOW_00011", "HIGH_01111"):
        for tick in (50, 55):
            query = telemetry[f"{label}_INTACT_QUERY_t{tick}_raw"]
            noquery = telemetry[f"{label}_INTACT_NO_QUERY_t{tick}_raw"]
            query_global_raw_effects[f"{label}_t{tick}"] = {
                "raw_diff_positions": int(np.count_nonzero(query != noquery)),
                "raw_xor_sha256": sha256_array(np.bitwise_xor(query, noquery)),
            }
    second_query_effects = {}
    for label in ("LOW_00011", "HIGH_01111"):
        for tick in (51, 57):
            no_q1 = np.bitwise_xor(
                telemetry[f"{label}_Q2_ONLY_t{tick}_raw"],
                telemetry[f"{label}_INTACT_NO_QUERY_t{tick}_raw"],
            )
            with_q1 = np.bitwise_xor(
                telemetry[f"{label}_CHAIN_Q1_Q2_t{tick}_raw"],
                telemetry[f"{label}_INTACT_QUERY_t{tick}_raw"],
            )
            second_query_effects[f"{label}_t{tick}"] = {
                "Q2_effect_without_Q1_positions": int(np.count_nonzero(no_q1)),
                "Q2_effect_with_Q1_positions": int(np.count_nonzero(with_q1)),
                "Q1_changes_Q2_effect_positions": int(np.count_nonzero(no_q1 != with_q1)),
                "Q2_effect_without_Q1_sha256": sha256_array(no_q1),
                "Q2_effect_with_Q1_sha256": sha256_array(with_q1),
            }
    result = {
        "campaign": "PENSAMIENTO_01_CONTINUACION_TRANSPORTED_SREG_NATIVE_RECEIVER_20261001",
        "runtime": runtime,
        "elapsed_seconds": time.time() - started,
        "config": {
            "n": N, "root": list(ROOT), "P_KERNEL": P_KERNEL, "cap": CAP,
            "bias_sreg": BIAS_SREG, "receiver_travel": RECEIVER_TRAVEL,
            "support_offsets": [list(x) for x in SUPPORT_OFFSETS],
            "checkpoints": list(CHECKPOINTS),
            "post_t0_host_calls": ["tick", "read", "hash", "checkpoint", "log", "stop"],
        },
        "completed_worlds": len(cases),
        "partial_worlds": 0,
        "cases": cases,
        "comparisons": compare_cases(cases),
        "query_global_raw_effects": query_global_raw_effects,
        "second_query_effects": second_query_effects,
        "measurement_note": "The apparatus relation is checked as a domain-specific accounting identity; scientific interpretation is left open.",
    }
    json_dump(HERE / "transported_sreg_receiver_results.json", result)
    np.savez_compressed(HERE / "transported_sreg_receiver_telemetry.npz", **telemetry)
    print(json.dumps({"completed_worlds": len(cases), "elapsed_seconds": result["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
