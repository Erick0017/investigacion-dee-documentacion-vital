# Reproducción breve

Desde esta carpeta y con el Python CPython 3.13 ya configurado:

1. `python -I -B run_temporal_plasticity.py --output .` reproduce el intento de entrada ocluido.
2. `python -I -B run_temporal_plasticity_v2_preloaded.py --output .` reproduce trenes y reutilización.
3. `python -I -B run_native_return_stream.py --output .` reproduce el retorno con fuente persistente.
4. `python -I -B analyze_plasticity_temporal_return.py` recalcula el resumen y el informe sin llamar al kernel.

Los runners resuelven los helpers heredados dentro del mismo ZIP. El WHL no se duplica; su ruta e identidad están en `continuation_config.json`.
