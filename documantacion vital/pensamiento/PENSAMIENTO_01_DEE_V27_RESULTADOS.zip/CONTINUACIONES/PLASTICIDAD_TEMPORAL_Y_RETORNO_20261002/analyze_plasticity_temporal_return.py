#!/usr/bin/env python3
"""Derived analysis over the three executed blocks; no kernel calls."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def load_json(name):
    return json.loads((HERE / name).read_text(encoding="utf-8"))


def dump(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                             encoding="utf-8")


def sha256_bytes(data: bytes):
    return hashlib.sha256(data).hexdigest()


def array_diff(left, right):
    mask = left != right
    return {"positions": int(np.count_nonzero(mask)),
            "mask_sha256": sha256_bytes(np.ascontiguousarray(mask).tobytes())}


def query_h16(case):
    q = case["diagnostic_query"]
    if not q.get("measurement_available"):
        return {"available": False, "reason": q.get("reason")}
    e = q["horizons"]["16"]["effect"]
    return {"available": True, "raw_diff_positions": e["raw_diff_positions"],
            "raw_xor_sha256": e["raw_xor_sha256"]}


def trace_case(return_data, case_id):
    return next(case for case in return_data["cases"] if case["case_id"] == case_id)


def record_key(record):
    if record is None:
        return None
    return (record["state"], record["sreg"], tuple(record["direction"]), record["semantic"])


def main():
    blocked = load_json("temporal_plasticity_results.json")
    temporal = load_json("temporal_trains_reuse_results.json")
    ret = load_json("native_return_stream_results.json")
    tnpz = np.load(HERE / "temporal_trains_reuse_telemetry.npz", allow_pickle=False)

    blocked_cases = []
    for case in blocked["single_sequence_cases"]:
        blocked_cases.append({"case_id": case["case_id"],
                              "realized": case["host_writes_realized"],
                              "attempted": case["host_writes_attempted"]})
    for case in blocked["continuous_reuse_cases"]:
        blocked_cases.append({"case_id": case["case_id"],
                              "realized_by_phase": [p["host_writes_realized"] for p in case["phases"]],
                              "attempted_by_phase": [p["host_writes_attempted"] for p in case["phases"]]})

    single = {case["case_id"]: case for case in temporal["single_sequence_cases"]}
    reuse = {case["case_id"]: case for case in temporal["continuous_reuse_cases"]}
    trained_ids = ["ORDER_S1", "ORDER_S2", "LOW_ORDER_ALT", "DOSE_A10_B6", "RHYTHM_S1"]
    trained_queries = {case_id: query_h16(single[case_id]) for case_id in trained_ids}
    trained_hashes = {value["raw_xor_sha256"] for value in trained_queries.values() if value["available"]}
    noexp_query = query_h16(single["NO_EXPERIENCE"])

    single_stability = {}
    for case_id in list(single):
        single_stability[case_id] = {
            "raw": array_diff(tnpz[f"{case_id}__checkpoint_raw"], tnpz[f"{case_id}__final_raw"]),
            "clock": array_diff(tnpz[f"{case_id}__checkpoint_clock"], tnpz[f"{case_id}__final_clock"]),
        }

    reuse_phase_comparisons = {}
    for left, right in (("S1_S2_S1", "S1_S1_S1"), ("S1_S2_S1", "S2_S1_S2")):
        reuse_phase_comparisons[f"{left}__vs__{right}"] = {
            f"phase_{phase}": array_diff(tnpz[f"{left}__phase{phase}_raw"],
                                          tnpz[f"{right}__phase{phase}_raw"])
            for phase in (1, 2, 3)
        }
    reuse_query = {
        case_id: [query_h16({"diagnostic_query": phase["diagnostic_query"]})
                  for phase in case["phases"]]
        for case_id, case in reuse.items()
    }

    low_stream = trace_case(ret, "LOW_00011_STREAM")
    high_stream = trace_case(ret, "HIGH_01111_STREAM")
    low_no = trace_case(ret, "LOW_00011_NO_STREAM")
    high_no = trace_case(ret, "HIGH_01111_NO_STREAM")
    high_cut = trace_case(ret, "HIGH_01111_BIAS_CUT_STREAM")
    high_sham_bias = trace_case(ret, "HIGH_01111_BIAS_SHAM_STREAM")
    high_sham_route = trace_case(ret, "HIGH_01111_STREAM_SHAM_ROUTE")

    def d_record(case, tick, key):
        return case["trace"][tick]["records"][key]

    pulse_ticks = {}
    for case in (low_stream, high_stream, low_no, high_no, high_cut, high_sham_bias, high_sham_route):
        pulse_ticks[case["case_id"]] = [
            tick for tick in range(50, 71)
            if (lambda r: r is not None and r["sreg"] == 23 and r["direction"] == [1, 1, 1])(
                d_record(case, tick, "demux_target"))
        ]

    receiver_unchanged = {}
    for label, stream_case, no_case in (("low", low_stream, low_no), ("high", high_stream, high_no)):
        receiver_unchanged[label] = {
            "all_equal_t50_t70": all(
                record_key(d_record(stream_case, tick, "receiver_target")) ==
                record_key(d_record(no_case, tick, "receiver_target"))
                for tick in range(50, 71)
            ),
            "compared_ticks": list(range(50, 71)),
        }

    return_observations = {
        "roi_nonperturbation_before_arrival": {
            "checkpoints": [0, 16, 32],
            "low_stream_vs_no_stream_raw_diff": [
                ret["comparisons"]["low_stream_vs_no_stream"]["checkpoint_timeline"][str(t)]["raw_diff_positions"]
                for t in (0, 16, 32)],
            "high_stream_vs_no_stream_raw_diff": [
                ret["comparisons"]["high_stream_vs_no_stream"]["checkpoint_timeline"][str(t)]["raw_diff_positions"]
                for t in (0, 16, 32)],
        },
        "demux_pulse_ticks_t50_t70": pulse_ticks,
        "selective_first_pulse": {
            "low_t50": d_record(low_stream, 50, "demux_target"),
            "high_t50": d_record(high_stream, 50, "demux_target"),
            "high_bias_cut_t50": d_record(high_cut, 50, "demux_target"),
            "high_bias_sham_t50": d_record(high_sham_bias, 50, "demux_target"),
            "high_sham_route_t50": d_record(high_sham_route, 50, "demux_target"),
        },
        "receiver_stream_vs_no_stream": receiver_unchanged,
        "measured_interpretation": (
            "The history-conditioned receiver consequence changes admission of the first supply pulse at the "
            "DEMUX interface. Later pulses pass in both histories. No retained receiver rewrite was measured "
            "through t70."
        ),
    }

    summary = {
        "campaign_id": "PENSAMIENTO_01_PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002",
        "case_accounting": {
            "completed_cases": 16,
            "partial_cases": 9,
            "completed_definition": "9 corrected temporal/reuse protocols plus 7 native-return worlds",
            "partial_definition": "9 initial input-site protocols whose intended 16-event exposure was occluded",
            "diagnostic_clones_counted_as_cases": False,
        },
        "instrumentation_correction": {
            "initial_attempts": blocked_cases,
            "cause": "prior event dynamics occupied the single host-write input sites",
            "scientific_use": "retained as input-occlusion telemetry; excluded from matched-sequence attribution",
            "corrected_architecture": "t0 causal input trains with fixed ports, phase and payload; no clearing/reset",
        },
        "temporal_structure": {
            "matched_order_constraints": {
                "S1": temporal["single_sequence_cases"][0]["statistics"],
                "S2": temporal["single_sequence_cases"][1]["statistics"],
            },
            "checkpoint_raw_differences": temporal["cross_case_comparisons"],
            "frozen_query_h16": trained_queries,
            "trained_query_effect_hash_count": len(trained_hashes),
            "all_trained_histories_same_query_effect_h16": len(trained_hashes) == 1,
            "no_experience_query_h16": noexp_query,
            "no_experience_effect_differs_from_trained": noexp_query.get("raw_xor_sha256") not in trained_hashes,
            "post_host_stability": single_stability,
        },
        "reuse": {
            "all_phase_input_trains_realized_16_of_16": all(
                all(p["writes_realized"] == 16 for p in case["phases"]) for case in reuse.values()),
            "reset_count_each": {case_id: case["reset_count"] for case_id, case in reuse.items()},
            "phase_raw_comparisons": reuse_phase_comparisons,
            "phase_query_h16": reuse_query,
            "raw_support_by_phase": {
                case_id: [p["end_readout"]["world"]["raw_support"] for p in case["phases"]]
                for case_id, case in reuse.items()},
            "observed_relations": {
                "S1_S2_S1_equals_S1_S1_S1_after_each_phase": all(
                    v["positions"] == 0 for v in reuse_phase_comparisons["S1_S2_S1__vs__S1_S1_S1"].values()),
                "S1_S2_vs_S1_S1_phase2_raw_difference":
                    reuse_phase_comparisons["S1_S2_S1__vs__S1_S1_S1"]["phase_2"],
                "S1_S2_S1_vs_S1_S1_S1_phase3_converged":
                    reuse_phase_comparisons["S1_S2_S1__vs__S1_S1_S1"]["phase_3"]["positions"] == 0,
                "S1_first_vs_S2_first_phase1_raw_difference":
                    reuse_phase_comparisons["S1_S2_S1__vs__S2_S1_S2"]["phase_1"],
                "same_phase1_query_effect_despite_raw_difference":
                    reuse_query["S1_S2_S1"][0] == reuse_query["S2_S1_S2"][0],
                "phase2_query_effect_differs_after_reversed_block_order":
                    reuse_query["S1_S2_S1"][1] != reuse_query["S2_S1_S2"][1],
            },
        },
        "native_return": return_observations,
        "host_contract": {
            "temporal_experience": "writes only while installing each declared input train; post HOST_STOP tick/read only",
            "native_return": "all components at t0; t1..t70 tick/read only",
            "kernel_substitution": False,
        },
        "runtime_seconds": {
            "occluded_input_attempt": blocked["elapsed_seconds"],
            "corrected_temporal_reuse": temporal["elapsed_seconds"],
            "native_return": ret["elapsed_seconds"],
            "total_kernel_blocks": blocked["elapsed_seconds"] + temporal["elapsed_seconds"] + ret["elapsed_seconds"],
        },
    }
    dump("MEASUREMENT_SUMMARY.json", summary)

    config = {
        "campaign_id": summary["campaign_id"],
        "author": "Ivan Erick Tlaltecatl Morales",
        "kernel": temporal["environment"],
        "sequences": {case["case_id"]: {"symbols": case["symbols"], "arrivals": case["arrivals"]}
                      for case in temporal["single_sequence_cases"]},
        "reuse_protocols": {case_id: case["phase_sequence"] for case_id, case in reuse.items()},
        "return_config": ret["config"],
        "random_seed": "NOT_APPLICABLE_DETERMINISTIC_PREPARATIONS",
        "post_host_forbidden_operations_observed": 0,
    }
    dump("continuation_config.json", config)
    dump("EXECUTION_LOG.json", {
        "blocks": [
            {"runner": "run_temporal_plasticity.py", "status": "COMPLETED_WITH_INPUT_OCCLUSION",
             "cases_reclassified_partial": 9, "elapsed_seconds": blocked["elapsed_seconds"]},
            {"runner": "run_temporal_plasticity_v2_preloaded.py", "status": "COMPLETED",
             "completed_cases": 9, "elapsed_seconds": temporal["elapsed_seconds"]},
            {"runner": "run_native_return_stream.py", "status": "COMPLETED",
             "completed_cases": 7, "elapsed_seconds": ret["elapsed_seconds"]},
        ],
        "completed_cases": 16, "partial_cases": 9,
    })

    report = f"""# PENSAMIENTO 01 — Plasticidad temporal y retorno causal

## Pregunta examinada

Se examinó si experiencias temporales con igual inventario físico podían dejar organizaciones distintas, si el mismo medio y sus mismos corredores aceptaban historia adicional sin reset, y si una consecuencia histórica ya heredada podía modular un encuentro posterior generado por un suministro persistente preinstalado.

## Preparaciones e intervenciones

El primer intento escribió cada evento sucesivo en un único sitio de entrada. El medio ocupó esos sitios después de 2–4 eventos; en las fases de reutilización posteriores realizó 0/16 escrituras. Los nueve protocolos terminaron computacionalmente, pero su exposición prevista quedó parcial. Se conservan como telemetría de oclusión y no se usan para atribuir un efecto al orden.

La corrección instaló trenes causales en t0, con un mismo par de puertos, `clock=17`, `s_reg=3` y estados de alfabeto A/B. S1=`AABBBAABBAABBAAB` y S2=`ABAAABBBABBBAAAB` tienen longitud 16, ocho A y ocho B, final AB, duración 35 ticks y los mismos conteos AA=4, AB=4, BA=3, BB=4. También se ejecutaron controles de estructura local, dosis, ritmo y ausencia de experiencia. El máximo recorrido 35 satisface 35 < N/2=36.5.

La reutilización ejecutó S1→S2→S1, S1→S1→S1 y S2→S1→S2 sobre el mismo mundo. Cada fase volvió a usar los mismos 16 sitios de corredor: 16/16 escrituras en las nueve fases, sin borrado, reset ni copia limpia. Las sondas de seis ejes se aplicaron sólo a clones diagnósticos congelados.

El retorno usó el receptor fusion/DEMUX heredado de la continuación anterior. Una fuente `semantic=4`, presente en t0 a distancia 50 y con dirección (1,1,1), suministró portadores `s_reg=23`. Se compararon historias baja y alta, suministro cortado, bias cortado/desviado y ruta del suministro desviada. Desde t1 hasta t70 sólo se llamó al kernel y se leyó.

## Mediciones y contrastes

### Estructura temporal

En t35, S1 y S2 difirieron en 96 posiciones RAW pese a igual dosis, duración, último evento y conteos de pares. S1 frente al control de dosis difirió en 89 posiciones; frente al ritmo alternado, en 3. S2 y el control alternante convergieron bajo esta preparación, de modo que una diferencia de secuencia no garantiza una organización distinta para todo par.

El observador antiguo (`memory_delta_sreg`, dirección del comparador) fue 0/0 en todos los tratamientos. La consulta congelada produjo a h16 diez posiciones RAW de efecto y el mismo hash XOR en S1, S2, alternante, dosis y ritmo. El control sin experiencia produjo once posiciones y otro hash. Por tanto, X_FULL retuvo distinciones entre varias experiencias, pero esta consulta no distinguió su contenido; sí distinguió experiencia frente a ausencia de experiencia.

Durante los 24 ticks posteriores a HOST_STOP el conteo de soporte se mantuvo, pero RAW no quedó congelado: cambiaron 78–86 posiciones en los cinco tratamientos con experiencia y 12 en el control sin experiencia; el clock avanzó en toda la retícula (389017 posiciones). La ventana documenta organización persistente con dinámica interna, no un estado RAW fijo.

### Reutilización y uso posterior

El soporte RAW de S1→S2→S1 y S1→S1→S1 fue 167→250→301. Tras la primera fase eran idénticos; tras la segunda, sustituir S1 por S2 dejó 16 posiciones RAW diferentes, pero la consulta siguió siendo idéntica (30 posiciones y el mismo hash). Tras la tercera S1, ambos mundos convergieron exactamente en RAW y en la consulta (7 posiciones). La modificación intermedia existió, quedó oculta para esa lectura y no sobrevivió a la siguiente experiencia común.

S2→S1→S2 dejó 171→257→316 posiciones de soporte y se mantuvo distinto. Tras la primera fase, S1 y S2 tenían X_FULL distintos pero la misma consulta h16 (10 posiciones, mismo hash). Después de la segunda experiencia, las consultas divergieron: 30 posiciones para S1→S2 (idéntico a S1→S1) y 13 para S2→S1, con hashes diferentes. A la tercera fase fueron 7 y 42. Esta es una observación de dependencia del orden de bloques en una lectura futura, con igual inventario total A/B y sin reset; no prueba conservación universal de cada secuencia.

La respuesta a repetir S1 cambió 10→30→7 posiciones entre fases. Es una modificación de respuesta bajo dosis/edad/contexto acumulado; no debe confundirse con aprendizaje del contenido de S1, porque la lectura congelada no separó S1 de S2 en un medio fresco.

### Retorno nativo

En la ROI de la interfaz, los mundos con y sin fuente fueron idénticos en t0, t16 y t32. La fuente empezó a aparecer localmente antes del encuentro nominal (una posición distinta en t47), sin alterar la transición heredada del receptor: la historia baja produjo `s_reg=19543`, y la alta alcanzó cap y DEMUX (`s_reg=0`) en t49.

En t50 la historia baja admitió en el sitio DEMUX un portador `state=1, s_reg=23, direction=(1,1,1)`. La historia alta no lo admitió. Cortar o desviar el bias restauró el portador en t50; cortar la fuente o desviar su ruta lo eliminó. Los pulsos siguientes aparecieron cada dos ticks: baja registró 11 encuentros en t50–t70; alta registró 10, desde t52. El efecto selectivo fue, por tanto, la pérdida del primer pulso, no la eliminación permanente del flujo.

El registro del centro receptor fue idéntico con y sin fuente en todos los ticks t50–t70 para cada historia. La consecuencia condicionó un encuentro posterior en la interfaz, pero no produjo en esta ventana una nueva escritura retenida del centro. No se observó un ciclo recurrente de actualización; se midió un enlace de retorno único dentro de un suministro persistente.

## Observaciones inesperadas

La diferencia microscópica S1/S2 estuvo oculta para la consulta tras una fase, pero la precedencia S1→S2 frente a S2→S1 se volvió visible tras una experiencia adicional. En contraste, S1→S2 colapsó exactamente sobre S1→S1. La sensibilidad al orden es así contextual y no una etiqueta fija de la secuencia.

La fuente persistente emitió en cadencia de dos ticks y el DEMUX histórico suprimió sólo su primer encuentro. La ruta no quedó cerrada permanentemente.

## Hipótesis de mecanismo compatibles

1. La primera fase lleva el medio a organizaciones distintas que el observer de seis ejes fusiona; la segunda fase interactúa no conmutativamente con una de ellas y hace reaparecer la distinción.
2. S1 puede llevar el aparato a una cuenca en la que S1 y S2 son equivalentes, mientras S2 lleva a una organización desde la que la siguiente experiencia mantiene otra trayectoria.
3. En el retorno, el estado DEMUX de t49 actúa como condición transitoria de admisión: intercepta el primer portador y luego deja pasar la cadencia persistente.

## Explicaciones alternativas y límites

La consulta congelada puede ser demasiado pobre para otras diferencias funcionales; igualdad bajo ella no implica igualdad causal. El cambio 10→30→7 también depende de edad y dosis acumulada, no sólo del nombre del bloque. No se midió transferencia a otra geometría ni generalización estadística.

El retorno usa una fuente preinstalada: demuestra acoplamiento con suministro, no generación endógena del suministro. El portador admitido no reescribió el centro en t50–t70, por lo que la cadena no alcanzó una nueva modificación histórica retenida ni tres ciclos adaptativos completos.

## Aspectos no ejecutados o no medidos

No se abrió una tercera familia, no se entrenó un clasificador externo, no se reiniciaron clocks ni se ablacionó exhaustivamente el paisaje. No se usó una serie sísmica real. El tratado 4.0.1 no fue relocalizado en la búsqueda dirigida heredada; se trabajó con código y resultados primarios ya integrados en el ZIP acumulativo.

## Correspondencia con antecedentes reutilizados

El medio temporal procede del aparato de memoria relativa de Ingeniería 02; el criterio de comparar efectos de una misma consulta y la no aditividad siguen NRD05/NRD06 e Ingeniería 06. El receptor transportado y su identidad `s_j = 7 + 212j + 61Σb` se reutilizaron de la continuación anterior únicamente en su dominio validado. La nueva evidencia añade (a) secuencias de 16 eventos, (b) tres fases sobre el mismo medio/corredor, (c) reaparición funcional después de una segunda experiencia y (d) un suministro persistente cuyo primer encuentro es modulado por la consecuencia DEMUX.

Esta continuación registra 16 casos completos y 9 parciales de instrumentación. No contiene adjudicación global de pensamiento, autonomía o nivel promocional.
"""
    (HERE / "SCIENTIFIC_REPORT_CONTINUATION.md").write_text(report, encoding="utf-8")

    reproduction = """# Reproducción breve

Desde esta carpeta y con el Python CPython 3.13 ya configurado:

1. `python -I -B run_temporal_plasticity.py --output .` reproduce el intento de entrada ocluido.
2. `python -I -B run_temporal_plasticity_v2_preloaded.py --output .` reproduce trenes y reutilización.
3. `python -I -B run_native_return_stream.py --output .` reproduce el retorno con fuente persistente.
4. `python -I -B analyze_plasticity_temporal_return.py` recalcula el resumen y el informe sin llamar al kernel.

Los runners resuelven los helpers heredados dentro del mismo ZIP. El WHL no se duplica; su ruta e identidad están en `continuation_config.json`.
"""
    (HERE / "REPRODUCTION.md").write_text(reproduction, encoding="utf-8")

    dump("SOURCE_REFERENCES.json", {
        "reused_internal_sources": [
            "CONTINUACIONES/PAISAJE_REUTILIZABLE_20261001/continuation_common.py",
            "CONTINUACIONES/PAISAJE_REUTILIZABLE_20261001/run_transported_sreg_receiver.py",
            "pilot_pensamiento01.py",
            "run_pensamiento01_chain.py",
        ],
        "primary_prior_mechanisms": [
            "Ingenieria 02 temporal-order apparatus",
            "Ingenieria 05 NRD05/NRD06 query-effect logic",
            "PENSAMIENTO 01 transported s_reg fusion/DEMUX receiver",
        ],
        "DEE_V4_0_1_1_docx": "NOT_LOCATED_IN_PRIOR_TARGETED_SEARCH; not used as a primary source",
    })


if __name__ == "__main__":
    main()
