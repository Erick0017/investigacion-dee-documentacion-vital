#!/usr/bin/env python3
"""Build and atomically replace the cumulative PENSAMIENTO 01 ZIP."""
from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
TESTS = STAGE.parents[1]
OFFICIAL = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"
WORK = TESTS / "PENSAMIENTO_01_CONT_20261002"
TEMP_ZIP = WORK / "PENSAMIENTO_01_DEE_V27_RESULTADOS.tmp.zip"
CONT_PREFIX = "CONTINUACIONES/PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002/"


def digest_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def digest_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def write_json(path: Path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
                    encoding="utf-8")


def rel_files(root: Path):
    return sorted((p for p in root.rglob("*") if p.is_file()), key=lambda p: p.relative_to(root).as_posix())


def main():
    if not OFFICIAL.is_file():
        raise RuntimeError(f"official parent missing: {OFFICIAL}")
    parent_sha = digest_file(OFFICIAL)
    with zipfile.ZipFile(OFFICIAL, "r") as parent:
        bad = parent.testzip()
        if bad:
            raise RuntimeError(f"parent archive corrupt at {bad}")
        parent_names = parent.namelist()
        changed_allowed = {"CUMULATIVE_INDEX.md", "CUMULATIVE_MANIFEST.json"}
        historical_mismatches = []
        for name in parent_names:
            if name.endswith("/") or name in changed_allowed:
                continue
            staged = STAGE / Path(name)
            if not staged.is_file():
                historical_mismatches.append({"path": name, "reason": "missing_from_stage"})
                continue
            if digest_bytes(parent.read(name)) != digest_file(staged):
                historical_mismatches.append({"path": name, "reason": "content_changed"})
        if historical_mismatches:
            raise RuntimeError(f"historical preservation failed: {historical_mismatches[:5]}")

    summary = json.loads((HERE / "MEASUREMENT_SUMMARY.json").read_text(encoding="utf-8"))
    lock = {
        "parent_official_path": str(OFFICIAL),
        "parent_sha256": parent_sha,
        "parent_member_count": len(parent_names),
        "historical_members_checked": len([x for x in parent_names if not x.endswith('/')]) - 2,
        "historical_mismatches": [],
        "allowed_updated_root_members": sorted(changed_allowed),
    }
    write_json(HERE / "PARENT_PACKAGE_LOCK.json", lock)

    required = [
        "run_temporal_plasticity.py", "run_temporal_plasticity_v2_preloaded.py",
        "run_native_return_stream.py", "analyze_plasticity_temporal_return.py",
        "temporal_plasticity_results.json", "temporal_plasticity_telemetry.npz",
        "temporal_trains_reuse_results.json", "temporal_trains_reuse_telemetry.npz",
        "native_return_stream_results.json", "native_return_stream_telemetry.npz",
        "MEASUREMENT_SUMMARY.json", "SCIENTIFIC_REPORT_CONTINUATION.md",
        "continuation_config.json", "EXECUTION_LOG.json", "REPRODUCTION.md",
        "SOURCE_REFERENCES.json", "PARENT_PACKAGE_LOCK.json",
    ]
    missing = [name for name in required if not (HERE / name).is_file()]
    if missing:
        raise RuntimeError(f"required continuation files missing: {missing}")
    for name in ("temporal_plasticity_results.json", "temporal_trains_reuse_results.json",
                 "native_return_stream_results.json", "MEASUREMENT_SUMMARY.json"):
        json.loads((HERE / name).read_text(encoding="utf-8"))
    for name in ("temporal_plasticity_telemetry.npz", "temporal_trains_reuse_telemetry.npz",
                 "native_return_stream_telemetry.npz"):
        with __import__("numpy").load(HERE / name, allow_pickle=False) as arrays:
            if not arrays.files:
                raise RuntimeError(f"empty telemetry: {name}")

    validation = {
        "required_files_present": True,
        "json_parse_valid": True,
        "npz_readable": True,
        "historical_members_preserved": True,
        "completed_cases": summary["case_accounting"]["completed_cases"],
        "partial_cases": summary["case_accounting"]["partial_cases"],
        "scientific_global_verdict_generated": False,
        "pensamiento_02_opened": False,
    }
    write_json(HERE / "PACKAGE_VALIDATION.json", validation)

    hash_lines = []
    for path in rel_files(HERE):
        if path.name == "CONTINUATION_HASHES.sha256":
            continue
        rel = path.relative_to(HERE).as_posix()
        hash_lines.append(f"{digest_file(path)}  {rel}")
    (HERE / "CONTINUATION_HASHES.sha256").write_text("\n".join(hash_lines) + "\n", encoding="utf-8")

    members = []
    for path in rel_files(STAGE):
        rel = path.relative_to(STAGE).as_posix()
        if rel == "CUMULATIVE_MANIFEST.json":
            continue
        section = "current_continuation" if rel.startswith(CONT_PREFIX) else (
            "prior_continuation" if rel.startswith("CONTINUACIONES/") else "initial_campaign")
        members.append({"path": rel, "size": path.stat().st_size,
                        "sha256": digest_file(path), "section": section})
    manifest = {
        "campaign": "PENSAMIENTO_01_DEE_V27",
        "parent_zip_sha256": parent_sha,
        "continuations": ["PAISAJE_REUTILIZABLE_20261001", "PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002"],
        "current_continuation_completed_cases": 16,
        "current_continuation_partial_cases": 9,
        "member_hash_scope": "all members except this CUMULATIVE_MANIFEST.json",
        "members": members,
    }
    write_json(STAGE / "CUMULATIVE_MANIFEST.json", manifest)

    if TEMP_ZIP.exists():
        TEMP_ZIP.unlink()
    with zipfile.ZipFile(TEMP_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in rel_files(STAGE):
            archive.write(path, path.relative_to(STAGE).as_posix())
    with zipfile.ZipFile(TEMP_ZIP, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"temporary archive corrupt at {bad}")
        names = set(archive.namelist())
        expected = {p.relative_to(STAGE).as_posix() for p in rel_files(STAGE)}
        if names != expected:
            raise RuntimeError("temporary archive member set mismatch")
        hash_text = archive.read(CONT_PREFIX + "CONTINUATION_HASHES.sha256").decode("utf-8")
        for line in hash_text.splitlines():
            expected_hash, rel = line.split("  ", 1)
            member = CONT_PREFIX + rel
            if digest_bytes(archive.read(member)) != expected_hash:
                raise RuntimeError(f"continuation hash mismatch: {member}")

    temp_sha = digest_file(TEMP_ZIP)
    os.replace(TEMP_ZIP, OFFICIAL)
    if digest_file(OFFICIAL) != temp_sha:
        raise RuntimeError("official hash changed during replacement")
    with zipfile.ZipFile(OFFICIAL, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"official archive corrupt at {bad}")
    print(json.dumps({"official_path": str(OFFICIAL), "sha256": temp_sha,
                      "member_count": len(expected), "completed_cases": 16,
                      "partial_cases": 9}, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
