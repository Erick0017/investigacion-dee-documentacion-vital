#!/usr/bin/env python3
"""Preinstalled persistent supply crossing the inherited s_reg receiver.

This replaces the prior preloaded Q1/Q2 list with one general semantic-4
source present at t0.  After t0 every main world receives only v27 ticks and
passive reads.  The experiment measures whether the receiver consequence at
the DEMUX site changes the later encounter of that stream with the receiver.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
PREVIOUS = ZIP_ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
for path in (ZIP_ROOT, PREVIOUS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import (  # noqa: E402
    decoded_fields, effect_signature, json_dump, sha256_array,
)
from pilot_pensamiento01 import add, load_kernel, pack, read  # noqa: E402
import run_transported_sreg_receiver as inherited  # noqa: E402

CAMPAIGN = "PENSAMIENTO_01_NATIVE_RETURN_STREAM_20261002"
N = inherited.N
STREAM_DISTANCE = 50
STREAM_STATE = 73000
STREAM_SREG = 23
STREAM_DIR = (1, 1, 1)
SHAM_DIR = (1, 1, 0)
HORIZON = 70
FULL_CHECKPOINTS = (0, 16, 32, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 60, 64, 70)

CASES = (
    {"id": "LOW_00011_STREAM", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "stream": "intact"},
    {"id": "HIGH_01111_STREAM", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "stream": "intact"},
    {"id": "LOW_00011_NO_STREAM", "bits": (0, 0, 0, 1, 1), "receiver": "intact", "stream": "cut"},
    {"id": "HIGH_01111_NO_STREAM", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "stream": "cut"},
    {"id": "HIGH_01111_BIAS_CUT_STREAM", "bits": (0, 1, 1, 1, 1), "receiver": "bias_cut", "stream": "intact"},
    {"id": "HIGH_01111_BIAS_SHAM_STREAM", "bits": (0, 1, 1, 1, 1), "receiver": "bias_sham", "stream": "intact"},
    {"id": "HIGH_01111_STREAM_SHAM_ROUTE", "bits": (0, 1, 1, 1, 1), "receiver": "intact", "stream": "sham_route"},
)


def torus_add(q, offset):
    return tuple((int(q[i]) + int(offset[i])) % N for i in range(3))


def install_stream(world, apparatus, mode: str):
    if mode == "cut":
        return {"mode": mode, "installed": False, "source": None}
    demux = tuple(apparatus["demux_target"])
    source = add(demux, STREAM_DIR, -STREAM_DISTANCE, N)
    direction = STREAM_DIR if mode == "intact" else SHAM_DIR
    if int(world.raw_a[source]):
        raise RuntimeError(f"stream source overlap at {source}: {read(world.raw_a, source)}")
    value = pack(STREAM_STATE, STREAM_SREG, direction, 4)
    for array in (world.raw_a, world.raw_b):
        array[source] = value
    for array in (world.clock_a, world.clock_b):
        array[source] = np.uint64(0)
    return {
        "mode": mode, "installed": True, "source": list(source),
        "direction": list(direction), "state": STREAM_STATE, "sreg": STREAM_SREG,
        "semantic": 4, "nominal_demux_arrival_tick": STREAM_DISTANCE if mode == "intact" else None,
    }


def roi_mask(center, radius: int):
    mask = np.zeros((N, N, N), bool)
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                mask[torus_add(center, (dx, dy, dz))] = True
    return mask


def local_records(raw, center, radius=2):
    rows = []
    for dx in range(-radius, radius + 1):
        for dy in range(-radius, radius + 1):
            for dz in range(-radius, radius + 1):
                q = torus_add(center, (dx, dy, dz))
                rec = read(raw, q)
                if rec is not None:
                    rows.append({"offset": [dx, dy, dz], "site": list(q), **rec})
    return rows


def build_case(kernel, spec):
    inherited_spec = {
        "id": spec["id"], "bits": spec["bits"], "receiver": spec["receiver"],
        "query": False, "query2": False, "translation": (0, 0, 0),
    }
    world, tree, apparatus = inherited.build_case(kernel, inherited_spec)
    stream = install_stream(world, apparatus, spec["stream"])
    return world, tree, apparatus, stream


def run_case(kernel, spec, telemetry):
    world, tree, apparatus, stream = build_case(kernel, spec)
    demux = tuple(apparatus["demux_target"])
    receiver = tuple(apparatus["receiver_target"])
    after_receiver = add(receiver, STREAM_DIR, 1, N)
    stream_source = None if stream["source"] is None else tuple(stream["source"])
    trace, kernel_events = [], []
    for tick in range(HORIZON + 1):
        fields = decoded_fields(world.raw_a)
        state_locations = np.argwhere(fields["state"] == STREAM_STATE)
        trace.append({
            "tick": tick,
            "raw_support": int(np.count_nonzero(world.raw_a)),
            "raw_sha256": sha256_array(world.raw_a),
            "clock_sha256": sha256_array(world.clock_a),
            "stream_state_count": int(state_locations.shape[0]),
            "stream_state_sample": state_locations[:12].astype(int).tolist(),
            "records": {
                "stream_source": None if stream_source is None else read(world.raw_a, stream_source),
                "demux_target": read(world.raw_a, demux),
                "receiver_target": read(world.raw_a, receiver),
                "after_receiver": read(world.raw_a, after_receiver),
            },
            "demux_neighborhood": local_records(world.raw_a, demux, 2) if tick >= 46 else None,
            "receiver_neighborhood": local_records(world.raw_a, receiver, 2) if tick >= 46 else None,
        })
        if tick in FULL_CHECKPOINTS:
            telemetry[f"{spec['id']}__t{tick}__raw"] = world.raw_a.copy()
            telemetry[f"{spec['id']}__t{tick}__clock"] = world.clock_a.copy()
        if tick == HORIZON:
            break
        info = world.tick()
        if any(int(info.get(key, 0)) for key in ("colisiones", "overflows", "genesis")):
            kernel_events.append({"tick": tick + 1, **info})
    return {
        "case_id": spec["id"], "spec": spec, "stream": stream,
        "apparatus": apparatus,
        "expected_history_sreg_apparatus_relation": 7 + 212 * len(spec["bits"]) + 61 * sum(spec["bits"]),
        "trace": trace, "kernel_events": kernel_events,
        "post_t0_host_calls": ["tick", "read", "snapshot", "hash", "log", "stop"],
        "post_t0_host_writes": 0, "completed": True,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    kernel, environment = load_kernel()
    telemetry = {}
    cases = [run_case(kernel, spec, telemetry) for spec in CASES]
    by_id = {case["case_id"]: case for case in cases}
    comparisons = {}
    pair_defs = {
        "low_stream_vs_no_stream": ("LOW_00011_STREAM", "LOW_00011_NO_STREAM"),
        "high_stream_vs_no_stream": ("HIGH_01111_STREAM", "HIGH_01111_NO_STREAM"),
        "high_vs_low_stream": ("HIGH_01111_STREAM", "LOW_00011_STREAM"),
        "high_stream_vs_bias_cut": ("HIGH_01111_STREAM", "HIGH_01111_BIAS_CUT_STREAM"),
        "high_stream_vs_bias_sham": ("HIGH_01111_STREAM", "HIGH_01111_BIAS_SHAM_STREAM"),
        "high_stream_vs_sham_route": ("HIGH_01111_STREAM", "HIGH_01111_STREAM_SHAM_ROUTE"),
    }
    for label, (left_id, right_id) in pair_defs.items():
        left_case, right_case = by_id[left_id], by_id[right_id]
        demux = tuple(left_case["apparatus"]["demux_target"])
        receiver = tuple(left_case["apparatus"]["receiver_target"])
        mask = roi_mask(demux, 4) | roi_mask(receiver, 4)
        timeline = {}
        for tick in FULL_CHECKPOINTS:
            lraw = telemetry[f"{left_id}__t{tick}__raw"]
            rraw = telemetry[f"{right_id}__t{tick}__raw"]
            lclock = telemetry[f"{left_id}__t{tick}__clock"]
            rclock = telemetry[f"{right_id}__t{tick}__clock"]
            timeline[str(tick)] = effect_signature((lraw, lclock), (rraw, rclock), mask)
        comparisons[label] = {"left": left_id, "right": right_id,
                              "roi": "union of Chebyshev radius 4 around DEMUX and receiver",
                              "checkpoint_timeline": timeline}
    payload = {
        "campaign_id": CAMPAIGN,
        "question": "Does an inherited DEMUX consequence alter a later encounter produced by a pre-existing persistent source?",
        "environment": environment,
        "config": {"N": N, "stream_distance": STREAM_DISTANCE, "stream_direction": STREAM_DIR,
                   "stream_state": STREAM_STATE, "stream_sreg": STREAM_SREG,
                   "horizon": HORIZON, "full_checkpoints": FULL_CHECKPOINTS,
                   "main_world_post_t0_contract": ["tick", "read", "snapshot", "hash", "log", "stop"]},
        "cases": cases, "comparisons": comparisons,
        "completed_case_count": len(cases), "partial_case_count": 0,
        "elapsed_seconds": time.monotonic() - start,
    }
    json_dump(args.output / "native_return_stream_results.json", payload)
    np.savez_compressed(args.output / "native_return_stream_telemetry.npz", **telemetry)
    print(json.dumps({"completed": len(cases), "partial": 0,
                      "elapsed_seconds": payload["elapsed_seconds"]}, indent=2))


if __name__ == "__main__":
    main()
