#!/usr/bin/env python3
"""PENSAMIENTO 01 continuation: temporal structure and reuse of one medium.

All attributed dynamics use the frozen DEE v27 extension.  Host writes are
restricted to the declared experience phase and to diagnostic clones.  After
HOST_STOP the main world receives only kernel ticks and passive reads.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from collections import Counter
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
PREVIOUS = ZIP_ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
for path in (ZIP_ROOT, PREVIOUS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import (  # noqa: E402
    World,
    add,
    build_history_arrays,
    decoded_fields,
    effect_signature,
    json_dump,
    load_kernel,
    pack,
    read,
    sha256_array,
    world_summary,
)

CAMPAIGN = "PENSAMIENTO_01_PLASTICIDAD_TEMPORAL_Y_RETORNO_20261002"
N = 39
ORIGIN = (19, 19, 19)
EVENT_PHASE = 17
PASSIVE_AFTER_HOST_STOP = 24
QUERY_HORIZONS = (1, 4, 8, 16)

SEQUENCES = {
    # Same length, A/B inventory, duration, ports, last symbol, and adjacent
    # pair counts; their higher-order run organization differs.
    "ORDER_S1": {"symbols": "AABBBAABBAABBAAB", "gaps": [4] * 16},
    "ORDER_S2": {"symbols": "ABAAABBBABBBAAAB", "gaps": [4] * 16},
    # Same inventory, duration and last event, but a different adjacent-pair
    # structure.
    "LOW_ORDER_ALT": {"symbols": "ABABABABABABABAB", "gaps": [4] * 16},
    # Explicit dose control; duration and final AB remain fixed.
    "DOSE_A10_B6": {"symbols": "AAABBAAABAABBAAB", "gaps": [4] * 16},
    # Same S1 symbols and total duration; arrival gaps alternate 3/5.
    "RHYTHM_S1": {"symbols": "AABBBAABBAABBAAB", "gaps": [3, 5] * 8},
    "NO_EXPERIENCE": {"symbols": "", "gaps": [64]},
}

REUSE_PROTOCOLS = {
    "S1_S2_S1": ("ORDER_S1", "ORDER_S2", "ORDER_S1"),
    "S1_S1_S1": ("ORDER_S1", "ORDER_S1", "ORDER_S1"),
    "S2_S1_S2": ("ORDER_S2", "ORDER_S1", "ORDER_S2"),
}


def sequence_statistics(symbols: str, gaps: list[int]) -> dict:
    pairs = Counter(a + b for a, b in zip(symbols, symbols[1:]))
    triples = Counter(symbols[i:i + 3] for i in range(max(0, len(symbols) - 2)))
    return {
        "length": len(symbols),
        "inventory": dict(sorted(Counter(symbols).items())),
        "pair_counts": {k: pairs.get(k, 0) for k in ("AA", "AB", "BA", "BB")},
        "triple_counts": dict(sorted(triples.items())),
        "last_two": symbols[-2:] if symbols else None,
        "total_duration_ticks": int(sum(gaps)),
        "gaps": [int(x) for x in gaps],
    }


def clone_world(kernel, world: World) -> World:
    return World(kernel, world.raw_a.copy(), world.clock_a.copy())


def inject(world: World, q, raw_value: int, clock_value: int, label: str) -> dict:
    q = tuple(int(x) for x in q)
    before = read(world.raw_a, q)
    record = {
        "label": label,
        "site": list(q),
        "raw_value": int(raw_value),
        "clock_value": int(clock_value),
        "site_before": before,
        "written": before is None,
    }
    if before is not None:
        return record
    value = np.uint64(raw_value)
    clock = np.uint64(clock_value)
    world.raw_a[q] = value
    world.raw_b[q] = value
    world.clock_a[q] = clock
    world.clock_b[q] = clock
    return record


def port_geometry(ports, symbol: str, n: int):
    if symbol == "A":
        target = add(ports["a"], (0, -1, 0), 1, n)
        direction = (0, 0, -1)
        state = 5000
    elif symbol == "B":
        target = add(ports["b"], (0, 1, 0), 1, n)
        direction = (0, 0, 1)
        state = 5001
    else:
        raise ValueError(symbol)
    source = add(target, direction, -1, n)
    return source, target, direction, state


def local_readout(world: World, ports, tick: int) -> dict:
    points = {key: read(world.raw_a, ports[key]) for key in ("a", "b", "comparator", "reader_source")}
    a, b, c = points["a"], points["b"], points["comparator"]
    return {
        "tick": int(tick),
        "points": points,
        "memory_delta_sreg": None if a is None or b is None else int(a["sreg"] - b["sreg"]),
        "comparator_x": None if c is None else int(c["direction"][0]),
        "world": world_summary(world, tick),
    }


def run_experience(world: World, ports, symbols: str, gaps: list[int], tick0: int, phase_label: str):
    tick = int(tick0)
    host_writes = []
    event_trace = []
    if not symbols:
        for _ in range(sum(gaps)):
            world.tick(); tick += 1
        return tick, host_writes, event_trace
    if len(symbols) != len(gaps):
        raise ValueError("one declared post-write gap is required per event")
    for index, (symbol, gap) in enumerate(zip(symbols, gaps), start=1):
        source, target, direction, state = port_geometry(ports, symbol, world.n)
        write = inject(
            world,
            source,
            int(pack(state, 3, direction, 1)),
            EVENT_PHASE,
            f"{phase_label}:event_{index}:{symbol}",
        )
        write.update({"tick": tick, "symbol": symbol, "target": list(target), "direction": list(direction)})
        host_writes.append(write)
        for offset in range(1, int(gap) + 1):
            info = world.tick(); tick += 1
            if offset == 1 or offset == int(gap):
                event_trace.append({
                    "event_index": index,
                    "symbol": symbol,
                    "tick": tick,
                    "offset_after_write": offset,
                    "kernel": info,
                    "source": read(world.raw_a, source),
                    "target": read(world.raw_a, target),
                    "readout": local_readout(world, ports, tick),
                })
    return tick, host_writes, event_trace


QUERY_DIRS = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))


def install_frozen_query(world: World, center, radius: int = 6):
    records = []
    for index, outward in enumerate(QUERY_DIRS):
        site = add(center, outward, radius, world.n)
        inward = tuple(-x for x in outward)
        records.append(inject(
            world,
            site,
            int(pack(8100 + index, 0, inward, 1)),
            EVENT_PHASE,
            f"diagnostic_query_axis_{index}",
        ))
    return records


def diagnostic_query(kernel, checkpoint: World, ports, tick0: int) -> dict:
    control = clone_world(kernel, checkpoint)
    query = clone_world(kernel, checkpoint)
    writes = install_frozen_query(query, ports["comparator"], 6)
    if not all(item["written"] for item in writes):
        return {"measurement_available": False, "reason": "QUERY_SITE_OCCUPIED", "writes": writes}
    horizons = {}
    previous = 0
    for horizon in QUERY_HORIZONS:
        for _ in range(horizon - previous):
            query.tick(); control.tick()
        horizons[str(horizon)] = {
            "effect": effect_signature(
                (query.raw_a, query.clock_a),
                (control.raw_a, control.clock_a),
            ),
            "query_readout": local_readout(query, ports, tick0 + horizon),
            "control_readout": local_readout(control, ports, tick0 + horizon),
        }
        previous = horizon
    return {
        "measurement_available": True,
        "temporal_semantics": "DIAGNOSTIC_CLONE_CONTRAFACTUAL",
        "query_definition": "six equal carriers at Chebyshev radius 6 directed toward comparator",
        "writes": writes,
        "horizons": horizons,
    }


def run_single_case(kernel, case_id: str, definition: dict) -> tuple[dict, dict[str, np.ndarray]]:
    raw, clock, ports = build_history_arrays(N, ORIGIN, "H0")
    world = World(kernel, raw, clock)
    initial = local_readout(world, ports, 0)
    tick, writes, trace = run_experience(
        world, ports, definition["symbols"], definition["gaps"], 0, case_id
    )
    checkpoint = clone_world(kernel, world)
    pre_stop = local_readout(world, ports, tick)
    query = diagnostic_query(kernel, checkpoint, ports, tick)
    host_stop = tick
    post_trace = []
    for offset in range(1, PASSIVE_AFTER_HOST_STOP + 1):
        info = world.tick(); tick += 1
        if offset in (1, 4, 8, 16, PASSIVE_AFTER_HOST_STOP):
            post_trace.append({"offset": offset, "kernel": info, "readout": local_readout(world, ports, tick)})
    result = {
        "case_id": case_id,
        "role": "MAIN_WORLD_EXPERIENCE_PLUS_SEPARATE_DIAGNOSTIC_CLONES",
        "definition": definition,
        "statistics": sequence_statistics(definition["symbols"], definition["gaps"]),
        "initial": initial,
        "host_writes": writes,
        "host_writes_attempted": len(writes),
        "host_writes_realized": sum(int(x["written"]) for x in writes),
        "event_trace": trace,
        "host_stop_tick": host_stop,
        "pre_stop": pre_stop,
        "diagnostic_query": query,
        "post_host_passive_trace": post_trace,
        "final": local_readout(world, ports, tick),
        "post_host_forbidden_writes_observed": 0,
        "completed": True,
    }
    arrays = {
        f"{case_id}__checkpoint_raw": checkpoint.raw_a,
        f"{case_id}__checkpoint_clock": checkpoint.clock_a,
        f"{case_id}__final_raw": world.raw_a,
        f"{case_id}__final_clock": world.clock_a,
    }
    return result, arrays


def run_reuse_case(kernel, case_id: str, phases: tuple[str, ...]) -> tuple[dict, dict[str, np.ndarray]]:
    raw, clock, ports = build_history_arrays(N, ORIGIN, "H0")
    world = World(kernel, raw, clock)
    tick = 0
    phase_results = []
    arrays = {}
    for phase_index, sequence_id in enumerate(phases, start=1):
        definition = SEQUENCES[sequence_id]
        tick, writes, trace = run_experience(
            world, ports, definition["symbols"], definition["gaps"], tick,
            f"{case_id}:phase_{phase_index}:{sequence_id}",
        )
        checkpoint = clone_world(kernel, world)
        arrays[f"{case_id}__phase{phase_index}_raw"] = checkpoint.raw_a
        arrays[f"{case_id}__phase{phase_index}_clock"] = checkpoint.clock_a
        phase_results.append({
            "phase": phase_index,
            "sequence_id": sequence_id,
            "start_tick": tick - sum(definition["gaps"]),
            "end_tick": tick,
            "host_writes": writes,
            "host_writes_attempted": len(writes),
            "host_writes_realized": sum(int(x["written"]) for x in writes),
            "event_trace": trace,
            "readout": local_readout(world, ports, tick),
            "diagnostic_query": diagnostic_query(kernel, checkpoint, ports, tick),
        })
    host_stop = tick
    post_trace = []
    for offset in range(1, PASSIVE_AFTER_HOST_STOP + 1):
        info = world.tick(); tick += 1
        if offset in (1, 4, 8, 16, PASSIVE_AFTER_HOST_STOP):
            post_trace.append({"offset": offset, "kernel": info, "readout": local_readout(world, ports, tick)})
    arrays[f"{case_id}__final_raw"] = world.raw_a
    arrays[f"{case_id}__final_clock"] = world.clock_a
    return {
        "case_id": case_id,
        "role": "CONTINUOUS_MAIN_WORLD_REUSE_WITH_SEPARATE_DIAGNOSTIC_CLONES",
        "phase_sequence": list(phases),
        "phases": phase_results,
        "host_stop_tick": host_stop,
        "post_host_passive_trace": post_trace,
        "final": local_readout(world, ports, tick),
        "post_host_forbidden_writes_observed": 0,
        "reset_count": 0,
        "completed": True,
    }, arrays


def raw_distance(a: np.ndarray, b: np.ndarray) -> dict:
    fa, fb = decoded_fields(a), decoded_fields(b)
    return {
        "raw_diff_positions": int(np.count_nonzero(a != b)),
        "raw_xor_sha256": sha256_array(np.bitwise_xor(a, b)),
        "field_diff_positions": {k: int(np.count_nonzero(fa[k] != fb[k])) for k in fa},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    kernel, environment = load_kernel()
    # Operational canary only: exact array/buffer contract and one known call.
    canary_raw = np.zeros((5, 5, 5), np.uint64)
    canary_clock = np.zeros_like(canary_raw)
    canary = World(kernel, canary_raw, canary_clock)
    canary_info = canary.tick()
    sequence_stats = {k: sequence_statistics(v["symbols"], v["gaps"]) for k, v in SEQUENCES.items()}
    if sequence_stats["ORDER_S1"]["inventory"] != sequence_stats["ORDER_S2"]["inventory"]:
        raise RuntimeError("order pair inventory mismatch")
    if sequence_stats["ORDER_S1"]["pair_counts"] != sequence_stats["ORDER_S2"]["pair_counts"]:
        raise RuntimeError("order pair adjacent-pair mismatch")
    if sequence_stats["ORDER_S1"]["total_duration_ticks"] != sequence_stats["ORDER_S2"]["total_duration_ticks"]:
        raise RuntimeError("order pair duration mismatch")

    cases = []
    arrays: dict[str, np.ndarray] = {}
    for case_id, definition in SEQUENCES.items():
        result, data = run_single_case(kernel, case_id, definition)
        cases.append(result); arrays.update(data)
    reuse_cases = []
    for case_id, phases in REUSE_PROTOCOLS.items():
        result, data = run_reuse_case(kernel, case_id, phases)
        reuse_cases.append(result); arrays.update(data)

    comparisons = {}
    for left, right in (("ORDER_S1", "ORDER_S2"), ("ORDER_S1", "LOW_ORDER_ALT"),
                        ("ORDER_S1", "DOSE_A10_B6"), ("ORDER_S1", "RHYTHM_S1")):
        comparisons[f"{left}__vs__{right}"] = raw_distance(
            arrays[f"{left}__checkpoint_raw"], arrays[f"{right}__checkpoint_raw"]
        )
    for left, right in (("S1_S2_S1", "S1_S1_S1"), ("S1_S2_S1", "S2_S1_S2")):
        comparisons[f"{left}__vs__{right}"] = raw_distance(
            arrays[f"{left}__final_raw"], arrays[f"{right}__final_raw"]
        )
    elapsed = time.monotonic() - start
    payload = {
        "campaign_id": CAMPAIGN,
        "question": "Can matched temporal experience alter retained response and can one medium be reused without reset?",
        "measurement_semantics": {
            "main_world": "controlled experience writes followed by kernel-only passive continuation",
            "diagnostic_clones": "frozen six-axis query; not counted as autonomous main-world events",
        },
        "sequence_statistics": sequence_stats,
        "environment": environment,
        "operational_canary": {"shape": [5, 5, 5], "tick_result": canary_info},
        "single_sequence_cases": cases,
        "continuous_reuse_cases": reuse_cases,
        "cross_case_comparisons": comparisons,
        "completed_case_count": len(cases) + len(reuse_cases),
        "partial_case_count": 0,
        "elapsed_seconds": elapsed,
    }
    json_dump(args.output / "temporal_plasticity_results.json", payload)
    np.savez_compressed(args.output / "temporal_plasticity_telemetry.npz", **arrays)
    json_dump(args.output / "temporal_plasticity_execution.json", {
        "campaign_id": CAMPAIGN,
        "start_monotonic_recorded": True,
        "elapsed_seconds": elapsed,
        "completed_case_count": len(cases) + len(reuse_cases),
        "partial_case_count": 0,
        "result_file": "temporal_plasticity_results.json",
        "telemetry_file": "temporal_plasticity_telemetry.npz",
    })
    print(json.dumps({
        "completed": len(cases) + len(reuse_cases),
        "partial": 0,
        "elapsed_seconds": elapsed,
        "host_write_realization": {
            c["case_id"]: [c.get("host_writes_realized"), c.get("host_writes_attempted")]
            for c in cases
        },
    }, indent=2))


if __name__ == "__main__":
    main()
