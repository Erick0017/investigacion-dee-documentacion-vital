#!/usr/bin/env python3
"""Mechanism-motivated correction: causal input trains, no clearing or reset."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ZIP_ROOT = HERE.parents[1]
PREVIOUS = ZIP_ROOT / "CONTINUACIONES" / "PAISAJE_REUTILIZABLE_20261001"
for path in (HERE, ZIP_ROOT, PREVIOUS):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

from continuation_common import (  # noqa: E402
    World, add, build_history_arrays, decoded_fields, effect_signature,
    json_dump, load_kernel, pack, read, sha256_array, world_summary,
)
from run_temporal_plasticity import (  # noqa: E402
    clone_world, local_readout, raw_distance, sequence_statistics,
)

CAMPAIGN = "PENSAMIENTO_01_TEMPORAL_TRAINS_AND_REUSE_20261002"
N = 73
ORIGIN = (36, 36, 36)
EVENT_PHASE = 17
ARRIVALS_REGULAR = list(range(5, 36, 2))  # 5,7,...,35 (16 arrivals)
ARRIVALS_RHYTHM = [5]
for delta in ([1, 3] * 7 + [2]):
    ARRIVALS_RHYTHM.append(ARRIVALS_RHYTHM[-1] + delta)
assert len(ARRIVALS_RHYTHM) == 16 and ARRIVALS_RHYTHM[-1] == 35
PHASE_TICKS = 35
PASSIVE_TICKS = 24
QUERY_HORIZONS = (1, 4, 8, 16)

SEQUENCES = {
    "ORDER_S1": "AABBBAABBAABBAAB",
    "ORDER_S2": "ABAAABBBABBBAAAB",
    "LOW_ORDER_ALT": "ABABABABABABABAB",
    "DOSE_A10_B6": "AAABBAAABAABBAAB",
    "NO_EXPERIENCE": "",
}
REUSE_PROTOCOLS = {
    "S1_S2_S1": ("ORDER_S1", "ORDER_S2", "ORDER_S1"),
    "S1_S1_S1": ("ORDER_S1", "ORDER_S1", "ORDER_S1"),
    "S2_S1_S2": ("ORDER_S2", "ORDER_S1", "ORDER_S2"),
}


def qstats(symbols: str, arrivals: list[int]) -> dict:
    gaps = [arrivals[0]] + [b - a for a, b in zip(arrivals, arrivals[1:])] if arrivals else [PHASE_TICKS]
    value = sequence_statistics(symbols, gaps)
    value["arrival_ticks_relative"] = arrivals
    value["phase_duration_ticks"] = PHASE_TICKS
    return value


def port_geometry(ports, symbol: str, n: int):
    if symbol == "A":
        target, direction, state = add(ports["a"], (0, -1, 0), 1, n), (0, 0, -1), 5000
    elif symbol == "B":
        target, direction, state = add(ports["b"], (0, 1, 0), 1, n), (0, 0, 1), 5001
    else:
        raise ValueError(symbol)
    return target, direction, state


def write_empty(world: World, q, value: int, clock: int, label: str) -> dict:
    q = tuple(q)
    before = read(world.raw_a, q)
    item = {"label": label, "site": list(q), "site_before": before, "written": before is None,
            "raw_value": int(value), "clock_value": int(clock)}
    if before is None:
        word, phase = np.uint64(value), np.uint64(clock)
        world.raw_a[q] = word; world.raw_b[q] = word
        world.clock_a[q] = phase; world.clock_b[q] = phase
    return item


def install_train(world: World, ports, symbols: str, arrivals: list[int], label: str) -> list[dict]:
    if len(symbols) != len(arrivals):
        raise ValueError("symbols/arrivals mismatch")
    writes = []
    for index, (symbol, arrival) in enumerate(zip(symbols, arrivals), start=1):
        target, direction, state = port_geometry(ports, symbol, world.n)
        source = add(target, direction, -arrival, world.n)
        item = write_empty(world, source, int(pack(state, 3, direction, 1)), EVENT_PHASE,
                           f"{label}:event_{index}:{symbol}")
        item.update({"symbol": symbol, "arrival_tick_relative": arrival,
                     "target": list(target), "direction": list(direction)})
        writes.append(item)
    return writes


def query_sources(ports, n: int):
    center = ports["comparator"]
    dirs = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))
    return [(add(center, d, 8, n), tuple(-x for x in d)) for d in dirs]


def diagnostic_query(kernel, checkpoint: World, ports, tick0: int) -> dict:
    control, query = clone_world(kernel, checkpoint), clone_world(kernel, checkpoint)
    writes = []
    for index, (site, inward) in enumerate(query_sources(ports, query.n)):
        writes.append(write_empty(query, site, int(pack(8200 + index, 0, inward, 1)), EVENT_PHASE,
                                  f"diagnostic_query_{index}"))
    if not all(x["written"] for x in writes):
        return {"measurement_available": False, "reason": "FIXED_QUERY_SITE_OCCUPIED", "writes": writes}
    horizons, previous = {}, 0
    for horizon in QUERY_HORIZONS:
        for _ in range(horizon - previous):
            query.tick(); control.tick()
        horizons[str(horizon)] = {
            "effect": effect_signature((query.raw_a, query.clock_a), (control.raw_a, control.clock_a)),
            "query_readout": local_readout(query, ports, tick0 + horizon),
            "control_readout": local_readout(control, ports, tick0 + horizon),
        }
        previous = horizon
    return {"measurement_available": True, "temporal_semantics": "DIAGNOSTIC_CLONE_CONTRAFACTUAL",
            "writes": writes, "horizons": horizons}


def advance_phase(world: World, ports, tick0: int, arrivals: list[int]):
    tick = tick0
    arrival_set = set(arrivals)
    trace = []
    for relative in range(1, PHASE_TICKS + 1):
        info = world.tick(); tick += 1
        if relative in arrival_set or relative in (1, PHASE_TICKS):
            trace.append({"relative_tick": relative, "tick": tick, "kernel": info,
                          "readout": local_readout(world, ports, tick)})
    return tick, trace


def base_world(kernel):
    raw, clock, ports = build_history_arrays(N, ORIGIN, "H0")
    return World(kernel, raw, clock), ports


def run_single(kernel, case_id: str, symbols: str, arrivals: list[int]):
    world, ports = base_world(kernel)
    writes = install_train(world, ports, symbols, arrivals, case_id) if symbols else []
    initial = local_readout(world, ports, 0)
    tick, trace = advance_phase(world, ports, 0, arrivals)
    checkpoint = clone_world(kernel, world)
    query = diagnostic_query(kernel, checkpoint, ports, tick)
    host_stop = tick
    passive = []
    for offset in range(1, PASSIVE_TICKS + 1):
        info = world.tick(); tick += 1
        if offset in (1, 4, 8, 16, PASSIVE_TICKS):
            passive.append({"offset": offset, "kernel": info, "readout": local_readout(world, ports, tick)})
    return {
        "case_id": case_id,
        "status": "COMPLETED" if all(x["written"] for x in writes) else "PARTIAL_INPUT_OCCLUSION",
        "role": "MAIN_WORLD_WITH_T0_PRELOADED_INPUT_TRAIN_AND_SEPARATE_DIAGNOSTIC_CLONES",
        "symbols": symbols,
        "arrivals": arrivals,
        "statistics": qstats(symbols, arrivals),
        "initial_after_preparation": initial,
        "preparation_writes": writes,
        "writes_realized": sum(int(x["written"]) for x in writes),
        "writes_attempted": len(writes),
        "event_trace": trace,
        "host_stop_tick": host_stop,
        "readout_at_host_stop": local_readout(world, ports, host_stop),
        "diagnostic_query": query,
        "post_host_passive": passive,
        "final": local_readout(world, ports, tick),
        "post_host_forbidden_writes_observed": 0,
    }, {
        f"{case_id}__checkpoint_raw": checkpoint.raw_a,
        f"{case_id}__checkpoint_clock": checkpoint.clock_a,
        f"{case_id}__final_raw": world.raw_a,
        f"{case_id}__final_clock": world.clock_a,
    }


def run_reuse(kernel, case_id: str, phases: tuple[str, ...]):
    world, ports = base_world(kernel)
    tick = 0
    phase_results, arrays = [], {}
    for phase_number, seq_id in enumerate(phases, start=1):
        symbols = SEQUENCES[seq_id]
        writes = install_train(world, ports, symbols, ARRIVALS_REGULAR,
                               f"{case_id}:phase_{phase_number}:{seq_id}")
        start_readout = local_readout(world, ports, tick)
        tick, trace = advance_phase(world, ports, tick, ARRIVALS_REGULAR)
        checkpoint = clone_world(kernel, world)
        arrays[f"{case_id}__phase{phase_number}_raw"] = checkpoint.raw_a
        arrays[f"{case_id}__phase{phase_number}_clock"] = checkpoint.clock_a
        phase_results.append({
            "phase": phase_number, "sequence_id": seq_id,
            "start_tick": tick - PHASE_TICKS, "end_tick": tick,
            "status": "COMPLETED" if all(x["written"] for x in writes) else "PARTIAL_INPUT_OCCLUSION",
            "writes": writes,
            "writes_realized": sum(int(x["written"]) for x in writes),
            "writes_attempted": len(writes),
            "start_readout": start_readout, "event_trace": trace,
            "end_readout": local_readout(world, ports, tick),
            "diagnostic_query": diagnostic_query(kernel, checkpoint, ports, tick),
        })
    host_stop = tick
    passive = []
    for offset in range(1, PASSIVE_TICKS + 1):
        info = world.tick(); tick += 1
        if offset in (1, 4, 8, 16, PASSIVE_TICKS):
            passive.append({"offset": offset, "kernel": info, "readout": local_readout(world, ports, tick)})
    arrays[f"{case_id}__final_raw"] = world.raw_a
    arrays[f"{case_id}__final_clock"] = world.clock_a
    return {
        "case_id": case_id,
        "role": "CONTINUOUS_MAIN_WORLD_THREE_EXPERIENCE_PHASES_WITHOUT_RESET",
        "phase_sequence": list(phases), "phases": phase_results,
        "host_stop_tick": host_stop, "post_host_passive": passive,
        "final": local_readout(world, ports, tick),
        "reset_count": 0, "post_host_forbidden_writes_observed": 0,
        "status": "COMPLETED" if all(p["status"] == "COMPLETED" for p in phase_results)
                  else "PARTIAL_INPUT_OCCLUSION",
    }, arrays


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE)
    args = parser.parse_args(); args.output.mkdir(parents=True, exist_ok=True)
    start = time.monotonic()
    kernel, environment = load_kernel()
    canary = World(kernel, np.zeros((5, 5, 5), np.uint64), np.zeros((5, 5, 5), np.uint64))
    canary_result = canary.tick()
    cases, arrays = [], {}
    for case_id, symbols in SEQUENCES.items():
        arrivals = [] if not symbols else ARRIVALS_REGULAR
        result, data = run_single(kernel, case_id, symbols, arrivals)
        cases.append(result); arrays.update(data)
    result, data = run_single(kernel, "RHYTHM_S1", SEQUENCES["ORDER_S1"], ARRIVALS_RHYTHM)
    cases.append(result); arrays.update(data)
    reuse, reuse_arrays = [], {}
    for case_id, phases in REUSE_PROTOCOLS.items():
        result, data = run_reuse(kernel, case_id, phases)
        reuse.append(result); reuse_arrays.update(data)
    arrays.update(reuse_arrays)
    comparisons = {}
    for left, right in (("ORDER_S1", "ORDER_S2"), ("ORDER_S1", "LOW_ORDER_ALT"),
                        ("ORDER_S1", "DOSE_A10_B6"), ("ORDER_S1", "RHYTHM_S1")):
        comparisons[f"{left}__vs__{right}"] = raw_distance(
            arrays[f"{left}__checkpoint_raw"], arrays[f"{right}__checkpoint_raw"])
    for left, right in (("S1_S2_S1", "S1_S1_S1"), ("S1_S2_S1", "S2_S1_S2")):
        comparisons[f"{left}__vs__{right}"] = raw_distance(
            arrays[f"{left}__final_raw"], arrays[f"{right}__final_raw"])
    completed = sum(c["status"] == "COMPLETED" for c in cases + reuse)
    partial = len(cases) + len(reuse) - completed
    payload = {
        "campaign_id": CAMPAIGN,
        "question": "Does matched temporal structure alter response, and can the same medium/input corridor accept further history without reset?",
        "apparatus": {"N": N, "origin": ORIGIN, "phase_ticks": PHASE_TICKS,
                      "regular_arrivals": ARRIVALS_REGULAR, "rhythm_arrivals": ARRIVALS_RHYTHM,
                      "no_self_wrap_bound": f"max source distance 35 < N/2={N/2}"},
        "environment": environment,
        "operational_canary": {"shape": [5, 5, 5], "tick_result": canary_result},
        "single_sequence_cases": cases,
        "continuous_reuse_cases": reuse,
        "cross_case_comparisons": comparisons,
        "completed_case_count": completed,
        "partial_case_count": partial,
        "elapsed_seconds": time.monotonic() - start,
    }
    json_dump(args.output / "temporal_trains_reuse_results.json", payload)
    np.savez_compressed(args.output / "temporal_trains_reuse_telemetry.npz", **arrays)
    print(json.dumps({
        "completed": completed, "partial": partial,
        "single_realized": {c["case_id"]: [c["writes_realized"], c["writes_attempted"]] for c in cases},
        "reuse_realized": {c["case_id"]: [[p["writes_realized"], p["writes_attempted"]] for p in c["phases"]] for c in reuse},
        "elapsed_seconds": payload["elapsed_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
