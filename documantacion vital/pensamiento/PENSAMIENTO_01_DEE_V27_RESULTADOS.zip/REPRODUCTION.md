# Reproducción breve

Requisitos:

- Windows AMD64;
- CPython 3.13 del entorno funcional existente;
- NumPy 2.2.6;
- `dee_universe_v27` v27.0.0 instalado desde el WHL identificado en `config.json`.

Desde la raíz `tests`:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\PENSAMIENTO_01_WORK\run_pensamiento01.py' --deadline-minutes 120
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\PENSAMIENTO_01_WORK\analyze_pensamiento01.py'
```

`run_pensamiento01.py` verifica las tres identidades SHA-256 antes de importar el módulo nativo. No modifica ni reinstala el kernel. La configuración confirmatoria está congelada en `frozen_confirmation.json`.

Los archivos `pilot_results.json`, `pilot_results_v2.json` y `chain_pilot_results.json` conservan los intentos exploratorios. `results.json` contiene la confirmación reservada y los controles.
