#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def main():
    result = json.loads((HERE / "results.json").read_text(encoding="utf-8"))
    cases = {row["case_id"]: row for row in result["cases"]}
    intact_ids = ["CONF_A_INTACT", "CONF_B_INTACT", "CONF_C_INTACT"]
    controls = ["CONF_A_CUT_SECOND_LINK", "CONF_A_SHAM_FIRST_LINK", "CONF_A_NO_ROOT_SUPPLY"]
    out = {
        "schema": "dee.v27.pensamiento01.analysis.v1",
        "source_results_content_sha256": result["content_sha256"],
        "direct_measurements": {},
        "causal_contrasts": {},
        "scope": {
            "main_world_evidence_only": True,
            "diagnostic_clones_used": False,
            "post_t0_host_writes": 0,
            "supply_type": "finite preloaded carriers and branch hardware",
            "persistent_semantic4_source": False,
            "confirmed_history_domain": "monotone 0*1*",
        },
    }
    for case_id in intact_ids + controls:
        row = cases[case_id]
        out["direct_measurements"][case_id] = {
            "bits": row["bits"], "mode": row["mode"],
            "complete_cycle_records": row["outcome"]["complete_cycles"],
            "renewed_updates_used_by_later_interaction": row["outcome"]["renewed_cycles_used_by_later_interaction"],
            "cycle_rows": row["outcome"]["cycle_rows"],
            "initial_support": row["initial_support"], "terminal_support": row["terminal_support"],
            "tree_nodes": len(row["tree"]["nodes"]),
            "unique_preloaded_sources": row["unique_preloaded_sources"],
            "logical_placements": row["preloaded_logical_placements"],
            "shared_logical_placements": row["shared_logical_placements"],
        }
    base = out["direct_measurements"]["CONF_A_INTACT"]
    for control_id in controls:
        control = out["direct_measurements"][control_id]
        out["causal_contrasts"][control_id] = {
            "delta_renewed_updates_vs_CONF_A": control["renewed_updates_used_by_later_interaction"] - base["renewed_updates_used_by_later_interaction"],
            "interpretive_scope": {
                "CONF_A_CUT_SECOND_LINK": "second native normalization absent; the second response is not converted into the third action",
                "CONF_A_SHAM_FIRST_LINK": "same logical carrier count at the first link but nonconjugate directions; first response remains and renewal stops",
                "CONF_A_NO_ROOT_SUPPLY": "branch hardware remains but the initial policy carrier is absent; no first action is formed",
            }[control_id],
        }
    (HERE / "analysis.json").write_text(json.dumps(out, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str((HERE / 'analysis.json').resolve()),
                      "renewed": {k: v["renewed_updates_used_by_later_interaction"] for k, v in out["direct_measurements"].items()}}, indent=2))


if __name__ == "__main__":
    main()
