#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import platform
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
CONFIG = json.loads((HERE / "config.json").read_text(encoding="utf-8"))

STATE_MASK = np.uint64((1 << 32) - 1)
SREG_MASK = np.uint64(0xFFFF)
SEM_MASK = np.uint64(0xF)

A = (1, 0, 0)
B = (0, 1, 0)
SENSOR = (-1, 0, 1)
NORMALIZER = (1, 0, -1)
PENALTY0 = (-1, 1, 0)
ACTION0 = (0, 0, 1)
ACTION1 = (-1, 1, 1)

PATTERN_A = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PATTERN_B = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def load_kernel():
    expected = CONFIG["kernel"]
    paths = {k: Path(expected[k]) for k in ("wheel_path", "package_path", "binary_path")}
    observed = {
        "wheel_sha256": sha256_file(paths["wheel_path"]),
        "package_sha256": sha256_file(paths["package_path"]),
        "binary_sha256": sha256_file(paths["binary_path"]),
    }
    for key, value in observed.items():
        if value != expected[key]:
            raise RuntimeError(f"kernel identity mismatch {key}: {value}")
    sys.path.insert(0, str(paths["package_path"].parent.parent))
    importlib.invalidate_caches()
    import dee_universe_v27 as package
    from dee_universe_v27 import dee_kernel_v27 as kernel
    if Path(package.__file__).resolve() != paths["package_path"].resolve():
        raise RuntimeError("unexpected package import")
    if Path(kernel.__file__).resolve() != paths["binary_path"].resolve():
        raise RuntimeError("unexpected kernel import")
    return kernel, {
        "paths": {k: str(v.resolve()) for k, v in paths.items()},
        "hashes": observed,
        "python": sys.version,
        "numpy": np.__version__,
        "platform": platform.platform(),
    }


def pack(state: int, sreg: int, direction=(0, 0, 0), semantic: int = 1) -> np.uint64:
    return np.uint64((state & 0xFFFFFFFF) | ((sreg & 0xFFFF) << 32) |
                     ((direction[0] & 0xF) << 48) | ((direction[1] & 0xF) << 52) |
                     ((direction[2] & 0xF) << 56) | ((semantic & 0xF) << 60))


def signed_nibble(value, shift: int) -> int:
    x = (int(value) >> shift) & 0xF
    return x - 16 if x >= 8 else x


def read(raw: np.ndarray, q):
    value = np.uint64(raw[q])
    if int(value) == 0:
        return None
    return {
        "raw": int(value), "state": int(value & STATE_MASK),
        "sreg": int((value >> np.uint64(32)) & SREG_MASK),
        "direction": [signed_nibble(value, s) for s in (48, 52, 56)],
        "semantic": int((value >> np.uint64(60)) & SEM_MASK),
    }


def add(q, d, k, n):
    return tuple((int(q[i]) + int(k) * int(d[i])) % n for i in range(3))


class World:
    def __init__(self, kernel, raw, clock):
        self.kernel = kernel
        self.n = int(raw.shape[0])
        self.raw_a = np.ascontiguousarray(raw, dtype=np.uint64).copy()
        self.raw_b = self.raw_a.copy()
        self.clock_a = np.ascontiguousarray(clock, dtype=np.uint64).copy()
        self.clock_b = self.clock_a.copy()

    @property
    def raw(self):
        return self.raw_a

    def tick(self):
        return {str(k): int(v) for k, v in dict(self.kernel.tick_universo_lazy(
            self.raw_a, self.raw_b, self.clock_a, self.clock_b, self.n, 1)).items()}


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0, label=""):
    if int(raw[q]):
        raise RuntimeError(f"initial overlap at {q}, label={label}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def place_arrival(raw, clock, target, tick, direction, state, sreg, semantic=1, label=""):
    source = add(target, direction, -tick, raw.shape[0])
    put(raw, clock, source, state, sreg, direction, semantic, phase=0, label=label)
    return source


def install_memory(raw, clock, center):
    n = raw.shape[0]
    mem_a = add(center, (-1, 0, 0), 1, n)
    mem_b = add(center, (1, 0, 0), 1, n)
    put(raw, clock, mem_a, 1000, 100, semantic=1, phase=260, label="memory_a")
    put(raw, clock, mem_b, 2000, 100, semantic=1, phase=260, label="memory_b")
    for i, offset in enumerate(PATTERN_A):
        put(raw, clock, add(mem_a, offset, 1, n), 3000 + i, 0, semantic=4, phase=31 + i, label=f"support_a_{i}")
    for i, offset in enumerate(PATTERN_B):
        put(raw, clock, add(mem_b, offset, 1, n), 4000 + i, 0, semantic=4, phase=41 + i, label=f"support_b_{i}")
    reader_source = add(center, (0, -2, 0), 1, n)
    put(raw, clock, reader_source, 6000, 7, (0, 1, 0), semantic=4, phase=23, label="reader_source")
    return {"a": mem_a, "b": mem_b, "comparator": center, "reader_source": reader_source}


def install_r14_cycle(raw, clock, t1, t1_coord, bit, cycle_id, mode="intact"):
    t2 = t1 + 1
    t3 = t1 + 2
    coord2 = add(t1_coord, ACTION0, 1, raw.shape[0])
    target_a = add(coord2, A, 1, raw.shape[0])
    target_b = add(coord2, B, 1, raw.shape[0])
    placed = []
    placed.append(place_arrival(raw, clock, t1_coord, t1, A, 100 + cycle_id, 7, label=f"c{cycle_id}_policy"))
    placed.append(place_arrival(raw, clock, t1_coord, t1, SENSOR, 200 + cycle_id, 47, label=f"c{cycle_id}_sensor"))
    consequence_direction = NORMALIZER if mode != "sham_consequence" else (1, -1, -1)
    if mode != "cut_consequence":
        placed.append(place_arrival(raw, clock, coord2, t2, consequence_direction, 300 + cycle_id, 53, label=f"c{cycle_id}_normalizer"))
        if bit:
            placed.append(place_arrival(raw, clock, coord2, t2, PENALTY0, 400 + cycle_id, 59, label=f"c{cycle_id}_penalty"))
    placed.append(place_arrival(raw, clock, target_a, t3, SENSOR, 500 + cycle_id, 101, label=f"c{cycle_id}_probe_a"))
    placed.append(place_arrival(raw, clock, target_b, t3, SENSOR, 600 + cycle_id, 103, label=f"c{cycle_id}_probe_b"))
    return {
        "cycle": cycle_id, "bit": int(bit), "mode": mode, "t1": t1, "t2": t2, "t3": t3,
        "t1_coord": list(t1_coord), "t2_coord": list(coord2),
        "target_a": list(target_a), "target_b": list(target_b),
        "initial_sources": [list(q) for q in placed],
    }


def snapshot(world, ports, tick, cycles):
    a = read(world.raw, ports["a"])
    b = read(world.raw, ports["b"])
    c = read(world.raw, ports["comparator"])
    cycle_records = []
    for item in cycles:
        cycle_records.append({
            "cycle": item["cycle"],
            "t1": read(world.raw, tuple(item["t1_coord"])),
            "t2": read(world.raw, tuple(item["t2_coord"])),
            "target_a": read(world.raw, tuple(item["target_a"])),
            "target_b": read(world.raw, tuple(item["target_b"])),
        })
    return {
        "tick": tick, "a": a, "b": b,
        "delta": None if a is None or b is None else a["sreg"] - b["sreg"],
        "comparator": c, "comparator_x": None if c is None else c["direction"][0],
        "support": int(np.count_nonzero(world.raw)), "cycles": cycle_records,
    }


def run_variant(kernel, variant, bits=(0, 1, 0), n=59, horizon=40):
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    center = (n // 2, n // 2, n // 2)
    ports = install_memory(raw, clock, center)
    # Three time-separated R14 modules, all physically present at t0.  The
    # selected R14 output is aligned with the already validated ING02 event-A
    # neighbor, without changing either inherited collision algebra.
    event_a = add(ports["a"], (0, -1, 0), 1, n)
    cycle_specs = []
    for t1, bit in zip((5, 13, 21), bits):
        learned = A if bit == 0 else B
        t2_coord = add(event_a, learned, -1, n)
        t1_coord = add(t2_coord, ACTION0, -1, n)
        cycle_specs.append((t1, t1_coord))
    cycles = []
    for i, ((t1, coord), bit) in enumerate(zip(cycle_specs, bits), start=1):
        mode = "intact"
        if variant == "cut_consequence": mode = "cut_consequence"
        if variant == "sham_consequence": mode = "sham_consequence"
        cycles.append(install_r14_cycle(raw, clock, t1, coord, bit, i, mode))
    if variant == "no_history":
        # Same memory, reader and inventory scale; remove policy carriers before t0.
        for item in cycles:
            q = tuple(item["initial_sources"][0])
            raw[q] = np.uint64(0); clock[q] = np.uint64(0)
    world = World(kernel, raw, clock)
    initial_raw = world.raw.copy()
    trace = [snapshot(world, ports, 0, cycles)]
    kernel_trace = []
    for tick in range(1, horizon + 1):
        info = world.tick()
        if info.get("overflows", 0) or info.get("genesis", 0):
            kernel_trace.append({"tick": tick, **info})
        trace.append(snapshot(world, ports, tick, cycles))
    return {
        "variant": variant, "bits": list(bits), "n": n, "horizon": horizon,
        "ports": {k: list(v) for k, v in ports.items()}, "cycles": cycles,
        "trace": trace, "kernel_events": kernel_trace,
        "initial_support": int(np.count_nonzero(initial_raw)),
        "terminal_support": int(np.count_nonzero(world.raw)),
        "python_interventions_after_t0": 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE / "pilot_results.json"))
    args = parser.parse_args()
    kernel, runtime = load_kernel()
    # Operational canary: known all-zero buffers remain raw-zero after one native tick.
    z = np.zeros((5, 5, 5), np.uint64)
    canary = World(kernel, z, z.copy())
    canary_info = canary.tick()
    operational_canary = {"raw_support_after_tick": int(np.count_nonzero(canary.raw)), "kernel_report": canary_info}
    variants = [run_variant(kernel, name) for name in ("intact", "cut_consequence", "sham_consequence", "no_history")]
    out = {
        "schema": "dee.v27.pensamiento01.pilot.a.v1",
        "runtime": runtime, "operational_canary": operational_canary,
        "question": CONFIG["primary_family"]["question"],
        "variants": variants,
    }
    path = Path(args.output)
    path.write_text(json.dumps(out, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(path.resolve()), "variant_terminal": {v["variant"]: v["trace"][-1] for v in variants}}, indent=2))


if __name__ == "__main__":
    main()
