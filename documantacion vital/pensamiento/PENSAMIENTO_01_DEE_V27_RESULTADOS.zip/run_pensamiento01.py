#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from run_pensamiento01_chain import load_kernel, run_case


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=False).encode("utf-8")).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE / "results.json"))
    parser.add_argument("--deadline-minutes", type=float, default=120.0)
    args = parser.parse_args()
    started = time.monotonic()
    deadline = started + args.deadline_minutes * 60.0
    frozen = json.loads((HERE / "frozen_confirmation.json").read_text(encoding="utf-8"))
    kernel, runtime = load_kernel()
    cases = []

    def execute(case_id, bits, mode, n, horizon, role):
        if time.monotonic() >= deadline - 120:
            raise RuntimeError("global campaign deadline reserve reached")
        row = run_case(kernel, case_id, tuple(bits), mode, n=n, horizon=horizon)
        row["role"] = role
        cases.append(row)

    for spec in frozen["confirmation_histories"]:
        execute(spec["id"] + "_INTACT", spec["bits"], "intact", spec["N"], spec["horizon"], "reserved_confirmation")
    a = frozen["confirmation_histories"][0]
    for mode in frozen["controls_on_CONF_A"]:
        execute("CONF_A_" + mode.upper(), a["bits"], mode, a["N"], a["horizon"], "causal_control")

    summary = {}
    for row in cases:
        summary[row["case_id"]] = {
            "role": row["role"], "bits": row["bits"], "mode": row["mode"],
            "complete_cycles": row["outcome"]["complete_cycles"],
            "renewed_cycles_used_by_later_interaction": row["outcome"]["renewed_cycles_used_by_later_interaction"],
            "python_interventions_after_t0": row["python_interventions_after_t0"],
            "terminal_support": row["terminal_support"],
        }
    result = {
        "schema": "dee.v27.pensamiento01.confirmation.v1",
        "campaign_id": "PENSAMIENTO_01_DEE_V27",
        "created_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "runtime": runtime,
        "frozen_confirmation": frozen,
        "main_world_contract": "No host writes after t0 in any case; no diagnostic clone contributes to evidence.",
        "cases": cases,
        "summary": summary,
        "elapsed_seconds": time.monotonic() - started,
    }
    result["content_sha256"] = canonical_hash(result)
    output = Path(args.output)
    output.write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"output": str(output.resolve()), "content_sha256": result["content_sha256"],
                      "elapsed_seconds": result["elapsed_seconds"], "summary": summary}, indent=2))


if __name__ == "__main__":
    main()
