#!/usr/bin/env python3
"""Finite native recurrent R14 chain for PENSAMIENTO 01.

All carriers and branch hardware exist at t0.  After t0 the host only calls the
official v27 kernel and reads arrays.  The full binary branch tree prevents the
host from selecting a port after observing a response.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from pilot_pensamiento01 import (
    A, ACTION0, ACTION1, B, NORMALIZER, PENALTY0, SENSOR,
    World, add, load_kernel, pack, place_arrival, read,
)

C1 = (1, -1, 0)
C2 = (1, 0, -1)


def put_unique(raw, clock, q, state, sreg, direction, semantic=1, label=""):
    if int(raw[q]):
        raise RuntimeError(f"initial overlap {q} while placing {label}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(0)


def arrival(raw, clock, target, tick, direction, state, sreg, label):
    return place_arrival(raw, clock, target, tick, direction, state, sreg, 1, label)


def node_geometry(q, n):
    t2 = add(q, ACTION0, 1, n)
    ta = add(t2, A, 1, n)
    tb = add(t2, B, 1, n)
    n0 = add(ta, ACTION0, 1, n)
    n1 = add(tb, ACTION1, 1, n)
    return t2, ta, tb, n0, n1


def build_tree(raw, clock, root, bits, t1_root=3, gap=5, mode="intact"):
    n = raw.shape[0]
    levels = [[root]]
    times = [t1_root]
    for depth in range(len(bits) - 1):
        t1 = times[-1]
        next_nodes = []
        for q in levels[-1]:
            _, _, _, norm0, norm1 = node_geometry(q, n)
            next_nodes.extend([add(norm0, A, gap, n), add(norm1, A, gap, n)])
        levels.append(next_nodes)
        times.append(t1 + 3 + gap)

    placements = []
    source_labels = {}
    source_meta = {}
    state_id = 10000

    def add_arr(target, tick, direction, sreg, label):
        nonlocal state_id
        q = add(target, direction, -tick, n)
        if int(raw[q]):
            prior = source_meta[q]
            if prior["target"] == tuple(target) and prior["tick"] == tick and prior["direction"] == tuple(direction):
                prior["labels"].append(label)
                placements.append({"label": label, "source": list(q), "target": list(target),
                                   "arrival_tick": tick, "direction": list(direction), "sreg": prior["sreg"],
                                   "shared_preexisting_carrier": True})
                return
            raise RuntimeError(f"initial overlap {q}: previous={source_labels.get(q)} new={label}")
        put_unique(raw, clock, q, state_id, sreg, direction, label=label)
        source_labels[q] = label
        source_meta[q] = {"target": tuple(target), "tick": tick, "direction": tuple(direction),
                          "sreg": sreg, "labels": [label]}
        placements.append({"label": label, "source": list(q), "target": list(target), "arrival_tick": tick,
                           "direction": list(direction), "sreg": sreg})
        state_id += 1

    # Root carrier. All later A carriers are created by the preceding native link.
    add_arr(root, t1_root, A, 7, "root_policy")

    nodes = []
    for depth, (level, t1, bit) in enumerate(zip(levels, times, bits), start=1):
        for branch_index, q in enumerate(level):
            t2, ta, tb, norm0, norm1 = node_geometry(q, n)
            prefix = f"d{depth}_b{branch_index}"
            add_arr(q, t1, SENSOR, 47, prefix + "_sensor")
            add_arr(t2, t1 + 1, NORMALIZER, 53, prefix + "_consequence_normalizer")
            if bit:
                add_arr(t2, t1 + 1, PENALTY0, 59, prefix + "_consequence_penalty")
            add_arr(ta, t1 + 2, SENSOR, 101, prefix + "_probe_a")
            add_arr(tb, t1 + 2, SENSOR, 103, prefix + "_probe_b")

            cut_here = (mode == "cut_first_link" and depth == 1) or (mode == "cut_second_link" and depth == 2)
            sham_here = mode == "sham_first_link" and depth == 1
            if not cut_here and not sham_here:
                add_arr(norm0, t1 + 3, NORMALIZER, 11, prefix + "_link0_converter")
                add_arr(norm1, t1 + 3, C1, 5, prefix + "_link1_converter_a")
                add_arr(norm1, t1 + 3, C2, 6, prefix + "_link1_converter_b")
            elif cut_here:
                pass
            elif sham_here:
                # Same carrier count and s_reg inventory, directions cannot normalize
                # ACTION0/ACTION1 to A.
                add_arr(norm0, t1 + 3, (0, 1, -1), 11, prefix + "_sham0")
                add_arr(norm1, t1 + 3, (0, -1, 0), 5, prefix + "_sham1a")
                add_arr(norm1, t1 + 3, (0, 0, -1), 6, prefix + "_sham1b")
            nodes.append({
                "depth": depth, "branch_index": branch_index, "bit": int(bit), "t1": t1,
                "q": list(q), "t2": list(t2), "target_a": list(ta), "target_b": list(tb),
                "norm0": list(norm0), "norm1": list(norm1),
            })
    return {"levels": [[list(q) for q in level] for level in levels], "times": times,
            "nodes": nodes, "placements": placements}


def rec_at(raw, q):
    return read(raw, tuple(q))


def compact_trace(world, tree, tick):
    rows = []
    for node in tree["nodes"]:
        if node["t1"] - 1 <= tick <= node["t1"] + 4:
            rows.append({
                "depth": node["depth"], "branch_index": node["branch_index"],
                "q": rec_at(world.raw, node["q"]), "t2": rec_at(world.raw, node["t2"]),
                "target_a": rec_at(world.raw, node["target_a"]),
                "target_b": rec_at(world.raw, node["target_b"]),
                "norm0": rec_at(world.raw, node["norm0"]), "norm1": rec_at(world.raw, node["norm1"]),
            })
    return {"tick": tick, "support": int(np.count_nonzero(world.raw)), "nodes": rows}


def classify_path(trace, tree):
    cycle_rows = []
    prior_branch = 0
    complete = 0
    for depth, t1 in enumerate(tree["times"], start=1):
        node = tree["nodes"][sum(2 ** i for i in range(depth - 1)) + prior_branch]
        by_tick = {row["tick"]: row for row in trace}
        def get(tick, key):
            for x in by_tick[tick]["nodes"]:
                if x["depth"] == depth and x["branch_index"] == prior_branch:
                    return x[key]
            return None
        action = get(t1, "q")
        policy = get(t1 + 1, "t2")
        out0 = get(t1 + 2, "target_a")
        out1 = get(t1 + 2, "target_b")
        link0 = get(t1 + 3, "norm0")
        link1 = get(t1 + 3, "norm1")
        action_dir = None if action is None else action["direction"]
        policy_dir = None if policy is None else policy["direction"]
        out0_dir = None if out0 is None else out0["direction"]
        out1_dir = None if out1 is None else out1["direction"]
        response = 0 if out0_dir == list(ACTION0) else 1 if out1_dir == list(ACTION1) else None
        link = link0 if response == 0 else link1 if response == 1 else None
        link_dir = None if link is None else link["direction"]
        action_ok = action_dir == list(ACTION0)
        policy_ok = policy_dir == list(A if node["bit"] == 0 else B)
        response_ok = response == node["bit"]
        link_ok = link_dir == list(A)
        cycle_complete = action_ok and policy_ok and response_ok and link_ok
        if cycle_complete:
            complete += 1
        cycle_rows.append({
            "depth": depth, "active_branch": prior_branch, "bit": node["bit"],
            "action_tick": t1, "consequence_tick": t1 + 1,
            "response_tick": t1 + 2, "update_tick": t1 + 3,
            "action_direction": action_dir, "policy_direction": policy_dir,
            "response": response, "link_direction": link_dir,
            "action_ok": action_ok, "policy_ok": policy_ok,
            "response_ok": response_ok, "link_ok": link_ok,
            "cycle_complete": cycle_complete,
        })
        if response is None:
            break
        prior_branch = 2 * prior_branch + response
    renewed = 0
    for index in range(len(cycle_rows) - 1):
        used = cycle_rows[index]["cycle_complete"] and cycle_rows[index + 1]["action_ok"]
        cycle_rows[index]["update_used_in_later_interaction"] = used
        cycle_rows[index]["later_interaction_tick"] = cycle_rows[index + 1]["action_tick"]
        if used:
            renewed += 1
    if cycle_rows:
        cycle_rows[-1]["update_used_in_later_interaction"] = None
        cycle_rows[-1]["later_interaction_tick"] = None
    return {"complete_cycles": complete, "renewed_cycles_used_by_later_interaction": renewed,
            "cycle_rows": cycle_rows}


def run_case(kernel, case_id, bits, mode, n=71, horizon=32):
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    root = (n // 2, n // 2, n // 2)
    tree = build_tree(raw, clock, root, bits, mode=mode)
    if mode == "no_root_supply":
        root_item = next(item for item in tree["placements"] if item["label"] == "root_policy")
        q = tuple(root_item["source"])
        raw[q] = np.uint64(0)
        clock[q] = np.uint64(0)
    initial_support = int(np.count_nonzero(raw))
    unique_preloaded_sources = len({tuple(item["source"]) for item in tree["placements"]})
    shared_logical_placements = sum(bool(item.get("shared_preexisting_carrier")) for item in tree["placements"])
    world = World(kernel, raw, clock)
    trace = [compact_trace(world, tree, 0)]
    reports = []
    for tick in range(1, horizon + 1):
        report = world.tick()
        if report.get("overflows", 0) or report.get("genesis", 0):
            reports.append({"tick": tick, **report})
        trace.append(compact_trace(world, tree, tick))
    outcome = classify_path(trace, tree)
    return {
        "case_id": case_id, "bits": list(bits), "mode": mode, "n": n, "horizon": horizon,
        "tree": tree, "trace": trace, "kernel_events": reports,
        "outcome": outcome, "terminal_support": int(np.count_nonzero(world.raw)),
        "initial_support": initial_support,
        "preloaded_logical_placements": len(tree["placements"]),
        "unique_preloaded_sources": unique_preloaded_sources,
        "shared_logical_placements": shared_logical_placements,
        "supply": "finite preloaded carriers; no semantic-4 persistent source",
        "python_interventions_after_t0": 0,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE / "chain_pilot_results.json"))
    args = parser.parse_args()
    kernel, runtime = load_kernel()
    cases = [
        run_case(kernel, "INTACT_010", (0, 1, 0), "intact"),
        run_case(kernel, "INTACT_101", (1, 0, 1), "intact"),
        run_case(kernel, "CUT_FIRST_LINK_010", (0, 1, 0), "cut_first_link"),
        run_case(kernel, "SHAM_FIRST_LINK_010", (0, 1, 0), "sham_first_link"),
    ]
    result = {
        "schema": "dee.v27.pensamiento01.native_recurrent_chain.pilot.v1",
        "runtime": runtime,
        "mechanism": "R14 action-consequence-policy-response chained through branch-symmetric native normalization",
        "main_world_only": True,
        "post_t0_contract": "kernel ticks and passive reads only",
        "cases": cases,
    }
    path = Path(args.output)
    path.write_text(json.dumps(result, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({c["case_id"]: c["outcome"] for c in cases}, indent=2))


if __name__ == "__main__":
    main()
