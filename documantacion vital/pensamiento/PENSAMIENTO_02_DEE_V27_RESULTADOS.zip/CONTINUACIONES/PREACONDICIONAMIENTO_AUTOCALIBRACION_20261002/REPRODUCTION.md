# Reproducción breve

La continuación reutiliza `run_pensamiento02.py`, `dee_v27_helpers.py` y `config.json` de la raíz del acumulativo. El helper valida los SHA-256 del wheel, paquete y binario v27 antes de importar el kernel.

Desde la raíz extraída del ZIP, con el Python 3.13 registrado:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\PREACONDICIONAMIENTO_AUTOCALIBRACION_20261002\run_p02_preconditioning_autocalibration.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\PREACONDICIONAMIENTO_AUTOCALIBRACION_20261002\run_targeted_controls.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\PREACONDICIONAMIENTO_AUTOCALIBRACION_20261002\run_environment_second_use.py'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\CONTINUACIONES\PREACONDICIONAMIENTO_AUTOCALIBRACION_20261002\analyze_continuation.py'
```

El primer runner recrea los 82 casos iniciales y sus checkpoints. Los dos runners cortos conservan los controles añadidos después de observar interferencia de instrumentación. Ejecutarlos otra vez sobre la misma carpeta reemplaza los archivos de esos casos; para una reproducción limpia debe usarse una copia nueva de la raíz extraída.

Los mundos principales reciben todos sus componentes en `t0`. Las entradas posteriores de las tareas se aplican exclusivamente a clones diagnósticos creados desde checkpoints y quedan enumeradas en cada JSON. Ningún clon intervenido vuelve al mundo principal.
