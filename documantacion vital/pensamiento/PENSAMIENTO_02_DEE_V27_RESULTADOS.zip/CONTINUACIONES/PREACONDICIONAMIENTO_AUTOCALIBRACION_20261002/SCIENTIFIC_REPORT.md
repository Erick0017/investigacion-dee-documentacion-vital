# PENSAMIENTO 02 — Preacondicionamiento endógeno, aprendizaje posterior y autocalibración operacional

## Preguntas y aparato reutilizado

La continuación reutilizó sin modificar el aparato histórico–multicanal–recurrente de PENSAMIENTO 02: historia H0/HA, coincidencias A/B/C, oscilador R04 con cuatro fuentes persistentes `semantic=4` y linaje C7H03. Se examinaron tres preguntas conectadas: qué permanece disponible al alcanzar el cap de `s_reg`; si la recurrencia previa cambia una tarea posterior bajo un contrato idéntico; y si una respuesta puede volver, modificar condiciones posteriores y ser usada más de una vez.

Se completaron 88 casos y 0 quedaron parciales. Los tres mundos de saturación y los dos controles de preacondicionamiento evolucionaron 700 ticks. Todos los componentes de los mundos principales se instalaron en `t0`; después sólo hubo ticks del kernel, lectura y checkpoints. Las tareas posteriores se ejecutaron en clones diagnósticos de t64, t654 y t700. Sus entradas están enumeradas como escrituras del host en cada caso y esos clones nunca regresaron al mundo principal.

## S — Saturación y disponibilidad funcional

La predicción condicional `q_siguiente=min(19664,q_actual+60)` coincidió hasta el cambio de régimen. H0+AB midió 19627 en q(t654), 19651 en qp(t655), alcanzó el cap en q(t656) y en qp(t657). HA+AB midió 19651 en t654 y alcanzó el cap ya en la semietapa t655; HA+ABC midió 19655 y también alcanzó el cap en t655. En las tres trayectorias la dirección siguió alternando `+x/-x` hasta t700. No se registraron eventos `overflow` ni `genesis` expuestos por el kernel.

En los checkpoints pares, el portador ocupado tenía cero vecinos RAW activos; en las semietapas impares había dos propuestas vecinas. Los cuatro RAW fuente permanecieron invariantes mientras sus clocks avanzaron. La observación es compatible con extinción local y reinstanciación en el destino sostenida por las fuentes, no con acumulación material persistente en una sola celda.

El cap afectó de forma distinta a la carga y al estado completo. HA+AB y HA+ABC diferían en una posición RAW en t654, pero sus arrays RAW y clock completos fueron idénticos en t656 y t700. H0+AB compartió desde t656 el mismo valor local saturado del oscilador, pero siguió separado: 550 voxels RAW y 2 clocks distintos en t656; 560 RAW y 2 clocks en t700. Así, la convergencia escalar local no implicó convergencia global entre todas las historias.

Las sondas +5 en clones separaron disponibilidad transitoria y retención. En H0/t654, el control recorrió 19627→19651→19664 y la sonda 19627→19656→19664: el incremento fue visible una semietapa y luego quedó eliminado por el cap. En HA+AB y HA+ABC ya no cambió ni siquiera la lectura de la primera semietapa; después del cap, control y sonda terminaron con cero voxels RAW o clock diferentes. Esto mide pérdida de sensibilidad de este canal escalar, no inactividad del oscilador ni imposibilidad de otras lecturas.

## P — Preacondicionamiento y tarea posterior

El corte instalado en t19 cambió el portador de 595 y dirección `-x` a 595 y dirección `+z`. Sin embargo, las fuentes persistentes reinstanciaron una recurrencia en el eje: el control cortado midió q=1356 en t64, 19056 en t654 y 19664 en t700, frente a 1951, 19651 y 19664 en intacto/sham. El corte produjo un déficit de carga 595 antes del cap, pero no eliminó el mecanismo suministrado. Este resultado corrige la interpretación simplista “cortar un portador detiene el oscilador”.

La tarea direccional posterior se congeló para todos los grupos y edades. Dosis 0 no produjo la dirección funcional esperada; dosis 1 produjo 1/1 respuestas; dosis 2, 2/2; dosis 4, 4/4. La consulta no idéntica de transferencia también produjo 1/1 en intacto, corte y sham a t64, t654 y t700. Por tanto, en este aparato la relación se adquirió en una experiencia y dejó un efecto direccional reutilizable, pero el techo de una experiencia impidió medir aceleración por preacondicionamiento.

La carga de la respuesta sí conservó diferencias previas antes del cap: a t64, la consulta de dosis 1 fue 2235 en intacto/sham y 1640 en corte; a t654 fue 19664 frente a 19340. A t700 los tres dieron 19664. La función direccional declarada fue igual pese a esos estados escalares distintos. No se observó mejora o deterioro de latencia, dosis necesaria, retención ni transferencia bajo esta tarea; esto es neutralidad dentro del lector utilizado, no equivalencia microscópica universal.

## Asociación multicanal corregida

La prueba B conservó por fin la identidad operacional del B de entrenamiento: carga 9 y dirección `(0,-1,-1)`. En emparejado, el receptor pasó de 4697 dirección `(0,1,1)` sin B a 4706 dirección cero con B. En no emparejado y sin entrenamiento pasó de 4673 a 4682 con la misma cancelación direccional. B añadió exactamente 9 en los tres fondos. El emparejamiento conservó el offset 24 antes y después de la prueba, pero no apareció una interacción específica adquirida entre ese estado y B bajo esta lectura. La corrección confirma que el antiguo `test_B` de carga 7 no era B, y muestra además que corregir la identidad no basta para producir evocación asociativa en este montaje.

## A — Respuesta propia, retorno y repetición

En la tarea direccional de cuatro ciclos, la respuesta de cada consulta fue redirigida físicamente a la configuración A y participó en el siguiente entrenamiento. El brazo intacto produjo 4/4 respuestas; un sham lejano, 4/4; y el corte del retorno, sólo la primera. El caso sin teacher después del primer ciclo también produjo sólo la primera. Un sham inicialmente colocado a dos celdas produjo 2/4 porque su portador “off-path” cruzó la trayectoria móvil más tarde; se conserva como fallo de comparabilidad y motivó el sham lejano.

Estos contrastes muestran que el retorno de la respuesta fue causalmente necesario para las interacciones posteriores del aparato. También muestran el límite: cada nueva adquisición dependió todavía de sensores/teacher preinstalados para ese ciclo. Sin teacher posterior no apareció una relación que predijera o corrigiera por sí sola la respuesta siguiente. Se observó auto-interacción con uso posterior, pero no una relación operacional adquirida sobre la propia respuesta que generalizara a la prueba no idéntica.

## E — Cierre ambiental y segundo uso

El enlace ambiental intacto produjo la siguiente secuencia completamente nativa después de t0:

- respuesta1 t33: 4704, dirección `+y`;
- condición ambiental t37: 4715, dirección `+z`;
- retorno t41: 4728, dirección `+y`;
- organización2 t47: 8830, dirección `(1,1,0)`;
- respuesta2 t55: 8835, dirección `+x`.

El corte ortogonal respuesta→entorno dejó únicamente los reactivos preparados: 11, 13, 4102 y 5. El sham lejano reprodujo 4715→4728→8830→8835. El corte entorno→retorno produjo igualmente sólo 13→4102→5 aguas abajo, mientras su sham reprodujo el intacto. Un primer corte con dirección `+z` no interceptó el portador y se conserva como control fallido; no se usó para la atribución.

La respuesta2 se utilizó una vez más con el mismo aparato. El brazo intacto y el sham lejano produjeron 8835→8852→8871→12973→12978 en t55/t59/t63/t69/t77. El corte del segundo enlace dejó sólo 17→19→4102→5. Los controles distinguen dos usos ambientales mediados de una simple agenda: los reactivos estaban programados desde t0, pero sólo la llegada de la respuesta previa los convirtió en los estados históricos grandes y cambió las respuestas posteriores.

## Recursos, actividad y costes

Las fuentes persistentes sostuvieron la recurrencia y sus RAW no cambiaron. Los reactivos, consultas, normalizadores y teachers fueron recursos finitos preparados; no fueron creados por la organización. El mundo no recibió una lista de respuestas calculadas por Python después de observar su conducta, pero sí una infraestructura de encuentros prediseñada. La recurrencia continuó hasta t700 y sobrevivió al cap como alternancia direccional; la admisión escalar de nueva carga quedó recortada. No se midió reciclaje de `s_reg`, creación de fuentes ni sostenibilidad indefinida.

El coste posterior de aprendizaje fue idéntico en los fondos comparados: una experiencia para la tarea direccional y una para la transferencia examinada. El preacondicionamiento añadió 64, 654 o 700 ticks de coste previo sin reducir esas dosis. La diferencia de carga retenida cambió, pero el observer funcional seleccionado no la utilizó.

## Observaciones inesperadas y explicaciones compatibles

La recurrencia reapareció tras cortar el portador porque las fuentes persistentes generan propuestas capaces de reinstanciar otro portador; el corte no retiró el suministro. El cap borró la distinción HA+AB/HA+ABC en el estado completo medido, pero no igualó H0 con HA. La igualdad de rendimiento de la tarea puede reflejar insensibilidad genuina del mecanismo direccional a `s_reg`, saturación de rendimiento en una experiencia o ambas; este panel no las separa.

Los dos controles instrumentales fallidos muestran que una intervención “off-path” puede cruzar después una identidad móvil y que la trayectoria de un deflector puede impedir que llegue a su encuentro. Por eso la atribución usa los controles ortogonales/lejanos posteriores y conserva los intentos iniciales.

## Aspectos no ejecutados o no medidos

No se examinó una tarea que requiriera más de una experiencia antes de alcanzar techo, una asociación multicanal con plasticidad específica ya compatible, generación endógena de teachers, creación o reciclaje de fuentes, mejora estadística entre múltiples semillas, ni un dominio amplio de perturbaciones para autocalibración. No se infiere de estos datos ausencia general de esas capacidades. Tampoco se identificó `s_reg` como energía ni el recorte del cap como reciclaje.

La continuación aporta mediciones separadas de: continuidad dinámica tras el cap; pérdida de sensibilidad escalar; historia global que puede persistir fuera del valor local saturado; neutralidad del preacondicionamiento para una tarea con techo de una experiencia; retorno causal necesario para ciclos preparados; y dos usos consecutivos de consecuencias mediadas por el entorno. No convierte esas mediciones en un dictamen global sobre pensamiento, autopoiesis o aprendizaje universal.
