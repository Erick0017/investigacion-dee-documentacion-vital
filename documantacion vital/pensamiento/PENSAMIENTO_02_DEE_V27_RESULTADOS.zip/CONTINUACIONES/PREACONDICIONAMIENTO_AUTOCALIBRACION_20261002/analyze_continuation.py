#!/usr/bin/env python3
"""Deterministic reduction of the already executed continuation telemetry."""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent


def dump(name: str, value: object) -> None:
    (HERE / name).write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def main() -> None:
    data = json.loads((HERE / "results.json").read_text(encoding="utf-8"))
    cases = data["cases"]
    by_id = {case["case_id"]: case for case in cases}

    cap = {}
    telemetry = {}
    for case_id in ("CAP_H0_AB", "CAP_HA_AB", "CAP_HA_ABC"):
        case = by_id[case_id]
        cap[case_id] = {
            "first_q_cap": case["first_q_cap"], "first_qp_cap": case["first_qp_cap"],
            "persistent_source_raw_invariant": all(row["raw_equal"] for row in case["source_terminal"].values()),
            "reported_overflow_or_genesis_events": case["kernel_events"],
            "key_records": {
                str(row["tick"]): {"q": row["q"], "qp": row["qp"], "local": row["local"]}
                for row in case["trace"] if row["tick"] in (64, 654, 655, 656, 657, 700)
            },
        }
        telemetry[f"{case_id}_tick"] = np.asarray([row["tick"] for row in case["trace"]], dtype=np.int32)
        telemetry[f"{case_id}_sreg"] = np.asarray([
            (row["q"] or row["qp"] or {}).get("sreg", -1) for row in case["trace"]
        ], dtype=np.int32)
        telemetry[f"{case_id}_site"] = np.asarray([
            0 if row["q"] else 1 if row["qp"] else -1 for row in case["trace"]
        ], dtype=np.int8)

    diag = {}
    for parent in ("CAP_H0_AB", "CAP_HA_AB", "CAP_HA_ABC"):
        diag[parent] = {}
        for tick in (654, 656, 700):
            control = by_id[f"DIAG_{parent}_T{tick}_CONTROL"]
            update = by_id[f"DIAG_{parent}_T{tick}_UPDATE_PLUS5"]
            scalar = lambda row: (row["q"] or row["qp"] or {}).get("sreg")
            diag[parent][str(tick)] = {
                "control_sreg": [scalar(row) for row in control["trajectory"]],
                "update_plus5_sreg": [scalar(row) for row in update["trajectory"]],
                **update["paired_control_comparison"],
            }

    task_table = []
    for parent in ("CAP_HA_AB", "PRECONDITION_CUT", "PRECONDITION_SHAM"):
        for age in (64, 654, 700):
            for dose in (0, 1, 2, 4):
                case = by_id[f"TASK_{parent}_T{age}_DOSE{dose}"]
                task_table.append({
                    "parent": parent, "age": age, "dose": dose,
                    "matched": case["matched_query_count"], "queries": len(case["query_records"]),
                    "query_sreg": [row["record"]["sreg"] if row["record"] else None for row in case["query_records"]],
                })
            transfer = by_id[f"TASK_{parent}_T{age}_TRANSFER"]
            task_table.append({
                "parent": parent, "age": age, "dose": 1, "task": "transfer",
                "matched": transfer["matched_query_count"], "queries": len(transfer["query_records"]),
            })

    self_return = {}
    for case_id in (
        "TASK_CAP_HA_AB_T64_DOSE4", "TASK_CAP_HA_AB_T64_DOSE4_CUT",
        "TASK_CAP_HA_AB_T64_DOSE4_SHAM", "TASK_CAP_HA_AB_T64_DOSE4_SHAM_FAR",
        "TASK_CAP_HA_AB_T64_DOSE4_NO_TEACHER_AFTER_FIRST",
    ):
        case = by_id[case_id]
        self_return[case_id] = {
            "matched": case["matched_query_count"], "queries": len(case["query_records"]),
            "directions": [row["record"]["direction"] if row["record"] else None for row in case["query_records"]],
        }

    association = {}
    for schedule in ("PAIRED", "UNPAIRED", "NONE"):
        with_test = by_id[f"ASSOC_CORRECTED_{schedule}_TEST_B"]
        no_test = by_id[f"ASSOC_CORRECTED_{schedule}_NO_TEST"]
        response = lambda case: next(row["receiver"] for row in case["trace"] if row["tick"] == 33)
        a, b = response(with_test), response(no_test)
        association[schedule] = {
            "with_B": a, "without_B": b, "B_sreg_increment": a["sreg"] - b["sreg"],
        }

    env = {}
    for case in cases:
        if case["family"] in {"environmental_return", "environmental_return_second_use"}:
            env[case["case_id"]] = case["trace"]

    summary = {
        "campaign_id": data["campaign_id"],
        "case_accounting": {
            "completed": data["completed_case_count"], "partial": data["partial_case_count"],
            "by_family": dict(sorted(Counter(case["family"] for case in cases).items())),
            "diagnostic_tasks_admitted": data["admitted_task_count"],
            "diagnostic_tasks_not_admitted": data["nonadmitted_task_count"],
        },
        "saturation": cap,
        "cap_diagnostic_updates": diag,
        "full_state_cap_comparisons": data["cap_state_comparisons"],
        "preconditioning_task_table": task_table,
        "self_response_return": self_return,
        "corrected_association": association,
        "environmental_return_traces": env,
        "runtime": {
            "case_simulation_seconds": data["simulation_seconds"],
            "initial_runner_wall_seconds": data["runner_wall_seconds"],
            "main_world_post_host_writes": data["main_world_post_host_writes"],
        },
    }
    dump("MEASUREMENT_SUMMARY.json", summary)
    np.savez_compressed(HERE / "telemetry.npz", **telemetry)


if __name__ == "__main__":
    main()
