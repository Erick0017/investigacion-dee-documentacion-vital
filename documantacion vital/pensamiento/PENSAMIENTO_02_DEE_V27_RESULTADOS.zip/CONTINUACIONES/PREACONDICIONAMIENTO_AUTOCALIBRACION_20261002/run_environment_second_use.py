#!/usr/bin/env python3
"""Frozen small extension: use the first returned response in one further chain."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import run_p02_preconditioning_autocalibration as run


def execute(kernel, mode: str) -> dict:
    started = time.monotonic()
    case_id = f"ENV_SECOND_USE_{mode}"
    spec = run.integrated_spec(case_id, "HA", "AB", 77)
    spec.update({"closure": True, "test_present": True})
    world, geometry, _ = run.p02.build_integrated(kernel, spec)
    receiver = tuple(geometry["receiver"])
    env1 = run.add(receiver, (0, 1, 0), 4, run.N)
    env2 = run.add(env1, (0, 0, 1), 4, run.N)
    org2 = run.add(env2, (0, 1, 0), 6, run.N)
    response2 = run.add(org2, (1, 1, 0), 8, run.N)
    env3 = run.add(response2, (1, 0, 0), 4, run.N)
    env4 = run.add(env3, (0, 0, 1), 4, run.N)
    org3 = run.add(env4, (0, 1, 0), 6, run.N)
    response3 = run.add(org3, (1, 1, 0), 8, run.N)
    sources = {}
    def place(name, target, tick, direction, state, sreg):
        sources[name] = run.p02.place(world.raw_a, world.clock_a, target, tick, direction, state, sreg, name)
    place("environment_carrier_1", env1, 37, (0, -1, 1), 98500, 11)
    place("general_supply_1", env2, 41, (0, 1, -1), 98501, 13)
    place("organization_2", org2, 47, (1, 0, 0), 98502, 4102)
    place("query_2", response2, 55, (0, -1, 0), 98503, 5)
    place("environment_carrier_2", env3, 59, (-1, 0, 1), 98504, 17)
    place("general_supply_2", env4, 63, (0, 1, -1), 98505, 19)
    place("organization_3", org3, 69, (1, 0, 0), 98506, 4102)
    place("query_3", response3, 77, (0, -1, 0), 98507, 5)
    if mode in {"SECOND_LINK_CUT", "SECOND_LINK_SHAM_FAR"}:
        actual = run.add(response2, (1, 0, 0), 2, run.N)
        if mode.endswith("SHAM_FAR"):
            actual = ((actual[0] + 11) % run.N, (actual[1] + 17) % run.N, actual[2])
        place("second_link_control", actual, 57, (0, -1, 0), 98508, 0)
    world.raw_b[:] = world.raw_a
    world.clock_b[:] = world.clock_a
    points = {
        "response1": receiver, "environment1": env1, "return1": env2,
        "organization2": org2, "response2": response2, "environment2": env3,
        "return2": env4, "organization3": org3, "response3": response3,
    }
    trace = []
    for tick in range(78):
        if tick in (33, 37, 41, 47, 55, 57, 59, 63, 69, 77):
            trace.append({"tick": tick, "records": {name: run.read(world.raw_a, pos) for name, pos in points.items()}})
        if tick < 77:
            world.tick()
    result = {
        "case_id": case_id, "family": "environmental_return_second_use", "completed": True,
        "mode": mode, "geometry": {name: list(pos) for name, pos in points.items()},
        "sources": {name: list(pos) for name, pos in sources.items()}, "trace": trace,
        "post_t0_host_writes": 0, "terminal_raw_sha256": run.sha256_array(world.raw_a),
        "simulation_seconds": time.monotonic() - started,
    }
    run.dump(HERE / "CASES" / f"{case_id}.json", result)
    run.append_progress(HERE, case_id, result["family"], result["simulation_seconds"])
    return result


def main() -> None:
    kernel, environment = run.load_kernel()
    result_path = HERE / "results.json"
    result = json.loads(result_path.read_text(encoding="utf-8"))
    new_cases = [execute(kernel, mode) for mode in ("INTACT", "SECOND_LINK_CUT", "SECOND_LINK_SHAM_FAR")]
    result["cases"].extend(new_cases)
    result["completed_case_count"] = sum(bool(case.get("completed")) for case in result["cases"])
    result["partial_case_count"] = sum(not bool(case.get("completed")) for case in result["cases"])
    result["simulation_seconds"] += sum(float(case.get("simulation_seconds", 0.0)) for case in new_cases)
    result["second_environmental_use_extension"] = {
        "cases": [case["case_id"] for case in new_cases], "environment_revalidated": environment
    }
    run.dump(result_path, result)
    print(json.dumps({"added": len(new_cases), "completed_total": result["completed_case_count"]}, indent=2))


if __name__ == "__main__":
    main()
