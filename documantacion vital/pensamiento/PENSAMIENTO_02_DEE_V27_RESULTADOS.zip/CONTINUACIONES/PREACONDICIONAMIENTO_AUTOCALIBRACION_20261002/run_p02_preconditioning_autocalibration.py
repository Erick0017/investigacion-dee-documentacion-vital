#!/usr/bin/env python3
"""PENSAMIENTO 02 continuation: cap, preconditioning, self-return and environment."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
STAGE = HERE.parents[1]
if str(STAGE) not in sys.path:
    sys.path.insert(0, str(STAGE))

import run_pensamiento02 as p02
from dee_v27_helpers import World, add, load_kernel, pack, read, sha256_array

CAMPAIGN_ID = "P02_PRECONDITIONING_AUTOCALIBRATION_20261002"
N = p02.N
CAP = 19664
KEY_CAP_TICKS = (64, 654, 655, 656, 657, 700)
PRECONDITION_AGES = (64, 654, 700)


def dump(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def append_progress(output: Path, case_id: str, family: str, seconds: float, completed: bool = True) -> None:
    row = {"case_id": case_id, "family": family, "completed": completed, "simulation_seconds": seconds}
    with (output / "case_progress.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps(row, sort_keys=True) + "\n")


def occupied_neighbors(raw: np.ndarray, q) -> dict:
    n = raw.shape[0]
    raw_count = 0
    active_count = 0
    for dx in (-1, 0, 1):
        for dy in (-1, 0, 1):
            for dz in (-1, 0, 1):
                if dx == dy == dz == 0:
                    continue
                pos = ((q[0] + dx) % n, (q[1] + dy) % n, (q[2] + dz) % n)
                rec = read(raw, pos)
                if rec is not None:
                    raw_count += 1
                    if rec["state"] != 0 and rec["semantic"] != 5:
                        active_count += 1
    return {"raw_neighbors": raw_count, "active_material_neighbors": active_count}


def put_preserve_clock(raw: np.ndarray, clock: np.ndarray, q, state: int, sreg: int,
                       direction, semantic: int, label: str) -> dict:
    before = read(raw, q)
    if before is not None:
        raise RuntimeError(f"occupied diagnostic input site {q} for {label}: {before}")
    prior_clock = int(clock[q])
    raw[q] = pack(state, sreg, direction, semantic)
    return {"label": label, "site": list(q), "preserved_clock": prior_clock, "raw": int(raw[q])}


def place_preserve_clock(raw: np.ndarray, clock: np.ndarray, target, tick: int, direction,
                         state: int, sreg: int, label: str, semantic: int = 1) -> dict:
    source = add(target, direction, -tick, raw.shape[0])
    return put_preserve_clock(raw, clock, source, state, sreg, direction, semantic, label)


def integrated_spec(case_id: str, history="HA", channels="AB", horizon=700) -> dict:
    return {
        "id": case_id, "family": "continuation", "history": history,
        "channels": channels, "schedule": "paired", "channel_loads": {},
        "source_mode": "persistent", "insert_link": "intact", "closure": False,
        "return_link": "intact", "test_present": False, "horizon": horizon,
    }


def trace_oscillator(world: World, q, qp, tick: int) -> dict:
    rq, rqp = read(world.raw_a, q), read(world.raw_a, qp)
    occupied = q if rq is not None else qp if rqp is not None else q
    return {
        "tick": tick, "q": rq, "qp": rqp,
        "raw_support": int(np.count_nonzero(world.raw_a)),
        "local": occupied_neighbors(world.raw_a, occupied),
    }


def run_cap_world(kernel, output: Path, history: str, channels: str) -> dict:
    case_id = f"CAP_{history}_{channels}"
    started = time.monotonic()
    spec = integrated_spec(case_id, history, channels, 700)
    world, geometry, source_positions = p02.build_integrated(kernel, spec)
    q, qp = tuple(geometry["q"]), tuple(geometry["qp"])
    source_initial = {str(pos): int(world.raw_a[pos]) for pos in source_positions}
    trace = []
    snapshots = {}
    events = []
    record_ticks = set(KEY_CAP_TICKS) | set(range(640, 671))
    for tick in range(701):
        if tick % 2 == 0 or tick in record_ticks:
            trace.append(trace_oscillator(world, q, qp, tick))
        if tick in KEY_CAP_TICKS:
            snapshots[f"t{tick}_raw"] = world.raw_a.copy()
            snapshots[f"t{tick}_clock"] = world.clock_a.copy()
        if tick < 700:
            info = world.tick()
            if any(int(info.get(key, 0)) for key in ("overflows", "genesis")):
                events.append({"tick": tick + 1, **info})
    first_q_cap = next((row["tick"] for row in trace if row["q"] and row["q"]["sreg"] == CAP), None)
    first_qp_cap = next((row["tick"] for row in trace if row["qp"] and row["qp"]["sreg"] == CAP), None)
    source_terminal = {
        str(pos): {
            "raw_initial": source_initial[str(pos)], "raw_terminal": int(world.raw_a[pos]),
            "raw_equal": source_initial[str(pos)] == int(world.raw_a[pos]),
            "clock_terminal": int(world.clock_a[pos]),
        } for pos in source_positions
    }
    np.savez_compressed(output / "CHECKPOINTS" / f"{case_id}.npz", **snapshots)
    result = {
        "case_id": case_id, "family": "saturation_main", "completed": True,
        "history": history, "channels": channels, "horizon": 700,
        "geometry": geometry, "trace": trace, "first_q_cap": first_q_cap,
        "first_qp_cap": first_qp_cap, "kernel_events": events,
        "source_terminal": source_terminal, "post_t0_host_writes": 0,
        "terminal_raw_sha256": sha256_array(world.raw_a),
        "terminal_clock_sha256": sha256_array(world.clock_a),
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", result)
    append_progress(output, case_id, result["family"], result["simulation_seconds"])
    return result


def load_checkpoint(output: Path, case_id: str, tick: int):
    with np.load(output / "CHECKPOINTS" / f"{case_id}.npz") as archive:
        return archive[f"t{tick}_raw"].copy(), archive[f"t{tick}_clock"].copy()


def run_cap_diagnostic(kernel, output: Path, parent_id: str, tick: int, q, qp) -> list[dict]:
    raw0, clock0 = load_checkpoint(output, parent_id, tick)
    results = []
    worlds = {}
    for mode in ("CONTROL", "UPDATE_PLUS5"):
        raw, clock = raw0.copy(), clock0.copy()
        writes = []
        if mode == "UPDATE_PLUS5":
            target = qp if tick % 2 == 0 else q
            writes.append(place_preserve_clock(raw, clock, target, 1, (-1, 0, 1), 98001, 2, "update_2"))
            writes.append(place_preserve_clock(raw, clock, target, 1, (-1, 0, -1), 98002, 3, "update_3"))
        world = World(kernel, raw, clock)
        trajectory = []
        for rel in range(3):
            trajectory.append({"relative_tick": rel, "q": read(world.raw_a, q), "qp": read(world.raw_a, qp)})
            if rel < 2:
                world.tick()
        worlds[mode] = (world.raw_a.copy(), world.clock_a.copy())
        case_id = f"DIAG_{parent_id}_T{tick}_{mode}"
        row = {
            "case_id": case_id, "family": "saturation_diagnostic_clone", "completed": True,
            "parent_case": parent_id, "parent_tick": tick, "mode": mode,
            "host_writes_in_clone": writes, "main_world_modified": False,
            "trajectory": trajectory, "terminal_raw_sha256": sha256_array(world.raw_a),
            "terminal_clock_sha256": sha256_array(world.clock_a), "simulation_seconds": 0.0,
        }
        dump(output / "CASES" / f"{case_id}.json", row)
        append_progress(output, case_id, row["family"], 0.0)
        results.append(row)
    raw_c, clock_c = worlds["CONTROL"]
    raw_u, clock_u = worlds["UPDATE_PLUS5"]
    comparison = {
        "parent_case": parent_id, "parent_tick": tick,
        "terminal_raw_different_voxels": int(np.count_nonzero(raw_c != raw_u)),
        "terminal_clock_different_voxels": int(np.count_nonzero(clock_c != clock_u)),
    }
    results[1]["paired_control_comparison"] = comparison
    dump(output / "CASES" / f"{results[1]['case_id']}.json", results[1])
    return results


def run_precondition_world(kernel, output: Path, mode: str) -> dict:
    case_id = f"PRECONDITION_{mode}"
    started = time.monotonic()
    spec = integrated_spec(case_id, "HA", "AB", 700)
    world, geometry, _ = p02.build_integrated(kernel, spec)
    q, qp = tuple(geometry["q"]), tuple(geometry["qp"])
    target = qp
    if mode == "SHAM":
        target = (qp[0], (qp[1] + 2) % N, qp[2])
    p02.place(world.raw_a, world.clock_a, target, 19, (1, 0, 1), 98100, 0, f"precondition_{mode.lower()}")
    world.raw_b[:] = world.raw_a
    world.clock_b[:] = world.clock_a
    snapshots = {}
    trace = []
    for tick in range(701):
        if tick in PRECONDITION_AGES or tick in (18, 19, 20, 21):
            trace.append(trace_oscillator(world, q, qp, tick))
        if tick in PRECONDITION_AGES:
            snapshots[f"t{tick}_raw"] = world.raw_a.copy()
            snapshots[f"t{tick}_clock"] = world.clock_a.copy()
        if tick < 700:
            world.tick()
    np.savez_compressed(output / "CHECKPOINTS" / f"{case_id}.npz", **snapshots)
    result = {
        "case_id": case_id, "family": "preconditioning_main", "completed": True,
        "mode": mode, "horizon": 700, "geometry": geometry, "trace": trace,
        "post_t0_host_writes": 0, "preinstalled_control_intervention": True,
        "terminal_raw_sha256": sha256_array(world.raw_a),
        "terminal_clock_sha256": sha256_array(world.clock_a),
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", result)
    append_progress(output, case_id, result["family"], result["simulation_seconds"])
    return result


def schedule_direction_task(raw, clock, q, qp, dose: int, transfer: bool,
                            return_mode: str, no_teacher_after_first: bool) -> tuple[list, list]:
    writes = []
    expected = []
    writes.append(place_preserve_clock(raw, clock, qp, 1, (1, 0, 1), 98200, 0, "route_to_z"))
    apos = add(qp, (0, 0, 1), 2, N)
    writes.append(place_preserve_clock(raw, clock, apos, 3, (1, 0, -1), 98201, 0, "route_to_a"))
    current_a = apos
    cycles = max(dose, 1)
    for cycle in range(cycles):
        train_tick = 4 + 4 * cycle
        sensor_site = add(current_a, (1, 0, 0), 1, N)
        learned_site = add(sensor_site, (0, 0, 1), 1, N)
        query_site = add(learned_site, (0, 1, 0), 1, N)
        if dose > 0:
            writes.append(place_preserve_clock(raw, clock, sensor_site, train_tick, (-1, 0, 1), 98210 + cycle * 10, 47, f"train_sensor_{cycle}"))
            if not (no_teacher_after_first and cycle > 0):
                writes.append(place_preserve_clock(raw, clock, learned_site, train_tick + 1, (1, 0, -1), 98211 + cycle * 10, 53, f"train_normalizer_{cycle}"))
                writes.append(place_preserve_clock(raw, clock, learned_site, train_tick + 1, (-1, 1, 0), 98212 + cycle * 10, 59, f"train_teacher_{cycle}"))
        query_direction = (0, -1, 1) if transfer and cycle == cycles - 1 else (-1, 0, 1)
        writes.append(place_preserve_clock(raw, clock, query_site, train_tick + 2, query_direction, 98213 + cycle * 10, 101, f"query_{cycle}"))
        expected.append({
            "cycle": cycle + 1, "train_tick": train_tick, "query_tick": train_tick + 2,
            "query_site": list(query_site),
            "expected_direction": [0, 0, 1] if transfer and cycle == cycles - 1 else [-1, 1, 1],
        })
        if cycle < cycles - 1:
            action = (0, 0, 1) if transfer else (-1, 1, 1)
            reset_site = add(query_site, action, 1, N)
            writes.append(place_preserve_clock(raw, clock, reset_site, train_tick + 3, (1, -1, -1), 98214 + cycle * 10, 0, f"reset_1_{cycle}"))
            writes.append(place_preserve_clock(raw, clock, reset_site, train_tick + 3, (1, 0, 0), 98215 + cycle * 10, 0, f"reset_2_{cycle}"))
            if cycle == 0 and return_mode in {"CUT", "SHAM", "SHAM_FAR"}:
                if return_mode == "CUT":
                    actual = reset_site
                elif return_mode == "SHAM":
                    actual = (reset_site[0], (reset_site[1] + 2) % N, reset_site[2])
                else:
                    actual = ((reset_site[0] + 11) % N, (reset_site[1] + 17) % N, reset_site[2])
                writes.append(place_preserve_clock(raw, clock, actual, train_tick + 3, (0, 0, 1), 98216, 0, f"self_return_{return_mode.lower()}"))
            current_a = reset_site
    return writes, expected


def run_direction_task(kernel, output: Path, parent_id: str, age: int, dose: int,
                       transfer: bool = False, return_mode: str = "INTACT",
                       no_teacher_after_first: bool = False) -> dict:
    started = time.monotonic()
    raw, clock = load_checkpoint(output, parent_id, age)
    parent_json = json.loads((output / "CASES" / f"{parent_id}.json").read_text(encoding="utf-8"))
    q, qp = tuple(parent_json["geometry"]["q"]), tuple(parent_json["geometry"]["qp"])
    suffix = "TRANSFER" if transfer else f"DOSE{dose}"
    if return_mode != "INTACT":
        suffix += f"_{return_mode}"
    if no_teacher_after_first:
        suffix += "_NO_TEACHER_AFTER_FIRST"
    case_id = f"TASK_{parent_id}_T{age}_{suffix}"
    try:
        writes, expected = schedule_direction_task(raw, clock, q, qp, dose, transfer, return_mode, no_teacher_after_first)
    except RuntimeError as exc:
        result = {
            "case_id": case_id, "family": "post_preconditioning_task", "completed": True,
            "task_admitted": False, "non_admission_reason": str(exc), "parent_case": parent_id,
            "age": age, "dose": dose, "transfer": transfer, "return_mode": return_mode,
            "no_teacher_after_first": no_teacher_after_first,
            "main_world_modified": False, "simulation_seconds": time.monotonic() - started,
        }
        dump(output / "CASES" / f"{case_id}.json", result)
        append_progress(output, case_id, result["family"], result["simulation_seconds"])
        return result
    world = World(kernel, raw, clock)
    horizon = max(row["query_tick"] for row in expected)
    records = []
    for rel in range(horizon + 1):
        for row in expected:
            if rel == row["query_tick"]:
                rec = read(world.raw_a, tuple(row["query_site"]))
                records.append({**row, "record": rec, "direction_match": bool(rec and rec["direction"] == row["expected_direction"])})
        if rel < horizon:
            world.tick()
    result = {
        "case_id": case_id, "family": "post_preconditioning_task", "completed": True,
        "task_admitted": True, "parent_case": parent_id, "age": age, "dose": dose,
        "transfer": transfer, "return_mode": return_mode,
        "no_teacher_after_first": no_teacher_after_first,
        "host_writes_in_diagnostic_clone": writes, "main_world_modified": False,
        "query_records": records, "matched_query_count": sum(row["direction_match"] for row in records),
        "terminal_raw_sha256": sha256_array(world.raw_a),
        "terminal_clock_sha256": sha256_array(world.clock_a),
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", result)
    append_progress(output, case_id, result["family"], result["simulation_seconds"])
    return result


def run_corrected_association(kernel, output: Path, schedule: str, test_present: bool) -> dict:
    label = schedule.upper()
    case_id = f"ASSOC_CORRECTED_{label}_{'TEST_B' if test_present else 'NO_TEST'}"
    started = time.monotonic()
    channels = "AB" if schedule != "none" else ""
    spec = integrated_spec(case_id, "HA", channels, 34)
    spec.update({"closure": True, "schedule": "unpaired" if schedule == "unpaired" else "paired"})
    world, geometry, _ = p02.build_integrated(kernel, spec)
    receiver = tuple(geometry["receiver"])
    if test_present:
        p02.place(world.raw_a, world.clock_a, receiver, 33, (0, -1, -1), 98300, 9, "corrected_B_test")
        world.raw_b[:] = world.raw_a
        world.clock_b[:] = world.clock_a
    trace = []
    for tick in range(35):
        if tick in (25, 32, 33, 34):
            trace.append({"tick": tick, "lineage_meet": read(world.raw_a, tuple(geometry["lineage_meet"])), "receiver": read(world.raw_a, receiver)})
        if tick < 34:
            world.tick()
    result = {
        "case_id": case_id, "family": "corrected_multichannel_association", "completed": True,
        "schedule": schedule, "test_present": test_present,
        "test_identity": {"load": 9, "direction": [0, -1, -1], "same_as_training_B": True} if test_present else None,
        "trace": trace, "post_t0_host_writes": 0,
        "terminal_raw_sha256": sha256_array(world.raw_a),
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", result)
    append_progress(output, case_id, result["family"], result["simulation_seconds"])
    return result


def run_environment_return(kernel, output: Path, mode: str) -> dict:
    case_id = f"ENV_RETURN_{mode}"
    started = time.monotonic()
    spec = integrated_spec(case_id, "HA", "AB", 55)
    spec.update({"closure": True, "test_present": True})
    world, geometry, _ = p02.build_integrated(kernel, spec)
    receiver = tuple(geometry["receiver"])
    env1 = add(receiver, (0, 1, 0), 4, N)
    env2 = add(env1, (0, 0, 1), 4, N)
    org2 = add(env2, (0, 1, 0), 6, N)
    final = add(org2, (1, 1, 0), 8, N)
    sources = {}
    sources["environment_carrier"] = p02.place(world.raw_a, world.clock_a, env1, 37, (0, -1, 1), 98400, 11, "environment_carrier")
    sources["general_supply"] = p02.place(world.raw_a, world.clock_a, env2, 41, (0, 1, -1), 98401, 13, "general_supply")
    sources["second_organization"] = p02.place(world.raw_a, world.clock_a, org2, 47, (1, 0, 0), 98402, 4102, "second_organization")
    sources["final_query"] = p02.place(world.raw_a, world.clock_a, final, 55, (0, -1, 0), 98403, 5, "final_query")
    if mode in {"RESPONSE_ENV_CUT", "RESPONSE_ENV_SHAM"}:
        actual = add(receiver, (0, 1, 0), 2, N)
        if mode.endswith("SHAM"):
            actual = (actual[0] + 2, actual[1], actual[2])
        sources["response_env_control"] = p02.place(world.raw_a, world.clock_a, actual, 35, (0, 0, 1), 98404, 0, mode.lower())
    if mode in {"RESPONSE_ENV_CUT_X", "RESPONSE_ENV_SHAM_FAR"}:
        actual = add(receiver, (0, 1, 0), 2, N)
        if mode.endswith("SHAM_FAR"):
            actual = ((actual[0] + 11) % N, (actual[1] + 17) % N, actual[2])
        sources["response_env_control_x"] = p02.place(world.raw_a, world.clock_a, actual, 35, (-1, 0, 0), 98406, 0, mode.lower())
    if mode in {"ENV_RETURN_CUT", "ENV_RETURN_SHAM"}:
        actual = add(env1, (0, 0, 1), 2, N)
        if mode.endswith("SHAM"):
            actual = (actual[0] + 2, actual[1], actual[2])
        sources["env_return_control"] = p02.place(world.raw_a, world.clock_a, actual, 39, (1, 0, 0), 98405, 0, mode.lower())
    world.raw_b[:] = world.raw_a
    world.clock_b[:] = world.clock_a
    points = {"response1": receiver, "environment_update": env1, "returned_stimulus": env2, "organization2": org2, "response2": final}
    trace = []
    for tick in range(56):
        if tick in (33, 35, 37, 39, 41, 47, 55):
            trace.append({"tick": tick, "records": {name: read(world.raw_a, pos) for name, pos in points.items()}})
        if tick < 55:
            world.tick()
    result = {
        "case_id": case_id, "family": "environmental_return", "completed": True,
        "mode": mode, "geometry": {name: list(pos) for name, pos in points.items()},
        "sources": {name: list(pos) for name, pos in sources.items()}, "trace": trace,
        "post_t0_host_writes": 0, "terminal_raw_sha256": sha256_array(world.raw_a),
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", result)
    append_progress(output, case_id, result["family"], result["simulation_seconds"])
    return result


def compare_cap_checkpoints(output: Path) -> list[dict]:
    rows = []
    ids = ("CAP_H0_AB", "CAP_HA_AB", "CAP_HA_ABC")
    for tick in (654, 656, 700):
        arrays = {case: load_checkpoint(output, case, tick) for case in ids}
        for left, right in ((ids[0], ids[1]), (ids[1], ids[2]), (ids[0], ids[2])):
            lr, lc = arrays[left]
            rr, rc = arrays[right]
            rows.append({
                "tick": tick, "left": left, "right": right,
                "raw_different_voxels": int(np.count_nonzero(lr != rr)),
                "clock_different_voxels": int(np.count_nonzero(lc != rc)),
                "raw_equal": bool(np.array_equal(lr, rr)),
                "clock_equal": bool(np.array_equal(lc, rc)),
            })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE))
    args = parser.parse_args()
    output = Path(args.output).resolve()
    (output / "CASES").mkdir(parents=True, exist_ok=True)
    (output / "CHECKPOINTS").mkdir(parents=True, exist_ok=True)
    progress = output / "case_progress.jsonl"
    if progress.exists():
        progress.unlink()
    started = time.monotonic()
    kernel, environment = load_kernel()
    zero = np.zeros((5, 5, 5), np.uint64)
    canary_world = World(kernel, zero, zero.copy())
    canary = {"kernel_report": canary_world.tick(), "raw_support_after_tick": int(np.count_nonzero(canary_world.raw_a))}
    cases = []

    for history, channels in (("H0", "AB"), ("HA", "AB"), ("HA", "ABC")):
        parent = run_cap_world(kernel, output, history, channels)
        cases.append(parent)
        q, qp = tuple(parent["geometry"]["q"]), tuple(parent["geometry"]["qp"])
        for checkpoint in (654, 656, 700):
            cases.extend(run_cap_diagnostic(kernel, output, parent["case_id"], checkpoint, q, qp))

    cases.append(run_precondition_world(kernel, output, "CUT"))
    cases.append(run_precondition_world(kernel, output, "SHAM"))

    group_ids = ("CAP_HA_AB", "PRECONDITION_CUT", "PRECONDITION_SHAM")
    for parent_id in group_ids:
        for age in PRECONDITION_AGES:
            for dose in (0, 1, 2, 4):
                cases.append(run_direction_task(kernel, output, parent_id, age, dose))
            cases.append(run_direction_task(kernel, output, parent_id, age, 1, transfer=True))

    # The ordinary dose-4 case above is the preregistered intact self-return arm.
    for mode in ("CUT", "SHAM"):
        cases.append(run_direction_task(kernel, output, "CAP_HA_AB", 64, 4, return_mode=mode))
    cases.append(run_direction_task(kernel, output, "CAP_HA_AB", 64, 4, no_teacher_after_first=True))

    for schedule in ("paired", "unpaired", "none"):
        cases.append(run_corrected_association(kernel, output, schedule, True))
        cases.append(run_corrected_association(kernel, output, schedule, False))

    for mode in ("INTACT", "RESPONSE_ENV_CUT", "RESPONSE_ENV_SHAM", "ENV_RETURN_CUT", "ENV_RETURN_SHAM"):
        cases.append(run_environment_return(kernel, output, mode))

    result = {
        "campaign_id": CAMPAIGN_ID, "environment": environment, "operational_canary": canary,
        "cases": cases, "cap_state_comparisons": compare_cap_checkpoints(output),
        "completed_case_count": sum(bool(case.get("completed")) for case in cases),
        "partial_case_count": sum(not bool(case.get("completed")) for case in cases),
        "admitted_task_count": sum(case.get("task_admitted") is True for case in cases),
        "nonadmitted_task_count": sum(case.get("task_admitted") is False for case in cases),
        "simulation_seconds": sum(float(case.get("simulation_seconds", 0.0)) for case in cases),
        "runner_wall_seconds": time.monotonic() - started,
        "main_world_post_host_writes": 0,
    }
    dump(output / "results.json", result)
    print(json.dumps({
        "completed": result["completed_case_count"], "partial": result["partial_case_count"],
        "admitted_tasks": result["admitted_task_count"], "nonadmitted_tasks": result["nonadmitted_task_count"],
        "simulation_seconds": result["simulation_seconds"], "wall_seconds": result["runner_wall_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
