#!/usr/bin/env python3
"""Targeted controls frozen after two near-sham/path-interference observations."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import run_p02_preconditioning_autocalibration as run


def main() -> None:
    started = time.monotonic()
    kernel, environment = run.load_kernel()
    result_path = HERE / "results.json"
    result = json.loads(result_path.read_text(encoding="utf-8"))
    new_cases = [
        run.run_direction_task(kernel, HERE, "CAP_HA_AB", 64, 4, return_mode="SHAM_FAR"),
        run.run_environment_return(kernel, HERE, "RESPONSE_ENV_CUT_X"),
        run.run_environment_return(kernel, HERE, "RESPONSE_ENV_SHAM_FAR"),
    ]
    result["cases"].extend(new_cases)
    result["completed_case_count"] = sum(bool(case.get("completed")) for case in result["cases"])
    result["partial_case_count"] = sum(not bool(case.get("completed")) for case in result["cases"])
    result["admitted_task_count"] = sum(case.get("task_admitted") is True for case in result["cases"])
    result["nonadmitted_task_count"] = sum(case.get("task_admitted") is False for case in result["cases"])
    result["simulation_seconds"] += sum(float(case.get("simulation_seconds", 0.0)) for case in new_cases)
    result["targeted_control_extension"] = {
        "reason": "The near sham crossed a later self-return trajectory and the z-directed response cut failed to intercept; both observations remain in the record.",
        "frozen_cases": [case["case_id"] for case in new_cases],
        "environment_revalidated": environment,
        "wall_seconds": time.monotonic() - started,
    }
    run.dump(result_path, result)
    print(json.dumps({"added": len(new_cases), "completed_total": result["completed_case_count"]}, indent=2))


if __name__ == "__main__":
    main()
