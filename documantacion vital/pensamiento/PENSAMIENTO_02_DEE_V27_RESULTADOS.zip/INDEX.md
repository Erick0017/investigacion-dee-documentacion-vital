# Índice de PENSAMIENTO 02

- `SCIENTIFIC_REPORT.md`: informe descriptivo integrado.
- `MEASUREMENT_SUMMARY.json`: reducción numérica por pregunta G/E/S/M, asociación y contraste vacío/organizado.
- `results.json`: telemetría final de 35 casos.
- `PILOT_INSERT_CONTROL_T10/`: piloto completo preservado antes de corregir el corte comparable.
- `CASES/`: JSON y checkpoints NPZ de cada caso final.
- `telemetry.npz`: panel y curvas recurrentes compactas.
- `run_pensamiento02.py`, `dee_v27_helpers.py`, `config.json`: reproducción autocontenida con el WHL externo identificado.
- `PREREGISTERED_PREDICTIONS.json`, `DESIGN_ADJUSTMENT_LOG.json`: predicciones y único reajuste de instrumentación.
- `SOURCE_REFERENCES.json`, `EXECUTION_LOG.json`, `REPRODUCTION.md`: procedencia, tiempos y reproducción.

No contiene una adjudicación científica global ni abre otra campaña.

## Continuación 2026-10-02 — preacondicionamiento y autocalibración

`CONTINUACIONES/PREACONDICIONAMIENTO_AUTOCALIBRACION_20261002/` añade, sin reemplazar lo anterior:

- 88 casos terminados y 0 parciales;
- trayectorias hasta t700 antes/durante/después del cap;
- checkpoints y sondas diagnósticas +5;
- comparación de recurrencia intacta, corte y sham a edades 64/654/700;
- tareas direccionales con dosis 0/1/2/4 y transferencia;
- asociación A–B con identidad física de B corregida;
- retorno de la propia respuesta, cortes y shams;
- dos usos consecutivos de una cadena ambiental mediada;
- informe, reducción numérica, runners exactos y reproducción.

Las intervenciones aplicadas a clones se mantienen separadas de los mundos principales. La continuación tampoco contiene una adjudicación científica global.
