# Reproducción breve

Con CPython 3.13 y el WHL v27 identificado en `config.json`, desde la raíz del paquete:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\run_pensamiento02.py' --output '.'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\analyze_pensamiento02.py'
```

El runner guarda cada caso como JSON y NPZ antes de comenzar el siguiente. El piloto preservado usa su propio runner exacto. No requiere copiar PENSAMIENTO 01; sus fuentes heredadas se registran por ruta y SHA-256.
