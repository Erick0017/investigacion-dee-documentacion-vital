#!/usr/bin/env python3
"""Descriptive reduction for PENSAMIENTO 02; no global scientific verdicts."""
from __future__ import annotations

import hashlib
import json
import time
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
TESTS = HERE.parents[1]
RESULT_PATH = HERE / "results.json"
PILOT_PATH = HERE / "PILOT_INSERT_CONTROL_T10" / "results_t10_control.json"
P01 = TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip"


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def rec(case: dict, key: str):
    return case["measured"].get(key)


def sreg(case: dict, key: str):
    value = rec(case, key)
    return None if value is None else int(value["sreg"])


def direction(case: dict, key: str):
    value = rec(case, key)
    return None if value is None else value["direction"]


def recurrence(case: dict) -> dict:
    first_failure = None
    correct = 0
    observations = []
    for row in case["trace"]:
        tick = int(row["tick"])
        if tick == 0:
            continue
        target = "qp" if tick % 2 else "q"
        record = row["records"].get(target)
        expected = [-1, 0, 0] if tick % 2 else [1, 0, 0]
        ok = record is not None and record["direction"] == expected
        if ok:
            correct += 1
        elif first_failure is None:
            first_failure = tick
        if tick <= 20 or tick in (32, 48, 64):
            observations.append({
                "tick": tick, "target": target, "expected_direction": expected,
                "record": record, "direction_correct": ok,
            })
    return {"correct_observed_ticks": correct, "first_direction_failure_tick": first_failure, "observations": observations}


def main() -> None:
    started = time.monotonic()
    result = load(RESULT_PATH)
    pilot = load(PILOT_PATH)
    by_id = {case["case_id"]: case for case in result["cases"]}

    panel = {}
    for subset in ("NONE", "A", "B", "C", "AB", "AC", "BC", "ABC"):
        case = by_id[f"PANEL_HA_{subset}"]
        panel[subset] = {
            "consequence_sreg_t6": sreg(case, "consequence_t6"),
            "consequence_direction_t6": direction(case, "consequence_t6"),
            "oscillator_q_sreg_t12": sreg(case, "oscillator_q_t12"),
            "retained_increment_over_baseline": sreg(case, "oscillator_q_t12") - 367,
        }

    generalization = {}
    for case_id in ("RESERVED_H0_AB", "RESERVED_HB_AB", "RESERVED_H0_ABC", "RESERVED_HB_ABC", "RESERVED_HA_AB_ALT_LOAD"):
        case = by_id[case_id]
        generalization[case_id] = {
            "history": case["spec"]["history"], "channels": case["spec"]["channels"],
            "channel_loads": case["spec"]["channel_loads"],
            "consequence_sreg_t6": sreg(case, "consequence_t6"),
            "consequence_direction_t6": direction(case, "consequence_t6"),
            "oscillator_q_sreg_t12": sreg(case, "oscillator_q_t12"),
        }

    sustain_ids = (
        "SUSTAIN_HA_AB", "SUSTAIN_HA_ABC", "SUSTAIN_H0_AB", "SUSTAIN_HB_AB",
        "SUSTAIN_HA_AB_FINITE", "SUSTAIN_HA_AB_MISSING",
    )
    sustainability = {}
    for case_id in sustain_ids:
        case = by_id[case_id]
        row64 = next(row for row in case["trace"] if int(row["tick"]) == 64)
        q64 = row64["records"]["q"]
        source_values = list(case["source_terminal"].values())
        sustainability[case_id] = {
            "source_mode": case["spec"]["source_mode"],
            "q_t12": sreg(case, "oscillator_q_t12"),
            "q_t64": None if q64 is None else int(q64["sreg"]),
            "q_direction_t64": None if q64 is None else q64["direction"],
            "support_t64": int(row64["raw_support"]),
            "source_count": len(source_values),
            "source_raw_invariant_count": sum(bool(row["raw_equal"]) for row in source_values),
            "source_clock_advanced_count": sum(int(row["clock_terminal"]) != int(row["clock_initial"]) for row in source_values),
            "recurrence": recurrence(case),
        }

    with np.load(HERE / "CASES" / "SUSTAIN_HA_AB.npz", allow_pickle=False) as ha_npz, np.load(
        HERE / "CASES" / "SUSTAIN_H0_AB.npz", allow_pickle=False
    ) as h0_npz:
        ha_raw, h0_raw = ha_npz["t64_raw"], h0_npz["t64_raw"]
        ha_clock, h0_clock = ha_npz["t64_clock"], h0_npz["t64_clock"]
        footprint = {
            "tick": 64,
            "raw_diff_positions_HA_AB_vs_H0_AB": int(np.count_nonzero(ha_raw != h0_raw)),
            "clock_diff_positions_HA_AB_vs_H0_AB": int(np.count_nonzero(ha_clock != h0_clock)),
            "HA_raw_support": int(np.count_nonzero(ha_raw)),
            "H0_raw_support": int(np.count_nonzero(h0_raw)),
        }

    closure_ids = (
        "CLOSURE_HA_AB", "CLOSURE_HA_AB_INSERT_CUT", "CLOSURE_HA_AB_INSERT_SHAM",
        "CLOSURE_HA_AB_RETURN_CUT", "CLOSURE_HA_AB_RETURN_SHAM",
        "CLOSURE_H0_AB", "CLOSURE_HB_AB", "CLOSURE_HA_ABC",
    )
    closure = {}
    for case_id in closure_ids:
        case = by_id[case_id]
        closure[case_id] = {
            "consequence_t6": sreg(case, "consequence_t6"),
            "oscillator_q_t12": sreg(case, "oscillator_q_t12"),
            "environment_q_t18": sreg(case, "environment_q_t18"),
            "environment_qp_t19": sreg(case, "environment_qp_t19"),
            "lineage_t25": sreg(case, "lineage_t25"),
            "lineage_direction_t25": direction(case, "lineage_t25"),
            "response_t33": sreg(case, "response_t33"),
            "response_direction_t33": direction(case, "response_t33"),
        }

    association = {}
    for case_id in (
        "ASSOC_PAIRED_TEST", "ASSOC_PAIRED_NO_TEST", "ASSOC_UNPAIRED_TEST",
        "ASSOC_UNPAIRED_NO_TEST", "ASSOC_NONE_TEST", "ASSOC_NONE_NO_TEST",
    ):
        case = by_id[case_id]
        association[case_id] = {
            "schedule": case["spec"]["schedule"], "channels": case["spec"]["channels"],
            "test_present": case["spec"]["test_present"],
            "oscillator_q_t12": sreg(case, "oscillator_q_t12"),
            "lineage_t25": sreg(case, "lineage_t25"),
            "response_t33": sreg(case, "response_t33"),
        }
    association["derived_contrasts"] = {
        "paired_test_increment": association["ASSOC_PAIRED_TEST"]["response_t33"] - association["ASSOC_PAIRED_NO_TEST"]["response_t33"],
        "unpaired_test_increment": association["ASSOC_UNPAIRED_TEST"]["response_t33"] - association["ASSOC_UNPAIRED_NO_TEST"]["response_t33"],
        "none_test_increment": association["ASSOC_NONE_TEST"]["response_t33"] - association["ASSOC_NONE_NO_TEST"]["response_t33"],
        "paired_state_difference_before_test": association["ASSOC_PAIRED_NO_TEST"]["response_t33"] - association["ASSOC_NONE_NO_TEST"]["response_t33"],
    }

    empty = {}
    for case_id in ("EMPTY_ABC", "EMPTY_NONE"):
        case = by_id[case_id]
        empty[case_id] = {
            "formation_t4": case["measured"]["formation_t4"],
            "probe_t12": case["measured"]["probe_t12"],
            "terminal_raw_sha256": case["terminal_raw_sha256"],
        }

    completed = int(result["completed_case_count"]) + int(pilot["completed_case_count"])
    partial = int(result["partial_case_count"]) + int(pilot["partial_case_count"])
    simulation_seconds = float(result["simulation_seconds"]) + float(pilot["simulation_seconds"])
    summary = {
        "campaign_id": result["campaign_id"],
        "case_accounting": {
            "completed_total": completed, "partial_total": partial,
            "final_cases": int(result["completed_case_count"]),
            "preserved_instrumentation_pilot_cases": int(pilot["completed_case_count"]),
        },
        "generalization": {"panel": panel, "reserved": generalization},
        "multichannel": {
            "channels": load(HERE / "PREREGISTERED_PREDICTIONS.json")["channels"],
            "panel": panel,
            "subsets_reaching_fixed_insertion": [name for name, row in panel.items() if row["retained_increment_over_baseline"] != 0],
            "sreg_reducer_relation": "additive below cap",
            "route_relation": "sign of the joint direction vector; only AB and ABC reach the fixed insertion in HA",
        },
        "environmental_closure": closure,
        "sustainability": sustainability,
        "sustainability_footprint": footprint,
        "cross_association": association,
        "empty_vs_organized": {
            "empty": empty,
            "organized_reference": {"HA_AB_q_t12": 391, "H0_AB_q_t12": 367, "difference_retained_to_t64": 24},
        },
        "host_boundary": {
            "post_t0_host_writes": int(result["post_t0_host_writes"]),
            "all_inputs_and_sources_preinstalled": True,
            "python_selected_next_stimulus_from_response": False,
        },
        "runtime": {
            "recorded_kernel_simulation_seconds": simulation_seconds,
            "final_runner_wall_seconds": float(result["runner_wall_seconds"]),
            "pilot_runner_wall_seconds": float(pilot["runner_wall_seconds"]),
            "analysis_seconds": None,
        },
        "scientific_global_verdict_generated": False,
    }
    summary["runtime"]["analysis_seconds"] = time.monotonic() - started
    dump(HERE / "MEASUREMENT_SUMMARY.json", summary)

    # Compact numeric arrays for independent plotting/reduction.
    panel_order = ("NONE", "A", "B", "C", "AB", "AC", "BC", "ABC")
    even_ticks = np.arange(2, 65, 2, dtype=np.int16)
    sustain_arrays = {}
    for case_id in ("SUSTAIN_HA_AB", "SUSTAIN_HA_ABC", "SUSTAIN_H0_AB", "SUSTAIN_HB_AB"):
        case = by_id[case_id]
        trace = {int(row["tick"]): row for row in case["trace"]}
        sustain_arrays[case_id] = np.array([
            -1 if trace[int(tick)]["records"]["q"] is None else trace[int(tick)]["records"]["q"]["sreg"]
            for tick in even_ticks
        ], dtype=np.int32)
    np.savez_compressed(
        HERE / "telemetry.npz",
        panel_consequence_sreg=np.array([panel[name]["consequence_sreg_t6"] for name in panel_order], dtype=np.int32),
        panel_consequence_direction=np.array([panel[name]["consequence_direction_t6"] for name in panel_order], dtype=np.int8),
        panel_q_t12=np.array([panel[name]["oscillator_q_sreg_t12"] for name in panel_order], dtype=np.int32),
        sustainability_even_ticks=even_ticks,
        **sustain_arrays,
    )

    source_candidates = [
        TESTS / "documantacion vital" / "pensamiento" / "PENSAMIENTO_01_DEE_V27_RESULTADOS.zip",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_01" / "REWRITE_WORK" / "RUNNERS" / "reset_apparatus_v1.py",
        TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_01" / "REWRITE_WORK" / "DEE_NATIVE_RESET_REPLENISHMENT.json",
        TESTS / "DEE_V27_MASTER_REVALIDATION_REBUILD_WORK" / "RUNNERS" / "run_c7h03_reprogrammable_functional_matter.py",
        TESTS / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA" / "dee_kernel_v27.cpp",
        HERE / "run_pensamiento02.py",
        HERE / "dee_v27_helpers.py",
    ]
    dump(HERE / "SOURCE_REFERENCES.json", {
        "sources": [
            {"path": str(path), "sha256": sha(path)} for path in source_candidates if path.is_file()
        ]
    })

    report = f"""# PENSAMIENTO 02 — Generalización, cierre ambiental, sostenibilidad e integración multicanal

## Aparato y frontera del host

Se construyó un único aparato principal que acopla tres mecanismos existentes: historia H0/HA/HB, reducer direccional multicanal, oscilador recurrente R04 con cuatro fuentes `semantic=4` y linaje móvil C7H03. Todos los eventos, fuentes, consultas y controles fueron instalados en `t0`. Después sólo se ejecutó el kernel y se realizaron lecturas/checkpoints. Se preservó un piloto completo cuyo corte de inserción t10 no interceptó el payload; el control final movió únicamente ese deflector al encuentro medido de t8.

## Generalización

La geometría, el receptor y la lectura permanecieron fijos. En HA, el panel completo produjo en t6:

- ninguno: 7, dirección `(1,1,0)`;
- A: 15, `(1,0,1)`; B: 16, `(1,0,-1)`; C: 11, `(1,0,0)`;
- AB: 24, `(1,-1,0)`; AC: 19, `(1,-1,1)`; BC: 20, `(1,-1,-1)`;
- ABC: 28, `(1,-1,0)`.

Sólo AB y ABC alcanzaron el puerto fijo: el oscilador pasó de su baseline 367 a 391 y 395 en t12. Las preparaciones reservadas H0/HB con AB o ABC permanecieron en 367. Una distribución de cargas nueva A=5/B=12, con la misma suma 17, reprodujo 24 y 391. Esto caracteriza el contrato aditivo/rutado del sector y su especificidad histórica; no constituye por sí solo aprendizaje de una regla numérica. HA/AB y HB/BA comparten inventario, pero el aparato no añade un tramo final común, por lo que no separa el orden de toda variable de último evento/fase.

## Integración multicanal

Los tres canales conservaron puertos, direcciones y codificadores fijos. La carga `s_reg` se sumó bajo el cap; la dirección conjunta dependió del signo de la suma vectorial. A y B por separado no alcanzaron el oscilador, mientras su coincidencia AB sí; C aumentó el estado retenido de 24 a 28 sin cambiar esa ruta. El producto fusionado perdió la identidad individual de contribuciones en esta lectura. Se observaron coincidencia, respuesta conjunta, modificación retenida y uso posterior; no se midió adquisición de una regla nueva para integrar futuras entradas.

## Cierre ambiental

En HA+AB, el payload 24 entró en el oscilador en t12: q=391. Tras tres ciclos, q(t18)=571. En t19, el estado ambiental desviado fue 595; en t25 actualizó el linaje C7H03 de 4102 a 4697; una prueba común 7 produjo 4704 en t33. H0/HB y el corte de inserción siguieron 367→547→571→4673→4680. ABC siguió 395→575→599→4701→4708.

El corte de retorno mantuvo q(t12)=391 y el ambiente t19=595, pero el linaje quedó en 4102 y en el receptor apareció sólo la prueba 7. Los shams de inserción y retorno reprodujeron 4704. Estos contrastes separan la ruta mediada por el oscilador de una llegada directa de la historia al linaje dentro de este montaje.

## Sostenibilidad operacional

Con las cuatro fuentes persistentes, q presentó la dirección prevista en los 32 finales pares de ciclo hasta t64; la alternancia q/qp coincidió además en todos los 44 blancos registrados. En t64 se midió H0/HB=1927, HA+AB=1951 y HA+ABC=1955: las diferencias 24 y 28 permanecieron. Los cuatro RAW fuente fueron invariantes y sus clocks avanzaron. No se añadió nodo, copia o recurso por episodio. La carga creció 60 por ciclo y permaneció por debajo del cap 19664; el horizonte no demuestra duración infinita y expone acumulación finita.

Con fuentes normales finitas la recurrencia dejó de ocupar el blanco esperado; con una fuente persistente ausente cambió la ley y q(t64)=36. Estos controles separan la continuidad de la mera presencia inicial del policy carrier. En t64, HA+AB frente a H0+AB difirió en {footprint['raw_diff_positions_HA_AB_vs_H0_AB']} posiciones RAW y {footprint['clock_diff_positions_HA_AB_vs_H0_AB']} posiciones clock; sus soportes RAW fueron {footprint['HA_raw_support']} y {footprint['H0_raw_support']}.

## Asociación cruzada

El emparejamiento simultáneo AB dejó +24 antes de presentar la prueba B: sin prueba, t33 fue 4697 frente a 4673 en no emparejado/ninguno. La prueba añadió exactamente 7 en los tres fondos: 4704−4697, 4680−4673 y 4680−4673. Por ello este aparato muestra retención específica del emparejamiento/ruta, pero el contraste con ausencia de prueba atribuye la diferencia a un estado residual previo, no a evocación específica adquirida por B.

## Interior vacío y medio organizado

En el interior inicialmente vacío, ABC formó en t4 un producto 21 dirección `(0,-1,0)`. En t12, la sonda común en el sitio original produjo 5 dirección `(1,0,0)`, exactamente igual al mundo sin ABC. Los hashes terminales globales no fueron iguales porque el producto continuó en otra región, pero no se observó una ruta funcional retenida en el lector fijado. En el medio organizado, los mismos tipos de contribución pudieron insertarse y persistir en el oscilador. Este contraste no generaliza una imposibilidad para sustratos vacíos.

## Contabilidad y límites

Se completaron {completed} casos y quedaron {partial} parciales: 35 en el piloto de instrumentación preservado y 35 en la ejecución final. El kernel acumuló {simulation_seconds:.3f} s registrados. No se ejecutaron cinco canales, asociación reversible, entrada durante runtime, reposición de la carga acumulada, cámara/audio reales, clasificación externa de RAW ni una plataforma. No se generó un dictamen científico global.
"""
    (HERE / "SCIENTIFIC_REPORT.md").write_text(report, encoding="utf-8")

    reproduction = r"""# Reproducción breve

Con CPython 3.13 y el WHL v27 identificado en `config.json`, desde la raíz del paquete:

```powershell
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\run_pensamiento02.py' --output '.'
& 'D:\Descargas\ANACONDA MINICONDA\python.exe' -I -B '.\analyze_pensamiento02.py'
```

El runner guarda cada caso como JSON y NPZ antes de comenzar el siguiente. El piloto preservado usa su propio runner exacto. No requiere copiar PENSAMIENTO 01; sus fuentes heredadas se registran por ruta y SHA-256.
"""
    (HERE / "REPRODUCTION.md").write_text(reproduction, encoding="utf-8")

    dump(HERE / "EXECUTION_LOG.json", {
        "completed_cases": completed, "partial_cases": partial,
        "final_runner_simulation_seconds": result["simulation_seconds"],
        "pilot_runner_simulation_seconds": pilot["simulation_seconds"],
        "recorded_kernel_simulation_seconds_total": simulation_seconds,
        "analysis_seconds": summary["runtime"]["analysis_seconds"],
        "packaging_seconds": "TO_BE_RECORDED_BY_PACKAGER",
        "post_t0_host_writes": 0,
    })
    print(json.dumps({
        "completed": completed, "partial": partial,
        "kernel_seconds": simulation_seconds,
        "analysis_seconds": summary["runtime"]["analysis_seconds"],
        "footprint": footprint,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
