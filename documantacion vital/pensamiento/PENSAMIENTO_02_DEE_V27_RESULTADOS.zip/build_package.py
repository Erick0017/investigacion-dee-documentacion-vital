#!/usr/bin/env python3
"""Build and validate the single official PENSAMIENTO 02 package."""
from __future__ import annotations

import hashlib
import json
import os
import time
import zipfile
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
TESTS = HERE.parents[1]
WORK = HERE.parent
OFFICIAL_DIR = TESTS / "documantacion vital" / "pensamiento 2"
OFFICIAL = OFFICIAL_DIR / "PENSAMIENTO_02_DEE_V27_RESULTADOS.zip"
TEMP = WORK / "PENSAMIENTO_02_DEE_V27_RESULTADOS.tmp.zip"


def sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def files():
    return sorted(
        (path for path in HERE.rglob("*") if path.is_file() and "__pycache__" not in path.parts),
        key=lambda path: path.relative_to(HERE).as_posix(),
    )


def load(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def dump(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def measured(case: dict, key: str):
    record = case["measured"].get(key)
    return None if record is None else int(record["sreg"])


def main() -> None:
    started = time.monotonic()
    config = load(HERE / "config.json")
    parent = Path(config["parent_pensamiento_01"]["path"])
    parent_hash = sha_file(parent)
    if parent_hash != config["parent_pensamiento_01"]["sha256"]:
        raise RuntimeError(f"PENSAMIENTO 01 changed: {parent_hash}")

    required = (
        "run_pensamiento02.py", "dee_v27_helpers.py", "analyze_pensamiento02.py",
        "build_package.py", "config.json", "PREREGISTERED_PREDICTIONS.json",
        "DESIGN_ADJUSTMENT_LOG.json", "results.json", "telemetry.npz",
        "MEASUREMENT_SUMMARY.json", "SOURCE_REFERENCES.json", "EXECUTION_LOG.json",
        "SCIENTIFIC_REPORT.md", "REPRODUCTION.md", "INDEX.md",
        "PILOT_INSERT_CONTROL_T10/results_t10_control.json",
        "PILOT_INSERT_CONTROL_T10/run_pensamiento02_t10_control.py",
    )
    missing = [name for name in required if not (HERE / name).is_file()]
    if missing:
        raise RuntimeError(f"missing required files: {missing}")

    json_count = jsonl_count = npz_count = 0
    for path in files():
        suffix = path.suffix.lower()
        if suffix == ".json":
            load(path)
            json_count += 1
        elif suffix == ".jsonl":
            for line in path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    json.loads(line)
            jsonl_count += 1
        elif suffix == ".npz":
            with np.load(path, allow_pickle=False) as data:
                for name in data.files:
                    _ = data[name].shape
            npz_count += 1

    result = load(HERE / "results.json")
    pilot = load(HERE / "PILOT_INSERT_CONTROL_T10" / "results_t10_control.json")
    summary = load(HERE / "MEASUREMENT_SUMMARY.json")
    by_id = {case["case_id"]: case for case in result["cases"]}
    exact = {
        "PANEL_HA_AB": (24, 391), "PANEL_HA_ABC": (28, 395),
        "PANEL_HA_A": (15, 367), "PANEL_HA_B": (16, 367),
        "RESERVED_H0_AB": (17, 367), "RESERVED_HB_AB": (17, 367),
    }
    for case_id, (consequence, q12) in exact.items():
        case = by_id[case_id]
        if measured(case, "consequence_t6") != consequence or measured(case, "oscillator_q_t12") != q12:
            raise RuntimeError(f"panel telemetry changed: {case_id}")
    closure_expected = {
        "CLOSURE_HA_AB": (391, 595, 4697, 4704),
        "CLOSURE_HA_AB_INSERT_CUT": (367, 571, 4673, 4680),
        "CLOSURE_HA_AB_INSERT_SHAM": (391, 595, 4697, 4704),
        "CLOSURE_HA_AB_RETURN_CUT": (391, 595, 4102, 7),
        "CLOSURE_HA_AB_RETURN_SHAM": (391, 595, 4697, 4704),
        "CLOSURE_H0_AB": (367, 571, 4673, 4680),
        "CLOSURE_HA_ABC": (395, 599, 4701, 4708),
    }
    for case_id, expected in closure_expected.items():
        case = by_id[case_id]
        actual = (
            measured(case, "oscillator_q_t12"), measured(case, "environment_qp_t19"),
            measured(case, "lineage_t25"), measured(case, "response_t33"),
        )
        if actual != expected:
            raise RuntimeError(f"closure telemetry changed: {case_id} {actual} != {expected}")
    if summary["case_accounting"] != {
        "completed_total": 70, "final_cases": 35,
        "partial_total": 0, "preserved_instrumentation_pilot_cases": 35,
    }:
        raise RuntimeError("case accounting changed")
    if any(int(case["post_t0_host_writes"]) != 0 for case in result["cases"]):
        raise RuntimeError("post-t0 host-write contract violated")

    execution = load(HERE / "EXECUTION_LOG.json")
    execution["packaging_precompression_seconds"] = time.monotonic() - started
    execution["total_work_span_seconds_before_compression"] = max(0.0, time.time() - WORK.stat().st_ctime)
    execution["time_scope_note"] = "work-directory creation through precompression; final compression follows"
    dump(HERE / "EXECUTION_LOG.json", execution)

    dump(HERE / "PACKAGE_VALIDATION.json", {
        "parent_pensamiento01_sha256": parent_hash,
        "parent_pensamiento01_unchanged": True,
        "required_files_present": True,
        "json_files_parsed": json_count,
        "jsonl_files_parsed": jsonl_count,
        "npz_files_opened": npz_count,
        "measurement_invariants_checked": True,
        "completed_cases": 70,
        "partial_cases": 0,
        "post_t0_host_writes": 0,
        "scientific_global_verdict_generated": False,
        "zip_crc_and_manifest": "validated by build_package.py before installation",
    })

    hashes = []
    for path in files():
        if path.name in {"HASHES.sha256", "MANIFEST.json"}:
            continue
        hashes.append(f"{sha_file(path)}  {path.relative_to(HERE).as_posix()}")
    (HERE / "HASHES.sha256").write_text("\n".join(hashes) + "\n", encoding="utf-8")

    manifest_entries = []
    for path in files():
        rel = path.relative_to(HERE).as_posix()
        if rel == "MANIFEST.json":
            continue
        manifest_entries.append({"path": rel, "size": path.stat().st_size, "sha256": sha_file(path)})
    dump(HERE / "MANIFEST.json", {
        "campaign_id": config["campaign_id"],
        "author": config["author"],
        "parent_pensamiento01_sha256": parent_hash,
        "completed_cases": 70,
        "partial_cases": 0,
        "hash_scope": "all files except MANIFEST.json",
        "files": manifest_entries,
    })

    OFFICIAL_DIR.mkdir(parents=True, exist_ok=True)
    if TEMP.exists():
        TEMP.unlink()
    with zipfile.ZipFile(TEMP, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files():
            archive.write(path, path.relative_to(HERE).as_posix())
    expected_names = {path.relative_to(HERE).as_posix() for path in files()}
    with zipfile.ZipFile(TEMP, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"temporary ZIP CRC failed at {bad}")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("temporary ZIP member mismatch")
        for line in archive.read("HASHES.sha256").decode("utf-8").splitlines():
            expected_hash, rel = line.split("  ", 1)
            if sha_bytes(archive.read(rel)) != expected_hash:
                raise RuntimeError(f"HASHES mismatch: {rel}")
        manifest = json.loads(archive.read("MANIFEST.json").decode("utf-8"))
        for entry in manifest["files"]:
            if sha_bytes(archive.read(entry["path"])) != entry["sha256"]:
                raise RuntimeError(f"MANIFEST mismatch: {entry['path']}")

    final_hash = sha_file(TEMP)
    os.replace(TEMP, OFFICIAL)
    if sha_file(OFFICIAL) != final_hash:
        raise RuntimeError("official hash mismatch after atomic replacement")
    with zipfile.ZipFile(OFFICIAL, "r") as archive:
        bad = archive.testzip()
        if bad:
            raise RuntimeError(f"official ZIP CRC failed at {bad}")
        if set(archive.namelist()) != expected_names:
            raise RuntimeError("official ZIP member mismatch")
    if sha_file(parent) != parent_hash:
        raise RuntimeError("PENSAMIENTO 01 changed during packaging")
    print(json.dumps({
        "official_path": str(OFFICIAL), "sha256": final_hash,
        "members": len(expected_names), "completed": 70, "partial": 0,
        "zip_valid": True, "manifest_valid": True,
        "pensamiento01_unchanged": True,
    }, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
