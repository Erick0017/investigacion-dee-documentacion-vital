#!/usr/bin/env python3
"""Self-contained v27 helpers used by PENSAMIENTO 02."""
from __future__ import annotations

import hashlib
import importlib
import json
import platform
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
CONFIG = json.loads((HERE / "config.json").read_text(encoding="utf-8"))
STATE_MASK = np.uint64((1 << 32) - 1)
SREG_MASK = np.uint64(0xFFFF)
SEM_MASK = np.uint64(0xF)
PATTERN_A = ((-1, 0, 0), (-1, 1, 1), (0, 0, 1), (0, 1, 0))
PATTERN_B = ((0, -1, 0), (0, 0, -1), (1, -1, -1), (1, 0, 0))


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def sha256_array(array: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(array).tobytes()).hexdigest()


def load_kernel():
    expected = CONFIG["kernel"]
    paths = {key: Path(expected[key]) for key in ("wheel_path", "package_path", "binary_path")}
    observed = {
        "wheel_sha256": sha256_file(paths["wheel_path"]),
        "package_sha256": sha256_file(paths["package_path"]),
        "binary_sha256": sha256_file(paths["binary_path"]),
    }
    for key, value in observed.items():
        if value != expected[key]:
            raise RuntimeError(f"kernel identity mismatch: {key}={value}")
    sys.path.insert(0, str(paths["package_path"].parent.parent))
    importlib.invalidate_caches()
    import dee_universe_v27 as package
    from dee_universe_v27 import dee_kernel_v27 as kernel
    if Path(package.__file__).resolve() != paths["package_path"].resolve():
        raise RuntimeError("unexpected v27 package import")
    if Path(kernel.__file__).resolve() != paths["binary_path"].resolve():
        raise RuntimeError("unexpected v27 binary import")
    return kernel, {
        "paths": {key: str(path.resolve()) for key, path in paths.items()},
        "hashes": observed,
        "python": sys.version,
        "numpy": np.__version__,
        "platform": platform.platform(),
    }


def pack(state: int, sreg: int, direction=(0, 0, 0), semantic: int = 1) -> np.uint64:
    return np.uint64(
        (state & 0xFFFFFFFF) | ((sreg & 0xFFFF) << 32)
        | ((direction[0] & 0xF) << 48) | ((direction[1] & 0xF) << 52)
        | ((direction[2] & 0xF) << 56) | ((semantic & 0xF) << 60)
    )


def signed_nibble(value, shift: int) -> int:
    x = (int(value) >> shift) & 0xF
    return x - 16 if x >= 8 else x


def read(raw: np.ndarray, q):
    value = np.uint64(raw[q])
    if int(value) == 0:
        return None
    return {
        "raw": int(value),
        "state": int(value & STATE_MASK),
        "sreg": int((value >> np.uint64(32)) & SREG_MASK),
        "direction": [signed_nibble(value, shift) for shift in (48, 52, 56)],
        "semantic": int((value >> np.uint64(60)) & SEM_MASK),
    }


def add(q, direction, count: int, n: int):
    return tuple((int(q[i]) + int(count) * int(direction[i])) % n for i in range(3))


def put(raw, clock, q, state, sreg, direction=(0, 0, 0), semantic=1, phase=0, label=""):
    if int(raw[q]):
        raise RuntimeError(f"initial overlap at {q}: {label}; existing={read(raw, q)}")
    raw[q] = pack(state, sreg, direction, semantic)
    clock[q] = np.uint64(phase)


def place_arrival(raw, clock, target, tick, direction, state, sreg, semantic=1, phase=0, label=""):
    source = add(target, direction, -tick, raw.shape[0])
    put(raw, clock, source, state, sreg, direction, semantic, phase, label)
    return source


class World:
    def __init__(self, kernel, raw, clock):
        self.kernel = kernel
        self.n = int(raw.shape[0])
        self.raw_a = np.ascontiguousarray(raw, dtype=np.uint64).copy()
        self.raw_b = self.raw_a.copy()
        self.clock_a = np.ascontiguousarray(clock, dtype=np.uint64).copy()
        self.clock_b = self.clock_a.copy()

    def tick(self):
        return {str(k): int(v) for k, v in dict(self.kernel.tick_universo_lazy(
            self.raw_a, self.raw_b, self.clock_a, self.clock_b, self.n, 1
        )).items()}


def install_event(raw, clock, memory, target_offset, direction, when, n, state_base, sreg=3):
    target = add(memory, target_offset, 1, n)
    if when == "early":
        put(raw, clock, target, state_base, sreg, direction, 1, 17, "history_early")
        return target
    if when == "late":
        source = add(target, direction, -1, n)
        put(raw, clock, source, 0, sreg, direction, 1, 19, "history_late")
        return source
    raise ValueError(when)


def build_history_arrays(n: int, origin, mode: str):
    c = tuple(origin)
    axis = (1, 0, 0)
    a = add(c, (-1, 0, 0), 1, n)
    b = add(c, axis, 1, n)
    raw = np.zeros((n, n, n), np.uint64)
    clock = np.zeros_like(raw)
    put(raw, clock, a, 1000, 100, semantic=1, phase=260, label="memory_a")
    put(raw, clock, b, 2000, 100, semantic=1, phase=260, label="memory_b")
    for i, offset in enumerate(PATTERN_A):
        put(raw, clock, add(a, offset, 1, n), 3000 + i, 0, semantic=4, phase=31 + i, label=f"support_a_{i}")
    for i, offset in enumerate(PATTERN_B):
        put(raw, clock, add(b, offset, 1, n), 4000 + i, 0, semantic=4, phase=41 + i, label=f"support_b_{i}")
    schedule = {"H0": (None, None), "HA": ("early", "late"), "HB": ("late", "early")}[mode]
    event_sources = []
    if schedule[0]:
        event_sources.append(install_event(raw, clock, a, (0, -1, 0), (0, 0, -1), schedule[0], n, 5000, 0))
    if schedule[1]:
        event_sources.append(install_event(raw, clock, b, (0, 1, 0), (0, 0, 1), schedule[1], n, 5001, 0))
    reader_source = add(c, (0, -2, 0), 1, n)
    put(raw, clock, reader_source, 6000, 7, (0, 1, 0), semantic=4, phase=23, label="reader_source")
    return raw, clock, {
        "a": a, "b": b, "comparator": c, "reader_source": reader_source,
        "event_sources": event_sources, "axis": axis,
    }
