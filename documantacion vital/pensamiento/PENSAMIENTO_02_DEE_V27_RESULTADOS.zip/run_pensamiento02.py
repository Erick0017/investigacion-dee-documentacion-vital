#!/usr/bin/env python3
"""PENSAMIENTO 02: multichannel history, recurrent environment, and return."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

from dee_v27_helpers import (
    World, add, build_history_arrays, load_kernel, place_arrival, put, read,
    sha256_array,
)

CAMPAIGN_ID = "PENSAMIENTO_02_DEE_V27_GENERALIZATION_CLOSURE_SUSTAINABILITY_MULTICHANNEL"
N = 127
ORIGIN = (30, 30, 30)
P = (1, 0, 0)
S1, S2 = (-1, 1, 0), (-1, -1, 0)
N1, N2 = (1, 0, 1), (1, 0, -1)
CHANNELS = {
    "A": {"load": 8, "direction": (0, -1, 1)},
    "B": {"load": 9, "direction": (0, -1, -1)},
    "C": {"load": 4, "direction": (0, -1, 0)},
}
CONSEQUENCE_TICK = 6
REDIRECT_TICK = 8
INSERT_CUT_TICK = 10
INSERT_TICK = 12
ENV_DIVERT_TICK = 19
ENV_RETURN_CUT_TICK = 22
LINEAGE_MEET_TICK = 25
TEST_TICK = 33


def dump(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, ensure_ascii=False) + "\n", encoding="utf-8")


def place(raw, clock, target, tick, direction, state, sreg, label, semantic=1):
    return place_arrival(raw, clock, target, tick, direction, state, sreg, semantic, 0, label)


def record_points(raw, points):
    return {name: read(raw, q) for name, q in points.items()}


def source_spec(q, qp):
    return (
        (add(qp, S1, -1, N), S1, 11),
        (add(qp, S2, -1, N), S2, 13),
        (add(q, N1, -2, N), N1, 17),
        (add(q, N2, -2, N), N2, 19),
    )


def build_integrated(kernel, spec):
    raw, clock, history_ports = build_history_arrays(N, ORIGIN, spec["history"])
    comparator = tuple(history_ports["comparator"])
    consequence = add(comparator, (1, 1, 0), CONSEQUENCE_TICK - 3, N)
    sources = {}
    channel_loads = {name: int(spec.get("channel_loads", {}).get(name, CHANNELS[name]["load"])) for name in CHANNELS}
    for index, name in enumerate(spec["channels"], start=1):
        tick = CONSEQUENCE_TICK
        if spec.get("schedule") == "unpaired" and name == "B":
            tick += 1
        item = CHANNELS[name]
        sources[f"channel_{name}"] = place(
            raw, clock, consequence, tick, item["direction"],
            90000 + index, channel_loads[name], f"channel_{name}",
        )

    redirect_site = add(consequence, (1, -1, 0), REDIRECT_TICK - CONSEQUENCE_TICK, N)
    sources["history_redirect"] = place(
        raw, clock, redirect_site, REDIRECT_TICK, (0, 1, 0), 90010, 0, "history_redirect"
    )
    q = add(redirect_site, P, INSERT_TICK - REDIRECT_TICK, N)
    qp = add(q, P, 1, N)
    put(raw, clock, q, 1, 7, P, 1, 11, "oscillator_policy")

    oscillator_source_positions = []
    for index, (pos, direction, load) in enumerate(source_spec(q, qp)):
        if spec["source_mode"] == "missing" and index == 0:
            continue
        semantic = 1 if spec["source_mode"] == "finite" else 4
        put(raw, clock, pos, 91000 + index, load, direction, semantic,
            100000 + index, f"oscillator_source_{index}")
        oscillator_source_positions.append(pos)

    if spec["insert_link"] in {"cut", "sham"}:
        cut_target = redirect_site
        if spec["insert_link"] == "sham":
            cut_target = (cut_target[0], (cut_target[1] + 2) % N, cut_target[2])
        sources["insert_deflector"] = place(
            raw, clock, cut_target, REDIRECT_TICK, (0, 0, 1), 90020, 0,
            f"insert_{spec['insert_link']}",
        )

    geometry = {
        "history_ports": {k: list(v) if isinstance(v, tuple) else [list(x) for x in v] if isinstance(v, list) else v for k, v in history_ports.items()},
        "consequence": list(consequence), "redirect": list(redirect_site),
        "q": list(q), "qp": list(qp),
        "oscillator_sources": [list(pos) for pos in oscillator_source_positions],
    }

    if spec["closure"]:
        sources["environment_diverter"] = place(
            raw, clock, qp, ENV_DIVERT_TICK, (1, 0, 1), 90030, 0, "environment_diverter"
        )
        return_cut_site = add(qp, (0, 0, 1), ENV_RETURN_CUT_TICK - ENV_DIVERT_TICK, N)
        if spec["return_link"] in {"cut", "sham"}:
            actual = return_cut_site
            if spec["return_link"] == "sham":
                actual = (actual[0], (actual[1] + 2) % N, actual[2])
            sources["return_deflector"] = place(
                raw, clock, actual, ENV_RETURN_CUT_TICK, (1, 0, 0), 90031, 0,
                f"return_{spec['return_link']}",
            )

        lineage_meet = add(qp, (0, 0, 1), LINEAGE_MEET_TICK - ENV_DIVERT_TICK, N)
        lineage_junction = add(lineage_meet, (0, 1, 0), -(LINEAGE_MEET_TICK - 5), N)
        sources["lineage_cue"] = place(
            raw, clock, lineage_junction, 5, (1, 0, 0), 90040, 4096 - 13, "lineage_cue"
        )
        sources["lineage_teacher"] = place(
            raw, clock, lineage_junction, 5, (-1, 1, 0), 90041, 13 + 6, "lineage_teacher"
        )
        receiver = add(lineage_meet, (0, 1, 1), TEST_TICK - LINEAGE_MEET_TICK, N)
        if spec["test_present"]:
            sources["test_B"] = place(
                raw, clock, receiver, TEST_TICK, (0, 0, -1), 90042, 7, "test_B"
            )
        geometry.update({
            "return_cut_site": list(return_cut_site),
            "lineage_junction": list(lineage_junction),
            "lineage_meet": list(lineage_meet), "receiver": list(receiver),
        })

    geometry["sources"] = {name: list(pos) for name, pos in sources.items()}
    return World(kernel, raw, clock), geometry, oscillator_source_positions


def run_integrated_case(kernel, spec, output: Path):
    started = time.monotonic()
    world, geometry, source_positions = build_integrated(kernel, spec)
    initial_sources = {str(pos): {"raw": int(world.raw_a[pos]), "clock": int(world.clock_a[pos])} for pos in source_positions}
    points = {
        "history_reader": (ORIGIN[0], ORIGIN[1] - 1, ORIGIN[2]),
        "history_comparator": tuple(geometry["history_ports"]["comparator"]),
        "consequence": tuple(geometry["consequence"]),
        "redirect": tuple(geometry["redirect"]),
        "q": tuple(geometry["q"]), "qp": tuple(geometry["qp"]),
    }
    if spec["closure"]:
        points.update({
            "return_cut_site": tuple(geometry["return_cut_site"]),
            "lineage_junction": tuple(geometry["lineage_junction"]),
            "lineage_meet": tuple(geometry["lineage_meet"]),
            "receiver": tuple(geometry["receiver"]),
        })
    key_ticks = set(range(0, min(spec["horizon"], 20) + 1)) | {22, 25, 33, spec["horizon"]}
    key_ticks = {tick for tick in key_ticks if 0 <= tick <= spec["horizon"]}
    full_ticks = {12, spec["horizon"]}
    if spec["closure"]:
        full_ticks |= {19, 25, 33}
    trace, snapshots, kernel_events = [], {}, []
    for tick in range(spec["horizon"] + 1):
        if tick in key_ticks or (spec["family"] == "sustainability" and tick % 2 == 0):
            trace.append({
                "tick": tick,
                "records": record_points(world.raw_a, points),
                "raw_support": int(np.count_nonzero(world.raw_a)),
                "raw_sha256": sha256_array(world.raw_a),
                "clock_sha256": sha256_array(world.clock_a),
            })
        if tick in full_ticks:
            snapshots[f"t{tick}_raw"] = world.raw_a.copy()
            snapshots[f"t{tick}_clock"] = world.clock_a.copy()
        if tick < spec["horizon"]:
            info = world.tick()
            if info.get("overflows", 0) or info.get("genesis", 0):
                kernel_events.append({"tick": tick + 1, **info})
    by_tick = {row["tick"]: row for row in trace}
    source_terminal = {}
    for pos in source_positions:
        key = str(pos)
        source_terminal[key] = {
            "raw_initial": initial_sources[key]["raw"],
            "raw_terminal": int(world.raw_a[pos]),
            "raw_equal": int(world.raw_a[pos]) == initial_sources[key]["raw"],
            "clock_initial": initial_sources[key]["clock"],
            "clock_terminal": int(world.clock_a[pos]),
        }
    measured = {
        "history_reader_t2": by_tick.get(2, {}).get("records", {}).get("history_reader"),
        "history_output_t3": by_tick.get(3, {}).get("records", {}).get("history_comparator"),
        "consequence_t6": by_tick.get(6, {}).get("records", {}).get("consequence"),
        "redirect_t8": by_tick.get(8, {}).get("records", {}).get("redirect"),
        "oscillator_q_t12": by_tick.get(12, {}).get("records", {}).get("q"),
    }
    if spec["closure"]:
        measured.update({
            "environment_q_t18": by_tick.get(18, {}).get("records", {}).get("q"),
            "environment_qp_t19": by_tick.get(19, {}).get("records", {}).get("qp"),
            "lineage_t25": by_tick.get(25, {}).get("records", {}).get("lineage_meet"),
            "response_t33": by_tick.get(33, {}).get("records", {}).get("receiver"),
        })
    case = {
        "case_id": spec["id"], "completed": True, "spec": spec,
        "geometry": geometry, "measured": measured, "trace": trace,
        "source_terminal": source_terminal, "kernel_events": kernel_events,
        "post_t0_host_writes": 0,
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{spec['id']}.json", case)
    np.savez_compressed(output / "CASES" / f"{spec['id']}.npz", **snapshots)
    with (output / "case_progress.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"case_id": spec["id"], "completed": True, "simulation_seconds": case["simulation_seconds"]}, sort_keys=True) + "\n")
    return case


def run_empty_case(kernel, with_channels: bool, output: Path):
    started = time.monotonic()
    raw = np.zeros((N, N, N), np.uint64)
    clock = np.zeros_like(raw)
    center = (63, 63, 63)
    sources = {}
    if with_channels:
        for index, name in enumerate("ABC"):
            item = CHANNELS[name]
            sources[name] = place(raw, clock, center, 4, item["direction"], 93000 + index, item["load"], f"empty_{name}")
    sources["probe"] = place(raw, clock, center, 12, (1, 0, 0), 93010, 5, "empty_probe")
    world = World(kernel, raw, clock)
    trace, snapshots = [], {}
    for tick in range(13):
        if tick in (0, 4, 5, 12):
            trace.append({"tick": tick, "center": read(world.raw_a, center), "raw_support": int(np.count_nonzero(world.raw_a))})
        if tick in (4, 12):
            snapshots[f"t{tick}_raw"] = world.raw_a.copy()
            snapshots[f"t{tick}_clock"] = world.clock_a.copy()
        if tick < 12:
            world.tick()
    case_id = "EMPTY_ABC" if with_channels else "EMPTY_NONE"
    case = {
        "case_id": case_id, "completed": True,
        "spec": {"family": "empty_medium", "with_channels": with_channels, "horizon": 12},
        "sources": {name: list(pos) for name, pos in sources.items()},
        "trace": trace, "measured": {"formation_t4": trace[1]["center"], "probe_t12": trace[-1]["center"]},
        "terminal_raw_sha256": sha256_array(world.raw_a), "post_t0_host_writes": 0,
        "simulation_seconds": time.monotonic() - started,
    }
    dump(output / "CASES" / f"{case_id}.json", case)
    np.savez_compressed(output / "CASES" / f"{case_id}.npz", **snapshots)
    with (output / "case_progress.jsonl").open("a", encoding="utf-8") as stream:
        stream.write(json.dumps({"case_id": case_id, "completed": True, "simulation_seconds": case["simulation_seconds"]}, sort_keys=True) + "\n")
    return case


def specs():
    rows = []
    for subset in ("", "A", "B", "C", "AB", "AC", "BC", "ABC"):
        rows.append({
            "id": f"PANEL_HA_{subset or 'NONE'}", "family": "multichannel_panel",
            "history": "HA", "channels": subset, "schedule": "paired",
            "channel_loads": {}, "source_mode": "persistent", "insert_link": "intact",
            "closure": False, "return_link": "intact", "test_present": False, "horizon": 14,
        })
    for history, subset in (("H0", "AB"), ("HB", "AB"), ("H0", "ABC"), ("HB", "ABC")):
        rows.append({
            "id": f"RESERVED_{history}_{subset}", "family": "generalization",
            "history": history, "channels": subset, "schedule": "paired",
            "channel_loads": {}, "source_mode": "persistent", "insert_link": "intact",
            "closure": False, "return_link": "intact", "test_present": False, "horizon": 14,
        })
    rows.append({
        "id": "RESERVED_HA_AB_ALT_LOAD", "family": "generalization", "history": "HA",
        "channels": "AB", "schedule": "paired", "channel_loads": {"A": 5, "B": 12},
        "source_mode": "persistent", "insert_link": "intact", "closure": False,
        "return_link": "intact", "test_present": False, "horizon": 14,
    })
    for case_id, history, subset, source_mode in (
        ("SUSTAIN_HA_AB", "HA", "AB", "persistent"),
        ("SUSTAIN_HA_ABC", "HA", "ABC", "persistent"),
        ("SUSTAIN_H0_AB", "H0", "AB", "persistent"),
        ("SUSTAIN_HB_AB", "HB", "AB", "persistent"),
        ("SUSTAIN_HA_AB_FINITE", "HA", "AB", "finite"),
        ("SUSTAIN_HA_AB_MISSING", "HA", "AB", "missing"),
    ):
        rows.append({
            "id": case_id, "family": "sustainability", "history": history,
            "channels": subset, "schedule": "paired", "channel_loads": {},
            "source_mode": source_mode, "insert_link": "intact", "closure": False,
            "return_link": "intact", "test_present": False, "horizon": 64,
        })
    closure_specs = (
        ("CLOSURE_HA_AB", "HA", "AB", "paired", "intact", "intact", True),
        ("CLOSURE_HA_AB_INSERT_CUT", "HA", "AB", "paired", "cut", "intact", True),
        ("CLOSURE_HA_AB_INSERT_SHAM", "HA", "AB", "paired", "sham", "intact", True),
        ("CLOSURE_HA_AB_RETURN_CUT", "HA", "AB", "paired", "intact", "cut", True),
        ("CLOSURE_HA_AB_RETURN_SHAM", "HA", "AB", "paired", "intact", "sham", True),
        ("CLOSURE_H0_AB", "H0", "AB", "paired", "intact", "intact", True),
        ("CLOSURE_HB_AB", "HB", "AB", "paired", "intact", "intact", True),
        ("CLOSURE_HA_ABC", "HA", "ABC", "paired", "intact", "intact", True),
        ("ASSOC_PAIRED_TEST", "HA", "AB", "paired", "intact", "intact", True),
        ("ASSOC_PAIRED_NO_TEST", "HA", "AB", "paired", "intact", "intact", False),
        ("ASSOC_UNPAIRED_TEST", "HA", "AB", "unpaired", "intact", "intact", True),
        ("ASSOC_UNPAIRED_NO_TEST", "HA", "AB", "unpaired", "intact", "intact", False),
        ("ASSOC_NONE_TEST", "HA", "", "paired", "intact", "intact", True),
        ("ASSOC_NONE_NO_TEST", "HA", "", "paired", "intact", "intact", False),
    )
    for case_id, history, subset, schedule, insert_link, return_link, test in closure_specs:
        rows.append({
            "id": case_id, "family": "association" if case_id.startswith("ASSOC") else "environmental_closure",
            "history": history, "channels": subset, "schedule": schedule,
            "channel_loads": {}, "source_mode": "persistent", "insert_link": insert_link,
            "closure": True, "return_link": return_link, "test_present": test, "horizon": 33,
        })
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default=str(HERE))
    args = parser.parse_args()
    output = Path(args.output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    (output / "CASES").mkdir(exist_ok=True)
    progress = output / "case_progress.jsonl"
    if progress.exists():
        progress.unlink()
    kernel, environment = load_kernel()
    zero = np.zeros((5, 5, 5), np.uint64)
    canary = World(kernel, zero, zero.copy())
    canary_tick = canary.tick()
    operational_canary = {"raw_support_after_tick": int(np.count_nonzero(canary.raw_a)), "kernel_report": canary_tick}
    started = time.monotonic()
    cases = []
    for spec in specs():
        cases.append(run_integrated_case(kernel, spec, output))
    cases.append(run_empty_case(kernel, True, output))
    cases.append(run_empty_case(kernel, False, output))
    result = {
        "campaign_id": CAMPAIGN_ID,
        "environment": environment,
        "operational_canary": operational_canary,
        "cases": cases,
        "completed_case_count": sum(case["completed"] for case in cases),
        "partial_case_count": 0,
        "simulation_seconds": sum(case["simulation_seconds"] for case in cases),
        "runner_wall_seconds": time.monotonic() - started,
        "post_t0_host_writes": 0,
    }
    dump(output / "results.json", result)
    print(json.dumps({
        "completed": result["completed_case_count"], "partial": 0,
        "simulation_seconds": result["simulation_seconds"],
        "wall_seconds": result["runner_wall_seconds"],
    }, indent=2))


if __name__ == "__main__":
    main()
