#!/usr/bin/env python3
"""Recover authoritative DEE v27 sources and observer definitions for PROCESOS 01.

This is a documentary recovery step.  It reads sealed parents, records hashes and
scope, and never mutates a parent archive.
"""
from __future__ import annotations

import hashlib
import json
import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET


HERE = Path(__file__).resolve().parent
P01 = HERE.parent
TESTS = P01.parents[2]
VITAL = TESTS / "documantacion vital"
CORES = VITAL / "cores"
ENGINEERING = VITAL / "ingenieria"
EXPECTED_KERNEL = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def archive(prefix: str, root: Path) -> Path:
    matches = sorted(root.glob(prefix + "*.zip"))
    if len(matches) != 1:
        raise RuntimeError(f"Expected one {prefix}*.zip in {root}; found {matches}")
    return matches[0]


def member_ref(zip_path: Path, member: str) -> dict:
    with zipfile.ZipFile(zip_path) as zf:
        data = zf.read(member)
    return {
        "archive": str(zip_path),
        "archive_sha256": sha256_file(zip_path),
        "member": member,
        "member_sha256": sha256_bytes(data),
    }


def docx_paragraphs(path: Path) -> list[str]:
    with zipfile.ZipFile(path) as zf:
        root = ET.fromstring(zf.read("word/document.xml"))
    ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    out = []
    for p in root.findall(".//w:p", ns):
        text = "".join((node.text or "") for node in p.findall(".//w:t", ns)).strip()
        if text:
            out.append(text)
    return out


def relevant_docx_excerpt(path: Path, terms: tuple[str, ...], radius: int = 1) -> dict:
    paragraphs = docx_paragraphs(path)
    wanted: set[int] = set()
    lowered = [p.casefold() for p in paragraphs]
    for index, value in enumerate(lowered):
        if any(term.casefold() in value for term in terms):
            wanted.update(range(max(0, index - radius), min(len(paragraphs), index + radius + 1)))
    return {
        "path": str(path),
        "sha256": sha256_file(path),
        "paragraph_count": len(paragraphs),
        "selected_paragraphs": [{"index": i, "text": paragraphs[i]} for i in sorted(wanted)],
    }


def find_docx(name_fragment: str) -> Path:
    matches = [p for p in VITAL.rglob("*.docx") if name_fragment.casefold() in p.name.casefold()]
    if len(matches) != 1:
        raise RuntimeError(f"Expected one DOCX matching {name_fragment!r}; found {matches}")
    return matches[0]


def observer(
    observer_id: str,
    source: dict,
    inputs: list[str],
    output: str,
    domain: str,
    status: str,
    limits: list[str],
    process01: str,
    implementation: str | None = None,
) -> dict:
    return {
        "observer_id": observer_id,
        "source_reference": source,
        "inputs": inputs,
        "output": output,
        "validated_domain": domain,
        "parent_status": status,
        "limitations": limits,
        "process01_applicability": process01,
        "implementation_reference": implementation,
    }


def main() -> None:
    core05 = archive("05_", CORES)
    core08 = archive("08_", CORES)
    core14 = archive("14_", CORES)
    core15 = archive("15_", CORES)
    core16 = archive("16_", CORES)
    core17 = archive("17_", CORES)
    ing06 = archive("INGENIERIA_06_", ENGINEERING)

    refs = {
        "core05_relational": member_ref(
            core05,
            "DEE_V27_NATIVE_REALITY_DISCOVERY_AND_SYNTHESIS_RESULTADOS/RELATIONAL_OBSERVER.md",
        ),
        "core08_atlas": member_ref(core08, "OBSERVER_ATLAS.json"),
        "core14_registry": member_ref(core14, "OBSERVER_REGISTRY.json"),
        "core15_spec": member_ref(core15, "BASELINE_CORE15_LOCKED/FROZEN_OBSERVER_SPEC.json"),
        "core15_library": member_ref(core15, "BASELINE_CORE15_LOCKED/OBSERVER_LIBRARY.json"),
        "core16_access": member_ref(core16, "OBSERVER_ACCESSIBILITY_MATRIX.json"),
        "core16_graph": member_ref(core16, "REALITY_LEVEL_GRAPH.json"),
        "core17_access": member_ref(core17, "CORE17_OBSERVER_ACCESSIBILITY.json"),
        "core17_graph": member_ref(core17, "CORE17_REALITY_LEVEL_GRAPH.json"),
    }

    official_core_archives = []
    for number in range(1, 18):
        z = archive(f"{number:02d}_", CORES)
        official_core_archives.append({"core": number, "name": z.name, "path": str(z), "sha256": sha256_file(z)})

    engineering_archives = []
    for z in sorted(ENGINEERING.glob("INGENIERIA_*.zip")):
        engineering_archives.append({"name": z.name, "path": str(z), "sha256": sha256_file(z)})

    pyd = TESTS / "DEE_V27_MASTER_REVALIDATION_REBUILD_WORK" / "KERNEL" / "wheel_extracted" / "dee_universe_v27" / "dee_kernel_v27.cp313-win_amd64.pyd"
    source_cpp = TESTS / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA" / "dee_kernel_v27.cpp"
    source_zip = TESTS / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA.zip"
    wheel = TESTS / "dee_universe_v27-27.0.0-cp313-cp313-win_amd64.whl"
    for required in (pyd, source_cpp, source_zip, wheel):
        if not required.is_file():
            raise FileNotFoundError(required)
    if sha256_file(pyd) != EXPECTED_KERNEL:
        raise RuntimeError("Accepted kernel binary hash mismatch")

    kernel_doc = find_docx("justificacion y estructura del kernel")
    ent_doc = find_docx("ENTRELAZAMIENTO")
    relation_doc = find_docx("RELACION_UNIVERSAL")
    fgif_doc = find_docx("FISICA GEOMETRICA")
    doc_audit = {
        "kernel_closure": relevant_docx_excerpt(
            kernel_doc,
            ("cierre microscópico", "P_KERNEL", "19665", "304980", "Moore-26", "XNOR"),
            radius=1,
        ),
        "effective_quantum_map": relevant_docx_excerpt(
            ent_doc,
            ("X_FULL", "F_DEE", "M_Q", "S_Q", "U_F", "omega", "factorización"),
            radius=1,
        ),
        "universal_relation_map": relevant_docx_excerpt(
            relation_doc,
            ("causal order", "first passage", "topology", "reachability", "R_DEE"),
            radius=1,
        ),
        "fgif_map": relevant_docx_excerpt(
            fgif_doc,
            ("observer", "causal", "geometr", "relational"),
            radius=0,
        ),
    }

    source_audit = {
        "schema": "dee.v27.processes01.source_audit.v1",
        "kernel": {
            "expected_pyd_sha256": EXPECTED_KERNEL,
            "accepted_pyd": {"path": str(pyd), "sha256": sha256_file(pyd)},
            "wheel": {"path": str(wheel), "sha256": sha256_file(wheel)},
            "sealed_source": {"path": str(source_cpp), "sha256": sha256_file(source_cpp)},
            "sealed_source_zip": {"path": str(source_zip), "sha256": sha256_file(source_zip)},
            "status": "PASS",
        },
        "official_core_archives": official_core_archives,
        "core17_found": any(row["core"] == 17 for row in official_core_archives),
        "official_engineering_archives": engineering_archives,
        "selected_authority_members": refs,
        "selected_document_authorities": doc_audit,
        "parents_mutated": False,
    }
    write_json(HERE / "SOURCE_AUDIT.json", source_audit)

    registry = {
        "schema": "dee.v27.processes01.recovered_observer_registry.v1",
        "policy": {
            "reference_state": "X_FULL=(raw_a,clock_a) over the complete lattice",
            "scratch_status": "raw_b/clock_b are implementation scratch and are not treated as public causal degrees of freedom",
            "scope_rule": "A parent observer is not generalized beyond its validated apparatus/domain.",
            "status_vocabulary": ["VALID", "NOT_APPLICABLE", "OUTSIDE_VALIDATED_SCOPE"],
        },
        "observers": [
            observer("X_FULL", refs["core17_graph"], ["raw_a", "clock_a", "toroidal coordinates"], "complete public microstate", "DEE v27 public state", "EXACT_REFERENCE", [], "VALID", "process01_common.x_full_descriptor"),
            observer("R0_NATIVE_CAUSAL_QUOTIENT", refs["core16_graph"], ["occupancy/existence", "semantic4 payload", "s_reg", "direction", "semantic", "clock mod 304980", "destination/incumbent relations"], "exact multistep quotient", "validated CORE16 scope excluding uint64 wrap-sensitive cases", "FRESH_CONFIRMED", ["not a universal external-human mapping", "closure not revalidated by PROCESOS 01"], "VALID", "process01_common.r0_descriptor"),
            observer("R1_ROUTED_PHASE_EVENT", refs["core17_graph"], ["destination fibers", "arrival phase", "payload", "direction", "event history"], "routed temporal event quotient", "prepared transport/event apparatuses", "FRESH_RECONFIRMED", ["does not predict receiver relational state"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("R2_RELATIONAL", refs["core17_graph"], ["relative geometry", "interface topology", "coupling", "response class"], "organization/interface response", "task-relative prepared organizations", "PARENT_PLUS_NEW", ["requires a declared intervention/readout"], "VALID", "process01_common.relation_descriptor"),
            observer("R2_FUNCTIONAL", refs["core17_graph"], ["history", "route", "prepared receiver", "functional identity"], "history-bearing functional response", "task-relative prepared organizations", "PARENT_PLUS_NEW", ["not a global quotient"], "VALID", "process01_common.future_descriptor"),
            observer("R3_STATISTICAL_ENSEMBLE", refs["core17_graph"], ["macroclass", "declared preparation measure", "outcome distribution", "fluctuation"], "measure-conditioned ensemble", "declared compatible-microstate measures", "FRESH_RECONFIRMED", ["PROCESOS 01 has no independent preparation measure"], "NOT_APPLICABLE", None),
            observer("M_ZUPDATE", refs["core08_atlas"], ["xnor_guard", "sum_s", "sign(sum_d)"], "void-destination raw", "one void destination; aggregate coordinate-deletion family", "HOLDOUT_CONFIRMED_INTERNAL", ["not a global quotient"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("M_BOUNDARY_T", refs["core08_atlas"], ["surface place", "delay", "s_reg event history"], "restricted ray state/future", "collision-free normal-ray family", "HOLDOUT_CONFIRMED_INTERNAL_POST_FAILURE", ["not arbitrary volumetric state"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("M_EVENT_CAUSAL", refs["core15_library"], ["route length", "event tick", "event s_reg", "event direction", "relative phase", "target occupancy", "guard count"], "priority-cluster event shadow", "CORE13 priority cluster A", "HISTORICAL_SELECTED", ["fails global X_FULL closure"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("M_REL", refs["core15_library"], ["support", "proposals", "fiber multiplicity", "direction", "s_reg", "semantic", "guard", "clock/history"], "relational causal shadow", "CORE08/11 relational tasks", "PARENT_CONFIRMED", ["fails global exact closure"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("M_OCCUPANCY", refs["core15_library"], ["occupied coordinates"], "support geometry", "negative/coarse baseline", "INSUFFICIENT_FOR_PHASE_GUARD_PAYLOAD_HISTORY", ["ignores raw fields, clock and lineage"], "VALID", "process01_common.geometry_descriptor"),
            observer("M_HISTORY", refs["core15_library"], ["current lineage", "training relation", "prior target occupancy", "ordered intervention record"], "history-bearing trajectory shadow", "history-bearing apparatuses", "PARENT_CONFIRMED", ["includes trajectory information not recoverable from every coarse present"], "VALID", "main runner ordered provenance/timeline"),
            observer("M_CLOCK_RESIDUAL", refs["core15_library"], ["raw state", "clock residual relative to matched age"], "hidden clock trace", "clock-trace apparatuses", "EXACT_TRACE_PARENT", ["absolute clock advance alone is not evidence", "parent probes found bounded functional null in one domain"], "VALID", "process01_common.phase_descriptor"),
            observer("S_CAUSAL_PANEL_V1", refs["core15_spec"], ["route/geometry", "direction", "s_reg", "semantic", "relative phase", "target history", "guard topology", "ordered lineage", "coupling context"], "family of task-relative shadows", "eight frozen CORE15 predicates", "FROZEN_PARENT_SPEC", ["not one scalar", "not validated on Ing06 apparatus"], "OUTSIDE_VALIDATED_SCOPE", None),
            observer("M_CONFIGURATION", refs["core16_access"], ["canonical raw_a field records"], "raw configuration signature", "descriptive projection used in Ing05/06", "PARENT_SUPPORTED", ["does not include clock"], "VALID", "process01_common.configuration_descriptor"),
            observer("M_GEOMETRY", refs["core16_access"], ["occupied support", "Moore-26 components", "toroidal radial profile"], "support geometry signature", "descriptive projection; causal only when linked to a validated readout", "PARENT_SUPPORTED", ["geometry equality does not imply functional equality"], "VALID", "process01_common.geometry_descriptor"),
            observer("M_RELATION", refs["core17_graph"], ["FULL and OMIT_P1/P2/P3 paired trajectories", "h32", "h64"], "opportunity-effect relation fingerprints", "Ing06 sensitive-opportunity apparatus V2", "FRESH_REPLICATED_PARENT", ["omission is diagnostic", "task-relative"], "VALID", "process01_common.relation_descriptor"),
            observer("M_PHASE", refs["core15_library"], ["clock residual", "clock difference", "mod 391", "mod 782", "mod 304980"], "phase/residual signature", "matched-age comparisons; quotient only inside CORE16 scope", "MIXED_PARENT_SUPPORT", ["absolute clock excluded from novelty gate"], "VALID", "process01_common.phase_descriptor"),
            observer("M_FUNCTION", refs["core17_graph"], ["frozen free-future panel", "h32", "h64"], "future-response fingerprint", "Ing06 V2 parent apparatus", "FRESH_REPLICATED_PARENT", ["task-relative; not universal function"], "VALID", "process01_common.future_descriptor"),
            observer("M_COMPETENCE", refs["core15_library"], ["response to acquisition challenge"], "future acquisition capability", "apparatuses with a frozen competence challenge", "PARENT_FAMILY_ONLY", ["no validated acquisition challenge in the selected Ing06 V2 apparatus"], "NOT_APPLICABLE", None),
            observer("M_ENVIRONMENT", refs["core14_registry"], ["organization-environment coupling variables"], "environmental consequence", "apparatuses with a declared environment boundary", "PARENT_FAMILY_ONLY", ["selected apparatus has no independently validated system/environment cut"], "NOT_APPLICABLE", None),
            observer("M_RESOURCE", refs["core17_graph"], ["occupied support", "field counts", "component sizes"], "resource/support accounting", "descriptive accounting in bounded lattice", "PARENT_SUPPORTED", ["not an energy measure"], "VALID", "process01_common.resource_descriptor"),
        ],
        "process01_family_aliases": {
            "M_configuration": "M_CONFIGURATION",
            "M_geometry": "M_GEOMETRY",
            "M_relation": "M_RELATION",
            "M_phase": "M_PHASE",
            "M_history": "M_HISTORY",
            "M_function": "M_FUNCTION",
            "M_competence": "M_COMPETENCE",
            "M_environment": "M_ENVIRONMENT",
            "M_resource": "M_RESOURCE",
        },
    }
    write_json(P01 / "01_OBSERVER_REGISTRY_RECOVERY" / "OBSERVER_REGISTRY_RECOVERED.json", registry)

    apparatus_runner = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería" / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RUNNERS" / "run_ing06_sensitive_opportunities_v2.py"
    apparatus_result = apparatus_runner.parents[1] / "RESULTS" / "ING06_SENSITIVE_OPPORTUNITIES_V2.json"
    freeze = {
        "schema": "dee.v27.processes01.parent_apparatus_freeze.v1",
        "parent_archive": {"path": str(ing06), "sha256": sha256_file(ing06)},
        "runner": {"path": str(apparatus_runner), "sha256": sha256_file(apparatus_runner)},
        "parent_result": {"path": str(apparatus_result), "sha256": sha256_file(apparatus_result)},
        "n": 39,
        "origin": [19, 6, 19],
        "host_stop_tick": 4,
        "histories": {"H0": None, "HA": "AB", "HB": "BA"},
        "opportunity_offsets": {"P1": [-13, 13, 0], "P2": [0, 13, 0], "P3": [13, 13, 0]},
        "fresh_transforms": {
            "MAIN_S0": {"permutation": [0, 1, 2], "signs": [1, 1, 1]},
            "FRESH_V1": {"permutation": [1, 0, 2], "signs": [1, -1, 1]},
            "FRESH_V2": {"permutation": [2, 1, 0], "signs": [-1, 1, 1]},
        },
        "parent_panel": {"type": "free future", "horizons": [32, 64], "post_checkpoint_physical_injection": False},
        "frozen_process01_offsets": list(range(33)) + [48, 64, 96, 128, 192, 256],
        "post_host_main_world_operations": ["tick", "checkpoint", "read", "log", "stop"],
    }
    write_json(P01 / "02_PARENT_APPARATUS_SENTINEL" / "PARENT_APPARATUS_FREEZE.json", freeze)

    matrix = {
        "schema": "dee.v27.processes01.observation_matrix.v1",
        "axes": {"scale": ["VOXEL", "ROI", "GLOBAL", "TEMPORAL", "CONTRAFACTUAL"]},
        "rows": [
            {"observer": "X_FULL", "VOXEL": "VALID", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "R0", "VOXEL": "VALID", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "R1", "VOXEL": "OUTSIDE_VALIDATED_SCOPE", "ROI": "OUTSIDE_VALIDATED_SCOPE", "GLOBAL": "OUTSIDE_VALIDATED_SCOPE", "TEMPORAL": "OUTSIDE_VALIDATED_SCOPE", "CONTRAFACTUAL": "OUTSIDE_VALIDATED_SCOPE"},
            {"observer": "R2_RELATIONAL", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "R2_FUNCTIONAL", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "R3", "VOXEL": "NOT_APPLICABLE", "ROI": "NOT_APPLICABLE", "GLOBAL": "OUTSIDE_VALIDATED_SCOPE", "TEMPORAL": "OUTSIDE_VALIDATED_SCOPE", "CONTRAFACTUAL": "OUTSIDE_VALIDATED_SCOPE"},
            {"observer": "M_CONFIGURATION", "VOXEL": "VALID", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_GEOMETRY", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_RELATION", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_PHASE", "VOXEL": "VALID", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_HISTORY", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_FUNCTION", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
            {"observer": "M_COMPETENCE", "VOXEL": "NOT_APPLICABLE", "ROI": "NOT_APPLICABLE", "GLOBAL": "NOT_APPLICABLE", "TEMPORAL": "NOT_APPLICABLE", "CONTRAFACTUAL": "NOT_APPLICABLE"},
            {"observer": "M_ENVIRONMENT", "VOXEL": "NOT_APPLICABLE", "ROI": "NOT_APPLICABLE", "GLOBAL": "NOT_APPLICABLE", "TEMPORAL": "NOT_APPLICABLE", "CONTRAFACTUAL": "NOT_APPLICABLE"},
            {"observer": "M_RESOURCE", "VOXEL": "NOT_APPLICABLE", "ROI": "VALID", "GLOBAL": "VALID", "TEMPORAL": "VALID", "CONTRAFACTUAL": "VALID"},
        ],
    }
    write_json(P01 / "01_OBSERVER_REGISTRY_RECOVERY" / "OBSERVATION_MATRIX.json", matrix)
    print(json.dumps({"status": "PASS", "core_count": len(official_core_archives), "observer_count": len(registry["observers"]), "core17_found": True}, indent=2))


if __name__ == "__main__":
    main()
