#!/usr/bin/env python3
"""Minimal reproduction sentinel for the frozen Ing06 V2 apparatus."""
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
P01 = HERE.parents[1]
COMMON = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RUNNERS"
sys.path.insert(0, str(COMMON))

import process01_common as common  # noqa: E402


def main() -> None:
    kernel, runtime = common.nrd05.load_kernel(1)
    observed_kernel = runtime["observed_hashes"]["kernel"]
    timeline = common.run_timeline(kernel, "MAIN_S0")
    observations = {
        history: common.relation_descriptor(timeline[history], 0)
        for history in common.HISTORIES
    }
    parent_result_path = common.ENGINEERING / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RESULTS" / "ING06_SENSITIVE_OPPORTUNITIES_V2.json"
    parent = json.loads(parent_result_path.read_text(encoding="utf-8"))
    parent_row = parent["cases"]["MAIN_S0"]["observations"]["0"]
    pattern_matches = {
        history: observations[history]["pattern"] == parent_row[history]["pattern"]
        for history in common.HISTORIES
    }
    gates = {
        "kernel_hash": observed_kernel == common.EXPECTED_KERNEL_SHA256,
        "parent_patterns_exact": all(pattern_matches.values()),
        "h0_equivalent": observations["H0"]["equivalent"],
        "all_opportunities_future_relevant": all(observations[h]["all_future_relevant"] for h in common.HISTORIES),
        "ha_broken": not observations["HA"]["equivalent"],
        "hb_broken": not observations["HB"]["equivalent"],
        "ha_hb_patterns_different": observations["HA"]["pattern"] != observations["HB"]["pattern"],
    }
    result = {
        "schema": "dee.v27.processes01.parent_sentinel.v1",
        "status": "PASS" if all(gates.values()) else "FAIL",
        "science_class": "REPRODUCTION_SENTINEL_NOT_NEW_SCIENCE",
        "runtime": runtime,
        "configuration": "MAIN_S0",
        "host_stop_tick": common.HOST_STOP_TICK,
        "post_host_main_world_interventions": 0,
        "gates": gates,
        "pattern_matches": pattern_matches,
        "observations": observations,
        "parent_result": str(parent_result_path),
    }
    out = HERE.parent / "RESULTS" / "PROCESS01_PARENT_SENTINEL.json"
    common.write_json(out, result)
    print(json.dumps({"status": result["status"], "gates": gates}, indent=2))
    if result["status"] != "PASS":
        raise SystemExit(2)


if __name__ == "__main__":
    main()
