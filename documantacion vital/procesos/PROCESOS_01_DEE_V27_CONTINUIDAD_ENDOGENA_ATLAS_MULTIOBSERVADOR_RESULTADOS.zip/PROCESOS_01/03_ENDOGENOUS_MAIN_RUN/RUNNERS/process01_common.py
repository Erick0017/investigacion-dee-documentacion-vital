#!/usr/bin/env python3
"""Shared frozen apparatus and observer projections for PROCESOS 01."""
from __future__ import annotations

import hashlib
import json
import sys
from collections import Counter, deque
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
P01 = HERE.parents[1]
TESTS = P01.parents[2]
ENGINEERING = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería"
ING06_RUNNERS = ENGINEERING / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RUNNERS"
NRD05_RUNNERS = ENGINEERING / "INGENIERIA_05_HISTORY_CONDITIONED_TRANSFORMATION" / "RUNNERS"
NRD06_RUNNERS = ENGINEERING / "INGENIERIA_05_HISTORY_SPECIFICITY" / "RUNNERS"
sys.path[:0] = [str(ING06_RUNNERS), str(NRD05_RUNNERS), str(NRD06_RUNNERS)]

import run_ing06_sensitive_opportunities_v2 as v2  # noqa: E402
import run_nrd05_history_conditioned_transformation as nrd05  # noqa: E402
import run_nrd06_history_specificity as nrd06  # noqa: E402


N = v2.N
ORIGIN = v2.ORIGIN
CONFIGURATIONS = tuple(v2.GLOBAL)
HISTORIES = tuple(v2.HISTORIES)
OPPORTUNITIES = tuple(v2.OPPORTUNITIES)
HORIZONS = tuple(v2.HORIZONS)
HOST_STOP_TICK = 4
EXPECTED_KERNEL_SHA256 = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"
OBSERVATION_OFFSETS = tuple(range(33)) + (48, 64, 96, 128, 192, 256)
NEEDED_OFFSETS = tuple(sorted(set(OBSERVATION_OFFSETS) | {x + h for x in OBSERVATION_OFFSETS for h in HORIZONS}))

STATE_MASK = np.uint64(0xFFFFFFFF)
SREG_MASK = np.uint64(0xFFFF)
SEM_MASK = np.uint64(0xF)
LOW_STATE_CLEAR = np.uint64(0xFFFFFFFF00000000)
R0_CLOCK_MODULUS = np.uint64(304980)


def hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_array(array: np.ndarray) -> str:
    return hash_bytes(np.ascontiguousarray(array).tobytes())


def hash_json(value: object) -> str:
    return hash_bytes(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8"))


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def inverse_transform(vector: tuple[int, int, int], permutation: tuple[int, int, int], signs: tuple[int, int, int]) -> tuple[int, int, int]:
    result = [0, 0, 0]
    for i in range(3):
        result[permutation[i]] = int(signs[i]) * int(vector[i])
    return tuple(result)


def centered_delta(coord: tuple[int, int, int]) -> tuple[int, int, int]:
    return tuple(int((int(coord[i]) - ORIGIN[i] + N // 2) % N - N // 2) for i in range(3))


def canonical_coord(coord: tuple[int, int, int], configuration: str) -> tuple[int, int, int]:
    permutation, signs = v2.GLOBAL[configuration]
    return inverse_transform(centered_delta(coord), permutation, signs)


def canonical_direction(direction: tuple[int, int, int], configuration: str) -> tuple[int, int, int]:
    permutation, signs = v2.GLOBAL[configuration]
    return inverse_transform(direction, permutation, signs)


def occupied_records(raw: np.ndarray, configuration: str, include_state: bool = True) -> list[tuple[int, ...]]:
    f = nrd05.fields(raw)
    rows: list[tuple[int, ...]] = []
    for q_arr in np.argwhere(raw != 0):
        q = tuple(int(x) for x in q_arr)
        c = canonical_coord(q, configuration)
        d = canonical_direction((int(f["dx"][q]), int(f["dy"][q]), int(f["dz"][q])), configuration)
        row = (*c, int(f["state"][q]) if include_state else int(int(f["state"][q]) != 0), int(f["sreg"][q]), *d, int(f["semantic"][q]))
        rows.append(row)
    rows.sort()
    return rows


def configuration_descriptor(state: tuple[np.ndarray, np.ndarray], configuration: str) -> dict:
    raw = state[0]
    f = nrd05.fields(raw)
    records = occupied_records(raw, configuration, include_state=True)
    return {
        "status": "VALID",
        "canonical_raw_signature": hash_json(records),
        "native_raw_sha256": hash_array(raw),
        "occupied": int(np.count_nonzero(raw)),
        "field_value_counts": {
            key: [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in f[key][raw != 0]).items())]
            for key in ("state", "sreg", "dx", "dy", "dz", "semantic")
        },
    }


MOORE_26 = tuple((dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1) if (dx, dy, dz) != (0, 0, 0))


def component_sizes(raw: np.ndarray) -> list[int]:
    remaining = {tuple(int(x) for x in q) for q in np.argwhere(raw != 0)}
    sizes: list[int] = []
    while remaining:
        seed = remaining.pop()
        queue = deque([seed])
        size = 1
        while queue:
            q = queue.popleft()
            for d in MOORE_26:
                n = tuple((q[i] + d[i]) % N for i in range(3))
                if n in remaining:
                    remaining.remove(n)
                    queue.append(n)
                    size += 1
        sizes.append(size)
    return sorted(sizes, reverse=True)


def geometry_descriptor(state: tuple[np.ndarray, np.ndarray], configuration: str) -> dict:
    raw = state[0]
    coords = [canonical_coord(tuple(int(x) for x in q), configuration) for q in np.argwhere(raw != 0)]
    coords.sort()
    radial = Counter(sum(v * v for v in q) for q in coords)
    components = component_sizes(raw)
    return {
        "status": "VALID",
        "canonical_support_signature": hash_json(coords),
        "occupied": len(coords),
        "component_count_moore26": len(components),
        "component_sizes_moore26": components,
        "radial_squared_histogram": [[int(k), int(v)] for k, v in sorted(radial.items())],
        "geometry_class_signature": hash_json({"components": components, "radial": sorted(radial.items())}),
    }


def r0_descriptor(state: tuple[np.ndarray, np.ndarray], configuration: str) -> dict:
    raw, clock = state
    f = nrd05.fields(raw)
    occupied = raw != 0
    semantic4 = f["semantic"] == 4
    reduced_state = np.where(occupied & ~semantic4, np.uint64(1), raw & STATE_MASK)
    r0_raw = (raw & LOW_STATE_CLEAR) | reduced_state.astype(np.uint64)
    r0_clock = np.remainder(clock, R0_CLOCK_MODULUS).astype(np.uint64)
    records = occupied_records(r0_raw, configuration, include_state=True)
    clock_rows = []
    for q_arr in np.argwhere(occupied):
        q = tuple(int(x) for x in q_arr)
        clock_rows.append((*canonical_coord(q, configuration), int(r0_clock[q])))
    clock_rows.sort()
    return {
        "status": "VALID",
        "scope_note": "projection instantiated; exact closure inherited from CORE16 and not revalidated here",
        "canonical_signature": hash_json({"raw": records, "clock": clock_rows}),
        "native_raw_sha256": hash_array(r0_raw),
        "native_clock_mod_304980_sha256": hash_array(r0_clock),
    }


def phase_descriptor(state: tuple[np.ndarray, np.ndarray], configuration: str, absolute_age: int) -> dict:
    raw, clock = state
    occupied = raw != 0
    residual = (clock - np.uint64(absolute_age)).astype(np.uint64)
    rows = []
    for q_arr in np.argwhere(occupied):
        q = tuple(int(x) for x in q_arr)
        rows.append((*canonical_coord(q, configuration), int(residual[q]), int(clock[q] % np.uint64(391)), int(clock[q] % np.uint64(782)), int(clock[q] % R0_CLOCK_MODULUS)))
    rows.sort()
    return {
        "status": "VALID",
        "absolute_clock_recorded_not_used_for_novelty": int(absolute_age),
        "occupied_residual_signature": hash_json(rows),
        "occupied_residual_nonzero": int(np.count_nonzero(residual[occupied])),
        "residual_value_counts": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in residual[occupied]).items())],
        "clock_mod_391_counts": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in (clock[occupied] % np.uint64(391))).items())],
        "clock_mod_782_counts": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in (clock[occupied] % np.uint64(782))).items())],
    }


def resource_descriptor(state: tuple[np.ndarray, np.ndarray]) -> dict:
    raw = state[0]
    f = nrd05.fields(raw)
    occupied = raw != 0
    return {
        "status": "VALID",
        "bounded_lattice_voxels": int(raw.size),
        "occupied_voxels": int(np.count_nonzero(occupied)),
        "nonzero_sreg": int(np.count_nonzero(f["sreg"])),
        "semantic_counts": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in f["semantic"][occupied]).items())],
        "note": "support accounting only; not energy",
    }


def raw_signature(left: tuple[np.ndarray, np.ndarray], right: tuple[np.ndarray, np.ndarray]) -> tuple[int, ...]:
    return tuple(int(x) for x in v2.v1.raw_signature(left, right))


def relation_descriptor(states_at: dict[int, dict[str, tuple[np.ndarray, np.ndarray]]], offset: int) -> dict:
    relations = {}
    for p in OPPORTUNITIES:
        vectors = [raw_signature(states_at[offset]["FULL"], states_at[offset][f"OMIT_{p}"])]
        vectors.extend(raw_signature(states_at[offset + h]["FULL"], states_at[offset + h][f"OMIT_{p}"]) for h in HORIZONS)
        relations[p] = {
            "fingerprint": hash_json(vectors),
            "vectors": [list(v) for v in vectors],
            "future_relevant": any(any(v) for v in vectors[1:]),
        }
    pattern = [relations[p]["fingerprint"] for p in OPPORTUNITIES]
    groups: dict[str, list[str]] = {}
    for p, fingerprint in zip(OPPORTUNITIES, pattern):
        groups.setdefault(fingerprint, []).append(p)
    partition = sorted(sorted(group) for group in groups.values())
    return {
        "status": "VALID",
        "relations": relations,
        "pattern": pattern,
        "equivalent": len(set(pattern)) == 1,
        "all_future_relevant": all(relations[p]["future_relevant"] for p in OPPORTUNITIES),
        "equivalence_partition": partition,
        "relation_class_signature": hash_json(partition),
    }


def future_descriptor(states_at: dict[int, dict[str, tuple[np.ndarray, np.ndarray]]], offset: int, configuration: str) -> dict:
    rows = {}
    for horizon in HORIZONS:
        state = states_at[offset + horizon]["FULL"]
        rows[str(horizon)] = {
            "configuration_signature": configuration_descriptor(state, configuration)["canonical_raw_signature"],
            "clock_sha256": hash_array(state[1]),
        }
    return {"status": "VALID", "panel": "parent V2 free-future", "horizons": rows, "raw_future_fingerprint": hash_json({h: rows[h]["configuration_signature"] for h in rows})}


def snapshot_observers(
    states_at: dict[int, dict[str, tuple[np.ndarray, np.ndarray]]],
    offset: int,
    configuration: str,
    history: str,
) -> dict:
    state = states_at[offset]["FULL"]
    config = configuration_descriptor(state, configuration)
    geometry = geometry_descriptor(state, configuration)
    relation = relation_descriptor(states_at, offset)
    future = future_descriptor(states_at, offset, configuration)
    phase = phase_descriptor(state, configuration, HOST_STOP_TICK + offset)
    r0 = r0_descriptor(state, configuration)
    return {
        "X_FULL": {"status": "VALID", "raw_sha256": hash_array(state[0]), "clock_sha256": hash_array(state[1]), "canonical_raw_signature": config["canonical_raw_signature"]},
        "R0": r0,
        "R1": {"status": "OUTSIDE_VALIDATED_SCOPE", "reason": "No parent R1 first-passage detector was embedded in the Ing06 V2 opportunity apparatus."},
        "R2_RELATIONAL": relation,
        "R2_FUNCTIONAL": future,
        "R3": {"status": "NOT_APPLICABLE", "reason": "No independent compatible-microstate preparation measure was declared."},
        "M_configuration": config,
        "M_geometry": geometry,
        "M_relation": relation,
        "M_phase": phase,
        "M_history": {"status": "VALID", "history_provenance": history, "post_host_offset": offset, "note": "trajectory/provenance observer; not a kernel field"},
        "M_function": future,
        "M_competence": {"status": "NOT_APPLICABLE", "reason": "No validated acquisition challenge belongs to the frozen parent V2 panel."},
        "M_environment": {"status": "NOT_APPLICABLE", "reason": "No validated organization/environment cut belongs to the parent apparatus."},
        "M_resource": resource_descriptor(state),
        "CORE15_S_CAUSAL_PANEL_V1": {"status": "OUTSIDE_VALIDATED_SCOPE", "reason": "Frozen for eight CORE15 predicates, not this apparatus."},
    }


def build_worlds(kernel, configuration: str) -> dict[str, dict[str, object]]:
    return {
        history: {
            "FULL": v2.make_world(kernel, configuration, history),
            **{f"OMIT_{p}": v2.make_world(kernel, configuration, history, p) for p in OPPORTUNITIES},
        }
        for history in HISTORIES
    }


def run_timeline(kernel, configuration: str) -> dict[str, dict[int, dict[str, tuple[np.ndarray, np.ndarray]]]]:
    worlds = build_worlds(kernel, configuration)
    flat = {f"{h}_{b}": world for h, branches in worlds.items() for b, world in branches.items()}
    nrd06.tick_all(flat, HOST_STOP_TICK)
    elapsed = 0
    timeline: dict[str, dict[int, dict[str, tuple[np.ndarray, np.ndarray]]]] = {h: {} for h in HISTORIES}
    for offset in NEEDED_OFFSETS:
        nrd06.tick_all(flat, offset - elapsed)
        elapsed = offset
        for history, branches in worlds.items():
            timeline[history][offset] = {branch: nrd05.checkpoint(world) for branch, world in branches.items()}
    return timeline
