#!/usr/bin/env python3
"""PROCESOS 01: dense post-HOST_STOP multobserver atlas on the frozen Ing06 V2 apparatus."""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
P01 = HERE.parents[1]
sys.path.insert(0, str(HERE))

import process01_common as common  # noqa: E402


SIGNATURE_PATHS = {
    "X_FULL": ("X_FULL", "canonical_raw_signature"),
    "R0": ("R0", "canonical_signature"),
    "R2_RELATIONAL": ("R2_RELATIONAL", "pattern"),
    "R2_FUNCTIONAL": ("R2_FUNCTIONAL", "raw_future_fingerprint"),
    "M_configuration": ("M_configuration", "canonical_raw_signature"),
    "M_geometry": ("M_geometry", "canonical_support_signature"),
    "M_relation": ("M_relation", "pattern"),
    "M_phase": ("M_phase", "occupied_residual_signature"),
    "M_function": ("M_function", "raw_future_fingerprint"),
    "M_resource": ("M_resource", "occupied_voxels"),
}


def nested(row: dict, path: tuple[str, ...]):
    value = row
    for key in path:
        value = value[key]
    return value


def serial_signature(value) -> str:
    return common.hash_json(value)


def diff_counts(left: tuple[np.ndarray, np.ndarray], right: tuple[np.ndarray, np.ndarray]) -> dict:
    lf, rf = common.nrd05.fields(left[0]), common.nrd05.fields(right[0])
    return {
        "raw_diff_positions": int(np.count_nonzero(left[0] != right[0])),
        "clock_diff_positions": int(np.count_nonzero(left[1] != right[1])),
        "field_diff_positions": {key: int(np.count_nonzero(lf[key] != rf[key])) for key in lf},
    }


def visibility_table(observations: dict) -> dict:
    out = {}
    offsets = common.OBSERVATION_OFFSETS
    for observer, path in SIGNATURE_PATHS.items():
        rows = {}
        for offset in offsets:
            signatures = {h: serial_signature(nested(observations[str(offset)][h], path)) for h in common.HISTORIES}
            rows[str(offset)] = {
                "signatures": signatures,
                "HA_vs_HB_visible": signatures["HA"] != signatures["HB"],
                "HA_vs_H0_visible": signatures["HA"] != signatures["H0"],
                "HB_vs_H0_visible": signatures["HB"] != signatures["H0"],
            }
        out[observer] = rows
    return out


def first_visibility(visibility: dict) -> dict:
    result = {}
    for observer, rows in visibility.items():
        visible = [int(offset) for offset, row in rows.items() if row["HA_vs_HB_visible"]]
        at_zero = rows["0"]["HA_vs_HB_visible"]
        first = visible[0] if visible else None
        transitions = []
        previous = rows[str(common.OBSERVATION_OFFSETS[0])]["HA_vs_HB_visible"]
        for offset in common.OBSERVATION_OFFSETS[1:]:
            current = rows[str(offset)]["HA_vs_HB_visible"]
            if current != previous:
                transitions.append({"offset": offset, "from_visible": previous, "to_visible": current})
            previous = current
        if not visible:
            classification = "HIDDEN_CONTINUOUSLY"
        elif at_zero and len(visible) == len(rows):
            classification = "VISIBLE_CONTINUOUSLY"
        elif not at_zero and visible:
            classification = "HIDDEN_THEN_VISIBLE"
        elif at_zero and len(visible) < len(rows):
            classification = "VISIBLE_THEN_HIDDEN_OR_TRANSFORMED"
        else:
            classification = "OBSERVER_SPECIFIC"
        result[observer] = {
            "t_first_HA_vs_HB": first,
            "visible_at_host_stop": at_zero,
            "visible_offsets": visible,
            "transitions": transitions,
            "classification": classification,
        }
    result["R1"] = {"status": "OUTSIDE_VALIDATED_SCOPE", "t_first_HA_vs_HB": None}
    result["R3"] = {"status": "NOT_APPLICABLE", "t_first_HA_vs_HB": None}
    result["M_history"] = {"status": "VALID_TRAJECTORY_PROVENANCE_NOT_STATE_ONLY", "t_first_HA_vs_HB": 0, "note": "The AB/BA label is not counted as endogenous observer discovery."}
    result["M_competence"] = {"status": "NOT_APPLICABLE", "t_first_HA_vs_HB": None}
    result["M_environment"] = {"status": "NOT_APPLICABLE", "t_first_HA_vs_HB": None}
    return result


def robust_hidden_then_visible(per_config_first: dict) -> list[dict]:
    candidates = []
    excluded = {"X_FULL", "R0", "R2_RELATIONAL", "R2_FUNCTIONAL", "M_configuration", "M_relation", "M_function", "M_history"}
    for observer in SIGNATURE_PATHS:
        if observer in excluded:
            continue
        rows = [per_config_first[c][observer] for c in common.CONFIGURATIONS]
        if all(row.get("classification") == "HIDDEN_THEN_VISIBLE" for row in rows):
            firsts = [row["t_first_HA_vs_HB"] for row in rows]
            candidates.append({
                "observer": observer,
                "fresh_replicated": True,
                "first_offsets": dict(zip(common.CONFIGURATIONS, firsts)),
                "same_relative_tick": len(set(firsts)) == 1,
                "classification": "NEW_POST_HOST_PROJECTION_VISIBILITY",
            })
    return candidates


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()

    sentinel_path = P01 / "02_PARENT_APPARATUS_SENTINEL" / "RESULTS" / "PROCESS01_PARENT_SENTINEL.json"
    sentinel = json.loads(sentinel_path.read_text(encoding="utf-8"))
    if sentinel["status"] != "PASS":
        raise RuntimeError("Parent sentinel is not PASS")

    started = time.time()
    kernel, runtime = common.nrd05.load_kernel(args.threads)
    if runtime["observed_hashes"]["kernel"] != common.EXPECTED_KERNEL_SHA256:
        raise RuntimeError("Kernel hash mismatch")

    cases = {}
    first_by_config = {}
    telemetry_refs = {}
    for configuration in common.CONFIGURATIONS:
        timeline = common.run_timeline(kernel, configuration)
        observations = {}
        telemetry = {}
        for offset in common.OBSERVATION_OFFSETS:
            observations[str(offset)] = {}
            for history in common.HISTORIES:
                observations[str(offset)][history] = common.snapshot_observers(timeline[history], offset, configuration, history)
                state = timeline[history][offset]["FULL"]
                telemetry[f"T{offset}_{history}_raw_a"] = state[0]
                telemetry[f"T{offset}_{history}_clock_a"] = state[1]
            observations[str(offset)]["cross_history"] = {
                "HA_vs_HB": diff_counts(timeline["HA"][offset]["FULL"], timeline["HB"][offset]["FULL"]),
                "HA_vs_H0": diff_counts(timeline["HA"][offset]["FULL"], timeline["H0"][offset]["FULL"]),
                "HB_vs_H0": diff_counts(timeline["HB"][offset]["FULL"], timeline["H0"][offset]["FULL"]),
                "raw_changed_since_stop": {
                    history: diff_counts(timeline[history][offset]["FULL"], timeline[history][0]["FULL"])
                    for history in common.HISTORIES
                },
            }
        visibility = visibility_table(observations)
        first = first_visibility(visibility)
        first_by_config[configuration] = first
        cases[configuration] = {
            "observations": observations,
            "visibility": visibility,
            "first_visibility": first,
            "post_host_main_world_physical_interventions": 0,
        }
        telemetry_path = P01 / "03_ENDOGENOUS_MAIN_RUN" / "TELEMETRY" / f"PROCESS01_{configuration}_X_FULL.npz"
        np.savez_compressed(telemetry_path, **telemetry)
        telemetry_refs[configuration] = str(telemetry_path.relative_to(P01)).replace("\\", "/")
        del timeline, telemetry

    candidates = robust_hidden_then_visible(first_by_config)
    xfull_present_at_stop = all(first_by_config[c]["X_FULL"]["visible_at_host_stop"] for c in common.CONFIGURATIONS)
    raw_post_host_change = all(
        any(
            cases[c]["observations"][str(offset)]["cross_history"]["raw_changed_since_stop"][history]["raw_diff_positions"] > 0
            for offset in common.OBSERVATION_OFFSETS[1:]
        )
        for c in common.CONFIGURATIONS
        for history in ("HA", "HB")
    )
    new_microcausal_distinction = bool(candidates) and not xfull_present_at_stop
    category = (
        "NEW_ENDOGENOUS_CAUSAL_DISTINCTION"
        if new_microcausal_distinction
        else "HISTORY_CONDITIONED_ENDOGENOUS_REORGANIZATION_WITH_PREEXISTING_X_FULL_DISTINCTION"
        if raw_post_host_change
        else "CONTINUING_STATE_EVOLUTION"
    )
    result = {
        "schema": "dee.v27.processes01.multobserver_main.v1",
        "experiment_id": "PROCESS01_ENDOGENOUS_MULTIOBSERVER_ATLAS",
        "status": category,
        "runtime": runtime,
        "elapsed_seconds": time.time() - started,
        "sentinel": str(sentinel_path.relative_to(P01)).replace("\\", "/"),
        "frozen_apparatus": {
            "n": common.N,
            "origin": list(common.ORIGIN),
            "host_stop_tick": common.HOST_STOP_TICK,
            "observation_offsets": list(common.OBSERVATION_OFFSETS),
            "diagnostic_horizons": list(common.HORIZONS),
            "histories": list(common.HISTORIES),
            "configurations": list(common.CONFIGURATIONS),
            "post_host_main_world_operations": ["tick", "checkpoint", "read", "log", "stop"],
        },
        "cases": cases,
        "fresh_replication": {"configurations": list(common.CONFIGURATIONS), "no_retuning": True},
        "new_post_host_projection_candidates": candidates,
        "adjudication": {
            "x_full_HA_HB_distinction_already_present_at_host_stop": xfull_present_at_stop,
            "history_conditioned_raw_evolution_after_host_stop": raw_post_host_change,
            "new_microcausal_distinction_first_created_after_host_stop": new_microcausal_distinction,
            "new_distinction_became_new_history": False,
            "reason_new_history_not_promoted": "The causal HA/HB distinction is already visible in X_FULL at HOST_STOP+0; later coarse visibility can be projection/reorganization of that inherited distinction. No not-traversed counterfactual or confirmed mediation isolates a newly created distinction.",
            "clock_absolute_used_for_pass": False,
            "python_physical_interventions_after_host_stop": 0,
            "causal_mediation": "NOT_EXECUTED_NO_PROMOTABLE_NEW_CAUSAL_DISTINCTION",
        },
        "telemetry": telemetry_refs,
    }
    out = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RESULTS" / "PROCESS01_MULTIOBSERVER_MAIN.json"
    common.write_json(out, result)
    print(json.dumps({
        "status": category,
        "elapsed_seconds": result["elapsed_seconds"],
        "new_post_host_projection_candidates": candidates,
        "new_microcausal_distinction": new_microcausal_distinction,
    }, indent=2))


if __name__ == "__main__":
    main()
