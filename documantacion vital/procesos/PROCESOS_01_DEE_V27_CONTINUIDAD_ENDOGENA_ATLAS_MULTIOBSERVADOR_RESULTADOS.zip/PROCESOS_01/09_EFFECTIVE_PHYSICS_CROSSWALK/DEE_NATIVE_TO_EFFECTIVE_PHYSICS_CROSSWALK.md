# DEE native to effective-physics crosswalk

This is a map to already defined formal objects, not a new physics derivation.

| Layer | Object available in PROCESOS 01 | Status | Boundary |
|---|---|---|---|
| Micro | `X_FULL=(raw_a, clock_a)` | Instantiated exactly | `raw_b/clock_b` remain scratch, not public state. |
| Micro dynamics | frozen `F_DEE` | Inherited | Not rederived. |
| Causal | reachability at h32/h64 | Instantiated task-relatively | Does not establish a universal causal quotient beyond R0's parent scope. |
| Causal | causal order / first passage / destination fibers | Parent objects available | `R1` is `OUTSIDE_VALIDATED_SCOPE` in this apparatus; no new first-passage detector was embedded. |
| Relational | FULL versus OMIT_P1/P2/P3 effect relation | Instantiated and future-relevant | Diagnostic counterfactual, not a fundamental field. |
| Phase | matched-age clock residual, mod 391, mod 782, mod 304980 | Instantiated | Absolute clock advance excluded from novelty. No new phase law found. |
| Effective | AB/BA history-conditioned trajectory classes | Instantiated | Task-relative; no universal observer closure. |
| Geometric | occupied support, Moore-26 connectivity, toroidal radial profile | Instantiated descriptively | Geometry was already history-distinguishing at HOST_STOP+0; no new geometry-first transition. |
| Statistical | compatible-microstate measure and ensemble pushforward | `NOT_APPLICABLE` | Formal R3 requires a declared preparation measure absent here. |

## Effective quantum crosswalk

- Candidate microstate `X`: instantiated as X_FULL.
- Candidate measurement map `M_Q`: only task-relative observer inputs exist; a quantum measurement map is `NOT_INSTANTIATED`.
- Candidate sector `S_Q`: `NOT_INSTANTIATED`; no reversible/recurrent quantum sector was selected here.
- `U_F` / dispersion `ω(k)`: `NOT_INSTANTIATED`.
- Joint organization/factorization test: `NOT_INSTANTIATED` in PROCESOS 01.

Nothing in this package is promoted as entanglement, a wavefunction, Born probability, or a quantum sector.

## Causal/geometric crosswalk

Ready inputs are X_FULL trajectories, causal ordering by frozen ticks, bounded support volume, Moore-26 topology, anisotropy encoded in direction fields, task-relative reachability, observer dependence and history dependence. A Lorentzian metric, Lorentz invariance, Einstein dynamics or continuum spacetime is not instantiated or claimed.
