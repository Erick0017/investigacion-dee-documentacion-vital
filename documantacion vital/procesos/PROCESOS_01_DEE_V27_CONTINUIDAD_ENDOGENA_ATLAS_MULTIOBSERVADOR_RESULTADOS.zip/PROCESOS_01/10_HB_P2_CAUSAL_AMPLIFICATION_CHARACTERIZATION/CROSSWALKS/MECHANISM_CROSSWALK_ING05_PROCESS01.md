# Crosswalk: Ingeniería 05 NRD04 ↔ Procesos 01 HB–P2

## Evidencia parental reutilizada

- `NRD04_EXHAUSTIVE_SUBSETS.json` mostró dependencia de una configuración RAW de ocho posiciones y respuesta no aditiva en su aparato.
- `NRD04_VALUE_POSITION.json` mostró que permutar valores entre las mismas posiciones modifica el futuro.
- Esos resultados se usan por referencia forense; no fueron reejecutados.

## Propiedades que coinciden

1. La consecuencia no queda descrita por el conteo de componentes aislados. En HB–P2, los cinco pares comienzan con 19 posiciones RAW de diferencia, pero sus trayectorias se separan por historia y oportunidad.
2. Identidad, posición y contexto importan. La omisión de P2 bajo BA alcanza media retícula en `+112`, mientras H0–P2 y HA–P2 no alcanzan media retícula hasta `+512`, y HB–P1/HB–P3 lo hacen en `+442`.
3. La interacción es configuracional: P2 no actúa como una fuente suficiente aislada. La rama `HB_OMIT_P2` se densifica primero; `HB_FULL`, que contiene P2, se mantiene dispersa hasta cientos de ticks después.

## Propiedades nuevas en Procesos 01

- Se midió una transformación temporal de una huella de 19 posiciones a 58 751 posiciones en `+121` y 58 877 en `+128` sobre 59 319.
- La primera divergencia por vóxel, la topología toroidal, la descomposición por campos y la ascendencia potencial self+Moore-26 quedaron registradas.
- Ninguna primera divergencia RAW precede su distancia Chebyshev toroidal mínima desde el soporte inicial, y ninguna aparición RAW nueva carece de un posible antecedente local self+Moore-26 en el tick previo.
- La covariancia geométrica es exacta en MAIN_S0, FRESH_V1 y FRESH_V2 después de canonicalización.

## Lo que estos datos no identifican

- No establecen que NRD04 y HB–P2 sean el mismo mecanismo microscópico.
- No convierten las ocho posiciones NRD04 en soporte causal de HB–P2.
- No distinguen todavía entre una modulación de latencia configuracional, una condición de acceso a un régimen expansivo o una combinación de ambas.

