# Crosswalk: POST-04.5 ↔ Procesos 01 HB–P2

## Fenómeno A: expansión visible/organizacional

POST-04.5 registró una expansión de soporte visible desde aproximadamente 327 hasta 68 198/68 921 posiciones en su aparato. Esa magnitud describe geometría ocupada del mundo correspondiente.

## Fenómeno B: extensión contrafactual HB–P2

Procesos 01 compara dos mundos emparejados. En `+128`:

- `HB_FULL` contiene 355 posiciones ocupadas;
- `HB_OMIT_P2` contiene 58 903;
- la máscara RAW contrafactual contiene 58 877;
- 58 549 posiciones están ocupadas sólo en `OMIT_P2`;
- 327 están ocupadas en ambos pero tienen RAW distinto;
- 415 son cero en ambos.

Por ello, la extensión contrafactual casi global no es una geometría del mundo `FULL`. En este intervalo surge principalmente porque la rama `OMIT_P2` entra antes en un régimen de soporte denso mientras `FULL` permanece dispersa. No es, sin embargo, una propagación sin expansión visible en ninguna rama: la rama contrafactual sí se expande visiblemente.

## Comparación limitada

Los dos aparatos comparten una propiedad descriptiva: una configuración inicial pequeña puede anteceder una reorganización que cubre gran parte de una retícula. Difieren en la cantidad primaria medida:

- POST-04.5: soporte visible dentro de un mundo;
- HB–P2: diferencia causal entre mundos FULL/OMIT, descompuesta además en soporte visible de cada rama.

No hay evidencia en esta entrega para identificarlos como una única clase microscópica. Los observables ahora disponibles permiten una comparación futura sin confundir geometría del mundo con geometría de la diferencia.

