from __future__ import annotations

import hashlib
import json
import os
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve()
BLOCK = HERE.parents[1]
ROOT = HERE.parents[2]
TESTS = ROOT.parents[2]
OFFICIAL_NAME = "PROCESOS_01_DEE_V27_CONTINUIDAD_ENDOGENA_ATLAS_MULTIOBSERVADOR_RESULTADOS.zip"
OFFICIAL = TESTS / "documantacion vital" / "procesos" / OFFICIAL_NAME
TMP_ZIP = ROOT / ".process01_part1_package.tmp"
KERNEL_SHA256 = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def write_json(path: Path, payload: object) -> None:
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def normalize_latency_metadata() -> None:
    path = BLOCK / "OBSERVER_LATENCY" / "HB_P2_OBSERVER_LATENCY_MAP.json"
    data = json.loads(path.read_text(encoding="utf-8"))
    mapping = {
        "X_FULL_PAIR_EFFECT": "X_FULL_COUNTERFACTUAL_EFFECT_MASK",
        "R0": "R0_COUNTERFACTUAL_EFFECT_COUNTS",
        "M_configuration": "M_configuration_FIELD_COUNT_SIGNATURE",
        "M_geometry": "M_geometry_COUNTERFACTUAL_SUPPORT",
        "M_resource": "M_resource_PAIRED_SUPPORT_COUNTS",
    }
    for rows in data["configurations"].values():
        for old, new in mapping.items():
            if old in rows:
                rows[new] = rows.pop(old)
        rows["scope_note"] = {
            "description": (
                "Latencies compare FULL-vs-OMIT effect features across matched pairs. "
                "They are not the first inequality of the literal X_FULL worlds, "
                "which differ by construction at t=0."
            )
        }
    write_json(path, data)


def required_files() -> list[Path]:
    relative = [
        "FIELD_DECOMPOSITION/RAW_SIGNATURE_SCHEMA.json",
        "DENSE_TELEMETRY/HB_P2_DENSE_TIMELINE.json",
        "FIELD_DECOMPOSITION/FIELD_DIFF_TIMELINE.json",
        "SPATIAL_FRONT/HB_P2_CAUSAL_FRONT_TOPOLOGY.json",
        "FIRST_DIVERGENCE/HB_P2_FIRST_DIVERGENCE_MAP.npz",
        "FIRST_DIVERGENCE/FIRST_DIVERGENCE_STATISTICS.json",
        "ANCESTRY/DIFFERENCE_ANCESTRY_GRAPH.json",
        "RESIDUAL_STRUCTURE/UNCHANGED_RESIDUE_MAP.npz",
        "RESIDUAL_STRUCTURE/UNCHANGED_RESIDUE_MAP.json",
        "RESIDUAL_STRUCTURE/PLATEAU_MASK_DYNAMICS.json",
        "OBSERVER_LATENCY/OBSERVER_TEMPORAL_SEMANTICS.json",
        "OBSERVER_LATENCY/HB_P2_OBSERVER_LATENCY_MAP.json",
        "CONTROLS/MATCHED_CONTROL_COMPARISON.json",
        "FRESH/FRESH_CHARACTERIZATION.json",
        "CROSSWALKS/MECHANISM_CROSSWALK_ING05_PROCESS01.md",
        "CROSSWALKS/MECHANISM_CROSSWALK_POST045_PROCESS01.md",
        "SOURCE_REUSE_LEDGER/SOURCE_REUSE_LEDGER.json",
        "REPORT/CHARACTERIZATION_REPORT.md",
    ]
    return [BLOCK / item for item in relative]


def member_files(include_manifest: bool) -> list[Path]:
    excluded = {
        (ROOT / "HASHES" / "HASHES.sha256").resolve(),
        (ROOT / "MASTER_INDEX" / "DELIVERY_RECORD.json").resolve(),
    }
    if not include_manifest:
        excluded.add((ROOT / "MANIFEST" / "MANIFEST.json").resolve())
    files = []
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        if path.resolve() in excluded:
            continue
        if path.suffix.lower() == ".zip" or path.name.endswith(".tmp"):
            continue
        files.append(path)
    return sorted(files, key=lambda p: p.relative_to(ROOT).as_posix())


def build_manifest() -> None:
    files = member_files(include_manifest=False)
    entries = [
        {
            "path": path.relative_to(ROOT).as_posix(),
            "size": path.stat().st_size,
            "sha256": sha256_file(path),
        }
        for path in files
    ]
    payload = {
        "schema": "dee.v27.processes01.manifest.v2",
        "official_filename": OFFICIAL_NAME,
        "kernel_sha256": KERNEL_SHA256,
        "parent_archives_embedded": False,
        "continuation": "10_HB_P2_CAUSAL_AMPLIFICATION_CHARACTERIZATION",
        "scientific_interpretation_is_runner_agnostic": True,
        "file_count_before_manifest_and_hashes": len(entries),
        "preservation_note": "Stages 00-09 are retained; only master index, manifest and hashes are refreshed for the integrated archive.",
        "entries": entries,
    }
    write_json(ROOT / "MANIFEST" / "MANIFEST.json", payload)


def build_hashes() -> None:
    files = member_files(include_manifest=True)
    lines = [f"{sha256_file(path)}  {path.relative_to(ROOT).as_posix()}" for path in files]
    (ROOT / "HASHES" / "HASHES.sha256").write_text("\n".join(lines) + "\n", encoding="utf-8")


def validate_required() -> None:
    missing = [str(path) for path in required_files() if not path.is_file()]
    if missing:
        raise FileNotFoundError("Missing required characterization files: " + "; ".join(missing))


def build_zip() -> tuple[str, int, int]:
    if TMP_ZIP.exists():
        TMP_ZIP.unlink()
    files = member_files(include_manifest=True)
    hashes_path = ROOT / "HASHES" / "HASHES.sha256"
    files.append(hashes_path)
    files = sorted(set(files), key=lambda p: p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(TMP_ZIP, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in files:
            zf.write(path, f"PROCESOS_01/{path.relative_to(ROOT).as_posix()}")
    with zipfile.ZipFile(TMP_ZIP, "r") as zf:
        bad = zf.testzip()
        if bad is not None:
            raise RuntimeError(f"CRC mismatch: {bad}")
        names = set(zf.namelist())
        expected = {f"PROCESOS_01/{path.relative_to(ROOT).as_posix()}" for path in files}
        if names != expected:
            raise RuntimeError("Archive member set differs from package member set")
        hash_lines = zf.read("PROCESOS_01/HASHES/HASHES.sha256").decode("utf-8").splitlines()
        for line in hash_lines:
            digest, rel = line.split("  ", 1)
            if sha256_bytes(zf.read(f"PROCESOS_01/{rel}")) != digest:
                raise RuntimeError(f"Internal hash mismatch: {rel}")
    OFFICIAL.parent.mkdir(parents=True, exist_ok=True)
    os.replace(TMP_ZIP, OFFICIAL)
    return sha256_file(OFFICIAL), OFFICIAL.stat().st_size, len(files)


def main() -> None:
    normalize_latency_metadata()
    validate_required()
    build_manifest()
    build_hashes()
    digest, size, members = build_zip()
    delivery = {
        "schema": "dee.v27.processes01.delivery_record.v2",
        "archive": str(OFFICIAL),
        "sha256": digest,
        "size_bytes": size,
        "member_count": members,
        "crc_integrity": "HASH_MATCH",
        "internal_hash_integrity": "HASH_MATCH",
        "single_official_archive": True,
    }
    write_json(ROOT / "MASTER_INDEX" / "DELIVERY_RECORD.json", delivery)
    print(json.dumps(delivery, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
