#!/usr/bin/env python3
"""Dense, measurement-only characterization of the frozen HB FULL/OMIT_P2 divergence.

The runner emits measurements and traceability without assigning a scientific
interpretation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import sys
import time
from collections import Counter, deque
from pathlib import Path

import numpy as np


HERE = Path(__file__).resolve().parent
BLOCK = HERE.parent
P01 = BLOCK.parent
COMMON_DIR = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RUNNERS"
sys.path.insert(0, str(COMMON_DIR))
import process01_common as common  # noqa: E402


N = common.N
TOTAL = N ** 3
CONFIGS = common.CONFIGURATIONS
HOST_STOP_TICK = common.HOST_STOP_TICK
PAIR_SPECS = {
    "H0_P2": ("H0", "P2"),
    "HA_P2": ("HA", "P2"),
    "HB_P1": ("HB", "P1"),
    "HB_P2": ("HB", "P2"),
    "HB_P3": ("HB", "P3"),
}
SAMPLED = tuple(sorted({0, 16, 32, 48, *range(64, 145), 160, 192, 224, 256, 320, 391, 512}))
TOPOLOGY_CONTROL_TICKS = (0, 64, 96, 112, 128, 144, 192, 256, 391, 512)
STATE_TICKS = (0, 32, 64, 80, 96, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 160, 192, 224, 256, 320, 391, 512)
PLATEAU_TICKS = (128, 160, 192, 224, 256, 320, 391, 512)
UINT16_NEVER = np.uint16(65535)
MOORE6 = ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))
MOORE26 = common.MOORE_26


def sha_array(a: np.ndarray) -> str:
    return hashlib.sha256(np.ascontiguousarray(a).tobytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def canonical_index(configuration: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    coords = np.indices((N, N, N), dtype=np.int16)
    delta = ((coords - np.asarray(common.ORIGIN, dtype=np.int16)[:, None, None, None] + N // 2) % N) - N // 2
    permutation, signs = common.v2.GLOBAL[configuration]
    local = np.empty_like(delta)
    for i in range(3):
        local[permutation[i]] = int(signs[i]) * delta[i]
    target = (local + np.asarray(common.ORIGIN, dtype=np.int16)[:, None, None, None]) % N
    return tuple(target[i].astype(np.intp) for i in range(3))


def canonicalize(a: np.ndarray, index: tuple[np.ndarray, np.ndarray, np.ndarray]) -> np.ndarray:
    out = np.empty_like(a)
    out[index] = a
    return out


def component_sizes(mask: np.ndarray, neighbors: tuple[tuple[int, int, int], ...]) -> list[int]:
    remaining = {tuple(int(v) for v in q) for q in np.argwhere(mask)}
    sizes: list[int] = []
    while remaining:
        seed = remaining.pop()
        qd = deque([seed])
        size = 1
        while qd:
            q = qd.popleft()
            for d in neighbors:
                nxt = tuple((q[i] + d[i]) % N for i in range(3))
                if nxt in remaining:
                    remaining.remove(nxt)
                    qd.append(nxt)
                    size += 1
        sizes.append(size)
    return sorted(sizes, reverse=True)


def toroidal_center_and_moments(mask: np.ndarray) -> dict:
    pos = np.argwhere(mask)
    if len(pos) == 0:
        return {"center": None, "axis_concentration": [0.0, 0.0, 0.0], "covariance": None, "axis_variance": None}
    centers = []
    concentrations = []
    for axis in range(3):
        z = np.exp(2j * np.pi * pos[:, axis] / N).mean()
        concentrations.append(float(abs(z)))
        centers.append(float((np.angle(z) % (2 * np.pi)) * N / (2 * np.pi)))
    if min(concentrations) < 1e-9:
        covariance = None
        variances = None
    else:
        center = np.asarray(centers)
        delta = ((pos - center + N / 2.0) % N) - N / 2.0
        covariance_array = (delta.T @ delta) / len(delta)
        covariance = covariance_array.tolist()
        variances = np.diag(covariance_array).tolist()
    return {"center": centers, "axis_concentration": concentrations, "covariance": covariance, "axis_variance": variances}


def surface_metrics(mask: np.ndarray) -> dict:
    exposed_faces = 0
    boundary = np.zeros_like(mask, dtype=bool)
    for d in MOORE6:
        neighbor = np.roll(mask, shift=d, axis=(0, 1, 2))
        exposed = mask & ~neighbor
        exposed_faces += int(np.count_nonzero(exposed))
        boundary |= exposed
    return {"exposed_faces_moore6": exposed_faces, "boundary_voxels_moore6": int(np.count_nonzero(boundary))}


def minimum_chebyshev_distance(shape: tuple[int, int, int], seeds: np.ndarray) -> np.ndarray:
    grid = np.indices(shape, dtype=np.int16).reshape(3, -1).T
    best = np.full(len(grid), N, dtype=np.int16)
    for seed in seeds:
        delta = np.abs(grid - seed)
        delta = np.minimum(delta, N - delta)
        best = np.minimum(best, delta.max(axis=1))
    return best.reshape(shape)


def topology(mask: np.ndarray, distance_map: np.ndarray | None = None) -> dict:
    sizes6 = component_sizes(mask, MOORE6)
    sizes26 = component_sizes(mask, MOORE26)
    row = {
        "size": int(np.count_nonzero(mask)),
        "density": float(np.count_nonzero(mask) / mask.size),
        "moore6_component_count": len(sizes6),
        "moore6_component_sizes": sizes6,
        "moore26_component_count": len(sizes26),
        "moore26_component_sizes": sizes26,
        **surface_metrics(mask),
        "toroidal_center_and_moments": toroidal_center_and_moments(mask),
    }
    if distance_map is not None:
        row["initial_support_chebyshev_shells"] = [
            [int(k), int(v)] for k, v in sorted(Counter(int(x) for x in distance_map[mask]).items())
        ]
        if np.any(mask):
            row["maximum_initial_support_chebyshev_distance"] = int(distance_map[mask].max())
    return row


def pair_measure(full: tuple[np.ndarray, np.ndarray], omit: tuple[np.ndarray, np.ndarray], age: int) -> dict:
    raw_f, clock_f = full
    raw_o, clock_o = omit
    ff, fo = common.nrd05.fields(raw_f), common.nrd05.fields(raw_o)
    occ_f, occ_o = raw_f != 0, raw_o != 0
    raw_diff = raw_f != raw_o
    clock_diff = clock_f != clock_o
    residual_f = (clock_f - np.uint64(age)).astype(np.uint64)
    residual_o = (clock_o - np.uint64(age)).astype(np.uint64)
    return {
        "full_occupied": int(np.count_nonzero(occ_f)),
        "omit_occupied": int(np.count_nonzero(occ_o)),
        "raw_diff_positions": int(np.count_nonzero(raw_diff)),
        "occupancy_diff_positions": int(np.count_nonzero(occ_f != occ_o)),
        "both_occupied_but_raw_different": int(np.count_nonzero(occ_f & occ_o & raw_diff)),
        "full_occupied_only": int(np.count_nonzero(occ_f & ~occ_o)),
        "omit_occupied_only": int(np.count_nonzero(~occ_f & occ_o)),
        "both_raw_zero": int(np.count_nonzero(~occ_f & ~occ_o)),
        "state_diff_positions": int(np.count_nonzero(ff["state"] != fo["state"])),
        "sreg_diff_positions": int(np.count_nonzero(ff["sreg"] != fo["sreg"])),
        "dx_diff_positions": int(np.count_nonzero(ff["dx"] != fo["dx"])),
        "dy_diff_positions": int(np.count_nonzero(ff["dy"] != fo["dy"])),
        "dz_diff_positions": int(np.count_nonzero(ff["dz"] != fo["dz"])),
        "semantic_diff_positions": int(np.count_nonzero(ff["semantic"] != fo["semantic"])),
        "clock_absolute_difference": int(np.count_nonzero(clock_diff)),
        "clock_residual_difference": int(np.count_nonzero(residual_f != residual_o)),
        "clock_mod391_difference": int(np.count_nonzero((clock_f % np.uint64(391)) != (clock_o % np.uint64(391)))),
        "clock_mod782_difference": int(np.count_nonzero((clock_f % np.uint64(782)) != (clock_o % np.uint64(782)))),
        "clock_mod304980_difference": int(np.count_nonzero((clock_f % common.R0_CLOCK_MODULUS) != (clock_o % common.R0_CLOCK_MODULUS))),
        "raw_diff_mask_sha256": sha_array(raw_diff),
        "clock_diff_mask_sha256": sha_array(clock_diff),
    }


def r0_pair_measure(full: tuple[np.ndarray, np.ndarray], omit: tuple[np.ndarray, np.ndarray]) -> dict:
    def r0_arrays(state):
        raw, clock = state
        f = common.nrd05.fields(raw)
        occupied = raw != 0
        semantic4 = f["semantic"] == 4
        reduced_state = np.where(occupied & ~semantic4, np.uint64(1), raw & common.STATE_MASK)
        return (raw & common.LOW_STATE_CLEAR) | reduced_state.astype(np.uint64), clock % common.R0_CLOCK_MODULUS
    lf, lc = r0_arrays(full)
    rf, rc = r0_arrays(omit)
    return {"r0_raw_diff_positions": int(np.count_nonzero(lf != rf)), "r0_clock_diff_positions": int(np.count_nonzero(lc != rc))}


def world_geometry(state: tuple[np.ndarray, np.ndarray], configuration: str) -> dict:
    raw = state[0]
    f = common.nrd05.fields(raw)
    occ = raw != 0
    geo = common.geometry_descriptor(state, configuration)
    return {
        "occupancy": int(np.count_nonzero(occ)),
        "component_count_moore26": geo["component_count_moore26"],
        "largest_components_moore26": geo["component_sizes_moore26"][:20],
        "radial_squared_histogram": geo["radial_squared_histogram"],
        "direction_distribution": {
            axis: [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in f[axis][occ]).items())]
            for axis in ("dx", "dy", "dz")
        },
        "semantic_distribution": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in f["semantic"][occ]).items())],
        "sreg_distribution": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in f["sreg"][occ]).items())],
    }


def build_worlds(kernel, configuration: str) -> dict[str, object]:
    return {
        "H0_FULL": common.v2.make_world(kernel, configuration, "H0"),
        "H0_OMIT_P2": common.v2.make_world(kernel, configuration, "H0", "P2"),
        "HA_FULL": common.v2.make_world(kernel, configuration, "HA"),
        "HA_OMIT_P2": common.v2.make_world(kernel, configuration, "HA", "P2"),
        "HB_FULL": common.v2.make_world(kernel, configuration, "HB"),
        "HB_OMIT_P1": common.v2.make_world(kernel, configuration, "HB", "P1"),
        "HB_OMIT_P2": common.v2.make_world(kernel, configuration, "HB", "P2"),
        "HB_OMIT_P3": common.v2.make_world(kernel, configuration, "HB", "P3"),
    }


def states(
    snapshots: dict[str, tuple[np.ndarray, np.ndarray]], pair: str
) -> tuple[tuple[np.ndarray, np.ndarray], tuple[np.ndarray, np.ndarray]]:
    history, opportunity = PAIR_SPECS[pair]
    full = snapshots[f"{history}_FULL"]
    omit = snapshots[f"{history}_OMIT_{opportunity}"]
    return full, omit


def landmarks(rows: list[dict]) -> dict:
    counts = np.asarray([row["raw_diff_positions"] for row in rows], dtype=np.int64)
    delta = np.diff(counts, prepend=counts[0])
    second = np.diff(delta, prepend=delta[0])
    ratio = np.divide(counts[1:], counts[:-1], out=np.full(len(counts) - 1, np.nan), where=counts[:-1] != 0)
    return {
        "baseline_count_t0": int(counts[0]),
        "first_tick_above_t0_count": next((int(i) for i, value in enumerate(counts) if value > counts[0]), None),
        "first_tick_at_least_half_lattice": next((int(i) for i, value in enumerate(counts) if value >= TOTAL / 2), None),
        "first_tick_at_least_99_percent_lattice": next((int(i) for i, value in enumerate(counts) if value >= 0.99 * TOTAL), None),
        "largest_positive_delta": {"tick": int(np.argmax(delta)), "value": int(delta.max())},
        "largest_second_difference": {"tick": int(np.argmax(second)), "value": int(second.max())},
        "largest_finite_ratio": None if not np.any(np.isfinite(ratio)) else {"tick": int(np.nanargmax(ratio) + 1), "value": float(np.nanmax(ratio))},
        "maximum_count": int(counts.max()),
        "maximum_count_tick": int(np.argmax(counts)),
        "count_at_512": int(counts[512]),
    }


def local_context(worlds: dict[str, object], configuration: str, offset: int) -> dict:
    ha = common.nrd05.checkpoint(worlds["HA_FULL"])
    hb = common.nrd05.checkpoint(worlds["HB_FULL"])
    spec = common.v2.GLOBAL[configuration]
    moved = common.nrd05.transform(common.v2.OPPORTUNITIES["P2"], spec[0], spec[1])
    center = tuple((common.ORIGIN[i] + moved[i]) % N for i in range(3))
    raw_diff = ha[0] != hb[0]
    clock_diff = ha[1] != hb[1]
    rows = {"offset": offset, "p2_center_native": list(center), "radii": {}}
    for radius in range(0, 5):
        coords = []
        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                for dz in range(-radius, radius + 1):
                    coords.append(((center[0] + dx) % N, (center[1] + dy) % N, (center[2] + dz) % N))
        rows["radii"][str(radius)] = {
            "voxel_count": len(coords),
            "raw_diff_positions": sum(bool(raw_diff[q]) for q in coords),
            "clock_diff_positions": sum(bool(clock_diff[q]) for q in coords),
        }
    diff_pos = np.argwhere(raw_diff | clock_diff)
    if len(diff_pos):
        delta = np.abs(diff_pos - np.asarray(center))
        delta = np.minimum(delta, N - delta)
        rows["minimum_chebyshev_distance_from_any_HA_HB_difference_to_P2_center"] = int(delta.max(axis=1).min())
    else:
        rows["minimum_chebyshev_distance_from_any_HA_HB_difference_to_P2_center"] = None
    return rows


def residue_description(equal_mask: np.ndarray, full: tuple[np.ndarray, np.ndarray], omit: tuple[np.ndarray, np.ndarray], distance_map: np.ndarray, configuration: str) -> dict:
    raw = full[0]
    fields = common.nrd05.fields(raw)
    occupied_equal = equal_mask & (raw != 0)
    coords_native = np.argwhere(equal_mask)
    coords_canonical = sorted(common.canonical_coord(tuple(int(v) for v in q), configuration) for q in coords_native)
    return {
        "equal_position_count": int(np.count_nonzero(equal_mask)),
        "both_raw_zero": int(np.count_nonzero(equal_mask & (full[0] == 0) & (omit[0] == 0))),
        "both_equal_occupied": int(np.count_nonzero(occupied_equal)),
        "clock_different_inside_equal_raw": int(np.count_nonzero(equal_mask & (full[1] != omit[1]))),
        "moore6_components": component_sizes(equal_mask, MOORE6),
        "moore26_components": component_sizes(equal_mask, MOORE26),
        "distance_shells": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in distance_map[equal_mask]).items())],
        "semantic_distribution_equal_occupied": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in fields["semantic"][occupied_equal]).items())],
        "state_distribution_equal_occupied": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in fields["state"][occupied_equal]).items())],
        "sreg_distribution_equal_occupied": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in fields["sreg"][occupied_equal]).items())],
        "direction_distribution_equal_occupied": {
            axis: [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in fields[axis][occupied_equal]).items())]
            for axis in ("dx", "dy", "dz")
        },
        "canonical_coordinates": [list(q) for q in coords_canonical],
        "canonical_coordinate_sha256": common.hash_json(coords_canonical),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--threads", type=int, default=1)
    args = parser.parse_args()
    source_ledger = BLOCK / "SOURCE_REUSE_LEDGER" / "SOURCE_REUSE_LEDGER.json"
    if not source_ledger.is_file():
        raise FileNotFoundError(source_ledger)

    started = time.time()
    kernel, runtime = common.nrd05.load_kernel(args.threads)
    measurements: dict[str, dict] = {}
    mask_hashes: dict[str, dict] = {}
    first_maps: dict[str, dict[str, np.ndarray]] = {}
    topology_rows: dict[str, dict] = {}
    ancestry_by_config: dict[str, list] = {}
    residue_by_config: dict[str, dict] = {}
    world_geometry_by_config: dict[str, dict] = {}
    local_context_by_config: dict[str, list] = {}
    saved_mask_arrays: dict[str, np.ndarray] = {}
    saved_residue_arrays: dict[str, np.ndarray] = {}
    saved_state_arrays: dict[str, np.ndarray] = {}
    canonical_indices = {config: canonical_index(config) for config in CONFIGS}

    for configuration in CONFIGS:
        worlds = build_worlds(kernel, configuration)
        common.nrd06.tick_all(worlds, HOST_STOP_TICK)
        per_pair = {pair: [] for pair in PAIR_SPECS}
        first_raw = np.full((N, N, N), UINT16_NEVER, dtype=np.uint16)
        first_clock = np.full((N, N, N), UINT16_NEVER, dtype=np.uint16)
        initial_distance = None
        previous_raw = None
        previous_joint = None
        ancestry = []
        topo = {}
        residues = {}
        geom = {}
        local_rows = []
        config_mask_hashes = {}

        for tick in range(513):
            age = HOST_STOP_TICK + tick
            snapshots = {
                name: common.nrd05.checkpoint(world)
                for name, world in worlds.items()
            }
            state_cache = {pair: states(snapshots, pair) for pair in PAIR_SPECS}
            for pair, (full, omit) in state_cache.items():
                row = {"tick": tick, **pair_measure(full, omit, age), **r0_pair_measure(full, omit)}
                per_pair[pair].append(row)

            hb_full, hb_omit = state_cache["HB_P2"]
            raw_mask = hb_full[0] != hb_omit[0]
            clock_mask = hb_full[1] != hb_omit[1]
            joint_mask = raw_mask | clock_mask
            first_raw[(first_raw == UINT16_NEVER) & raw_mask] = np.uint16(tick)
            first_clock[(first_clock == UINT16_NEVER) & clock_mask] = np.uint16(tick)
            if tick == 0:
                initial_distance = minimum_chebyshev_distance(raw_mask.shape, np.argwhere(raw_mask))
            if previous_joint is not None:
                parent_count = previous_joint.astype(np.uint8)
                for d in MOORE26:
                    parent_count = parent_count + np.roll(previous_joint, shift=d, axis=(0, 1, 2)).astype(np.uint8)
                new_raw = raw_mask & ~previous_raw
                ancestry.append({
                    "from_tick": tick - 1,
                    "to_tick": tick,
                    "previous_joint_difference_count": int(np.count_nonzero(previous_joint)),
                    "current_raw_difference_count": int(np.count_nonzero(raw_mask)),
                    "new_raw_difference_count": int(np.count_nonzero(new_raw)),
                    "new_raw_without_self_or_moore26_joint_parent": int(np.count_nonzero(new_raw & (parent_count == 0))),
                    "all_raw_without_self_or_moore26_joint_parent": int(np.count_nonzero(raw_mask & (parent_count == 0))),
                    "potential_parent_edge_count_to_new_raw": int(parent_count[new_raw].sum(dtype=np.int64)),
                    "potential_parent_count_distribution_for_new_raw": [[int(k), int(v)] for k, v in sorted(Counter(int(x) for x in parent_count[new_raw]).items())],
                })
            previous_raw = raw_mask.copy()
            previous_joint = joint_mask.copy()

            if tick in SAMPLED:
                canonical_mask = canonicalize(raw_mask, canonical_indices[configuration])
                saved_mask_arrays[f"{configuration}_T{tick}_raw_diff"] = raw_mask
                saved_mask_arrays[f"{configuration}_T{tick}_raw_diff_canonical"] = canonical_mask
                config_mask_hashes[str(tick)] = {"native": sha_array(raw_mask), "canonical": sha_array(canonical_mask)}
                if configuration == "MAIN_S0":
                    topo[str(tick)] = topology(raw_mask, initial_distance)
                    geom[str(tick)] = world_geometry(hb_full, configuration)
                    if tick in PLATEAU_TICKS:
                        equal = ~raw_mask
                        saved_residue_arrays[f"MAIN_S0_T{tick}_equal_raw"] = equal
                        residues[str(tick)] = residue_description(equal, hb_full, hb_omit, initial_distance, configuration)
                    if tick in STATE_TICKS:
                        saved_state_arrays[f"T{tick}_HB_FULL_raw_a"] = hb_full[0]
                        saved_state_arrays[f"T{tick}_HB_FULL_clock_a"] = hb_full[1]
                        saved_state_arrays[f"T{tick}_HB_OMIT_P2_raw_a"] = hb_omit[0]
                        saved_state_arrays[f"T{tick}_HB_OMIT_P2_clock_a"] = hb_omit[1]
                elif tick in TOPOLOGY_CONTROL_TICKS:
                    topo[str(tick)] = topology(canonical_mask, canonicalize(initial_distance, canonical_indices[configuration]))

                if tick in TOPOLOGY_CONTROL_TICKS:
                    for control in ("H0_P2", "HA_P2", "HB_P1", "HB_P3"):
                        f, o = state_cache[control]
                        topo[f"{tick}_{control}"] = topology(f[0] != o[0], None)

            if tick in (0, 32, 64, 80, 96):
                local_rows.append(local_context(worlds, configuration, tick))

            if tick < 512:
                common.nrd06.tick_all(worlds, 1)

        canonical_first_raw = canonicalize(first_raw, canonical_indices[configuration])
        canonical_first_clock = canonicalize(first_clock, canonical_indices[configuration])
        first_maps[configuration] = {
            "raw_native": first_raw,
            "clock_native": first_clock,
            "raw_canonical": canonical_first_raw,
            "clock_canonical": canonical_first_clock,
            "initial_distance_native": initial_distance.astype(np.uint8),
            "initial_distance_canonical": canonicalize(initial_distance, canonical_indices[configuration]).astype(np.uint8),
        }
        measurements[configuration] = per_pair
        mask_hashes[configuration] = config_mask_hashes
        topology_rows[configuration] = topo
        ancestry_by_config[configuration] = ancestry
        residue_by_config[configuration] = residues
        world_geometry_by_config[configuration] = geom
        local_context_by_config[configuration] = local_rows

    # Save exact compressed telemetry.
    np.savez_compressed(BLOCK / "DENSE_TELEMETRY" / "HB_P2_CAUSAL_FRONT_MASKS.npz", **saved_mask_arrays)
    np.savez_compressed(BLOCK / "DENSE_TELEMETRY" / "HB_P2_MAIN_STATE_CHECKPOINTS.npz", **saved_state_arrays)
    first_payload = {f"{config}_{name}": array for config, maps in first_maps.items() for name, array in maps.items()}
    np.savez_compressed(BLOCK / "FIRST_DIVERGENCE" / "HB_P2_FIRST_DIVERGENCE_MAP.npz", **first_payload)
    np.savez_compressed(BLOCK / "RESIDUAL_STRUCTURE" / "UNCHANGED_RESIDUE_MAP.npz", **saved_residue_arrays)

    schema = {
        "schema": "dee.v27.processes01.hbp2.raw_signature_schema.v1",
        "parent_function": "run_ing06_sensitive_opportunities.py::raw_signature",
        "parent_vector_exact_order": [
            "raw_diff_positions",
            "state_diff_positions",
            "sreg_diff_positions",
            "semantic_diff_positions",
            "direction_component_diff_count_sorted_ascending_0",
            "direction_component_diff_count_sorted_ascending_1",
            "direction_component_diff_count_sorted_ascending_2",
        ],
        "critical_note": "The parent vector sorts the three dx/dy/dz difference counts, so its final three entries do not retain axis identity.",
        "new_named_measurements": [
            "raw_diff_positions", "state_diff_positions", "sreg_diff_positions", "dx_diff_positions", "dy_diff_positions", "dz_diff_positions", "semantic_diff_positions",
        ],
    }
    write_json(BLOCK / "FIELD_DECOMPOSITION" / "RAW_SIGNATURE_SCHEMA.json", schema)

    dense = {
        "schema": "dee.v27.processes01.hbp2.dense_timeline.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "lattice": {"N": N, "positions": TOTAL},
        "host_stop_tick": HOST_STOP_TICK,
        "sampled_ticks": list(SAMPLED),
        "main_all_ticks_HB_P2": measurements["MAIN_S0"]["HB_P2"],
        "descriptive_landmarks": {config: {pair: landmarks(rows) for pair, rows in pairs.items()} for config, pairs in measurements.items()},
        "mask_hashes": mask_hashes,
        "runtime": runtime,
        "elapsed_seconds": time.time() - started,
    }
    write_json(BLOCK / "DENSE_TELEMETRY" / "HB_P2_DENSE_TIMELINE.json", dense)

    field_timeline = {
        "schema": "dee.v27.processes01.hbp2.field_diff_timeline.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "rows": {
            config: {
                pair: [row for row in rows if row["tick"] in SAMPLED]
                for pair, rows in pairs.items()
            }
            for config, pairs in measurements.items()
        },
    }
    write_json(BLOCK / "FIELD_DECOMPOSITION" / "FIELD_DIFF_TIMELINE.json", field_timeline)

    front = {
        "schema": "dee.v27.processes01.hbp2.causal_front_topology.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "initial_support_distance": "minimum toroidal Chebyshev distance to D_0, matching one-step self+Moore-26 locality",
        "rows": topology_rows,
        "mask_telemetry": "../DENSE_TELEMETRY/HB_P2_CAUSAL_FRONT_MASKS.npz",
    }
    write_json(BLOCK / "SPATIAL_FRONT" / "HB_P2_CAUSAL_FRONT_TOPOLOGY.json", front)

    first_stats = {"schema": "dee.v27.processes01.hbp2.first_divergence_statistics.v1", "administrative_state": "MEASUREMENT_AVAILABLE", "configurations": {}}
    for config, maps in first_maps.items():
        raw = maps["raw_native"]
        clock = maps["clock_native"]
        distance = maps["initial_distance_native"]
        observed = raw != UINT16_NEVER
        clock_observed = clock != UINT16_NEVER
        per_tick = Counter(int(x) for x in raw[observed])
        shell_rows = {}
        for shell in sorted(set(int(x) for x in distance.flat)):
            values = raw[(distance == shell) & observed].astype(np.int64)
            shell_rows[str(shell)] = {
                "position_count": int(np.count_nonzero(distance == shell)),
                "raw_diverged_by_512": int(len(values)),
                "first_tick_min": None if len(values) == 0 else int(values.min()),
                "first_tick_median": None if len(values) == 0 else float(np.median(values)),
                "first_tick_max": None if len(values) == 0 else int(values.max()),
            }
        first_stats["configurations"][config] = {
            "raw_first_tick_counts": [[int(k), int(v)] for k, v in sorted(per_tick.items())],
            "raw_never_diverged_by_512": int(np.count_nonzero(~observed)),
            "clock_never_diverged_by_512": int(np.count_nonzero(~clock_observed)),
            "raw_first_before_initial_chebyshev_distance_count": int(np.count_nonzero(observed & (raw < distance))),
            "raw_first_at_distance_bound_count": int(np.count_nonzero(observed & (raw == distance))),
            "maximum_initial_chebyshev_distance": int(distance.max()),
            "first_tick_any_raw_at_maximum_distance": None if not np.any(observed & (distance == distance.max())) else int(raw[observed & (distance == distance.max())].min()),
            "shell_statistics": shell_rows,
            "canonical_raw_map_sha256": sha_array(maps["raw_canonical"]),
            "canonical_clock_map_sha256": sha_array(maps["clock_canonical"]),
        }
    write_json(BLOCK / "FIRST_DIVERGENCE" / "FIRST_DIVERGENCE_STATISTICS.json", first_stats)

    ancestry = {
        "schema": "dee.v27.processes01.hbp2.difference_ancestry_graph.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "edge_semantics": "Potential local ancestry: a current raw difference has an edge from each prior self/Moore-26 site differing in raw or clock. This is a necessary-neighborhood graph, not a unique parent assignment.",
        "configurations": ancestry_by_config,
    }
    write_json(BLOCK / "ANCESTRY" / "DIFFERENCE_ANCESTRY_GRAPH.json", ancestry)

    write_json(BLOCK / "RESIDUAL_STRUCTURE" / "UNCHANGED_RESIDUE_MAP.json", {
        "schema": "dee.v27.processes01.hbp2.unchanged_residue.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "configurations": residue_by_config,
        "npz": "UNCHANGED_RESIDUE_MAP.npz",
    })

    plateau = {"schema": "dee.v27.processes01.hbp2.plateau_mask_dynamics.v1", "administrative_state": "MEASUREMENT_AVAILABLE", "configurations": {}}
    for config in CONFIGS:
        rows = []
        arrays = {tick: saved_mask_arrays[f"{config}_T{tick}_raw_diff"] for tick in PLATEAU_TICKS}
        for left_tick, right_tick in zip(PLATEAU_TICKS, PLATEAU_TICKS[1:]):
            left, right = arrays[left_tick], arrays[right_tick]
            intersection = int(np.count_nonzero(left & right))
            union = int(np.count_nonzero(left | right))
            rows.append({
                "from_tick": left_tick,
                "to_tick": right_tick,
                "left_count": int(np.count_nonzero(left)),
                "right_count": int(np.count_nonzero(right)),
                "jaccard": 1.0 if union == 0 else intersection / union,
                "hamming": int(np.count_nonzero(left != right)),
                "entered": int(np.count_nonzero(~left & right)),
                "exited": int(np.count_nonzero(left & ~right)),
            })
        persistent_all = np.logical_and.reduce([arrays[t] for t in PLATEAU_TICKS])
        persistent_equal_all = np.logical_and.reduce([~arrays[t] for t in PLATEAU_TICKS])
        plateau["configurations"][config] = {
            "consecutive": rows,
            "raw_different_at_every_plateau_checkpoint": int(np.count_nonzero(persistent_all)),
            "raw_equal_at_every_plateau_checkpoint": int(np.count_nonzero(persistent_equal_all)),
        }
    write_json(BLOCK / "RESIDUAL_STRUCTURE" / "PLATEAU_MASK_DYNAMICS.json", plateau)

    temporal_semantics = {
        "schema": "dee.v27.processes01.hbp2.observer_temporal_semantics.v1",
        "observers": [
            {"observer": "X_FULL", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["raw_a", "clock_a"]},
            {"observer": "R0", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["causal quotient of raw_a", "clock mod 304980"]},
            {"observer": "M_configuration", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["current named RAW fields"]},
            {"observer": "M_geometry", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["current occupied support"]},
            {"observer": "M_phase", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["current matched-age clock residual/moduli"]},
            {"observer": "M_resource", "class": "INSTANTANEOUS_STATE_PROJECTION", "inputs": ["current support counts"]},
            {"observer": "M_history", "class": "TRAJECTORY_PROJECTION", "inputs": ["ordered AB/BA preparation and checkpoint history"]},
            {"observer": "M_relation", "class": "FUTURE_INFORMED_PROJECTION", "secondary_class": "CONTRAFACTUAL_PROJECTION", "inputs": ["FULL/OMIT", "h32", "h64"]},
            {"observer": "R2_RELATIONAL", "class": "FUTURE_INFORMED_PROJECTION", "secondary_class": "CONTRAFACTUAL_PROJECTION", "inputs": ["paired effect trajectories"]},
            {"observer": "M_function", "class": "FUTURE_INFORMED_PROJECTION", "inputs": ["frozen h32/h64 future response"]},
            {"observer": "R1", "class": "OUTSIDE_VALIDATED_SCOPE"},
            {"observer": "R3", "class": "NOT_APPLICABLE"},
        ],
    }
    write_json(BLOCK / "OBSERVER_LATENCY" / "OBSERVER_TEMPORAL_SEMANTICS.json", temporal_semantics)

    # Observer feature latency: first tick at which HB-P2's feature differs from every matched control.
    latency = {"schema": "dee.v27.processes01.hbp2.observer_latency.v1", "administrative_state": "MEASUREMENT_AVAILABLE", "configurations": {}}
    for config in CONFIGS:
        pairs = measurements[config]
        feature_builders = {
            "X_FULL_COUNTERFACTUAL_EFFECT_MASK": lambda r: (r["raw_diff_mask_sha256"], r["clock_diff_mask_sha256"]),
            "R0_COUNTERFACTUAL_EFFECT_COUNTS": lambda r: (r["r0_raw_diff_positions"], r["r0_clock_diff_positions"]),
            "M_configuration_FIELD_COUNT_SIGNATURE": lambda r: tuple(r[k] for k in ("state_diff_positions", "sreg_diff_positions", "dx_diff_positions", "dy_diff_positions", "dz_diff_positions", "semantic_diff_positions")),
            "M_geometry_COUNTERFACTUAL_SUPPORT": lambda r: (r["occupancy_diff_positions"], r["both_occupied_but_raw_different"], r["full_occupied_only"], r["omit_occupied_only"]),
            "M_phase": lambda r: (r["clock_residual_difference"], r["clock_mod391_difference"], r["clock_mod782_difference"]),
            "M_resource_PAIRED_SUPPORT_COUNTS": lambda r: (r["full_occupied"], r["omit_occupied"]),
        }
        rows = {}
        for observer, builder in feature_builders.items():
            first = None
            for tick in range(513):
                target = builder(pairs["HB_P2"][tick])
                controls = [builder(pairs[name][tick]) for name in ("H0_P2", "HA_P2", "HB_P1", "HB_P3")]
                if all(target != value for value in controls):
                    first = tick
                    break
            rows[observer] = {"first_tick_HB_P2_feature_differs_from_each_control": first}
        future_rows = {}
        for tick in range(0, 449):
            target = tuple(pairs["HB_P2"][tick + h]["raw_diff_positions"] for h in (0, 32, 64))
            controls = {name: tuple(pairs[name][tick + h]["raw_diff_positions"] for h in (0, 32, 64)) for name in ("H0_P2", "HA_P2", "HB_P1", "HB_P3")}
            future_rows[str(tick)] = {"HB_P2": list(target), "controls": {k: list(v) for k, v in controls.items()}}
        first_future = next((tick for tick in range(449) if all(tuple(future_rows[str(tick)]["HB_P2"]) != tuple(v) for v in future_rows[str(tick)]["controls"].values())), None)
        rows["M_relation_R2_future_informed"] = {"first_tick_HB_P2_h0_h32_h64_vector_differs_from_each_control": first_future, "selected_rows": {str(t): future_rows[str(t)] for t in (0, 32, 64, 96, 112, 128) if str(t) in future_rows}}
        rows["M_history"] = {"history_BA_visible_at": 0, "P2_specific_amplification_not_determined_by_history_label_alone": True}
        rows["M_function"] = rows["M_relation_R2_future_informed"]
        rows["scope_note"] = {
            "description": "Latencies compare FULL-vs-OMIT effect features across matched pairs. They are not the first inequality of the literal X_FULL worlds, which differ by construction at t=0."
        }
        latency["configurations"][config] = rows
    write_json(BLOCK / "OBSERVER_LATENCY" / "HB_P2_OBSERVER_LATENCY_MAP.json", latency)

    control_comparison = {
        "schema": "dee.v27.processes01.hbp2.matched_controls.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "landmarks": {config: {pair: landmarks(rows) for pair, rows in pairs.items()} for config, pairs in measurements.items()},
        "selected_measurements": {
            config: {
                pair: [rows[t] for t in (0, 16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 192, 256, 320, 391, 512)]
                for pair, rows in pairs.items()
            }
            for config, pairs in measurements.items()
        },
        "HA_HB_context_around_P2": local_context_by_config,
        "world_geometry_HB_FULL": world_geometry_by_config,
    }
    write_json(BLOCK / "CONTROLS" / "MATCHED_CONTROL_COMPARISON.json", control_comparison)

    main_curve = [measurements["MAIN_S0"]["HB_P2"][t]["raw_diff_positions"] for t in range(513)]
    fresh_rows = {}
    for config in CONFIGS:
        curve = [measurements[config]["HB_P2"][t]["raw_diff_positions"] for t in range(513)]
        fresh_rows[config] = {
            "curve_equals_MAIN_S0": curve == main_curve,
            "curve_sha256": common.hash_json(curve),
            "canonical_first_raw_map_equals_MAIN_S0": bool(np.array_equal(first_maps[config]["raw_canonical"], first_maps["MAIN_S0"]["raw_canonical"])),
            "canonical_first_clock_map_equals_MAIN_S0": bool(np.array_equal(first_maps[config]["clock_canonical"], first_maps["MAIN_S0"]["clock_canonical"])),
            "canonical_sample_mask_hashes_equal_MAIN_S0": all(mask_hashes[config][str(t)]["canonical"] == mask_hashes["MAIN_S0"][str(t)]["canonical"] for t in SAMPLED),
            "native_sample_mask_hashes": {str(t): mask_hashes[config][str(t)]["native"] for t in SAMPLED},
            "canonical_sample_mask_hashes": {str(t): mask_hashes[config][str(t)]["canonical"] for t in SAMPLED},
        }
    write_json(BLOCK / "FRESH" / "FRESH_CHARACTERIZATION.json", {
        "schema": "dee.v27.processes01.hbp2.fresh_characterization.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "transformations_are_frozen_spatial_covariance_checks_not_statistical_samples": True,
        "rows": fresh_rows,
    })

    write_json(BLOCK / "REPORT" / "MEASUREMENT_INDEX.json", {
        "schema": "dee.v27.processes01.hbp2.measurement_index.v1",
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "runtime_seconds": time.time() - started,
        "kernel_sha256": runtime["observed_hashes"]["kernel"],
        "files": [
            "FIELD_DECOMPOSITION/RAW_SIGNATURE_SCHEMA.json",
            "DENSE_TELEMETRY/HB_P2_DENSE_TIMELINE.json",
            "FIELD_DECOMPOSITION/FIELD_DIFF_TIMELINE.json",
            "SPATIAL_FRONT/HB_P2_CAUSAL_FRONT_TOPOLOGY.json",
            "FIRST_DIVERGENCE/HB_P2_FIRST_DIVERGENCE_MAP.npz",
            "FIRST_DIVERGENCE/FIRST_DIVERGENCE_STATISTICS.json",
            "ANCESTRY/DIFFERENCE_ANCESTRY_GRAPH.json",
            "RESIDUAL_STRUCTURE/UNCHANGED_RESIDUE_MAP.npz",
            "RESIDUAL_STRUCTURE/UNCHANGED_RESIDUE_MAP.json",
            "RESIDUAL_STRUCTURE/PLATEAU_MASK_DYNAMICS.json",
            "OBSERVER_LATENCY/OBSERVER_TEMPORAL_SEMANTICS.json",
            "OBSERVER_LATENCY/HB_P2_OBSERVER_LATENCY_MAP.json",
            "CONTROLS/MATCHED_CONTROL_COMPARISON.json",
            "FRESH/FRESH_CHARACTERIZATION.json",
        ],
    })
    print(json.dumps({
        "administrative_state": "MEASUREMENT_AVAILABLE",
        "elapsed_seconds": time.time() - started,
        "main_landmarks": landmarks(measurements["MAIN_S0"]["HB_P2"]),
    }, indent=2))


if __name__ == "__main__":
    main()
