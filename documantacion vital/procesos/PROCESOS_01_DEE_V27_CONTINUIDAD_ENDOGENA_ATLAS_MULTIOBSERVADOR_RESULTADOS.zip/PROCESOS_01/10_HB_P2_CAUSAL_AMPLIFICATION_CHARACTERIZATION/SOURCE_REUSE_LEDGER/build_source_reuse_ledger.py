#!/usr/bin/env python3
"""Record pre-existing definitions reused by the HB-P2 characterization."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
P01 = HERE.parents[1]
TESTS = P01.parents[2]
ENG = TESTS / "EXPEDIENTE_EXPERIMENTOS_DEE" / "ingeniería"


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def ref(metric: str, path: Path, symbol: str, domain: str, reuse: str) -> dict:
    if not path.is_file():
        raise FileNotFoundError(path)
    return {
        "datum_or_metric": metric,
        "source_file": str(path),
        "source_sha256": sha(path),
        "runner_or_function": symbol,
        "validated_domain": domain,
        "reuse": reuse,
    }


def main() -> None:
    ing06_v1 = ENG / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RUNNERS" / "run_ing06_sensitive_opportunities.py"
    ing06_v2 = ENG / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RUNNERS" / "run_ing06_sensitive_opportunities_v2.py"
    load_runner = ENG / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "03_PROGRESSIVE_CAUSAL_LOAD" / "RUNNERS" / "run_ing06_progressive_load_s0.py"
    nrd_support = ENG / "NATIVE_REACHABILITY_DEE_V27" / "RUNNERS" / "analyze_nrd_history_support.py"
    process_common = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RUNNERS" / "process01_common.py"
    ing02_common = ENG / "INGENIERIA_02" / "RUNNERS" / "ing02_common.py"
    kernel = TESTS / "DEE_V27_KERNEL_PARA_DERIVACION_MATEMATICA" / "dee_kernel_v27.cpp"
    nrd04_subsets = ENG / "INGENIERIA_05_RAW_CAUSAL_MINIMUM" / "RESULTS" / "NRD04_EXHAUSTIVE_SUBSETS.json"
    nrd04_position = ENG / "INGENIERIA_05_RAW_CAUSAL_MINIMUM" / "RESULTS" / "NRD04_VALUE_POSITION.json"
    post045 = ENG / "POST_INGENIERIA_04_5_REORGANIZACION_NATIVA" / "RESULTS" / "U1_PILOT_01R_MATCHED_CONTROLS.json"
    post045_resource = ENG / "POST_INGENIERIA_04_5_REORGANIZACION_NATIVA" / "RESOURCE_AUDIT.json"
    parent_result = ENG / "INGENIERIA_06_ADAPTIVE_CAPACITY" / "12_CAUSALLY_SENSITIVE_OPPORTUNITIES" / "RESULTS" / "ING06_SENSITIVE_OPPORTUNITIES_V2.json"
    p01_main = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RESULTS" / "PROCESS01_MULTIOBSERVER_MAIN.json"

    rows = [
        ref("anonymous parent raw_signature vector", ing06_v1, "raw_signature", "Ing06 V1/V2 paired FULL/OMIT trajectories", "Decode exact component order; do not reuse its sorted direction counts as named axes."),
        ref("frozen N=39 histories/opportunities/fresh transforms", ing06_v2, "N, ORIGIN, OPPORTUNITIES, GLOBAL, HISTORIES, make_world", "Ing06 sensitive-opportunity V2", "Construct unchanged H0/HA/HB FULL and OMIT branches."),
        ref("public field unpacking", ing02_common, "fields", "packed raw_a v27", "Measure state, s_reg, dx, dy, dz and semantic differences with named axes."),
        ref("kernel identity and NativeWorld", ing02_common, "load_kernel, NativeWorld", "DEE v27 cp313 runtime", "Load the accepted frozen kernel and evolve worlds."),
        ref("toroidal Moore-6 connected components", load_runner, "periodic_components", "boolean masks on cubic torus", "Reuse algorithm for difference-mask component sizes."),
        ref("paired causal-support accounting", nrd_support, "support_row, components", "NRD causal-support masks", "Reuse FULL/OMIT occupancy and field decomposition semantics."),
        ref("canonical spatial transforms and Moore-26 components", process_common, "canonical_coord, component_sizes, geometry_descriptor", "Processes01 N=39 Ing06 V2 apparatus", "Canonicalize fresh transforms and measure Moore-26 support topology."),
        ref("clock residual/modulo projections", process_common, "phase_descriptor, R0_CLOCK_MODULUS", "matched-age Processes01 snapshots", "Separate absolute clock, residual and modulo 391/782/304980 comparisons."),
        ref("local public update neighborhood", kernel, "MOORE_DXYZ; candidate halo at lines 593-615", "kernel v27 public update", "Use self+Moore-26 as the one-tick potential difference ancestry neighborhood."),
        ref("P_KERNEL and cap", kernel, "P_KERNEL=19665; cap=P_KERNEL-1", "kernel v27", "Reference constants only; not recomputed or used as a fitted parameter."),
        ref("NRD04 non-additive 8-position support", nrd04_subsets, "subset and xor_nonadditive results", "Ing05 NRD04 apparatus", "Crosswalk only; no rerun."),
        ref("NRD04 value-position dependence", nrd04_position, "base_vs_permuted", "Ing05 NRD04 apparatus", "Crosswalk configurational dependence only."),
        ref("POST-04.5 visible support expansion", post045, "initial/maximum/terminal support", "POST-04.5 U1 P01R apparatus", "Compare visible support expansion with counterfactual-difference expansion."),
        ref("POST-04.5 resource accounting", post045_resource, "world_cells and support counts", "POST-04.5 U1", "Use comparable support/world fractions."),
        ref("parent V2 sparse-time opportunity fingerprints", parent_result, "cases.*.observations", "Ing06 V2 at offsets 0,16,32,64,128,256", "Check dense measurements against inherited values."),
        ref("Processes01 exact X_FULL checkpoints", p01_main, "cases and telemetry references", "Processes01 offsets through 256", "Retain prior measurements; rerun only for missing dense checkpoints and extension."),
    ]
    value = {
        "schema": "dee.v27.processes01.hbp2.source_reuse_ledger.v1",
        "records": rows,
        "new_metrics_implemented_only_where_absent": [
            "tickwise 64-144 front topology",
            "toroidal circular center and covariance",
            "first divergence per voxel",
            "potential difference ancestry summaries",
            "unchanged-residue persistence",
            "observer temporal semantics/latency",
        ],
    }
    out = HERE / "SOURCE_REUSE_LEDGER.json"
    out.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({"administrative_state": "MEASUREMENT_AVAILABLE", "records": len(rows)}, indent=2))


if __name__ == "__main__":
    main()
