#!/usr/bin/env python3
"""Build the scientific products and single official PROCESOS 01 archive."""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path


HERE = Path(__file__).resolve().parent
P01 = HERE.parent
TESTS = P01.parents[2]
VITAL = TESTS / "documantacion vital"
FINAL_DIR = VITAL / "procesos"
ZIP_NAME = "PROCESOS_01_DEE_V27_CONTINUIDAD_ENDOGENA_ATLAS_MULTIOBSERVADOR_RESULTADOS.zip"
EXPECTED_KERNEL = "0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def hash_json(value: object) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def write_text(path: Path, value: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value.rstrip() + "\n", encoding="utf-8")


def sig(row: dict, observer: str):
    paths = {
        "X_FULL": ("X_FULL", "canonical_raw_signature"),
        "R0": ("R0", "canonical_signature"),
        "R2_RELATIONAL": ("R2_RELATIONAL", "pattern"),
        "R2_FUNCTIONAL": ("R2_FUNCTIONAL", "raw_future_fingerprint"),
        "M_configuration": ("M_configuration", "canonical_raw_signature"),
        "M_geometry": ("M_geometry", "canonical_support_signature"),
        "M_relation": ("M_relation", "pattern"),
        "M_phase": ("M_phase", "occupied_residual_signature"),
        "M_function": ("M_function", "raw_future_fingerprint"),
        "M_resource": ("M_resource", "occupied_voxels"),
    }
    value = row
    for key in paths[observer]:
        value = value[key]
    return hash_json(value)


def main() -> None:
    source = json.loads((P01 / "00_SOURCE_AUDIT" / "SOURCE_AUDIT.json").read_text(encoding="utf-8"))
    registry = json.loads((P01 / "01_OBSERVER_REGISTRY_RECOVERY" / "OBSERVER_REGISTRY_RECOVERED.json").read_text(encoding="utf-8"))
    sentinel = json.loads((P01 / "02_PARENT_APPARATUS_SENTINEL" / "RESULTS" / "PROCESS01_PARENT_SENTINEL.json").read_text(encoding="utf-8"))
    main_result_path = P01 / "03_ENDOGENOUS_MAIN_RUN" / "RESULTS" / "PROCESS01_MULTIOBSERVER_MAIN.json"
    result = json.loads(main_result_path.read_text(encoding="utf-8"))
    if source["kernel"]["status"] != "PASS" or sentinel["status"] != "PASS":
        raise RuntimeError("Source or sentinel gate failed")
    if result["runtime"]["observed_hashes"]["kernel"] != EXPECTED_KERNEL:
        raise RuntimeError("Main run kernel mismatch")

    observers = ("X_FULL", "R0", "R2_RELATIONAL", "R2_FUNCTIONAL", "M_configuration", "M_geometry", "M_relation", "M_phase", "M_function", "M_resource")
    offsets = result["frozen_apparatus"]["observation_offsets"]
    histories = result["frozen_apparatus"]["histories"]
    configs = result["frozen_apparatus"]["configurations"]

    timeline = {
        "schema": "dee.v27.processes01.multobserver_timeline.v1",
        "reference": "All observer rows derive from the same X_FULL checkpoint per world/time.",
        "absolute_clock_novelty_gate": False,
        "configurations": {},
    }
    first_table = {
        "schema": "dee.v27.processes01.first_visibility.v1",
        "meaning": "First visibility of the already-existing HA/AB versus HB/BA distinction; not automatically first causal creation.",
        "configurations": {},
        "cross_fresh_consensus": {},
    }
    hidden_atlas = {
        "schema": "dee.v27.processes01.hidden_visible_atlas.v1",
        "distinction": "HA/AB versus HB/BA",
        "configurations": {},
        "fresh_summary": {},
        "hidden_state_resurrection_observed": False,
        "destroyed_candidate_observed": False,
    }

    for config in configs:
        case = result["cases"][config]
        compact_rows = {}
        for offset in offsets:
            source_row = case["observations"][str(offset)]
            compact_rows[str(offset)] = {
                history: {
                    "signatures": {observer: sig(source_row[history], observer) for observer in observers},
                    "geometry": {
                        "occupied": source_row[history]["M_geometry"]["occupied"],
                        "component_count_moore26": source_row[history]["M_geometry"]["component_count_moore26"],
                        "component_sizes_moore26": source_row[history]["M_geometry"]["component_sizes_moore26"],
                    },
                    "relation": {
                        "equivalent": source_row[history]["M_relation"]["equivalent"],
                        "all_future_relevant": source_row[history]["M_relation"]["all_future_relevant"],
                        "equivalence_partition": source_row[history]["M_relation"]["equivalence_partition"],
                    },
                    "phase": {
                        "occupied_residual_nonzero": source_row[history]["M_phase"]["occupied_residual_nonzero"],
                        "absolute_clock_used_for_novelty": False,
                    },
                    "resource": source_row[history]["M_resource"],
                }
                for history in histories
            }
            compact_rows[str(offset)]["cross_history"] = source_row["cross_history"]
        timeline["configurations"][config] = compact_rows
        first_table["configurations"][config] = case["first_visibility"]
        hidden_atlas["configurations"][config] = {
            observer: {
                "classification": row.get("classification"),
                "visible_at_host_stop": row.get("visible_at_host_stop"),
                "transitions": row.get("transitions", []),
            }
            for observer, row in case["first_visibility"].items()
        }

    for observer in observers:
        rows = [result["cases"][config]["first_visibility"][observer] for config in configs]
        first_table["cross_fresh_consensus"][observer] = {
            "t_first_by_configuration": {config: row["t_first_HA_vs_HB"] for config, row in zip(configs, rows)},
            "classification_by_configuration": {config: row["classification"] for config, row in zip(configs, rows)},
            "fresh_consensus": len({(row["t_first_HA_vs_HB"], row["classification"]) for row in rows}) == 1,
        }
        hidden_atlas["fresh_summary"][observer] = {
            "classification": rows[0]["classification"] if len({row["classification"] for row in rows}) == 1 else "CONFIGURATION_DEPENDENT",
            "new_post_host_visibility": all(row["classification"] == "HIDDEN_THEN_VISIBLE" for row in rows),
        }
    first_table["cross_fresh_consensus"].update({
        "R1": {"status": "OUTSIDE_VALIDATED_SCOPE"},
        "R3": {"status": "NOT_APPLICABLE"},
        "M_competence": {"status": "NOT_APPLICABLE"},
        "M_environment": {"status": "NOT_APPLICABLE"},
    })

    write_json(P01 / "04_MULTIOBSERVER_ATLAS" / "MULTIOBSERVER_TIMELINE.json", timeline)
    write_json(P01 / "05_FIRST_VISIBILITY_MAP" / "FIRST_VISIBILITY_TABLE.json", first_table)
    write_json(P01 / "06_HIDDEN_VISIBLE_TRANSITIONS" / "HIDDEN_VISIBLE_ATLAS.json", hidden_atlas)

    projection_graph = {
        "schema": "dee.v27.processes01.observer_projection_graph.v1",
        "reference": "X_FULL",
        "nodes": [
            {"id": "X_FULL", "status": "VALID", "role": "complete public microstate"},
            {"id": "R0", "status": "VALID_PROJECTION_IN_INHERITED_SCOPE", "role": "exact causal quotient"},
            {"id": "R1", "status": "OUTSIDE_VALIDATED_SCOPE", "role": "routed event quotient"},
            {"id": "R2_RELATIONAL", "status": "VALID", "role": "FULL/OMIT opportunity-effect response"},
            {"id": "R2_FUNCTIONAL", "status": "VALID", "role": "frozen free-future response"},
            {"id": "R3", "status": "NOT_APPLICABLE", "role": "requires declared compatible-microstate measure"},
            {"id": "M_GEOMETRY", "status": "VALID_DESCRIPTIVE", "role": "support topology shadow"},
            {"id": "M_PHASE", "status": "VALID", "role": "matched-age residual shadow"},
            {"id": "M_RESOURCE", "status": "VALID_DESCRIPTIVE", "role": "bounded support accounting"},
        ],
        "edges": [
            {"from": "X_FULL", "to": "R0", "relation": "inherited exact projection", "causal_order_in_process01": "simultaneous at every checkpoint"},
            {"from": "X_FULL", "to": "M_GEOMETRY", "relation": "discard raw fields and clock", "information_lost": ["state", "s_reg", "direction", "semantic", "clock"]},
            {"from": "X_FULL", "to": "M_PHASE", "relation": "matched-age clock residual projection", "information_lost": ["most raw configuration"]},
            {"from": "X_FULL", "to": "R2_RELATIONAL", "relation": "diagnostic paired omission and h32/h64 evolution", "requires_counterfactual": True},
            {"from": "X_FULL", "to": "R2_FUNCTIONAL", "relation": "frozen h32/h64 future evolution", "requires_counterfactual": False},
        ],
        "causal_projection_sequence": "NO_NEW_SEQUENCE_ADJUDICATED",
        "reason": "Every applicable observer already separated HA from HB at HOST_STOP+0; no later first-visibility edge was found. Temporal precedence cannot be used to invent a micro-to-macro chain.",
    }
    write_json(P01 / "04_MULTIOBSERVER_ATLAS" / "OBSERVER_PROJECTION_GRAPH.json", projection_graph)

    mediation = {
        "schema": "dee.v27.processes01.causal_mediation_graph.v1",
        "status": "NOT_EXECUTED",
        "candidate_count": 0,
        "reason": "No promotable distinction was first created after HOST_STOP. X_FULL already separated HA/HB at +0, and all applicable coarse observers were also visible at +0.",
        "retrospective_ablation_performed": False,
        "fresh_confirmatory_mediation_performed": False,
        "causal_mediation_confirmed": False,
    }
    write_json(P01 / "07_CAUSAL_MEDIATION" / "CAUSAL_MEDIATION_GRAPH.json", mediation)

    fresh = {
        "schema": "dee.v27.processes01.fresh_validation.v1",
        "status": "FRESH_REPLICATED_BOUNDARY",
        "configurations": configs,
        "retuning": False,
        "replicated": [
            "parent sentinel signature on MAIN_S0",
            "HA/HB visible at HOST_STOP+0 in every applicable observer",
            "history-conditioned post-host X_FULL/RAW evolution",
            "absence of any robust HIDDEN_THEN_VISIBLE observer transition",
        ],
        "not_promoted": ["NEW_ENDOGENOUS_CAUSAL_DISTINCTION", "CAUSAL_MEDIATION", "ENDOGENOUS_DISTINCTION_THAT_BECOMES_NEW_HISTORY"],
    }
    write_json(P01 / "08_FRESH_VALIDATION" / "FRESH_VALIDATION_SUMMARY.json", fresh)

    history_ledger = {
        "schema": "dee.v27.processes01.endogenous_history_ledger.v1",
        "entry": {
            "histories": {"H0": "control", "HA": "AB", "HB": "BA"},
            "host_stop_tick": 4,
            "post_host_physical_interventions": 0,
            "x_full_distinction_present_at_stop": True,
            "post_host_raw_reorganization": True,
            "future_relevance": True,
            "new_distinction_first_created_after_stop": False,
            "became_new_history": False,
            "modified_another_later_transformation_as_new_history": False,
            "adjudication": "HISTORY_CONDITIONED_ENDOGENOUS_REORGANIZATION_WITH_PREEXISTING_X_FULL_DISTINCTION",
        },
        "epistemic_boundary": "This is category B, not category C or D. It does not negate endogenous continuation in untested apparatuses/domains.",
    }
    write_json(P01 / "06_HIDDEN_VISIBLE_TRANSITIONS" / "ENDOGENOUS_HISTORY_LEDGER.json", history_ledger)

    crosswalk = """# DEE native to effective-physics crosswalk

This is a map to already defined formal objects, not a new physics derivation.

| Layer | Object available in PROCESOS 01 | Status | Boundary |
|---|---|---|---|
| Micro | `X_FULL=(raw_a, clock_a)` | Instantiated exactly | `raw_b/clock_b` remain scratch, not public state. |
| Micro dynamics | frozen `F_DEE` | Inherited | Not rederived. |
| Causal | reachability at h32/h64 | Instantiated task-relatively | Does not establish a universal causal quotient beyond R0's parent scope. |
| Causal | causal order / first passage / destination fibers | Parent objects available | `R1` is `OUTSIDE_VALIDATED_SCOPE` in this apparatus; no new first-passage detector was embedded. |
| Relational | FULL versus OMIT_P1/P2/P3 effect relation | Instantiated and future-relevant | Diagnostic counterfactual, not a fundamental field. |
| Phase | matched-age clock residual, mod 391, mod 782, mod 304980 | Instantiated | Absolute clock advance excluded from novelty. No new phase law found. |
| Effective | AB/BA history-conditioned trajectory classes | Instantiated | Task-relative; no universal observer closure. |
| Geometric | occupied support, Moore-26 connectivity, toroidal radial profile | Instantiated descriptively | Geometry was already history-distinguishing at HOST_STOP+0; no new geometry-first transition. |
| Statistical | compatible-microstate measure and ensemble pushforward | `NOT_APPLICABLE` | Formal R3 requires a declared preparation measure absent here. |

## Effective quantum crosswalk

- Candidate microstate `X`: instantiated as X_FULL.
- Candidate measurement map `M_Q`: only task-relative observer inputs exist; a quantum measurement map is `NOT_INSTANTIATED`.
- Candidate sector `S_Q`: `NOT_INSTANTIATED`; no reversible/recurrent quantum sector was selected here.
- `U_F` / dispersion `ω(k)`: `NOT_INSTANTIATED`.
- Joint organization/factorization test: `NOT_INSTANTIATED` in PROCESOS 01.

Nothing in this package is promoted as entanglement, a wavefunction, Born probability, or a quantum sector.

## Causal/geometric crosswalk

Ready inputs are X_FULL trajectories, causal ordering by frozen ticks, bounded support volume, Moore-26 topology, anisotropy encoded in direction fields, task-relative reachability, observer dependence and history dependence. A Lorentzian metric, Lorentz invariance, Einstein dynamics or continuum spacetime is not instantiated or claimed.
"""
    write_text(P01 / "09_EFFECTIVE_PHYSICS_CROSSWALK" / "DEE_NATIVE_TO_EFFECTIVE_PHYSICS_CROSSWALK.md", crosswalk)

    claims = {
        "schema": "dee.v27.processes01.claim_ledger.v1",
        "kernel_sha256": EXPECTED_KERNEL,
        "claims": [
            {"id": "P01-C01", "claim": "The exact Ing06 V2 opportunity apparatus reproduces on MAIN_S0.", "status": "PASS_SENTINEL", "evidence": "02_PARENT_APPARATUS_SENTINEL/RESULTS/PROCESS01_PARENT_SENTINEL.json"},
            {"id": "P01-C02", "claim": "After HOST_STOP, HA and HB continue history-conditioned RAW/X_FULL evolution without physical host intervention.", "status": "FRESH_REPLICATED_PARENT_EXTENSION", "evidence": "03_ENDOGENOUS_MAIN_RUN/RESULTS/PROCESS01_MULTIOBSERVER_MAIN.json"},
            {"id": "P01-C03", "claim": "A new causal distinction first appears after HOST_STOP.", "status": "NOT_DEMONSTRATED", "evidence": "05_FIRST_VISIBILITY_MAP/FIRST_VISIBILITY_TABLE.json", "reason": "HA/HB were already distinct in X_FULL and every applicable observer at +0."},
            {"id": "P01-C04", "claim": "A post-stop hidden distinction later becomes visible under an inherited observer.", "status": "NOT_OBSERVED_IN_TESTED_DOMAIN", "evidence": "06_HIDDEN_VISIBLE_TRANSITIONS/HIDDEN_VISIBLE_ATLAS.json"},
            {"id": "P01-C05", "claim": "A new endogenous distinction becomes new history and changes another transformation.", "status": "NOT_DEMONSTRATED", "evidence": "06_HIDDEN_VISIBLE_TRANSITIONS/ENDOGENOUS_HISTORY_LEDGER.json"},
            {"id": "P01-C06", "claim": "Causal mediation of a new post-stop distinction is confirmed.", "status": "NOT_EXECUTED_NO_VALID_CANDIDATE", "evidence": "07_CAUSAL_MEDIATION/CAUSAL_MEDIATION_GRAPH.json"},
        ],
        "maximum_adjudication": "HISTORY_CONDITIONED_ENDOGENOUS_REORGANIZATION_WITH_PREEXISTING_X_FULL_DISTINCTION",
        "engineering_level_claims": {"RW3": False, "RW4": False, "RW5": False, "L4": False},
    }
    write_json(P01 / "CLAIM_LEDGER" / "CLAIM_LEDGER.json", claims)

    report = f"""# PROCESOS 01 — scientific report

## Outcome

The frozen Ing06 V2 apparatus reproduced exactly. Across MAIN_S0, FRESH_V1 and FRESH_V2, the AB and BA histories were already distinct at `HOST_STOP+0` in X_FULL and in every applicable recovered observer. Their public RAW states continued to reorganize without host writes, and their frozen h32/h64 futures remained different. This supports **history-conditioned endogenous reorganization**, not a newly created post-stop causal distinction.

No inherited observer transitioned reproducibly from HA/HB-equivalent at +0 to HA/HB-distinguishing later. Therefore there was no valid candidate for retrospective ablation or fresh mediation, and no claim that a new endogenous distinction became a new history.

## Observer adjudication

- X_FULL: exact reference; AB/BA visible at +0 and continuously.
- R0: instantiated as the inherited exact projection; visible at +0. Closure was not revalidated beyond its parent scope.
- R1: `OUTSIDE_VALIDATED_SCOPE` for this apparatus.
- R2 relational/function: valid task-relative omission and frozen-future responses; visible at +0.
- R3: `NOT_APPLICABLE` because no compatible-microstate preparation measure was declared.
- configuration, geometry, relation, phase, function and resource: all distinguished AB/BA at +0 and continuously.
- history: valid as trajectory/provenance, not as a new kernel field.
- competence and environment: `NOT_APPLICABLE` in the selected frozen panel.

The poorest valid shadow is M_resource: it retains bounded support accounting but discards almost all configuration and causal structure. The strongest compact task-relative predictor is M_relation/R2_RELATIONAL: three causal omission relations with h32/h64 readout. It is not a global replacement for X_FULL.

## What is new

The new result is a negative/structural one: dense +0…+32 sampling plus later windows and two frozen spatial fresh transforms found no observer-dependent first appearance. The multilevel descriptions are simultaneous projections of a distinction already present at HOST_STOP. This blocks a false promotion from continuing endogenous dynamics to endogenous creation of a new causal history.

## What remains open

An apparatus is still needed in which two branches are equivalent at HOST_STOP under X_FULL or a causally justified effective state, then DEE-only dynamics create a future-relevant distinction with a not-traversed counterfactual. Only then would mediation and “becomes new history” tests be justified.

Runtime: {result['elapsed_seconds']:.3f} s for the multiconfiguration main run. Kernel SHA-256: `{EXPECTED_KERNEL}`.
"""
    write_text(P01 / "SCIENTIFIC_REPORT.md", report)

    reproduction = """# Reproduction

Use CPython 3.13 with NumPy and the frozen DEE v27 binary whose SHA-256 is `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

From the v27 `tests` directory:

1. Run `00_SOURCE_AUDIT/recover_sources_and_observers.py`.
2. Run `02_PARENT_APPARATUS_SENTINEL/RUNNERS/run_process01_sentinel.py`.
3. Only if the sentinel is PASS, run `03_ENDOGENOUS_MAIN_RUN/RUNNERS/run_process01_multobserver.py --threads 1`.
4. Run `MASTER_INDEX/finalize_process01.py` to regenerate summaries and the official ZIP.

The exact parent runner is referenced by path and SHA-256 in `02_PARENT_APPARATUS_SENTINEL/PARENT_APPARATUS_FREEZE.json`; parent ZIPs are not duplicated. The main world receives only tick/checkpoint/read/log/stop after HOST_STOP. OMIT branches are t0-prepared diagnostic counterfactual worlds, not edits to the main world.
"""
    write_text(P01 / "REPRODUCTION.md", reproduction)

    index = """# PROCESOS 01 master index

- `00_SOURCE_AUDIT/`: kernel, CORE01–17, engineering and formal-document authority references.
- `01_OBSERVER_REGISTRY_RECOVERY/`: recovered observer registry and applicability matrix.
- `02_PARENT_APPARATUS_SENTINEL/`: frozen Ing06 V2 apparatus and exact reproduction sentinel.
- `03_ENDOGENOUS_MAIN_RUN/`: exact runner, full result and X_FULL checkpoint telemetry.
- `04_MULTIOBSERVER_ATLAS/`: compact timeline and projection graph.
- `05_FIRST_VISIBILITY_MAP/`: first-visibility table.
- `06_HIDDEN_VISIBLE_TRANSITIONS/`: visibility atlas and endogenous-history ledger.
- `07_CAUSAL_MEDIATION/`: explicit non-execution adjudication.
- `08_FRESH_VALIDATION/`: MAIN plus two frozen spatial transforms.
- `09_EFFECTIVE_PHYSICS_CROSSWALK/`: bounded crosswalk; no new quantum/relativistic claims.
- `CLAIM_LEDGER/`, `MANIFEST/`, `HASHES/`: final scientific and forensic closure.
"""
    write_text(P01 / "MASTER_INDEX" / "README.md", index)

    # Build manifest over all files except generated manifest/hashes and prior ZIPs.
    delivery_record = P01 / "MASTER_INDEX" / "DELIVERY_RECORD.json"
    excluded = {P01 / "MANIFEST" / "MANIFEST.json", P01 / "HASHES" / "HASHES.sha256", delivery_record}
    files = [p for p in sorted(P01.rglob("*")) if p.is_file() and p not in excluded and p.suffix.lower() != ".zip"]
    entries = [{"path": str(p.relative_to(P01)).replace("\\", "/"), "size": p.stat().st_size, "sha256": sha256_file(p)} for p in files]
    manifest = {
        "schema": "dee.v27.processes01.manifest.v1",
        "official_filename": ZIP_NAME,
        "kernel_sha256": EXPECTED_KERNEL,
        "file_count_before_manifest_and_hashes": len(entries),
        "parent_archives_embedded": False,
        "parent_reference_count": len(source["official_core_archives"]) + len(source["official_engineering_archives"]),
        "entries": entries,
    }
    write_json(P01 / "MANIFEST" / "MANIFEST.json", manifest)
    files_with_manifest = [p for p in sorted(P01.rglob("*")) if p.is_file() and p not in {P01 / "HASHES" / "HASHES.sha256", delivery_record} and p.suffix.lower() != ".zip"]
    hash_lines = [f"{sha256_file(p)}  {str(p.relative_to(P01)).replace(chr(92), '/')}" for p in files_with_manifest]
    write_text(P01 / "HASHES" / "HASHES.sha256", "\n".join(hash_lines))

    FINAL_DIR.mkdir(parents=True, exist_ok=True)
    final_zip = FINAL_DIR / ZIP_NAME
    temp_zip = P01 / ZIP_NAME
    if temp_zip.exists():
        temp_zip.unlink()
    with zipfile.ZipFile(temp_zip, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(P01.rglob("*")):
            if path.is_file() and path not in {temp_zip, delivery_record} and path.suffix.lower() != ".zip":
                arcname = (Path("PROCESOS_01") / path.relative_to(P01)).as_posix()
                zf.write(path, arcname)
    shutil.copy2(temp_zip, final_zip)
    temp_zip.unlink()

    # Final CRC and internal hash audit.
    with zipfile.ZipFile(final_zip) as zf:
        bad = zf.testzip()
        members = [info for info in zf.infolist() if not info.is_dir()]
        internal_hashes = zf.read("PROCESOS_01/HASHES/HASHES.sha256").decode("utf-8").splitlines()
        internal_failures = []
        for line in internal_hashes:
            expected, rel = line.split("  ", 1)
            actual = hashlib.sha256(zf.read("PROCESOS_01/" + rel)).hexdigest()
            if actual != expected:
                internal_failures.append(rel)
    delivery = {
        "path": str(final_zip),
        "name": final_zip.name,
        "size": final_zip.stat().st_size,
        "sha256": sha256_file(final_zip),
        "members": len(members),
        "crc": "PASS" if bad is None else f"FAIL:{bad}",
        "internal_hashes": "PASS" if not internal_failures else {"FAIL": internal_failures},
        "FINAL_ZIP_READY": bad is None and not internal_failures,
    }
    write_json(delivery_record, delivery)
    print(json.dumps(delivery, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
