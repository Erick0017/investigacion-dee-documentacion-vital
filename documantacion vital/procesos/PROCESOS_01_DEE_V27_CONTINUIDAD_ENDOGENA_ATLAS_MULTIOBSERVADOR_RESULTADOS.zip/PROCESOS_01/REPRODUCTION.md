# Reproduction

Use CPython 3.13 with NumPy and the frozen DEE v27 binary whose SHA-256 is `0b17ba32037935a255b0f2182a52137bceab424f7e09126b761076b63e42c6ff`.

From the v27 `tests` directory:

1. Run `00_SOURCE_AUDIT/recover_sources_and_observers.py`.
2. Run `02_PARENT_APPARATUS_SENTINEL/RUNNERS/run_process01_sentinel.py`.
3. Only if the sentinel is PASS, run `03_ENDOGENOUS_MAIN_RUN/RUNNERS/run_process01_multobserver.py --threads 1`.
4. Run `MASTER_INDEX/finalize_process01.py` to regenerate summaries and the official ZIP.

The exact parent runner is referenced by path and SHA-256 in `02_PARENT_APPARATUS_SENTINEL/PARENT_APPARATUS_FREEZE.json`; parent ZIPs are not duplicated. The main world receives only tick/checkpoint/read/log/stop after HOST_STOP. OMIT branches are t0-prepared diagnostic counterfactual worlds, not edits to the main world.
